function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

for (const k of ["IO.print"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  const _x_0 = ($observe$({$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 7, "values": {$: "Con", "head": 1, "tail": {$: "Con", "head": 2, "tail": {$: "Con", "head": 3, "tail": {$: "Nil"}}}}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 1, "values": {$: "Con", "head": 9, "tail": {$: "Con", "head": 9, "tail": {$: "Con", "head": 0, "tail": {$: "Nil"}}}}}, "tail": {$: "Nil"}}}}));
  const _x_1 = ($observe$({$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Con", "head": 1, "tail": {$: "Con", "head": 2, "tail": {$: "Con", "head": 3, "tail": {$: "Nil"}}}}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 1, "values": {$: "Con", "head": 9, "tail": {$: "Con", "head": 9, "tail": {$: "Con", "head": 0, "tail": {$: "Nil"}}}}}, "tail": {$: "Nil"}}}}));
  const _x_2 = ("\n" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($observe$({$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 7, "values": {$: "Con", "head": 1, "tail": {$: "Con", "head": 2, "tail": {$: "Con", "head": 3, "tail": {$: "Nil"}}}}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 1, "values": {$: "Con", "head": 9, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}}}}));
  const _x_5 = ("\n" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($observe$({$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Con", "head": 1, "tail": {$: "Con", "head": 2, "tail": {$: "Con", "head": 3, "tail": {$: "Nil"}}}}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 1, "values": {$: "Con", "head": 9, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}}}}));
  const _x_8 = ("\n" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($observe$({$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 7, "values": {$: "Con", "head": 1, "tail": {$: "Con", "head": 2, "tail": {$: "Con", "head": 3, "tail": {$: "Nil"}}}}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 1, "values": {$: "Nil"}}, "tail": {$: "Nil"}}}}));
  const _x_11 = ("\n" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($observe$({$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Con", "head": 1, "tail": {$: "Con", "head": 2, "tail": {$: "Con", "head": 3, "tail": {$: "Nil"}}}}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 1, "values": {$: "Nil"}}, "tail": {$: "Nil"}}}}));
  const _x_14 = ("\n" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($observe$({$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 7, "values": {$: "Con", "head": 1, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 1, "values": {$: "Con", "head": 9, "tail": {$: "Con", "head": 9, "tail": {$: "Con", "head": 0, "tail": {$: "Nil"}}}}}, "tail": {$: "Nil"}}}}));
  const _x_17 = ("\n" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = ($observe$({$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Con", "head": 1, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 1, "values": {$: "Con", "head": 9, "tail": {$: "Con", "head": 9, "tail": {$: "Con", "head": 0, "tail": {$: "Nil"}}}}}, "tail": {$: "Nil"}}}}));
  const _x_20 = ("\n" + _x_18);
  const _x_21 = (_x_19 + _x_20);
  const _x_22 = ($observe$({$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 7, "values": {$: "Con", "head": 1, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 1, "values": {$: "Con", "head": 9, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}}}}));
  const _x_23 = ("\n" + _x_21);
  const _x_24 = (_x_22 + _x_23);
  const _x_25 = ($observe$({$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Con", "head": 1, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 1, "values": {$: "Con", "head": 9, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}}}}));
  const _x_26 = ("\n" + _x_24);
  const _x_27 = (_x_25 + _x_26);
  const _x_28 = ($observe$({$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 7, "values": {$: "Con", "head": 1, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 1, "values": {$: "Nil"}}, "tail": {$: "Nil"}}}}));
  const _x_29 = ("\n" + _x_27);
  const _x_30 = (_x_28 + _x_29);
  const _x_31 = ($observe$({$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Con", "head": 1, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 1, "values": {$: "Nil"}}, "tail": {$: "Nil"}}}}));
  const _x_32 = ("\n" + _x_30);
  const _x_33 = (_x_31 + _x_32);
  const _x_34 = ($observe$({$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 7, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 1, "values": {$: "Con", "head": 9, "tail": {$: "Con", "head": 9, "tail": {$: "Con", "head": 0, "tail": {$: "Nil"}}}}}, "tail": {$: "Nil"}}}}));
  const _x_35 = ("\n" + _x_33);
  const _x_36 = (_x_34 + _x_35);
  const _x_37 = ($observe$({$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 1, "values": {$: "Con", "head": 9, "tail": {$: "Con", "head": 9, "tail": {$: "Con", "head": 0, "tail": {$: "Nil"}}}}}, "tail": {$: "Nil"}}}}));
  const _x_38 = ("\n" + _x_36);
  const _x_39 = (_x_37 + _x_38);
  const _x_40 = ($observe$({$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 7, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 1, "values": {$: "Con", "head": 9, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}}}}));
  const _x_41 = ("\n" + _x_39);
  const _x_42 = (_x_40 + _x_41);
  const _x_43 = ($observe$({$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 1, "values": {$: "Con", "head": 9, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}}}}));
  const _x_44 = ("\n" + _x_42);
  const _x_45 = (_x_43 + _x_44);
  const _x_46 = ($observe$({$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 7, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 1, "values": {$: "Nil"}}, "tail": {$: "Nil"}}}}));
  const _x_47 = ("\n" + _x_45);
  const _x_48 = (_x_46 + _x_47);
  const _x_49 = ($observe$({$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 0, "values": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": 1, "values": {$: "Nil"}}, "tail": {$: "Nil"}}}}));
  const _x_50 = ("\n" + _x_48);
  return (_x_51) => $IO$print$((_x_49 + _x_50), _x_51);
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $observe$(_batches_0) {
  const _x_0 = ($Nat$show$(($count$058size$1260$(_batches_0))));
  const _x_1 = ($Nat$show$(($$$$047$$$047$$$047src$047ecs$047event$045runtime$058size$1260$(_batches_0))));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058size$1260$(_batches_0) {
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058count$1260$(($$$$047$$$047$$$047src$047ecs$047event$045runtime$058values$1260$(_batches_0)));
}

function $count$058size$1260$(_batches_0) {
  return $count$058size_loop$1260$(_batches_0, 0);
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058count$1260$(_items_0) {
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058count_loop$1260$(_items_0, 0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058values$1260$(_batches_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _batches_0["head"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1260$(_items_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058values$1260$(_rest_0)));
  }
}

function $count$058size_loop$1260$($0, $1) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _acc_0 = $1;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058count_loop$1260$(_items_0, _acc_0));
        continue;
      }
    }
  }
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058count_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1260$(_left_0, _right_0) {
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);