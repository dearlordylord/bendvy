function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// Harness-only UTF-8/FNV-1a32 transport. No timed ECS operations are substituted.
let featureStart = null;
let featureChunks = [];
let featureDigest = 2166136261;
let featureBytes = 0;
function io_feature_begin() {
  if (featureStart !== null) throw Error("nested feature timer");
  featureChunks = [];
  featureDigest = 2166136261;
  featureBytes = 0;
  featureStart = process.hrtime.bigint();
  return {$: "Unit"};
}
function io_feature_capture(text) {
  if (featureStart === null) throw Error("capture outside feature timer");
  const bytes = io_bytes(text + "\n");
  for (const byte of bytes) featureDigest = Math.imul(featureDigest ^ byte, 16777619) >>> 0;
  featureBytes += bytes.length;
  featureChunks.push(bytes);
  return {$: "Unit"};
}
function io_feature_end() {
  if (featureStart === null) throw Error("end without feature timer");
  const elapsedNs = process.hrtime.bigint() - featureStart;
  featureStart = null;
  io_out(2, io_bytes(JSON.stringify({elapsedNs: elapsedNs.toString(), bytes: featureBytes, digest: featureDigest}) + "\n"));
  for (const bytes of featureChunks) io_out(1, bytes);
  featureChunks = [];
  return {$: "Unit"};
}
io_eff("timing.begin", io_feature_begin);
io_eff("timing.capture", io_feature_capture);
io_eff("timing.end", io_feature_end);

})();

for (const k of ["timing.begin","timing.end","timing.capture"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $timing$058begin$(_x_1), run_clo((_x_2) => {
  return $repeat$(1);
}), _x_0);
});
}

function $IO$bind$(_m_0, _f_0, _k_0) {
  return run_tail(_m_0, run_clo((_x_0) => {
  return run_tail(_f_0(_x_0), _k_0);
}));
}

function $timing$058begin$(_k_0) {
  return { $: "$FFI", run: $0eff["timing.begin"].run, need: $0eff["timing.begin"].need, args: [], kont: (_k_0) };
}
function $repeat$(_fuel_0) {
  if (_fuel_0 === 0) {
    return (_x_0) => $timing$058end$(_x_0);
  } else {
    const _rest_0 = (_fuel_0 - 1);
    return run_clo((_x_1) => {
  return $IO$bind$(run_clo((_x_2) => {
  const _x_3 = ($$$$047experiments$047public$045nested$045provision$047app$058scenario$(11));
  const _x_4 = (_x_3 + "");
  const _x_5 = ($$$$047experiments$047public$045nested$045provision$047app$058scenario$(9));
  const _x_6 = ("\ncase11|" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($$$$047experiments$047public$045nested$045provision$047app$058scenario$(8));
  const _x_9 = ("\ncase9|" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($$$$047experiments$047public$045nested$045provision$047app$058scenario$(7));
  const _x_12 = ("\ncase8|" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = ($$$$047experiments$047public$045nested$045provision$047app$058scenario$(3));
  const _x_15 = ("\ncase7|" + _x_13);
  const _x_16 = (_x_14 + _x_15);
  const _x_17 = ($$$$047experiments$047public$045nested$045provision$047app$058scenario$(1));
  const _x_18 = ("\ncase3|" + _x_16);
  const _x_19 = (_x_17 + _x_18);
  const _x_20 = ($$$$047experiments$047public$045nested$045provision$047app$058scenario$(0));
  const _x_21 = ("\ncase1|" + _x_19);
  const _x_22 = (_x_20 + _x_21);
  return $IO$bind$((_x_23) => $timing$058capture$(("schema-A\ncase0|" + _x_22), _x_23), run_clo((_x_24) => {
  const _x_25 = ($$$$047experiments$047public$045nested$045provision$047other$058scenario$(11));
  const _x_26 = (_x_25 + "");
  const _x_27 = ($$$$047experiments$047public$045nested$045provision$047other$058scenario$(9));
  const _x_28 = ("\ncase11|" + _x_26);
  const _x_29 = (_x_27 + _x_28);
  const _x_30 = ($$$$047experiments$047public$045nested$045provision$047other$058scenario$(8));
  const _x_31 = ("\ncase9|" + _x_29);
  const _x_32 = (_x_30 + _x_31);
  const _x_33 = ($$$$047experiments$047public$045nested$045provision$047other$058scenario$(7));
  const _x_34 = ("\ncase8|" + _x_32);
  const _x_35 = (_x_33 + _x_34);
  const _x_36 = ($$$$047experiments$047public$045nested$045provision$047other$058scenario$(3));
  const _x_37 = ("\ncase7|" + _x_35);
  const _x_38 = (_x_36 + _x_37);
  const _x_39 = ($$$$047experiments$047public$045nested$045provision$047other$058scenario$(1));
  const _x_40 = ("\ncase3|" + _x_38);
  const _x_41 = (_x_39 + _x_40);
  const _x_42 = ($$$$047experiments$047public$045nested$045provision$047other$058scenario$(0));
  const _x_43 = ("\ncase1|" + _x_41);
  const _x_44 = (_x_42 + _x_43);
  return (_x_45) => $timing$058capture$(("schema-B\ncase0|" + _x_44), _x_45);
}), _x_2);
}), run_clo((_x_46) => {
  return $repeat$(_rest_0);
}), _x_1);
});
  }
}

function $timing$058end$(_k_0) {
  return { $: "$FFI", run: $0eff["timing.end"].run, need: $0eff["timing.end"].need, args: [], kont: (_k_0) };
}
function $timing$058capture$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["timing.capture"].run, need: $0eff["timing.capture"].need, args: [(_text_0)], kont: (_k_0) };
}
function $$$$047experiments$047public$045nested$045provision$047app$058scenario$(_mode_0) {
  return $$$$047experiments$047public$045nested$045provision$047app$058created$(($$$$047src$047ecs$047world$058create$1260$(($$$$047src$047ecs$047world$058factory$()), ($$$$047experiments$047public$045nested$045provision$047app$058resource_start$(_mode_0)))), _mode_0);
}

function $$$$047experiments$047public$045nested$045provision$047other$058scenario$(_mode_0) {
  return $$$$047experiments$047public$045nested$045provision$047other$058created$(($$$$047src$047ecs$047world$058create$1261$(($$$$047src$047ecs$047world$058factory$()), ($$$$047experiments$047public$045nested$045provision$047other$058resource_start$(_mode_0)))), _mode_0);
}

function $$$$047experiments$047public$045nested$045provision$047app$058created$(_result_0, _mode_0) {
  if (_result_0.$ === "../src/ecs/world.Created") {
    const _world_0 = _result_0["world"];
    return $$$$047experiments$047public$045nested$045provision$047app$058reserved$(($$$$047src$047ecs$047world$058reserve_id$1260$(($$$$047experiments$047public$045nested$045provision$047app$058configure$(_world_0, _mode_0)))), _mode_0);
  } else {
    return "create-rejected";
  }
}

function $$$$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $$$$047src$047ecs$047world$058factory$() {
  return {$: "../src/ecs/world.Factory", "nextNamespace": 1};
}

function $$$$047experiments$047public$045nested$045provision$047app$058resource_start$(_mode_0) {
  if (_mode_0 == 1) {
    return {$: "../experiments/public-nested-provision/app.Resources", "resource": ($$$$047experiments$047public$045nested$045provision$047app$058slot$(0, 20)), "service": ($$$$047experiments$047public$045nested$045provision$047app$058slot$(1, 30)), "resourceWrites": 0, "hostCalls": 0, "conditionCalls": 0, "retired": {$: "Nil"}, "trace": {$: "Nil"}, "reservedIds": {$: "Nil"}};
  } else if ((_mode_0 & 3) == 1) {
    return {$: "../experiments/public-nested-provision/app.Resources", "resource": ($$$$047experiments$047public$045nested$045provision$047app$058slot$(1, 20)), "service": ($$$$047experiments$047public$045nested$045provision$047app$058slot$(1, 30)), "resourceWrites": 0, "hostCalls": 0, "conditionCalls": 0, "retired": {$: "Nil"}, "trace": {$: "Nil"}, "reservedIds": {$: "Nil"}};
  } else if (_mode_0 == 3) {
    return {$: "../experiments/public-nested-provision/app.Resources", "resource": ($$$$047experiments$047public$045nested$045provision$047app$058slot$(1, 20)), "service": ($$$$047experiments$047public$045nested$045provision$047app$058slot$(0, 30)), "resourceWrites": 0, "hostCalls": 0, "conditionCalls": 0, "retired": {$: "Nil"}, "trace": {$: "Nil"}, "reservedIds": {$: "Nil"}};
  } else if (_mode_0 == 11) {
    return {$: "../experiments/public-nested-provision/app.Resources", "resource": ($$$$047experiments$047public$045nested$045provision$047app$058slot$(0, 20)), "service": ($$$$047experiments$047public$045nested$045provision$047app$058slot$(0, 30)), "resourceWrites": 0, "hostCalls": 0, "conditionCalls": 0, "retired": {$: "Nil"}, "trace": {$: "Nil"}, "reservedIds": {$: "Nil"}};
  } else if ((_mode_0 & 3) == 3) {
    return {$: "../experiments/public-nested-provision/app.Resources", "resource": ($$$$047experiments$047public$045nested$045provision$047app$058slot$(1, 20)), "service": ($$$$047experiments$047public$045nested$045provision$047app$058slot$(1, 30)), "resourceWrites": 0, "hostCalls": 0, "conditionCalls": 0, "retired": {$: "Nil"}, "trace": {$: "Nil"}, "reservedIds": {$: "Nil"}};
  } else if (_mode_0 == 2) {
    return {$: "../experiments/public-nested-provision/app.Resources", "resource": ($$$$047experiments$047public$045nested$045provision$047app$058slot$(2, 20)), "service": ($$$$047experiments$047public$045nested$045provision$047app$058slot$(1, 30)), "resourceWrites": 0, "hostCalls": 0, "conditionCalls": 0, "retired": {$: "Nil"}, "trace": {$: "Nil"}, "reservedIds": {$: "Nil"}};
  } else if ((_mode_0 & 3) == 2) {
    return {$: "../experiments/public-nested-provision/app.Resources", "resource": ($$$$047experiments$047public$045nested$045provision$047app$058slot$(1, 20)), "service": ($$$$047experiments$047public$045nested$045provision$047app$058slot$(1, 30)), "resourceWrites": 0, "hostCalls": 0, "conditionCalls": 0, "retired": {$: "Nil"}, "trace": {$: "Nil"}, "reservedIds": {$: "Nil"}};
  } else if (_mode_0 == 4) {
    return {$: "../experiments/public-nested-provision/app.Resources", "resource": ($$$$047experiments$047public$045nested$045provision$047app$058slot$(1, 20)), "service": ($$$$047experiments$047public$045nested$045provision$047app$058slot$(2, 30)), "resourceWrites": 0, "hostCalls": 0, "conditionCalls": 0, "retired": {$: "Nil"}, "trace": {$: "Nil"}, "reservedIds": {$: "Nil"}};
  } else {
    return {$: "../experiments/public-nested-provision/app.Resources", "resource": ($$$$047experiments$047public$045nested$045provision$047app$058slot$(1, 20)), "service": ($$$$047experiments$047public$045nested$045provision$047app$058slot$(1, 30)), "resourceWrites": 0, "hostCalls": 0, "conditionCalls": 0, "retired": {$: "Nil"}, "trace": {$: "Nil"}, "reservedIds": {$: "Nil"}};
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058created$(_result_0, _mode_0) {
  if (_result_0.$ === "../src/ecs/world.Created") {
    const _world_0 = _result_0["world"];
    return $$$$047experiments$047public$045nested$045provision$047other$058reserved$(($$$$047src$047ecs$047world$058reserve_id$1261$(($$$$047experiments$047public$045nested$045provision$047other$058configure$(_world_0, _mode_0)))), _mode_0);
  } else {
    return "create-rejected";
  }
}

function $$$$047src$047ecs$047world$058create$1261$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047src$047ecs$047world$058create_checked$1261$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $$$$047experiments$047public$045nested$045provision$047other$058resource_start$(_mode_0) {
  if (_mode_0 == 1) {
    return {$: "../experiments/public-nested-provision/other.Resources", "resource": ($$$$047experiments$047public$045nested$045provision$047other$058slot$(0, 20)), "service": ($$$$047experiments$047public$045nested$045provision$047other$058slot$(1, 30)), "resourceWrites": 0, "hostCalls": 0, "conditionCalls": 0, "retired": {$: "Nil"}, "trace": {$: "Nil"}, "reservedIds": {$: "Nil"}};
  } else if ((_mode_0 & 3) == 1) {
    return {$: "../experiments/public-nested-provision/other.Resources", "resource": ($$$$047experiments$047public$045nested$045provision$047other$058slot$(1, 20)), "service": ($$$$047experiments$047public$045nested$045provision$047other$058slot$(1, 30)), "resourceWrites": 0, "hostCalls": 0, "conditionCalls": 0, "retired": {$: "Nil"}, "trace": {$: "Nil"}, "reservedIds": {$: "Nil"}};
  } else if (_mode_0 == 3) {
    return {$: "../experiments/public-nested-provision/other.Resources", "resource": ($$$$047experiments$047public$045nested$045provision$047other$058slot$(1, 20)), "service": ($$$$047experiments$047public$045nested$045provision$047other$058slot$(0, 30)), "resourceWrites": 0, "hostCalls": 0, "conditionCalls": 0, "retired": {$: "Nil"}, "trace": {$: "Nil"}, "reservedIds": {$: "Nil"}};
  } else if (_mode_0 == 11) {
    return {$: "../experiments/public-nested-provision/other.Resources", "resource": ($$$$047experiments$047public$045nested$045provision$047other$058slot$(0, 20)), "service": ($$$$047experiments$047public$045nested$045provision$047other$058slot$(0, 30)), "resourceWrites": 0, "hostCalls": 0, "conditionCalls": 0, "retired": {$: "Nil"}, "trace": {$: "Nil"}, "reservedIds": {$: "Nil"}};
  } else if ((_mode_0 & 3) == 3) {
    return {$: "../experiments/public-nested-provision/other.Resources", "resource": ($$$$047experiments$047public$045nested$045provision$047other$058slot$(1, 20)), "service": ($$$$047experiments$047public$045nested$045provision$047other$058slot$(1, 30)), "resourceWrites": 0, "hostCalls": 0, "conditionCalls": 0, "retired": {$: "Nil"}, "trace": {$: "Nil"}, "reservedIds": {$: "Nil"}};
  } else if (_mode_0 == 2) {
    return {$: "../experiments/public-nested-provision/other.Resources", "resource": ($$$$047experiments$047public$045nested$045provision$047other$058slot$(2, 20)), "service": ($$$$047experiments$047public$045nested$045provision$047other$058slot$(1, 30)), "resourceWrites": 0, "hostCalls": 0, "conditionCalls": 0, "retired": {$: "Nil"}, "trace": {$: "Nil"}, "reservedIds": {$: "Nil"}};
  } else if ((_mode_0 & 3) == 2) {
    return {$: "../experiments/public-nested-provision/other.Resources", "resource": ($$$$047experiments$047public$045nested$045provision$047other$058slot$(1, 20)), "service": ($$$$047experiments$047public$045nested$045provision$047other$058slot$(1, 30)), "resourceWrites": 0, "hostCalls": 0, "conditionCalls": 0, "retired": {$: "Nil"}, "trace": {$: "Nil"}, "reservedIds": {$: "Nil"}};
  } else if (_mode_0 == 4) {
    return {$: "../experiments/public-nested-provision/other.Resources", "resource": ($$$$047experiments$047public$045nested$045provision$047other$058slot$(1, 20)), "service": ($$$$047experiments$047public$045nested$045provision$047other$058slot$(2, 30)), "resourceWrites": 0, "hostCalls": 0, "conditionCalls": 0, "retired": {$: "Nil"}, "trace": {$: "Nil"}, "reservedIds": {$: "Nil"}};
  } else {
    return {$: "../experiments/public-nested-provision/other.Resources", "resource": ($$$$047experiments$047public$045nested$045provision$047other$058slot$(1, 20)), "service": ($$$$047experiments$047public$045nested$045provision$047other$058slot$(1, 30)), "resourceWrites": 0, "hostCalls": 0, "conditionCalls": 0, "retired": {$: "Nil"}, "trace": {$: "Nil"}, "reservedIds": {$: "Nil"}};
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058reserved$(_result_0, _mode_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $$$$047experiments$047public$045nested$045provision$047app$058activated$(($$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)), _mode_0);
  } else {
    return "reserve-rejected";
  }
}

function $$$$047src$047ecs$047world$058reserve_id$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047world$058reserve_available$1260$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047experiments$047public$045nested$045provision$047app$058configure$(_world_0, _mode_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _t_0 = _world_0["store"];
  const _column_0 = _t_0["column"];
  const __0 = _t_0["family"];
  const _writes_0 = _t_0["writes"];
  const _t_1 = _world_0["resource"];
  const _resource_0 = _t_1["resource"];
  const _host_0 = _t_1["service"];
  const _writes_1 = _t_1["resourceWrites"];
  const _calls_0 = _t_1["hostCalls"];
  const _conditions_0 = _t_1["conditionCalls"];
  const _retired_0 = _t_1["retired"];
  const _trace_0 = _t_1["trace"];
  const _reservedIds_0 = _t_1["reservedIds"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  if (_mode_0 == 5) {
    return {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/app.Store", "column": _column_0, "family": {$: "../experiments/public-nested-provision/app.AbsentFamily"}, "writes": _writes_0}, "resource": {$: "../experiments/public-nested-provision/app.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_1, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
  } else if ((_mode_0 & 1) == 1) {
    return {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/app.Store", "column": _column_0, "family": __0, "writes": _writes_0}, "resource": {$: "../experiments/public-nested-provision/app.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_1, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
  } else if (_mode_0 == 6) {
    return {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/app.Store", "column": _column_0, "family": {$: "../experiments/public-nested-provision/app.WrongFamily", "descriptor": ($$$$047experiments$047public$045nested$045provision$047app$058other_family$())}, "writes": _writes_0}, "resource": {$: "../experiments/public-nested-provision/app.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_1, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
  } else if ((_mode_0 & 7) == 6) {
    return {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/app.Store", "column": _column_0, "family": __0, "writes": _writes_0}, "resource": {$: "../experiments/public-nested-provision/app.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_1, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
  } else if (_mode_0 == 10) {
    return {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/app.Store", "column": {$: "../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}}, "family": __0, "writes": _writes_0}, "resource": {$: "../experiments/public-nested-provision/app.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_1, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
  } else if ((_mode_0 & 7) == 2) {
    return {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/app.Store", "column": _column_0, "family": __0, "writes": _writes_0}, "resource": {$: "../experiments/public-nested-provision/app.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_1, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
  } else if (_mode_0 == 8) {
    return {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/app.Store", "column": _column_0, "family": __0, "writes": _writes_0}, "resource": {$: "../experiments/public-nested-provision/app.Resources", "resource": _resource_0, "service": {$: "../experiments/public-nested-provision/app.Missing"}, "resourceWrites": _writes_1, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
  } else {
    return {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/app.Store", "column": _column_0, "family": __0, "writes": _writes_0}, "resource": {$: "../experiments/public-nested-provision/app.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_1, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
  }
}

function $$$$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../src/ecs/world.CreateRejected", "factory": {$: "../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../src/ecs/world.Created", "factory": {$: "../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($$$$047experiments$047public$045nested$045provision$047app$058empty$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058slot$(_mode_0, _value_0) {
  if (_mode_0 == 0) {
    return {$: "../experiments/public-nested-provision/app.Missing"};
  } else if ((_mode_0 & 1) == 0) {
    return {$: "../experiments/public-nested-provision/app.Incompatible", "owner": array_node([_value_0], [((_value_0 + 100) >>> 0)])};
  } else if (_mode_0 == 1) {
    return {$: "../experiments/public-nested-provision/app.Ready", "owner": array_node([_value_0], [((_value_0 + 100) >>> 0)])};
  } else {
    return {$: "../experiments/public-nested-provision/app.Incompatible", "owner": array_node([_value_0], [((_value_0 + 100) >>> 0)])};
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058reserved$(_result_0, _mode_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $$$$047experiments$047public$045nested$045provision$047other$058activated$(($$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0)), _mode_0);
  } else {
    return "reserve-rejected";
  }
}

function $$$$047src$047ecs$047world$058reserve_id$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047world$058reserve_available$1261$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047experiments$047public$045nested$045provision$047other$058configure$(_world_0, _mode_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _t_0 = _world_0["store"];
  const _column_0 = _t_0["column"];
  const __0 = _t_0["family"];
  const _writes_0 = _t_0["writes"];
  const _t_1 = _world_0["resource"];
  const _resource_0 = _t_1["resource"];
  const _host_0 = _t_1["service"];
  const _writes_1 = _t_1["resourceWrites"];
  const _calls_0 = _t_1["hostCalls"];
  const _conditions_0 = _t_1["conditionCalls"];
  const _retired_0 = _t_1["retired"];
  const _trace_0 = _t_1["trace"];
  const _reservedIds_0 = _t_1["reservedIds"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  if (_mode_0 == 5) {
    return {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/other.Store", "column": _column_0, "family": {$: "../experiments/public-nested-provision/other.AbsentFamily"}, "writes": _writes_0}, "resource": {$: "../experiments/public-nested-provision/other.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_1, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
  } else if ((_mode_0 & 1) == 1) {
    return {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/other.Store", "column": _column_0, "family": __0, "writes": _writes_0}, "resource": {$: "../experiments/public-nested-provision/other.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_1, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
  } else if (_mode_0 == 6) {
    return {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/other.Store", "column": _column_0, "family": {$: "../experiments/public-nested-provision/other.WrongFamily", "descriptor": ($$$$047experiments$047public$045nested$045provision$047other$058other_family$())}, "writes": _writes_0}, "resource": {$: "../experiments/public-nested-provision/other.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_1, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
  } else if ((_mode_0 & 7) == 6) {
    return {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/other.Store", "column": _column_0, "family": __0, "writes": _writes_0}, "resource": {$: "../experiments/public-nested-provision/other.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_1, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
  } else if (_mode_0 == 10) {
    return {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/other.Store", "column": {$: "../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}}, "family": __0, "writes": _writes_0}, "resource": {$: "../experiments/public-nested-provision/other.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_1, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
  } else if ((_mode_0 & 7) == 2) {
    return {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/other.Store", "column": _column_0, "family": __0, "writes": _writes_0}, "resource": {$: "../experiments/public-nested-provision/other.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_1, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
  } else if (_mode_0 == 8) {
    return {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/other.Store", "column": _column_0, "family": __0, "writes": _writes_0}, "resource": {$: "../experiments/public-nested-provision/other.Resources", "resource": _resource_0, "service": {$: "../experiments/public-nested-provision/other.Missing"}, "resourceWrites": _writes_1, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
  } else {
    return {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/other.Store", "column": _column_0, "family": __0, "writes": _writes_0}, "resource": {$: "../experiments/public-nested-provision/other.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_1, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
  }
}

function $$$$047src$047ecs$047world$058create_checked$1261$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../src/ecs/world.CreateRejected", "factory": {$: "../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../src/ecs/world.Created", "factory": {$: "../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($$$$047experiments$047public$045nested$045provision$047other$058empty$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058slot$(_mode_0, _value_0) {
  if (_mode_0 == 0) {
    return {$: "../experiments/public-nested-provision/other.Missing"};
  } else if ((_mode_0 & 1) == 0) {
    return {$: "../experiments/public-nested-provision/other.Incompatible", "owner": array_node([_value_0], [((_value_0 + 100) >>> 0)])};
  } else if (_mode_0 == 1) {
    return {$: "../experiments/public-nested-provision/other.Ready", "owner": array_node([_value_0], [((_value_0 + 100) >>> 0)])};
  } else {
    return {$: "../experiments/public-nested-provision/other.Incompatible", "owner": array_node([_value_0], [((_value_0 + 100) >>> 0)])};
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058activated$(_result_0, _mode_0) {
  const _world_0 = _result_0["fst"];
  return $$$$047experiments$047public$045nested$045provision$047app$058start_a$(($$$$047src$047ecs$047system$058register$1260$(_world_0, "A", {$: "Con", "head": "component.write", "tail": {$: "Con", "head": "resource.write", "tail": {$: "Con", "head": "service.call", "tail": {$: "Con", "head": "event.write", "tail": {$: "Con", "head": "commands", "tail": {$: "Nil"}}}}}})), _mode_0);
}

function $$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0) {
  return $$$$047src$047ecs$047world$058set_live_join$1260$(true, _handle_0, ($$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047src$047ecs$047world$058reserve_available$1260$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../src/ecs/world.ReservationRejected", "error": {$: "../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047src$047ecs$047world$058reserve_finish$1260$({$: "../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047src$047ecs$047world$058reserve_finish$1260$(($$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058other_family$() {
  return {$: "../src/ecs/component.Family", "name": "other-cells"};
}

function $$$$047experiments$047public$045nested$045provision$047app$058empty$(__0) {
  return {$: "../experiments/public-nested-provision/app.Store", "column": {$: "../src/ecs/column.Column", "values": [{$: "Some", "value": array_node([10], [99])}], "stamps": {$: "Nil"}}, "family": {$: "../experiments/public-nested-provision/app.DeclaredFamily", "descriptor": ($$$$047experiments$047public$045nested$045provision$047app$058family$())}, "writes": 0};
}

function $$$$047experiments$047public$045nested$045provision$047other$058activated$(_result_0, _mode_0) {
  const _world_0 = _result_0["fst"];
  return $$$$047experiments$047public$045nested$045provision$047other$058start_a$(($$$$047src$047ecs$047system$058register$1261$(_world_0, "A", {$: "Con", "head": "component.write", "tail": {$: "Con", "head": "resource.write", "tail": {$: "Con", "head": "service.call", "tail": {$: "Con", "head": "event.write", "tail": {$: "Con", "head": "commands", "tail": {$: "Nil"}}}}}})), _mode_0);
}

function $$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0) {
  return $$$$047src$047ecs$047world$058set_live_join$1261$(true, _handle_0, ($$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047src$047ecs$047world$058reserve_available$1261$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../src/ecs/world.ReservationRejected", "error": {$: "../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047src$047ecs$047world$058reserve_finish$1261$({$: "../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047src$047ecs$047world$058reserve_finish$1261$(($$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058other_family$() {
  return {$: "../src/ecs/component.Family", "name": "other-cells"};
}

function $$$$047experiments$047public$045nested$045provision$047other$058empty$(__0) {
  return {$: "../experiments/public-nested-provision/other.Store", "column": {$: "../src/ecs/column.Column", "values": [{$: "Some", "value": array_node([10], [99])}], "stamps": {$: "Nil"}}, "family": {$: "../experiments/public-nested-provision/other.DeclaredFamily", "descriptor": ($$$$047experiments$047public$045nested$045provision$047other$058family$())}, "writes": 0};
}

function $$$$047experiments$047public$045nested$045provision$047app$058start_a$(_result_0, _mode_0) {
  if (_result_0.$ === "../src/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _a_0 = _result_0["registry"];
    return $$$$047experiments$047public$045nested$045provision$047app$058start_b$(($$$$047src$047ecs$047system$058register$1260$(_world_0, "B", {$: "Con", "head": "component.write", "tail": {$: "Con", "head": "resource.write", "tail": {$: "Con", "head": "service.call", "tail": {$: "Con", "head": "event.write", "tail": {$: "Con", "head": "commands", "tail": {$: "Nil"}}}}}})), _a_0, _mode_0);
  } else {
    return "registration-failed";
  }
}

function $$$$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0) {
  return $$$$047src$047ecs$047system$058register_namespace$1260$(($$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047src$047ecs$047world$058set_live_join$1260$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047src$047ecs$047world$058reserve_finish$1260$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../src/ecs/world.Reserved", "handle": {$: "../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047src$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058family$() {
  return {$: "../src/ecs/component.Family", "name": "cells"};
}

function $$$$047experiments$047public$045nested$045provision$047other$058start_a$(_result_0, _mode_0) {
  if (_result_0.$ === "../src/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _a_0 = _result_0["registry"];
    return $$$$047experiments$047public$045nested$045provision$047other$058start_b$(($$$$047src$047ecs$047system$058register$1261$(_world_0, "B", {$: "Con", "head": "component.write", "tail": {$: "Con", "head": "resource.write", "tail": {$: "Con", "head": "service.call", "tail": {$: "Con", "head": "event.write", "tail": {$: "Con", "head": "commands", "tail": {$: "Nil"}}}}}})), _a_0, _mode_0);
  } else {
    return "registration-failed";
  }
}

function $$$$047src$047ecs$047system$058register$1261$(_world_0, _name_0, _access_0) {
  return $$$$047src$047ecs$047system$058register_namespace$1261$(($$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $$$$047src$047ecs$047world$058set_live_join$1261$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047src$047ecs$047world$058reserve_finish$1261$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../src/ecs/world.Reserved", "handle": {$: "../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047experiments$047public$045nested$045provision$047other$058family$() {
  return {$: "../src/ecs/component.Family", "name": "cells"};
}

function $$$$047experiments$047public$045nested$045provision$047app$058start_b$(_result_0, _a_0, _mode_0) {
  if (_result_0.$ === "../src/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _b_0 = _result_0["registry"];
    return $$$$047experiments$047public$045nested$045provision$047app$058built$(($$$$047src$047ecs$047schedule$045provision$058build$1260$(1, "nested", ($$$$047experiments$047public$045nested$045provision$047app$058nested$(_mode_0)), {$: "Con", "head": 1, "tail": {$: "Con", "head": 2, "tail": {$: "Nil"}}}, {$: "../experiments/public-nested-provision/app.Owners", "a": _a_0, "b": _b_0})), _world_0);
  } else {
    return "registration-failed";
  }
}

function $$$$047src$047ecs$047system$058register_namespace$1260$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047src$047ecs$047system$058register_join$1260$(($$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../src/ecs/world.Rejected", "error": {$: "../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../src/ecs/world.Accepted"}};
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058start_b$(_result_0, _a_0, _mode_0) {
  if (_result_0.$ === "../src/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _b_0 = _result_0["registry"];
    return $$$$047experiments$047public$045nested$045provision$047other$058built$(($$$$047src$047ecs$047schedule$045provision$058build$1261$(1, "nested", ($$$$047experiments$047public$045nested$045provision$047other$058nested$(_mode_0)), {$: "Con", "head": 1, "tail": {$: "Con", "head": 2, "tail": {$: "Nil"}}}, {$: "../experiments/public-nested-provision/other.Owners", "a": _a_0, "b": _b_0})), _world_0);
  } else {
    return "registration-failed";
  }
}

function $$$$047src$047ecs$047system$058register_namespace$1261$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047src$047ecs$047system$058register_join$1261$(($$$$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047src$047ecs$047world$058namespace$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../src/ecs/world.Rejected", "error": {$: "../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../src/ecs/world.Accepted"}};
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058built$(_result_0, _world_0) {
  if (_result_0.$ === "../src/ecs/schedule-provision.Invalid") {
    const _owners_0 = _result_0["owners"];
    return $$$$047experiments$047public$045nested$045provision$047app$058invalid_snapshot$(($$$$047experiments$047public$045nested$045provision$047app$058owner_snapshot$(_owners_0)), ($$$$047experiments$047public$045nested$045provision$047app$058world_snapshot$(_world_0)));
  } else {
    const _schedule_0 = _result_0["schedule"];
    return $$$$047experiments$047public$045nested$045provision$047app$058provision_result$(($$$$047src$047ecs$047schedule$045provision$058run$1260$(_schedule_0, _world_0)));
  }
}

function $$$$047src$047ecs$047schedule$045provision$058build$1260$(_namespace_0, _name_0, _plan_0, _catalog_0, _owners_0) {
  return $$$$047src$047ecs$047schedule$045provision$058finish_build$1260$(($$$$047src$047ecs$047schedule$058build$1260$(_namespace_0, _name_0, ($$$$047src$047ecs$047schedule$045provision$058flatten$1260$(_plan_0)), _catalog_0, _owners_0)), ($$$$047src$047ecs$047schedule$045provision$058unique$1260$(($$$$047src$047ecs$047schedule$045provision$058requirements$1260$(_plan_0)))));
}

function $$$$047experiments$047public$045nested$045provision$047app$058nested$(_mode_0) {
  if (_mode_0 == 7) {
    return {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.System", "id": 1, "condition": 1}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Nil"}}}}}, "right": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Empty"}, "right": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.System", "id": 1, "condition": 1}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Nil"}}}}};
  } else if ((_mode_0 & 3) == 3) {
    return {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.Phase", "name": "before"}, "requirements": {$: "Nil"}}, "right": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.System", "id": 1, "condition": 1}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Nil"}}}}}}, "right": {$: "../src/ecs/schedule-provision.Empty"}}, "right": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.Phase", "name": "inner"}, "requirements": {$: "Nil"}}, "right": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.System", "id": 2, "condition": 1}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Nil"}}}}}}}};
  } else if (_mode_0 == 9) {
    return {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Empty"}, "right": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.Phase", "name": "empty"}, "requirements": {$: "Nil"}}, "right": {$: "../src/ecs/schedule-provision.Empty"}}};
  } else if ((_mode_0 & 3) == 1) {
    return {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.Phase", "name": "before"}, "requirements": {$: "Nil"}}, "right": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.System", "id": 1, "condition": 1}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Nil"}}}}}}, "right": {$: "../src/ecs/schedule-provision.Empty"}}, "right": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.Phase", "name": "inner"}, "requirements": {$: "Nil"}}, "right": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.System", "id": 2, "condition": 1}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Nil"}}}}}}}};
  } else if (_mode_0 == 8) {
    return {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.Phase", "name": "before"}, "requirements": {$: "Nil"}}, "right": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Empty"}, "right": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.System", "id": 2, "condition": 0}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Nil"}}}}}}};
  } else if ((_mode_0 & 3) == 0) {
    return {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.Phase", "name": "before"}, "requirements": {$: "Nil"}}, "right": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.System", "id": 1, "condition": 1}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Nil"}}}}}}, "right": {$: "../src/ecs/schedule-provision.Empty"}}, "right": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.Phase", "name": "inner"}, "requirements": {$: "Nil"}}, "right": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.System", "id": 2, "condition": 1}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Nil"}}}}}}}};
  } else if (_mode_0 == 10) {
    return {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.Phase", "name": "family-only"}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Nil"}}};
  } else {
    return {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.Phase", "name": "before"}, "requirements": {$: "Nil"}}, "right": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.System", "id": 1, "condition": 1}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Nil"}}}}}}, "right": {$: "../src/ecs/schedule-provision.Empty"}}, "right": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.Phase", "name": "inner"}, "requirements": {$: "Nil"}}, "right": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.System", "id": 2, "condition": 1}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Nil"}}}}}}}};
  }
}

function $$$$047src$047ecs$047system$058register_join$1260$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047experiments$047public$045nested$045provision$047other$058built$(_result_0, _world_0) {
  if (_result_0.$ === "../src/ecs/schedule-provision.Invalid") {
    const _owners_0 = _result_0["owners"];
    return $$$$047experiments$047public$045nested$045provision$047other$058invalid_snapshot$(($$$$047experiments$047public$045nested$045provision$047other$058owner_snapshot$(_owners_0)), ($$$$047experiments$047public$045nested$045provision$047other$058world_snapshot$(_world_0)));
  } else {
    const _schedule_0 = _result_0["schedule"];
    return $$$$047experiments$047public$045nested$045provision$047other$058provision_result$(($$$$047src$047ecs$047schedule$045provision$058run$1261$(_schedule_0, _world_0)));
  }
}

function $$$$047src$047ecs$047schedule$045provision$058build$1261$(_namespace_0, _name_0, _plan_0, _catalog_0, _owners_0) {
  return $$$$047src$047ecs$047schedule$045provision$058finish_build$1261$(($$$$047src$047ecs$047schedule$058build$1261$(_namespace_0, _name_0, ($$$$047src$047ecs$047schedule$045provision$058flatten$1261$(_plan_0)), _catalog_0, _owners_0)), ($$$$047src$047ecs$047schedule$045provision$058unique$1261$(($$$$047src$047ecs$047schedule$045provision$058requirements$1261$(_plan_0)))));
}

function $$$$047experiments$047public$045nested$045provision$047other$058nested$(_mode_0) {
  if (_mode_0 == 7) {
    return {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.System", "id": 1, "condition": 1}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Nil"}}}}}, "right": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Empty"}, "right": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.System", "id": 1, "condition": 1}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Nil"}}}}};
  } else if ((_mode_0 & 3) == 3) {
    return {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.Phase", "name": "before"}, "requirements": {$: "Nil"}}, "right": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.System", "id": 1, "condition": 1}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Nil"}}}}}}, "right": {$: "../src/ecs/schedule-provision.Empty"}}, "right": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.Phase", "name": "inner"}, "requirements": {$: "Nil"}}, "right": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.System", "id": 2, "condition": 1}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Nil"}}}}}}}};
  } else if (_mode_0 == 9) {
    return {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Empty"}, "right": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.Phase", "name": "empty"}, "requirements": {$: "Nil"}}, "right": {$: "../src/ecs/schedule-provision.Empty"}}};
  } else if ((_mode_0 & 3) == 1) {
    return {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.Phase", "name": "before"}, "requirements": {$: "Nil"}}, "right": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.System", "id": 1, "condition": 1}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Nil"}}}}}}, "right": {$: "../src/ecs/schedule-provision.Empty"}}, "right": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.Phase", "name": "inner"}, "requirements": {$: "Nil"}}, "right": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.System", "id": 2, "condition": 1}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Nil"}}}}}}}};
  } else if (_mode_0 == 8) {
    return {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.Phase", "name": "before"}, "requirements": {$: "Nil"}}, "right": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Empty"}, "right": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.System", "id": 2, "condition": 0}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Nil"}}}}}}};
  } else if ((_mode_0 & 3) == 0) {
    return {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.Phase", "name": "before"}, "requirements": {$: "Nil"}}, "right": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.System", "id": 1, "condition": 1}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Nil"}}}}}}, "right": {$: "../src/ecs/schedule-provision.Empty"}}, "right": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.Phase", "name": "inner"}, "requirements": {$: "Nil"}}, "right": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.System", "id": 2, "condition": 1}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Nil"}}}}}}}};
  } else if (_mode_0 == 10) {
    return {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.Phase", "name": "family-only"}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Nil"}}};
  } else {
    return {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.Phase", "name": "before"}, "requirements": {$: "Nil"}}, "right": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.System", "id": 1, "condition": 1}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Nil"}}}}}}, "right": {$: "../src/ecs/schedule-provision.Empty"}}, "right": {$: "../src/ecs/schedule-provision.Sequence", "left": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.Phase", "name": "inner"}, "requirements": {$: "Nil"}}, "right": {$: "../src/ecs/schedule-provision.Entry", "step": {$: "../src/ecs/schedule.System", "id": 2, "condition": 1}, "requirements": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Nil"}}}}}}}};
  }
}

function $$$$047src$047ecs$047system$058register_join$1261$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047world$058register_checked$1261$((_nextSystemId_0 < 4294967295), {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047experiments$047public$045nested$045provision$047app$058invalid_snapshot$(_owners_0, _world_0) {
  const _owners_1 = _owners_0["snd"];
  const _text_0 = _world_0["snd"];
  const _x_0 = ("|" + _text_0);
  const _x_1 = (_owners_1 + _x_0);
  return ("invalid|owners=" + _x_1);
}

function $$$$047experiments$047public$045nested$045provision$047app$058owner_snapshot$(_value_0) {
  const _a_0 = _value_0["a"];
  const _b_0 = _value_0["b"];
  return $$$$047experiments$047public$045nested$045provision$047app$058owners_join$(($$$$047experiments$047public$045nested$045provision$047app$058registry$(_a_0)), ($$$$047experiments$047public$045nested$045provision$047app$058registry$(_b_0)));
}

function $$$$047experiments$047public$045nested$045provision$047app$058world_snapshot$(_world_0) {
  return $$$$047experiments$047public$045nested$045provision$047app$058measured_observe$(($$$$047experiments$047public$045nested$045provision$047app$058measured_original_snapshot$(_world_0)));
}

function $$$$047experiments$047public$045nested$045provision$047app$058provision_result$(_result_0) {
  if (_result_0.$ === "../src/ecs/schedule-provision.Executed") {
    const _result_1 = _result_0["result"];
    const _needs_0 = _result_0["requirements"];
    return $$$$047experiments$047public$045nested$045provision$047app$058finished$(_result_1, _needs_0);
  } else {
    const _t_0 = _result_0["schedule"];
    const _schedule_0 = _t_0["schedule"];
    const _needs_1 = _t_0["requirements"];
    const _world_0 = _result_0["world"];
    const _missing_0 = _result_0["missing"];
    return $$$$047experiments$047public$045nested$045provision$047app$058measured_refusal$(($$$$047experiments$047public$045nested$045provision$047app$058schedule_snapshot$(_schedule_0)), ($$$$047experiments$047public$045nested$045provision$047app$058world_snapshot$(_world_0)), _needs_1, _missing_0, ($$$$047experiments$047public$045nested$045provision$047app$058measured_resource_missing$(_missing_0)));
  }
}

function $$$$047src$047ecs$047schedule$045provision$058run$1260$(_schedule_0, _world_0) {
  const _schedule_1 = _schedule_0["schedule"];
  const _needs_0 = _schedule_0["requirements"];
  return $$$$047src$047ecs$047schedule$045provision$058run_available$1260$(($$$$047experiments$047public$045nested$045provision$047app$058provision$(_world_0)), _schedule_1, _needs_0);
}

function $$$$047src$047ecs$047schedule$045provision$058finish_build$1260$(_built_0, _needs_0) {
  if (_built_0.$ === "../src/ecs/schedule.Invalid") {
    const _owners_0 = _built_0["owners"];
    return {$: "../src/ecs/schedule-provision.Invalid", "owners": _owners_0};
  } else {
    const _schedule_0 = _built_0["schedule"];
    return {$: "../src/ecs/schedule-provision.Built", "schedule": {$: "../src/ecs/schedule-provision.Provisioned", "schedule": _schedule_0, "requirements": _needs_0}};
  }
}

function $$$$047src$047ecs$047schedule$058build$1260$(_namespace_0, _name_0, _steps_0, _catalog_0, _owners_0) {
  return $$$$047src$047ecs$047schedule$058build_checked$1260$(($$$$047src$047ecs$047schedule$058valid$(_steps_0, _catalog_0, {$: "Nil"})), _namespace_0, _name_0, _steps_0, _owners_0);
}

function $$$$047src$047ecs$047schedule$045provision$058flatten$1260$(_plan_0) {
  if (_plan_0.$ === "../src/ecs/schedule-provision.Empty") {
    return {$: "Nil"};
  } else if (_plan_0.$ === "../src/ecs/schedule-provision.Entry") {
    const _step_0 = _plan_0["step"];
    return {$: "Con", "head": _step_0, "tail": {$: "Nil"}};
  } else {
    const _left_0 = _plan_0["left"];
    const _right_0 = _plan_0["right"];
    return $List$append$(($$$$047src$047ecs$047schedule$045provision$058flatten$1260$(_left_0)), ($$$$047src$047ecs$047schedule$045provision$058flatten$1260$(_right_0)));
  }
}

function $$$$047src$047ecs$047schedule$045provision$058unique$1260$(_items_0) {
  return $$$$047src$047ecs$047schedule$045provision$058unique_seen$1260$(_items_0, {$: "Nil"});
}

function $$$$047src$047ecs$047schedule$045provision$058requirements$1260$(_plan_0) {
  if (_plan_0.$ === "../src/ecs/schedule-provision.Empty") {
    return {$: "Nil"};
  } else if (_plan_0.$ === "../src/ecs/schedule-provision.Entry") {
    const _needs_0 = _plan_0["requirements"];
    return _needs_0;
  } else {
    const _left_0 = _plan_0["left"];
    const _right_0 = _plan_0["right"];
    return $List$append$(($$$$047src$047ecs$047schedule$045provision$058requirements$1260$(_left_0)), ($$$$047src$047ecs$047schedule$045provision$058requirements$1260$(_right_0)));
  }
}

function $$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../src/ecs/world.RegistrationRejected") {
    return {$: "../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../src/ecs/world.RegistrationRejected", "error": {$: "../src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058invalid_snapshot$(_owners_0, _world_0) {
  const _owners_1 = _owners_0["snd"];
  const _text_0 = _world_0["snd"];
  const _x_0 = ("|" + _text_0);
  const _x_1 = (_owners_1 + _x_0);
  return ("invalid|owners=" + _x_1);
}

function $$$$047experiments$047public$045nested$045provision$047other$058owner_snapshot$(_value_0) {
  const _a_0 = _value_0["a"];
  const _b_0 = _value_0["b"];
  return $$$$047experiments$047public$045nested$045provision$047other$058owners_join$(($$$$047experiments$047public$045nested$045provision$047other$058registry$(_a_0)), ($$$$047experiments$047public$045nested$045provision$047other$058registry$(_b_0)));
}

function $$$$047experiments$047public$045nested$045provision$047other$058world_snapshot$(_world_0) {
  return $$$$047experiments$047public$045nested$045provision$047other$058measured_observe$(($$$$047experiments$047public$045nested$045provision$047other$058measured_original_snapshot$(_world_0)));
}

function $$$$047experiments$047public$045nested$045provision$047other$058provision_result$(_result_0) {
  if (_result_0.$ === "../src/ecs/schedule-provision.Executed") {
    const _result_1 = _result_0["result"];
    const _needs_0 = _result_0["requirements"];
    return $$$$047experiments$047public$045nested$045provision$047other$058finished$(_result_1, _needs_0);
  } else {
    const _t_0 = _result_0["schedule"];
    const _schedule_0 = _t_0["schedule"];
    const _needs_1 = _t_0["requirements"];
    const _world_0 = _result_0["world"];
    const _missing_0 = _result_0["missing"];
    return $$$$047experiments$047public$045nested$045provision$047other$058measured_refusal$(($$$$047experiments$047public$045nested$045provision$047other$058schedule_snapshot$(_schedule_0)), ($$$$047experiments$047public$045nested$045provision$047other$058world_snapshot$(_world_0)), _needs_1, _missing_0, ($$$$047experiments$047public$045nested$045provision$047other$058measured_resource_missing$(_missing_0)));
  }
}

function $$$$047src$047ecs$047schedule$045provision$058run$1261$(_schedule_0, _world_0) {
  const _schedule_1 = _schedule_0["schedule"];
  const _needs_0 = _schedule_0["requirements"];
  return $$$$047src$047ecs$047schedule$045provision$058run_available$1261$(($$$$047experiments$047public$045nested$045provision$047other$058provision$(_world_0)), _schedule_1, _needs_0);
}

function $$$$047src$047ecs$047schedule$045provision$058finish_build$1261$(_built_0, _needs_0) {
  if (_built_0.$ === "../src/ecs/schedule.Invalid") {
    const _owners_0 = _built_0["owners"];
    return {$: "../src/ecs/schedule-provision.Invalid", "owners": _owners_0};
  } else {
    const _schedule_0 = _built_0["schedule"];
    return {$: "../src/ecs/schedule-provision.Built", "schedule": {$: "../src/ecs/schedule-provision.Provisioned", "schedule": _schedule_0, "requirements": _needs_0}};
  }
}

function $$$$047src$047ecs$047schedule$058build$1261$(_namespace_0, _name_0, _steps_0, _catalog_0, _owners_0) {
  return $$$$047src$047ecs$047schedule$058build_checked$1261$(($$$$047src$047ecs$047schedule$058valid$(_steps_0, _catalog_0, {$: "Nil"})), _namespace_0, _name_0, _steps_0, _owners_0);
}

function $$$$047src$047ecs$047schedule$045provision$058flatten$1261$(_plan_0) {
  if (_plan_0.$ === "../src/ecs/schedule-provision.Empty") {
    return {$: "Nil"};
  } else if (_plan_0.$ === "../src/ecs/schedule-provision.Entry") {
    const _step_0 = _plan_0["step"];
    return {$: "Con", "head": _step_0, "tail": {$: "Nil"}};
  } else {
    const _left_0 = _plan_0["left"];
    const _right_0 = _plan_0["right"];
    return $List$append$(($$$$047src$047ecs$047schedule$045provision$058flatten$1261$(_left_0)), ($$$$047src$047ecs$047schedule$045provision$058flatten$1261$(_right_0)));
  }
}

function $$$$047src$047ecs$047schedule$045provision$058unique$1261$(_items_0) {
  return $$$$047src$047ecs$047schedule$045provision$058unique_seen$1261$(_items_0, {$: "Nil"});
}

function $$$$047src$047ecs$047schedule$045provision$058requirements$1261$(_plan_0) {
  if (_plan_0.$ === "../src/ecs/schedule-provision.Empty") {
    return {$: "Nil"};
  } else if (_plan_0.$ === "../src/ecs/schedule-provision.Entry") {
    const _needs_0 = _plan_0["requirements"];
    return _needs_0;
  } else {
    const _left_0 = _plan_0["left"];
    const _right_0 = _plan_0["right"];
    return $List$append$(($$$$047src$047ecs$047schedule$045provision$058requirements$1261$(_left_0)), ($$$$047src$047ecs$047schedule$045provision$058requirements$1261$(_right_0)));
  }
}

function $$$$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../src/ecs/world.RegistrationRejected") {
    return {$: "../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047src$047ecs$047world$058register_checked$1261$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../src/ecs/world.RegistrationRejected", "error": {$: "../src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058owners_join$(_a_0, _b_0) {
  const _a_1 = _a_0["fst"];
  const _x_0 = _a_0["snd"];
  const _b_1 = _b_0["fst"];
  const _y_0 = _b_0["snd"];
  const _x_1 = ("/" + _y_0);
  return {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/app.Owners", "a": _a_1, "b": _b_1}, "snd": (_x_0 + _x_1)};
}

function $$$$047experiments$047public$045nested$045provision$047app$058registry$(_owner_0) {
  const _ns_0 = _owner_0["namespace"];
  const _id_0 = _owner_0["id"];
  const _name_0 = _owner_0["name"];
  const _access_0 = _owner_0["access"];
  const _cursor_0 = _owner_0["cursor"];
  const _x_0 = ($U32$show$(_cursor_0));
  const _x_1 = ($$$$047experiments$047public$045nested$045provision$047app$058texts$(_access_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":" + _x_3);
  const _x_5 = (_name_0 + _x_4);
  const _x_6 = ($U32$show$(_id_0));
  const _x_7 = (":" + _x_5);
  const _x_8 = (_x_6 + _x_7);
  const _x_9 = ($U32$show$(_ns_0));
  const _x_10 = (":" + _x_8);
  return {$: "Tuple", "fst": {$: "../src/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": (_x_9 + _x_10)};
}

function $$$$047experiments$047public$045nested$045provision$047app$058measured_observe$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return $$$$047experiments$047public$045nested$045provision$047app$058measured_before$(($$$$047src$047ecs$047world$058handles$1260$(_world_0)), _text_0);
}

function $$$$047experiments$047public$045nested$045provision$047app$058measured_original_snapshot$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _t_0 = _world_0["store"];
  const _column_0 = _t_0["column"];
  const _family_0 = _t_0["family"];
  const _cwrites_0 = _t_0["writes"];
  const _t_1 = _world_0["resource"];
  const _resource_0 = _t_1["resource"];
  const _host_0 = _t_1["service"];
  const _rwrites_0 = _t_1["resourceWrites"];
  const _calls_0 = _t_1["hostCalls"];
  const _conditions_0 = _t_1["conditionCalls"];
  const _retired_0 = _t_1["retired"];
  const _trace_0 = _t_1["trace"];
  const _reservedIds_0 = _t_1["reservedIds"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _x_0 = ($U32$show$(($$$$047experiments$047public$045nested$045provision$047app$058family_code$(_family_0))));
  return $$$$047experiments$047public$045nested$045provision$047app$058world_snapshot_join$({$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/app.Store", "column": {$: "../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}}, "family": _family_0, "writes": _cwrites_0}, "resource": {$: "../experiments/public-nested-provision/app.Resources", "resource": {$: "../experiments/public-nested-provision/app.Missing"}, "service": {$: "../experiments/public-nested-provision/app.Missing"}, "resourceWrites": _rwrites_0, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": {$: "Nil"}, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, {$: "Tuple", "fst": ($$$$047experiments$047public$045nested$045provision$047app$058slot_snapshot$(_resource_0)), "snd": ($$$$047experiments$047public$045nested$045provision$047app$058slot_snapshot$(_host_0))}, ($$$$047src$047ecs$047column$058view$1260$(_column_0, 1)), ("family=" + _x_0), ($$$$047experiments$047public$045nested$045provision$047app$058queue_count$(_pending_0)), ($$$$047experiments$047public$045nested$045provision$047app$058retired_snapshot$(_retired_0)));
}

function $$$$047experiments$047public$045nested$045provision$047app$058finished$(_result_0, _requirements_0) {
  if (_result_0.$ === "../src/ecs/schedule.Finished") {
    const _schedule_0 = _result_0["schedule"];
    const _world_0 = _result_0["world"];
    const _obs_0 = _result_0["observations"];
    const _x_0 = ($$$$047experiments$047public$045nested$045provision$047app$058needs$(_requirements_0));
    const _x_1 = ($$$$047experiments$047public$045nested$045provision$047app$058observations$(_obs_0));
    const _x_2 = (":needs=" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    return $$$$047experiments$047public$045nested$045provision$047app$058result_snapshot$(("ok:" + _x_3), ($$$$047experiments$047public$045nested$045provision$047app$058schedule_snapshot$(_schedule_0)), ($$$$047experiments$047public$045nested$045provision$047app$058world_snapshot$(_world_0)));
  } else if (_result_0.$ === "../src/ecs/schedule.Failed") {
    const _schedule_1 = _result_0["schedule"];
    const _world_1 = _result_0["world"];
    const _error_0 = _result_0["error"];
    const _obs_1 = _result_0["observations"];
    const _x_4 = ($$$$047experiments$047public$045nested$045provision$047app$058observations$(_obs_1));
    const _x_5 = (":" + _x_4);
    const _x_6 = (_error_0 + _x_5);
    return $$$$047experiments$047public$045nested$045provision$047app$058result_snapshot$(("failed:" + _x_6), ($$$$047experiments$047public$045nested$045provision$047app$058schedule_snapshot$(_schedule_1)), ($$$$047experiments$047public$045nested$045provision$047app$058world_snapshot$(_world_1)));
  } else {
    const _schedule_2 = _result_0["schedule"];
    const _world_2 = _result_0["world"];
    return $$$$047experiments$047public$045nested$045provision$047app$058result_snapshot$("rejected", ($$$$047experiments$047public$045nested$045provision$047app$058schedule_snapshot$(_schedule_2)), ($$$$047experiments$047public$045nested$045provision$047app$058world_snapshot$(_world_2)));
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058measured_refusal$(_schedule_0, _world_0, _requirements_0, _missing_0, _resourceMissing_0) {
  if (_resourceMissing_0) {
    return $$$$047experiments$047public$045nested$045provision$047app$058measured_refusal_only$(_schedule_0, _world_0, _requirements_0, _missing_0);
  } else {
    return $$$$047experiments$047public$045nested$045provision$047app$058refusal_observed$(_schedule_0, _world_0, _requirements_0, _missing_0);
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058schedule_snapshot$(_value_0) {
  const _ns_0 = _value_0["namespace"];
  const _name_0 = _value_0["name"];
  const _steps_0 = _value_0["steps"];
  const _owners_0 = _value_0["owners"];
  return $$$$047experiments$047public$045nested$045provision$047app$058schedule_join$(_ns_0, _name_0, _steps_0, ($$$$047experiments$047public$045nested$045provision$047app$058owner_snapshot$(_owners_0)));
}

function $$$$047experiments$047public$045nested$045provision$047app$058measured_resource_missing$($0) {
  for (;;) {
    {
      const _items_0 = $0;
      if (_items_0.$ === "Nil") {
        return false;
      } else {
        const _t_0 = _items_0["head"];
        if (_t_0.$ === "../src/ecs/schedule-provision.Resource") {
          return true;
        } else {
          const __2 = _items_0["tail"];
          $0 = __2;
          continue;
        }
      }
    }
  }
}

function $$$$047src$047ecs$047schedule$045provision$058run_available$1260$(_observed_0, _schedule_0, _needs_0) {
  const _world_0 = _observed_0["fst"];
  const _available_0 = _observed_0["snd"];
  return $$$$047src$047ecs$047schedule$045provision$058run_checked$1260$(($$$$047src$047ecs$047schedule$045provision$058missing_requirements$1260$(_needs_0, _available_0)), _schedule_0, _world_0, _needs_0);
}

function $$$$047experiments$047public$045nested$045provision$047app$058provision$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _t_0 = _world_0["store"];
  const _column_0 = _t_0["column"];
  const _family_0 = _t_0["family"];
  const _cwrites_0 = _t_0["writes"];
  const _t_1 = _world_0["resource"];
  const _resource_0 = _t_1["resource"];
  const _host_0 = _t_1["service"];
  const _writes_0 = _t_1["resourceWrites"];
  const _calls_0 = _t_1["hostCalls"];
  const _conditions_0 = _t_1["conditionCalls"];
  const _retired_0 = _t_1["retired"];
  const _trace_0 = _t_1["trace"];
  const _reservedIds_0 = _t_1["reservedIds"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047experiments$047public$045nested$045provision$047app$058provisioned$({$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/app.Store", "column": _column_0, "family": _family_0, "writes": _cwrites_0}, "resource": {$: "../experiments/public-nested-provision/app.Resources", "resource": {$: "../experiments/public-nested-provision/app.Missing"}, "service": {$: "../experiments/public-nested-provision/app.Missing"}, "resourceWrites": _writes_0, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, ($$$$047experiments$047public$045nested$045provision$047app$058available_slots$(_family_0, _resource_0, _host_0)));
}

function $$$$047src$047ecs$047schedule$058build_checked$1260$(_allowed_0, _namespace_0, _name_0, _steps_0, _owners_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/schedule.Invalid", "owners": _owners_0};
  } else {
    return {$: "../src/ecs/schedule.Built", "schedule": {$: "../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}};
  }
}

function $$$$047src$047ecs$047schedule$058valid$($0, $1, $2) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _catalog_0 = $1;
      const _seen_0 = $2;
      if (_steps_0.$ === "Nil") {
        return true;
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../src/ecs/schedule.Phase") {
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _catalog_0;
          $2 = _seen_0;
          continue;
        } else if (_t_0.$ === "../src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _catalog_0;
          $2 = _seen_0;
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _rest_2 = _steps_0["tail"];
          return $Bool$and$(($$$$047src$047ecs$047schedule$058contains$(_catalog_0, _id_0)), ($Bool$and$(($Bool$not$(($$$$047src$047ecs$047schedule$058contains$(_seen_0, _id_0)))), ($$$$047src$047ecs$047schedule$058valid$(_rest_2, _catalog_0, {$: "Con", "head": _id_0, "tail": _seen_0})))));
        }
      }
    }
  }
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $$$$047src$047ecs$047schedule$045provision$058unique_seen$1260$(_items_0, _seen_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    return $$$$047src$047ecs$047schedule$045provision$058unique_add$1260$(($$$$047src$047ecs$047schedule$045provision$058contains$1260$(_seen_0, _head_0)), _head_0, ($$$$047src$047ecs$047schedule$045provision$058unique_seen$1260$(_rest_0, {$: "Con", "head": _head_0, "tail": _seen_0})));
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058owners_join$(_a_0, _b_0) {
  const _a_1 = _a_0["fst"];
  const _x_0 = _a_0["snd"];
  const _b_1 = _b_0["fst"];
  const _y_0 = _b_0["snd"];
  const _x_1 = ("/" + _y_0);
  return {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/other.Owners", "a": _a_1, "b": _b_1}, "snd": (_x_0 + _x_1)};
}

function $$$$047experiments$047public$045nested$045provision$047other$058registry$(_owner_0) {
  const _ns_0 = _owner_0["namespace"];
  const _id_0 = _owner_0["id"];
  const _name_0 = _owner_0["name"];
  const _access_0 = _owner_0["access"];
  const _cursor_0 = _owner_0["cursor"];
  const _x_0 = ($U32$show$(_cursor_0));
  const _x_1 = ($$$$047experiments$047public$045nested$045provision$047other$058texts$(_access_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":" + _x_3);
  const _x_5 = (_name_0 + _x_4);
  const _x_6 = ($U32$show$(_id_0));
  const _x_7 = (":" + _x_5);
  const _x_8 = (_x_6 + _x_7);
  const _x_9 = ($U32$show$(_ns_0));
  const _x_10 = (":" + _x_8);
  return {$: "Tuple", "fst": {$: "../src/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": (_x_9 + _x_10)};
}

function $$$$047experiments$047public$045nested$045provision$047other$058measured_observe$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return $$$$047experiments$047public$045nested$045provision$047other$058measured_before$(($$$$047src$047ecs$047world$058handles$1261$(_world_0)), _text_0);
}

function $$$$047experiments$047public$045nested$045provision$047other$058measured_original_snapshot$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _t_0 = _world_0["store"];
  const _column_0 = _t_0["column"];
  const _family_0 = _t_0["family"];
  const _cwrites_0 = _t_0["writes"];
  const _t_1 = _world_0["resource"];
  const _resource_0 = _t_1["resource"];
  const _host_0 = _t_1["service"];
  const _rwrites_0 = _t_1["resourceWrites"];
  const _calls_0 = _t_1["hostCalls"];
  const _conditions_0 = _t_1["conditionCalls"];
  const _retired_0 = _t_1["retired"];
  const _trace_0 = _t_1["trace"];
  const _reservedIds_0 = _t_1["reservedIds"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _x_0 = ($U32$show$(($$$$047experiments$047public$045nested$045provision$047other$058family_code$(_family_0))));
  return $$$$047experiments$047public$045nested$045provision$047other$058world_snapshot_join$({$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/other.Store", "column": {$: "../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}}, "family": _family_0, "writes": _cwrites_0}, "resource": {$: "../experiments/public-nested-provision/other.Resources", "resource": {$: "../experiments/public-nested-provision/other.Missing"}, "service": {$: "../experiments/public-nested-provision/other.Missing"}, "resourceWrites": _rwrites_0, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": {$: "Nil"}, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, {$: "Tuple", "fst": ($$$$047experiments$047public$045nested$045provision$047other$058slot_snapshot$(_resource_0)), "snd": ($$$$047experiments$047public$045nested$045provision$047other$058slot_snapshot$(_host_0))}, ($$$$047src$047ecs$047column$058view$1261$(_column_0, 1)), ("family=" + _x_0), ($$$$047experiments$047public$045nested$045provision$047other$058queue_count$(_pending_0)), ($$$$047experiments$047public$045nested$045provision$047other$058retired_snapshot$(_retired_0)));
}

function $$$$047experiments$047public$045nested$045provision$047other$058finished$(_result_0, _requirements_0) {
  if (_result_0.$ === "../src/ecs/schedule.Finished") {
    const _schedule_0 = _result_0["schedule"];
    const _world_0 = _result_0["world"];
    const _obs_0 = _result_0["observations"];
    const _x_0 = ($$$$047experiments$047public$045nested$045provision$047other$058needs$(_requirements_0));
    const _x_1 = ($$$$047experiments$047public$045nested$045provision$047other$058observations$(_obs_0));
    const _x_2 = (":needs=" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    return $$$$047experiments$047public$045nested$045provision$047other$058result_snapshot$(("ok:" + _x_3), ($$$$047experiments$047public$045nested$045provision$047other$058schedule_snapshot$(_schedule_0)), ($$$$047experiments$047public$045nested$045provision$047other$058world_snapshot$(_world_0)));
  } else if (_result_0.$ === "../src/ecs/schedule.Failed") {
    const _schedule_1 = _result_0["schedule"];
    const _world_1 = _result_0["world"];
    const _error_0 = _result_0["error"];
    const _obs_1 = _result_0["observations"];
    const _x_4 = ($$$$047experiments$047public$045nested$045provision$047other$058observations$(_obs_1));
    const _x_5 = (":" + _x_4);
    const _x_6 = (_error_0 + _x_5);
    return $$$$047experiments$047public$045nested$045provision$047other$058result_snapshot$(("failed:" + _x_6), ($$$$047experiments$047public$045nested$045provision$047other$058schedule_snapshot$(_schedule_1)), ($$$$047experiments$047public$045nested$045provision$047other$058world_snapshot$(_world_1)));
  } else {
    const _schedule_2 = _result_0["schedule"];
    const _world_2 = _result_0["world"];
    return $$$$047experiments$047public$045nested$045provision$047other$058result_snapshot$("rejected", ($$$$047experiments$047public$045nested$045provision$047other$058schedule_snapshot$(_schedule_2)), ($$$$047experiments$047public$045nested$045provision$047other$058world_snapshot$(_world_2)));
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058measured_refusal$(_schedule_0, _world_0, _requirements_0, _missing_0, _resourceMissing_0) {
  if (_resourceMissing_0) {
    return $$$$047experiments$047public$045nested$045provision$047other$058measured_refusal_only$(_schedule_0, _world_0, _requirements_0, _missing_0);
  } else {
    return $$$$047experiments$047public$045nested$045provision$047other$058refusal_observed$(_schedule_0, _world_0, _requirements_0, _missing_0);
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058schedule_snapshot$(_value_0) {
  const _ns_0 = _value_0["namespace"];
  const _name_0 = _value_0["name"];
  const _steps_0 = _value_0["steps"];
  const _owners_0 = _value_0["owners"];
  return $$$$047experiments$047public$045nested$045provision$047other$058schedule_join$(_ns_0, _name_0, _steps_0, ($$$$047experiments$047public$045nested$045provision$047other$058owner_snapshot$(_owners_0)));
}

function $$$$047experiments$047public$045nested$045provision$047other$058measured_resource_missing$($0) {
  for (;;) {
    {
      const _items_0 = $0;
      if (_items_0.$ === "Nil") {
        return false;
      } else {
        const _t_0 = _items_0["head"];
        if (_t_0.$ === "../src/ecs/schedule-provision.Resource") {
          return true;
        } else {
          const __2 = _items_0["tail"];
          $0 = __2;
          continue;
        }
      }
    }
  }
}

function $$$$047src$047ecs$047schedule$045provision$058run_available$1261$(_observed_0, _schedule_0, _needs_0) {
  const _world_0 = _observed_0["fst"];
  const _available_0 = _observed_0["snd"];
  return $$$$047src$047ecs$047schedule$045provision$058run_checked$1261$(($$$$047src$047ecs$047schedule$045provision$058missing_requirements$1261$(_needs_0, _available_0)), _schedule_0, _world_0, _needs_0);
}

function $$$$047experiments$047public$045nested$045provision$047other$058provision$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _t_0 = _world_0["store"];
  const _column_0 = _t_0["column"];
  const _family_0 = _t_0["family"];
  const _cwrites_0 = _t_0["writes"];
  const _t_1 = _world_0["resource"];
  const _resource_0 = _t_1["resource"];
  const _host_0 = _t_1["service"];
  const _writes_0 = _t_1["resourceWrites"];
  const _calls_0 = _t_1["hostCalls"];
  const _conditions_0 = _t_1["conditionCalls"];
  const _retired_0 = _t_1["retired"];
  const _trace_0 = _t_1["trace"];
  const _reservedIds_0 = _t_1["reservedIds"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047experiments$047public$045nested$045provision$047other$058provisioned$({$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/other.Store", "column": _column_0, "family": _family_0, "writes": _cwrites_0}, "resource": {$: "../experiments/public-nested-provision/other.Resources", "resource": {$: "../experiments/public-nested-provision/other.Missing"}, "service": {$: "../experiments/public-nested-provision/other.Missing"}, "resourceWrites": _writes_0, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, ($$$$047experiments$047public$045nested$045provision$047other$058available_slots$(_family_0, _resource_0, _host_0)));
}

function $$$$047src$047ecs$047schedule$058build_checked$1261$(_allowed_0, _namespace_0, _name_0, _steps_0, _owners_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/schedule.Invalid", "owners": _owners_0};
  } else {
    return {$: "../src/ecs/schedule.Built", "schedule": {$: "../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}};
  }
}

function $$$$047src$047ecs$047schedule$045provision$058unique_seen$1261$(_items_0, _seen_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    return $$$$047src$047ecs$047schedule$045provision$058unique_add$1261$(($$$$047src$047ecs$047schedule$045provision$058contains$1261$(_seen_0, _head_0)), _head_0, ($$$$047src$047ecs$047schedule$045provision$058unique_seen$1261$(_rest_0, {$: "Con", "head": _head_0, "tail": _seen_0})));
  }
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $$$$047experiments$047public$045nested$045provision$047app$058texts$(_items_0) {
  if (_items_0.$ === "Nil") {
    return "";
  } else {
    const _item_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    const _x_0 = ($$$$047experiments$047public$045nested$045provision$047app$058texts$(_rest_0));
    const _x_1 = ("," + _x_0);
    return (_item_0 + _x_1);
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058measured_before$(_observed_0, _text_0) {
  const _t_0 = _observed_0["fst"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["nextId"];
  const _high_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _cap_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _store_0 = _t_0["store"];
  const _t_1 = _t_0["resource"];
  const _resource_0 = _t_1["resource"];
  const _host_0 = _t_1["service"];
  const _writes_0 = _t_1["resourceWrites"];
  const _calls_0 = _t_1["hostCalls"];
  const _conditions_0 = _t_1["conditionCalls"];
  const _retired_0 = _t_1["retired"];
  const _trace_0 = _t_1["trace"];
  const _reservedIds_0 = _t_1["reservedIds"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSystem_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _handles_0 = _observed_0["snd"];
  const _x_0 = ($List$show$1260$(_events_0));
  const _x_1 = ($List$show$1262$(_handles_0));
  const _x_2 = (";published=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($List$show$1260$(_reservedIds_0));
  const _x_5 = (";beforeLive=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = (";reserved=" + _x_6);
  return $$$$047experiments$047public$045nested$045provision$047app$058measured_probed$(($$$$047experiments$047public$045nested$045provision$047app$058measured_probe$({$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../experiments/public-nested-provision/app.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_0, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0})), (_text_0 + _x_7));
}

function $$$$047src$047ecs$047world$058handles$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047world$058handles_tail_finish$1260$(($$$$047src$047ecs$047world$058collect_tail$1260$(_highWater_0, _namespace_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047experiments$047public$045nested$045provision$047app$058world_snapshot_join$(_world_0, _slots_0, _component_0, _prefix_0, _queue_0, _oldOwners_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _t_0 = _world_0["store"];
  const _family_0 = _t_0["family"];
  const _cwrites_0 = _t_0["writes"];
  const _t_1 = _world_0["resource"];
  const _rwrites_0 = _t_1["resourceWrites"];
  const _calls_0 = _t_1["hostCalls"];
  const _conditions_0 = _t_1["conditionCalls"];
  const _trace_0 = _t_1["trace"];
  const _reservedIds_0 = _t_1["reservedIds"];
  const _events_0 = _world_0["events"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _t_2 = _slots_0["fst"];
  const _resource_0 = _t_2["fst"];
  const _rtext_0 = _t_2["snd"];
  const _t_3 = _slots_0["snd"];
  const _host_0 = _t_3["fst"];
  const _stext_0 = _t_3["snd"];
  const _column_0 = _component_0["fst"];
  const _t_4 = _component_0["snd"];
  if (_t_4.$ === "None") {
    const _pending_0 = _queue_0["fst"];
    const _queued_0 = _queue_0["snd"];
    const _retired_0 = _oldOwners_0["fst"];
    const _oldCells_0 = _oldOwners_0["snd"];
    const _x_0 = ($List$show$1260$(_trace_0));
    const _x_1 = ($U32$show$(_queued_0));
    const _x_2 = (";trace=" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($List$show$1260$(_events_0));
    const _x_5 = (";queue=" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    const _x_7 = ($U32$show$(_clock_0));
    const _x_8 = (";events=" + _x_6);
    const _x_9 = (_x_7 + _x_8);
    const _x_10 = ($U32$show$(_conditions_0));
    const _x_11 = (";clock=" + _x_9);
    const _x_12 = (_x_10 + _x_11);
    const _x_13 = ($U32$show$(_calls_0));
    const _x_14 = (";conditions=" + _x_12);
    const _x_15 = (_x_13 + _x_14);
    const _x_16 = ($U32$show$(_rwrites_0));
    const _x_17 = (";host=" + _x_15);
    const _x_18 = (_x_16 + _x_17);
    const _x_19 = ($U32$show$(_cwrites_0));
    const _x_20 = (";rw=" + _x_18);
    const _x_21 = (_x_19 + _x_20);
    const _x_22 = (";cw=" + _x_21);
    const _x_23 = (_stext_0 + _x_22);
    const _x_24 = (";service=" + _x_23);
    const _x_25 = (_rtext_0 + _x_24);
    const _x_26 = (";resource=" + _x_25);
    const _x_27 = ("absent" + _x_26);
    const _x_28 = ($List$show$1261$(_oldCells_0));
    const _x_29 = (";cell=" + _x_27);
    const _x_30 = (_x_28 + _x_29);
    const _x_31 = (";retired=" + _x_30);
    return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/app.Store", "column": _column_0, "family": _family_0, "writes": _cwrites_0}, "resource": {$: "../experiments/public-nested-provision/app.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _rwrites_0, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": (_prefix_0 + _x_31)};
  } else {
    const _cells_0 = _t_4["value"];
    const _pending_1 = _queue_0["fst"];
    const _queued_1 = _queue_0["snd"];
    const _retired_1 = _oldOwners_0["fst"];
    const _oldCells_1 = _oldOwners_0["snd"];
    const _x_32 = ($List$show$1260$(_trace_0));
    const _x_33 = ($U32$show$(_queued_1));
    const _x_34 = (";trace=" + _x_32);
    const _x_35 = (_x_33 + _x_34);
    const _x_36 = ($List$show$1260$(_events_0));
    const _x_37 = (";queue=" + _x_35);
    const _x_38 = (_x_36 + _x_37);
    const _x_39 = ($U32$show$(_clock_0));
    const _x_40 = (";events=" + _x_38);
    const _x_41 = (_x_39 + _x_40);
    const _x_42 = ($U32$show$(_conditions_0));
    const _x_43 = (";clock=" + _x_41);
    const _x_44 = (_x_42 + _x_43);
    const _x_45 = ($U32$show$(_calls_0));
    const _x_46 = (";conditions=" + _x_44);
    const _x_47 = (_x_45 + _x_46);
    const _x_48 = ($U32$show$(_rwrites_0));
    const _x_49 = (";host=" + _x_47);
    const _x_50 = (_x_48 + _x_49);
    const _x_51 = ($U32$show$(_cwrites_0));
    const _x_52 = (";rw=" + _x_50);
    const _x_53 = (_x_51 + _x_52);
    const _x_54 = (";cw=" + _x_53);
    const _x_55 = (_stext_0 + _x_54);
    const _x_56 = (";service=" + _x_55);
    const _x_57 = (_rtext_0 + _x_56);
    const _x_58 = ($List$show$1260$(_cells_0));
    const _x_59 = (";resource=" + _x_57);
    const _x_60 = (_x_58 + _x_59);
    const _x_61 = ($List$show$1261$(_oldCells_1));
    const _x_62 = (";cell=" + _x_60);
    const _x_63 = (_x_61 + _x_62);
    const _x_64 = (";retired=" + _x_63);
    return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/app.Store", "column": _column_0, "family": _family_0, "writes": _cwrites_0}, "resource": {$: "../experiments/public-nested-provision/app.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _rwrites_0, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_1, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_1, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": (_prefix_0 + _x_64)};
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058slot_snapshot$(_value_0) {
  if (_value_0.$ === "../experiments/public-nested-provision/app.Missing") {
    return {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/app.Missing"}, "snd": "missing"};
  } else if (_value_0.$ === "../experiments/public-nested-provision/app.Ready") {
    const _owner_0 = _value_0["owner"];
    return $$$$047experiments$047public$045nested$045provision$047app$058slot_projected$1260$(($$$$047experiments$047public$045nested$045provision$047app$058projected$(_owner_0)));
  } else {
    const _owner_1 = _value_0["owner"];
    return $$$$047experiments$047public$045nested$045provision$047app$058incompatible_snapshot$(($$$$047experiments$047public$045nested$045provision$047app$058slot_projected$1261$(($$$$047experiments$047public$045nested$045provision$047app$058projected$(_owner_1)))));
  }
}

function $$$$047src$047ecs$047column$058view$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, ($$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, ($$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058family_code$(_value_0) {
  if (_value_0.$ === "../experiments/public-nested-provision/app.AbsentFamily") {
    return 0;
  } else if (_value_0.$ === "../experiments/public-nested-provision/app.DeclaredFamily") {
    return 1;
  } else {
    return 2;
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058queue_count$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047experiments$047public$045nested$045provision$047app$058queue_join$(_command_0, ($$$$047experiments$047public$045nested$045provision$047app$058queue_count$(_rest_0)));
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058retired_snapshot$(_owners_0) {
  if (_owners_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _owner_0 = _owners_0["head"];
    const _rest_0 = _owners_0["tail"];
    return $$$$047experiments$047public$045nested$045provision$047app$058retired_join$(($$$$047experiments$047public$045nested$045provision$047app$058projected$(_owner_0)), ($$$$047experiments$047public$045nested$045provision$047app$058retired_snapshot$(_rest_0)));
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058result_snapshot$(_label_0, _schedule_0, _world_0) {
  const _owners_0 = _schedule_0["snd"];
  const _text_0 = _world_0["snd"];
  const _x_0 = ("|" + _text_0);
  const _x_1 = (_owners_0 + _x_0);
  const _x_2 = ("|owners=" + _x_1);
  return (_label_0 + _x_2);
}

function $$$$047experiments$047public$045nested$045provision$047app$058observations$(_items_0) {
  if (_items_0.$ === "Nil") {
    return "";
  } else {
    const _t_0 = _items_0["head"];
    if (_t_0.$ === "../src/ecs/schedule.Entered") {
      const _name_0 = _t_0["name"];
      const _rest_0 = _items_0["tail"];
      const _x_0 = ($$$$047experiments$047public$045nested$045provision$047app$058observations$(_rest_0));
      const _x_1 = (";" + _x_0);
      const _x_2 = (_name_0 + _x_1);
      return ("phase:" + _x_2);
    } else if (_t_0.$ === "../src/ecs/schedule.Ran") {
      const _id_0 = _t_0["id"];
      const _rest_1 = _items_0["tail"];
      const _x_3 = ($$$$047experiments$047public$045nested$045provision$047app$058observations$(_rest_1));
      const _x_4 = ($U32$show$(_id_0));
      const _x_5 = (";" + _x_3);
      const _x_6 = (_x_4 + _x_5);
      return ("run:" + _x_6);
    } else if (_t_0.$ === "../src/ecs/schedule.Skipped") {
      const _id_1 = _t_0["id"];
      const _rest_2 = _items_0["tail"];
      const _x_7 = ($$$$047experiments$047public$045nested$045provision$047app$058observations$(_rest_2));
      const _x_8 = ($U32$show$(_id_1));
      const _x_9 = (";" + _x_7);
      const _x_10 = (_x_8 + _x_9);
      return ("skip:" + _x_10);
    } else {
      const _rest_3 = _items_0["tail"];
      const _x_11 = ($$$$047experiments$047public$045nested$045provision$047app$058observations$(_rest_3));
      return ("barrier;" + _x_11);
    }
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058needs$(_items_0) {
  if (_items_0.$ === "Nil") {
    return "";
  } else {
    const _item_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    const _x_0 = ($$$$047experiments$047public$045nested$045provision$047app$058needs$(_rest_0));
    const _x_1 = ($$$$047experiments$047public$045nested$045provision$047app$058requirement$(_item_0));
    const _x_2 = ("," + _x_0);
    return (_x_1 + _x_2);
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058measured_refusal_only$(_schedule_0, _world_0, _requirements_0, _missing_0) {
  const _ownertext_0 = _schedule_0["snd"];
  const _text_0 = _world_0["snd"];
  const _x_0 = ("|" + _text_0);
  const _x_1 = (_ownertext_0 + _x_0);
  const _x_2 = ($$$$047experiments$047public$045nested$045provision$047app$058needs$(_requirements_0));
  const _x_3 = ("|owners=" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($$$$047experiments$047public$045nested$045provision$047app$058needs$(_missing_0));
  const _x_6 = (":needs=" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  return ("missing:" + _x_7);
}

function $$$$047experiments$047public$045nested$045provision$047app$058refusal_observed$(_schedule_0, _world_0, _requirements_0, _missing_0) {
  const _schedule_1 = _schedule_0["fst"];
  const _ownertext_0 = _schedule_0["snd"];
  const _world_1 = _world_0["fst"];
  const _text_0 = _world_0["snd"];
  const _x_0 = ($$$$047experiments$047public$045nested$045provision$047app$058retry_result$(($$$$047src$047ecs$047schedule$045provision$058run$1260$({$: "../src/ecs/schedule-provision.Provisioned", "schedule": _schedule_1, "requirements": _requirements_0}, ($$$$047experiments$047public$045nested$045provision$047app$058repair$(_world_1))))));
  const _x_1 = ("\nretry|" + _x_0);
  const _x_2 = (_text_0 + _x_1);
  const _x_3 = ("|" + _x_2);
  const _x_4 = (_ownertext_0 + _x_3);
  const _x_5 = ($$$$047experiments$047public$045nested$045provision$047app$058needs$(_requirements_0));
  const _x_6 = ("|owners=" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($$$$047experiments$047public$045nested$045provision$047app$058needs$(_missing_0));
  const _x_9 = (":needs=" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  return ("missing:" + _x_10);
}

function $$$$047experiments$047public$045nested$045provision$047app$058schedule_join$(_ns_0, _name_0, _steps_0, _owners_0) {
  const _owners_1 = _owners_0["fst"];
  const _text_0 = _owners_0["snd"];
  const _x_0 = ($U32$show$(_ns_0));
  const _x_1 = (":" + _text_0);
  const _x_2 = (_x_0 + _x_1);
  const _x_3 = (":" + _x_2);
  return {$: "Tuple", "fst": {$: "../src/ecs/schedule.Schedule", "namespace": _ns_0, "name": _name_0, "steps": _steps_0, "owners": _owners_1}, "snd": (_name_0 + _x_3)};
}

function $$$$047src$047ecs$047schedule$045provision$058run_checked$1260$(_missing_0, _schedule_0, _world_0, _needs_0) {
  if (_missing_0.$ === "Con") {
    const _first_0 = _missing_0["head"];
    const _rest_0 = _missing_0["tail"];
    return {$: "../src/ecs/schedule-provision.Missing", "schedule": {$: "../src/ecs/schedule-provision.Provisioned", "schedule": _schedule_0, "requirements": _needs_0}, "world": _world_0, "missing": {$: "Con", "head": _first_0, "tail": _rest_0}};
  } else {
    return {$: "../src/ecs/schedule-provision.Executed", "result": run_loop($$$$047src$047ecs$047schedule$058run$1260$(_schedule_0, _world_0)), "requirements": _needs_0};
  }
}

function $$$$047src$047ecs$047schedule$045provision$058missing_requirements$1260$(_needs_0, _available_0) {
  if (_needs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _needs_0["head"];
    const _rest_0 = _needs_0["tail"];
    return $$$$047src$047ecs$047schedule$045provision$058missing_next$1260$(($$$$047src$047ecs$047schedule$045provision$058contains$1260$(_available_0, _head_0)), _head_0, ($$$$047src$047ecs$047schedule$045provision$058missing_requirements$1260$(_rest_0, _available_0)));
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058provisioned$(_world_0, _observed_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _writes_0 = _t_0["resourceWrites"];
  const _calls_0 = _t_0["hostCalls"];
  const _conditions_0 = _t_0["conditionCalls"];
  const _retired_0 = _t_0["retired"];
  const _trace_0 = _t_0["trace"];
  const _reservedIds_0 = _t_0["reservedIds"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _t_1 = _observed_0["fst"];
  const _resource_0 = _t_1["fst"];
  const _host_0 = _t_1["snd"];
  const _available_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../experiments/public-nested-provision/app.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_0, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _available_0};
}

function $$$$047experiments$047public$045nested$045provision$047app$058available_slots$(_family_0, _resource_0, _host_0) {
  if (_resource_0.$ === "../experiments/public-nested-provision/app.Ready") {
    const _r_0 = _resource_0["owner"];
    if (_host_0.$ === "../experiments/public-nested-provision/app.Ready") {
      const _s_0 = _host_0["owner"];
      return {$: "Tuple", "fst": {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/app.Ready", "owner": _r_0}, "snd": {$: "../experiments/public-nested-provision/app.Ready", "owner": _s_0}}, "snd": ($List$append$({$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Nil"}}}, ($$$$047experiments$047public$045nested$045provision$047app$058families$(_family_0))))};
    } else {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/app.Ready", "owner": _r_0}, "snd": _host_0}, "snd": ($List$append$({$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Nil"}}, ($$$$047experiments$047public$045nested$045provision$047app$058families$(_family_0))))};
    }
  } else {
    if (_host_0.$ === "../experiments/public-nested-provision/app.Ready") {
      const _s_1 = _host_0["owner"];
      return {$: "Tuple", "fst": {$: "Tuple", "fst": _resource_0, "snd": {$: "../experiments/public-nested-provision/app.Ready", "owner": _s_1}}, "snd": ($List$append$({$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Nil"}}, ($$$$047experiments$047public$045nested$045provision$047app$058families$(_family_0))))};
    } else {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": _resource_0, "snd": _host_0}, "snd": ($$$$047experiments$047public$045nested$045provision$047app$058families$(_family_0))};
    }
  }
}

function $$$$047src$047ecs$047schedule$058contains$(_ids_0, _id_0) {
  if (_ids_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    const _x_0 = (_head_0 === _id_0);
    const _x_1 = ($$$$047src$047ecs$047schedule$058contains$(_rest_0, _id_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047src$047ecs$047schedule$045provision$058unique_add$1260$(_present_0, _item_0, _rest_0) {
  if (_present_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _item_0, "tail": _rest_0};
  }
}

function $$$$047src$047ecs$047schedule$045provision$058contains$1260$(_items_0, _item_0) {
  if (_items_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    const _x_0 = ($$$$047src$047ecs$047schedule$045provision$058same$1260$(_head_0, _item_0));
    const _x_1 = ($$$$047src$047ecs$047schedule$045provision$058contains$1260$(_rest_0, _item_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058texts$(_items_0) {
  if (_items_0.$ === "Nil") {
    return "";
  } else {
    const _item_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    const _x_0 = ($$$$047experiments$047public$045nested$045provision$047other$058texts$(_rest_0));
    const _x_1 = ("," + _x_0);
    return (_item_0 + _x_1);
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058measured_before$(_observed_0, _text_0) {
  const _t_0 = _observed_0["fst"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["nextId"];
  const _high_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _cap_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _store_0 = _t_0["store"];
  const _t_1 = _t_0["resource"];
  const _resource_0 = _t_1["resource"];
  const _host_0 = _t_1["service"];
  const _writes_0 = _t_1["resourceWrites"];
  const _calls_0 = _t_1["hostCalls"];
  const _conditions_0 = _t_1["conditionCalls"];
  const _retired_0 = _t_1["retired"];
  const _trace_0 = _t_1["trace"];
  const _reservedIds_0 = _t_1["reservedIds"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSystem_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _handles_0 = _observed_0["snd"];
  const _x_0 = ($List$show$1260$(_events_0));
  const _x_1 = ($List$show$1264$(_handles_0));
  const _x_2 = (";published=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($List$show$1260$(_reservedIds_0));
  const _x_5 = (";beforeLive=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = (";reserved=" + _x_6);
  return $$$$047experiments$047public$045nested$045provision$047other$058measured_probed$(($$$$047experiments$047public$045nested$045provision$047other$058measured_probe$({$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../experiments/public-nested-provision/other.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_0, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0})), (_text_0 + _x_7));
}

function $$$$047src$047ecs$047world$058handles$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047world$058handles_tail_finish$1261$(($$$$047src$047ecs$047world$058collect_tail$1261$(_highWater_0, _namespace_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047experiments$047public$045nested$045provision$047other$058world_snapshot_join$(_world_0, _slots_0, _component_0, _prefix_0, _queue_0, _oldOwners_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _t_0 = _world_0["store"];
  const _family_0 = _t_0["family"];
  const _cwrites_0 = _t_0["writes"];
  const _t_1 = _world_0["resource"];
  const _rwrites_0 = _t_1["resourceWrites"];
  const _calls_0 = _t_1["hostCalls"];
  const _conditions_0 = _t_1["conditionCalls"];
  const _trace_0 = _t_1["trace"];
  const _reservedIds_0 = _t_1["reservedIds"];
  const _events_0 = _world_0["events"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _t_2 = _slots_0["fst"];
  const _resource_0 = _t_2["fst"];
  const _rtext_0 = _t_2["snd"];
  const _t_3 = _slots_0["snd"];
  const _host_0 = _t_3["fst"];
  const _stext_0 = _t_3["snd"];
  const _column_0 = _component_0["fst"];
  const _t_4 = _component_0["snd"];
  if (_t_4.$ === "None") {
    const _pending_0 = _queue_0["fst"];
    const _queued_0 = _queue_0["snd"];
    const _retired_0 = _oldOwners_0["fst"];
    const _oldCells_0 = _oldOwners_0["snd"];
    const _x_0 = ($List$show$1260$(_trace_0));
    const _x_1 = ($U32$show$(_queued_0));
    const _x_2 = (";trace=" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($List$show$1260$(_events_0));
    const _x_5 = (";queue=" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    const _x_7 = ($U32$show$(_clock_0));
    const _x_8 = (";events=" + _x_6);
    const _x_9 = (_x_7 + _x_8);
    const _x_10 = ($U32$show$(_conditions_0));
    const _x_11 = (";clock=" + _x_9);
    const _x_12 = (_x_10 + _x_11);
    const _x_13 = ($U32$show$(_calls_0));
    const _x_14 = (";conditions=" + _x_12);
    const _x_15 = (_x_13 + _x_14);
    const _x_16 = ($U32$show$(_rwrites_0));
    const _x_17 = (";host=" + _x_15);
    const _x_18 = (_x_16 + _x_17);
    const _x_19 = ($U32$show$(_cwrites_0));
    const _x_20 = (";rw=" + _x_18);
    const _x_21 = (_x_19 + _x_20);
    const _x_22 = (";cw=" + _x_21);
    const _x_23 = (_stext_0 + _x_22);
    const _x_24 = (";service=" + _x_23);
    const _x_25 = (_rtext_0 + _x_24);
    const _x_26 = (";resource=" + _x_25);
    const _x_27 = ("absent" + _x_26);
    const _x_28 = ($List$show$1263$(_oldCells_0));
    const _x_29 = (";cell=" + _x_27);
    const _x_30 = (_x_28 + _x_29);
    const _x_31 = (";retired=" + _x_30);
    return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/other.Store", "column": _column_0, "family": _family_0, "writes": _cwrites_0}, "resource": {$: "../experiments/public-nested-provision/other.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _rwrites_0, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": (_prefix_0 + _x_31)};
  } else {
    const _cells_0 = _t_4["value"];
    const _pending_1 = _queue_0["fst"];
    const _queued_1 = _queue_0["snd"];
    const _retired_1 = _oldOwners_0["fst"];
    const _oldCells_1 = _oldOwners_0["snd"];
    const _x_32 = ($List$show$1260$(_trace_0));
    const _x_33 = ($U32$show$(_queued_1));
    const _x_34 = (";trace=" + _x_32);
    const _x_35 = (_x_33 + _x_34);
    const _x_36 = ($List$show$1260$(_events_0));
    const _x_37 = (";queue=" + _x_35);
    const _x_38 = (_x_36 + _x_37);
    const _x_39 = ($U32$show$(_clock_0));
    const _x_40 = (";events=" + _x_38);
    const _x_41 = (_x_39 + _x_40);
    const _x_42 = ($U32$show$(_conditions_0));
    const _x_43 = (";clock=" + _x_41);
    const _x_44 = (_x_42 + _x_43);
    const _x_45 = ($U32$show$(_calls_0));
    const _x_46 = (";conditions=" + _x_44);
    const _x_47 = (_x_45 + _x_46);
    const _x_48 = ($U32$show$(_rwrites_0));
    const _x_49 = (";host=" + _x_47);
    const _x_50 = (_x_48 + _x_49);
    const _x_51 = ($U32$show$(_cwrites_0));
    const _x_52 = (";rw=" + _x_50);
    const _x_53 = (_x_51 + _x_52);
    const _x_54 = (";cw=" + _x_53);
    const _x_55 = (_stext_0 + _x_54);
    const _x_56 = (";service=" + _x_55);
    const _x_57 = (_rtext_0 + _x_56);
    const _x_58 = ($List$show$1260$(_cells_0));
    const _x_59 = (";resource=" + _x_57);
    const _x_60 = (_x_58 + _x_59);
    const _x_61 = ($List$show$1263$(_oldCells_1));
    const _x_62 = (";cell=" + _x_60);
    const _x_63 = (_x_61 + _x_62);
    const _x_64 = (";retired=" + _x_63);
    return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/other.Store", "column": _column_0, "family": _family_0, "writes": _cwrites_0}, "resource": {$: "../experiments/public-nested-provision/other.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _rwrites_0, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_1, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_1, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": (_prefix_0 + _x_64)};
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058slot_snapshot$(_value_0) {
  if (_value_0.$ === "../experiments/public-nested-provision/other.Missing") {
    return {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/other.Missing"}, "snd": "missing"};
  } else if (_value_0.$ === "../experiments/public-nested-provision/other.Ready") {
    const _owner_0 = _value_0["owner"];
    return $$$$047experiments$047public$045nested$045provision$047other$058slot_projected$1260$(($$$$047experiments$047public$045nested$045provision$047other$058projected$(_owner_0)));
  } else {
    const _owner_1 = _value_0["owner"];
    return $$$$047experiments$047public$045nested$045provision$047other$058incompatible_snapshot$(($$$$047experiments$047public$045nested$045provision$047other$058slot_projected$1261$(($$$$047experiments$047public$045nested$045provision$047other$058projected$(_owner_1)))));
  }
}

function $$$$047src$047ecs$047column$058view$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058plain_view_sized$1261$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058prepared_view_state$1261$(_id_0, ($$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_view_state$1261$(_id_0, ($$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_view_state$1261$(_id_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058family_code$(_value_0) {
  if (_value_0.$ === "../experiments/public-nested-provision/other.AbsentFamily") {
    return 0;
  } else if (_value_0.$ === "../experiments/public-nested-provision/other.DeclaredFamily") {
    return 1;
  } else {
    return 2;
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058queue_count$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047experiments$047public$045nested$045provision$047other$058queue_join$(_command_0, ($$$$047experiments$047public$045nested$045provision$047other$058queue_count$(_rest_0)));
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058retired_snapshot$(_owners_0) {
  if (_owners_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _owner_0 = _owners_0["head"];
    const _rest_0 = _owners_0["tail"];
    return $$$$047experiments$047public$045nested$045provision$047other$058retired_join$(($$$$047experiments$047public$045nested$045provision$047other$058projected$(_owner_0)), ($$$$047experiments$047public$045nested$045provision$047other$058retired_snapshot$(_rest_0)));
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058result_snapshot$(_label_0, _schedule_0, _world_0) {
  const _owners_0 = _schedule_0["snd"];
  const _text_0 = _world_0["snd"];
  const _x_0 = ("|" + _text_0);
  const _x_1 = (_owners_0 + _x_0);
  const _x_2 = ("|owners=" + _x_1);
  return (_label_0 + _x_2);
}

function $$$$047experiments$047public$045nested$045provision$047other$058observations$(_items_0) {
  if (_items_0.$ === "Nil") {
    return "";
  } else {
    const _t_0 = _items_0["head"];
    if (_t_0.$ === "../src/ecs/schedule.Entered") {
      const _name_0 = _t_0["name"];
      const _rest_0 = _items_0["tail"];
      const _x_0 = ($$$$047experiments$047public$045nested$045provision$047other$058observations$(_rest_0));
      const _x_1 = (";" + _x_0);
      const _x_2 = (_name_0 + _x_1);
      return ("phase:" + _x_2);
    } else if (_t_0.$ === "../src/ecs/schedule.Ran") {
      const _id_0 = _t_0["id"];
      const _rest_1 = _items_0["tail"];
      const _x_3 = ($$$$047experiments$047public$045nested$045provision$047other$058observations$(_rest_1));
      const _x_4 = ($U32$show$(_id_0));
      const _x_5 = (";" + _x_3);
      const _x_6 = (_x_4 + _x_5);
      return ("run:" + _x_6);
    } else if (_t_0.$ === "../src/ecs/schedule.Skipped") {
      const _id_1 = _t_0["id"];
      const _rest_2 = _items_0["tail"];
      const _x_7 = ($$$$047experiments$047public$045nested$045provision$047other$058observations$(_rest_2));
      const _x_8 = ($U32$show$(_id_1));
      const _x_9 = (";" + _x_7);
      const _x_10 = (_x_8 + _x_9);
      return ("skip:" + _x_10);
    } else {
      const _rest_3 = _items_0["tail"];
      const _x_11 = ($$$$047experiments$047public$045nested$045provision$047other$058observations$(_rest_3));
      return ("barrier;" + _x_11);
    }
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058needs$(_items_0) {
  if (_items_0.$ === "Nil") {
    return "";
  } else {
    const _item_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    const _x_0 = ($$$$047experiments$047public$045nested$045provision$047other$058needs$(_rest_0));
    const _x_1 = ($$$$047experiments$047public$045nested$045provision$047other$058requirement$(_item_0));
    const _x_2 = ("," + _x_0);
    return (_x_1 + _x_2);
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058measured_refusal_only$(_schedule_0, _world_0, _requirements_0, _missing_0) {
  const _ownertext_0 = _schedule_0["snd"];
  const _text_0 = _world_0["snd"];
  const _x_0 = ("|" + _text_0);
  const _x_1 = (_ownertext_0 + _x_0);
  const _x_2 = ($$$$047experiments$047public$045nested$045provision$047other$058needs$(_requirements_0));
  const _x_3 = ("|owners=" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($$$$047experiments$047public$045nested$045provision$047other$058needs$(_missing_0));
  const _x_6 = (":needs=" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  return ("missing:" + _x_7);
}

function $$$$047experiments$047public$045nested$045provision$047other$058refusal_observed$(_schedule_0, _world_0, _requirements_0, _missing_0) {
  const _schedule_1 = _schedule_0["fst"];
  const _ownertext_0 = _schedule_0["snd"];
  const _world_1 = _world_0["fst"];
  const _text_0 = _world_0["snd"];
  const _x_0 = ($$$$047experiments$047public$045nested$045provision$047other$058retry_result$(($$$$047src$047ecs$047schedule$045provision$058run$1261$({$: "../src/ecs/schedule-provision.Provisioned", "schedule": _schedule_1, "requirements": _requirements_0}, ($$$$047experiments$047public$045nested$045provision$047other$058repair$(_world_1))))));
  const _x_1 = ("\nretry|" + _x_0);
  const _x_2 = (_text_0 + _x_1);
  const _x_3 = ("|" + _x_2);
  const _x_4 = (_ownertext_0 + _x_3);
  const _x_5 = ($$$$047experiments$047public$045nested$045provision$047other$058needs$(_requirements_0));
  const _x_6 = ("|owners=" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($$$$047experiments$047public$045nested$045provision$047other$058needs$(_missing_0));
  const _x_9 = (":needs=" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  return ("missing:" + _x_10);
}

function $$$$047experiments$047public$045nested$045provision$047other$058schedule_join$(_ns_0, _name_0, _steps_0, _owners_0) {
  const _owners_1 = _owners_0["fst"];
  const _text_0 = _owners_0["snd"];
  const _x_0 = ($U32$show$(_ns_0));
  const _x_1 = (":" + _text_0);
  const _x_2 = (_x_0 + _x_1);
  const _x_3 = (":" + _x_2);
  return {$: "Tuple", "fst": {$: "../src/ecs/schedule.Schedule", "namespace": _ns_0, "name": _name_0, "steps": _steps_0, "owners": _owners_1}, "snd": (_name_0 + _x_3)};
}

function $$$$047src$047ecs$047schedule$045provision$058run_checked$1261$(_missing_0, _schedule_0, _world_0, _needs_0) {
  if (_missing_0.$ === "Con") {
    const _first_0 = _missing_0["head"];
    const _rest_0 = _missing_0["tail"];
    return {$: "../src/ecs/schedule-provision.Missing", "schedule": {$: "../src/ecs/schedule-provision.Provisioned", "schedule": _schedule_0, "requirements": _needs_0}, "world": _world_0, "missing": {$: "Con", "head": _first_0, "tail": _rest_0}};
  } else {
    return {$: "../src/ecs/schedule-provision.Executed", "result": run_loop($$$$047src$047ecs$047schedule$058run$1261$(_schedule_0, _world_0)), "requirements": _needs_0};
  }
}

function $$$$047src$047ecs$047schedule$045provision$058missing_requirements$1261$(_needs_0, _available_0) {
  if (_needs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _needs_0["head"];
    const _rest_0 = _needs_0["tail"];
    return $$$$047src$047ecs$047schedule$045provision$058missing_next$1261$(($$$$047src$047ecs$047schedule$045provision$058contains$1261$(_available_0, _head_0)), _head_0, ($$$$047src$047ecs$047schedule$045provision$058missing_requirements$1261$(_rest_0, _available_0)));
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058provisioned$(_world_0, _observed_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _writes_0 = _t_0["resourceWrites"];
  const _calls_0 = _t_0["hostCalls"];
  const _conditions_0 = _t_0["conditionCalls"];
  const _retired_0 = _t_0["retired"];
  const _trace_0 = _t_0["trace"];
  const _reservedIds_0 = _t_0["reservedIds"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _t_1 = _observed_0["fst"];
  const _resource_0 = _t_1["fst"];
  const _host_0 = _t_1["snd"];
  const _available_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../experiments/public-nested-provision/other.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_0, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _available_0};
}

function $$$$047experiments$047public$045nested$045provision$047other$058available_slots$(_family_0, _resource_0, _host_0) {
  if (_resource_0.$ === "../experiments/public-nested-provision/other.Ready") {
    const _r_0 = _resource_0["owner"];
    if (_host_0.$ === "../experiments/public-nested-provision/other.Ready") {
      const _s_0 = _host_0["owner"];
      return {$: "Tuple", "fst": {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/other.Ready", "owner": _r_0}, "snd": {$: "../experiments/public-nested-provision/other.Ready", "owner": _s_0}}, "snd": ($List$append$({$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Nil"}}}, ($$$$047experiments$047public$045nested$045provision$047other$058families$(_family_0))))};
    } else {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/other.Ready", "owner": _r_0}, "snd": _host_0}, "snd": ($List$append$({$: "Con", "head": {$: "../src/ecs/schedule-provision.Resource", "id": 1}, "tail": {$: "Nil"}}, ($$$$047experiments$047public$045nested$045provision$047other$058families$(_family_0))))};
    }
  } else {
    if (_host_0.$ === "../experiments/public-nested-provision/other.Ready") {
      const _s_1 = _host_0["owner"];
      return {$: "Tuple", "fst": {$: "Tuple", "fst": _resource_0, "snd": {$: "../experiments/public-nested-provision/other.Ready", "owner": _s_1}}, "snd": ($List$append$({$: "Con", "head": {$: "../src/ecs/schedule-provision.Service", "id": 1}, "tail": {$: "Nil"}}, ($$$$047experiments$047public$045nested$045provision$047other$058families$(_family_0))))};
    } else {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": _resource_0, "snd": _host_0}, "snd": ($$$$047experiments$047public$045nested$045provision$047other$058families$(_family_0))};
    }
  }
}

function $$$$047src$047ecs$047schedule$045provision$058unique_add$1261$(_present_0, _item_0, _rest_0) {
  if (_present_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _item_0, "tail": _rest_0};
  }
}

function $$$$047src$047ecs$047schedule$045provision$058contains$1261$(_items_0, _item_0) {
  if (_items_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    const _x_0 = ($$$$047src$047ecs$047schedule$045provision$058same$1261$(_head_0, _item_0));
    const _x_1 = ($$$$047src$047ecs$047schedule$045provision$058contains$1261$(_rest_0, _item_0));
    return (_x_0 || _x_1);
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058measured_probed$(_probed_0, _text_0) {
  const _world_0 = _probed_0["fst"];
  const _id_0 = _probed_0["snd"];
  return $$$$047experiments$047public$045nested$045provision$047app$058measured_after$(($$$$047src$047ecs$047world$058handles$1260$(run_loop($$$$047src$047ecs$047world$058barrier$1260$(_world_0)))), _text_0, _id_0);
}

function $$$$047experiments$047public$045nested$045provision$047app$058measured_probe$(_world_0) {
  return $$$$047experiments$047public$045nested$045provision$047app$058measured_probe_reserved$(($$$$047src$047ecs$047commands$058tx_spawn$1260$(($$$$047src$047ecs$047transaction$058begin$1260$(_world_0)), {$: "Unit"})));
}

function $List$show$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047experiments$047public$045nested$045provision$047app$058measured_handle$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047src$047ecs$047world$058handles_tail_finish$1260$(_scanned_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _scanned_0["live"];
  const _handles_0 = _scanned_0["handles"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _handles_0};
}

function $$$$047src$047ecs$047world$058collect_tail$1260$(_remaining_0, _namespace_0, _live_0) {
  return $$$$047src$047ecs$047world$058collect_tail_loop$1260$(nat_chk(2 * _remaining_0), _remaining_0, _namespace_0, {$: "../src/ecs/world.Ready", "live": _live_0, "handles": {$: "Nil"}});
}

function $List$show$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047experiments$047public$045nested$045provision$047app$058string_identity$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058slot_projected$1260$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047experiments$047public$045nested$045provision$047app$058ready$(_owner_0)), "snd": ($List$show$1260$(_values_0))};
}

function $$$$047experiments$047public$045nested$045provision$047app$058projected$(_values_0) {
  if (_values_0.length === 1) {
    const _a_0 = _values_0[0];
    return {$: "Tuple", "fst": [_a_0], "snd": {$: "Con", "head": _a_0, "tail": {$: "Nil"}}};
  } else {
    const _left_0 = _values_0.slice(0, _values_0.length >> 1);
    const _right_0 = _values_0.slice(_values_0.length >> 1);
    return $$$$047experiments$047public$045nested$045provision$047app$058projected_join$(($$$$047experiments$047public$045nested$045provision$047app$058projected$(_left_0)), ($$$$047experiments$047public$045nested$045provision$047app$058projected$(_right_0)));
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058incompatible_snapshot$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": ("incompatible:" + _text_0)};
}

function $$$$047experiments$047public$045nested$045provision$047app$058slot_projected$1261$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047experiments$047public$045nested$045provision$047app$058bad$(_owner_0)), "snd": ($List$show$1260$(_values_0))};
}

function $$$$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047src$047ecs$047column$058unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047src$047ecs$047column$058indexed_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058queue_join$(_head_0, _tail_0) {
  const _tail_1 = _tail_0["fst"];
  const _n_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_0, "tail": _tail_1}, "snd": ((_n_0 + 1) >>> 0)};
}

function $$$$047experiments$047public$045nested$045provision$047app$058retired_join$(_head_0, _tail_0) {
  const _owner_0 = _head_0["fst"];
  const _cells_0 = _head_0["snd"];
  const _tail_1 = _tail_0["fst"];
  const _views_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _owner_0, "tail": _tail_1}, "snd": {$: "Con", "head": ($List$show$1260$(_cells_0)), "tail": _views_0}};
}

function $$$$047experiments$047public$045nested$045provision$047app$058requirement$(_item_0) {
  if (_item_0.$ === "../src/ecs/schedule-provision.Component") {
    const _id_0 = _item_0["id"];
    const _x_0 = ($U32$show$(_id_0));
    return ("C" + _x_0);
  } else if (_item_0.$ === "../src/ecs/schedule-provision.Resource") {
    const _id_1 = _item_0["id"];
    const _x_1 = ($U32$show$(_id_1));
    return ("R" + _x_1);
  } else {
    const _id_2 = _item_0["id"];
    const _x_2 = ($U32$show$(_id_2));
    return ("S" + _x_2);
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058retry_result$(_result_0) {
  if (_result_0.$ === "../src/ecs/schedule-provision.Executed") {
    const _result_1 = _result_0["result"];
    const _needs_0 = _result_0["requirements"];
    return $$$$047experiments$047public$045nested$045provision$047app$058finished$(_result_1, _needs_0);
  } else {
    const _item_0 = _result_0["missing"];
    const _x_0 = ($$$$047experiments$047public$045nested$045provision$047app$058needs$(_item_0));
    return ("still-missing:" + _x_0);
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058repair$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _t_0 = _world_0["store"];
  const _column_0 = _t_0["column"];
  const _writes_0 = _t_0["writes"];
  const _t_1 = _world_0["resource"];
  const _resource_0 = _t_1["resource"];
  const _host_0 = _t_1["service"];
  const _rwrites_0 = _t_1["resourceWrites"];
  const _calls_0 = _t_1["hostCalls"];
  const _conditions_0 = _t_1["conditionCalls"];
  const _retired_0 = _t_1["retired"];
  const _trace_0 = _t_1["trace"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/app.Store", "column": _column_0, "family": {$: "../experiments/public-nested-provision/app.DeclaredFamily", "descriptor": ($$$$047experiments$047public$045nested$045provision$047app$058family$())}, "writes": _writes_0}, "resource": {$: "../experiments/public-nested-provision/app.Resources", "resource": ($$$$047experiments$047public$045nested$045provision$047app$058repaired_slot$(_resource_0, 20)), "service": ($$$$047experiments$047public$045nested$045provision$047app$058repaired_slot$(_host_0, 30)), "resourceWrites": _rwrites_0, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": {$: "Nil"}}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047src$047ecs$047schedule$058run$1260$(_schedule_0, _world_0) {
  return $$$$047src$047ecs$047schedule$058run_namespace$1260$(_schedule_0, ($$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $$$$047src$047ecs$047schedule$045provision$058missing_next$1260$(_present_0, _item_0, _next_0) {
  if (!_present_0) {
    return {$: "Con", "head": _item_0, "tail": _next_0};
  } else {
    return _next_0;
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058families$(_compatible_0) {
  if (_compatible_0.$ === "../experiments/public-nested-provision/app.DeclaredFamily") {
    return {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Nil"}};
  } else {
    return {$: "Nil"};
  }
}

function $$$$047src$047ecs$047schedule$045provision$058same$1260$(_a_0, _b_0) {
  if (_a_0.$ === "../src/ecs/schedule-provision.Component") {
    const _a_1 = _a_0["id"];
    if (_b_0.$ === "../src/ecs/schedule-provision.Component") {
      const _b_1 = _b_0["id"];
      return (_a_1 === _b_1);
    } else {
      return false;
    }
  } else if (_a_0.$ === "../src/ecs/schedule-provision.Resource") {
    const _a_2 = _a_0["id"];
    if (_b_0.$ === "../src/ecs/schedule-provision.Resource") {
      const _b_2 = _b_0["id"];
      return (_a_2 === _b_2);
    } else {
      return false;
    }
  } else {
    const _a_3 = _a_0["id"];
    if (_b_0.$ === "../src/ecs/schedule-provision.Service") {
      const _b_3 = _b_0["id"];
      return (_a_3 === _b_3);
    } else {
      return false;
    }
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058measured_probed$(_probed_0, _text_0) {
  const _world_0 = _probed_0["fst"];
  const _id_0 = _probed_0["snd"];
  return $$$$047experiments$047public$045nested$045provision$047other$058measured_after$(($$$$047src$047ecs$047world$058handles$1261$(run_loop($$$$047src$047ecs$047world$058barrier$1261$(_world_0)))), _text_0, _id_0);
}

function $$$$047experiments$047public$045nested$045provision$047other$058measured_probe$(_world_0) {
  return $$$$047experiments$047public$045nested$045provision$047other$058measured_probe_reserved$(($$$$047src$047ecs$047commands$058tx_spawn$1261$(($$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), {$: "Unit"})));
}

function $List$show$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047experiments$047public$045nested$045provision$047other$058measured_handle$(_h_0));
    const _x_1 = ($List$show$go$1264$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047src$047ecs$047world$058handles_tail_finish$1261$(_scanned_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _scanned_0["live"];
  const _handles_0 = _scanned_0["handles"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _handles_0};
}

function $$$$047src$047ecs$047world$058collect_tail$1261$(_remaining_0, _namespace_0, _live_0) {
  return $$$$047src$047ecs$047world$058collect_tail_loop$1261$(nat_chk(2 * _remaining_0), _remaining_0, _namespace_0, {$: "../src/ecs/world.Ready", "live": _live_0, "handles": {$: "Nil"}});
}

function $List$show$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047experiments$047public$045nested$045provision$047other$058string_identity$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058slot_projected$1260$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047experiments$047public$045nested$045provision$047other$058ready$(_owner_0)), "snd": ($List$show$1260$(_values_0))};
}

function $$$$047experiments$047public$045nested$045provision$047other$058projected$(_values_0) {
  if (_values_0.length === 1) {
    const _a_0 = _values_0[0];
    return {$: "Tuple", "fst": [_a_0], "snd": {$: "Con", "head": _a_0, "tail": {$: "Nil"}}};
  } else {
    const _left_0 = _values_0.slice(0, _values_0.length >> 1);
    const _right_0 = _values_0.slice(_values_0.length >> 1);
    return $$$$047experiments$047public$045nested$045provision$047other$058projected_join$(($$$$047experiments$047public$045nested$045provision$047other$058projected$(_left_0)), ($$$$047experiments$047public$045nested$045provision$047other$058projected$(_right_0)));
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058incompatible_snapshot$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": ("incompatible:" + _text_0)};
}

function $$$$047experiments$047public$045nested$045provision$047other$058slot_projected$1261$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047experiments$047public$045nested$045provision$047other$058bad$(_owner_0)), "snd": ($List$show$1260$(_values_0))};
}

function $$$$047src$047ecs$047column$058plain_view_sized$1261$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058plain_view_checked$1261$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058prepared_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058prepared_view_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047src$047ecs$047column$058unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_view_sized$1261$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047src$047ecs$047column$058indexed_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_prepared_view_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058queue_join$(_head_0, _tail_0) {
  const _tail_1 = _tail_0["fst"];
  const _n_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_0, "tail": _tail_1}, "snd": ((_n_0 + 1) >>> 0)};
}

function $$$$047experiments$047public$045nested$045provision$047other$058retired_join$(_head_0, _tail_0) {
  const _owner_0 = _head_0["fst"];
  const _cells_0 = _head_0["snd"];
  const _tail_1 = _tail_0["fst"];
  const _views_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _owner_0, "tail": _tail_1}, "snd": {$: "Con", "head": ($List$show$1260$(_cells_0)), "tail": _views_0}};
}

function $$$$047experiments$047public$045nested$045provision$047other$058requirement$(_item_0) {
  if (_item_0.$ === "../src/ecs/schedule-provision.Component") {
    const _id_0 = _item_0["id"];
    const _x_0 = ($U32$show$(_id_0));
    return ("C" + _x_0);
  } else if (_item_0.$ === "../src/ecs/schedule-provision.Resource") {
    const _id_1 = _item_0["id"];
    const _x_1 = ($U32$show$(_id_1));
    return ("R" + _x_1);
  } else {
    const _id_2 = _item_0["id"];
    const _x_2 = ($U32$show$(_id_2));
    return ("S" + _x_2);
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058retry_result$(_result_0) {
  if (_result_0.$ === "../src/ecs/schedule-provision.Executed") {
    const _result_1 = _result_0["result"];
    const _needs_0 = _result_0["requirements"];
    return $$$$047experiments$047public$045nested$045provision$047other$058finished$(_result_1, _needs_0);
  } else {
    const _item_0 = _result_0["missing"];
    const _x_0 = ($$$$047experiments$047public$045nested$045provision$047other$058needs$(_item_0));
    return ("still-missing:" + _x_0);
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058repair$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _t_0 = _world_0["store"];
  const _column_0 = _t_0["column"];
  const _writes_0 = _t_0["writes"];
  const _t_1 = _world_0["resource"];
  const _resource_0 = _t_1["resource"];
  const _host_0 = _t_1["service"];
  const _rwrites_0 = _t_1["resourceWrites"];
  const _calls_0 = _t_1["hostCalls"];
  const _conditions_0 = _t_1["conditionCalls"];
  const _retired_0 = _t_1["retired"];
  const _trace_0 = _t_1["trace"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/other.Store", "column": _column_0, "family": {$: "../experiments/public-nested-provision/other.DeclaredFamily", "descriptor": ($$$$047experiments$047public$045nested$045provision$047other$058family$())}, "writes": _writes_0}, "resource": {$: "../experiments/public-nested-provision/other.Resources", "resource": ($$$$047experiments$047public$045nested$045provision$047other$058repaired_slot$(_resource_0, 20)), "service": ($$$$047experiments$047public$045nested$045provision$047other$058repaired_slot$(_host_0, 30)), "resourceWrites": _rwrites_0, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": {$: "Nil"}}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047src$047ecs$047schedule$058run$1261$(_schedule_0, _world_0) {
  return $$$$047src$047ecs$047schedule$058run_namespace$1261$(_schedule_0, ($$$$047src$047ecs$047world$058namespace$1261$(_world_0)));
}

function $$$$047src$047ecs$047schedule$045provision$058missing_next$1261$(_present_0, _item_0, _next_0) {
  if (!_present_0) {
    return {$: "Con", "head": _item_0, "tail": _next_0};
  } else {
    return _next_0;
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058families$(_compatible_0) {
  if (_compatible_0.$ === "../experiments/public-nested-provision/other.DeclaredFamily") {
    return {$: "Con", "head": {$: "../src/ecs/schedule-provision.Component", "id": 1}, "tail": {$: "Nil"}};
  } else {
    return {$: "Nil"};
  }
}

function $$$$047src$047ecs$047schedule$045provision$058same$1261$(_a_0, _b_0) {
  if (_a_0.$ === "../src/ecs/schedule-provision.Component") {
    const _a_1 = _a_0["id"];
    if (_b_0.$ === "../src/ecs/schedule-provision.Component") {
      const _b_1 = _b_0["id"];
      return (_a_1 === _b_1);
    } else {
      return false;
    }
  } else if (_a_0.$ === "../src/ecs/schedule-provision.Resource") {
    const _a_2 = _a_0["id"];
    if (_b_0.$ === "../src/ecs/schedule-provision.Resource") {
      const _b_2 = _b_0["id"];
      return (_a_2 === _b_2);
    } else {
      return false;
    }
  } else {
    const _a_3 = _a_0["id"];
    if (_b_0.$ === "../src/ecs/schedule-provision.Service") {
      const _b_3 = _b_0["id"];
      return (_a_3 === _b_3);
    } else {
      return false;
    }
  }
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058measured_after$(_observed_0, _text_0, _id_0) {
  const _world_0 = _observed_0["fst"];
  const _handles_0 = _observed_0["snd"];
  const _x_0 = ($List$show$1262$(_handles_0));
  const _x_1 = ($U32$show$(_id_0));
  const _x_2 = (";afterLive=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (";probeId=" + _x_3);
  return {$: "Tuple", "fst": _world_0, "snd": (_text_0 + _x_4)};
}

function $$$$047src$047ecs$047world$058barrier$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047world$058drain_fifo$1260$(_pending_0, {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047experiments$047public$045nested$045provision$047app$058measured_probe_reserved$(_result_0) {
  const _tx_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../src/ecs/world.Reserved") {
    const _t_1 = _t_0["handle"];
    const _id_0 = _t_1["id"];
    return $$$$047experiments$047public$045nested$045provision$047app$058measured_probe_finished$(($$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, {$: "../src/ecs/transaction.Success"})), _id_0);
  } else {
    return $$$$047experiments$047public$045nested$045provision$047app$058measured_probe_finished$(($$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, {$: "../src/ecs/transaction.Success"})), 0);
  }
}

function $$$$047src$047ecs$047commands$058tx_spawn$1260$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047src$047ecs$047commands$058spawn_join$1260$(($$$$047src$047ecs$047world$058reserve_id$1260$(_world_0)), _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $List$show$go$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058measured_handle$(_handle_0) {
  const _id_0 = _handle_0["id"];
  return $U32$show$(_id_0);
}

function $List$show$go$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047experiments$047public$045nested$045provision$047app$058measured_handle$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047src$047ecs$047world$058collect_tail_loop$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _remaining_0 = $1;
      const _namespace_0 = $2;
      const _phase_0 = $3;
      if (_fuel_0 === 0) {
        if (_phase_0.$ === "../src/ecs/world.Ready") {
          const _live_0 = _phase_0["live"];
          const _handles_0 = _phase_0["handles"];
          return {$: "../src/ecs/world.HandleScan", "live": _live_0, "handles": _handles_0};
        } else {
          const _t_0 = _phase_0["checked"];
          const _live_1 = _t_0["fst"];
          const _handles_1 = _phase_0["handles"];
          return {$: "../src/ecs/world.HandleScan", "live": _live_1, "handles": _handles_1};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0 === 0) {
          if (_phase_0.$ === "../src/ecs/world.Ready") {
            const _live_2 = _phase_0["live"];
            const _handles_2 = _phase_0["handles"];
            return {$: "../src/ecs/world.HandleScan", "live": _live_2, "handles": _handles_2};
          } else {
            const _t_1 = _phase_0["checked"];
            const _live_3 = _t_1["fst"];
            const _handles_3 = _phase_0["handles"];
            return {$: "../src/ecs/world.HandleScan", "live": _live_3, "handles": _handles_3};
          }
        } else {
          const _rest_0 = (_remaining_0 - 1);
          if (_phase_0.$ === "../src/ecs/world.Ready") {
            const _live_4 = _phase_0["live"];
            const _handles_4 = _phase_0["handles"];
            const _x_0 = nat_chk(_rest_0 + 1);
            const _x_1 = (_x_0 >>> 0);
            $0 = _more_0;
            $1 = nat_chk(_rest_0 + 1);
            $2 = _namespace_0;
            $3 = {$: "../src/ecs/world.Read", "checked": {$: "Tuple", fst: _live_4, snd: _live_4[_x_1 % _live_4.length]}, "handles": _handles_4};
            continue;
          } else {
            const _t_2 = _phase_0["checked"];
            const _live_5 = _t_2["fst"];
            const _present_0 = _t_2["snd"];
            const _handles_5 = _phase_0["handles"];
            const _x_2 = nat_chk(_rest_0 + 1);
            $0 = _more_0;
            $1 = _rest_0;
            $2 = _namespace_0;
            $3 = {$: "../src/ecs/world.Ready", "live": _live_5, "handles": ($$$$047src$047ecs$047world$058collect_checked$1260$(_present_0, _namespace_0, (_x_2 >>> 0), _handles_5))};
            continue;
          }
        }
      }
    }
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058string_identity$(_value_0) {
  return _value_0;
}

function $List$show$go$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047experiments$047public$045nested$045provision$047app$058string_identity$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058ready$(_owner_0) {
  return {$: "../experiments/public-nested-provision/app.Ready", "owner": _owner_0};
}

function $$$$047experiments$047public$045nested$045provision$047app$058projected_join$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ($List$append$(_a_0, _b_0))};
}

function $$$$047experiments$047public$045nested$045provision$047app$058bad$(_owner_0) {
  return {$: "../experiments/public-nested-provision/app.Incompatible", "owner": _owner_0};
}

function $$$$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058repaired_slot$(_value_0, _fresh_0) {
  if (_value_0.$ === "../experiments/public-nested-provision/app.Missing") {
    return {$: "../experiments/public-nested-provision/app.Ready", "owner": array_node([_fresh_0], [((_fresh_0 + 100) >>> 0)])};
  } else if (_value_0.$ === "../experiments/public-nested-provision/app.Ready") {
    const _owner_0 = _value_0["owner"];
    return {$: "../experiments/public-nested-provision/app.Ready", "owner": _owner_0};
  } else {
    const _owner_1 = _value_0["owner"];
    return {$: "../experiments/public-nested-provision/app.Ready", "owner": _owner_1};
  }
}

function $$$$047src$047ecs$047schedule$058run_namespace$1260$(_schedule_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047src$047ecs$047schedule$058run_actual$1260$(_schedule_0, _world_0, _actual_0);
}

function $$$$047experiments$047public$045nested$045provision$047other$058measured_after$(_observed_0, _text_0, _id_0) {
  const _world_0 = _observed_0["fst"];
  const _handles_0 = _observed_0["snd"];
  const _x_0 = ($List$show$1264$(_handles_0));
  const _x_1 = ($U32$show$(_id_0));
  const _x_2 = (";afterLive=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (";probeId=" + _x_3);
  return {$: "Tuple", "fst": _world_0, "snd": (_text_0 + _x_4)};
}

function $$$$047src$047ecs$047world$058barrier$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047world$058drain_fifo$1261$(_pending_0, {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047experiments$047public$045nested$045provision$047other$058measured_probe_reserved$(_result_0) {
  const _tx_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../src/ecs/world.Reserved") {
    const _t_1 = _t_0["handle"];
    const _id_0 = _t_1["id"];
    return $$$$047experiments$047public$045nested$045provision$047other$058measured_probe_finished$(($$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, {$: "../src/ecs/transaction.Success"})), _id_0);
  } else {
    return $$$$047experiments$047public$045nested$045provision$047other$058measured_probe_finished$(($$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, {$: "../src/ecs/transaction.Success"})), 0);
  }
}

function $$$$047src$047ecs$047commands$058tx_spawn$1261$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047src$047ecs$047commands$058spawn_join$1261$(($$$$047src$047ecs$047world$058reserve_id$1261$(_world_0)), _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047src$047ecs$047transaction$058begin$1261$(_world_0) {
  return {$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047experiments$047public$045nested$045provision$047other$058measured_handle$(_handle_0) {
  const _id_0 = _handle_0["id"];
  return $U32$show$(_id_0);
}

function $List$show$go$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047experiments$047public$045nested$045provision$047other$058measured_handle$(_h_0));
    const _x_1 = ($List$show$go$1264$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047src$047ecs$047world$058collect_tail_loop$1261$($0, $1, $2, $3) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _remaining_0 = $1;
      const _namespace_0 = $2;
      const _phase_0 = $3;
      if (_fuel_0 === 0) {
        if (_phase_0.$ === "../src/ecs/world.Ready") {
          const _live_0 = _phase_0["live"];
          const _handles_0 = _phase_0["handles"];
          return {$: "../src/ecs/world.HandleScan", "live": _live_0, "handles": _handles_0};
        } else {
          const _t_0 = _phase_0["checked"];
          const _live_1 = _t_0["fst"];
          const _handles_1 = _phase_0["handles"];
          return {$: "../src/ecs/world.HandleScan", "live": _live_1, "handles": _handles_1};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0 === 0) {
          if (_phase_0.$ === "../src/ecs/world.Ready") {
            const _live_2 = _phase_0["live"];
            const _handles_2 = _phase_0["handles"];
            return {$: "../src/ecs/world.HandleScan", "live": _live_2, "handles": _handles_2};
          } else {
            const _t_1 = _phase_0["checked"];
            const _live_3 = _t_1["fst"];
            const _handles_3 = _phase_0["handles"];
            return {$: "../src/ecs/world.HandleScan", "live": _live_3, "handles": _handles_3};
          }
        } else {
          const _rest_0 = (_remaining_0 - 1);
          if (_phase_0.$ === "../src/ecs/world.Ready") {
            const _live_4 = _phase_0["live"];
            const _handles_4 = _phase_0["handles"];
            const _x_0 = nat_chk(_rest_0 + 1);
            const _x_1 = (_x_0 >>> 0);
            $0 = _more_0;
            $1 = nat_chk(_rest_0 + 1);
            $2 = _namespace_0;
            $3 = {$: "../src/ecs/world.Read", "checked": {$: "Tuple", fst: _live_4, snd: _live_4[_x_1 % _live_4.length]}, "handles": _handles_4};
            continue;
          } else {
            const _t_2 = _phase_0["checked"];
            const _live_5 = _t_2["fst"];
            const _present_0 = _t_2["snd"];
            const _handles_5 = _phase_0["handles"];
            const _x_2 = nat_chk(_rest_0 + 1);
            $0 = _more_0;
            $1 = _rest_0;
            $2 = _namespace_0;
            $3 = {$: "../src/ecs/world.Ready", "live": _live_5, "handles": ($$$$047src$047ecs$047world$058collect_checked$1261$(_present_0, _namespace_0, (_x_2 >>> 0), _handles_5))};
            continue;
          }
        }
      }
    }
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058string_identity$(_value_0) {
  return _value_0;
}

function $List$show$go$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047experiments$047public$045nested$045provision$047other$058string_identity$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058ready$(_owner_0) {
  return {$: "../experiments/public-nested-provision/other.Ready", "owner": _owner_0};
}

function $$$$047experiments$047public$045nested$045provision$047other$058projected_join$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ($List$append$(_a_0, _b_0))};
}

function $$$$047experiments$047public$045nested$045provision$047other$058bad$(_owner_0) {
  return {$: "../experiments/public-nested-provision/other.Incompatible", "owner": _owner_0};
}

function $$$$047src$047ecs$047column$058plain_view_checked$1261$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047src$047ecs$047column$058plain_view_taken$1261$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047src$047ecs$047column$058prepared_view_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047src$047ecs$047column$058prepared_view_current$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047src$047ecs$047column$058prepared_view_different$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_view_sized$1261$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_view_checked$1261$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047src$047ecs$047column$058indexed_prepared_view_current$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047src$047ecs$047column$058indexed_prepared_view_different$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058repaired_slot$(_value_0, _fresh_0) {
  if (_value_0.$ === "../experiments/public-nested-provision/other.Missing") {
    return {$: "../experiments/public-nested-provision/other.Ready", "owner": array_node([_fresh_0], [((_fresh_0 + 100) >>> 0)])};
  } else if (_value_0.$ === "../experiments/public-nested-provision/other.Ready") {
    const _owner_0 = _value_0["owner"];
    return {$: "../experiments/public-nested-provision/other.Ready", "owner": _owner_0};
  } else {
    const _owner_1 = _value_0["owner"];
    return {$: "../experiments/public-nested-provision/other.Ready", "owner": _owner_1};
  }
}

function $$$$047src$047ecs$047schedule$058run_namespace$1261$(_schedule_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047src$047ecs$047schedule$058run_actual$1261$(_schedule_0, _world_0, _actual_0);
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047src$047ecs$047world$058drain_fifo$1260$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047src$047ecs$047world$058drain_fifo$1260$(_rest_0, _world_0)));
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058measured_probe_finished$(_result_0, _id_0) {
  const _world_0 = _result_0["world"];
  return {$: "Tuple", "fst": _world_0, "snd": _id_0};
}

function $$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0) {
  return $$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0);
}

function $$$$047src$047ecs$047commands$058spawn_join$1260$(_reserved_0, _undo_0, _commands_0, _events_0, _payload_0) {
  const _world_0 = _reserved_0["fst"];
  const _reservation_0 = _reserved_0["snd"];
  return $$$$047src$047ecs$047commands$058spawn_reserved$1260$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047src$047ecs$047world$058collect_checked$1260$(_present_0, _namespace_0, _id_0, _handles_0) {
  if (!_present_0) {
    return _handles_0;
  } else {
    return {$: "Con", "head": {$: "../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _handles_0};
  }
}

function $$$$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, ($$$$047experiments$047public$045nested$045provision$047app$058projected$(_owner_0)));
  }
}

function $$$$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047experiments$047public$045nested$045provision$047app$058projected$(_owned_0)));
  }
}

function $$$$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047src$047ecs$047column$058seek_view$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
  }
}

function $$$$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047experiments$047public$045nested$045provision$047app$058projected$(_owned_0)));
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047src$047ecs$047column$058indexed_seek_view$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
  }
}

function $$$$047src$047ecs$047schedule$058run_actual$1260$(_schedule_0, _world_0, _actual_0) {
  const _namespace_0 = _schedule_0["namespace"];
  const _name_0 = _schedule_0["name"];
  const _steps_0 = _schedule_0["steps"];
  const _owners_0 = _schedule_0["owners"];
  return $$$$047src$047ecs$047schedule$058run_checked$1260$((_namespace_0 === _actual_0), {$: "../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}, _world_0);
}

function $$$$047src$047ecs$047world$058drain_fifo$1261$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047src$047ecs$047world$058drain_fifo$1261$(_rest_0, _world_0)));
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058measured_probe_finished$(_result_0, _id_0) {
  const _world_0 = _result_0["world"];
  return {$: "Tuple", "fst": _world_0, "snd": _id_0};
}

function $$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, _outcome_0) {
  return $$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0);
}

function $$$$047src$047ecs$047commands$058spawn_join$1261$(_reserved_0, _undo_0, _commands_0, _events_0, _payload_0) {
  const _world_0 = _reserved_0["fst"];
  const _reservation_0 = _reserved_0["snd"];
  return $$$$047src$047ecs$047commands$058spawn_reserved$1261$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047src$047ecs$047world$058collect_checked$1261$(_present_0, _namespace_0, _id_0, _handles_0) {
  if (!_present_0) {
    return _handles_0;
  } else {
    return {$: "Con", "head": {$: "../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _handles_0};
  }
}

function $$$$047src$047ecs$047column$058plain_view_taken$1261$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047src$047ecs$047column$058plain_view_projected$1261$(_values_0, _stamps_0, _id_0, ($$$$047experiments$047public$045nested$045provision$047other$058projected$(_owner_0)));
  }
}

function $$$$047src$047ecs$047column$058prepared_view_current$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047experiments$047public$045nested$045provision$047other$058projected$(_owned_0)));
  }
}

function $$$$047src$047ecs$047column$058prepared_view_different$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047src$047ecs$047column$058view_taken$1261$(_id_0, ($$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047src$047ecs$047column$058seek_view$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
  }
}

function $$$$047src$047ecs$047column$058indexed_view_checked$1261$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047src$047ecs$047column$058indexed_view_taken$1261$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_current$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047experiments$047public$045nested$045provision$047other$058projected$(_owned_0)));
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_different$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047src$047ecs$047column$058view_taken$1261$(_id_0, ($$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047src$047ecs$047column$058indexed_seek_view$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
  }
}

function $$$$047src$047ecs$047schedule$058run_actual$1261$(_schedule_0, _world_0, _actual_0) {
  const _namespace_0 = _schedule_0["namespace"];
  const _name_0 = _schedule_0["name"];
  const _steps_0 = _schedule_0["steps"];
  const _owners_0 = _schedule_0["owners"];
  return $$$$047src$047ecs$047schedule$058run_checked$1261$((_namespace_0 === _actual_0), {$: "../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}, _world_0);
}

function $$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047src$047ecs$047commands$058spawn_reserved$1260$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0) {
  if (_reservation_0.$ === "../src/ecs/world.ReservationRejected") {
    const _error_0 = _reservation_0["error"];
    return {$: "Tuple", "fst": {$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "../src/ecs/world.ReservationRejected", "error": _error_0}};
  } else {
    const _handle_0 = _reservation_0["handle"];
    return {$: "Tuple", "fst": {$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047src$047ecs$047commands$058spawn_apply$1260$(_x_0, _handle_0, _payload_0);
}), "tail": _commands_0}, "events": _events_0}, "snd": {$: "../src/ecs/world.Reserved", "handle": _handle_0}};
  }
}

function $$$$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047src$047ecs$047column$058view_taken$1260$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047src$047ecs$047column$058viewed$1260$(($$$$047experiments$047public$045nested$045provision$047app$058projected$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return {$: "../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../src/ecs/column.Column", "values": ($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../src/ecs/column.Column", "values": ($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047src$047ecs$047column$058seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047experiments$047public$045nested$045provision$047app$058projected$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0) {
  return {$: "../src/ecs/column.Indexed", "state": {$: "../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, ($$$$047experiments$047public$045nested$045provision$047app$058projected$(_owner_0)));
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047src$047ecs$047column$058indexed_seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047experiments$047public$045nested$045provision$047app$058projected$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047src$047ecs$047schedule$058run_checked$1260$(_allowed_0, _schedule_0, _world_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/schedule.Rejected", "schedule": _schedule_0, "world": _world_0};
  } else {
    const _namespace_0 = _schedule_0["namespace"];
    const _name_0 = _schedule_0["name"];
    const _steps_0 = _schedule_0["steps"];
    const _owners_0 = _schedule_0["owners"];
    return $$$$047src$047ecs$047schedule$058execute$1260$(_steps_0, _owners_0, _world_0, _namespace_0, _name_0, _steps_0, {$: "Nil"});
  }
}

function $$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047src$047ecs$047commands$058spawn_reserved$1261$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0) {
  if (_reservation_0.$ === "../src/ecs/world.ReservationRejected") {
    const _error_0 = _reservation_0["error"];
    return {$: "Tuple", "fst": {$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "../src/ecs/world.ReservationRejected", "error": _error_0}};
  } else {
    const _handle_0 = _reservation_0["handle"];
    return {$: "Tuple", "fst": {$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047src$047ecs$047commands$058spawn_apply$1261$(_x_0, _handle_0, _payload_0);
}), "tail": _commands_0}, "events": _events_0}, "snd": {$: "../src/ecs/world.Reserved", "handle": _handle_0}};
  }
}

function $$$$047src$047ecs$047column$058plain_view_projected$1261$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047src$047ecs$047column$058restored$1261$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047src$047ecs$047column$058view_taken$1261$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047src$047ecs$047column$058viewed$1261$(($$$$047experiments$047public$045nested$045provision$047other$058projected$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return {$: "../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../src/ecs/column.Column", "values": ($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../src/ecs/column.Column", "values": ($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047src$047ecs$047column$058seek_view$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047experiments$047public$045nested$045provision$047other$058projected$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0) {
  return {$: "../src/ecs/column.Indexed", "state": {$: "../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047src$047ecs$047column$058indexed_view_taken$1261$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, ($$$$047experiments$047public$045nested$045provision$047other$058projected$(_owner_0)));
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047src$047ecs$047column$058indexed_seek_view$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047experiments$047public$045nested$045provision$047other$058projected$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047src$047ecs$047schedule$058run_checked$1261$(_allowed_0, _schedule_0, _world_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/schedule.Rejected", "schedule": _schedule_0, "world": _world_0};
  } else {
    const _namespace_0 = _schedule_0["namespace"];
    const _name_0 = _schedule_0["name"];
    const _steps_0 = _schedule_0["steps"];
    const _owners_0 = _schedule_0["owners"];
    return $$$$047src$047ecs$047schedule$058execute$1261$(_steps_0, _owners_0, _world_0, _namespace_0, _name_0, _steps_0, {$: "Nil"});
  }
}

function $$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../src/ecs/transaction.Returned", "world": ($$$$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../src/ecs/transaction.Returned", "world": ($$$$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047src$047ecs$047commands$058spawn_apply$1260$(_world_0, _handle_0, _payload_0) {
  return $$$$047src$047ecs$047commands$058spawned$1260$(($$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $$$$047src$047ecs$047column$058restored$1260$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047src$047ecs$047column$058viewed$1260$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047src$047ecs$047column$058swap$1260$({$: "../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047src$047ecs$047column$058swap$1260$({$: "../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047src$047ecs$047column$058recover_selected_rows$($0, $1) {
  for (;;) {
    {
      const _rows_0 = $0;
      const _values_0 = $1;
      if (_rows_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
        return _values_0;
      } else {
        const _id_0 = _rows_0["id"];
        const _owner_0 = _rows_0["owner"];
        const _rest_0 = _rows_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        const _x_1 = {$: "Some", "value": _owner_0};
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _x_1, _values_0);
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058recover_past$1260$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047src$047ecs$047schedule$058execute$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _owners_0 = $1;
      const _world_0 = $2;
      const _namespace_0 = $3;
      const _name_0 = $4;
      const _all_0 = $5;
      const _observations_0 = $6;
      if (_steps_0.$ === "Nil") {
        return {$: "../src/ecs/schedule.Finished", "schedule": {$: "../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "observations": _observations_0};
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../src/ecs/schedule.Phase") {
          const _phase_0 = _t_0["name"];
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _owners_0;
          $2 = _world_0;
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../src/ecs/schedule.Entered", "name": _phase_0}, "tail": {$: "Nil"}}));
          continue;
        } else if (_t_0.$ === "../src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _owners_0;
          $2 = run_loop($$$$047src$047ecs$047world$058barrier$1260$(_world_0));
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../src/ecs/schedule.Applied"}, "tail": {$: "Nil"}}));
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _slot_0 = _t_0["condition"];
          const _rest_2 = _steps_0["tail"];
          return $$$$047src$047ecs$047schedule$058after_condition$1260$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047src$047ecs$047schedule$058execute$1260$(_rest_2, _x_0, _x_1, _namespace_0, _name_0, _all_0, _x_2);
});
});
}), ($$$$047experiments$047public$045nested$045provision$047app$058condition$(_world_0, _slot_0)), _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
        }
      }
    }
  }
}

function $$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047src$047ecs$047commands$058enqueue$1261$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../src/ecs/transaction.Returned", "world": ($$$$047src$047ecs$047commands$058publish$1261$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../src/ecs/transaction.Returned", "world": ($$$$047src$047ecs$047transaction$058rollback$1261$(_undo_0, _world_0)), "outcome": {$: "../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047src$047ecs$047commands$058spawn_apply$1261$(_world_0, _handle_0, _payload_0) {
  return $$$$047src$047ecs$047commands$058spawned$1261$(($$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $$$$047src$047ecs$047column$058restored$1261$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047src$047ecs$047column$058viewed$1261$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047src$047ecs$047column$058restored$1261$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058viewed_return$1261$(_result_0, ($$$$047src$047ecs$047column$058swap$1261$({$: "../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_projected_state$1261$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058viewed_return$1261$(_result_0, ($$$$047src$047ecs$047column$058swap$1261$({$: "../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047src$047ecs$047column$058recover_past$1261$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047src$047ecs$047column$058indexed_view_restored$1261$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047src$047ecs$047schedule$058execute$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _owners_0 = $1;
      const _world_0 = $2;
      const _namespace_0 = $3;
      const _name_0 = $4;
      const _all_0 = $5;
      const _observations_0 = $6;
      if (_steps_0.$ === "Nil") {
        return {$: "../src/ecs/schedule.Finished", "schedule": {$: "../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "observations": _observations_0};
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../src/ecs/schedule.Phase") {
          const _phase_0 = _t_0["name"];
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _owners_0;
          $2 = _world_0;
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../src/ecs/schedule.Entered", "name": _phase_0}, "tail": {$: "Nil"}}));
          continue;
        } else if (_t_0.$ === "../src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _owners_0;
          $2 = run_loop($$$$047src$047ecs$047world$058barrier$1261$(_world_0));
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../src/ecs/schedule.Applied"}, "tail": {$: "Nil"}}));
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _slot_0 = _t_0["condition"];
          const _rest_2 = _steps_0["tail"];
          return $$$$047src$047ecs$047schedule$058after_condition$1261$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047src$047ecs$047schedule$058execute$1261$(_rest_2, _x_0, _x_1, _namespace_0, _name_0, _all_0, _x_2);
});
});
}), ($$$$047experiments$047public$045nested$045provision$047other$058condition$(_world_0, _slot_0)), _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
        }
      }
    }
  }
}

function $$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, _commands_0) {
  return $$$$047src$047ecs$047commands$058enqueue_list$1260$(_commands_0, _world_0);
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047src$047ecs$047commands$058publish$1260$(_world_0, _events_0) {
  return $$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _events_0);
}

function $$$$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047commands$058spawned$1260$(_activated_0, _handle_0, _payload_0) {
  const _world_0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "../src/ecs/world.Accepted") {
    return $$$$047experiments$047public$045nested$045provision$047app$058measured_populate$(_world_0, _handle_0, _payload_0);
  } else {
    return _world_0;
  }
}

function $$$$047src$047ecs$047column$058viewed_return$1260$(_view_0, _result_0) {
  if (_result_0.$ === "../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047src$047ecs$047column$058swapped$1260$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047src$047ecs$047schedule$058after_condition$1260$(_next_0, _checked_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047src$047ecs$047schedule$058conditioned$1260$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $$$$047experiments$047public$045nested$045provision$047app$058condition$(_world_0, _slot_0) {
  return $$$$047experiments$047public$045nested$045provision$047app$058condition_value$(_world_0, _slot_0);
}

function $$$$047src$047ecs$047commands$058enqueue$1261$(_world_0, _commands_0) {
  return $$$$047src$047ecs$047commands$058enqueue_list$1261$(_commands_0, _world_0);
}

function $$$$047src$047ecs$047commands$058publish$1261$(_world_0, _events_0) {
  return $$$$047src$047ecs$047world$058event_publish$1261$(_world_0, _events_0);
}

function $$$$047src$047ecs$047transaction$058rollback$1261$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047commands$058spawned$1261$(_activated_0, _handle_0, _payload_0) {
  const _world_0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "../src/ecs/world.Accepted") {
    return $$$$047experiments$047public$045nested$045provision$047other$058measured_populate$(_world_0, _handle_0, _payload_0);
  } else {
    return _world_0;
  }
}

function $$$$047src$047ecs$047column$058viewed_return$1261$(_view_0, _result_0) {
  if (_result_0.$ === "../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047src$047ecs$047column$058swap$1261$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058indexed_projected_state$1261$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047src$047ecs$047column$058swapped$1261$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058indexed_view_restored$1261$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047src$047ecs$047schedule$058after_condition$1261$(_next_0, _checked_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047src$047ecs$047schedule$058conditioned$1261$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $$$$047experiments$047public$045nested$045provision$047other$058condition$(_world_0, _slot_0) {
  return $$$$047experiments$047public$045nested$045provision$047other$058condition_value$(_world_0, _slot_0);
}

function $$$$047src$047ecs$047commands$058enqueue_list$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058measured_populate$(_world_0, _handle_0, _payload_0) {
  return _world_0;
}

function $$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047src$047ecs$047column$058swapped$1260$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": ($$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047src$047ecs$047schedule$058conditioned$1260$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (!_allowed_0) {
    return run_tail(_next_0(_owners_0)(_world_0), ($List$append$(_observations_0, {$: "Con", "head": {$: "../src/ecs/schedule.Skipped", "id": _id_0}, "tail": {$: "Nil"}})));
  } else {
    return $$$$047src$047ecs$047schedule$058after_dispatch$1260$(_next_0, ($$$$047experiments$047public$045nested$045provision$047app$058dispatch$(_owners_0, _world_0, _id_0)), _namespace_0, _name_0, _all_0, _observations_0, _id_0);
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058condition_value$(_world_0, _slot_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _resource_0 = _t_0["resource"];
  const _host_0 = _t_0["service"];
  const _writes_0 = _t_0["resourceWrites"];
  const _calls_0 = _t_0["hostCalls"];
  const _conditions_0 = _t_0["conditionCalls"];
  const _retired_0 = _t_0["retired"];
  const _trace_0 = _t_0["trace"];
  const _reservedIds_0 = _t_0["reservedIds"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../experiments/public-nested-provision/app.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_0, "hostCalls": _calls_0, "conditionCalls": ((_conditions_0 + 1) >>> 0), "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": (_slot_0 > 0)};
}

function $$$$047src$047ecs$047commands$058enqueue_list$1261$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047world$058event_publish$1261$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058measured_populate$(_world_0, _handle_0, _payload_0) {
  return _world_0;
}

function $$$$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047src$047ecs$047column$058swapped$1261$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": ($$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047src$047ecs$047schedule$058conditioned$1261$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (!_allowed_0) {
    return run_tail(_next_0(_owners_0)(_world_0), ($List$append$(_observations_0, {$: "Con", "head": {$: "../src/ecs/schedule.Skipped", "id": _id_0}, "tail": {$: "Nil"}})));
  } else {
    return $$$$047src$047ecs$047schedule$058after_dispatch$1261$(_next_0, ($$$$047experiments$047public$045nested$045provision$047other$058dispatch$(_owners_0, _world_0, _id_0)), _namespace_0, _name_0, _all_0, _observations_0, _id_0);
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058condition_value$(_world_0, _slot_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _resource_0 = _t_0["resource"];
  const _host_0 = _t_0["service"];
  const _writes_0 = _t_0["resourceWrites"];
  const _calls_0 = _t_0["hostCalls"];
  const _conditions_0 = _t_0["conditionCalls"];
  const _retired_0 = _t_0["retired"];
  const _trace_0 = _t_0["trace"];
  const _reservedIds_0 = _t_0["reservedIds"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../experiments/public-nested-provision/other.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_0, "hostCalls": _calls_0, "conditionCalls": ((_conditions_0 + 1) >>> 0), "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": (_slot_0 > 0)};
}

function $$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058recover$1260$({$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047src$047ecs$047column$058seek$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058recover$1260$({$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047src$047ecs$047column$058indexed_seek$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../src/ecs/column.Accepted", "column": ($$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047src$047ecs$047schedule$058after_dispatch$1260$(_next_0, _result_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _owners_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return $$$$047src$047ecs$047schedule$058after_outcome$1260$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $$$$047experiments$047public$045nested$045provision$047app$058dispatch$(_owners_0, _world_0, _id_0) {
  return $$$$047experiments$047public$045nested$045provision$047app$058dispatch_value$(_owners_0, _world_0, _id_0);
}

function $$$$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058recover$1261$({$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047src$047ecs$047column$058seek$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058recover$1261$({$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047src$047ecs$047column$058indexed_seek$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../src/ecs/column.Accepted", "column": ($$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047src$047ecs$047schedule$058after_dispatch$1261$(_next_0, _result_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _owners_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return $$$$047src$047ecs$047schedule$058after_outcome$1261$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $$$$047experiments$047public$045nested$045provision$047other$058dispatch$(_owners_0, _world_0, _id_0) {
  return $$$$047experiments$047public$045nested$045provision$047other$058dispatch_value$(_owners_0, _world_0, _id_0);
}

function $$$$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047src$047ecs$047column$058recover$1260$(_column_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058recover_state$1260$(($$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_recover_state$1260$(($$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047src$047ecs$047schedule$058after_outcome$1260$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (_outcome_0.$ === "../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../src/ecs/schedule.Failed", "schedule": {$: "../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "error": _error_0, "observations": ($List$append$(_observations_0, {$: "Con", "head": {$: "../src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}}))};
  } else {
    const _world_1 = _outcome_0["world"];
    return run_tail(_next_0(_owners_0)(_world_1), ($List$append$(_observations_0, {$: "Con", "head": {$: "../src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}})));
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058dispatch_value$(_owners_0, _world_0, _id_0) {
  const _a_0 = _owners_0["a"];
  const _b_0 = _owners_0["b"];
  if (_id_0 == 1) {
    return $$$$047experiments$047public$045nested$045provision$047app$058result_a$(($$$$047src$047ecs$047system$058run$1260$(_a_0, _world_0, 1)), _b_0);
  } else if ((_id_0 & 1) == 1) {
    return {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/app.Owners", "a": _a_0, "b": _b_0}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": "unknown"}};
  } else if (_id_0 == 2) {
    return $$$$047experiments$047public$045nested$045provision$047app$058result_b$(($$$$047src$047ecs$047system$058run$1260$(_b_0, _world_0, 2)), _a_0);
  } else {
    return {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/app.Owners", "a": _a_0, "b": _b_0}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": "unknown"}};
  }
}

function $$$$047src$047ecs$047column$058recover$1261$(_column_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058recover_state$1261$(($$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_recover_state$1261$(($$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047src$047ecs$047schedule$058after_outcome$1261$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (_outcome_0.$ === "../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../src/ecs/schedule.Failed", "schedule": {$: "../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "error": _error_0, "observations": ($List$append$(_observations_0, {$: "Con", "head": {$: "../src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}}))};
  } else {
    const _world_1 = _outcome_0["world"];
    return run_tail(_next_0(_owners_0)(_world_1), ($List$append$(_observations_0, {$: "Con", "head": {$: "../src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}})));
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058dispatch_value$(_owners_0, _world_0, _id_0) {
  const _a_0 = _owners_0["a"];
  const _b_0 = _owners_0["b"];
  if (_id_0 == 1) {
    return $$$$047experiments$047public$045nested$045provision$047other$058result_a$(($$$$047src$047ecs$047system$058run$1261$(_a_0, _world_0, 1)), _b_0);
  } else if ((_id_0 & 1) == 1) {
    return {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/other.Owners", "a": _a_0, "b": _b_0}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": "unknown"}};
  } else if (_id_0 == 2) {
    return $$$$047experiments$047public$045nested$045provision$047other$058result_b$(($$$$047src$047ecs$047system$058run$1261$(_b_0, _world_0, 2)), _a_0);
  } else {
    return {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/other.Owners", "a": _a_0, "b": _b_0}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": "unknown"}};
  }
}

function $$$$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047src$047ecs$047column$058indexed_recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047experiments$047public$045nested$045provision$047app$058result_a$(_result_0, _b_0) {
  if (_result_0.$ === "../src/ecs/system.Completed") {
    const _a_0 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/app.Owners", "a": _a_0, "b": _b_0}, "snd": _outcome_0};
  } else {
    const _a_1 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    return {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/app.Owners", "a": _a_1, "b": _b_0}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": "registration"}};
  }
}

function $$$$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, ($$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047experiments$047public$045nested$045provision$047app$058result_b$(_result_0, _a_0) {
  if (_result_0.$ === "../src/ecs/system.Completed") {
    const _b_0 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/app.Owners", "a": _a_0, "b": _b_0}, "snd": _outcome_0};
  } else {
    const _b_1 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    return {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/app.Owners", "a": _a_0, "b": _b_1}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": "registration"}};
  }
}

function $$$$047src$047ecs$047column$058recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047src$047ecs$047column$058indexed_recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047experiments$047public$045nested$045provision$047other$058result_a$(_result_0, _b_0) {
  if (_result_0.$ === "../src/ecs/system.Completed") {
    const _a_0 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/other.Owners", "a": _a_0, "b": _b_0}, "snd": _outcome_0};
  } else {
    const _a_1 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    return {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/other.Owners", "a": _a_1, "b": _b_0}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": "registration"}};
  }
}

function $$$$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047src$047ecs$047system$058run_namespace$1261$(_registry_0, ($$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $$$$047experiments$047public$045nested$045provision$047other$058result_b$(_result_0, _a_0) {
  if (_result_0.$ === "../src/ecs/system.Completed") {
    const _b_0 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/other.Owners", "a": _a_0, "b": _b_0}, "snd": _outcome_0};
  } else {
    const _b_1 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    return {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/other.Owners", "a": _a_0, "b": _b_1}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": "registration"}};
  }
}

function $$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047src$047ecs$047system$058run_namespace$1261$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047src$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047src$047ecs$047system$058run_namespace_checked$1261$((_namespace_0 === _actual_0), {$: "../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047src$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047src$047ecs$047system$058run_metadata$1260$({$: "../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047src$047ecs$047system$058run_namespace_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047src$047ecs$047system$058run_metadata$1261$({$: "../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047src$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047src$047ecs$047system$058run_metadata$1261$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047src$047ecs$047system$058complete$1260$(_registry_0, ($$$$047experiments$047public$045nested$045provision$047app$058runner$(_world_0, _args_0)));
  }
}

function $$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  if (_registrations_0.$ === "Nil") {
    return false;
  } else {
    const _meta_0 = _registrations_0["head"];
    const _rest_0 = _registrations_0["tail"];
    const _x_0 = ($$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
    const _x_1 = ($$$$047src$047ecs$047world$058registration_list_matches$(_rest_0, _id_0, _name_0, _access_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047src$047ecs$047system$058complete$1261$(_registry_0, ($$$$047experiments$047public$045nested$045provision$047other$058runner$(_world_0, _args_0)));
  }
}

function $$$$047src$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047experiments$047public$045nested$045provision$047app$058runner$(_world_0, _id_0) {
  return $$$$047experiments$047public$045nested$045provision$047app$058runner_value$(_world_0, _id_0);
}

function $$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $Bool$and$((_mid_0 === _id_0), ($Bool$and$(($String$eq$(_mname_0, _name_0)), ($$$$047src$047ecs$047world$058access_equal$(_maccess_0, _access_0)))));
}

function $$$$047src$047ecs$047system$058complete$1261$(_registry_0, _outcome_0) {
  return {$: "../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047experiments$047public$045nested$045provision$047other$058runner$(_world_0, _id_0) {
  return $$$$047experiments$047public$045nested$045provision$047other$058runner_value$(_world_0, _id_0);
}

function $$$$047experiments$047public$045nested$045provision$047app$058runner_value$(_world_0, _id_0) {
  return $$$$047experiments$047public$045nested$045provision$047app$058replaced$(($$$$047src$047ecs$047component$058replace$1260$(($$$$047experiments$047public$045nested$045provision$047app$058family$()), _world_0, {$: "../src/ecs/world.Handle", "namespace": 1, "id": 1}, {$: "Some", "value": array_node([_id_0], [99])})), _id_0);
}

function $String$eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(($String$order$(_a_0, _b_0)));
}

function $$$$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($String$eq$(__2, _y_0)), ($$$$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058runner_value$(_world_0, _id_0) {
  return $$$$047experiments$047public$045nested$045provision$047other$058replaced$(($$$$047src$047ecs$047component$058replace$1261$(($$$$047experiments$047public$045nested$045provision$047other$058family$()), _world_0, {$: "../src/ecs/world.Handle", "namespace": 1, "id": 1}, {$: "Some", "value": array_node([_id_0], [99])})), _id_0);
}

function $$$$047experiments$047public$045nested$045provision$047app$058replaced$(_result_0, _id_0) {
  if (_result_0.$ === "../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    const _old_0 = _result_0["previous"];
    return {$: "../src/ecs/system.Succeeded", "world": ($$$$047experiments$047public$045nested$045provision$047app$058effects$(_world_0, _id_0, _old_0)), "output": {$: "Unit"}};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "../src/ecs/system.Failed", "world": _world_1, "error": "component-rejected"};
  }
}

function $$$$047src$047ecs$047component$058replace$1260$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047src$047ecs$047component$058replace_allowed$1260$(($$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $Cmp$is_eq$(_c_0) {
  if (_c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $String$order$(_a_0, _b_0) {
  return $Pair$snd$(($String$cmp$(_a_0, _b_0)));
}

function $$$$047experiments$047public$045nested$045provision$047other$058replaced$(_result_0, _id_0) {
  if (_result_0.$ === "../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    const _old_0 = _result_0["previous"];
    return {$: "../src/ecs/system.Succeeded", "world": ($$$$047experiments$047public$045nested$045provision$047other$058effects$(_world_0, _id_0, _old_0)), "output": {$: "Unit"}};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "../src/ecs/system.Failed", "world": _world_1, "error": "component-rejected"};
  }
}

function $$$$047src$047ecs$047component$058replace$1261$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047src$047ecs$047component$058replace_allowed$1261$(($$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047experiments$047public$045nested$045provision$047app$058effects$(_world_0, _id_0, _old_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _t_0 = _world_0["store"];
  const _column_0 = _t_0["column"];
  const _family_0 = _t_0["family"];
  const _writes_0 = _t_0["writes"];
  const _t_1 = _world_0["resource"];
  const _resource_0 = _t_1["resource"];
  const _host_0 = _t_1["service"];
  const _rwrites_0 = _t_1["resourceWrites"];
  const _calls_0 = _t_1["hostCalls"];
  const _conditions_0 = _t_1["conditionCalls"];
  const _retired_0 = _t_1["retired"];
  const _trace_0 = _t_1["trace"];
  const _reservedIds_0 = _t_1["reservedIds"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  if (_old_0.$ === "Some") {
    const _old_1 = _old_0["value"];
    return $$$$047experiments$047public$045nested$045provision$047app$058complete_side_effects$({$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/app.Store", "column": _column_0, "family": _family_0, "writes": ((_writes_0 + 1) >>> 0)}, "resource": {$: "../experiments/public-nested-provision/app.Resources", "resource": {$: "../experiments/public-nested-provision/app.Missing"}, "service": {$: "../experiments/public-nested-provision/app.Missing"}, "resourceWrites": 0, "hostCalls": 0, "conditionCalls": 0, "retired": {$: "Nil"}, "trace": {$: "Nil"}, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, _id_0, ($$$$047experiments$047public$045nested$045provision$047app$058resource_write$(_resource_0, _rwrites_0, _id_0)), ($$$$047experiments$047public$045nested$045provision$047app$058service$(_host_0, _calls_0)), _conditions_0, {$: "Con", "head": _old_1, "tail": _retired_0}, _trace_0);
  } else {
    return {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/app.Store", "column": _column_0, "family": _family_0, "writes": _writes_0}, "resource": {$: "../experiments/public-nested-provision/app.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _rwrites_0, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
  }
}

function $$$$047src$047ecs$047component$058replace_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047src$047ecs$047component$058replace_clock$1260$(_id_0, _incoming_0, ($$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0) {
  return $$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, ($$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $Pair$snd$(_p_0) {
  const _b_0 = _p_0["snd"];
  return _b_0;
}

function $String$cmp$(_a_0, _b_0) {
  if (_a_0 === "") {
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": ""}, "snd": {$: "EQ"}};
    } else {
      const _h_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": (_h_0 + _t_0)}, "snd": {$: "LT"}};
    }
  } else {
    const _h_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
    const _t_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h_1 + _t_1), "snd": ""}, "snd": {$: "GT"}};
    } else {
      const _h2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return $String$cmp$fin$(_t_1, _t2_0, ($Char$cmp$(_h_1, _h2_0)));
    }
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058effects$(_world_0, _id_0, _old_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _t_0 = _world_0["store"];
  const _column_0 = _t_0["column"];
  const _family_0 = _t_0["family"];
  const _writes_0 = _t_0["writes"];
  const _t_1 = _world_0["resource"];
  const _resource_0 = _t_1["resource"];
  const _host_0 = _t_1["service"];
  const _rwrites_0 = _t_1["resourceWrites"];
  const _calls_0 = _t_1["hostCalls"];
  const _conditions_0 = _t_1["conditionCalls"];
  const _retired_0 = _t_1["retired"];
  const _trace_0 = _t_1["trace"];
  const _reservedIds_0 = _t_1["reservedIds"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  if (_old_0.$ === "Some") {
    const _old_1 = _old_0["value"];
    return $$$$047experiments$047public$045nested$045provision$047other$058complete_side_effects$({$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/other.Store", "column": _column_0, "family": _family_0, "writes": ((_writes_0 + 1) >>> 0)}, "resource": {$: "../experiments/public-nested-provision/other.Resources", "resource": {$: "../experiments/public-nested-provision/other.Missing"}, "service": {$: "../experiments/public-nested-provision/other.Missing"}, "resourceWrites": 0, "hostCalls": 0, "conditionCalls": 0, "retired": {$: "Nil"}, "trace": {$: "Nil"}, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, _id_0, ($$$$047experiments$047public$045nested$045provision$047other$058resource_write$(_resource_0, _rwrites_0, _id_0)), ($$$$047experiments$047public$045nested$045provision$047other$058service$(_host_0, _calls_0)), _conditions_0, {$: "Con", "head": _old_1, "tail": _retired_0}, _trace_0);
  } else {
    return {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": {$: "../experiments/public-nested-provision/other.Store", "column": _column_0, "family": _family_0, "writes": _writes_0}, "resource": {$: "../experiments/public-nested-provision/other.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _rwrites_0, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
  }
}

function $$$$047src$047ecs$047component$058replace_allowed$1261$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047src$047ecs$047component$058replace_clock$1261$(_id_0, _incoming_0, ($$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  }
}

function $$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0) {
  return $$$$047src$047ecs$047world$058valid_join$1261$(_handle_0, ($$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047experiments$047public$045nested$045provision$047app$058complete_side_effects$(_world_0, _id_0, _r_0, _s_0, _conditions_0, _retired_0, _trace_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _reservedIds_0 = _t_0["reservedIds"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _resource_0 = _r_0["fst"];
  const _writes_0 = _r_0["snd"];
  const _host_0 = _s_0["fst"];
  const _calls_0 = _s_0["snd"];
  return $$$$047experiments$047public$045nested$045provision$047app$058measured_spawn$(($$$$047src$047ecs$047world$058event_publish$1260$({$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../experiments/public-nested-provision/app.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_0, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": ($List$append$(_trace_0, {$: "Con", "head": _id_0, "tail": {$: "Nil"}})), "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, {$: "Con", "head": _id_0, "tail": {$: "Nil"}})));
}

function $$$$047experiments$047public$045nested$045provision$047app$058resource_write$(_value_0, _count_0, _id_0) {
  if (_value_0.$ === "../experiments/public-nested-provision/app.Ready") {
    const _owner_0 = _value_0["owner"];
    return $$$$047experiments$047public$045nested$045provision$047app$058resource_mutated$(_owner_0, _count_0, _id_0);
  } else {
    return {$: "Tuple", "fst": _value_0, "snd": _count_0};
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058service$(_value_0, _calls_0) {
  if (_value_0.$ === "../experiments/public-nested-provision/app.Ready") {
    const _owner_0 = _value_0["owner"];
    return {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/app.Ready", "owner": _owner_0}, "snd": ((_calls_0 + 1) >>> 0)};
  } else {
    return {$: "Tuple", "fst": _value_0, "snd": _calls_0};
  }
}

function $$$$047src$047ecs$047component$058replace_clock$1260$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047src$047ecs$047component$058replace_clock_checked$1260$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047src$047ecs$047component$058owner_present$1260$(_incoming_0)));
}

function $$$$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0);
}

function $String$cmp$fin$(_t1_0, _t2_0, _hc_0) {
  const _t_0 = _hc_0["fst"];
  const _h1b_0 = _t_0["fst"];
  const _h2b_0 = _t_0["snd"];
  const _t_1 = _hc_0["snd"];
  if (_t_1.$ === "LT") {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "LT"}};
  } else if (_t_1.$ === "EQ") {
    return $String$cmp$rec$(_h1b_0, _h2b_0, ($String$cmp$(_t1_0, _t2_0)));
  } else {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "GT"}};
  }
}

function $Char$cmp$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _a_0, "snd": _b_0}, "snd": cmp_new(_x_0, _x_1)};
}

function $$$$047experiments$047public$045nested$045provision$047other$058complete_side_effects$(_world_0, _id_0, _r_0, _s_0, _conditions_0, _retired_0, _trace_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _reservedIds_0 = _t_0["reservedIds"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _resource_0 = _r_0["fst"];
  const _writes_0 = _r_0["snd"];
  const _host_0 = _s_0["fst"];
  const _calls_0 = _s_0["snd"];
  return $$$$047experiments$047public$045nested$045provision$047other$058measured_spawn$(($$$$047src$047ecs$047world$058event_publish$1261$({$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../experiments/public-nested-provision/other.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_0, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": ($List$append$(_trace_0, {$: "Con", "head": _id_0, "tail": {$: "Nil"}})), "reservedIds": _reservedIds_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, {$: "Con", "head": _id_0, "tail": {$: "Nil"}})));
}

function $$$$047experiments$047public$045nested$045provision$047other$058resource_write$(_value_0, _count_0, _id_0) {
  if (_value_0.$ === "../experiments/public-nested-provision/other.Ready") {
    const _owner_0 = _value_0["owner"];
    return $$$$047experiments$047public$045nested$045provision$047other$058resource_mutated$(_owner_0, _count_0, _id_0);
  } else {
    return {$: "Tuple", "fst": _value_0, "snd": _count_0};
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058service$(_value_0, _calls_0) {
  if (_value_0.$ === "../experiments/public-nested-provision/other.Ready") {
    const _owner_0 = _value_0["owner"];
    return {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/other.Ready", "owner": _owner_0}, "snd": ((_calls_0 + 1) >>> 0)};
  } else {
    return {$: "Tuple", "fst": _value_0, "snd": _calls_0};
  }
}

function $$$$047src$047ecs$047component$058replace_clock$1261$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047src$047ecs$047component$058replace_clock_checked$1261$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047src$047ecs$047component$058owner_present$1260$(_incoming_0)));
}

function $$$$047src$047ecs$047world$058clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047src$047ecs$047world$058valid_join$1261$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0);
}

function $$$$047experiments$047public$045nested$045provision$047app$058measured_spawn$(_world_0) {
  return $$$$047experiments$047public$045nested$045provision$047app$058measured_reserved$(($$$$047src$047ecs$047commands$058tx_spawn$1260$(($$$$047src$047ecs$047transaction$058begin$1260$(_world_0)), {$: "Unit"})));
}

function $$$$047experiments$047public$045nested$045provision$047app$058resource_mutated$(_owner_0, _count_0, _id_0) {
  return {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/app.Ready", "owner": (_owner_0[0 % _owner_0.length] = _id_0, _owner_0)}, "snd": ((_count_0 + 1) >>> 0)};
}

function $$$$047src$047ecs$047component$058replace_clock_checked$1260$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047src$047ecs$047component$058replace_clock_advanced$1260$(_id_0, _present_0, _incoming_1, ($$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047src$047ecs$047component$058owner_present$1260$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047src$047ecs$047world$058live_join$1260$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $String$cmp$rec$(_h1b_0, _h2b_0, _rr_0) {
  const _t_0 = _rr_0["fst"];
  const _t1b_0 = _t_0["fst"];
  const _t2b_0 = _t_0["snd"];
  const _r_0 = _rr_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1b_0), "snd": (_h2b_0 + _t2b_0)}, "snd": _r_0};
}

function $$$$047experiments$047public$045nested$045provision$047other$058measured_spawn$(_world_0) {
  return $$$$047experiments$047public$045nested$045provision$047other$058measured_reserved$(($$$$047src$047ecs$047commands$058tx_spawn$1261$(($$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), {$: "Unit"})));
}

function $$$$047experiments$047public$045nested$045provision$047other$058resource_mutated$(_owner_0, _count_0, _id_0) {
  return {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/other.Ready", "owner": (_owner_0[0 % _owner_0.length] = _id_0, _owner_0)}, "snd": ((_count_0 + 1) >>> 0)};
}

function $$$$047src$047ecs$047component$058replace_clock_checked$1261$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047src$047ecs$047component$058replace_clock_advanced$1261$(_id_0, _present_0, _incoming_1, ($$$$047src$047ecs$047world$058advance_clock$1261$(_world_0)));
  }
}

function $$$$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047src$047ecs$047world$058live_join$1261$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047experiments$047public$045nested$045provision$047app$058measured_reserved$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _events_0 = _t_0["events"];
  const _t_1 = _result_0["snd"];
  if (_t_1.$ === "../src/ecs/world.Reserved") {
    const _t_2 = _t_1["handle"];
    const _id_0 = _t_2["id"];
    return $$$$047experiments$047public$045nested$045provision$047app$058measured_finished$(($$$$047src$047ecs$047commands$058tx_finish$1260$({$: "../src/ecs/transaction.Tx", "world": ($$$$047experiments$047public$045nested$045provision$047app$058measured_record$(_world_0, _id_0)), "undo": _undo_0, "commands": _commands_0, "events": _events_0}, {$: "../src/ecs/transaction.Success"})));
  } else {
    return $$$$047experiments$047public$045nested$045provision$047app$058measured_finished$(($$$$047src$047ecs$047commands$058tx_finish$1260$({$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, {$: "../src/ecs/transaction.Success"})));
  }
}

function $$$$047src$047ecs$047component$058replace_clock_advanced$1260$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047src$047ecs$047component$058replaced$1260$(($$$$047src$047ecs$047component$058swap_world$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047src$047ecs$047world$058advance_clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $$$$047src$047ecs$047world$058live_join$1260$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047experiments$047public$045nested$045provision$047other$058measured_reserved$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _events_0 = _t_0["events"];
  const _t_1 = _result_0["snd"];
  if (_t_1.$ === "../src/ecs/world.Reserved") {
    const _t_2 = _t_1["handle"];
    const _id_0 = _t_2["id"];
    return $$$$047experiments$047public$045nested$045provision$047other$058measured_finished$(($$$$047src$047ecs$047commands$058tx_finish$1261$({$: "../src/ecs/transaction.Tx", "world": ($$$$047experiments$047public$045nested$045provision$047other$058measured_record$(_world_0, _id_0)), "undo": _undo_0, "commands": _commands_0, "events": _events_0}, {$: "../src/ecs/transaction.Success"})));
  } else {
    return $$$$047experiments$047public$045nested$045provision$047other$058measured_finished$(($$$$047src$047ecs$047commands$058tx_finish$1261$({$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, {$: "../src/ecs/transaction.Success"})));
  }
}

function $$$$047src$047ecs$047component$058replace_clock_advanced$1261$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047src$047ecs$047component$058replaced$1261$(($$$$047src$047ecs$047component$058swap_world$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047src$047ecs$047world$058advance_clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $$$$047src$047ecs$047world$058live_join$1261$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047experiments$047public$045nested$045provision$047app$058measured_finished$(_result_0) {
  const _world_0 = _result_0["world"];
  return _world_0;
}

function $$$$047experiments$047public$045nested$045provision$047app$058measured_record$(_world_0, _id_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _resource_0 = _t_0["resource"];
  const _host_0 = _t_0["service"];
  const _writes_0 = _t_0["resourceWrites"];
  const _calls_0 = _t_0["hostCalls"];
  const _conditions_0 = _t_0["conditionCalls"];
  const _retired_0 = _t_0["retired"];
  const _trace_0 = _t_0["trace"];
  const _reservedIds_0 = _t_0["reservedIds"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../experiments/public-nested-provision/app.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_0, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": ($List$append$(_reservedIds_0, {$: "Con", "head": _id_0, "tail": {$: "Nil"}}))}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047src$047ecs$047component$058replaced$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047src$047ecs$047component$058swap_world$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047world$058with_store_finish$1260$(($$$$047src$047ecs$047component$058swap_store$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($$$$047experiments$047public$045nested$045provision$047app$058take$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047src$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047experiments$047public$045nested$045provision$047other$058measured_finished$(_result_0) {
  const _world_0 = _result_0["world"];
  return _world_0;
}

function $$$$047experiments$047public$045nested$045provision$047other$058measured_record$(_world_0, _id_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _resource_0 = _t_0["resource"];
  const _host_0 = _t_0["service"];
  const _writes_0 = _t_0["resourceWrites"];
  const _calls_0 = _t_0["hostCalls"];
  const _conditions_0 = _t_0["conditionCalls"];
  const _retired_0 = _t_0["retired"];
  const _trace_0 = _t_0["trace"];
  const _reservedIds_0 = _t_0["reservedIds"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../experiments/public-nested-provision/other.Resources", "resource": _resource_0, "service": _host_0, "resourceWrites": _writes_0, "hostCalls": _calls_0, "conditionCalls": _conditions_0, "retired": _retired_0, "trace": _trace_0, "reservedIds": ($List$append$(_reservedIds_0, {$: "Con", "head": _id_0, "tail": {$: "Nil"}}))}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047src$047ecs$047component$058replaced$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047src$047ecs$047component$058swap_world$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047world$058with_store_finish$1261$(($$$$047src$047ecs$047component$058swap_store$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($$$$047experiments$047public$045nested$045provision$047other$058take$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047src$047ecs$047world$058with_store_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047src$047ecs$047component$058swap_store$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047src$047ecs$047column$058swap$1260$(($$$$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047experiments$047public$045nested$045provision$047app$058take$(_store_0) {
  const _column_0 = _store_0["column"];
  const _family_0 = _store_0["family"];
  const _writes_0 = _store_0["writes"];
  return {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/app.Rest", "family": _family_0, "writes": _writes_0}, "snd": _column_0};
}

function $$$$047src$047ecs$047world$058with_store_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047src$047ecs$047component$058swap_store$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047src$047ecs$047column$058swap$1261$(($$$$047src$047ecs$047column$058ensure$1261$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047experiments$047public$045nested$045provision$047other$058take$(_store_0) {
  const _column_0 = _store_0["column"];
  const _family_0 = _store_0["family"];
  const _writes_0 = _store_0["writes"];
  return {$: "Tuple", "fst": {$: "../experiments/public-nested-provision/other.Rest", "family": _family_0, "writes": _writes_0}, "snd": _column_0};
}

function $$$$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047src$047ecs$047component$058mark_swapped$1260$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($$$$047experiments$047public$045nested$045provision$047app$058put$(_rest_0, _column_1)), "snd": {$: "../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047src$047ecs$047column$058ensure$1260$(_column_0, _target_0) {
  return $$$$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047src$047ecs$047component$058mark_swapped$1261$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($$$$047experiments$047public$045nested$045provision$047other$058put$(_rest_0, _column_1)), "snd": {$: "../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047src$047ecs$047column$058ensure$1261$(_column_0, _target_0) {
  return $$$$047src$047ecs$047column$058ensure_checked$1261$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047src$047ecs$047component$058mark_swapped$1260$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047experiments$047public$045nested$045provision$047app$058put$(_rest_0, ($$$$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047experiments$047public$045nested$045provision$047app$058put$(_rest_0, _column_0) {
  const _family_0 = _rest_0["family"];
  const _writes_0 = _rest_0["writes"];
  return {$: "../experiments/public-nested-provision/app.Store", "column": _column_0, "family": _family_0, "writes": _writes_0};
}

function $$$$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047src$047ecs$047column$058ensure_state$1260$(_target_0, ($$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
    }
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
    }
  }
}

function $$$$047src$047ecs$047component$058mark_swapped$1261$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047experiments$047public$045nested$045provision$047other$058put$(_rest_0, ($$$$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047experiments$047public$045nested$045provision$047other$058put$(_rest_0, _column_0) {
  const _family_0 = _rest_0["family"];
  const _writes_0 = _rest_0["writes"];
  return {$: "../experiments/public-nested-provision/other.Store", "column": _column_0, "family": _family_0, "writes": _writes_0};
}

function $$$$047src$047ecs$047column$058ensure_checked$1261$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047src$047ecs$047column$058ensure_state$1261$(_target_0, ($$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
    }
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, ($$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1261$(_target_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
    }
  }
}

function $$$$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047src$047ecs$047column$058grow$1260$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047src$047ecs$047column$058ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047src$047ecs$047column$058grow$1261$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047src$047ecs$047column$058ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_ensure_sized$1261$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047src$047ecs$047lifecycle$058set$(_entries_0, _id_0, _stamp_0) {
  return {$: "Con", "head": {$: "../src/ecs/lifecycle.Entry", "id": _id_0, "stamp": _stamp_0}, "tail": ($$$$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0))};
}

function $$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0) {
  if (!_incoming_0) {
    return {$: "../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    return $$$$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0);
  }
}

function $$$$047src$047ecs$047lifecycle$058get$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047src$047ecs$047lifecycle$058choose$((_key_0 === _id_0), _stamp_0, ($$$$047src$047ecs$047lifecycle$058get$(_rest_0, _id_0)));
  }
}

function $$$$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047src$047ecs$047column$058grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $U32$log2$(_n_0) {
  return $U32$log2$go$(5, _n_0, 0);
}

function $$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, ($$$$047src$047ecs$047column$058recover$1260$(_column_0)));
  }
}

function $$$$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_grow$1260$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047src$047ecs$047column$058grow$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047src$047ecs$047column$058ensure_recovered$1261$(_target_0, ($$$$047src$047ecs$047column$058recover$1261$(_column_0)));
  }
}

function $$$$047src$047ecs$047column$058indexed_ensure_sized$1261$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_grow$1261$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047src$047ecs$047lifecycle$058keep$((_key_0 === _id_0), {$: "../src/ecs/lifecycle.Entry", "id": _key_0, "stamp": _stamp_0}, ($$$$047src$047ecs$047lifecycle$058clear$(_rest_0, _id_0)));
  }
}

function $$$$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0) {
  if (!_wasPresent_0) {
    return {$: "../src/ecs/lifecycle.Stamp", "added": _tick_0, "changed": _tick_0};
  } else {
    const _added_0 = _stamp_0["added"];
    return {$: "../src/ecs/lifecycle.Stamp", "added": _added_0, "changed": _tick_0};
  }
}

function $$$$047src$047ecs$047lifecycle$058choose$(_found_0, _stamp_0, _other_0) {
  if (_found_0) {
    return _stamp_0;
  } else {
    return _other_0;
  }
}

function $$$$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)), (_id_0 <= _capacity_0));
}

function $$$$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058absent$1260$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047src$047ecs$047column$058absent$1260$(_rest_0)), ($$$$047src$047ecs$047column$058absent$1260$(_rest_0)));
  }
}

function $U32$log2$go$($0, $1, $2) {
  for (;;) {
    {
      const _k_0 = $0;
      const _n_0 = $1;
      const _b_0 = $2;
      if (_k_0 === 0) {
        return _b_0;
      } else {
        const _p_0 = (_k_0 - 1);
        const _x_0 = (_p_0 >= 32 ? 0 : (1 << _p_0) >>> 0);
        const _s_0 = _x_0;
        const _x_1 = (_s_0 >= 32 ? 0 : (_n_0 >>> _s_0) >>> 0);
        const _x_2 = ($Bool$to_u32$((_x_1 !== 0)));
        const _t_0 = nat_chk(_s_0 * _x_2);
        $0 = _p_0;
        $1 = (_t_0 >= 32 ? 0 : (_n_0 >>> _t_0) >>> 0);
        $2 = nat_chk(_b_0 + _t_0);
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, _column_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047src$047ecs$047column$058indexed_grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          return $$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058ensure_recovered$1261$(_target_0, _column_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, ($$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047src$047ecs$047column$058indexed_grow$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        } else {
          return $$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047src$047ecs$047lifecycle$058keep$(_equal_0, _entry_0, _rest_0) {
  if (_equal_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _entry_0, "tail": _rest_0};
  }
}

function $$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)));
}

function $$$$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0, _fits_0) {
  if (!_isnormal_0) {
    return {$: "Tuple", "fst": {$: "../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": ($$$$047src$047ecs$047lifecycle$058get$(_exceptional_0, _id_0))};
  } else {
    if (!_fits_0) {
      return {$: "Tuple", "fst": {$: "../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
    } else {
      const _x_0 = ((_id_0 - 1) >>> 0);
      return $$$$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, {$: "Tuple", fst: _added_0, snd: _added_0[_x_0 % _added_0.length]});
    }
  }
}

function $$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0) {
  return $Bool$and$((_id_0 > 0), (_id_0 <= 131072));
}

function $Bool$to_u32$(_b_0) {
  if (!_b_0) {
    return 0;
  } else {
    return 1;
  }
}

function $$$$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0) {
  if (!_isnormal_0) {
    return {$: "../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": ($$$$047src$047ecs$047lifecycle$058set$(_exceptional_0, _id_0, _stamp_0))};
  } else {
    return $$$$047src$047ecs$047indexed$045lifecycle$058write_grow$(17, _id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, (_id_0 <= _capacity_0));
  }
}

function $$$$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _observed_0) {
  const _added_0 = _observed_0["fst"];
  const _first_0 = _observed_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return $$$$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, {$: "Tuple", fst: _changed_0, snd: _changed_0[_x_0 % _changed_0.length]});
}

function $$$$047src$047ecs$047indexed$045lifecycle$058write_grow$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _id_0 = $1;
      const _stamp_0 = $2;
      const _added_0 = $3;
      const _changed_0 = $4;
      const _capacity_0 = $5;
      const _depth_0 = $6;
      const _exceptional_0 = $7;
      const _fits_0 = $8;
      if (_fuel_0 === 0) {
        if (_fits_0) {
          return $$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          return {$: "../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_fits_0) {
          return $$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          const _next_0 = ((_capacity_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _stamp_0;
          $3 = array_node(_added_0, array_new(_depth_0, 0));
          $4 = array_node(_changed_0, array_new(_depth_0, 0));
          $5 = _next_0;
          $6 = nat_chk(_depth_0 + 1);
          $7 = _exceptional_0;
          $8 = (_id_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, _observed_0) {
  const _changed_0 = _observed_0["fst"];
  const _last_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../src/ecs/lifecycle.Stamp", "added": _first_0, "changed": _last_0}};
}

function $$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0) {
  const _first_0 = _stamp_0["added"];
  const _last_0 = _stamp_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = ((_id_0 - 1) >>> 0);
  return {$: "../src/ecs/indexed-lifecycle.Metadata", "added": (_added_0[_x_0 % _added_0.length] = _first_0, _added_0), "changed": (_changed_0[_x_1 % _changed_0.length] = _last_0, _changed_0), "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);