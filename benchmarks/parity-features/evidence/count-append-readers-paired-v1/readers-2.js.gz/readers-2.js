function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// Harness-only UTF-8/FNV-1a32 transport. No timed ECS operations are substituted.
let featureStart = null;
let featureChunks = [];
let featureDigest = 2166136261;
let featureBytes = 0;
function io_feature_begin() {
  if (featureStart !== null) throw Error("nested feature timer");
  featureChunks = [];
  featureDigest = 2166136261;
  featureBytes = 0;
  featureStart = process.hrtime.bigint();
  return {$: "Unit"};
}
function io_feature_capture(text) {
  if (featureStart === null) throw Error("capture outside feature timer");
  const bytes = io_bytes(text + "\n");
  for (const byte of bytes) featureDigest = Math.imul(featureDigest ^ byte, 16777619) >>> 0;
  featureBytes += bytes.length;
  featureChunks.push(bytes);
  return {$: "Unit"};
}
function io_feature_end() {
  if (featureStart === null) throw Error("end without feature timer");
  const elapsedNs = process.hrtime.bigint() - featureStart;
  featureStart = null;
  io_out(2, io_bytes(JSON.stringify({elapsedNs: elapsedNs.toString(), bytes: featureBytes, digest: featureDigest}) + "\n"));
  for (const bytes of featureChunks) io_out(1, bytes);
  featureChunks = [];
  return {$: "Unit"};
}
io_eff("timing.begin", io_feature_begin);
io_eff("timing.capture", io_feature_capture);
io_eff("timing.end", io_feature_end);

})();

for (const k of ["timing.begin","timing.end","timing.capture"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $timing$058begin$(_x_1), run_clo((_x_2) => {
  return $repeat$(2);
}), _x_0);
});
}

function $IO$bind$(_m_0, _f_0, _k_0) {
  return run_tail(_m_0, run_clo((_x_0) => {
  return run_tail(_f_0(_x_0), _k_0);
}));
}

function $timing$058begin$(_k_0) {
  return { $: "$FFI", run: $0eff["timing.begin"].run, need: $0eff["timing.begin"].need, args: [], kont: (_k_0) };
}
function $repeat$(_fuel_0) {
  if (_fuel_0 === 0) {
    return (_x_0) => $timing$058end$(_x_0);
  } else {
    const _rest_0 = (_fuel_0 - 1);
    return run_clo((_x_1) => {
  return $IO$bind$(run_clo((_x_2) => {
  return $IO$bind$(($$$$047experiments$047public$045schedule$045readers$047driver$058main$()), run_clo((_x_3) => {
  return $$$$047experiments$047public$045schedule$045readers$047added$045controls$058main$();
}), _x_2);
}), run_clo((_x_4) => {
  return $repeat$(_rest_0);
}), _x_1);
});
  }
}

function $timing$058end$(_k_0) {
  return { $: "$FFI", run: $0eff["timing.end"].run, need: $0eff["timing.end"].need, args: [], kont: (_k_0) };
}
function $$$$047experiments$047public$045schedule$045readers$047driver$058main$() {
  const _x_0 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058array$(run_loop($$$$047experiments$047public$045schedule$045readers$047driver$058ready$(($$$$047experiments$047public$045schedule$045readers$047driver$058init_created$(($$$$047experiments$047public$045schedule$045readers$047schema$058create$(($$$$047src$047ecs$047world$058factory$())))))))));
  const _x_1 = (_x_0 + "}");
  return (_x_2) => $timing$058capture$(("{\"format\":1,\"checkpoints\":" + _x_1), _x_2);
}

function $$$$047experiments$047public$045schedule$045readers$047added$045controls$058main$() {
  return $$$$047experiments$047public$045schedule$045readers$047added$045controls$058created$(($$$$047experiments$047public$045schedule$045readers$047driver$058init_created$(($$$$047src$047ecs$047world$058create$1260$(($$$$047src$047ecs$047world$058factory$()), {$: "Unit"})))));
}

function $timing$058capture$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["timing.capture"].run, need: $0eff["timing.capture"].need, args: [(_text_0)], kont: (_k_0) };
}
function $$$$047experiments$047public$045schedule$045readers$047consumers$058array$(_xs_0) {
  return $List$show$1260$(_xs_0);
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058ready$(_result_0) {
  if (_result_0.$ === "None") {
    return {$: "Con", "head": "setup-failure", "tail": {$: "Nil"}};
  } else {
    const _host_0 = _result_0["value"];
    return $$$$047experiments$047public$045schedule$045readers$047driver$058scenario$(_host_0);
  }
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058init_created$(_result_0) {
  if (_result_0.$ === "../src/ecs/world.Created") {
    const _world_0 = _result_0["world"];
    return $$$$047experiments$047public$045schedule$045readers$047driver$058init_event_fast$(($$$$047src$047ecs$047event$045runtime$058register$1260$(($$$$047src$047ecs$047event$045runtime$058start$1260$(_world_0, 65536)), "event-fast", {$: "Con", "head": "Ping.read", "tail": {$: "Nil"}})));
  } else {
    return {$: "None"};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058create$(_factory_0) {
  return $$$$047src$047ecs$047world$058create$1260$(_factory_0, {$: "Unit"});
}

function $$$$047src$047ecs$047world$058factory$() {
  return {$: "../src/ecs/world.Factory", "nextNamespace": 1};
}

function $$$$047experiments$047public$045schedule$045readers$047added$045controls$058created$(_host_0) {
  if (_host_0.$ === "Some") {
    const _t_0 = _host_0["value"];
    const _world_0 = _t_0["world"];
    const _base_0 = _t_0["owners"];
    return $$$$047experiments$047public$045schedule$045readers$047added$045controls$058registered$(_base_0, ($$$$047src$047ecs$047system$058register$1263$(_world_0, "change-added", {$: "Con", "head": "Stock.added", "tail": {$: "Con", "head": "Stock.changed", "tail": {$: "Con", "head": "Stock.write", "tail": {$: "Nil"}}}})));
  } else {
    return (_x_0) => $timing$058capture$("added-creation-failed", _x_0);
  }
}

function $$$$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $List$show$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058raw$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058scenario$(_host_0) {
  return $$$$047experiments$047public$045schedule$045readers$047driver$058execute$({$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "seed", "enabled": true, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 4, "value": 0, "count": 0, "second": {$: "None"}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": false, "own": false}, "steps": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 1, "condition": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.Barrier"}, "tail": {$: "Nil"}}}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "register", "enabled": true, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 1, "value": 0, "count": 0, "second": {$: "None"}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": false, "own": false}, "steps": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 4, "condition": 0}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 5, "condition": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 6, "condition": 0}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 7, "condition": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 8, "condition": 0}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 9, "condition": 1}, "tail": {$: "Nil"}}}}}}}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "publish-pending", "enabled": true, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 1, "value": 1, "count": 1, "second": {$: "Some", "value": 2}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": false, "own": false}, "steps": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 1, "condition": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 4, "condition": 0}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 6, "condition": 0}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 8, "condition": 0}, "tail": {$: "Nil"}}}}}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "skip-all", "enabled": false, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 2, "value": 0, "count": 0, "second": {$: "None"}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": false, "own": false}, "steps": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 2, "condition": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 4, "condition": 0}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 6, "condition": 0}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 8, "condition": 0}, "tail": {$: "Nil"}}}}}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "barrier-skipped", "enabled": false, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 1, "value": 0, "count": 0, "second": {$: "None"}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": false, "own": false}, "steps": {$: "Con", "head": {$: "../src/ecs/schedule.Barrier"}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 4, "condition": 0}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 6, "condition": 0}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 8, "condition": 0}, "tail": {$: "Nil"}}}}}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "resume-fast", "enabled": true, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 1, "value": 0, "count": 0, "second": {$: "None"}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": false, "own": false}, "steps": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 4, "condition": 0}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 6, "condition": 0}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 8, "condition": 0}, "tail": {$: "Nil"}}}}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "event-fail", "enabled": true, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 1, "value": 0, "count": 0, "second": {$: "None"}, "fail": false}, "eventFail": true, "changeFail": false, "removalFail": false, "own": false}, "steps": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 5, "condition": 1}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "event-retry", "enabled": true, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 1, "value": 0, "count": 0, "second": {$: "None"}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": false, "own": false}, "steps": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 5, "condition": 1}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "change-fail-own-write", "enabled": true, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 1, "value": 0, "count": 0, "second": {$: "None"}, "fail": false}, "eventFail": false, "changeFail": true, "removalFail": false, "own": true}, "steps": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 7, "condition": 1}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "change-retry-own-write", "enabled": true, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 1, "value": 0, "count": 0, "second": {$: "None"}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": false, "own": true}, "steps": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 7, "condition": 1}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "change-own-write-consumed", "enabled": true, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 1, "value": 0, "count": 0, "second": {$: "None"}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": false, "own": true}, "steps": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 7, "condition": 1}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "churn-pending", "enabled": true, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 3, "value": 0, "count": 0, "second": {$: "None"}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": false, "own": false}, "steps": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 3, "condition": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 8, "condition": 0}, "tail": {$: "Nil"}}}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "churn-visible", "enabled": true, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 1, "value": 0, "count": 0, "second": {$: "None"}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": false, "own": false}, "steps": {$: "Con", "head": {$: "../src/ecs/schedule.Barrier"}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "removal-fail", "enabled": true, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 1, "value": 0, "count": 0, "second": {$: "None"}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": true, "own": false}, "steps": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 9, "condition": 1}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "removal-retry", "enabled": true, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 1, "value": 0, "count": 0, "second": {$: "None"}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": false, "own": false}, "steps": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 9, "condition": 1}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "removal-consumed", "enabled": true, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 1, "value": 0, "count": 0, "second": {$: "None"}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": false, "own": false}, "steps": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 9, "condition": 1}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "earlier-commit", "enabled": true, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 1, "value": 3, "count": 1, "second": {$: "None"}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": false, "own": false}, "steps": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 1, "condition": 1}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "failed-publisher", "enabled": true, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 1, "value": 999, "count": 1, "second": {$: "None"}, "fail": true}, "eventFail": false, "changeFail": false, "removalFail": false, "own": false}, "steps": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 1, "condition": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.Barrier"}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 4, "condition": 0}, "tail": {$: "Nil"}}}}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "earlier-command-survives", "enabled": true, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 1, "value": 0, "count": 0, "second": {$: "None"}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": false, "own": false}, "steps": {$: "Con", "head": {$: "../src/ecs/schedule.Barrier"}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 4, "condition": 0}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 8, "condition": 0}, "tail": {$: "Nil"}}}}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "publisher-retry", "enabled": true, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 1, "value": 4, "count": 1, "second": {$: "None"}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": false, "own": false}, "steps": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 1, "condition": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 5, "condition": 1}, "tail": {$: "Nil"}}}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "lag-batch", "enabled": true, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 1, "value": 7, "count": 65535, "second": {$: "None"}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": false, "own": false}, "steps": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 1, "condition": 1}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "lag-overflow", "enabled": true, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 1, "value": 8, "count": 1, "second": {$: "Some", "value": 9}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": false, "own": false}, "steps": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 1, "condition": 1}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "lag-retention", "enabled": true, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 1, "value": 0, "count": 0, "second": {$: "None"}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": false, "own": false}, "steps": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "lag-readers", "enabled": true, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 1, "value": 0, "count": 0, "second": {$: "None"}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": false, "own": false}, "steps": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 4, "condition": 0}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 5, "condition": 1}, "tail": {$: "Nil"}}}}, "tail": {$: "Con", "head": {$: "../experiments/public-schedule-readers/driver.Step", "label": "after-lag", "enabled": true, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 1, "value": 0, "count": 0, "second": {$: "None"}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": false, "own": false}, "steps": {$: "Nil"}}, "tail": {$: "Nil"}}}}}}}}}}}}}}}}}}}}}}}}}}, _host_0, {$: "Nil"});
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058init_event_fast$(_result_0) {
  if (_result_0.$ === "../src/ecs/event-runtime.Registered") {
    const _runtime_0 = _result_0["runtime"];
    const _reader_0 = _result_0["reader"];
    const _registry_0 = _result_0["registry"];
    return $$$$047experiments$047public$045schedule$045readers$047driver$058init_event_slow$({$: "../experiments/public-schedule-readers/driver.EventOwner", "reader": _reader_0, "registry": _registry_0}, ($$$$047src$047ecs$047event$045runtime$058register$1260$(_runtime_0, "event-slow", {$: "Con", "head": "Ping.read", "tail": {$: "Nil"}})));
  } else {
    return {$: "None"};
  }
}

function $$$$047src$047ecs$047event$045runtime$058register$1260$(_runtime_0, _name_0, _access_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047src$047ecs$047event$045runtime$058registered_result$1260$(($$$$047src$047ecs$047system$058register$1262$(_world_0, _name_0, _access_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $$$$047src$047ecs$047event$045runtime$058start$1260$(_world_0, _capacity_0) {
  return $$$$047src$047ecs$047event$045runtime$058start_named$1260$(_capacity_0, ($$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047added$045controls$058registered$(_base_0, _result_0) {
  if (_result_0.$ === "../src/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _reader_0 = _result_0["registry"];
    return $$$$047experiments$047public$045schedule$045readers$047added$045controls$058first$(($$$$047experiments$047public$045schedule$045readers$047added$045controls$058snapshot$("added-seed", ($$$$047experiments$047public$045schedule$045readers$047added$045controls$058tick$({$: "../experiments/public-schedule-readers/added-controls.Host", "world": _world_0, "owners": {$: "../experiments/public-schedule-readers/added-controls.Owners", "base": _base_0, "reader": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _reader_0}, "own": false}}, true, false, {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 1, "condition": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.Barrier"}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 100, "condition": 0}, "tail": {$: "Nil"}}}})))));
  } else {
    return (_x_0) => $timing$058capture$("added-registration-failed", _x_0);
  }
}

function $$$$047src$047ecs$047system$058register$1263$(_world_0, _name_0, _access_0) {
  return $$$$047src$047ecs$047system$058register_namespace$1263$(($$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../src/ecs/world.CreateRejected", "factory": {$: "../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../src/ecs/world.Created", "factory": {$: "../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($$$$047experiments$047public$045schedule$045readers$047schema$058empty_store$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058raw$(_x_0) {
  return _x_0;
}

function $List$show$go$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058raw$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058execute$(_steps_0, _host_0, _previous_0) {
  if (_steps_0.$ === "Nil") {
    return _previous_0;
  } else {
    const _t_0 = _steps_0["head"];
    const _label_0 = _t_0["label"];
    const _enabled_0 = _t_0["enabled"];
    const _config_0 = _t_0["config"];
    const _plan_0 = _t_0["steps"];
    const _rest_0 = _steps_0["tail"];
    return $$$$047experiments$047public$045schedule$045readers$047driver$058advance$(_previous_0, ($$$$047experiments$047public$045schedule$045readers$047driver$058snapshot$(_label_0, ($$$$047experiments$047public$045schedule$045readers$047driver$058tick$(($$$$047experiments$047public$045schedule$045readers$047driver$058frame$(($$$$047experiments$047public$045schedule$045readers$047driver$058configure$(_host_0, _enabled_0, _config_0)))), _plan_0)))), run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047experiments$047public$045schedule$045readers$047driver$058execute$(_rest_0, _x_0, _x_1);
});
}));
  }
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058init_event_slow$(_fast_0, _result_0) {
  if (_result_0.$ === "../src/ecs/event-runtime.Registered") {
    const _t_0 = _result_0["runtime"];
    const _world_0 = _t_0["world"];
    const _ns_0 = _t_0["namespace"];
    const _batches_0 = _t_0["batches"];
    const _positions_0 = _t_0["positions"];
    const _next_0 = _t_0["nextReader"];
    const _tick_0 = _t_0["tick"];
    const _start_0 = _t_0["frameStart"];
    const _boundary_0 = _t_0["boundary"];
    const _capacity_0 = _t_0["capacity"];
    const _dropped_0 = _t_0["droppedThrough"];
    const _reader_0 = _result_0["reader"];
    const _registry_0 = _result_0["registry"];
    return $$$$047experiments$047public$045schedule$045readers$047driver$058init_operation$({$: "../src/ecs/reader-domains.Events", "namespace": _ns_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _next_0, "tick": _tick_0, "frameStart": _start_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0, "values": {$: "Nil"}}, _fast_0, {$: "../experiments/public-schedule-readers/driver.EventOwner", "reader": _reader_0, "registry": _registry_0}, ($$$$047src$047ecs$047system$058register$1261$(_world_0, "operations", {$: "Con", "head": "Ping.write", "tail": {$: "Con", "head": "Stock.insert", "tail": {$: "Con", "head": "Stock.remove", "tail": {$: "Con", "head": "Aux.remove", "tail": {$: "Con", "head": "despawn", "tail": {$: "Con", "head": "spawn", "tail": {$: "Nil"}}}}}}})));
  } else {
    return {$: "None"};
  }
}

function $$$$047src$047ecs$047event$045runtime$058registered_result$1260$(_result_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_result_0.$ === "../src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "../src/ecs/event-runtime.RegisterFailed", "runtime": {$: "../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return $$$$047src$047ecs$047event$045runtime$058registered_identity$1260$(_world_1, ($$$$047src$047ecs$047system$058identity$1260$(_registry_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047src$047ecs$047system$058register$1262$(_world_0, _name_0, _access_0) {
  return $$$$047src$047ecs$047system$058register_namespace$1262$(($$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047src$047ecs$047event$045runtime$058start_named$1260$(_capacity_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return {$: "../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": {$: "Nil"}, "positions": {$: "Nil"}, "nextReader": 1, "tick": 0, "frameStart": 0, "boundary": 0, "capacity": _capacity_0, "droppedThrough": 0};
}

function $$$$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047experiments$047public$045schedule$045readers$047added$045controls$058first$(_observed_0) {
  const _host_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return $$$$047experiments$047public$045schedule$045readers$047added$045controls$058second$(_text_0, ($$$$047experiments$047public$045schedule$045readers$047added$045controls$058snapshot$("added-skipped-spawn", ($$$$047experiments$047public$045schedule$045readers$047added$045controls$058tick$(_host_0, false, false, {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 1, "condition": 1}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.Barrier"}, "tail": {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 100, "condition": 0}, "tail": {$: "Nil"}}}})))));
}

function $$$$047experiments$047public$045schedule$045readers$047added$045controls$058snapshot$(_label_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _world_0 = _t_0["world"];
  const _t_1 = _t_0["owners"];
  const _base_0 = _t_1["base"];
  const _reader_0 = _t_1["reader"];
  const _own_0 = _t_1["own"];
  const _ok_0 = _observed_0["snd"];
  return $$$$047experiments$047public$045schedule$045readers$047added$045controls$058snapped$(_reader_0, _own_0, ($$$$047experiments$047public$045schedule$045readers$047driver$058snapshot$(_label_0, {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": _base_0}, "snd": _ok_0})));
}

function $$$$047experiments$047public$045schedule$045readers$047added$045controls$058tick$(_host_0, _enabled_0, _own_0, _steps_0) {
  const _world_0 = _host_0["world"];
  const _t_0 = _host_0["owners"];
  const _base_0 = _t_0["base"];
  const _reader_0 = _t_0["reader"];
  return $$$$047experiments$047public$045schedule$045readers$047added$045controls$058prepared$(_reader_0, _own_0, _steps_0, ($$$$047experiments$047public$045schedule$045readers$047driver$058frame$(($$$$047experiments$047public$045schedule$045readers$047driver$058configure$({$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": _base_0}, _enabled_0, {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 4, "value": 0, "count": 0, "second": {$: "None"}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": false, "own": false})))));
}

function $$$$047src$047ecs$047system$058register_namespace$1263$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047src$047ecs$047system$058register_join$1263$(($$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058empty_store$(_unit_0) {
  return {$: "../experiments/public-schedule-readers/schema.Store", "stock": ($$$$047src$047ecs$047column$058empty$1260$()), "recipe": ($$$$047src$047ecs$047column$058empty$1261$()), "queue": ($$$$047src$047ecs$047column$058empty$1262$()), "enabled": ($$$$047src$047ecs$047column$058empty$1263$()), "locked": ($$$$047src$047ecs$047column$058empty$1264$())};
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058advance$(_previous_0, _observed_0, _next_0) {
  const _host_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return run_tail(_next_0(_host_0), ($List$append$(_previous_0, {$: "Con", "head": _value_0, "tail": {$: "Nil"}})));
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058snapshot$(_label_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _world_0 = _t_0["world"];
  const _owners_0 = _t_0["owners"];
  const _ok_0 = _observed_0["snd"];
  return $$$$047experiments$047public$045schedule$045readers$047driver$058snapshot_rows$(_label_0, _ok_0, _owners_0, ($$$$047experiments$047public$045schedule$045readers$047observe$058all$(_world_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058tick$(_host_0, _steps_0) {
  const _world_0 = _host_0["world"];
  const _owners_0 = _host_0["owners"];
  return $$$$047experiments$047public$045schedule$045readers$047driver$058build_named$(_owners_0, _steps_0, ($$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058frame$(_host_0) {
  const _world_0 = _host_0["world"];
  const _t_0 = _host_0["owners"];
  const _t_1 = _t_0["events"];
  if (_t_1.$ === "../experiments/public-schedule-readers/driver.Occupied") {
    const _events_0 = _t_1["owner"];
    const _fast_0 = _t_0["fast"];
    const _slow_0 = _t_0["slow"];
    const _cf_0 = _t_0["changeFast"];
    const _cs_0 = _t_0["changeSlow"];
    const _rf_0 = _t_0["removalFast"];
    const _rs_0 = _t_0["removalSlow"];
    const _op_0 = _t_0["operation"];
    const _config_0 = _t_0["config"];
    const _reads_0 = _t_0["reads"];
    return $$$$047experiments$047public$045schedule$045readers$047driver$058frame_collected$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Empty"}, "fast": _fast_0, "slow": _slow_0, "changeFast": _cf_0, "changeSlow": _cs_0, "removalFast": _rf_0, "removalSlow": _rs_0, "operation": _op_0, "config": _config_0, "reads": _reads_0}, ($$$$047src$047ecs$047reader$045domains$058collect$1260$(_events_0, _world_0)));
  } else {
    const _fast_1 = _t_0["fast"];
    const _slow_1 = _t_0["slow"];
    const _cf_1 = _t_0["changeFast"];
    const _cs_1 = _t_0["changeSlow"];
    const _rf_1 = _t_0["removalFast"];
    const _rs_1 = _t_0["removalSlow"];
    const _op_1 = _t_0["operation"];
    const _config_1 = _t_0["config"];
    const _reads_1 = _t_0["reads"];
    return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": _t_1, "fast": _fast_1, "slow": _slow_1, "changeFast": _cf_1, "changeSlow": _cs_1, "removalFast": _rf_1, "removalSlow": _rs_1, "operation": _op_1, "config": _config_1, "reads": _reads_1}};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058configure$(_host_0, _enabled_0, _config_0) {
  const _world_0 = _host_0["world"];
  const _t_0 = _host_0["owners"];
  const _t_1 = _t_0["events"];
  if (_t_1.$ === "../experiments/public-schedule-readers/driver.Occupied") {
    const _events_0 = _t_1["owner"];
    const _t_2 = _t_0["fast"];
    if (_t_2.$ === "../experiments/public-schedule-readers/driver.Occupied") {
      const _fast_0 = _t_2["owner"];
      const _t_3 = _t_0["slow"];
      if (_t_3.$ === "../experiments/public-schedule-readers/driver.Occupied") {
        const _slow_0 = _t_3["owner"];
        const _t_4 = _t_0["changeFast"];
        if (_t_4.$ === "../experiments/public-schedule-readers/driver.Occupied") {
          const _cf_0 = _t_4["owner"];
          const _t_5 = _t_0["changeSlow"];
          if (_t_5.$ === "../experiments/public-schedule-readers/driver.Occupied") {
            const _cs_0 = _t_5["owner"];
            const _t_6 = _t_0["removalFast"];
            if (_t_6.$ === "../experiments/public-schedule-readers/driver.Occupied") {
              const _rf_0 = _t_6["owner"];
              const _t_7 = _t_0["removalSlow"];
              if (_t_7.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                const _rs_0 = _t_7["owner"];
                const _t_8 = _t_0["operation"];
                if (_t_8.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                  const _op_0 = _t_8["owner"];
                  const _reads_0 = _t_0["reads"];
                  return {$: "../experiments/public-schedule-readers/driver.Host", "world": ($$$$047experiments$047public$045schedule$045readers$047operations$058condition_set$(_world_0, _enabled_0)), "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _op_0}, "config": _config_0, "reads": _reads_0}};
                } else {
                  const __1 = _t_0["config"];
                  const _reads_1 = _t_0["reads"];
                  return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": _t_8, "config": __1, "reads": _reads_1}};
                }
              } else {
                const _41_0 = _t_0["operation"];
                const __2 = _t_0["config"];
                const _reads_2 = _t_0["reads"];
                return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": _t_7, "operation": _41_0, "config": __2, "reads": _reads_2}};
              }
            } else {
              const _40_0 = _t_0["removalSlow"];
              const _41_1 = _t_0["operation"];
              const __3 = _t_0["config"];
              const _reads_3 = _t_0["reads"];
              return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": _t_6, "removalSlow": _40_0, "operation": _41_1, "config": __3, "reads": _reads_3}};
            }
          } else {
            const _39_0 = _t_0["removalFast"];
            const _40_1 = _t_0["removalSlow"];
            const _41_2 = _t_0["operation"];
            const __4 = _t_0["config"];
            const _reads_4 = _t_0["reads"];
            return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": _t_5, "removalFast": _39_0, "removalSlow": _40_1, "operation": _41_2, "config": __4, "reads": _reads_4}};
          }
        } else {
          const _38_0 = _t_0["changeSlow"];
          const _39_1 = _t_0["removalFast"];
          const _40_2 = _t_0["removalSlow"];
          const _41_3 = _t_0["operation"];
          const __5 = _t_0["config"];
          const _reads_5 = _t_0["reads"];
          return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": _t_4, "changeSlow": _38_0, "removalFast": _39_1, "removalSlow": _40_2, "operation": _41_3, "config": __5, "reads": _reads_5}};
        }
      } else {
        const _37_0 = _t_0["changeFast"];
        const _38_1 = _t_0["changeSlow"];
        const _39_2 = _t_0["removalFast"];
        const _40_3 = _t_0["removalSlow"];
        const _41_4 = _t_0["operation"];
        const __6 = _t_0["config"];
        const _reads_6 = _t_0["reads"];
        return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": _t_3, "changeFast": _37_0, "changeSlow": _38_1, "removalFast": _39_2, "removalSlow": _40_3, "operation": _41_4, "config": __6, "reads": _reads_6}};
      }
    } else {
      const _36_0 = _t_0["slow"];
      const _37_1 = _t_0["changeFast"];
      const _38_2 = _t_0["changeSlow"];
      const _39_3 = _t_0["removalFast"];
      const _40_4 = _t_0["removalSlow"];
      const _41_5 = _t_0["operation"];
      const __7 = _t_0["config"];
      const _reads_7 = _t_0["reads"];
      return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": _t_2, "slow": _36_0, "changeFast": _37_1, "changeSlow": _38_2, "removalFast": _39_3, "removalSlow": _40_4, "operation": _41_5, "config": __7, "reads": _reads_7}};
    }
  } else {
    const _35_0 = _t_0["fast"];
    const _36_1 = _t_0["slow"];
    const _37_2 = _t_0["changeFast"];
    const _38_3 = _t_0["changeSlow"];
    const _39_4 = _t_0["removalFast"];
    const _40_5 = _t_0["removalSlow"];
    const _41_6 = _t_0["operation"];
    const __8 = _t_0["config"];
    const _reads_8 = _t_0["reads"];
    return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": _t_1, "fast": _35_0, "slow": _36_1, "changeFast": _37_2, "changeSlow": _38_3, "removalFast": _39_4, "removalSlow": _40_5, "operation": _41_6, "config": __8, "reads": _reads_8}};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058init_operation$(_runtime_0, _fast_0, _slow_0, _result_0) {
  if (_result_0.$ === "../src/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _op_0 = _result_0["registry"];
    return $$$$047experiments$047public$045schedule$045readers$047driver$058init_change_fast$(_runtime_0, _fast_0, _slow_0, _op_0, ($$$$047src$047ecs$047system$058register$1260$(_world_0, "change-fast", {$: "Con", "head": "Stock.write", "tail": {$: "Con", "head": "Stock.changed", "tail": {$: "Nil"}}})));
  } else {
    return {$: "None"};
  }
}

function $$$$047src$047ecs$047system$058register$1261$(_world_0, _name_0, _access_0) {
  return $$$$047src$047ecs$047system$058register_namespace$1261$(($$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047src$047ecs$047event$045runtime$058registered_identity$1260$(_world_0, _identity_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _registry_0 = _identity_0["fst"];
  const _registryId_0 = _identity_0["snd"];
  return {$: "../src/ecs/event-runtime.Registered", "runtime": {$: "../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": ((_nextReader_0 + 1) >>> 0), "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "reader": {$: "../src/ecs/event-runtime.Reader", "namespace": _namespace_0, "id": _nextReader_0, "registryId": _registryId_0}, "registry": _registry_0};
}

function $$$$047src$047ecs$047system$058identity$1260$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _id_0};
}

function $$$$047src$047ecs$047system$058register_namespace$1262$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047src$047ecs$047system$058register_join$1262$(($$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047experiments$047public$045schedule$045readers$047added$045controls$058second$(_first_0, _observed_0) {
  const _host_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return $$$$047experiments$047public$045schedule$045readers$047added$045controls$058third$({$: "Con", "head": _first_0, "tail": {$: "Con", "head": _text_0, "tail": {$: "Nil"}}}, ($$$$047experiments$047public$045schedule$045readers$047added$045controls$058snapshot$("added-resume-own-write", ($$$$047experiments$047public$045schedule$045readers$047added$045controls$058tick$(_host_0, true, true, {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 100, "condition": 0}, "tail": {$: "Nil"}})))));
}

function $$$$047experiments$047public$045schedule$045readers$047added$045controls$058snapped$(_reader_0, _own_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _world_0 = _t_0["world"];
  const _base_0 = _t_0["owners"];
  const _text_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/added-controls.Host", "world": _world_0, "owners": {$: "../experiments/public-schedule-readers/added-controls.Owners", "base": _base_0, "reader": _reader_0, "own": _own_0}}, "snd": _text_0};
}

function $$$$047experiments$047public$045schedule$045readers$047added$045controls$058prepared$(_reader_0, _own_0, _steps_0, _host_0) {
  const _world_0 = _host_0["world"];
  const _base_0 = _host_0["owners"];
  return $$$$047experiments$047public$045schedule$045readers$047added$045controls$058built$(_world_0, ($$$$047src$047ecs$047schedule$058build$1261$(1, "added", _steps_0, {$: "Con", "head": 1, "tail": {$: "Con", "head": 100, "tail": {$: "Nil"}}}, {$: "../experiments/public-schedule-readers/added-controls.Owners", "base": _base_0, "reader": _reader_0, "own": _own_0})));
}

function $$$$047src$047ecs$047system$058register_join$1263$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047src$047ecs$047system$058register_meta$1263$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047src$047ecs$047column$058empty$1260$() {
  return {$: "../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $$$$047src$047ecs$047column$058empty$1261$() {
  return {$: "../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $$$$047src$047ecs$047column$058empty$1262$() {
  return {$: "../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $$$$047src$047ecs$047column$058empty$1263$() {
  return {$: "../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $$$$047src$047ecs$047column$058empty$1264$() {
  return {$: "../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058snapshot_rows$(_label_0, _ok_0, _owners_0, _observed_0) {
  const _t_0 = _owners_0["events"];
  if (_t_0.$ === "../experiments/public-schedule-readers/driver.Occupied") {
    const _events_0 = _t_0["owner"];
    const _t_1 = _owners_0["fast"];
    if (_t_1.$ === "../experiments/public-schedule-readers/driver.Occupied") {
      const _fast_0 = _t_1["owner"];
      const _t_2 = _owners_0["slow"];
      if (_t_2.$ === "../experiments/public-schedule-readers/driver.Occupied") {
        const _slow_0 = _t_2["owner"];
        const _t_3 = _owners_0["changeFast"];
        if (_t_3.$ === "../experiments/public-schedule-readers/driver.Occupied") {
          const _cf_0 = _t_3["owner"];
          const _t_4 = _owners_0["changeSlow"];
          if (_t_4.$ === "../experiments/public-schedule-readers/driver.Occupied") {
            const _cs_0 = _t_4["owner"];
            const _t_5 = _owners_0["removalFast"];
            if (_t_5.$ === "../experiments/public-schedule-readers/driver.Occupied") {
              const _rf_0 = _t_5["owner"];
              const _t_6 = _owners_0["removalSlow"];
              if (_t_6.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                const _rs_0 = _t_6["owner"];
                const _t_7 = _owners_0["operation"];
                if (_t_7.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                  const _op_0 = _t_7["owner"];
                  const _config_0 = _owners_0["config"];
                  const _reads_0 = _owners_0["reads"];
                  const _world_0 = _observed_0["fst"];
                  const _rows_0 = _observed_0["snd"];
                  return $$$$047experiments$047public$045schedule$045readers$047driver$058snapshot_events$(_label_0, _ok_0, {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Empty"}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _op_0}, "config": _config_0, "reads": _reads_0}, _rows_0, ($$$$047experiments$047public$045schedule$045readers$047observe$058event_observation$(_events_0)), _world_0);
                } else {
                  const _config_1 = _owners_0["config"];
                  const _reads_1 = _owners_0["reads"];
                  const _world_1 = _observed_0["fst"];
                  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_1, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": _t_7, "config": _config_1, "reads": _reads_1}}, "snd": "{\"invalidSlot\":true}"};
                }
              } else {
                const _48_0 = _owners_0["operation"];
                const _config_2 = _owners_0["config"];
                const _reads_2 = _owners_0["reads"];
                const _world_2 = _observed_0["fst"];
                return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_2, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": _t_6, "operation": _48_0, "config": _config_2, "reads": _reads_2}}, "snd": "{\"invalidSlot\":true}"};
              }
            } else {
              const _47_0 = _owners_0["removalSlow"];
              const _48_1 = _owners_0["operation"];
              const _config_3 = _owners_0["config"];
              const _reads_3 = _owners_0["reads"];
              const _world_3 = _observed_0["fst"];
              return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_3, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": _t_5, "removalSlow": _47_0, "operation": _48_1, "config": _config_3, "reads": _reads_3}}, "snd": "{\"invalidSlot\":true}"};
            }
          } else {
            const _46_0 = _owners_0["removalFast"];
            const _47_1 = _owners_0["removalSlow"];
            const _48_2 = _owners_0["operation"];
            const _config_4 = _owners_0["config"];
            const _reads_4 = _owners_0["reads"];
            const _world_4 = _observed_0["fst"];
            return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_4, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": _t_4, "removalFast": _46_0, "removalSlow": _47_1, "operation": _48_2, "config": _config_4, "reads": _reads_4}}, "snd": "{\"invalidSlot\":true}"};
          }
        } else {
          const _45_0 = _owners_0["changeSlow"];
          const _46_1 = _owners_0["removalFast"];
          const _47_2 = _owners_0["removalSlow"];
          const _48_3 = _owners_0["operation"];
          const _config_5 = _owners_0["config"];
          const _reads_5 = _owners_0["reads"];
          const _world_5 = _observed_0["fst"];
          return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_5, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": _t_3, "changeSlow": _45_0, "removalFast": _46_1, "removalSlow": _47_2, "operation": _48_3, "config": _config_5, "reads": _reads_5}}, "snd": "{\"invalidSlot\":true}"};
        }
      } else {
        const _44_0 = _owners_0["changeFast"];
        const _45_1 = _owners_0["changeSlow"];
        const _46_2 = _owners_0["removalFast"];
        const _47_3 = _owners_0["removalSlow"];
        const _48_4 = _owners_0["operation"];
        const _config_6 = _owners_0["config"];
        const _reads_6 = _owners_0["reads"];
        const _world_6 = _observed_0["fst"];
        return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_6, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": _t_2, "changeFast": _44_0, "changeSlow": _45_1, "removalFast": _46_2, "removalSlow": _47_3, "operation": _48_4, "config": _config_6, "reads": _reads_6}}, "snd": "{\"invalidSlot\":true}"};
      }
    } else {
      const _43_0 = _owners_0["slow"];
      const _44_1 = _owners_0["changeFast"];
      const _45_2 = _owners_0["changeSlow"];
      const _46_3 = _owners_0["removalFast"];
      const _47_4 = _owners_0["removalSlow"];
      const _48_5 = _owners_0["operation"];
      const _config_7 = _owners_0["config"];
      const _reads_7 = _owners_0["reads"];
      const _world_7 = _observed_0["fst"];
      return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_7, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": _t_1, "slow": _43_0, "changeFast": _44_1, "changeSlow": _45_2, "removalFast": _46_3, "removalSlow": _47_4, "operation": _48_5, "config": _config_7, "reads": _reads_7}}, "snd": "{\"invalidSlot\":true}"};
    }
  } else {
    const _42_0 = _owners_0["fast"];
    const _43_1 = _owners_0["slow"];
    const _44_2 = _owners_0["changeFast"];
    const _45_3 = _owners_0["changeSlow"];
    const _46_4 = _owners_0["removalFast"];
    const _47_5 = _owners_0["removalSlow"];
    const _48_6 = _owners_0["operation"];
    const _config_8 = _owners_0["config"];
    const _reads_8 = _owners_0["reads"];
    const _world_8 = _observed_0["fst"];
    return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_8, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": _t_0, "fast": _42_0, "slow": _43_1, "changeFast": _44_2, "changeSlow": _45_3, "removalFast": _46_4, "removalSlow": _47_5, "operation": _48_6, "config": _config_8, "reads": _reads_8}}, "snd": "{\"invalidSlot\":true}"};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047observe$058all$(_world_0) {
  return $$$$047experiments$047public$045schedule$045readers$047observe$058all_handles$(($$$$047src$047ecs$047world$058handles$1260$(_world_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058build_named$(_owners_0, _steps_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047experiments$047public$045schedule$045readers$047driver$058built$(_world_0, ($$$$047src$047ecs$047schedule$058build$1260$(_namespace_0, "reader-tick", _steps_0, {$: "Con", "head": 1, "tail": {$: "Con", "head": 2, "tail": {$: "Con", "head": 3, "tail": {$: "Con", "head": 4, "tail": {$: "Con", "head": 5, "tail": {$: "Con", "head": 6, "tail": {$: "Con", "head": 7, "tail": {$: "Con", "head": 8, "tail": {$: "Con", "head": 9, "tail": {$: "Nil"}}}}}}}}}}, _owners_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058frame_collected$(_owners_0, _result_0) {
  const _fast_0 = _owners_0["fast"];
  const _slow_0 = _owners_0["slow"];
  const _cf_0 = _owners_0["changeFast"];
  const _cs_0 = _owners_0["changeSlow"];
  const _rf_0 = _owners_0["removalFast"];
  const _rs_0 = _owners_0["removalSlow"];
  const _op_0 = _owners_0["operation"];
  const _config_0 = _owners_0["config"];
  const _reads_0 = _owners_0["reads"];
  const _world_0 = _result_0["world"];
  const _events_0 = _result_0["events"];
  return $$$$047experiments$047public$045schedule$045readers$047driver$058frame_observed$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": _fast_0, "slow": _slow_0, "changeFast": _cf_0, "changeSlow": _cs_0, "removalFast": _rf_0, "removalSlow": _rs_0, "operation": _op_0, "config": _config_0, "reads": _reads_0}, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
}

function $$$$047src$047ecs$047reader$045domains$058collect$1260$(_events_0, _world_0) {
  return $$$$047src$047ecs$047reader$045domains$058collect_view$1260$(_events_0, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047operations$058condition_set$(_world_0, _enabled_0) {
  return $$$$047experiments$047public$045schedule$045readers$047operations$058condition_set_named$(_enabled_0, ($$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058init_change_fast$(_runtime_0, _fast_0, _slow_0, _op_0, _result_0) {
  if (_result_0.$ === "../src/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _cf_0 = _result_0["registry"];
    return $$$$047experiments$047public$045schedule$045readers$047driver$058init_change_slow$(_runtime_0, _fast_0, _slow_0, _cf_0, _op_0, ($$$$047src$047ecs$047system$058register$1260$(_world_0, "change-slow", {$: "Con", "head": "Stock.write", "tail": {$: "Con", "head": "Stock.changed", "tail": {$: "Nil"}}})));
  } else {
    return {$: "None"};
  }
}

function $$$$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0) {
  return $$$$047src$047ecs$047system$058register_namespace$1260$(($$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047src$047ecs$047system$058register_namespace$1261$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047src$047ecs$047system$058register_join$1261$(($$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047src$047ecs$047system$058register_join$1262$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047src$047ecs$047system$058register_meta$1262$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047experiments$047public$045schedule$045readers$047added$045controls$058third$(_log_0, _observed_0) {
  const _host_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return $$$$047experiments$047public$045schedule$045readers$047added$045controls$058fourth$(($List$append$(_log_0, {$: "Con", "head": _text_0, "tail": {$: "Nil"}})), ($$$$047experiments$047public$045schedule$045readers$047added$045controls$058snapshot$("added-own-write-consumed", ($$$$047experiments$047public$045schedule$045readers$047added$045controls$058tick$(_host_0, true, true, {$: "Con", "head": {$: "../src/ecs/schedule.System", "id": 100, "condition": 0}, "tail": {$: "Nil"}})))));
}

function $$$$047experiments$047public$045schedule$045readers$047added$045controls$058built$(_world_0, _build_0) {
  if (_build_0.$ === "../src/ecs/schedule.Built") {
    const _schedule_0 = _build_0["schedule"];
    return $$$$047experiments$047public$045schedule$045readers$047added$045controls$058result$(run_loop($$$$047src$047ecs$047schedule$058run_with_skip$1261$(_schedule_0, _world_0)));
  } else {
    const _owners_0 = _build_0["owners"];
    return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/added-controls.Host", "world": _world_0, "owners": _owners_0}, "snd": false};
  }
}

function $$$$047src$047ecs$047schedule$058build$1261$(_namespace_0, _name_0, _steps_0, _catalog_0, _owners_0) {
  return $$$$047src$047ecs$047schedule$058build_checked$1261$(($$$$047src$047ecs$047schedule$058valid$(_steps_0, _catalog_0, {$: "Nil"})), _namespace_0, _name_0, _steps_0, _owners_0);
}

function $$$$047src$047ecs$047system$058register_meta$1263$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../src/ecs/world.RegistrationRejected") {
    return {$: "../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../src/ecs/world.RegistrationRejected", "error": {$: "../src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058snapshot_events$(_label_0, _ok_0, _owners_0, _rows_0, _observed_0, _world_0) {
  const __0 = _owners_0["events"];
  const _t_0 = _owners_0["fast"];
  if (_t_0.$ === "../experiments/public-schedule-readers/driver.Occupied") {
    const _fast_0 = _t_0["owner"];
    const _t_1 = _owners_0["slow"];
    if (_t_1.$ === "../experiments/public-schedule-readers/driver.Occupied") {
      const _slow_0 = _t_1["owner"];
      const _t_2 = _owners_0["changeFast"];
      if (_t_2.$ === "../experiments/public-schedule-readers/driver.Occupied") {
        const _cf_0 = _t_2["owner"];
        const _t_3 = _owners_0["changeSlow"];
        if (_t_3.$ === "../experiments/public-schedule-readers/driver.Occupied") {
          const _cs_0 = _t_3["owner"];
          const _t_4 = _owners_0["removalFast"];
          if (_t_4.$ === "../experiments/public-schedule-readers/driver.Occupied") {
            const _rf_0 = _t_4["owner"];
            const _t_5 = _owners_0["removalSlow"];
            if (_t_5.$ === "../experiments/public-schedule-readers/driver.Occupied") {
              const _rs_0 = _t_5["owner"];
              const _t_6 = _owners_0["operation"];
              if (_t_6.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                const _op_0 = _t_6["owner"];
                const _config_0 = _owners_0["config"];
                const _reads_0 = _owners_0["reads"];
                const _events_0 = _observed_0["fst"];
                const _t_7 = _observed_0["snd"];
                const _values_0 = _t_7["fst"];
                const _statuses_0 = _t_7["snd"];
                const _x_0 = (_statuses_0 + "}");
                const _x_1 = (",\"readers\":" + _x_0);
                const _x_2 = (_values_0 + _x_1);
                const _x_3 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058array$(_rows_0));
                const _x_4 = (",\"events\":" + _x_2);
                const _x_5 = (_x_3 + _x_4);
                const _x_6 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058array$(_reads_0));
                const _x_7 = (",\"entities\":" + _x_5);
                const _x_8 = (_x_6 + _x_7);
                const _x_9 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058boolean$(_ok_0));
                const _x_10 = (",\"reads\":" + _x_8);
                const _x_11 = (_x_9 + _x_10);
                const _x_12 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058quoted$(_label_0));
                const _x_13 = (",\"ok\":" + _x_11);
                const _x_14 = (_x_12 + _x_13);
                return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _op_0}, "config": _config_0, "reads": _reads_0}}, "snd": ("{\"label\":" + _x_14)};
              } else {
                const _config_1 = _owners_0["config"];
                const _reads_1 = _owners_0["reads"];
                return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": _t_6, "config": _config_1, "reads": _reads_1}}, "snd": "{\"invalidSlot\":true}"};
              }
            } else {
              const _50_0 = _owners_0["operation"];
              const _config_2 = _owners_0["config"];
              const _reads_2 = _owners_0["reads"];
              return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": _t_5, "operation": _50_0, "config": _config_2, "reads": _reads_2}}, "snd": "{\"invalidSlot\":true}"};
            }
          } else {
            const _49_0 = _owners_0["removalSlow"];
            const _50_1 = _owners_0["operation"];
            const _config_3 = _owners_0["config"];
            const _reads_3 = _owners_0["reads"];
            return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": _t_4, "removalSlow": _49_0, "operation": _50_1, "config": _config_3, "reads": _reads_3}}, "snd": "{\"invalidSlot\":true}"};
          }
        } else {
          const _48_0 = _owners_0["removalFast"];
          const _49_1 = _owners_0["removalSlow"];
          const _50_2 = _owners_0["operation"];
          const _config_4 = _owners_0["config"];
          const _reads_4 = _owners_0["reads"];
          return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": _t_3, "removalFast": _48_0, "removalSlow": _49_1, "operation": _50_2, "config": _config_4, "reads": _reads_4}}, "snd": "{\"invalidSlot\":true}"};
        }
      } else {
        const _47_0 = _owners_0["changeSlow"];
        const _48_1 = _owners_0["removalFast"];
        const _49_2 = _owners_0["removalSlow"];
        const _50_3 = _owners_0["operation"];
        const _config_5 = _owners_0["config"];
        const _reads_5 = _owners_0["reads"];
        return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": _t_2, "changeSlow": _47_0, "removalFast": _48_1, "removalSlow": _49_2, "operation": _50_3, "config": _config_5, "reads": _reads_5}}, "snd": "{\"invalidSlot\":true}"};
      }
    } else {
      const _46_0 = _owners_0["changeFast"];
      const _47_1 = _owners_0["changeSlow"];
      const _48_2 = _owners_0["removalFast"];
      const _49_3 = _owners_0["removalSlow"];
      const _50_4 = _owners_0["operation"];
      const _config_6 = _owners_0["config"];
      const _reads_6 = _owners_0["reads"];
      return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": _t_1, "changeFast": _46_0, "changeSlow": _47_1, "removalFast": _48_2, "removalSlow": _49_3, "operation": _50_4, "config": _config_6, "reads": _reads_6}}, "snd": "{\"invalidSlot\":true}"};
    }
  } else {
    const _45_0 = _owners_0["slow"];
    const _46_1 = _owners_0["changeFast"];
    const _47_2 = _owners_0["changeSlow"];
    const _48_3 = _owners_0["removalFast"];
    const _49_4 = _owners_0["removalSlow"];
    const _50_5 = _owners_0["operation"];
    const _config_7 = _owners_0["config"];
    const _reads_7 = _owners_0["reads"];
    return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": _t_0, "slow": _45_0, "changeFast": _46_1, "changeSlow": _47_2, "removalFast": _48_3, "removalSlow": _49_4, "operation": _50_5, "config": _config_7, "reads": _reads_7}}, "snd": "{\"invalidSlot\":true}"};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047observe$058event_observation$(_events_0) {
  const _ns_0 = _events_0["namespace"];
  const _batches_0 = _events_0["batches"];
  const _positions_0 = _events_0["positions"];
  const _next_0 = _events_0["nextReader"];
  const _tick_0 = _events_0["tick"];
  const _start_0 = _events_0["frameStart"];
  const _boundary_0 = _events_0["boundary"];
  const _capacity_0 = _events_0["capacity"];
  const _dropped_0 = _events_0["dropped"];
  const _values_0 = _events_0["values"];
  return {$: "Tuple", "fst": {$: "../src/ecs/reader-domains.Events", "namespace": _ns_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _next_0, "tick": _tick_0, "frameStart": _start_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0, "values": _values_0}, "snd": {$: "Tuple", "fst": ($$$$047experiments$047public$045schedule$045readers$047consumers$058numbers$(($$$$047experiments$047public$045schedule$045readers$047consumers$058ping_values$(_values_0)))), "snd": ($$$$047experiments$047public$045schedule$045readers$047consumers$058array$(($$$$047experiments$047public$045schedule$045readers$047observe$058statuses$(($$$$047src$047ecs$047event$045runtime$058reader_statuses$1260$(($List$reverse$(_positions_0)), _batches_0, _dropped_0))))))}};
}

function $$$$047experiments$047public$045schedule$045readers$047observe$058all_handles$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _handles_0 = _observed_0["snd"];
  return $$$$047experiments$047public$045schedule$045readers$047observe$058rows$(_handles_0, {$: "Tuple", "fst": _world_0, "snd": {$: "Nil"}});
}

function $$$$047src$047ecs$047world$058handles$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047world$058handles_finish$1260$(($$$$047src$047ecs$047world$058collect_live$1260$(_highWater_0, _namespace_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058built$(_world_0, _result_0) {
  if (_result_0.$ === "../src/ecs/schedule.Built") {
    const _schedule_0 = _result_0["schedule"];
    return $$$$047experiments$047public$045schedule$045readers$047driver$058run_result$(run_loop($$$$047src$047ecs$047schedule$058run_with_skip$1260$(_schedule_0, _world_0)));
  } else {
    const _owners_0 = _result_0["owners"];
    return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": _owners_0}, "snd": false};
  }
}

function $$$$047src$047ecs$047schedule$058build$1260$(_namespace_0, _name_0, _steps_0, _catalog_0, _owners_0) {
  return $$$$047src$047ecs$047schedule$058build_checked$1260$(($$$$047src$047ecs$047schedule$058valid$(_steps_0, _catalog_0, {$: "Nil"})), _namespace_0, _name_0, _steps_0, _owners_0);
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058frame_observed$(_owners_0, _observed_0) {
  const _t_0 = _owners_0["events"];
  if (_t_0.$ === "../experiments/public-schedule-readers/driver.Occupied") {
    const _events_0 = _t_0["owner"];
    const _t_1 = _owners_0["fast"];
    if (_t_1.$ === "../experiments/public-schedule-readers/driver.Occupied") {
      const _fast_0 = _t_1["owner"];
      const _t_2 = _owners_0["slow"];
      if (_t_2.$ === "../experiments/public-schedule-readers/driver.Occupied") {
        const _slow_0 = _t_2["owner"];
        const _t_3 = _owners_0["changeFast"];
        if (_t_3.$ === "../experiments/public-schedule-readers/driver.Occupied") {
          const _cf_0 = _t_3["owner"];
          const _t_4 = _owners_0["changeSlow"];
          if (_t_4.$ === "../experiments/public-schedule-readers/driver.Occupied") {
            const _cs_0 = _t_4["owner"];
            const _t_5 = _owners_0["removalFast"];
            if (_t_5.$ === "../experiments/public-schedule-readers/driver.Occupied") {
              const _rf_0 = _t_5["owner"];
              const _t_6 = _owners_0["removalSlow"];
              if (_t_6.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                const _rs_0 = _t_6["owner"];
                const _t_7 = _owners_0["operation"];
                if (_t_7.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                  const _op_0 = _t_7["owner"];
                  const _config_0 = _owners_0["config"];
                  const _reads_0 = _owners_0["reads"];
                  const _world_0 = _observed_0["fst"];
                  const _removals_0 = _observed_0["snd"];
                  return $$$$047experiments$047public$045schedule$045readers$047driver$058framed$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Empty"}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _op_0}, "config": _config_0, "reads": _reads_0}, ($$$$047src$047ecs$047reader$045domains$058detach$1260$(($$$$047src$047ecs$047event$045runtime$058frame$1260$(($$$$047src$047ecs$047reader$045domains$058attach$1260$(_events_0, _world_0)))), _removals_0)));
                } else {
                  const _config_1 = _owners_0["config"];
                  const _reads_1 = _owners_0["reads"];
                  const _world_1 = _observed_0["fst"];
                  return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_1, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": _t_7, "config": _config_1, "reads": _reads_1}};
                }
              } else {
                const _45_0 = _owners_0["operation"];
                const _config_2 = _owners_0["config"];
                const _reads_2 = _owners_0["reads"];
                const _world_2 = _observed_0["fst"];
                return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_2, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": _t_6, "operation": _45_0, "config": _config_2, "reads": _reads_2}};
              }
            } else {
              const _44_0 = _owners_0["removalSlow"];
              const _45_1 = _owners_0["operation"];
              const _config_3 = _owners_0["config"];
              const _reads_3 = _owners_0["reads"];
              const _world_3 = _observed_0["fst"];
              return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_3, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": _t_5, "removalSlow": _44_0, "operation": _45_1, "config": _config_3, "reads": _reads_3}};
            }
          } else {
            const _43_0 = _owners_0["removalFast"];
            const _44_1 = _owners_0["removalSlow"];
            const _45_2 = _owners_0["operation"];
            const _config_4 = _owners_0["config"];
            const _reads_4 = _owners_0["reads"];
            const _world_4 = _observed_0["fst"];
            return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_4, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": _t_4, "removalFast": _43_0, "removalSlow": _44_1, "operation": _45_2, "config": _config_4, "reads": _reads_4}};
          }
        } else {
          const _42_0 = _owners_0["changeSlow"];
          const _43_1 = _owners_0["removalFast"];
          const _44_2 = _owners_0["removalSlow"];
          const _45_3 = _owners_0["operation"];
          const _config_5 = _owners_0["config"];
          const _reads_5 = _owners_0["reads"];
          const _world_5 = _observed_0["fst"];
          return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_5, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": _t_3, "changeSlow": _42_0, "removalFast": _43_1, "removalSlow": _44_2, "operation": _45_3, "config": _config_5, "reads": _reads_5}};
        }
      } else {
        const _41_0 = _owners_0["changeFast"];
        const _42_1 = _owners_0["changeSlow"];
        const _43_2 = _owners_0["removalFast"];
        const _44_3 = _owners_0["removalSlow"];
        const _45_4 = _owners_0["operation"];
        const _config_6 = _owners_0["config"];
        const _reads_6 = _owners_0["reads"];
        const _world_6 = _observed_0["fst"];
        return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_6, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": _t_2, "changeFast": _41_0, "changeSlow": _42_1, "removalFast": _43_2, "removalSlow": _44_3, "operation": _45_4, "config": _config_6, "reads": _reads_6}};
      }
    } else {
      const _40_0 = _owners_0["slow"];
      const _41_1 = _owners_0["changeFast"];
      const _42_2 = _owners_0["changeSlow"];
      const _43_3 = _owners_0["removalFast"];
      const _44_4 = _owners_0["removalSlow"];
      const _45_5 = _owners_0["operation"];
      const _config_7 = _owners_0["config"];
      const _reads_7 = _owners_0["reads"];
      const _world_7 = _observed_0["fst"];
      return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_7, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": _t_1, "slow": _40_0, "changeFast": _41_1, "changeSlow": _42_2, "removalFast": _43_3, "removalSlow": _44_4, "operation": _45_5, "config": _config_7, "reads": _reads_7}};
    }
  } else {
    const _39_0 = _owners_0["fast"];
    const _40_1 = _owners_0["slow"];
    const _41_2 = _owners_0["changeFast"];
    const _42_3 = _owners_0["changeSlow"];
    const _43_4 = _owners_0["removalFast"];
    const _44_5 = _owners_0["removalSlow"];
    const _45_6 = _owners_0["operation"];
    const _config_8 = _owners_0["config"];
    const _reads_8 = _owners_0["reads"];
    const _world_8 = _observed_0["fst"];
    return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_8, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": _t_0, "fast": _39_0, "slow": _40_1, "changeFast": _41_2, "changeSlow": _42_3, "removalFast": _43_4, "removalSlow": _44_5, "operation": _45_6, "config": _config_8, "reads": _reads_8}};
  }
}

function $$$$047src$047ecs$047world$058events_view$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $$$$047src$047ecs$047reader$045domains$058collect_view$1260$(_events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _values_0 = _observed_0["snd"];
  return $$$$047src$047ecs$047reader$045domains$058collected$1260$(_world_0, _events_0, ($$$$047src$047ecs$047reader$045domains$058split$1260$(_values_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047operations$058condition_set_named$(_enabled_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047experiments$047public$045schedule$045readers$047schema$058populate_enabled$(_world_0, ($$$$047experiments$047public$045schedule$045readers$047operations$058handle$(_namespace_0, 1)), ($$$$047experiments$047public$045schedule$045readers$047operations$058enabled_value$(_enabled_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058init_change_slow$(_runtime_0, _fast_0, _slow_0, _cf_0, _op_0, _result_0) {
  const _ns_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _next_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _start_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["dropped"];
  if (_result_0.$ === "../src/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _cs_0 = _result_0["registry"];
    return $$$$047experiments$047public$045schedule$045readers$047driver$058init_changes_detached$(_fast_0, _slow_0, _cf_0, _cs_0, _op_0, ($$$$047src$047ecs$047reader$045domains$058detach$1260$({$: "../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _ns_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _next_0, "tick": _tick_0, "frameStart": _start_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, {$: "Nil"})));
  } else {
    return {$: "None"};
  }
}

function $$$$047src$047ecs$047system$058register_namespace$1260$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047src$047ecs$047system$058register_join$1260$(($$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047src$047ecs$047system$058register_join$1261$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047src$047ecs$047system$058register_meta$1262$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../src/ecs/world.RegistrationRejected") {
    return {$: "../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047added$045controls$058fourth$(_log_0, _observed_0) {
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058array$(($List$append$(_log_0, {$: "Con", "head": _text_0, "tail": {$: "Nil"}}))));
  const _x_1 = (_x_0 + "}");
  return (_x_2) => $timing$058capture$(("{\"format\":1,\"application\":\"AddedSchedule\",\"checkpoints\":" + _x_1), _x_2);
}

function $$$$047experiments$047public$045schedule$045readers$047added$045controls$058result$(_result_0) {
  if (_result_0.$ === "../src/ecs/schedule.Finished") {
    const _t_0 = _result_0["schedule"];
    const _owners_0 = _t_0["owners"];
    const _world_0 = _result_0["world"];
    return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/added-controls.Host", "world": _world_0, "owners": _owners_0}, "snd": true};
  } else if (_result_0.$ === "../src/ecs/schedule.Failed") {
    const _t_1 = _result_0["schedule"];
    const _owners_1 = _t_1["owners"];
    const _world_1 = _result_0["world"];
    return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/added-controls.Host", "world": _world_1, "owners": _owners_1}, "snd": false};
  } else {
    const _t_2 = _result_0["schedule"];
    const _owners_2 = _t_2["owners"];
    const _world_2 = _result_0["world"];
    return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/added-controls.Host", "world": _world_2, "owners": _owners_2}, "snd": false};
  }
}

function $$$$047src$047ecs$047schedule$058run_with_skip$1261$(_schedule_0, _world_0) {
  return $$$$047src$047ecs$047schedule$058run_namespace_skip$1261$(_schedule_0, ($$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $$$$047src$047ecs$047schedule$058build_checked$1261$(_allowed_0, _namespace_0, _name_0, _steps_0, _owners_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/schedule.Invalid", "owners": _owners_0};
  } else {
    return {$: "../src/ecs/schedule.Built", "schedule": {$: "../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}};
  }
}

function $$$$047src$047ecs$047schedule$058valid$($0, $1, $2) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _catalog_0 = $1;
      const _seen_0 = $2;
      if (_steps_0.$ === "Nil") {
        return true;
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../src/ecs/schedule.Phase") {
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _catalog_0;
          $2 = _seen_0;
          continue;
        } else if (_t_0.$ === "../src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _catalog_0;
          $2 = _seen_0;
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _rest_2 = _steps_0["tail"];
          return $Bool$and$(($$$$047src$047ecs$047schedule$058contains$(_catalog_0, _id_0)), ($Bool$and$(($Bool$not$(($$$$047src$047ecs$047schedule$058contains$(_seen_0, _id_0)))), ($$$$047src$047ecs$047schedule$058valid$(_rest_2, _catalog_0, {$: "Con", "head": _id_0, "tail": _seen_0})))));
        }
      }
    }
  }
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058quoted$(_x_0) {
  const _x_1 = (_x_0 + "\"");
  return ("\"" + _x_1);
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058boolean$(_x_0) {
  if (_x_0) {
    return "true";
  } else {
    return "false";
  }
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058numbers$(_values_0) {
  return $$$$047experiments$047public$045schedule$045readers$047consumers$058numbers_loop$(($List$reverse$(_values_0)), "]", true);
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058ping_values$(_values_0) {
  return $$$$047experiments$047public$045schedule$045readers$047consumers$058ping_loop$(_values_0, {$: "Nil"});
}

function $$$$047experiments$047public$045schedule$045readers$047observe$058statuses$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    return {$: "Con", "head": ($$$$047experiments$047public$045schedule$045readers$047observe$058status$(_value_0)), "tail": ($$$$047experiments$047public$045schedule$045readers$047observe$058statuses$(_rest_0))};
  }
}

function $$$$047src$047ecs$047event$045runtime$058reader_statuses$1260$(_positions_0, _batches_0, _dropped_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _position_0 = _positions_0["head"];
    const _rest_0 = _positions_0["tail"];
    return {$: "Con", "head": ($$$$047src$047ecs$047event$045runtime$058reader_status$1260$(_position_0, _batches_0, _dropped_0)), "tail": ($$$$047src$047ecs$047event$045runtime$058reader_statuses$1260$(_rest_0, _batches_0, _dropped_0))};
  }
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047experiments$047public$045schedule$045readers$047observe$058rows$($0, $1) {
  for (;;) {
    {
      const _handles_0 = $0;
      const _observed_0 = $1;
      if (_handles_0.$ === "Nil") {
        const _world_0 = _observed_0["fst"];
        const _previous_0 = _observed_0["snd"];
        return {$: "Tuple", "fst": _world_0, "snd": ($List$reverse$(_previous_0))};
      } else {
        const _handle_0 = _handles_0["head"];
        const _rest_0 = _handles_0["tail"];
        const _world_1 = _observed_0["fst"];
        const _previous_1 = _observed_0["snd"];
        $0 = _rest_0;
        $1 = ($$$$047experiments$047public$045schedule$045readers$047observe$058accumulate$(_previous_1, ($$$$047experiments$047public$045schedule$045readers$047observe$058row$(_world_1, _handle_0))));
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047world$058handles_finish$1260$(_scanned_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _scanned_0["live"];
  const _handles_0 = _scanned_0["handles"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($List$reverse$(_handles_0))};
}

function $$$$047src$047ecs$047world$058collect_live$1260$(_remaining_0, _namespace_0, _live_0) {
  if (_remaining_0 === 0) {
    return {$: "../src/ecs/world.HandleScan", "live": _live_0, "handles": {$: "Nil"}};
  } else {
    const _rest_0 = (_remaining_0 - 1);
    const _x_0 = nat_chk(_rest_0 + 1);
    return $$$$047src$047ecs$047world$058collect_join$1260$(($$$$047src$047ecs$047world$058collect_live$1260$(_rest_0, _namespace_0, _live_0)), _namespace_0, (_x_0 >>> 0));
  }
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058run_result$(_result_0) {
  if (_result_0.$ === "../src/ecs/schedule.Finished") {
    const _t_0 = _result_0["schedule"];
    const _owners_0 = _t_0["owners"];
    const _world_0 = _result_0["world"];
    return $$$$047experiments$047public$045schedule$045readers$047driver$058returned$(_owners_0, _world_0, true);
  } else if (_result_0.$ === "../src/ecs/schedule.Failed") {
    const _t_1 = _result_0["schedule"];
    const _owners_1 = _t_1["owners"];
    const _world_1 = _result_0["world"];
    return $$$$047experiments$047public$045schedule$045readers$047driver$058returned$(_owners_1, _world_1, false);
  } else {
    const _t_2 = _result_0["schedule"];
    const _owners_2 = _t_2["owners"];
    const _world_2 = _result_0["world"];
    return $$$$047experiments$047public$045schedule$045readers$047driver$058returned$(_owners_2, _world_2, false);
  }
}

function $$$$047src$047ecs$047schedule$058run_with_skip$1260$(_schedule_0, _world_0) {
  return $$$$047src$047ecs$047schedule$058run_namespace_skip$1260$(_schedule_0, ($$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $$$$047src$047ecs$047schedule$058build_checked$1260$(_allowed_0, _namespace_0, _name_0, _steps_0, _owners_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/schedule.Invalid", "owners": _owners_0};
  } else {
    return {$: "../src/ecs/schedule.Built", "schedule": {$: "../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058framed$(_owners_0, _result_0) {
  const __0 = _owners_0["events"];
  const _t_0 = _owners_0["fast"];
  if (_t_0.$ === "../experiments/public-schedule-readers/driver.Occupied") {
    const _fast_0 = _t_0["owner"];
    const _t_1 = _owners_0["slow"];
    if (_t_1.$ === "../experiments/public-schedule-readers/driver.Occupied") {
      const _slow_0 = _t_1["owner"];
      const _t_2 = _owners_0["changeFast"];
      if (_t_2.$ === "../experiments/public-schedule-readers/driver.Occupied") {
        const _cf_0 = _t_2["owner"];
        const _t_3 = _owners_0["changeSlow"];
        if (_t_3.$ === "../experiments/public-schedule-readers/driver.Occupied") {
          const _cs_0 = _t_3["owner"];
          const _t_4 = _owners_0["removalFast"];
          if (_t_4.$ === "../experiments/public-schedule-readers/driver.Occupied") {
            const _rf_0 = _t_4["owner"];
            const _t_5 = _owners_0["removalSlow"];
            if (_t_5.$ === "../experiments/public-schedule-readers/driver.Occupied") {
              const _rs_0 = _t_5["owner"];
              const _t_6 = _owners_0["operation"];
              if (_t_6.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                const _op_0 = _t_6["owner"];
                const _config_0 = _owners_0["config"];
                const _world_0 = _result_0["world"];
                const _events_0 = _result_0["events"];
                return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _op_0}, "config": _config_0, "reads": {$: "Nil"}}};
              } else {
                const _config_1 = _owners_0["config"];
                const __2 = _owners_0["reads"];
                const _world_1 = _result_0["world"];
                return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_1, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": _t_6, "config": _config_1, "reads": __2}};
              }
            } else {
              const _40_0 = _owners_0["operation"];
              const _config_2 = _owners_0["config"];
              const __4 = _owners_0["reads"];
              const _world_2 = _result_0["world"];
              return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_2, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": _t_5, "operation": _40_0, "config": _config_2, "reads": __4}};
            }
          } else {
            const _39_0 = _owners_0["removalSlow"];
            const _40_1 = _owners_0["operation"];
            const _config_3 = _owners_0["config"];
            const __6 = _owners_0["reads"];
            const _world_3 = _result_0["world"];
            return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_3, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": _t_4, "removalSlow": _39_0, "operation": _40_1, "config": _config_3, "reads": __6}};
          }
        } else {
          const _38_0 = _owners_0["removalFast"];
          const _39_1 = _owners_0["removalSlow"];
          const _40_2 = _owners_0["operation"];
          const _config_4 = _owners_0["config"];
          const __8 = _owners_0["reads"];
          const _world_4 = _result_0["world"];
          return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_4, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": _t_3, "removalFast": _38_0, "removalSlow": _39_1, "operation": _40_2, "config": _config_4, "reads": __8}};
        }
      } else {
        const _37_0 = _owners_0["changeSlow"];
        const _38_1 = _owners_0["removalFast"];
        const _39_2 = _owners_0["removalSlow"];
        const _40_3 = _owners_0["operation"];
        const _config_5 = _owners_0["config"];
        const __10 = _owners_0["reads"];
        const _world_5 = _result_0["world"];
        return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_5, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": _t_2, "changeSlow": _37_0, "removalFast": _38_1, "removalSlow": _39_2, "operation": _40_3, "config": _config_5, "reads": __10}};
      }
    } else {
      const _36_0 = _owners_0["changeFast"];
      const _37_1 = _owners_0["changeSlow"];
      const _38_2 = _owners_0["removalFast"];
      const _39_3 = _owners_0["removalSlow"];
      const _40_4 = _owners_0["operation"];
      const _config_6 = _owners_0["config"];
      const __12 = _owners_0["reads"];
      const _world_6 = _result_0["world"];
      return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_6, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": _t_1, "changeFast": _36_0, "changeSlow": _37_1, "removalFast": _38_2, "removalSlow": _39_3, "operation": _40_4, "config": _config_6, "reads": __12}};
    }
  } else {
    const _35_0 = _owners_0["slow"];
    const _36_1 = _owners_0["changeFast"];
    const _37_2 = _owners_0["changeSlow"];
    const _38_3 = _owners_0["removalFast"];
    const _39_4 = _owners_0["removalSlow"];
    const _40_5 = _owners_0["operation"];
    const _config_7 = _owners_0["config"];
    const __14 = _owners_0["reads"];
    const _world_7 = _result_0["world"];
    return {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_7, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": _t_0, "slow": _35_0, "changeFast": _36_1, "changeSlow": _37_2, "removalFast": _38_3, "removalSlow": _39_4, "operation": _40_5, "config": _config_7, "reads": __14}};
  }
}

function $$$$047src$047ecs$047reader$045domains$058detach$1260$(_runtime_0, _removals_0) {
  const _world_0 = _runtime_0["world"];
  const _ns_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _next_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _start_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047src$047ecs$047reader$045domains$058detached_values$1260$(_ns_0, _batches_0, _positions_0, _next_0, _tick_0, _start_0, _boundary_0, _capacity_0, _dropped_0, _removals_0, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
}

function $$$$047src$047ecs$047event$045runtime$058frame$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047src$047ecs$047event$045runtime$058trim$1260$({$: "../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _tick_0, "boundary": _frameStart_0, "capacity": _capacity_0, "droppedThrough": _dropped_0});
}

function $$$$047src$047ecs$047reader$045domains$058attach$1260$(_events_0, _world_0) {
  const _ns_0 = _events_0["namespace"];
  const _batches_0 = _events_0["batches"];
  const _positions_0 = _events_0["positions"];
  const _next_0 = _events_0["nextReader"];
  const _tick_0 = _events_0["tick"];
  const _start_0 = _events_0["frameStart"];
  const _boundary_0 = _events_0["boundary"];
  const _capacity_0 = _events_0["capacity"];
  const _dropped_0 = _events_0["dropped"];
  const _values_0 = _events_0["values"];
  return {$: "../src/ecs/event-runtime.Runtime", "world": ($$$$047src$047ecs$047world$058events_replace$1260$(_world_0, _values_0)), "namespace": _ns_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _next_0, "tick": _tick_0, "frameStart": _start_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0};
}

function $$$$047src$047ecs$047reader$045domains$058collected$1260$(_world_0, _events_0, _partition_0) {
  const _ns_0 = _events_0["namespace"];
  const _batches_0 = _events_0["batches"];
  const _positions_0 = _events_0["positions"];
  const _next_0 = _events_0["nextReader"];
  const _tick_0 = _events_0["tick"];
  const _start_0 = _events_0["frameStart"];
  const _boundary_0 = _events_0["boundary"];
  const _capacity_0 = _events_0["capacity"];
  const _dropped_0 = _events_0["dropped"];
  const _old_0 = _events_0["values"];
  const _fresh_0 = _partition_0["fst"];
  const _removals_0 = _partition_0["snd"];
  return $$$$047src$047ecs$047reader$045domains$058detach$1260$(($$$$047src$047ecs$047event$045runtime$058sync_values$1260$({$: "Tuple", "fst": ($$$$047src$047ecs$047world$058events_replace$1260$(_world_0, ($$$$047src$047ecs$047event$045runtime$058append$1260$(_old_0, _fresh_0)))), "snd": ($$$$047src$047ecs$047event$045runtime$058append$1260$(_old_0, _fresh_0))}, _ns_0, _batches_0, _positions_0, _next_0, nat_chk(_tick_0 + 1), _start_0, _boundary_0, _capacity_0, _dropped_0)), _removals_0);
}

function $$$$047src$047ecs$047reader$045domains$058split$1260$(_values_0) {
  return $$$$047src$047ecs$047reader$045domains$058split_loop$1260$(_values_0, {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}});
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058populate_enabled$(_world_0, _handle_0, _incoming_0) {
  return $$$$047experiments$047public$045schedule$045readers$047schema$058replaced$1263$(($$$$047src$047ecs$047component$058structural_replace$1263$(($$$$047experiments$047public$045schedule$045readers$047schema$058enabled$()), _world_0, _handle_0, _incoming_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047operations$058handle$(_namespace_0, _id_0) {
  return {$: "../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0};
}

function $$$$047experiments$047public$045schedule$045readers$047operations$058enabled_value$(_enabled_0) {
  if (_enabled_0) {
    return {$: "Some", "value": {$: "../experiments/public-schedule-readers/schema.Enabled"}};
  } else {
    return {$: "None"};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058init_changes_detached$(_fast_0, _slow_0, _cf_0, _cs_0, _op_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _events_0 = _result_0["events"];
  return $$$$047experiments$047public$045schedule$045readers$047driver$058init_removal_fast$(_events_0, _fast_0, _slow_0, _cf_0, _cs_0, _op_0, ($$$$047src$047ecs$047removals$058register$1260$(_world_0, "removal-fast")));
}

function $$$$047src$047ecs$047system$058register_join$1260$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../src/ecs/world.RegistrationRejected") {
    return {$: "../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047src$047ecs$047schedule$058run_namespace_skip$1261$(_schedule_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047src$047ecs$047schedule$058run_actual_skip$1261$(_schedule_0, _world_0, _actual_0);
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $$$$047src$047ecs$047schedule$058contains$(_ids_0, _id_0) {
  if (_ids_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    const _x_0 = (_head_0 === _id_0);
    const _x_1 = ($$$$047src$047ecs$047schedule$058contains$(_rest_0, _id_0));
    return (_x_0 || _x_1);
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058numbers_loop$($0, $1, $2) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_items_0.$ === "Nil") {
        return ("[" + _acc_0);
      } else {
        const _value_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        const _x_0 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058comma$(_first_0));
        const _x_1 = ($U32$show$(_value_0));
        const _x_2 = (_x_0 + _acc_0);
        $0 = _rest_0;
        $1 = (_x_1 + _x_2);
        $2 = false;
        continue;
      }
    }
  }
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058ping_loop$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _t_0 = _values_0["head"];
        if (_t_0.$ === "../experiments/public-schedule-readers/schema.Ping") {
          const _value_0 = _t_0["value"];
          const _rest_0 = _values_0["tail"];
          $0 = _rest_0;
          $1 = {$: "Con", "head": _value_0, "tail": _acc_0};
          continue;
        } else {
          const _rest_1 = _values_0["tail"];
          $0 = _rest_1;
          $1 = _acc_0;
          continue;
        }
      }
    }
  }
}

function $$$$047experiments$047public$045schedule$045readers$047observe$058status$(_value_0) {
  const _id_0 = _value_0["id"];
  const _unread_0 = _value_0["unread"];
  const _lagged_0 = _value_0["lagged"];
  const _x_0 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058boolean$(_lagged_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($Nat$show$(_unread_0));
  const _x_3 = (",\"lagged\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058quoted$(($$$$047experiments$047public$045schedule$045readers$047observe$058reader_name$(_id_0))));
  const _x_6 = (",\"unread\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  return ("{\"name\":" + _x_7);
}

function $$$$047src$047ecs$047event$045runtime$058reader_status$1260$(_position_0, _batches_0, _dropped_0) {
  const _id_0 = _position_0["id"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../src/ecs/event-runtime.ReaderStatus", "id": _id_0, "cursor": _cursor_0, "registeredAt": _registered_0, "unread": ($$$$047src$047ecs$047event$045runtime$058count$1260$(($$$$047src$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0)))), "lagged": (_x_0 < _dropped_0)};
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047experiments$047public$045schedule$045readers$047observe$058accumulate$(_previous_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": _value_0, "tail": _previous_0}};
}

function $$$$047experiments$047public$045schedule$045readers$047observe$058row$(_world_0, _handle_0) {
  return $$$$047experiments$047public$045schedule$045readers$047observe$058row_stock$(_handle_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058get_stock$(_world_0, _handle_0)));
}

function $$$$047src$047ecs$047world$058collect_join$1260$(_scanned_0, _namespace_0, _id_0) {
  const _live_0 = _scanned_0["live"];
  const _handles_0 = _scanned_0["handles"];
  return $$$$047src$047ecs$047world$058collect_step$1260$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _id_0, _handles_0);
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058returned$(_owners_0, _world_0, _ok_0) {
  const _t_0 = _owners_0["events"];
  if (_t_0.$ === "../experiments/public-schedule-readers/driver.Occupied") {
    const _events_0 = _t_0["owner"];
    const _fast_0 = _owners_0["fast"];
    const _slow_0 = _owners_0["slow"];
    const _cf_0 = _owners_0["changeFast"];
    const _cs_0 = _owners_0["changeSlow"];
    const _rf_0 = _owners_0["removalFast"];
    const _rs_0 = _owners_0["removalSlow"];
    const _op_0 = _owners_0["operation"];
    const _config_0 = _owners_0["config"];
    const _reads_0 = _owners_0["reads"];
    return $$$$047experiments$047public$045schedule$045readers$047driver$058returned_collected$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Empty"}, "fast": _fast_0, "slow": _slow_0, "changeFast": _cf_0, "changeSlow": _cs_0, "removalFast": _rf_0, "removalSlow": _rs_0, "operation": _op_0, "config": _config_0, "reads": _reads_0}, _ok_0, ($$$$047src$047ecs$047reader$045domains$058collect$1260$(_events_0, _world_0)));
  } else {
    const _fast_1 = _owners_0["fast"];
    const _slow_1 = _owners_0["slow"];
    const _cf_1 = _owners_0["changeFast"];
    const _cs_1 = _owners_0["changeSlow"];
    const _rf_1 = _owners_0["removalFast"];
    const _rs_1 = _owners_0["removalSlow"];
    const _op_1 = _owners_0["operation"];
    const _config_1 = _owners_0["config"];
    const _reads_1 = _owners_0["reads"];
    return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": _t_0, "fast": _fast_1, "slow": _slow_1, "changeFast": _cf_1, "changeSlow": _cs_1, "removalFast": _rf_1, "removalSlow": _rs_1, "operation": _op_1, "config": _config_1, "reads": _reads_1}}, "snd": _ok_0};
  }
}

function $$$$047src$047ecs$047schedule$058run_namespace_skip$1260$(_schedule_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047src$047ecs$047schedule$058run_actual_skip$1260$(_schedule_0, _world_0, _actual_0);
}

function $$$$047src$047ecs$047reader$045domains$058detached_values$1260$(_namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, _removals_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _values_0 = _observed_0["snd"];
  return {$: "../src/ecs/reader-domains.Detached", "world": ($$$$047src$047ecs$047world$058events_replace$1260$(_world_0, _removals_0)), "events": {$: "../src/ecs/reader-domains.Events", "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0, "values": _values_0}};
}

function $$$$047src$047ecs$047event$045runtime$058trim$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047src$047ecs$047event$045runtime$058trim_result$1260$(_world_0, _namespace_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, run_loop($$$$047src$047ecs$047event$045runtime$058trim_capacity$1260$(run_loop($$$$047src$047ecs$047event$045runtime$058past_window$1260$(_batches_0, ($$$$047src$047ecs$047event$045runtime$058hold_boundary$(_positions_0, _boundary_0)), _dropped_0)), _capacity_0)));
}

function $$$$047src$047ecs$047world$058events_replace$1260$(_world_0, _retained_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _retained_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047src$047ecs$047event$045runtime$058sync_values$1260$(_observed_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _observed_0["fst"];
  const _all_0 = _observed_0["snd"];
  const _published_0 = ($List$drop$(_all_0, ($$$$047src$047ecs$047event$045runtime$058size$1260$(_batches_0))));
  const _x_0 = ($$$$047src$047ecs$047event$045runtime$058count$1260$(_published_0));
  return {$: "../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": ($$$$047src$047ecs$047event$045runtime$058sync_checked$1260$((0 < _x_0), _batches_0, _tick_0, _published_0)), "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0};
}

function $$$$047src$047ecs$047event$045runtime$058append$1260$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047src$047ecs$047event$045runtime$058append_loop$1260$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047src$047ecs$047reader$045domains$058split_loop$1260$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      if (_values_0.$ === "Nil") {
        return $$$$047src$047ecs$047reader$045domains$058split_reverse$1260$(_acc_0);
      } else {
        const _value_0 = _values_0["head"];
        const _rest_0 = _values_0["tail"];
        const _events_0 = _acc_0["fst"];
        const _removals_0 = _acc_0["snd"];
        $0 = _rest_0;
        $1 = ($$$$047src$047ecs$047reader$045domains$058choose$1260$(($$$$047experiments$047public$045schedule$045readers$047schema$058is_event$(_value_0)), _value_0, _events_0, _removals_0));
        continue;
      }
    }
  }
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058replaced$1263$(_result_0) {
  if (_result_0.$ === "../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047src$047ecs$047component$058structural_replace$1263$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047src$047ecs$047component$058replace_allowed$1263$(($$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058enabled$() {
  return $$$$047src$047ecs$047component$058define$1263$("Enabled");
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058init_removal_fast$(_events_0, _fast_0, _slow_0, _cf_0, _cs_0, _op_0, _result_0) {
  if (_result_0.$ === "../src/ecs/removals.Registered") {
    const _world_0 = _result_0["world"];
    const _rf_0 = _result_0["reader"];
    return $$$$047experiments$047public$045schedule$045readers$047driver$058init_removal_slow$(_events_0, _fast_0, _slow_0, _cf_0, _cs_0, _rf_0, _op_0, ($$$$047src$047ecs$047removals$058register$1260$(_world_0, "removal-slow")));
  } else {
    return {$: "None"};
  }
}

function $$$$047src$047ecs$047removals$058register$1260$(_world_0, _name_0) {
  return $$$$047src$047ecs$047removals$058register_named$1260$(($$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0);
}

function $$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../src/ecs/world.RegistrationRejected") {
    return {$: "../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047src$047ecs$047schedule$058run_actual_skip$1261$(_schedule_0, _world_0, _actual_0) {
  const _namespace_0 = _schedule_0["namespace"];
  const _name_0 = _schedule_0["name"];
  const _steps_0 = _schedule_0["steps"];
  const _owners_0 = _schedule_0["owners"];
  return $$$$047src$047ecs$047schedule$058run_checked_skip$1261$((_namespace_0 === _actual_0), {$: "../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}, _world_0);
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058comma$(_first_0) {
  if (_first_0) {
    return "";
  } else {
    return ",";
  }
}

function $$$$047experiments$047public$045schedule$045readers$047observe$058reader_name$(_id_0) {
  if (_id_0 == 1) {
    return "event-fast";
  } else if ((_id_0 & 1) == 1) {
    const _8_0 = u32_to_word(_id_0)["tail"]["head"];
    const _9_0 = u32_to_word(_id_0)["tail"]["tail"];
    const _x_0 = ($U32$show$(word_to_u32({$: "WCon", "head": true, "tail": {$: "WCon", "head": _8_0, "tail": _9_0}})));
    return ("reader#" + _x_0);
  } else if (_id_0 == 2) {
    return "event-slow";
  } else {
    const _70_0 = u32_to_word(_id_0)["tail"]["head"];
    const _71_0 = u32_to_word(_id_0)["tail"]["tail"];
    const _x_1 = ($U32$show$(word_to_u32({$: "WCon", "head": false, "tail": {$: "WCon", "head": _70_0, "tail": _71_0}})));
    return ("reader#" + _x_1);
  }
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $$$$047src$047ecs$047event$045runtime$058count$1260$(_items_0) {
  return $$$$047src$047ecs$047event$045runtime$058count_loop$1260$(_items_0, 0);
}

function $$$$047src$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047src$047ecs$047event$045runtime$058since_checked$1260$((_cursor_0 < _tick_0), _items_0, ($$$$047src$047ecs$047event$045runtime$058since$1260$(_rest_0, _cursor_0)));
  }
}

function $$$$047experiments$047public$045schedule$045readers$047observe$058row_stock$(_handle_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _s_0 = _observed_0["snd"];
  return $$$$047experiments$047public$045schedule$045readers$047observe$058row_aux$(_handle_0, _s_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058get_queue$(_world_0, _handle_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058get_stock$(_world_0, _handle_0) {
  return $$$$047src$047ecs$047component$058get$1260$(($$$$047experiments$047public$045schedule$045readers$047schema$058stock$()), _world_0, _handle_0);
}

function $$$$047src$047ecs$047world$058collect_step$1260$(_checked_0, _namespace_0, _id_0, _handles_0) {
  const _live_0 = _checked_0["fst"];
  const _present_0 = _checked_0["snd"];
  return {$: "../src/ecs/world.HandleScan", "live": _live_0, "handles": ($$$$047src$047ecs$047world$058collect_checked$1260$(_present_0, _namespace_0, _id_0, _handles_0))};
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058returned_collected$(_owners_0, _ok_0, _result_0) {
  const _fast_0 = _owners_0["fast"];
  const _slow_0 = _owners_0["slow"];
  const _cf_0 = _owners_0["changeFast"];
  const _cs_0 = _owners_0["changeSlow"];
  const _rf_0 = _owners_0["removalFast"];
  const _rs_0 = _owners_0["removalSlow"];
  const _op_0 = _owners_0["operation"];
  const _config_0 = _owners_0["config"];
  const _reads_0 = _owners_0["reads"];
  const _world_0 = _result_0["world"];
  const _events_0 = _result_0["events"];
  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": _fast_0, "slow": _slow_0, "changeFast": _cf_0, "changeSlow": _cs_0, "removalFast": _rf_0, "removalSlow": _rs_0, "operation": _op_0, "config": _config_0, "reads": _reads_0}}, "snd": _ok_0};
}

function $$$$047src$047ecs$047schedule$058run_actual_skip$1260$(_schedule_0, _world_0, _actual_0) {
  const _namespace_0 = _schedule_0["namespace"];
  const _name_0 = _schedule_0["name"];
  const _steps_0 = _schedule_0["steps"];
  const _owners_0 = _schedule_0["owners"];
  return $$$$047src$047ecs$047schedule$058run_checked_skip$1260$((_namespace_0 === _actual_0), {$: "../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}, _world_0);
}

function $$$$047src$047ecs$047event$045runtime$058trim_result$1260$(_world_0, _namespace_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _trimmed_0) {
  const _batches_0 = _trimmed_0["batches"];
  const _dropped_0 = _trimmed_0["dropped"];
  return {$: "../src/ecs/event-runtime.Runtime", "world": ($$$$047src$047ecs$047world$058events_replace$1260$(_world_0, ($$$$047src$047ecs$047event$045runtime$058values$1260$(_batches_0)))), "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0};
}

function $$$$047src$047ecs$047event$045runtime$058trim_capacity$1260$(_trimmed_0, _capacity_0) {
  const _batches_0 = _trimmed_0["batches"];
  const _dropped_0 = _trimmed_0["dropped"];
  return $$$$047src$047ecs$047event$045runtime$058at_capacity$1260$(_batches_0, _capacity_0, _dropped_0);
}

function $$$$047src$047ecs$047event$045runtime$058past_window$1260$(_batches_0, _boundary_0, _dropped_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "../src/ecs/event-runtime.Trimmed", "batches": {$: "Nil"}, "dropped": _dropped_0};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047src$047ecs$047event$045runtime$058past_checked$1260$(($Nat$is_le$(_tick_0, _boundary_0)), _tick_0, _items_0, _rest_0, _dropped_0, run_clo((_x_0) => {
  return $$$$047src$047ecs$047event$045runtime$058past_window$1260$(_rest_0, _boundary_0, _x_0);
}));
  }
}

function $$$$047src$047ecs$047event$045runtime$058hold_boundary$($0, $1) {
  for (;;) {
    {
      const _positions_0 = $0;
      const _boundary_0 = $1;
      if (_positions_0.$ === "Nil") {
        return _boundary_0;
      } else {
        const _t_0 = _positions_0["head"];
        const _cursor_0 = _t_0["cursor"];
        const _rest_0 = _positions_0["tail"];
        $0 = _rest_0;
        $1 = (_boundary_0 < _cursor_0 ? _boundary_0 : _cursor_0);
        continue;
      }
    }
  }
}

function $List$drop$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _n_0 = $1;
      if (_xs_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        if (_n_0 === 0) {
          return {$: "Con", "head": _h_0, "tail": _t_0};
        } else {
          const _p_0 = (_n_0 - 1);
          $0 = _t_0;
          $1 = _p_0;
          continue;
        }
      }
    }
  }
}

function $$$$047src$047ecs$047event$045runtime$058size$1260$(_batches_0) {
  return $$$$047src$047ecs$047event$045runtime$058size_loop$1260$(_batches_0, 0);
}

function $$$$047src$047ecs$047event$045runtime$058sync_checked$1260$(_nonempty_0, _batches_0, _tick_0, _published_0) {
  if (!_nonempty_0) {
    return _batches_0;
  } else {
    return $$$$047src$047ecs$047event$045runtime$058append$1261$(_batches_0, {$: "Con", "head": {$: "../src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _published_0}, "tail": {$: "Nil"}});
  }
}

function $$$$047src$047ecs$047event$045runtime$058append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047reader$045domains$058split_reverse$1260$(_pair_0) {
  const _events_0 = _pair_0["fst"];
  const _removals_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": ($List$reverse$(_events_0)), "snd": ($List$reverse$(_removals_0))};
}

function $$$$047src$047ecs$047reader$045domains$058choose$1260$(_selected_0, _value_0, _events_0, _removals_0) {
  if (_selected_0) {
    return {$: "Tuple", "fst": {$: "Con", "head": _value_0, "tail": _events_0}, "snd": _removals_0};
  } else {
    return {$: "Tuple", "fst": _events_0, "snd": {$: "Con", "head": _value_0, "tail": _removals_0}};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058is_event$(_value_0) {
  if (_value_0.$ === "../experiments/public-schedule-readers/schema.Ping") {
    return true;
  } else {
    return false;
  }
}

function $$$$047src$047ecs$047component$058replace_allowed$1263$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047src$047ecs$047component$058replace_clock$1263$(_id_0, _incoming_0, ($$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047src$047ecs$047component$058define$1263$(_name_0) {
  return {$: "../src/ecs/component.Family", "name": _name_0};
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058init_removal_slow$(_events_0, _fast_0, _slow_0, _cf_0, _cs_0, _rf_0, _op_0, _result_0) {
  if (_result_0.$ === "../src/ecs/removals.Registered") {
    const _world_0 = _result_0["world"];
    const _rs_0 = _result_0["reader"];
    return {$: "Some", "value": {$: "../experiments/public-schedule-readers/driver.Host", "world": _world_0, "owners": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _op_0}, "config": {$: "../experiments/public-schedule-readers/driver.Config", "request": {$: "../experiments/public-schedule-readers/operations.Request", "op": 4, "value": 0, "count": 0, "second": {$: "None"}, "fail": false}, "eventFail": false, "changeFail": false, "removalFail": false, "own": false}, "reads": {$: "Nil"}}}};
  } else {
    return {$: "None"};
  }
}

function $$$$047src$047ecs$047removals$058register_named$1260$(_named_0, _name_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047src$047ecs$047removals$058register_view$1260$(($$$$047src$047ecs$047world$058events_view$1260$(_world_0)), _namespace_0, _name_0);
}

function $$$$047src$047ecs$047schedule$058run_checked_skip$1261$(_allowed_0, _schedule_0, _world_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/schedule.Rejected", "schedule": _schedule_0, "world": _world_0};
  } else {
    const _namespace_0 = _schedule_0["namespace"];
    const _name_0 = _schedule_0["name"];
    const _steps_0 = _schedule_0["steps"];
    const _owners_0 = _schedule_0["owners"];
    return $$$$047src$047ecs$047schedule$058execute_skip$1261$(_steps_0, _owners_0, _world_0, _namespace_0, _name_0, _steps_0, {$: "Nil"});
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $$$$047src$047ecs$047event$045runtime$058count_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047event$045runtime$058since_checked$1260$(_visible_0, _items_0, _rest_0) {
  if (!_visible_0) {
    return _rest_0;
  } else {
    return $$$$047src$047ecs$047event$045runtime$058append$1260$(_items_0, _rest_0);
  }
}

function $$$$047experiments$047public$045schedule$045readers$047observe$058row_aux$(_handle_0, _value_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _q_0 = _observed_0["snd"];
  const _x_0 = ($$$$047experiments$047public$045schedule$045readers$047observe$058aux$(_q_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($$$$047experiments$047public$045schedule$045readers$047observe$058stock$(_value_0));
  const _x_3 = (",\"aux\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($U32$show$(($$$$047experiments$047public$045schedule$045readers$047consumers$058id$(_handle_0))));
  const _x_6 = (",\"stock\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  return {$: "Tuple", "fst": _world_0, "snd": ("{\"id\":" + _x_7)};
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058get_queue$(_world_0, _handle_0) {
  return $$$$047src$047ecs$047component$058get$1262$(($$$$047experiments$047public$045schedule$045readers$047schema$058queue$()), _world_0, _handle_0);
}

function $$$$047src$047ecs$047component$058get$1260$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047src$047ecs$047component$058get_live_owned$1260$(_id_0, ($$$$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058stock$() {
  return $$$$047src$047ecs$047component$058define$1260$("Stock");
}

function $$$$047src$047ecs$047world$058collect_checked$1260$(_present_0, _namespace_0, _id_0, _handles_0) {
  if (!_present_0) {
    return _handles_0;
  } else {
    return {$: "Con", "head": {$: "../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _handles_0};
  }
}

function $$$$047src$047ecs$047schedule$058run_checked_skip$1260$(_allowed_0, _schedule_0, _world_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/schedule.Rejected", "schedule": _schedule_0, "world": _world_0};
  } else {
    const _namespace_0 = _schedule_0["namespace"];
    const _name_0 = _schedule_0["name"];
    const _steps_0 = _schedule_0["steps"];
    const _owners_0 = _schedule_0["owners"];
    return $$$$047src$047ecs$047schedule$058execute_skip$1260$(_steps_0, _owners_0, _world_0, _namespace_0, _name_0, _steps_0, {$: "Nil"});
  }
}

function $$$$047src$047ecs$047event$045runtime$058values$1260$(_batches_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _batches_0["head"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047src$047ecs$047event$045runtime$058append$1260$(_items_0, ($$$$047src$047ecs$047event$045runtime$058values$1260$(_rest_0)));
  }
}

function $$$$047src$047ecs$047event$045runtime$058at_capacity$1260$(_batches_0, _capacity_0, _dropped_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "../src/ecs/event-runtime.Trimmed", "batches": {$: "Nil"}, "dropped": _dropped_0};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    const _x_0 = ($$$$047src$047ecs$047event$045runtime$058size$1260$({$: "Con", "head": {$: "../src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}));
    return $$$$047src$047ecs$047event$045runtime$058capacity_checked$1260$((_capacity_0 < _x_0), _tick_0, _items_0, _rest_0, _dropped_0, run_clo((_x_1) => {
  return $$$$047src$047ecs$047event$045runtime$058at_capacity$1260$(_rest_0, _capacity_0, _x_1);
}));
  }
}

function $$$$047src$047ecs$047event$045runtime$058past_checked$1260$(_remove_0, _tick_0, _items_0, _rest_0, _dropped_0, _ih_0) {
  if (!_remove_0) {
    return {$: "../src/ecs/event-runtime.Trimmed", "batches": {$: "Con", "head": {$: "../src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0));
  }
}

function $Nat$is_le$(_a_0, _b_0) {
  return $Cmp$is_le$(cmp_new(_a_0, _b_0));
}

function $$$$047src$047ecs$047event$045runtime$058size_loop$1260$($0, $1) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _acc_0 = $1;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047src$047ecs$047event$045runtime$058count_loop$1260$(_items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047event$045runtime$058append$1261$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047src$047ecs$047event$045runtime$058append_loop$1261$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047src$047ecs$047component$058replace_clock$1263$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047src$047ecs$047component$058replace_clock_checked$1263$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047src$047ecs$047component$058owner_present$1263$(_incoming_0)));
}

function $$$$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047src$047ecs$047removals$058register_view$1260$(_viewed_0, _namespace_0, _name_0) {
  const _world_0 = _viewed_0["fst"];
  return $$$$047src$047ecs$047removals$058register_result$1260$(($$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, {$: "Con", "head": "removal", "tail": {$: "Con", "head": _name_0, "tail": {$: "Nil"}}})), _namespace_0, _name_0, 0);
}

function $$$$047src$047ecs$047schedule$058execute_skip$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _owners_0 = $1;
      const _world_0 = $2;
      const _namespace_0 = $3;
      const _name_0 = $4;
      const _all_0 = $5;
      const _observations_0 = $6;
      if (_steps_0.$ === "Nil") {
        return {$: "../src/ecs/schedule.Finished", "schedule": {$: "../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "observations": _observations_0};
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../src/ecs/schedule.Phase") {
          const _phase_0 = _t_0["name"];
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _owners_0;
          $2 = _world_0;
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../src/ecs/schedule.Entered", "name": _phase_0}, "tail": {$: "Nil"}}));
          continue;
        } else if (_t_0.$ === "../src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _owners_0;
          $2 = run_loop($$$$047src$047ecs$047world$058barrier$1260$(_world_0));
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../src/ecs/schedule.Applied"}, "tail": {$: "Nil"}}));
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _slot_0 = _t_0["condition"];
          const _rest_2 = _steps_0["tail"];
          return $$$$047src$047ecs$047schedule$058after_condition_skip$1261$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047src$047ecs$047schedule$058execute_skip$1261$(_rest_2, _x_0, _x_1, _namespace_0, _name_0, _all_0, _x_2);
});
});
}), ($$$$047experiments$047public$045schedule$045readers$047operations$058condition$(_world_0, _slot_0)), _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
        }
      }
    }
  }
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058id$(_handle_0) {
  const _id_0 = _handle_0["id"];
  return _id_0;
}

function $$$$047experiments$047public$045schedule$045readers$047observe$058stock$(_value_0) {
  if (_value_0.$ === "../src/ecs/component.Found") {
    const _value_1 = _value_0["value"];
    const _x_0 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058view$(_value_1));
    const _x_1 = (_x_0 + "}");
    return ("{" + _x_1);
  } else {
    return "null";
  }
}

function $$$$047experiments$047public$045schedule$045readers$047observe$058aux$(_value_0) {
  if (_value_0.$ === "../src/ecs/component.Found") {
    const _t_0 = _value_0["value"];
    const _owned_0 = _t_0["owned"];
    const _x_0 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058numbers$(_owned_0));
    const _x_1 = (_x_0 + "}");
    return ("{\"owned\":" + _x_1);
  } else {
    return "null";
  }
}

function $$$$047src$047ecs$047component$058get$1262$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047src$047ecs$047component$058get_live_owned$1262$(_id_0, ($$$$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058queue$() {
  return $$$$047src$047ecs$047component$058define$1262$("Queue");
}

function $$$$047src$047ecs$047component$058get_live_owned$1260$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047src$047ecs$047world$058with_store_finish$1260$(($$$$047src$047ecs$047component$058get_store$1260$(_id_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058take_stock$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047src$047ecs$047component$058get_live_read$(_allowed_0, _id_0, _live_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _live_0, "snd": false};
  } else {
    return {$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]};
  }
}

function $$$$047src$047ecs$047component$058define$1260$(_name_0) {
  return {$: "../src/ecs/component.Family", "name": _name_0};
}

function $$$$047src$047ecs$047schedule$058execute_skip$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _owners_0 = $1;
      const _world_0 = $2;
      const _namespace_0 = $3;
      const _name_0 = $4;
      const _all_0 = $5;
      const _observations_0 = $6;
      if (_steps_0.$ === "Nil") {
        return {$: "../src/ecs/schedule.Finished", "schedule": {$: "../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "observations": _observations_0};
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../src/ecs/schedule.Phase") {
          const _phase_0 = _t_0["name"];
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _owners_0;
          $2 = _world_0;
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../src/ecs/schedule.Entered", "name": _phase_0}, "tail": {$: "Nil"}}));
          continue;
        } else if (_t_0.$ === "../src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _owners_0;
          $2 = run_loop($$$$047src$047ecs$047world$058barrier$1260$(_world_0));
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../src/ecs/schedule.Applied"}, "tail": {$: "Nil"}}));
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _slot_0 = _t_0["condition"];
          const _rest_2 = _steps_0["tail"];
          return $$$$047src$047ecs$047schedule$058after_condition_skip$1260$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047src$047ecs$047schedule$058execute_skip$1260$(_rest_2, _x_0, _x_1, _namespace_0, _name_0, _all_0, _x_2);
});
});
}), ($$$$047experiments$047public$045schedule$045readers$047operations$058condition$(_world_0, _slot_0)), _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
        }
      }
    }
  }
}

function $$$$047src$047ecs$047event$045runtime$058capacity_checked$1260$(_overflow_0, _tick_0, _items_0, _rest_0, _dropped_0, _ih_0) {
  if (!_overflow_0) {
    return {$: "../src/ecs/event-runtime.Trimmed", "batches": {$: "Con", "head": {$: "../src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0));
  }
}

function $Cmp$is_le$(_c_0) {
  if (_c_0.$ === "GT") {
    return false;
  } else {
    return true;
  }
}

function $$$$047src$047ecs$047event$045runtime$058append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047component$058replace_clock_checked$1263$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047src$047ecs$047component$058replace_clock_advanced$1263$(_id_0, _present_0, _incoming_1, ($$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047src$047ecs$047component$058owner_present$1263$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047src$047ecs$047removals$058register_result$1260$(_registered_0, _namespace_0, _name_0, _cursor_0) {
  const _world_0 = _registered_0["fst"];
  const _t_0 = _registered_0["snd"];
  if (_t_0.$ === "../src/ecs/world.Registered") {
    const _id_0 = _t_0["id"];
    return {$: "../src/ecs/removals.Registered", "world": _world_0, "reader": {$: "../src/ecs/removals.Reader", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "cursor": _cursor_0}};
  } else {
    return {$: "../src/ecs/removals.Rejected", "world": _world_0};
  }
}

function $$$$047src$047ecs$047world$058barrier$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047world$058drain_fifo$1260$(_pending_0, {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047src$047ecs$047schedule$058after_condition_skip$1261$(_next_0, _checked_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047src$047ecs$047schedule$058conditioned_skip$1261$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $$$$047experiments$047public$045schedule$045readers$047operations$058condition$(_world_0, _slot_0) {
  return $$$$047experiments$047public$045schedule$045readers$047operations$058condition_named$(_slot_0, ($$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058view$(_value_0) {
  const _value_1 = _value_0["value"];
  const _owned_0 = _value_0["owned"];
  const _x_0 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058numbers$(_owned_0));
  const _x_1 = ($U32$show$(_value_1));
  const _x_2 = (",\"owned\":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  return ("\"value\":" + _x_3);
}

function $$$$047src$047ecs$047component$058get_live_owned$1262$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047src$047ecs$047world$058with_store_finish$1262$(($$$$047src$047ecs$047component$058get_store$1262$(_id_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058take_queue$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047src$047ecs$047component$058define$1262$(_name_0) {
  return {$: "../src/ecs/component.Family", "name": _name_0};
}

function $$$$047src$047ecs$047world$058with_store_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047src$047ecs$047component$058get_store$1260$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047src$047ecs$047component$058get_projected$1260$(_rest_0, ($$$$047src$047ecs$047column$058view$1260$(_column_0, _id_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058take_stock$(_store_0) {
  const _stock_0 = _store_0["stock"];
  const _recipe_0 = _store_0["recipe"];
  const _queue_0 = _store_0["queue"];
  const _enabled_0 = _store_0["enabled"];
  const _locked_0 = _store_0["locked"];
  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/schema.StockRest", "recipe": _recipe_0, "queue": _queue_0, "enabled": _enabled_0, "locked": _locked_0}, "snd": _stock_0};
}

function $$$$047src$047ecs$047schedule$058after_condition_skip$1260$(_next_0, _checked_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047src$047ecs$047schedule$058conditioned_skip$1260$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $$$$047src$047ecs$047component$058replace_clock_advanced$1263$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047src$047ecs$047component$058replaced$1263$(($$$$047src$047ecs$047component$058swap_world$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047src$047ecs$047world$058advance_clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $$$$047src$047ecs$047world$058drain_fifo$1260$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047src$047ecs$047world$058drain_fifo$1260$(_rest_0, _world_0)));
  }
}

function $$$$047src$047ecs$047schedule$058conditioned_skip$1261$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (!_allowed_0) {
    return $$$$047src$047ecs$047schedule$058after_skip$1261$(_next_0, ($$$$047experiments$047public$045schedule$045readers$047added$045controls$058skip$(_owners_0, _world_0, _id_0)), ($List$append$(_observations_0, {$: "Con", "head": {$: "../src/ecs/schedule.Skipped", "id": _id_0}, "tail": {$: "Nil"}})));
  } else {
    return $$$$047src$047ecs$047schedule$058after_dispatch$1261$(_next_0, ($$$$047experiments$047public$045schedule$045readers$047added$045controls$058dispatch$(_owners_0, _world_0, _id_0)), _namespace_0, _name_0, _all_0, _observations_0, _id_0);
  }
}

function $$$$047experiments$047public$045schedule$045readers$047operations$058condition_named$(_slot_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047experiments$047public$045schedule$045readers$047operations$058condition_value$(_slot_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058get_enabled$(_world_0, ($$$$047experiments$047public$045schedule$045readers$047operations$058handle$(_namespace_0, 1)))));
}

function $$$$047src$047ecs$047world$058with_store_finish$1262$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047src$047ecs$047component$058get_store$1262$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047src$047ecs$047component$058get_projected$1262$(_rest_0, ($$$$047src$047ecs$047column$058view$1262$(_column_0, _id_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058take_queue$(_store_0) {
  const _stock_0 = _store_0["stock"];
  const _recipe_0 = _store_0["recipe"];
  const _queue_0 = _store_0["queue"];
  const _enabled_0 = _store_0["enabled"];
  const _locked_0 = _store_0["locked"];
  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/schema.QueueRest", "stock": _stock_0, "recipe": _recipe_0, "enabled": _enabled_0, "locked": _locked_0}, "snd": _queue_0};
}

function $$$$047src$047ecs$047component$058get_projected$1260$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047experiments$047public$045schedule$045readers$047schema$058put_stock$(_rest_0, _column_0)), "snd": ($$$$047src$047ecs$047component$058access$1260$(_value_0))};
}

function $$$$047src$047ecs$047column$058view$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, ($$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, ($$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047schedule$058conditioned_skip$1260$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (!_allowed_0) {
    return $$$$047src$047ecs$047schedule$058after_skip$1260$(_next_0, ($$$$047experiments$047public$045schedule$045readers$047driver$058skip$(_owners_0, _world_0, _id_0)), ($List$append$(_observations_0, {$: "Con", "head": {$: "../src/ecs/schedule.Skipped", "id": _id_0}, "tail": {$: "Nil"}})));
  } else {
    return $$$$047src$047ecs$047schedule$058after_dispatch$1260$(_next_0, ($$$$047experiments$047public$045schedule$045readers$047driver$058dispatch$(_owners_0, _world_0, _id_0)), _namespace_0, _name_0, _all_0, _observations_0, _id_0);
  }
}

function $$$$047src$047ecs$047component$058replaced$1263$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047src$047ecs$047component$058swap_world$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047world$058with_store_finish$1268$(($$$$047src$047ecs$047component$058swap_store$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058take_enabled$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047src$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047src$047ecs$047schedule$058after_skip$1261$(_next_0, _returned_0, _observations_0) {
  const _owners_0 = _returned_0["fst"];
  const _world_0 = _returned_0["snd"];
  return run_tail(_next_0(_owners_0)(_world_0), _observations_0);
}

function $$$$047experiments$047public$045schedule$045readers$047added$045controls$058skip$(_owners_0, _world_0, _id_0) {
  return {$: "Tuple", "fst": _owners_0, "snd": _world_0};
}

function $$$$047src$047ecs$047schedule$058after_dispatch$1261$(_next_0, _result_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _owners_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return $$$$047src$047ecs$047schedule$058after_outcome$1261$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $$$$047experiments$047public$045schedule$045readers$047added$045controls$058dispatch$(_owners_0, _world_0, _id_0) {
  const _base_0 = _owners_0["base"];
  const _t_0 = _owners_0["reader"];
  if (_t_0.$ === "../experiments/public-schedule-readers/driver.Occupied") {
    const _reader_0 = _t_0["owner"];
    const _own_0 = _owners_0["own"];
    if (_id_0 == 100) {
      return $$$$047experiments$047public$045schedule$045readers$047added$045controls$058identified$(_base_0, _own_0, _world_0, ($$$$047src$047ecs$047system$058cursor$1261$(_reader_0)));
    } else {
      const _28_0 = u32_to_word(_id_0)["head"];
      const _29_0 = u32_to_word(_id_0)["tail"];
      return $$$$047experiments$047public$045schedule$045readers$047added$045controls$058forwarded$({$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _reader_0}, _own_0, ($$$$047experiments$047public$045schedule$045readers$047driver$058dispatch$(_base_0, _world_0, word_to_u32({$: "WCon", "head": _28_0, "tail": _29_0}))));
    }
  } else {
    const _own_1 = _owners_0["own"];
    return $$$$047experiments$047public$045schedule$045readers$047added$045controls$058forwarded$(_t_0, _own_1, ($$$$047experiments$047public$045schedule$045readers$047driver$058dispatch$(_base_0, _world_0, _id_0)));
  }
}

function $$$$047experiments$047public$045schedule$045readers$047operations$058condition_value$(_slot_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../src/ecs/component.Found") {
    return {$: "Tuple", "fst": _world_0, "snd": true};
  } else {
    return {$: "Tuple", "fst": _world_0, "snd": (_slot_0 === 1)};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058get_enabled$(_world_0, _handle_0) {
  return $$$$047src$047ecs$047component$058get$1263$(($$$$047experiments$047public$045schedule$045readers$047schema$058enabled$()), _world_0, _handle_0);
}

function $$$$047src$047ecs$047component$058get_projected$1262$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047experiments$047public$045schedule$045readers$047schema$058put_queue$(_rest_0, _column_0)), "snd": ($$$$047src$047ecs$047component$058access$1262$(_value_0))};
}

function $$$$047src$047ecs$047column$058view$1262$(_column_0, _id_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058plain_view_sized$1262$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058prepared_view_state$1262$(_id_0, ($$$$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_view_state$1262$(_id_0, ($$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_view_state$1262$(_id_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
  }
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058put_stock$(_rest_0, _column_0) {
  const _recipe_0 = _rest_0["recipe"];
  const _queue_0 = _rest_0["queue"];
  const _enabled_0 = _rest_0["enabled"];
  const _locked_0 = _rest_0["locked"];
  return {$: "../experiments/public-schedule-readers/schema.Store", "stock": _column_0, "recipe": _recipe_0, "queue": _queue_0, "enabled": _enabled_0, "locked": _locked_0};
}

function $$$$047src$047ecs$047component$058access$1260$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "../src/ecs/component.ComponentAbsent"};
  } else {
    const _value_1 = _value_0["value"];
    return {$: "../src/ecs/component.Found", "value": _value_1};
  }
}

function $$$$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047src$047ecs$047column$058unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047src$047ecs$047column$058indexed_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047schedule$058after_skip$1260$(_next_0, _returned_0, _observations_0) {
  const _owners_0 = _returned_0["fst"];
  const _world_0 = _returned_0["snd"];
  return run_tail(_next_0(_owners_0)(_world_0), _observations_0);
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058skip$(_owners_0, _world_0, _id_0) {
  const _t_0 = _owners_0["events"];
  if (_t_0.$ === "../experiments/public-schedule-readers/driver.Occupied") {
    const _events_0 = _t_0["owner"];
    const _fast_0 = _owners_0["fast"];
    const _slow_0 = _owners_0["slow"];
    const _cf_0 = _owners_0["changeFast"];
    const _cs_0 = _owners_0["changeSlow"];
    const _rf_0 = _owners_0["removalFast"];
    const _rs_0 = _owners_0["removalSlow"];
    const _op_0 = _owners_0["operation"];
    const _config_0 = _owners_0["config"];
    const _reads_0 = _owners_0["reads"];
    if (_id_0 == 4) {
      return $$$$047experiments$047public$045schedule$045readers$047driver$058skip_collected$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Empty"}, "fast": _fast_0, "slow": _slow_0, "changeFast": _cf_0, "changeSlow": _cs_0, "removalFast": _rf_0, "removalSlow": _rs_0, "operation": _op_0, "config": _config_0, "reads": _reads_0}, ($$$$047src$047ecs$047reader$045domains$058collect$1260$(_events_0, _world_0)));
    } else {
      return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": _fast_0, "slow": _slow_0, "changeFast": _cf_0, "changeSlow": _cs_0, "removalFast": _rf_0, "removalSlow": _rs_0, "operation": _op_0, "config": _config_0, "reads": _reads_0}, "snd": _world_0};
    }
  } else {
    const _fast_1 = _owners_0["fast"];
    const _slow_1 = _owners_0["slow"];
    const _cf_1 = _owners_0["changeFast"];
    const _cs_1 = _owners_0["changeSlow"];
    const _rf_1 = _owners_0["removalFast"];
    const _rs_1 = _owners_0["removalSlow"];
    const _op_1 = _owners_0["operation"];
    const _config_1 = _owners_0["config"];
    const _reads_1 = _owners_0["reads"];
    return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": _t_0, "fast": _fast_1, "slow": _slow_1, "changeFast": _cf_1, "changeSlow": _cs_1, "removalFast": _rf_1, "removalSlow": _rs_1, "operation": _op_1, "config": _config_1, "reads": _reads_1}, "snd": _world_0};
  }
}

function $$$$047src$047ecs$047schedule$058after_dispatch$1260$(_next_0, _result_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _owners_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return $$$$047src$047ecs$047schedule$058after_outcome$1260$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058dispatch$(_owners_0, _world_0, _id_0) {
  const _t_0 = _owners_0["events"];
  if (_t_0.$ === "../experiments/public-schedule-readers/driver.Occupied") {
    const _events_0 = _t_0["owner"];
    const _fast_0 = _owners_0["fast"];
    const _slow_0 = _owners_0["slow"];
    const _cf_0 = _owners_0["changeFast"];
    const _cs_0 = _owners_0["changeSlow"];
    const _rf_0 = _owners_0["removalFast"];
    const _rs_0 = _owners_0["removalSlow"];
    const _op_0 = _owners_0["operation"];
    const _config_0 = _owners_0["config"];
    const _reads_0 = _owners_0["reads"];
    return $$$$047src$047ecs$047reader$045domains$058drive$1260$(_events_0, {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Empty"}, "fast": _fast_0, "slow": _slow_0, "changeFast": _cf_0, "changeSlow": _cs_0, "removalFast": _rf_0, "removalSlow": _rs_0, "operation": _op_0, "config": _config_0, "reads": _reads_0}, "snd": _id_0}, _world_0);
  } else {
    const _fast_1 = _owners_0["fast"];
    const _slow_1 = _owners_0["slow"];
    const _cf_1 = _owners_0["changeFast"];
    const _cs_1 = _owners_0["changeSlow"];
    const _rf_1 = _owners_0["removalFast"];
    const _rs_1 = _owners_0["removalSlow"];
    const _op_1 = _owners_0["operation"];
    const _config_1 = _owners_0["config"];
    const _reads_1 = _owners_0["reads"];
    return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": _t_0, "fast": _fast_1, "slow": _slow_1, "changeFast": _cf_1, "changeSlow": _cs_1, "removalFast": _rf_1, "removalSlow": _rs_1, "operation": _op_1, "config": _config_1, "reads": _reads_1}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("dispatch-domain"))}};
  }
}

function $$$$047src$047ecs$047world$058with_store_finish$1268$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047src$047ecs$047component$058swap_store$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047src$047ecs$047component$058swap_join$1263$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047src$047ecs$047column$058swap$1263$(($$$$047src$047ecs$047column$058ensure$1263$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058take_enabled$(_store_0) {
  const _stock_0 = _store_0["stock"];
  const _recipe_0 = _store_0["recipe"];
  const _queue_0 = _store_0["queue"];
  const _enabled_0 = _store_0["enabled"];
  const _locked_0 = _store_0["locked"];
  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/schema.EnabledRest", "stock": _stock_0, "recipe": _recipe_0, "queue": _queue_0, "locked": _locked_0}, "snd": _enabled_0};
}

function $$$$047src$047ecs$047schedule$058after_outcome$1261$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (_outcome_0.$ === "../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../src/ecs/schedule.Failed", "schedule": {$: "../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "error": _error_0, "observations": ($List$append$(_observations_0, {$: "Con", "head": {$: "../src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}}))};
  } else {
    const _world_1 = _outcome_0["world"];
    return run_tail(_next_0(_owners_0)(_world_1), ($List$append$(_observations_0, {$: "Con", "head": {$: "../src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}})));
  }
}

function $$$$047experiments$047public$045schedule$045readers$047added$045controls$058identified$(_base_0, _own_0, _world_0, _identified_0) {
  const _registry_0 = _identified_0["fst"];
  const _cursor_0 = _identified_0["snd"];
  return $$$$047experiments$047public$045schedule$045readers$047added$045controls$058completed$(_base_0, _own_0, ($$$$047src$047ecs$047system$058run_tracked$1261$(_registry_0, _world_0, {$: "../experiments/public-schedule-readers/consumers.ReadArgs", "name": "change-added", "fail": false, "own": _own_0, "cursor": _cursor_0})));
}

function $$$$047src$047ecs$047system$058cursor$1261$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _cursor_0};
}

function $$$$047experiments$047public$045schedule$045readers$047added$045controls$058forwarded$(_reader_0, _own_0, _result_0) {
  const _base_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/added-controls.Owners", "base": _base_0, "reader": _reader_0, "own": _own_0}, "snd": _outcome_0};
}

function $$$$047src$047ecs$047component$058get$1263$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047src$047ecs$047component$058get_live_owned$1263$(_id_0, ($$$$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058put_queue$(_rest_0, _column_0) {
  const _stock_0 = _rest_0["stock"];
  const _recipe_0 = _rest_0["recipe"];
  const _enabled_0 = _rest_0["enabled"];
  const _locked_0 = _rest_0["locked"];
  return {$: "../experiments/public-schedule-readers/schema.Store", "stock": _stock_0, "recipe": _recipe_0, "queue": _column_0, "enabled": _enabled_0, "locked": _locked_0};
}

function $$$$047src$047ecs$047component$058access$1262$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "../src/ecs/component.ComponentAbsent"};
  } else {
    const _value_1 = _value_0["value"];
    return {$: "../src/ecs/component.Found", "value": _value_1};
  }
}

function $$$$047src$047ecs$047column$058plain_view_sized$1262$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058plain_view_checked$1262$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058prepared_view_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058prepared_view_checked$1262$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047src$047ecs$047column$058unseal$1262$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_view_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_view_sized$1262$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047src$047ecs$047column$058indexed_unseal$1262$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_prepared_view_checked$1262$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058skip_collected$(_owners_0, _result_0) {
  const _fast_0 = _owners_0["fast"];
  const _slow_0 = _owners_0["slow"];
  const _cf_0 = _owners_0["changeFast"];
  const _cs_0 = _owners_0["changeSlow"];
  const _rf_0 = _owners_0["removalFast"];
  const _rs_0 = _owners_0["removalSlow"];
  const _op_0 = _owners_0["operation"];
  const _config_0 = _owners_0["config"];
  const _reads_0 = _owners_0["reads"];
  const _world_0 = _result_0["world"];
  const _events_0 = _result_0["events"];
  return $$$$047experiments$047public$045schedule$045readers$047driver$058skip_event$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": _fast_0, "slow": _slow_0, "changeFast": _cf_0, "changeSlow": _cs_0, "removalFast": _rf_0, "removalSlow": _rs_0, "operation": _op_0, "config": _config_0, "reads": _reads_0}, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
}

function $$$$047src$047ecs$047schedule$058after_outcome$1260$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (_outcome_0.$ === "../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../src/ecs/schedule.Failed", "schedule": {$: "../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "error": _error_0, "observations": ($List$append$(_observations_0, {$: "Con", "head": {$: "../src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}}))};
  } else {
    const _world_1 = _outcome_0["world"];
    return run_tail(_next_0(_owners_0)(_world_1), ($List$append$(_observations_0, {$: "Con", "head": {$: "../src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}})));
  }
}

function $$$$047src$047ecs$047reader$045domains$058drive$1260$(_events_0, _owners_0, _world_0) {
  return $$$$047src$047ecs$047reader$045domains$058driven$1260$(_owners_0, ($$$$047src$047ecs$047reader$045domains$058collect$1260$(_events_0, _world_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058invalid$(_text_0) {
  return {$: "../experiments/public-schedule-readers/consumers.Failed", "observation": ("invalid-owner-slot:" + _text_0)};
}

function $$$$047src$047ecs$047component$058swap_join$1263$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047src$047ecs$047component$058mark_swapped$1263$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047src$047ecs$047component$058owner_present$1263$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($$$$047experiments$047public$045schedule$045readers$047schema$058put_enabled$(_rest_0, _column_1)), "snd": {$: "../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047src$047ecs$047column$058swap$1263$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058swap_sized$1263$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058swap_state$1263$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_swap_state$1263$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_swap_state$1263$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058ensure$1263$(_column_0, _target_0) {
  return $$$$047src$047ecs$047column$058ensure_checked$1263$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047experiments$047public$045schedule$045readers$047added$045controls$058completed$(_base_0, _own_0, _result_0) {
  if (_result_0.$ === "../src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _t_0 = _result_0["outcome"];
    if (_t_0.$ === "../src/ecs/system.Succeeded") {
      const _world_0 = _t_0["world"];
      const _text_0 = _t_0["output"];
      return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/added-controls.Owners", "base": ($$$$047experiments$047public$045schedule$045readers$047added$045controls$058append$(_base_0, _text_0)), "reader": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _registry_0}, "own": _own_0}, "snd": {$: "../src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}}};
    } else {
      const _world_1 = _t_0["world"];
      const _t_1 = _t_0["error"];
      const _text_1 = _t_1["observation"];
      return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/added-controls.Owners", "base": ($$$$047experiments$047public$045schedule$045readers$047added$045controls$058append$(_base_0, _text_1)), "reader": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _registry_0}, "own": _own_0}, "snd": {$: "../src/ecs/system.Failed", "world": _world_1, "error": {$: "../experiments/public-schedule-readers/consumers.Failed", "observation": _text_1}}};
    }
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_2 = _result_0["world"];
    return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/added-controls.Owners", "base": _base_0, "reader": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _registry_1}, "own": _own_0}, "snd": {$: "../src/ecs/system.Failed", "world": _world_2, "error": {$: "../experiments/public-schedule-readers/consumers.Failed", "observation": "added-rejected"}}};
  }
}

function $$$$047src$047ecs$047system$058run_tracked$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047src$047ecs$047system$058tracked_result$1261$(($$$$047src$047ecs$047system$058run$1263$(_registry_0, _world_0, _args_0)));
}

function $$$$047src$047ecs$047component$058get_live_owned$1263$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047src$047ecs$047world$058with_store_finish$1263$(($$$$047src$047ecs$047component$058get_store$1263$(_id_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058take_enabled$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047src$047ecs$047column$058plain_view_checked$1262$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047src$047ecs$047column$058plain_view_taken$1262$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047src$047ecs$047column$058prepared_view_checked$1262$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047src$047ecs$047column$058prepared_view_current$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047src$047ecs$047column$058prepared_view_different$1262$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_view_sized$1262$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_view_checked$1262$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_checked$1262$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047src$047ecs$047column$058indexed_prepared_view_current$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047src$047ecs$047column$058indexed_prepared_view_different$1262$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058project_stock$(_owner_0)));
  }
}

function $$$$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058project_stock$(_owned_0)));
  }
}

function $$$$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047src$047ecs$047column$058seek_view$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
  }
}

function $$$$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058project_stock$(_owned_0)));
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047src$047ecs$047column$058indexed_seek_view$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
  }
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058skip_event$(_owners_0, _observed_0) {
  const _t_0 = _owners_0["events"];
  if (_t_0.$ === "../experiments/public-schedule-readers/driver.Occupied") {
    const _events_0 = _t_0["owner"];
    const _t_1 = _owners_0["fast"];
    if (_t_1.$ === "../experiments/public-schedule-readers/driver.Occupied") {
      const _t_2 = _t_1["owner"];
      const _reader_0 = _t_2["reader"];
      const _registry_0 = _t_2["registry"];
      const _t_3 = _owners_0["slow"];
      if (_t_3.$ === "../experiments/public-schedule-readers/driver.Occupied") {
        const _slow_0 = _t_3["owner"];
        const _t_4 = _owners_0["changeFast"];
        if (_t_4.$ === "../experiments/public-schedule-readers/driver.Occupied") {
          const _cf_0 = _t_4["owner"];
          const _t_5 = _owners_0["changeSlow"];
          if (_t_5.$ === "../experiments/public-schedule-readers/driver.Occupied") {
            const _cs_0 = _t_5["owner"];
            const _t_6 = _owners_0["removalFast"];
            if (_t_6.$ === "../experiments/public-schedule-readers/driver.Occupied") {
              const _rf_0 = _t_6["owner"];
              const _t_7 = _owners_0["removalSlow"];
              if (_t_7.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                const _rs_0 = _t_7["owner"];
                const _t_8 = _owners_0["operation"];
                if (_t_8.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                  const _op_0 = _t_8["owner"];
                  const _config_0 = _owners_0["config"];
                  const _reads_0 = _owners_0["reads"];
                  const _world_0 = _observed_0["fst"];
                  const _removals_0 = _observed_0["snd"];
                  return $$$$047experiments$047public$045schedule$045readers$047driver$058skipped_runtime$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Empty"}, "fast": {$: "../experiments/public-schedule-readers/driver.Empty"}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _op_0}, "config": _config_0, "reads": _reads_0}, _registry_0, _removals_0, ($$$$047src$047ecs$047event$045runtime$058skip$1260$(($$$$047src$047ecs$047reader$045domains$058attach$1260$(_events_0, _world_0)), _reader_0)));
                } else {
                  const _config_1 = _owners_0["config"];
                  const _reads_1 = _owners_0["reads"];
                  const _world_1 = _observed_0["fst"];
                  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": {$: "../experiments/public-schedule-readers/driver.EventOwner", "reader": _reader_0, "registry": _registry_0}}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": _t_8, "config": _config_1, "reads": _reads_1}, "snd": _world_1};
                }
              } else {
                const _46_0 = _owners_0["operation"];
                const _config_2 = _owners_0["config"];
                const _reads_2 = _owners_0["reads"];
                const _world_2 = _observed_0["fst"];
                return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": {$: "../experiments/public-schedule-readers/driver.EventOwner", "reader": _reader_0, "registry": _registry_0}}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": _t_7, "operation": _46_0, "config": _config_2, "reads": _reads_2}, "snd": _world_2};
              }
            } else {
              const _45_0 = _owners_0["removalSlow"];
              const _46_1 = _owners_0["operation"];
              const _config_3 = _owners_0["config"];
              const _reads_3 = _owners_0["reads"];
              const _world_3 = _observed_0["fst"];
              return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": {$: "../experiments/public-schedule-readers/driver.EventOwner", "reader": _reader_0, "registry": _registry_0}}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": _t_6, "removalSlow": _45_0, "operation": _46_1, "config": _config_3, "reads": _reads_3}, "snd": _world_3};
            }
          } else {
            const _44_0 = _owners_0["removalFast"];
            const _45_1 = _owners_0["removalSlow"];
            const _46_2 = _owners_0["operation"];
            const _config_4 = _owners_0["config"];
            const _reads_4 = _owners_0["reads"];
            const _world_4 = _observed_0["fst"];
            return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": {$: "../experiments/public-schedule-readers/driver.EventOwner", "reader": _reader_0, "registry": _registry_0}}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": _t_5, "removalFast": _44_0, "removalSlow": _45_1, "operation": _46_2, "config": _config_4, "reads": _reads_4}, "snd": _world_4};
          }
        } else {
          const _43_0 = _owners_0["changeSlow"];
          const _44_1 = _owners_0["removalFast"];
          const _45_2 = _owners_0["removalSlow"];
          const _46_3 = _owners_0["operation"];
          const _config_5 = _owners_0["config"];
          const _reads_5 = _owners_0["reads"];
          const _world_5 = _observed_0["fst"];
          return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": {$: "../experiments/public-schedule-readers/driver.EventOwner", "reader": _reader_0, "registry": _registry_0}}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": _t_4, "changeSlow": _43_0, "removalFast": _44_1, "removalSlow": _45_2, "operation": _46_3, "config": _config_5, "reads": _reads_5}, "snd": _world_5};
        }
      } else {
        const _42_0 = _owners_0["changeFast"];
        const _43_1 = _owners_0["changeSlow"];
        const _44_2 = _owners_0["removalFast"];
        const _45_3 = _owners_0["removalSlow"];
        const _46_4 = _owners_0["operation"];
        const _config_6 = _owners_0["config"];
        const _reads_6 = _owners_0["reads"];
        const _world_6 = _observed_0["fst"];
        return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": {$: "../experiments/public-schedule-readers/driver.EventOwner", "reader": _reader_0, "registry": _registry_0}}, "slow": _t_3, "changeFast": _42_0, "changeSlow": _43_1, "removalFast": _44_2, "removalSlow": _45_3, "operation": _46_4, "config": _config_6, "reads": _reads_6}, "snd": _world_6};
      }
    } else {
      const _41_0 = _owners_0["slow"];
      const _42_1 = _owners_0["changeFast"];
      const _43_2 = _owners_0["changeSlow"];
      const _44_3 = _owners_0["removalFast"];
      const _45_4 = _owners_0["removalSlow"];
      const _46_5 = _owners_0["operation"];
      const _config_7 = _owners_0["config"];
      const _reads_7 = _owners_0["reads"];
      const _world_7 = _observed_0["fst"];
      return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": _t_1, "slow": _41_0, "changeFast": _42_1, "changeSlow": _43_2, "removalFast": _44_3, "removalSlow": _45_4, "operation": _46_5, "config": _config_7, "reads": _reads_7}, "snd": _world_7};
    }
  } else {
    const _40_0 = _owners_0["fast"];
    const _41_1 = _owners_0["slow"];
    const _42_2 = _owners_0["changeFast"];
    const _43_3 = _owners_0["changeSlow"];
    const _44_4 = _owners_0["removalFast"];
    const _45_5 = _owners_0["removalSlow"];
    const _46_6 = _owners_0["operation"];
    const _config_8 = _owners_0["config"];
    const _reads_8 = _owners_0["reads"];
    const _world_8 = _observed_0["fst"];
    return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": _t_0, "fast": _40_0, "slow": _41_1, "changeFast": _42_2, "changeSlow": _43_3, "removalFast": _44_4, "removalSlow": _45_5, "operation": _46_6, "config": _config_8, "reads": _reads_8}, "snd": _world_8};
  }
}

function $$$$047src$047ecs$047reader$045domains$058driven$1260$(_owners_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _events_0 = _result_0["events"];
  return $$$$047experiments$047public$045schedule$045readers$047driver$058domain_dispatch$(_events_0, _owners_0, _world_0);
}

function $$$$047src$047ecs$047component$058mark_swapped$1263$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047experiments$047public$045schedule$045readers$047schema$058put_enabled$(_rest_0, ($$$$047src$047ecs$047column$058mark$1263$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058put_enabled$(_rest_0, _column_0) {
  const _stock_0 = _rest_0["stock"];
  const _recipe_0 = _rest_0["recipe"];
  const _queue_0 = _rest_0["queue"];
  const _locked_0 = _rest_0["locked"];
  return {$: "../experiments/public-schedule-readers/schema.Store", "stock": _stock_0, "recipe": _recipe_0, "queue": _queue_0, "enabled": _column_0, "locked": _locked_0};
}

function $$$$047src$047ecs$047column$058swap_sized$1263$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047src$047ecs$047column$058swap_checked$1263$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058swap_state$1263$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058prepared_swap$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047src$047ecs$047column$058unseal$1263$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_swap_state$1263$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_swap_sized$1263$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047src$047ecs$047column$058indexed_unseal$1263$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_swap_state$1263$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_prepared_swap$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047src$047ecs$047column$058indexed_prepared_unseal$1263$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058ensure_checked$1263$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047src$047ecs$047column$058ensure_sized$1263$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047src$047ecs$047column$058ensure_state$1263$(_target_0, ($$$$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
    }
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047src$047ecs$047column$058indexed_ensure_state$1263$(_target_0, ($$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1263$(_target_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
    }
  }
}

function $$$$047experiments$047public$045schedule$045readers$047added$045controls$058append$(_base_0, _text_0) {
  const _events_0 = _base_0["events"];
  const _fast_0 = _base_0["fast"];
  const _slow_0 = _base_0["slow"];
  const _cf_0 = _base_0["changeFast"];
  const _cs_0 = _base_0["changeSlow"];
  const _rf_0 = _base_0["removalFast"];
  const _rs_0 = _base_0["removalSlow"];
  const _op_0 = _base_0["operation"];
  const _config_0 = _base_0["config"];
  const _reads_0 = _base_0["reads"];
  return {$: "../experiments/public-schedule-readers/driver.Owners", "events": _events_0, "fast": _fast_0, "slow": _slow_0, "changeFast": _cf_0, "changeSlow": _cs_0, "removalFast": _rf_0, "removalSlow": _rs_0, "operation": _op_0, "config": _config_0, "reads": ($$$$047experiments$047public$045schedule$045readers$047driver$058append_read$(_reads_0, _text_0))};
}

function $$$$047src$047ecs$047system$058tracked_result$1261$(_result_0) {
  if (_result_0.$ === "../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047src$047ecs$047system$058tracked_outcome$1261$(_registry_1, _outcome_0);
  }
}

function $$$$047src$047ecs$047system$058run$1263$(_registry_0, _world_0, _args_0) {
  return $$$$047src$047ecs$047system$058run_namespace$1263$(_registry_0, ($$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047src$047ecs$047world$058with_store_finish$1263$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047src$047ecs$047component$058get_store$1263$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047src$047ecs$047component$058get_projected$1263$(_rest_0, ($$$$047src$047ecs$047column$058view$1263$(_column_0, _id_0)));
}

function $$$$047src$047ecs$047column$058plain_view_taken$1262$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047src$047ecs$047column$058plain_view_projected$1262$(_values_0, _stamps_0, _id_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058project_queue$(_owner_0)));
  }
}

function $$$$047src$047ecs$047column$058prepared_view_current$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047src$047ecs$047column$058prepared_view_projected$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058project_queue$(_owned_0)));
  }
}

function $$$$047src$047ecs$047column$058prepared_view_different$1262$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047src$047ecs$047column$058view_taken$1262$(_id_0, ($$$$047src$047ecs$047column$058swap_recovered$1262$(_id_0, {$: "None"}, ($$$$047src$047ecs$047column$058recover_current$1262$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047src$047ecs$047column$058seek_view$1262$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1262$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
  }
}

function $$$$047src$047ecs$047column$058indexed_view_checked$1262$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047src$047ecs$047column$058indexed_view_taken$1262$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_current$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047src$047ecs$047column$058indexed_prepared_view_projected$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058project_queue$(_owned_0)));
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_different$1262$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047src$047ecs$047column$058view_taken$1262$(_id_0, ($$$$047src$047ecs$047column$058swap_recovered$1262$(_id_0, {$: "None"}, ($$$$047src$047ecs$047column$058indexed_recover_current$1262$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047src$047ecs$047column$058indexed_seek_view$1262$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1262$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
  }
}

function $$$$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058project_stock$(_owner_0) {
  const _value_0 = _owner_0["value"];
  const _array_0 = _owner_0["owned"];
  const _length_0 = _owner_0["length"];
  return $$$$047experiments$047public$045schedule$045readers$047schema$058project_stock_join$(_value_0, _length_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058array_view$(_array_0)));
}

function $$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047src$047ecs$047column$058view_taken$1260$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047src$047ecs$047column$058viewed$1260$(($$$$047experiments$047public$045schedule$045readers$047schema$058project_stock$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return {$: "../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../src/ecs/column.Column", "values": ($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../src/ecs/column.Column", "values": ($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047src$047ecs$047column$058seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058project_stock$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0) {
  return {$: "../src/ecs/column.Indexed", "state": {$: "../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058project_stock$(_owner_0)));
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047src$047ecs$047column$058indexed_seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058project_stock$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058skipped_runtime$(_owners_0, _registry_0, _removals_0, _result_0) {
  const _runtime_0 = _result_0["fst"];
  const _reader_0 = _result_0["snd"];
  return $$$$047experiments$047public$045schedule$045readers$047driver$058skipped_detached$(_owners_0, _registry_0, _reader_0, ($$$$047src$047ecs$047reader$045domains$058detach$1260$(_runtime_0, _removals_0)));
}

function $$$$047src$047ecs$047event$045runtime$058skip$1260$(_runtime_0, _reader_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  const _readerNamespace_0 = _reader_0["namespace"];
  const _id_0 = _reader_0["id"];
  const _expected_0 = _reader_0["registryId"];
  return $$$$047src$047ecs$047event$045runtime$058skip_checked$1260$((_namespace_0 === _readerNamespace_0), {$: "../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, {$: "../src/ecs/event-runtime.Reader", "namespace": _readerNamespace_0, "id": _id_0, "registryId": _expected_0}, _id_0);
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058domain_dispatch$(_events_0, _args_0, _world_0) {
  const _t_0 = _args_0["fst"];
  const _fast_0 = _t_0["fast"];
  const _slow_0 = _t_0["slow"];
  const _cf_0 = _t_0["changeFast"];
  const _cs_0 = _t_0["changeSlow"];
  const _rf_0 = _t_0["removalFast"];
  const _rs_0 = _t_0["removalSlow"];
  const _op_0 = _t_0["operation"];
  const _config_0 = _t_0["config"];
  const _reads_0 = _t_0["reads"];
  const _id_0 = _args_0["snd"];
  return $$$$047experiments$047public$045schedule$045readers$047driver$058dispatch_value$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": _fast_0, "slow": _slow_0, "changeFast": _cf_0, "changeSlow": _cs_0, "removalFast": _rf_0, "removalSlow": _rs_0, "operation": _op_0, "config": _config_0, "reads": _reads_0}, _world_0, _id_0);
}

function $$$$047src$047ecs$047column$058mark$1263$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058swap_checked$1263$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047src$047ecs$047column$058swapped$1263$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047src$047ecs$047column$058prepared_swap$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047src$047ecs$047column$058swap_recovered$1263$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058recover$1263$({$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047src$047ecs$047column$058seek$1263$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1263$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_swap_sized$1263$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_swap_checked$1263$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058indexed_prepared_swap$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047src$047ecs$047column$058swap_recovered$1263$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058recover$1263$({$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047src$047ecs$047column$058indexed_seek$1263$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1263$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047src$047ecs$047column$058ensure_sized$1263$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047src$047ecs$047column$058grow$1263$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047src$047ecs$047column$058ensure_state$1263$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058ensure_prepared$1263$(_target_0, {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047src$047ecs$047column$058indexed_ensure_state$1263$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_ensure_sized$1263$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1263$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058ensure_prepared$1263$(_target_0, {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058append_read$(_reads_0, _text_0) {
  return $List$append$(_reads_0, ($$$$047experiments$047public$045schedule$045readers$047driver$058empty_read$(_text_0)));
}

function $$$$047src$047ecs$047system$058tracked_outcome$1261$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, ($$$$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047src$047ecs$047system$058run_namespace$1263$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047src$047ecs$047system$058run_namespace_value$1263$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047src$047ecs$047component$058get_projected$1263$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047experiments$047public$045schedule$045readers$047schema$058put_enabled$(_rest_0, _column_0)), "snd": ($$$$047src$047ecs$047component$058access$1263$(_value_0))};
}

function $$$$047src$047ecs$047column$058view$1263$(_column_0, _id_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058plain_view_sized$1263$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058prepared_view_state$1263$(_id_0, ($$$$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_view_state$1263$(_id_0, ($$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_view_state$1263$(_id_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058plain_view_projected$1262$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047src$047ecs$047column$058restored$1262$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058project_queue$(_owner_0) {
  const _value_0 = _owner_0["value"];
  const _array_0 = _owner_0["owned"];
  const _length_0 = _owner_0["length"];
  return $$$$047experiments$047public$045schedule$045readers$047schema$058project_queue_join$(_value_0, _length_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058array_view$(_array_0)));
}

function $$$$047src$047ecs$047column$058prepared_view_projected$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047src$047ecs$047column$058view_taken$1262$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047src$047ecs$047column$058viewed$1262$(($$$$047experiments$047public$045schedule$045readers$047schema$058project_queue$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047src$047ecs$047column$058swap_recovered$1262$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058swap_sized$1262$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_swap_state$1262$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_0)));
  } else {
    return {$: "../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047src$047ecs$047column$058recover_current$1262$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../src/ecs/column.Column", "values": ($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1262$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../src/ecs/column.Column", "values": ($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1262$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047src$047ecs$047column$058seek_view$1262$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047src$047ecs$047column$058prepared_view_projected$1262$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058project_queue$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058past_current$1262$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0) {
  return {$: "../src/ecs/column.Indexed", "state": {$: "../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047src$047ecs$047column$058indexed_view_taken$1262$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047src$047ecs$047column$058indexed_view_projected$1262$(_id_0, _values_0, _metadata_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058project_queue$(_owner_0)));
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_projected$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047src$047ecs$047column$058indexed_recover_current$1262$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047src$047ecs$047column$058indexed_wrap$1262$(($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1262$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047src$047ecs$047column$058indexed_wrap$1262$(($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1262$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047src$047ecs$047column$058indexed_seek_view$1262$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047src$047ecs$047column$058indexed_prepared_view_projected$1262$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058project_queue$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058restored$1260$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058project_stock_join$(_value_0, _length_0, _observed_0) {
  const _array_0 = _observed_0["fst"];
  const _values_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/schema.Stock", "value": _value_0, "owned": _array_0, "length": _length_0}, "snd": {$: "../experiments/public-schedule-readers/schema.StockView", "value": _value_0, "owned": ($$$$047experiments$047public$045schedule$045readers$047schema$058prefix$(_length_0, _values_0))}};
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058array_view$(_array_0) {
  if (_array_0.length === 1) {
    const _value_0 = _array_0[0];
    return {$: "Tuple", "fst": [_value_0], "snd": {$: "Con", "head": _value_0, "tail": {$: "Nil"}}};
  } else {
    const _left_0 = _array_0.slice(0, _array_0.length >> 1);
    const _right_0 = _array_0.slice(_array_0.length >> 1);
    return $$$$047experiments$047public$045schedule$045readers$047schema$058array_join$(($$$$047experiments$047public$045schedule$045readers$047schema$058array_view$(_left_0)), ($$$$047experiments$047public$045schedule$045readers$047schema$058array_view$(_right_0)));
  }
}

function $$$$047src$047ecs$047column$058viewed$1260$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047src$047ecs$047column$058swap$1260$({$: "../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047src$047ecs$047column$058swap$1260$({$: "../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047src$047ecs$047column$058recover_selected_rows$($0, $1) {
  for (;;) {
    {
      const _rows_0 = $0;
      const _values_0 = $1;
      if (_rows_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
        return _values_0;
      } else {
        const _id_0 = _rows_0["id"];
        const _owner_0 = _rows_0["owner"];
        const _rest_0 = _rows_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        const _x_1 = {$: "Some", "value": _owner_0};
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _x_1, _values_0);
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058recover_past$1260$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058skipped_detached$(_owners_0, _registry_0, _reader_0, _result_0) {
  const __0 = _owners_0["events"];
  const __1 = _owners_0["fast"];
  const _t_0 = _owners_0["slow"];
  if (_t_0.$ === "../experiments/public-schedule-readers/driver.Occupied") {
    const _slow_0 = _t_0["owner"];
    const _t_1 = _owners_0["changeFast"];
    if (_t_1.$ === "../experiments/public-schedule-readers/driver.Occupied") {
      const _cf_0 = _t_1["owner"];
      const _t_2 = _owners_0["changeSlow"];
      if (_t_2.$ === "../experiments/public-schedule-readers/driver.Occupied") {
        const _cs_0 = _t_2["owner"];
        const _t_3 = _owners_0["removalFast"];
        if (_t_3.$ === "../experiments/public-schedule-readers/driver.Occupied") {
          const _rf_0 = _t_3["owner"];
          const _t_4 = _owners_0["removalSlow"];
          if (_t_4.$ === "../experiments/public-schedule-readers/driver.Occupied") {
            const _rs_0 = _t_4["owner"];
            const _t_5 = _owners_0["operation"];
            if (_t_5.$ === "../experiments/public-schedule-readers/driver.Occupied") {
              const _op_0 = _t_5["owner"];
              const _config_0 = _owners_0["config"];
              const _reads_0 = _owners_0["reads"];
              const _world_0 = _result_0["world"];
              const _events_0 = _result_0["events"];
              return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": {$: "../experiments/public-schedule-readers/driver.EventOwner", "reader": _reader_0, "registry": _registry_0}}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _op_0}, "config": _config_0, "reads": _reads_0}, "snd": _world_0};
            } else {
              const _config_1 = _owners_0["config"];
              const _reads_1 = _owners_0["reads"];
              const _world_1 = _result_0["world"];
              return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": __1, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": _t_5, "config": _config_1, "reads": _reads_1}, "snd": _world_1};
            }
          } else {
            const _42_0 = _owners_0["operation"];
            const _config_2 = _owners_0["config"];
            const _reads_2 = _owners_0["reads"];
            const _world_2 = _result_0["world"];
            return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": __1, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": _t_4, "operation": _42_0, "config": _config_2, "reads": _reads_2}, "snd": _world_2};
          }
        } else {
          const _41_0 = _owners_0["removalSlow"];
          const _42_1 = _owners_0["operation"];
          const _config_3 = _owners_0["config"];
          const _reads_3 = _owners_0["reads"];
          const _world_3 = _result_0["world"];
          return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": __1, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": _t_3, "removalSlow": _41_0, "operation": _42_1, "config": _config_3, "reads": _reads_3}, "snd": _world_3};
        }
      } else {
        const _40_0 = _owners_0["removalFast"];
        const _41_1 = _owners_0["removalSlow"];
        const _42_2 = _owners_0["operation"];
        const _config_4 = _owners_0["config"];
        const _reads_4 = _owners_0["reads"];
        const _world_4 = _result_0["world"];
        return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": __1, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": _t_2, "removalFast": _40_0, "removalSlow": _41_1, "operation": _42_2, "config": _config_4, "reads": _reads_4}, "snd": _world_4};
      }
    } else {
      const _39_0 = _owners_0["changeSlow"];
      const _40_1 = _owners_0["removalFast"];
      const _41_2 = _owners_0["removalSlow"];
      const _42_3 = _owners_0["operation"];
      const _config_5 = _owners_0["config"];
      const _reads_5 = _owners_0["reads"];
      const _world_5 = _result_0["world"];
      return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": __1, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": _t_1, "changeSlow": _39_0, "removalFast": _40_1, "removalSlow": _41_2, "operation": _42_3, "config": _config_5, "reads": _reads_5}, "snd": _world_5};
    }
  } else {
    const _38_0 = _owners_0["changeFast"];
    const _39_1 = _owners_0["changeSlow"];
    const _40_2 = _owners_0["removalFast"];
    const _41_3 = _owners_0["removalSlow"];
    const _42_4 = _owners_0["operation"];
    const _config_6 = _owners_0["config"];
    const _reads_6 = _owners_0["reads"];
    const _world_6 = _result_0["world"];
    return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": __1, "slow": _t_0, "changeFast": _38_0, "changeSlow": _39_1, "removalFast": _40_2, "removalSlow": _41_3, "operation": _42_4, "config": _config_6, "reads": _reads_6}, "snd": _world_6};
  }
}

function $$$$047src$047ecs$047event$045runtime$058skip_checked$1260$(_allowed_0, _runtime_0, _reader_0, _id_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _runtime_0, "snd": _reader_0};
  } else {
    const _world_0 = _runtime_0["world"];
    const _namespace_0 = _runtime_0["namespace"];
    const _batches_0 = _runtime_0["batches"];
    const _positions_0 = _runtime_0["positions"];
    const _nextReader_0 = _runtime_0["nextReader"];
    const _tick_0 = _runtime_0["tick"];
    const _frameStart_0 = _runtime_0["frameStart"];
    const _boundary_0 = _runtime_0["boundary"];
    const _capacity_0 = _runtime_0["capacity"];
    const _dropped_0 = _runtime_0["droppedThrough"];
    return {$: "Tuple", "fst": {$: "../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": ($$$$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _tick_0, false)), "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "snd": _reader_0};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058dispatch_value$(_owners_0, _world_0, _id_0) {
  const _t_0 = _owners_0["events"];
  if (_t_0.$ === "../experiments/public-schedule-readers/driver.Occupied") {
    const _events_0 = _t_0["owner"];
    const _t_1 = _owners_0["fast"];
    if (_t_1.$ === "../experiments/public-schedule-readers/driver.Occupied") {
      const _fast_0 = _t_1["owner"];
      const _t_2 = _owners_0["slow"];
      if (_t_2.$ === "../experiments/public-schedule-readers/driver.Occupied") {
        const _slow_0 = _t_2["owner"];
        const _t_3 = _owners_0["changeFast"];
        if (_t_3.$ === "../experiments/public-schedule-readers/driver.Occupied") {
          const _cf_0 = _t_3["owner"];
          const _t_4 = _owners_0["changeSlow"];
          if (_t_4.$ === "../experiments/public-schedule-readers/driver.Occupied") {
            const _cs_0 = _t_4["owner"];
            const _t_5 = _owners_0["removalFast"];
            if (_t_5.$ === "../experiments/public-schedule-readers/driver.Occupied") {
              const _rf_0 = _t_5["owner"];
              const _t_6 = _owners_0["removalSlow"];
              if (_t_6.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                const _rs_0 = _t_6["owner"];
                const _t_7 = _owners_0["operation"];
                if (_t_7.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                  const _operation_0 = _t_7["owner"];
                  const _config_0 = _owners_0["config"];
                  const _reads_0 = _owners_0["reads"];
                  if (_id_0 == 4) {
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058event_read$(true, {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_0}, "config": _config_0, "reads": _reads_0}, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
                  } else if ((_id_0 & 7) == 4) {
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058op_completed$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Empty"}, "config": _config_0, "reads": _reads_0}, ($$$$047src$047ecs$047system$058run$1262$(_operation_0, _world_0, ($$$$047experiments$047public$045schedule$045readers$047driver$058config_request$(_config_0)))));
                  } else if (_id_0 == 8) {
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058removal_execute$(true, "removal-fast", {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Empty"}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_0}, "config": _config_0, "reads": _reads_0}, _rf_0, _world_0, ($$$$047experiments$047public$045schedule$045readers$047driver$058removal_config$(_config_0)));
                  } else if ((_id_0 & 7) == 0) {
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058op_completed$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Empty"}, "config": _config_0, "reads": _reads_0}, ($$$$047src$047ecs$047system$058run$1262$(_operation_0, _world_0, ($$$$047experiments$047public$045schedule$045readers$047driver$058config_request$(_config_0)))));
                  } else if (_id_0 == 6) {
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058change_run$(true, {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Empty"}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_0}, "config": _config_0, "reads": _reads_0}, _world_0, ($$$$047src$047ecs$047system$058cursor$1260$(_cf_0)));
                  } else if ((_id_0 & 3) == 2) {
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058op_completed$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Empty"}, "config": _config_0, "reads": _reads_0}, ($$$$047src$047ecs$047system$058run$1262$(_operation_0, _world_0, ($$$$047experiments$047public$045schedule$045readers$047driver$058config_request$(_config_0)))));
                  } else if (_id_0 == 5) {
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058event_read$(false, {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_0}, "config": _config_0, "reads": _reads_0}, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
                  } else if ((_id_0 & 7) == 5) {
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058op_completed$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Empty"}, "config": _config_0, "reads": _reads_0}, ($$$$047src$047ecs$047system$058run$1262$(_operation_0, _world_0, ($$$$047experiments$047public$045schedule$045readers$047driver$058config_request$(_config_0)))));
                  } else if (_id_0 == 9) {
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058removal_execute$(false, "removal-slow", {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Empty"}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_0}, "config": _config_0, "reads": _reads_0}, _rs_0, _world_0, ($$$$047experiments$047public$045schedule$045readers$047driver$058removal_config$(_config_0)));
                  } else if ((_id_0 & 7) == 1) {
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058op_completed$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Empty"}, "config": _config_0, "reads": _reads_0}, ($$$$047src$047ecs$047system$058run$1262$(_operation_0, _world_0, ($$$$047experiments$047public$045schedule$045readers$047driver$058config_request$(_config_0)))));
                  } else if (_id_0 == 7) {
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058change_run$(false, {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Empty"}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_0}, "config": _config_0, "reads": _reads_0}, _world_0, ($$$$047src$047ecs$047system$058cursor$1260$(_cs_0)));
                  } else {
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058op_completed$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Empty"}, "config": _config_0, "reads": _reads_0}, ($$$$047src$047ecs$047system$058run$1262$(_operation_0, _world_0, ($$$$047experiments$047public$045schedule$045readers$047driver$058config_request$(_config_0)))));
                  }
                } else {
                  const _config_1 = _owners_0["config"];
                  const _reads_1 = _owners_0["reads"];
                  if (_id_0 == 4) {
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058event_read$(true, {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": _t_7, "config": _config_1, "reads": _reads_1}, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
                  } else if ((_id_0 & 1) == 0) {
                    return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": _t_7, "config": _config_1, "reads": _reads_1}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("dispatch"))}};
                  } else if (_id_0 == 5) {
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058event_read$(false, {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": _t_7, "config": _config_1, "reads": _reads_1}, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
                  } else {
                    return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": _t_7, "config": _config_1, "reads": _reads_1}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("dispatch"))}};
                  }
                }
              } else {
                const _140_0 = _owners_0["operation"];
                const _config_2 = _owners_0["config"];
                const _reads_2 = _owners_0["reads"];
                if (_id_0 == 4) {
                  return $$$$047experiments$047public$045schedule$045readers$047driver$058event_read$(true, {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": _t_6, "operation": _140_0, "config": _config_2, "reads": _reads_2}, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
                } else if ((_id_0 & 1) == 0) {
                  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": _t_6, "operation": _140_0, "config": _config_2, "reads": _reads_2}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("dispatch"))}};
                } else if (_id_0 == 5) {
                  return $$$$047experiments$047public$045schedule$045readers$047driver$058event_read$(false, {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": _t_6, "operation": _140_0, "config": _config_2, "reads": _reads_2}, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
                } else {
                  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": _t_6, "operation": _140_0, "config": _config_2, "reads": _reads_2}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("dispatch"))}};
                }
              }
            } else {
              const _139_0 = _owners_0["removalSlow"];
              const _140_1 = _owners_0["operation"];
              const _config_3 = _owners_0["config"];
              const _reads_3 = _owners_0["reads"];
              if (_id_0 == 4) {
                return $$$$047experiments$047public$045schedule$045readers$047driver$058event_read$(true, {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": _t_5, "removalSlow": _139_0, "operation": _140_1, "config": _config_3, "reads": _reads_3}, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
              } else if ((_id_0 & 1) == 0) {
                return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": _t_5, "removalSlow": _139_0, "operation": _140_1, "config": _config_3, "reads": _reads_3}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("dispatch"))}};
              } else if (_id_0 == 5) {
                return $$$$047experiments$047public$045schedule$045readers$047driver$058event_read$(false, {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": _t_5, "removalSlow": _139_0, "operation": _140_1, "config": _config_3, "reads": _reads_3}, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
              } else {
                return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": _t_5, "removalSlow": _139_0, "operation": _140_1, "config": _config_3, "reads": _reads_3}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("dispatch"))}};
              }
            }
          } else {
            const _138_0 = _owners_0["removalFast"];
            const _139_1 = _owners_0["removalSlow"];
            const _140_2 = _owners_0["operation"];
            const _config_4 = _owners_0["config"];
            const _reads_4 = _owners_0["reads"];
            if (_id_0 == 4) {
              return $$$$047experiments$047public$045schedule$045readers$047driver$058event_read$(true, {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": _t_4, "removalFast": _138_0, "removalSlow": _139_1, "operation": _140_2, "config": _config_4, "reads": _reads_4}, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
            } else if ((_id_0 & 1) == 0) {
              return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": _t_4, "removalFast": _138_0, "removalSlow": _139_1, "operation": _140_2, "config": _config_4, "reads": _reads_4}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("dispatch"))}};
            } else if (_id_0 == 5) {
              return $$$$047experiments$047public$045schedule$045readers$047driver$058event_read$(false, {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": _t_4, "removalFast": _138_0, "removalSlow": _139_1, "operation": _140_2, "config": _config_4, "reads": _reads_4}, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
            } else {
              return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": _t_4, "removalFast": _138_0, "removalSlow": _139_1, "operation": _140_2, "config": _config_4, "reads": _reads_4}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("dispatch"))}};
            }
          }
        } else {
          const _137_0 = _owners_0["changeSlow"];
          const _138_1 = _owners_0["removalFast"];
          const _139_2 = _owners_0["removalSlow"];
          const _140_3 = _owners_0["operation"];
          const _config_5 = _owners_0["config"];
          const _reads_5 = _owners_0["reads"];
          if (_id_0 == 4) {
            return $$$$047experiments$047public$045schedule$045readers$047driver$058event_read$(true, {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": _t_3, "changeSlow": _137_0, "removalFast": _138_1, "removalSlow": _139_2, "operation": _140_3, "config": _config_5, "reads": _reads_5}, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
          } else if ((_id_0 & 1) == 0) {
            return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": _t_3, "changeSlow": _137_0, "removalFast": _138_1, "removalSlow": _139_2, "operation": _140_3, "config": _config_5, "reads": _reads_5}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("dispatch"))}};
          } else if (_id_0 == 5) {
            return $$$$047experiments$047public$045schedule$045readers$047driver$058event_read$(false, {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": _t_3, "changeSlow": _137_0, "removalFast": _138_1, "removalSlow": _139_2, "operation": _140_3, "config": _config_5, "reads": _reads_5}, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
          } else {
            return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": _t_3, "changeSlow": _137_0, "removalFast": _138_1, "removalSlow": _139_2, "operation": _140_3, "config": _config_5, "reads": _reads_5}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("dispatch"))}};
          }
        }
      } else {
        const _136_0 = _owners_0["changeFast"];
        const _137_1 = _owners_0["changeSlow"];
        const _138_2 = _owners_0["removalFast"];
        const _139_3 = _owners_0["removalSlow"];
        const _140_4 = _owners_0["operation"];
        const _config_6 = _owners_0["config"];
        const _reads_6 = _owners_0["reads"];
        if (_id_0 == 4) {
          return $$$$047experiments$047public$045schedule$045readers$047driver$058event_read$(true, {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": _t_2, "changeFast": _136_0, "changeSlow": _137_1, "removalFast": _138_2, "removalSlow": _139_3, "operation": _140_4, "config": _config_6, "reads": _reads_6}, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
        } else if ((_id_0 & 1) == 0) {
          return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": _t_2, "changeFast": _136_0, "changeSlow": _137_1, "removalFast": _138_2, "removalSlow": _139_3, "operation": _140_4, "config": _config_6, "reads": _reads_6}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("dispatch"))}};
        } else if (_id_0 == 5) {
          return $$$$047experiments$047public$045schedule$045readers$047driver$058event_read$(false, {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": _t_2, "changeFast": _136_0, "changeSlow": _137_1, "removalFast": _138_2, "removalSlow": _139_3, "operation": _140_4, "config": _config_6, "reads": _reads_6}, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
        } else {
          return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": _t_2, "changeFast": _136_0, "changeSlow": _137_1, "removalFast": _138_2, "removalSlow": _139_3, "operation": _140_4, "config": _config_6, "reads": _reads_6}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("dispatch"))}};
        }
      }
    } else {
      const _135_0 = _owners_0["slow"];
      const _136_1 = _owners_0["changeFast"];
      const _137_2 = _owners_0["changeSlow"];
      const _138_3 = _owners_0["removalFast"];
      const _139_4 = _owners_0["removalSlow"];
      const _140_5 = _owners_0["operation"];
      const _config_7 = _owners_0["config"];
      const _reads_7 = _owners_0["reads"];
      if (_id_0 == 4) {
        return $$$$047experiments$047public$045schedule$045readers$047driver$058event_read$(true, {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": _t_1, "slow": _135_0, "changeFast": _136_1, "changeSlow": _137_2, "removalFast": _138_3, "removalSlow": _139_4, "operation": _140_5, "config": _config_7, "reads": _reads_7}, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
      } else if ((_id_0 & 1) == 0) {
        return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": _t_1, "slow": _135_0, "changeFast": _136_1, "changeSlow": _137_2, "removalFast": _138_3, "removalSlow": _139_4, "operation": _140_5, "config": _config_7, "reads": _reads_7}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("dispatch"))}};
      } else if (_id_0 == 5) {
        return $$$$047experiments$047public$045schedule$045readers$047driver$058event_read$(false, {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": _t_1, "slow": _135_0, "changeFast": _136_1, "changeSlow": _137_2, "removalFast": _138_3, "removalSlow": _139_4, "operation": _140_5, "config": _config_7, "reads": _reads_7}, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
      } else {
        return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": _t_1, "slow": _135_0, "changeFast": _136_1, "changeSlow": _137_2, "removalFast": _138_3, "removalSlow": _139_4, "operation": _140_5, "config": _config_7, "reads": _reads_7}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("dispatch"))}};
      }
    }
  } else {
    const _134_0 = _owners_0["fast"];
    const _135_1 = _owners_0["slow"];
    const _136_2 = _owners_0["changeFast"];
    const _137_3 = _owners_0["changeSlow"];
    const _138_4 = _owners_0["removalFast"];
    const _139_5 = _owners_0["removalSlow"];
    const _140_6 = _owners_0["operation"];
    const _config_8 = _owners_0["config"];
    const _reads_8 = _owners_0["reads"];
    if (_id_0 == 4) {
      return $$$$047experiments$047public$045schedule$045readers$047driver$058event_read$(true, {$: "../experiments/public-schedule-readers/driver.Owners", "events": _t_0, "fast": _134_0, "slow": _135_1, "changeFast": _136_2, "changeSlow": _137_3, "removalFast": _138_4, "removalSlow": _139_5, "operation": _140_6, "config": _config_8, "reads": _reads_8}, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
    } else if ((_id_0 & 1) == 0) {
      return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": _t_0, "fast": _134_0, "slow": _135_1, "changeFast": _136_2, "changeSlow": _137_3, "removalFast": _138_4, "removalSlow": _139_5, "operation": _140_6, "config": _config_8, "reads": _reads_8}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("dispatch"))}};
    } else if (_id_0 == 5) {
      return $$$$047experiments$047public$045schedule$045readers$047driver$058event_read$(false, {$: "../experiments/public-schedule-readers/driver.Owners", "events": _t_0, "fast": _134_0, "slow": _135_1, "changeFast": _136_2, "changeSlow": _137_3, "removalFast": _138_4, "removalSlow": _139_5, "operation": _140_6, "config": _config_8, "reads": _reads_8}, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
    } else {
      return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": _t_0, "fast": _134_0, "slow": _135_1, "changeFast": _136_2, "changeSlow": _137_3, "removalFast": _138_4, "removalSlow": _139_5, "operation": _140_6, "config": _config_8, "reads": _reads_8}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("dispatch"))}};
    }
  }
}

function $$$$047src$047ecs$047lifecycle$058set$(_entries_0, _id_0, _stamp_0) {
  return {$: "Con", "head": {$: "../src/ecs/lifecycle.Entry", "id": _id_0, "stamp": _stamp_0}, "tail": ($$$$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0))};
}

function $$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0) {
  if (!_incoming_0) {
    return {$: "../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    return $$$$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0);
  }
}

function $$$$047src$047ecs$047lifecycle$058get$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047src$047ecs$047lifecycle$058choose$((_key_0 === _id_0), _stamp_0, ($$$$047src$047ecs$047lifecycle$058get$(_rest_0, _id_0)));
  }
}

function $$$$047src$047ecs$047column$058mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058indexed_mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_mark_got$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047src$047ecs$047column$058indexed_prepared_mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_prepared_mark_got$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047src$047ecs$047column$058swapped$1263$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047src$047ecs$047column$058swap_recovered$1263$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058swap_sized$1263$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_swap_state$1263$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_0)));
  } else {
    return {$: "../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047src$047ecs$047column$058recover$1263$(_column_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058recover_state$1263$(($$$$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_recover_state$1263$(($$$$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058seek$1263$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058past_current$1263$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047src$047ecs$047column$058indexed_swap_checked$1263$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": ($$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047src$047ecs$047column$058indexed_swapped$1263$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047src$047ecs$047column$058indexed_seek$1263$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058grow$1263$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047src$047ecs$047column$058absent$1263$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $U32$log2$(_n_0) {
  return $U32$log2$go$(5, _n_0, 0);
}

function $$$$047src$047ecs$047column$058ensure_prepared$1263$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047src$047ecs$047column$058ensure_recovered$1263$(_target_0, ($$$$047src$047ecs$047column$058recover$1263$(_column_0)));
  }
}

function $$$$047src$047ecs$047column$058indexed_ensure_sized$1263$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_grow$1263$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058empty_read$(_text_0) {
  if (_text_0 === "") {
    return {$: "Nil"};
  } else {
    return {$: "Con", "head": _text_0, "tail": {$: "Nil"}};
  }
}

function $$$$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047src$047ecs$047system$058cursor_outcome$1261$({$: "../src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047src$047ecs$047system$058run_namespace_value$1263$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047src$047ecs$047system$058run_namespace_checked$1263$((_namespace_0 === _actual_0), {$: "../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047src$047ecs$047component$058access$1263$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "../src/ecs/component.ComponentAbsent"};
  } else {
    const _value_1 = _value_0["value"];
    return {$: "../src/ecs/component.Found", "value": _value_1};
  }
}

function $$$$047src$047ecs$047column$058plain_view_sized$1263$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058plain_view_checked$1263$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058prepared_view_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058prepared_view_checked$1263$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047src$047ecs$047column$058indexed_view_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_view_sized$1263$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_prepared_view_checked$1263$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047src$047ecs$047column$058restored$1262$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058project_queue_join$(_value_0, _length_0, _observed_0) {
  const _array_0 = _observed_0["fst"];
  const _values_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/schema.Queue", "value": _value_0, "owned": _array_0, "length": _length_0}, "snd": {$: "../experiments/public-schedule-readers/schema.QueueView", "value": _value_0, "owned": ($$$$047experiments$047public$045schedule$045readers$047schema$058prefix$(_length_0, _values_0))}};
}

function $$$$047src$047ecs$047column$058viewed$1262$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047src$047ecs$047column$058restored$1262$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058viewed_return$1262$(_result_0, ($$$$047src$047ecs$047column$058swap$1262$({$: "../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_projected_state$1262$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058viewed_return$1262$(_result_0, ($$$$047src$047ecs$047column$058swap$1262$({$: "../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047src$047ecs$047column$058swap_sized$1262$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047src$047ecs$047column$058swap_checked$1262$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058indexed_swap_state$1262$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_swap_sized$1262$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047src$047ecs$047column$058recover_past$1262$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_view_projected$1262$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047src$047ecs$047column$058indexed_view_restored$1262$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058prefix$(_fuel_0, _xs_0) {
  if (_fuel_0 === 0) {
    if (_xs_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return {$: "Nil"};
    }
  } else {
    const _rest_0 = (_fuel_0 - 1);
    if (_xs_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      const _x_0 = _xs_0["head"];
      const _xs_1 = _xs_0["tail"];
      return {$: "Con", "head": _x_0, "tail": ($$$$047experiments$047public$045schedule$045readers$047schema$058prefix$(_rest_0, _xs_1))};
    }
  }
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058array_join$(_left_view_0, _right_view_0) {
  const _left_0 = _left_view_0["fst"];
  const _xs_0 = _left_view_0["snd"];
  const _right_0 = _right_view_0["fst"];
  const _ys_0 = _right_view_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_0, _right_0), "snd": ($List$append$(_xs_0, _ys_0))};
}

function $$$$047src$047ecs$047column$058viewed_return$1260$(_view_0, _result_0) {
  if (_result_0.$ === "../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047src$047ecs$047column$058swapped$1260$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _cursor_0, _dispose_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _positions_0["head"];
    const _actual_0 = _t_0["id"];
    const _old_0 = _t_0["cursor"];
    const _registered_0 = _t_0["registeredAt"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047src$047ecs$047event$045runtime$058update_checked$((_actual_0 === _id_0), _dispose_0, _actual_0, _old_0, _registered_0, ($$$$047src$047ecs$047event$045runtime$058update$(_rest_0, _id_0, _cursor_0, _dispose_0)), _cursor_0);
  }
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058event_read$(_which_0, _owners_0, _observed_0) {
  if (_which_0) {
    const _t_0 = _owners_0["events"];
    if (_t_0.$ === "../experiments/public-schedule-readers/driver.Occupied") {
      const _events_0 = _t_0["owner"];
      const _t_1 = _owners_0["fast"];
      if (_t_1.$ === "../experiments/public-schedule-readers/driver.Occupied") {
        const _t_2 = _t_1["owner"];
        const _reader_0 = _t_2["reader"];
        const _registry_0 = _t_2["registry"];
        const _t_3 = _owners_0["slow"];
        if (_t_3.$ === "../experiments/public-schedule-readers/driver.Occupied") {
          const _slow_0 = _t_3["owner"];
          const _t_4 = _owners_0["changeFast"];
          if (_t_4.$ === "../experiments/public-schedule-readers/driver.Occupied") {
            const _cf_0 = _t_4["owner"];
            const _t_5 = _owners_0["changeSlow"];
            if (_t_5.$ === "../experiments/public-schedule-readers/driver.Occupied") {
              const _cs_0 = _t_5["owner"];
              const _t_6 = _owners_0["removalFast"];
              if (_t_6.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                const _rf_0 = _t_6["owner"];
                const _t_7 = _owners_0["removalSlow"];
                if (_t_7.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                  const _rs_0 = _t_7["owner"];
                  const _t_8 = _owners_0["operation"];
                  if (_t_8.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                    const _operation_0 = _t_8["owner"];
                    const _config_0 = _owners_0["config"];
                    const _reads_0 = _owners_0["reads"];
                    const _world_0 = _observed_0["fst"];
                    const _removals_0 = _observed_0["snd"];
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058event_completed$(true, {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Empty"}, "fast": {$: "../experiments/public-schedule-readers/driver.Empty"}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_0}, "config": _config_0, "reads": _reads_0}, _removals_0, ($$$$047src$047ecs$047event$045runtime$058run$1260$(($$$$047src$047ecs$047reader$045domains$058attach$1260$(_events_0, _world_0)), _reader_0, _registry_0, ($$$$047experiments$047public$045schedule$045readers$047driver$058event_args$(_config_0, "event-fast")))));
                  } else {
                    const _config_1 = _owners_0["config"];
                    const _reads_1 = _owners_0["reads"];
                    const _world_1 = _observed_0["fst"];
                    return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": {$: "../experiments/public-schedule-readers/driver.EventOwner", "reader": _reader_0, "registry": _registry_0}}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": _t_8, "config": _config_1, "reads": _reads_1}, "snd": {$: "../src/ecs/system.Failed", "world": _world_1, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event-read"))}};
                  }
                } else {
                  const _85_0 = _owners_0["operation"];
                  const _config_2 = _owners_0["config"];
                  const _reads_2 = _owners_0["reads"];
                  const _world_2 = _observed_0["fst"];
                  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": {$: "../experiments/public-schedule-readers/driver.EventOwner", "reader": _reader_0, "registry": _registry_0}}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": _t_7, "operation": _85_0, "config": _config_2, "reads": _reads_2}, "snd": {$: "../src/ecs/system.Failed", "world": _world_2, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event-read"))}};
                }
              } else {
                const _84_0 = _owners_0["removalSlow"];
                const _85_1 = _owners_0["operation"];
                const _config_3 = _owners_0["config"];
                const _reads_3 = _owners_0["reads"];
                const _world_3 = _observed_0["fst"];
                return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": {$: "../experiments/public-schedule-readers/driver.EventOwner", "reader": _reader_0, "registry": _registry_0}}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": _t_6, "removalSlow": _84_0, "operation": _85_1, "config": _config_3, "reads": _reads_3}, "snd": {$: "../src/ecs/system.Failed", "world": _world_3, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event-read"))}};
              }
            } else {
              const _83_0 = _owners_0["removalFast"];
              const _84_1 = _owners_0["removalSlow"];
              const _85_2 = _owners_0["operation"];
              const _config_4 = _owners_0["config"];
              const _reads_4 = _owners_0["reads"];
              const _world_4 = _observed_0["fst"];
              return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": {$: "../experiments/public-schedule-readers/driver.EventOwner", "reader": _reader_0, "registry": _registry_0}}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": _t_5, "removalFast": _83_0, "removalSlow": _84_1, "operation": _85_2, "config": _config_4, "reads": _reads_4}, "snd": {$: "../src/ecs/system.Failed", "world": _world_4, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event-read"))}};
            }
          } else {
            const _82_0 = _owners_0["changeSlow"];
            const _83_1 = _owners_0["removalFast"];
            const _84_2 = _owners_0["removalSlow"];
            const _85_3 = _owners_0["operation"];
            const _config_5 = _owners_0["config"];
            const _reads_5 = _owners_0["reads"];
            const _world_5 = _observed_0["fst"];
            return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": {$: "../experiments/public-schedule-readers/driver.EventOwner", "reader": _reader_0, "registry": _registry_0}}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": _t_4, "changeSlow": _82_0, "removalFast": _83_1, "removalSlow": _84_2, "operation": _85_3, "config": _config_5, "reads": _reads_5}, "snd": {$: "../src/ecs/system.Failed", "world": _world_5, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event-read"))}};
          }
        } else {
          const _81_0 = _owners_0["changeFast"];
          const _82_1 = _owners_0["changeSlow"];
          const _83_2 = _owners_0["removalFast"];
          const _84_3 = _owners_0["removalSlow"];
          const _85_4 = _owners_0["operation"];
          const _config_6 = _owners_0["config"];
          const _reads_6 = _owners_0["reads"];
          const _world_6 = _observed_0["fst"];
          return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": {$: "../experiments/public-schedule-readers/driver.EventOwner", "reader": _reader_0, "registry": _registry_0}}, "slow": _t_3, "changeFast": _81_0, "changeSlow": _82_1, "removalFast": _83_2, "removalSlow": _84_3, "operation": _85_4, "config": _config_6, "reads": _reads_6}, "snd": {$: "../src/ecs/system.Failed", "world": _world_6, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event-read"))}};
        }
      } else {
        const _80_0 = _owners_0["slow"];
        const _81_1 = _owners_0["changeFast"];
        const _82_2 = _owners_0["changeSlow"];
        const _83_3 = _owners_0["removalFast"];
        const _84_4 = _owners_0["removalSlow"];
        const _85_5 = _owners_0["operation"];
        const _config_7 = _owners_0["config"];
        const _reads_7 = _owners_0["reads"];
        const _world_7 = _observed_0["fst"];
        return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": _t_1, "slow": _80_0, "changeFast": _81_1, "changeSlow": _82_2, "removalFast": _83_3, "removalSlow": _84_4, "operation": _85_5, "config": _config_7, "reads": _reads_7}, "snd": {$: "../src/ecs/system.Failed", "world": _world_7, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event-read"))}};
      }
    } else {
      const _79_0 = _owners_0["fast"];
      const _80_1 = _owners_0["slow"];
      const _81_2 = _owners_0["changeFast"];
      const _82_3 = _owners_0["changeSlow"];
      const _83_4 = _owners_0["removalFast"];
      const _84_5 = _owners_0["removalSlow"];
      const _85_6 = _owners_0["operation"];
      const _config_8 = _owners_0["config"];
      const _reads_8 = _owners_0["reads"];
      const _world_8 = _observed_0["fst"];
      return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": _t_0, "fast": _79_0, "slow": _80_1, "changeFast": _81_2, "changeSlow": _82_3, "removalFast": _83_4, "removalSlow": _84_5, "operation": _85_6, "config": _config_8, "reads": _reads_8}, "snd": {$: "../src/ecs/system.Failed", "world": _world_8, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event-read"))}};
    }
  } else {
    const _t_9 = _owners_0["events"];
    if (_t_9.$ === "../experiments/public-schedule-readers/driver.Occupied") {
      const _events_1 = _t_9["owner"];
      const _t_10 = _owners_0["fast"];
      if (_t_10.$ === "../experiments/public-schedule-readers/driver.Occupied") {
        const _fast_0 = _t_10["owner"];
        const _t_11 = _owners_0["slow"];
        if (_t_11.$ === "../experiments/public-schedule-readers/driver.Occupied") {
          const _t_12 = _t_11["owner"];
          const _reader_1 = _t_12["reader"];
          const _registry_1 = _t_12["registry"];
          const _t_13 = _owners_0["changeFast"];
          if (_t_13.$ === "../experiments/public-schedule-readers/driver.Occupied") {
            const _cf_1 = _t_13["owner"];
            const _t_14 = _owners_0["changeSlow"];
            if (_t_14.$ === "../experiments/public-schedule-readers/driver.Occupied") {
              const _cs_1 = _t_14["owner"];
              const _t_15 = _owners_0["removalFast"];
              if (_t_15.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                const _rf_1 = _t_15["owner"];
                const _t_16 = _owners_0["removalSlow"];
                if (_t_16.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                  const _rs_1 = _t_16["owner"];
                  const _t_17 = _owners_0["operation"];
                  if (_t_17.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                    const _operation_1 = _t_17["owner"];
                    const _config_9 = _owners_0["config"];
                    const _reads_9 = _owners_0["reads"];
                    const _world_9 = _observed_0["fst"];
                    const _removals_1 = _observed_0["snd"];
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058event_completed$(false, {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Empty"}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Empty"}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_1}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_1}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_1}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_1}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_1}, "config": _config_9, "reads": _reads_9}, _removals_1, ($$$$047src$047ecs$047event$045runtime$058run$1260$(($$$$047src$047ecs$047reader$045domains$058attach$1260$(_events_1, _world_9)), _reader_1, _registry_1, ($$$$047experiments$047public$045schedule$045readers$047driver$058event_args$(_config_9, "event-slow")))));
                  } else {
                    const _config_10 = _owners_0["config"];
                    const _reads_10 = _owners_0["reads"];
                    const _world_10 = _observed_0["fst"];
                    return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_1}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": {$: "../experiments/public-schedule-readers/driver.EventOwner", "reader": _reader_1, "registry": _registry_1}}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_1}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_1}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_1}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_1}, "operation": _t_17, "config": _config_10, "reads": _reads_10}, "snd": {$: "../src/ecs/system.Failed", "world": _world_10, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event-read"))}};
                  }
                } else {
                  const _94_0 = _owners_0["operation"];
                  const _config_11 = _owners_0["config"];
                  const _reads_11 = _owners_0["reads"];
                  const _world_11 = _observed_0["fst"];
                  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_1}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": {$: "../experiments/public-schedule-readers/driver.EventOwner", "reader": _reader_1, "registry": _registry_1}}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_1}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_1}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_1}, "removalSlow": _t_16, "operation": _94_0, "config": _config_11, "reads": _reads_11}, "snd": {$: "../src/ecs/system.Failed", "world": _world_11, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event-read"))}};
                }
              } else {
                const _93_0 = _owners_0["removalSlow"];
                const _94_1 = _owners_0["operation"];
                const _config_12 = _owners_0["config"];
                const _reads_12 = _owners_0["reads"];
                const _world_12 = _observed_0["fst"];
                return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_1}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": {$: "../experiments/public-schedule-readers/driver.EventOwner", "reader": _reader_1, "registry": _registry_1}}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_1}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_1}, "removalFast": _t_15, "removalSlow": _93_0, "operation": _94_1, "config": _config_12, "reads": _reads_12}, "snd": {$: "../src/ecs/system.Failed", "world": _world_12, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event-read"))}};
              }
            } else {
              const _92_0 = _owners_0["removalFast"];
              const _93_1 = _owners_0["removalSlow"];
              const _94_2 = _owners_0["operation"];
              const _config_13 = _owners_0["config"];
              const _reads_13 = _owners_0["reads"];
              const _world_13 = _observed_0["fst"];
              return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_1}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": {$: "../experiments/public-schedule-readers/driver.EventOwner", "reader": _reader_1, "registry": _registry_1}}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_1}, "changeSlow": _t_14, "removalFast": _92_0, "removalSlow": _93_1, "operation": _94_2, "config": _config_13, "reads": _reads_13}, "snd": {$: "../src/ecs/system.Failed", "world": _world_13, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event-read"))}};
            }
          } else {
            const _91_0 = _owners_0["changeSlow"];
            const _92_1 = _owners_0["removalFast"];
            const _93_2 = _owners_0["removalSlow"];
            const _94_3 = _owners_0["operation"];
            const _config_14 = _owners_0["config"];
            const _reads_14 = _owners_0["reads"];
            const _world_14 = _observed_0["fst"];
            return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_1}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": {$: "../experiments/public-schedule-readers/driver.EventOwner", "reader": _reader_1, "registry": _registry_1}}, "changeFast": _t_13, "changeSlow": _91_0, "removalFast": _92_1, "removalSlow": _93_2, "operation": _94_3, "config": _config_14, "reads": _reads_14}, "snd": {$: "../src/ecs/system.Failed", "world": _world_14, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event-read"))}};
          }
        } else {
          const _90_0 = _owners_0["changeFast"];
          const _91_1 = _owners_0["changeSlow"];
          const _92_2 = _owners_0["removalFast"];
          const _93_3 = _owners_0["removalSlow"];
          const _94_4 = _owners_0["operation"];
          const _config_15 = _owners_0["config"];
          const _reads_15 = _owners_0["reads"];
          const _world_15 = _observed_0["fst"];
          return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_1}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": _t_11, "changeFast": _90_0, "changeSlow": _91_1, "removalFast": _92_2, "removalSlow": _93_3, "operation": _94_4, "config": _config_15, "reads": _reads_15}, "snd": {$: "../src/ecs/system.Failed", "world": _world_15, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event-read"))}};
        }
      } else {
        const _89_0 = _owners_0["slow"];
        const _90_1 = _owners_0["changeFast"];
        const _91_2 = _owners_0["changeSlow"];
        const _92_3 = _owners_0["removalFast"];
        const _93_4 = _owners_0["removalSlow"];
        const _94_5 = _owners_0["operation"];
        const _config_16 = _owners_0["config"];
        const _reads_16 = _owners_0["reads"];
        const _world_16 = _observed_0["fst"];
        return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_1}, "fast": _t_10, "slow": _89_0, "changeFast": _90_1, "changeSlow": _91_2, "removalFast": _92_3, "removalSlow": _93_4, "operation": _94_5, "config": _config_16, "reads": _reads_16}, "snd": {$: "../src/ecs/system.Failed", "world": _world_16, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event-read"))}};
      }
    } else {
      const _88_0 = _owners_0["fast"];
      const _89_1 = _owners_0["slow"];
      const _90_2 = _owners_0["changeFast"];
      const _91_3 = _owners_0["changeSlow"];
      const _92_4 = _owners_0["removalFast"];
      const _93_5 = _owners_0["removalSlow"];
      const _94_6 = _owners_0["operation"];
      const _config_17 = _owners_0["config"];
      const _reads_17 = _owners_0["reads"];
      const _world_17 = _observed_0["fst"];
      return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": _t_9, "fast": _88_0, "slow": _89_1, "changeFast": _90_2, "changeSlow": _91_3, "removalFast": _92_4, "removalSlow": _93_5, "operation": _94_6, "config": _config_17, "reads": _reads_17}, "snd": {$: "../src/ecs/system.Failed", "world": _world_17, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event-read"))}};
    }
  }
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058op_completed$(_owners_0, _result_0) {
  const _t_0 = _owners_0["events"];
  if (_t_0.$ === "../experiments/public-schedule-readers/driver.Occupied") {
    const _events_0 = _t_0["owner"];
    const _t_1 = _owners_0["fast"];
    if (_t_1.$ === "../experiments/public-schedule-readers/driver.Occupied") {
      const _fast_0 = _t_1["owner"];
      const _t_2 = _owners_0["slow"];
      if (_t_2.$ === "../experiments/public-schedule-readers/driver.Occupied") {
        const _slow_0 = _t_2["owner"];
        const _t_3 = _owners_0["changeFast"];
        if (_t_3.$ === "../experiments/public-schedule-readers/driver.Occupied") {
          const _cf_0 = _t_3["owner"];
          const _t_4 = _owners_0["changeSlow"];
          if (_t_4.$ === "../experiments/public-schedule-readers/driver.Occupied") {
            const _cs_0 = _t_4["owner"];
            const _t_5 = _owners_0["removalFast"];
            if (_t_5.$ === "../experiments/public-schedule-readers/driver.Occupied") {
              const _rf_0 = _t_5["owner"];
              const _t_6 = _owners_0["removalSlow"];
              if (_t_6.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                const _rs_0 = _t_6["owner"];
                const _config_0 = _owners_0["config"];
                const _reads_0 = _owners_0["reads"];
                if (_result_0.$ === "../src/ecs/system.Completed") {
                  const _new_0 = _result_0["registry"];
                  const _t_7 = _result_0["outcome"];
                  if (_t_7.$ === "../src/ecs/system.Succeeded") {
                    const _world_0 = _t_7["world"];
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058collect_result$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _new_0}, "config": _config_0, "reads": _reads_0}, {$: "../src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}});
                  } else {
                    const _world_1 = _t_7["world"];
                    const _t_8 = _t_7["error"];
                    const _text_1 = _t_8["observation"];
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058collect_result$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _new_0}, "config": _config_0, "reads": _reads_0}, {$: "../src/ecs/system.Failed", "world": _world_1, "error": {$: "../experiments/public-schedule-readers/consumers.Failed", "observation": _text_1}});
                  }
                } else {
                  const _new_1 = _result_0["registry"];
                  const _world_2 = _result_0["world"];
                  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _new_1}, "config": _config_0, "reads": _reads_0}, "snd": {$: "../src/ecs/system.Failed", "world": _world_2, "error": {$: "../experiments/public-schedule-readers/consumers.Failed", "observation": "registration"}}};
                }
              } else {
                const __2 = _owners_0["operation"];
                const _config_1 = _owners_0["config"];
                const _reads_1 = _owners_0["reads"];
                return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": _t_6, "operation": __2, "config": _config_1, "reads": _reads_1}, "snd": {$: "../src/ecs/system.Failed", "world": ($$$$047experiments$047public$045schedule$045readers$047driver$058op_world$(_result_0)), "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("operation"))}};
              }
            } else {
              const _97_0 = _owners_0["removalSlow"];
              const __3 = _owners_0["operation"];
              const _config_2 = _owners_0["config"];
              const _reads_2 = _owners_0["reads"];
              return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": _t_5, "removalSlow": _97_0, "operation": __3, "config": _config_2, "reads": _reads_2}, "snd": {$: "../src/ecs/system.Failed", "world": ($$$$047experiments$047public$045schedule$045readers$047driver$058op_world$(_result_0)), "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("operation"))}};
            }
          } else {
            const _96_0 = _owners_0["removalFast"];
            const _97_1 = _owners_0["removalSlow"];
            const __4 = _owners_0["operation"];
            const _config_3 = _owners_0["config"];
            const _reads_3 = _owners_0["reads"];
            return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": _t_4, "removalFast": _96_0, "removalSlow": _97_1, "operation": __4, "config": _config_3, "reads": _reads_3}, "snd": {$: "../src/ecs/system.Failed", "world": ($$$$047experiments$047public$045schedule$045readers$047driver$058op_world$(_result_0)), "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("operation"))}};
          }
        } else {
          const _95_0 = _owners_0["changeSlow"];
          const _96_1 = _owners_0["removalFast"];
          const _97_2 = _owners_0["removalSlow"];
          const __5 = _owners_0["operation"];
          const _config_4 = _owners_0["config"];
          const _reads_4 = _owners_0["reads"];
          return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": _t_3, "changeSlow": _95_0, "removalFast": _96_1, "removalSlow": _97_2, "operation": __5, "config": _config_4, "reads": _reads_4}, "snd": {$: "../src/ecs/system.Failed", "world": ($$$$047experiments$047public$045schedule$045readers$047driver$058op_world$(_result_0)), "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("operation"))}};
        }
      } else {
        const _94_0 = _owners_0["changeFast"];
        const _95_1 = _owners_0["changeSlow"];
        const _96_2 = _owners_0["removalFast"];
        const _97_3 = _owners_0["removalSlow"];
        const __6 = _owners_0["operation"];
        const _config_5 = _owners_0["config"];
        const _reads_5 = _owners_0["reads"];
        return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": _t_2, "changeFast": _94_0, "changeSlow": _95_1, "removalFast": _96_2, "removalSlow": _97_3, "operation": __6, "config": _config_5, "reads": _reads_5}, "snd": {$: "../src/ecs/system.Failed", "world": ($$$$047experiments$047public$045schedule$045readers$047driver$058op_world$(_result_0)), "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("operation"))}};
      }
    } else {
      const _93_0 = _owners_0["slow"];
      const _94_1 = _owners_0["changeFast"];
      const _95_2 = _owners_0["changeSlow"];
      const _96_3 = _owners_0["removalFast"];
      const _97_4 = _owners_0["removalSlow"];
      const __7 = _owners_0["operation"];
      const _config_6 = _owners_0["config"];
      const _reads_6 = _owners_0["reads"];
      return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": _t_1, "slow": _93_0, "changeFast": _94_1, "changeSlow": _95_2, "removalFast": _96_3, "removalSlow": _97_4, "operation": __7, "config": _config_6, "reads": _reads_6}, "snd": {$: "../src/ecs/system.Failed", "world": ($$$$047experiments$047public$045schedule$045readers$047driver$058op_world$(_result_0)), "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("operation"))}};
    }
  } else {
    const _92_0 = _owners_0["fast"];
    const _93_1 = _owners_0["slow"];
    const _94_2 = _owners_0["changeFast"];
    const _95_3 = _owners_0["changeSlow"];
    const _96_4 = _owners_0["removalFast"];
    const _97_5 = _owners_0["removalSlow"];
    const __8 = _owners_0["operation"];
    const _config_7 = _owners_0["config"];
    const _reads_7 = _owners_0["reads"];
    return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": _t_0, "fast": _92_0, "slow": _93_1, "changeFast": _94_2, "changeSlow": _95_3, "removalFast": _96_4, "removalSlow": _97_5, "operation": __8, "config": _config_7, "reads": _reads_7}, "snd": {$: "../src/ecs/system.Failed", "world": ($$$$047experiments$047public$045schedule$045readers$047driver$058op_world$(_result_0)), "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("operation"))}};
  }
}

function $$$$047src$047ecs$047system$058run$1262$(_registry_0, _world_0, _args_0) {
  return $$$$047src$047ecs$047system$058run_namespace$1262$(_registry_0, ($$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058config_request$(_config_0) {
  const _request_0 = _config_0["request"];
  return _request_0;
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058removal_execute$(_which_0, _name_0, _owners_0, _reader_0, _world_0, _fail_0) {
  if (_fail_0) {
    return $$$$047experiments$047public$045schedule$045readers$047driver$058removal_finished$(_which_0, _name_0, _owners_0, ($$$$047src$047ecs$047removals$058run$1260$(_reader_0, _world_0)));
  } else {
    return $$$$047experiments$047public$045schedule$045readers$047driver$058removal_finished$(_which_0, _name_0, _owners_0, ($$$$047src$047ecs$047removals$058run$1261$(_reader_0, _world_0)));
  }
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058removal_config$(_config_0) {
  const _fail_0 = _config_0["removalFail"];
  return _fail_0;
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058change_run$(_which_0, _owners_0, _world_0, _identified_0) {
  if (_which_0) {
    const _t_0 = _owners_0["events"];
    if (_t_0.$ === "../experiments/public-schedule-readers/driver.Occupied") {
      const _events_0 = _t_0["owner"];
      const _t_1 = _owners_0["fast"];
      if (_t_1.$ === "../experiments/public-schedule-readers/driver.Occupied") {
        const _fast_0 = _t_1["owner"];
        const _t_2 = _owners_0["slow"];
        if (_t_2.$ === "../experiments/public-schedule-readers/driver.Occupied") {
          const _slow_0 = _t_2["owner"];
          const __0 = _owners_0["changeFast"];
          const _t_3 = _owners_0["changeSlow"];
          if (_t_3.$ === "../experiments/public-schedule-readers/driver.Occupied") {
            const _cs_0 = _t_3["owner"];
            const _t_4 = _owners_0["removalFast"];
            if (_t_4.$ === "../experiments/public-schedule-readers/driver.Occupied") {
              const _rf_0 = _t_4["owner"];
              const _t_5 = _owners_0["removalSlow"];
              if (_t_5.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                const _rs_0 = _t_5["owner"];
                const _t_6 = _owners_0["operation"];
                if (_t_6.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                  const _operation_0 = _t_6["owner"];
                  const _config_0 = _owners_0["config"];
                  const _reads_0 = _owners_0["reads"];
                  const _registry_0 = _identified_0["fst"];
                  const _cursor_0 = _identified_0["snd"];
                  return $$$$047experiments$047public$045schedule$045readers$047driver$058cf_completed$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Empty"}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_0}, "config": _config_0, "reads": _reads_0}, ($$$$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, ($$$$047experiments$047public$045schedule$045readers$047driver$058change_args$(_config_0, "change-fast", _cursor_0)))));
                } else {
                  const _config_1 = _owners_0["config"];
                  const _reads_1 = _owners_0["reads"];
                  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": __0, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": _t_6, "config": _config_1, "reads": _reads_1}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-run"))}};
                }
              } else {
                const _78_0 = _owners_0["operation"];
                const _config_2 = _owners_0["config"];
                const _reads_2 = _owners_0["reads"];
                return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": __0, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": _t_5, "operation": _78_0, "config": _config_2, "reads": _reads_2}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-run"))}};
              }
            } else {
              const _77_0 = _owners_0["removalSlow"];
              const _78_1 = _owners_0["operation"];
              const _config_3 = _owners_0["config"];
              const _reads_3 = _owners_0["reads"];
              return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": __0, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": _t_4, "removalSlow": _77_0, "operation": _78_1, "config": _config_3, "reads": _reads_3}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-run"))}};
            }
          } else {
            const _76_0 = _owners_0["removalFast"];
            const _77_1 = _owners_0["removalSlow"];
            const _78_2 = _owners_0["operation"];
            const _config_4 = _owners_0["config"];
            const _reads_4 = _owners_0["reads"];
            return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": __0, "changeSlow": _t_3, "removalFast": _76_0, "removalSlow": _77_1, "operation": _78_2, "config": _config_4, "reads": _reads_4}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-run"))}};
          }
        } else {
          const __1 = _owners_0["changeFast"];
          const _75_0 = _owners_0["changeSlow"];
          const _76_1 = _owners_0["removalFast"];
          const _77_2 = _owners_0["removalSlow"];
          const _78_3 = _owners_0["operation"];
          const _config_5 = _owners_0["config"];
          const _reads_5 = _owners_0["reads"];
          return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": _t_2, "changeFast": __1, "changeSlow": _75_0, "removalFast": _76_1, "removalSlow": _77_2, "operation": _78_3, "config": _config_5, "reads": _reads_5}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-run"))}};
        }
      } else {
        const _74_0 = _owners_0["slow"];
        const __2 = _owners_0["changeFast"];
        const _75_1 = _owners_0["changeSlow"];
        const _76_2 = _owners_0["removalFast"];
        const _77_3 = _owners_0["removalSlow"];
        const _78_4 = _owners_0["operation"];
        const _config_6 = _owners_0["config"];
        const _reads_6 = _owners_0["reads"];
        return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": _t_1, "slow": _74_0, "changeFast": __2, "changeSlow": _75_1, "removalFast": _76_2, "removalSlow": _77_3, "operation": _78_4, "config": _config_6, "reads": _reads_6}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-run"))}};
      }
    } else {
      const _73_0 = _owners_0["fast"];
      const _74_1 = _owners_0["slow"];
      const __3 = _owners_0["changeFast"];
      const _75_2 = _owners_0["changeSlow"];
      const _76_3 = _owners_0["removalFast"];
      const _77_4 = _owners_0["removalSlow"];
      const _78_5 = _owners_0["operation"];
      const _config_7 = _owners_0["config"];
      const _reads_7 = _owners_0["reads"];
      return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": _t_0, "fast": _73_0, "slow": _74_1, "changeFast": __3, "changeSlow": _75_2, "removalFast": _76_3, "removalSlow": _77_4, "operation": _78_5, "config": _config_7, "reads": _reads_7}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-run"))}};
    }
  } else {
    const _t_7 = _owners_0["events"];
    if (_t_7.$ === "../experiments/public-schedule-readers/driver.Occupied") {
      const _events_1 = _t_7["owner"];
      const _t_8 = _owners_0["fast"];
      if (_t_8.$ === "../experiments/public-schedule-readers/driver.Occupied") {
        const _fast_1 = _t_8["owner"];
        const _t_9 = _owners_0["slow"];
        if (_t_9.$ === "../experiments/public-schedule-readers/driver.Occupied") {
          const _slow_1 = _t_9["owner"];
          const _t_10 = _owners_0["changeFast"];
          if (_t_10.$ === "../experiments/public-schedule-readers/driver.Occupied") {
            const _cf_0 = _t_10["owner"];
            const __4 = _owners_0["changeSlow"];
            const _t_11 = _owners_0["removalFast"];
            if (_t_11.$ === "../experiments/public-schedule-readers/driver.Occupied") {
              const _rf_1 = _t_11["owner"];
              const _t_12 = _owners_0["removalSlow"];
              if (_t_12.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                const _rs_1 = _t_12["owner"];
                const _t_13 = _owners_0["operation"];
                if (_t_13.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                  const _operation_1 = _t_13["owner"];
                  const _config_8 = _owners_0["config"];
                  const _reads_8 = _owners_0["reads"];
                  const _registry_1 = _identified_0["fst"];
                  const _cursor_1 = _identified_0["snd"];
                  return $$$$047experiments$047public$045schedule$045readers$047driver$058cs_completed$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_1}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_1}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_1}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Empty"}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_1}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_1}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_1}, "config": _config_8, "reads": _reads_8}, ($$$$047src$047ecs$047system$058run_tracked$1260$(_registry_1, _world_0, ($$$$047experiments$047public$045schedule$045readers$047driver$058change_args$(_config_8, "change-slow", _cursor_1)))));
                } else {
                  const _config_9 = _owners_0["config"];
                  const _reads_9 = _owners_0["reads"];
                  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_1}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_1}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_1}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": __4, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_1}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_1}, "operation": _t_13, "config": _config_9, "reads": _reads_9}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-run"))}};
                }
              } else {
                const _85_0 = _owners_0["operation"];
                const _config_10 = _owners_0["config"];
                const _reads_10 = _owners_0["reads"];
                return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_1}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_1}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_1}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": __4, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_1}, "removalSlow": _t_12, "operation": _85_0, "config": _config_10, "reads": _reads_10}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-run"))}};
              }
            } else {
              const _84_0 = _owners_0["removalSlow"];
              const _85_1 = _owners_0["operation"];
              const _config_11 = _owners_0["config"];
              const _reads_11 = _owners_0["reads"];
              return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_1}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_1}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_1}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": __4, "removalFast": _t_11, "removalSlow": _84_0, "operation": _85_1, "config": _config_11, "reads": _reads_11}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-run"))}};
            }
          } else {
            const __5 = _owners_0["changeSlow"];
            const _83_0 = _owners_0["removalFast"];
            const _84_1 = _owners_0["removalSlow"];
            const _85_2 = _owners_0["operation"];
            const _config_12 = _owners_0["config"];
            const _reads_12 = _owners_0["reads"];
            return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_1}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_1}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_1}, "changeFast": _t_10, "changeSlow": __5, "removalFast": _83_0, "removalSlow": _84_1, "operation": _85_2, "config": _config_12, "reads": _reads_12}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-run"))}};
          }
        } else {
          const _82_0 = _owners_0["changeFast"];
          const __6 = _owners_0["changeSlow"];
          const _83_1 = _owners_0["removalFast"];
          const _84_2 = _owners_0["removalSlow"];
          const _85_3 = _owners_0["operation"];
          const _config_13 = _owners_0["config"];
          const _reads_13 = _owners_0["reads"];
          return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_1}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_1}, "slow": _t_9, "changeFast": _82_0, "changeSlow": __6, "removalFast": _83_1, "removalSlow": _84_2, "operation": _85_3, "config": _config_13, "reads": _reads_13}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-run"))}};
        }
      } else {
        const _81_0 = _owners_0["slow"];
        const _82_1 = _owners_0["changeFast"];
        const __7 = _owners_0["changeSlow"];
        const _83_2 = _owners_0["removalFast"];
        const _84_3 = _owners_0["removalSlow"];
        const _85_4 = _owners_0["operation"];
        const _config_14 = _owners_0["config"];
        const _reads_14 = _owners_0["reads"];
        return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_1}, "fast": _t_8, "slow": _81_0, "changeFast": _82_1, "changeSlow": __7, "removalFast": _83_2, "removalSlow": _84_3, "operation": _85_4, "config": _config_14, "reads": _reads_14}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-run"))}};
      }
    } else {
      const _80_0 = _owners_0["fast"];
      const _81_1 = _owners_0["slow"];
      const _82_2 = _owners_0["changeFast"];
      const __8 = _owners_0["changeSlow"];
      const _83_3 = _owners_0["removalFast"];
      const _84_4 = _owners_0["removalSlow"];
      const _85_5 = _owners_0["operation"];
      const _config_15 = _owners_0["config"];
      const _reads_15 = _owners_0["reads"];
      return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": _t_7, "fast": _80_0, "slow": _81_1, "changeFast": _82_2, "changeSlow": __8, "removalFast": _83_3, "removalSlow": _84_4, "operation": _85_5, "config": _config_15, "reads": _reads_15}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-run"))}};
    }
  }
}

function $$$$047src$047ecs$047system$058cursor$1260$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _cursor_0};
}

function $$$$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047src$047ecs$047lifecycle$058keep$((_key_0 === _id_0), {$: "../src/ecs/lifecycle.Entry", "id": _key_0, "stamp": _stamp_0}, ($$$$047src$047ecs$047lifecycle$058clear$(_rest_0, _id_0)));
  }
}

function $$$$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0) {
  if (!_wasPresent_0) {
    return {$: "../src/ecs/lifecycle.Stamp", "added": _tick_0, "changed": _tick_0};
  } else {
    const _added_0 = _stamp_0["added"];
    return {$: "../src/ecs/lifecycle.Stamp", "added": _added_0, "changed": _tick_0};
  }
}

function $$$$047src$047ecs$047lifecycle$058choose$(_found_0, _stamp_0, _other_0) {
  if (_found_0) {
    return _stamp_0;
  } else {
    return _other_0;
  }
}

function $$$$047src$047ecs$047column$058indexed_mark_got$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, ($$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)), (_id_0 <= _capacity_0));
}

function $$$$047src$047ecs$047column$058indexed_prepared_mark_got$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058recover_state$1263$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058recover_current$1263$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047src$047ecs$047column$058indexed_recover_state$1263$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_recover_current$1263$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0) {
  return {$: "../src/ecs/column.Indexed", "state": {$: "../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047src$047ecs$047column$058indexed_swapped$1263$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../src/ecs/column.Accepted", "column": ($$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047src$047ecs$047column$058absent$1263$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047src$047ecs$047column$058absent$1263$(_rest_0)), ($$$$047src$047ecs$047column$058absent$1263$(_rest_0)));
  }
}

function $U32$log2$go$($0, $1, $2) {
  for (;;) {
    {
      const _k_0 = $0;
      const _n_0 = $1;
      const _b_0 = $2;
      if (_k_0 === 0) {
        return _b_0;
      } else {
        const _p_0 = (_k_0 - 1);
        const _x_0 = (_p_0 >= 32 ? 0 : (1 << _p_0) >>> 0);
        const _s_0 = _x_0;
        const _x_1 = (_s_0 >= 32 ? 0 : (_n_0 >>> _s_0) >>> 0);
        const _x_2 = ($Bool$to_u32$((_x_1 !== 0)));
        const _t_0 = nat_chk(_s_0 * _x_2);
        $0 = _p_0;
        $1 = (_t_0 >= 32 ? 0 : (_n_0 >>> _t_0) >>> 0);
        $2 = nat_chk(_b_0 + _t_0);
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058ensure_recovered$1263$(_target_0, _column_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058ensure_sized$1263$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_ensure_state$1263$(_target_0, ($$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047src$047ecs$047column$058indexed_grow$1263$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0);
        } else {
          return $$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047src$047ecs$047column$058absent$1263$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047src$047ecs$047system$058cursor_outcome$1261$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../src/ecs/system.Completed", "registry": {$: "../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047src$047ecs$047system$058run_namespace_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047src$047ecs$047system$058run_metadata$1263$({$: "../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047src$047ecs$047column$058plain_view_checked$1263$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047src$047ecs$047column$058plain_view_taken$1263$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047src$047ecs$047column$058prepared_view_checked$1263$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047src$047ecs$047column$058prepared_view_current$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047src$047ecs$047column$058prepared_view_different$1263$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_view_sized$1263$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_view_checked$1263$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_checked$1263$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047src$047ecs$047column$058indexed_prepared_view_current$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047src$047ecs$047column$058indexed_prepared_view_different$1263$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047src$047ecs$047column$058viewed_return$1262$(_view_0, _result_0) {
  if (_result_0.$ === "../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047src$047ecs$047column$058swap$1262$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058swap_sized$1262$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058swap_state$1262$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_swap_state$1262$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_swap_state$1262$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058indexed_projected_state$1262$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_view_projected$1262$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047src$047ecs$047column$058swap_checked$1262$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047src$047ecs$047column$058swapped$1262$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047src$047ecs$047column$058indexed_swap_sized$1262$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_swap_checked$1262$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058indexed_view_restored$1262$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047src$047ecs$047column$058swapped$1260$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": ($$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047src$047ecs$047event$045runtime$058update_checked$(_found_0, _dispose_0, _id_0, _old_0, _registered_0, _rest_0, _cursor_0) {
  if (!_found_0) {
    return {$: "Con", "head": {$: "../src/ecs/event-runtime.Position", "id": _id_0, "cursor": _old_0, "registeredAt": _registered_0}, "tail": _rest_0};
  } else {
    if (!_dispose_0) {
      return {$: "Con", "head": {$: "../src/ecs/event-runtime.Position", "id": _id_0, "cursor": _cursor_0, "registeredAt": _registered_0}, "tail": _rest_0};
    } else {
      return _rest_0;
    }
  }
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058event_completed$(_which_0, _owners_0, _removals_0, _result_0) {
  const _runtime_0 = _result_0["runtime"];
  const _reader_0 = _result_0["reader"];
  const _registry_0 = _result_0["registry"];
  const _t_0 = _result_0["completion"];
  if (_t_0.$ === "../src/ecs/event-runtime.Succeeded") {
    const _text_0 = _t_0["output"];
    return $$$$047experiments$047public$045schedule$045readers$047driver$058event_detached$(_which_0, _owners_0, {$: "../experiments/public-schedule-readers/driver.EventOwner", "reader": _reader_0, "registry": _registry_0}, _text_0, {$: "None"}, ($$$$047src$047ecs$047reader$045domains$058recover$1260$(_runtime_0, _removals_0)));
  } else if (_t_0.$ === "../src/ecs/event-runtime.Failed") {
    const _t_1 = _t_0["error"];
    const _text_1 = _t_1["observation"];
    return $$$$047experiments$047public$045schedule$045readers$047driver$058event_detached$(_which_0, _owners_0, {$: "../experiments/public-schedule-readers/driver.EventOwner", "reader": _reader_0, "registry": _registry_0}, _text_1, {$: "Some", "value": {$: "../experiments/public-schedule-readers/consumers.Failed", "observation": _text_1}}, ($$$$047src$047ecs$047reader$045domains$058recover$1260$(_runtime_0, _removals_0)));
  } else {
    return $$$$047experiments$047public$045schedule$045readers$047driver$058event_detached$(_which_0, _owners_0, {$: "../experiments/public-schedule-readers/driver.EventOwner", "reader": _reader_0, "registry": _registry_0}, "registration", {$: "Some", "value": {$: "../experiments/public-schedule-readers/consumers.Failed", "observation": "registration"}}, ($$$$047src$047ecs$047reader$045domains$058recover$1260$(_runtime_0, _removals_0)));
  }
}

function $$$$047src$047ecs$047event$045runtime$058run$1260$(_runtime_0, _reader_0, _registry_0, _args_0) {
  return $$$$047src$047ecs$047event$045runtime$058run_identified$1260$(_runtime_0, _reader_0, ($$$$047src$047ecs$047system$058identity$1260$(_registry_0)), _args_0);
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058event_args$(_config_0, _name_0) {
  const _fail_0 = _config_0["eventFail"];
  return {$: "../experiments/public-schedule-readers/consumers.ReadArgs", "name": _name_0, "fail": _fail_0, "own": false, "cursor": 0};
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058collect_result$(_owners_0, _result_0) {
  const _t_0 = _owners_0["events"];
  if (_t_0.$ === "../experiments/public-schedule-readers/driver.Occupied") {
    const _events_0 = _t_0["owner"];
    const _t_1 = _owners_0["fast"];
    if (_t_1.$ === "../experiments/public-schedule-readers/driver.Occupied") {
      const _fast_0 = _t_1["owner"];
      const _t_2 = _owners_0["slow"];
      if (_t_2.$ === "../experiments/public-schedule-readers/driver.Occupied") {
        const _slow_0 = _t_2["owner"];
        const _t_3 = _owners_0["changeFast"];
        if (_t_3.$ === "../experiments/public-schedule-readers/driver.Occupied") {
          const _cf_0 = _t_3["owner"];
          const _t_4 = _owners_0["changeSlow"];
          if (_t_4.$ === "../experiments/public-schedule-readers/driver.Occupied") {
            const _cs_0 = _t_4["owner"];
            const _t_5 = _owners_0["removalFast"];
            if (_t_5.$ === "../experiments/public-schedule-readers/driver.Occupied") {
              const _rf_0 = _t_5["owner"];
              const _t_6 = _owners_0["removalSlow"];
              if (_t_6.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                const _rs_0 = _t_6["owner"];
                const _t_7 = _owners_0["operation"];
                if (_t_7.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                  const _operation_0 = _t_7["owner"];
                  const _config_0 = _owners_0["config"];
                  const _reads_0 = _owners_0["reads"];
                  if (_result_0.$ === "../src/ecs/system.Succeeded") {
                    const _world_0 = _result_0["world"];
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058refreshed$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Empty"}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_0}, "config": _config_0, "reads": _reads_0}, ($$$$047src$047ecs$047reader$045domains$058collect$1260$(_events_0, _world_0)), {$: "None"});
                  } else {
                    const _world_1 = _result_0["world"];
                    const _error_0 = _result_0["error"];
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058refreshed$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Empty"}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_0}, "config": _config_0, "reads": _reads_0}, ($$$$047src$047ecs$047reader$045domains$058collect$1260$(_events_0, _world_1)), {$: "Some", "value": _error_0});
                  }
                } else {
                  const _config_1 = _owners_0["config"];
                  const _reads_1 = _owners_0["reads"];
                  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": _t_7, "config": _config_1, "reads": _reads_1}, "snd": _result_0};
                }
              } else {
                const _67_0 = _owners_0["operation"];
                const _config_2 = _owners_0["config"];
                const _reads_2 = _owners_0["reads"];
                return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": _t_6, "operation": _67_0, "config": _config_2, "reads": _reads_2}, "snd": _result_0};
              }
            } else {
              const _66_0 = _owners_0["removalSlow"];
              const _67_1 = _owners_0["operation"];
              const _config_3 = _owners_0["config"];
              const _reads_3 = _owners_0["reads"];
              return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": _t_5, "removalSlow": _66_0, "operation": _67_1, "config": _config_3, "reads": _reads_3}, "snd": _result_0};
            }
          } else {
            const _65_0 = _owners_0["removalFast"];
            const _66_1 = _owners_0["removalSlow"];
            const _67_2 = _owners_0["operation"];
            const _config_4 = _owners_0["config"];
            const _reads_4 = _owners_0["reads"];
            return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": _t_4, "removalFast": _65_0, "removalSlow": _66_1, "operation": _67_2, "config": _config_4, "reads": _reads_4}, "snd": _result_0};
          }
        } else {
          const _64_0 = _owners_0["changeSlow"];
          const _65_1 = _owners_0["removalFast"];
          const _66_2 = _owners_0["removalSlow"];
          const _67_3 = _owners_0["operation"];
          const _config_5 = _owners_0["config"];
          const _reads_5 = _owners_0["reads"];
          return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": _t_3, "changeSlow": _64_0, "removalFast": _65_1, "removalSlow": _66_2, "operation": _67_3, "config": _config_5, "reads": _reads_5}, "snd": _result_0};
        }
      } else {
        const _63_0 = _owners_0["changeFast"];
        const _64_1 = _owners_0["changeSlow"];
        const _65_2 = _owners_0["removalFast"];
        const _66_3 = _owners_0["removalSlow"];
        const _67_4 = _owners_0["operation"];
        const _config_6 = _owners_0["config"];
        const _reads_6 = _owners_0["reads"];
        return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": _t_2, "changeFast": _63_0, "changeSlow": _64_1, "removalFast": _65_2, "removalSlow": _66_3, "operation": _67_4, "config": _config_6, "reads": _reads_6}, "snd": _result_0};
      }
    } else {
      const _62_0 = _owners_0["slow"];
      const _63_1 = _owners_0["changeFast"];
      const _64_2 = _owners_0["changeSlow"];
      const _65_3 = _owners_0["removalFast"];
      const _66_4 = _owners_0["removalSlow"];
      const _67_5 = _owners_0["operation"];
      const _config_7 = _owners_0["config"];
      const _reads_7 = _owners_0["reads"];
      return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": _t_1, "slow": _62_0, "changeFast": _63_1, "changeSlow": _64_2, "removalFast": _65_3, "removalSlow": _66_4, "operation": _67_5, "config": _config_7, "reads": _reads_7}, "snd": _result_0};
    }
  } else {
    const _61_0 = _owners_0["fast"];
    const _62_1 = _owners_0["slow"];
    const _63_2 = _owners_0["changeFast"];
    const _64_3 = _owners_0["changeSlow"];
    const _65_4 = _owners_0["removalFast"];
    const _66_5 = _owners_0["removalSlow"];
    const _67_6 = _owners_0["operation"];
    const _config_8 = _owners_0["config"];
    const _reads_8 = _owners_0["reads"];
    return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": _t_0, "fast": _61_0, "slow": _62_1, "changeFast": _63_2, "changeSlow": _64_3, "removalFast": _65_4, "removalSlow": _66_5, "operation": _67_6, "config": _config_8, "reads": _reads_8}, "snd": _result_0};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058op_world$(_result_0) {
  if (_result_0.$ === "../src/ecs/system.Completed") {
    const _outcome_0 = _result_0["outcome"];
    return $$$$047experiments$047public$045schedule$045readers$047driver$058outcome_world$(_outcome_0);
  } else {
    const _world_0 = _result_0["world"];
    return _world_0;
  }
}

function $$$$047src$047ecs$047system$058run_namespace$1262$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047src$047ecs$047system$058run_namespace_value$1262$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058removal_finished$(_which_0, _name_0, _owners_0, _result_0) {
  if (_result_0.$ === "../src/ecs/removals.Completed") {
    const _reader_0 = _result_0["reader"];
    const _t_0 = _result_0["outcome"];
    if (_t_0.$ === "../src/ecs/system.Succeeded") {
      const _world_0 = _t_0["world"];
      const _text_0 = _t_0["output"];
      const _x_0 = (_text_0 + "}");
      const _x_1 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058quoted$(_name_0));
      const _x_2 = ("," + _x_0);
      const _x_3 = (_x_1 + _x_2);
      return $$$$047experiments$047public$045schedule$045readers$047driver$058removal_rejoined$(_which_0, _owners_0, _reader_0, _world_0, ("{\"kind\":\"removal\",\"name\":" + _x_3), false);
    } else {
      const _world_1 = _t_0["world"];
      const _text_1 = _t_0["error"];
      const _x_4 = (_text_1 + "}");
      const _x_5 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058quoted$(_name_0));
      const _x_6 = ("," + _x_4);
      const _x_7 = (_x_5 + _x_6);
      return $$$$047experiments$047public$045schedule$045readers$047driver$058removal_rejoined$(_which_0, _owners_0, _reader_0, _world_1, ("{\"kind\":\"removal\",\"name\":" + _x_7), true);
    }
  } else {
    const _reader_1 = _result_0["reader"];
    const _world_2 = _result_0["world"];
    return $$$$047experiments$047public$045schedule$045readers$047driver$058removal_rejoined$(_which_0, _owners_0, _reader_1, _world_2, "removal-invalid", true);
  }
}

function $$$$047src$047ecs$047removals$058run$1260$(_reader_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047removals$058named$1260$(_reader_0, {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _ns_0);
}

function $$$$047src$047ecs$047removals$058run$1261$(_reader_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047removals$058named$1261$(_reader_0, {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _ns_0);
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058cf_completed$(_owners_0, _result_0) {
  const _t_0 = _owners_0["events"];
  if (_t_0.$ === "../experiments/public-schedule-readers/driver.Occupied") {
    const _events_0 = _t_0["owner"];
    const _t_1 = _owners_0["fast"];
    if (_t_1.$ === "../experiments/public-schedule-readers/driver.Occupied") {
      const _fast_0 = _t_1["owner"];
      const _t_2 = _owners_0["slow"];
      if (_t_2.$ === "../experiments/public-schedule-readers/driver.Occupied") {
        const _slow_0 = _t_2["owner"];
        const __0 = _owners_0["changeFast"];
        const _t_3 = _owners_0["changeSlow"];
        if (_t_3.$ === "../experiments/public-schedule-readers/driver.Occupied") {
          const _cs_0 = _t_3["owner"];
          const _t_4 = _owners_0["removalFast"];
          if (_t_4.$ === "../experiments/public-schedule-readers/driver.Occupied") {
            const _rf_0 = _t_4["owner"];
            const _t_5 = _owners_0["removalSlow"];
            if (_t_5.$ === "../experiments/public-schedule-readers/driver.Occupied") {
              const _rs_0 = _t_5["owner"];
              const _t_6 = _owners_0["operation"];
              if (_t_6.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                const _operation_0 = _t_6["owner"];
                const _config_0 = _owners_0["config"];
                const _reads_0 = _owners_0["reads"];
                if (_result_0.$ === "../src/ecs/system.Completed") {
                  const _new_0 = _result_0["registry"];
                  const _t_7 = _result_0["outcome"];
                  if (_t_7.$ === "../src/ecs/system.Succeeded") {
                    const _world_0 = _t_7["world"];
                    const _text_0 = _t_7["output"];
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058collect_result$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _new_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_0}, "config": _config_0, "reads": ($$$$047experiments$047public$045schedule$045readers$047driver$058append_read$(_reads_0, _text_0))}, {$: "../src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}});
                  } else {
                    const _world_1 = _t_7["world"];
                    const _t_8 = _t_7["error"];
                    const _text_1 = _t_8["observation"];
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058collect_result$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _new_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_0}, "config": _config_0, "reads": ($$$$047experiments$047public$045schedule$045readers$047driver$058append_read$(_reads_0, _text_1))}, {$: "../src/ecs/system.Failed", "world": _world_1, "error": {$: "../experiments/public-schedule-readers/consumers.Failed", "observation": _text_1}});
                  }
                } else {
                  const _new_1 = _result_0["registry"];
                  const _world_2 = _result_0["world"];
                  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _new_1}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_0}, "config": _config_0, "reads": _reads_0}, "snd": {$: "../src/ecs/system.Failed", "world": _world_2, "error": {$: "../experiments/public-schedule-readers/consumers.Failed", "observation": "registration"}}};
                }
              } else {
                const _config_1 = _owners_0["config"];
                const _reads_1 = _owners_0["reads"];
                return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": __0, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": _t_6, "config": _config_1, "reads": _reads_1}, "snd": {$: "../src/ecs/system.Failed", "world": ($$$$047experiments$047public$045schedule$045readers$047driver$058change_world$(_result_0)), "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-fast"))}};
              }
            } else {
              const _99_0 = _owners_0["operation"];
              const _config_2 = _owners_0["config"];
              const _reads_2 = _owners_0["reads"];
              return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": __0, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": _t_5, "operation": _99_0, "config": _config_2, "reads": _reads_2}, "snd": {$: "../src/ecs/system.Failed", "world": ($$$$047experiments$047public$045schedule$045readers$047driver$058change_world$(_result_0)), "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-fast"))}};
            }
          } else {
            const _98_0 = _owners_0["removalSlow"];
            const _99_1 = _owners_0["operation"];
            const _config_3 = _owners_0["config"];
            const _reads_3 = _owners_0["reads"];
            return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": __0, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": _t_4, "removalSlow": _98_0, "operation": _99_1, "config": _config_3, "reads": _reads_3}, "snd": {$: "../src/ecs/system.Failed", "world": ($$$$047experiments$047public$045schedule$045readers$047driver$058change_world$(_result_0)), "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-fast"))}};
          }
        } else {
          const _97_0 = _owners_0["removalFast"];
          const _98_1 = _owners_0["removalSlow"];
          const _99_2 = _owners_0["operation"];
          const _config_4 = _owners_0["config"];
          const _reads_4 = _owners_0["reads"];
          return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": __0, "changeSlow": _t_3, "removalFast": _97_0, "removalSlow": _98_1, "operation": _99_2, "config": _config_4, "reads": _reads_4}, "snd": {$: "../src/ecs/system.Failed", "world": ($$$$047experiments$047public$045schedule$045readers$047driver$058change_world$(_result_0)), "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-fast"))}};
        }
      } else {
        const __2 = _owners_0["changeFast"];
        const _96_0 = _owners_0["changeSlow"];
        const _97_1 = _owners_0["removalFast"];
        const _98_2 = _owners_0["removalSlow"];
        const _99_3 = _owners_0["operation"];
        const _config_5 = _owners_0["config"];
        const _reads_5 = _owners_0["reads"];
        return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": _t_2, "changeFast": __2, "changeSlow": _96_0, "removalFast": _97_1, "removalSlow": _98_2, "operation": _99_3, "config": _config_5, "reads": _reads_5}, "snd": {$: "../src/ecs/system.Failed", "world": ($$$$047experiments$047public$045schedule$045readers$047driver$058change_world$(_result_0)), "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-fast"))}};
      }
    } else {
      const _95_0 = _owners_0["slow"];
      const __3 = _owners_0["changeFast"];
      const _96_1 = _owners_0["changeSlow"];
      const _97_2 = _owners_0["removalFast"];
      const _98_3 = _owners_0["removalSlow"];
      const _99_4 = _owners_0["operation"];
      const _config_6 = _owners_0["config"];
      const _reads_6 = _owners_0["reads"];
      return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": _t_1, "slow": _95_0, "changeFast": __3, "changeSlow": _96_1, "removalFast": _97_2, "removalSlow": _98_3, "operation": _99_4, "config": _config_6, "reads": _reads_6}, "snd": {$: "../src/ecs/system.Failed", "world": ($$$$047experiments$047public$045schedule$045readers$047driver$058change_world$(_result_0)), "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-fast"))}};
    }
  } else {
    const _94_0 = _owners_0["fast"];
    const _95_1 = _owners_0["slow"];
    const __4 = _owners_0["changeFast"];
    const _96_2 = _owners_0["changeSlow"];
    const _97_3 = _owners_0["removalFast"];
    const _98_4 = _owners_0["removalSlow"];
    const _99_5 = _owners_0["operation"];
    const _config_7 = _owners_0["config"];
    const _reads_7 = _owners_0["reads"];
    return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": _t_0, "fast": _94_0, "slow": _95_1, "changeFast": __4, "changeSlow": _96_2, "removalFast": _97_3, "removalSlow": _98_4, "operation": _99_5, "config": _config_7, "reads": _reads_7}, "snd": {$: "../src/ecs/system.Failed", "world": ($$$$047experiments$047public$045schedule$045readers$047driver$058change_world$(_result_0)), "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-fast"))}};
  }
}

function $$$$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047src$047ecs$047system$058tracked_result$1260$(($$$$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058change_args$(_config_0, _name_0, _cursor_0) {
  const _fail_0 = _config_0["changeFail"];
  const _own_0 = _config_0["own"];
  return {$: "../experiments/public-schedule-readers/consumers.ReadArgs", "name": _name_0, "fail": _fail_0, "own": _own_0, "cursor": _cursor_0};
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058cs_completed$(_owners_0, _result_0) {
  const _t_0 = _owners_0["events"];
  if (_t_0.$ === "../experiments/public-schedule-readers/driver.Occupied") {
    const _events_0 = _t_0["owner"];
    const _t_1 = _owners_0["fast"];
    if (_t_1.$ === "../experiments/public-schedule-readers/driver.Occupied") {
      const _fast_0 = _t_1["owner"];
      const _t_2 = _owners_0["slow"];
      if (_t_2.$ === "../experiments/public-schedule-readers/driver.Occupied") {
        const _slow_0 = _t_2["owner"];
        const _t_3 = _owners_0["changeFast"];
        if (_t_3.$ === "../experiments/public-schedule-readers/driver.Occupied") {
          const _cf_0 = _t_3["owner"];
          const __0 = _owners_0["changeSlow"];
          const _t_4 = _owners_0["removalFast"];
          if (_t_4.$ === "../experiments/public-schedule-readers/driver.Occupied") {
            const _rf_0 = _t_4["owner"];
            const _t_5 = _owners_0["removalSlow"];
            if (_t_5.$ === "../experiments/public-schedule-readers/driver.Occupied") {
              const _rs_0 = _t_5["owner"];
              const _t_6 = _owners_0["operation"];
              if (_t_6.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                const _operation_0 = _t_6["owner"];
                const _config_0 = _owners_0["config"];
                const _reads_0 = _owners_0["reads"];
                if (_result_0.$ === "../src/ecs/system.Completed") {
                  const _new_0 = _result_0["registry"];
                  const _t_7 = _result_0["outcome"];
                  if (_t_7.$ === "../src/ecs/system.Succeeded") {
                    const _world_0 = _t_7["world"];
                    const _text_0 = _t_7["output"];
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058collect_result$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _new_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_0}, "config": _config_0, "reads": ($$$$047experiments$047public$045schedule$045readers$047driver$058append_read$(_reads_0, _text_0))}, {$: "../src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}});
                  } else {
                    const _world_1 = _t_7["world"];
                    const _t_8 = _t_7["error"];
                    const _text_1 = _t_8["observation"];
                    return $$$$047experiments$047public$045schedule$045readers$047driver$058collect_result$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _new_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_0}, "config": _config_0, "reads": ($$$$047experiments$047public$045schedule$045readers$047driver$058append_read$(_reads_0, _text_1))}, {$: "../src/ecs/system.Failed", "world": _world_1, "error": {$: "../experiments/public-schedule-readers/consumers.Failed", "observation": _text_1}});
                  }
                } else {
                  const _new_1 = _result_0["registry"];
                  const _world_2 = _result_0["world"];
                  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _new_1}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_0}, "config": _config_0, "reads": _reads_0}, "snd": {$: "../src/ecs/system.Failed", "world": _world_2, "error": {$: "../experiments/public-schedule-readers/consumers.Failed", "observation": "registration"}}};
                }
              } else {
                const _config_1 = _owners_0["config"];
                const _reads_1 = _owners_0["reads"];
                return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": __0, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": _t_6, "config": _config_1, "reads": _reads_1}, "snd": {$: "../src/ecs/system.Failed", "world": ($$$$047experiments$047public$045schedule$045readers$047driver$058change_world$(_result_0)), "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-slow"))}};
              }
            } else {
              const _99_0 = _owners_0["operation"];
              const _config_2 = _owners_0["config"];
              const _reads_2 = _owners_0["reads"];
              return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": __0, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": _t_5, "operation": _99_0, "config": _config_2, "reads": _reads_2}, "snd": {$: "../src/ecs/system.Failed", "world": ($$$$047experiments$047public$045schedule$045readers$047driver$058change_world$(_result_0)), "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-slow"))}};
            }
          } else {
            const _98_0 = _owners_0["removalSlow"];
            const _99_1 = _owners_0["operation"];
            const _config_3 = _owners_0["config"];
            const _reads_3 = _owners_0["reads"];
            return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": __0, "removalFast": _t_4, "removalSlow": _98_0, "operation": _99_1, "config": _config_3, "reads": _reads_3}, "snd": {$: "../src/ecs/system.Failed", "world": ($$$$047experiments$047public$045schedule$045readers$047driver$058change_world$(_result_0)), "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-slow"))}};
          }
        } else {
          const __2 = _owners_0["changeSlow"];
          const _97_0 = _owners_0["removalFast"];
          const _98_1 = _owners_0["removalSlow"];
          const _99_2 = _owners_0["operation"];
          const _config_4 = _owners_0["config"];
          const _reads_4 = _owners_0["reads"];
          return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": _t_3, "changeSlow": __2, "removalFast": _97_0, "removalSlow": _98_1, "operation": _99_2, "config": _config_4, "reads": _reads_4}, "snd": {$: "../src/ecs/system.Failed", "world": ($$$$047experiments$047public$045schedule$045readers$047driver$058change_world$(_result_0)), "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-slow"))}};
        }
      } else {
        const _96_0 = _owners_0["changeFast"];
        const __3 = _owners_0["changeSlow"];
        const _97_1 = _owners_0["removalFast"];
        const _98_2 = _owners_0["removalSlow"];
        const _99_3 = _owners_0["operation"];
        const _config_5 = _owners_0["config"];
        const _reads_5 = _owners_0["reads"];
        return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": _t_2, "changeFast": _96_0, "changeSlow": __3, "removalFast": _97_1, "removalSlow": _98_2, "operation": _99_3, "config": _config_5, "reads": _reads_5}, "snd": {$: "../src/ecs/system.Failed", "world": ($$$$047experiments$047public$045schedule$045readers$047driver$058change_world$(_result_0)), "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-slow"))}};
      }
    } else {
      const _95_0 = _owners_0["slow"];
      const _96_1 = _owners_0["changeFast"];
      const __4 = _owners_0["changeSlow"];
      const _97_2 = _owners_0["removalFast"];
      const _98_3 = _owners_0["removalSlow"];
      const _99_4 = _owners_0["operation"];
      const _config_6 = _owners_0["config"];
      const _reads_6 = _owners_0["reads"];
      return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": _t_1, "slow": _95_0, "changeFast": _96_1, "changeSlow": __4, "removalFast": _97_2, "removalSlow": _98_3, "operation": _99_4, "config": _config_6, "reads": _reads_6}, "snd": {$: "../src/ecs/system.Failed", "world": ($$$$047experiments$047public$045schedule$045readers$047driver$058change_world$(_result_0)), "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-slow"))}};
    }
  } else {
    const _94_0 = _owners_0["fast"];
    const _95_1 = _owners_0["slow"];
    const _96_2 = _owners_0["changeFast"];
    const __5 = _owners_0["changeSlow"];
    const _97_3 = _owners_0["removalFast"];
    const _98_4 = _owners_0["removalSlow"];
    const _99_5 = _owners_0["operation"];
    const _config_7 = _owners_0["config"];
    const _reads_7 = _owners_0["reads"];
    return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": _t_0, "fast": _94_0, "slow": _95_1, "changeFast": _96_2, "changeSlow": __5, "removalFast": _97_3, "removalSlow": _98_4, "operation": _99_5, "config": _config_7, "reads": _reads_7}, "snd": {$: "../src/ecs/system.Failed", "world": ($$$$047experiments$047public$045schedule$045readers$047driver$058change_world$(_result_0)), "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("change-slow"))}};
  }
}

function $$$$047src$047ecs$047lifecycle$058keep$(_equal_0, _entry_0, _rest_0) {
  if (_equal_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _entry_0, "tail": _rest_0};
  }
}

function $$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)));
}

function $$$$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0, _fits_0) {
  if (!_isnormal_0) {
    return {$: "Tuple", "fst": {$: "../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": ($$$$047src$047ecs$047lifecycle$058get$(_exceptional_0, _id_0))};
  } else {
    if (!_fits_0) {
      return {$: "Tuple", "fst": {$: "../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
    } else {
      const _x_0 = ((_id_0 - 1) >>> 0);
      return $$$$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, {$: "Tuple", fst: _added_0, snd: _added_0[_x_0 % _added_0.length]});
    }
  }
}

function $$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0) {
  return $Bool$and$((_id_0 > 0), (_id_0 <= 131072));
}

function $$$$047src$047ecs$047column$058recover_current$1263$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../src/ecs/column.Column", "values": ($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1263$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../src/ecs/column.Column", "values": ($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1263$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047src$047ecs$047column$058indexed_recover_current$1263$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047src$047ecs$047column$058indexed_wrap$1263$(($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1263$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047src$047ecs$047column$058indexed_wrap$1263$(($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1263$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $Bool$to_u32$(_b_0) {
  if (!_b_0) {
    return 0;
  } else {
    return 1;
  }
}

function $$$$047src$047ecs$047system$058run_metadata$1263$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047src$047ecs$047system$058run_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047src$047ecs$047column$058plain_view_taken$1263$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047src$047ecs$047column$058plain_view_projected$1263$(_values_0, _stamps_0, _id_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058project_enabled$(_owner_0)));
  }
}

function $$$$047src$047ecs$047column$058prepared_view_current$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047src$047ecs$047column$058prepared_view_projected$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058project_enabled$(_owned_0)));
  }
}

function $$$$047src$047ecs$047column$058prepared_view_different$1263$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047src$047ecs$047column$058view_taken$1263$(_id_0, ($$$$047src$047ecs$047column$058swap_recovered$1263$(_id_0, {$: "None"}, ($$$$047src$047ecs$047column$058recover_current$1263$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047src$047ecs$047column$058seek_view$1263$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1263$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
  }
}

function $$$$047src$047ecs$047column$058indexed_view_checked$1263$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047src$047ecs$047column$058indexed_view_taken$1263$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_current$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047src$047ecs$047column$058indexed_prepared_view_projected$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058project_enabled$(_owned_0)));
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_different$1263$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047src$047ecs$047column$058view_taken$1263$(_id_0, ($$$$047src$047ecs$047column$058swap_recovered$1263$(_id_0, {$: "None"}, ($$$$047src$047ecs$047column$058indexed_recover_current$1263$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047src$047ecs$047column$058indexed_seek_view$1263$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1263$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
  }
}

function $$$$047src$047ecs$047column$058swap_state$1262$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058prepared_swap$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047src$047ecs$047column$058indexed_prepared_swap_state$1262$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_prepared_swap$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047src$047ecs$047column$058swapped$1262$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047src$047ecs$047column$058indexed_swap_checked$1262$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": ($$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047src$047ecs$047column$058indexed_swapped$1262$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058recover$1260$({$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047src$047ecs$047column$058seek$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058recover$1260$({$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047src$047ecs$047column$058indexed_seek$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../src/ecs/column.Accepted", "column": ($$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058event_detached$(_which_0, _owners_0, _new_0, _text_0, _error_0, _result_0) {
  if (_which_0) {
    const __0 = _owners_0["events"];
    const __1 = _owners_0["fast"];
    const _t_0 = _owners_0["slow"];
    if (_t_0.$ === "../experiments/public-schedule-readers/driver.Occupied") {
      const _slow_0 = _t_0["owner"];
      const _t_1 = _owners_0["changeFast"];
      if (_t_1.$ === "../experiments/public-schedule-readers/driver.Occupied") {
        const _cf_0 = _t_1["owner"];
        const _t_2 = _owners_0["changeSlow"];
        if (_t_2.$ === "../experiments/public-schedule-readers/driver.Occupied") {
          const _cs_0 = _t_2["owner"];
          const _t_3 = _owners_0["removalFast"];
          if (_t_3.$ === "../experiments/public-schedule-readers/driver.Occupied") {
            const _rf_0 = _t_3["owner"];
            const _t_4 = _owners_0["removalSlow"];
            if (_t_4.$ === "../experiments/public-schedule-readers/driver.Occupied") {
              const _rs_0 = _t_4["owner"];
              const _t_5 = _owners_0["operation"];
              if (_t_5.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                const _operation_0 = _t_5["owner"];
                const _config_0 = _owners_0["config"];
                const _reads_0 = _owners_0["reads"];
                return $$$$047experiments$047public$045schedule$045readers$047driver$058refreshed$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Empty"}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _new_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_0}, "config": _config_0, "reads": ($$$$047experiments$047public$045schedule$045readers$047driver$058append_read$(_reads_0, _text_0))}, _result_0, _error_0);
              } else {
                const _config_1 = _owners_0["config"];
                const _reads_1 = _owners_0["reads"];
                const _world_0 = _result_0["world"];
                return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": __1, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": _t_5, "config": _config_1, "reads": _reads_1}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event"))}};
              }
            } else {
              const _71_0 = _owners_0["operation"];
              const _config_2 = _owners_0["config"];
              const _reads_2 = _owners_0["reads"];
              const _world_1 = _result_0["world"];
              return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": __1, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": _t_4, "operation": _71_0, "config": _config_2, "reads": _reads_2}, "snd": {$: "../src/ecs/system.Failed", "world": _world_1, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event"))}};
            }
          } else {
            const _70_0 = _owners_0["removalSlow"];
            const _71_1 = _owners_0["operation"];
            const _config_3 = _owners_0["config"];
            const _reads_3 = _owners_0["reads"];
            const _world_2 = _result_0["world"];
            return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": __1, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": _t_3, "removalSlow": _70_0, "operation": _71_1, "config": _config_3, "reads": _reads_3}, "snd": {$: "../src/ecs/system.Failed", "world": _world_2, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event"))}};
          }
        } else {
          const _69_0 = _owners_0["removalFast"];
          const _70_1 = _owners_0["removalSlow"];
          const _71_2 = _owners_0["operation"];
          const _config_4 = _owners_0["config"];
          const _reads_4 = _owners_0["reads"];
          const _world_3 = _result_0["world"];
          return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": __1, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": _t_2, "removalFast": _69_0, "removalSlow": _70_1, "operation": _71_2, "config": _config_4, "reads": _reads_4}, "snd": {$: "../src/ecs/system.Failed", "world": _world_3, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event"))}};
        }
      } else {
        const _68_0 = _owners_0["changeSlow"];
        const _69_1 = _owners_0["removalFast"];
        const _70_2 = _owners_0["removalSlow"];
        const _71_3 = _owners_0["operation"];
        const _config_5 = _owners_0["config"];
        const _reads_5 = _owners_0["reads"];
        const _world_4 = _result_0["world"];
        return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": __1, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": _t_1, "changeSlow": _68_0, "removalFast": _69_1, "removalSlow": _70_2, "operation": _71_3, "config": _config_5, "reads": _reads_5}, "snd": {$: "../src/ecs/system.Failed", "world": _world_4, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event"))}};
      }
    } else {
      const _67_0 = _owners_0["changeFast"];
      const _68_1 = _owners_0["changeSlow"];
      const _69_2 = _owners_0["removalFast"];
      const _70_3 = _owners_0["removalSlow"];
      const _71_4 = _owners_0["operation"];
      const _config_6 = _owners_0["config"];
      const _reads_6 = _owners_0["reads"];
      const _world_5 = _result_0["world"];
      return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": __1, "slow": _t_0, "changeFast": _67_0, "changeSlow": _68_1, "removalFast": _69_2, "removalSlow": _70_3, "operation": _71_4, "config": _config_6, "reads": _reads_6}, "snd": {$: "../src/ecs/system.Failed", "world": _world_5, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event"))}};
    }
  } else {
    const __8 = _owners_0["events"];
    const _t_6 = _owners_0["fast"];
    if (_t_6.$ === "../experiments/public-schedule-readers/driver.Occupied") {
      const _fast_0 = _t_6["owner"];
      const __9 = _owners_0["slow"];
      const _t_7 = _owners_0["changeFast"];
      if (_t_7.$ === "../experiments/public-schedule-readers/driver.Occupied") {
        const _cf_1 = _t_7["owner"];
        const _t_8 = _owners_0["changeSlow"];
        if (_t_8.$ === "../experiments/public-schedule-readers/driver.Occupied") {
          const _cs_1 = _t_8["owner"];
          const _t_9 = _owners_0["removalFast"];
          if (_t_9.$ === "../experiments/public-schedule-readers/driver.Occupied") {
            const _rf_1 = _t_9["owner"];
            const _t_10 = _owners_0["removalSlow"];
            if (_t_10.$ === "../experiments/public-schedule-readers/driver.Occupied") {
              const _rs_1 = _t_10["owner"];
              const _t_11 = _owners_0["operation"];
              if (_t_11.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                const _operation_1 = _t_11["owner"];
                const _config_7 = _owners_0["config"];
                const _reads_7 = _owners_0["reads"];
                return $$$$047experiments$047public$045schedule$045readers$047driver$058refreshed$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Empty"}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _new_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_1}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_1}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_1}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_1}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_1}, "config": _config_7, "reads": ($$$$047experiments$047public$045schedule$045readers$047driver$058append_read$(_reads_7, _text_0))}, _result_0, _error_0);
              } else {
                const _config_8 = _owners_0["config"];
                const _reads_8 = _owners_0["reads"];
                const _world_6 = _result_0["world"];
                return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __8, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": __9, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_1}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_1}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_1}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_1}, "operation": _t_11, "config": _config_8, "reads": _reads_8}, "snd": {$: "../src/ecs/system.Failed", "world": _world_6, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event"))}};
              }
            } else {
              const _77_0 = _owners_0["operation"];
              const _config_9 = _owners_0["config"];
              const _reads_9 = _owners_0["reads"];
              const _world_7 = _result_0["world"];
              return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __8, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": __9, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_1}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_1}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_1}, "removalSlow": _t_10, "operation": _77_0, "config": _config_9, "reads": _reads_9}, "snd": {$: "../src/ecs/system.Failed", "world": _world_7, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event"))}};
            }
          } else {
            const _76_0 = _owners_0["removalSlow"];
            const _77_1 = _owners_0["operation"];
            const _config_10 = _owners_0["config"];
            const _reads_10 = _owners_0["reads"];
            const _world_8 = _result_0["world"];
            return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __8, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": __9, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_1}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_1}, "removalFast": _t_9, "removalSlow": _76_0, "operation": _77_1, "config": _config_10, "reads": _reads_10}, "snd": {$: "../src/ecs/system.Failed", "world": _world_8, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event"))}};
          }
        } else {
          const _75_0 = _owners_0["removalFast"];
          const _76_1 = _owners_0["removalSlow"];
          const _77_2 = _owners_0["operation"];
          const _config_11 = _owners_0["config"];
          const _reads_11 = _owners_0["reads"];
          const _world_9 = _result_0["world"];
          return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __8, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": __9, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_1}, "changeSlow": _t_8, "removalFast": _75_0, "removalSlow": _76_1, "operation": _77_2, "config": _config_11, "reads": _reads_11}, "snd": {$: "../src/ecs/system.Failed", "world": _world_9, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event"))}};
        }
      } else {
        const _74_0 = _owners_0["changeSlow"];
        const _75_1 = _owners_0["removalFast"];
        const _76_2 = _owners_0["removalSlow"];
        const _77_3 = _owners_0["operation"];
        const _config_12 = _owners_0["config"];
        const _reads_12 = _owners_0["reads"];
        const _world_10 = _result_0["world"];
        return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __8, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": __9, "changeFast": _t_7, "changeSlow": _74_0, "removalFast": _75_1, "removalSlow": _76_2, "operation": _77_3, "config": _config_12, "reads": _reads_12}, "snd": {$: "../src/ecs/system.Failed", "world": _world_10, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event"))}};
      }
    } else {
      const __15 = _owners_0["slow"];
      const _73_0 = _owners_0["changeFast"];
      const _74_1 = _owners_0["changeSlow"];
      const _75_2 = _owners_0["removalFast"];
      const _76_3 = _owners_0["removalSlow"];
      const _77_4 = _owners_0["operation"];
      const _config_13 = _owners_0["config"];
      const _reads_13 = _owners_0["reads"];
      const _world_11 = _result_0["world"];
      return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __8, "fast": _t_6, "slow": __15, "changeFast": _73_0, "changeSlow": _74_1, "removalFast": _75_2, "removalSlow": _76_3, "operation": _77_4, "config": _config_13, "reads": _reads_13}, "snd": {$: "../src/ecs/system.Failed", "world": _world_11, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("event"))}};
    }
  }
}

function $$$$047src$047ecs$047reader$045domains$058recover$1260$(_runtime_0, _old_removals_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047src$047ecs$047reader$045domains$058recovery_view$1260$(_namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, _old_removals_0, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
}

function $$$$047src$047ecs$047event$045runtime$058run_identified$1260$(_runtime_0, _reader_0, _identified_0, _args_0) {
  const _registry_0 = _identified_0["fst"];
  const _actual_0 = _identified_0["snd"];
  return $$$$047src$047ecs$047event$045runtime$058run_identity$1260$(_runtime_0, _reader_0, _registry_0, _actual_0, _args_0);
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058refreshed$(_owners_0, _result_0, _error_0) {
  const __0 = _owners_0["events"];
  const _t_0 = _owners_0["fast"];
  if (_t_0.$ === "../experiments/public-schedule-readers/driver.Occupied") {
    const _fast_0 = _t_0["owner"];
    const _t_1 = _owners_0["slow"];
    if (_t_1.$ === "../experiments/public-schedule-readers/driver.Occupied") {
      const _slow_0 = _t_1["owner"];
      const _t_2 = _owners_0["changeFast"];
      if (_t_2.$ === "../experiments/public-schedule-readers/driver.Occupied") {
        const _cf_0 = _t_2["owner"];
        const _t_3 = _owners_0["changeSlow"];
        if (_t_3.$ === "../experiments/public-schedule-readers/driver.Occupied") {
          const _cs_0 = _t_3["owner"];
          const _t_4 = _owners_0["removalFast"];
          if (_t_4.$ === "../experiments/public-schedule-readers/driver.Occupied") {
            const _rf_0 = _t_4["owner"];
            const _t_5 = _owners_0["removalSlow"];
            if (_t_5.$ === "../experiments/public-schedule-readers/driver.Occupied") {
              const _rs_0 = _t_5["owner"];
              const _t_6 = _owners_0["operation"];
              if (_t_6.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                const _operation_0 = _t_6["owner"];
                const _config_0 = _owners_0["config"];
                const _reads_0 = _owners_0["reads"];
                const _world_0 = _result_0["world"];
                const _events_0 = _result_0["events"];
                if (_error_0.$ === "None") {
                  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_0}, "config": _config_0, "reads": _reads_0}, "snd": {$: "../src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}}};
                } else {
                  const _error_1 = _error_0["value"];
                  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_0}, "config": _config_0, "reads": _reads_0}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": _error_1}};
                }
              } else {
                const _config_1 = _owners_0["config"];
                const _reads_1 = _owners_0["reads"];
                const _world_1 = _result_0["world"];
                return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": _t_6, "config": _config_1, "reads": _reads_1}, "snd": {$: "../src/ecs/system.Failed", "world": _world_1, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("refreshed"))}};
              }
            } else {
              const _71_0 = _owners_0["operation"];
              const _config_2 = _owners_0["config"];
              const _reads_2 = _owners_0["reads"];
              const _world_2 = _result_0["world"];
              return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": _t_5, "operation": _71_0, "config": _config_2, "reads": _reads_2}, "snd": {$: "../src/ecs/system.Failed", "world": _world_2, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("refreshed"))}};
            }
          } else {
            const _70_0 = _owners_0["removalSlow"];
            const _71_1 = _owners_0["operation"];
            const _config_3 = _owners_0["config"];
            const _reads_3 = _owners_0["reads"];
            const _world_3 = _result_0["world"];
            return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": _t_4, "removalSlow": _70_0, "operation": _71_1, "config": _config_3, "reads": _reads_3}, "snd": {$: "../src/ecs/system.Failed", "world": _world_3, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("refreshed"))}};
          }
        } else {
          const _69_0 = _owners_0["removalFast"];
          const _70_1 = _owners_0["removalSlow"];
          const _71_2 = _owners_0["operation"];
          const _config_4 = _owners_0["config"];
          const _reads_4 = _owners_0["reads"];
          const _world_4 = _result_0["world"];
          return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": _t_3, "removalFast": _69_0, "removalSlow": _70_1, "operation": _71_2, "config": _config_4, "reads": _reads_4}, "snd": {$: "../src/ecs/system.Failed", "world": _world_4, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("refreshed"))}};
        }
      } else {
        const _68_0 = _owners_0["changeSlow"];
        const _69_1 = _owners_0["removalFast"];
        const _70_2 = _owners_0["removalSlow"];
        const _71_3 = _owners_0["operation"];
        const _config_5 = _owners_0["config"];
        const _reads_5 = _owners_0["reads"];
        const _world_5 = _result_0["world"];
        return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": _t_2, "changeSlow": _68_0, "removalFast": _69_1, "removalSlow": _70_2, "operation": _71_3, "config": _config_5, "reads": _reads_5}, "snd": {$: "../src/ecs/system.Failed", "world": _world_5, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("refreshed"))}};
      }
    } else {
      const _67_0 = _owners_0["changeFast"];
      const _68_1 = _owners_0["changeSlow"];
      const _69_2 = _owners_0["removalFast"];
      const _70_3 = _owners_0["removalSlow"];
      const _71_4 = _owners_0["operation"];
      const _config_6 = _owners_0["config"];
      const _reads_6 = _owners_0["reads"];
      const _world_6 = _result_0["world"];
      return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": _t_1, "changeFast": _67_0, "changeSlow": _68_1, "removalFast": _69_2, "removalSlow": _70_3, "operation": _71_4, "config": _config_6, "reads": _reads_6}, "snd": {$: "../src/ecs/system.Failed", "world": _world_6, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("refreshed"))}};
    }
  } else {
    const _66_0 = _owners_0["slow"];
    const _67_1 = _owners_0["changeFast"];
    const _68_2 = _owners_0["changeSlow"];
    const _69_3 = _owners_0["removalFast"];
    const _70_4 = _owners_0["removalSlow"];
    const _71_5 = _owners_0["operation"];
    const _config_7 = _owners_0["config"];
    const _reads_7 = _owners_0["reads"];
    const _world_7 = _result_0["world"];
    return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": __0, "fast": _t_0, "slow": _66_0, "changeFast": _67_1, "changeSlow": _68_2, "removalFast": _69_3, "removalSlow": _70_4, "operation": _71_5, "config": _config_7, "reads": _reads_7}, "snd": {$: "../src/ecs/system.Failed", "world": _world_7, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("refreshed"))}};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058outcome_world$(_result_0) {
  if (_result_0.$ === "../src/ecs/system.Succeeded") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047src$047ecs$047system$058run_namespace_value$1262$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047src$047ecs$047system$058run_namespace_checked$1262$((_namespace_0 === _actual_0), {$: "../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058removal_rejoined$(_which_0, _owners_0, _reader_0, _world_0, _text_0, _fail_0) {
  if (_which_0) {
    const _t_0 = _owners_0["events"];
    if (_t_0.$ === "../experiments/public-schedule-readers/driver.Occupied") {
      const _events_0 = _t_0["owner"];
      const _t_1 = _owners_0["fast"];
      if (_t_1.$ === "../experiments/public-schedule-readers/driver.Occupied") {
        const _fast_0 = _t_1["owner"];
        const _t_2 = _owners_0["slow"];
        if (_t_2.$ === "../experiments/public-schedule-readers/driver.Occupied") {
          const _slow_0 = _t_2["owner"];
          const _t_3 = _owners_0["changeFast"];
          if (_t_3.$ === "../experiments/public-schedule-readers/driver.Occupied") {
            const _cf_0 = _t_3["owner"];
            const _t_4 = _owners_0["changeSlow"];
            if (_t_4.$ === "../experiments/public-schedule-readers/driver.Occupied") {
              const _cs_0 = _t_4["owner"];
              const __0 = _owners_0["removalFast"];
              const _t_5 = _owners_0["removalSlow"];
              if (_t_5.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                const _rs_0 = _t_5["owner"];
                const _t_6 = _owners_0["operation"];
                if (_t_6.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                  const _operation_0 = _t_6["owner"];
                  const _config_0 = _owners_0["config"];
                  const _reads_0 = _owners_0["reads"];
                  return $$$$047experiments$047public$045schedule$045readers$047driver$058collect_result$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _reader_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_0}, "config": _config_0, "reads": ($$$$047experiments$047public$045schedule$045readers$047driver$058append_read$(_reads_0, _text_0))}, ($$$$047experiments$047public$045schedule$045readers$047driver$058as_unit$(($$$$047experiments$047public$045schedule$045readers$047consumers$058finish$(_world_0, _text_0, _fail_0)))));
                } else {
                  const _config_1 = _owners_0["config"];
                  const _reads_1 = _owners_0["reads"];
                  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": __0, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rs_0}, "operation": _t_6, "config": _config_1, "reads": _reads_1}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("removal"))}};
                }
              } else {
                const _69_0 = _owners_0["operation"];
                const _config_2 = _owners_0["config"];
                const _reads_2 = _owners_0["reads"];
                return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_0}, "removalFast": __0, "removalSlow": _t_5, "operation": _69_0, "config": _config_2, "reads": _reads_2}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("removal"))}};
              }
            } else {
              const __1 = _owners_0["removalFast"];
              const _68_0 = _owners_0["removalSlow"];
              const _69_1 = _owners_0["operation"];
              const _config_3 = _owners_0["config"];
              const _reads_3 = _owners_0["reads"];
              return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_0}, "changeSlow": _t_4, "removalFast": __1, "removalSlow": _68_0, "operation": _69_1, "config": _config_3, "reads": _reads_3}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("removal"))}};
            }
          } else {
            const _67_0 = _owners_0["changeSlow"];
            const __2 = _owners_0["removalFast"];
            const _68_1 = _owners_0["removalSlow"];
            const _69_2 = _owners_0["operation"];
            const _config_4 = _owners_0["config"];
            const _reads_4 = _owners_0["reads"];
            return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_0}, "changeFast": _t_3, "changeSlow": _67_0, "removalFast": __2, "removalSlow": _68_1, "operation": _69_2, "config": _config_4, "reads": _reads_4}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("removal"))}};
          }
        } else {
          const _66_0 = _owners_0["changeFast"];
          const _67_1 = _owners_0["changeSlow"];
          const __3 = _owners_0["removalFast"];
          const _68_2 = _owners_0["removalSlow"];
          const _69_3 = _owners_0["operation"];
          const _config_5 = _owners_0["config"];
          const _reads_5 = _owners_0["reads"];
          return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_0}, "slow": _t_2, "changeFast": _66_0, "changeSlow": _67_1, "removalFast": __3, "removalSlow": _68_2, "operation": _69_3, "config": _config_5, "reads": _reads_5}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("removal"))}};
        }
      } else {
        const _65_0 = _owners_0["slow"];
        const _66_1 = _owners_0["changeFast"];
        const _67_2 = _owners_0["changeSlow"];
        const __4 = _owners_0["removalFast"];
        const _68_3 = _owners_0["removalSlow"];
        const _69_4 = _owners_0["operation"];
        const _config_6 = _owners_0["config"];
        const _reads_6 = _owners_0["reads"];
        return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_0}, "fast": _t_1, "slow": _65_0, "changeFast": _66_1, "changeSlow": _67_2, "removalFast": __4, "removalSlow": _68_3, "operation": _69_4, "config": _config_6, "reads": _reads_6}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("removal"))}};
      }
    } else {
      const _64_0 = _owners_0["fast"];
      const _65_1 = _owners_0["slow"];
      const _66_2 = _owners_0["changeFast"];
      const _67_3 = _owners_0["changeSlow"];
      const __5 = _owners_0["removalFast"];
      const _68_4 = _owners_0["removalSlow"];
      const _69_5 = _owners_0["operation"];
      const _config_7 = _owners_0["config"];
      const _reads_7 = _owners_0["reads"];
      return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": _t_0, "fast": _64_0, "slow": _65_1, "changeFast": _66_2, "changeSlow": _67_3, "removalFast": __5, "removalSlow": _68_4, "operation": _69_5, "config": _config_7, "reads": _reads_7}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("removal"))}};
    }
  } else {
    const _t_7 = _owners_0["events"];
    if (_t_7.$ === "../experiments/public-schedule-readers/driver.Occupied") {
      const _events_1 = _t_7["owner"];
      const _t_8 = _owners_0["fast"];
      if (_t_8.$ === "../experiments/public-schedule-readers/driver.Occupied") {
        const _fast_1 = _t_8["owner"];
        const _t_9 = _owners_0["slow"];
        if (_t_9.$ === "../experiments/public-schedule-readers/driver.Occupied") {
          const _slow_1 = _t_9["owner"];
          const _t_10 = _owners_0["changeFast"];
          if (_t_10.$ === "../experiments/public-schedule-readers/driver.Occupied") {
            const _cf_1 = _t_10["owner"];
            const _t_11 = _owners_0["changeSlow"];
            if (_t_11.$ === "../experiments/public-schedule-readers/driver.Occupied") {
              const _cs_1 = _t_11["owner"];
              const _t_12 = _owners_0["removalFast"];
              if (_t_12.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                const _rf_0 = _t_12["owner"];
                const __6 = _owners_0["removalSlow"];
                const _t_13 = _owners_0["operation"];
                if (_t_13.$ === "../experiments/public-schedule-readers/driver.Occupied") {
                  const _operation_1 = _t_13["owner"];
                  const _config_8 = _owners_0["config"];
                  const _reads_8 = _owners_0["reads"];
                  return $$$$047experiments$047public$045schedule$045readers$047driver$058collect_result$({$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_1}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_1}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_1}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_1}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_1}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _reader_0}, "operation": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _operation_1}, "config": _config_8, "reads": ($$$$047experiments$047public$045schedule$045readers$047driver$058append_read$(_reads_8, _text_0))}, ($$$$047experiments$047public$045schedule$045readers$047driver$058as_unit$(($$$$047experiments$047public$045schedule$045readers$047consumers$058finish$(_world_0, _text_0, _fail_0)))));
                } else {
                  const _config_9 = _owners_0["config"];
                  const _reads_9 = _owners_0["reads"];
                  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_1}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_1}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_1}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_1}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_1}, "removalFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _rf_0}, "removalSlow": __6, "operation": _t_13, "config": _config_9, "reads": _reads_9}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("removal"))}};
                }
              } else {
                const __7 = _owners_0["removalSlow"];
                const _76_0 = _owners_0["operation"];
                const _config_10 = _owners_0["config"];
                const _reads_10 = _owners_0["reads"];
                return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_1}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_1}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_1}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_1}, "changeSlow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cs_1}, "removalFast": _t_12, "removalSlow": __7, "operation": _76_0, "config": _config_10, "reads": _reads_10}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("removal"))}};
              }
            } else {
              const _75_0 = _owners_0["removalFast"];
              const __8 = _owners_0["removalSlow"];
              const _76_1 = _owners_0["operation"];
              const _config_11 = _owners_0["config"];
              const _reads_11 = _owners_0["reads"];
              return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_1}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_1}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_1}, "changeFast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _cf_1}, "changeSlow": _t_11, "removalFast": _75_0, "removalSlow": __8, "operation": _76_1, "config": _config_11, "reads": _reads_11}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("removal"))}};
            }
          } else {
            const _74_0 = _owners_0["changeSlow"];
            const _75_1 = _owners_0["removalFast"];
            const __9 = _owners_0["removalSlow"];
            const _76_2 = _owners_0["operation"];
            const _config_12 = _owners_0["config"];
            const _reads_12 = _owners_0["reads"];
            return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_1}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_1}, "slow": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _slow_1}, "changeFast": _t_10, "changeSlow": _74_0, "removalFast": _75_1, "removalSlow": __9, "operation": _76_2, "config": _config_12, "reads": _reads_12}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("removal"))}};
          }
        } else {
          const _73_0 = _owners_0["changeFast"];
          const _74_1 = _owners_0["changeSlow"];
          const _75_2 = _owners_0["removalFast"];
          const __10 = _owners_0["removalSlow"];
          const _76_3 = _owners_0["operation"];
          const _config_13 = _owners_0["config"];
          const _reads_13 = _owners_0["reads"];
          return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_1}, "fast": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _fast_1}, "slow": _t_9, "changeFast": _73_0, "changeSlow": _74_1, "removalFast": _75_2, "removalSlow": __10, "operation": _76_3, "config": _config_13, "reads": _reads_13}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("removal"))}};
        }
      } else {
        const _72_0 = _owners_0["slow"];
        const _73_1 = _owners_0["changeFast"];
        const _74_2 = _owners_0["changeSlow"];
        const _75_3 = _owners_0["removalFast"];
        const __11 = _owners_0["removalSlow"];
        const _76_4 = _owners_0["operation"];
        const _config_14 = _owners_0["config"];
        const _reads_14 = _owners_0["reads"];
        return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": {$: "../experiments/public-schedule-readers/driver.Occupied", "owner": _events_1}, "fast": _t_8, "slow": _72_0, "changeFast": _73_1, "changeSlow": _74_2, "removalFast": _75_3, "removalSlow": __11, "operation": _76_4, "config": _config_14, "reads": _reads_14}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("removal"))}};
      }
    } else {
      const _71_0 = _owners_0["fast"];
      const _72_1 = _owners_0["slow"];
      const _73_2 = _owners_0["changeFast"];
      const _74_3 = _owners_0["changeSlow"];
      const _75_4 = _owners_0["removalFast"];
      const __12 = _owners_0["removalSlow"];
      const _76_5 = _owners_0["operation"];
      const _config_15 = _owners_0["config"];
      const _reads_15 = _owners_0["reads"];
      return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/driver.Owners", "events": _t_7, "fast": _71_0, "slow": _72_1, "changeFast": _73_2, "changeSlow": _74_3, "removalFast": _75_4, "removalSlow": __12, "operation": _76_5, "config": _config_15, "reads": _reads_15}, "snd": {$: "../src/ecs/system.Failed", "world": _world_0, "error": ($$$$047experiments$047public$045schedule$045readers$047driver$058invalid$("removal"))}};
    }
  }
}

function $$$$047src$047ecs$047removals$058named$1260$(_reader_0, _world_0, _actual_0) {
  const _namespace_0 = _reader_0["namespace"];
  const _id_0 = _reader_0["id"];
  const _name_0 = _reader_0["name"];
  const _cursor_0 = _reader_0["cursor"];
  const _ns_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047removals$058checked$1260$(($Bool$and$((_namespace_0 === _actual_0), ($$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, {$: "Con", "head": "removal", "tail": {$: "Con", "head": _name_0, "tail": {$: "Nil"}}})))), {$: "../src/ecs/removals.Reader", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "cursor": _cursor_0}, {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _cursor_0);
}

function $$$$047src$047ecs$047removals$058named$1261$(_reader_0, _world_0, _actual_0) {
  const _namespace_0 = _reader_0["namespace"];
  const _id_0 = _reader_0["id"];
  const _name_0 = _reader_0["name"];
  const _cursor_0 = _reader_0["cursor"];
  const _ns_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047removals$058checked$1261$(($Bool$and$((_namespace_0 === _actual_0), ($$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, {$: "Con", "head": "removal", "tail": {$: "Con", "head": _name_0, "tail": {$: "Nil"}}})))), {$: "../src/ecs/removals.Reader", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "cursor": _cursor_0}, {$: "../src/ecs/world.World", "namespace": _ns_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _cursor_0);
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058change_world$(_result_0) {
  if (_result_0.$ === "../src/ecs/system.Completed") {
    const _outcome_0 = _result_0["outcome"];
    return $$$$047experiments$047public$045schedule$045readers$047driver$058outcome_world$(_outcome_0);
  } else {
    const _world_0 = _result_0["world"];
    return _world_0;
  }
}

function $$$$047src$047ecs$047system$058tracked_result$1260$(_result_0) {
  if (_result_0.$ === "../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047src$047ecs$047system$058tracked_outcome$1260$(_registry_1, _outcome_0);
  }
}

function $$$$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047src$047ecs$047system$058run_namespace$1261$(_registry_0, ($$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0) {
  if (!_isnormal_0) {
    return {$: "../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": ($$$$047src$047ecs$047lifecycle$058set$(_exceptional_0, _id_0, _stamp_0))};
  } else {
    return $$$$047src$047ecs$047indexed$045lifecycle$058write_grow$(17, _id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, (_id_0 <= _capacity_0));
  }
}

function $$$$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _observed_0) {
  const _added_0 = _observed_0["fst"];
  const _first_0 = _observed_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return $$$$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, {$: "Tuple", fst: _changed_0, snd: _changed_0[_x_0 % _changed_0.length]});
}

function $$$$047src$047ecs$047column$058recover_past$1263$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047system$058run_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047src$047ecs$047system$058complete$1263$(_registry_0, ($$$$047experiments$047public$045schedule$045readers$047added$045controls$058runner$(_world_0, _args_0)));
  }
}

function $$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  if (_registrations_0.$ === "Nil") {
    return false;
  } else {
    const _meta_0 = _registrations_0["head"];
    const _rest_0 = _registrations_0["tail"];
    const _x_0 = ($$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
    const _x_1 = ($$$$047src$047ecs$047world$058registration_list_matches$(_rest_0, _id_0, _name_0, _access_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047src$047ecs$047column$058plain_view_projected$1263$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047src$047ecs$047column$058restored$1263$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058project_enabled$(_owner_0) {
  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/schema.Enabled"}, "snd": {$: "../experiments/public-schedule-readers/schema.Enabled"}};
}

function $$$$047src$047ecs$047column$058prepared_view_projected$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047src$047ecs$047column$058view_taken$1263$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047src$047ecs$047column$058viewed$1263$(($$$$047experiments$047public$045schedule$045readers$047schema$058project_enabled$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047src$047ecs$047column$058seek_view$1263$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047src$047ecs$047column$058prepared_view_projected$1263$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058project_enabled$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_view_taken$1263$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047src$047ecs$047column$058indexed_view_projected$1263$(_id_0, _values_0, _metadata_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058project_enabled$(_owner_0)));
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_view_projected$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047src$047ecs$047column$058indexed_seek_view$1263$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047src$047ecs$047column$058indexed_prepared_view_projected$1263$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058project_enabled$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058prepared_swap$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047src$047ecs$047column$058swap_recovered$1262$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058recover$1262$({$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047src$047ecs$047column$058seek$1262$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1262$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_swap$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047src$047ecs$047column$058swap_recovered$1262$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058recover$1262$({$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047src$047ecs$047column$058indexed_seek$1262$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1262$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_swapped$1262$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../src/ecs/column.Accepted", "column": ($$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047src$047ecs$047column$058recover$1260$(_column_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058recover_state$1260$(($$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_recover_state$1260$(($$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047src$047ecs$047reader$045domains$058recovery_view$1260$(_namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, _old_removals_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _values_0 = _observed_0["snd"];
  return $$$$047src$047ecs$047reader$045domains$058recovered$1260$(_world_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, _old_removals_0, ($$$$047src$047ecs$047reader$045domains$058split$1260$(_values_0)));
}

function $$$$047src$047ecs$047event$045runtime$058run_identity$1260$(_runtime_0, _reader_0, _registry_0, _actual_0, _args_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  const _readerNamespace_0 = _reader_0["namespace"];
  const _readerId_0 = _reader_0["id"];
  const _expected_0 = _reader_0["registryId"];
  return $$$$047src$047ecs$047event$045runtime$058run_checked$1260$(($Bool$and$((_namespace_0 === _readerNamespace_0), (_expected_0 === _actual_0))), _world_0, {$: "../src/ecs/event-runtime.Reader", "namespace": _readerNamespace_0, "id": _readerId_0, "registryId": _expected_0}, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $$$$047src$047ecs$047system$058run_namespace_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047src$047ecs$047system$058run_metadata$1262$({$: "../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047experiments$047public$045schedule$045readers$047driver$058as_unit$(_result_0) {
  if (_result_0.$ === "../src/ecs/system.Succeeded") {
    const _world_0 = _result_0["world"];
    return {$: "../src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}};
  } else {
    const _world_1 = _result_0["world"];
    const _error_0 = _result_0["error"];
    return {$: "../src/ecs/system.Failed", "world": _world_1, "error": _error_0};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058finish$(_world_0, _text_0, _fail_0) {
  if (_fail_0) {
    return {$: "../src/ecs/system.Failed", "world": _world_0, "error": {$: "../experiments/public-schedule-readers/consumers.Failed", "observation": _text_0}};
  } else {
    return {$: "../src/ecs/system.Succeeded", "world": _world_0, "output": _text_0};
  }
}

function $$$$047src$047ecs$047removals$058checked$1260$(_allowed_0, _reader_0, _world_0, _cursor_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/removals.Invalid", "reader": _reader_0, "world": _world_0};
  } else {
    return $$$$047src$047ecs$047removals$058viewed$1260$(_reader_0, _cursor_0, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
  }
}

function $$$$047src$047ecs$047removals$058checked$1261$(_allowed_0, _reader_0, _world_0, _cursor_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/removals.Invalid", "reader": _reader_0, "world": _world_0};
  } else {
    return $$$$047src$047ecs$047removals$058viewed$1261$(_reader_0, _cursor_0, ($$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
  }
}

function $$$$047src$047ecs$047system$058tracked_outcome$1260$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, ($$$$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047src$047ecs$047system$058run_namespace$1261$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047src$047ecs$047indexed$045lifecycle$058write_grow$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _id_0 = $1;
      const _stamp_0 = $2;
      const _added_0 = $3;
      const _changed_0 = $4;
      const _capacity_0 = $5;
      const _depth_0 = $6;
      const _exceptional_0 = $7;
      const _fits_0 = $8;
      if (_fuel_0 === 0) {
        if (_fits_0) {
          return $$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          return {$: "../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_fits_0) {
          return $$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          const _next_0 = ((_capacity_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _stamp_0;
          $3 = array_node(_added_0, array_new(_depth_0, 0));
          $4 = array_node(_changed_0, array_new(_depth_0, 0));
          $5 = _next_0;
          $6 = nat_chk(_depth_0 + 1);
          $7 = _exceptional_0;
          $8 = (_id_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, _observed_0) {
  const _changed_0 = _observed_0["fst"];
  const _last_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../src/ecs/lifecycle.Stamp", "added": _first_0, "changed": _last_0}};
}

function $$$$047src$047ecs$047system$058complete$1263$(_registry_0, _outcome_0) {
  return {$: "../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047experiments$047public$045schedule$045readers$047added$045controls$058runner$(_world_0, _args_0) {
  const _name_0 = _args_0["name"];
  const _fail_0 = _args_0["fail"];
  const _own_0 = _args_0["own"];
  const _cursor_0 = _args_0["cursor"];
  return $$$$047experiments$047public$045schedule$045readers$047consumers$058change_result$(_name_0, ($$$$047src$047ecs$047compose$058each_since$1261$({$: "../experiments/public-schedule-readers/consumers.Mode", "own": _own_0, "fail": _fail_0}, _world_0, _cursor_0)));
}

function $$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $Bool$and$((_mid_0 === _id_0), ($Bool$and$(($String$eq$(_mname_0, _name_0)), ($$$$047src$047ecs$047world$058access_equal$(_maccess_0, _access_0)))));
}

function $$$$047src$047ecs$047column$058restored$1263$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047src$047ecs$047column$058viewed$1263$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047src$047ecs$047column$058restored$1263$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058viewed_return$1263$(_result_0, ($$$$047src$047ecs$047column$058swap$1263$({$: "../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_projected_state$1263$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058viewed_return$1263$(_result_0, ($$$$047src$047ecs$047column$058swap$1263$({$: "../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047src$047ecs$047column$058indexed_view_projected$1263$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047src$047ecs$047column$058indexed_view_restored$1263$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047src$047ecs$047column$058recover$1262$(_column_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058recover_state$1262$(($$$$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_recover_state$1262$(($$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058seek$1262$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_seek$1262$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047src$047ecs$047column$058indexed_recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047src$047ecs$047reader$045domains$058recovered$1260$(_world_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, _old_removals_0, _partition_0) {
  const _values_0 = _partition_0["fst"];
  const _fresh_removals_0 = _partition_0["snd"];
  return {$: "../src/ecs/reader-domains.Detached", "world": ($$$$047src$047ecs$047world$058events_replace$1260$(_world_0, ($$$$047src$047ecs$047event$045runtime$058append$1260$(_old_removals_0, _fresh_removals_0)))), "events": {$: "../src/ecs/reader-domains.Events", "namespace": _namespace_0, "batches": ($$$$047src$047ecs$047reader$045domains$058event_batches$1260$(_batches_0)), "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0, "values": _values_0}};
}

function $$$$047src$047ecs$047event$045runtime$058run_checked$1260$(_allowed_0, _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/event-runtime.Ran", "runtime": {$: "../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "reader": _reader_0, "registry": _registry_0, "completion": {$: "../src/ecs/event-runtime.Rejected", "args": _args_0}};
  } else {
    return $$$$047src$047ecs$047event$045runtime$058run_position$1260$(($$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _readerId_0)), _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047src$047ecs$047system$058run_metadata$1262$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047src$047ecs$047system$058run_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047src$047ecs$047removals$058viewed$1260$(_reader_0, _cursor_0, _viewed_0) {
  const _world_0 = _viewed_0["fst"];
  const _values_0 = _viewed_0["snd"];
  const _result_0 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058removal_fail$(($$$$047src$047ecs$047removals$058since$1260$(_values_0, _cursor_0))));
  return $$$$047src$047ecs$047removals$058consumed$1260$(_reader_0, ($$$$047src$047ecs$047removals$058count$1260$(_values_0)), _world_0, _result_0);
}

function $$$$047src$047ecs$047removals$058viewed$1261$(_reader_0, _cursor_0, _viewed_0) {
  const _world_0 = _viewed_0["fst"];
  const _values_0 = _viewed_0["snd"];
  const _result_0 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058removal_success$(($$$$047src$047ecs$047removals$058since$1260$(_values_0, _cursor_0))));
  return $$$$047src$047ecs$047removals$058consumed$1260$(_reader_0, ($$$$047src$047ecs$047removals$058count$1260$(_values_0)), _world_0, _result_0);
}

function $$$$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047src$047ecs$047system$058cursor_outcome$1260$({$: "../src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047src$047ecs$047system$058run_namespace_checked$1261$((_namespace_0 === _actual_0), {$: "../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0) {
  const _first_0 = _stamp_0["added"];
  const _last_0 = _stamp_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = ((_id_0 - 1) >>> 0);
  return {$: "../src/ecs/indexed-lifecycle.Metadata", "added": (_added_0[_x_0 % _added_0.length] = _first_0, _added_0), "changed": (_changed_0[_x_1 % _changed_0.length] = _last_0, _changed_0), "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058change_result$(_name_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../src/ecs/transaction.Success") {
    const _values_0 = _result_0["values"];
    const _x_0 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058array$(_values_0));
    const _x_1 = (_x_0 + "}");
    const _x_2 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058quoted$(_name_0));
    const _x_3 = (",\"values\":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return $$$$047experiments$047public$045schedule$045readers$047consumers$058finish$(_world_0, ("{\"kind\":\"change\",\"name\":" + _x_4), false);
  } else {
    const _t_1 = _t_0["error"];
    if (_t_1.$ === "../src/ecs/compose.UserError") {
      const _value_0 = _t_1["error"];
      const _x_5 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058array$({$: "Con", "head": _value_0, "tail": {$: "Nil"}}));
      const _x_6 = (_x_5 + "}");
      const _x_7 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058quoted$(_name_0));
      const _x_8 = (",\"values\":" + _x_6);
      const _x_9 = (_x_7 + _x_8);
      return $$$$047experiments$047public$045schedule$045readers$047consumers$058finish$(_world_0, ("{\"kind\":\"change\",\"name\":" + _x_9), true);
    } else {
      return $$$$047experiments$047public$045schedule$045readers$047consumers$058finish$(_world_0, "unexpected-change-failure", true);
    }
  }
}

function $$$$047src$047ecs$047compose$058each_since$1261$(_args_0, _world_0, _cursor_0) {
  return $$$$047src$047ecs$047compose$058reserved$1261$(_args_0, _cursor_0, ($$$$047src$047ecs$047world$058handles$1260$(_world_0)));
}

function $String$eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(($String$order$(_a_0, _b_0)));
}

function $$$$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($String$eq$(__2, _y_0)), ($$$$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047src$047ecs$047column$058viewed_return$1263$(_view_0, _result_0) {
  if (_result_0.$ === "../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047src$047ecs$047column$058indexed_projected_state$1263$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_view_projected$1263$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047src$047ecs$047column$058indexed_view_restored$1263$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047src$047ecs$047column$058recover_state$1262$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058recover_current$1262$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047src$047ecs$047column$058indexed_recover_state$1262$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_recover_current$1262$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047src$047ecs$047reader$045domains$058event_batches$1260$(_batches_0) {
  return $$$$047src$047ecs$047reader$045domains$058event_batches_loop$1260$(_batches_0, {$: "Nil"});
}

function $$$$047src$047ecs$047event$045runtime$058run_position$1260$(_position_0, _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_position_0.$ === "None") {
    return $$$$047src$047ecs$047event$045runtime$058run_reading$1260$(($$$$047src$047ecs$047event$045runtime$058reading$1260$({$: "../src/ecs/event-runtime.Position", "id": _readerId_0, "cursor": 0, "registeredAt": _tick_0}, _batches_0, _dropped_0)), _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  } else {
    const _position_1 = _position_0["value"];
    return $$$$047src$047ecs$047event$045runtime$058run_reading$1260$(($$$$047src$047ecs$047event$045runtime$058reading$1260$(_position_1, _batches_0, _dropped_0)), _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _position_0 = _positions_0["head"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, ($$$$047src$047ecs$047event$045runtime$058lookup$(_rest_0, _id_0)));
  }
}

function $$$$047src$047ecs$047system$058run_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047src$047ecs$047system$058complete$1262$(_registry_0, ($$$$047experiments$047public$045schedule$045readers$047operations$058runner$(_world_0, _args_0)));
  }
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058removal_fail$(_xs_0) {
  return {$: "Fail", "error": ($$$$047experiments$047public$045schedule$045readers$047consumers$058removal_text$(_xs_0))};
}

function $$$$047src$047ecs$047removals$058since$1260$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _cursor_0 = $1;
      if (_xs_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const __0 = _xs_0["head"];
        const _rest_0 = _xs_0["tail"];
        if (_cursor_0 === 0) {
          return $$$$047src$047ecs$047removals$058include$1260$(($$$$047experiments$047public$045schedule$045readers$047consumers$058select$(__0)), ($$$$047src$047ecs$047removals$058since$1260$(_rest_0, 0)));
        } else {
          const _p_0 = (_cursor_0 - 1);
          $0 = _rest_0;
          $1 = _p_0;
          continue;
        }
      }
    }
  }
}

function $$$$047src$047ecs$047removals$058consumed$1260$(_reader_0, _next_0, _world_0, _result_0) {
  if (_result_0.$ === "Done") {
    const _out_0 = _result_0["value"];
    return $$$$047src$047ecs$047removals$058finished$1260$(_reader_0, _next_0, {$: "../src/ecs/system.Succeeded", "world": _world_0, "output": _out_0});
  } else {
    const _error_0 = _result_0["error"];
    return $$$$047src$047ecs$047removals$058finished$1260$(_reader_0, _next_0, {$: "../src/ecs/system.Failed", "world": _world_0, "error": _error_0});
  }
}

function $$$$047src$047ecs$047removals$058count$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _rest_0 = _xs_0["tail"];
    return nat_chk(($$$$047src$047ecs$047removals$058count$1260$(_rest_0)) + 1);
  }
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058removal_success$(_xs_0) {
  return {$: "Done", "value": ($$$$047experiments$047public$045schedule$045readers$047consumers$058removal_text$(_xs_0))};
}

function $$$$047src$047ecs$047system$058cursor_outcome$1260$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../src/ecs/system.Completed", "registry": {$: "../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047src$047ecs$047system$058run_namespace_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047src$047ecs$047system$058run_metadata$1261$({$: "../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047src$047ecs$047compose$058reserved$1261$(_args_0, _cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _handles_0 = _observed_0["snd"];
  return $$$$047src$047ecs$047compose$058finished$1260$(run_loop($$$$047src$047ecs$047compose$058run_handles$1261$(_handles_0, _args_0, _cursor_0, ($$$$047src$047ecs$047transaction$058begin$1260$(_world_0)))));
}

function $Cmp$is_eq$(_c_0) {
  if (_c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $String$order$(_a_0, _b_0) {
  return $Pair$snd$(($String$cmp$(_a_0, _b_0)));
}

function $$$$047src$047ecs$047reader$045domains$058event_batches_loop$1260$($0, $1) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _acc_0 = $1;
      if (_batches_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _t_0 = _batches_0["head"];
        const _tick_0 = _t_0["tick"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047src$047ecs$047reader$045domains$058event_batch$1260$(_tick_0, ($$$$047src$047ecs$047reader$045domains$058split$1260$(_items_0)), _acc_0));
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047event$045runtime$058run_reading$1260$(_reading_0, _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _items_0 = _reading_0["values"];
  const _lagged_0 = _reading_0["lagged"];
  return $$$$047src$047ecs$047event$045runtime$058run_registered_result$1260$(($$$$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, {$: "../src/ecs/event-runtime.Input", "values": _items_0, "lagged": _lagged_0, "args": _args_0})), _reader_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $$$$047src$047ecs$047event$045runtime$058reading$1260$(_position_0, _batches_0, _dropped_0) {
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../src/ecs/event-runtime.Reading", "values": ($$$$047src$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $$$$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, _fallback_0) {
  const _actual_0 = _position_0["id"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  return $$$$047src$047ecs$047event$045runtime$058choose_position$((_actual_0 === _id_0), {$: "../src/ecs/event-runtime.Position", "id": _actual_0, "cursor": _cursor_0, "registeredAt": _registered_0}, _fallback_0);
}

function $$$$047src$047ecs$047system$058complete$1262$(_registry_0, _outcome_0) {
  return {$: "../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047experiments$047public$045schedule$045readers$047operations$058runner$(_world_0, _request_0) {
  return $$$$047experiments$047public$045schedule$045readers$047operations$058named$(_request_0, ($$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058removal_text$(_xs_0) {
  const _x_0 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058numbers$(($$$$047experiments$047public$045schedule$045readers$047consumers$058removal_gone$(_xs_0))));
  const _x_1 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058numbers$(($$$$047experiments$047public$045schedule$045readers$047consumers$058removal_aux$(_xs_0))));
  const _x_2 = (",\"despawned\":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058numbers$(($$$$047experiments$047public$045schedule$045readers$047consumers$058removal_stock$(_xs_0))));
  const _x_5 = (",\"aux\":" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  return ("\"stock\":" + _x_6);
}

function $$$$047src$047ecs$047removals$058include$1260$(_item_0, _rest_0) {
  if (_item_0.$ === "None") {
    return _rest_0;
  } else {
    const _value_0 = _item_0["value"];
    return {$: "Con", "head": _value_0, "tail": _rest_0};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058select$(_value_0) {
  if (_value_0.$ === "../experiments/public-schedule-readers/schema.RemovedStock") {
    const _handle_0 = _value_0["handle"];
    return {$: "Some", "value": {$: "../src/ecs/removals.Removed", "entity": _handle_0, "family": {$: "../experiments/public-schedule-readers/schema.StockFamily"}}};
  } else if (_value_0.$ === "../experiments/public-schedule-readers/schema.RemovedAux") {
    const _handle_1 = _value_0["handle"];
    return {$: "Some", "value": {$: "../src/ecs/removals.Removed", "entity": _handle_1, "family": {$: "../experiments/public-schedule-readers/schema.AuxFamily"}}};
  } else if (_value_0.$ === "../experiments/public-schedule-readers/schema.Gone") {
    const _handle_2 = _value_0["handle"];
    return {$: "Some", "value": {$: "../src/ecs/removals.Despawned", "entity": _handle_2}};
  } else {
    return {$: "None"};
  }
}

function $$$$047src$047ecs$047removals$058finished$1260$(_reader_0, _next_0, _outcome_0) {
  const _namespace_0 = _reader_0["namespace"];
  const _id_0 = _reader_0["id"];
  const _name_0 = _reader_0["name"];
  const __0 = _reader_0["cursor"];
  if (_outcome_0.$ === "../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../src/ecs/removals.Completed", "reader": {$: "../src/ecs/removals.Reader", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "cursor": __0}, "outcome": {$: "../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _out_0 = _outcome_0["output"];
    return {$: "../src/ecs/removals.Completed", "reader": {$: "../src/ecs/removals.Reader", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "cursor": _next_0}, "outcome": {$: "../src/ecs/system.Succeeded", "world": _world_1, "output": _out_0}};
  }
}

function $$$$047src$047ecs$047system$058run_metadata$1261$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047src$047ecs$047compose$058finished$1260$(_observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _result_0 = _t_0["fst"];
  const _values_0 = _t_0["snd"];
  return $$$$047src$047ecs$047compose$058finish_returned$1260$(_values_0, ($$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _result_0)));
}

function $$$$047src$047ecs$047compose$058run_handles$1261$(_handles_0, _args_0, _cursor_0, _tx_0) {
  if (_handles_0.$ === "Nil") {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../src/ecs/transaction.Success"}, "snd": {$: "Nil"}}};
  } else {
    const _handle_0 = _handles_0["head"];
    const _rest_0 = _handles_0["tail"];
    return $$$$047src$047ecs$047compose$058selected$1261$(_args_0, run_clo((_x_0) => {
  return $$$$047src$047ecs$047compose$058run_handles$1261$(_rest_0, _args_0, _cursor_0, _x_0);
}), ($$$$047src$047ecs$047compose$058plan_select$1260$(($$$$047experiments$047public$045schedule$045readers$047added$045controls$058plan$())))({$: "../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": {$: "None"}, "cursor": _cursor_0}));
  }
}

function $$$$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $Pair$snd$(_p_0) {
  const _b_0 = _p_0["snd"];
  return _b_0;
}

function $String$cmp$(_a_0, _b_0) {
  if (_a_0 === "") {
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": ""}, "snd": {$: "EQ"}};
    } else {
      const _h_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": (_h_0 + _t_0)}, "snd": {$: "LT"}};
    }
  } else {
    const _h_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
    const _t_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h_1 + _t_1), "snd": ""}, "snd": {$: "GT"}};
    } else {
      const _h2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return $String$cmp$fin$(_t_1, _t2_0, ($Char$cmp$(_h_1, _h2_0)));
    }
  }
}

function $$$$047src$047ecs$047reader$045domains$058event_batch$1260$(_tick_0, _filtered_0, _rest_0) {
  const _t_0 = _filtered_0["fst"];
  if (_t_0.$ === "Nil") {
    return _rest_0;
  } else {
    return {$: "Con", "head": {$: "../src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _t_0}, "tail": _rest_0};
  }
}

function $$$$047src$047ecs$047event$045runtime$058run_registered_result$1260$(_result_0, _reader_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_result_0.$ === "../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return $$$$047src$047ecs$047event$045runtime$058reject_input$1260$(_args_0, {$: "../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, _reader_0, _registry_0);
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047src$047ecs$047event$045runtime$058run_outcome$1260$(_outcome_0, _reader_0, _registry_1, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, ($$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047src$047ecs$047event$045runtime$058choose_position$(_found_0, _position_0, _fallback_0) {
  if (!_found_0) {
    return _fallback_0;
  } else {
    return {$: "Some", "value": _position_0};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047operations$058named$(_request_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047experiments$047public$045schedule$045readers$047operations$058run_request$(_request_0, _namespace_0, _world_0);
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058removal_stock$($0) {
  for (;;) {
    {
      const _xs_0 = $0;
      if (_xs_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _t_0 = _xs_0["head"];
        if (_t_0.$ === "../src/ecs/removals.Removed") {
          const _handle_0 = _t_0["entity"];
          const _t_1 = _t_0["family"];
          if (_t_1.$ === "../experiments/public-schedule-readers/schema.StockFamily") {
            const _rest_0 = _xs_0["tail"];
            return {$: "Con", "head": ($$$$047experiments$047public$045schedule$045readers$047consumers$058id$(_handle_0)), "tail": ($$$$047experiments$047public$045schedule$045readers$047consumers$058removal_stock$(_rest_0))};
          } else {
            const _rest_1 = _xs_0["tail"];
            $0 = _rest_1;
            continue;
          }
        } else {
          const _rest_2 = _xs_0["tail"];
          $0 = _rest_2;
          continue;
        }
      }
    }
  }
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058removal_aux$($0) {
  for (;;) {
    {
      const _xs_0 = $0;
      if (_xs_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _t_0 = _xs_0["head"];
        if (_t_0.$ === "../src/ecs/removals.Removed") {
          const _handle_0 = _t_0["entity"];
          const _t_1 = _t_0["family"];
          if (_t_1.$ === "../experiments/public-schedule-readers/schema.AuxFamily") {
            const _rest_0 = _xs_0["tail"];
            return {$: "Con", "head": ($$$$047experiments$047public$045schedule$045readers$047consumers$058id$(_handle_0)), "tail": ($$$$047experiments$047public$045schedule$045readers$047consumers$058removal_aux$(_rest_0))};
          } else {
            const _rest_1 = _xs_0["tail"];
            $0 = _rest_1;
            continue;
          }
        } else {
          const _rest_2 = _xs_0["tail"];
          $0 = _rest_2;
          continue;
        }
      }
    }
  }
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058removal_gone$($0) {
  for (;;) {
    {
      const _xs_0 = $0;
      if (_xs_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _t_0 = _xs_0["head"];
        if (_t_0.$ === "../src/ecs/removals.Despawned") {
          const _handle_0 = _t_0["entity"];
          const _rest_0 = _xs_0["tail"];
          return {$: "Con", "head": ($$$$047experiments$047public$045schedule$045readers$047consumers$058id$(_handle_0)), "tail": ($$$$047experiments$047public$045schedule$045readers$047consumers$058removal_gone$(_rest_0))};
        } else {
          const _rest_1 = _xs_0["tail"];
          $0 = _rest_1;
          continue;
        }
      }
    }
  }
}

function $$$$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047src$047ecs$047system$058complete$1261$(_registry_0, ($$$$047experiments$047public$045schedule$045readers$047consumers$058change_runner$(_world_0, _args_0)));
  }
}

function $$$$047src$047ecs$047compose$058finish_returned$1260$(_values_0, _returned_0) {
  const _world_0 = _returned_0["world"];
  const _t_0 = _returned_0["outcome"];
  if (_t_0.$ === "../src/ecs/transaction.Success") {
    return {$: "../src/ecs/compose.Executed", "world": _world_0, "outcome": {$: "../src/ecs/transaction.Success"}, "values": _values_0};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../src/ecs/compose.Executed", "world": _world_0, "outcome": {$: "../src/ecs/transaction.Failure", "error": _error_0}, "values": {$: "Nil"}};
  }
}

function $$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0) {
  return $$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0);
}

function $$$$047src$047ecs$047compose$058selected$1261$(_args_0, _next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const __0 = _t_0["handle"];
  const __1 = _t_0["error"];
  const __2 = _t_0["cursor"];
  const _t_1 = _observed_0["snd"];
  if (!_t_1) {
    return run_tail(_next_0, _tx_0);
  } else {
    return $$$$047src$047ecs$047compose$058body_returned$1260$(_next_0, ($$$$047src$047ecs$047capabilities$058invoke$1261$(_args_0, {$: "../src/ecs/compose.Frame", "tx": _tx_0, "handle": __0, "error": __1, "cursor": __2})));
  }
}

function $$$$047src$047ecs$047compose$058plan_select$1260$(_plan_0) {
  const _select_0 = _plan_0["select"];
  return _select_0;
}

function $$$$047experiments$047public$045schedule$045readers$047added$045controls$058plan$() {
  return {$: "../src/ecs/compose.Plan", "caps": {$: "../experiments/public-schedule-readers/consumers.ChangeCaps", "stock": ($$$$047src$047ecs$047compose$058write_family$1260$()), "handle": ($$$$047src$047ecs$047compose$058handle_read$1260$())}, "select": run_clo((_x_0) => {
  return $$$$047experiments$047public$045schedule$045readers$047added$045controls$058selected$(_x_0);
})};
}

function $String$cmp$fin$(_t1_0, _t2_0, _hc_0) {
  const _t_0 = _hc_0["fst"];
  const _h1b_0 = _t_0["fst"];
  const _h2b_0 = _t_0["snd"];
  const _t_1 = _hc_0["snd"];
  if (_t_1.$ === "LT") {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "LT"}};
  } else if (_t_1.$ === "EQ") {
    return $String$cmp$rec$(_h1b_0, _h2b_0, ($String$cmp$(_t1_0, _t2_0)));
  } else {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "GT"}};
  }
}

function $Char$cmp$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _a_0, "snd": _b_0}, "snd": cmp_new(_x_0, _x_1)};
}

function $$$$047src$047ecs$047event$045runtime$058reject_input$1260$(_input_0, _runtime_0, _reader_0, _registry_0) {
  const _args_0 = _input_0["args"];
  return {$: "../src/ecs/event-runtime.Ran", "runtime": _runtime_0, "reader": _reader_0, "registry": _registry_0, "completion": {$: "../src/ecs/event-runtime.Rejected", "args": _args_0}};
}

function $$$$047src$047ecs$047event$045runtime$058run_outcome$1260$(_outcome_0, _reader_0, _registry_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_outcome_0.$ === "../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../src/ecs/event-runtime.Ran", "runtime": {$: "../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": ($$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _readerId_0, (_tick_0 < 1 ? 0 : _tick_0 - 1))), "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "reader": _reader_0, "registry": _registry_0, "completion": {$: "../src/ecs/event-runtime.Failed", "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return {$: "../src/ecs/event-runtime.Ran", "runtime": ($$$$047src$047ecs$047event$045runtime$058sync_values$1260$(($$$$047src$047ecs$047world$058events_view$1260$(_world_1)), _namespace_0, _batches_0, ($$$$047src$047ecs$047event$045runtime$058update$(($$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _readerId_0, (_tick_0 < 1 ? 0 : _tick_0 - 1))), _readerId_0, _tick_0, false)), _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0)), "reader": _reader_0, "registry": _registry_0, "completion": {$: "../src/ecs/event-runtime.Succeeded", "output": _output_0}};
  }
}

function $$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047experiments$047public$045schedule$045readers$047operations$058run_request$(_request_0, _namespace_0, _world_0) {
  const _t_0 = _request_0["op"];
  if (_t_0 == 1) {
    const _value_0 = _request_0["value"];
    const _count_0 = _request_0["count"];
    const _secondValue_0 = _request_0["second"];
    const _fail_0 = _request_0["fail"];
    return $$$$047experiments$047public$045schedule$045readers$047operations$058finished$(($$$$047src$047ecs$047commands$058tx_finish$1261$(($$$$047experiments$047public$045schedule$045readers$047schema$058remove_aux$(($$$$047experiments$047public$045schedule$045readers$047operations$058second$(_secondValue_0, ($$$$047experiments$047public$045schedule$045readers$047operations$058emit$(_count_0, _value_0, ($$$$047src$047ecs$047transaction$058begin$1261$(_world_0)))))), ($$$$047experiments$047public$045schedule$045readers$047operations$058handle$(_namespace_0, 1)))), ($$$$047experiments$047public$045schedule$045readers$047operations$058outcome$(_fail_0)))));
  } else if ((_t_0 & 3) == 1) {
    return {$: "../src/ecs/system.Failed", "world": _world_0, "error": {$: "../experiments/public-schedule-readers/consumers.Failed", "observation": "unknown-operation"}};
  } else if (_t_0 == 3) {
    const _fail_2 = _request_0["fail"];
    return $$$$047experiments$047public$045schedule$045readers$047operations$058finished$(($$$$047src$047ecs$047commands$058tx_finish$1261$(($$$$047experiments$047public$045schedule$045readers$047operations$058despawned$(($$$$047src$047ecs$047commands$058tx_despawn_observed$1260$(($$$$047experiments$047public$045schedule$045readers$047schema$058remove_stock$(($$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), ($$$$047experiments$047public$045schedule$045readers$047operations$058handle$(_namespace_0, 1)))), ($$$$047experiments$047public$045schedule$045readers$047operations$058handle$(_namespace_0, 2)))))), ($$$$047experiments$047public$045schedule$045readers$047operations$058outcome$(_fail_2)))));
  } else if ((_t_0 & 3) == 3) {
    return {$: "../src/ecs/system.Failed", "world": _world_0, "error": {$: "../experiments/public-schedule-readers/consumers.Failed", "observation": "unknown-operation"}};
  } else if (_t_0 == 2) {
    const _fail_4 = _request_0["fail"];
    return $$$$047experiments$047public$045schedule$045readers$047operations$058finished$(($$$$047src$047ecs$047commands$058tx_finish$1261$(($$$$047experiments$047public$045schedule$045readers$047schema$058remove_aux$(($$$$047experiments$047public$045schedule$045readers$047schema$058queue_stock$(($$$$047src$047ecs$047transaction$058emit$1260$(($$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), {$: "../experiments/public-schedule-readers/schema.Ping", "value": 5})), ($$$$047experiments$047public$045schedule$045readers$047operations$058handle$(_namespace_0, 1)), {$: "Some", "value": ($$$$047experiments$047public$045schedule$045readers$047schema$058stock_owner$({$: "../experiments/public-schedule-readers/schema.StockView", "value": 50, "owned": {$: "Con", "head": 50, "tail": {$: "Con", "head": 51, "tail": {$: "Con", "head": 52, "tail": {$: "Con", "head": 53, "tail": {$: "Nil"}}}}}}))})), ($$$$047experiments$047public$045schedule$045readers$047operations$058handle$(_namespace_0, 1)))), ($$$$047experiments$047public$045schedule$045readers$047operations$058outcome$(_fail_4)))));
  } else if ((_t_0 & 3) == 2) {
    return {$: "../src/ecs/system.Failed", "world": _world_0, "error": {$: "../experiments/public-schedule-readers/consumers.Failed", "observation": "unknown-operation"}};
  } else if (_t_0 == 4) {
    const _fail_6 = _request_0["fail"];
    return $$$$047experiments$047public$045schedule$045readers$047operations$058finished$(($$$$047src$047ecs$047commands$058tx_finish$1261$(($$$$047experiments$047public$045schedule$045readers$047operations$058spawned$(($$$$047src$047ecs$047commands$058tx_spawn$1260$(($$$$047experiments$047public$045schedule$045readers$047operations$058spawned$(($$$$047src$047ecs$047commands$058tx_spawn$1260$(($$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), ($$$$047experiments$047public$045schedule$045readers$047operations$058seed_bundle$(10, 20)))))), ($$$$047experiments$047public$045schedule$045readers$047operations$058seed_bundle$(30, 40)))))), ($$$$047experiments$047public$045schedule$045readers$047operations$058outcome$(_fail_6)))));
  } else {
    return {$: "../src/ecs/system.Failed", "world": _world_0, "error": {$: "../experiments/public-schedule-readers/consumers.Failed", "observation": "unknown-operation"}};
  }
}

function $$$$047src$047ecs$047system$058complete$1261$(_registry_0, _outcome_0) {
  return {$: "../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058change_runner$(_world_0, _args_0) {
  const _name_0 = _args_0["name"];
  const _fail_0 = _args_0["fail"];
  const _own_0 = _args_0["own"];
  const _cursor_0 = _args_0["cursor"];
  return $$$$047experiments$047public$045schedule$045readers$047consumers$058change_result$(_name_0, ($$$$047src$047ecs$047compose$058each_since$1260$({$: "../experiments/public-schedule-readers/consumers.Mode", "own": _own_0, "fail": _fail_0}, _world_0, _cursor_0)));
}

function $$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047src$047ecs$047compose$058body_returned$1260$(_next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const _internal_0 = _t_0["error"];
  const _t_1 = _observed_0["snd"];
  const _user_0 = _t_1["fst"];
  const _value_0 = _t_1["snd"];
  return $$$$047src$047ecs$047compose$058completed$1260$(_next_0, _tx_0, _value_0, ($$$$047src$047ecs$047compose$058outcome$1260$(_internal_0, _user_0)));
}

function $$$$047src$047ecs$047capabilities$058invoke$1261$(_args_0, _ctx_0) {
  return $$$$047experiments$047public$045schedule$045readers$047consumers$058transactional_body$1261$(_args_0, _ctx_0);
}

function $$$$047src$047ecs$047compose$058write_family$1260$() {
  return {$: "../src/ecs/capabilities.Write", "get": run_clo((_x_0) => {
  return $$$$047src$047ecs$047compose$058get$1260$(_x_0);
}), "set": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047src$047ecs$047compose$058set$1260$(_x_1, _x_2);
});
})};
}

function $$$$047src$047ecs$047compose$058handle_read$1260$() {
  return {$: "../src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047src$047ecs$047compose$058handle_get$1260$(_x_0);
})};
}

function $$$$047experiments$047public$045schedule$045readers$047added$045controls$058selected$(_ctx_0) {
  return $$$$047src$047ecs$047compose$058both$1260$(_ctx_0);
}

function $String$cmp$rec$(_h1b_0, _h2b_0, _rr_0) {
  const _t_0 = _rr_0["fst"];
  const _t1b_0 = _t_0["fst"];
  const _t2b_0 = _t_0["snd"];
  const _r_0 = _rr_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1b_0), "snd": (_h2b_0 + _t2b_0)}, "snd": _r_0};
}

function $$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _registered_0) {
  return $$$$047src$047ecs$047event$045runtime$058activation$(($$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _positions_0, _id_0, _registered_0);
}

function $$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047src$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047experiments$047public$045schedule$045readers$047operations$058finished$(_result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../src/ecs/transaction.Success") {
    return {$: "../src/ecs/system.Succeeded", "world": _world_0, "output": ""};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../src/ecs/system.Failed", "world": _world_0, "error": _error_0};
  }
}

function $$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, _outcome_0) {
  return $$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0);
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058remove_aux$(_tx_0, _handle_0) {
  return $$$$047experiments$047public$045schedule$045readers$047schema$058queued$1262$(($$$$047src$047ecs$047structural$058tx_remove_observed$1261$(($$$$047experiments$047public$045schedule$045readers$047schema$058queue$()), _tx_0, _handle_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047operations$058second$(_value_0, _tx_0) {
  if (_value_0.$ === "None") {
    return _tx_0;
  } else {
    const _value_1 = _value_0["value"];
    return $$$$047src$047ecs$047transaction$058emit$1260$(_tx_0, {$: "../experiments/public-schedule-readers/schema.Ping", "value": _value_1});
  }
}

function $$$$047experiments$047public$045schedule$045readers$047operations$058emit$($0, $1, $2) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _value_0 = $1;
      const _tx_0 = $2;
      if (_remaining_0 === 0) {
        return _tx_0;
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = _value_0;
        $2 = ($$$$047src$047ecs$047transaction$058emit$1260$(_tx_0, {$: "../experiments/public-schedule-readers/schema.Ping", "value": _value_0}));
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047transaction$058begin$1261$(_world_0) {
  return {$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047experiments$047public$045schedule$045readers$047operations$058outcome$(_fail_0) {
  if (!_fail_0) {
    return {$: "../src/ecs/transaction.Success"};
  } else {
    return {$: "../src/ecs/transaction.Failure", "error": {$: "../experiments/public-schedule-readers/consumers.Failed", "observation": "publisher"}};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047operations$058despawned$(_result_0) {
  const _tx_0 = _result_0["fst"];
  return _tx_0;
}

function $$$$047src$047ecs$047commands$058tx_despawn_observed$1260$(_tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047src$047ecs$047commands$058despawn_join_observed$1260$(($$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _undo_0, _commands_0, _events_0, _handle_0);
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058remove_stock$(_tx_0, _handle_0) {
  return $$$$047experiments$047public$045schedule$045readers$047schema$058queued$1260$(($$$$047src$047ecs$047structural$058tx_remove_observed$1260$(($$$$047experiments$047public$045schedule$045readers$047schema$058stock$()), _tx_0, _handle_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058queue_stock$(_tx_0, _handle_0, _incoming_0) {
  return $$$$047experiments$047public$045schedule$045readers$047schema$058queued$1260$(($$$$047src$047ecs$047structural$058tx_replace$1260$(($$$$047experiments$047public$045schedule$045readers$047schema$058stock$()), _tx_0, _handle_0, _incoming_0)));
}

function $$$$047src$047ecs$047transaction$058emit$1260$(_tx_0, _event_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": {$: "Con", "head": _event_0, "tail": _events_0}};
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058stock_owner$(_view_0) {
  const _value_0 = _view_0["value"];
  const _values_0 = _view_0["owned"];
  return {$: "../experiments/public-schedule-readers/schema.Stock", "value": _value_0, "owned": ($$$$047experiments$047public$045schedule$045readers$047schema$058payload_array$(_values_0)), "length": ($List$length$(_values_0))};
}

function $$$$047experiments$047public$045schedule$045readers$047operations$058spawned$(_result_0) {
  const _tx_0 = _result_0["fst"];
  return _tx_0;
}

function $$$$047src$047ecs$047commands$058tx_spawn$1260$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047src$047ecs$047commands$058spawn_join$1260$(($$$$047src$047ecs$047world$058reserve_id$1260$(_world_0)), _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047experiments$047public$045schedule$045readers$047operations$058seed_bundle$(_value_0, _aux_0) {
  return {$: "../experiments/public-schedule-readers/schema.Bundle", "stock": {$: "Some", "value": ($$$$047experiments$047public$045schedule$045readers$047schema$058stock_payload$(_value_0))}, "recipe": {$: "None"}, "queue": {$: "Some", "value": {$: "../experiments/public-schedule-readers/schema.Queue", "value": _aux_0, "owned": ($$$$047experiments$047public$045schedule$045readers$047schema$058payload_array$({$: "Con", "head": _aux_0, "tail": {$: "Con", "head": ((_aux_0 + 1) >>> 0), "tail": {$: "Nil"}}})), "length": 2}}, "enabled": {$: "Some", "value": {$: "../experiments/public-schedule-readers/schema.Enabled"}}, "locked": {$: "None"}};
}

function $$$$047src$047ecs$047compose$058each_since$1260$(_args_0, _world_0, _cursor_0) {
  return $$$$047src$047ecs$047compose$058reserved$1260$(_args_0, _cursor_0, ($$$$047src$047ecs$047world$058handles$1260$(_world_0)));
}

function $$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../src/ecs/transaction.Returned", "world": ($$$$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../src/ecs/transaction.Returned", "world": ($$$$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047src$047ecs$047compose$058completed$1260$(_next_0, _tx_0, _value_0, _result_0) {
  if (_result_0.$ === "../src/ecs/transaction.Success") {
    return $$$$047src$047ecs$047compose$058prepend$1260$(_value_0, _next_0(_tx_0));
  } else {
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../src/ecs/transaction.Failure", "error": _error_0}, "snd": {$: "Nil"}}};
  }
}

function $$$$047src$047ecs$047compose$058outcome$1260$(_internal_0, _user_0) {
  if (_internal_0.$ === "Some") {
    const _error_0 = _internal_0["value"];
    return {$: "../src/ecs/transaction.Failure", "error": {$: "../src/ecs/compose.AccessError", "error": _error_0}};
  } else {
    if (_user_0.$ === "../src/ecs/transaction.Failure") {
      const _error_1 = _user_0["error"];
      return {$: "../src/ecs/transaction.Failure", "error": {$: "../src/ecs/compose.UserError", "error": _error_1}};
    } else {
      return {$: "../src/ecs/transaction.Success"};
    }
  }
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058transactional_body$1261$(_mode_0, _ctx_0) {
  const _own_0 = _mode_0["own"];
  const _fail_0 = _mode_0["fail"];
  return $$$$047experiments$047public$045schedule$045readers$047consumers$058change_return$1260$(_fail_0, ($$$$047experiments$047public$045schedule$045readers$047consumers$058change_body$1261$(_own_0, _ctx_0)));
}

function $$$$047src$047ecs$047compose$058get$1260$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047src$047ecs$047compose$058read_join$1260$(_handle_0, _error_0, _cursor_0, ($$$$047src$047ecs$047component$058tx_get$1260$(($$$$047experiments$047public$045schedule$045readers$047schema$058stock$()), _tx_0, _handle_0)));
}

function $$$$047src$047ecs$047compose$058set$1260$(_frame_0, _replacement_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047src$047ecs$047compose$058written$1260$(_handle_0, _error_0, _cursor_0, ($$$$047src$047ecs$047component$058tx_set$1260$(($$$$047experiments$047public$045schedule$045readers$047schema$058stock$()), _tx_0, _handle_0, _replacement_0)));
}

function $$$$047src$047ecs$047compose$058handle_get$1260$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return {$: "Tuple", "fst": {$: "../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}, "snd": _handle_0};
}

function $$$$047src$047ecs$047compose$058both$1260$(_frame_0) {
  return $$$$047src$047ecs$047compose$058and_join$1260$(($$$$047experiments$047public$045schedule$045readers$047added$045controls$058added$(_frame_0)));
}

function $$$$047src$047ecs$047event$045runtime$058activation$(_position_0, _positions_0, _id_0, _registered_0) {
  if (_position_0.$ === "None") {
    return {$: "Con", "head": {$: "../src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _registered_0}, "tail": _positions_0};
  } else {
    return _positions_0;
  }
}

function $$$$047src$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047src$047ecs$047system$058run_metadata$1260$({$: "../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058queued$1262$(_result_0) {
  if (_result_0.$ === "../src/ecs/structural.Queued") {
    const _tx_0 = _result_0["tx"];
    return _tx_0;
  } else {
    const _tx_1 = _result_0["tx"];
    return _tx_1;
  }
}

function $$$$047src$047ecs$047structural$058tx_remove_observed$1261$(_family_0, _tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047src$047ecs$047structural$058removed_queue_join$1261$(_family_0, ($$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _undo_0, _commands_0, _events_0, _handle_0, {$: "None"});
}

function $$$$047src$047ecs$047commands$058despawn_join_observed$1260$(_checked_0, _undo_0, _commands_0, _events_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047src$047ecs$047commands$058despawn_checked_observed$1260$(_allowed_0, _world_0, _undo_0, _commands_0, _events_0, _handle_0);
}

function $$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0) {
  return $$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, ($$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058queued$1260$(_result_0) {
  if (_result_0.$ === "../src/ecs/structural.Queued") {
    const _tx_0 = _result_0["tx"];
    return _tx_0;
  } else {
    const _tx_1 = _result_0["tx"];
    return _tx_1;
  }
}

function $$$$047src$047ecs$047structural$058tx_remove_observed$1260$(_family_0, _tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047src$047ecs$047structural$058removed_queue_join$1260$(_family_0, ($$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _undo_0, _commands_0, _events_0, _handle_0, {$: "None"});
}

function $$$$047src$047ecs$047structural$058tx_replace$1260$(_family_0, _tx_0, _handle_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047src$047ecs$047structural$058queue_join$1260$(_family_0, ($$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _undo_0, _commands_0, _events_0, _handle_0, _incoming_0);
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058payload_array$(_values_0) {
  const _x_0 = ($$$$047experiments$047public$045schedule$045readers$047schema$058shape_depth$(($$$$047experiments$047public$045schedule$045readers$047schema$058shape$(_values_0, {$: "../experiments/public-schedule-readers/schema.ArrayShape", "capacity": 1, "depth": 0, "used": 0}))));
  return $$$$047experiments$047public$045schedule$045readers$047schema$058fill$(_values_0, 0, array_new(_x_0, 0));
}

function $List$length$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = _xs_0["tail"];
    return nat_chk(($List$length$(_t_0)) + 1);
  }
}

function $$$$047src$047ecs$047commands$058spawn_join$1260$(_reserved_0, _undo_0, _commands_0, _events_0, _payload_0) {
  const _world_0 = _reserved_0["fst"];
  const _reservation_0 = _reserved_0["snd"];
  return $$$$047src$047ecs$047commands$058spawn_reserved$1260$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047src$047ecs$047world$058reserve_id$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047world$058reserve_available$1260$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058stock_payload$(_value_0) {
  return {$: "../experiments/public-schedule-readers/schema.Stock", "value": _value_0, "owned": ($$$$047experiments$047public$045schedule$045readers$047schema$058payload_array$({$: "Con", "head": _value_0, "tail": {$: "Con", "head": ((_value_0 + 1) >>> 0), "tail": {$: "Con", "head": ((_value_0 + 2) >>> 0), "tail": {$: "Nil"}}}})), "length": 3};
}

function $$$$047src$047ecs$047compose$058reserved$1260$(_args_0, _cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _handles_0 = _observed_0["snd"];
  return $$$$047src$047ecs$047compose$058finished$1260$(run_loop($$$$047src$047ecs$047compose$058run_handles$1260$(_handles_0, _args_0, _cursor_0, ($$$$047src$047ecs$047transaction$058begin$1260$(_world_0)))));
}

function $$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, _commands_0) {
  return $$$$047src$047ecs$047commands$058enqueue_list$1260$(_commands_0, _world_0);
}

function $$$$047src$047ecs$047commands$058publish$1260$(_world_0, _events_0) {
  return $$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _events_0);
}

function $$$$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047compose$058prepend$1260$(_value_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _outcome_0 = _t_0["fst"];
  const _values_0 = _t_0["snd"];
  return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": {$: "Con", "head": _value_0, "tail": _values_0}}};
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058change_return$1260$(_fail_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _result_0 = _observed_0["snd"];
  return $$$$047experiments$047public$045schedule$045readers$047consumers$058change_return_outcome$1260$(_fail_0, _ctx_0, _result_0);
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058change_body$1261$(_own_0, _ctx_0) {
  return $$$$047experiments$047public$045schedule$045readers$047consumers$058change_handle$1261$(_own_0, run_loop($$$$047src$047ecs$047capabilities$058value_read$1261$(_ctx_0)));
}

function $$$$047src$047ecs$047compose$058read_join$1260$(_handle_0, _error_0, _cursor_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047src$047ecs$047component$058tx_get$1260$(_family_0, _tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047src$047ecs$047component$058tx_get_join$1260$(_undo_0, _commands_0, _events_0, ($$$$047src$047ecs$047component$058get$1260$(_family_0, _world_0, _handle_0)));
}

function $$$$047src$047ecs$047compose$058written$1260$(_handle_0, _error_0, _cursor_0, _result_0) {
  if (_result_0.$ === "../src/ecs/component.Written") {
    const _tx_0 = _result_0["tx"];
    return {$: "../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0};
  } else if (_result_0.$ === "../src/ecs/component.WriteRejected") {
    const _tx_1 = _result_0["tx"];
    const _reason_0 = _result_0["error"];
    return {$: "../src/ecs/compose.Frame", "tx": _tx_1, "handle": _handle_0, "error": ($$$$047src$047ecs$047compose$058first_error$(_error_0, _reason_0)), "cursor": _cursor_0};
  } else {
    const _tx_2 = _result_0["tx"];
    const _reason_1 = _result_0["error"];
    return {$: "../src/ecs/compose.Frame", "tx": _tx_2, "handle": _handle_0, "error": ($$$$047src$047ecs$047compose$058first_error$(_error_0, _reason_1)), "cursor": _cursor_0};
  }
}

function $$$$047src$047ecs$047component$058tx_set$1260$(_family_0, _tx_0, _handle_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047src$047ecs$047component$058tx_set_fused$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, ($$$$047src$047ecs$047component$058stamped_allowed$1260$(($$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0)));
}

function $$$$047src$047ecs$047compose$058and_join$1260$(_observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _frame_0, "snd": false};
  } else {
    return $$$$047experiments$047public$045schedule$045readers$047consumers$058changed$(_frame_0);
  }
}

function $$$$047experiments$047public$045schedule$045readers$047added$045controls$058added$(_ctx_0) {
  return $$$$047src$047ecs$047compose$058lifecycle_match$1261$(_ctx_0);
}

function $$$$047src$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../src/ecs/transaction.Returned", "world": ($$$$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../src/ecs/transaction.Returned", "world": ($$$$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047src$047ecs$047structural$058removed_queue_join$1261$(_family_0, _checked_0, _undo_0, _commands_0, _events_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047src$047ecs$047structural$058removed_queue_checked$1261$(_allowed_0, _family_0, _world_0, _undo_0, _commands_0, _events_0, _handle_0, _incoming_0);
}

function $$$$047src$047ecs$047commands$058despawn_checked_observed$1260$(_allowed_0, _world_0, _undo_0, _commands_0, _events_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": {$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "../src/ecs/world.Rejected", "error": {$: "../src/ecs/world.MissingEntity"}}};
  } else {
    return {$: "Tuple", "fst": {$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047src$047ecs$047commands$058despawn_apply_observed$1260$(_x_0, _handle_0);
}), "tail": _commands_0}, "events": _events_0}, "snd": {$: "../src/ecs/world.Accepted"}};
  }
}

function $$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0);
}

function $$$$047src$047ecs$047structural$058removed_queue_join$1260$(_family_0, _checked_0, _undo_0, _commands_0, _events_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047src$047ecs$047structural$058removed_queue_checked$1260$(_allowed_0, _family_0, _world_0, _undo_0, _commands_0, _events_0, _handle_0, _incoming_0);
}

function $$$$047src$047ecs$047structural$058queue_join$1260$(_family_0, _checked_0, _undo_0, _commands_0, _events_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047src$047ecs$047structural$058queue_checked$1260$(_allowed_0, _family_0, _world_0, _undo_0, _commands_0, _events_0, _handle_0, _incoming_0);
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058fill$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _index_0 = $1;
      const _array_0 = $2;
      if (_values_0.$ === "Nil") {
        return _array_0;
      } else {
        const _x_0 = _values_0["head"];
        const _rest_0 = _values_0["tail"];
        $0 = _rest_0;
        $1 = ((_index_0 + 1) >>> 0);
        $2 = (_array_0[_index_0 % _array_0.length] = _x_0, _array_0);
        continue;
      }
    }
  }
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058shape_depth$(_shape_0) {
  const _depth_0 = _shape_0["depth"];
  return _depth_0;
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058shape$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _current_0 = $1;
      if (_values_0.$ === "Nil") {
        return _current_0;
      } else {
        const _rest_0 = _values_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047experiments$047public$045schedule$045readers$047schema$058shape_advance$(_current_0));
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047commands$058spawn_reserved$1260$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0) {
  if (_reservation_0.$ === "../src/ecs/world.ReservationRejected") {
    const _error_0 = _reservation_0["error"];
    return {$: "Tuple", "fst": {$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "../src/ecs/world.ReservationRejected", "error": _error_0}};
  } else {
    const _handle_0 = _reservation_0["handle"];
    return {$: "Tuple", "fst": {$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047src$047ecs$047commands$058spawn_apply$1260$(_x_0, _handle_0, _payload_0);
}), "tail": _commands_0}, "events": _events_0}, "snd": {$: "../src/ecs/world.Reserved", "handle": _handle_0}};
  }
}

function $$$$047src$047ecs$047world$058reserve_available$1260$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../src/ecs/world.ReservationRejected", "error": {$: "../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047src$047ecs$047world$058reserve_finish$1260$({$: "../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047src$047ecs$047world$058reserve_finish$1260$(($$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $$$$047src$047ecs$047compose$058run_handles$1260$(_handles_0, _args_0, _cursor_0, _tx_0) {
  if (_handles_0.$ === "Nil") {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../src/ecs/transaction.Success"}, "snd": {$: "Nil"}}};
  } else {
    const _handle_0 = _handles_0["head"];
    const _rest_0 = _handles_0["tail"];
    return $$$$047src$047ecs$047compose$058selected$1260$(_args_0, run_clo((_x_0) => {
  return $$$$047src$047ecs$047compose$058run_handles$1260$(_rest_0, _args_0, _cursor_0, _x_0);
}), ($$$$047src$047ecs$047compose$058plan_select$1260$(($$$$047experiments$047public$045schedule$045readers$047consumers$058plan$())))({$: "../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": {$: "None"}, "cursor": _cursor_0}));
  }
}

function $$$$047src$047ecs$047commands$058enqueue_list$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058change_return_outcome$1260$(_fail_0, _ctx_0, _result_0) {
  const _t_0 = _result_0["fst"];
  if (_t_0.$ === "../src/ecs/transaction.Success") {
    const _value_0 = _result_0["snd"];
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": ($$$$047experiments$047public$045schedule$045readers$047consumers$058row_outcome$(_fail_0, _value_0)), "snd": _value_0}};
  } else {
    const _error_0 = _t_0["error"];
    const _value_1 = _result_0["snd"];
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../src/ecs/transaction.Failure", "error": _error_0}, "snd": _value_1}};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058change_handle$1261$(_own_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _entity_0 = _observed_0["snd"];
  return $$$$047experiments$047public$045schedule$045readers$047consumers$058change_value$1261$(_own_0, _entity_0, run_loop($$$$047src$047ecs$047capabilities$058get$1261$(_ctx_0)));
}

function $$$$047src$047ecs$047capabilities$058value_read$1261$(_ctx_0) {
  return run_tail(($$$$047src$047ecs$047capabilities$058value_read_field$1260$(($$$$047experiments$047public$045schedule$045readers$047consumers$058handle$1260$(($$$$047src$047ecs$047compose$058plan_caps$1260$(($$$$047experiments$047public$045schedule$045readers$047added$045controls$058plan$()))))))), _ctx_0);
}

function $$$$047src$047ecs$047component$058tx_get_join$1260$(_undo_0, _commands_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047src$047ecs$047compose$058first_error$(_previous_0, _error_0) {
  if (_previous_0.$ === "None") {
    return {$: "Some", "value": _error_0};
  } else {
    const _previous_1 = _previous_0["value"];
    return {$: "Some", "value": _previous_1};
  }
}

function $$$$047src$047ecs$047component$058tx_set_fused$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _observed_0) {
  const _result_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047src$047ecs$047component$058tx_written$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0);
}

function $$$$047src$047ecs$047component$058stamped_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": {$: "Some", "value": _incoming_0}, "error": {$: "../src/ecs/world.MissingEntity"}}, "snd": {$: "../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047src$047ecs$047component$058stamped_world$1260$(_id_0, _incoming_0, _world_0);
  }
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058changed$(_ctx_0) {
  return $$$$047src$047ecs$047compose$058lifecycle_match$1260$(_ctx_0);
}

function $$$$047src$047ecs$047compose$058lifecycle_match$1261$(_frame_0) {
  const _t_0 = _frame_0["tx"];
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _events_0 = _t_0["events"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047src$047ecs$047compose$058lifecycle_join$1261$(_handle_0, _error_0, _cursor_0, _undo_0, _commands_0, _events_0, ($$$$047src$047ecs$047component$058lifecycle$1260$(($$$$047experiments$047public$045schedule$045readers$047schema$058stock$()), _world_0, _handle_0)));
}

function $$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047src$047ecs$047system$058complete$1260$(_registry_0, ($$$$047experiments$047public$045schedule$045readers$047consumers$058event_body$(_world_0, _args_0)));
  }
}

function $$$$047src$047ecs$047structural$058removed_queue_checked$1261$(_allowed_0, _family_0, _world_0, _undo_0, _commands_0, _events_0, _handle_0, _incoming_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/structural.QueueRejected", "tx": {$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "incoming": _incoming_0, "error": {$: "../src/ecs/world.MissingEntity"}};
  } else {
    return {$: "../src/ecs/structural.Queued", "tx": {$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047src$047ecs$047structural$058remove_apply_observed$1261$(_family_0, _x_0, _handle_0, _incoming_0);
}), "tail": _commands_0}, "events": _events_0}};
  }
}

function $$$$047src$047ecs$047commands$058despawn_apply_observed$1260$(_world_0, _handle_0) {
  return $$$$047src$047ecs$047commands$058despawn_valid_observed$1260$(($$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0);
}

function $$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047src$047ecs$047world$058live_join$1260$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047src$047ecs$047structural$058removed_queue_checked$1260$(_allowed_0, _family_0, _world_0, _undo_0, _commands_0, _events_0, _handle_0, _incoming_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/structural.QueueRejected", "tx": {$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "incoming": _incoming_0, "error": {$: "../src/ecs/world.MissingEntity"}};
  } else {
    return {$: "../src/ecs/structural.Queued", "tx": {$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047src$047ecs$047structural$058remove_apply_observed$1260$(_family_0, _x_0, _handle_0, _incoming_0);
}), "tail": _commands_0}, "events": _events_0}};
  }
}

function $$$$047src$047ecs$047structural$058queue_checked$1260$(_allowed_0, _family_0, _world_0, _undo_0, _commands_0, _events_0, _handle_0, _incoming_0) {
  if (!_allowed_0) {
    return {$: "../src/ecs/structural.QueueRejected", "tx": {$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "incoming": _incoming_0, "error": {$: "../src/ecs/world.MissingEntity"}};
  } else {
    return {$: "../src/ecs/structural.Queued", "tx": {$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047src$047ecs$047structural$058apply$1260$(_family_0, _x_0, _handle_0, _incoming_0);
}), "tail": _commands_0}, "events": _events_0}};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058shape_advance$(_shape_0) {
  const _capacity_0 = _shape_0["capacity"];
  const _depth_0 = _shape_0["depth"];
  const _used_0 = _shape_0["used"];
  return $$$$047experiments$047public$045schedule$045readers$047schema$058shape_choose$(($Nat$is_eq$(_capacity_0, _used_0)), _capacity_0, _depth_0, _used_0);
}

function $$$$047src$047ecs$047commands$058spawn_apply$1260$(_world_0, _handle_0, _payload_0) {
  return $$$$047src$047ecs$047commands$058spawned$1260$(($$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $$$$047src$047ecs$047world$058reserve_finish$1260$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../src/ecs/world.Reserved", "handle": {$: "../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047src$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047compose$058selected$1260$(_args_0, _next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const __0 = _t_0["handle"];
  const __1 = _t_0["error"];
  const __2 = _t_0["cursor"];
  const _t_1 = _observed_0["snd"];
  if (!_t_1) {
    return run_tail(_next_0, _tx_0);
  } else {
    return $$$$047src$047ecs$047compose$058body_returned$1260$(_next_0, ($$$$047src$047ecs$047capabilities$058invoke$1260$(_args_0, {$: "../src/ecs/compose.Frame", "tx": _tx_0, "handle": __0, "error": __1, "cursor": __2})));
  }
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058plan$() {
  return {$: "../src/ecs/compose.Plan", "caps": {$: "../experiments/public-schedule-readers/consumers.ChangeCaps", "stock": ($$$$047src$047ecs$047compose$058write_family$1260$()), "handle": ($$$$047src$047ecs$047compose$058handle_read$1260$())}, "select": run_clo((_x_0) => {
  return $$$$047experiments$047public$045schedule$045readers$047consumers$058changed$(_x_0);
})};
}

function $$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058row_outcome$(_fail_0, _row_0) {
  if (_fail_0) {
    return {$: "../src/ecs/transaction.Failure", "error": _row_0};
  } else {
    return {$: "../src/ecs/transaction.Success"};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058change_value$1261$(_own_0, _entity_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../src/ecs/component.Found") {
    const _value_0 = _t_0["value"];
    return $$$$047experiments$047public$045schedule$045readers$047consumers$058change_write$1261$(_own_0, _entity_0, _value_0, _ctx_0);
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../src/ecs/transaction.Failure", "error": "missing"}, "snd": "missing"}};
  }
}

function $$$$047src$047ecs$047capabilities$058get$1261$(_ctx_0) {
  return run_tail(($$$$047src$047ecs$047capabilities$058write_read_field$1260$(($$$$047experiments$047public$045schedule$045readers$047consumers$058stock$1260$(($$$$047src$047ecs$047compose$058plan_caps$1260$(($$$$047experiments$047public$045schedule$045readers$047added$045controls$058plan$()))))))), _ctx_0);
}

function $$$$047src$047ecs$047capabilities$058value_read_field$1260$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058handle$1260$(_caps_0) {
  const _handle_0 = _caps_0["handle"];
  return _handle_0;
}

function $$$$047src$047ecs$047compose$058plan_caps$1260$(_plan_0) {
  const _caps_0 = _plan_0["caps"];
  return _caps_0;
}

function $$$$047src$047ecs$047component$058tx_written$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../src/ecs/component.Written", "tx": {$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047src$047ecs$047component$058restore_stamp$1260$(_handle_0, _stamp_0, ($$$$047src$047ecs$047component$058restore$1260$(_family_0, _handle_0, _previous_0, _x_0)));
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["incoming"];
    if (_t_0.$ === "Some") {
      const _incoming_0 = _t_0["value"];
      const _error_0 = _result_0["error"];
      return {$: "../src/ecs/component.WriteRejected", "tx": {$: "../src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "incoming": _incoming_0, "error": _error_0};
    } else {
      const _error_1 = _result_0["error"];
      return {$: "../src/ecs/component.WriteFailure", "tx": {$: "../src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "error": _error_1};
    }
  }
}

function $$$$047src$047ecs$047component$058stamped_world$1260$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047component$058stamped_replaced$1260$(($$$$047src$047ecs$047world$058with_store_finish$12612$(($$$$047src$047ecs$047component$058stamped_store$1260$(_id_0, _incoming_0, ($$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))), (_clock_0 < 4294967295), ($$$$047experiments$047public$045schedule$045readers$047schema$058take_stock$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, ($$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))))));
}

function $$$$047src$047ecs$047compose$058lifecycle_match$1260$(_frame_0) {
  const _t_0 = _frame_0["tx"];
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _events_0 = _t_0["events"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047src$047ecs$047compose$058lifecycle_join$1260$(_handle_0, _error_0, _cursor_0, _undo_0, _commands_0, _events_0, ($$$$047src$047ecs$047component$058lifecycle$1260$(($$$$047experiments$047public$045schedule$045readers$047schema$058stock$()), _world_0, _handle_0)));
}

function $$$$047src$047ecs$047compose$058lifecycle_join$1261$(_handle_0, _error_0, _cursor_0, _undo_0, _commands_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/compose.Frame", "tx": {$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}, "snd": ($$$$047src$047ecs$047compose$058lifecycle_selected$({$: "../src/ecs/compose.Added"}, _stamp_0, _cursor_0))};
}

function $$$$047src$047ecs$047component$058lifecycle$1260$(_family_0, _world_0, _handle_0) {
  return $$$$047src$047ecs$047component$058lifecycle_allowed$1260$(($$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0);
}

function $$$$047src$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058event_body$(_world_0, _input_0) {
  const _values_0 = _input_0["values"];
  const _lagged_0 = _input_0["lagged"];
  const _t_0 = _input_0["args"];
  const _name_0 = _t_0["name"];
  const _fail_0 = _t_0["fail"];
  const _x_0 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058boolean$(_lagged_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058numbers$(($$$$047experiments$047public$045schedule$045readers$047consumers$058ping_values$(_values_0))));
  const _x_3 = (",\"lagged\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058quoted$(_name_0));
  const _x_6 = (",\"values\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  return $$$$047experiments$047public$045schedule$045readers$047consumers$058finish$(_world_0, ("{\"kind\":\"event\",\"name\":" + _x_7), _fail_0);
}

function $$$$047src$047ecs$047structural$058remove_apply_observed$1261$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047src$047ecs$047structural$058removal_published$1261$(_handle_0, ($$$$047src$047ecs$047component$058replace$1262$(_family_0, _world_0, _handle_0, _incoming_0)));
}

function $$$$047src$047ecs$047commands$058despawn_valid_observed$1260$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return _world_0;
  } else {
    return $$$$047src$047ecs$047commands$058clear_observed_accepted$1260$(($$$$047src$047ecs$047world$058deactivate$1260$(_world_0, _handle_0)), _handle_0);
  }
}

function $$$$047src$047ecs$047world$058live_join$1260$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047src$047ecs$047structural$058remove_apply_observed$1260$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047src$047ecs$047structural$058removal_published$1260$(_handle_0, ($$$$047src$047ecs$047component$058replace$1260$(_family_0, _world_0, _handle_0, _incoming_0)));
}

function $$$$047src$047ecs$047structural$058apply$1260$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047src$047ecs$047structural$058applied$1260$(($$$$047src$047ecs$047component$058replace$1260$(_family_0, _world_0, _handle_0, _incoming_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058shape_choose$(_grow_0, _capacity_0, _depth_0, _used_0) {
  if (_grow_0) {
    return {$: "../experiments/public-schedule-readers/schema.ArrayShape", "capacity": nat_chk(2 * _capacity_0), "depth": nat_chk(_depth_0 + 1), "used": nat_chk(_used_0 + 1)};
  } else {
    return {$: "../experiments/public-schedule-readers/schema.ArrayShape", "capacity": _capacity_0, "depth": _depth_0, "used": nat_chk(_used_0 + 1)};
  }
}

function $Nat$is_eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(cmp_new(_a_0, _b_0));
}

function $$$$047src$047ecs$047commands$058spawned$1260$(_activated_0, _handle_0, _payload_0) {
  const _world_0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "../src/ecs/world.Accepted") {
    return $$$$047experiments$047public$045schedule$045readers$047schema$058populate$(_world_0, _handle_0, _payload_0);
  } else {
    return _world_0;
  }
}

function $$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0) {
  return $$$$047src$047ecs$047world$058set_live_join$1260$(true, _handle_0, ($$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047src$047ecs$047capabilities$058invoke$1260$(_args_0, _ctx_0) {
  return $$$$047experiments$047public$045schedule$045readers$047consumers$058transactional_body$1260$(_args_0, _ctx_0);
}

function $$$$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058change_write$1261$(_own_0, _entity_0, _value_0, _ctx_0) {
  if (_own_0) {
    return {$: "Tuple", "fst": run_loop($$$$047src$047ecs$047capabilities$058set$1261$(_ctx_0, ($$$$047experiments$047public$045schedule$045readers$047consumers$058increment$(_value_0)))), "snd": {$: "Tuple", "fst": {$: "../src/ecs/transaction.Success"}, "snd": ($$$$047experiments$047public$045schedule$045readers$047consumers$058row$(_entity_0, _value_0))}};
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../src/ecs/transaction.Success"}, "snd": ($$$$047experiments$047public$045schedule$045readers$047consumers$058row$(_entity_0, _value_0))}};
  }
}

function $$$$047src$047ecs$047capabilities$058write_read_field$1260$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058stock$1260$(_caps_0) {
  const _stock_0 = _caps_0["stock"];
  return _stock_0;
}

function $$$$047src$047ecs$047component$058restore_stamp$1260$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047src$047ecs$047component$058restore_stamp_done$1260$(($$$$047src$047ecs$047component$058restore_stamp_world$1260$(_id_0, _stamp_0, _world_0)));
}

function $$$$047src$047ecs$047component$058restore$1260$(_family_0, _handle_0, _incoming_0, _world_0) {
  return $$$$047src$047ecs$047component$058restore_allowed$1260$(($$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047src$047ecs$047component$058stamped_replaced$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _t_1 = _t_0["fst"];
  if (_t_1.$ === "../src/ecs/component.Swapped") {
    const _previous_0 = _t_1["previous"];
    const _stamp_0 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0}, "snd": _stamp_0};
  } else {
    const _incoming_0 = _t_1["incoming"];
    const _stamp_1 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../src/ecs/world.CapacityExceeded"}}, "snd": _stamp_1};
  }
}

function $$$$047src$047ecs$047world$058with_store_finish$12612$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047src$047ecs$047component$058stamped_store$1260$(_id_0, _incoming_0, _tick_0, _allowed_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047src$047ecs$047component$058stamped_column$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, ($$$$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0)));
}

function $$$$047src$047ecs$047component$058stamped_tick$(_clock_0, _allowed_0) {
  if (!_allowed_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047src$047ecs$047compose$058lifecycle_join$1260$(_handle_0, _error_0, _cursor_0, _undo_0, _commands_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/compose.Frame", "tx": {$: "../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}, "snd": ($$$$047src$047ecs$047compose$058lifecycle_selected$({$: "../src/ecs/compose.Changed"}, _stamp_0, _cursor_0))};
}

function $$$$047src$047ecs$047compose$058lifecycle_selected$(_mode_0, _stamp_0, _cursor_0) {
  if (_mode_0.$ === "../src/ecs/compose.Added") {
    return $$$$047src$047ecs$047lifecycle$058added$(_stamp_0, _cursor_0);
  } else {
    return $$$$047src$047ecs$047lifecycle$058changed$(_stamp_0, _cursor_0);
  }
}

function $$$$047src$047ecs$047component$058lifecycle_allowed$1260$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047src$047ecs$047component$058lifecycle_world$1260$(_id_0, _world_0);
  }
}

function $$$$047src$047ecs$047structural$058removal_published$1261$(_handle_0, _result_0) {
  if (_result_0.$ === "../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    const _t_0 = _result_0["previous"];
    if (_t_0.$ === "None") {
      return _world_0;
    } else {
      return $$$$047src$047ecs$047world$058event_publish$1260$(_world_0, {$: "Con", "head": ($$$$047experiments$047public$045schedule$045readers$047schema$058aux_removed$(_handle_0)), "tail": {$: "Nil"}});
    }
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047src$047ecs$047component$058replace$1262$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047src$047ecs$047component$058replace_allowed$1262$(($$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047src$047ecs$047commands$058clear_observed_accepted$1260$(_activated_0, _handle_0) {
  const _world_0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "../src/ecs/world.Rejected") {
    return _world_0;
  } else {
    return $$$$047src$047ecs$047commands$058clear_observed_join$1260$(_handle_0, ($$$$047src$047ecs$047world$058with_store$1260$(run_clo((_x_0) => {
  return $$$$047experiments$047public$045schedule$045readers$047schema$058cleanup$(_x_0, _handle_0);
}), _world_0)));
  }
}

function $$$$047src$047ecs$047world$058deactivate$1260$(_world_0, _handle_0) {
  return $$$$047src$047ecs$047world$058set_live_join$1260$(false, _handle_0, ($$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047src$047ecs$047structural$058removal_published$1260$(_handle_0, _result_0) {
  if (_result_0.$ === "../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    const _t_0 = _result_0["previous"];
    if (_t_0.$ === "None") {
      return _world_0;
    } else {
      return $$$$047src$047ecs$047world$058event_publish$1260$(_world_0, {$: "Con", "head": ($$$$047experiments$047public$045schedule$045readers$047schema$058stock_removed$(_handle_0)), "tail": {$: "Nil"}});
    }
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047src$047ecs$047component$058replace$1260$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047src$047ecs$047component$058replace_allowed$1260$(($$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047src$047ecs$047structural$058applied$1260$(_result_0) {
  if (_result_0.$ === "../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058populate$(_world_0, _handle_0, _bundle_0) {
  const _namespace_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047experiments$047public$045schedule$045readers$047schema$058populate_inner$(_world_0, {$: "../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, _bundle_0);
}

function $$$$047src$047ecs$047world$058set_live_join$1260$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058transactional_body$1260$(_mode_0, _ctx_0) {
  const _own_0 = _mode_0["own"];
  const _fail_0 = _mode_0["fail"];
  return $$$$047experiments$047public$045schedule$045readers$047consumers$058change_return$1260$(_fail_0, ($$$$047experiments$047public$045schedule$045readers$047consumers$058change_body$1260$(_own_0, _ctx_0)));
}

function $$$$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047capabilities$058set$1261$(_ctx_0, _value_0) {
  return run_tail(($$$$047src$047ecs$047capabilities$058write_field$1260$(($$$$047experiments$047public$045schedule$045readers$047consumers$058stock$1260$(($$$$047src$047ecs$047compose$058plan_caps$1260$(($$$$047experiments$047public$045schedule$045readers$047added$045controls$058plan$())))))))(_ctx_0), _value_0);
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058increment$(_value_0) {
  const _value_1 = _value_0["value"];
  const _owned_0 = _value_0["owned"];
  return $$$$047experiments$047public$045schedule$045readers$047schema$058stock_owner$({$: "../experiments/public-schedule-readers/schema.StockView", "value": ((_value_1 + 1) >>> 0), "owned": ($List$append$(_owned_0, {$: "Con", "head": ((_value_1 + 1) >>> 0), "tail": {$: "Nil"}}))});
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058row$(_entity_0, _value_0) {
  const _x_0 = ($$$$047experiments$047public$045schedule$045readers$047consumers$058view$(_value_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($U32$show$(($$$$047experiments$047public$045schedule$045readers$047consumers$058id$(_entity_0))));
  const _x_3 = ("," + _x_1);
  const _x_4 = (_x_2 + _x_3);
  return ("{\"id\":" + _x_4);
}

function $$$$047src$047ecs$047component$058restore_stamp_done$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047src$047ecs$047component$058restore_stamp_world$1260$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047world$058with_store_finish$12611$(($$$$047src$047ecs$047component$058restore_stamp_store$1260$(_id_0, _stamp_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058take_stock$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047src$047ecs$047component$058restore_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return _world_0;
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047src$047ecs$047component$058restore_observed$1260$(($$$$047src$047ecs$047component$058restore_world$1260$(_id_0, _incoming_0, _world_0)));
  }
}

function $$$$047src$047ecs$047component$058stamped_column$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, _observed_0) {
  if (!_allowed_0) {
    const _column_0 = _observed_0["fst"];
    const _stamp_0 = _observed_0["snd"];
    return {$: "Tuple", "fst": ($$$$047experiments$047public$045schedule$045readers$047schema$058put_stock$(_rest_0, _column_0)), "snd": {$: "Tuple", "fst": {$: "../src/ecs/component.SwapRejected", "incoming": {$: "Some", "value": _incoming_0}}, "snd": _stamp_0}};
  } else {
    const _column_1 = _observed_0["fst"];
    const _stamp_1 = _observed_0["snd"];
    return $$$$047src$047ecs$047component$058stamped_store_join$1260$(_stamp_1, ($$$$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, true, _tick_0, ($$$$047src$047ecs$047column$058swap$1260$(($$$$047src$047ecs$047column$058ensure$1260$(_column_1, _id_0)), _id_0, {$: "Some", "value": _incoming_0})))));
  }
}

function $$$$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, ($$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, ($$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047lifecycle$058added$(_stamp_0, _cursor_0) {
  const _value_0 = _stamp_0["added"];
  return (_value_0 > _cursor_0);
}

function $$$$047src$047ecs$047lifecycle$058changed$(_stamp_0, _cursor_0) {
  const _value_0 = _stamp_0["changed"];
  return (_value_0 > _cursor_0);
}

function $$$$047src$047ecs$047component$058lifecycle_world$1260$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047world$058with_store_finish$12610$(($$$$047src$047ecs$047component$058lifecycle_store$1260$(_id_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058take_stock$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058aux_removed$(_handle_0) {
  return {$: "../experiments/public-schedule-readers/schema.RemovedAux", "handle": _handle_0};
}

function $$$$047src$047ecs$047component$058replace_allowed$1262$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047src$047ecs$047component$058replace_clock$1262$(_id_0, _incoming_0, ($$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047src$047ecs$047commands$058clear_observed_join$1260$(_handle_0, _cleared_0) {
  const _world_0 = _cleared_0["fst"];
  const _records_0 = _cleared_0["snd"];
  return $$$$047src$047ecs$047world$058event_publish$1260$(_world_0, ($List$append$(_records_0, {$: "Con", "head": ($$$$047experiments$047public$045schedule$045readers$047schema$058gone$(_handle_0)), "tail": {$: "Nil"}})));
}

function $$$$047src$047ecs$047world$058with_store$1260$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047world$058with_store_finish$12613$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058cleanup$(_store_0, _handle_0) {
  const _stock_0 = _store_0["stock"];
  const _recipe_0 = _store_0["recipe"];
  const _queue_0 = _store_0["queue"];
  const _enabled_0 = _store_0["enabled"];
  const _locked_0 = _store_0["locked"];
  const _namespace_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047experiments$047public$045schedule$045readers$047schema$058cleanup_join$(($$$$047experiments$047public$045schedule$045readers$047schema$058clear_column$1261$(_id_0, _recipe_0)), ($$$$047experiments$047public$045schedule$045readers$047schema$058clear_column$1263$(_id_0, _enabled_0)), ($$$$047experiments$047public$045schedule$045readers$047schema$058clear_column$1264$(_id_0, _locked_0)), ($$$$047experiments$047public$045schedule$045readers$047schema$058clear_stock_result$({$: "../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, ($$$$047src$047ecs$047column$058clear$1260$(_stock_0, _id_0)))), ($$$$047experiments$047public$045schedule$045readers$047schema$058clear_aux_result$({$: "../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, ($$$$047src$047ecs$047column$058clear$1262$(_queue_0, _id_0)))));
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058stock_removed$(_handle_0) {
  return {$: "../experiments/public-schedule-readers/schema.RemovedStock", "handle": _handle_0};
}

function $$$$047src$047ecs$047component$058replace_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047src$047ecs$047component$058replace_clock$1260$(_id_0, _incoming_0, ($$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058populate_inner$(_world_0, _handle_0, _bundle_0) {
  const _stock_0 = _bundle_0["stock"];
  const _recipe_0 = _bundle_0["recipe"];
  const _queue_0 = _bundle_0["queue"];
  const _enabled_0 = _bundle_0["enabled"];
  const _locked_0 = _bundle_0["locked"];
  return $$$$047experiments$047public$045schedule$045readers$047schema$058populate_locked$(($$$$047experiments$047public$045schedule$045readers$047schema$058populate_enabled$(($$$$047experiments$047public$045schedule$045readers$047schema$058populate_queue$(($$$$047experiments$047public$045schedule$045readers$047schema$058populate_recipe$(($$$$047experiments$047public$045schedule$045readers$047schema$058populate_stock$(_world_0, _handle_0, _stock_0)), _handle_0, _recipe_0)), _handle_0, _queue_0)), _handle_0, _enabled_0)), _handle_0, _locked_0);
}

function $$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../src/ecs/world.Rejected", "error": {$: "../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../src/ecs/world.Accepted"}};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058change_body$1260$(_own_0, _ctx_0) {
  return $$$$047experiments$047public$045schedule$045readers$047consumers$058change_handle$1260$(_own_0, run_loop($$$$047src$047ecs$047capabilities$058value_read$1260$(_ctx_0)));
}

function $$$$047src$047ecs$047capabilities$058write_field$1260$(_cap_0) {
  const _set_0 = _cap_0["set"];
  return _set_0;
}

function $$$$047src$047ecs$047world$058with_store_finish$12611$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047src$047ecs$047component$058restore_stamp_store$1260$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($$$$047experiments$047public$045schedule$045readers$047schema$058put_stock$(_rest_0, ($$$$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047src$047ecs$047component$058restore_observed$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047src$047ecs$047component$058restore_world$1260$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047world$058with_store_finish$12611$(($$$$047src$047ecs$047component$058restore_store$1260$(_id_0, _incoming_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058take_stock$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047src$047ecs$047component$058stamped_store_join$1260$(_stamp_0, _result_0) {
  const _store_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _store_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": _stamp_0}};
}

function $$$$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047src$047ecs$047component$058mark_swapped$1260$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($$$$047experiments$047public$045schedule$045readers$047schema$058put_stock$(_rest_0, _column_1)), "snd": {$: "../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047src$047ecs$047column$058ensure$1260$(_column_0, _target_0) {
  return $$$$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, ($$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047src$047ecs$047world$058with_store_finish$12610$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047src$047ecs$047component$058lifecycle_store$1260$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047src$047ecs$047component$058lifecycle_join$1260$(_rest_0, ($$$$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0)));
}

function $$$$047src$047ecs$047component$058replace_clock$1262$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047src$047ecs$047component$058replace_clock_checked$1262$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047src$047ecs$047component$058owner_present$1262$(_incoming_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058gone$(_handle_0) {
  return {$: "../experiments/public-schedule-readers/schema.Gone", "handle": _handle_0};
}

function $$$$047src$047ecs$047world$058with_store_finish$12613$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058cleanup_join$(_recipe_0, _enabled_0, _locked_0, _stock_0, _queue_0) {
  const _stock_1 = _stock_0["fst"];
  const _a_0 = _stock_0["snd"];
  const _queue_1 = _queue_0["fst"];
  const _b_0 = _queue_0["snd"];
  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/schema.Store", "stock": _stock_1, "recipe": _recipe_0, "queue": _queue_1, "enabled": _enabled_0, "locked": _locked_0}, "snd": ($List$append$(_a_0, _b_0))};
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058clear_column$1261$(_id_0, _column_0) {
  return $$$$047experiments$047public$045schedule$045readers$047schema$058clear_column_result$1261$(($$$$047src$047ecs$047column$058clear$1261$(_column_0, _id_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058clear_column$1263$(_id_0, _column_0) {
  return $$$$047experiments$047public$045schedule$045readers$047schema$058clear_column_result$1263$(($$$$047src$047ecs$047column$058clear$1263$(_column_0, _id_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058clear_column$1264$(_id_0, _column_0) {
  return $$$$047experiments$047public$045schedule$045readers$047schema$058clear_column_result$1264$(($$$$047src$047ecs$047column$058clear$1264$(_column_0, _id_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058clear_stock_result$(_handle_0, _result_0) {
  if (_result_0.$ === "../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _t_0 = _result_0["previous"];
    if (_t_0.$ === "Some") {
      return {$: "Tuple", "fst": _column_0, "snd": {$: "Con", "head": {$: "../experiments/public-schedule-readers/schema.RemovedStock", "handle": _handle_0}, "tail": {$: "Nil"}}};
    } else {
      return {$: "Tuple", "fst": _column_0, "snd": {$: "Nil"}};
    }
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "Nil"}};
  }
}

function $$$$047src$047ecs$047column$058clear$1260$(_column_0, _id_0) {
  return $$$$047src$047ecs$047column$058cleared$1260$(_id_0, ($$$$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, {$: "None"})));
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058clear_aux_result$(_handle_0, _result_0) {
  if (_result_0.$ === "../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _t_0 = _result_0["previous"];
    if (_t_0.$ === "Some") {
      return {$: "Tuple", "fst": _column_0, "snd": {$: "Con", "head": {$: "../experiments/public-schedule-readers/schema.RemovedAux", "handle": _handle_0}, "tail": {$: "Nil"}}};
    } else {
      return {$: "Tuple", "fst": _column_0, "snd": {$: "Nil"}};
    }
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "Nil"}};
  }
}

function $$$$047src$047ecs$047column$058clear$1262$(_column_0, _id_0) {
  return $$$$047src$047ecs$047column$058cleared$1262$(_id_0, ($$$$047src$047ecs$047column$058swap$1262$(_column_0, _id_0, {$: "None"})));
}

function $$$$047src$047ecs$047component$058replace_clock$1260$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047src$047ecs$047component$058replace_clock_checked$1260$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047src$047ecs$047component$058owner_present$1260$(_incoming_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058populate_locked$(_world_0, _handle_0, _incoming_0) {
  return $$$$047experiments$047public$045schedule$045readers$047schema$058replaced$1264$(($$$$047src$047ecs$047component$058structural_replace$1264$(($$$$047experiments$047public$045schedule$045readers$047schema$058locked$()), _world_0, _handle_0, _incoming_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058populate_queue$(_world_0, _handle_0, _incoming_0) {
  return $$$$047experiments$047public$045schedule$045readers$047schema$058replaced$1262$(($$$$047src$047ecs$047component$058structural_replace$1262$(($$$$047experiments$047public$045schedule$045readers$047schema$058queue$()), _world_0, _handle_0, _incoming_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058populate_recipe$(_world_0, _handle_0, _incoming_0) {
  return $$$$047experiments$047public$045schedule$045readers$047schema$058replaced$1261$(($$$$047src$047ecs$047component$058structural_replace$1261$(($$$$047experiments$047public$045schedule$045readers$047schema$058recipe$()), _world_0, _handle_0, _incoming_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058populate_stock$(_world_0, _handle_0, _incoming_0) {
  return $$$$047experiments$047public$045schedule$045readers$047schema$058replaced$1260$(($$$$047src$047ecs$047component$058structural_replace$1260$(($$$$047experiments$047public$045schedule$045readers$047schema$058stock$()), _world_0, _handle_0, _incoming_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058change_handle$1260$(_own_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _entity_0 = _observed_0["snd"];
  return $$$$047experiments$047public$045schedule$045readers$047consumers$058change_value$1260$(_own_0, _entity_0, run_loop($$$$047src$047ecs$047capabilities$058get$1260$(_ctx_0)));
}

function $$$$047src$047ecs$047capabilities$058value_read$1260$(_ctx_0) {
  return run_tail(($$$$047src$047ecs$047capabilities$058value_read_field$1260$(($$$$047experiments$047public$045schedule$045readers$047consumers$058handle$1260$(($$$$047src$047ecs$047compose$058plan_caps$1260$(($$$$047experiments$047public$045schedule$045readers$047consumers$058plan$()))))))), _ctx_0);
}

function $$$$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, ($$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, ($$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047component$058restore_store$1260$(_id_0, _incoming_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047src$047ecs$047component$058restore_swap$1260$(_rest_0, ($$$$047src$047ecs$047column$058swap$1260$(($$$$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047src$047ecs$047component$058mark_swapped$1260$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047experiments$047public$045schedule$045readers$047schema$058put_stock$(_rest_0, ($$$$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047src$047ecs$047component$058owner_present$1260$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047src$047ecs$047column$058ensure_state$1260$(_target_0, ($$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
    }
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047src$047ecs$047component$058lifecycle_join$1260$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047experiments$047public$045schedule$045readers$047schema$058put_stock$(_rest_0, _column_0)), "snd": _stamp_0};
}

function $$$$047src$047ecs$047component$058replace_clock_checked$1262$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047src$047ecs$047component$058replace_clock_advanced$1262$(_id_0, _present_0, _incoming_1, ($$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047src$047ecs$047component$058owner_present$1262$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058clear_column_result$1261$(_result_0) {
  if (_result_0.$ === "../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return _column_0;
  } else {
    const _column_1 = _result_0["column"];
    return _column_1;
  }
}

function $$$$047src$047ecs$047column$058clear$1261$(_column_0, _id_0) {
  return $$$$047src$047ecs$047column$058cleared$1261$(_id_0, ($$$$047src$047ecs$047column$058swap$1261$(_column_0, _id_0, {$: "None"})));
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058clear_column_result$1263$(_result_0) {
  if (_result_0.$ === "../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return _column_0;
  } else {
    const _column_1 = _result_0["column"];
    return _column_1;
  }
}

function $$$$047src$047ecs$047column$058clear$1263$(_column_0, _id_0) {
  return $$$$047src$047ecs$047column$058cleared$1263$(_id_0, ($$$$047src$047ecs$047column$058swap$1263$(_column_0, _id_0, {$: "None"})));
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058clear_column_result$1264$(_result_0) {
  if (_result_0.$ === "../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return _column_0;
  } else {
    const _column_1 = _result_0["column"];
    return _column_1;
  }
}

function $$$$047src$047ecs$047column$058clear$1264$(_column_0, _id_0) {
  return $$$$047src$047ecs$047column$058cleared$1264$(_id_0, ($$$$047src$047ecs$047column$058swap$1264$(_column_0, _id_0, {$: "None"})));
}

function $$$$047src$047ecs$047column$058cleared$1260$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../src/ecs/column.Accepted") {
    const _column_0 = _outcome_0["column"];
    const _previous_0 = _outcome_0["previous"];
    return {$: "../src/ecs/column.Accepted", "column": ($$$$047src$047ecs$047column$058clear_stamp$1260$(_column_0, _id_0)), "previous": _previous_0};
  } else {
    const _column_1 = _outcome_0["column"];
    const _incoming_0 = _outcome_0["incoming"];
    return {$: "../src/ecs/column.Rejected", "column": _column_1, "incoming": _incoming_0};
  }
}

function $$$$047src$047ecs$047column$058cleared$1262$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../src/ecs/column.Accepted") {
    const _column_0 = _outcome_0["column"];
    const _previous_0 = _outcome_0["previous"];
    return {$: "../src/ecs/column.Accepted", "column": ($$$$047src$047ecs$047column$058clear_stamp$1262$(_column_0, _id_0)), "previous": _previous_0};
  } else {
    const _column_1 = _outcome_0["column"];
    const _incoming_0 = _outcome_0["incoming"];
    return {$: "../src/ecs/column.Rejected", "column": _column_1, "incoming": _incoming_0};
  }
}

function $$$$047src$047ecs$047component$058replace_clock_checked$1260$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047src$047ecs$047component$058replace_clock_advanced$1260$(_id_0, _present_0, _incoming_1, ($$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058replaced$1264$(_result_0) {
  if (_result_0.$ === "../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047src$047ecs$047component$058structural_replace$1264$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047src$047ecs$047component$058replace_allowed$1264$(($$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058locked$() {
  return $$$$047src$047ecs$047component$058define$1264$("Locked");
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058replaced$1262$(_result_0) {
  if (_result_0.$ === "../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047src$047ecs$047component$058structural_replace$1262$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047src$047ecs$047component$058replace_allowed$1262$(($$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058replaced$1261$(_result_0) {
  if (_result_0.$ === "../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047src$047ecs$047component$058structural_replace$1261$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047src$047ecs$047component$058replace_allowed$1261$(($$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058recipe$() {
  return $$$$047src$047ecs$047component$058define$1261$("Recipe");
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058replaced$1260$(_result_0) {
  if (_result_0.$ === "../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047src$047ecs$047component$058structural_replace$1260$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047src$047ecs$047component$058replace_allowed$1260$(($$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058change_value$1260$(_own_0, _entity_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../src/ecs/component.Found") {
    const _value_0 = _t_0["value"];
    return $$$$047experiments$047public$045schedule$045readers$047consumers$058change_write$1260$(_own_0, _entity_0, _value_0, _ctx_0);
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../src/ecs/transaction.Failure", "error": "missing"}, "snd": "missing"}};
  }
}

function $$$$047src$047ecs$047capabilities$058get$1260$(_ctx_0) {
  return run_tail(($$$$047src$047ecs$047capabilities$058write_read_field$1260$(($$$$047experiments$047public$045schedule$045readers$047consumers$058stock$1260$(($$$$047src$047ecs$047compose$058plan_caps$1260$(($$$$047experiments$047public$045schedule$045readers$047consumers$058plan$()))))))), _ctx_0);
}

function $$$$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047component$058restore_swap$1260$(_rest_0, _result_0) {
  if (_result_0.$ === "../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": ($$$$047experiments$047public$045schedule$045readers$047schema$058put_stock$(_rest_0, _column_0)), "snd": {$: "Unit"}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": ($$$$047experiments$047public$045schedule$045readers$047schema$058put_stock$(_rest_0, _column_1)), "snd": {$: "Unit"}};
  }
}

function $$$$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047src$047ecs$047column$058grow$1260$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047src$047ecs$047column$058ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047src$047ecs$047component$058replace_clock_advanced$1262$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047src$047ecs$047component$058replaced$1262$(($$$$047src$047ecs$047component$058swap_world$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047src$047ecs$047column$058cleared$1261$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../src/ecs/column.Accepted") {
    const _column_0 = _outcome_0["column"];
    const _previous_0 = _outcome_0["previous"];
    return {$: "../src/ecs/column.Accepted", "column": ($$$$047src$047ecs$047column$058clear_stamp$1261$(_column_0, _id_0)), "previous": _previous_0};
  } else {
    const _column_1 = _outcome_0["column"];
    const _incoming_0 = _outcome_0["incoming"];
    return {$: "../src/ecs/column.Rejected", "column": _column_1, "incoming": _incoming_0};
  }
}

function $$$$047src$047ecs$047column$058swap$1261$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058cleared$1263$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../src/ecs/column.Accepted") {
    const _column_0 = _outcome_0["column"];
    const _previous_0 = _outcome_0["previous"];
    return {$: "../src/ecs/column.Accepted", "column": ($$$$047src$047ecs$047column$058clear_stamp$1263$(_column_0, _id_0)), "previous": _previous_0};
  } else {
    const _column_1 = _outcome_0["column"];
    const _incoming_0 = _outcome_0["incoming"];
    return {$: "../src/ecs/column.Rejected", "column": _column_1, "incoming": _incoming_0};
  }
}

function $$$$047src$047ecs$047column$058cleared$1264$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../src/ecs/column.Accepted") {
    const _column_0 = _outcome_0["column"];
    const _previous_0 = _outcome_0["previous"];
    return {$: "../src/ecs/column.Accepted", "column": ($$$$047src$047ecs$047column$058clear_stamp$1264$(_column_0, _id_0)), "previous": _previous_0};
  } else {
    const _column_1 = _outcome_0["column"];
    const _incoming_0 = _outcome_0["incoming"];
    return {$: "../src/ecs/column.Rejected", "column": _column_1, "incoming": _incoming_0};
  }
}

function $$$$047src$047ecs$047column$058swap$1264$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058swap_sized$1264$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058swap_state$1264$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058unseal$1264$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_swap_state$1264$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058indexed_unseal$1264$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_swap_state$1264$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1264$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058clear_stamp$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058clear_state$1260$(_id_0, ($$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_clear_state$1260$(_id_0, ($$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_clear_state$1260$(_id_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058clear_stamp$1262$(_column_0, _id_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058clear_state$1262$(_id_0, ($$$$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_clear_state$1262$(_id_0, ($$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_clear_state$1262$(_id_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047component$058replace_clock_advanced$1260$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047src$047ecs$047component$058replaced$1260$(($$$$047src$047ecs$047component$058swap_world$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047src$047ecs$047component$058replace_allowed$1264$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047src$047ecs$047component$058replace_clock$1264$(_id_0, _incoming_0, ($$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047src$047ecs$047component$058define$1264$(_name_0) {
  return {$: "../src/ecs/component.Family", "name": _name_0};
}

function $$$$047src$047ecs$047component$058replace_allowed$1261$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047src$047ecs$047component$058replace_clock$1261$(_id_0, _incoming_0, ($$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047src$047ecs$047component$058define$1261$(_name_0) {
  return {$: "../src/ecs/component.Family", "name": _name_0};
}

function $$$$047experiments$047public$045schedule$045readers$047consumers$058change_write$1260$(_own_0, _entity_0, _value_0, _ctx_0) {
  if (_own_0) {
    return {$: "Tuple", "fst": run_loop($$$$047src$047ecs$047capabilities$058set$1260$(_ctx_0, ($$$$047experiments$047public$045schedule$045readers$047consumers$058increment$(_value_0)))), "snd": {$: "Tuple", "fst": {$: "../src/ecs/transaction.Success"}, "snd": ($$$$047experiments$047public$045schedule$045readers$047consumers$058row$(_entity_0, _value_0))}};
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../src/ecs/transaction.Success"}, "snd": ($$$$047experiments$047public$045schedule$045readers$047consumers$058row$(_entity_0, _value_0))}};
  }
}

function $$$$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047src$047ecs$047column$058grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, ($$$$047src$047ecs$047column$058recover$1260$(_column_0)));
  }
}

function $$$$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_grow$1260$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047src$047ecs$047component$058replaced$1262$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047src$047ecs$047component$058swap_world$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047world$058with_store_finish$1267$(($$$$047src$047ecs$047component$058swap_store$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058take_queue$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047src$047ecs$047column$058clear_stamp$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058clear_state$1261$(_id_0, ($$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_clear_state$1261$(_id_0, ($$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_clear_state$1261$(_id_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047src$047ecs$047column$058unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047src$047ecs$047column$058indexed_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058clear_stamp$1263$(_column_0, _id_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058clear_state$1263$(_id_0, ($$$$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_clear_state$1263$(_id_0, ($$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_clear_state$1263$(_id_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058clear_stamp$1264$(_column_0, _id_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058clear_state$1264$(_id_0, ($$$$047src$047ecs$047column$058unseal$1264$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_clear_state$1264$(_id_0, ($$$$047src$047ecs$047column$058indexed_unseal$1264$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_clear_state$1264$(_id_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1264$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058swap_sized$1264$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047src$047ecs$047column$058swap_checked$1264$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058swap_state$1264$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058prepared_swap$1264$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047src$047ecs$047column$058unseal$1264$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_swap_state$1264$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_swap_sized$1264$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047src$047ecs$047column$058indexed_unseal$1264$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_prepared_swap_state$1264$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_prepared_swap$1264$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047src$047ecs$047column$058indexed_prepared_unseal$1264$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058clear_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058indexed_clear_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)));
}

function $$$$047src$047ecs$047column$058indexed_prepared_clear_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058clear_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058indexed_clear_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, ($$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)));
}

function $$$$047src$047ecs$047column$058indexed_prepared_clear_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047component$058replaced$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047src$047ecs$047component$058swap_world$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047world$058with_store_finish$1265$(($$$$047src$047ecs$047component$058swap_store$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058take_stock$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047src$047ecs$047component$058replace_clock$1264$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047src$047ecs$047component$058replace_clock_checked$1264$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047src$047ecs$047component$058owner_present$1264$(_incoming_0)));
}

function $$$$047src$047ecs$047component$058replace_clock$1261$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047src$047ecs$047component$058replace_clock_checked$1261$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047src$047ecs$047component$058owner_present$1261$(_incoming_0)));
}

function $$$$047src$047ecs$047capabilities$058set$1260$(_ctx_0, _value_0) {
  return run_tail(($$$$047src$047ecs$047capabilities$058write_field$1260$(($$$$047experiments$047public$045schedule$045readers$047consumers$058stock$1260$(($$$$047src$047ecs$047compose$058plan_caps$1260$(($$$$047experiments$047public$045schedule$045readers$047consumers$058plan$())))))))(_ctx_0), _value_0);
}

function $$$$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058absent$1260$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047src$047ecs$047column$058absent$1260$(_rest_0)), ($$$$047src$047ecs$047column$058absent$1260$(_rest_0)));
  }
}

function $$$$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, _column_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047src$047ecs$047column$058indexed_grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          return $$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047src$047ecs$047world$058with_store_finish$1267$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047src$047ecs$047component$058swap_store$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047src$047ecs$047component$058swap_join$1262$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047src$047ecs$047column$058swap$1262$(($$$$047src$047ecs$047column$058ensure$1262$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047src$047ecs$047column$058clear_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058indexed_clear_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)));
}

function $$$$047src$047ecs$047column$058indexed_prepared_clear_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047src$047ecs$047column$058swapped$1261$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058recover$1261$({$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047src$047ecs$047column$058seek$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058recover$1261$({$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047src$047ecs$047column$058indexed_seek$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047src$047ecs$047column$058clear_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058indexed_clear_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, ($$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)));
}

function $$$$047src$047ecs$047column$058indexed_prepared_clear_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058clear_state$1264$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058indexed_clear_state$1264$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, ($$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)));
}

function $$$$047src$047ecs$047column$058indexed_prepared_clear_state$1264$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058swap_checked$1264$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047src$047ecs$047column$058swapped$1264$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047src$047ecs$047column$058prepared_swap$1264$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047src$047ecs$047column$058swap_recovered$1264$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058recover$1264$({$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047src$047ecs$047column$058seek$1264$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1264$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_swap_sized$1264$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_swap_checked$1264$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058indexed_prepared_swap$1264$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047src$047ecs$047column$058swap_recovered$1264$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058recover$1264$({$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047src$047ecs$047column$058indexed_seek$1264$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047src$047ecs$047column$058past_current$1264$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047src$047ecs$047indexed$045lifecycle$058clear_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)), (_id_0 <= _capacity_0));
}

function $$$$047src$047ecs$047world$058with_store_finish$1265$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047src$047ecs$047component$058swap_store$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047src$047ecs$047column$058swap$1260$(($$$$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047src$047ecs$047component$058replace_clock_checked$1264$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047src$047ecs$047component$058replace_clock_advanced$1264$(_id_0, _present_0, _incoming_1, ($$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047src$047ecs$047component$058owner_present$1264$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047src$047ecs$047component$058replace_clock_checked$1261$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047src$047ecs$047component$058replace_clock_advanced$1261$(_id_0, _present_0, _incoming_1, ($$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047src$047ecs$047component$058owner_present$1261$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047src$047ecs$047component$058swap_join$1262$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047src$047ecs$047component$058mark_swapped$1262$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047src$047ecs$047component$058owner_present$1262$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($$$$047experiments$047public$045schedule$045readers$047schema$058put_queue$(_rest_0, _column_1)), "snd": {$: "../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047src$047ecs$047column$058ensure$1262$(_column_0, _target_0) {
  return $$$$047src$047ecs$047column$058ensure_checked$1262$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0) {
  return {$: "../src/ecs/column.Indexed", "state": {$: "../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047src$047ecs$047column$058swapped$1261$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return {$: "../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047src$047ecs$047column$058recover$1261$(_column_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058recover_state$1261$(($$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_recover_state$1261$(($$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": ($$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047src$047ecs$047column$058indexed_seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, _metadata_0) {
  return {$: "../src/ecs/column.Indexed", "state": {$: "../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047src$047ecs$047column$058swapped$1264$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047src$047ecs$047column$058swap_recovered$1264$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058swap_sized$1264$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_swap_state$1264$(_id_0, _incoming_0, ($$$$047src$047ecs$047column$058indexed_unseal$1264$(_carrier_0)));
  } else {
    return {$: "../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047src$047ecs$047column$058recover$1264$(_column_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058recover_state$1264$(($$$$047src$047ecs$047column$058unseal$1264$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_recover_state$1264$(($$$$047src$047ecs$047column$058indexed_prepared_unseal$1264$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058seek$1264$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058past_current$1264$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047src$047ecs$047column$058indexed_swap_checked$1264$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../src/ecs/column.Rejected", "column": ($$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047src$047ecs$047column$058indexed_swapped$1264$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047src$047ecs$047column$058indexed_seek$1264$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../src/ecs/column.Rejected", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../src/ecs/column.Accepted", "column": {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047src$047ecs$047indexed$045lifecycle$058clear_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0, _fits_0) {
  if (!_isnormal_0) {
    return {$: "../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": ($$$$047src$047ecs$047lifecycle$058clear$(_exceptional_0, _id_0))};
  } else {
    if (!_fits_0) {
      return {$: "../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
    } else {
      return $$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, {$: "../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0});
    }
  }
}

function $$$$047src$047ecs$047component$058replace_clock_advanced$1264$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047src$047ecs$047component$058replaced$1264$(($$$$047src$047ecs$047component$058swap_world$1264$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047src$047ecs$047component$058replace_clock_advanced$1261$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047src$047ecs$047component$058replaced$1261$(($$$$047src$047ecs$047component$058swap_world$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047src$047ecs$047component$058mark_swapped$1262$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047experiments$047public$045schedule$045readers$047schema$058put_queue$(_rest_0, ($$$$047src$047ecs$047column$058mark$1262$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047src$047ecs$047column$058ensure_checked$1262$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047src$047ecs$047column$058ensure_sized$1262$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047src$047ecs$047column$058ensure_state$1262$(_target_0, ($$$$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
    }
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047src$047ecs$047column$058indexed_ensure_state$1262$(_target_0, ($$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1262$(_target_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
    }
  }
}

function $$$$047src$047ecs$047column$058recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047src$047ecs$047column$058indexed_recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../src/ecs/column.Accepted", "column": ($$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047src$047ecs$047column$058recover_state$1264$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058recover_current$1264$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047src$047ecs$047column$058indexed_recover_state$1264$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_recover_current$1264$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047src$047ecs$047column$058indexed_swapped$1264$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../src/ecs/column.Accepted", "column": ($$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047src$047ecs$047component$058replaced$1264$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047src$047ecs$047component$058swap_world$1264$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047world$058with_store_finish$1269$(($$$$047src$047ecs$047component$058swap_store$1264$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058take_locked$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047src$047ecs$047component$058replaced$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047src$047ecs$047component$058swap_world$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047src$047ecs$047world$058with_store_finish$1266$(($$$$047src$047ecs$047component$058swap_store$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($$$$047experiments$047public$045schedule$045readers$047schema$058take_recipe$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047src$047ecs$047column$058mark$1262$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058ensure_sized$1262$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047src$047ecs$047column$058grow$1262$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047src$047ecs$047column$058ensure_state$1262$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058ensure_prepared$1262$(_target_0, {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047src$047ecs$047column$058indexed_ensure_state$1262$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_ensure_sized$1262$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1262$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058ensure_prepared$1262$(_target_0, {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../src/ecs/column.Column", "values": ($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../src/ecs/column.Column", "values": ($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047src$047ecs$047column$058recover_current$1264$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../src/ecs/column.Column", "values": ($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1264$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../src/ecs/column.Column", "values": ($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1264$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047src$047ecs$047column$058indexed_recover_current$1264$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047src$047ecs$047column$058indexed_wrap$1264$(($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1264$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047src$047ecs$047column$058indexed_wrap$1264$(($$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047src$047ecs$047column$058recover_past$1264$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047src$047ecs$047world$058with_store_finish$1269$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047src$047ecs$047component$058swap_store$1264$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047src$047ecs$047component$058swap_join$1264$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047src$047ecs$047column$058swap$1264$(($$$$047src$047ecs$047column$058ensure$1264$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058take_locked$(_store_0) {
  const _stock_0 = _store_0["stock"];
  const _recipe_0 = _store_0["recipe"];
  const _queue_0 = _store_0["queue"];
  const _enabled_0 = _store_0["enabled"];
  const _locked_0 = _store_0["locked"];
  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/schema.LockedRest", "stock": _stock_0, "recipe": _recipe_0, "queue": _queue_0, "enabled": _enabled_0}, "snd": _locked_0};
}

function $$$$047src$047ecs$047world$058with_store_finish$1266$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047src$047ecs$047component$058swap_store$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047src$047ecs$047column$058swap$1261$(($$$$047src$047ecs$047column$058ensure$1261$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058take_recipe$(_store_0) {
  const _stock_0 = _store_0["stock"];
  const _recipe_0 = _store_0["recipe"];
  const _queue_0 = _store_0["queue"];
  const _enabled_0 = _store_0["enabled"];
  const _locked_0 = _store_0["locked"];
  return {$: "Tuple", "fst": {$: "../experiments/public-schedule-readers/schema.RecipeRest", "stock": _stock_0, "queue": _queue_0, "enabled": _enabled_0, "locked": _locked_0}, "snd": _recipe_0};
}

function $$$$047src$047ecs$047column$058mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058indexed_mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_mark_got$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047src$047ecs$047column$058indexed_prepared_mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_prepared_mark_got$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047src$047ecs$047column$058grow$1262$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047src$047ecs$047column$058absent$1262$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058ensure_prepared$1262$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047src$047ecs$047column$058ensure_recovered$1262$(_target_0, ($$$$047src$047ecs$047column$058recover$1262$(_column_0)));
  }
}

function $$$$047src$047ecs$047column$058indexed_ensure_sized$1262$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_grow$1262$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047src$047ecs$047column$058recover_past$1261$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047column$058recover_past$1264$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047src$047ecs$047component$058swap_join$1264$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047src$047ecs$047component$058mark_swapped$1264$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047src$047ecs$047component$058owner_present$1264$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($$$$047experiments$047public$045schedule$045readers$047schema$058put_locked$(_rest_0, _column_1)), "snd": {$: "../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047src$047ecs$047column$058ensure$1264$(_column_0, _target_0) {
  return $$$$047src$047ecs$047column$058ensure_checked$1264$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047src$047ecs$047component$058mark_swapped$1261$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047src$047ecs$047component$058owner_present$1261$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($$$$047experiments$047public$045schedule$045readers$047schema$058put_recipe$(_rest_0, _column_1)), "snd": {$: "../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047src$047ecs$047column$058ensure$1261$(_column_0, _target_0) {
  return $$$$047src$047ecs$047column$058ensure_checked$1261$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047src$047ecs$047column$058indexed_mark_got$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, ($$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047src$047ecs$047column$058indexed_prepared_mark_got$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058absent$1262$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047src$047ecs$047column$058absent$1262$(_rest_0)), ($$$$047src$047ecs$047column$058absent$1262$(_rest_0)));
  }
}

function $$$$047src$047ecs$047column$058ensure_recovered$1262$(_target_0, _column_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058ensure_sized$1262$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_ensure_state$1262$(_target_0, ($$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047src$047ecs$047column$058indexed_grow$1262$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0);
        } else {
          return $$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047src$047ecs$047column$058absent$1262$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047src$047ecs$047component$058mark_swapped$1264$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047experiments$047public$045schedule$045readers$047schema$058put_locked$(_rest_0, ($$$$047src$047ecs$047column$058mark$1264$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058put_locked$(_rest_0, _column_0) {
  const _stock_0 = _rest_0["stock"];
  const _recipe_0 = _rest_0["recipe"];
  const _queue_0 = _rest_0["queue"];
  const _enabled_0 = _rest_0["enabled"];
  return {$: "../experiments/public-schedule-readers/schema.Store", "stock": _stock_0, "recipe": _recipe_0, "queue": _queue_0, "enabled": _enabled_0, "locked": _column_0};
}

function $$$$047src$047ecs$047column$058ensure_checked$1264$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047src$047ecs$047column$058ensure_sized$1264$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047src$047ecs$047column$058ensure_state$1264$(_target_0, ($$$$047src$047ecs$047column$058unseal$1264$(_carrier_0)));
    }
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047src$047ecs$047column$058indexed_ensure_state$1264$(_target_0, ($$$$047src$047ecs$047column$058indexed_unseal$1264$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1264$(_target_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1264$(_carrier_2)));
    }
  }
}

function $$$$047src$047ecs$047component$058mark_swapped$1261$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047experiments$047public$045schedule$045readers$047schema$058put_recipe$(_rest_0, ($$$$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047experiments$047public$045schedule$045readers$047schema$058put_recipe$(_rest_0, _column_0) {
  const _stock_0 = _rest_0["stock"];
  const _queue_0 = _rest_0["queue"];
  const _enabled_0 = _rest_0["enabled"];
  const _locked_0 = _rest_0["locked"];
  return {$: "../experiments/public-schedule-readers/schema.Store", "stock": _stock_0, "recipe": _column_0, "queue": _queue_0, "enabled": _enabled_0, "locked": _locked_0};
}

function $$$$047src$047ecs$047column$058ensure_checked$1261$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047src$047ecs$047column$058ensure_state$1261$(_target_0, ($$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
    }
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, ($$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1261$(_target_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
    }
  }
}

function $$$$047src$047ecs$047column$058mark$1264$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058mark_state$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047src$047ecs$047column$058unseal$1264$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_mark_state$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047src$047ecs$047column$058indexed_unseal$1264$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_mark_state$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1264$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058ensure_sized$1264$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047src$047ecs$047column$058grow$1264$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047src$047ecs$047column$058ensure_state$1264$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058ensure_prepared$1264$(_target_0, {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047src$047ecs$047column$058indexed_ensure_state$1264$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_ensure_sized$1264$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1264$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058ensure_prepared$1264$(_target_0, {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047src$047ecs$047column$058grow$1261$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047src$047ecs$047column$058ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_ensure_sized$1261$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047src$047ecs$047column$058mark_state$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058indexed_mark_state$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_mark_got$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047src$047ecs$047column$058indexed_prepared_mark_state$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_prepared_mark_got$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047src$047ecs$047column$058grow$1264$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047src$047ecs$047column$058absent$1264$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058ensure_prepared$1264$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047src$047ecs$047column$058ensure_recovered$1264$(_target_0, ($$$$047src$047ecs$047column$058recover$1264$(_column_0)));
  }
}

function $$$$047src$047ecs$047column$058indexed_ensure_sized$1264$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_grow$1264$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../src/ecs/column.Prepared", "state": {$: "../src/ecs/column.Owned", "state": {$: "../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047src$047ecs$047column$058grow$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047src$047ecs$047column$058absent$1261$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047src$047ecs$047column$058ensure_recovered$1261$(_target_0, ($$$$047src$047ecs$047column$058recover$1261$(_column_0)));
  }
}

function $$$$047src$047ecs$047column$058indexed_ensure_sized$1261$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_grow$1261$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047src$047ecs$047column$058indexed_mark_got$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, ($$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047src$047ecs$047column$058indexed_prepared_mark_got$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058absent$1264$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047src$047ecs$047column$058absent$1264$(_rest_0)), ($$$$047src$047ecs$047column$058absent$1264$(_rest_0)));
  }
}

function $$$$047src$047ecs$047column$058ensure_recovered$1264$(_target_0, _column_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058ensure_sized$1264$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_ensure_state$1264$(_target_0, ($$$$047src$047ecs$047column$058indexed_unseal$1264$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047src$047ecs$047column$058indexed_grow$1264$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, _metadata_0);
        } else {
          return $$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047src$047ecs$047column$058absent$1264$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../src/ecs/column.PreparedIndexed", "state": {$: "../src/ecs/column.IndexedPreparedOwned", "state": {$: "../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047src$047ecs$047column$058absent$1261$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047src$047ecs$047column$058absent$1261$(_rest_0)), ($$$$047src$047ecs$047column$058absent$1261$(_rest_0)));
  }
}

function $$$$047src$047ecs$047column$058ensure_recovered$1261$(_target_0, _column_0) {
  if (_column_0.$ === "../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, ($$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047src$047ecs$047column$058indexed_grow$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        } else {
          return $$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047src$047ecs$047column$058absent$1261$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);