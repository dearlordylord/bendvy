import {timed} from './capture.mjs';
import {run as R0} from './fragments-reference.mjs';
await timed(async()=>{for(let batch=0;batch<2;batch++){R0();}});
