import {timed} from './capture.mjs';
import {run as R0} from './readers-reference.mjs';
import {run as R1} from './added-reference.mjs';
await timed(async()=>{for(let batch=0;batch<2;batch++){R0();R1();}});
