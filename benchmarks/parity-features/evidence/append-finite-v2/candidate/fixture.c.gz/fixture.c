
// Imports
// =======

// The Objective-C headers take #include, not #import: a build
// (-o) reads an #import as the framework of an effect.

#pragma clang fp contract(off)

#if defined(__CUDACC_RTC__)
#define BEND_RTC 1
#endif

#ifdef __METAL_VERSION__
#include <metal_stdlib>
using namespace metal;
#elif !defined(BEND_RTC)
#ifdef __APPLE__
#define _DARWIN_UNLIMITED_SELECT
#else
#define _GNU_SOURCE
#endif
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <unistd.h>
#include <signal.h>
#include <sys/mman.h>
#include <time.h>
#include <poll.h>
#include <sys/select.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif
#ifdef __OBJC__
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#elif BEND_CUDA
#include <cuda.h>
#include <nvrtc.h>
#include <fcntl.h>
#include <sys/stat.h>
#endif
#endif

// Dialect
// =======

// Metal needs coherent(device) (MSL 3.2), or M1-class parts lose stores
// across the threadgroups of a dispatch. CUDA keeps plain data cacheable
// in L1: lanes hand off through a32 and FENCE. Only clang 19+ has both
// preserve_none and preserve_most, and compiles preserve_most soundly; at
// -O0 its register allocator cannot place a preserve_none segment, so an
// unoptimized build takes neither. A segment is a case of the device's
// switch; on the host, a preserve_none function (WL_SIG) entered by
// musttail, its words fresh at WL_OPEN.

#ifdef __METAL_VERSION__
#if __METAL_VERSION__ >= 320
#define DEV     coherent(device) device
#else
#define DEV     device
#endif
#define THR     thread
#define TG      threadgroup
#define INLINE  inline
#define OUTLINE static
#define CONSTV  constant
#define DEVICE  1
#define CLZ(x)  clz(x)
#define FENCE() atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst)
#define BAR()   threadgroup_barrier(mem_flags::mem_threadgroup)
#define BARD()  threadgroup_barrier(mem_flags::mem_device \
  | mem_flags::mem_threadgroup)
#else
#define DEV
#define THR
#define TG
#define INLINE  static inline
#define CONSTV  static const
#ifdef BEND_RTC
#define OUTLINE static __attribute__((noinline))
#define DEVICE  1
#define CLZ(x)  (u32)__clz((int)(x))
#define FENCE() __threadfence()
#define BAR()   __syncthreads()
#define BARD()  \
  { __threadfence(); __syncthreads(); }
#else
#if __has_attribute(preserve_none) && __has_attribute(preserve_most) \
  && defined(__OPTIMIZE__)
#define PRESERVE(A) __attribute__((A))
#else
#define PRESERVE(A)
#endif
#define OUTLINE static __attribute__((noinline, cold)) PRESERVE(preserve_most)
#define DEVICE  0
#define CLZ(x)  (u32)__builtin_clz(x)
#define FENCE() ((void)0)
#endif
#endif
#define FAR static __attribute__((noinline))

#if DEVICE
#define LOCK(l)
#define UNLOCK(l)
#define WL_CASE(F) case F:
#define WL_OPEN    {
#define WL_JMP(F)  { fid = (F); break; }
#define WL_DYN     WL_JMP
#else
#define LOCK(l)    while (__atomic_exchange_n(&(l), 1, __ATOMIC_ACQUIRE)) {}
#define UNLOCK(l)  __atomic_store_n(&(l), 0, __ATOMIC_RELEASE)
#define WL_FN      static PRESERVE(preserve_none) __attribute__((noinline)) Term
#define WL_CASE(F) WL_FN WL_##F(WL_SIG)
#define WL_OPEN    { WL_BANK u32 rn;
#define WL_JMP(F)  __attribute__((musttail)) return WL_##F(WL_ALL)
#define WL_DYN(F)  __attribute__((musttail)) return wl_tab[F](WL_ALL)
#endif
#define WL_SPIN     for (;;) { if (err_spun(e.mem, &wpoll)) { return 0; }
#define WL_SPUN     } break;
#define WL_AGAIN(F) continue

#define LANE_STEP (DEVICE ? (long)CUBE : 1)
#define STK(I)    sp[(long)(I) * LANE_STEP]

#define WL_RETN(N)  { rn = (N); sp -= LANE_STEP; WL_DYN((u32)STK(0)); }
#define WL_CONT     STK(-3)
#define WL_IDX      STK(-2)
#define WL_POPN(N)  sp -= N * LANE_STEP
#define WL_PUSHN(N) sp += N * LANE_STEP
#define WL_FRAME(T) \
  u64 wtl = task_tail(T); \
  u64 wtw = e.mem[wtl + 1]; \
  STK(0) = e.mem[wtl]; \
  STK(1) = (wtw >> 32) & 0xFFFF; \
  STK(2) = FID_EXIT; \
  sp += 3 * LANE_STEP;
#define WL_ARGS(A, N) \
  for (u32 wi = 0; wi + 1 < N; wi += 1) { \
    STK(wi) = e.mem[A + wi]; \
  } \
  sp += (N - 1) * LANE_STEP;
#define WL_ROOM(N) \
  if (DEVICE && sp + (N) * CUBE >= e.mem + STAT_OFF + CUBE) { \
    err_post(e.mem, ERR_DEEP); \
    return 0; \
  }

// Types
// =====

#ifdef __METAL_VERSION__
typedef ulong u64;
typedef uint  u32;
typedef uchar u8;
#elif defined(BEND_RTC)
typedef unsigned long long u64;
typedef unsigned int       u32;
typedef unsigned char      u8;
#else
typedef uint64_t u64;
typedef uint32_t u32;
typedef uint8_t  u8;
#endif
typedef float f32;

typedef u64 Term;

typedef struct {
  DEV u64* mem;
  DEV u64* alc;
} Env;

typedef struct {
  u64 off;
  u32 rd;
  u32 wr;
  u32 top;
} Bank;

#if DEVICE
typedef u32 u32a;
#else
typedef u32 __attribute__((may_alias)) u32a;
#endif

// Constants
// =========

#define TAG_PAK 1ull
#define TAG_CTR 2ull
#define TAG_CLO 3ull
#define TAG_BUF 4ull
#define TAG_TSK 5ull
#define TAG_ARR 6ull

#define TERM_HOLE (~0ull)
#define LOC_MASK  ((1ull << 40) - 1)
#define RFC_BIT   (1ull << 63)
#define RFC_CNT   ((1u << 24) - 1)
#define NAT_IMM   ((1ull << 48) - 1)

#define ERR_RING 1
#define ERR_TAGS 2
#define ERR_HEAP 3
#define ERR_FIDS 4
#define ERR_NATS 5
#define ERR_RFCS 6
#define ERR_DEEP 7
#define ERR_ARRS 8

#define LINE      16
#define PAGE_BITS 7
#define PAGE_LEN  (1ull << PAGE_BITS)
#define CUBE_T    128
#define CUBE      ((u64)CUBE_T * CUBE_T)
#define CUBE_G    (1u << CUBE_LOG)
#define LANES     ((u64)CUBE_T << CUBE_LOG)
#define RING_LOG  (17 - CUBE_LOG)
#define RING_LEN  (1ull << RING_LOG)
#define STAK_LEN  (1ull << 11)
#define NCLS      8
#define NCLS_ALL  32
#define IO_HELP   64

#define TG_HOLD   2304
#define CHUNK     256
#define CAP_WORDS 32768
#define QUANTUM   (DEVICE ? PAGE_LEN \
  : KEEP_WORDS < 32 * PAGE_LEN ? KEEP_WORDS : 32 * PAGE_LEN)
#if DEVICE
#define KEEP_WORDS CHUNK
#endif
#define RING_WORDS ((1ull << 10) + 2)

#define H_BUMP       0
#define H_CAP        1
#define H_CURSOR     LINE
#define H_ROOT_DONE  (2 * LINE)
#define H_ERROR_CODE (3 * LINE)
#define H_ROOT_WORD  (4 * LINE)
#define H_BANK       (H_ROOT_WORD + WL_RESW)

#define PAGE_UP(n) (((n) + PAGE_LEN - 1) & ~(PAGE_LEN - 1))
#define ALC_OFF  PAGE_UP(H_BANK + 3 * NCLS_ALL)
#define RING_OFF (ALC_OFF + CUBE * 2 * NCLS_ALL)
#define STAK_OFF (RING_OFF + CUBE * RING_WORDS)
#define STAT_OFF (STAK_OFF + CUBE * STAK_LEN)
#define HEAP_OFF (STAT_OFF + PAGE_UP(STAT_LEN))

// Globals
// =======

// The bag is 2^CUBE_LOG groups of CUBE_T lanes (a -D constant on the
// device). The device program compiles from the binary's own text.

#if !DEVICE

static u64*    CORPUS;
static u64    ALC[CUBE_T + 1][3 * NCLS_ALL] __attribute__((aligned(128)));
static u32    KEEP_WORDS;
static u32    CUBE_LOG = 7;
static u32    bank_lock;

static u32             pool_size;
static u32             pool_row;
static u32             pool_done;
static pthread_mutex_t pool_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  pool_wake = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  pool_join = PTHREAD_COND_INITIALIZER;

#if BEND_METAL || BEND_CUDA
#pragma clang diagnostic ignored "-Wc23-extensions"
static const char BEND_SRC[] = {
#embed __FILE__
, 0 };
#endif

#ifdef __OBJC__
static id<MTLDevice>               gpu_dev;
static id<MTLCommandQueue>         gpu_que;
static id<MTLComputePipelineState> gpu_pso;
static id<MTLBuffer>               gpu_buf;
static id<MTLComputeCommandEncoder> gpu_enc;
#elif BEND_CUDA
static CUdevice   gpu_dev;
static CUmodule   gpu_lib;
static CUfunction gpu_pso;
#endif
static bool io_gpu;
static DEV Term*  io_stk;

static const char* CLI_HELP =
  "usage: %s [options] [arguments]\n"
  "  --threads N       worker threads, 1 to 128 (default: the CPU count)\n"
  "  --gpu on|off|4GB  run ! calls on the GPU, over this much of its memory\n"
  "                    (default: on if present, over 2GB on Metal)\n"
  "  --gpu-build       write the GPU program and exit\n"
  "  --bend-help       show this text\n"
  "  --                the rest are the program's arguments (IO.args)\n";

#endif

// Tables
// ======

#define CID_TUPLE 0
#define CID_SNIL 1
#define CID_SCON 2
#define CID_WCON 3
#define CID_EMIT 4
#define CID_HALT 5
#define CID_FAIL 6
#define CID_DONE 7
#define CID_NONE 8
#define CID_SOME 9
#define CID_FALSE 10
#define CID_TRUE 11
#define CID_UNIT 12
#define CID_NIL 13
#define CID_CON 14
#define CID_CHR 15
#define CID_IO_PRINT 16
#define FID_U32_SHOW_GO 0
#define FID_LIST_SHOW_GO_0 1
#define FID_LIST_SHOW_GO_0_K7 2
#define FID_LIST_SHOW_GO_0_K8 3
#define FID_LIST_SHOW_GO_0_K9 4
#define FID_U32_SHOW 5
#define FID_LIST_SHOW_0 6
#define FID_LIST_SHOW_0_K14 7
#define FID_LIST_SHOW_0_K15 8
#define FID_LIST_SHOW_0_K16 9
#define FID_OBSERVE 10
#define FID_OBSERVE_K18 11
#define FID_OBSERVE_K19 12
#define FID_OBSERVE_K20 13
#define FID_STRING_APPEND 14
#define FID_STRING_APPEND_K22 15
#define FID_MAIN 16
#define FID_MAIN_K24 17
#define FID_MAIN_K25 18
#define FID_MAIN_K26 19
#define FID_MAIN_K27 20
#define FID_MAIN_K28 21
#define FID_MAIN_K29 22
#define FID_MAIN_K30 23
#define FID_MAIN_K31 24
#define FID_MAIN_K32 25
#define FID_MAIN_K33 26
#define FID_MAIN_K34 27
#define FID_MAIN_K35 28
#define FID_MAIN_K36 29
#define FID_MAIN_K37 30
#define FID_MAIN_K38 31
#define FID_MAIN_K39 32
#define FID_MAIN_K40 33
#define FID_MAIN_K41 34
#define FID_MAIN_K42 35
#define FID_MAIN_K43 36
#define FID_MAIN_K44 37
#define FID_MAIN_K45 38
#define FID_MAIN_K46 39
#define FID_MAIN_K47 40
#define FID_MAIN_K48 41
#define FID_MAIN_K49 42
#define FID_MAIN_K50 43
#define FID_MAIN_K51 44
#define FID_MAIN_K52 45
#define FID_MAIN_K53 46
#define FID_MAIN_K54 47
#define FID_MAIN_K55 48
#define FID_MAIN_K56 49
#define FID_MAIN_K57 50
#define FID_MAIN_K58 51
#define FID_MAIN_K59 52
#define FID_MAIN_K60 53
#define FID_MAIN_K61 54
#define FID_MAIN_K62 55
#define FID_MAIN_K63 56
#define FID_MAIN_K64 57
#define FID_MAIN_K65 58
#define FID_MAIN_K66 59
#define FID_MAIN_K67 60
#define FID_MAIN_K68 61
#define FID_MAIN_K69 62
#define FID_MAIN_K70 63
#define FID_MAIN_K71 64
#define FID_MAIN_K72 65
#define FID_MAIN_K73 66
#define FID_MAIN_K74 67
#define FID_MAIN_K75 68
#define FID_MAIN_K76 69
#define FID_MAIN_K77 70
#define FID_MAIN_K78 71
#define FID_MAIN_K79 72
#define FID_MAIN_K80 73
#define FID_MAIN_K81 74
#define FID_MAIN_K82 75
#define FID_MAIN_K83 76
#define FID_MAIN_K84 77
#define FID_MAIN_K85 78
#define FID_MAIN_K86 79
#define FID_MAIN_K87 80
#define FID_MAIN_K88 81
#define FID_MAIN_K89 82
#define FID_MAIN_K90 83
#define FID_MAIN_K91 84
#define FID_MAIN_K92 85
#define FID_MAIN_K93 86
#define FID_MAIN_K94 87
#define FID_MAIN_K95 88
#define FID_MAIN_K96 89
#define FID_IO_PRINT 90
#define FID_IO_EMIT 91
#define FID_CLO_APPLY 92
#define FID_EXIT 93
#define FID_ENTER 94
CONSTV u8 FID_T[][3] = { { 3, 0, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 0, 0, 2 }, { 1, 1, 2 }, { 2, 1, 2 }, { 3, 1, 2 }, { 4, 1, 2 }, { 5, 1, 2 }, { 6, 1, 2 }, { 7, 1, 2 }, { 8, 1, 2 }, { 9, 1, 2 }, { 10, 1, 2 }, { 11, 1, 2 }, { 12, 1, 2 }, { 13, 1, 2 }, { 14, 1, 2 }, { 15, 1, 2 }, { 16, 1, 2 }, { 17, 1, 2 }, { 18, 1, 2 }, { 19, 1, 2 }, { 20, 1, 2 }, { 21, 1, 2 }, { 22, 1, 2 }, { 23, 1, 2 }, { 24, 1, 2 }, { 25, 1, 2 }, { 25, 1, 2 }, { 24, 1, 2 }, { 24, 1, 2 }, { 23, 1, 2 }, { 23, 1, 2 }, { 22, 1, 2 }, { 22, 1, 2 }, { 21, 1, 2 }, { 21, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 19, 1, 2 }, { 19, 1, 2 }, { 18, 1, 2 }, { 18, 1, 2 }, { 17, 1, 2 }, { 17, 1, 2 }, { 16, 1, 2 }, { 16, 1, 2 }, { 15, 1, 2 }, { 15, 1, 2 }, { 14, 1, 2 }, { 14, 1, 2 }, { 13, 1, 2 }, { 13, 1, 2 }, { 12, 1, 2 }, { 12, 1, 2 }, { 11, 1, 2 }, { 11, 1, 2 }, { 10, 1, 2 }, { 10, 1, 2 }, { 9, 1, 2 }, { 9, 1, 2 }, { 8, 1, 2 }, { 8, 1, 2 }, { 7, 1, 2 }, { 7, 1, 2 }, { 6, 1, 2 }, { 6, 1, 2 }, { 5, 1, 2 }, { 5, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 } };
CONSTV u8 CID_T[][2] = { { 2, 0 }, { 0, 0 }, { 2, 0 }, { 2, 1 }, { 1, 0 }, { 2, 0 }, { 1, 0 }, { 1, 0 }, { 0, 0 }, { 1, 0 }, { 0, 1 }, { 0, 1 }, { 0, 0 }, { 0, 1 }, { 2, 1 }, { 1, 0 }, { 2, 0 } };
#define STAT_LEN 34

#define WL_RESW 1
#define BANGS   0

#define WL_BANK Term r0, r1, r2;

#define WL_LOAD(A, N) \
  do { \
    if ((N) <= 0) break; r0 = e.mem[(A) + 0]; \
    if ((N) <= 1) break; r1 = e.mem[(A) + 1]; \
    if ((N) <= 2) break; r2 = e.mem[(A) + 2]; \
  } while (0);

#define WL_LAST(X) \
  switch (war) { \
    case 0: r0 = (X); \
      break; \
    case 1: r1 = (X); \
      break; \
    case 2: r2 = (X); \
      break; \
  }

#define WL_SAVE(V) (V)[0] = r0;

#define WL_TAKE(V) r0 = (V)[0];

#define WL_SIG Env e, DEV Term* sp, u32 seq, u32 rn, Term r0, Term r1, Term r2

#define WL_ALL e, sp, seq, rn, r0, r1, r2

#define WL_TABLE WL_X(FID_U32_SHOW_GO) WL_X(FID_LIST_SHOW_GO_0) WL_X(FID_LIST_SHOW_GO_0_K7) WL_X(FID_LIST_SHOW_GO_0_K8) WL_X(FID_LIST_SHOW_GO_0_K9) WL_X(FID_U32_SHOW) WL_X(FID_LIST_SHOW_0) WL_X(FID_LIST_SHOW_0_K14) WL_X(FID_LIST_SHOW_0_K15) WL_X(FID_LIST_SHOW_0_K16) WL_X(FID_OBSERVE) WL_X(FID_OBSERVE_K18) WL_X(FID_OBSERVE_K19) WL_X(FID_OBSERVE_K20) WL_X(FID_STRING_APPEND) WL_X(FID_STRING_APPEND_K22) WL_X(FID_MAIN) WL_X(FID_MAIN_K24) WL_X(FID_MAIN_K25) WL_X(FID_MAIN_K26) WL_X(FID_MAIN_K27) WL_X(FID_MAIN_K28) WL_X(FID_MAIN_K29) WL_X(FID_MAIN_K30) WL_X(FID_MAIN_K31) WL_X(FID_MAIN_K32) WL_X(FID_MAIN_K33) WL_X(FID_MAIN_K34) WL_X(FID_MAIN_K35) WL_X(FID_MAIN_K36) WL_X(FID_MAIN_K37) WL_X(FID_MAIN_K38) WL_X(FID_MAIN_K39) WL_X(FID_MAIN_K40) WL_X(FID_MAIN_K41) WL_X(FID_MAIN_K42) WL_X(FID_MAIN_K43) WL_X(FID_MAIN_K44) WL_X(FID_MAIN_K45) WL_X(FID_MAIN_K46) WL_X(FID_MAIN_K47) WL_X(FID_MAIN_K48) WL_X(FID_MAIN_K49) WL_X(FID_MAIN_K50) WL_X(FID_MAIN_K51) WL_X(FID_MAIN_K52) WL_X(FID_MAIN_K53) WL_X(FID_MAIN_K54) WL_X(FID_MAIN_K55) WL_X(FID_MAIN_K56) WL_X(FID_MAIN_K57) WL_X(FID_MAIN_K58) WL_X(FID_MAIN_K59) WL_X(FID_MAIN_K60) WL_X(FID_MAIN_K61) WL_X(FID_MAIN_K62) WL_X(FID_MAIN_K63) WL_X(FID_MAIN_K64) WL_X(FID_MAIN_K65) WL_X(FID_MAIN_K66) WL_X(FID_MAIN_K67) WL_X(FID_MAIN_K68) WL_X(FID_MAIN_K69) WL_X(FID_MAIN_K70) WL_X(FID_MAIN_K71) WL_X(FID_MAIN_K72) WL_X(FID_MAIN_K73) WL_X(FID_MAIN_K74) WL_X(FID_MAIN_K75) WL_X(FID_MAIN_K76) WL_X(FID_MAIN_K77) WL_X(FID_MAIN_K78) WL_X(FID_MAIN_K79) WL_X(FID_MAIN_K80) WL_X(FID_MAIN_K81) WL_X(FID_MAIN_K82) WL_X(FID_MAIN_K83) WL_X(FID_MAIN_K84) WL_X(FID_MAIN_K85) WL_X(FID_MAIN_K86) WL_X(FID_MAIN_K87) WL_X(FID_MAIN_K88) WL_X(FID_MAIN_K89) WL_X(FID_MAIN_K90) WL_X(FID_MAIN_K91) WL_X(FID_MAIN_K92) WL_X(FID_MAIN_K93) WL_X(FID_MAIN_K94) WL_X(FID_MAIN_K95) WL_X(FID_MAIN_K96) WL_X(FID_IO_PRINT) WL_X(FID_IO_EMIT) WL_X(FID_CLO_APPLY) WL_X(FID_EXIT)
#define MAIN_FID FID_MAIN
#define MAIN_PURE 0
#define BLK_SHR 0

#define TAB_AT(T, S, I) T[S < I ? S : I]

#define fid_arity(x) ((u32)FID_T[x][0])
#define fid_resw(x)  ((u32)FID_T[x][1])
#define fid_bangs(x) ((bool)(FID_T[x][2] & 1))
#define fid_nofk(x)  ((bool)(FID_T[x][2] & 2))
#define cid_arity(x) ((u32)CID_T[x][0])
#define cid_hot(x)   ((bool)CID_T[x][1])

// A32
// ===

// C11's atomics on every lane; a device FENCE releases or acquires.
// Metal's loads read through a volatile local, or the M1 and M2 pipeline
// builds die. A weak CAS may fail with the cell still x: a32_cmpx loops.

#define A32_LOOP(k, x) \
  INLINE u32 a32_##k(DEV u32* p, u32 v) { \
    u32 o = a32_load(p); \
    while (!a32_cas(p, &o, x)) { \
    } \
    return o; \
  }

#ifdef __METAL_VERSION__

INLINE DEV atomic_uint* A32(DEV u32* p) {
  return (DEV atomic_uint*)p;
}

INLINE TG atomic_uint* A32(TG u32* p) {
  return (TG atomic_uint*)p;
}

#define a32_load(p) \
  ({ volatile thread u32 _a32v = atomic_load_explicit(A32(p), RLX); _a32v; })

#else

#define a32_load(p) atomic_load_explicit(A32(p), RLX)

#ifdef BEND_RTC

#define A32(p) (p)
#define atomic_load_explicit(p, o)     (*(volatile u32*)(p))
#define atomic_store_explicit(p, v, o) (*(volatile u32*)(p) = (v))
#define atomic_fetch_add_explicit(p, v, o) atomicAdd((u32*)(p), v)
#define atomic_fetch_sub_explicit(p, v, o) atomicSub((u32*)(p), v)
#define atomic_fetch_and_explicit(p, v, o) atomicAnd((u32*)(p), v)
#define atomic_fetch_or_explicit(p, v, o) atomicOr((u32*)(p), v)
#define atomic_fetch_xor_explicit(p, v, o) atomicXor((u32*)(p), v)
#define atomic_fetch_min_explicit(p, v, o) atomicMin((u32*)(p), v)
#define atomic_fetch_max_explicit(p, v, o) atomicMax((u32*)(p), v)
#define atomic_compare_exchange_weak_explicit(p, e, v, s, f) a32_swp(p, e, v)

INLINE bool a32_swp(DEV u32* p, u32* e, u32 v) {
  u32 x = *e;
  *e = atomicCAS((u32*)p, x, v);
  return *e == x;
}

#else

#define A32(p) ((_Atomic u32*)(p))
#define atomic_fetch_min_explicit __c11_atomic_fetch_min
#define atomic_fetch_max_explicit __c11_atomic_fetch_max

#endif

#endif

#define RLX memory_order_relaxed

#if DEVICE
#define REL RLX
#define ACQ RLX
#define ACR RLX
#define a32_acq(p) FENCE()
#define w64_load(p) (*(p))
#else
#define REL memory_order_release
#define ACQ memory_order_acquire
#define ACR memory_order_acq_rel
#define a32_acq(p) ((void)a32_load_acq(p))
#define w64_load(p) atomic_load_explicit((_Atomic u64*)(p), RLX)
#endif

#define a32_store(p, v)     atomic_store_explicit(A32(p), v, RLX)
#define a32_add(p, v) atomic_fetch_add_explicit(A32(p), v, RLX)
#define a32_sub(p, v) atomic_fetch_sub_explicit(A32(p), v, RLX)
#define a32_and(p, v) atomic_fetch_and_explicit(A32(p), v, RLX)
#define a32_or(p, v) atomic_fetch_or_explicit(A32(p), v, RLX)
#define a32_xor(p, v) atomic_fetch_xor_explicit(A32(p), v, RLX)
#define a32_min(p, v) atomic_fetch_min_explicit(A32(p), v, RLX)
#define a32_max(p, v) atomic_fetch_max_explicit(A32(p), v, RLX)
#define a32_sub_rel(p, v)   (FENCE(), atomic_fetch_sub_explicit(A32(p), v, REL))
#define a32_store_rel(p, v) (FENCE(), atomic_store_explicit(A32(p), v, REL))
#define a32_at(H, word)     ((DEV u32*)&(H)[word])

INLINE u32 a32_load_acq(DEV u32* p) {
  u32 v = DEVICE ? a32_load(p) : atomic_load_explicit(A32(p), ACQ);
  FENCE();
  return v;
}

INLINE bool a32_cas(DEV u32* p, THR u32* e, u32 v) {
  FENCE();
  bool ok = atomic_compare_exchange_weak_explicit(A32(p), e, v, ACR, ACQ);
  FENCE();
  return ok;
}

A32_LOOP(exch, v)

INLINE u32 a32_cmpx(DEV u32* p, u32 x, u32 v) {
  u32 o = x;
  while (!a32_cas(p, &o, v) && o == x) {
  }
  return o;
}

// Err
// ===

#if DEVICE

INLINE void err_post(DEV u64* H, u32 code) {
  a32_cmpx(a32_at(H, H_ERROR_CODE), 0, code);
}

#else

static const char* ERR_TEXT[] = { "",
  "runtime fail-stop",
  "runtime fail-stop",
  "out of memory: run again with a bigger span, as in --gpu 8GB",
  "a function the device does not hold",
  "a Nat past the largest immediate 2^48-1",
  "runtime fail-stop",
  "memory fault (machine stack overflow?)",
  "an array past the deepest block class 31" };

static void err_fail(const char* msg) {
  fflush(stdout);
  fprintf(stderr, "bend: %s\n", msg);
  _exit(1);
}

static void err_post(u64* H, u32 code) {
  err_fail(ERR_TEXT[code]);
}

static void err_trap(int sig) {
  err_post(NULL, ERR_DEEP);
}

#endif

#define err_seen(H)    (DEVICE && a32_load(a32_at(H, H_ERROR_CODE)) != 0)
#define err_spun(H, n) ((++*(n) & 4095) == 0 && err_seen(H))

#ifdef __METAL_VERSION__
INLINE f32 atan2_c99(f32 y, f32 x) {
  return y == 0.0f && x == x
    ? copysign(signbit(x) ? M_PI_F : 0.0f, y) : atan2(y, x);
}
#define sqrt  precise::sqrt
#define exp   precise::exp
#define log   precise::log
#define log2  precise::log2
#define log10 precise::log10
#define sin   fast::sin
#define cos   fast::cos
#define tan   fast::tan
#define pow   precise::pow
#define fmod  precise::fmod
#define atan2 atan2_c99
#define U32_QUO(a, b) \
  ((a) / 2 / (b) * 2 + ((a) - (a) / 2 / (b) * 2 * (b) >= (b)))
#else
#define U32_QUO(a, b) ((a) / (b))
#endif

#define U32_BIN(a, o, b) ((u64)((u32)(a) o (u32)(b)))

INLINE f32 f32_unbox(u64 x) {
  union { u32 u; f32 f; } p = { (u32)x };
  return p.f;
}

INLINE u64 f32_rewrap(f32 x) {
  union { f32 f; u32 u; } p = { x };
  return p.u;
}

INLINE u64 f32_to_u32(u64 a) {
  f32 v = f32_unbox(a);
  return v >= 0.0f && v < 4294967296.0f ? (u32)v : 0;
}

INLINE u64 nat_chk(Env e, u64 n) {
  if (n > NAT_IMM) {
    err_post(e.mem, ERR_NATS);
    return NAT_IMM;
  }
  return n;
}

INLINE u64 nat_mul(Env e, u64 a, u64 b) {
  return nat_chk(e, b != 0 && a > NAT_IMM / b ? NAT_IMM + 1 : a * b);
}

#if DEVICE

#define f32_show(e, x) (err_post(e.mem, ERR_FIDS), 0)
#define f32_read(e, s) (err_post(e.mem, ERR_FIDS), 0)

#else

static Term f32_show(Env e, Term x);
static Term f32_read(Env e, Term s);

#endif

A32_LOOP(fadd, f32_rewrap(f32_unbox(o) + f32_unbox(v)))

// Bank
// ====

// A stack of exact generations per class. The host pops and pushes at rd;
// a device pass pops below rd and pushes above top, compacted after it.

#define bank_at(H, c) ((DEV Bank*)((H) + H_BANK) + (c))

INLINE u64 bank_pop(DEV u64* H, u32 c) {
  DEV Bank* b = bank_at(H, c);
  u64 got = 0;
  LOCK(bank_lock);
  u32 t = a32_sub(&b->rd, 1);
  if ((int)t > 0) {
    got = H[b->off + t - 1];
  } else {
    a32_add(&b->rd, 1);
  }
  if (!DEVICE) {
    b->wr = b->top = b->rd;
  }
  UNLOCK(bank_lock);
  return got;
}

INLINE void bank_push(DEV u64* H, u32 c, u64 head) {
  DEV Bank* b = bank_at(H, c);
  LOCK(bank_lock);
  H[b->off + a32_add(&b->wr, 1)] = head;
  if (!DEVICE) {
    b->rd = b->top = b->wr;
  }
  UNLOCK(bank_lock);
}

// Heap
// ====

// Per lane and class: HOT, a LIFO free chain; LEN, its length in words;
// on the host COLD, one parked generation. A host free reaching KEEP_WORDS
// parks HOT as COLD and banks the old COLD. A miss takes COLD, a bank entry
// or a fresh quantum. A device lane banks its complete generations at the
// kernel end (dev_cut). The bump grows only when all of these are empty.

#define ALC_AT(e, i)   (e).alc[(i) * LANE_STEP]
#define ALC_LEN(e, c)  ALC_AT(e, NCLS_ALL + (c))
#define ALC_COLD(e, c) ALC_AT(e, 2 * NCLS_ALL + (c))
#define KEEP(c)        (KEEP_WORDS >> (c) ? KEEP_WORDS >> (c) : 1)

INLINE u32 cls_fit(u32 words) {
  return words > 1 ? 32 - CLZ(words - 1) : 0;
}

OUTLINE void heap_hand(Env e, u32 cls) {
  u64 cold = ALC_COLD(e, cls);
  if (cold) {
    bank_push(e.mem, cls, cold);
  }
  ALC_COLD(e, cls) = ALC_AT(e, cls);
  ALC_AT(e, cls)   = 0;
  ALC_LEN(e, cls)  = 0;
}

#if DEVICE
#define corpus_grow(H, n) false
#else
static bool corpus_grow(u64* H, u64 need);
#endif

OUTLINE u64 heap_alloc_miss(Env e, u32 cls) {
  DEV u64* H = e.mem;
  u64  got = 0;
  if (!DEVICE) {
    got = ALC_COLD(e, cls);
    ALC_COLD(e, cls) = 0;
  }
  if (!got) {
    got = bank_pop(H, cls);
  }
  u32 n = got ? KEEP(cls) : cls < NCLS ? QUANTUM >> cls : 1;
  if (!got) {
    u32 pages = (n << cls) >> PAGE_BITS;
    u32 p     = a32_add(a32_at(H, H_BUMP), pages);
    if ((u64)p + pages > a32_load_acq(a32_at(H, H_CAP))
      && !corpus_grow(H, (u64)p + pages)) {
      err_post(H, ERR_HEAP);
      return HEAP_OFF;
    }
    got = HEAP_OFF + ((u64)p << PAGE_BITS);
    for (u32 i = 1; i <= n; i += 1) {
      H[got + ((u64)(i - 1) << cls)] = i < n ? got + ((u64)i << cls) : 0;
    }
  }
  ALC_AT(e, cls)  = H[got];
  ALC_LEN(e, cls) = (u64)(n - 1) << cls;
  return got;
}

INLINE u64 heap_alloc(Env e, u32 cls) {
  u64 h = ALC_AT(e, cls);
  if (h) {
    ALC_AT(e, cls)   = e.mem[h];
    ALC_LEN(e, cls) -= 1ull << cls;
    return h;
  }
  return heap_alloc_miss(e, cls);
}

INLINE void heap_free(Env e, u32 cls, u64 loc) {
  if (err_seen(e.mem)) {
    return;
  }
  e.mem[loc]       = ALC_AT(e, cls);
  ALC_AT(e, cls)   = loc;
  ALC_LEN(e, cls) += 1ull << cls;
  if (!DEVICE && ALC_LEN(e, cls) >= KEEP_WORDS) {
    heap_hand(e, cls);
  }
}

INLINE void spare_free(Env e, u32 cls, u64 loc) {
  if (loc >= HEAP_OFF) {
    heap_free(e, cls, loc);
  }
}

// Term
// ====

#define term_make(tag, aux, loc) \
  (((u64)(tag) << 56) | ((u64)(aux) << 40) | (u64)(loc))

#define term_ctr(cid, loc) term_make(TAG_CTR, cid, loc)
#define term_pak(cid, loc) term_make(TAG_PAK, cid, loc)
#define term_clo(fid, loc) term_make(TAG_CLO, fid, loc)
#define term_buf(cls, loc) term_make(TAG_BUF, cls, loc)
#define term_tsk(fid, loc) term_make(TAG_TSK, fid, loc)

INLINE Term term_blk(bool arr, u32 cls, u64 loc) {
  return term_buf(cls, loc) | ((u64)arr << 57);
}

INLINE u64 term_tag(Term t) {
  return (t >> 56) & 0x7f;
}

INLINE bool term_rfc(Term t) {
  return (t & RFC_BIT) != 0;
}

INLINE u64 term_aux(Term t) {
  return (t >> 40) & 0xFFFF;
}

INLINE u64 term_loc(Term t) {
  return t & LOC_MASK;
}

INLINE bool term_triv(Term t) {
  return term_tag(t) <= TAG_PAK || t == TERM_HOLE || term_loc(t) < HEAP_OFF;
}

OUTLINE Term rfc_wrap(Env e, Term t, u32 cnt) {
  if (term_tag(t) == TAG_CLO || term_tag(t) == TAG_TSK) {
    err_post(e.mem, ERR_RFCS);
    return t;
  }
  u64 r = heap_alloc(e, 0);
  e.mem[r] = ((u64)term_loc(t) << 24) | cnt;
  return (t & ~LOC_MASK) | RFC_BIT | r;
}

INLINE Term rfc_seal(Env e, Term t) {
  if (term_tag(t) != TAG_CTR || term_rfc(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1);
}

// A redirect cell holds its target's loc over a 24-bit count, which
// changes by atomic adds on the low half, so a host never reads it as one
// plain word.
INLINE u64 rfc_view(DEV u64* H, u64 r) {
  DEV u32* w = a32_at(H, r);
  u64 cell = ((u64)a32_load(w + 1) << 32) | a32_load(w);
  if ((cell & RFC_CNT) == 1) {
    a32_acq(w);
  }
  return cell;
}

INLINE void rfc_bump(Env e, u64 r, u32 k) {
  u32 c = a32_add(a32_at(e.mem, r), k);
  if ((c & RFC_CNT) >= RFC_CNT - k) {
    err_post(e.mem, ERR_RFCS);
  }
}

INLINE Term term_keep(Env e, Term t, u32 k) {
  if (term_rfc(t)) {
    rfc_bump(e, term_loc(t), k);
    return t;
  }
  if (term_triv(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1 + k);
}

INLINE u64 term_peek(DEV u64* H, Term t) {
  if (term_rfc(t)) {
    return rfc_view(H, term_loc(t)) >> 24;
  }
  return term_loc(t);
}

#define blk_shr(t) (BLK_SHR && term_rfc(t))

INLINE u64 blk_loc(DEV u64* H, Term a) {
  return blk_shr(a) ? w64_load(&H[term_loc(a)]) >> 24 : term_loc(a);
}

INLINE u32 blk_cls(Term t) {
  return (u32)term_aux(t) & 31;
}

#define buf_wcls(c) ((c) == 0 ? 0 : (c) - 1)

INLINE u32 blk_span(Term t) {
  u32 c = blk_cls(t);
  return term_tag(t) == TAG_ARR ? c : buf_wcls(c);
}

FAR void term_drop(Env e, Term t) {
  DEV u64* H = e.mem;
  u64  cur = 0;
  Term c0  = 0;
  u32  step = 0;
  for (;;) {
    if (!term_triv(t) && term_rfc(t)) {
      u64      r = term_loc(t);
      DEV u32* p = a32_at(H, r);
      if ((a32_sub_rel(p, 1) & RFC_CNT) != 1) {
        t = 0;
      } else {
        a32_acq(p);
        t = (t & ~(RFC_BIT | LOC_MASK)) | (H[r] >> 24);
        heap_free(e, 0, r);
      }
    }
    if (!term_triv(t)) {
      u64 tag = term_tag(t);
      if (tag == TAG_BUF) {
        heap_free(e, blk_span(t), term_loc(t));
      } else {
        u32 aux = (u32)term_aux(t);
        u64 loc = term_loc(t);
        u32 n   = tag == TAG_ARR ? 0 : tag == TAG_CTR ? cid_arity(aux)
          : fid_arity(aux) - (tag == TAG_CLO);
        u32 cls = tag == TAG_ARR ? 64 | blk_cls(t)
          : n > 247 ? 64 | (n - 240)
          : cls_fit(tag == TAG_TSK ? n + 2 : n);
        c0 = H[loc];
        H[loc] = cur;
        cur = loc | ((u64)n << 48) | ((u64)cls << 56);
      }
    }
    for (;;) {
      if (err_spun(H, &step) || cur == 0) {
        return;
      }
      u64  loc = cur & LOC_MASK;
      u32  i   = (u8)(cur >> 40);
      u32  n   = (u8)(cur >> 48);
      u32  cls = (u32)(cur >> 56);
      bool arr = cls > 63;
      u32  j   = i;
      if (arr) {
        cls &= 63;
        n   = 1u << cls;
        if (i == 2) {
          j = (u32)H[loc + 1];
        }
      }
      if (j < n) {
        Term c = j == 0 ? c0 : H[loc + j];
        if (arr && j > 0) {
          H[loc + 1] = j + 1;
        }
        if (!arr || i < 2) {
          cur += 1ull << 40;
        }
        if (!term_triv(c)) {
          t = c;
          break;
        }
      } else {
        u64 up = H[loc];
        heap_free(e, cls, loc);
        cur = up;
      }
    }
  }
}

INLINE void term_sink(Env e, Term t) {
  if (!term_triv(t)) {
    term_drop(e, t);
  }
}

OUTLINE void span_fade(Env e, Term t, u64 src, u32 n) {
  for (u32 j = 0; j < n; j += 1) {
    Term f = e.mem[src + j];
    if (term_rfc(f)) {
      rfc_bump(e, term_loc(f), 1);
    } else if (!term_triv(f)) {
      err_post(e.mem, ERR_RFCS);
    }
  }
  term_drop(e, t);
}

INLINE u64 ctr_take(Env e, Term t, u32 n, THR Term* out) {
  DEV u64* H = e.mem;
  if (!term_rfc(t)) {
    for (u32 j = 0; j < n; j += 1) {
      out[j] = H[term_loc(t) + j];
    }
    return term_loc(t);
  }
  u64 r    = term_loc(t);
  u64 cell = rfc_view(H, r);
  u64 src  = cell >> 24;
  for (u32 j = 0; j < n; j += 1) {
    out[j] = H[src + j];
  }
  if ((cell & RFC_CNT) == 1) {
    heap_free(e, 0, r);
    return src;
  }
  span_fade(e, t, src, n);
  return 0;
}

INLINE Term term_word(Env e, Term w) {
  u32 x = 0;
  Term t = w;
  for (u32 i = 0; i < 32 && term_aux(t) == CID_WCON; i += 1) {
    u64 l = term_peek(e.mem, t);
    x |= (u32)(e.mem[l] & 1) << i;
    t = e.mem[l + 1];
  }
  term_sink(e, w);
  return x;
}

// Blk
// ===

// A block owns one allocation in its class (an ARR 2^c Terms, a BUF 2^c
// u32). Matching ANode is blk_half twice (the high call frees the source);
// ANode{l, r} is blk_node; Array.clone is blk_copy.

#define BLK_ALLOC(n, w) \
  u64 n = heap_alloc(e, w); \
  if (err_seen(e.mem)) { \
    return term_buf(0, n); \
  }

INLINE DEV u32a* blk_ptr(DEV u64* H, u64 loc, u32 i) {
  return (DEV u32a*)(H + loc) + i;
}

INLINE Term blk_read(DEV u64* H, bool arr, u64 loc, u32 i) {
  if (arr) {
    return H[loc + i];
  }
  return (u64)*blk_ptr(H, loc, i);
}

INLINE void blk_write(DEV u64* H, bool arr, u64 loc, u32 i, Term v) {
  if (arr) {
    H[loc + i] = v;
  } else {
    *blk_ptr(H, loc, i) = (u32)v;
  }
}

INLINE u32 blk_at(Term a, u64 i, u32 lgs) {
  return ((u32)i & (u32)((1ull << (blk_cls(a) - lgs)) - 1)) << lgs;
}

INLINE Term blk_keep(Env e, u64 at) {
  Term w = e.mem[at];
  Term v = term_keep(e, w, 1);
  if (v != w) {
    e.mem[at] = v;
  }
  return v;
}

INLINE void blk_fill(Env e, u64 dst, u64 src, u64 n, bool keep) {
  for (u64 j = 0; j < n; j += 1) {
    e.mem[dst + j] = keep ? blk_keep(e, src + j) : e.mem[src + j];
  }
}

INLINE void blk_free(Env e, Term t) {
  blk_shr(t) ? term_drop(e, t) : heap_free(e, blk_span(t), term_loc(t));
}

OUTLINE Term blk_copy(Env e, Term a) {
  bool arr = term_tag(a) == TAG_ARR;
  u32 cls = blk_span(a);
  BLK_ALLOC(dst, cls)
  blk_fill(e, dst, blk_loc(e.mem, a), 1ull << cls, arr);
  return term_blk(arr, blk_cls(a), dst);
}

INLINE Term blk_node(Env e, Term l, Term r) {
  DEV u64* H = e.mem;
  bool arr = term_tag(l) == TAG_ARR;
  u32 c = blk_cls(l);
  if (c != blk_cls(r) || c + 1 >= NCLS_ALL) {
    err_post(H, ERR_TAGS);
    return l;
  }
  u64 pl = blk_loc(H, l);
  u64 pr = blk_loc(H, r);
  BLK_ALLOC(n, arr ? c + 1 : c)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, pl, 0) | ((u64)*blk_ptr(H, pr, 0) << 32);
  } else {
    u64 cw = 1ull << blk_span(l);
    blk_fill(e, n, pl, cw, arr && blk_shr(l));
    blk_fill(e, n + cw, pr, cw, arr && blk_shr(r));
  }
  blk_free(e, l);
  blk_free(e, r);
  return term_blk(arr, c + 1, n);
}

INLINE Term blk_half(Env e, Term a, u32 hi) {
  DEV u64* H = e.mem;
  bool arr = term_tag(a) == TAG_ARR;
  u32 c = blk_cls(a);
  if (c == 0) {
    err_post(H, ERR_TAGS);
    return a;
  }
  c -= 1;
  u32 cw = arr ? c : buf_wcls(c);
  u64 src = blk_loc(H, a);
  BLK_ALLOC(n, cw)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, src, hi);
  } else {
    blk_fill(e, n, src + ((u64)hi << cw), 1ull << cw, arr && blk_shr(a));
  }
  if (hi) {
    blk_free(e, a);
  }
  return term_blk(arr, c, n);
}

INLINE Term blk_new(Env e, bool arr, u64 d, u32 lgs, u32 n, THR Term* v) {
  DEV u64* H = e.mem;
  if (d + lgs > 31) {
    err_post(H, ERR_ARRS);
    d = 0;
  }
  u32 c = (u32)d + lgs;
  BLK_ALLOC(l, arr ? c : buf_wcls(c))
  for (u32 j = 0; arr && d > 0 && j < n; j += 1) {
    if (d >= 24 && !term_triv(v[j])) {
      err_post(H, ERR_RFCS);
    }
    v[j] = term_keep(e, v[j], (1u << d) - 1);
  }
  for (u64 i = 0; i < (1ull << c); i += 1) {
    blk_write(H, arr, l, (u32)i, i % (1u << lgs) < n ? v[i % (1u << lgs)] : 0);
  }
  return term_blk(arr, c, l);
}

// Ring
// ====

#define ring_word(H, r, w) ((H) + RING_OFF + (w) * LANES + (r))
#define ring_slot(H, r, p) ring_word(H, r, (p) & (RING_LEN - 1))
#define ring_get(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN))
#define ring_put(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN + 1))

INLINE u32 ring_lap(u32 pos) {
  return ~(u32)(pos / RING_LEN) & 1;
}

INLINE void ring_push(DEV u64* H, u32 r, Term tsk) {
  u32 pos = a32_add(ring_put(H, r), 1);
  if (pos - a32_load(ring_get(H, r)) >= RING_LEN) {
    err_post(H, ERR_RING);
    return;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, r, pos);
  a32_store(lo, (u32)tsk);
  a32_store_rel(lo + 1, (u32)(tsk >> 32) | (ring_lap(pos) << 31));
}

INLINE u32 ring_flip(u32 i) {
  return (i % CUBE_T << CUBE_LOG) + i / CUBE_T;
}

#define ring_pick(b, s, c) ((b) + (s) * (a32_add(c, 1) & (CUBE_T - 1)))

// Task
// ====

INLINE u64 task_node(Env e, u32 fid, Term cont, u32 idx, u32 rem) {
  u32 ar  = fid_arity(fid);
  u64 loc = heap_alloc(e, cls_fit(ar + 2));
  for (u32 i = 0; rem && i < ar; i += 1) {
    e.mem[loc + i] = TERM_HOLE;
  }
  e.mem[loc + ar]     = cont;
  e.mem[loc + ar + 1] = ((u64)idx << 32) | rem;
  return loc;
}

INLINE u64 task_tail(Term t) {
  return term_loc(t) + fid_arity((u32)term_aux(t));
}

INLINE Term task_deliver(DEV u64* H, Term cont, u32 idx, THR Term* v, u32 n) {
  u64 at = cont == TERM_HOLE ? H_ROOT_WORD : term_loc(cont) + idx;
  for (u32 j = 0; j < WL_RESW; j += 1) {
    if (j < n) {
      H[at + j] = v[j];
    }
  }
  if (cont == TERM_HOLE) {
    a32_store_rel(a32_at(H, H_ROOT_DONE), n + 1);
    return 0;
  }
  u64 tl = task_tail(cont);
  if (a32_sub_rel(a32_at(H, tl + 1), 1) == 1) {
    a32_acq(a32_at(H, tl + 1));
    return cont;
  }
  return 0;
}

INLINE void task_deal(DEV u64* H, Term join, u32 base, u32 stride, TG u32* cur) {
  u64 loc = term_loc(join);
  u32 ar  = fid_arity((u32)term_aux(join));
  u32 g   = 0;
  if (stride == 0) {
    u32 rem = (u32)H[loc + ar + 1];
    g = a32_add(a32_at(H, H_CURSOR), rem);
  }
  for (u32 i = 0; i < ar; i += 1) {
    Term k = H[loc + i];
    if (term_tag(k) == TAG_TSK) {
      H[loc + i] = TERM_HOLE;
      u32 to;
      if (stride != 0) {
        to = ring_pick(base, stride, cur);
      } else {
        to = ring_flip(g & (u32)(LANES - 1));
        g += 1;
      }
      ring_push(H, to, k);
    }
  }
}

// Root
// ====

INLINE bool root_done(DEV u64* H) {
  return a32_load_acq(a32_at(H, H_ROOT_DONE)) != 0;
}

static u32 root_take(DEV u64* H, THR Term* v) {
  u32 n = a32_load_acq(a32_at(H, H_ROOT_DONE)) - 1;
  for (u32 j = 0; j < n; j += 1) {
    v[j] = H[H_ROOT_WORD + j];
  }
  a32_store(a32_at(H, H_ROOT_DONE), 0);
  return n;
}

// Spins
// =====

CONSTV u64 STAT_IMG[] = { 48ull, term_pak(CID_SNIL, 0), 93ull, term_pak(CID_SNIL, 0), 32ull, term_pak(CID_SNIL, 0), 44ull, term_ctr(CID_SCON, STAT_OFF + 4), 91ull, term_ctr(CID_SCON, STAT_OFF + 2), 91ull, term_pak(CID_SNIL, 0), 124ull, term_pak(CID_SNIL, 0), 1ull, term_pak(CID_NIL, 0), 3ull, term_pak(CID_NIL, 0), 2ull, term_ctr(CID_CON, STAT_OFF + 16), 1ull, term_ctr(CID_CON, STAT_OFF + 18), 0ull, term_pak(CID_NIL, 0), 7ull, term_ctr(CID_CON, STAT_OFF + 22), 7ull, term_ctr(CID_CON, STAT_OFF + 24), 9ull, term_pak(CID_NIL, 0), 0ull, term_ctr(CID_CON, STAT_OFF + 28), 10ull, term_pak(CID_SNIL, 0) };

INLINE Term spin_2(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  Term _v_4 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_4 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_2);
    }
  break;
  }
  o[0] = _v_4;
  return 1;
}

INLINE Term spin_1(Env e, THR Term* o, Term r0) {
  u32 wpoll = 0;
  Term _v_2 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_3 = 0;
    Term _o_0[1];
    if (spin_2(e, _o_0, _xs_0, term_pak(CID_NIL, 0)) == 0) {
      return 0;
    }
    _v_3 = _o_0[0];
    _v_2 = _v_3;
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_3(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  Term _v_6 = 0;
  Term _reversed_0 = r0;
  Term _output_0 = r1;
  WL_SPIN
    if (term_aux(_reversed_0) == CID_NIL) {
      _v_6 = _output_0;
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _reversed_0, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      u64 _nd_1 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _f_2);
      e.mem[_nd_1 + 1] = rfc_seal(e, _output_0);
      r0 = _f_3;
      r1 = term_ctr(CID_CON, _nd_1);
      _reversed_0 = r0;
      _output_0 = r1;
      WL_AGAIN(spin_3);
    }
  break;
  }
  o[0] = _v_6;
  return 1;
}

INLINE Term spin_4(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  Term _v_2 = 0;
  Term _left_1 = r0;
  Term _right_1 = r1;
  WL_SPIN
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _o_0[1];
    if (spin_1(e, _o_0, _left_1) == 0) {
      return 0;
    }
    _v_4 = _o_0[0];
    _v_3 = _v_4;
    Term _v_5 = 0;
    Term _o_1[1];
    if (spin_3(e, _o_1, _v_3, _right_1) == 0) {
      return 0;
    }
    _v_5 = _o_1[0];
    _v_2 = _v_5;
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_5(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  Term _v_8 = 0;
  Term _left_3 = r0;
  Term _right_3 = r1;
  WL_SPIN
    if (term_aux(_left_3) == CID_NIL) {
      if (term_aux(_right_3) == CID_NIL) {
        _v_8 = term_pak(CID_NIL, 0);
      } else {
        _v_8 = _right_3;
      }
    } else {
      if (term_aux(_right_3) == CID_NIL) {
        _v_8 = _left_3;
      } else {
        Term _v_9 = 0;
        Term _v_10 = 0;
        Term _o_3[1];
        if (spin_1(e, _o_3, _left_3) == 0) {
          return 0;
        }
        _v_10 = _o_3[0];
        _v_9 = _v_10;
        Term _v_11 = 0;
        Term _o_4[1];
        if (spin_3(e, _o_4, _v_9, _right_3) == 0) {
          return 0;
        }
        _v_11 = _o_4[0];
        _v_8 = _v_11;
      }
    }
  break;
  }
  o[0] = _v_8;
  return 1;
}

// Work
// ====

// A host self-jump is a tail call: as a loop, clang hoisted constants into
// symreg's entry (3.05 s against 2.51 s).
#if !DEVICE
#undef  WL_SPIN
#undef  WL_SPUN
#undef  WL_AGAIN
#define WL_SPIN
#define WL_SPUN
#define WL_AGAIN(F) __attribute__((musttail)) return WL_##F(WL_ALL)

typedef Term (PRESERVE(preserve_none) *WlFn)(WL_SIG);
#define WL_X(F) WL_FN WL_##F(WL_SIG);
WL_TABLE WL_X(FID_ENTER)
#undef WL_X
#define WL_X(F) WL_##F,
static const WlFn wl_tab[] = { WL_TABLE };
#undef WL_X
#endif

static Term work_loop(Env e, DEV Term* sp, Term t, u32 seq) {
  WL_BANK
  u32 rn = 0;
  r0 = t;
#if DEVICE
  u32 fid   = FID_ENTER;
  u32 wpoll = 0;
  for (;;) {
  if (err_spun(e.mem, &wpoll)) {
    return 0;
  }
  switch (fid) {
#else
  return WL_FID_ENTER(WL_ALL);
}
#endif

// Segments
// ========

// A task enters through its words: a continuation's results ride r0..
// and its parameters the stack; any other segment's parameters ride r0..

#if !DEVICE
  WL_CASE(FID_U32_SHOW_GO)
  {
    Term _f_0 = r0;
    u32 _n_0 = r1;
    Term _acc_0 = r2;
    WL_OPEN
    WL_SPIN
    if (_f_0 == 0) {
      r0 = _acc_0;
      WL_RETN(1);
    } else {
      Term _g_0 = (_f_0 - 1);
      u32 _s_0 = U32_BIN(_n_0, ==, 0);
      if (_s_0 == 1) {
        r0 = _acc_0;
        WL_RETN(1);
      } else {
        Term _a_0 = 10ull;
        Term _a_1 = 10ull;
        u64 _nd_0 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = U32_BIN(48ull, +, ((u32)(_a_1) == 0 ? _n_0 : U32_BIN(_n_0, -, U32_QUO((u32)(_n_0), (u32)(_a_1)) * _a_1)));
        e.mem[_nd_0 + 1] = _acc_0;
        r0 = _g_0;
        r1 = ((u32)(_a_0) == 0 ? 0 : (u64)U32_QUO((u32)(_n_0), (u32)(_a_0)));
        r2 = term_ctr(CID_SCON, _nd_0);
        _f_0 = r0;
        _n_0 = r1;
        _acc_0 = r2;
        WL_AGAIN(FID_U32_SHOW_GO);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_0)
  {
    Term _xs_0 = r0;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 2);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_LIST_SHOW_GO_0_K7;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_GO_0_K7, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_LIST_SHOW_GO_0_K7, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_0;
        return term_tsk(FID_U32_SHOW, _t_1);
      }
      r0 = _f_0;
      WL_JMP(FID_U32_SHOW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_0_K7)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_LIST_SHOW_GO_0_K8;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_LIST_SHOW_GO_0_K8, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_LIST_SHOW_GO_0_K8, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_GO_0)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_GO_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_2;
      return term_tsk(FID_LIST_SHOW_GO_0, _t_3);
    }
    r0 = _f_2;
    WL_JMP(FID_LIST_SHOW_GO_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_0_K8)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_GO_0_K9;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_LIST_SHOW_GO_0_K9, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_GO_0_K9, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_0_K9)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 6);
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 6);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW)
  {
    u32 _a_0 = r0;
    WL_OPEN
    u32 _s_0 = U32_BIN(_a_0, ==, 0);
    if (_s_0 == 1) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 0);
      WL_RETN(1);
    } else {
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW_GO)) {
        u64 _t_0 = task_node(e, FID_U32_SHOW_GO, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = 10ull;
        e.mem[_t_0 + 1] = _a_0;
        e.mem[_t_0 + 2] = term_pak(CID_SNIL, 0);
        return term_tsk(FID_U32_SHOW_GO, _t_0);
      }
      r0 = 10ull;
      r1 = _a_0;
      r2 = term_pak(CID_SNIL, 0);
      WL_JMP(FID_U32_SHOW_GO);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_0)
  {
    Term _xs_0 = r0;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 8);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_LIST_SHOW_0_K14;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_0_K14, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_LIST_SHOW_0_K14, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_0;
        return term_tsk(FID_U32_SHOW, _t_1);
      }
      r0 = _f_0;
      WL_JMP(FID_U32_SHOW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_0_K14)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_LIST_SHOW_0_K15;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_LIST_SHOW_0_K15, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_LIST_SHOW_0_K15, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_GO_0)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_GO_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_2;
      return term_tsk(FID_LIST_SHOW_GO_0, _t_3);
    }
    r0 = _f_2;
    WL_JMP(FID_LIST_SHOW_GO_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_0_K15)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_0_K16;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_LIST_SHOW_0_K16, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_0_K16, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_0_K16)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 10);
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 10);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVE)
  {
    Term _left_0 = r0;
    Term _right_0 = r1;
    WL_OPEN
    Term _v_0 = 0;
    _left_0 = term_keep(e, _left_0, 1);
    _right_0 = term_keep(e, _right_0, 1);
    Term _v_1 = 0;
    Term _o_2[1];
    if (spin_4(e, _o_2, _left_0, _right_0) == 0) {
      return 0;
    }
    _v_1 = _o_2[0];
    _v_0 = _v_1;
    if (seq) {
      WL_ROOM(3);
      STK(0) = _left_0;
      STK(1) = _right_0;
      STK(2) = FID_OBSERVE_K18;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID_OBSERVE_K18, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _left_0;
      e.mem[_t_0 + 1] = _right_0;
      WL_CONT = term_tsk(FID_OBSERVE_K18, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_0)) {
      u64 _t_1 = task_node(e, FID_LIST_SHOW_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _v_0;
      return term_tsk(FID_LIST_SHOW_0, _t_1);
    }
    r0 = _v_0;
    WL_JMP(FID_LIST_SHOW_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVE_K18)
  {
    WL_POPN(2);
    Term _left_2 = STK(0);
    Term _right_2 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _o_5[1];
    if (spin_5(e, _o_5, _left_2, _right_2) == 0) {
      return 0;
    }
    _v_7 = _o_5[0];
    _v_6 = _v_7;
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_OBSERVE_K19;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_OBSERVE_K19, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_OBSERVE_K19, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_0)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _v_6;
      return term_tsk(FID_LIST_SHOW_0, _t_3);
    }
    r0 = _v_6;
    WL_JMP(FID_LIST_SHOW_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVE_K19)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_2;
      STK(1) = FID_OBSERVE_K20;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_OBSERVE_K20, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      WL_CONT = term_tsk(FID_OBSERVE_K20, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 12);
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 12);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OBSERVE_K20)
  {
    WL_POPN(1);
    Term _h_4 = STK(0);
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _h_4;
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = _h_4;
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_a_0) == CID_SNIL) {
      r0 = _b_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _a_0, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_STRING_APPEND_K22;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_STRING_APPEND_K22, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_STRING_APPEND_K22, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _b_0;
      _a_0 = r0;
      _b_0 = r1;
      WL_AGAIN(FID_STRING_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND_K22)
  {
    WL_POPN(1);
    u32 _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _f_2;
    e.mem[_nd_0 + 1] = _h_0;
    r0 = term_ctr(CID_SCON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN)
  {
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K24;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_MAIN_K24, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K24, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_1 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = term_pak(CID_NIL, 0);
      e.mem[_t_1 + 1] = term_pak(CID_NIL, 0);
      return term_tsk(FID_OBSERVE, _t_1);
    }
    r0 = term_pak(CID_NIL, 0);
    r1 = term_pak(CID_NIL, 0);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K24)
  {
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_MAIN_K25;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_MAIN_K25, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_MAIN_K25, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_3 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_pak(CID_NIL, 0);
      e.mem[_t_3 + 1] = term_ctr(CID_CON, STAT_OFF + 14);
      return term_tsk(FID_OBSERVE, _t_3);
    }
    r0 = term_pak(CID_NIL, 0);
    r1 = term_ctr(CID_CON, STAT_OFF + 14);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K25)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_2;
      STK(1) = _h_1;
      STK(2) = FID_MAIN_K26;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_MAIN_K26, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      e.mem[_t_4 + 1] = _h_1;
      WL_CONT = term_tsk(FID_MAIN_K26, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_5 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_pak(CID_NIL, 0);
      e.mem[_t_5 + 1] = term_ctr(CID_CON, STAT_OFF + 20);
      return term_tsk(FID_OBSERVE, _t_5);
    }
    r0 = term_pak(CID_NIL, 0);
    r1 = term_ctr(CID_CON, STAT_OFF + 20);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K26)
  {
    WL_POPN(2);
    Term _h_4 = STK(0);
    Term _h_5 = STK(1);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_4;
      STK(1) = _h_5;
      STK(2) = _h_3;
      STK(3) = FID_MAIN_K27;
      WL_PUSHN(4);
    } else {
      u64 _t_6 = task_node(e, FID_MAIN_K27, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_4;
      e.mem[_t_6 + 1] = _h_5;
      e.mem[_t_6 + 2] = _h_3;
      WL_CONT = term_tsk(FID_MAIN_K27, _t_6);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_7 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_pak(CID_NIL, 0);
      e.mem[_t_7 + 1] = term_ctr(CID_CON, STAT_OFF + 26);
      return term_tsk(FID_OBSERVE, _t_7);
    }
    r0 = term_pak(CID_NIL, 0);
    r1 = term_ctr(CID_CON, STAT_OFF + 26);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K27)
  {
    WL_POPN(3);
    Term _h_7 = STK(0);
    Term _h_8 = STK(1);
    Term _h_9 = STK(2);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_7;
      STK(1) = _h_8;
      STK(2) = _h_9;
      STK(3) = _h_6;
      STK(4) = FID_MAIN_K28;
      WL_PUSHN(5);
    } else {
      u64 _t_8 = task_node(e, FID_MAIN_K28, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_7;
      e.mem[_t_8 + 1] = _h_8;
      e.mem[_t_8 + 2] = _h_9;
      e.mem[_t_8 + 3] = _h_6;
      WL_CONT = term_tsk(FID_MAIN_K28, _t_8);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_9 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = term_pak(CID_NIL, 0);
      e.mem[_t_9 + 1] = term_ctr(CID_CON, STAT_OFF + 30);
      return term_tsk(FID_OBSERVE, _t_9);
    }
    r0 = term_pak(CID_NIL, 0);
    r1 = term_ctr(CID_CON, STAT_OFF + 30);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K28)
  {
    WL_POPN(4);
    Term _h_11 = STK(0);
    Term _h_12 = STK(1);
    Term _h_13 = STK(2);
    Term _h_14 = STK(3);
    Term _h_10 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _h_11;
      STK(1) = _h_12;
      STK(2) = _h_13;
      STK(3) = _h_14;
      STK(4) = _h_10;
      STK(5) = FID_MAIN_K29;
      WL_PUSHN(6);
    } else {
      u64 _t_10 = task_node(e, FID_MAIN_K29, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_11;
      e.mem[_t_10 + 1] = _h_12;
      e.mem[_t_10 + 2] = _h_13;
      e.mem[_t_10 + 3] = _h_14;
      e.mem[_t_10 + 4] = _h_10;
      WL_CONT = term_tsk(FID_MAIN_K29, _t_10);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_11 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_CON, STAT_OFF + 14);
      e.mem[_t_11 + 1] = term_pak(CID_NIL, 0);
      return term_tsk(FID_OBSERVE, _t_11);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 14);
    r1 = term_pak(CID_NIL, 0);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K29)
  {
    WL_POPN(5);
    Term _h_16 = STK(0);
    Term _h_17 = STK(1);
    Term _h_18 = STK(2);
    Term _h_19 = STK(3);
    Term _h_20 = STK(4);
    Term _h_15 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _h_16;
      STK(1) = _h_17;
      STK(2) = _h_18;
      STK(3) = _h_19;
      STK(4) = _h_20;
      STK(5) = _h_15;
      STK(6) = FID_MAIN_K30;
      WL_PUSHN(7);
    } else {
      u64 _t_12 = task_node(e, FID_MAIN_K30, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _h_16;
      e.mem[_t_12 + 1] = _h_17;
      e.mem[_t_12 + 2] = _h_18;
      e.mem[_t_12 + 3] = _h_19;
      e.mem[_t_12 + 4] = _h_20;
      e.mem[_t_12 + 5] = _h_15;
      WL_CONT = term_tsk(FID_MAIN_K30, _t_12);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_13 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = term_ctr(CID_CON, STAT_OFF + 14);
      e.mem[_t_13 + 1] = term_ctr(CID_CON, STAT_OFF + 14);
      return term_tsk(FID_OBSERVE, _t_13);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 14);
    r1 = term_ctr(CID_CON, STAT_OFF + 14);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K30)
  {
    WL_POPN(6);
    Term _h_22 = STK(0);
    Term _h_23 = STK(1);
    Term _h_24 = STK(2);
    Term _h_25 = STK(3);
    Term _h_26 = STK(4);
    Term _h_27 = STK(5);
    Term _h_21 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _h_22;
      STK(1) = _h_23;
      STK(2) = _h_24;
      STK(3) = _h_25;
      STK(4) = _h_26;
      STK(5) = _h_27;
      STK(6) = _h_21;
      STK(7) = FID_MAIN_K31;
      WL_PUSHN(8);
    } else {
      u64 _t_14 = task_node(e, FID_MAIN_K31, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _h_22;
      e.mem[_t_14 + 1] = _h_23;
      e.mem[_t_14 + 2] = _h_24;
      e.mem[_t_14 + 3] = _h_25;
      e.mem[_t_14 + 4] = _h_26;
      e.mem[_t_14 + 5] = _h_27;
      e.mem[_t_14 + 6] = _h_21;
      WL_CONT = term_tsk(FID_MAIN_K31, _t_14);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_15 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = term_ctr(CID_CON, STAT_OFF + 14);
      e.mem[_t_15 + 1] = term_ctr(CID_CON, STAT_OFF + 20);
      return term_tsk(FID_OBSERVE, _t_15);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 14);
    r1 = term_ctr(CID_CON, STAT_OFF + 20);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K31)
  {
    WL_POPN(7);
    Term _h_29 = STK(0);
    Term _h_30 = STK(1);
    Term _h_31 = STK(2);
    Term _h_32 = STK(3);
    Term _h_33 = STK(4);
    Term _h_34 = STK(5);
    Term _h_35 = STK(6);
    Term _h_28 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(9);
      STK(0) = _h_29;
      STK(1) = _h_30;
      STK(2) = _h_31;
      STK(3) = _h_32;
      STK(4) = _h_33;
      STK(5) = _h_34;
      STK(6) = _h_35;
      STK(7) = _h_28;
      STK(8) = FID_MAIN_K32;
      WL_PUSHN(9);
    } else {
      u64 _t_16 = task_node(e, FID_MAIN_K32, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _h_29;
      e.mem[_t_16 + 1] = _h_30;
      e.mem[_t_16 + 2] = _h_31;
      e.mem[_t_16 + 3] = _h_32;
      e.mem[_t_16 + 4] = _h_33;
      e.mem[_t_16 + 5] = _h_34;
      e.mem[_t_16 + 6] = _h_35;
      e.mem[_t_16 + 7] = _h_28;
      WL_CONT = term_tsk(FID_MAIN_K32, _t_16);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_17 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = term_ctr(CID_CON, STAT_OFF + 14);
      e.mem[_t_17 + 1] = term_ctr(CID_CON, STAT_OFF + 26);
      return term_tsk(FID_OBSERVE, _t_17);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 14);
    r1 = term_ctr(CID_CON, STAT_OFF + 26);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K32)
  {
    WL_POPN(8);
    Term _h_37 = STK(0);
    Term _h_38 = STK(1);
    Term _h_39 = STK(2);
    Term _h_40 = STK(3);
    Term _h_41 = STK(4);
    Term _h_42 = STK(5);
    Term _h_43 = STK(6);
    Term _h_44 = STK(7);
    Term _h_36 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _h_37;
      STK(1) = _h_38;
      STK(2) = _h_39;
      STK(3) = _h_40;
      STK(4) = _h_41;
      STK(5) = _h_42;
      STK(6) = _h_43;
      STK(7) = _h_44;
      STK(8) = _h_36;
      STK(9) = FID_MAIN_K33;
      WL_PUSHN(10);
    } else {
      u64 _t_18 = task_node(e, FID_MAIN_K33, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _h_37;
      e.mem[_t_18 + 1] = _h_38;
      e.mem[_t_18 + 2] = _h_39;
      e.mem[_t_18 + 3] = _h_40;
      e.mem[_t_18 + 4] = _h_41;
      e.mem[_t_18 + 5] = _h_42;
      e.mem[_t_18 + 6] = _h_43;
      e.mem[_t_18 + 7] = _h_44;
      e.mem[_t_18 + 8] = _h_36;
      WL_CONT = term_tsk(FID_MAIN_K33, _t_18);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_19 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = term_ctr(CID_CON, STAT_OFF + 14);
      e.mem[_t_19 + 1] = term_ctr(CID_CON, STAT_OFF + 30);
      return term_tsk(FID_OBSERVE, _t_19);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 14);
    r1 = term_ctr(CID_CON, STAT_OFF + 30);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K33)
  {
    WL_POPN(9);
    Term _h_46 = STK(0);
    Term _h_47 = STK(1);
    Term _h_48 = STK(2);
    Term _h_49 = STK(3);
    Term _h_50 = STK(4);
    Term _h_51 = STK(5);
    Term _h_52 = STK(6);
    Term _h_53 = STK(7);
    Term _h_54 = STK(8);
    Term _h_45 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _h_46;
      STK(1) = _h_47;
      STK(2) = _h_48;
      STK(3) = _h_49;
      STK(4) = _h_50;
      STK(5) = _h_51;
      STK(6) = _h_52;
      STK(7) = _h_53;
      STK(8) = _h_54;
      STK(9) = _h_45;
      STK(10) = FID_MAIN_K34;
      WL_PUSHN(11);
    } else {
      u64 _t_20 = task_node(e, FID_MAIN_K34, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _h_46;
      e.mem[_t_20 + 1] = _h_47;
      e.mem[_t_20 + 2] = _h_48;
      e.mem[_t_20 + 3] = _h_49;
      e.mem[_t_20 + 4] = _h_50;
      e.mem[_t_20 + 5] = _h_51;
      e.mem[_t_20 + 6] = _h_52;
      e.mem[_t_20 + 7] = _h_53;
      e.mem[_t_20 + 8] = _h_54;
      e.mem[_t_20 + 9] = _h_45;
      WL_CONT = term_tsk(FID_MAIN_K34, _t_20);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_21 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = term_ctr(CID_CON, STAT_OFF + 20);
      e.mem[_t_21 + 1] = term_pak(CID_NIL, 0);
      return term_tsk(FID_OBSERVE, _t_21);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 20);
    r1 = term_pak(CID_NIL, 0);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K34)
  {
    WL_POPN(10);
    Term _h_56 = STK(0);
    Term _h_57 = STK(1);
    Term _h_58 = STK(2);
    Term _h_59 = STK(3);
    Term _h_60 = STK(4);
    Term _h_61 = STK(5);
    Term _h_62 = STK(6);
    Term _h_63 = STK(7);
    Term _h_64 = STK(8);
    Term _h_65 = STK(9);
    Term _h_55 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _h_56;
      STK(1) = _h_57;
      STK(2) = _h_58;
      STK(3) = _h_59;
      STK(4) = _h_60;
      STK(5) = _h_61;
      STK(6) = _h_62;
      STK(7) = _h_63;
      STK(8) = _h_64;
      STK(9) = _h_65;
      STK(10) = _h_55;
      STK(11) = FID_MAIN_K35;
      WL_PUSHN(12);
    } else {
      u64 _t_22 = task_node(e, FID_MAIN_K35, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _h_56;
      e.mem[_t_22 + 1] = _h_57;
      e.mem[_t_22 + 2] = _h_58;
      e.mem[_t_22 + 3] = _h_59;
      e.mem[_t_22 + 4] = _h_60;
      e.mem[_t_22 + 5] = _h_61;
      e.mem[_t_22 + 6] = _h_62;
      e.mem[_t_22 + 7] = _h_63;
      e.mem[_t_22 + 8] = _h_64;
      e.mem[_t_22 + 9] = _h_65;
      e.mem[_t_22 + 10] = _h_55;
      WL_CONT = term_tsk(FID_MAIN_K35, _t_22);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_23 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = term_ctr(CID_CON, STAT_OFF + 20);
      e.mem[_t_23 + 1] = term_ctr(CID_CON, STAT_OFF + 14);
      return term_tsk(FID_OBSERVE, _t_23);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 20);
    r1 = term_ctr(CID_CON, STAT_OFF + 14);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K35)
  {
    WL_POPN(11);
    Term _h_67 = STK(0);
    Term _h_68 = STK(1);
    Term _h_69 = STK(2);
    Term _h_70 = STK(3);
    Term _h_71 = STK(4);
    Term _h_72 = STK(5);
    Term _h_73 = STK(6);
    Term _h_74 = STK(7);
    Term _h_75 = STK(8);
    Term _h_76 = STK(9);
    Term _h_77 = STK(10);
    Term _h_66 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _h_67;
      STK(1) = _h_68;
      STK(2) = _h_69;
      STK(3) = _h_70;
      STK(4) = _h_71;
      STK(5) = _h_72;
      STK(6) = _h_73;
      STK(7) = _h_74;
      STK(8) = _h_75;
      STK(9) = _h_76;
      STK(10) = _h_77;
      STK(11) = _h_66;
      STK(12) = FID_MAIN_K36;
      WL_PUSHN(13);
    } else {
      u64 _t_24 = task_node(e, FID_MAIN_K36, WL_CONT, WL_IDX, 1);
      e.mem[_t_24 + 0] = _h_67;
      e.mem[_t_24 + 1] = _h_68;
      e.mem[_t_24 + 2] = _h_69;
      e.mem[_t_24 + 3] = _h_70;
      e.mem[_t_24 + 4] = _h_71;
      e.mem[_t_24 + 5] = _h_72;
      e.mem[_t_24 + 6] = _h_73;
      e.mem[_t_24 + 7] = _h_74;
      e.mem[_t_24 + 8] = _h_75;
      e.mem[_t_24 + 9] = _h_76;
      e.mem[_t_24 + 10] = _h_77;
      e.mem[_t_24 + 11] = _h_66;
      WL_CONT = term_tsk(FID_MAIN_K36, _t_24);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_25 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = term_ctr(CID_CON, STAT_OFF + 20);
      e.mem[_t_25 + 1] = term_ctr(CID_CON, STAT_OFF + 20);
      return term_tsk(FID_OBSERVE, _t_25);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 20);
    r1 = term_ctr(CID_CON, STAT_OFF + 20);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K36)
  {
    WL_POPN(12);
    Term _h_79 = STK(0);
    Term _h_80 = STK(1);
    Term _h_81 = STK(2);
    Term _h_82 = STK(3);
    Term _h_83 = STK(4);
    Term _h_84 = STK(5);
    Term _h_85 = STK(6);
    Term _h_86 = STK(7);
    Term _h_87 = STK(8);
    Term _h_88 = STK(9);
    Term _h_89 = STK(10);
    Term _h_90 = STK(11);
    Term _h_78 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _h_79;
      STK(1) = _h_80;
      STK(2) = _h_81;
      STK(3) = _h_82;
      STK(4) = _h_83;
      STK(5) = _h_84;
      STK(6) = _h_85;
      STK(7) = _h_86;
      STK(8) = _h_87;
      STK(9) = _h_88;
      STK(10) = _h_89;
      STK(11) = _h_90;
      STK(12) = _h_78;
      STK(13) = FID_MAIN_K37;
      WL_PUSHN(14);
    } else {
      u64 _t_26 = task_node(e, FID_MAIN_K37, WL_CONT, WL_IDX, 1);
      e.mem[_t_26 + 0] = _h_79;
      e.mem[_t_26 + 1] = _h_80;
      e.mem[_t_26 + 2] = _h_81;
      e.mem[_t_26 + 3] = _h_82;
      e.mem[_t_26 + 4] = _h_83;
      e.mem[_t_26 + 5] = _h_84;
      e.mem[_t_26 + 6] = _h_85;
      e.mem[_t_26 + 7] = _h_86;
      e.mem[_t_26 + 8] = _h_87;
      e.mem[_t_26 + 9] = _h_88;
      e.mem[_t_26 + 10] = _h_89;
      e.mem[_t_26 + 11] = _h_90;
      e.mem[_t_26 + 12] = _h_78;
      WL_CONT = term_tsk(FID_MAIN_K37, _t_26);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_27 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_27 + 0] = term_ctr(CID_CON, STAT_OFF + 20);
      e.mem[_t_27 + 1] = term_ctr(CID_CON, STAT_OFF + 26);
      return term_tsk(FID_OBSERVE, _t_27);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 20);
    r1 = term_ctr(CID_CON, STAT_OFF + 26);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K37)
  {
    WL_POPN(13);
    Term _h_92 = STK(0);
    Term _h_93 = STK(1);
    Term _h_94 = STK(2);
    Term _h_95 = STK(3);
    Term _h_96 = STK(4);
    Term _h_97 = STK(5);
    Term _h_98 = STK(6);
    Term _h_99 = STK(7);
    Term _h_100 = STK(8);
    Term _h_101 = STK(9);
    Term _h_102 = STK(10);
    Term _h_103 = STK(11);
    Term _h_104 = STK(12);
    Term _h_91 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _h_92;
      STK(1) = _h_93;
      STK(2) = _h_94;
      STK(3) = _h_95;
      STK(4) = _h_96;
      STK(5) = _h_97;
      STK(6) = _h_98;
      STK(7) = _h_99;
      STK(8) = _h_100;
      STK(9) = _h_101;
      STK(10) = _h_102;
      STK(11) = _h_103;
      STK(12) = _h_104;
      STK(13) = _h_91;
      STK(14) = FID_MAIN_K38;
      WL_PUSHN(15);
    } else {
      u64 _t_28 = task_node(e, FID_MAIN_K38, WL_CONT, WL_IDX, 1);
      e.mem[_t_28 + 0] = _h_92;
      e.mem[_t_28 + 1] = _h_93;
      e.mem[_t_28 + 2] = _h_94;
      e.mem[_t_28 + 3] = _h_95;
      e.mem[_t_28 + 4] = _h_96;
      e.mem[_t_28 + 5] = _h_97;
      e.mem[_t_28 + 6] = _h_98;
      e.mem[_t_28 + 7] = _h_99;
      e.mem[_t_28 + 8] = _h_100;
      e.mem[_t_28 + 9] = _h_101;
      e.mem[_t_28 + 10] = _h_102;
      e.mem[_t_28 + 11] = _h_103;
      e.mem[_t_28 + 12] = _h_104;
      e.mem[_t_28 + 13] = _h_91;
      WL_CONT = term_tsk(FID_MAIN_K38, _t_28);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_29 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_29 + 0] = term_ctr(CID_CON, STAT_OFF + 20);
      e.mem[_t_29 + 1] = term_ctr(CID_CON, STAT_OFF + 30);
      return term_tsk(FID_OBSERVE, _t_29);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 20);
    r1 = term_ctr(CID_CON, STAT_OFF + 30);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K38)
  {
    WL_POPN(14);
    Term _h_106 = STK(0);
    Term _h_107 = STK(1);
    Term _h_108 = STK(2);
    Term _h_109 = STK(3);
    Term _h_110 = STK(4);
    Term _h_111 = STK(5);
    Term _h_112 = STK(6);
    Term _h_113 = STK(7);
    Term _h_114 = STK(8);
    Term _h_115 = STK(9);
    Term _h_116 = STK(10);
    Term _h_117 = STK(11);
    Term _h_118 = STK(12);
    Term _h_119 = STK(13);
    Term _h_105 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _h_106;
      STK(1) = _h_107;
      STK(2) = _h_108;
      STK(3) = _h_109;
      STK(4) = _h_110;
      STK(5) = _h_111;
      STK(6) = _h_112;
      STK(7) = _h_113;
      STK(8) = _h_114;
      STK(9) = _h_115;
      STK(10) = _h_116;
      STK(11) = _h_117;
      STK(12) = _h_118;
      STK(13) = _h_119;
      STK(14) = _h_105;
      STK(15) = FID_MAIN_K39;
      WL_PUSHN(16);
    } else {
      u64 _t_30 = task_node(e, FID_MAIN_K39, WL_CONT, WL_IDX, 1);
      e.mem[_t_30 + 0] = _h_106;
      e.mem[_t_30 + 1] = _h_107;
      e.mem[_t_30 + 2] = _h_108;
      e.mem[_t_30 + 3] = _h_109;
      e.mem[_t_30 + 4] = _h_110;
      e.mem[_t_30 + 5] = _h_111;
      e.mem[_t_30 + 6] = _h_112;
      e.mem[_t_30 + 7] = _h_113;
      e.mem[_t_30 + 8] = _h_114;
      e.mem[_t_30 + 9] = _h_115;
      e.mem[_t_30 + 10] = _h_116;
      e.mem[_t_30 + 11] = _h_117;
      e.mem[_t_30 + 12] = _h_118;
      e.mem[_t_30 + 13] = _h_119;
      e.mem[_t_30 + 14] = _h_105;
      WL_CONT = term_tsk(FID_MAIN_K39, _t_30);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_31 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_31 + 0] = term_ctr(CID_CON, STAT_OFF + 26);
      e.mem[_t_31 + 1] = term_pak(CID_NIL, 0);
      return term_tsk(FID_OBSERVE, _t_31);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 26);
    r1 = term_pak(CID_NIL, 0);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K39)
  {
    WL_POPN(15);
    Term _h_121 = STK(0);
    Term _h_122 = STK(1);
    Term _h_123 = STK(2);
    Term _h_124 = STK(3);
    Term _h_125 = STK(4);
    Term _h_126 = STK(5);
    Term _h_127 = STK(6);
    Term _h_128 = STK(7);
    Term _h_129 = STK(8);
    Term _h_130 = STK(9);
    Term _h_131 = STK(10);
    Term _h_132 = STK(11);
    Term _h_133 = STK(12);
    Term _h_134 = STK(13);
    Term _h_135 = STK(14);
    Term _h_120 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(17);
      STK(0) = _h_121;
      STK(1) = _h_122;
      STK(2) = _h_123;
      STK(3) = _h_124;
      STK(4) = _h_125;
      STK(5) = _h_126;
      STK(6) = _h_127;
      STK(7) = _h_128;
      STK(8) = _h_129;
      STK(9) = _h_130;
      STK(10) = _h_131;
      STK(11) = _h_132;
      STK(12) = _h_133;
      STK(13) = _h_134;
      STK(14) = _h_135;
      STK(15) = _h_120;
      STK(16) = FID_MAIN_K40;
      WL_PUSHN(17);
    } else {
      u64 _t_32 = task_node(e, FID_MAIN_K40, WL_CONT, WL_IDX, 1);
      e.mem[_t_32 + 0] = _h_121;
      e.mem[_t_32 + 1] = _h_122;
      e.mem[_t_32 + 2] = _h_123;
      e.mem[_t_32 + 3] = _h_124;
      e.mem[_t_32 + 4] = _h_125;
      e.mem[_t_32 + 5] = _h_126;
      e.mem[_t_32 + 6] = _h_127;
      e.mem[_t_32 + 7] = _h_128;
      e.mem[_t_32 + 8] = _h_129;
      e.mem[_t_32 + 9] = _h_130;
      e.mem[_t_32 + 10] = _h_131;
      e.mem[_t_32 + 11] = _h_132;
      e.mem[_t_32 + 12] = _h_133;
      e.mem[_t_32 + 13] = _h_134;
      e.mem[_t_32 + 14] = _h_135;
      e.mem[_t_32 + 15] = _h_120;
      WL_CONT = term_tsk(FID_MAIN_K40, _t_32);
      WL_IDX = 16;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_33 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_33 + 0] = term_ctr(CID_CON, STAT_OFF + 26);
      e.mem[_t_33 + 1] = term_ctr(CID_CON, STAT_OFF + 14);
      return term_tsk(FID_OBSERVE, _t_33);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 26);
    r1 = term_ctr(CID_CON, STAT_OFF + 14);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K40)
  {
    WL_POPN(16);
    Term _h_137 = STK(0);
    Term _h_138 = STK(1);
    Term _h_139 = STK(2);
    Term _h_140 = STK(3);
    Term _h_141 = STK(4);
    Term _h_142 = STK(5);
    Term _h_143 = STK(6);
    Term _h_144 = STK(7);
    Term _h_145 = STK(8);
    Term _h_146 = STK(9);
    Term _h_147 = STK(10);
    Term _h_148 = STK(11);
    Term _h_149 = STK(12);
    Term _h_150 = STK(13);
    Term _h_151 = STK(14);
    Term _h_152 = STK(15);
    Term _h_136 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(18);
      STK(0) = _h_137;
      STK(1) = _h_138;
      STK(2) = _h_139;
      STK(3) = _h_140;
      STK(4) = _h_141;
      STK(5) = _h_142;
      STK(6) = _h_143;
      STK(7) = _h_144;
      STK(8) = _h_145;
      STK(9) = _h_146;
      STK(10) = _h_147;
      STK(11) = _h_148;
      STK(12) = _h_149;
      STK(13) = _h_150;
      STK(14) = _h_151;
      STK(15) = _h_152;
      STK(16) = _h_136;
      STK(17) = FID_MAIN_K41;
      WL_PUSHN(18);
    } else {
      u64 _t_34 = task_node(e, FID_MAIN_K41, WL_CONT, WL_IDX, 1);
      e.mem[_t_34 + 0] = _h_137;
      e.mem[_t_34 + 1] = _h_138;
      e.mem[_t_34 + 2] = _h_139;
      e.mem[_t_34 + 3] = _h_140;
      e.mem[_t_34 + 4] = _h_141;
      e.mem[_t_34 + 5] = _h_142;
      e.mem[_t_34 + 6] = _h_143;
      e.mem[_t_34 + 7] = _h_144;
      e.mem[_t_34 + 8] = _h_145;
      e.mem[_t_34 + 9] = _h_146;
      e.mem[_t_34 + 10] = _h_147;
      e.mem[_t_34 + 11] = _h_148;
      e.mem[_t_34 + 12] = _h_149;
      e.mem[_t_34 + 13] = _h_150;
      e.mem[_t_34 + 14] = _h_151;
      e.mem[_t_34 + 15] = _h_152;
      e.mem[_t_34 + 16] = _h_136;
      WL_CONT = term_tsk(FID_MAIN_K41, _t_34);
      WL_IDX = 17;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_35 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_35 + 0] = term_ctr(CID_CON, STAT_OFF + 26);
      e.mem[_t_35 + 1] = term_ctr(CID_CON, STAT_OFF + 20);
      return term_tsk(FID_OBSERVE, _t_35);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 26);
    r1 = term_ctr(CID_CON, STAT_OFF + 20);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K41)
  {
    WL_POPN(17);
    Term _h_154 = STK(0);
    Term _h_155 = STK(1);
    Term _h_156 = STK(2);
    Term _h_157 = STK(3);
    Term _h_158 = STK(4);
    Term _h_159 = STK(5);
    Term _h_160 = STK(6);
    Term _h_161 = STK(7);
    Term _h_162 = STK(8);
    Term _h_163 = STK(9);
    Term _h_164 = STK(10);
    Term _h_165 = STK(11);
    Term _h_166 = STK(12);
    Term _h_167 = STK(13);
    Term _h_168 = STK(14);
    Term _h_169 = STK(15);
    Term _h_170 = STK(16);
    Term _h_153 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(19);
      STK(0) = _h_154;
      STK(1) = _h_155;
      STK(2) = _h_156;
      STK(3) = _h_157;
      STK(4) = _h_158;
      STK(5) = _h_159;
      STK(6) = _h_160;
      STK(7) = _h_161;
      STK(8) = _h_162;
      STK(9) = _h_163;
      STK(10) = _h_164;
      STK(11) = _h_165;
      STK(12) = _h_166;
      STK(13) = _h_167;
      STK(14) = _h_168;
      STK(15) = _h_169;
      STK(16) = _h_170;
      STK(17) = _h_153;
      STK(18) = FID_MAIN_K42;
      WL_PUSHN(19);
    } else {
      u64 _t_36 = task_node(e, FID_MAIN_K42, WL_CONT, WL_IDX, 1);
      e.mem[_t_36 + 0] = _h_154;
      e.mem[_t_36 + 1] = _h_155;
      e.mem[_t_36 + 2] = _h_156;
      e.mem[_t_36 + 3] = _h_157;
      e.mem[_t_36 + 4] = _h_158;
      e.mem[_t_36 + 5] = _h_159;
      e.mem[_t_36 + 6] = _h_160;
      e.mem[_t_36 + 7] = _h_161;
      e.mem[_t_36 + 8] = _h_162;
      e.mem[_t_36 + 9] = _h_163;
      e.mem[_t_36 + 10] = _h_164;
      e.mem[_t_36 + 11] = _h_165;
      e.mem[_t_36 + 12] = _h_166;
      e.mem[_t_36 + 13] = _h_167;
      e.mem[_t_36 + 14] = _h_168;
      e.mem[_t_36 + 15] = _h_169;
      e.mem[_t_36 + 16] = _h_170;
      e.mem[_t_36 + 17] = _h_153;
      WL_CONT = term_tsk(FID_MAIN_K42, _t_36);
      WL_IDX = 18;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_37 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_37 + 0] = term_ctr(CID_CON, STAT_OFF + 26);
      e.mem[_t_37 + 1] = term_ctr(CID_CON, STAT_OFF + 26);
      return term_tsk(FID_OBSERVE, _t_37);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 26);
    r1 = term_ctr(CID_CON, STAT_OFF + 26);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K42)
  {
    WL_POPN(18);
    Term _h_172 = STK(0);
    Term _h_173 = STK(1);
    Term _h_174 = STK(2);
    Term _h_175 = STK(3);
    Term _h_176 = STK(4);
    Term _h_177 = STK(5);
    Term _h_178 = STK(6);
    Term _h_179 = STK(7);
    Term _h_180 = STK(8);
    Term _h_181 = STK(9);
    Term _h_182 = STK(10);
    Term _h_183 = STK(11);
    Term _h_184 = STK(12);
    Term _h_185 = STK(13);
    Term _h_186 = STK(14);
    Term _h_187 = STK(15);
    Term _h_188 = STK(16);
    Term _h_189 = STK(17);
    Term _h_171 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_172;
      STK(1) = _h_173;
      STK(2) = _h_174;
      STK(3) = _h_175;
      STK(4) = _h_176;
      STK(5) = _h_177;
      STK(6) = _h_178;
      STK(7) = _h_179;
      STK(8) = _h_180;
      STK(9) = _h_181;
      STK(10) = _h_182;
      STK(11) = _h_183;
      STK(12) = _h_184;
      STK(13) = _h_185;
      STK(14) = _h_186;
      STK(15) = _h_187;
      STK(16) = _h_188;
      STK(17) = _h_189;
      STK(18) = _h_171;
      STK(19) = FID_MAIN_K43;
      WL_PUSHN(20);
    } else {
      u64 _t_38 = task_node(e, FID_MAIN_K43, WL_CONT, WL_IDX, 1);
      e.mem[_t_38 + 0] = _h_172;
      e.mem[_t_38 + 1] = _h_173;
      e.mem[_t_38 + 2] = _h_174;
      e.mem[_t_38 + 3] = _h_175;
      e.mem[_t_38 + 4] = _h_176;
      e.mem[_t_38 + 5] = _h_177;
      e.mem[_t_38 + 6] = _h_178;
      e.mem[_t_38 + 7] = _h_179;
      e.mem[_t_38 + 8] = _h_180;
      e.mem[_t_38 + 9] = _h_181;
      e.mem[_t_38 + 10] = _h_182;
      e.mem[_t_38 + 11] = _h_183;
      e.mem[_t_38 + 12] = _h_184;
      e.mem[_t_38 + 13] = _h_185;
      e.mem[_t_38 + 14] = _h_186;
      e.mem[_t_38 + 15] = _h_187;
      e.mem[_t_38 + 16] = _h_188;
      e.mem[_t_38 + 17] = _h_189;
      e.mem[_t_38 + 18] = _h_171;
      WL_CONT = term_tsk(FID_MAIN_K43, _t_38);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_39 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_39 + 0] = term_ctr(CID_CON, STAT_OFF + 26);
      e.mem[_t_39 + 1] = term_ctr(CID_CON, STAT_OFF + 30);
      return term_tsk(FID_OBSERVE, _t_39);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 26);
    r1 = term_ctr(CID_CON, STAT_OFF + 30);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K43)
  {
    WL_POPN(19);
    Term _h_191 = STK(0);
    Term _h_192 = STK(1);
    Term _h_193 = STK(2);
    Term _h_194 = STK(3);
    Term _h_195 = STK(4);
    Term _h_196 = STK(5);
    Term _h_197 = STK(6);
    Term _h_198 = STK(7);
    Term _h_199 = STK(8);
    Term _h_200 = STK(9);
    Term _h_201 = STK(10);
    Term _h_202 = STK(11);
    Term _h_203 = STK(12);
    Term _h_204 = STK(13);
    Term _h_205 = STK(14);
    Term _h_206 = STK(15);
    Term _h_207 = STK(16);
    Term _h_208 = STK(17);
    Term _h_209 = STK(18);
    Term _h_190 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _h_191;
      STK(1) = _h_192;
      STK(2) = _h_193;
      STK(3) = _h_194;
      STK(4) = _h_195;
      STK(5) = _h_196;
      STK(6) = _h_197;
      STK(7) = _h_198;
      STK(8) = _h_199;
      STK(9) = _h_200;
      STK(10) = _h_201;
      STK(11) = _h_202;
      STK(12) = _h_203;
      STK(13) = _h_204;
      STK(14) = _h_205;
      STK(15) = _h_206;
      STK(16) = _h_207;
      STK(17) = _h_208;
      STK(18) = _h_209;
      STK(19) = _h_190;
      STK(20) = FID_MAIN_K44;
      WL_PUSHN(21);
    } else {
      u64 _t_40 = task_node(e, FID_MAIN_K44, WL_CONT, WL_IDX, 1);
      e.mem[_t_40 + 0] = _h_191;
      e.mem[_t_40 + 1] = _h_192;
      e.mem[_t_40 + 2] = _h_193;
      e.mem[_t_40 + 3] = _h_194;
      e.mem[_t_40 + 4] = _h_195;
      e.mem[_t_40 + 5] = _h_196;
      e.mem[_t_40 + 6] = _h_197;
      e.mem[_t_40 + 7] = _h_198;
      e.mem[_t_40 + 8] = _h_199;
      e.mem[_t_40 + 9] = _h_200;
      e.mem[_t_40 + 10] = _h_201;
      e.mem[_t_40 + 11] = _h_202;
      e.mem[_t_40 + 12] = _h_203;
      e.mem[_t_40 + 13] = _h_204;
      e.mem[_t_40 + 14] = _h_205;
      e.mem[_t_40 + 15] = _h_206;
      e.mem[_t_40 + 16] = _h_207;
      e.mem[_t_40 + 17] = _h_208;
      e.mem[_t_40 + 18] = _h_209;
      e.mem[_t_40 + 19] = _h_190;
      WL_CONT = term_tsk(FID_MAIN_K44, _t_40);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_41 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_41 + 0] = term_ctr(CID_CON, STAT_OFF + 30);
      e.mem[_t_41 + 1] = term_pak(CID_NIL, 0);
      return term_tsk(FID_OBSERVE, _t_41);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 30);
    r1 = term_pak(CID_NIL, 0);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K44)
  {
    WL_POPN(20);
    Term _h_211 = STK(0);
    Term _h_212 = STK(1);
    Term _h_213 = STK(2);
    Term _h_214 = STK(3);
    Term _h_215 = STK(4);
    Term _h_216 = STK(5);
    Term _h_217 = STK(6);
    Term _h_218 = STK(7);
    Term _h_219 = STK(8);
    Term _h_220 = STK(9);
    Term _h_221 = STK(10);
    Term _h_222 = STK(11);
    Term _h_223 = STK(12);
    Term _h_224 = STK(13);
    Term _h_225 = STK(14);
    Term _h_226 = STK(15);
    Term _h_227 = STK(16);
    Term _h_228 = STK(17);
    Term _h_229 = STK(18);
    Term _h_230 = STK(19);
    Term _h_210 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(22);
      STK(0) = _h_211;
      STK(1) = _h_212;
      STK(2) = _h_213;
      STK(3) = _h_214;
      STK(4) = _h_215;
      STK(5) = _h_216;
      STK(6) = _h_217;
      STK(7) = _h_218;
      STK(8) = _h_219;
      STK(9) = _h_220;
      STK(10) = _h_221;
      STK(11) = _h_222;
      STK(12) = _h_223;
      STK(13) = _h_224;
      STK(14) = _h_225;
      STK(15) = _h_226;
      STK(16) = _h_227;
      STK(17) = _h_228;
      STK(18) = _h_229;
      STK(19) = _h_230;
      STK(20) = _h_210;
      STK(21) = FID_MAIN_K45;
      WL_PUSHN(22);
    } else {
      u64 _t_42 = task_node(e, FID_MAIN_K45, WL_CONT, WL_IDX, 1);
      e.mem[_t_42 + 0] = _h_211;
      e.mem[_t_42 + 1] = _h_212;
      e.mem[_t_42 + 2] = _h_213;
      e.mem[_t_42 + 3] = _h_214;
      e.mem[_t_42 + 4] = _h_215;
      e.mem[_t_42 + 5] = _h_216;
      e.mem[_t_42 + 6] = _h_217;
      e.mem[_t_42 + 7] = _h_218;
      e.mem[_t_42 + 8] = _h_219;
      e.mem[_t_42 + 9] = _h_220;
      e.mem[_t_42 + 10] = _h_221;
      e.mem[_t_42 + 11] = _h_222;
      e.mem[_t_42 + 12] = _h_223;
      e.mem[_t_42 + 13] = _h_224;
      e.mem[_t_42 + 14] = _h_225;
      e.mem[_t_42 + 15] = _h_226;
      e.mem[_t_42 + 16] = _h_227;
      e.mem[_t_42 + 17] = _h_228;
      e.mem[_t_42 + 18] = _h_229;
      e.mem[_t_42 + 19] = _h_230;
      e.mem[_t_42 + 20] = _h_210;
      WL_CONT = term_tsk(FID_MAIN_K45, _t_42);
      WL_IDX = 21;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_43 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_43 + 0] = term_ctr(CID_CON, STAT_OFF + 30);
      e.mem[_t_43 + 1] = term_ctr(CID_CON, STAT_OFF + 14);
      return term_tsk(FID_OBSERVE, _t_43);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 30);
    r1 = term_ctr(CID_CON, STAT_OFF + 14);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K45)
  {
    WL_POPN(21);
    Term _h_232 = STK(0);
    Term _h_233 = STK(1);
    Term _h_234 = STK(2);
    Term _h_235 = STK(3);
    Term _h_236 = STK(4);
    Term _h_237 = STK(5);
    Term _h_238 = STK(6);
    Term _h_239 = STK(7);
    Term _h_240 = STK(8);
    Term _h_241 = STK(9);
    Term _h_242 = STK(10);
    Term _h_243 = STK(11);
    Term _h_244 = STK(12);
    Term _h_245 = STK(13);
    Term _h_246 = STK(14);
    Term _h_247 = STK(15);
    Term _h_248 = STK(16);
    Term _h_249 = STK(17);
    Term _h_250 = STK(18);
    Term _h_251 = STK(19);
    Term _h_252 = STK(20);
    Term _h_231 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(23);
      STK(0) = _h_232;
      STK(1) = _h_233;
      STK(2) = _h_234;
      STK(3) = _h_235;
      STK(4) = _h_236;
      STK(5) = _h_237;
      STK(6) = _h_238;
      STK(7) = _h_239;
      STK(8) = _h_240;
      STK(9) = _h_241;
      STK(10) = _h_242;
      STK(11) = _h_243;
      STK(12) = _h_244;
      STK(13) = _h_245;
      STK(14) = _h_246;
      STK(15) = _h_247;
      STK(16) = _h_248;
      STK(17) = _h_249;
      STK(18) = _h_250;
      STK(19) = _h_251;
      STK(20) = _h_252;
      STK(21) = _h_231;
      STK(22) = FID_MAIN_K46;
      WL_PUSHN(23);
    } else {
      u64 _t_44 = task_node(e, FID_MAIN_K46, WL_CONT, WL_IDX, 1);
      e.mem[_t_44 + 0] = _h_232;
      e.mem[_t_44 + 1] = _h_233;
      e.mem[_t_44 + 2] = _h_234;
      e.mem[_t_44 + 3] = _h_235;
      e.mem[_t_44 + 4] = _h_236;
      e.mem[_t_44 + 5] = _h_237;
      e.mem[_t_44 + 6] = _h_238;
      e.mem[_t_44 + 7] = _h_239;
      e.mem[_t_44 + 8] = _h_240;
      e.mem[_t_44 + 9] = _h_241;
      e.mem[_t_44 + 10] = _h_242;
      e.mem[_t_44 + 11] = _h_243;
      e.mem[_t_44 + 12] = _h_244;
      e.mem[_t_44 + 13] = _h_245;
      e.mem[_t_44 + 14] = _h_246;
      e.mem[_t_44 + 15] = _h_247;
      e.mem[_t_44 + 16] = _h_248;
      e.mem[_t_44 + 17] = _h_249;
      e.mem[_t_44 + 18] = _h_250;
      e.mem[_t_44 + 19] = _h_251;
      e.mem[_t_44 + 20] = _h_252;
      e.mem[_t_44 + 21] = _h_231;
      WL_CONT = term_tsk(FID_MAIN_K46, _t_44);
      WL_IDX = 22;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_45 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_45 + 0] = term_ctr(CID_CON, STAT_OFF + 30);
      e.mem[_t_45 + 1] = term_ctr(CID_CON, STAT_OFF + 20);
      return term_tsk(FID_OBSERVE, _t_45);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 30);
    r1 = term_ctr(CID_CON, STAT_OFF + 20);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K46)
  {
    WL_POPN(22);
    Term _h_254 = STK(0);
    Term _h_255 = STK(1);
    Term _h_256 = STK(2);
    Term _h_257 = STK(3);
    Term _h_258 = STK(4);
    Term _h_259 = STK(5);
    Term _h_260 = STK(6);
    Term _h_261 = STK(7);
    Term _h_262 = STK(8);
    Term _h_263 = STK(9);
    Term _h_264 = STK(10);
    Term _h_265 = STK(11);
    Term _h_266 = STK(12);
    Term _h_267 = STK(13);
    Term _h_268 = STK(14);
    Term _h_269 = STK(15);
    Term _h_270 = STK(16);
    Term _h_271 = STK(17);
    Term _h_272 = STK(18);
    Term _h_273 = STK(19);
    Term _h_274 = STK(20);
    Term _h_275 = STK(21);
    Term _h_253 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(24);
      STK(0) = _h_254;
      STK(1) = _h_255;
      STK(2) = _h_256;
      STK(3) = _h_257;
      STK(4) = _h_258;
      STK(5) = _h_259;
      STK(6) = _h_260;
      STK(7) = _h_261;
      STK(8) = _h_262;
      STK(9) = _h_263;
      STK(10) = _h_264;
      STK(11) = _h_265;
      STK(12) = _h_266;
      STK(13) = _h_267;
      STK(14) = _h_268;
      STK(15) = _h_269;
      STK(16) = _h_270;
      STK(17) = _h_271;
      STK(18) = _h_272;
      STK(19) = _h_273;
      STK(20) = _h_274;
      STK(21) = _h_275;
      STK(22) = _h_253;
      STK(23) = FID_MAIN_K47;
      WL_PUSHN(24);
    } else {
      u64 _t_46 = task_node(e, FID_MAIN_K47, WL_CONT, WL_IDX, 1);
      e.mem[_t_46 + 0] = _h_254;
      e.mem[_t_46 + 1] = _h_255;
      e.mem[_t_46 + 2] = _h_256;
      e.mem[_t_46 + 3] = _h_257;
      e.mem[_t_46 + 4] = _h_258;
      e.mem[_t_46 + 5] = _h_259;
      e.mem[_t_46 + 6] = _h_260;
      e.mem[_t_46 + 7] = _h_261;
      e.mem[_t_46 + 8] = _h_262;
      e.mem[_t_46 + 9] = _h_263;
      e.mem[_t_46 + 10] = _h_264;
      e.mem[_t_46 + 11] = _h_265;
      e.mem[_t_46 + 12] = _h_266;
      e.mem[_t_46 + 13] = _h_267;
      e.mem[_t_46 + 14] = _h_268;
      e.mem[_t_46 + 15] = _h_269;
      e.mem[_t_46 + 16] = _h_270;
      e.mem[_t_46 + 17] = _h_271;
      e.mem[_t_46 + 18] = _h_272;
      e.mem[_t_46 + 19] = _h_273;
      e.mem[_t_46 + 20] = _h_274;
      e.mem[_t_46 + 21] = _h_275;
      e.mem[_t_46 + 22] = _h_253;
      WL_CONT = term_tsk(FID_MAIN_K47, _t_46);
      WL_IDX = 23;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_47 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_47 + 0] = term_ctr(CID_CON, STAT_OFF + 30);
      e.mem[_t_47 + 1] = term_ctr(CID_CON, STAT_OFF + 26);
      return term_tsk(FID_OBSERVE, _t_47);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 30);
    r1 = term_ctr(CID_CON, STAT_OFF + 26);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K47)
  {
    WL_POPN(23);
    Term _h_277 = STK(0);
    Term _h_278 = STK(1);
    Term _h_279 = STK(2);
    Term _h_280 = STK(3);
    Term _h_281 = STK(4);
    Term _h_282 = STK(5);
    Term _h_283 = STK(6);
    Term _h_284 = STK(7);
    Term _h_285 = STK(8);
    Term _h_286 = STK(9);
    Term _h_287 = STK(10);
    Term _h_288 = STK(11);
    Term _h_289 = STK(12);
    Term _h_290 = STK(13);
    Term _h_291 = STK(14);
    Term _h_292 = STK(15);
    Term _h_293 = STK(16);
    Term _h_294 = STK(17);
    Term _h_295 = STK(18);
    Term _h_296 = STK(19);
    Term _h_297 = STK(20);
    Term _h_298 = STK(21);
    Term _h_299 = STK(22);
    Term _h_276 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(25);
      STK(0) = _h_277;
      STK(1) = _h_278;
      STK(2) = _h_279;
      STK(3) = _h_280;
      STK(4) = _h_281;
      STK(5) = _h_282;
      STK(6) = _h_283;
      STK(7) = _h_284;
      STK(8) = _h_285;
      STK(9) = _h_286;
      STK(10) = _h_287;
      STK(11) = _h_288;
      STK(12) = _h_289;
      STK(13) = _h_290;
      STK(14) = _h_291;
      STK(15) = _h_292;
      STK(16) = _h_293;
      STK(17) = _h_294;
      STK(18) = _h_295;
      STK(19) = _h_296;
      STK(20) = _h_297;
      STK(21) = _h_298;
      STK(22) = _h_299;
      STK(23) = _h_276;
      STK(24) = FID_MAIN_K48;
      WL_PUSHN(25);
    } else {
      u64 _t_48 = task_node(e, FID_MAIN_K48, WL_CONT, WL_IDX, 1);
      e.mem[_t_48 + 0] = _h_277;
      e.mem[_t_48 + 1] = _h_278;
      e.mem[_t_48 + 2] = _h_279;
      e.mem[_t_48 + 3] = _h_280;
      e.mem[_t_48 + 4] = _h_281;
      e.mem[_t_48 + 5] = _h_282;
      e.mem[_t_48 + 6] = _h_283;
      e.mem[_t_48 + 7] = _h_284;
      e.mem[_t_48 + 8] = _h_285;
      e.mem[_t_48 + 9] = _h_286;
      e.mem[_t_48 + 10] = _h_287;
      e.mem[_t_48 + 11] = _h_288;
      e.mem[_t_48 + 12] = _h_289;
      e.mem[_t_48 + 13] = _h_290;
      e.mem[_t_48 + 14] = _h_291;
      e.mem[_t_48 + 15] = _h_292;
      e.mem[_t_48 + 16] = _h_293;
      e.mem[_t_48 + 17] = _h_294;
      e.mem[_t_48 + 18] = _h_295;
      e.mem[_t_48 + 19] = _h_296;
      e.mem[_t_48 + 20] = _h_297;
      e.mem[_t_48 + 21] = _h_298;
      e.mem[_t_48 + 22] = _h_299;
      e.mem[_t_48 + 23] = _h_276;
      WL_CONT = term_tsk(FID_MAIN_K48, _t_48);
      WL_IDX = 24;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OBSERVE)) {
      u64 _t_49 = task_node(e, FID_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_49 + 0] = term_ctr(CID_CON, STAT_OFF + 30);
      e.mem[_t_49 + 1] = term_ctr(CID_CON, STAT_OFF + 30);
      return term_tsk(FID_OBSERVE, _t_49);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 30);
    r1 = term_ctr(CID_CON, STAT_OFF + 30);
    WL_JMP(FID_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K48)
  {
    WL_POPN(24);
    Term _h_301 = STK(0);
    Term _h_302 = STK(1);
    Term _h_303 = STK(2);
    Term _h_304 = STK(3);
    Term _h_305 = STK(4);
    Term _h_306 = STK(5);
    Term _h_307 = STK(6);
    Term _h_308 = STK(7);
    Term _h_309 = STK(8);
    Term _h_310 = STK(9);
    Term _h_311 = STK(10);
    Term _h_312 = STK(11);
    Term _h_313 = STK(12);
    Term _h_314 = STK(13);
    Term _h_315 = STK(14);
    Term _h_316 = STK(15);
    Term _h_317 = STK(16);
    Term _h_318 = STK(17);
    Term _h_319 = STK(18);
    Term _h_320 = STK(19);
    Term _h_321 = STK(20);
    Term _h_322 = STK(21);
    Term _h_323 = STK(22);
    Term _h_324 = STK(23);
    Term _h_300 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(25);
      STK(0) = _h_301;
      STK(1) = _h_302;
      STK(2) = _h_303;
      STK(3) = _h_304;
      STK(4) = _h_305;
      STK(5) = _h_306;
      STK(6) = _h_307;
      STK(7) = _h_308;
      STK(8) = _h_309;
      STK(9) = _h_310;
      STK(10) = _h_311;
      STK(11) = _h_312;
      STK(12) = _h_313;
      STK(13) = _h_314;
      STK(14) = _h_315;
      STK(15) = _h_316;
      STK(16) = _h_317;
      STK(17) = _h_318;
      STK(18) = _h_319;
      STK(19) = _h_320;
      STK(20) = _h_321;
      STK(21) = _h_322;
      STK(22) = _h_323;
      STK(23) = _h_324;
      STK(24) = FID_MAIN_K49;
      WL_PUSHN(25);
    } else {
      u64 _t_50 = task_node(e, FID_MAIN_K49, WL_CONT, WL_IDX, 1);
      e.mem[_t_50 + 0] = _h_301;
      e.mem[_t_50 + 1] = _h_302;
      e.mem[_t_50 + 2] = _h_303;
      e.mem[_t_50 + 3] = _h_304;
      e.mem[_t_50 + 4] = _h_305;
      e.mem[_t_50 + 5] = _h_306;
      e.mem[_t_50 + 6] = _h_307;
      e.mem[_t_50 + 7] = _h_308;
      e.mem[_t_50 + 8] = _h_309;
      e.mem[_t_50 + 9] = _h_310;
      e.mem[_t_50 + 10] = _h_311;
      e.mem[_t_50 + 11] = _h_312;
      e.mem[_t_50 + 12] = _h_313;
      e.mem[_t_50 + 13] = _h_314;
      e.mem[_t_50 + 14] = _h_315;
      e.mem[_t_50 + 15] = _h_316;
      e.mem[_t_50 + 16] = _h_317;
      e.mem[_t_50 + 17] = _h_318;
      e.mem[_t_50 + 18] = _h_319;
      e.mem[_t_50 + 19] = _h_320;
      e.mem[_t_50 + 20] = _h_321;
      e.mem[_t_50 + 21] = _h_322;
      e.mem[_t_50 + 22] = _h_323;
      e.mem[_t_50 + 23] = _h_324;
      WL_CONT = term_tsk(FID_MAIN_K49, _t_50);
      WL_IDX = 24;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_51 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_51 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_51 + 1] = _h_300;
      return term_tsk(FID_STRING_APPEND, _t_51);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_300;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K49)
  {
    WL_POPN(24);
    Term _h_326 = STK(0);
    Term _h_327 = STK(1);
    Term _h_328 = STK(2);
    Term _h_329 = STK(3);
    Term _h_330 = STK(4);
    Term _h_331 = STK(5);
    Term _h_332 = STK(6);
    Term _h_333 = STK(7);
    Term _h_334 = STK(8);
    Term _h_335 = STK(9);
    Term _h_336 = STK(10);
    Term _h_337 = STK(11);
    Term _h_338 = STK(12);
    Term _h_339 = STK(13);
    Term _h_340 = STK(14);
    Term _h_341 = STK(15);
    Term _h_342 = STK(16);
    Term _h_343 = STK(17);
    Term _h_344 = STK(18);
    Term _h_345 = STK(19);
    Term _h_346 = STK(20);
    Term _h_347 = STK(21);
    Term _h_348 = STK(22);
    Term _h_349 = STK(23);
    Term _h_325 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(24);
      STK(0) = _h_326;
      STK(1) = _h_327;
      STK(2) = _h_328;
      STK(3) = _h_329;
      STK(4) = _h_330;
      STK(5) = _h_331;
      STK(6) = _h_332;
      STK(7) = _h_333;
      STK(8) = _h_334;
      STK(9) = _h_335;
      STK(10) = _h_336;
      STK(11) = _h_337;
      STK(12) = _h_338;
      STK(13) = _h_339;
      STK(14) = _h_340;
      STK(15) = _h_341;
      STK(16) = _h_342;
      STK(17) = _h_343;
      STK(18) = _h_344;
      STK(19) = _h_345;
      STK(20) = _h_346;
      STK(21) = _h_347;
      STK(22) = _h_348;
      STK(23) = FID_MAIN_K50;
      WL_PUSHN(24);
    } else {
      u64 _t_52 = task_node(e, FID_MAIN_K50, WL_CONT, WL_IDX, 1);
      e.mem[_t_52 + 0] = _h_326;
      e.mem[_t_52 + 1] = _h_327;
      e.mem[_t_52 + 2] = _h_328;
      e.mem[_t_52 + 3] = _h_329;
      e.mem[_t_52 + 4] = _h_330;
      e.mem[_t_52 + 5] = _h_331;
      e.mem[_t_52 + 6] = _h_332;
      e.mem[_t_52 + 7] = _h_333;
      e.mem[_t_52 + 8] = _h_334;
      e.mem[_t_52 + 9] = _h_335;
      e.mem[_t_52 + 10] = _h_336;
      e.mem[_t_52 + 11] = _h_337;
      e.mem[_t_52 + 12] = _h_338;
      e.mem[_t_52 + 13] = _h_339;
      e.mem[_t_52 + 14] = _h_340;
      e.mem[_t_52 + 15] = _h_341;
      e.mem[_t_52 + 16] = _h_342;
      e.mem[_t_52 + 17] = _h_343;
      e.mem[_t_52 + 18] = _h_344;
      e.mem[_t_52 + 19] = _h_345;
      e.mem[_t_52 + 20] = _h_346;
      e.mem[_t_52 + 21] = _h_347;
      e.mem[_t_52 + 22] = _h_348;
      WL_CONT = term_tsk(FID_MAIN_K50, _t_52);
      WL_IDX = 23;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_53 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_53 + 0] = _h_349;
      e.mem[_t_53 + 1] = _h_325;
      return term_tsk(FID_STRING_APPEND, _t_53);
    }
    r0 = _h_349;
    r1 = _h_325;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K50)
  {
    WL_POPN(23);
    Term _h_351 = STK(0);
    Term _h_352 = STK(1);
    Term _h_353 = STK(2);
    Term _h_354 = STK(3);
    Term _h_355 = STK(4);
    Term _h_356 = STK(5);
    Term _h_357 = STK(6);
    Term _h_358 = STK(7);
    Term _h_359 = STK(8);
    Term _h_360 = STK(9);
    Term _h_361 = STK(10);
    Term _h_362 = STK(11);
    Term _h_363 = STK(12);
    Term _h_364 = STK(13);
    Term _h_365 = STK(14);
    Term _h_366 = STK(15);
    Term _h_367 = STK(16);
    Term _h_368 = STK(17);
    Term _h_369 = STK(18);
    Term _h_370 = STK(19);
    Term _h_371 = STK(20);
    Term _h_372 = STK(21);
    Term _h_373 = STK(22);
    Term _h_350 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(24);
      STK(0) = _h_351;
      STK(1) = _h_352;
      STK(2) = _h_353;
      STK(3) = _h_354;
      STK(4) = _h_355;
      STK(5) = _h_356;
      STK(6) = _h_357;
      STK(7) = _h_358;
      STK(8) = _h_359;
      STK(9) = _h_360;
      STK(10) = _h_361;
      STK(11) = _h_362;
      STK(12) = _h_363;
      STK(13) = _h_364;
      STK(14) = _h_365;
      STK(15) = _h_366;
      STK(16) = _h_367;
      STK(17) = _h_368;
      STK(18) = _h_369;
      STK(19) = _h_370;
      STK(20) = _h_371;
      STK(21) = _h_372;
      STK(22) = _h_373;
      STK(23) = FID_MAIN_K51;
      WL_PUSHN(24);
    } else {
      u64 _t_54 = task_node(e, FID_MAIN_K51, WL_CONT, WL_IDX, 1);
      e.mem[_t_54 + 0] = _h_351;
      e.mem[_t_54 + 1] = _h_352;
      e.mem[_t_54 + 2] = _h_353;
      e.mem[_t_54 + 3] = _h_354;
      e.mem[_t_54 + 4] = _h_355;
      e.mem[_t_54 + 5] = _h_356;
      e.mem[_t_54 + 6] = _h_357;
      e.mem[_t_54 + 7] = _h_358;
      e.mem[_t_54 + 8] = _h_359;
      e.mem[_t_54 + 9] = _h_360;
      e.mem[_t_54 + 10] = _h_361;
      e.mem[_t_54 + 11] = _h_362;
      e.mem[_t_54 + 12] = _h_363;
      e.mem[_t_54 + 13] = _h_364;
      e.mem[_t_54 + 14] = _h_365;
      e.mem[_t_54 + 15] = _h_366;
      e.mem[_t_54 + 16] = _h_367;
      e.mem[_t_54 + 17] = _h_368;
      e.mem[_t_54 + 18] = _h_369;
      e.mem[_t_54 + 19] = _h_370;
      e.mem[_t_54 + 20] = _h_371;
      e.mem[_t_54 + 21] = _h_372;
      e.mem[_t_54 + 22] = _h_373;
      WL_CONT = term_tsk(FID_MAIN_K51, _t_54);
      WL_IDX = 23;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_55 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_55 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_55 + 1] = _h_350;
      return term_tsk(FID_STRING_APPEND, _t_55);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_350;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K51)
  {
    WL_POPN(23);
    Term _h_375 = STK(0);
    Term _h_376 = STK(1);
    Term _h_377 = STK(2);
    Term _h_378 = STK(3);
    Term _h_379 = STK(4);
    Term _h_380 = STK(5);
    Term _h_381 = STK(6);
    Term _h_382 = STK(7);
    Term _h_383 = STK(8);
    Term _h_384 = STK(9);
    Term _h_385 = STK(10);
    Term _h_386 = STK(11);
    Term _h_387 = STK(12);
    Term _h_388 = STK(13);
    Term _h_389 = STK(14);
    Term _h_390 = STK(15);
    Term _h_391 = STK(16);
    Term _h_392 = STK(17);
    Term _h_393 = STK(18);
    Term _h_394 = STK(19);
    Term _h_395 = STK(20);
    Term _h_396 = STK(21);
    Term _h_397 = STK(22);
    Term _h_374 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(23);
      STK(0) = _h_375;
      STK(1) = _h_376;
      STK(2) = _h_377;
      STK(3) = _h_378;
      STK(4) = _h_379;
      STK(5) = _h_380;
      STK(6) = _h_381;
      STK(7) = _h_382;
      STK(8) = _h_383;
      STK(9) = _h_384;
      STK(10) = _h_385;
      STK(11) = _h_386;
      STK(12) = _h_387;
      STK(13) = _h_388;
      STK(14) = _h_389;
      STK(15) = _h_390;
      STK(16) = _h_391;
      STK(17) = _h_392;
      STK(18) = _h_393;
      STK(19) = _h_394;
      STK(20) = _h_395;
      STK(21) = _h_396;
      STK(22) = FID_MAIN_K52;
      WL_PUSHN(23);
    } else {
      u64 _t_56 = task_node(e, FID_MAIN_K52, WL_CONT, WL_IDX, 1);
      e.mem[_t_56 + 0] = _h_375;
      e.mem[_t_56 + 1] = _h_376;
      e.mem[_t_56 + 2] = _h_377;
      e.mem[_t_56 + 3] = _h_378;
      e.mem[_t_56 + 4] = _h_379;
      e.mem[_t_56 + 5] = _h_380;
      e.mem[_t_56 + 6] = _h_381;
      e.mem[_t_56 + 7] = _h_382;
      e.mem[_t_56 + 8] = _h_383;
      e.mem[_t_56 + 9] = _h_384;
      e.mem[_t_56 + 10] = _h_385;
      e.mem[_t_56 + 11] = _h_386;
      e.mem[_t_56 + 12] = _h_387;
      e.mem[_t_56 + 13] = _h_388;
      e.mem[_t_56 + 14] = _h_389;
      e.mem[_t_56 + 15] = _h_390;
      e.mem[_t_56 + 16] = _h_391;
      e.mem[_t_56 + 17] = _h_392;
      e.mem[_t_56 + 18] = _h_393;
      e.mem[_t_56 + 19] = _h_394;
      e.mem[_t_56 + 20] = _h_395;
      e.mem[_t_56 + 21] = _h_396;
      WL_CONT = term_tsk(FID_MAIN_K52, _t_56);
      WL_IDX = 22;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_57 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_57 + 0] = _h_397;
      e.mem[_t_57 + 1] = _h_374;
      return term_tsk(FID_STRING_APPEND, _t_57);
    }
    r0 = _h_397;
    r1 = _h_374;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K52)
  {
    WL_POPN(22);
    Term _h_399 = STK(0);
    Term _h_400 = STK(1);
    Term _h_401 = STK(2);
    Term _h_402 = STK(3);
    Term _h_403 = STK(4);
    Term _h_404 = STK(5);
    Term _h_405 = STK(6);
    Term _h_406 = STK(7);
    Term _h_407 = STK(8);
    Term _h_408 = STK(9);
    Term _h_409 = STK(10);
    Term _h_410 = STK(11);
    Term _h_411 = STK(12);
    Term _h_412 = STK(13);
    Term _h_413 = STK(14);
    Term _h_414 = STK(15);
    Term _h_415 = STK(16);
    Term _h_416 = STK(17);
    Term _h_417 = STK(18);
    Term _h_418 = STK(19);
    Term _h_419 = STK(20);
    Term _h_420 = STK(21);
    Term _h_398 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(23);
      STK(0) = _h_399;
      STK(1) = _h_400;
      STK(2) = _h_401;
      STK(3) = _h_402;
      STK(4) = _h_403;
      STK(5) = _h_404;
      STK(6) = _h_405;
      STK(7) = _h_406;
      STK(8) = _h_407;
      STK(9) = _h_408;
      STK(10) = _h_409;
      STK(11) = _h_410;
      STK(12) = _h_411;
      STK(13) = _h_412;
      STK(14) = _h_413;
      STK(15) = _h_414;
      STK(16) = _h_415;
      STK(17) = _h_416;
      STK(18) = _h_417;
      STK(19) = _h_418;
      STK(20) = _h_419;
      STK(21) = _h_420;
      STK(22) = FID_MAIN_K53;
      WL_PUSHN(23);
    } else {
      u64 _t_58 = task_node(e, FID_MAIN_K53, WL_CONT, WL_IDX, 1);
      e.mem[_t_58 + 0] = _h_399;
      e.mem[_t_58 + 1] = _h_400;
      e.mem[_t_58 + 2] = _h_401;
      e.mem[_t_58 + 3] = _h_402;
      e.mem[_t_58 + 4] = _h_403;
      e.mem[_t_58 + 5] = _h_404;
      e.mem[_t_58 + 6] = _h_405;
      e.mem[_t_58 + 7] = _h_406;
      e.mem[_t_58 + 8] = _h_407;
      e.mem[_t_58 + 9] = _h_408;
      e.mem[_t_58 + 10] = _h_409;
      e.mem[_t_58 + 11] = _h_410;
      e.mem[_t_58 + 12] = _h_411;
      e.mem[_t_58 + 13] = _h_412;
      e.mem[_t_58 + 14] = _h_413;
      e.mem[_t_58 + 15] = _h_414;
      e.mem[_t_58 + 16] = _h_415;
      e.mem[_t_58 + 17] = _h_416;
      e.mem[_t_58 + 18] = _h_417;
      e.mem[_t_58 + 19] = _h_418;
      e.mem[_t_58 + 20] = _h_419;
      e.mem[_t_58 + 21] = _h_420;
      WL_CONT = term_tsk(FID_MAIN_K53, _t_58);
      WL_IDX = 22;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_59 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_59 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_59 + 1] = _h_398;
      return term_tsk(FID_STRING_APPEND, _t_59);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_398;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K53)
  {
    WL_POPN(22);
    Term _h_422 = STK(0);
    Term _h_423 = STK(1);
    Term _h_424 = STK(2);
    Term _h_425 = STK(3);
    Term _h_426 = STK(4);
    Term _h_427 = STK(5);
    Term _h_428 = STK(6);
    Term _h_429 = STK(7);
    Term _h_430 = STK(8);
    Term _h_431 = STK(9);
    Term _h_432 = STK(10);
    Term _h_433 = STK(11);
    Term _h_434 = STK(12);
    Term _h_435 = STK(13);
    Term _h_436 = STK(14);
    Term _h_437 = STK(15);
    Term _h_438 = STK(16);
    Term _h_439 = STK(17);
    Term _h_440 = STK(18);
    Term _h_441 = STK(19);
    Term _h_442 = STK(20);
    Term _h_443 = STK(21);
    Term _h_421 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(22);
      STK(0) = _h_422;
      STK(1) = _h_423;
      STK(2) = _h_424;
      STK(3) = _h_425;
      STK(4) = _h_426;
      STK(5) = _h_427;
      STK(6) = _h_428;
      STK(7) = _h_429;
      STK(8) = _h_430;
      STK(9) = _h_431;
      STK(10) = _h_432;
      STK(11) = _h_433;
      STK(12) = _h_434;
      STK(13) = _h_435;
      STK(14) = _h_436;
      STK(15) = _h_437;
      STK(16) = _h_438;
      STK(17) = _h_439;
      STK(18) = _h_440;
      STK(19) = _h_441;
      STK(20) = _h_442;
      STK(21) = FID_MAIN_K54;
      WL_PUSHN(22);
    } else {
      u64 _t_60 = task_node(e, FID_MAIN_K54, WL_CONT, WL_IDX, 1);
      e.mem[_t_60 + 0] = _h_422;
      e.mem[_t_60 + 1] = _h_423;
      e.mem[_t_60 + 2] = _h_424;
      e.mem[_t_60 + 3] = _h_425;
      e.mem[_t_60 + 4] = _h_426;
      e.mem[_t_60 + 5] = _h_427;
      e.mem[_t_60 + 6] = _h_428;
      e.mem[_t_60 + 7] = _h_429;
      e.mem[_t_60 + 8] = _h_430;
      e.mem[_t_60 + 9] = _h_431;
      e.mem[_t_60 + 10] = _h_432;
      e.mem[_t_60 + 11] = _h_433;
      e.mem[_t_60 + 12] = _h_434;
      e.mem[_t_60 + 13] = _h_435;
      e.mem[_t_60 + 14] = _h_436;
      e.mem[_t_60 + 15] = _h_437;
      e.mem[_t_60 + 16] = _h_438;
      e.mem[_t_60 + 17] = _h_439;
      e.mem[_t_60 + 18] = _h_440;
      e.mem[_t_60 + 19] = _h_441;
      e.mem[_t_60 + 20] = _h_442;
      WL_CONT = term_tsk(FID_MAIN_K54, _t_60);
      WL_IDX = 21;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_61 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_61 + 0] = _h_443;
      e.mem[_t_61 + 1] = _h_421;
      return term_tsk(FID_STRING_APPEND, _t_61);
    }
    r0 = _h_443;
    r1 = _h_421;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K54)
  {
    WL_POPN(21);
    Term _h_445 = STK(0);
    Term _h_446 = STK(1);
    Term _h_447 = STK(2);
    Term _h_448 = STK(3);
    Term _h_449 = STK(4);
    Term _h_450 = STK(5);
    Term _h_451 = STK(6);
    Term _h_452 = STK(7);
    Term _h_453 = STK(8);
    Term _h_454 = STK(9);
    Term _h_455 = STK(10);
    Term _h_456 = STK(11);
    Term _h_457 = STK(12);
    Term _h_458 = STK(13);
    Term _h_459 = STK(14);
    Term _h_460 = STK(15);
    Term _h_461 = STK(16);
    Term _h_462 = STK(17);
    Term _h_463 = STK(18);
    Term _h_464 = STK(19);
    Term _h_465 = STK(20);
    Term _h_444 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(22);
      STK(0) = _h_445;
      STK(1) = _h_446;
      STK(2) = _h_447;
      STK(3) = _h_448;
      STK(4) = _h_449;
      STK(5) = _h_450;
      STK(6) = _h_451;
      STK(7) = _h_452;
      STK(8) = _h_453;
      STK(9) = _h_454;
      STK(10) = _h_455;
      STK(11) = _h_456;
      STK(12) = _h_457;
      STK(13) = _h_458;
      STK(14) = _h_459;
      STK(15) = _h_460;
      STK(16) = _h_461;
      STK(17) = _h_462;
      STK(18) = _h_463;
      STK(19) = _h_464;
      STK(20) = _h_465;
      STK(21) = FID_MAIN_K55;
      WL_PUSHN(22);
    } else {
      u64 _t_62 = task_node(e, FID_MAIN_K55, WL_CONT, WL_IDX, 1);
      e.mem[_t_62 + 0] = _h_445;
      e.mem[_t_62 + 1] = _h_446;
      e.mem[_t_62 + 2] = _h_447;
      e.mem[_t_62 + 3] = _h_448;
      e.mem[_t_62 + 4] = _h_449;
      e.mem[_t_62 + 5] = _h_450;
      e.mem[_t_62 + 6] = _h_451;
      e.mem[_t_62 + 7] = _h_452;
      e.mem[_t_62 + 8] = _h_453;
      e.mem[_t_62 + 9] = _h_454;
      e.mem[_t_62 + 10] = _h_455;
      e.mem[_t_62 + 11] = _h_456;
      e.mem[_t_62 + 12] = _h_457;
      e.mem[_t_62 + 13] = _h_458;
      e.mem[_t_62 + 14] = _h_459;
      e.mem[_t_62 + 15] = _h_460;
      e.mem[_t_62 + 16] = _h_461;
      e.mem[_t_62 + 17] = _h_462;
      e.mem[_t_62 + 18] = _h_463;
      e.mem[_t_62 + 19] = _h_464;
      e.mem[_t_62 + 20] = _h_465;
      WL_CONT = term_tsk(FID_MAIN_K55, _t_62);
      WL_IDX = 21;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_63 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_63 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_63 + 1] = _h_444;
      return term_tsk(FID_STRING_APPEND, _t_63);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_444;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K55)
  {
    WL_POPN(21);
    Term _h_467 = STK(0);
    Term _h_468 = STK(1);
    Term _h_469 = STK(2);
    Term _h_470 = STK(3);
    Term _h_471 = STK(4);
    Term _h_472 = STK(5);
    Term _h_473 = STK(6);
    Term _h_474 = STK(7);
    Term _h_475 = STK(8);
    Term _h_476 = STK(9);
    Term _h_477 = STK(10);
    Term _h_478 = STK(11);
    Term _h_479 = STK(12);
    Term _h_480 = STK(13);
    Term _h_481 = STK(14);
    Term _h_482 = STK(15);
    Term _h_483 = STK(16);
    Term _h_484 = STK(17);
    Term _h_485 = STK(18);
    Term _h_486 = STK(19);
    Term _h_487 = STK(20);
    Term _h_466 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _h_467;
      STK(1) = _h_468;
      STK(2) = _h_469;
      STK(3) = _h_470;
      STK(4) = _h_471;
      STK(5) = _h_472;
      STK(6) = _h_473;
      STK(7) = _h_474;
      STK(8) = _h_475;
      STK(9) = _h_476;
      STK(10) = _h_477;
      STK(11) = _h_478;
      STK(12) = _h_479;
      STK(13) = _h_480;
      STK(14) = _h_481;
      STK(15) = _h_482;
      STK(16) = _h_483;
      STK(17) = _h_484;
      STK(18) = _h_485;
      STK(19) = _h_486;
      STK(20) = FID_MAIN_K56;
      WL_PUSHN(21);
    } else {
      u64 _t_64 = task_node(e, FID_MAIN_K56, WL_CONT, WL_IDX, 1);
      e.mem[_t_64 + 0] = _h_467;
      e.mem[_t_64 + 1] = _h_468;
      e.mem[_t_64 + 2] = _h_469;
      e.mem[_t_64 + 3] = _h_470;
      e.mem[_t_64 + 4] = _h_471;
      e.mem[_t_64 + 5] = _h_472;
      e.mem[_t_64 + 6] = _h_473;
      e.mem[_t_64 + 7] = _h_474;
      e.mem[_t_64 + 8] = _h_475;
      e.mem[_t_64 + 9] = _h_476;
      e.mem[_t_64 + 10] = _h_477;
      e.mem[_t_64 + 11] = _h_478;
      e.mem[_t_64 + 12] = _h_479;
      e.mem[_t_64 + 13] = _h_480;
      e.mem[_t_64 + 14] = _h_481;
      e.mem[_t_64 + 15] = _h_482;
      e.mem[_t_64 + 16] = _h_483;
      e.mem[_t_64 + 17] = _h_484;
      e.mem[_t_64 + 18] = _h_485;
      e.mem[_t_64 + 19] = _h_486;
      WL_CONT = term_tsk(FID_MAIN_K56, _t_64);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_65 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_65 + 0] = _h_487;
      e.mem[_t_65 + 1] = _h_466;
      return term_tsk(FID_STRING_APPEND, _t_65);
    }
    r0 = _h_487;
    r1 = _h_466;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K56)
  {
    WL_POPN(20);
    Term _h_489 = STK(0);
    Term _h_490 = STK(1);
    Term _h_491 = STK(2);
    Term _h_492 = STK(3);
    Term _h_493 = STK(4);
    Term _h_494 = STK(5);
    Term _h_495 = STK(6);
    Term _h_496 = STK(7);
    Term _h_497 = STK(8);
    Term _h_498 = STK(9);
    Term _h_499 = STK(10);
    Term _h_500 = STK(11);
    Term _h_501 = STK(12);
    Term _h_502 = STK(13);
    Term _h_503 = STK(14);
    Term _h_504 = STK(15);
    Term _h_505 = STK(16);
    Term _h_506 = STK(17);
    Term _h_507 = STK(18);
    Term _h_508 = STK(19);
    Term _h_488 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _h_489;
      STK(1) = _h_490;
      STK(2) = _h_491;
      STK(3) = _h_492;
      STK(4) = _h_493;
      STK(5) = _h_494;
      STK(6) = _h_495;
      STK(7) = _h_496;
      STK(8) = _h_497;
      STK(9) = _h_498;
      STK(10) = _h_499;
      STK(11) = _h_500;
      STK(12) = _h_501;
      STK(13) = _h_502;
      STK(14) = _h_503;
      STK(15) = _h_504;
      STK(16) = _h_505;
      STK(17) = _h_506;
      STK(18) = _h_507;
      STK(19) = _h_508;
      STK(20) = FID_MAIN_K57;
      WL_PUSHN(21);
    } else {
      u64 _t_66 = task_node(e, FID_MAIN_K57, WL_CONT, WL_IDX, 1);
      e.mem[_t_66 + 0] = _h_489;
      e.mem[_t_66 + 1] = _h_490;
      e.mem[_t_66 + 2] = _h_491;
      e.mem[_t_66 + 3] = _h_492;
      e.mem[_t_66 + 4] = _h_493;
      e.mem[_t_66 + 5] = _h_494;
      e.mem[_t_66 + 6] = _h_495;
      e.mem[_t_66 + 7] = _h_496;
      e.mem[_t_66 + 8] = _h_497;
      e.mem[_t_66 + 9] = _h_498;
      e.mem[_t_66 + 10] = _h_499;
      e.mem[_t_66 + 11] = _h_500;
      e.mem[_t_66 + 12] = _h_501;
      e.mem[_t_66 + 13] = _h_502;
      e.mem[_t_66 + 14] = _h_503;
      e.mem[_t_66 + 15] = _h_504;
      e.mem[_t_66 + 16] = _h_505;
      e.mem[_t_66 + 17] = _h_506;
      e.mem[_t_66 + 18] = _h_507;
      e.mem[_t_66 + 19] = _h_508;
      WL_CONT = term_tsk(FID_MAIN_K57, _t_66);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_67 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_67 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_67 + 1] = _h_488;
      return term_tsk(FID_STRING_APPEND, _t_67);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_488;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K57)
  {
    WL_POPN(20);
    Term _h_510 = STK(0);
    Term _h_511 = STK(1);
    Term _h_512 = STK(2);
    Term _h_513 = STK(3);
    Term _h_514 = STK(4);
    Term _h_515 = STK(5);
    Term _h_516 = STK(6);
    Term _h_517 = STK(7);
    Term _h_518 = STK(8);
    Term _h_519 = STK(9);
    Term _h_520 = STK(10);
    Term _h_521 = STK(11);
    Term _h_522 = STK(12);
    Term _h_523 = STK(13);
    Term _h_524 = STK(14);
    Term _h_525 = STK(15);
    Term _h_526 = STK(16);
    Term _h_527 = STK(17);
    Term _h_528 = STK(18);
    Term _h_529 = STK(19);
    Term _h_509 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_510;
      STK(1) = _h_511;
      STK(2) = _h_512;
      STK(3) = _h_513;
      STK(4) = _h_514;
      STK(5) = _h_515;
      STK(6) = _h_516;
      STK(7) = _h_517;
      STK(8) = _h_518;
      STK(9) = _h_519;
      STK(10) = _h_520;
      STK(11) = _h_521;
      STK(12) = _h_522;
      STK(13) = _h_523;
      STK(14) = _h_524;
      STK(15) = _h_525;
      STK(16) = _h_526;
      STK(17) = _h_527;
      STK(18) = _h_528;
      STK(19) = FID_MAIN_K58;
      WL_PUSHN(20);
    } else {
      u64 _t_68 = task_node(e, FID_MAIN_K58, WL_CONT, WL_IDX, 1);
      e.mem[_t_68 + 0] = _h_510;
      e.mem[_t_68 + 1] = _h_511;
      e.mem[_t_68 + 2] = _h_512;
      e.mem[_t_68 + 3] = _h_513;
      e.mem[_t_68 + 4] = _h_514;
      e.mem[_t_68 + 5] = _h_515;
      e.mem[_t_68 + 6] = _h_516;
      e.mem[_t_68 + 7] = _h_517;
      e.mem[_t_68 + 8] = _h_518;
      e.mem[_t_68 + 9] = _h_519;
      e.mem[_t_68 + 10] = _h_520;
      e.mem[_t_68 + 11] = _h_521;
      e.mem[_t_68 + 12] = _h_522;
      e.mem[_t_68 + 13] = _h_523;
      e.mem[_t_68 + 14] = _h_524;
      e.mem[_t_68 + 15] = _h_525;
      e.mem[_t_68 + 16] = _h_526;
      e.mem[_t_68 + 17] = _h_527;
      e.mem[_t_68 + 18] = _h_528;
      WL_CONT = term_tsk(FID_MAIN_K58, _t_68);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_69 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_69 + 0] = _h_529;
      e.mem[_t_69 + 1] = _h_509;
      return term_tsk(FID_STRING_APPEND, _t_69);
    }
    r0 = _h_529;
    r1 = _h_509;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K58)
  {
    WL_POPN(19);
    Term _h_531 = STK(0);
    Term _h_532 = STK(1);
    Term _h_533 = STK(2);
    Term _h_534 = STK(3);
    Term _h_535 = STK(4);
    Term _h_536 = STK(5);
    Term _h_537 = STK(6);
    Term _h_538 = STK(7);
    Term _h_539 = STK(8);
    Term _h_540 = STK(9);
    Term _h_541 = STK(10);
    Term _h_542 = STK(11);
    Term _h_543 = STK(12);
    Term _h_544 = STK(13);
    Term _h_545 = STK(14);
    Term _h_546 = STK(15);
    Term _h_547 = STK(16);
    Term _h_548 = STK(17);
    Term _h_549 = STK(18);
    Term _h_530 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_531;
      STK(1) = _h_532;
      STK(2) = _h_533;
      STK(3) = _h_534;
      STK(4) = _h_535;
      STK(5) = _h_536;
      STK(6) = _h_537;
      STK(7) = _h_538;
      STK(8) = _h_539;
      STK(9) = _h_540;
      STK(10) = _h_541;
      STK(11) = _h_542;
      STK(12) = _h_543;
      STK(13) = _h_544;
      STK(14) = _h_545;
      STK(15) = _h_546;
      STK(16) = _h_547;
      STK(17) = _h_548;
      STK(18) = _h_549;
      STK(19) = FID_MAIN_K59;
      WL_PUSHN(20);
    } else {
      u64 _t_70 = task_node(e, FID_MAIN_K59, WL_CONT, WL_IDX, 1);
      e.mem[_t_70 + 0] = _h_531;
      e.mem[_t_70 + 1] = _h_532;
      e.mem[_t_70 + 2] = _h_533;
      e.mem[_t_70 + 3] = _h_534;
      e.mem[_t_70 + 4] = _h_535;
      e.mem[_t_70 + 5] = _h_536;
      e.mem[_t_70 + 6] = _h_537;
      e.mem[_t_70 + 7] = _h_538;
      e.mem[_t_70 + 8] = _h_539;
      e.mem[_t_70 + 9] = _h_540;
      e.mem[_t_70 + 10] = _h_541;
      e.mem[_t_70 + 11] = _h_542;
      e.mem[_t_70 + 12] = _h_543;
      e.mem[_t_70 + 13] = _h_544;
      e.mem[_t_70 + 14] = _h_545;
      e.mem[_t_70 + 15] = _h_546;
      e.mem[_t_70 + 16] = _h_547;
      e.mem[_t_70 + 17] = _h_548;
      e.mem[_t_70 + 18] = _h_549;
      WL_CONT = term_tsk(FID_MAIN_K59, _t_70);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_71 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_71 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_71 + 1] = _h_530;
      return term_tsk(FID_STRING_APPEND, _t_71);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_530;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K59)
  {
    WL_POPN(19);
    Term _h_551 = STK(0);
    Term _h_552 = STK(1);
    Term _h_553 = STK(2);
    Term _h_554 = STK(3);
    Term _h_555 = STK(4);
    Term _h_556 = STK(5);
    Term _h_557 = STK(6);
    Term _h_558 = STK(7);
    Term _h_559 = STK(8);
    Term _h_560 = STK(9);
    Term _h_561 = STK(10);
    Term _h_562 = STK(11);
    Term _h_563 = STK(12);
    Term _h_564 = STK(13);
    Term _h_565 = STK(14);
    Term _h_566 = STK(15);
    Term _h_567 = STK(16);
    Term _h_568 = STK(17);
    Term _h_569 = STK(18);
    Term _h_550 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(19);
      STK(0) = _h_551;
      STK(1) = _h_552;
      STK(2) = _h_553;
      STK(3) = _h_554;
      STK(4) = _h_555;
      STK(5) = _h_556;
      STK(6) = _h_557;
      STK(7) = _h_558;
      STK(8) = _h_559;
      STK(9) = _h_560;
      STK(10) = _h_561;
      STK(11) = _h_562;
      STK(12) = _h_563;
      STK(13) = _h_564;
      STK(14) = _h_565;
      STK(15) = _h_566;
      STK(16) = _h_567;
      STK(17) = _h_568;
      STK(18) = FID_MAIN_K60;
      WL_PUSHN(19);
    } else {
      u64 _t_72 = task_node(e, FID_MAIN_K60, WL_CONT, WL_IDX, 1);
      e.mem[_t_72 + 0] = _h_551;
      e.mem[_t_72 + 1] = _h_552;
      e.mem[_t_72 + 2] = _h_553;
      e.mem[_t_72 + 3] = _h_554;
      e.mem[_t_72 + 4] = _h_555;
      e.mem[_t_72 + 5] = _h_556;
      e.mem[_t_72 + 6] = _h_557;
      e.mem[_t_72 + 7] = _h_558;
      e.mem[_t_72 + 8] = _h_559;
      e.mem[_t_72 + 9] = _h_560;
      e.mem[_t_72 + 10] = _h_561;
      e.mem[_t_72 + 11] = _h_562;
      e.mem[_t_72 + 12] = _h_563;
      e.mem[_t_72 + 13] = _h_564;
      e.mem[_t_72 + 14] = _h_565;
      e.mem[_t_72 + 15] = _h_566;
      e.mem[_t_72 + 16] = _h_567;
      e.mem[_t_72 + 17] = _h_568;
      WL_CONT = term_tsk(FID_MAIN_K60, _t_72);
      WL_IDX = 18;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_73 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_73 + 0] = _h_569;
      e.mem[_t_73 + 1] = _h_550;
      return term_tsk(FID_STRING_APPEND, _t_73);
    }
    r0 = _h_569;
    r1 = _h_550;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K60)
  {
    WL_POPN(18);
    Term _h_571 = STK(0);
    Term _h_572 = STK(1);
    Term _h_573 = STK(2);
    Term _h_574 = STK(3);
    Term _h_575 = STK(4);
    Term _h_576 = STK(5);
    Term _h_577 = STK(6);
    Term _h_578 = STK(7);
    Term _h_579 = STK(8);
    Term _h_580 = STK(9);
    Term _h_581 = STK(10);
    Term _h_582 = STK(11);
    Term _h_583 = STK(12);
    Term _h_584 = STK(13);
    Term _h_585 = STK(14);
    Term _h_586 = STK(15);
    Term _h_587 = STK(16);
    Term _h_588 = STK(17);
    Term _h_570 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(19);
      STK(0) = _h_571;
      STK(1) = _h_572;
      STK(2) = _h_573;
      STK(3) = _h_574;
      STK(4) = _h_575;
      STK(5) = _h_576;
      STK(6) = _h_577;
      STK(7) = _h_578;
      STK(8) = _h_579;
      STK(9) = _h_580;
      STK(10) = _h_581;
      STK(11) = _h_582;
      STK(12) = _h_583;
      STK(13) = _h_584;
      STK(14) = _h_585;
      STK(15) = _h_586;
      STK(16) = _h_587;
      STK(17) = _h_588;
      STK(18) = FID_MAIN_K61;
      WL_PUSHN(19);
    } else {
      u64 _t_74 = task_node(e, FID_MAIN_K61, WL_CONT, WL_IDX, 1);
      e.mem[_t_74 + 0] = _h_571;
      e.mem[_t_74 + 1] = _h_572;
      e.mem[_t_74 + 2] = _h_573;
      e.mem[_t_74 + 3] = _h_574;
      e.mem[_t_74 + 4] = _h_575;
      e.mem[_t_74 + 5] = _h_576;
      e.mem[_t_74 + 6] = _h_577;
      e.mem[_t_74 + 7] = _h_578;
      e.mem[_t_74 + 8] = _h_579;
      e.mem[_t_74 + 9] = _h_580;
      e.mem[_t_74 + 10] = _h_581;
      e.mem[_t_74 + 11] = _h_582;
      e.mem[_t_74 + 12] = _h_583;
      e.mem[_t_74 + 13] = _h_584;
      e.mem[_t_74 + 14] = _h_585;
      e.mem[_t_74 + 15] = _h_586;
      e.mem[_t_74 + 16] = _h_587;
      e.mem[_t_74 + 17] = _h_588;
      WL_CONT = term_tsk(FID_MAIN_K61, _t_74);
      WL_IDX = 18;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_75 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_75 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_75 + 1] = _h_570;
      return term_tsk(FID_STRING_APPEND, _t_75);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_570;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K61)
  {
    WL_POPN(18);
    Term _h_590 = STK(0);
    Term _h_591 = STK(1);
    Term _h_592 = STK(2);
    Term _h_593 = STK(3);
    Term _h_594 = STK(4);
    Term _h_595 = STK(5);
    Term _h_596 = STK(6);
    Term _h_597 = STK(7);
    Term _h_598 = STK(8);
    Term _h_599 = STK(9);
    Term _h_600 = STK(10);
    Term _h_601 = STK(11);
    Term _h_602 = STK(12);
    Term _h_603 = STK(13);
    Term _h_604 = STK(14);
    Term _h_605 = STK(15);
    Term _h_606 = STK(16);
    Term _h_607 = STK(17);
    Term _h_589 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(18);
      STK(0) = _h_590;
      STK(1) = _h_591;
      STK(2) = _h_592;
      STK(3) = _h_593;
      STK(4) = _h_594;
      STK(5) = _h_595;
      STK(6) = _h_596;
      STK(7) = _h_597;
      STK(8) = _h_598;
      STK(9) = _h_599;
      STK(10) = _h_600;
      STK(11) = _h_601;
      STK(12) = _h_602;
      STK(13) = _h_603;
      STK(14) = _h_604;
      STK(15) = _h_605;
      STK(16) = _h_606;
      STK(17) = FID_MAIN_K62;
      WL_PUSHN(18);
    } else {
      u64 _t_76 = task_node(e, FID_MAIN_K62, WL_CONT, WL_IDX, 1);
      e.mem[_t_76 + 0] = _h_590;
      e.mem[_t_76 + 1] = _h_591;
      e.mem[_t_76 + 2] = _h_592;
      e.mem[_t_76 + 3] = _h_593;
      e.mem[_t_76 + 4] = _h_594;
      e.mem[_t_76 + 5] = _h_595;
      e.mem[_t_76 + 6] = _h_596;
      e.mem[_t_76 + 7] = _h_597;
      e.mem[_t_76 + 8] = _h_598;
      e.mem[_t_76 + 9] = _h_599;
      e.mem[_t_76 + 10] = _h_600;
      e.mem[_t_76 + 11] = _h_601;
      e.mem[_t_76 + 12] = _h_602;
      e.mem[_t_76 + 13] = _h_603;
      e.mem[_t_76 + 14] = _h_604;
      e.mem[_t_76 + 15] = _h_605;
      e.mem[_t_76 + 16] = _h_606;
      WL_CONT = term_tsk(FID_MAIN_K62, _t_76);
      WL_IDX = 17;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_77 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_77 + 0] = _h_607;
      e.mem[_t_77 + 1] = _h_589;
      return term_tsk(FID_STRING_APPEND, _t_77);
    }
    r0 = _h_607;
    r1 = _h_589;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K62)
  {
    WL_POPN(17);
    Term _h_609 = STK(0);
    Term _h_610 = STK(1);
    Term _h_611 = STK(2);
    Term _h_612 = STK(3);
    Term _h_613 = STK(4);
    Term _h_614 = STK(5);
    Term _h_615 = STK(6);
    Term _h_616 = STK(7);
    Term _h_617 = STK(8);
    Term _h_618 = STK(9);
    Term _h_619 = STK(10);
    Term _h_620 = STK(11);
    Term _h_621 = STK(12);
    Term _h_622 = STK(13);
    Term _h_623 = STK(14);
    Term _h_624 = STK(15);
    Term _h_625 = STK(16);
    Term _h_608 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(18);
      STK(0) = _h_609;
      STK(1) = _h_610;
      STK(2) = _h_611;
      STK(3) = _h_612;
      STK(4) = _h_613;
      STK(5) = _h_614;
      STK(6) = _h_615;
      STK(7) = _h_616;
      STK(8) = _h_617;
      STK(9) = _h_618;
      STK(10) = _h_619;
      STK(11) = _h_620;
      STK(12) = _h_621;
      STK(13) = _h_622;
      STK(14) = _h_623;
      STK(15) = _h_624;
      STK(16) = _h_625;
      STK(17) = FID_MAIN_K63;
      WL_PUSHN(18);
    } else {
      u64 _t_78 = task_node(e, FID_MAIN_K63, WL_CONT, WL_IDX, 1);
      e.mem[_t_78 + 0] = _h_609;
      e.mem[_t_78 + 1] = _h_610;
      e.mem[_t_78 + 2] = _h_611;
      e.mem[_t_78 + 3] = _h_612;
      e.mem[_t_78 + 4] = _h_613;
      e.mem[_t_78 + 5] = _h_614;
      e.mem[_t_78 + 6] = _h_615;
      e.mem[_t_78 + 7] = _h_616;
      e.mem[_t_78 + 8] = _h_617;
      e.mem[_t_78 + 9] = _h_618;
      e.mem[_t_78 + 10] = _h_619;
      e.mem[_t_78 + 11] = _h_620;
      e.mem[_t_78 + 12] = _h_621;
      e.mem[_t_78 + 13] = _h_622;
      e.mem[_t_78 + 14] = _h_623;
      e.mem[_t_78 + 15] = _h_624;
      e.mem[_t_78 + 16] = _h_625;
      WL_CONT = term_tsk(FID_MAIN_K63, _t_78);
      WL_IDX = 17;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_79 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_79 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_79 + 1] = _h_608;
      return term_tsk(FID_STRING_APPEND, _t_79);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_608;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K63)
  {
    WL_POPN(17);
    Term _h_627 = STK(0);
    Term _h_628 = STK(1);
    Term _h_629 = STK(2);
    Term _h_630 = STK(3);
    Term _h_631 = STK(4);
    Term _h_632 = STK(5);
    Term _h_633 = STK(6);
    Term _h_634 = STK(7);
    Term _h_635 = STK(8);
    Term _h_636 = STK(9);
    Term _h_637 = STK(10);
    Term _h_638 = STK(11);
    Term _h_639 = STK(12);
    Term _h_640 = STK(13);
    Term _h_641 = STK(14);
    Term _h_642 = STK(15);
    Term _h_643 = STK(16);
    Term _h_626 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(17);
      STK(0) = _h_627;
      STK(1) = _h_628;
      STK(2) = _h_629;
      STK(3) = _h_630;
      STK(4) = _h_631;
      STK(5) = _h_632;
      STK(6) = _h_633;
      STK(7) = _h_634;
      STK(8) = _h_635;
      STK(9) = _h_636;
      STK(10) = _h_637;
      STK(11) = _h_638;
      STK(12) = _h_639;
      STK(13) = _h_640;
      STK(14) = _h_641;
      STK(15) = _h_642;
      STK(16) = FID_MAIN_K64;
      WL_PUSHN(17);
    } else {
      u64 _t_80 = task_node(e, FID_MAIN_K64, WL_CONT, WL_IDX, 1);
      e.mem[_t_80 + 0] = _h_627;
      e.mem[_t_80 + 1] = _h_628;
      e.mem[_t_80 + 2] = _h_629;
      e.mem[_t_80 + 3] = _h_630;
      e.mem[_t_80 + 4] = _h_631;
      e.mem[_t_80 + 5] = _h_632;
      e.mem[_t_80 + 6] = _h_633;
      e.mem[_t_80 + 7] = _h_634;
      e.mem[_t_80 + 8] = _h_635;
      e.mem[_t_80 + 9] = _h_636;
      e.mem[_t_80 + 10] = _h_637;
      e.mem[_t_80 + 11] = _h_638;
      e.mem[_t_80 + 12] = _h_639;
      e.mem[_t_80 + 13] = _h_640;
      e.mem[_t_80 + 14] = _h_641;
      e.mem[_t_80 + 15] = _h_642;
      WL_CONT = term_tsk(FID_MAIN_K64, _t_80);
      WL_IDX = 16;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_81 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_81 + 0] = _h_643;
      e.mem[_t_81 + 1] = _h_626;
      return term_tsk(FID_STRING_APPEND, _t_81);
    }
    r0 = _h_643;
    r1 = _h_626;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K64)
  {
    WL_POPN(16);
    Term _h_645 = STK(0);
    Term _h_646 = STK(1);
    Term _h_647 = STK(2);
    Term _h_648 = STK(3);
    Term _h_649 = STK(4);
    Term _h_650 = STK(5);
    Term _h_651 = STK(6);
    Term _h_652 = STK(7);
    Term _h_653 = STK(8);
    Term _h_654 = STK(9);
    Term _h_655 = STK(10);
    Term _h_656 = STK(11);
    Term _h_657 = STK(12);
    Term _h_658 = STK(13);
    Term _h_659 = STK(14);
    Term _h_660 = STK(15);
    Term _h_644 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(17);
      STK(0) = _h_645;
      STK(1) = _h_646;
      STK(2) = _h_647;
      STK(3) = _h_648;
      STK(4) = _h_649;
      STK(5) = _h_650;
      STK(6) = _h_651;
      STK(7) = _h_652;
      STK(8) = _h_653;
      STK(9) = _h_654;
      STK(10) = _h_655;
      STK(11) = _h_656;
      STK(12) = _h_657;
      STK(13) = _h_658;
      STK(14) = _h_659;
      STK(15) = _h_660;
      STK(16) = FID_MAIN_K65;
      WL_PUSHN(17);
    } else {
      u64 _t_82 = task_node(e, FID_MAIN_K65, WL_CONT, WL_IDX, 1);
      e.mem[_t_82 + 0] = _h_645;
      e.mem[_t_82 + 1] = _h_646;
      e.mem[_t_82 + 2] = _h_647;
      e.mem[_t_82 + 3] = _h_648;
      e.mem[_t_82 + 4] = _h_649;
      e.mem[_t_82 + 5] = _h_650;
      e.mem[_t_82 + 6] = _h_651;
      e.mem[_t_82 + 7] = _h_652;
      e.mem[_t_82 + 8] = _h_653;
      e.mem[_t_82 + 9] = _h_654;
      e.mem[_t_82 + 10] = _h_655;
      e.mem[_t_82 + 11] = _h_656;
      e.mem[_t_82 + 12] = _h_657;
      e.mem[_t_82 + 13] = _h_658;
      e.mem[_t_82 + 14] = _h_659;
      e.mem[_t_82 + 15] = _h_660;
      WL_CONT = term_tsk(FID_MAIN_K65, _t_82);
      WL_IDX = 16;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_83 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_83 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_83 + 1] = _h_644;
      return term_tsk(FID_STRING_APPEND, _t_83);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_644;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K65)
  {
    WL_POPN(16);
    Term _h_662 = STK(0);
    Term _h_663 = STK(1);
    Term _h_664 = STK(2);
    Term _h_665 = STK(3);
    Term _h_666 = STK(4);
    Term _h_667 = STK(5);
    Term _h_668 = STK(6);
    Term _h_669 = STK(7);
    Term _h_670 = STK(8);
    Term _h_671 = STK(9);
    Term _h_672 = STK(10);
    Term _h_673 = STK(11);
    Term _h_674 = STK(12);
    Term _h_675 = STK(13);
    Term _h_676 = STK(14);
    Term _h_677 = STK(15);
    Term _h_661 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _h_662;
      STK(1) = _h_663;
      STK(2) = _h_664;
      STK(3) = _h_665;
      STK(4) = _h_666;
      STK(5) = _h_667;
      STK(6) = _h_668;
      STK(7) = _h_669;
      STK(8) = _h_670;
      STK(9) = _h_671;
      STK(10) = _h_672;
      STK(11) = _h_673;
      STK(12) = _h_674;
      STK(13) = _h_675;
      STK(14) = _h_676;
      STK(15) = FID_MAIN_K66;
      WL_PUSHN(16);
    } else {
      u64 _t_84 = task_node(e, FID_MAIN_K66, WL_CONT, WL_IDX, 1);
      e.mem[_t_84 + 0] = _h_662;
      e.mem[_t_84 + 1] = _h_663;
      e.mem[_t_84 + 2] = _h_664;
      e.mem[_t_84 + 3] = _h_665;
      e.mem[_t_84 + 4] = _h_666;
      e.mem[_t_84 + 5] = _h_667;
      e.mem[_t_84 + 6] = _h_668;
      e.mem[_t_84 + 7] = _h_669;
      e.mem[_t_84 + 8] = _h_670;
      e.mem[_t_84 + 9] = _h_671;
      e.mem[_t_84 + 10] = _h_672;
      e.mem[_t_84 + 11] = _h_673;
      e.mem[_t_84 + 12] = _h_674;
      e.mem[_t_84 + 13] = _h_675;
      e.mem[_t_84 + 14] = _h_676;
      WL_CONT = term_tsk(FID_MAIN_K66, _t_84);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_85 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_85 + 0] = _h_677;
      e.mem[_t_85 + 1] = _h_661;
      return term_tsk(FID_STRING_APPEND, _t_85);
    }
    r0 = _h_677;
    r1 = _h_661;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K66)
  {
    WL_POPN(15);
    Term _h_679 = STK(0);
    Term _h_680 = STK(1);
    Term _h_681 = STK(2);
    Term _h_682 = STK(3);
    Term _h_683 = STK(4);
    Term _h_684 = STK(5);
    Term _h_685 = STK(6);
    Term _h_686 = STK(7);
    Term _h_687 = STK(8);
    Term _h_688 = STK(9);
    Term _h_689 = STK(10);
    Term _h_690 = STK(11);
    Term _h_691 = STK(12);
    Term _h_692 = STK(13);
    Term _h_693 = STK(14);
    Term _h_678 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _h_679;
      STK(1) = _h_680;
      STK(2) = _h_681;
      STK(3) = _h_682;
      STK(4) = _h_683;
      STK(5) = _h_684;
      STK(6) = _h_685;
      STK(7) = _h_686;
      STK(8) = _h_687;
      STK(9) = _h_688;
      STK(10) = _h_689;
      STK(11) = _h_690;
      STK(12) = _h_691;
      STK(13) = _h_692;
      STK(14) = _h_693;
      STK(15) = FID_MAIN_K67;
      WL_PUSHN(16);
    } else {
      u64 _t_86 = task_node(e, FID_MAIN_K67, WL_CONT, WL_IDX, 1);
      e.mem[_t_86 + 0] = _h_679;
      e.mem[_t_86 + 1] = _h_680;
      e.mem[_t_86 + 2] = _h_681;
      e.mem[_t_86 + 3] = _h_682;
      e.mem[_t_86 + 4] = _h_683;
      e.mem[_t_86 + 5] = _h_684;
      e.mem[_t_86 + 6] = _h_685;
      e.mem[_t_86 + 7] = _h_686;
      e.mem[_t_86 + 8] = _h_687;
      e.mem[_t_86 + 9] = _h_688;
      e.mem[_t_86 + 10] = _h_689;
      e.mem[_t_86 + 11] = _h_690;
      e.mem[_t_86 + 12] = _h_691;
      e.mem[_t_86 + 13] = _h_692;
      e.mem[_t_86 + 14] = _h_693;
      WL_CONT = term_tsk(FID_MAIN_K67, _t_86);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_87 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_87 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_87 + 1] = _h_678;
      return term_tsk(FID_STRING_APPEND, _t_87);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_678;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K67)
  {
    WL_POPN(15);
    Term _h_695 = STK(0);
    Term _h_696 = STK(1);
    Term _h_697 = STK(2);
    Term _h_698 = STK(3);
    Term _h_699 = STK(4);
    Term _h_700 = STK(5);
    Term _h_701 = STK(6);
    Term _h_702 = STK(7);
    Term _h_703 = STK(8);
    Term _h_704 = STK(9);
    Term _h_705 = STK(10);
    Term _h_706 = STK(11);
    Term _h_707 = STK(12);
    Term _h_708 = STK(13);
    Term _h_709 = STK(14);
    Term _h_694 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _h_695;
      STK(1) = _h_696;
      STK(2) = _h_697;
      STK(3) = _h_698;
      STK(4) = _h_699;
      STK(5) = _h_700;
      STK(6) = _h_701;
      STK(7) = _h_702;
      STK(8) = _h_703;
      STK(9) = _h_704;
      STK(10) = _h_705;
      STK(11) = _h_706;
      STK(12) = _h_707;
      STK(13) = _h_708;
      STK(14) = FID_MAIN_K68;
      WL_PUSHN(15);
    } else {
      u64 _t_88 = task_node(e, FID_MAIN_K68, WL_CONT, WL_IDX, 1);
      e.mem[_t_88 + 0] = _h_695;
      e.mem[_t_88 + 1] = _h_696;
      e.mem[_t_88 + 2] = _h_697;
      e.mem[_t_88 + 3] = _h_698;
      e.mem[_t_88 + 4] = _h_699;
      e.mem[_t_88 + 5] = _h_700;
      e.mem[_t_88 + 6] = _h_701;
      e.mem[_t_88 + 7] = _h_702;
      e.mem[_t_88 + 8] = _h_703;
      e.mem[_t_88 + 9] = _h_704;
      e.mem[_t_88 + 10] = _h_705;
      e.mem[_t_88 + 11] = _h_706;
      e.mem[_t_88 + 12] = _h_707;
      e.mem[_t_88 + 13] = _h_708;
      WL_CONT = term_tsk(FID_MAIN_K68, _t_88);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_89 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_89 + 0] = _h_709;
      e.mem[_t_89 + 1] = _h_694;
      return term_tsk(FID_STRING_APPEND, _t_89);
    }
    r0 = _h_709;
    r1 = _h_694;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K68)
  {
    WL_POPN(14);
    Term _h_711 = STK(0);
    Term _h_712 = STK(1);
    Term _h_713 = STK(2);
    Term _h_714 = STK(3);
    Term _h_715 = STK(4);
    Term _h_716 = STK(5);
    Term _h_717 = STK(6);
    Term _h_718 = STK(7);
    Term _h_719 = STK(8);
    Term _h_720 = STK(9);
    Term _h_721 = STK(10);
    Term _h_722 = STK(11);
    Term _h_723 = STK(12);
    Term _h_724 = STK(13);
    Term _h_710 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _h_711;
      STK(1) = _h_712;
      STK(2) = _h_713;
      STK(3) = _h_714;
      STK(4) = _h_715;
      STK(5) = _h_716;
      STK(6) = _h_717;
      STK(7) = _h_718;
      STK(8) = _h_719;
      STK(9) = _h_720;
      STK(10) = _h_721;
      STK(11) = _h_722;
      STK(12) = _h_723;
      STK(13) = _h_724;
      STK(14) = FID_MAIN_K69;
      WL_PUSHN(15);
    } else {
      u64 _t_90 = task_node(e, FID_MAIN_K69, WL_CONT, WL_IDX, 1);
      e.mem[_t_90 + 0] = _h_711;
      e.mem[_t_90 + 1] = _h_712;
      e.mem[_t_90 + 2] = _h_713;
      e.mem[_t_90 + 3] = _h_714;
      e.mem[_t_90 + 4] = _h_715;
      e.mem[_t_90 + 5] = _h_716;
      e.mem[_t_90 + 6] = _h_717;
      e.mem[_t_90 + 7] = _h_718;
      e.mem[_t_90 + 8] = _h_719;
      e.mem[_t_90 + 9] = _h_720;
      e.mem[_t_90 + 10] = _h_721;
      e.mem[_t_90 + 11] = _h_722;
      e.mem[_t_90 + 12] = _h_723;
      e.mem[_t_90 + 13] = _h_724;
      WL_CONT = term_tsk(FID_MAIN_K69, _t_90);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_91 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_91 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_91 + 1] = _h_710;
      return term_tsk(FID_STRING_APPEND, _t_91);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_710;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K69)
  {
    WL_POPN(14);
    Term _h_726 = STK(0);
    Term _h_727 = STK(1);
    Term _h_728 = STK(2);
    Term _h_729 = STK(3);
    Term _h_730 = STK(4);
    Term _h_731 = STK(5);
    Term _h_732 = STK(6);
    Term _h_733 = STK(7);
    Term _h_734 = STK(8);
    Term _h_735 = STK(9);
    Term _h_736 = STK(10);
    Term _h_737 = STK(11);
    Term _h_738 = STK(12);
    Term _h_739 = STK(13);
    Term _h_725 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _h_726;
      STK(1) = _h_727;
      STK(2) = _h_728;
      STK(3) = _h_729;
      STK(4) = _h_730;
      STK(5) = _h_731;
      STK(6) = _h_732;
      STK(7) = _h_733;
      STK(8) = _h_734;
      STK(9) = _h_735;
      STK(10) = _h_736;
      STK(11) = _h_737;
      STK(12) = _h_738;
      STK(13) = FID_MAIN_K70;
      WL_PUSHN(14);
    } else {
      u64 _t_92 = task_node(e, FID_MAIN_K70, WL_CONT, WL_IDX, 1);
      e.mem[_t_92 + 0] = _h_726;
      e.mem[_t_92 + 1] = _h_727;
      e.mem[_t_92 + 2] = _h_728;
      e.mem[_t_92 + 3] = _h_729;
      e.mem[_t_92 + 4] = _h_730;
      e.mem[_t_92 + 5] = _h_731;
      e.mem[_t_92 + 6] = _h_732;
      e.mem[_t_92 + 7] = _h_733;
      e.mem[_t_92 + 8] = _h_734;
      e.mem[_t_92 + 9] = _h_735;
      e.mem[_t_92 + 10] = _h_736;
      e.mem[_t_92 + 11] = _h_737;
      e.mem[_t_92 + 12] = _h_738;
      WL_CONT = term_tsk(FID_MAIN_K70, _t_92);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_93 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_93 + 0] = _h_739;
      e.mem[_t_93 + 1] = _h_725;
      return term_tsk(FID_STRING_APPEND, _t_93);
    }
    r0 = _h_739;
    r1 = _h_725;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K70)
  {
    WL_POPN(13);
    Term _h_741 = STK(0);
    Term _h_742 = STK(1);
    Term _h_743 = STK(2);
    Term _h_744 = STK(3);
    Term _h_745 = STK(4);
    Term _h_746 = STK(5);
    Term _h_747 = STK(6);
    Term _h_748 = STK(7);
    Term _h_749 = STK(8);
    Term _h_750 = STK(9);
    Term _h_751 = STK(10);
    Term _h_752 = STK(11);
    Term _h_753 = STK(12);
    Term _h_740 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _h_741;
      STK(1) = _h_742;
      STK(2) = _h_743;
      STK(3) = _h_744;
      STK(4) = _h_745;
      STK(5) = _h_746;
      STK(6) = _h_747;
      STK(7) = _h_748;
      STK(8) = _h_749;
      STK(9) = _h_750;
      STK(10) = _h_751;
      STK(11) = _h_752;
      STK(12) = _h_753;
      STK(13) = FID_MAIN_K71;
      WL_PUSHN(14);
    } else {
      u64 _t_94 = task_node(e, FID_MAIN_K71, WL_CONT, WL_IDX, 1);
      e.mem[_t_94 + 0] = _h_741;
      e.mem[_t_94 + 1] = _h_742;
      e.mem[_t_94 + 2] = _h_743;
      e.mem[_t_94 + 3] = _h_744;
      e.mem[_t_94 + 4] = _h_745;
      e.mem[_t_94 + 5] = _h_746;
      e.mem[_t_94 + 6] = _h_747;
      e.mem[_t_94 + 7] = _h_748;
      e.mem[_t_94 + 8] = _h_749;
      e.mem[_t_94 + 9] = _h_750;
      e.mem[_t_94 + 10] = _h_751;
      e.mem[_t_94 + 11] = _h_752;
      e.mem[_t_94 + 12] = _h_753;
      WL_CONT = term_tsk(FID_MAIN_K71, _t_94);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_95 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_95 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_95 + 1] = _h_740;
      return term_tsk(FID_STRING_APPEND, _t_95);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_740;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K71)
  {
    WL_POPN(13);
    Term _h_755 = STK(0);
    Term _h_756 = STK(1);
    Term _h_757 = STK(2);
    Term _h_758 = STK(3);
    Term _h_759 = STK(4);
    Term _h_760 = STK(5);
    Term _h_761 = STK(6);
    Term _h_762 = STK(7);
    Term _h_763 = STK(8);
    Term _h_764 = STK(9);
    Term _h_765 = STK(10);
    Term _h_766 = STK(11);
    Term _h_767 = STK(12);
    Term _h_754 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _h_755;
      STK(1) = _h_756;
      STK(2) = _h_757;
      STK(3) = _h_758;
      STK(4) = _h_759;
      STK(5) = _h_760;
      STK(6) = _h_761;
      STK(7) = _h_762;
      STK(8) = _h_763;
      STK(9) = _h_764;
      STK(10) = _h_765;
      STK(11) = _h_766;
      STK(12) = FID_MAIN_K72;
      WL_PUSHN(13);
    } else {
      u64 _t_96 = task_node(e, FID_MAIN_K72, WL_CONT, WL_IDX, 1);
      e.mem[_t_96 + 0] = _h_755;
      e.mem[_t_96 + 1] = _h_756;
      e.mem[_t_96 + 2] = _h_757;
      e.mem[_t_96 + 3] = _h_758;
      e.mem[_t_96 + 4] = _h_759;
      e.mem[_t_96 + 5] = _h_760;
      e.mem[_t_96 + 6] = _h_761;
      e.mem[_t_96 + 7] = _h_762;
      e.mem[_t_96 + 8] = _h_763;
      e.mem[_t_96 + 9] = _h_764;
      e.mem[_t_96 + 10] = _h_765;
      e.mem[_t_96 + 11] = _h_766;
      WL_CONT = term_tsk(FID_MAIN_K72, _t_96);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_97 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_97 + 0] = _h_767;
      e.mem[_t_97 + 1] = _h_754;
      return term_tsk(FID_STRING_APPEND, _t_97);
    }
    r0 = _h_767;
    r1 = _h_754;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K72)
  {
    WL_POPN(12);
    Term _h_769 = STK(0);
    Term _h_770 = STK(1);
    Term _h_771 = STK(2);
    Term _h_772 = STK(3);
    Term _h_773 = STK(4);
    Term _h_774 = STK(5);
    Term _h_775 = STK(6);
    Term _h_776 = STK(7);
    Term _h_777 = STK(8);
    Term _h_778 = STK(9);
    Term _h_779 = STK(10);
    Term _h_780 = STK(11);
    Term _h_768 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _h_769;
      STK(1) = _h_770;
      STK(2) = _h_771;
      STK(3) = _h_772;
      STK(4) = _h_773;
      STK(5) = _h_774;
      STK(6) = _h_775;
      STK(7) = _h_776;
      STK(8) = _h_777;
      STK(9) = _h_778;
      STK(10) = _h_779;
      STK(11) = _h_780;
      STK(12) = FID_MAIN_K73;
      WL_PUSHN(13);
    } else {
      u64 _t_98 = task_node(e, FID_MAIN_K73, WL_CONT, WL_IDX, 1);
      e.mem[_t_98 + 0] = _h_769;
      e.mem[_t_98 + 1] = _h_770;
      e.mem[_t_98 + 2] = _h_771;
      e.mem[_t_98 + 3] = _h_772;
      e.mem[_t_98 + 4] = _h_773;
      e.mem[_t_98 + 5] = _h_774;
      e.mem[_t_98 + 6] = _h_775;
      e.mem[_t_98 + 7] = _h_776;
      e.mem[_t_98 + 8] = _h_777;
      e.mem[_t_98 + 9] = _h_778;
      e.mem[_t_98 + 10] = _h_779;
      e.mem[_t_98 + 11] = _h_780;
      WL_CONT = term_tsk(FID_MAIN_K73, _t_98);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_99 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_99 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_99 + 1] = _h_768;
      return term_tsk(FID_STRING_APPEND, _t_99);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_768;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K73)
  {
    WL_POPN(12);
    Term _h_782 = STK(0);
    Term _h_783 = STK(1);
    Term _h_784 = STK(2);
    Term _h_785 = STK(3);
    Term _h_786 = STK(4);
    Term _h_787 = STK(5);
    Term _h_788 = STK(6);
    Term _h_789 = STK(7);
    Term _h_790 = STK(8);
    Term _h_791 = STK(9);
    Term _h_792 = STK(10);
    Term _h_793 = STK(11);
    Term _h_781 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _h_782;
      STK(1) = _h_783;
      STK(2) = _h_784;
      STK(3) = _h_785;
      STK(4) = _h_786;
      STK(5) = _h_787;
      STK(6) = _h_788;
      STK(7) = _h_789;
      STK(8) = _h_790;
      STK(9) = _h_791;
      STK(10) = _h_792;
      STK(11) = FID_MAIN_K74;
      WL_PUSHN(12);
    } else {
      u64 _t_100 = task_node(e, FID_MAIN_K74, WL_CONT, WL_IDX, 1);
      e.mem[_t_100 + 0] = _h_782;
      e.mem[_t_100 + 1] = _h_783;
      e.mem[_t_100 + 2] = _h_784;
      e.mem[_t_100 + 3] = _h_785;
      e.mem[_t_100 + 4] = _h_786;
      e.mem[_t_100 + 5] = _h_787;
      e.mem[_t_100 + 6] = _h_788;
      e.mem[_t_100 + 7] = _h_789;
      e.mem[_t_100 + 8] = _h_790;
      e.mem[_t_100 + 9] = _h_791;
      e.mem[_t_100 + 10] = _h_792;
      WL_CONT = term_tsk(FID_MAIN_K74, _t_100);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_101 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_101 + 0] = _h_793;
      e.mem[_t_101 + 1] = _h_781;
      return term_tsk(FID_STRING_APPEND, _t_101);
    }
    r0 = _h_793;
    r1 = _h_781;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K74)
  {
    WL_POPN(11);
    Term _h_795 = STK(0);
    Term _h_796 = STK(1);
    Term _h_797 = STK(2);
    Term _h_798 = STK(3);
    Term _h_799 = STK(4);
    Term _h_800 = STK(5);
    Term _h_801 = STK(6);
    Term _h_802 = STK(7);
    Term _h_803 = STK(8);
    Term _h_804 = STK(9);
    Term _h_805 = STK(10);
    Term _h_794 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _h_795;
      STK(1) = _h_796;
      STK(2) = _h_797;
      STK(3) = _h_798;
      STK(4) = _h_799;
      STK(5) = _h_800;
      STK(6) = _h_801;
      STK(7) = _h_802;
      STK(8) = _h_803;
      STK(9) = _h_804;
      STK(10) = _h_805;
      STK(11) = FID_MAIN_K75;
      WL_PUSHN(12);
    } else {
      u64 _t_102 = task_node(e, FID_MAIN_K75, WL_CONT, WL_IDX, 1);
      e.mem[_t_102 + 0] = _h_795;
      e.mem[_t_102 + 1] = _h_796;
      e.mem[_t_102 + 2] = _h_797;
      e.mem[_t_102 + 3] = _h_798;
      e.mem[_t_102 + 4] = _h_799;
      e.mem[_t_102 + 5] = _h_800;
      e.mem[_t_102 + 6] = _h_801;
      e.mem[_t_102 + 7] = _h_802;
      e.mem[_t_102 + 8] = _h_803;
      e.mem[_t_102 + 9] = _h_804;
      e.mem[_t_102 + 10] = _h_805;
      WL_CONT = term_tsk(FID_MAIN_K75, _t_102);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_103 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_103 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_103 + 1] = _h_794;
      return term_tsk(FID_STRING_APPEND, _t_103);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_794;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K75)
  {
    WL_POPN(11);
    Term _h_807 = STK(0);
    Term _h_808 = STK(1);
    Term _h_809 = STK(2);
    Term _h_810 = STK(3);
    Term _h_811 = STK(4);
    Term _h_812 = STK(5);
    Term _h_813 = STK(6);
    Term _h_814 = STK(7);
    Term _h_815 = STK(8);
    Term _h_816 = STK(9);
    Term _h_817 = STK(10);
    Term _h_806 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _h_807;
      STK(1) = _h_808;
      STK(2) = _h_809;
      STK(3) = _h_810;
      STK(4) = _h_811;
      STK(5) = _h_812;
      STK(6) = _h_813;
      STK(7) = _h_814;
      STK(8) = _h_815;
      STK(9) = _h_816;
      STK(10) = FID_MAIN_K76;
      WL_PUSHN(11);
    } else {
      u64 _t_104 = task_node(e, FID_MAIN_K76, WL_CONT, WL_IDX, 1);
      e.mem[_t_104 + 0] = _h_807;
      e.mem[_t_104 + 1] = _h_808;
      e.mem[_t_104 + 2] = _h_809;
      e.mem[_t_104 + 3] = _h_810;
      e.mem[_t_104 + 4] = _h_811;
      e.mem[_t_104 + 5] = _h_812;
      e.mem[_t_104 + 6] = _h_813;
      e.mem[_t_104 + 7] = _h_814;
      e.mem[_t_104 + 8] = _h_815;
      e.mem[_t_104 + 9] = _h_816;
      WL_CONT = term_tsk(FID_MAIN_K76, _t_104);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_105 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_105 + 0] = _h_817;
      e.mem[_t_105 + 1] = _h_806;
      return term_tsk(FID_STRING_APPEND, _t_105);
    }
    r0 = _h_817;
    r1 = _h_806;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K76)
  {
    WL_POPN(10);
    Term _h_819 = STK(0);
    Term _h_820 = STK(1);
    Term _h_821 = STK(2);
    Term _h_822 = STK(3);
    Term _h_823 = STK(4);
    Term _h_824 = STK(5);
    Term _h_825 = STK(6);
    Term _h_826 = STK(7);
    Term _h_827 = STK(8);
    Term _h_828 = STK(9);
    Term _h_818 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _h_819;
      STK(1) = _h_820;
      STK(2) = _h_821;
      STK(3) = _h_822;
      STK(4) = _h_823;
      STK(5) = _h_824;
      STK(6) = _h_825;
      STK(7) = _h_826;
      STK(8) = _h_827;
      STK(9) = _h_828;
      STK(10) = FID_MAIN_K77;
      WL_PUSHN(11);
    } else {
      u64 _t_106 = task_node(e, FID_MAIN_K77, WL_CONT, WL_IDX, 1);
      e.mem[_t_106 + 0] = _h_819;
      e.mem[_t_106 + 1] = _h_820;
      e.mem[_t_106 + 2] = _h_821;
      e.mem[_t_106 + 3] = _h_822;
      e.mem[_t_106 + 4] = _h_823;
      e.mem[_t_106 + 5] = _h_824;
      e.mem[_t_106 + 6] = _h_825;
      e.mem[_t_106 + 7] = _h_826;
      e.mem[_t_106 + 8] = _h_827;
      e.mem[_t_106 + 9] = _h_828;
      WL_CONT = term_tsk(FID_MAIN_K77, _t_106);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_107 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_107 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_107 + 1] = _h_818;
      return term_tsk(FID_STRING_APPEND, _t_107);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_818;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K77)
  {
    WL_POPN(10);
    Term _h_830 = STK(0);
    Term _h_831 = STK(1);
    Term _h_832 = STK(2);
    Term _h_833 = STK(3);
    Term _h_834 = STK(4);
    Term _h_835 = STK(5);
    Term _h_836 = STK(6);
    Term _h_837 = STK(7);
    Term _h_838 = STK(8);
    Term _h_839 = STK(9);
    Term _h_829 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _h_830;
      STK(1) = _h_831;
      STK(2) = _h_832;
      STK(3) = _h_833;
      STK(4) = _h_834;
      STK(5) = _h_835;
      STK(6) = _h_836;
      STK(7) = _h_837;
      STK(8) = _h_838;
      STK(9) = FID_MAIN_K78;
      WL_PUSHN(10);
    } else {
      u64 _t_108 = task_node(e, FID_MAIN_K78, WL_CONT, WL_IDX, 1);
      e.mem[_t_108 + 0] = _h_830;
      e.mem[_t_108 + 1] = _h_831;
      e.mem[_t_108 + 2] = _h_832;
      e.mem[_t_108 + 3] = _h_833;
      e.mem[_t_108 + 4] = _h_834;
      e.mem[_t_108 + 5] = _h_835;
      e.mem[_t_108 + 6] = _h_836;
      e.mem[_t_108 + 7] = _h_837;
      e.mem[_t_108 + 8] = _h_838;
      WL_CONT = term_tsk(FID_MAIN_K78, _t_108);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_109 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_109 + 0] = _h_839;
      e.mem[_t_109 + 1] = _h_829;
      return term_tsk(FID_STRING_APPEND, _t_109);
    }
    r0 = _h_839;
    r1 = _h_829;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K78)
  {
    WL_POPN(9);
    Term _h_841 = STK(0);
    Term _h_842 = STK(1);
    Term _h_843 = STK(2);
    Term _h_844 = STK(3);
    Term _h_845 = STK(4);
    Term _h_846 = STK(5);
    Term _h_847 = STK(6);
    Term _h_848 = STK(7);
    Term _h_849 = STK(8);
    Term _h_840 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _h_841;
      STK(1) = _h_842;
      STK(2) = _h_843;
      STK(3) = _h_844;
      STK(4) = _h_845;
      STK(5) = _h_846;
      STK(6) = _h_847;
      STK(7) = _h_848;
      STK(8) = _h_849;
      STK(9) = FID_MAIN_K79;
      WL_PUSHN(10);
    } else {
      u64 _t_110 = task_node(e, FID_MAIN_K79, WL_CONT, WL_IDX, 1);
      e.mem[_t_110 + 0] = _h_841;
      e.mem[_t_110 + 1] = _h_842;
      e.mem[_t_110 + 2] = _h_843;
      e.mem[_t_110 + 3] = _h_844;
      e.mem[_t_110 + 4] = _h_845;
      e.mem[_t_110 + 5] = _h_846;
      e.mem[_t_110 + 6] = _h_847;
      e.mem[_t_110 + 7] = _h_848;
      e.mem[_t_110 + 8] = _h_849;
      WL_CONT = term_tsk(FID_MAIN_K79, _t_110);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_111 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_111 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_111 + 1] = _h_840;
      return term_tsk(FID_STRING_APPEND, _t_111);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_840;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K79)
  {
    WL_POPN(9);
    Term _h_851 = STK(0);
    Term _h_852 = STK(1);
    Term _h_853 = STK(2);
    Term _h_854 = STK(3);
    Term _h_855 = STK(4);
    Term _h_856 = STK(5);
    Term _h_857 = STK(6);
    Term _h_858 = STK(7);
    Term _h_859 = STK(8);
    Term _h_850 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(9);
      STK(0) = _h_851;
      STK(1) = _h_852;
      STK(2) = _h_853;
      STK(3) = _h_854;
      STK(4) = _h_855;
      STK(5) = _h_856;
      STK(6) = _h_857;
      STK(7) = _h_858;
      STK(8) = FID_MAIN_K80;
      WL_PUSHN(9);
    } else {
      u64 _t_112 = task_node(e, FID_MAIN_K80, WL_CONT, WL_IDX, 1);
      e.mem[_t_112 + 0] = _h_851;
      e.mem[_t_112 + 1] = _h_852;
      e.mem[_t_112 + 2] = _h_853;
      e.mem[_t_112 + 3] = _h_854;
      e.mem[_t_112 + 4] = _h_855;
      e.mem[_t_112 + 5] = _h_856;
      e.mem[_t_112 + 6] = _h_857;
      e.mem[_t_112 + 7] = _h_858;
      WL_CONT = term_tsk(FID_MAIN_K80, _t_112);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_113 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_113 + 0] = _h_859;
      e.mem[_t_113 + 1] = _h_850;
      return term_tsk(FID_STRING_APPEND, _t_113);
    }
    r0 = _h_859;
    r1 = _h_850;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K80)
  {
    WL_POPN(8);
    Term _h_861 = STK(0);
    Term _h_862 = STK(1);
    Term _h_863 = STK(2);
    Term _h_864 = STK(3);
    Term _h_865 = STK(4);
    Term _h_866 = STK(5);
    Term _h_867 = STK(6);
    Term _h_868 = STK(7);
    Term _h_860 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(9);
      STK(0) = _h_861;
      STK(1) = _h_862;
      STK(2) = _h_863;
      STK(3) = _h_864;
      STK(4) = _h_865;
      STK(5) = _h_866;
      STK(6) = _h_867;
      STK(7) = _h_868;
      STK(8) = FID_MAIN_K81;
      WL_PUSHN(9);
    } else {
      u64 _t_114 = task_node(e, FID_MAIN_K81, WL_CONT, WL_IDX, 1);
      e.mem[_t_114 + 0] = _h_861;
      e.mem[_t_114 + 1] = _h_862;
      e.mem[_t_114 + 2] = _h_863;
      e.mem[_t_114 + 3] = _h_864;
      e.mem[_t_114 + 4] = _h_865;
      e.mem[_t_114 + 5] = _h_866;
      e.mem[_t_114 + 6] = _h_867;
      e.mem[_t_114 + 7] = _h_868;
      WL_CONT = term_tsk(FID_MAIN_K81, _t_114);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_115 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_115 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_115 + 1] = _h_860;
      return term_tsk(FID_STRING_APPEND, _t_115);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_860;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K81)
  {
    WL_POPN(8);
    Term _h_870 = STK(0);
    Term _h_871 = STK(1);
    Term _h_872 = STK(2);
    Term _h_873 = STK(3);
    Term _h_874 = STK(4);
    Term _h_875 = STK(5);
    Term _h_876 = STK(6);
    Term _h_877 = STK(7);
    Term _h_869 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _h_870;
      STK(1) = _h_871;
      STK(2) = _h_872;
      STK(3) = _h_873;
      STK(4) = _h_874;
      STK(5) = _h_875;
      STK(6) = _h_876;
      STK(7) = FID_MAIN_K82;
      WL_PUSHN(8);
    } else {
      u64 _t_116 = task_node(e, FID_MAIN_K82, WL_CONT, WL_IDX, 1);
      e.mem[_t_116 + 0] = _h_870;
      e.mem[_t_116 + 1] = _h_871;
      e.mem[_t_116 + 2] = _h_872;
      e.mem[_t_116 + 3] = _h_873;
      e.mem[_t_116 + 4] = _h_874;
      e.mem[_t_116 + 5] = _h_875;
      e.mem[_t_116 + 6] = _h_876;
      WL_CONT = term_tsk(FID_MAIN_K82, _t_116);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_117 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_117 + 0] = _h_877;
      e.mem[_t_117 + 1] = _h_869;
      return term_tsk(FID_STRING_APPEND, _t_117);
    }
    r0 = _h_877;
    r1 = _h_869;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K82)
  {
    WL_POPN(7);
    Term _h_879 = STK(0);
    Term _h_880 = STK(1);
    Term _h_881 = STK(2);
    Term _h_882 = STK(3);
    Term _h_883 = STK(4);
    Term _h_884 = STK(5);
    Term _h_885 = STK(6);
    Term _h_878 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _h_879;
      STK(1) = _h_880;
      STK(2) = _h_881;
      STK(3) = _h_882;
      STK(4) = _h_883;
      STK(5) = _h_884;
      STK(6) = _h_885;
      STK(7) = FID_MAIN_K83;
      WL_PUSHN(8);
    } else {
      u64 _t_118 = task_node(e, FID_MAIN_K83, WL_CONT, WL_IDX, 1);
      e.mem[_t_118 + 0] = _h_879;
      e.mem[_t_118 + 1] = _h_880;
      e.mem[_t_118 + 2] = _h_881;
      e.mem[_t_118 + 3] = _h_882;
      e.mem[_t_118 + 4] = _h_883;
      e.mem[_t_118 + 5] = _h_884;
      e.mem[_t_118 + 6] = _h_885;
      WL_CONT = term_tsk(FID_MAIN_K83, _t_118);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_119 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_119 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_119 + 1] = _h_878;
      return term_tsk(FID_STRING_APPEND, _t_119);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_878;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K83)
  {
    WL_POPN(7);
    Term _h_887 = STK(0);
    Term _h_888 = STK(1);
    Term _h_889 = STK(2);
    Term _h_890 = STK(3);
    Term _h_891 = STK(4);
    Term _h_892 = STK(5);
    Term _h_893 = STK(6);
    Term _h_886 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _h_887;
      STK(1) = _h_888;
      STK(2) = _h_889;
      STK(3) = _h_890;
      STK(4) = _h_891;
      STK(5) = _h_892;
      STK(6) = FID_MAIN_K84;
      WL_PUSHN(7);
    } else {
      u64 _t_120 = task_node(e, FID_MAIN_K84, WL_CONT, WL_IDX, 1);
      e.mem[_t_120 + 0] = _h_887;
      e.mem[_t_120 + 1] = _h_888;
      e.mem[_t_120 + 2] = _h_889;
      e.mem[_t_120 + 3] = _h_890;
      e.mem[_t_120 + 4] = _h_891;
      e.mem[_t_120 + 5] = _h_892;
      WL_CONT = term_tsk(FID_MAIN_K84, _t_120);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_121 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_121 + 0] = _h_893;
      e.mem[_t_121 + 1] = _h_886;
      return term_tsk(FID_STRING_APPEND, _t_121);
    }
    r0 = _h_893;
    r1 = _h_886;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K84)
  {
    WL_POPN(6);
    Term _h_895 = STK(0);
    Term _h_896 = STK(1);
    Term _h_897 = STK(2);
    Term _h_898 = STK(3);
    Term _h_899 = STK(4);
    Term _h_900 = STK(5);
    Term _h_894 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _h_895;
      STK(1) = _h_896;
      STK(2) = _h_897;
      STK(3) = _h_898;
      STK(4) = _h_899;
      STK(5) = _h_900;
      STK(6) = FID_MAIN_K85;
      WL_PUSHN(7);
    } else {
      u64 _t_122 = task_node(e, FID_MAIN_K85, WL_CONT, WL_IDX, 1);
      e.mem[_t_122 + 0] = _h_895;
      e.mem[_t_122 + 1] = _h_896;
      e.mem[_t_122 + 2] = _h_897;
      e.mem[_t_122 + 3] = _h_898;
      e.mem[_t_122 + 4] = _h_899;
      e.mem[_t_122 + 5] = _h_900;
      WL_CONT = term_tsk(FID_MAIN_K85, _t_122);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_123 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_123 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_123 + 1] = _h_894;
      return term_tsk(FID_STRING_APPEND, _t_123);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_894;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K85)
  {
    WL_POPN(6);
    Term _h_902 = STK(0);
    Term _h_903 = STK(1);
    Term _h_904 = STK(2);
    Term _h_905 = STK(3);
    Term _h_906 = STK(4);
    Term _h_907 = STK(5);
    Term _h_901 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _h_902;
      STK(1) = _h_903;
      STK(2) = _h_904;
      STK(3) = _h_905;
      STK(4) = _h_906;
      STK(5) = FID_MAIN_K86;
      WL_PUSHN(6);
    } else {
      u64 _t_124 = task_node(e, FID_MAIN_K86, WL_CONT, WL_IDX, 1);
      e.mem[_t_124 + 0] = _h_902;
      e.mem[_t_124 + 1] = _h_903;
      e.mem[_t_124 + 2] = _h_904;
      e.mem[_t_124 + 3] = _h_905;
      e.mem[_t_124 + 4] = _h_906;
      WL_CONT = term_tsk(FID_MAIN_K86, _t_124);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_125 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_125 + 0] = _h_907;
      e.mem[_t_125 + 1] = _h_901;
      return term_tsk(FID_STRING_APPEND, _t_125);
    }
    r0 = _h_907;
    r1 = _h_901;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K86)
  {
    WL_POPN(5);
    Term _h_909 = STK(0);
    Term _h_910 = STK(1);
    Term _h_911 = STK(2);
    Term _h_912 = STK(3);
    Term _h_913 = STK(4);
    Term _h_908 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _h_909;
      STK(1) = _h_910;
      STK(2) = _h_911;
      STK(3) = _h_912;
      STK(4) = _h_913;
      STK(5) = FID_MAIN_K87;
      WL_PUSHN(6);
    } else {
      u64 _t_126 = task_node(e, FID_MAIN_K87, WL_CONT, WL_IDX, 1);
      e.mem[_t_126 + 0] = _h_909;
      e.mem[_t_126 + 1] = _h_910;
      e.mem[_t_126 + 2] = _h_911;
      e.mem[_t_126 + 3] = _h_912;
      e.mem[_t_126 + 4] = _h_913;
      WL_CONT = term_tsk(FID_MAIN_K87, _t_126);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_127 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_127 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_127 + 1] = _h_908;
      return term_tsk(FID_STRING_APPEND, _t_127);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_908;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K87)
  {
    WL_POPN(5);
    Term _h_915 = STK(0);
    Term _h_916 = STK(1);
    Term _h_917 = STK(2);
    Term _h_918 = STK(3);
    Term _h_919 = STK(4);
    Term _h_914 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_915;
      STK(1) = _h_916;
      STK(2) = _h_917;
      STK(3) = _h_918;
      STK(4) = FID_MAIN_K88;
      WL_PUSHN(5);
    } else {
      u64 _t_128 = task_node(e, FID_MAIN_K88, WL_CONT, WL_IDX, 1);
      e.mem[_t_128 + 0] = _h_915;
      e.mem[_t_128 + 1] = _h_916;
      e.mem[_t_128 + 2] = _h_917;
      e.mem[_t_128 + 3] = _h_918;
      WL_CONT = term_tsk(FID_MAIN_K88, _t_128);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_129 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_129 + 0] = _h_919;
      e.mem[_t_129 + 1] = _h_914;
      return term_tsk(FID_STRING_APPEND, _t_129);
    }
    r0 = _h_919;
    r1 = _h_914;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K88)
  {
    WL_POPN(4);
    Term _h_921 = STK(0);
    Term _h_922 = STK(1);
    Term _h_923 = STK(2);
    Term _h_924 = STK(3);
    Term _h_920 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_921;
      STK(1) = _h_922;
      STK(2) = _h_923;
      STK(3) = _h_924;
      STK(4) = FID_MAIN_K89;
      WL_PUSHN(5);
    } else {
      u64 _t_130 = task_node(e, FID_MAIN_K89, WL_CONT, WL_IDX, 1);
      e.mem[_t_130 + 0] = _h_921;
      e.mem[_t_130 + 1] = _h_922;
      e.mem[_t_130 + 2] = _h_923;
      e.mem[_t_130 + 3] = _h_924;
      WL_CONT = term_tsk(FID_MAIN_K89, _t_130);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_131 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_131 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_131 + 1] = _h_920;
      return term_tsk(FID_STRING_APPEND, _t_131);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_920;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K89)
  {
    WL_POPN(4);
    Term _h_926 = STK(0);
    Term _h_927 = STK(1);
    Term _h_928 = STK(2);
    Term _h_929 = STK(3);
    Term _h_925 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_926;
      STK(1) = _h_927;
      STK(2) = _h_928;
      STK(3) = FID_MAIN_K90;
      WL_PUSHN(4);
    } else {
      u64 _t_132 = task_node(e, FID_MAIN_K90, WL_CONT, WL_IDX, 1);
      e.mem[_t_132 + 0] = _h_926;
      e.mem[_t_132 + 1] = _h_927;
      e.mem[_t_132 + 2] = _h_928;
      WL_CONT = term_tsk(FID_MAIN_K90, _t_132);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_133 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_133 + 0] = _h_929;
      e.mem[_t_133 + 1] = _h_925;
      return term_tsk(FID_STRING_APPEND, _t_133);
    }
    r0 = _h_929;
    r1 = _h_925;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K90)
  {
    WL_POPN(3);
    Term _h_931 = STK(0);
    Term _h_932 = STK(1);
    Term _h_933 = STK(2);
    Term _h_930 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_931;
      STK(1) = _h_932;
      STK(2) = _h_933;
      STK(3) = FID_MAIN_K91;
      WL_PUSHN(4);
    } else {
      u64 _t_134 = task_node(e, FID_MAIN_K91, WL_CONT, WL_IDX, 1);
      e.mem[_t_134 + 0] = _h_931;
      e.mem[_t_134 + 1] = _h_932;
      e.mem[_t_134 + 2] = _h_933;
      WL_CONT = term_tsk(FID_MAIN_K91, _t_134);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_135 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_135 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_135 + 1] = _h_930;
      return term_tsk(FID_STRING_APPEND, _t_135);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_930;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K91)
  {
    WL_POPN(3);
    Term _h_935 = STK(0);
    Term _h_936 = STK(1);
    Term _h_937 = STK(2);
    Term _h_934 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_935;
      STK(1) = _h_936;
      STK(2) = FID_MAIN_K92;
      WL_PUSHN(3);
    } else {
      u64 _t_136 = task_node(e, FID_MAIN_K92, WL_CONT, WL_IDX, 1);
      e.mem[_t_136 + 0] = _h_935;
      e.mem[_t_136 + 1] = _h_936;
      WL_CONT = term_tsk(FID_MAIN_K92, _t_136);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_137 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_137 + 0] = _h_937;
      e.mem[_t_137 + 1] = _h_934;
      return term_tsk(FID_STRING_APPEND, _t_137);
    }
    r0 = _h_937;
    r1 = _h_934;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K92)
  {
    WL_POPN(2);
    Term _h_939 = STK(0);
    Term _h_940 = STK(1);
    Term _h_938 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_939;
      STK(1) = _h_940;
      STK(2) = FID_MAIN_K93;
      WL_PUSHN(3);
    } else {
      u64 _t_138 = task_node(e, FID_MAIN_K93, WL_CONT, WL_IDX, 1);
      e.mem[_t_138 + 0] = _h_939;
      e.mem[_t_138 + 1] = _h_940;
      WL_CONT = term_tsk(FID_MAIN_K93, _t_138);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_139 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_139 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_139 + 1] = _h_938;
      return term_tsk(FID_STRING_APPEND, _t_139);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_938;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K93)
  {
    WL_POPN(2);
    Term _h_942 = STK(0);
    Term _h_943 = STK(1);
    Term _h_941 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_942;
      STK(1) = FID_MAIN_K94;
      WL_PUSHN(2);
    } else {
      u64 _t_140 = task_node(e, FID_MAIN_K94, WL_CONT, WL_IDX, 1);
      e.mem[_t_140 + 0] = _h_942;
      WL_CONT = term_tsk(FID_MAIN_K94, _t_140);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_141 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_141 + 0] = _h_943;
      e.mem[_t_141 + 1] = _h_941;
      return term_tsk(FID_STRING_APPEND, _t_141);
    }
    r0 = _h_943;
    r1 = _h_941;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K94)
  {
    WL_POPN(1);
    Term _h_945 = STK(0);
    Term _h_944 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_945;
      STK(1) = FID_MAIN_K95;
      WL_PUSHN(2);
    } else {
      u64 _t_142 = task_node(e, FID_MAIN_K95, WL_CONT, WL_IDX, 1);
      e.mem[_t_142 + 0] = _h_945;
      WL_CONT = term_tsk(FID_MAIN_K95, _t_142);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_143 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_143 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_143 + 1] = _h_944;
      return term_tsk(FID_STRING_APPEND, _t_143);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_944;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K95)
  {
    WL_POPN(1);
    Term _h_947 = STK(0);
    Term _h_946 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K96;
      WL_PUSHN(1);
    } else {
      u64 _t_144 = task_node(e, FID_MAIN_K96, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K96, _t_144);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_145 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_145 + 0] = _h_947;
      e.mem[_t_145 + 1] = _h_946;
      return term_tsk(FID_STRING_APPEND, _t_145);
    }
    r0 = _h_947;
    r1 = _h_946;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K96)
  {
    Term _h_948 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _h_948;
    r0 = term_clo(FID_IO_PRINT, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_PRINT)
  {
    Term _text_4 = r0;
    Term _k_4 = r1;
    WL_OPEN
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = _text_4;
    e.mem[_nd_4 + 1] = _k_4;
    r0 = term_ctr(CID_IO_PRINT, _nd_4);
    WL_RETN(1);
  }}
#endif

  WL_CASE(FID_ENTER)
  {
    Term t = r0;
    WL_OPEN
    u32 f   = (u32)term_aux(t);
    u64 a   = term_loc(t);
    u32 war = fid_arity(f);
    WL_FRAME(t)
    seq |= fid_nofk(f) << 1;
    u32 rw = fid_resw(f);
    if (rw) {
      WL_LOAD(a + war - rw, rw)
      WL_ARGS(a, war - rw + 1)
    } else {
      WL_LOAD(a, war)
    }
    heap_free(e, cls_fit(war + 2), a);
    WL_DYN(f);
  }}

  WL_CASE(FID_IO_EMIT)
  {
    Term x = r0;
    WL_OPEN
    u64 l = heap_alloc(e, 0);
    e.mem[l] = x;
    r0 = term_ctr(CID_EMIT, l);
    WL_RETN(1);
  }}

  WL_CASE(FID_CLO_APPLY)
  {
    Term fun = r0;
    Term arg = r1;
    WL_OPEN
    u32 f    = (u32)term_aux(fun);
    u32 war  = fid_arity(f) - 1;
    u64 a    = term_loc(fun);
    WL_LOAD(a, war)
    spare_free(e, cls_fit(war), a);
    WL_LAST(arg)
    WL_DYN(f);
  }}

  WL_CASE(FID_EXIT)
  {
    u32  n = rn;
    Term rv[WL_RESW];
    WL_SAVE(rv)
    WL_OPEN
    if (err_seen(e.mem)) {
      return 0;
    }
    sp -= 2 * LANE_STEP;
    Term cont = STK(0);
    u32  idx  = (u32)STK(1);
    u32  wf   = (u32)term_aux(cont);
    if (cont != TERM_HOLE && fid_resw(wf)) {
      u64 wa = term_loc(cont);
      u32 wn = fid_arity(wf);
      WL_FRAME(cont)
      seq = (seq & 1) | fid_nofk(wf) << 1;
      WL_ARGS(wa, wn - n + 1)
      heap_free(e, cls_fit(wn + 2), wa);
      WL_TAKE(rv)
      WL_DYN(wf);
    }
    return task_deliver(e.mem, cont, idx, rv, n);
  }}

#if DEVICE
  default: {
    err_post(e.mem, ERR_FIDS);
    return 0;
  }
  }
  }
}
#endif

// Monk
// ====

// One turn on a ring: its head task below put0 runs (a growing
// lane skips a fork-free one). The host grows a row ring by
// ring and drains a ring; a device lane does both.
INLINE u32 monk_step(Env e, DEV Term* stk, u32 rg, u32 put0, u32 base, u32 stride,
  TG u32* cur) {
  DEV u64* H   = e.mem;
  bool     seq = stride == 0;
  DEV u32* get = ring_get(H, rg);
  if (*get == put0) {
    return 0;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, rg, *get);
  u32      hi = a32_load_acq(lo + 1);
  Term     t  = (((u64)hi << 32) | a32_load(lo)) & ~RFC_BIT;
  if ((hi >> 31) != ring_lap(*get) || (!seq && fid_nofk((u32)term_aux(t)))) {
    return 0;
  }
  a32_store(get, *get + 1);
  u32 spin = 0;
  for (;;) {
    Term r = work_loop(e, stk, t, seq);
    if (r == 0) {
      return 2;
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      if (err_spun(H, &spin)) {
        return 2;
      }
      if (stride != 0 && fid_nofk((u32)term_aux(r))) {
        ring_push(H, ring_pick(base, stride, cur), r);
        return 2;
      }
      t      = r;
      seq    = false;
      stride = 0;
      continue;
    }
    task_deal(H, r, base, stride, cur);
    return 1;
  }
}

// Dev
// ===

// One kernel: pass 0 grows the frontier, pass 1 drains each lane's ring,
// pass 2 packs the banks: in one group, each bank's [top, wr) slides onto
// rd, CUBE_T entries a step (loads, barrier, stores: rd <= top), off the
// host's pages. A grow pass ends when its group is full or nothing grew,
// so a spine of forks unrolls whole. TG_HOLD words of threadgroup memory
// hold one group per Apple core (bitonic 1.35x without).

#if DEVICE

INLINE void dev_cut(Env e) {
  if (err_seen(e.mem)) {
    return;
  }
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    u64 gen = (u64)KEEP(c) << c;
    while (ALC_LEN(e, c) >= gen) {
      u64 head = ALC_AT(e, c);
      u64 tail = head;
      for (u32 i = 1; i < KEEP(c); i += 1) {
        tail = e.mem[tail];
      }
      ALC_AT(e, c)    = e.mem[tail];
      ALC_LEN(e, c)  -= gen;
      e.mem[tail]     = 0;
      bank_push(e.mem, c, head);
    }
  }
}

INLINE void bank_pack(DEV u64* H, u32 lane) {
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    DEV Bank* b  = bank_at(H, c);
    u32       rd = b->rd;
    u32       n  = b->wr - b->top;
    for (u32 i = 0; i < n; i += CUBE_T) {
      Term v = i + lane < n ? H[b->off + b->top + i + lane] : 0;
      BAR();
      if (i + lane < n) {
        H[b->off + rd + i + lane] = v;
      }
    }
    BAR();
    if (lane == 0) {
      b->rd = b->wr = b->top = rd + n;
    }
  }
}

#ifdef __METAL_VERSION__
kernel void bend_dev(DEV u64* H [[buffer(0)]], constant u32& pass [[buffer(1)]],
  TG u32* vote [[threadgroup(0)]],
  u32 grids [[threadgroups_per_grid]],
  u32 row [[threadgroup_position_in_grid]],
  u32 lane [[thread_position_in_threadgroup]]) {
#else
extern "C" __global__ void bend_dev(DEV u64* H, u32 pass) {
  extern __shared__ u32 vote[];
  u32 grids = gridDim.x;
  u32 row   = blockIdx.x;
  u32 lane  = threadIdx.x;
#endif
  if (pass == 2) {
    bank_pack(H, lane);
    return;
  }
  u32  stride = grids == 1 ? CUBE_G : 1;
  u32  me     = row * CUBE_T + stride * lane;
  u32 rg     = pass ? ring_flip(me) : me;
  Env  e      = { H, H + ALC_OFF + me };
  DEV Term*  stk    = (DEV Term*)(H + STAK_OFF + me);
  if (lane == 0) {
    for (u32 i = 0; i < 3; i += 1) {
      a32_store(vote + i, 0);
    }
  }
  BAR();
  u32 put0      = a32_load(ring_put(H, rg));
  u32 seen_has  = 0;
  u32 seen_grew = 0;
  for (;;) {
    if (pass) {
      if (*ring_get(H, rg) == put0 || err_seen(H)) {
        break;
      }
    } else {
      put0 = a32_load(ring_put(H, rg));
      u32 has = put0 != a32_load(ring_get(H, rg));
      if (lane == 0 && (err_seen(H) || root_done(H))) {
        has = CUBE_T;
      }
      a32_add(vote + 2, has);
      BAR();
      has = a32_load(vote + 2);
      if (has - seen_has >= CUBE_T) {
        break;
      }
      seen_has = has;
    }
    u32 ran = monk_step(e, stk, rg, put0, row * CUBE_T, pass ? 0 : stride,
      vote);
    if (!pass) {
      if (ran == 1) {
        a32_add(vote + 1, 1);
      }
      BARD();
      u32 grew = a32_load(vote + 1);
      if (grew == seen_grew) {
        break;
      }
      seen_grew = grew;
    }
  }
  dev_cut(e);
}

#endif

// Window
// ======

// Linux's window fill (the Mac's is window_msl): an Image is a quadtree over
// 2^k x 2^k (Qua splits tl, tr, bl, br; Pix is 0xRRGGBB).
#if defined(__linux__) || defined(BEND_RTC)

INLINE u32 window_pix(DEV u64* H, Term t, u32 k, u32 x, u32 y) {
  for (u32 i = k; term_tag(t) == TAG_CTR;) {
    u32 j = 0;
    if (i > 0) {
      i -= 1;
      j = ((y >> i) & 1) * 2 + ((x >> i) & 1);
    }
    t = H[term_peek(H, t) + j];
  }
  return (u32)term_loc(t) & 0xFFFFFF;
}

#ifdef BEND_RTC
extern "C" __global__ void window_dev(DEV u64* H, Term root, u32 w, u32 h,
  u32 k, u32* out) {
  u32 x = blockIdx.x * blockDim.x + threadIdx.x;
  u32 y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x < w && y < h) {
    out[y * w + x] = window_pix(H, root, k, x, y);
  }
}
#endif

#endif

#if !DEVICE

// Row
// ===

static u32 row_grow(Env e, DEV Term* stk, u32 base, u32 stride, u32 want) {
  u64* H = e.mem;
  u32 cur = 0;
  for (;;) {
    u32 put0[CUBE_T];
    u32 has = 0;
    for (u32 i = 0; i < CUBE_T; i += 1) {
      put0[i] = *ring_put(H, base + i * stride);
      has += put0[i] != *ring_get(H, base + i * stride);
    }
    if (root_done(H) || has >= want) {
      return cur;
    }
    u32 grew = 0;
    u32 ran  = 0;
    for (u32 i = 0; i < CUBE_T && ran != 2; i += 1) {
      ran   = monk_step(e, stk, base + i * stride, put0[i], base, stride,
        &cur);
      grew += ran == 1;
    }
    if (grew == 0) {
      return cur;
    }
  }
}

// Pool
// ====

static void* pool_try(void* at, u64 bytes) {
  return mmap(at, bytes, PROT_READ | PROT_WRITE,
    MAP_PRIVATE | MAP_ANON | MAP_NORESERVE, -1, 0);
}

static void* pool_mmap(u64 bytes) {
  void* p = pool_try(NULL, bytes);
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static Term* pool_stack(void) {
  u64   len = 1ull << 31;
  char* p   = pool_mmap(len + 16384 + SIGSTKSZ);
  if (mprotect(p + len, 16384, PROT_NONE) != 0) {
    err_fail("stack guard failed");
  }
  stack_t ss = { .ss_sp = p + len + 16384, .ss_size = SIGSTKSZ };
  sigaltstack(&ss, NULL);
  struct sigaction sa = { .sa_handler = err_trap, .sa_flags = SA_ONSTACK };
  sigaction(SIGSEGV, &sa, NULL);
  sigaction(SIGBUS, &sa, NULL);
  return (Term*)p;
}

// A wait yields a while before it sleeps, so a turn that ends (or follows)
// within microseconds never pays a condvar wake.

#define POOL_WAIT(c, cv) \
  for (u32 s = 0; s < 128 && (c); s += 1) { \
    sched_yield(); \
  } \
  pthread_mutex_lock(&pool_lock); \
  while (c) { \
    pthread_cond_wait(&cv, &pool_lock); \
  } \
  pthread_mutex_unlock(&pool_lock);

static u32 pool_step(u32 rows) {
  u32 per = rows * CUBE_T / (32 * pool_size);
  return CUBE_T >> (31 - CLZ(per < LINE ? per | 1 : LINE));
}

static u32 pool_rows(Env e, DEV Term* stk) {
  u32 n = 0;
  for (;;) {
    u32 c    = a32_add(&pool_row, 1);
    u32 r    = c & 32767;
    u32 rows = c >> 15 & 255;
    u32 step = c >> 23 & 1 ? 1 : pool_step(rows);
    if (r >= rows * step) {
      if (n != 0 && a32_sub_rel(&pool_done, n) == n) {
        pthread_mutex_lock(&pool_lock);
        pthread_cond_signal(&pool_join);
        pthread_mutex_unlock(&pool_lock);
      }
      return c >> 24;
    }
    a32_acq(&pool_row);
    if (c >> 23 & 1) {
      row_grow(e, stk, r * CUBE_T, 1, CUBE_T);
    } else {
      u32 row = r / step * CUBE_T;
      for (u32 rg = row + r % step; rg < row + CUBE_T; rg += step) {
        u32 put0 = a32_load(ring_put(e.mem, rg));
        while (*ring_get(e.mem, rg) != put0 && !err_seen(e.mem)) {
          monk_step(e, stk, rg, put0, rg, 0, NULL);
        }
      }
    }
    n += 1;
  }
}

static void* pool_work(void* arg) {
  Term* stk  = pool_stack();
  u32   seen = 0;
  for (;;) {
    POOL_WAIT(a32_load(&pool_row) >> 24 == seen, pool_wake)
    seen = pool_rows((Env){ CORPUS, ALC[(uintptr_t)arg] }, stk);
  }
}

OUTLINE void pool_open(void) {
  static bool up;
  if (up) {
    return;
  }
  up = true;
  for (u32 w = 1; w < pool_size; w += 1) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, pool_work, (void*)(uintptr_t)w)) {
      err_fail("pthread_create");
    }
  }
}

static int cpu_read(const char* path, long* a, long* b) {
  FILE* f = fopen(path, "r");
  if (f == NULL) {
    return 0;
  }
  int n = fscanf(f, "%ld %ld", a, b);
  fclose(f);
  return n;
}

static long cpu_count(void) {
  long n = sysconf(_SC_NPROCESSORS_ONLN);
#ifdef __linux__
  cpu_set_t set;
  if (sched_getaffinity(0, sizeof set, &set) == 0) {
    n = CPU_COUNT(&set);
  }
  long q = 0;
  long p = 0;
  if (cpu_read("/sys/fs/cgroup/cpu.max", &q, &p) != 2) {
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_quota_us", &q, &p);
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_period_us", &p, &p);
  }
  if (q > 0 && p > 0 && (q + p - 1) / p < n) {
    n = (q + p - 1) / p;
  }
#endif
  return n;
}

OUTLINE void pool_turn(bool grow, u32 rows) {
  static u32 turn;
  u32 n = rows < CUBE_G ? rows : CUBE_G;
  turn += 1;
  a32_store(&pool_done, grow ? n : n * pool_step(n));
  pthread_mutex_lock(&pool_lock);
  a32_store_rel(&pool_row, turn << 24 | grow << 23 | n << 15);
  pthread_cond_broadcast(&pool_wake);
  pthread_mutex_unlock(&pool_lock);
  pool_rows((Env){ CORPUS, ALC[0] }, io_stk);
  POOL_WAIT(a32_load_acq(&pool_done) != 0, pool_join)
}

// Gpu
// ===

// gpu_make compiles the device program into <binary>.gpu
// (--gpu-build): Metal's binary archive, or CUDA's cubin behind a
// hash of the text. A launch loads it, else notes and compiles. CUDA
// shapes the bag by the device: a group of 128 lanes per 64 KB of
// L2, a power of two in 16..128 (Apple keeps the tuned 128). CUDA
// runs one stream: the default 8 cost about half of the startup.

static const char* gpu_path(void) {
  static char path[4096];
  u32 n = sizeof path - 8;
#ifdef __APPLE__
  _NSGetExecutablePath(path, &n);
#else
  path[readlink("/proc/self/exe", path, n)] = 0;
#endif
  return strcat(path, ".gpu");
}

static void gpu_note(const char* path) {
  fprintf(stderr, "bend: compiling the GPU program (%s is missing or"
    " stale)\n", path);
}

#if !BEND_CUDA
#define gpu_map pool_mmap
#endif

#if BEND_METAL || BEND_CUDA

static void gpu_kernel(u32 pass, u32 groups);

static void gpu_run(u32 f) {
  if (f < CUBE_T) {
    gpu_kernel(0, 1);
  }
  if (f < LANES) {
    gpu_kernel(0, CUBE_G);
  }
  gpu_kernel(1, CUBE_G);
  gpu_kernel(2, 1);
}

#endif

#if BEND_CUDA

static u64 gpu_hash(void) {
  u64 key = 14695981039346656037ull ^ CUBE_LOG;
  for (const char* p = BEND_SRC; *p != 0; p += 1) {
    key = (key ^ (u8)*p) * 1099511628211ull;
  }
  return key;
}

#endif

#if BEND_METAL

static void gpu_fail(NSError* err) {
  err_fail([[err localizedDescription] UTF8String]);
}

static bool gpu_probe(void) {
  return (gpu_dev = MTLCreateSystemDefaultDevice()) != nil;
}

static MTLComputePipelineDescriptor* gpu_desc(void) {
  NSError* err = nil;
  MTLCompileOptions* opts = [MTLCompileOptions new];
  opts.mathMode = MTLMathModeSafe;
  opts.preprocessorMacros = @{ @"CUBE_LOG": @(CUBE_LOG) };
  id<MTLLibrary> lib = [gpu_dev newLibraryWithSource:@(BEND_SRC) options:opts
    error:&err];
  if (!lib) {
    gpu_fail(err);
  }
  MTLComputePipelineDescriptor* d = [MTLComputePipelineDescriptor new];
  d.computeFunction = [lib newFunctionWithName:@"bend_dev"];
  return d;
}

static bool gpu_make(const char* path) {
  NSError* err = nil;
  id<MTLBinaryArchive> ar = [gpu_dev
    newBinaryArchiveWithDescriptor:[MTLBinaryArchiveDescriptor new] error:&err];
  if (![ar addComputePipelineFunctionsWithDescriptor:gpu_desc() error:&err]) {
    gpu_fail(err);
  }
  return [ar serializeToURL:[NSURL fileURLWithPath:@(path)] error:&err];
}

static id<MTLComputePipelineState> gpu_pipe(MTLComputePipelineDescriptor* d,
  id<MTLBinaryArchive> ar) {
  NSError* err = nil;
  d.binaryArchives = ar ? @[ar] : @[];
  id<MTLComputePipelineState> pso = [gpu_dev
    newComputePipelineStateWithDescriptor:d
    options:ar ? MTLPipelineOptionFailOnBinaryArchiveMiss : 0 reflection:nil
    error:&err];
  if (!pso && !ar) {
    gpu_fail(err);
  }
  return pso;
}

static u64 gpu_span(void) {
  u64 span = [gpu_dev recommendedMaxWorkingSetSize];
  u64 most = [gpu_dev maxBufferLength];
  span = span < most ? span : most;
  return span < (2ull << 30) ? span : 2ull << 30;
}

static void gpu_load(u64 bytes) {
  gpu_buf = [gpu_dev newBufferWithBytesNoCopy:CORPUS length:bytes
    options:MTLResourceStorageModeShared
      | MTLResourceHazardTrackingModeUntracked deallocator:nil];
  u64 most = [gpu_dev maxBufferLength];
  if (!gpu_buf && bytes > most) {
    char msg[96];
    snprintf(msg, sizeof msg, "--gpu %lluMB is over the device's %lluMB",
      (unsigned long long)(bytes >> 20), (unsigned long long)(most >> 20));
    err_fail(msg);
  }
  if (!gpu_buf) {
    err_fail("the GPU span is more than the device has");
  }
  @autoreleasepool {
    gpu_que = [gpu_dev newCommandQueue];
    const char* path = gpu_path();
    MTLBinaryArchiveDescriptor* ad = [MTLBinaryArchiveDescriptor new];
    ad.url = [NSURL fileURLWithPath:@(path)];
    MTLComputePipelineDescriptor* d = gpu_desc();
    id<MTLBinaryArchive> ar = [gpu_dev newBinaryArchiveWithDescriptor:ad
      error:nil];
    gpu_pso = ar ? gpu_pipe(d, ar) : nil;
    if (!gpu_pso) {
      gpu_note(path);
      gpu_pso = gpu_pipe(d, nil);
    }
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  [gpu_enc setComputePipelineState:gpu_pso];
  [gpu_enc setBuffer:gpu_buf offset:0 atIndex:0];
  [gpu_enc setBytes:&pass length:sizeof pass atIndex:1];
  [gpu_enc setThreadgroupMemoryLength:TG_HOLD * 8 atIndex:0];
  [gpu_enc dispatchThreadgroups:MTLSizeMake(groups, 1, 1)
    threadsPerThreadgroup:MTLSizeMake(CUBE_T, 1, 1)];
  [gpu_enc memoryBarrierWithScope:MTLBarrierScopeBuffers];
}

static void gpu_pass(u32 f) {
  @autoreleasepool {
    id<MTLCommandBuffer> cb = [gpu_que commandBuffer];
    gpu_enc = [cb computeCommandEncoder];
    gpu_run(f);
    [gpu_enc endEncoding];
    [cb commit];
    [cb waitUntilCompleted];
    if ([cb error]) {
      gpu_fail([cb error]);
    }
  }
}

#elif BEND_CUDA

static void gpu_shape(int units) {
  CUBE_LOG = 31 - CLZ(units < 16 ? 16 : units > 128 ? 128 : units);
}

static bool gpu_probe(void) {
  int       managed = 0;
  CUcontext ctx;
  setenv("CUDA_DEVICE_MAX_CONNECTIONS", "1", 0);
  if (cuInit(0) == CUDA_SUCCESS && cuDeviceGet(&gpu_dev, 0) == CUDA_SUCCESS) {
    cuDeviceGetAttribute(&managed,
      CU_DEVICE_ATTRIBUTE_CONCURRENT_MANAGED_ACCESS, gpu_dev);
  }
  int l2 = 1 << 23;
  cuDeviceGetAttribute(&l2, CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE, gpu_dev);
  gpu_shape(l2 >> 16);
  return managed != 0
    && cuDevicePrimaryCtxRetain(&ctx, gpu_dev) == CUDA_SUCCESS
    && cuCtxSetCurrent(ctx) == CUDA_SUCCESS;
}

static u64* gpu_map(u64 bytes) {
  CUdeviceptr p = 0;
  if (cuMemAllocManaged(&p, bytes, CU_MEM_ATTACH_GLOBAL) != CUDA_SUCCESS) {
    err_fail("corpus reservation failed");
  }
#if CUDA_VERSION >= 13000
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION,
    (CUmemLocation){ CU_MEM_LOCATION_TYPE_DEVICE, gpu_dev });
#else
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION, gpu_dev);
#endif
  return (u64*)(uintptr_t)p;
}

static bool gpu_make(const char* path) {
  int cc[2] = {0, 0};
  cuDeviceGetAttribute(cc,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR, gpu_dev);
  cuDeviceGetAttribute(cc + 1,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR, gpu_dev);
  char arch[40];
  char bag[24];
  snprintf(arch, sizeof arch, "--gpu-architecture=sm_%d%d", cc[0], cc[1]);
  snprintf(bag, sizeof bag, "-DCUBE_LOG=%u", CUBE_LOG);
  const char* opts[] = { arch, bag, "--fmad=false", "-default-device" };
  nvrtcProgram prog;
  if (nvrtcCreateProgram(&prog, BEND_SRC, "bend.cu", 0, NULL, NULL)
    != NVRTC_SUCCESS) {
    err_fail("cannot compile the CUDA library");
  }
  if (nvrtcCompileProgram(prog, 4, opts) != NVRTC_SUCCESS) {
    size_t n = 0;
    nvrtcGetProgramLogSize(prog, &n);
    char* log = calloc(n + 1, 1);
    if (log != NULL && nvrtcGetProgramLog(prog, log) == NVRTC_SUCCESS) {
      fprintf(stderr, "%s\n", log);
    }
    err_fail("cannot compile the CUDA library");
  }
  size_t len = 0;
  nvrtcGetCUBINSize(prog, &len);
  char* bin = malloc(len);
  if (bin == NULL || nvrtcGetCUBIN(prog, bin) != NVRTC_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  nvrtcDestroyProgram(&prog);
  u64   key = gpu_hash();
  FILE* out = path == NULL ? NULL : fopen(path, "wb");
  bool  ok  = out != NULL && fwrite(&key, 8, 1, out) == 1
    && fwrite(bin, 1, len, out) == len && fclose(out) == 0;
  if (cuModuleLoadData(&gpu_lib, bin) != CUDA_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  free(bin);
  return path == NULL || ok;
}

static u64 gpu_span(void) {
  size_t span = 0;
  cuDeviceTotalMem(&span, gpu_dev);
  return span;
}

static void gpu_load(u64 bytes) {
  const char* path = gpu_path();
  int         fd   = open(path, O_RDONLY);
  struct stat st   = { 0 };
  u64         key  = 0;
  char*       bin  = fd < 0 || fstat(fd, &st) != 0 || st.st_size <= 8 ? NULL
    : mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
  if (bin != NULL && bin != MAP_FAILED) {
    memcpy(&key, bin, 8);
  }
  if (key != gpu_hash()
    || cuModuleLoadData(&gpu_lib, bin + 8) != CUDA_SUCCESS) {
    gpu_note(path);
    gpu_make(path);
  }
  if (cuModuleGetFunction(&gpu_pso, gpu_lib, "bend_dev") != CUDA_SUCCESS) {
    err_fail("cannot load the GPU program");
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  void* args[] = { &CORPUS, &pass };
  if (cuLaunchKernel(gpu_pso, groups, 1, 1, CUBE_T, 1, 1, TG_HOLD * 8, NULL,
    args, NULL) != CUDA_SUCCESS) {
    err_fail("device launch failed");
  }
}

static void gpu_pass(u32 f) {
  gpu_run(f);
  if (cuCtxSynchronize() != CUDA_SUCCESS) {
    err_fail("device fault");
  }
}

#else

#define gpu_probe() false
#define gpu_make(p) true
#define gpu_span()  0
#define gpu_load(b)
#define gpu_pass(f)

#endif

// Cube
// ====

// The host's column grows to the rows that give a LINE of tasks a thread,
// no more: every task a grow starts early is live at once (tree-matmul's
// 2048 at 16 threads start 384 rounds: 15 MB -> 68 MB), and pool_step
// splits the few rows finely instead. A turn visits only the rows below
// its bound: a drain deals task g to ring_flip(g), whose row is at most g,
// a row grows into itself, and a column grow's cur tasks land in rows 0
// to cur - 1, so those rows hold every task.

// Between turns, each ring's pending tasks move back to slot 0.

static void ring_rewind(u64* H, u32 rows) {
  Term keep[RING_LEN];
  for (u32 r = 0; r < (rows < CUBE_G ? rows : CUBE_G) * CUBE_T; r += 1) {
    u32 g = *ring_get(H, r);
    u32 n = *ring_put(H, r) - g;
    if (g == 0 || n > RING_LEN) {
      continue;
    }
    for (u32 i = 0; i < n; i += 1) {
      keep[i] = *ring_slot(H, r, g + i) & ~RFC_BIT;
    }
    for (u32 i = n; i < g + n && i < RING_LEN; i += 1) {
      ((u32*)ring_slot(H, r, i))[1] = 0;
    }
    *ring_get(H, r) = *ring_put(H, r) = 0;
    for (u32 i = 0; i < n; i += 1) {
      ring_push(H, r, keep[i]);
    }
  }
}

static void cube_run(u64* H, bool gpu) {
  for (;;) {
    u32 f = a32_exch(a32_at(H, H_CURSOR), 0);
    if (root_done(H)) {
      return;
    }
    if (f == 0) {
      err_fail("frontier drained without a result");
    }
    if (gpu) {
      gpu_pass(f);
    } else {
      u32 rows = f;
      u32 want = (pool_size - 1) / (CUBE_T / LINE) + 1;
      if (f < want) {
        u32 cur = row_grow((Env){ H, ALC[0] }, io_stk, 0, CUBE_G, want);
        rows = cur > f ? cur : f;
      }
      if (f < CUBE) {
        pool_turn(true, rows);
      }
      f = a32_load(a32_at(H, H_CURSOR));
      pool_turn(false, f > rows ? f : rows);
      f = a32_load(a32_at(H, H_CURSOR));
      ring_rewind(H, f > rows ? f : rows);
    }
    u32 ec = a32_load(a32_at(H, H_ERROR_CODE));
    if (ec != 0) {
      err_post(H, ec);
    }
  }
}

// Corpus
// ======

// The cores map 8 GiB at a high base and double it in place, so one
// base holds every location; the banks move up past the pages. The GPU maps
// its whole span at once, and never grows it.

static u64 corpus_size;

static void* corpus_map(u64 size) {
  u64   hint = 1ull << 45;
  void* p    = pool_try((void*)hint, size);
  while (p != (void*)hint && hint > size) {
    if (p != MAP_FAILED) {
      munmap(p, size);
    }
    hint /= 2;
    p     = pool_try((void*)hint, size);
  }
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static void corpus_lay(u64* H, u64 size) {
  u64 span = size / 8;
  u64 cap  = span > HEAP_OFF ? (span - HEAP_OFF) / (PAGE_LEN + 10) : 0;
  if (cap <= CUBE) {
    err_fail("the GPU span is under the rings, stacks and a page per lane");
  }
  cap = cap < ~0u ? cap : ~0u - 1;
  u64 at = HEAP_OFF + (cap << PAGE_BITS);
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    Bank* b = bank_at(H, c);
    memcpy(H + at, H + b->off, b->wr * sizeof(u64));
    b->off  = at;
    at     += 2 * (cap >> ((c < NCLS ? NCLS : c) - PAGE_BITS));
  }
  corpus_size = size;
  a32_store_rel(a32_at(H, H_CAP), (u32)cap);
}

static bool corpus_grow(u64* H, u64 need) {
  bool ok = true;
  LOCK(bank_lock);
  while (ok && need > a32_load(a32_at(H, H_CAP))) {
    u64   more = corpus_size;
    char* at   = (char*)H + more;
    void* got  = io_gpu || more >= 1ull << 43 ? MAP_FAILED
      : pool_try(at, more);
    ok = got == at;
    if (ok) {
      corpus_lay(H, more * 2);
    } else if (got != MAP_FAILED) {
      munmap(got, more);
    }
  }
  UNLOCK(bank_lock);
  return ok;
}

static u64* corpus_setup(bool gpu, long threads, u64 bytes) {
  io_gpu     = gpu;
  KEEP_WORDS = gpu ? CHUNK : CAP_WORDS;
  u64 dflt   = gpu ? gpu_span() : 1ull << 33;
  u64 size   = (gpu && bytes != 0 ? bytes : dflt) & ~16383ull;
  CORPUS     = gpu ? gpu_map(size) : corpus_map(size);
  u64* H     = CORPUS;
#if BEND_CUDA
  if (gpu) {
    cuMemsetD8((CUdeviceptr)(uintptr_t)H, 0, STAK_OFF * 8);
    cuCtxSynchronize();
  }
#endif
  corpus_lay(H, size);
  memcpy(H + STAT_OFF, STAT_IMG, STAT_LEN * sizeof(u64));
  a32_store(a32_at(H, H_BUMP), 1);
  if (gpu) {
    gpu_load(size);
  }
  pool_size = threads < 1 ? 1 : threads < CUBE_T ? threads : CUBE_T;
  return H;
}

OUTLINE Term corpus_eval(u64* H, Term t) {
  Env  e = { H, ALC[0] };
  Term rv[WL_RESW];
  for (;;) {
    Term r = work_loop(e, io_stk, t, !BANGS && pool_size == 1);
    if (r == 0) {
      if (root_done(H)) {
        break;
      }
      err_fail("solo delivery lost");
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      t = r;
      if (io_gpu && fid_bangs((u32)term_aux(t))) {
        u64  tl   = task_tail(t);
        Term cont = H[tl];
        u32  idx  = (u32)(H[tl + 1] >> 32) & 0xFFFF;
        H[tl]     = TERM_HOLE;
        a32_store(a32_at(H, H_CURSOR), 1);
        ring_push(H, 0, t);
        cube_run(H, true);
        Term p = task_deliver(H, cont, idx, rv, root_take(H, rv));
        if (root_done(H)) {
          break;
        }
        if (p == 0) {
          err_fail("seam delivery lost");
        }
        t = p;
      }
      continue;
    }
    task_deal(H, r, 0, 0, NULL);
    pool_open();
    cube_run(H, false);
    break;
  }
  root_take(H, rv);
  return rv[0];
}

// Io
// ==

// Base's opaque, linear handles pack host fds or pointers into aux and loc:
// no forging, copying, reuse or host wrapper. A request's cont applied to
// its item is the next request. A parked request keeps its fd, deadline and
// readiness in word, time and evts; the loop then calls pack: a value
// resumes, IO_PARK parks again. The edge is UTF-8, decoded as WHATWG does: a
// broken sequence yields one U+FFFD and its breaking byte is read again as a
// lead. inet_aton reads a leading zero as octal, so io_sys_addr refuses it.
// macOS poll misses FIFO EOF, so io_wait selects, its sets sized to the
// highest fd (_DARWIN_UNLIMITED_SELECT allows fds past FD_SETSIZE).

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define IO_READ 1
#define IO_TIME 2
#define IO_PARK TERM_HOLE

#define io_hand(v)   term_make(TAG_PAK, (u64)(v) >> 40, (u64)(v) & LOC_MASK)
#define io_hand_v(t) (((u64)term_aux(t) << 40) | term_loc(t))

struct IoWork;
typedef void (*IoCall)(struct IoWork* w);
typedef Term (*IoPack)(Env e, struct IoWork* w);

typedef struct IoWork {
  intptr_t       hand;
  intptr_t       made;
  u32            word;
  u64            size;
  char*          data;
  char*          text;
  u32            code;
  IoCall         call;
  IoPack         pack;
  Term           cont;
  Term           item;
  u64            time;
  short          evts;
  struct IoWork* next;
} IoWork;

typedef Term (*Effect)(Env e, Term* f, IoWork* w);

typedef struct {
  Effect run;
  u32    ask;
} IoEff;

static IoEff io_eff_rows[1 << 16];
static u32   io_live;

static u64 io_tick(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}

OUTLINE void* io_mem(void* mem) {
  if (mem == NULL) {
    err_fail("host allocation failed");
  }
  return mem;
}

static int io_sys_addr(const char* host, u32 port, struct sockaddr_in* at) {
  memset(at, 0, sizeof(*at));
  at->sin_family = AF_INET;
  at->sin_port   = htons((uint16_t)port);
  for (const char* p = host; *p != 0; p += 1) {
    if ((p == host || p[-1] == '.') && *p == '0'
      && p[1] >= '0' && p[1] <= '9') {
      return -1;
    }
  }
  return port > 65535 || inet_pton(AF_INET, host, &at->sin_addr) != 1
    ? -1 : 0;
}

static int    io_argc;
static char** io_argv;

static void io_eff(u32 cid, Effect run, u32 need) {
  if (io_eff_rows[cid].run != NULL) {
    err_fail("two effects register one request");
  }
  io_eff_rows[cid] = (IoEff){ run, need };
}

static u64 io_sys_end(IoWork* w, ssize_t n) {
  w->code = n < 0 ? (u32)errno : 0;
  return n < 0 ? 0 : (u64)n;
}

static IoWork* io_runs;
static IoWork* io_park;
static IoWork* io_jobs;

static void io_push(IoWork** q, IoWork* a) {
  IoWork* l = *q != NULL ? *q : a;
  a->next = l->next;
  l->next = a;
  *q      = a;
}

static IoWork* io_pop(IoWork** q) {
  IoWork* a  = (*q)->next;
  (*q)->next = a->next;
  *q         = a != *q ? *q : NULL;
  return a;
}

static void io_spawn(Term m) {
  IoWork* a = io_mem(calloc(1, sizeof(IoWork)));
  a->cont  = m;
  a->item  = term_clo(FID_IO_EMIT, 0);
  io_push(&io_runs, a);
  io_live += 1;
}

// io_park stays in deadline order (time 0, none, sorts last; ties keep
// their park order), so io_wait wakes due timers in the order they expire.
static void io_park_add(IoWork* w) {
  IoWork* p = io_park;
  if (p == NULL || p->time - 1 <= w->time - 1) {
    io_push(&io_park, w);
    return;
  }
  while (p->next->time - 1 <= w->time - 1) {
    p = p->next;
  }
  io_push(&p, w);
}

static Term io_wait_on(IoWork* w, int fd, short evts, u64 time, IoPack more) {
  w->word = (u32)fd;
  w->pack = more;
  w->time = time;
  w->evts = evts;
  io_park_add(w);
  return IO_PARK;
}

OUTLINE void io_out(FILE* h, const char* data, u64 len) {
  if (fwrite(data, 1, len, h) != len) {
    err_fail("a short write on a standard stream");
  }
}

OUTLINE void io_sync(void) {
  if (fflush(stdout) != 0) {
    err_fail("a short write on a standard stream");
  }
}

static u64 io_utf8(char* buf, u64 c) {
  u64 k = c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
  for (u64 i = k; i > 1; i -= 1) {
    buf[i - 1] = (char)(0x80 | (c & 0x3F));
    c >>= 6;
  }
  buf[0] = (char)(k == 1 ? c : (0xF00 >> k) | c);
  return k;
}

// io_cbuf writes a String (cons SCon) as UTF-8, or a List (cons Con) as
// its bytes, with no UTF-8: NULL if a value is past 255.
OUTLINE char* io_cbuf(Env e, Term s, u64* len, u64 cons) {
  u64   cap = 64;
  u64   n   = 0;
  u64   bad = 0;
  char* buf = io_mem(malloc(cap));
  while (term_aux(s) == cons) {
    Term fb[2];
    spare_free(e, cls_fit(2), ctr_take(e, s, 2, fb));
    if (n + 5 > cap) {
      cap *= 2;
      buf = io_mem(realloc(buf, cap));
    }
    if (cons == CID_SCON) {
      n += io_utf8(buf + n, fb[0]);
    } else {
      bad |= fb[0] > 255;
      buf[n++] = (char)fb[0];
    }
    s = fb[1];
  }
  buf[n] = 0;
  *len = n;
  if (bad) {
    free(buf);
    return NULL;
  }
  return buf;
}

#define io_cstr(e, s, len) io_cbuf(e, s, len, CID_SCON)

OUTLINE void io_errs(Env e, Term s) {
  u64   n    = 0;
  char* text = io_cstr(e, s, &n);
  io_sync();
  io_out(stderr, text, n);
  io_out(stderr, "\n", 1);
  free(text);
}

#define io_nul(s, n) (strlen(s) != (n))

#define io_seal(e, t, cid) (cid_hot(cid) ? rfc_seal(e, t) : (t))

static Term io_node(Env e, u64 cid, Term a, Term b) {
  u64 l = heap_alloc(e, 1);
  e.mem[l]     = io_seal(e, a, cid);
  e.mem[l + 1] = io_seal(e, b, cid);
  return term_ctr(cid, l);
}

static Term io_str(Env e, const char* p, u64 n) {
  Term s    = term_pak(CID_SNIL, 0);
  u64  hole = 0;
  u64  c = 0, need = 0, lo = 0x80, hi = 0xBF;
  for (u64 i = 0; i < n || need > 0; i += 1) {
    u64 b = i < n ? (uint8_t)p[i] : 0x100;
    if (need > 0 && (b < lo || b > hi)) {
      need = 0;
      c    = 0xFFFD;
      i   -= 1;
    } else if (need > 0) {
      lo = 0x80;
      hi = 0xBF;
      c  = (c << 6) | (b & 0x3F);
      if (--need > 0) {
        continue;
      }
    } else if (b < 0x80) {
      c = b;
    } else if (b < 0xC2 || b > 0xF4) {
      c = 0xFFFD;
    } else {
      need = b < 0xE0 ? 1 : b < 0xF0 ? 2 : 3;
      lo   = b == 0xE0 ? 0xA0 : b == 0xF0 ? 0x90 : 0x80;
      hi   = b == 0xED ? 0x9F : b == 0xF4 ? 0x8F : 0xBF;
      c    = b & (0x3F >> need);
      continue;
    }
    u64  l = heap_alloc(e, 1);
    Term t = term_ctr(CID_SCON, l);
    e.mem[l] = c;
    if (hole == 0) {
      s = t;
    } else {
      e.mem[hole] = io_seal(e, t, CID_SCON);
    }
    hole = l + 1;
  }
  if (hole != 0) {
    e.mem[hole] = io_seal(e, term_pak(CID_SNIL, 0), CID_SCON);
  }
  return s;
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8.
#ifdef CID_CON

static Term io_list(Env e, const char* p, u64 n) {
  Term xs = term_pak(CID_NIL, 0);
  for (u64 i = n; i > 0; i -= 1) {
    xs = io_node(e, CID_CON, (uint8_t)p[i - 1], xs);
  }
  return xs;
}

#endif

#define io_tup(e, a, b) io_node(e, CID_TUPLE, a, b)
#define io_done(e, v)   io_box(e, CID_DONE, v)
#define io_res(e, w, v) ((w)->code ? io_fail(e, (w)->code, NULL) \
  : io_done(e, v))

static Term io_box(Env e, u64 cid, Term v) {
  u64 l = heap_alloc(e, 0);
  e.mem[l] = io_seal(e, v, cid);
  return term_ctr(cid, l);
}

static Term io_fail(Env e, u32 code, const char* text) {
  const char* s = text != NULL ? text : strerror((int)code);
  Term t = io_tup(e, code, io_str(e, s, strlen(s)));
  return io_box(e, CID_FAIL, t);
}

static pthread_mutex_t io_gate = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  io_bell = PTHREAD_COND_INITIALIZER;
static u32             io_busy;
static u32             io_size;
static int             io_wake_fd[2];

static void io_take(Env e) {
  IoWork* acts[64];
  ssize_t n;
  while ((n = read(io_wake_fd[0], acts, sizeof acts)) > 0) {
    for (u32 i = 0; i < (u32)n / sizeof(IoWork*); i += 1) {
      IoWork* a = acts[i];
      a->item   = a->pack(e, a);
      io_push(&io_runs, a);
      io_busy -= 1;
    }
  }
}

static void* io_help(void* arg) {
  for (;;) {
    pthread_mutex_lock(&io_gate);
    while (io_jobs == NULL) {
      pthread_cond_wait(&io_bell, &io_gate);
    }
    IoWork* a = io_pop(&io_jobs);
    pthread_mutex_unlock(&io_gate);
    a->call(a);
    while (write(io_wake_fd[1], &a, sizeof a) != sizeof a) {
    }
  }
}

static Term io_work(IoWork* w, IoCall call, IoPack pack) {
  w->call  = call;
  w->pack  = pack;
  io_busy += 1;
  if (io_busy > io_size && io_size < IO_HELP) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, io_help, NULL)) {
      err_fail("pthread_create");
    }
    pthread_detach(tid);
    io_size += 1;
  }
  pthread_mutex_lock(&io_gate);
  io_push(&io_jobs, w);
  pthread_cond_signal(&io_bell);
  pthread_mutex_unlock(&io_gate);
  return IO_PARK;
}

static Term io_exec(Env e, IoWork* w) {
  Term fs[256];
  u32  c = (u32)term_aux(w->cont);
  u32  n = cid_arity(c);
  spare_free(e, cls_fit(n), ctr_take(e, w->cont, n, fs));
  w->cont = fs[n - 1];
  return io_eff_rows[c].run(e, fs, w);
}

static bool io_bit(u8* set, int fd, bool put) {
  u8* at = set + fd / 8;
  *at |= put << fd % 8;
  return *at >> fd % 8 & 1;
}

static void io_wait(Env e, bool block) {
  int top  = io_wake_fd[0];
  u64 soon = io_park != NULL ? io_park->next->time : 0;
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0 && (int)a->word > top) {
      top = (int)a->word;
    }
  }
  u64 len = (u64)top / 64 * 8 + 8;
  u8* set[2] = { io_mem(calloc(2, len)), NULL };
  set[1] = set[0] + len;
  io_bit(set[0], io_wake_fd[0], true);
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0) {
      io_bit(set[a->evts == POLLOUT], (int)a->word, true);
    }
  }
  u64 tick = io_tick();
  u64 ms = soon > tick && block ? (soon - tick) / 1000000 + 1 : 0;
  struct timeval tv = { ms / 1000, ms % 1000 * 1000 };
  io_sync();
  if (select(top + 1, (fd_set*)set[0], (fd_set*)set[1], NULL,
    soon == 0 && block ? NULL : &tv) < 0) {
    if (errno != EINTR) {
      err_fail("the poller failed");
    }
    memset(set[0], 0, 2 * len);
  }
  if (io_bit(set[0], io_wake_fd[0], false)) {
    io_take(e);
  }
  u64     now  = io_tick();
  IoWork* todo = io_park;
  io_park = NULL;
  while (todo != NULL) {
    IoWork* a   = io_pop(&todo);
    bool    due = (a->evts != 0
        && io_bit(set[a->evts == POLLOUT], (int)a->word, false))
      || (a->time != 0 && a->time <= now);
    if (!due) {
      io_park_add(a);
      continue;
    }
    Term x = a->pack(e, a);
    if (x != IO_PARK) {
      a->item = x;
      io_push(&io_runs, a);
    }
  }
  free(set[0]);
}

static int f32_text(char* buf, f32 v) {
  int n = 0;
  int p = 0;
  if (v != v) {
    return sprintf(buf, "nan");
  }
  for (; p < 9; p += 1) {
    n = snprintf(buf, 40, "%.*e", p, (double)v);
    if (strtof(buf, NULL) == v) {
      break;
    }
  }
  char* ep = strchr(buf, 'e');
  if (ep == NULL) {
    return n;
  }
  int ex = atoi(ep + 1);
  if (ex >= 21 || ex <= -7) {
    n = (int)(ep - buf) + sprintf(ep, "e%c%d", ex < 0 ? '-' : '+', abs(ex));
  } else if (ex <= p) {
    n = snprintf(buf, 40, "%.*f", p - ex, (double)v);
  } else {
    int s = *buf == '-';
    memmove(buf + s + 1, buf + s + 2, p);
    memset(buf + s + 1 + p, '0', ex - p);
    n = s + 1 + ex;
  }
  return n;
}

static Term f32_show(Env e, Term x) {
  char buf[40];
  return io_str(e, buf, f32_text(buf, f32_unbox(x)));
}

static Term f32_read(Env e, Term s) {
  u64 n = 0;
  char* text = io_cstr(e, s, &n);
  char* end;
  f32 v = strtof(text, &end);
  Term out = n > 0 && (u64)(end - text) == n && strpbrk(text, "xX(") == NULL
    ? io_box(e, CID_SOME, f32_rewrap(v)) : term_pak(CID_NONE, 0);
  free(text);
  return out;
}


// Show
// ====

// show_val prints a pure main's value as term_show spells it: d
// is a SHOW_DESC node (see show_main), w its words, and chain the
// bracket of the [a, b] or (a, b) the value continues, or 0. Con
// or Nil spell a list, Tuple a tuple, and their tails continue
// it. show_chr escapes as char_show does; show_f32 prints the
// shortest text that reads back, with a point before an e.

#if MAIN_PURE

static void show_val(Env e, u32 d, const Term* w, char chain);

static void show_chr(u64 c, char q) {
  char b[4];
  int  k = c == 10 ? 'n' : c == 9 ? 't' : c == 13 ? 'r' : c == 0 ? '0'
    : c == 92 || c == (u64)q ? (int)c : 0;
  if (k != 0) {
    printf("\\%c", k);
  } else if (c < 32 || c == 127 || (c >= 0xD800 && c <= 0xDFFF)
    || c > 0x10FFFF) {
    printf("\\u{%llx}", (unsigned long long)c);
  } else {
    fwrite(b, 1, io_utf8(b, c), stdout);
  }
}

static void show_f32(u32 x) {
  char  buf[40];
  int   n  = f32_text(buf, f32_unbox(x));
  char* ep = memchr(buf, 'e', n);
  int   m  = ep == NULL ? n : (int)(ep - buf);
  buf[n] = 0;
  if (strpbrk(buf, ".ni") == NULL) {
    printf("%.*s.0%s", m, buf, buf + m);
  } else {
    fputs(buf, stdout);
  }
}

static void show_val(Env e, u32 d, const Term* w, char chain) {
  const u32* D = SHOW_DESC;
  Term one;
  char zs[4];
  u32  zn = 0;
  for (bool tail = true; tail;) switch (tail = false, D[d]) {
    case 0:
      printf("%u", (u32)w[0]);
      break;
    case 1:
      show_f32((u32)w[0]);
      break;
    case 2:
      printf("%llun", (unsigned long long)w[0]);
      break;
    case 3:
      putchar('\'');
      show_chr(D[d + 1] != 0 ? term_loc(w[0]) : w[0], '\'');
      putchar('\'');
      break;
    case 4:
      putchar('"');
      for (Term s = w[0]; term_aux(s) == CID_SCON;) {
        u64 l = term_peek(e.mem, s);
        show_chr(e.mem[l], '"');
        s = e.mem[l + 1];
      }
      putchar('"');
      break;
    case 5:
      fputs("{==}", stdout);
      break;
    case 6:
      putchar('[');
      for (u32 i = 0, g = D[d + 2]; i < 1u << (blk_cls(w[0]) - g); i += 1) {
        Term v[1u << g];
        for (u32 j = 0; j < 1u << g; j += 1) {
          v[j] = blk_read(e.mem, term_tag(w[0]) == TAG_ARR,
            term_peek(e.mem, w[0]), (i << g) + j);
        }
        fputs(i > 0 ? ", " : "", stdout);
        show_val(e, D[d + 1], v, 0);
      }
      putchar(']');
      break;
    default: {
      Term t   = w[0];
      bool box = D[d + 1] != 0;
      u32  key = box ? (u32)term_aux(t) : D[d + 2] > 1 ? (u32)t : 0;
      u32  a   = d + 3;
      for (u32 i = 0; box ? D[a + 1] != key : i != key; i += 1) {
        a += 4 + 2 * D[a + 2];
      }
      if (box) {
        one = term_loc(t);
        w   = term_tag(t) == TAG_PAK ? &one : e.mem + term_peek(e.mem, t);
      }
      char o = "{[("[D[a + 3]];
      if (o == '{') {
        printf("%s{", SHOW_NAMES[D[a]]);
      } else if (chain != o) {
        putchar(o);
      }
      if (o == '{' || chain != o) {
        zs[zn++] = "}])"[D[a + 3]];
      }
      for (u32 j = 0; j < D[a + 2]; j += 1) {
        if (o == '[' ? j == 0 && chain == o : j > 0) {
          fputs(", ", stdout);
        }
        if (j == 1 && o != '{') {
          tail  = true;
          chain = o;
          d     = D[a + 5 + 2 * j];
          w     = w + D[a + 4 + 2 * j];
        } else {
          show_val(e, D[a + 5 + 2 * j], w + D[a + 4 + 2 * j], 0);
        }
      }
    }
  }
  while (zn > 0) {
    putchar(zs[--zn]);
  }
}

#endif

// Run
// ===

static void io_step(Env e, IoWork* a) {
  for (;;) {
    u64  ap  = task_node(e, FID_CLO_APPLY, TERM_HOLE, 0, 0);
    e.mem[ap]     = a->cont;
    e.mem[ap + 1] = a->item;
    Term req = corpus_eval(e.mem, term_tsk(FID_CLO_APPLY, ap));
    u32  c   = (u32)term_aux(req);
    u64  at  = term_peek(e.mem, req);
    if (c == CID_EMIT) {
      term_drop(e, req);
      free(a);
      io_live -= 1;
      return;
    }
    if (c == CID_HALT) {
      io_errs(e, e.mem[at + 1]);
      exit((int)(u32)e.mem[at]);
    }
    if (io_eff_rows[c].run == NULL) {
      err_fail("an alien request");
    }
    u32 need = io_eff_rows[c].ask;
    u32 word = (u32)(need & IO_READ ? io_hand_v(e.mem[at]) : e.mem[at]);
    a->cont  = req;
    if (need != 0) {
      io_wait_on(a, (int)word, need & IO_READ ? POLLIN : 0,
        need & IO_TIME ? io_tick() + (u64)word * 1000000ull : 0, io_exec);
      return;
    }
    Term x = io_exec(e, a);
    if (x == IO_PARK) {
      return;
    }
    a->item = x;
  }
}

OUTLINE void io_loop(u64* H) {
  Env e = { H, ALC[0] };
  io_stk = pool_stack();
  signal(SIGPIPE, SIG_IGN);
  if (pipe(io_wake_fd) | fcntl(io_wake_fd[0], F_SETFL, O_NONBLOCK)) {
    err_fail("the event loop failed to open");
  }
  Term m = corpus_eval(H, term_tsk(MAIN_FID, task_node(e, MAIN_FID,
    TERM_HOLE, 0, 0)));
#if MAIN_PURE
  show_val(e, 0, H + H_ROOT_WORD, 0);
  putchar('\n');
  return;
#endif
  io_spawn(m);
  u64 look = 0;
  for (u32 n = 0;; n += 1) {
    if (io_runs == NULL) {
      if (io_live == 0) {
        return;
      }
      if (io_park == NULL && io_busy == 0) {
        io_sync();
        err_fail("deadlock: every computation waits on a channel");
      }
      io_wait(e, true);
      continue;
    }
    if ((n & 63) == 0 && io_busy != 0) {
      io_take(e);
    }
    // A busy loop still checks due timers, and fds periodically.
    if ((n & 63) == 0 && io_park != NULL) {
      u64 now = io_tick();
      if (now >= look || io_park->next->time - 1 < now) {
        look = now + 10000000;
        io_wait(e, false);
      }
    }
    io_step(e, io_pop(&io_runs));
  }
}

// Requests
// ========

// IO
// ==

Term io_print_run(Env e, Term* f, IoWork* w) {
  uint64_t n = 0;
  char* text = io_cstr(e, f[0], &n);
  io_out(stdout, text, n);
  io_out(stdout, "\n", 1);
  free(text);
  return term_pak(CID_UNIT, 0);
}

static void __attribute__((constructor)) io_print_use(void) {
  io_eff(CID_IO_PRINT, io_print_run, 0);
}


// Main
// ====

int main(int argc, char** argv) {
  long thr = 0;
  int  gpu = -1;
  u64  mem = 0;
  io_argv = argv;
  io_argc = 1;
  for (int i = 1; i < argc; i += 1) {
    const char* a = argv[i];
    const char* v = i + 1 < argc ? argv[i + 1] : NULL;
    if (strcmp(a, "--") == 0) {
      while (i + 1 < argc) {
        io_argv[io_argc++] = argv[++i];
      }
    } else if (strcmp(a, "--bend-help") == 0) {
      printf(CLI_HELP, argv[0]);
      return 0;
    } else if (strcmp(a, "--gpu-build") == 0) {
      if (gpu_probe() && !gpu_make(gpu_path())) {
        fprintf(stderr, "bend: cannot write %s\n", gpu_path());
        return 1;
      }
      return 0;
    } else if (strcmp(a, "--threads") == 0) {
      char* end = NULL;
      thr = v != NULL ? strtol(v, &end, 10) : 0;
      if (thr < 1 || *end != '\0') {
        err_fail("expected a thread count of 1 or more after --threads");
      }
      i += 1;
    } else if (strcmp(a, "--gpu") == 0) {
      char*  end = NULL;
      double n   = v != NULL ? strtod(v, &end) : 0;
      u64    mul = end == NULL ? 0 : strcmp(end, "GB") == 0 ? 1ull << 30
        : strcmp(end, "MB") == 0 ? 1ull << 20 : 0;
      if (v != NULL && strcmp(v, "off") == 0) {
        gpu = 0;
      } else if (v != NULL && (strcmp(v, "on") == 0 || (mul != 0 && n > 0))) {
        gpu = 1;
        mem = (u64)(n * (double)mul);
      } else {
        err_fail("expected on, off or a size like 4GB after --gpu");
      }
      i += 1;
    } else {
      io_argv[io_argc++] = argv[i];
    }
  }
  bool dev = gpu != 0 && BANGS != 0 && gpu_probe();
  if (gpu == 1 && BANGS != 0 && !dev) {
    err_fail("--gpu on, but this binary found no usable GPU (a CUDA GPU needs"
      " concurrent managed access, which WSL2's lack)");
  }
  io_loop(corpus_setup(dev, thr > 0 ? thr : cpu_count(), mem));
  io_sync();
  return 0;
}

#endif
