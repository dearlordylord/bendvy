function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $main$() {
  return $workshop$(($scenario$058run$1261$(($$$$047$$$047$$$047src$047ecs$047world$058factory$()), 64)));
}

function $workshop$(_result_0) {
  if (_result_0.$ === "scenario.ScenarioExecuted") {
    const _factory_0 = _result_0["factory"];
    const _run_0 = _result_0["run"];
    return $workshop_run$(_factory_0, _run_0);
  } else {
    return {$: "InitializationRefused", "schema": "Workshop"};
  }
}

function $scenario$058run$1261$(_factory_0, _capacity_0) {
  return $scenario$058initialized$1261$(($consumer$045start$058initialize$1261$(_factory_0, _capacity_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058factory$() {
  return {$: "../../../src/ecs/world.Factory", "nextNamespace": 1};
}

function $workshop_run$(_factory_0, _run_0) {
  const _phases_0 = _run_0["phases"];
  return $garden$(_phases_0, ($scenario$058run$1260$(_factory_0, 64)));
}

function $scenario$058initialized$1261$(_result_0) {
  if (_result_0.$ === "consumer-start.Initialized") {
    const _factory_0 = _result_0["factory"];
    const _app_0 = _result_0["app"];
    const _readers_0 = _result_0["readers"];
    return {$: "scenario.ScenarioExecuted", "factory": _factory_0, "run": run_loop($scenario$058initial_observed$1261$(_readers_0, ($consumer$045state$058observe$1261$("register-readers", _app_0))))};
  } else {
    return {$: "scenario.ScenarioInitializationRefused", "result": _result_0};
  }
}

function $consumer$045start$058initialize$1261$(_factory_0, _capacity_0) {
  return $consumer$045start$058created$1261$(($runtime$045start$058start$1261$(_factory_0, _capacity_0)));
}

function $garden$(_workshop_0, _result_0) {
  if (_result_0.$ === "scenario.ScenarioExecuted") {
    const _run_0 = _result_0["run"];
    return $garden_run$(_workshop_0, _run_0);
  } else {
    return {$: "InitializationRefused", "schema": "Garden"};
  }
}

function $scenario$058run$1260$(_factory_0, _capacity_0) {
  return $scenario$058initialized$1260$(($consumer$045start$058initialize$1260$(_factory_0, _capacity_0)));
}

function $scenario$058initial_observed$1261$(_result_0, _observed_0) {
  const _app_0 = _observed_0["fst"];
  const _snapshot_0 = _observed_0["snd"];
  return $scenario$058loop$1261$(($scenario$045actions$058commands$({$: "Unit"})), _app_0, {$: "Con", "head": {$: "scenario.Phase", "observation": _snapshot_0, "result": {$: "scenario-actions.ReadersResult", "completion": _result_0}}, "tail": {$: "Nil"}});
}

function $consumer$045state$058observe$1261$(_label_0, _app_0) {
  const _pair_0 = _app_0["readers"];
  const _registries_0 = _app_0["registries"];
  return $consumer$045state$058observe_pair$1261$(_label_0, _registries_0, _pair_0);
}

function $consumer$045start$058created$1261$(_result_0) {
  if (_result_0.$ === "runtime-start.Started") {
    const _factory_0 = _result_0["factory"];
    const _runtime_0 = _result_0["runtime"];
    return $consumer$045start$058registered$1261$(_factory_0, ($$$$047readers$045v1$047pair$058register$1261$(_runtime_0)));
  } else {
    const _factory_1 = _result_0["factory"];
    const _resource_0 = _result_0["resource"];
    return {$: "consumer-start.WorldCreateRefused", "factory": _factory_1, "resource": _resource_0};
  }
}

function $runtime$045start$058start$1261$(_factory_0, _capacity_0) {
  return $runtime$045start$058created$1261$(_capacity_0, ($application$058create$1261$(_factory_0)));
}

function $garden_run$(_workshop_0, _run_0) {
  const _phases_0 = _run_0["phases"];
  return {$: "TwoSchemaReport", "workshop": _workshop_0, "garden": _phases_0};
}

function $scenario$058initialized$1260$(_result_0) {
  if (_result_0.$ === "consumer-start.Initialized") {
    const _factory_0 = _result_0["factory"];
    const _app_0 = _result_0["app"];
    const _readers_0 = _result_0["readers"];
    return {$: "scenario.ScenarioExecuted", "factory": _factory_0, "run": run_loop($scenario$058initial_observed$1260$(_readers_0, ($consumer$045state$058observe$1260$("register-readers", _app_0))))};
  } else {
    return {$: "scenario.ScenarioInitializationRefused", "result": _result_0};
  }
}

function $consumer$045start$058initialize$1260$(_factory_0, _capacity_0) {
  return $consumer$045start$058created$1260$(($runtime$045start$058start$1260$(_factory_0, _capacity_0)));
}

function $scenario$058loop$1261$(_commands_0, _app_0, _trace_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "scenario.ScenarioRun", "app": _app_0, "phases": ($List$reverse$(_trace_0))};
  } else {
    const _head_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $scenario$058command$1261$(_head_0, _app_0, _trace_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $scenario$058loop$1261$(_rest_0, _x_0, _x_1);
});
}));
  }
}

function $scenario$045actions$058commands$(_unit_0) {
  return {$: "Con", "head": {$: "scenario-actions.Command", "label": "queue-spawn", "operation": {$: "scenario-actions.SpawnOperation"}}, "tail": {$: "Con", "head": {$: "scenario-actions.Command", "label": "spawn-barrier", "operation": {$: "scenario-actions.BarrierOperation"}}, "tail": {$: "Con", "head": {$: "scenario-actions.Command", "label": "step-1-damage", "operation": {$: "scenario-actions.GameplayOperation"}}, "tail": {$: "Con", "head": {$: "scenario-actions.Command", "label": "step-1-readers", "operation": {$: "scenario-actions.ReadersOperation", "failB": false}}, "tail": {$: "Con", "head": {$: "scenario-actions.Command", "label": "step-1-barrier", "operation": {$: "scenario-actions.BarrierOperation"}}, "tail": {$: "Con", "head": {$: "scenario-actions.Command", "label": "step-2-damage", "operation": {$: "scenario-actions.GameplayOperation"}}, "tail": {$: "Con", "head": {$: "scenario-actions.Command", "label": "step-2-reader-failure", "operation": {$: "scenario-actions.ReadersOperation", "failB": true}}, "tail": {$: "Con", "head": {$: "scenario-actions.Command", "label": "step-2-reader-retry", "operation": {$: "scenario-actions.RetryReaderBOperation"}}, "tail": {$: "Con", "head": {$: "scenario-actions.Command", "label": "step-2-barrier", "operation": {$: "scenario-actions.BarrierOperation"}}, "tail": {$: "Con", "head": {$: "scenario-actions.Command", "label": "step-3-damage", "operation": {$: "scenario-actions.GameplayOperation"}}, "tail": {$: "Con", "head": {$: "scenario-actions.Command", "label": "step-3-readers", "operation": {$: "scenario-actions.ReadersOperation", "failB": false}}, "tail": {$: "Con", "head": {$: "scenario-actions.Command", "label": "step-3-barrier", "operation": {$: "scenario-actions.BarrierOperation"}}, "tail": {$: "Con", "head": {$: "scenario-actions.Command", "label": "empty-readers", "operation": {$: "scenario-actions.ReadersOperation", "failB": false}}, "tail": {$: "Nil"}}}}}}}}}}}}}};
}

function $consumer$045state$058observe_pair$1261$(_label_0, _registries_0, _pair_0) {
  const _runtime_0 = _pair_0["runtime"];
  const _a_0 = _pair_0["a"];
  const _b_0 = _pair_0["b"];
  const _journalA_0 = _pair_0["journalA"];
  const _journalB_0 = _pair_0["journalB"];
  return $consumer$045state$058observed$1261$(_registries_0, _a_0, _b_0, _journalA_0, _journalB_0, ($runtime$045checkpoint$058observe$1261$(_label_0, _runtime_0)));
}

function $consumer$045start$058registered$1261$(_factory_0, _result_0) {
  if (_result_0.$ === "../readers-v1/pair.Ready") {
    const _t_0 = _result_0["result"];
    const _pair_0 = _t_0["pair"];
    const _a_0 = _t_0["a"];
    const _b_0 = _t_0["b"];
    return {$: "consumer-start.Initialized", "factory": _factory_0, "app": {$: "consumer-state.Application", "readers": _pair_0, "registries": {$: "consumer-state.Registries", "spawn": {$: "None"}, "movement": {$: "None"}, "damage": {$: "None"}}}, "readers": {$: "consumer-state.ReaderResults", "a": _a_0, "b": _b_0}};
  } else if (_result_0.$ === "../readers-v1/pair.ARegistrationFailed") {
    const _runtime_0 = _result_0["runtime"];
    return {$: "consumer-start.ReaderARegisterRefused", "factory": _factory_0, "runtime": _runtime_0};
  } else if (_result_0.$ === "../readers-v1/pair.ARunStopped") {
    const _runtime_1 = _result_0["runtime"];
    const _a_1 = _result_0["a"];
    const _journalA_0 = _result_0["journalA"];
    const _statusA_0 = _result_0["statusA"];
    return {$: "consumer-start.ReaderARunStopped", "factory": _factory_0, "runtime": _runtime_1, "a": _a_1, "journalA": _journalA_0, "statusA": _statusA_0};
  } else {
    const _runtime_2 = _result_0["runtime"];
    const _a_2 = _result_0["a"];
    const _journalA_1 = _result_0["journalA"];
    const _statusA_1 = _result_0["statusA"];
    return {$: "consumer-start.ReaderBRegisterRefused", "factory": _factory_0, "runtime": _runtime_2, "a": _a_2, "journalA": _journalA_1, "statusA": _statusA_1};
  }
}

function $$$$047readers$045v1$047pair$058register$1261$(_runtime_0) {
  return $$$$047readers$045v1$047pair$058registered_a$1261$(($$$$047readers$045v1$047readers$058register$1261$(_runtime_0, "Simulation/ReaderA")));
}

function $runtime$045start$058created$1261$(_capacity_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world.Created") {
    const _factory_0 = _result_0["factory"];
    const _world_0 = _result_0["world"];
    return {$: "runtime-start.Started", "factory": _factory_0, "runtime": ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058start$1261$(_world_0, _capacity_0))};
  } else {
    const _factory_1 = _result_0["factory"];
    const _resource_0 = _result_0["resource"];
    return {$: "runtime-start.StartRefused", "factory": _factory_1, "resource": _resource_0};
  }
}

function $application$058create$1261$(_factory_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058create$1261$(_factory_0, ($spawn$058cell$(0, 900)));
}

function $scenario$058initial_observed$1260$(_result_0, _observed_0) {
  const _app_0 = _observed_0["fst"];
  const _snapshot_0 = _observed_0["snd"];
  return $scenario$058loop$1260$(($scenario$045actions$058commands$({$: "Unit"})), _app_0, {$: "Con", "head": {$: "scenario.Phase", "observation": _snapshot_0, "result": {$: "scenario-actions.ReadersResult", "completion": _result_0}}, "tail": {$: "Nil"}});
}

function $consumer$045state$058observe$1260$(_label_0, _app_0) {
  const _pair_0 = _app_0["readers"];
  const _registries_0 = _app_0["registries"];
  return $consumer$045state$058observe_pair$1260$(_label_0, _registries_0, _pair_0);
}

function $consumer$045start$058created$1260$(_result_0) {
  if (_result_0.$ === "runtime-start.Started") {
    const _factory_0 = _result_0["factory"];
    const _runtime_0 = _result_0["runtime"];
    return $consumer$045start$058registered$1260$(_factory_0, ($$$$047readers$045v1$047pair$058register$1260$(_runtime_0)));
  } else {
    const _factory_1 = _result_0["factory"];
    const _resource_0 = _result_0["resource"];
    return {$: "consumer-start.WorldCreateRefused", "factory": _factory_1, "resource": _resource_0};
  }
}

function $runtime$045start$058start$1260$(_factory_0, _capacity_0) {
  return $runtime$045start$058created$1260$(_capacity_0, ($application$058create$1260$(_factory_0)));
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $scenario$058command$1261$(_command_0, _app_0, _trace_0, _next_0) {
  const _label_0 = _command_0["label"];
  const _operation_0 = _command_0["operation"];
  return $scenario$058executed$1261$(_label_0, _trace_0, _next_0, ($scenario$045actions$058execute$1261$(_operation_0, ($consumer$045barrier$058frame$1261$(_app_0)))));
}

function $consumer$045state$058observed$1261$(_registries_0, _a_0, _b_0, _journalA_0, _journalB_0, _result_0) {
  const _runtime_0 = _result_0["fst"];
  const _snapshot_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "consumer-state.Application", "readers": {$: "../readers-v1/pair.ReaderPair", "runtime": _runtime_0, "a": _a_0, "b": _b_0, "journalA": _journalA_0, "journalB": _journalB_0}, "registries": _registries_0}, "snd": {$: "consumer-state.Observation", "runtime": _snapshot_0, "journalA": _journalA_0, "journalB": _journalB_0}};
}

function $runtime$045checkpoint$058observe$1261$(_label_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $runtime$045checkpoint$058returned$1261$(_namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, ($checkpoint$058observe$1261$(_label_0, _world_0)));
}

function $$$$047readers$045v1$047pair$058registered_a$1261$(_result_0) {
  if (_result_0.$ === "../readers-v1/readers.RegisterFailed") {
    const _runtime_0 = _result_0["runtime"];
    return {$: "../readers-v1/pair.ARegistrationFailed", "runtime": _runtime_0};
  } else {
    const _runtime_1 = _result_0["runtime"];
    const _a_0 = _result_0["owner"];
    return $$$$047readers$045v1$047pair$058initial_a$1261$(($$$$047readers$045v1$047readers$058run$1261$(_runtime_1, _a_0, {$: "../readers-v1/readers.Args", "journal": {$: "Nil"}, "fail": false})));
  }
}

function $$$$047readers$045v1$047readers$058register$1261$(_runtime_0, _name_0) {
  return $$$$047readers$045v1$047readers$058registered$1261$(($$$$047$$$047$$$047src$047ecs$047event$045runtime$058register$1261$(_runtime_0, _name_0, {$: "Con", "head": "event:read", "tail": {$: "Nil"}})));
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058start$1261$(_world_0, _capacity_0) {
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058start_named$1261$(_capacity_0, ($$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058create$1261$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047src$047ecs$047world$058create_checked$1261$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $spawn$058cell$(_value_0, _sentinel_0) {
  return array_node([_value_0], [_sentinel_0]);
}

function $scenario$058loop$1260$(_commands_0, _app_0, _trace_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "scenario.ScenarioRun", "app": _app_0, "phases": ($List$reverse$(_trace_0))};
  } else {
    const _head_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $scenario$058command$1260$(_head_0, _app_0, _trace_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $scenario$058loop$1260$(_rest_0, _x_0, _x_1);
});
}));
  }
}

function $consumer$045state$058observe_pair$1260$(_label_0, _registries_0, _pair_0) {
  const _runtime_0 = _pair_0["runtime"];
  const _a_0 = _pair_0["a"];
  const _b_0 = _pair_0["b"];
  const _journalA_0 = _pair_0["journalA"];
  const _journalB_0 = _pair_0["journalB"];
  return $consumer$045state$058observed$1260$(_registries_0, _a_0, _b_0, _journalA_0, _journalB_0, ($runtime$045checkpoint$058observe$1260$(_label_0, _runtime_0)));
}

function $consumer$045start$058registered$1260$(_factory_0, _result_0) {
  if (_result_0.$ === "../readers-v1/pair.Ready") {
    const _t_0 = _result_0["result"];
    const _pair_0 = _t_0["pair"];
    const _a_0 = _t_0["a"];
    const _b_0 = _t_0["b"];
    return {$: "consumer-start.Initialized", "factory": _factory_0, "app": {$: "consumer-state.Application", "readers": _pair_0, "registries": {$: "consumer-state.Registries", "spawn": {$: "None"}, "movement": {$: "None"}, "damage": {$: "None"}}}, "readers": {$: "consumer-state.ReaderResults", "a": _a_0, "b": _b_0}};
  } else if (_result_0.$ === "../readers-v1/pair.ARegistrationFailed") {
    const _runtime_0 = _result_0["runtime"];
    return {$: "consumer-start.ReaderARegisterRefused", "factory": _factory_0, "runtime": _runtime_0};
  } else if (_result_0.$ === "../readers-v1/pair.ARunStopped") {
    const _runtime_1 = _result_0["runtime"];
    const _a_1 = _result_0["a"];
    const _journalA_0 = _result_0["journalA"];
    const _statusA_0 = _result_0["statusA"];
    return {$: "consumer-start.ReaderARunStopped", "factory": _factory_0, "runtime": _runtime_1, "a": _a_1, "journalA": _journalA_0, "statusA": _statusA_0};
  } else {
    const _runtime_2 = _result_0["runtime"];
    const _a_2 = _result_0["a"];
    const _journalA_1 = _result_0["journalA"];
    const _statusA_1 = _result_0["statusA"];
    return {$: "consumer-start.ReaderBRegisterRefused", "factory": _factory_0, "runtime": _runtime_2, "a": _a_2, "journalA": _journalA_1, "statusA": _statusA_1};
  }
}

function $$$$047readers$045v1$047pair$058register$1260$(_runtime_0) {
  return $$$$047readers$045v1$047pair$058registered_a$1260$(($$$$047readers$045v1$047readers$058register$1260$(_runtime_0, "Simulation/ReaderA")));
}

function $runtime$045start$058created$1260$(_capacity_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world.Created") {
    const _factory_0 = _result_0["factory"];
    const _world_0 = _result_0["world"];
    return {$: "runtime-start.Started", "factory": _factory_0, "runtime": ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058start$1260$(_world_0, _capacity_0))};
  } else {
    const _factory_1 = _result_0["factory"];
    const _resource_0 = _result_0["resource"];
    return {$: "runtime-start.StartRefused", "factory": _factory_1, "resource": _resource_0};
  }
}

function $application$058create$1260$(_factory_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058create$1260$(_factory_0, ($spawn$058cell$(0, 900)));
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $scenario$058executed$1261$(_label_0, _trace_0, _next_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _result_1 = _result_0["snd"];
  return $scenario$058observed$1261$(_result_1, _trace_0, _next_0, ($consumer$045state$058observe$1261$(_label_0, _app_0)));
}

function $scenario$045actions$058execute$1261$(_operation_0, _app_0) {
  if (_operation_0.$ === "scenario-actions.SpawnOperation") {
    return $scenario$045actions$058spawned$1261$(($consumer$045spawn$058run$1261$(_app_0)));
  } else if (_operation_0.$ === "scenario-actions.BarrierOperation") {
    return {$: "Tuple", "fst": ($consumer$045barrier$058barrier$1261$(_app_0)), "snd": {$: "scenario-actions.BarrierResult"}};
  } else if (_operation_0.$ === "scenario-actions.GameplayOperation") {
    return $scenario$045actions$058played$1261$(($consumer$045gameplay$058run$1261$(_app_0, 1, {$: "damage-body.DamageArgs", "goal": 2, "damage": 1})));
  } else if (_operation_0.$ === "scenario-actions.ReadersOperation") {
    const _failB_0 = _operation_0["failB"];
    return $scenario$045actions$058read$1261$(($consumer$045state$058read$1261$(_app_0, _failB_0)));
  } else {
    return $scenario$045actions$058read$1261$(($consumer$045state$058retry_b$1261$(_app_0)));
  }
}

function $consumer$045barrier$058frame$1261$(_app_0) {
  const _pair_0 = _app_0["readers"];
  const _registries_0 = _app_0["registries"];
  return $consumer$045barrier$058frame_pair$1261$(_registries_0, _pair_0);
}

function $runtime$045checkpoint$058returned$1261$(_namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _snapshot_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "snd": {$: "runtime-checkpoint.Snapshot", "world": _snapshot_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}};
}

function $checkpoint$058observe$1261$(_label_0, _world_0) {
  return $checkpoint$058allocation_known$1261$(_label_0, ($world$045view$058allocation$1261$(_world_0)));
}

function $$$$047readers$045v1$047pair$058initial_a$1261$(_result_0) {
  const _runtime_0 = _result_0["runtime"];
  const _a_0 = _result_0["owner"];
  const _outcome_0 = _result_0["completion"];
  return $$$$047readers$045v1$047pair$058initial_completed$1261$(_runtime_0, _a_0, ($$$$047readers$045v1$047pair$058completion$1260$(_outcome_0)));
}

function $$$$047readers$045v1$047readers$058run$1261$(_runtime_0, _owner_0, _args_0) {
  const _reader_0 = _owner_0["reader"];
  const _registry_0 = _owner_0["registry"];
  return $$$$047readers$045v1$047readers$058returned$1261$(($$$$047$$$047$$$047src$047ecs$047event$045runtime$058run$1261$(_runtime_0, _reader_0, _registry_0, _args_0)));
}

function $$$$047readers$045v1$047readers$058registered$1261$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/event-runtime.Registered") {
    const _runtime_0 = _result_0["runtime"];
    const _reader_0 = _result_0["reader"];
    const _registry_0 = _result_0["registry"];
    return {$: "../readers-v1/readers.Registered", "runtime": _runtime_0, "owner": {$: "../readers-v1/readers.Owner", "reader": _reader_0, "registry": _registry_0}};
  } else {
    const _runtime_1 = _result_0["runtime"];
    return {$: "../readers-v1/readers.RegisterFailed", "runtime": _runtime_1};
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058register$1261$(_runtime_0, _name_0, _access_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058registered_result$1261$(($$$$047$$$047$$$047src$047ecs$047system$058register$1267$(_world_0, _name_0, _access_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058start_named$1261$(_capacity_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return {$: "../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": {$: "Nil"}, "positions": {$: "Nil"}, "nextReader": 1, "tick": 0, "frameStart": 0, "boundary": 0, "capacity": _capacity_0, "droppedThrough": 0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058create_checked$1261$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../src/ecs/world.CreateRejected", "factory": {$: "../../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../src/ecs/world.Created", "factory": {$: "../../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($storage$058empty$1261$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $scenario$058command$1260$(_command_0, _app_0, _trace_0, _next_0) {
  const _label_0 = _command_0["label"];
  const _operation_0 = _command_0["operation"];
  return $scenario$058executed$1260$(_label_0, _trace_0, _next_0, ($scenario$045actions$058execute$1260$(_operation_0, ($consumer$045barrier$058frame$1260$(_app_0)))));
}

function $consumer$045state$058observed$1260$(_registries_0, _a_0, _b_0, _journalA_0, _journalB_0, _result_0) {
  const _runtime_0 = _result_0["fst"];
  const _snapshot_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "consumer-state.Application", "readers": {$: "../readers-v1/pair.ReaderPair", "runtime": _runtime_0, "a": _a_0, "b": _b_0, "journalA": _journalA_0, "journalB": _journalB_0}, "registries": _registries_0}, "snd": {$: "consumer-state.Observation", "runtime": _snapshot_0, "journalA": _journalA_0, "journalB": _journalB_0}};
}

function $runtime$045checkpoint$058observe$1260$(_label_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $runtime$045checkpoint$058returned$1260$(_namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, ($checkpoint$058observe$1260$(_label_0, _world_0)));
}

function $$$$047readers$045v1$047pair$058registered_a$1260$(_result_0) {
  if (_result_0.$ === "../readers-v1/readers.RegisterFailed") {
    const _runtime_0 = _result_0["runtime"];
    return {$: "../readers-v1/pair.ARegistrationFailed", "runtime": _runtime_0};
  } else {
    const _runtime_1 = _result_0["runtime"];
    const _a_0 = _result_0["owner"];
    return $$$$047readers$045v1$047pair$058initial_a$1260$(($$$$047readers$045v1$047readers$058run$1260$(_runtime_1, _a_0, {$: "../readers-v1/readers.Args", "journal": {$: "Nil"}, "fail": false})));
  }
}

function $$$$047readers$045v1$047readers$058register$1260$(_runtime_0, _name_0) {
  return $$$$047readers$045v1$047readers$058registered$1260$(($$$$047$$$047$$$047src$047ecs$047event$045runtime$058register$1260$(_runtime_0, _name_0, {$: "Con", "head": "event:read", "tail": {$: "Nil"}})));
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058start$1260$(_world_0, _capacity_0) {
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058start_named$1260$(_capacity_0, ($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $scenario$058observed$1261$(_result_0, _trace_0, _next_0, _observation_0) {
  const _app_0 = _observation_0["fst"];
  const _snapshot_0 = _observation_0["snd"];
  return run_tail(_next_0(_app_0), {$: "Con", "head": {$: "scenario.Phase", "observation": _snapshot_0, "result": _result_0}, "tail": _trace_0});
}

function $scenario$045actions$058spawned$1261$(_observed_0) {
  const _app_0 = _observed_0["fst"];
  const _completion_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _app_0, "snd": {$: "scenario-actions.SpawnResult", "completion": _completion_0}};
}

function $consumer$045spawn$058run$1261$(_app_0) {
  const _pair_0 = _app_0["readers"];
  const _owners_0 = _app_0["registries"];
  return $consumer$045spawn$058paired$1261$(_owners_0, _pair_0);
}

function $consumer$045barrier$058barrier$1261$(_app_0) {
  const _pair_0 = _app_0["readers"];
  const _registries_0 = _app_0["registries"];
  return $consumer$045barrier$058barrier_pair$1261$(_registries_0, _pair_0);
}

function $scenario$045actions$058played$1261$(_observed_0) {
  const _app_0 = _observed_0["fst"];
  const _completion_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _app_0, "snd": {$: "scenario-actions.GameplayResult", "completion": _completion_0}};
}

function $consumer$045gameplay$058run$1261$(_app_0, _fixed_step_0, _args_0) {
  const _pair_0 = _app_0["readers"];
  const _owners_0 = _app_0["registries"];
  return $consumer$045gameplay$058paired$1261$(_owners_0, _fixed_step_0, _args_0, _pair_0);
}

function $scenario$045actions$058read$1261$(_observed_0) {
  const _app_0 = _observed_0["fst"];
  const _completion_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _app_0, "snd": {$: "scenario-actions.ReadersResult", "completion": _completion_0}};
}

function $consumer$045state$058read$1261$(_app_0, _fail_b_0) {
  const _pair_0 = _app_0["readers"];
  const _registries_0 = _app_0["registries"];
  return $consumer$045state$058readers_returned$1261$(_registries_0, ($$$$047readers$045v1$047pair$058run$1261$(_pair_0, _fail_b_0)));
}

function $consumer$045state$058retry_b$1261$(_app_0) {
  const _pair_0 = _app_0["readers"];
  const _registries_0 = _app_0["registries"];
  return $consumer$045state$058readers_returned$1261$(_registries_0, ($$$$047readers$045v1$047pair$058retry_b$1261$(_pair_0)));
}

function $consumer$045barrier$058frame_pair$1261$(_registries_0, _pair_0) {
  const _runtime_0 = _pair_0["runtime"];
  const _a_0 = _pair_0["a"];
  const _b_0 = _pair_0["b"];
  const _journalA_0 = _pair_0["journalA"];
  const _journalB_0 = _pair_0["journalB"];
  return {$: "consumer-state.Application", "readers": {$: "../readers-v1/pair.ReaderPair", "runtime": ($runtime$045spawn$058frame$1261$(_runtime_0)), "a": _a_0, "b": _b_0, "journalA": _journalA_0, "journalB": _journalB_0}, "registries": _registries_0};
}

function $checkpoint$058allocation_known$1261$(_label_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _allocation_0 = _observed_0["snd"];
  return $checkpoint$058resource_known$1261$(_label_0, _allocation_0, ($world$045view$058resource$1261$(_world_0)));
}

function $world$045view$058allocation$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "world-view.Allocation", "nextId": _nextId_0, "highWater": _highWater_0}};
}

function $$$$047readers$045v1$047pair$058initial_completed$1261$(_runtime_0, _a_0, _completed_0) {
  const _journalA_0 = _completed_0["fst"];
  const _statusA_0 = _completed_0["snd"];
  return $$$$047readers$045v1$047pair$058initial_continue$1261$(_statusA_0, _runtime_0, _a_0, _journalA_0);
}

function $$$$047readers$045v1$047pair$058completion$1260$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/event-runtime.Succeeded") {
    const _journal_0 = _result_0["output"];
    return {$: "Tuple", "fst": _journal_0, "snd": {$: "../readers-v1/pair.Succeeded", "journal": _journal_0}};
  } else if (_result_0.$ === "../../../src/ecs/event-runtime.Failed") {
    const _error_0 = _result_0["error"];
    return $$$$047readers$045v1$047pair$058failed_journal$1260$(_error_0);
  } else {
    const _t_0 = _result_0["args"];
    const _journal_1 = _t_0["journal"];
    const _fail_0 = _t_0["fail"];
    return {$: "Tuple", "fst": _journal_1, "snd": {$: "../readers-v1/pair.Rejected", "args": {$: "../readers-v1/readers.Args", "journal": _journal_1, "fail": _fail_0}}};
  }
}

function $$$$047readers$045v1$047readers$058returned$1261$(_result_0) {
  const _runtime_0 = _result_0["runtime"];
  const _reader_0 = _result_0["reader"];
  const _registry_0 = _result_0["registry"];
  const _completion_0 = _result_0["completion"];
  return {$: "../readers-v1/readers.Returned", "runtime": _runtime_0, "owner": {$: "../readers-v1/readers.Owner", "reader": _reader_0, "registry": _registry_0}, "completion": _completion_0};
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run$1261$(_runtime_0, _reader_0, _registry_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_identified$1261$(_runtime_0, _reader_0, ($$$$047$$$047$$$047src$047ecs$047system$058identity$1261$(_registry_0)), _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058registered_result$1261$(_result_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_result_0.$ === "../../../src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../src/ecs/event-runtime.RegisterFailed", "runtime": {$: "../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058registered_identity$1261$(_world_1, ($$$$047$$$047$$$047src$047ecs$047system$058identity$1261$(_registry_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058register$1267$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1267$(($$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $storage$058empty$1261$(_unit_0) {
  return {$: "storage.Store", "position": ($$$$047$$$047$$$047src$047ecs$047column$058empty_indexed$1261$()), "velocity": ($$$$047$$$047$$$047src$047ecs$047column$058empty_indexed$1261$()), "health": ($$$$047$$$047$$$047src$047ecs$047column$058empty_indexed$1261$())};
}

function $scenario$058executed$1260$(_label_0, _trace_0, _next_0, _result_0) {
  const _app_0 = _result_0["fst"];
  const _result_1 = _result_0["snd"];
  return $scenario$058observed$1260$(_result_1, _trace_0, _next_0, ($consumer$045state$058observe$1260$(_label_0, _app_0)));
}

function $scenario$045actions$058execute$1260$(_operation_0, _app_0) {
  if (_operation_0.$ === "scenario-actions.SpawnOperation") {
    return $scenario$045actions$058spawned$1260$(($consumer$045spawn$058run$1260$(_app_0)));
  } else if (_operation_0.$ === "scenario-actions.BarrierOperation") {
    return {$: "Tuple", "fst": ($consumer$045barrier$058barrier$1260$(_app_0)), "snd": {$: "scenario-actions.BarrierResult"}};
  } else if (_operation_0.$ === "scenario-actions.GameplayOperation") {
    return $scenario$045actions$058played$1260$(($consumer$045gameplay$058run$1260$(_app_0, 1, {$: "damage-body.DamageArgs", "goal": 2, "damage": 1})));
  } else if (_operation_0.$ === "scenario-actions.ReadersOperation") {
    const _failB_0 = _operation_0["failB"];
    return $scenario$045actions$058read$1260$(($consumer$045state$058read$1260$(_app_0, _failB_0)));
  } else {
    return $scenario$045actions$058read$1260$(($consumer$045state$058retry_b$1260$(_app_0)));
  }
}

function $consumer$045barrier$058frame$1260$(_app_0) {
  const _pair_0 = _app_0["readers"];
  const _registries_0 = _app_0["registries"];
  return $consumer$045barrier$058frame_pair$1260$(_registries_0, _pair_0);
}

function $runtime$045checkpoint$058returned$1260$(_namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _snapshot_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "snd": {$: "runtime-checkpoint.Snapshot", "world": _snapshot_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}};
}

function $checkpoint$058observe$1260$(_label_0, _world_0) {
  return $checkpoint$058allocation_known$1260$(_label_0, ($world$045view$058allocation$1260$(_world_0)));
}

function $$$$047readers$045v1$047pair$058initial_a$1260$(_result_0) {
  const _runtime_0 = _result_0["runtime"];
  const _a_0 = _result_0["owner"];
  const _outcome_0 = _result_0["completion"];
  return $$$$047readers$045v1$047pair$058initial_completed$1260$(_runtime_0, _a_0, ($$$$047readers$045v1$047pair$058completion$1260$(_outcome_0)));
}

function $$$$047readers$045v1$047readers$058run$1260$(_runtime_0, _owner_0, _args_0) {
  const _reader_0 = _owner_0["reader"];
  const _registry_0 = _owner_0["registry"];
  return $$$$047readers$045v1$047readers$058returned$1260$(($$$$047$$$047$$$047src$047ecs$047event$045runtime$058run$1260$(_runtime_0, _reader_0, _registry_0, _args_0)));
}

function $$$$047readers$045v1$047readers$058registered$1260$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/event-runtime.Registered") {
    const _runtime_0 = _result_0["runtime"];
    const _reader_0 = _result_0["reader"];
    const _registry_0 = _result_0["registry"];
    return {$: "../readers-v1/readers.Registered", "runtime": _runtime_0, "owner": {$: "../readers-v1/readers.Owner", "reader": _reader_0, "registry": _registry_0}};
  } else {
    const _runtime_1 = _result_0["runtime"];
    return {$: "../readers-v1/readers.RegisterFailed", "runtime": _runtime_1};
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058register$1260$(_runtime_0, _name_0, _access_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058registered_result$1260$(($$$$047$$$047$$$047src$047ecs$047system$058register$1263$(_world_0, _name_0, _access_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058start_named$1260$(_capacity_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return {$: "../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": {$: "Nil"}, "positions": {$: "Nil"}, "nextReader": 1, "tick": 0, "frameStart": 0, "boundary": 0, "capacity": _capacity_0, "droppedThrough": 0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../src/ecs/world.CreateRejected", "factory": {$: "../../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../src/ecs/world.Created", "factory": {$: "../../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($storage$058empty$1260$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $consumer$045spawn$058paired$1261$(_owners_0, _pair_0) {
  const _runtime_0 = _pair_0["runtime"];
  const _a_0 = _pair_0["a"];
  const _b_0 = _pair_0["b"];
  const _journalA_0 = _pair_0["journalA"];
  const _journalB_0 = _pair_0["journalB"];
  return $consumer$045spawn$058registries$1261$(_runtime_0, _a_0, _b_0, _journalA_0, _journalB_0, _owners_0);
}

function $consumer$045barrier$058barrier_pair$1261$(_registries_0, _pair_0) {
  const _runtime_0 = _pair_0["runtime"];
  const _a_0 = _pair_0["a"];
  const _b_0 = _pair_0["b"];
  const _journalA_0 = _pair_0["journalA"];
  const _journalB_0 = _pair_0["journalB"];
  return $consumer$045barrier$058returned$1261$(_registries_0, _a_0, _b_0, _journalA_0, _journalB_0, ($runtime$045spawn$058barrier$1261$(_runtime_0)));
}

function $consumer$045gameplay$058paired$1261$(_owners_0, _fixed_step_0, _args_0, _pair_0) {
  const _runtime_0 = _pair_0["runtime"];
  const _a_0 = _pair_0["a"];
  const _b_0 = _pair_0["b"];
  const _journalA_0 = _pair_0["journalA"];
  const _journalB_0 = _pair_0["journalB"];
  return $consumer$045gameplay$058registries$1261$(_runtime_0, _a_0, _b_0, _journalA_0, _journalB_0, _fixed_step_0, _args_0, _owners_0);
}

function $consumer$045state$058readers_returned$1261$(_registries_0, _result_0) {
  const _pair_0 = _result_0["pair"];
  const _a_0 = _result_0["a"];
  const _b_0 = _result_0["b"];
  return {$: "Tuple", "fst": {$: "consumer-state.Application", "readers": _pair_0, "registries": _registries_0}, "snd": {$: "consumer-state.ReaderResults", "a": _a_0, "b": _b_0}};
}

function $$$$047readers$045v1$047pair$058run$1261$(_pair_0, _failB_0) {
  const _runtime_0 = _pair_0["runtime"];
  const _a_0 = _pair_0["a"];
  const _b_0 = _pair_0["b"];
  const _journalA_0 = _pair_0["journalA"];
  const _journalB_0 = _pair_0["journalB"];
  return $$$$047readers$045v1$047pair$058finish_a$1261$(($$$$047readers$045v1$047readers$058run$1261$(_runtime_0, _a_0, {$: "../readers-v1/readers.Args", "journal": _journalA_0, "fail": false})), _b_0, _journalB_0, _failB_0);
}

function $$$$047readers$045v1$047pair$058retry_b$1261$(_pair_0) {
  const _runtime_0 = _pair_0["runtime"];
  const _a_0 = _pair_0["a"];
  const _b_0 = _pair_0["b"];
  const _journalA_0 = _pair_0["journalA"];
  const _journalB_0 = _pair_0["journalB"];
  return $$$$047readers$045v1$047pair$058finish_b$1261$(($$$$047readers$045v1$047readers$058run$1261$(_runtime_0, _b_0, {$: "../readers-v1/readers.Args", "journal": _journalB_0, "fail": false})), _a_0, _journalA_0, {$: "../readers-v1/pair.Skipped"});
}

function $runtime$045spawn$058frame$1261$(_runtime_0) {
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058frame$1261$(_runtime_0);
}

function $checkpoint$058resource_known$1261$(_label_0, _allocation_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _resource_0 = _observed_0["snd"];
  return $checkpoint$058cells_known$1261$(_label_0, _allocation_0, _resource_0, ($world$045view$058allocated$1261$(_world_0)));
}

function $world$045view$058resource$1261$(_world_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058observe_resource$1262$(_world_0);
}

function $$$$047readers$045v1$047pair$058initial_continue$1261$(_statusA_0, _runtime_0, _a_0, _journalA_0) {
  if (_statusA_0.$ === "../readers-v1/pair.Succeeded") {
    const _journal_0 = _statusA_0["journal"];
    return $$$$047readers$045v1$047pair$058registered_b$1261$(($$$$047readers$045v1$047readers$058register$1261$(_runtime_0, "Simulation/ReaderB")), _a_0, _journalA_0, {$: "../readers-v1/pair.Succeeded", "journal": _journal_0});
  } else {
    return {$: "../readers-v1/pair.ARunStopped", "runtime": _runtime_0, "a": _a_0, "journalA": _journalA_0, "statusA": _statusA_0};
  }
}

function $$$$047readers$045v1$047pair$058failed_journal$1260$(_error_0) {
  const _journal_0 = _error_0["journal"];
  return {$: "Tuple", "fst": _journal_0, "snd": {$: "../readers-v1/pair.Failed", "error": {$: "../readers-v1/readers.ReaderFailed", "journal": _journal_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_identified$1261$(_runtime_0, _reader_0, _identified_0, _args_0) {
  const _registry_0 = _identified_0["fst"];
  const _actual_0 = _identified_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_identity$1261$(_runtime_0, _reader_0, _registry_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058identity$1261$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _id_0};
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058registered_identity$1261$(_world_0, _identity_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _registry_0 = _identity_0["fst"];
  const _registryId_0 = _identity_0["snd"];
  return {$: "../../../src/ecs/event-runtime.Registered", "runtime": {$: "../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": ((_nextReader_0 + 1) >>> 0), "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "reader": {$: "../../../src/ecs/event-runtime.Reader", "namespace": _namespace_0, "id": _nextReader_0, "registryId": _registryId_0}, "registry": _registry_0};
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1267$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_join$1267$(($$$$047$$$047$$$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047column$058empty_indexed$1261$() {
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$([{$: "None"}], ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058empty$()));
}

function $scenario$058observed$1260$(_result_0, _trace_0, _next_0, _observation_0) {
  const _app_0 = _observation_0["fst"];
  const _snapshot_0 = _observation_0["snd"];
  return run_tail(_next_0(_app_0), {$: "Con", "head": {$: "scenario.Phase", "observation": _snapshot_0, "result": _result_0}, "tail": _trace_0});
}

function $scenario$045actions$058spawned$1260$(_observed_0) {
  const _app_0 = _observed_0["fst"];
  const _completion_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _app_0, "snd": {$: "scenario-actions.SpawnResult", "completion": _completion_0}};
}

function $consumer$045spawn$058run$1260$(_app_0) {
  const _pair_0 = _app_0["readers"];
  const _owners_0 = _app_0["registries"];
  return $consumer$045spawn$058paired$1260$(_owners_0, _pair_0);
}

function $consumer$045barrier$058barrier$1260$(_app_0) {
  const _pair_0 = _app_0["readers"];
  const _registries_0 = _app_0["registries"];
  return $consumer$045barrier$058barrier_pair$1260$(_registries_0, _pair_0);
}

function $scenario$045actions$058played$1260$(_observed_0) {
  const _app_0 = _observed_0["fst"];
  const _completion_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _app_0, "snd": {$: "scenario-actions.GameplayResult", "completion": _completion_0}};
}

function $consumer$045gameplay$058run$1260$(_app_0, _fixed_step_0, _args_0) {
  const _pair_0 = _app_0["readers"];
  const _owners_0 = _app_0["registries"];
  return $consumer$045gameplay$058paired$1260$(_owners_0, _fixed_step_0, _args_0, _pair_0);
}

function $scenario$045actions$058read$1260$(_observed_0) {
  const _app_0 = _observed_0["fst"];
  const _completion_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _app_0, "snd": {$: "scenario-actions.ReadersResult", "completion": _completion_0}};
}

function $consumer$045state$058read$1260$(_app_0, _fail_b_0) {
  const _pair_0 = _app_0["readers"];
  const _registries_0 = _app_0["registries"];
  return $consumer$045state$058readers_returned$1260$(_registries_0, ($$$$047readers$045v1$047pair$058run$1260$(_pair_0, _fail_b_0)));
}

function $consumer$045state$058retry_b$1260$(_app_0) {
  const _pair_0 = _app_0["readers"];
  const _registries_0 = _app_0["registries"];
  return $consumer$045state$058readers_returned$1260$(_registries_0, ($$$$047readers$045v1$047pair$058retry_b$1260$(_pair_0)));
}

function $consumer$045barrier$058frame_pair$1260$(_registries_0, _pair_0) {
  const _runtime_0 = _pair_0["runtime"];
  const _a_0 = _pair_0["a"];
  const _b_0 = _pair_0["b"];
  const _journalA_0 = _pair_0["journalA"];
  const _journalB_0 = _pair_0["journalB"];
  return {$: "consumer-state.Application", "readers": {$: "../readers-v1/pair.ReaderPair", "runtime": ($runtime$045spawn$058frame$1260$(_runtime_0)), "a": _a_0, "b": _b_0, "journalA": _journalA_0, "journalB": _journalB_0}, "registries": _registries_0};
}

function $checkpoint$058allocation_known$1260$(_label_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _allocation_0 = _observed_0["snd"];
  return $checkpoint$058resource_known$1260$(_label_0, _allocation_0, ($world$045view$058resource$1260$(_world_0)));
}

function $world$045view$058allocation$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "world-view.Allocation", "nextId": _nextId_0, "highWater": _highWater_0}};
}

function $$$$047readers$045v1$047pair$058initial_completed$1260$(_runtime_0, _a_0, _completed_0) {
  const _journalA_0 = _completed_0["fst"];
  const _statusA_0 = _completed_0["snd"];
  return $$$$047readers$045v1$047pair$058initial_continue$1260$(_statusA_0, _runtime_0, _a_0, _journalA_0);
}

function $$$$047readers$045v1$047readers$058returned$1260$(_result_0) {
  const _runtime_0 = _result_0["runtime"];
  const _reader_0 = _result_0["reader"];
  const _registry_0 = _result_0["registry"];
  const _completion_0 = _result_0["completion"];
  return {$: "../readers-v1/readers.Returned", "runtime": _runtime_0, "owner": {$: "../readers-v1/readers.Owner", "reader": _reader_0, "registry": _registry_0}, "completion": _completion_0};
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run$1260$(_runtime_0, _reader_0, _registry_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_identified$1260$(_runtime_0, _reader_0, ($$$$047$$$047$$$047src$047ecs$047system$058identity$1260$(_registry_0)), _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058registered_result$1260$(_result_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_result_0.$ === "../../../src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../src/ecs/event-runtime.RegisterFailed", "runtime": {$: "../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058registered_identity$1260$(_world_1, ($$$$047$$$047$$$047src$047ecs$047system$058identity$1260$(_registry_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058register$1263$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1263$(($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $storage$058empty$1260$(_unit_0) {
  return {$: "storage.Store", "position": ($$$$047$$$047$$$047src$047ecs$047column$058empty_indexed$1260$()), "velocity": ($$$$047$$$047$$$047src$047ecs$047column$058empty_indexed$1260$()), "health": ($$$$047$$$047$$$047src$047ecs$047column$058empty_indexed$1260$())};
}

function $consumer$045spawn$058registries$1261$(_runtime_0, _a_0, _b_0, _journalA_0, _journalB_0, _owners_0) {
  const _spawn_0 = _owners_0["spawn"];
  const _movement_0 = _owners_0["movement"];
  const _damage_0 = _owners_0["damage"];
  return $consumer$045spawn$058selected$1261$(_runtime_0, {$: "consumer-spawn.Context", "a": _a_0, "b": _b_0, "journalA": _journalA_0, "journalB": _journalB_0, "movement": _movement_0, "damage": _damage_0}, _spawn_0);
}

function $consumer$045barrier$058returned$1261$(_registries_0, _a_0, _b_0, _journalA_0, _journalB_0, _observed_0) {
  const _runtime_0 = _observed_0["fst"];
  return {$: "consumer-state.Application", "readers": {$: "../readers-v1/pair.ReaderPair", "runtime": _runtime_0, "a": _a_0, "b": _b_0, "journalA": _journalA_0, "journalB": _journalB_0}, "registries": _registries_0};
}

function $runtime$045spawn$058barrier$1261$(_runtime_0) {
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world$1265$(run_clo((_x_0) => {
  return $runtime$045spawn$058barrier_world$1261$(_x_0);
}), _runtime_0);
}

function $consumer$045gameplay$058registries$1261$(_runtime_0, _a_0, _b_0, _journalA_0, _journalB_0, _fixed_step_0, _args_0, _owners_0) {
  const _spawn_0 = _owners_0["spawn"];
  const _movement_0 = _owners_0["movement"];
  const _damage_0 = _owners_0["damage"];
  return $consumer$045gameplay$058selected$1261$(_runtime_0, {$: "consumer-gameplay.Context", "a": _a_0, "b": _b_0, "journalA": _journalA_0, "journalB": _journalB_0, "spawn": _spawn_0}, _fixed_step_0, _args_0, _movement_0, _damage_0);
}

function $$$$047readers$045v1$047pair$058finish_a$1261$(_result_0, _b_0, _journalB_0, _failB_0) {
  const _runtime_0 = _result_0["runtime"];
  const _a_0 = _result_0["owner"];
  const _outcome_0 = _result_0["completion"];
  return $$$$047readers$045v1$047pair$058join_a$1261$(_runtime_0, _a_0, _b_0, _journalB_0, _failB_0, ($$$$047readers$045v1$047pair$058completion$1260$(_outcome_0)));
}

function $$$$047readers$045v1$047pair$058finish_b$1261$(_result_0, _a_0, _journalA_0, _statusA_0) {
  const _runtime_0 = _result_0["runtime"];
  const _b_0 = _result_0["owner"];
  const _outcome_0 = _result_0["completion"];
  return $$$$047readers$045v1$047pair$058join_b$1261$(_runtime_0, _a_0, _b_0, _journalA_0, _statusA_0, ($$$$047readers$045v1$047pair$058completion$1260$(_outcome_0)));
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058frame$1261$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058trim$1261$({$: "../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _tick_0, "boundary": _frameStart_0, "capacity": _capacity_0, "droppedThrough": _dropped_0});
}

function $checkpoint$058cells_known$1261$(_label_0, _allocation_0, _resource_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _cells_0 = _observed_0["snd"];
  return $checkpoint$058events_known$1261$(_label_0, _allocation_0, _resource_0, _cells_0, ($$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0)));
}

function $world$045view$058allocated$1261$(_world_0) {
  return $world$045view$058allocated_known$1261$(($world$045view$058allocation$1261$(_world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058observe_resource$1262$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058observe_resource_finish$1262$(($owner$045view$058view$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047readers$045v1$047pair$058registered_b$1261$(_result_0, _a_0, _journalA_0, _statusA_0) {
  if (_result_0.$ === "../readers-v1/readers.RegisterFailed") {
    const _runtime_0 = _result_0["runtime"];
    return {$: "../readers-v1/pair.BRegistrationFailed", "runtime": _runtime_0, "a": _a_0, "journalA": _journalA_0, "statusA": _statusA_0};
  } else {
    const _runtime_1 = _result_0["runtime"];
    const _b_0 = _result_0["owner"];
    return {$: "../readers-v1/pair.Ready", "result": ($$$$047readers$045v1$047pair$058finish_b$1261$(($$$$047readers$045v1$047readers$058run$1261$(_runtime_1, _b_0, {$: "../readers-v1/readers.Args", "journal": {$: "Nil"}, "fail": false})), _a_0, _journalA_0, _statusA_0))};
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_identity$1261$(_runtime_0, _reader_0, _registry_0, _actual_0, _args_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  const _readerNamespace_0 = _reader_0["namespace"];
  const _readerId_0 = _reader_0["id"];
  const _expected_0 = _reader_0["registryId"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_checked$1261$(($Bool$and$((_namespace_0 === _readerNamespace_0), (_expected_0 === _actual_0))), _world_0, {$: "../../../src/ecs/event-runtime.Reader", "namespace": _readerNamespace_0, "id": _readerId_0, "registryId": _expected_0}, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_join$1267$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1267$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058register_checked$1261$((_nextSystemId_0 < 4294967295), {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0) {
  return {$: "../../../src/ecs/column.Indexed", "state": {$: "../../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058empty$() {
  return {$: "../../../src/ecs/indexed-lifecycle.Metadata", "added": [0], "changed": [0], "capacity": 1, "depth": 0, "exceptional": {$: "Nil"}};
}

function $consumer$045spawn$058paired$1260$(_owners_0, _pair_0) {
  const _runtime_0 = _pair_0["runtime"];
  const _a_0 = _pair_0["a"];
  const _b_0 = _pair_0["b"];
  const _journalA_0 = _pair_0["journalA"];
  const _journalB_0 = _pair_0["journalB"];
  return $consumer$045spawn$058registries$1260$(_runtime_0, _a_0, _b_0, _journalA_0, _journalB_0, _owners_0);
}

function $consumer$045barrier$058barrier_pair$1260$(_registries_0, _pair_0) {
  const _runtime_0 = _pair_0["runtime"];
  const _a_0 = _pair_0["a"];
  const _b_0 = _pair_0["b"];
  const _journalA_0 = _pair_0["journalA"];
  const _journalB_0 = _pair_0["journalB"];
  return $consumer$045barrier$058returned$1260$(_registries_0, _a_0, _b_0, _journalA_0, _journalB_0, ($runtime$045spawn$058barrier$1260$(_runtime_0)));
}

function $consumer$045gameplay$058paired$1260$(_owners_0, _fixed_step_0, _args_0, _pair_0) {
  const _runtime_0 = _pair_0["runtime"];
  const _a_0 = _pair_0["a"];
  const _b_0 = _pair_0["b"];
  const _journalA_0 = _pair_0["journalA"];
  const _journalB_0 = _pair_0["journalB"];
  return $consumer$045gameplay$058registries$1260$(_runtime_0, _a_0, _b_0, _journalA_0, _journalB_0, _fixed_step_0, _args_0, _owners_0);
}

function $consumer$045state$058readers_returned$1260$(_registries_0, _result_0) {
  const _pair_0 = _result_0["pair"];
  const _a_0 = _result_0["a"];
  const _b_0 = _result_0["b"];
  return {$: "Tuple", "fst": {$: "consumer-state.Application", "readers": _pair_0, "registries": _registries_0}, "snd": {$: "consumer-state.ReaderResults", "a": _a_0, "b": _b_0}};
}

function $$$$047readers$045v1$047pair$058run$1260$(_pair_0, _failB_0) {
  const _runtime_0 = _pair_0["runtime"];
  const _a_0 = _pair_0["a"];
  const _b_0 = _pair_0["b"];
  const _journalA_0 = _pair_0["journalA"];
  const _journalB_0 = _pair_0["journalB"];
  return $$$$047readers$045v1$047pair$058finish_a$1260$(($$$$047readers$045v1$047readers$058run$1260$(_runtime_0, _a_0, {$: "../readers-v1/readers.Args", "journal": _journalA_0, "fail": false})), _b_0, _journalB_0, _failB_0);
}

function $$$$047readers$045v1$047pair$058retry_b$1260$(_pair_0) {
  const _runtime_0 = _pair_0["runtime"];
  const _a_0 = _pair_0["a"];
  const _b_0 = _pair_0["b"];
  const _journalA_0 = _pair_0["journalA"];
  const _journalB_0 = _pair_0["journalB"];
  return $$$$047readers$045v1$047pair$058finish_b$1260$(($$$$047readers$045v1$047readers$058run$1260$(_runtime_0, _b_0, {$: "../readers-v1/readers.Args", "journal": _journalB_0, "fail": false})), _a_0, _journalA_0, {$: "../readers-v1/pair.Skipped"});
}

function $runtime$045spawn$058frame$1260$(_runtime_0) {
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058frame$1260$(_runtime_0);
}

function $checkpoint$058resource_known$1260$(_label_0, _allocation_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _resource_0 = _observed_0["snd"];
  return $checkpoint$058cells_known$1260$(_label_0, _allocation_0, _resource_0, ($world$045view$058allocated$1260$(_world_0)));
}

function $world$045view$058resource$1260$(_world_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058observe_resource$1260$(_world_0);
}

function $$$$047readers$045v1$047pair$058initial_continue$1260$(_statusA_0, _runtime_0, _a_0, _journalA_0) {
  if (_statusA_0.$ === "../readers-v1/pair.Succeeded") {
    const _journal_0 = _statusA_0["journal"];
    return $$$$047readers$045v1$047pair$058registered_b$1260$(($$$$047readers$045v1$047readers$058register$1260$(_runtime_0, "Simulation/ReaderB")), _a_0, _journalA_0, {$: "../readers-v1/pair.Succeeded", "journal": _journal_0});
  } else {
    return {$: "../readers-v1/pair.ARunStopped", "runtime": _runtime_0, "a": _a_0, "journalA": _journalA_0, "statusA": _statusA_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_identified$1260$(_runtime_0, _reader_0, _identified_0, _args_0) {
  const _registry_0 = _identified_0["fst"];
  const _actual_0 = _identified_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_identity$1260$(_runtime_0, _reader_0, _registry_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058identity$1260$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _id_0};
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058registered_identity$1260$(_world_0, _identity_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _registry_0 = _identity_0["fst"];
  const _registryId_0 = _identity_0["snd"];
  return {$: "../../../src/ecs/event-runtime.Registered", "runtime": {$: "../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": ((_nextReader_0 + 1) >>> 0), "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "reader": {$: "../../../src/ecs/event-runtime.Reader", "namespace": _namespace_0, "id": _nextReader_0, "registryId": _registryId_0}, "registry": _registry_0};
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1263$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_join$1263$(($$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047column$058empty_indexed$1260$() {
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$([{$: "None"}], ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058empty$()));
}

function $consumer$045spawn$058selected$1261$(_runtime_0, _context_0, _spawn_0) {
  if (_spawn_0.$ === "None") {
    return $consumer$045spawn$058registered$1261$(_context_0, ($runtime$045register$045spawn$058register$1261$(_runtime_0)));
  } else {
    const _registry_0 = _spawn_0["value"];
    return $consumer$045spawn$058returned$1261$(_context_0, ($runtime$045spawn$058run$1261$(_runtime_0, _registry_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world$1265$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world_result$1265$(_effect_0(_world_0), _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $runtime$045spawn$058barrier_world$1261$(_world_0) {
  return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047src$047ecs$047world$058barrier$1261$(_world_0)), "snd": {$: "Unit"}};
}

function $consumer$045gameplay$058selected$1261$(_runtime_0, _context_0, _fixed_step_0, _args_0, _movement_0, _damage_0) {
  if (_movement_0.$ === "None") {
    if (_damage_0.$ === "None") {
      return $consumer$045gameplay$058installed$1261$(_context_0, _fixed_step_0, _args_0, ($runtime$045install$058install$1261$(_runtime_0)));
    } else {
      return {$: "Tuple", "fst": ($consumer$045gameplay$058assembled$1261$(_runtime_0, {$: "None"}, _damage_0, _context_0)), "snd": {$: "consumer-gameplay.GameplayIncompleteRegistration"}};
    }
  } else {
    const _movement_1 = _movement_0["value"];
    if (_damage_0.$ === "Some") {
      const _damage_1 = _damage_0["value"];
      return $consumer$045gameplay$058returned$1261$(_context_0, ($runtime$045gameplay$058run$1261$({$: "runtime-gameplay.State", "runtime": _runtime_0, "movement": _movement_1, "damage": _damage_1}, _fixed_step_0, _args_0)));
    } else {
      return {$: "Tuple", "fst": ($consumer$045gameplay$058assembled$1261$(_runtime_0, {$: "Some", "value": _movement_1}, _damage_0, _context_0)), "snd": {$: "consumer-gameplay.GameplayIncompleteRegistration"}};
    }
  }
}

function $$$$047readers$045v1$047pair$058join_a$1261$(_runtime_0, _a_0, _b_0, _journalB_0, _failB_0, _completed_0) {
  const _journalA_0 = _completed_0["fst"];
  const _statusA_0 = _completed_0["snd"];
  return $$$$047readers$045v1$047pair$058continue_a$1261$(_statusA_0, _runtime_0, _a_0, _b_0, _journalA_0, _journalB_0, _failB_0);
}

function $$$$047readers$045v1$047pair$058join_b$1261$(_runtime_0, _a_0, _b_0, _journalA_0, _statusA_0, _completed_0) {
  const _journalB_0 = _completed_0["fst"];
  const _statusB_0 = _completed_0["snd"];
  return {$: "../readers-v1/pair.Returned", "pair": {$: "../readers-v1/pair.ReaderPair", "runtime": _runtime_0, "a": _a_0, "b": _b_0, "journalA": _journalA_0, "journalB": _journalB_0}, "a": _statusA_0, "b": _statusB_0};
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058trim$1261$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058trim_result$1261$(_world_0, _namespace_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, run_loop($$$$047$$$047$$$047src$047ecs$047event$045runtime$058trim_capacity$1260$(run_loop($$$$047$$$047$$$047src$047ecs$047event$045runtime$058past_window$1260$(_batches_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058hold_boundary$(_positions_0, _boundary_0)), _dropped_0)), _capacity_0)));
}

function $checkpoint$058events_known$1261$(_label_0, _allocation_0, _resource_0, _cells_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _events_0 = _observed_0["snd"];
  return $checkpoint$058pending_known$1261$(_label_0, _allocation_0, _resource_0, _cells_0, _events_0, ($$$$047$$$047$$$047src$047ecs$047world$058pending_count$1261$(_world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $world$045view$058allocated_known$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _highWater_0 = _t_0["highWater"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store$1262$(run_clo((_x_0) => {
  return $store$045view$058allocated$1261$(_highWater_0, 1, _x_0);
}), _world_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058observe_resource_finish$1262$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $owner$045view$058view$(_owner_0) {
  return $owner$045view$058sized$({$: "Tuple", fst: _owner_0, snd: _owner_0.length});
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_checked$1261$(_allowed_0, _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/event-runtime.Ran", "runtime": {$: "../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../src/ecs/event-runtime.Rejected", "args": _args_0}};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_position$1261$(($$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _readerId_0)), _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1267$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058register_checked$1261$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/world.RegistrationRejected", "error": {$: "../../../src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $consumer$045spawn$058registries$1260$(_runtime_0, _a_0, _b_0, _journalA_0, _journalB_0, _owners_0) {
  const _spawn_0 = _owners_0["spawn"];
  const _movement_0 = _owners_0["movement"];
  const _damage_0 = _owners_0["damage"];
  return $consumer$045spawn$058selected$1260$(_runtime_0, {$: "consumer-spawn.Context", "a": _a_0, "b": _b_0, "journalA": _journalA_0, "journalB": _journalB_0, "movement": _movement_0, "damage": _damage_0}, _spawn_0);
}

function $consumer$045barrier$058returned$1260$(_registries_0, _a_0, _b_0, _journalA_0, _journalB_0, _observed_0) {
  const _runtime_0 = _observed_0["fst"];
  return {$: "consumer-state.Application", "readers": {$: "../readers-v1/pair.ReaderPair", "runtime": _runtime_0, "a": _a_0, "b": _b_0, "journalA": _journalA_0, "journalB": _journalB_0}, "registries": _registries_0};
}

function $runtime$045spawn$058barrier$1260$(_runtime_0) {
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world$1261$(run_clo((_x_0) => {
  return $runtime$045spawn$058barrier_world$1260$(_x_0);
}), _runtime_0);
}

function $consumer$045gameplay$058registries$1260$(_runtime_0, _a_0, _b_0, _journalA_0, _journalB_0, _fixed_step_0, _args_0, _owners_0) {
  const _spawn_0 = _owners_0["spawn"];
  const _movement_0 = _owners_0["movement"];
  const _damage_0 = _owners_0["damage"];
  return $consumer$045gameplay$058selected$1260$(_runtime_0, {$: "consumer-gameplay.Context", "a": _a_0, "b": _b_0, "journalA": _journalA_0, "journalB": _journalB_0, "spawn": _spawn_0}, _fixed_step_0, _args_0, _movement_0, _damage_0);
}

function $$$$047readers$045v1$047pair$058finish_a$1260$(_result_0, _b_0, _journalB_0, _failB_0) {
  const _runtime_0 = _result_0["runtime"];
  const _a_0 = _result_0["owner"];
  const _outcome_0 = _result_0["completion"];
  return $$$$047readers$045v1$047pair$058join_a$1260$(_runtime_0, _a_0, _b_0, _journalB_0, _failB_0, ($$$$047readers$045v1$047pair$058completion$1260$(_outcome_0)));
}

function $$$$047readers$045v1$047pair$058finish_b$1260$(_result_0, _a_0, _journalA_0, _statusA_0) {
  const _runtime_0 = _result_0["runtime"];
  const _b_0 = _result_0["owner"];
  const _outcome_0 = _result_0["completion"];
  return $$$$047readers$045v1$047pair$058join_b$1260$(_runtime_0, _a_0, _b_0, _journalA_0, _statusA_0, ($$$$047readers$045v1$047pair$058completion$1260$(_outcome_0)));
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058frame$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058trim$1260$({$: "../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _tick_0, "boundary": _frameStart_0, "capacity": _capacity_0, "droppedThrough": _dropped_0});
}

function $checkpoint$058cells_known$1260$(_label_0, _allocation_0, _resource_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _cells_0 = _observed_0["snd"];
  return $checkpoint$058events_known$1260$(_label_0, _allocation_0, _resource_0, _cells_0, ($$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
}

function $world$045view$058allocated$1260$(_world_0) {
  return $world$045view$058allocated_known$1260$(($world$045view$058allocation$1260$(_world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058observe_resource$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058observe_resource_finish$1260$(($owner$045view$058view$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047readers$045v1$047pair$058registered_b$1260$(_result_0, _a_0, _journalA_0, _statusA_0) {
  if (_result_0.$ === "../readers-v1/readers.RegisterFailed") {
    const _runtime_0 = _result_0["runtime"];
    return {$: "../readers-v1/pair.BRegistrationFailed", "runtime": _runtime_0, "a": _a_0, "journalA": _journalA_0, "statusA": _statusA_0};
  } else {
    const _runtime_1 = _result_0["runtime"];
    const _b_0 = _result_0["owner"];
    return {$: "../readers-v1/pair.Ready", "result": ($$$$047readers$045v1$047pair$058finish_b$1260$(($$$$047readers$045v1$047readers$058run$1260$(_runtime_1, _b_0, {$: "../readers-v1/readers.Args", "journal": {$: "Nil"}, "fail": false})), _a_0, _journalA_0, _statusA_0))};
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_identity$1260$(_runtime_0, _reader_0, _registry_0, _actual_0, _args_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  const _readerNamespace_0 = _reader_0["namespace"];
  const _readerId_0 = _reader_0["id"];
  const _expected_0 = _reader_0["registryId"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_checked$1260$(($Bool$and$((_namespace_0 === _readerNamespace_0), (_expected_0 === _actual_0))), _world_0, {$: "../../../src/ecs/event-runtime.Reader", "namespace": _readerNamespace_0, "id": _readerId_0, "registryId": _expected_0}, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_join$1263$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1263$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0) {
  return {$: "../../../src/ecs/column.Indexed", "state": {$: "../../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $consumer$045spawn$058registered$1261$(_context_0, _result_0) {
  const _runtime_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "runtime-register-spawn.Registered") {
    const _registry_0 = _t_0["registry"];
    return $consumer$045spawn$058returned$1261$(_context_0, ($runtime$045spawn$058run$1261$(_runtime_0, _registry_0)));
  } else {
    return {$: "Tuple", "fst": ($consumer$045spawn$058assembled$1261$(_runtime_0, {$: "None"}, _context_0)), "snd": {$: "runtime-spawn.SpawnRegistrationRejected"}};
  }
}

function $runtime$045register$045spawn$058register$1261$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $runtime$045register$045spawn$058returned$1261$(_namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, ($runtime$045register$045spawn$058extracted$1261$(($spawn$045system$058register$1261$(_world_0)))));
}

function $consumer$045spawn$058returned$1261$(_context_0, _result_0) {
  const _runtime_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _registry_0 = _t_0["registry"];
  const _completion_0 = _t_0["completion"];
  return {$: "Tuple", "fst": ($consumer$045spawn$058assembled$1261$(_runtime_0, {$: "Some", "value": _registry_0}, _context_0)), "snd": _completion_0};
}

function $runtime$045spawn$058run$1261$(_runtime_0, _registry_0) {
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world$1264$(run_clo((_x_0) => {
  return $runtime$045spawn$058returned$1261$(($spawn$045system$058run$1261$(_registry_0, _x_0)));
}), _runtime_0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world_result$1265$(_returned_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _returned_0["fst"];
  const _output_0 = _returned_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_values$1261$(($$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0)), "snd": _output_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058barrier$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1261$(_pending_0, {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $consumer$045gameplay$058installed$1261$(_context_0, _fixed_step_0, _args_0, _result_0) {
  const _runtime_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "runtime-install.Installed") {
    const _movement_0 = _t_0["movement"];
    const _damage_0 = _t_0["damage"];
    return $consumer$045gameplay$058returned$1261$(_context_0, ($runtime$045gameplay$058run$1261$({$: "runtime-gameplay.State", "runtime": _runtime_0, "movement": _movement_0, "damage": _damage_0}, _fixed_step_0, _args_0)));
  } else if (_t_0.$ === "runtime-install.MovementRefused") {
    return {$: "Tuple", "fst": ($consumer$045gameplay$058assembled$1261$(_runtime_0, {$: "None"}, {$: "None"}, _context_0)), "snd": {$: "consumer-gameplay.MovementRegistrationFailed"}};
  } else {
    const _movement_1 = _t_0["movement"];
    return {$: "Tuple", "fst": ($consumer$045gameplay$058assembled$1261$(_runtime_0, {$: "Some", "value": _movement_1}, {$: "None"}, _context_0)), "snd": {$: "consumer-gameplay.DamageRegistrationFailed"}};
  }
}

function $runtime$045install$058install$1261$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $runtime$045install$058returned$1261$(_namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, ($runtime$045install$058extracted$1261$(($gameplay$058install$1261$(_world_0)))));
}

function $consumer$045gameplay$058assembled$1261$(_runtime_0, _movement_0, _damage_0, _context_0) {
  const _a_0 = _context_0["a"];
  const _b_0 = _context_0["b"];
  const _journalA_0 = _context_0["journalA"];
  const _journalB_0 = _context_0["journalB"];
  const _spawn_0 = _context_0["spawn"];
  return {$: "consumer-state.Application", "readers": {$: "../readers-v1/pair.ReaderPair", "runtime": _runtime_0, "a": _a_0, "b": _b_0, "journalA": _journalA_0, "journalB": _journalB_0}, "registries": {$: "consumer-state.Registries", "spawn": _spawn_0, "movement": _movement_0, "damage": _damage_0}};
}

function $consumer$045gameplay$058returned$1261$(_context_0, _result_0) {
  const _state_0 = _result_0["fst"];
  const _output_0 = _result_0["snd"];
  return $consumer$045gameplay$058returned_state$1261$(_context_0, _output_0, _state_0);
}

function $runtime$045gameplay$058run$1261$(_state_0, _fixed_step_0, _args_0) {
  const _runtime_0 = _state_0["runtime"];
  const _movement_0 = _state_0["movement"];
  const _damage_0 = _state_0["damage"];
  return $runtime$045gameplay$058movement_synced$1261$(_damage_0, _args_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world$1267$(run_clo((_x_0) => {
  return $runtime$045gameplay$058movement_returned$1261$(($systems$058run_movement$1261$(_movement_0, _x_0, _fixed_step_0)));
}), _runtime_0)));
}

function $$$$047readers$045v1$047pair$058continue_a$1261$(_statusA_0, _runtime_0, _a_0, _b_0, _journalA_0, _journalB_0, _failB_0) {
  if (_statusA_0.$ === "../readers-v1/pair.Succeeded") {
    const _journal_0 = _statusA_0["journal"];
    return $$$$047readers$045v1$047pair$058finish_b$1261$(($$$$047readers$045v1$047readers$058run$1261$(_runtime_0, _b_0, {$: "../readers-v1/readers.Args", "journal": _journalB_0, "fail": _failB_0})), _a_0, _journalA_0, {$: "../readers-v1/pair.Succeeded", "journal": _journal_0});
  } else {
    return {$: "../readers-v1/pair.Returned", "pair": {$: "../readers-v1/pair.ReaderPair", "runtime": _runtime_0, "a": _a_0, "b": _b_0, "journalA": _journalA_0, "journalB": _journalB_0}, "a": _statusA_0, "b": {$: "../readers-v1/pair.Skipped"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058trim_result$1261$(_world_0, _namespace_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _trimmed_0) {
  const _batches_0 = _trimmed_0["batches"];
  const _dropped_0 = _trimmed_0["dropped"];
  return {$: "../../../src/ecs/event-runtime.Runtime", "world": ($$$$047$$$047$$$047src$047ecs$047world$058events_replace$1261$(_world_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058values$1260$(_batches_0)))), "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0};
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058trim_capacity$1260$(_trimmed_0, _capacity_0) {
  const _batches_0 = _trimmed_0["batches"];
  const _dropped_0 = _trimmed_0["dropped"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058at_capacity$1260$(_batches_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058past_window$1260$(_batches_0, _boundary_0, _dropped_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "../../../src/ecs/event-runtime.Trimmed", "batches": {$: "Nil"}, "dropped": _dropped_0};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058past_checked$1260$(($Nat$is_le$(_tick_0, _boundary_0)), _tick_0, _items_0, _rest_0, _dropped_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058past_window$1260$(_rest_0, _boundary_0, _x_0);
}));
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058hold_boundary$($0, $1) {
  for (;;) {
    {
      const _positions_0 = $0;
      const _boundary_0 = $1;
      if (_positions_0.$ === "Nil") {
        return _boundary_0;
      } else {
        const _t_0 = _positions_0["head"];
        const _cursor_0 = _t_0["cursor"];
        const _rest_0 = _positions_0["tail"];
        $0 = _rest_0;
        $1 = (_boundary_0 < _cursor_0 ? _boundary_0 : _cursor_0);
        continue;
      }
    }
  }
}

function $checkpoint$058pending_known$1261$(_label_0, _allocation_0, _resource_0, _cells_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _pending_0 = _observed_0["snd"];
  return $checkpoint$058clock_known$1261$(_label_0, _allocation_0, _resource_0, _cells_0, _events_0, _pending_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058pending_count$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058pending_count_join$1261$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, ($$$$047$$$047$$$047src$047ecs$047world$058pending_length$1261$(_pending_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store$1262$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1265$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $store$045view$058allocated$1261$(_count_0, _id_0, _store_0) {
  if (_count_0 === 0) {
    return {$: "Tuple", "fst": _store_0, "snd": {$: "Nil"}};
  } else {
    const _rest_0 = (_count_0 - 1);
    return $store$045view$058collected_next$1261$(run_clo((_x_0) => {
  return $store$045view$058allocated$1261$(_rest_0, ((_id_0 + 1) >>> 0), _x_0);
}), ($store$045view$058entity$1261$(_id_0, _store_0)));
  }
}

function $owner$045view$058sized$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _length_0 = _observed_0["snd"];
  return $owner$045view$058completed$(_length_0, ($owner$045view$058collect$(_length_0, 0, _owner_0)));
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_position$1261$(_position_0, _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_position_0.$ === "None") {
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_reading$1261$(($$$$047$$$047$$$047src$047ecs$047event$045runtime$058reading$1260$({$: "../../../src/ecs/event-runtime.Position", "id": _readerId_0, "cursor": 0, "registeredAt": _tick_0}, _batches_0, _dropped_0)), _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  } else {
    const _position_1 = _position_0["value"];
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_reading$1261$(($$$$047$$$047$$$047src$047ecs$047event$045runtime$058reading$1260$(_position_1, _batches_0, _dropped_0)), _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _position_0 = _positions_0["head"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_rest_0, _id_0)));
  }
}

function $consumer$045spawn$058selected$1260$(_runtime_0, _context_0, _spawn_0) {
  if (_spawn_0.$ === "None") {
    return $consumer$045spawn$058registered$1260$(_context_0, ($runtime$045register$045spawn$058register$1260$(_runtime_0)));
  } else {
    const _registry_0 = _spawn_0["value"];
    return $consumer$045spawn$058returned$1260$(_context_0, ($runtime$045spawn$058run$1260$(_runtime_0, _registry_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world$1261$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world_result$1261$(_effect_0(_world_0), _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $runtime$045spawn$058barrier_world$1260$(_world_0) {
  return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0)), "snd": {$: "Unit"}};
}

function $consumer$045gameplay$058selected$1260$(_runtime_0, _context_0, _fixed_step_0, _args_0, _movement_0, _damage_0) {
  if (_movement_0.$ === "None") {
    if (_damage_0.$ === "None") {
      return $consumer$045gameplay$058installed$1260$(_context_0, _fixed_step_0, _args_0, ($runtime$045install$058install$1260$(_runtime_0)));
    } else {
      return {$: "Tuple", "fst": ($consumer$045gameplay$058assembled$1260$(_runtime_0, {$: "None"}, _damage_0, _context_0)), "snd": {$: "consumer-gameplay.GameplayIncompleteRegistration"}};
    }
  } else {
    const _movement_1 = _movement_0["value"];
    if (_damage_0.$ === "Some") {
      const _damage_1 = _damage_0["value"];
      return $consumer$045gameplay$058returned$1260$(_context_0, ($runtime$045gameplay$058run$1260$({$: "runtime-gameplay.State", "runtime": _runtime_0, "movement": _movement_1, "damage": _damage_1}, _fixed_step_0, _args_0)));
    } else {
      return {$: "Tuple", "fst": ($consumer$045gameplay$058assembled$1260$(_runtime_0, {$: "Some", "value": _movement_1}, _damage_0, _context_0)), "snd": {$: "consumer-gameplay.GameplayIncompleteRegistration"}};
    }
  }
}

function $$$$047readers$045v1$047pair$058join_a$1260$(_runtime_0, _a_0, _b_0, _journalB_0, _failB_0, _completed_0) {
  const _journalA_0 = _completed_0["fst"];
  const _statusA_0 = _completed_0["snd"];
  return $$$$047readers$045v1$047pair$058continue_a$1260$(_statusA_0, _runtime_0, _a_0, _b_0, _journalA_0, _journalB_0, _failB_0);
}

function $$$$047readers$045v1$047pair$058join_b$1260$(_runtime_0, _a_0, _b_0, _journalA_0, _statusA_0, _completed_0) {
  const _journalB_0 = _completed_0["fst"];
  const _statusB_0 = _completed_0["snd"];
  return {$: "../readers-v1/pair.Returned", "pair": {$: "../readers-v1/pair.ReaderPair", "runtime": _runtime_0, "a": _a_0, "b": _b_0, "journalA": _journalA_0, "journalB": _journalB_0}, "a": _statusA_0, "b": _statusB_0};
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058trim$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058trim_result$1260$(_world_0, _namespace_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, run_loop($$$$047$$$047$$$047src$047ecs$047event$045runtime$058trim_capacity$1260$(run_loop($$$$047$$$047$$$047src$047ecs$047event$045runtime$058past_window$1260$(_batches_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058hold_boundary$(_positions_0, _boundary_0)), _dropped_0)), _capacity_0)));
}

function $checkpoint$058events_known$1260$(_label_0, _allocation_0, _resource_0, _cells_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _events_0 = _observed_0["snd"];
  return $checkpoint$058pending_known$1260$(_label_0, _allocation_0, _resource_0, _cells_0, _events_0, ($$$$047$$$047$$$047src$047ecs$047world$058pending_count$1260$(_world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $world$045view$058allocated_known$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _highWater_0 = _t_0["highWater"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store$1260$(run_clo((_x_0) => {
  return $store$045view$058allocated$1260$(_highWater_0, 1, _x_0);
}), _world_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058observe_resource_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_checked$1260$(_allowed_0, _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/event-runtime.Ran", "runtime": {$: "../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../src/ecs/event-runtime.Rejected", "args": _args_0}};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_position$1260$(($$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _readerId_0)), _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1263$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/world.RegistrationRejected", "error": {$: "../../../src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $consumer$045spawn$058assembled$1261$(_runtime_0, _spawn_0, _context_0) {
  const _a_0 = _context_0["a"];
  const _b_0 = _context_0["b"];
  const _journalA_0 = _context_0["journalA"];
  const _journalB_0 = _context_0["journalB"];
  const _movement_0 = _context_0["movement"];
  const _damage_0 = _context_0["damage"];
  return {$: "consumer-state.Application", "readers": {$: "../readers-v1/pair.ReaderPair", "runtime": _runtime_0, "a": _a_0, "b": _b_0, "journalA": _journalA_0, "journalB": _journalB_0}, "registries": {$: "consumer-state.Registries", "spawn": _spawn_0, "movement": _movement_0, "damage": _damage_0}};
}

function $runtime$045register$045spawn$058returned$1261$(_namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registered_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "snd": _registered_0};
}

function $runtime$045register$045spawn$058extracted$1261$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "Tuple", "fst": _world_0, "snd": {$: "runtime-register-spawn.Registered", "registry": _registry_0}};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "Tuple", "fst": _world_1, "snd": {$: "runtime-register-spawn.RegistrationRefused"}};
  }
}

function $spawn$045system$058register$1261$(_world_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058register$1264$(_world_0, "Simulation/Spawn", {$: "Con", "head": "command:spawn", "tail": {$: "Nil"}});
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world$1264$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world_result$1264$(_effect_0(_world_0), _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $runtime$045spawn$058returned$1261$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _t_0 = _result_0["outcome"];
    if (_t_0.$ === "../../../src/ecs/system.Succeeded") {
      const _world_0 = _t_0["world"];
      const _reservations_0 = _t_0["output"];
      return {$: "Tuple", "fst": _world_0, "snd": {$: "runtime-spawn.Output", "registry": _registry_0, "completion": {$: "runtime-spawn.SpawnSucceeded", "reservations": _reservations_0}}};
    } else {
      const _world_1 = _t_0["world"];
      const _error_0 = _t_0["error"];
      return {$: "Tuple", "fst": _world_1, "snd": {$: "runtime-spawn.Output", "registry": _registry_0, "completion": {$: "runtime-spawn.SpawnFailed", "error": _error_0}}};
    }
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_2 = _result_0["world"];
    return {$: "Tuple", "fst": _world_2, "snd": {$: "runtime-spawn.Output", "registry": _registry_1, "completion": {$: "runtime-spawn.SpawnRegistrationRejected"}}};
  }
}

function $spawn$045system$058run$1261$(_registry_0, _world_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1263$(_registry_0, _world_0, {$: "Unit"});
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_values$1261$(_observed_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _observed_0["fst"];
  const _all_0 = _observed_0["snd"];
  const _published_0 = ($List$drop$(_all_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058size$1260$(_batches_0))));
  const _x_0 = ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058count$1260$(_published_0));
  return {$: "../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_checked$1260$((0 < _x_0), _batches_0, _tick_0, _published_0)), "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1261$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1261$(_rest_0, _world_0)));
  }
}

function $runtime$045install$058returned$1261$(_namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _owners_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "snd": _owners_0};
}

function $runtime$045install$058extracted$1261$(_result_0) {
  if (_result_0.$ === "gameplay.GameplayInstalled") {
    const _t_0 = _result_0["game"];
    const _world_0 = _t_0["world"];
    const _movement_0 = _t_0["movement"];
    const _damage_0 = _t_0["damage"];
    return {$: "Tuple", "fst": _world_0, "snd": {$: "runtime-install.Installed", "movement": _movement_0, "damage": _damage_0}};
  } else if (_result_0.$ === "gameplay.GameplayMovementRefused") {
    const _world_1 = _result_0["world"];
    return {$: "Tuple", "fst": _world_1, "snd": {$: "runtime-install.MovementRefused"}};
  } else {
    const _world_2 = _result_0["world"];
    const _movement_1 = _result_0["movement"];
    return {$: "Tuple", "fst": _world_2, "snd": {$: "runtime-install.DamageRefused", "movement": _movement_1}};
  }
}

function $gameplay$058install$1261$(_world_0) {
  return $gameplay$058movement_registered$1261$(($systems$058register_movement$1261$(_world_0)));
}

function $consumer$045gameplay$058returned_state$1261$(_context_0, _output_0, _state_0) {
  const _runtime_0 = _state_0["runtime"];
  const _movement_0 = _state_0["movement"];
  const _damage_0 = _state_0["damage"];
  return {$: "Tuple", "fst": ($consumer$045gameplay$058assembled$1261$(_runtime_0, {$: "Some", "value": _movement_0}, {$: "Some", "value": _damage_0}, _context_0)), "snd": {$: "consumer-gameplay.GameplayRan", "output": _output_0}};
}

function $runtime$045gameplay$058movement_synced$1261$(_damage_0, _args_0, _observed_0) {
  const _runtime_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _movement_0 = _t_0["registry"];
  const _t_1 = _t_0["outcome"];
  if (_t_1.$ === "../../../src/ecs/transaction.Failure") {
    const _error_0 = _t_1["error"];
    const _moved_0 = _t_0["values"];
    return {$: "Tuple", "fst": {$: "runtime-gameplay.State", "runtime": _runtime_0, "movement": _movement_0, "damage": _damage_0}, "snd": {$: "runtime-gameplay.FrameOutput", "outcome": {$: "../../../src/ecs/transaction.Failure", "error": _error_0}, "moved": _moved_0, "damaged": {$: "Nil"}}};
  } else {
    const _moved_1 = _t_0["values"];
    return $runtime$045gameplay$058damage_synced$1261$(_movement_0, _moved_1, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world$1266$(run_clo((_x_0) => {
  return $runtime$045gameplay$058damage_returned$1261$(($systems$058run_damage$1261$(_damage_0, _x_0, _args_0)));
}), _runtime_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world$1267$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world_result$1267$(_effect_0(_world_0), _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $runtime$045gameplay$058movement_returned$1261$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _t_0 = _result_0["outcome"];
    if (_t_0.$ === "../../../src/ecs/system.Succeeded") {
      const _world_0 = _t_0["world"];
      const _values_0 = _t_0["output"];
      return {$: "Tuple", "fst": _world_0, "snd": {$: "runtime-gameplay.MovementOutput", "registry": _registry_0, "outcome": {$: "../../../src/ecs/transaction.Success"}, "values": _values_0}};
    } else {
      const _world_1 = _t_0["world"];
      const _error_0 = _t_0["error"];
      return {$: "Tuple", "fst": _world_1, "snd": {$: "runtime-gameplay.MovementOutput", "registry": _registry_0, "outcome": {$: "../../../src/ecs/transaction.Failure", "error": {$: "gameplay-run.MovementRunFailed", "error": _error_0}}, "values": {$: "Nil"}}};
    }
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_2 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "Tuple", "fst": _world_2, "snd": {$: "runtime-gameplay.MovementOutput", "registry": _registry_1, "outcome": {$: "../../../src/ecs/transaction.Failure", "error": {$: "gameplay-run.MovementRunRegistrationRefused", "args": _args_0}}, "values": {$: "Nil"}}};
  }
}

function $systems$058run_movement$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1265$(_registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058events_replace$1261$(_world_0, _retained_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _retained_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058values$1260$(_batches_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _batches_0["head"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1262$(_items_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058values$1260$(_rest_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058at_capacity$1260$(_batches_0, _capacity_0, _dropped_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "../../../src/ecs/event-runtime.Trimmed", "batches": {$: "Nil"}, "dropped": _dropped_0};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058size$1260$({$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}));
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058capacity_checked$1260$((_capacity_0 < _x_0), _tick_0, _items_0, _rest_0, _dropped_0, run_clo((_x_1) => {
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058at_capacity$1260$(_rest_0, _capacity_0, _x_1);
}));
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058past_checked$1260$(_remove_0, _tick_0, _items_0, _rest_0, _dropped_0, _ih_0) {
  if (!_remove_0) {
    return {$: "../../../src/ecs/event-runtime.Trimmed", "batches": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0));
  }
}

function $Nat$is_le$(_a_0, _b_0) {
  return $Cmp$is_le$(cmp_new(_a_0, _b_0));
}

function $checkpoint$058clock_known$1261$(_label_0, _allocation_0, _resource_0, _cells_0, _events_0, _pending_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $checkpoint$058live_known$1261$(_label_0, _allocation_0, _resource_0, _cells_0, _events_0, _pending_0, _clock_0, ($$$$047$$$047$$$047src$047ecs$047world$058handles$1261$(_world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058pending_count_join$1261$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, _counted_0) {
  const _pending_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _count_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058pending_length$1261$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047world$058pending_prepend$1261$(_command_0, ($$$$047$$$047$$$047src$047ecs$047world$058pending_length$1261$(_rest_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1265$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $store$045view$058collected_next$1261$(_next_0, _observed_0) {
  const _store_0 = _observed_0["fst"];
  const _head_0 = _observed_0["snd"];
  return $store$045view$058collected_head$1261$(_head_0, _next_0(_store_0));
}

function $store$045view$058entity$1261$(_id_0, _store_0) {
  const _position_0 = _store_0["position"];
  const _velocity_0 = _store_0["velocity"];
  const _health_0 = _store_0["health"];
  return $store$045view$058position_viewed$1261$(_id_0, _velocity_0, _health_0, ($$$$047$$$047$$$047src$047ecs$047column$058view$1262$(_position_0, _id_0)));
}

function $owner$045view$058completed$(_length_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _values_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "owner-view.FullCell", "length": _length_0, "values": _values_0}};
}

function $owner$045view$058collect$(_count_0, _index_0, _owner_0) {
  if (_count_0 === 0) {
    return {$: "Tuple", "fst": _owner_0, "snd": {$: "Nil"}};
  } else {
    const _rest_0 = (_count_0 - 1);
    return $owner$045view$058fetched$(run_clo((_x_0) => {
  return $owner$045view$058collect$(_rest_0, ((_index_0 + 1) >>> 0), _x_0);
}), {$: "Tuple", fst: _owner_0, snd: _owner_0[_index_0 % _owner_0.length]});
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_reading$1261$(_reading_0, _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _items_0 = _reading_0["values"];
  const _lagged_0 = _reading_0["lagged"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_registered_result$1261$(($$$$047$$$047$$$047src$047ecs$047system$058run$1267$(_registry_0, _world_0, {$: "../../../src/ecs/event-runtime.Input", "values": _items_0, "lagged": _lagged_0, "args": _args_0})), _reader_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058reading$1260$(_position_0, _batches_0, _dropped_0) {
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../../../src/ecs/event-runtime.Reading", "values": ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, _fallback_0) {
  const _actual_0 = _position_0["id"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058choose_position$((_actual_0 === _id_0), {$: "../../../src/ecs/event-runtime.Position", "id": _actual_0, "cursor": _cursor_0, "registeredAt": _registered_0}, _fallback_0);
}

function $consumer$045spawn$058registered$1260$(_context_0, _result_0) {
  const _runtime_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "runtime-register-spawn.Registered") {
    const _registry_0 = _t_0["registry"];
    return $consumer$045spawn$058returned$1260$(_context_0, ($runtime$045spawn$058run$1260$(_runtime_0, _registry_0)));
  } else {
    return {$: "Tuple", "fst": ($consumer$045spawn$058assembled$1260$(_runtime_0, {$: "None"}, _context_0)), "snd": {$: "runtime-spawn.SpawnRegistrationRejected"}};
  }
}

function $runtime$045register$045spawn$058register$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $runtime$045register$045spawn$058returned$1260$(_namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, ($runtime$045register$045spawn$058extracted$1260$(($spawn$045system$058register$1260$(_world_0)))));
}

function $consumer$045spawn$058returned$1260$(_context_0, _result_0) {
  const _runtime_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _registry_0 = _t_0["registry"];
  const _completion_0 = _t_0["completion"];
  return {$: "Tuple", "fst": ($consumer$045spawn$058assembled$1260$(_runtime_0, {$: "Some", "value": _registry_0}, _context_0)), "snd": _completion_0};
}

function $runtime$045spawn$058run$1260$(_runtime_0, _registry_0) {
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world$1260$(run_clo((_x_0) => {
  return $runtime$045spawn$058returned$1260$(($spawn$045system$058run$1260$(_registry_0, _x_0)));
}), _runtime_0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world_result$1261$(_returned_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _returned_0["fst"];
  const _output_0 = _returned_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_values$1260$(($$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0)), "snd": _output_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_pending_0, {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $consumer$045gameplay$058installed$1260$(_context_0, _fixed_step_0, _args_0, _result_0) {
  const _runtime_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "runtime-install.Installed") {
    const _movement_0 = _t_0["movement"];
    const _damage_0 = _t_0["damage"];
    return $consumer$045gameplay$058returned$1260$(_context_0, ($runtime$045gameplay$058run$1260$({$: "runtime-gameplay.State", "runtime": _runtime_0, "movement": _movement_0, "damage": _damage_0}, _fixed_step_0, _args_0)));
  } else if (_t_0.$ === "runtime-install.MovementRefused") {
    return {$: "Tuple", "fst": ($consumer$045gameplay$058assembled$1260$(_runtime_0, {$: "None"}, {$: "None"}, _context_0)), "snd": {$: "consumer-gameplay.MovementRegistrationFailed"}};
  } else {
    const _movement_1 = _t_0["movement"];
    return {$: "Tuple", "fst": ($consumer$045gameplay$058assembled$1260$(_runtime_0, {$: "Some", "value": _movement_1}, {$: "None"}, _context_0)), "snd": {$: "consumer-gameplay.DamageRegistrationFailed"}};
  }
}

function $runtime$045install$058install$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $runtime$045install$058returned$1260$(_namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, ($runtime$045install$058extracted$1260$(($gameplay$058install$1260$(_world_0)))));
}

function $consumer$045gameplay$058assembled$1260$(_runtime_0, _movement_0, _damage_0, _context_0) {
  const _a_0 = _context_0["a"];
  const _b_0 = _context_0["b"];
  const _journalA_0 = _context_0["journalA"];
  const _journalB_0 = _context_0["journalB"];
  const _spawn_0 = _context_0["spawn"];
  return {$: "consumer-state.Application", "readers": {$: "../readers-v1/pair.ReaderPair", "runtime": _runtime_0, "a": _a_0, "b": _b_0, "journalA": _journalA_0, "journalB": _journalB_0}, "registries": {$: "consumer-state.Registries", "spawn": _spawn_0, "movement": _movement_0, "damage": _damage_0}};
}

function $consumer$045gameplay$058returned$1260$(_context_0, _result_0) {
  const _state_0 = _result_0["fst"];
  const _output_0 = _result_0["snd"];
  return $consumer$045gameplay$058returned_state$1260$(_context_0, _output_0, _state_0);
}

function $runtime$045gameplay$058run$1260$(_state_0, _fixed_step_0, _args_0) {
  const _runtime_0 = _state_0["runtime"];
  const _movement_0 = _state_0["movement"];
  const _damage_0 = _state_0["damage"];
  return $runtime$045gameplay$058movement_synced$1260$(_damage_0, _args_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world$1263$(run_clo((_x_0) => {
  return $runtime$045gameplay$058movement_returned$1260$(($systems$058run_movement$1260$(_movement_0, _x_0, _fixed_step_0)));
}), _runtime_0)));
}

function $$$$047readers$045v1$047pair$058continue_a$1260$(_statusA_0, _runtime_0, _a_0, _b_0, _journalA_0, _journalB_0, _failB_0) {
  if (_statusA_0.$ === "../readers-v1/pair.Succeeded") {
    const _journal_0 = _statusA_0["journal"];
    return $$$$047readers$045v1$047pair$058finish_b$1260$(($$$$047readers$045v1$047readers$058run$1260$(_runtime_0, _b_0, {$: "../readers-v1/readers.Args", "journal": _journalB_0, "fail": _failB_0})), _a_0, _journalA_0, {$: "../readers-v1/pair.Succeeded", "journal": _journal_0});
  } else {
    return {$: "../readers-v1/pair.Returned", "pair": {$: "../readers-v1/pair.ReaderPair", "runtime": _runtime_0, "a": _a_0, "b": _b_0, "journalA": _journalA_0, "journalB": _journalB_0}, "a": _statusA_0, "b": {$: "../readers-v1/pair.Skipped"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058trim_result$1260$(_world_0, _namespace_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _trimmed_0) {
  const _batches_0 = _trimmed_0["batches"];
  const _dropped_0 = _trimmed_0["dropped"];
  return {$: "../../../src/ecs/event-runtime.Runtime", "world": ($$$$047$$$047$$$047src$047ecs$047world$058events_replace$1260$(_world_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058values$1260$(_batches_0)))), "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0};
}

function $checkpoint$058pending_known$1260$(_label_0, _allocation_0, _resource_0, _cells_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _pending_0 = _observed_0["snd"];
  return $checkpoint$058clock_known$1260$(_label_0, _allocation_0, _resource_0, _cells_0, _events_0, _pending_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058pending_count$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058pending_count_join$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, ($$$$047$$$047$$$047src$047ecs$047world$058pending_length$1260$(_pending_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store$1260$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $store$045view$058allocated$1260$(_count_0, _id_0, _store_0) {
  if (_count_0 === 0) {
    return {$: "Tuple", "fst": _store_0, "snd": {$: "Nil"}};
  } else {
    const _rest_0 = (_count_0 - 1);
    return $store$045view$058collected_next$1260$(run_clo((_x_0) => {
  return $store$045view$058allocated$1260$(_rest_0, ((_id_0 + 1) >>> 0), _x_0);
}), ($store$045view$058entity$1260$(_id_0, _store_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_position$1260$(_position_0, _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_position_0.$ === "None") {
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_reading$1260$(($$$$047$$$047$$$047src$047ecs$047event$045runtime$058reading$1260$({$: "../../../src/ecs/event-runtime.Position", "id": _readerId_0, "cursor": 0, "registeredAt": _tick_0}, _batches_0, _dropped_0)), _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  } else {
    const _position_1 = _position_0["value"];
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_reading$1260$(($$$$047$$$047$$$047src$047ecs$047event$045runtime$058reading$1260$(_position_1, _batches_0, _dropped_0)), _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058register$1264$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1264$(($$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world_result$1264$(_returned_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _returned_0["fst"];
  const _output_0 = _returned_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_values$1261$(($$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0)), "snd": _output_0};
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1263$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1263$(($$$$047$$$047$$$047src$047ecs$047system$058run$1264$(_registry_0, _world_0, _args_0)));
}

function $List$drop$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _n_0 = $1;
      if (_xs_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        if (_n_0 === 0) {
          return {$: "Con", "head": _h_0, "tail": _t_0};
        } else {
          const _p_0 = (_n_0 - 1);
          $0 = _t_0;
          $1 = _p_0;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058size$1260$(_batches_0) {
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058size_loop$1260$(_batches_0, 0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_checked$1260$(_nonempty_0, _batches_0, _tick_0, _published_0) {
  if (!_nonempty_0) {
    return _batches_0;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1260$(_batches_0, {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _published_0}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058count$1260$(_items_0) {
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058count_loop$1260$(_items_0, 0);
}

function $gameplay$058movement_registered$1261$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _movement_0 = _result_0["registry"];
    return $gameplay$058damage_registered$1261$(_movement_0, ($systems$058register_damage$1261$(_world_0)));
  } else {
    const _world_1 = _result_0["world"];
    return {$: "gameplay.GameplayMovementRefused", "world": _world_1};
  }
}

function $systems$058register_movement$1261$(_world_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058register$1266$(_world_0, "Simulation/Move", {$: "Con", "head": "write:Simulation/Position", "tail": {$: "Con", "head": "read:Simulation/Velocity", "tail": {$: "Con", "head": "write:Simulation/Step", "tail": {$: "Nil"}}}});
}

function $runtime$045gameplay$058damage_synced$1261$(_movement_0, _moved_0, _observed_0) {
  const _runtime_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _damage_0 = _t_0["registry"];
  const _outcome_0 = _t_0["outcome"];
  const _damaged_0 = _t_0["values"];
  return {$: "Tuple", "fst": {$: "runtime-gameplay.State", "runtime": _runtime_0, "movement": _movement_0, "damage": _damage_0}, "snd": {$: "runtime-gameplay.FrameOutput", "outcome": _outcome_0, "moved": _moved_0, "damaged": _damaged_0}};
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world$1266$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world_result$1266$(_effect_0(_world_0), _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $runtime$045gameplay$058damage_returned$1261$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _t_0 = _result_0["outcome"];
    if (_t_0.$ === "../../../src/ecs/system.Succeeded") {
      const _world_0 = _t_0["world"];
      const _values_0 = _t_0["output"];
      return {$: "Tuple", "fst": _world_0, "snd": {$: "runtime-gameplay.DamageOutput", "registry": _registry_0, "outcome": {$: "../../../src/ecs/transaction.Success"}, "values": _values_0}};
    } else {
      const _world_1 = _t_0["world"];
      const _error_0 = _t_0["error"];
      return {$: "Tuple", "fst": _world_1, "snd": {$: "runtime-gameplay.DamageOutput", "registry": _registry_0, "outcome": {$: "../../../src/ecs/transaction.Failure", "error": {$: "gameplay-run.DamageRunFailed", "error": _error_0}}, "values": {$: "Nil"}}};
    }
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_2 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "Tuple", "fst": _world_2, "snd": {$: "runtime-gameplay.DamageOutput", "registry": _registry_1, "outcome": {$: "../../../src/ecs/transaction.Failure", "error": {$: "gameplay-run.DamageRunRegistrationRefused", "args": _args_0}}, "values": {$: "Nil"}}};
  }
}

function $systems$058run_damage$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1264$(_registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world_result$1267$(_returned_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _returned_0["fst"];
  const _output_0 = _returned_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_values$1261$(($$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0)), "snd": _output_0};
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1265$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1265$(($$$$047$$$047$$$047src$047ecs$047system$058run$1266$(_registry_0, _world_0, _args_0)));
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1262$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1262$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058capacity_checked$1260$(_overflow_0, _tick_0, _items_0, _rest_0, _dropped_0, _ih_0) {
  if (!_overflow_0) {
    return {$: "../../../src/ecs/event-runtime.Trimmed", "batches": {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0));
  }
}

function $Cmp$is_le$(_c_0) {
  if (_c_0.$ === "GT") {
    return false;
  } else {
    return true;
  }
}

function $checkpoint$058live_known$1261$(_label_0, _allocation_0, _resource_0, _cells_0, _events_0, _pending_0, _clock_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _handles_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "checkpoint.Snapshot", "label": _label_0, "allocation": _allocation_0, "resource": _resource_0, "cells": _cells_0, "events": _events_0, "pending": _pending_0, "clock": _clock_0, "live": ($checkpoint$058ids$1261$(_handles_0))}};
}

function $$$$047$$$047$$$047src$047ecs$047world$058handles$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058handles_tail_finish$1261$(($$$$047$$$047$$$047src$047ecs$047world$058collect_tail$1261$(_highWater_0, _namespace_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058pending_prepend$1261$(_command_0, _counted_0) {
  const _commands_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": ((_count_0 + 1) >>> 0)};
}

function $store$045view$058collected_head$1261$(_head_0, _observed_0) {
  const _store_0 = _observed_0["fst"];
  const _tail_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _store_0, "snd": {$: "Con", "head": _head_0, "tail": _tail_0}};
}

function $store$045view$058position_viewed$1261$(_id_0, _velocity_0, _health_0, _observed_0) {
  const _position_0 = _observed_0["fst"];
  const _p_0 = _observed_0["snd"];
  return $store$045view$058velocity_viewed$1261$(_id_0, _position_0, _health_0, _p_0, ($$$$047$$$047$$$047src$047ecs$047column$058view$1262$(_velocity_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058view$1262$(_column_0, _id_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1262$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1262$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1262$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1262$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $owner$045view$058fetched$(_next_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return $owner$045view$058prepended$(_value_0, _next_0(_owner_0));
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_registered_result$1261$(_result_0, _reader_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_result_0.$ === "../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058reject_input$1261$(_args_0, {$: "../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, _reader_0, _registry_0);
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_outcome$1261$(_outcome_0, _reader_0, _registry_1, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run$1267$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1267$(_registry_0, ($$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058since_checked$1260$((_cursor_0 < _tick_0), _items_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058since$1260$(_rest_0, _cursor_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058choose_position$(_found_0, _position_0, _fallback_0) {
  if (!_found_0) {
    return _fallback_0;
  } else {
    return {$: "Some", "value": _position_0};
  }
}

function $consumer$045spawn$058assembled$1260$(_runtime_0, _spawn_0, _context_0) {
  const _a_0 = _context_0["a"];
  const _b_0 = _context_0["b"];
  const _journalA_0 = _context_0["journalA"];
  const _journalB_0 = _context_0["journalB"];
  const _movement_0 = _context_0["movement"];
  const _damage_0 = _context_0["damage"];
  return {$: "consumer-state.Application", "readers": {$: "../readers-v1/pair.ReaderPair", "runtime": _runtime_0, "a": _a_0, "b": _b_0, "journalA": _journalA_0, "journalB": _journalB_0}, "registries": {$: "consumer-state.Registries", "spawn": _spawn_0, "movement": _movement_0, "damage": _damage_0}};
}

function $runtime$045register$045spawn$058returned$1260$(_namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _registered_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "snd": _registered_0};
}

function $runtime$045register$045spawn$058extracted$1260$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "Tuple", "fst": _world_0, "snd": {$: "runtime-register-spawn.Registered", "registry": _registry_0}};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "Tuple", "fst": _world_1, "snd": {$: "runtime-register-spawn.RegistrationRefused"}};
  }
}

function $spawn$045system$058register$1260$(_world_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058register$1260$(_world_0, "Simulation/Spawn", {$: "Con", "head": "command:spawn", "tail": {$: "Nil"}});
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world$1260$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world_result$1260$(_effect_0(_world_0), _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $runtime$045spawn$058returned$1260$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _t_0 = _result_0["outcome"];
    if (_t_0.$ === "../../../src/ecs/system.Succeeded") {
      const _world_0 = _t_0["world"];
      const _reservations_0 = _t_0["output"];
      return {$: "Tuple", "fst": _world_0, "snd": {$: "runtime-spawn.Output", "registry": _registry_0, "completion": {$: "runtime-spawn.SpawnSucceeded", "reservations": _reservations_0}}};
    } else {
      const _world_1 = _t_0["world"];
      const _error_0 = _t_0["error"];
      return {$: "Tuple", "fst": _world_1, "snd": {$: "runtime-spawn.Output", "registry": _registry_0, "completion": {$: "runtime-spawn.SpawnFailed", "error": _error_0}}};
    }
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_2 = _result_0["world"];
    return {$: "Tuple", "fst": _world_2, "snd": {$: "runtime-spawn.Output", "registry": _registry_1, "completion": {$: "runtime-spawn.SpawnRegistrationRejected"}}};
  }
}

function $spawn$045system$058run$1260$(_registry_0, _world_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, {$: "Unit"});
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_values$1260$(_observed_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _observed_0["fst"];
  const _all_0 = _observed_0["snd"];
  const _published_0 = ($List$drop$(_all_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058size$1260$(_batches_0))));
  const _x_0 = ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058count$1260$(_published_0));
  return {$: "../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_checked$1260$((0 < _x_0), _batches_0, _tick_0, _published_0)), "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_rest_0, _world_0)));
  }
}

function $runtime$045install$058returned$1260$(_namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _owners_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "snd": _owners_0};
}

function $runtime$045install$058extracted$1260$(_result_0) {
  if (_result_0.$ === "gameplay.GameplayInstalled") {
    const _t_0 = _result_0["game"];
    const _world_0 = _t_0["world"];
    const _movement_0 = _t_0["movement"];
    const _damage_0 = _t_0["damage"];
    return {$: "Tuple", "fst": _world_0, "snd": {$: "runtime-install.Installed", "movement": _movement_0, "damage": _damage_0}};
  } else if (_result_0.$ === "gameplay.GameplayMovementRefused") {
    const _world_1 = _result_0["world"];
    return {$: "Tuple", "fst": _world_1, "snd": {$: "runtime-install.MovementRefused"}};
  } else {
    const _world_2 = _result_0["world"];
    const _movement_1 = _result_0["movement"];
    return {$: "Tuple", "fst": _world_2, "snd": {$: "runtime-install.DamageRefused", "movement": _movement_1}};
  }
}

function $gameplay$058install$1260$(_world_0) {
  return $gameplay$058movement_registered$1260$(($systems$058register_movement$1260$(_world_0)));
}

function $consumer$045gameplay$058returned_state$1260$(_context_0, _output_0, _state_0) {
  const _runtime_0 = _state_0["runtime"];
  const _movement_0 = _state_0["movement"];
  const _damage_0 = _state_0["damage"];
  return {$: "Tuple", "fst": ($consumer$045gameplay$058assembled$1260$(_runtime_0, {$: "Some", "value": _movement_0}, {$: "Some", "value": _damage_0}, _context_0)), "snd": {$: "consumer-gameplay.GameplayRan", "output": _output_0}};
}

function $runtime$045gameplay$058movement_synced$1260$(_damage_0, _args_0, _observed_0) {
  const _runtime_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _movement_0 = _t_0["registry"];
  const _t_1 = _t_0["outcome"];
  if (_t_1.$ === "../../../src/ecs/transaction.Failure") {
    const _error_0 = _t_1["error"];
    const _moved_0 = _t_0["values"];
    return {$: "Tuple", "fst": {$: "runtime-gameplay.State", "runtime": _runtime_0, "movement": _movement_0, "damage": _damage_0}, "snd": {$: "runtime-gameplay.FrameOutput", "outcome": {$: "../../../src/ecs/transaction.Failure", "error": _error_0}, "moved": _moved_0, "damaged": {$: "Nil"}}};
  } else {
    const _moved_1 = _t_0["values"];
    return $runtime$045gameplay$058damage_synced$1260$(_movement_0, _moved_1, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world$1262$(run_clo((_x_0) => {
  return $runtime$045gameplay$058damage_returned$1260$(($systems$058run_damage$1260$(_damage_0, _x_0, _args_0)));
}), _runtime_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world$1263$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world_result$1263$(_effect_0(_world_0), _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $runtime$045gameplay$058movement_returned$1260$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _t_0 = _result_0["outcome"];
    if (_t_0.$ === "../../../src/ecs/system.Succeeded") {
      const _world_0 = _t_0["world"];
      const _values_0 = _t_0["output"];
      return {$: "Tuple", "fst": _world_0, "snd": {$: "runtime-gameplay.MovementOutput", "registry": _registry_0, "outcome": {$: "../../../src/ecs/transaction.Success"}, "values": _values_0}};
    } else {
      const _world_1 = _t_0["world"];
      const _error_0 = _t_0["error"];
      return {$: "Tuple", "fst": _world_1, "snd": {$: "runtime-gameplay.MovementOutput", "registry": _registry_0, "outcome": {$: "../../../src/ecs/transaction.Failure", "error": {$: "gameplay-run.MovementRunFailed", "error": _error_0}}, "values": {$: "Nil"}}};
    }
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_2 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "Tuple", "fst": _world_2, "snd": {$: "runtime-gameplay.MovementOutput", "registry": _registry_1, "outcome": {$: "../../../src/ecs/transaction.Failure", "error": {$: "gameplay-run.MovementRunRegistrationRefused", "args": _args_0}}, "values": {$: "Nil"}}};
  }
}

function $systems$058run_movement$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1262$(_registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058events_replace$1260$(_world_0, _retained_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _retained_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $checkpoint$058clock_known$1260$(_label_0, _allocation_0, _resource_0, _cells_0, _events_0, _pending_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $checkpoint$058live_known$1260$(_label_0, _allocation_0, _resource_0, _cells_0, _events_0, _pending_0, _clock_0, ($$$$047$$$047$$$047src$047ecs$047world$058handles$1260$(_world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058pending_count_join$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, _counted_0) {
  const _pending_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _count_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058pending_length$1260$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047world$058pending_prepend$1260$(_command_0, ($$$$047$$$047$$$047src$047ecs$047world$058pending_length$1260$(_rest_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $store$045view$058collected_next$1260$(_next_0, _observed_0) {
  const _store_0 = _observed_0["fst"];
  const _head_0 = _observed_0["snd"];
  return $store$045view$058collected_head$1260$(_head_0, _next_0(_store_0));
}

function $store$045view$058entity$1260$(_id_0, _store_0) {
  const _position_0 = _store_0["position"];
  const _velocity_0 = _store_0["velocity"];
  const _health_0 = _store_0["health"];
  return $store$045view$058position_viewed$1260$(_id_0, _velocity_0, _health_0, ($$$$047$$$047$$$047src$047ecs$047column$058view$1260$(_position_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_reading$1260$(_reading_0, _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _items_0 = _reading_0["values"];
  const _lagged_0 = _reading_0["lagged"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_registered_result$1260$(($$$$047$$$047$$$047src$047ecs$047system$058run$1263$(_registry_0, _world_0, {$: "../../../src/ecs/event-runtime.Input", "values": _items_0, "lagged": _lagged_0, "args": _args_0})), _reader_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1264$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_join$1264$(($$$$047$$$047$$$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1263$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1263$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run$1264$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1264$(_registry_0, ($$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058size_loop$1260$($0, $1) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _acc_0 = $1;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058count_loop$1260$(_items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1260$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1260$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058count_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $gameplay$058damage_registered$1261$(_movement_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _damage_0 = _result_0["registry"];
    return {$: "gameplay.GameplayInstalled", "game": {$: "gameplay.Gameplay", "world": _world_0, "movement": _movement_0, "damage": _damage_0}};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "gameplay.GameplayDamageRefused", "world": _world_1, "movement": _movement_0};
  }
}

function $systems$058register_damage$1261$(_world_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058register$1265$(_world_0, "Simulation/Damage", {$: "Con", "head": "read:Simulation/Position", "tail": {$: "Con", "head": "write:Simulation/Health", "tail": {$: "Con", "head": "write:Simulation/Hit", "tail": {$: "Con", "head": "write:Simulation/Death", "tail": {$: "Con", "head": "command:despawn", "tail": {$: "Nil"}}}}}});
}

function $$$$047$$$047$$$047src$047ecs$047system$058register$1266$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1266$(($$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world_result$1266$(_returned_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _returned_0["fst"];
  const _output_0 = _returned_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_values$1261$(($$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0)), "snd": _output_0};
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1264$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1264$(($$$$047$$$047$$$047src$047ecs$047system$058run$1265$(_registry_0, _world_0, _args_0)));
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1265$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1265$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run$1266$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1266$(_registry_0, ($$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1262$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $checkpoint$058ids$1261$(_handles_0) {
  if (_handles_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _handles_0["head"];
    const _id_0 = _t_0["id"];
    const _rest_0 = _handles_0["tail"];
    return {$: "Con", "head": _id_0, "tail": ($checkpoint$058ids$1261$(_rest_0))};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058handles_tail_finish$1261$(_scanned_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _scanned_0["live"];
  const _handles_0 = _scanned_0["handles"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _handles_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058collect_tail$1261$(_remaining_0, _namespace_0, _live_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058collect_tail_loop$1261$(nat_chk(2 * _remaining_0), _remaining_0, _namespace_0, {$: "../../../src/ecs/world.WorldTailScanReady", "live": _live_0, "handles": {$: "Nil"}});
}

function $store$045view$058velocity_viewed$1261$(_id_0, _position_0, _health_0, _p_0, _observed_0) {
  const _velocity_0 = _observed_0["fst"];
  const _v_0 = _observed_0["snd"];
  return $store$045view$058health_viewed$1261$(_id_0, _position_0, _velocity_0, _p_0, _v_0, ($$$$047$$$047$$$047src$047ecs$047column$058view$1262$(_health_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1262$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1262$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1262$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1262$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1262$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $owner$045view$058prepended$(_value_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _values_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Con", "head": _value_0, "tail": _values_0}};
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058reject_input$1261$(_input_0, _runtime_0, _reader_0, _registry_0) {
  const _args_0 = _input_0["args"];
  return {$: "../../../src/ecs/event-runtime.Ran", "runtime": _runtime_0, "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../src/ecs/event-runtime.Rejected", "args": _args_0}};
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_outcome$1261$(_outcome_0, _reader_0, _registry_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/event-runtime.Ran", "runtime": {$: "../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _readerId_0, (_tick_0 < 1 ? 0 : _tick_0 - 1))), "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../src/ecs/event-runtime.Failed", "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return {$: "../../../src/ecs/event-runtime.Ran", "runtime": ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_values$1261$(($$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_1)), _namespace_0, _batches_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(($$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _readerId_0, (_tick_0 < 1 ? 0 : _tick_0 - 1))), _readerId_0, _tick_0, false)), _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0)), "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../src/ecs/event-runtime.Succeeded", "output": _output_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1267$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1267$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058since_checked$1260$(_visible_0, _items_0, _rest_0) {
  if (!_visible_0) {
    return _rest_0;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1262$(_items_0, _rest_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1260$(($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world_result$1260$(_returned_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _returned_0["fst"];
  const _output_0 = _returned_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_values$1260$(($$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0)), "snd": _output_0};
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1260$(($$$$047$$$047$$$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0)));
}

function $gameplay$058movement_registered$1260$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _movement_0 = _result_0["registry"];
    return $gameplay$058damage_registered$1260$(_movement_0, ($systems$058register_damage$1260$(_world_0)));
  } else {
    const _world_1 = _result_0["world"];
    return {$: "gameplay.GameplayMovementRefused", "world": _world_1};
  }
}

function $systems$058register_movement$1260$(_world_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058register$1262$(_world_0, "Simulation/Move", {$: "Con", "head": "write:Simulation/Position", "tail": {$: "Con", "head": "read:Simulation/Velocity", "tail": {$: "Con", "head": "write:Simulation/Step", "tail": {$: "Nil"}}}});
}

function $runtime$045gameplay$058damage_synced$1260$(_movement_0, _moved_0, _observed_0) {
  const _runtime_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _damage_0 = _t_0["registry"];
  const _outcome_0 = _t_0["outcome"];
  const _damaged_0 = _t_0["values"];
  return {$: "Tuple", "fst": {$: "runtime-gameplay.State", "runtime": _runtime_0, "movement": _movement_0, "damage": _damage_0}, "snd": {$: "runtime-gameplay.FrameOutput", "outcome": _outcome_0, "moved": _moved_0, "damaged": _damaged_0}};
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world$1262$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world_result$1262$(_effect_0(_world_0), _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $runtime$045gameplay$058damage_returned$1260$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _t_0 = _result_0["outcome"];
    if (_t_0.$ === "../../../src/ecs/system.Succeeded") {
      const _world_0 = _t_0["world"];
      const _values_0 = _t_0["output"];
      return {$: "Tuple", "fst": _world_0, "snd": {$: "runtime-gameplay.DamageOutput", "registry": _registry_0, "outcome": {$: "../../../src/ecs/transaction.Success"}, "values": _values_0}};
    } else {
      const _world_1 = _t_0["world"];
      const _error_0 = _t_0["error"];
      return {$: "Tuple", "fst": _world_1, "snd": {$: "runtime-gameplay.DamageOutput", "registry": _registry_0, "outcome": {$: "../../../src/ecs/transaction.Failure", "error": {$: "gameplay-run.DamageRunFailed", "error": _error_0}}, "values": {$: "Nil"}}};
    }
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_2 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "Tuple", "fst": _world_2, "snd": {$: "runtime-gameplay.DamageOutput", "registry": _registry_1, "outcome": {$: "../../../src/ecs/transaction.Failure", "error": {$: "gameplay-run.DamageRunRegistrationRefused", "args": _args_0}}, "values": {$: "Nil"}}};
  }
}

function $systems$058run_damage$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1261$(_registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world_result$1263$(_returned_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _returned_0["fst"];
  const _output_0 = _returned_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_values$1260$(($$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0)), "snd": _output_0};
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1262$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1262$(($$$$047$$$047$$$047src$047ecs$047system$058run$1262$(_registry_0, _world_0, _args_0)));
}

function $checkpoint$058live_known$1260$(_label_0, _allocation_0, _resource_0, _cells_0, _events_0, _pending_0, _clock_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _handles_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "checkpoint.Snapshot", "label": _label_0, "allocation": _allocation_0, "resource": _resource_0, "cells": _cells_0, "events": _events_0, "pending": _pending_0, "clock": _clock_0, "live": ($checkpoint$058ids$1260$(_handles_0))}};
}

function $$$$047$$$047$$$047src$047ecs$047world$058handles$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058handles_tail_finish$1260$(($$$$047$$$047$$$047src$047ecs$047world$058collect_tail$1260$(_highWater_0, _namespace_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058pending_prepend$1260$(_command_0, _counted_0) {
  const _commands_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": ((_count_0 + 1) >>> 0)};
}

function $store$045view$058collected_head$1260$(_head_0, _observed_0) {
  const _store_0 = _observed_0["fst"];
  const _tail_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _store_0, "snd": {$: "Con", "head": _head_0, "tail": _tail_0}};
}

function $store$045view$058position_viewed$1260$(_id_0, _velocity_0, _health_0, _observed_0) {
  const _position_0 = _observed_0["fst"];
  const _p_0 = _observed_0["snd"];
  return $store$045view$058velocity_viewed$1260$(_id_0, _position_0, _health_0, _p_0, ($$$$047$$$047$$$047src$047ecs$047column$058view$1260$(_velocity_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058view$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_registered_result$1260$(_result_0, _reader_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_result_0.$ === "../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058reject_input$1260$(_args_0, {$: "../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, _reader_0, _registry_0);
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_outcome$1260$(_outcome_0, _reader_0, _registry_1, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run$1263$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1263$(_registry_0, ($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_join$1264$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1264$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1263$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1263$(_registry_0, _output_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_1)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1264$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1264$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058register$1265$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1265$(($$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1266$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_join$1266$(($$$$047$$$047$$$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1264$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1264$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run$1265$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1265$(_registry_0, ($$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1265$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1265$(_registry_0, _output_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_1)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1266$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1266$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058collect_tail_loop$1261$($0, $1, $2, $3) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _remaining_0 = $1;
      const _namespace_0 = $2;
      const _phase_0 = $3;
      if (_fuel_0 === 0) {
        if (_phase_0.$ === "../../../src/ecs/world.WorldTailScanReady") {
          const _live_0 = _phase_0["live"];
          const _handles_0 = _phase_0["handles"];
          return {$: "../../../src/ecs/world.HandleScan", "live": _live_0, "handles": _handles_0};
        } else {
          const _t_0 = _phase_0["checked"];
          const _live_1 = _t_0["fst"];
          const _handles_1 = _phase_0["handles"];
          return {$: "../../../src/ecs/world.HandleScan", "live": _live_1, "handles": _handles_1};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0 === 0) {
          if (_phase_0.$ === "../../../src/ecs/world.WorldTailScanReady") {
            const _live_2 = _phase_0["live"];
            const _handles_2 = _phase_0["handles"];
            return {$: "../../../src/ecs/world.HandleScan", "live": _live_2, "handles": _handles_2};
          } else {
            const _t_1 = _phase_0["checked"];
            const _live_3 = _t_1["fst"];
            const _handles_3 = _phase_0["handles"];
            return {$: "../../../src/ecs/world.HandleScan", "live": _live_3, "handles": _handles_3};
          }
        } else {
          const _rest_0 = (_remaining_0 - 1);
          if (_phase_0.$ === "../../../src/ecs/world.WorldTailScanReady") {
            const _live_4 = _phase_0["live"];
            const _handles_4 = _phase_0["handles"];
            const _x_0 = nat_chk(_rest_0 + 1);
            const _x_1 = (_x_0 >>> 0);
            $0 = _more_0;
            $1 = nat_chk(_rest_0 + 1);
            $2 = _namespace_0;
            $3 = {$: "../../../src/ecs/world.WorldTailScanRead", "checked": {$: "Tuple", fst: _live_4, snd: _live_4[_x_1 % _live_4.length]}, "handles": _handles_4};
            continue;
          } else {
            const _t_2 = _phase_0["checked"];
            const _live_5 = _t_2["fst"];
            const _present_0 = _t_2["snd"];
            const _handles_5 = _phase_0["handles"];
            const _x_2 = nat_chk(_rest_0 + 1);
            $0 = _more_0;
            $1 = _rest_0;
            $2 = _namespace_0;
            $3 = {$: "../../../src/ecs/world.WorldTailScanReady", "live": _live_5, "handles": ($$$$047$$$047$$$047src$047ecs$047world$058collect_checked$1261$(_present_0, _namespace_0, (_x_2 >>> 0), _handles_5))};
            continue;
          }
        }
      }
    }
  }
}

function $store$045view$058health_viewed$1261$(_id_0, _position_0, _velocity_0, _p_0, _v_0, _observed_0) {
  const _health_0 = _observed_0["fst"];
  const _h_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.Store", "position": _position_0, "velocity": _velocity_0, "health": _health_0}, "snd": {$: "store-view.EntityCells", "id": _id_0, "position": _p_0, "velocity": _v_0, "health": _h_0}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1262$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1262$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1262$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1262$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1262$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1262$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1262$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1262$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _registered_0) {
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058activation$(($$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _positions_0, _id_0, _registered_0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _cursor_0, _dispose_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _positions_0["head"];
    const _actual_0 = _t_0["id"];
    const _old_0 = _t_0["cursor"];
    const _registered_0 = _t_0["registeredAt"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058update_checked$((_actual_0 === _id_0), _dispose_0, _actual_0, _old_0, _registered_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_rest_0, _id_0, _cursor_0, _dispose_0)), _cursor_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1267$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1267$((_namespace_0 === _actual_0), {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1260$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_join$1260$(($$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1260$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1260$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, ($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $gameplay$058damage_registered$1260$(_movement_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _damage_0 = _result_0["registry"];
    return {$: "gameplay.GameplayInstalled", "game": {$: "gameplay.Gameplay", "world": _world_0, "movement": _movement_0, "damage": _damage_0}};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "gameplay.GameplayDamageRefused", "world": _world_1, "movement": _movement_0};
  }
}

function $systems$058register_damage$1260$(_world_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058register$1261$(_world_0, "Simulation/Damage", {$: "Con", "head": "read:Simulation/Position", "tail": {$: "Con", "head": "write:Simulation/Health", "tail": {$: "Con", "head": "write:Simulation/Hit", "tail": {$: "Con", "head": "write:Simulation/Death", "tail": {$: "Con", "head": "command:despawn", "tail": {$: "Nil"}}}}}});
}

function $$$$047$$$047$$$047src$047ecs$047system$058register$1262$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1262$(($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world_result$1262$(_returned_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _returned_0["fst"];
  const _output_0 = _returned_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_values$1260$(($$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0)), "snd": _output_0};
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1261$(($$$$047$$$047$$$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0)));
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1262$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1262$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run$1262$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1262$(_registry_0, ($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $checkpoint$058ids$1260$(_handles_0) {
  if (_handles_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _handles_0["head"];
    const _id_0 = _t_0["id"];
    const _rest_0 = _handles_0["tail"];
    return {$: "Con", "head": _id_0, "tail": ($checkpoint$058ids$1260$(_rest_0))};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058handles_tail_finish$1260$(_scanned_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _scanned_0["live"];
  const _handles_0 = _scanned_0["handles"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _handles_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058collect_tail$1260$(_remaining_0, _namespace_0, _live_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058collect_tail_loop$1260$(nat_chk(2 * _remaining_0), _remaining_0, _namespace_0, {$: "../../../src/ecs/world.WorldTailScanReady", "live": _live_0, "handles": {$: "Nil"}});
}

function $store$045view$058velocity_viewed$1260$(_id_0, _position_0, _health_0, _p_0, _observed_0) {
  const _velocity_0 = _observed_0["fst"];
  const _v_0 = _observed_0["snd"];
  return $store$045view$058health_viewed$1260$(_id_0, _position_0, _velocity_0, _p_0, _v_0, ($$$$047$$$047$$$047src$047ecs$047column$058view$1260$(_health_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058reject_input$1260$(_input_0, _runtime_0, _reader_0, _registry_0) {
  const _args_0 = _input_0["args"];
  return {$: "../../../src/ecs/event-runtime.Ran", "runtime": _runtime_0, "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../src/ecs/event-runtime.Rejected", "args": _args_0}};
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_outcome$1260$(_outcome_0, _reader_0, _registry_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/event-runtime.Ran", "runtime": {$: "../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _readerId_0, (_tick_0 < 1 ? 0 : _tick_0 - 1))), "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../src/ecs/event-runtime.Failed", "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return {$: "../../../src/ecs/event-runtime.Ran", "runtime": ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_values$1260$(($$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_1)), _namespace_0, _batches_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(($$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _readerId_0, (_tick_0 < 1 ? 0 : _tick_0 - 1))), _readerId_0, _tick_0, false)), _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0)), "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../src/ecs/event-runtime.Succeeded", "output": _output_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1263$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1263$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1264$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1263$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1263$({$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1264$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1264$((_namespace_0 === _actual_0), {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1265$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_join$1265$(($$$$047$$$047$$$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_join$1266$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1266$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1264$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1264$(_registry_0, _output_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_1)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1265$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1265$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1265$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1265$({$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1266$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1266$((_namespace_0 === _actual_0), {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058collect_checked$1261$(_present_0, _namespace_0, _id_0, _handles_0) {
  if (!_present_0) {
    return _handles_0;
  } else {
    return {$: "Con", "head": {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _handles_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1262$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1262$(_values_0, _stamps_0, _id_0, ($owner$045view$058view$(_owner_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($owner$045view$058view$(_owned_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1262$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047src$047ecs$047column$058view_taken$1262$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058seek_view$1262$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1262$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1262$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($owner$045view$058view$(_owned_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1262$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047src$047ecs$047column$058view_taken$1262$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1262$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058activation$(_position_0, _positions_0, _id_0, _registered_0) {
  if (_position_0.$ === "None") {
    return {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _registered_0}, "tail": _positions_0};
  } else {
    return _positions_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058update_checked$(_found_0, _dispose_0, _id_0, _old_0, _registered_0, _rest_0, _cursor_0) {
  if (!_found_0) {
    return {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": _old_0, "registeredAt": _registered_0}, "tail": _rest_0};
  } else {
    if (!_dispose_0) {
      return {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": _cursor_0, "registeredAt": _registered_0}, "tail": _rest_0};
    } else {
      return _rest_0;
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1267$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1267$({$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_join$1260$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1260$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register$1261$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1261$(($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1262$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_join$1262$(($$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1261$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1261$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1261$(_registry_0, ($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1262$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1262$(_registry_0, _output_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1262$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1262$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058collect_tail_loop$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _remaining_0 = $1;
      const _namespace_0 = $2;
      const _phase_0 = $3;
      if (_fuel_0 === 0) {
        if (_phase_0.$ === "../../../src/ecs/world.WorldTailScanReady") {
          const _live_0 = _phase_0["live"];
          const _handles_0 = _phase_0["handles"];
          return {$: "../../../src/ecs/world.HandleScan", "live": _live_0, "handles": _handles_0};
        } else {
          const _t_0 = _phase_0["checked"];
          const _live_1 = _t_0["fst"];
          const _handles_1 = _phase_0["handles"];
          return {$: "../../../src/ecs/world.HandleScan", "live": _live_1, "handles": _handles_1};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0 === 0) {
          if (_phase_0.$ === "../../../src/ecs/world.WorldTailScanReady") {
            const _live_2 = _phase_0["live"];
            const _handles_2 = _phase_0["handles"];
            return {$: "../../../src/ecs/world.HandleScan", "live": _live_2, "handles": _handles_2};
          } else {
            const _t_1 = _phase_0["checked"];
            const _live_3 = _t_1["fst"];
            const _handles_3 = _phase_0["handles"];
            return {$: "../../../src/ecs/world.HandleScan", "live": _live_3, "handles": _handles_3};
          }
        } else {
          const _rest_0 = (_remaining_0 - 1);
          if (_phase_0.$ === "../../../src/ecs/world.WorldTailScanReady") {
            const _live_4 = _phase_0["live"];
            const _handles_4 = _phase_0["handles"];
            const _x_0 = nat_chk(_rest_0 + 1);
            const _x_1 = (_x_0 >>> 0);
            $0 = _more_0;
            $1 = nat_chk(_rest_0 + 1);
            $2 = _namespace_0;
            $3 = {$: "../../../src/ecs/world.WorldTailScanRead", "checked": {$: "Tuple", fst: _live_4, snd: _live_4[_x_1 % _live_4.length]}, "handles": _handles_4};
            continue;
          } else {
            const _t_2 = _phase_0["checked"];
            const _live_5 = _t_2["fst"];
            const _present_0 = _t_2["snd"];
            const _handles_5 = _phase_0["handles"];
            const _x_2 = nat_chk(_rest_0 + 1);
            $0 = _more_0;
            $1 = _rest_0;
            $2 = _namespace_0;
            $3 = {$: "../../../src/ecs/world.WorldTailScanReady", "live": _live_5, "handles": ($$$$047$$$047$$$047src$047ecs$047world$058collect_checked$1260$(_present_0, _namespace_0, (_x_2 >>> 0), _handles_5))};
            continue;
          }
        }
      }
    }
  }
}

function $store$045view$058health_viewed$1260$(_id_0, _position_0, _velocity_0, _p_0, _v_0, _observed_0) {
  const _health_0 = _observed_0["fst"];
  const _h_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.Store", "position": _position_0, "velocity": _velocity_0, "health": _health_0}, "snd": {$: "store-view.EntityCells", "id": _id_0, "position": _p_0, "velocity": _v_0, "health": _h_0}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1263$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1263$((_namespace_0 === _actual_0), {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1263$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../src/ecs/system.Completed", "registry": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1264$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1264$({$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_join$1265$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1265$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1266$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1264$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1264$({$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1265$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1265$((_namespace_0 === _actual_0), {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1265$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../src/ecs/system.Completed", "registry": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1266$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1266$({$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1262$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047src$047ecs$047column$058restored$1262$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058view_taken$1262$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047$$$047src$047ecs$047column$058viewed$1262$(($owner$045view$058view$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return {$: "../../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058seek_view$1262$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1262$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($owner$045view$058view$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1262$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1262$(_id_0, _values_0, _metadata_0, ($owner$045view$058view$(_owner_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1262$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1262$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($owner$045view$058view$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1267$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1267$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1260$({$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1261$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_join$1261$(($$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_join$1262$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1262$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1261$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1261$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1262$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1262$({$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1262$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1262$((_namespace_0 === _actual_0), {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058collect_checked$1260$(_present_0, _namespace_0, _id_0, _handles_0) {
  if (!_present_0) {
    return _handles_0;
  } else {
    return {$: "Con", "head": {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _handles_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, ($owner$045view$058view$(_owner_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($owner$045view$058view$(_owned_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058seek_view$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($owner$045view$058view$(_owned_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1263$({$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1264$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1264$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1265$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1264$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../src/ecs/system.Completed", "registry": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1265$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1265$({$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1266$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1266$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047column$058restored$1262$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058viewed$1262$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047$$$047src$047ecs$047column$058restored$1262$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1262$(_result_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1261$({$: "../../../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1262$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1262$(_result_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1261$({$: "../../../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$($0, $1) {
  for (;;) {
    {
      const _rows_0 = $0;
      const _values_0 = $1;
      if (_rows_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
        return _values_0;
      } else {
        const _id_0 = _rows_0["id"];
        const _owner_0 = _rows_0["owner"];
        const _rest_0 = _rows_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        const _x_1 = {$: "Some", "value": _owner_0};
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _x_1, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1262$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1262$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1267$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047system$058complete$1267$(_registry_0, ($$$$047readers$045v1$047readers$058runner$1261$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1260$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../src/ecs/system.Completed", "registry": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1260$({$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_join$1261$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1262$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1261$({$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1261$((_namespace_0 === _actual_0), {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1262$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../src/ecs/system.Completed", "registry": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1262$({$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047$$$047src$047ecs$047column$058viewed$1260$(($owner$045view$058view$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return {$: "../../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($owner$045view$058view$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, ($owner$045view$058view$(_owner_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($owner$045view$058view$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1263$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1264$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047system$058complete$1264$(_registry_0, ($spawn$045system$058runner$1261$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1265$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1265$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1266$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047system$058complete$1266$(_registry_0, ($systems$058movement_runner$1261$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1262$(_view_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1262$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1262$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058swapped$1261$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1262$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047src$047ecs$047system$058complete$1267$(_registry_0, _outcome_0) {
  return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047readers$045v1$047readers$058runner$1261$(_world_0, _input_0) {
  const _items_0 = _input_0["values"];
  const _lagged_0 = _input_0["lagged"];
  const _t_0 = _input_0["args"];
  const _journal_0 = _t_0["journal"];
  const _fail_0 = _t_0["fail"];
  return $$$$047readers$045v1$047readers$058decide$1261$(_fail_0, _world_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1261$(_journal_0, {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Reading", "values": _items_0, "lagged": _lagged_0}, "tail": {$: "Nil"}})));
}

function $$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1261$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../src/ecs/system.Completed", "registry": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1261$({$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1262$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047column$058restored$1260$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058viewed$1260$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047$$$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1260$({$: "../../../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1260$({$: "../../../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047system$058complete$1263$(_registry_0, ($$$$047readers$045v1$047readers$058runner$1260$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058complete$1264$(_registry_0, _outcome_0) {
  return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $spawn$045system$058runner$1261$(_world_0, _args_0) {
  return $spawn$045system$058first$1261$(($spawn$058spawn$1261$(_world_0, ($spawn$058payload$(0, 1, 2, 100)))));
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1265$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047system$058complete$1265$(_registry_0, ($systems$058damage_runner$1261$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058complete$1266$(_registry_0, _outcome_0) {
  return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $systems$058movement_runner$1261$(_world_0, _args_0) {
  return $systems$058returned$1263$(($movement$058execute$1261$(_args_0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058swapped$1261$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047readers$045v1$047readers$058decide$1261$(_fail_0, _world_0, _journal_0) {
  if (!_fail_0) {
    return {$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": _journal_0};
  } else {
    return {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": {$: "../readers-v1/readers.ReaderFailed", "journal": _journal_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1261$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1261$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $$$$047$$$047$$$047src$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047system$058complete$1260$(_registry_0, ($spawn$045system$058runner$1260$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1261$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047system$058complete$1262$(_registry_0, ($systems$058movement_runner$1260$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_view_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058swapped$1260$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047src$047ecs$047system$058complete$1263$(_registry_0, _outcome_0) {
  return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047readers$045v1$047readers$058runner$1260$(_world_0, _input_0) {
  const _items_0 = _input_0["values"];
  const _lagged_0 = _input_0["lagged"];
  const _t_0 = _input_0["args"];
  const _journal_0 = _t_0["journal"];
  const _fail_0 = _t_0["fail"];
  return $$$$047readers$045v1$047readers$058decide$1260$(_fail_0, _world_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1261$(_journal_0, {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Reading", "values": _items_0, "lagged": _lagged_0}, "tail": {$: "Nil"}})));
}

function $spawn$045system$058first$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _reservation_0 = _observed_0["snd"];
  return $spawn$045system$058second$1261$({$: "Con", "head": _reservation_0, "tail": {$: "Nil"}}, ($spawn$058spawn$1261$(_world_0, ($spawn$058payload$(0, 2, 1, 200)))));
}

function $spawn$058spawn$1261$(_world_0, _payload_0) {
  return $spawn$058staged$1261$(($$$$047$$$047$$$047src$047ecs$047commands$058tx_spawn$1261$(($$$$047$$$047$$$047src$047ecs$047transaction$058begin$1262$(_world_0)), _payload_0)));
}

function $spawn$058payload$(_position_0, _velocity_0, _health_0, _sentinel_0) {
  return {$: "spawn.SpawnPayload", "position": ($spawn$058cell$(_position_0, _sentinel_0)), "velocity": ($spawn$058cell$(_velocity_0, ((_sentinel_0 + 1) >>> 0))), "health": ($spawn$058cell$(_health_0, ((_sentinel_0 + 2) >>> 0)))};
}

function $$$$047$$$047$$$047src$047ecs$047system$058complete$1265$(_registry_0, _outcome_0) {
  return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $systems$058damage_runner$1261$(_world_0, _args_0) {
  return $systems$058returned$1262$(($damage$058execute$1261$(_args_0, _world_0)));
}

function $systems$058returned$1263$(_result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../../src/ecs/transaction.Success") {
    const _values_0 = _result_0["values"];
    return {$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": _values_0};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0};
  }
}

function $movement$058execute$1261$(_fixed_step_0, _world_0) {
  return $movement$045transaction$058execute$1261$(_fixed_step_0, _world_0);
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1261$({$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047src$047ecs$047column$058seek$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1261$({$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047world$058matching_access$(($$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $spawn$045system$058runner$1260$(_world_0, _args_0) {
  return $spawn$045system$058first$1260$(($spawn$058spawn$1260$(_world_0, ($spawn$058payload$(0, 1, 2, 100)))));
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047system$058complete$1261$(_registry_0, ($systems$058damage_runner$1260$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058complete$1262$(_registry_0, _outcome_0) {
  return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $systems$058movement_runner$1260$(_world_0, _args_0) {
  return $systems$058returned$1261$(($movement$058execute$1260$(_args_0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058swapped$1260$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047readers$045v1$047readers$058decide$1260$(_fail_0, _world_0, _journal_0) {
  if (!_fail_0) {
    return {$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": _journal_0};
  } else {
    return {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": {$: "../readers-v1/readers.ReaderFailed", "journal": _journal_0}};
  }
}

function $spawn$045system$058second$1261$(_reservations_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _reservation_0 = _observed_0["snd"];
  return $spawn$045system$058third$1261$({$: "Con", "head": _reservation_0, "tail": _reservations_0}, ($spawn$058spawn$1261$(_world_0, ($spawn$058payload$(0, 1, 1, 300)))));
}

function $spawn$058staged$1261$(_observed_0) {
  const _t_0 = _observed_0["fst"];
  const _world_0 = _t_0["world"];
  const _commands_0 = _t_0["commands"];
  const _reservation_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1261$(_world_0, _commands_0)), "snd": _reservation_0};
}

function $$$$047$$$047$$$047src$047ecs$047commands$058tx_spawn$1261$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047commands$058spawn_join$1261$(($$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0)), _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058begin$1262$(_world_0) {
  return {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $systems$058returned$1262$(_result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../../src/ecs/transaction.Success") {
    const _values_0 = _result_0["values"];
    return {$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": _values_0};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0};
  }
}

function $damage$058execute$1261$(_args_0, _world_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058each$1261$(_args_0, _world_0);
}

function $movement$045transaction$058execute$1261$(_args_0, _world_0) {
  return $movement$045transaction$058traversed$1261$(_args_0, ($$$$047$$$047$$$047src$047ecs$047world$058handles$1261$(_world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover$1261$(_column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058recover_state$1261$(($$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1261$(($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $spawn$045system$058first$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _reservation_0 = _observed_0["snd"];
  return $spawn$045system$058second$1260$({$: "Con", "head": _reservation_0, "tail": {$: "Nil"}}, ($spawn$058spawn$1260$(_world_0, ($spawn$058payload$(0, 2, 1, 200)))));
}

function $spawn$058spawn$1260$(_world_0, _payload_0) {
  return $spawn$058staged$1260$(($$$$047$$$047$$$047src$047ecs$047commands$058tx_spawn$1260$(($$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)), _payload_0)));
}

function $$$$047$$$047$$$047src$047ecs$047system$058complete$1261$(_registry_0, _outcome_0) {
  return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $systems$058damage_runner$1260$(_world_0, _args_0) {
  return $systems$058returned$1260$(($damage$058execute$1260$(_args_0, _world_0)));
}

function $systems$058returned$1261$(_result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../../src/ecs/transaction.Success") {
    const _values_0 = _result_0["values"];
    return {$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": _values_0};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0};
  }
}

function $movement$058execute$1260$(_fixed_step_0, _world_0) {
  return $movement$045transaction$058execute$1260$(_fixed_step_0, _world_0);
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1260$({$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047src$047ecs$047column$058seek$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1260$({$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $spawn$045system$058third$1261$(_reservations_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _reservation_0 = _observed_0["snd"];
  return {$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": ($List$reverse$({$: "Con", "head": _reservation_0, "tail": _reservations_0}))};
}

function $$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1261$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1261$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047src$047ecs$047commands$058spawn_join$1261$(_reserved_0, _undo_0, _commands_0, _events_0, _payload_0) {
  const _world_0 = _reserved_0["fst"];
  const _reservation_0 = _reserved_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047commands$058spawn_reserved$1261$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1261$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047src$047ecs$047compose$058each$1261$(_args_0, _world_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058reserved$1261$(_args_0, 0, ($$$$047$$$047$$$047src$047ecs$047world$058handles$1261$(_world_0)));
}

function $movement$045transaction$058traversed$1261$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _handles_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058finished$1263$(run_loop($$$$047$$$047$$$047src$047ecs$047compose$058run_handles$1263$(_handles_0, _args_0, 0, ($step$058begin$1261$(_world_0)))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $spawn$045system$058second$1260$(_reservations_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _reservation_0 = _observed_0["snd"];
  return $spawn$045system$058third$1260$({$: "Con", "head": _reservation_0, "tail": _reservations_0}, ($spawn$058spawn$1260$(_world_0, ($spawn$058payload$(0, 1, 1, 300)))));
}

function $spawn$058staged$1260$(_observed_0) {
  const _t_0 = _observed_0["fst"];
  const _world_0 = _t_0["world"];
  const _commands_0 = _t_0["commands"];
  const _reservation_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, _commands_0)), "snd": _reservation_0};
}

function $$$$047$$$047$$$047src$047ecs$047commands$058tx_spawn$1260$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047commands$058spawn_join$1260$(($$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0)), _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $systems$058returned$1260$(_result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../../src/ecs/transaction.Success") {
    const _values_0 = _result_0["values"];
    return {$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": _values_0};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0};
  }
}

function $damage$058execute$1260$(_args_0, _world_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058each$1260$(_args_0, _world_0);
}

function $movement$045transaction$058execute$1260$(_args_0, _world_0) {
  return $movement$045transaction$058traversed$1260$(_args_0, ($$$$047$$$047$$$047src$047ecs$047world$058handles$1260$(_world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover$1260$(_column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058recover_state$1260$(($$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1260$(($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1261$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058spawn_reserved$1261$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0) {
  if (_reservation_0.$ === "../../../src/ecs/world.ReservationRejected") {
    const _error_0 = _reservation_0["error"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "../../../src/ecs/world.ReservationRejected", "error": _error_0}};
  } else {
    const _handle_0 = _reservation_0["handle"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047commands$058spawn_apply$1261$(_x_0, _handle_0, _payload_0);
}), "tail": _commands_0}, "events": _events_0}, "snd": {$: "../../../src/ecs/world.Reserved", "handle": _handle_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1261$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/world.ReservationRejected", "error": {$: "../../../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$({$: "../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$(($$$$047$$$047$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047src$047ecs$047compose$058reserved$1261$(_args_0, _cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _handles_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058finished$1262$(run_loop($$$$047$$$047$$$047src$047ecs$047compose$058run_handles$1262$(_handles_0, _args_0, _cursor_0, ($$$$047$$$047$$$047src$047ecs$047transaction$058begin$1263$(_world_0)))));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058finished$1263$(_observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _result_0 = _t_0["fst"];
  const _values_0 = _t_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058finish_returned$1263$(_values_0, ($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1263$(_tx_0, _result_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058run_handles$1263$(_handles_0, _args_0, _cursor_0, _tx_0) {
  if (_handles_0.$ === "Nil") {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Success"}, "snd": {$: "Nil"}}};
  } else {
    const _handle_0 = _handles_0["head"];
    const _rest_0 = _handles_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047compose$058selected$1263$(_args_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047compose$058run_handles$1263$(_rest_0, _args_0, _cursor_0, _x_0);
}), ($$$$047$$$047$$$047src$047ecs$047compose$058plan_select$1263$(($movement$058plan$1261$())))({$: "../../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": {$: "None"}, "cursor": _cursor_0}));
  }
}

function $step$058begin$1261$(_world_0) {
  return $step$058advanced$1261$(($$$$047$$$047$$$047src$047ecs$047resource$058tx_get$1261$(($$$$047$$$047$$$047src$047ecs$047transaction$058begin$1262$(_world_0)))));
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

function $spawn$045system$058third$1260$(_reservations_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _reservation_0 = _observed_0["snd"];
  return {$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": ($List$reverse$({$: "Con", "head": _reservation_0, "tail": _reservations_0}))};
}

function $$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047src$047ecs$047commands$058spawn_join$1260$(_reserved_0, _undo_0, _commands_0, _events_0, _payload_0) {
  const _world_0 = _reserved_0["fst"];
  const _reservation_0 = _reserved_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047commands$058spawn_reserved$1260$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1260$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047src$047ecs$047compose$058each$1260$(_args_0, _world_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058reserved$1260$(_args_0, 0, ($$$$047$$$047$$$047src$047ecs$047world$058handles$1260$(_world_0)));
}

function $movement$045transaction$058traversed$1260$(_args_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _handles_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058finished$1261$(run_loop($$$$047$$$047$$$047src$047ecs$047compose$058run_handles$1261$(_handles_0, _args_0, 0, ($step$058begin$1260$(_world_0)))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047src$047ecs$047commands$058spawn_apply$1261$(_world_0, _handle_0, _payload_0) {
  return $$$$047$$$047$$$047src$047ecs$047commands$058spawned$1261$(($$$$047$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../src/ecs/world.Reserved", "handle": {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047compose$058finished$1262$(_observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _result_0 = _t_0["fst"];
  const _values_0 = _t_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058finish_returned$1262$(_values_0, ($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1262$(_tx_0, _result_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058run_handles$1262$(_handles_0, _args_0, _cursor_0, _tx_0) {
  if (_handles_0.$ === "Nil") {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Success"}, "snd": {$: "Nil"}}};
  } else {
    const _handle_0 = _handles_0["head"];
    const _rest_0 = _handles_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047compose$058selected$1262$(_args_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047compose$058run_handles$1262$(_rest_0, _args_0, _cursor_0, _x_0);
}), ($$$$047$$$047$$$047src$047ecs$047compose$058plan_select$1262$(($damage$058plan$1261$())))({$: "../../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": {$: "None"}, "cursor": _cursor_0}));
  }
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058begin$1263$(_world_0) {
  return {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058finish_returned$1263$(_values_0, _returned_0) {
  const _world_0 = _returned_0["world"];
  const _t_0 = _returned_0["outcome"];
  if (_t_0.$ === "../../../src/ecs/transaction.Success") {
    return {$: "../../../src/ecs/compose.Executed", "world": _world_0, "outcome": {$: "../../../src/ecs/transaction.Success"}, "values": _values_0};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../src/ecs/compose.Executed", "world": _world_0, "outcome": {$: "../../../src/ecs/transaction.Failure", "error": _error_0}, "values": {$: "Nil"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1263$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047src$047ecs$047transaction$058finish$1263$(_tx_0, _outcome_0);
}

function $$$$047$$$047$$$047src$047ecs$047compose$058selected$1263$(_args_0, _next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const __0 = _t_0["handle"];
  const __1 = _t_0["error"];
  const __2 = _t_0["cursor"];
  const _t_1 = _observed_0["snd"];
  if (!_t_1) {
    return run_tail(_next_0, _tx_0);
  } else {
    return $$$$047$$$047$$$047src$047ecs$047compose$058body_returned$1263$(_next_0, ($$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1263$(_args_0, {$: "../../../src/ecs/compose.Frame", "tx": _tx_0, "handle": __0, "error": __1, "cursor": __2})));
  }
}

function $$$$047$$$047$$$047src$047ecs$047compose$058plan_select$1263$(_plan_0) {
  const _select_0 = _plan_0["select"];
  return _select_0;
}

function $movement$058plan$1261$() {
  return {$: "../../../src/ecs/compose.Plan", "caps": {$: "movement.MovementOps", "position": ($$$$047$$$047$$$047src$047ecs$047compose$058write_family$1263$()), "velocity": ($$$$047$$$047$$$047src$047ecs$047compose$058read_family$1263$())}, "select": run_clo((_x_0) => {
  return $movement$058selected$1261$(_x_0);
})};
}

function $step$058advanced$1261$(_observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _value_0 = _t_0["value"];
  const _sentinel_0 = _t_0["sentinel"];
  return $$$$047$$$047$$$047src$047ecs$047resource$058tx_replace$1261$(_tx_0, array_node([((_value_0 + 1) >>> 0)], [_sentinel_0]));
}

function $$$$047$$$047$$$047src$047ecs$047resource$058tx_get$1261$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047resource$058get_join$1261$(($$$$047$$$047$$$047src$047ecs$047world$058observe_resource$1263$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058spawn_reserved$1260$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0) {
  if (_reservation_0.$ === "../../../src/ecs/world.ReservationRejected") {
    const _error_0 = _reservation_0["error"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "../../../src/ecs/world.ReservationRejected", "error": _error_0}};
  } else {
    const _handle_0 = _reservation_0["handle"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047commands$058spawn_apply$1260$(_x_0, _handle_0, _payload_0);
}), "tail": _commands_0}, "events": _events_0}, "snd": {$: "../../../src/ecs/world.Reserved", "handle": _handle_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1260$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/world.ReservationRejected", "error": {$: "../../../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$({$: "../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(($$$$047$$$047$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047compose$058reserved$1260$(_args_0, _cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _handles_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058finished$1260$(run_loop($$$$047$$$047$$$047src$047ecs$047compose$058run_handles$1260$(_handles_0, _args_0, _cursor_0, ($$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0)))));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058finished$1261$(_observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _result_0 = _t_0["fst"];
  const _values_0 = _t_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058finish_returned$1261$(_values_0, ($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, _result_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058run_handles$1261$(_handles_0, _args_0, _cursor_0, _tx_0) {
  if (_handles_0.$ === "Nil") {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Success"}, "snd": {$: "Nil"}}};
  } else {
    const _handle_0 = _handles_0["head"];
    const _rest_0 = _handles_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047compose$058selected$1261$(_args_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047compose$058run_handles$1261$(_rest_0, _args_0, _cursor_0, _x_0);
}), ($$$$047$$$047$$$047src$047ecs$047compose$058plan_select$1261$(($movement$058plan$1260$())))({$: "../../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": {$: "None"}, "cursor": _cursor_0}));
  }
}

function $step$058begin$1260$(_world_0) {
  return $step$058advanced$1260$(($$$$047$$$047$$$047src$047ecs$047resource$058tx_get$1260$(($$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)))));
}

function $$$$047$$$047$$$047src$047ecs$047commands$058spawned$1261$(_activated_0, _handle_0, _payload_0) {
  const _world_0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "../../../src/ecs/world.Accepted") {
    return $spawn$058populate$1261$(_world_0, _handle_0, _payload_0);
  } else {
    return _world_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1261$(true, _handle_0, ($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058finish_returned$1262$(_values_0, _returned_0) {
  const _world_0 = _returned_0["world"];
  const _t_0 = _returned_0["outcome"];
  if (_t_0.$ === "../../../src/ecs/transaction.Success") {
    return {$: "../../../src/ecs/compose.Executed", "world": _world_0, "outcome": {$: "../../../src/ecs/transaction.Success"}, "values": _values_0};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../src/ecs/compose.Executed", "world": _world_0, "outcome": {$: "../../../src/ecs/transaction.Failure", "error": _error_0}, "values": {$: "Nil"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1262$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047src$047ecs$047transaction$058finish$1262$(_tx_0, _outcome_0);
}

function $$$$047$$$047$$$047src$047ecs$047compose$058selected$1262$(_args_0, _next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const __0 = _t_0["handle"];
  const __1 = _t_0["error"];
  const __2 = _t_0["cursor"];
  const _t_1 = _observed_0["snd"];
  if (!_t_1) {
    return run_tail(_next_0, _tx_0);
  } else {
    return $$$$047$$$047$$$047src$047ecs$047compose$058body_returned$1262$(_next_0, ($$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1262$(_args_0, {$: "../../../src/ecs/compose.Frame", "tx": _tx_0, "handle": __0, "error": __1, "cursor": __2})));
  }
}

function $$$$047$$$047$$$047src$047ecs$047compose$058plan_select$1262$(_plan_0) {
  const _select_0 = _plan_0["select"];
  return _select_0;
}

function $damage$058plan$1261$() {
  return {$: "../../../src/ecs/compose.Plan", "caps": {$: "damage-body.DamageOps", "position": ($$$$047$$$047$$$047src$047ecs$047compose$058read_family$1262$()), "health": ($$$$047$$$047$$$047src$047ecs$047compose$058write_family$1262$()), "handle": ($$$$047$$$047$$$047src$047ecs$047compose$058handle_read$1261$()), "events": ($$$$047$$$047$$$047src$047ecs$047compose$058event_write$1261$()), "despawn": ($$$$047$$$047$$$047src$047ecs$047compose$058command_despawn$1261$())}, "select": run_clo((_x_0) => {
  return $damage$058selected$1261$(_x_0);
})};
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058finish$1263$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1263$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047src$047ecs$047compose$058body_returned$1263$(_next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const _internal_0 = _t_0["error"];
  const _t_1 = _observed_0["snd"];
  const _user_0 = _t_1["fst"];
  const _value_0 = _t_1["snd"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058completed$1263$(_next_0, _tx_0, _value_0, ($$$$047$$$047$$$047src$047ecs$047compose$058outcome$1261$(_internal_0, _user_0)));
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1263$(_args_0, _ctx_0) {
  return $movement$058body$1261$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047src$047ecs$047compose$058write_family$1263$() {
  return {$: "../../../src/ecs/capabilities.Write", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047compose$058get$1263$(_x_0);
}), "set": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047src$047ecs$047compose$058set$1263$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058read_family$1263$() {
  return {$: "../../../src/ecs/capabilities.Read", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047compose$058get$1265$(_x_0);
})};
}

function $movement$058selected$1261$(_frame_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058both$1263$(_frame_0);
}

function $$$$047$$$047$$$047src$047ecs$047resource$058tx_replace$1261$(_tx_0, _replacement_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047resource$058replace_join$1261$(($$$$047$$$047$$$047src$047ecs$047world$058replace_resource$1261$(_world_0, _replacement_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047src$047ecs$047resource$058get_join$1261$(_observed_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058observe_resource$1263$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058observe_resource_finish$1263$(($geometry$058project$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047src$047ecs$047commands$058spawn_apply$1260$(_world_0, _handle_0, _payload_0) {
  return $$$$047$$$047$$$047src$047ecs$047commands$058spawned$1260$(($$$$047$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../src/ecs/world.Reserved", "handle": {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058finished$1260$(_observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _result_0 = _t_0["fst"];
  const _values_0 = _t_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058finish_returned$1260$(_values_0, ($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _result_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058run_handles$1260$(_handles_0, _args_0, _cursor_0, _tx_0) {
  if (_handles_0.$ === "Nil") {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Success"}, "snd": {$: "Nil"}}};
  } else {
    const _handle_0 = _handles_0["head"];
    const _rest_0 = _handles_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047compose$058selected$1260$(_args_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047compose$058run_handles$1260$(_rest_0, _args_0, _cursor_0, _x_0);
}), ($$$$047$$$047$$$047src$047ecs$047compose$058plan_select$1260$(($damage$058plan$1260$())))({$: "../../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": {$: "None"}, "cursor": _cursor_0}));
  }
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0) {
  return {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058finish_returned$1261$(_values_0, _returned_0) {
  const _world_0 = _returned_0["world"];
  const _t_0 = _returned_0["outcome"];
  if (_t_0.$ === "../../../src/ecs/transaction.Success") {
    return {$: "../../../src/ecs/compose.Executed", "world": _world_0, "outcome": {$: "../../../src/ecs/transaction.Success"}, "values": _values_0};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../src/ecs/compose.Executed", "world": _world_0, "outcome": {$: "../../../src/ecs/transaction.Failure", "error": _error_0}, "values": {$: "Nil"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0);
}

function $$$$047$$$047$$$047src$047ecs$047compose$058selected$1261$(_args_0, _next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const __0 = _t_0["handle"];
  const __1 = _t_0["error"];
  const __2 = _t_0["cursor"];
  const _t_1 = _observed_0["snd"];
  if (!_t_1) {
    return run_tail(_next_0, _tx_0);
  } else {
    return $$$$047$$$047$$$047src$047ecs$047compose$058body_returned$1261$(_next_0, ($$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1261$(_args_0, {$: "../../../src/ecs/compose.Frame", "tx": _tx_0, "handle": __0, "error": __1, "cursor": __2})));
  }
}

function $$$$047$$$047$$$047src$047ecs$047compose$058plan_select$1261$(_plan_0) {
  const _select_0 = _plan_0["select"];
  return _select_0;
}

function $movement$058plan$1260$() {
  return {$: "../../../src/ecs/compose.Plan", "caps": {$: "movement.MovementOps", "position": ($$$$047$$$047$$$047src$047ecs$047compose$058write_family$1261$()), "velocity": ($$$$047$$$047$$$047src$047ecs$047compose$058read_family$1261$())}, "select": run_clo((_x_0) => {
  return $movement$058selected$1260$(_x_0);
})};
}

function $step$058advanced$1260$(_observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _value_0 = _t_0["value"];
  const _sentinel_0 = _t_0["sentinel"];
  return $$$$047$$$047$$$047src$047ecs$047resource$058tx_replace$1260$(_tx_0, array_node([((_value_0 + 1) >>> 0)], [_sentinel_0]));
}

function $$$$047$$$047$$$047src$047ecs$047resource$058tx_get$1260$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047resource$058get_join$1260$(($$$$047$$$047$$$047src$047ecs$047world$058observe_resource$1261$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $spawn$058populate$1261$(_world_0, _handle_0, _payload_0) {
  return $spawn$058populate_parts$1261$(_world_0, _handle_0, _payload_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1261$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058finish$1262$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1262$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047src$047ecs$047compose$058body_returned$1262$(_next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const _internal_0 = _t_0["error"];
  const _t_1 = _observed_0["snd"];
  const _user_0 = _t_1["fst"];
  const _value_0 = _t_1["snd"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058completed$1262$(_next_0, _tx_0, _value_0, ($$$$047$$$047$$$047src$047ecs$047compose$058outcome$1260$(_internal_0, _user_0)));
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1262$(_args_0, _ctx_0) {
  return $damage$045body$058body$1261$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047src$047ecs$047compose$058read_family$1262$() {
  return {$: "../../../src/ecs/capabilities.Read", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047compose$058get$1263$(_x_0);
})};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058write_family$1262$() {
  return {$: "../../../src/ecs/capabilities.Write", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047compose$058get$1264$(_x_0);
}), "set": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047src$047ecs$047compose$058set$1262$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058handle_read$1261$() {
  return {$: "../../../src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047compose$058handle_get$1261$(_x_0);
})};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058event_write$1261$() {
  return {$: "../../../src/ecs/capabilities.Send", "send": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047src$047ecs$047compose$058emit$1261$(_x_0, _x_1);
});
})};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058command_despawn$1261$() {
  return {$: "../../../src/ecs/capabilities.Action", "run": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047compose$058despawn$1261$(_x_0);
})};
}

function $damage$058selected$1261$(_frame_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058both$1262$(_frame_0);
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1263$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1261$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047src$047ecs$047commands$058publish$1261$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1261$(_undo_0, _world_0)), "outcome": {$: "../../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047compose$058completed$1263$(_next_0, _tx_0, _value_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/transaction.Success") {
    return $$$$047$$$047$$$047src$047ecs$047compose$058prepend$1263$(_value_0, _next_0(_tx_0));
  } else {
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Failure", "error": _error_0}, "snd": {$: "Nil"}}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047compose$058outcome$1261$(_internal_0, _user_0) {
  if (_internal_0.$ === "Some") {
    const _error_0 = _internal_0["value"];
    return {$: "../../../src/ecs/transaction.Failure", "error": {$: "../../../src/ecs/compose.AccessError", "error": _error_0}};
  } else {
    if (_user_0.$ === "../../../src/ecs/transaction.Failure") {
      const _error_1 = _user_0["error"];
      return {$: "../../../src/ecs/transaction.Failure", "error": {$: "../../../src/ecs/compose.UserError", "error": _error_1}};
    } else {
      return {$: "../../../src/ecs/transaction.Success"};
    }
  }
}

function $movement$058body$1261$(_fixed_step_0, _ctx_0) {
  return $movement$058positioned$1261$(_fixed_step_0, run_loop($$$$047$$$047$$$047src$047ecs$047capabilities$058get$1263$(_ctx_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058get$1263$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058read_join$1261$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047$$$047src$047ecs$047component$058tx_get$1263$(($schema$058position$1261$()), _tx_0, _handle_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058set$1263$(_frame_0, _replacement_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058written$1261$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047$$$047src$047ecs$047component$058tx_set$1263$(($schema$058position$1261$()), _tx_0, _handle_0, _replacement_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058get$1265$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058read_join$1261$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047$$$047src$047ecs$047component$058tx_get$1265$(($schema$058velocity$1261$()), _tx_0, _handle_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058both$1263$(_frame_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058and_join$1263$(($movement$058selected_position$1261$(_frame_0)));
}

function $$$$047$$$047$$$047src$047ecs$047resource$058replace_join$1261$(_replaced_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _replaced_0["fst"];
  const _old_0 = _replaced_0["snd"];
  return {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047resource$058restore$1261$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058replace_resource$1261$(_world_0, _replacement_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _replacement_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _resource_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058observe_resource_finish$1263$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $geometry$058project$(_owner_0) {
  return $geometry$058projected_first$({$: "Tuple", fst: _owner_0, snd: _owner_0[0 % _owner_0.length]});
}

function $$$$047$$$047$$$047src$047ecs$047commands$058spawned$1260$(_activated_0, _handle_0, _payload_0) {
  const _world_0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "../../../src/ecs/world.Accepted") {
    return $spawn$058populate$1260$(_world_0, _handle_0, _payload_0);
  } else {
    return _world_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1260$(true, _handle_0, ($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058finish_returned$1260$(_values_0, _returned_0) {
  const _world_0 = _returned_0["world"];
  const _t_0 = _returned_0["outcome"];
  if (_t_0.$ === "../../../src/ecs/transaction.Success") {
    return {$: "../../../src/ecs/compose.Executed", "world": _world_0, "outcome": {$: "../../../src/ecs/transaction.Success"}, "values": _values_0};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../src/ecs/compose.Executed", "world": _world_0, "outcome": {$: "../../../src/ecs/transaction.Failure", "error": _error_0}, "values": {$: "Nil"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0);
}

function $$$$047$$$047$$$047src$047ecs$047compose$058selected$1260$(_args_0, _next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const __0 = _t_0["handle"];
  const __1 = _t_0["error"];
  const __2 = _t_0["cursor"];
  const _t_1 = _observed_0["snd"];
  if (!_t_1) {
    return run_tail(_next_0, _tx_0);
  } else {
    return $$$$047$$$047$$$047src$047ecs$047compose$058body_returned$1260$(_next_0, ($$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1260$(_args_0, {$: "../../../src/ecs/compose.Frame", "tx": _tx_0, "handle": __0, "error": __1, "cursor": __2})));
  }
}

function $$$$047$$$047$$$047src$047ecs$047compose$058plan_select$1260$(_plan_0) {
  const _select_0 = _plan_0["select"];
  return _select_0;
}

function $damage$058plan$1260$() {
  return {$: "../../../src/ecs/compose.Plan", "caps": {$: "damage-body.DamageOps", "position": ($$$$047$$$047$$$047src$047ecs$047compose$058read_family$1260$()), "health": ($$$$047$$$047$$$047src$047ecs$047compose$058write_family$1260$()), "handle": ($$$$047$$$047$$$047src$047ecs$047compose$058handle_read$1260$()), "events": ($$$$047$$$047$$$047src$047ecs$047compose$058event_write$1260$()), "despawn": ($$$$047$$$047$$$047src$047ecs$047compose$058command_despawn$1260$())}, "select": run_clo((_x_0) => {
  return $damage$058selected$1260$(_x_0);
})};
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047src$047ecs$047compose$058body_returned$1261$(_next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const _internal_0 = _t_0["error"];
  const _t_1 = _observed_0["snd"];
  const _user_0 = _t_1["fst"];
  const _value_0 = _t_1["snd"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058completed$1261$(_next_0, _tx_0, _value_0, ($$$$047$$$047$$$047src$047ecs$047compose$058outcome$1261$(_internal_0, _user_0)));
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1261$(_args_0, _ctx_0) {
  return $movement$058body$1260$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047src$047ecs$047compose$058write_family$1261$() {
  return {$: "../../../src/ecs/capabilities.Write", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047compose$058get$1260$(_x_0);
}), "set": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047src$047ecs$047compose$058set$1261$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058read_family$1261$() {
  return {$: "../../../src/ecs/capabilities.Read", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047compose$058get$1262$(_x_0);
})};
}

function $movement$058selected$1260$(_frame_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058both$1261$(_frame_0);
}

function $$$$047$$$047$$$047src$047ecs$047resource$058tx_replace$1260$(_tx_0, _replacement_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047resource$058replace_join$1260$(($$$$047$$$047$$$047src$047ecs$047world$058replace_resource$1260$(_world_0, _replacement_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047src$047ecs$047resource$058get_join$1260$(_observed_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058observe_resource$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058observe_resource_finish$1261$(($geometry$058project$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $spawn$058populate_parts$1261$(_world_0, _handle_0, _payload_0) {
  const _position_0 = _payload_0["position"];
  const _velocity_0 = _payload_0["velocity"];
  const _health_0 = _payload_0["health"];
  return $spawn$058insert_health$1261$(($spawn$058insert_velocity$1261$(($spawn$058insert_position$1261$(_world_0, _handle_0, _position_0)), _handle_0, _velocity_0)), _handle_0, _health_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/world.Rejected", "error": {$: "../../../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../src/ecs/world.Accepted"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1262$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1261$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047src$047ecs$047commands$058publish$1261$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1261$(_undo_0, _world_0)), "outcome": {$: "../../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047compose$058completed$1262$(_next_0, _tx_0, _value_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/transaction.Success") {
    return $$$$047$$$047$$$047src$047ecs$047compose$058prepend$1262$(_value_0, _next_0(_tx_0));
  } else {
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Failure", "error": _error_0}, "snd": {$: "Nil"}}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047compose$058outcome$1260$(_internal_0, _user_0) {
  if (_internal_0.$ === "Some") {
    const _error_0 = _internal_0["value"];
    return {$: "../../../src/ecs/transaction.Failure", "error": {$: "../../../src/ecs/compose.AccessError", "error": _error_0}};
  } else {
    if (_user_0.$ === "../../../src/ecs/transaction.Failure") {
      const _error_1 = _user_0["error"];
      return {$: "../../../src/ecs/transaction.Failure", "error": {$: "../../../src/ecs/compose.UserError", "error": _error_1}};
    } else {
      return {$: "../../../src/ecs/transaction.Success"};
    }
  }
}

function $damage$045body$058body$1261$(_args_0, _ctx_0) {
  return $damage$045body$058positioned$1261$(_args_0, run_loop($$$$047$$$047$$$047src$047ecs$047capabilities$058read$1262$(_ctx_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058get$1264$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058read_join$1261$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047$$$047src$047ecs$047component$058tx_get$1264$(($schema$058health$1261$()), _tx_0, _handle_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058set$1262$(_frame_0, _replacement_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058written$1261$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047$$$047src$047ecs$047component$058tx_set$1262$(($schema$058health$1261$()), _tx_0, _handle_0, _replacement_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058handle_get$1261$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}, "snd": _handle_0};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058emit$1261$(_frame_0, _event_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return {$: "../../../src/ecs/compose.Frame", "tx": ($$$$047$$$047$$$047src$047ecs$047transaction$058emit$1261$(_tx_0, _event_0)), "handle": _handle_0, "error": _error_0, "cursor": _cursor_0};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058despawn$1261$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058despawn_join$1261$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047$$$047src$047ecs$047commands$058tx_despawn_with$1261$(_tx_0, _handle_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058both$1262$(_frame_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058and_join$1262$(($damage$058selected_position$1261$(_frame_0)));
}

function $$$$047$$$047$$$047src$047ecs$047commands$058publish$1261$(_world_0, _events_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, _events_0);
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1261$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047compose$058prepend$1263$(_value_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _outcome_0 = _t_0["fst"];
  const _values_0 = _t_0["snd"];
  return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": {$: "Con", "head": _value_0, "tail": _values_0}}};
}

function $movement$058positioned$1261$(_fixed_step_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Found") {
    const _position_0 = _t_0["value"];
    return $movement$058moved$1261$(_fixed_step_0, _position_0, run_loop($$$$047$$$047$$$047src$047ecs$047capabilities$058read$1263$(_ctx_0)));
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Failure", "error": {$: "movement.MovementMissingPosition"}}, "snd": {$: "geometry.Cell", "value": 0, "sentinel": 0}}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058get$1263$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047src$047ecs$047capabilities$058write_read_field$1261$(($movement$058position_cap$1261$(($$$$047$$$047$$$047src$047ecs$047compose$058plan_caps$1263$(($movement$058plan$1261$()))))))), _ctx_0);
}

function $$$$047$$$047$$$047src$047ecs$047compose$058read_join$1261$(_handle_0, _error_0, _cursor_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_get$1263$(_family_0, _tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047component$058tx_get_join$1263$(_undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047src$047ecs$047component$058get$1263$(_family_0, _world_0, _handle_0)));
}

function $schema$058position$1261$() {
  return {$: "../../../src/ecs/component.Family", "name": "Simulation/Position"};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058written$1261$(_handle_0, _error_0, _cursor_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/component.Written") {
    const _tx_0 = _result_0["tx"];
    return {$: "../../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0};
  } else if (_result_0.$ === "../../../src/ecs/component.WriteRejected") {
    const _tx_1 = _result_0["tx"];
    const _reason_0 = _result_0["error"];
    return {$: "../../../src/ecs/compose.Frame", "tx": _tx_1, "handle": _handle_0, "error": ($$$$047$$$047$$$047src$047ecs$047compose$058first_error$(_error_0, _reason_0)), "cursor": _cursor_0};
  } else {
    const _tx_2 = _result_0["tx"];
    const _reason_1 = _result_0["error"];
    return {$: "../../../src/ecs/compose.Frame", "tx": _tx_2, "handle": _handle_0, "error": ($$$$047$$$047$$$047src$047ecs$047compose$058first_error$(_error_0, _reason_1)), "cursor": _cursor_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_set$1263$(_family_0, _tx_0, _handle_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047component$058tx_set_fused$1263$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047src$047ecs$047component$058stamped_allowed$1263$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_get$1265$(_family_0, _tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047component$058tx_get_join$1265$(_undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047src$047ecs$047component$058get$1265$(_family_0, _world_0, _handle_0)));
}

function $schema$058velocity$1261$() {
  return {$: "../../../src/ecs/component.Family", "name": "Simulation/Velocity"};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058and_join$1263$(_observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _frame_0, "snd": false};
  } else {
    return $movement$058selected_velocity$1261$(_frame_0);
  }
}

function $movement$058selected_position$1261$(_frame_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058family_match$1264$(_frame_0);
}

function $$$$047$$$047$$$047src$047ecs$047resource$058restore$1261$(_world_0, _old_0) {
  return $$$$047$$$047$$$047src$047ecs$047resource$058restore_join$1261$(($$$$047$$$047$$$047src$047ecs$047world$058replace_resource$1261$(_world_0, _old_0)));
}

function $geometry$058projected_first$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return $geometry$058projected_second$(_value_0, {$: "Tuple", fst: _owner_0, snd: _owner_0[1 % _owner_0.length]});
}

function $spawn$058populate$1260$(_world_0, _handle_0, _payload_0) {
  return $spawn$058populate_parts$1260$(_world_0, _handle_0, _payload_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1260$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047src$047ecs$047compose$058body_returned$1260$(_next_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const _internal_0 = _t_0["error"];
  const _t_1 = _observed_0["snd"];
  const _user_0 = _t_1["fst"];
  const _value_0 = _t_1["snd"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058completed$1260$(_next_0, _tx_0, _value_0, ($$$$047$$$047$$$047src$047ecs$047compose$058outcome$1260$(_internal_0, _user_0)));
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058invoke$1260$(_args_0, _ctx_0) {
  return $damage$045body$058body$1260$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047src$047ecs$047compose$058read_family$1260$() {
  return {$: "../../../src/ecs/capabilities.Read", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047compose$058get$1260$(_x_0);
})};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058write_family$1260$() {
  return {$: "../../../src/ecs/capabilities.Write", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047compose$058get$1261$(_x_0);
}), "set": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047src$047ecs$047compose$058set$1260$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058handle_read$1260$() {
  return {$: "../../../src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047compose$058handle_get$1260$(_x_0);
})};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058event_write$1260$() {
  return {$: "../../../src/ecs/capabilities.Send", "send": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047src$047ecs$047compose$058emit$1260$(_x_0, _x_1);
});
})};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058command_despawn$1260$() {
  return {$: "../../../src/ecs/capabilities.Action", "run": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047compose$058despawn$1260$(_x_0);
})};
}

function $damage$058selected$1260$(_frame_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058both$1260$(_frame_0);
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047compose$058completed$1261$(_next_0, _tx_0, _value_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/transaction.Success") {
    return $$$$047$$$047$$$047src$047ecs$047compose$058prepend$1261$(_value_0, _next_0(_tx_0));
  } else {
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Failure", "error": _error_0}, "snd": {$: "Nil"}}};
  }
}

function $movement$058body$1260$(_fixed_step_0, _ctx_0) {
  return $movement$058positioned$1260$(_fixed_step_0, run_loop($$$$047$$$047$$$047src$047ecs$047capabilities$058get$1261$(_ctx_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058get$1260$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058read_join$1260$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047$$$047src$047ecs$047component$058tx_get$1260$(($schema$058position$1260$()), _tx_0, _handle_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058set$1261$(_frame_0, _replacement_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058written$1260$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047$$$047src$047ecs$047component$058tx_set$1261$(($schema$058position$1260$()), _tx_0, _handle_0, _replacement_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058get$1262$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058read_join$1260$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047$$$047src$047ecs$047component$058tx_get$1262$(($schema$058velocity$1260$()), _tx_0, _handle_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058both$1261$(_frame_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058and_join$1261$(($movement$058selected_position$1260$(_frame_0)));
}

function $$$$047$$$047$$$047src$047ecs$047resource$058replace_join$1260$(_replaced_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _replaced_0["fst"];
  const _old_0 = _replaced_0["snd"];
  return {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047resource$058restore$1260$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058replace_resource$1260$(_world_0, _replacement_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _replacement_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _resource_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058observe_resource_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $spawn$058insert_health$1261$(_world_0, _handle_0, _value_0) {
  return $spawn$058replaced$1261$(($$$$047$$$047$$$047src$047ecs$047component$058structural_replace$1263$(($schema$058health$1261$()), _world_0, _handle_0, {$: "Some", "value": _value_0})));
}

function $spawn$058insert_velocity$1261$(_world_0, _handle_0, _value_0) {
  return $spawn$058replaced$1261$(($$$$047$$$047$$$047src$047ecs$047component$058structural_replace$1264$(($schema$058velocity$1261$()), _world_0, _handle_0, {$: "Some", "value": _value_0})));
}

function $spawn$058insert_position$1261$(_world_0, _handle_0, _value_0) {
  return $spawn$058replaced$1261$(($$$$047$$$047$$$047src$047ecs$047component$058structural_replace$1265$(($schema$058position$1261$()), _world_0, _handle_0, {$: "Some", "value": _value_0})));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058prepend$1262$(_value_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _outcome_0 = _t_0["fst"];
  const _values_0 = _t_0["snd"];
  return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": {$: "Con", "head": _value_0, "tail": _values_0}}};
}

function $damage$045body$058positioned$1261$(_args_0, _observed_0) {
  const _goal_0 = _args_0["goal"];
  const _damage_0 = _args_0["damage"];
  return $damage$045body$058positioned_result$1261$(_goal_0, _damage_0, _observed_0);
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058read$1262$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047src$047ecs$047capabilities$058read_field$1261$(($damage$045body$058position_cap$1261$(($$$$047$$$047$$$047src$047ecs$047compose$058plan_caps$1262$(($damage$058plan$1261$()))))))), _ctx_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_get$1264$(_family_0, _tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047component$058tx_get_join$1264$(_undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047src$047ecs$047component$058get$1264$(_family_0, _world_0, _handle_0)));
}

function $schema$058health$1261$() {
  return {$: "../../../src/ecs/component.Family", "name": "Simulation/Health"};
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_set$1262$(_family_0, _tx_0, _handle_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047component$058tx_set_fused$1262$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047src$047ecs$047component$058stamped_allowed$1262$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058emit$1261$(_tx_0, _event_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": {$: "Con", "head": _event_0, "tail": _events_0}};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058despawn_join$1261$(_handle_0, _error_0, _cursor_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../src/ecs/world.Accepted") {
    return {$: "../../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0};
  } else {
    const _reason_0 = _t_0["error"];
    return {$: "../../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": ($$$$047$$$047$$$047src$047ecs$047compose$058first_error$(_error_0, _reason_0)), "cursor": _cursor_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058tx_despawn_with$1261$(_tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047commands$058despawn_join_with$1261$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _undo_0, _commands_0, _events_0, _handle_0);
}

function $$$$047$$$047$$$047src$047ecs$047compose$058and_join$1262$(_observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _frame_0, "snd": false};
  } else {
    return $damage$058selected_health$1261$(_frame_0);
  }
}

function $damage$058selected_position$1261$(_frame_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058family_match$1264$(_frame_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $movement$058moved$1261$(_fixed_step_0, _position_0, _observed_0) {
  const _value_0 = _position_0["value"];
  const _sentinel_0 = _position_0["sentinel"];
  return $movement$058moved_result$1261$(_fixed_step_0, _value_0, _sentinel_0, _observed_0);
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058read$1263$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047src$047ecs$047capabilities$058read_field$1261$(($movement$058velocity_cap$1261$(($$$$047$$$047$$$047src$047ecs$047compose$058plan_caps$1263$(($movement$058plan$1261$()))))))), _ctx_0);
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058write_read_field$1261$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $movement$058position_cap$1261$(_ops_0) {
  const _position_0 = _ops_0["position"];
  return _position_0;
}

function $$$$047$$$047$$$047src$047ecs$047compose$058plan_caps$1263$(_plan_0) {
  const _caps_0 = _plan_0["caps"];
  return _caps_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_get_join$1263$(_undo_0, _commands_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058get$1263$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047component$058get_live_owned$1263$(_id_0, ($$$$047$$$047$$$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047compose$058first_error$(_previous_0, _error_0) {
  if (_previous_0.$ === "None") {
    return {$: "Some", "value": _error_0};
  } else {
    const _previous_1 = _previous_0["value"];
    return {$: "Some", "value": _previous_1};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_set_fused$1263$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _observed_0) {
  const _result_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058tx_written$1263$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_allowed$1263$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": {$: "Some", "value": _incoming_0}, "error": {$: "../../../src/ecs/world.MissingEntity"}}, "snd": {$: "../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058stamped_world$1263$(_id_0, _incoming_0, _world_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058valid_join$1261$(_handle_0, ($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_get_join$1265$(_undo_0, _commands_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058get$1265$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047component$058get_live_owned$1265$(_id_0, ($$$$047$$$047$$$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $movement$058selected_velocity$1261$(_frame_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058family_match$1265$(_frame_0);
}

function $$$$047$$$047$$$047src$047ecs$047compose$058family_match$1264$(_frame_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058selected_join$1261$({$: "../../../src/ecs/compose.Required"}, ($$$$047$$$047$$$047src$047ecs$047compose$058get$1263$(_frame_0)));
}

function $$$$047$$$047$$$047src$047ecs$047resource$058restore_join$1261$(_replaced_0) {
  const _world_0 = _replaced_0["fst"];
  return _world_0;
}

function $geometry$058projected_second$(_value_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _sentinel_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "geometry.Cell", "value": _value_0, "sentinel": _sentinel_0}};
}

function $spawn$058populate_parts$1260$(_world_0, _handle_0, _payload_0) {
  const _position_0 = _payload_0["position"];
  const _velocity_0 = _payload_0["velocity"];
  const _health_0 = _payload_0["health"];
  return $spawn$058insert_health$1260$(($spawn$058insert_velocity$1260$(($spawn$058insert_position$1260$(_world_0, _handle_0, _position_0)), _handle_0, _velocity_0)), _handle_0, _health_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/world.Rejected", "error": {$: "../../../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../src/ecs/world.Accepted"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047compose$058completed$1260$(_next_0, _tx_0, _value_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/transaction.Success") {
    return $$$$047$$$047$$$047src$047ecs$047compose$058prepend$1260$(_value_0, _next_0(_tx_0));
  } else {
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Failure", "error": _error_0}, "snd": {$: "Nil"}}};
  }
}

function $damage$045body$058body$1260$(_args_0, _ctx_0) {
  return $damage$045body$058positioned$1260$(_args_0, run_loop($$$$047$$$047$$$047src$047ecs$047capabilities$058read$1260$(_ctx_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058get$1261$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058read_join$1260$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047$$$047src$047ecs$047component$058tx_get$1261$(($schema$058health$1260$()), _tx_0, _handle_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058set$1260$(_frame_0, _replacement_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058written$1260$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047$$$047src$047ecs$047component$058tx_set$1260$(($schema$058health$1260$()), _tx_0, _handle_0, _replacement_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058handle_get$1260$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}, "snd": _handle_0};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058emit$1260$(_frame_0, _event_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return {$: "../../../src/ecs/compose.Frame", "tx": ($$$$047$$$047$$$047src$047ecs$047transaction$058emit$1260$(_tx_0, _event_0)), "handle": _handle_0, "error": _error_0, "cursor": _cursor_0};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058despawn$1260$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047compose$058despawn_join$1260$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047$$$047src$047ecs$047commands$058tx_despawn_with$1260$(_tx_0, _handle_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058both$1260$(_frame_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058and_join$1260$(($damage$058selected_position$1260$(_frame_0)));
}

function $$$$047$$$047$$$047src$047ecs$047commands$058publish$1260$(_world_0, _events_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _events_0);
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047compose$058prepend$1261$(_value_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _outcome_0 = _t_0["fst"];
  const _values_0 = _t_0["snd"];
  return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": {$: "Con", "head": _value_0, "tail": _values_0}}};
}

function $movement$058positioned$1260$(_fixed_step_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Found") {
    const _position_0 = _t_0["value"];
    return $movement$058moved$1260$(_fixed_step_0, _position_0, run_loop($$$$047$$$047$$$047src$047ecs$047capabilities$058read$1261$(_ctx_0)));
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Failure", "error": {$: "movement.MovementMissingPosition"}}, "snd": {$: "geometry.Cell", "value": 0, "sentinel": 0}}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058get$1261$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047src$047ecs$047capabilities$058write_read_field$1260$(($movement$058position_cap$1260$(($$$$047$$$047$$$047src$047ecs$047compose$058plan_caps$1261$(($movement$058plan$1260$()))))))), _ctx_0);
}

function $$$$047$$$047$$$047src$047ecs$047compose$058read_join$1260$(_handle_0, _error_0, _cursor_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_get$1260$(_family_0, _tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047component$058tx_get_join$1260$(_undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047src$047ecs$047component$058get$1260$(_family_0, _world_0, _handle_0)));
}

function $schema$058position$1260$() {
  return {$: "../../../src/ecs/component.Family", "name": "Simulation/Position"};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058written$1260$(_handle_0, _error_0, _cursor_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/component.Written") {
    const _tx_0 = _result_0["tx"];
    return {$: "../../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0};
  } else if (_result_0.$ === "../../../src/ecs/component.WriteRejected") {
    const _tx_1 = _result_0["tx"];
    const _reason_0 = _result_0["error"];
    return {$: "../../../src/ecs/compose.Frame", "tx": _tx_1, "handle": _handle_0, "error": ($$$$047$$$047$$$047src$047ecs$047compose$058first_error$(_error_0, _reason_0)), "cursor": _cursor_0};
  } else {
    const _tx_2 = _result_0["tx"];
    const _reason_1 = _result_0["error"];
    return {$: "../../../src/ecs/compose.Frame", "tx": _tx_2, "handle": _handle_0, "error": ($$$$047$$$047$$$047src$047ecs$047compose$058first_error$(_error_0, _reason_1)), "cursor": _cursor_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_set$1261$(_family_0, _tx_0, _handle_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047component$058tx_set_fused$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047src$047ecs$047component$058stamped_allowed$1261$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_get$1262$(_family_0, _tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047component$058tx_get_join$1262$(_undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047src$047ecs$047component$058get$1262$(_family_0, _world_0, _handle_0)));
}

function $schema$058velocity$1260$() {
  return {$: "../../../src/ecs/component.Family", "name": "Simulation/Velocity"};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058and_join$1261$(_observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _frame_0, "snd": false};
  } else {
    return $movement$058selected_velocity$1260$(_frame_0);
  }
}

function $movement$058selected_position$1260$(_frame_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058family_match$1261$(_frame_0);
}

function $$$$047$$$047$$$047src$047ecs$047resource$058restore$1260$(_world_0, _old_0) {
  return $$$$047$$$047$$$047src$047ecs$047resource$058restore_join$1260$(($$$$047$$$047$$$047src$047ecs$047world$058replace_resource$1260$(_world_0, _old_0)));
}

function $spawn$058replaced$1261$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058structural_replace$1263$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1263$(($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058structural_replace$1264$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1264$(($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058structural_replace$1265$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1265$(($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $damage$045body$058positioned_result$1261$(_goal_0, _damage_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Found") {
    const _t_1 = _t_0["value"];
    const _position_0 = _t_1["value"];
    return $damage$045body$058eligible$1261$((_goal_0 <= _position_0), _damage_0, _ctx_0);
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Failure", "error": {$: "damage-body.DamageMissingPosition"}}, "snd": {$: "geometry.Cell", "value": 0, "sentinel": 0}}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058read_field$1261$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $damage$045body$058position_cap$1261$(_ops_0) {
  const _position_0 = _ops_0["position"];
  return _position_0;
}

function $$$$047$$$047$$$047src$047ecs$047compose$058plan_caps$1262$(_plan_0) {
  const _caps_0 = _plan_0["caps"];
  return _caps_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_get_join$1264$(_undo_0, _commands_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058get$1264$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047component$058get_live_owned$1264$(_id_0, ($$$$047$$$047$$$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_set_fused$1262$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _observed_0) {
  const _result_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058tx_written$1262$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_allowed$1262$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": {$: "Some", "value": _incoming_0}, "error": {$: "../../../src/ecs/world.MissingEntity"}}, "snd": {$: "../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058stamped_world$1262$(_id_0, _incoming_0, _world_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058despawn_join_with$1261$(_checked_0, _undo_0, _commands_0, _events_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047commands$058despawn_checked_with$1261$(_allowed_0, _world_0, _undo_0, _commands_0, _events_0, _handle_0);
}

function $damage$058selected_health$1261$(_frame_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058family_match$1263$(_frame_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $movement$058moved_result$1261$(_fixed_step_0, _value_0, _sentinel_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Found") {
    const _t_1 = _t_0["value"];
    const _velocity_0 = _t_1["value"];
    const _x_0 = (Math.imul(_velocity_0, _fixed_step_0) >>> 0);
    const _next_0 = ((_value_0 + _x_0) >>> 0);
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047src$047ecs$047capabilities$058set$1263$(_ctx_0, array_node([_next_0], [_sentinel_0]))), "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Success"}, "snd": {$: "geometry.Cell", "value": _next_0, "sentinel": _sentinel_0}}};
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Failure", "error": {$: "movement.MovementMissingVelocity"}}, "snd": {$: "geometry.Cell", "value": _value_0, "sentinel": _sentinel_0}}};
  }
}

function $movement$058velocity_cap$1261$(_ops_0) {
  const _velocity_0 = _ops_0["velocity"];
  return _velocity_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058get_live_owned$1263$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1267$(($$$$047$$$047$$$047src$047ecs$047component$058get_store$1263$(_id_0, ($storage$058take_position$1261$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058get_live_read$(_allowed_0, _id_0, _live_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _live_0, "snd": false};
  } else {
    return {$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_written$1263$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../../src/ecs/component.Written", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1263$(_handle_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047component$058restore$1263$(_family_0, _handle_0, _previous_0, _x_0)));
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["incoming"];
    if (_t_0.$ === "Some") {
      const _incoming_0 = _t_0["value"];
      const _error_0 = _result_0["error"];
      return {$: "../../../src/ecs/component.WriteRejected", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "incoming": _incoming_0, "error": _error_0};
    } else {
      const _error_1 = _result_0["error"];
      return {$: "../../../src/ecs/component.WriteFailure", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "error": _error_1};
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_world$1263$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047component$058stamped_replaced$1263$(($$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1269$(($$$$047$$$047$$$047src$047ecs$047component$058stamped_store$1263$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))), (_clock_0 < 4294967295), ($storage$058take_position$1261$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, ($$$$047$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))))));
}

function $$$$047$$$047$$$047src$047ecs$047world$058valid_join$1261$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058get_live_owned$1265$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1267$(($$$$047$$$047$$$047src$047ecs$047component$058get_store$1265$(_id_0, ($storage$058take_velocity$1261$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047compose$058family_match$1265$(_frame_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058selected_join$1261$({$: "../../../src/ecs/compose.Required"}, ($$$$047$$$047$$$047src$047ecs$047compose$058get$1265$(_frame_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058selected_join$1261$(_mode_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047src$047ecs$047compose$058selected_value$1260$(_mode_0, _value_0))};
}

function $spawn$058insert_health$1260$(_world_0, _handle_0, _value_0) {
  return $spawn$058replaced$1260$(($$$$047$$$047$$$047src$047ecs$047component$058structural_replace$1260$(($schema$058health$1260$()), _world_0, _handle_0, {$: "Some", "value": _value_0})));
}

function $spawn$058insert_velocity$1260$(_world_0, _handle_0, _value_0) {
  return $spawn$058replaced$1260$(($$$$047$$$047$$$047src$047ecs$047component$058structural_replace$1261$(($schema$058velocity$1260$()), _world_0, _handle_0, {$: "Some", "value": _value_0})));
}

function $spawn$058insert_position$1260$(_world_0, _handle_0, _value_0) {
  return $spawn$058replaced$1260$(($$$$047$$$047$$$047src$047ecs$047component$058structural_replace$1262$(($schema$058position$1260$()), _world_0, _handle_0, {$: "Some", "value": _value_0})));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058prepend$1260$(_value_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _outcome_0 = _t_0["fst"];
  const _values_0 = _t_0["snd"];
  return {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": {$: "Con", "head": _value_0, "tail": _values_0}}};
}

function $damage$045body$058positioned$1260$(_args_0, _observed_0) {
  const _goal_0 = _args_0["goal"];
  const _damage_0 = _args_0["damage"];
  return $damage$045body$058positioned_result$1260$(_goal_0, _damage_0, _observed_0);
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058read$1260$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047src$047ecs$047capabilities$058read_field$1260$(($damage$045body$058position_cap$1260$(($$$$047$$$047$$$047src$047ecs$047compose$058plan_caps$1260$(($damage$058plan$1260$()))))))), _ctx_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_get$1261$(_family_0, _tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047component$058tx_get_join$1261$(_undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047src$047ecs$047component$058get$1261$(_family_0, _world_0, _handle_0)));
}

function $schema$058health$1260$() {
  return {$: "../../../src/ecs/component.Family", "name": "Simulation/Health"};
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_set$1260$(_family_0, _tx_0, _handle_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047component$058tx_set_fused$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047src$047ecs$047component$058stamped_allowed$1260$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058emit$1260$(_tx_0, _event_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": {$: "Con", "head": _event_0, "tail": _events_0}};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058despawn_join$1260$(_handle_0, _error_0, _cursor_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../src/ecs/world.Accepted") {
    return {$: "../../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0};
  } else {
    const _reason_0 = _t_0["error"];
    return {$: "../../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": ($$$$047$$$047$$$047src$047ecs$047compose$058first_error$(_error_0, _reason_0)), "cursor": _cursor_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058tx_despawn_with$1260$(_tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047commands$058despawn_join_with$1260$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _undo_0, _commands_0, _events_0, _handle_0);
}

function $$$$047$$$047$$$047src$047ecs$047compose$058and_join$1260$(_observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _frame_0, "snd": false};
  } else {
    return $damage$058selected_health$1260$(_frame_0);
  }
}

function $damage$058selected_position$1260$(_frame_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058family_match$1261$(_frame_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $movement$058moved$1260$(_fixed_step_0, _position_0, _observed_0) {
  const _value_0 = _position_0["value"];
  const _sentinel_0 = _position_0["sentinel"];
  return $movement$058moved_result$1260$(_fixed_step_0, _value_0, _sentinel_0, _observed_0);
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058read$1261$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047src$047ecs$047capabilities$058read_field$1260$(($movement$058velocity_cap$1260$(($$$$047$$$047$$$047src$047ecs$047compose$058plan_caps$1261$(($movement$058plan$1260$()))))))), _ctx_0);
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058write_read_field$1260$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $movement$058position_cap$1260$(_ops_0) {
  const _position_0 = _ops_0["position"];
  return _position_0;
}

function $$$$047$$$047$$$047src$047ecs$047compose$058plan_caps$1261$(_plan_0) {
  const _caps_0 = _plan_0["caps"];
  return _caps_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_get_join$1260$(_undo_0, _commands_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058get$1260$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047component$058get_live_owned$1260$(_id_0, ($$$$047$$$047$$$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_set_fused$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _observed_0) {
  const _result_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058tx_written$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_allowed$1261$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": {$: "Some", "value": _incoming_0}, "error": {$: "../../../src/ecs/world.MissingEntity"}}, "snd": {$: "../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058stamped_world$1261$(_id_0, _incoming_0, _world_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, ($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_get_join$1262$(_undo_0, _commands_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058get$1262$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047component$058get_live_owned$1262$(_id_0, ($$$$047$$$047$$$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $movement$058selected_velocity$1260$(_frame_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058family_match$1262$(_frame_0);
}

function $$$$047$$$047$$$047src$047ecs$047compose$058family_match$1261$(_frame_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058selected_join$1260$({$: "../../../src/ecs/compose.Required"}, ($$$$047$$$047$$$047src$047ecs$047compose$058get$1260$(_frame_0)));
}

function $$$$047$$$047$$$047src$047ecs$047resource$058restore_join$1260$(_replaced_0) {
  const _world_0 = _replaced_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1263$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1263$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1264$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1264$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1265$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1265$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  }
}

function $damage$045body$058eligible$1261$(_accepted_0, _damage_0, _ctx_0) {
  if (!_accepted_0) {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Success"}, "snd": {$: "geometry.Cell", "value": 0, "sentinel": 0}}};
  } else {
    return $damage$045body$058damaged$1261$(_damage_0, run_loop($$$$047$$$047$$$047src$047ecs$047capabilities$058get$1262$(_ctx_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058get_live_owned$1264$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1267$(($$$$047$$$047$$$047src$047ecs$047component$058get_store$1264$(_id_0, ($storage$058take_health$1261$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_written$1262$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../../src/ecs/component.Written", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1262$(_handle_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047component$058restore$1262$(_family_0, _handle_0, _previous_0, _x_0)));
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["incoming"];
    if (_t_0.$ === "Some") {
      const _incoming_0 = _t_0["value"];
      const _error_0 = _result_0["error"];
      return {$: "../../../src/ecs/component.WriteRejected", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "incoming": _incoming_0, "error": _error_0};
    } else {
      const _error_1 = _result_0["error"];
      return {$: "../../../src/ecs/component.WriteFailure", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "error": _error_1};
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_world$1262$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047component$058stamped_replaced$1262$(($$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1269$(($$$$047$$$047$$$047src$047ecs$047component$058stamped_store$1262$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))), (_clock_0 < 4294967295), ($storage$058take_health$1261$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, ($$$$047$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))))));
}

function $$$$047$$$047$$$047src$047ecs$047commands$058despawn_checked_with$1261$(_allowed_0, _world_0, _undo_0, _commands_0, _events_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "../../../src/ecs/world.Rejected", "error": {$: "../../../src/ecs/world.MissingEntity"}}};
  } else {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047commands$058despawn_apply_with$1261$(_x_0, _handle_0);
}), "tail": _commands_0}, "events": _events_0}, "snd": {$: "../../../src/ecs/world.Accepted"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047compose$058family_match$1263$(_frame_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058selected_join$1261$({$: "../../../src/ecs/compose.Required"}, ($$$$047$$$047$$$047src$047ecs$047compose$058get$1264$(_frame_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058set$1263$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047src$047ecs$047capabilities$058write_field$1261$(($movement$058position_cap$1261$(($$$$047$$$047$$$047src$047ecs$047compose$058plan_caps$1263$(($movement$058plan$1261$())))))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1267$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058get_store$1263$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058get_projected$1263$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058view$1263$(_column_0, _id_0)));
}

function $storage$058take_position$1261$(_store_0) {
  const _position_0 = _store_0["position"];
  const _velocity_0 = _store_0["velocity"];
  const _health_0 = _store_0["health"];
  return {$: "Tuple", "fst": {$: "storage.PositionRest", "velocity": _velocity_0, "health": _health_0}, "snd": _position_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1263$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1263$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1263$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore$1263$(_family_0, _handle_0, _incoming_0, _world_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_allowed$1263$(($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_replaced$1263$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _t_1 = _t_0["fst"];
  if (_t_1.$ === "../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_1["previous"];
    const _stamp_0 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0}, "snd": _stamp_0};
  } else {
    const _incoming_0 = _t_1["incoming"];
    const _stamp_1 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}}, "snd": _stamp_1};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1269$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_store$1263$(_id_0, _incoming_0, _tick_0, _allowed_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058stamped_column$1263$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, ($$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1261$(_column_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, _allowed_0) {
  if (!_allowed_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047world$058live_join$1261$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058get_store$1265$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058get_projected$1265$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058view$1263$(_column_0, _id_0)));
}

function $storage$058take_velocity$1261$(_store_0) {
  const _position_0 = _store_0["position"];
  const _velocity_0 = _store_0["velocity"];
  const _health_0 = _store_0["health"];
  return {$: "Tuple", "fst": {$: "storage.VelocityRest", "position": _position_0, "health": _health_0}, "snd": _velocity_0};
}

function $$$$047$$$047$$$047src$047ecs$047compose$058selected_value$1260$(_mode_0, _value_0) {
  if (_mode_0.$ === "../../../src/ecs/compose.Required") {
    if (_value_0.$ === "../../../src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../../src/ecs/compose.Present") {
    if (_value_0.$ === "../../../src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../../src/ecs/compose.Absent") {
    if (_value_0.$ === "../../../src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_value_0.$ === "../../../src/ecs/component.Found") {
      return true;
    } else if (_value_0.$ === "../../../src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  }
}

function $spawn$058replaced$1260$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058structural_replace$1260$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1260$(($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058structural_replace$1261$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1261$(($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058structural_replace$1262$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1262$(($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $damage$045body$058positioned_result$1260$(_goal_0, _damage_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Found") {
    const _t_1 = _t_0["value"];
    const _position_0 = _t_1["value"];
    return $damage$045body$058eligible$1260$((_goal_0 <= _position_0), _damage_0, _ctx_0);
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Failure", "error": {$: "damage-body.DamageMissingPosition"}}, "snd": {$: "geometry.Cell", "value": 0, "sentinel": 0}}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058read_field$1260$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $damage$045body$058position_cap$1260$(_ops_0) {
  const _position_0 = _ops_0["position"];
  return _position_0;
}

function $$$$047$$$047$$$047src$047ecs$047compose$058plan_caps$1260$(_plan_0) {
  const _caps_0 = _plan_0["caps"];
  return _caps_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_get_join$1261$(_undo_0, _commands_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058get$1261$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047component$058get_live_owned$1261$(_id_0, ($$$$047$$$047$$$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_set_fused$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _observed_0) {
  const _result_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058tx_written$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": {$: "Some", "value": _incoming_0}, "error": {$: "../../../src/ecs/world.MissingEntity"}}, "snd": {$: "../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058stamped_world$1260$(_id_0, _incoming_0, _world_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058despawn_join_with$1260$(_checked_0, _undo_0, _commands_0, _events_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047commands$058despawn_checked_with$1260$(_allowed_0, _world_0, _undo_0, _commands_0, _events_0, _handle_0);
}

function $damage$058selected_health$1260$(_frame_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058family_match$1260$(_frame_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $movement$058moved_result$1260$(_fixed_step_0, _value_0, _sentinel_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Found") {
    const _t_1 = _t_0["value"];
    const _velocity_0 = _t_1["value"];
    const _x_0 = (Math.imul(_velocity_0, _fixed_step_0) >>> 0);
    const _next_0 = ((_value_0 + _x_0) >>> 0);
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047src$047ecs$047capabilities$058set$1261$(_ctx_0, array_node([_next_0], [_sentinel_0]))), "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Success"}, "snd": {$: "geometry.Cell", "value": _next_0, "sentinel": _sentinel_0}}};
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Failure", "error": {$: "movement.MovementMissingVelocity"}}, "snd": {$: "geometry.Cell", "value": _value_0, "sentinel": _sentinel_0}}};
  }
}

function $movement$058velocity_cap$1260$(_ops_0) {
  const _velocity_0 = _ops_0["velocity"];
  return _velocity_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058get_live_owned$1260$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1262$(($$$$047$$$047$$$047src$047ecs$047component$058get_store$1260$(_id_0, ($storage$058take_position$1260$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_written$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../../src/ecs/component.Written", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1261$(_handle_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047component$058restore$1261$(_family_0, _handle_0, _previous_0, _x_0)));
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["incoming"];
    if (_t_0.$ === "Some") {
      const _incoming_0 = _t_0["value"];
      const _error_0 = _result_0["error"];
      return {$: "../../../src/ecs/component.WriteRejected", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "incoming": _incoming_0, "error": _error_0};
    } else {
      const _error_1 = _result_0["error"];
      return {$: "../../../src/ecs/component.WriteFailure", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "error": _error_1};
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_world$1261$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047component$058stamped_replaced$1261$(($$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1264$(($$$$047$$$047$$$047src$047ecs$047component$058stamped_store$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))), (_clock_0 < 4294967295), ($storage$058take_position$1260$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, ($$$$047$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))))));
}

function $$$$047$$$047$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058get_live_owned$1262$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1262$(($$$$047$$$047$$$047src$047ecs$047component$058get_store$1262$(_id_0, ($storage$058take_velocity$1260$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047compose$058family_match$1262$(_frame_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058selected_join$1260$({$: "../../../src/ecs/compose.Required"}, ($$$$047$$$047$$$047src$047ecs$047compose$058get$1262$(_frame_0)));
}

function $$$$047$$$047$$$047src$047ecs$047compose$058selected_join$1260$(_mode_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047src$047ecs$047compose$058selected_value$1260$(_mode_0, _value_0))};
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1263$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1263$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1264$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1264$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1265$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1265$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_incoming_0)));
}

function $damage$045body$058damaged$1261$(_damage_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Found") {
    const _t_1 = _t_0["value"];
    const _value_0 = _t_1["value"];
    const _sentinel_0 = _t_1["sentinel"];
    const _next_0 = ((_value_0 - _damage_0) >>> 0);
    return $damage$045body$058hit$1261$(_damage_0, {$: "geometry.Cell", "value": _next_0, "sentinel": _sentinel_0}, run_loop($$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1261$(run_loop($$$$047$$$047$$$047src$047ecs$047capabilities$058set$1262$(_ctx_0, array_node([_next_0], [_sentinel_0]))))));
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Failure", "error": {$: "damage-body.DamageMissingHealth"}}, "snd": {$: "geometry.Cell", "value": 0, "sentinel": 0}}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058get$1262$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047src$047ecs$047capabilities$058write_read_field$1261$(($damage$045body$058health_cap$1261$(($$$$047$$$047$$$047src$047ecs$047compose$058plan_caps$1262$(($damage$058plan$1261$()))))))), _ctx_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058get_store$1264$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058get_projected$1264$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058view$1263$(_column_0, _id_0)));
}

function $storage$058take_health$1261$(_store_0) {
  const _position_0 = _store_0["position"];
  const _velocity_0 = _store_0["velocity"];
  const _health_0 = _store_0["health"];
  return {$: "Tuple", "fst": {$: "storage.HealthRest", "position": _position_0, "velocity": _velocity_0}, "snd": _health_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1262$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1262$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1262$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore$1262$(_family_0, _handle_0, _incoming_0, _world_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_allowed$1262$(($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_replaced$1262$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _t_1 = _t_0["fst"];
  if (_t_1.$ === "../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_1["previous"];
    const _stamp_0 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0}, "snd": _stamp_0};
  } else {
    const _incoming_0 = _t_1["incoming"];
    const _stamp_1 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}}, "snd": _stamp_1};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_store$1262$(_id_0, _incoming_0, _tick_0, _allowed_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058stamped_column$1262$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, ($$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1261$(_column_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047commands$058despawn_apply_with$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047commands$058clear_accepted$1261$(($$$$047$$$047$$$047src$047ecs$047world$058deactivate$1261$(_world_0, _handle_0)), _handle_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058write_field$1261$(_cap_0) {
  const _set_0 = _cap_0["set"];
  return _set_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058get_projected$1263$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($storage$058put_position$1261$(_rest_0, _column_0)), "snd": ($$$$047$$$047$$$047src$047ecs$047component$058access$1260$(_value_0))};
}

function $$$$047$$$047$$$047src$047ecs$047column$058view$1263$(_column_0, _id_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1263$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1263$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1263$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1263$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1263$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1263$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1268$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1263$(_id_0, _stamp_0, ($storage$058take_position$1261$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_allowed$1263$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return _world_0;
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058restore_observed$1263$(($$$$047$$$047$$$047src$047ecs$047component$058restore_world$1263$(_id_0, _incoming_0, _world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_column$1263$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, _observed_0) {
  if (!_allowed_0) {
    const _column_0 = _observed_0["fst"];
    const _stamp_0 = _observed_0["snd"];
    return {$: "Tuple", "fst": ($storage$058put_position$1261$(_rest_0, _column_0)), "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/component.SwapRejected", "incoming": {$: "Some", "value": _incoming_0}}, "snd": _stamp_0}};
  } else {
    const _column_1 = _observed_0["fst"];
    const _stamp_1 = _observed_0["snd"];
    return $$$$047$$$047$$$047src$047ecs$047component$058stamped_store_join$1263$(_stamp_1, ($$$$047$$$047$$$047src$047ecs$047component$058swap_join$1265$(_rest_0, _id_0, true, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1261$(_column_1, _id_0)), _id_0, {$: "Some", "value": _incoming_0})))));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058live_join$1261$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058get_projected$1265$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($storage$058put_velocity$1261$(_rest_0, _column_0)), "snd": ($$$$047$$$047$$$047src$047ecs$047component$058access$1260$(_value_0))};
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1261$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1262$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1262$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $damage$045body$058eligible$1260$(_accepted_0, _damage_0, _ctx_0) {
  if (!_accepted_0) {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Success"}, "snd": {$: "geometry.Cell", "value": 0, "sentinel": 0}}};
  } else {
    return $damage$045body$058damaged$1260$(_damage_0, run_loop($$$$047$$$047$$$047src$047ecs$047capabilities$058get$1260$(_ctx_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058get_live_owned$1261$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1262$(($$$$047$$$047$$$047src$047ecs$047component$058get_store$1261$(_id_0, ($storage$058take_health$1260$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_written$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../../src/ecs/component.Written", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1260$(_handle_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047component$058restore$1260$(_family_0, _handle_0, _previous_0, _x_0)));
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["incoming"];
    if (_t_0.$ === "Some") {
      const _incoming_0 = _t_0["value"];
      const _error_0 = _result_0["error"];
      return {$: "../../../src/ecs/component.WriteRejected", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "incoming": _incoming_0, "error": _error_0};
    } else {
      const _error_1 = _result_0["error"];
      return {$: "../../../src/ecs/component.WriteFailure", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "error": _error_1};
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_world$1260$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047component$058stamped_replaced$1260$(($$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1264$(($$$$047$$$047$$$047src$047ecs$047component$058stamped_store$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))), (_clock_0 < 4294967295), ($storage$058take_health$1260$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, ($$$$047$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))))));
}

function $$$$047$$$047$$$047src$047ecs$047commands$058despawn_checked_with$1260$(_allowed_0, _world_0, _undo_0, _commands_0, _events_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "../../../src/ecs/world.Rejected", "error": {$: "../../../src/ecs/world.MissingEntity"}}};
  } else {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047commands$058despawn_apply_with$1260$(_x_0, _handle_0);
}), "tail": _commands_0}, "events": _events_0}, "snd": {$: "../../../src/ecs/world.Accepted"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047compose$058family_match$1260$(_frame_0) {
  return $$$$047$$$047$$$047src$047ecs$047compose$058selected_join$1260$({$: "../../../src/ecs/compose.Required"}, ($$$$047$$$047$$$047src$047ecs$047compose$058get$1261$(_frame_0)));
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058set$1261$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047src$047ecs$047capabilities$058write_field$1260$(($movement$058position_cap$1260$(($$$$047$$$047$$$047src$047ecs$047compose$058plan_caps$1261$(($movement$058plan$1260$())))))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1262$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058get_store$1260$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058get_projected$1260$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058view$1261$(_column_0, _id_0)));
}

function $storage$058take_position$1260$(_store_0) {
  const _position_0 = _store_0["position"];
  const _velocity_0 = _store_0["velocity"];
  const _health_0 = _store_0["health"];
  return {$: "Tuple", "fst": {$: "storage.PositionRest", "velocity": _velocity_0, "health": _health_0}, "snd": _position_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1261$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1261$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1261$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore$1261$(_family_0, _handle_0, _incoming_0, _world_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_allowed$1261$(($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_replaced$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _t_1 = _t_0["fst"];
  if (_t_1.$ === "../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_1["previous"];
    const _stamp_0 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0}, "snd": _stamp_0};
  } else {
    const _incoming_0 = _t_1["incoming"];
    const _stamp_1 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}}, "snd": _stamp_1};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1264$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_store$1261$(_id_0, _incoming_0, _tick_0, _allowed_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058stamped_column$1261$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, ($$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047world$058live_join$1260$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058get_store$1262$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058get_projected$1262$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058view$1261$(_column_0, _id_0)));
}

function $storage$058take_velocity$1260$(_store_0) {
  const _position_0 = _store_0["position"];
  const _velocity_0 = _store_0["velocity"];
  const _health_0 = _store_0["health"];
  return {$: "Tuple", "fst": {$: "storage.VelocityRest", "position": _position_0, "health": _health_0}, "snd": _velocity_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1263$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1263$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1264$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1264$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1265$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1265$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0)));
  }
}

function $damage$045body$058hit$1261$(_damage_0, _health_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _id_0 = _t_0["id"];
  return $damage$045body$058hit_health$1261$(_damage_0, _id_0, _ctx_0, _health_0);
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1261$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1261$(($damage$045body$058handle_cap$1261$(($$$$047$$$047$$$047src$047ecs$047compose$058plan_caps$1262$(($damage$058plan$1261$()))))))), _ctx_0);
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058set$1262$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047src$047ecs$047capabilities$058write_field$1261$(($damage$045body$058health_cap$1261$(($$$$047$$$047$$$047src$047ecs$047compose$058plan_caps$1262$(($damage$058plan$1261$())))))))(_ctx_0), _value_0);
}

function $damage$045body$058health_cap$1261$(_ops_0) {
  const _health_0 = _ops_0["health"];
  return _health_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058get_projected$1264$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($storage$058put_health$1261$(_rest_0, _column_0)), "snd": ($$$$047$$$047$$$047src$047ecs$047component$058access$1260$(_value_0))};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1262$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1262$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1268$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1262$(_id_0, _stamp_0, ($storage$058take_health$1261$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_allowed$1262$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return _world_0;
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058restore_observed$1262$(($$$$047$$$047$$$047src$047ecs$047component$058restore_world$1262$(_id_0, _incoming_0, _world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_column$1262$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, _observed_0) {
  if (!_allowed_0) {
    const _column_0 = _observed_0["fst"];
    const _stamp_0 = _observed_0["snd"];
    return {$: "Tuple", "fst": ($storage$058put_health$1261$(_rest_0, _column_0)), "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/component.SwapRejected", "incoming": {$: "Some", "value": _incoming_0}}, "snd": _stamp_0}};
  } else {
    const _column_1 = _observed_0["fst"];
    const _stamp_1 = _observed_0["snd"];
    return $$$$047$$$047$$$047src$047ecs$047component$058stamped_store_join$1262$(_stamp_1, ($$$$047$$$047$$$047src$047ecs$047component$058swap_join$1263$(_rest_0, _id_0, true, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1261$(_column_1, _id_0)), _id_0, {$: "Some", "value": _incoming_0})))));
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058clear_accepted$1261$(_activated_0, _handle_0) {
  const _world_0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "../../../src/ecs/world.Rejected") {
    return _world_0;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047commands$058clear_join$1261$(($$$$047$$$047$$$047src$047ecs$047world$058with_store$1263$(run_clo((_x_0) => {
  return {$: "Tuple", "fst": ($cleanup$058clear$1261$(_x_0, _handle_0)), "snd": {$: "Unit"}};
}), _world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058deactivate$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1261$(false, _handle_0, ($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $storage$058put_position$1261$(_rest_0, _position_0) {
  const _velocity_0 = _rest_0["velocity"];
  const _health_0 = _rest_0["health"];
  return {$: "storage.Store", "position": _position_0, "velocity": _velocity_0, "health": _health_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058access$1260$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "../../../src/ecs/component.ComponentAbsent"};
  } else {
    const _value_1 = _value_0["value"];
    return {$: "../../../src/ecs/component.Found", "value": _value_1};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1263$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1263$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1263$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1263$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1263$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1268$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1263$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($storage$058put_position$1261$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1261$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_observed$1263$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_world$1263$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1268$(($$$$047$$$047$$$047src$047ecs$047component$058restore_store$1263$(_id_0, _incoming_0, ($storage$058take_position$1261$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_store_join$1263$(_stamp_0, _result_0) {
  const _store_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _store_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": _stamp_0}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1265$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1265$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($storage$058put_position$1261$(_rest_0, _column_1)), "snd": {$: "../../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure$1261$(_column_0, _target_0) {
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1261$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047lifecycle$058choose$((_key_0 === _id_0), _stamp_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1261$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1261$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $storage$058put_velocity$1261$(_rest_0, _velocity_0) {
  const _position_0 = _rest_0["position"];
  const _health_0 = _rest_0["health"];
  return {$: "storage.Store", "position": _position_0, "velocity": _velocity_0, "health": _health_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1260$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1260$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1261$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1261$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1262$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1262$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_incoming_0)));
}

function $damage$045body$058damaged$1260$(_damage_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Found") {
    const _t_1 = _t_0["value"];
    const _value_0 = _t_1["value"];
    const _sentinel_0 = _t_1["sentinel"];
    const _next_0 = ((_value_0 - _damage_0) >>> 0);
    return $damage$045body$058hit$1260$(_damage_0, {$: "geometry.Cell", "value": _next_0, "sentinel": _sentinel_0}, run_loop($$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1260$(run_loop($$$$047$$$047$$$047src$047ecs$047capabilities$058set$1260$(_ctx_0, array_node([_next_0], [_sentinel_0]))))));
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Failure", "error": {$: "damage-body.DamageMissingHealth"}}, "snd": {$: "geometry.Cell", "value": 0, "sentinel": 0}}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058get$1260$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047src$047ecs$047capabilities$058write_read_field$1260$(($damage$045body$058health_cap$1260$(($$$$047$$$047$$$047src$047ecs$047compose$058plan_caps$1260$(($damage$058plan$1260$()))))))), _ctx_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058get_store$1261$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058get_projected$1261$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058view$1261$(_column_0, _id_0)));
}

function $storage$058take_health$1260$(_store_0) {
  const _position_0 = _store_0["position"];
  const _velocity_0 = _store_0["velocity"];
  const _health_0 = _store_0["health"];
  return {$: "Tuple", "fst": {$: "storage.HealthRest", "position": _position_0, "velocity": _velocity_0}, "snd": _health_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1260$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1260$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1260$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore$1260$(_family_0, _handle_0, _incoming_0, _world_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_allowed$1260$(($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_replaced$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _t_1 = _t_0["fst"];
  if (_t_1.$ === "../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_1["previous"];
    const _stamp_0 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0}, "snd": _stamp_0};
  } else {
    const _incoming_0 = _t_1["incoming"];
    const _stamp_1 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}}, "snd": _stamp_1};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_store$1260$(_id_0, _incoming_0, _tick_0, _allowed_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058stamped_column$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, ($$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047commands$058despawn_apply_with$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047commands$058clear_accepted$1260$(($$$$047$$$047$$$047src$047ecs$047world$058deactivate$1260$(_world_0, _handle_0)), _handle_0);
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058write_field$1260$(_cap_0) {
  const _set_0 = _cap_0["set"];
  return _set_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058get_projected$1260$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($storage$058put_position$1260$(_rest_0, _column_0)), "snd": ($$$$047$$$047$$$047src$047ecs$047component$058access$1260$(_value_0))};
}

function $$$$047$$$047$$$047src$047ecs$047column$058view$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1261$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1261$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1261$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1261$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1261$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1263$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1261$(_id_0, _stamp_0, ($storage$058take_position$1260$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_allowed$1261$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return _world_0;
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058restore_observed$1261$(($$$$047$$$047$$$047src$047ecs$047component$058restore_world$1261$(_id_0, _incoming_0, _world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_column$1261$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, _observed_0) {
  if (!_allowed_0) {
    const _column_0 = _observed_0["fst"];
    const _stamp_0 = _observed_0["snd"];
    return {$: "Tuple", "fst": ($storage$058put_position$1260$(_rest_0, _column_0)), "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/component.SwapRejected", "incoming": {$: "Some", "value": _incoming_0}}, "snd": _stamp_0}};
  } else {
    const _column_1 = _observed_0["fst"];
    const _stamp_1 = _observed_0["snd"];
    return $$$$047$$$047$$$047src$047ecs$047component$058stamped_store_join$1261$(_stamp_1, ($$$$047$$$047$$$047src$047ecs$047component$058swap_join$1262$(_rest_0, _id_0, true, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_1, _id_0)), _id_0, {$: "Some", "value": _incoming_0})))));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058live_join$1260$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058get_projected$1262$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($storage$058put_velocity$1260$(_rest_0, _column_0)), "snd": ($$$$047$$$047$$$047src$047ecs$047component$058access$1260$(_value_0))};
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1263$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replaced$1263$(($$$$047$$$047$$$047src$047ecs$047component$058swap_world$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1264$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replaced$1264$(($$$$047$$$047$$$047src$047ecs$047component$058swap_world$1264$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1265$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replaced$1265$(($$$$047$$$047$$$047src$047ecs$047component$058swap_world$1265$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $damage$045body$058hit_health$1261$(_damage_0, _id_0, _ctx_0, _health_0) {
  const _value_0 = _health_0["value"];
  const _sentinel_0 = _health_0["sentinel"];
  return {$: "Tuple", "fst": run_loop($damage$045body$058died$1261$((_value_0 === 0), _id_0, run_loop($$$$047$$$047$$$047src$047ecs$047capabilities$058send$1261$(_ctx_0, {$: "events.SimulationHit", "id": _id_0, "damage": _damage_0})))), "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Success"}, "snd": {$: "geometry.Cell", "value": _value_0, "sentinel": _sentinel_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1261$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $damage$045body$058handle_cap$1261$(_ops_0) {
  const _handle_0 = _ops_0["handle"];
  return _handle_0;
}

function $storage$058put_health$1261$(_rest_0, _health_0) {
  const _position_0 = _rest_0["position"];
  const _velocity_0 = _rest_0["velocity"];
  return {$: "storage.Store", "position": _position_0, "velocity": _velocity_0, "health": _health_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1262$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($storage$058put_health$1261$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1261$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_observed$1262$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_world$1262$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1268$(($$$$047$$$047$$$047src$047ecs$047component$058restore_store$1262$(_id_0, _incoming_0, ($storage$058take_health$1261$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_store_join$1262$(_stamp_0, _result_0) {
  const _store_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _store_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": _stamp_0}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1263$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1263$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($storage$058put_health$1261$(_rest_0, _column_1)), "snd": {$: "../../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058clear_join$1261$(_cleared_0) {
  const _world_0 = _cleared_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store$1263$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1268$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $cleanup$058clear$1261$(_store_0, _handle_0) {
  const _position_0 = _store_0["position"];
  const _velocity_0 = _store_0["velocity"];
  const _health_0 = _store_0["health"];
  const _id_0 = _handle_0["id"];
  return {$: "storage.Store", "position": ($cleanup$058cleared$1261$(($$$$047$$$047$$$047src$047ecs$047column$058clear$1261$(_position_0, _id_0)))), "velocity": ($cleanup$058cleared$1261$(($$$$047$$$047$$$047src$047ecs$047column$058clear$1261$(_velocity_0, _id_0)))), "health": ($cleanup$058cleared$1261$(($$$$047$$$047$$$047src$047ecs$047column$058clear$1261$(_health_0, _id_0))))};
}

function $$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1263$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1263$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1263$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1263$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1263$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1263$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1263$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1263$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1261$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_store$1263$(_id_0, _incoming_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_swap$1263$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1261$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1265$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($storage$058put_position$1261$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1261$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1261$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047lifecycle$058choose$(_found_0, _stamp_0, _other_0) {
  if (_found_0) {
    return _stamp_0;
  } else {
    return _other_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1261$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)), (_id_0 <= _capacity_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1261$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1260$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1260$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1261$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1261$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1262$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1262$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $damage$045body$058hit$1260$(_damage_0, _health_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _id_0 = _t_0["id"];
  return $damage$045body$058hit_health$1260$(_damage_0, _id_0, _ctx_0, _health_0);
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1260$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1260$(($damage$045body$058handle_cap$1260$(($$$$047$$$047$$$047src$047ecs$047compose$058plan_caps$1260$(($damage$058plan$1260$()))))))), _ctx_0);
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058set$1260$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047src$047ecs$047capabilities$058write_field$1260$(($damage$045body$058health_cap$1260$(($$$$047$$$047$$$047src$047ecs$047compose$058plan_caps$1260$(($damage$058plan$1260$())))))))(_ctx_0), _value_0);
}

function $damage$045body$058health_cap$1260$(_ops_0) {
  const _health_0 = _ops_0["health"];
  return _health_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058get_projected$1261$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($storage$058put_health$1260$(_rest_0, _column_0)), "snd": ($$$$047$$$047$$$047src$047ecs$047component$058access$1260$(_value_0))};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1260$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1263$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1260$(_id_0, _stamp_0, ($storage$058take_health$1260$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return _world_0;
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058restore_observed$1260$(($$$$047$$$047$$$047src$047ecs$047component$058restore_world$1260$(_id_0, _incoming_0, _world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_column$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, _observed_0) {
  if (!_allowed_0) {
    const _column_0 = _observed_0["fst"];
    const _stamp_0 = _observed_0["snd"];
    return {$: "Tuple", "fst": ($storage$058put_health$1260$(_rest_0, _column_0)), "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/component.SwapRejected", "incoming": {$: "Some", "value": _incoming_0}}, "snd": _stamp_0}};
  } else {
    const _column_1 = _observed_0["fst"];
    const _stamp_1 = _observed_0["snd"];
    return $$$$047$$$047$$$047src$047ecs$047component$058stamped_store_join$1260$(_stamp_1, ($$$$047$$$047$$$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, true, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_1, _id_0)), _id_0, {$: "Some", "value": _incoming_0})))));
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058clear_accepted$1260$(_activated_0, _handle_0) {
  const _world_0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "../../../src/ecs/world.Rejected") {
    return _world_0;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047commands$058clear_join$1260$(($$$$047$$$047$$$047src$047ecs$047world$058with_store$1261$(run_clo((_x_0) => {
  return {$: "Tuple", "fst": ($cleanup$058clear$1260$(_x_0, _handle_0)), "snd": {$: "Unit"}};
}), _world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058deactivate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1260$(false, _handle_0, ($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $storage$058put_position$1260$(_rest_0, _position_0) {
  const _velocity_0 = _rest_0["velocity"];
  const _health_0 = _rest_0["health"];
  return {$: "storage.Store", "position": _position_0, "velocity": _velocity_0, "health": _health_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1261$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1261$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1261$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1263$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1261$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($storage$058put_position$1260$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_observed$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_world$1261$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1263$(($$$$047$$$047$$$047src$047ecs$047component$058restore_store$1261$(_id_0, _incoming_0, ($storage$058take_position$1260$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_store_join$1261$(_stamp_0, _result_0) {
  const _store_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _store_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": _stamp_0}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1262$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1262$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($storage$058put_position$1260$(_rest_0, _column_1)), "snd": {$: "../../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_0, _target_0) {
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $storage$058put_velocity$1260$(_rest_0, _velocity_0) {
  const _position_0 = _rest_0["position"];
  const _health_0 = _rest_0["health"];
  return {$: "storage.Store", "position": _position_0, "velocity": _velocity_0, "health": _health_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058replaced$1263$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_world$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1266$(($$$$047$$$047$$$047src$047ecs$047component$058swap_store$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($storage$058take_health$1261$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replaced$1264$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_world$1264$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1266$(($$$$047$$$047$$$047src$047ecs$047component$058swap_store$1264$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($storage$058take_velocity$1261$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058replaced$1265$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_world$1265$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1266$(($$$$047$$$047$$$047src$047ecs$047component$058swap_store$1265$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($storage$058take_position$1261$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $damage$045body$058died$1261$(_dead_0, _id_0, _ctx_0) {
  if (!_dead_0) {
    return _ctx_0;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047capabilities$058action$1261$(run_loop($$$$047$$$047$$$047src$047ecs$047capabilities$058send$1261$(_ctx_0, {$: "events.SimulationDeath", "id": _id_0})));
  }
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058send$1261$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047src$047ecs$047capabilities$058send_field$1261$(($damage$045body$058events_cap$1261$(($$$$047$$$047$$$047src$047ecs$047compose$058plan_caps$1262$(($damage$058plan$1261$())))))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_store$1262$(_id_0, _incoming_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_swap$1262$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1261$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1263$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($storage$058put_health$1261$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $cleanup$058cleared$1261$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return _column_0;
  } else {
    const _column_1 = _result_0["column"];
    return _column_1;
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058clear$1261$(_column_0, _id_0) {
  return $$$$047$$$047$$$047src$047ecs$047column$058cleared$1261$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(_column_0, _id_0, {$: "None"})));
}

function $$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1263$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1263$(_values_0, _stamps_0, _id_0, ($geometry$058project$(_owner_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($geometry$058project$(_owned_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1263$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047src$047ecs$047column$058view_taken$1263$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058seek_view$1263$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1263$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1263$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($geometry$058project$(_owned_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1263$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047src$047ecs$047column$058view_taken$1263$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1263$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_entries_0, _id_0, _stamp_0) {
  return {$: "Con", "head": {$: "../../../src/ecs/lifecycle.Entry", "id": _id_0, "stamp": _stamp_0}, "tail": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0))};
}

function $$$$047$$$047$$$047src$047ecs$047column$058restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_swap$1263$(_rest_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": ($storage$058put_position$1261$(_rest_0, _column_0)), "snd": {$: "Unit"}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": ($storage$058put_position$1261$(_rest_0, _column_1)), "snd": {$: "Unit"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058grow$1261$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1261$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0, _fits_0) {
  if (!_isnormal_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_exceptional_0, _id_0))};
  } else {
    if (!_fits_0) {
      return {$: "Tuple", "fst": {$: "../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
    } else {
      const _x_0 = ((_id_0 - 1) >>> 0);
      return $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, {$: "Tuple", fst: _added_0, snd: _added_0[_x_0 % _added_0.length]});
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0) {
  return $Bool$and$((_id_0 > 0), (_id_0 <= 131072));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1260$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replaced$1260$(($$$$047$$$047$$$047src$047ecs$047component$058swap_world$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1261$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replaced$1261$(($$$$047$$$047$$$047src$047ecs$047component$058swap_world$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1262$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replaced$1262$(($$$$047$$$047$$$047src$047ecs$047component$058swap_world$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $damage$045body$058hit_health$1260$(_damage_0, _id_0, _ctx_0, _health_0) {
  const _value_0 = _health_0["value"];
  const _sentinel_0 = _health_0["sentinel"];
  return {$: "Tuple", "fst": run_loop($damage$045body$058died$1260$((_value_0 === 0), _id_0, run_loop($$$$047$$$047$$$047src$047ecs$047capabilities$058send$1260$(_ctx_0, {$: "events.SimulationHit", "id": _id_0, "damage": _damage_0})))), "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Success"}, "snd": {$: "geometry.Cell", "value": _value_0, "sentinel": _sentinel_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1260$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $damage$045body$058handle_cap$1260$(_ops_0) {
  const _handle_0 = _ops_0["handle"];
  return _handle_0;
}

function $storage$058put_health$1260$(_rest_0, _health_0) {
  const _position_0 = _rest_0["position"];
  const _velocity_0 = _rest_0["velocity"];
  return {$: "storage.Store", "position": _position_0, "velocity": _velocity_0, "health": _health_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1260$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($storage$058put_health$1260$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_observed$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_world$1260$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1263$(($$$$047$$$047$$$047src$047ecs$047component$058restore_store$1260$(_id_0, _incoming_0, ($storage$058take_health$1260$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_store_join$1260$(_stamp_0, _result_0) {
  const _store_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _store_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": _stamp_0}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1260$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($storage$058put_health$1260$(_rest_0, _column_1)), "snd": {$: "../../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058clear_join$1260$(_cleared_0) {
  const _world_0 = _cleared_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store$1261$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1263$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $cleanup$058clear$1260$(_store_0, _handle_0) {
  const _position_0 = _store_0["position"];
  const _velocity_0 = _store_0["velocity"];
  const _health_0 = _store_0["health"];
  const _id_0 = _handle_0["id"];
  return {$: "storage.Store", "position": ($cleanup$058cleared$1260$(($$$$047$$$047$$$047src$047ecs$047column$058clear$1260$(_position_0, _id_0)))), "velocity": ($cleanup$058cleared$1260$(($$$$047$$$047$$$047src$047ecs$047column$058clear$1260$(_velocity_0, _id_0)))), "health": ($cleanup$058cleared$1260$(($$$$047$$$047$$$047src$047ecs$047column$058clear$1260$(_health_0, _id_0))))};
}

function $$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1261$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1261$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1261$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1261$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_store$1261$(_id_0, _incoming_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_swap$1261$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1262$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($storage$058put_position$1260$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1260$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1266$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_store$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1263$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1261$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_store$1264$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1264$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1261$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_store$1265$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1265$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1261$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058action$1261$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047src$047ecs$047capabilities$058action_field$1261$(($damage$045body$058despawn_cap$1261$(($$$$047$$$047$$$047src$047ecs$047compose$058plan_caps$1262$(($damage$058plan$1261$()))))))), _ctx_0);
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058send_field$1261$(_cap_0) {
  const _send_0 = _cap_0["send"];
  return _send_0;
}

function $damage$045body$058events_cap$1261$(_ops_0) {
  const _events_0 = _ops_0["events"];
  return _events_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_swap$1262$(_rest_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": ($storage$058put_health$1261$(_rest_0, _column_0)), "snd": {$: "Unit"}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": ($storage$058put_health$1261$(_rest_0, _column_1)), "snd": {$: "Unit"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058cleared$1261$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _outcome_0["column"];
    const _previous_0 = _outcome_0["previous"];
    return {$: "../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047src$047ecs$047column$058clear_stamp$1261$(_column_0, _id_0)), "previous": _previous_0};
  } else {
    const _column_1 = _outcome_0["column"];
    const _incoming_0 = _outcome_0["incoming"];
    return {$: "../../../src/ecs/column.Rejected", "column": _column_1, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1263$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047src$047ecs$047column$058restored$1263$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058view_taken$1263$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047$$$047src$047ecs$047column$058viewed$1263$(($geometry$058project$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058seek_view$1263$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1263$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($geometry$058project$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1263$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1263$(_id_0, _values_0, _metadata_0, ($geometry$058project$(_owner_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1263$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1263$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($geometry$058project$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047lifecycle$058keep$((_key_0 === _id_0), {$: "../../../src/ecs/lifecycle.Entry", "id": _key_0, "stamp": _stamp_0}, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0) {
  if (!_incoming_0) {
    return {$: "../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058grow$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $U32$log2$(_n_0) {
  return $U32$log2$go$(5, _n_0, 0);
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1261$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1261$(_column_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1261$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1261$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _observed_0) {
  const _added_0 = _observed_0["fst"];
  const _first_0 = _observed_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, {$: "Tuple", fst: _changed_0, snd: _changed_0[_x_0 % _changed_0.length]});
}

function $$$$047$$$047$$$047src$047ecs$047component$058replaced$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_world$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1261$(($$$$047$$$047$$$047src$047ecs$047component$058swap_store$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($storage$058take_health$1260$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058replaced$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_world$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1261$(($$$$047$$$047$$$047src$047ecs$047component$058swap_store$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($storage$058take_velocity$1260$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058replaced$1262$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_world$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1261$(($$$$047$$$047$$$047src$047ecs$047component$058swap_store$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($storage$058take_position$1260$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $damage$045body$058died$1260$(_dead_0, _id_0, _ctx_0) {
  if (!_dead_0) {
    return _ctx_0;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047capabilities$058action$1260$(run_loop($$$$047$$$047$$$047src$047ecs$047capabilities$058send$1260$(_ctx_0, {$: "events.SimulationDeath", "id": _id_0})));
  }
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058send$1260$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047src$047ecs$047capabilities$058send_field$1260$(($damage$045body$058events_cap$1260$(($$$$047$$$047$$$047src$047ecs$047compose$058plan_caps$1260$(($damage$058plan$1260$())))))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_store$1260$(_id_0, _incoming_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_swap$1260$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1260$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($storage$058put_health$1260$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $cleanup$058cleared$1260$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return _column_0;
  } else {
    const _column_1 = _result_0["column"];
    return _column_1;
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058clear$1260$(_column_0, _id_0) {
  return $$$$047$$$047$$$047src$047ecs$047column$058cleared$1260$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, {$: "None"})));
}

function $$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1261$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1261$(_values_0, _stamps_0, _id_0, ($geometry$058project$(_owner_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($geometry$058project$(_owned_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058seek_view$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1261$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1261$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($geometry$058project$(_owned_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_swap$1261$(_rest_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": ($storage$058put_position$1260$(_rest_0, _column_0)), "snd": {$: "Unit"}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": ($storage$058put_position$1260$(_rest_0, _column_1)), "snd": {$: "Unit"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058grow$1260$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1264$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1264$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($storage$058put_velocity$1261$(_rest_0, _column_1)), "snd": {$: "../../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058action_field$1261$(_cap_0) {
  const _run_0 = _cap_0["run"];
  return _run_0;
}

function $damage$045body$058despawn_cap$1261$(_ops_0) {
  const _despawn_0 = _ops_0["despawn"];
  return _despawn_0;
}

function $$$$047$$$047$$$047src$047ecs$047column$058clear_stamp$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058clear_state$1261$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_clear_state$1261$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_clear_state$1261$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058restored$1263$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058viewed$1263$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047$$$047src$047ecs$047column$058restored$1263$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1263$(_result_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1261$({$: "../../../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1263$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1263$(_result_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1261$({$: "../../../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1263$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1263$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047$$$047src$047ecs$047lifecycle$058keep$(_equal_0, _entry_0, _rest_0) {
  if (_equal_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _entry_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0) {
  if (!_isnormal_0) {
    return {$: "../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_exceptional_0, _id_0, _stamp_0))};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_grow$(17, _id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, (_id_0 <= _capacity_0));
  }
}

function $$$$047$$$047$$$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0) {
  if (!_wasPresent_0) {
    return {$: "../../../src/ecs/lifecycle.Stamp", "added": _tick_0, "changed": _tick_0};
  } else {
    const _added_0 = _stamp_0["added"];
    return {$: "../../../src/ecs/lifecycle.Stamp", "added": _added_0, "changed": _tick_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_rest_0)), ($$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_rest_0)));
  }
}

function $U32$log2$go$($0, $1, $2) {
  for (;;) {
    {
      const _k_0 = $0;
      const _n_0 = $1;
      const _b_0 = $2;
      if (_k_0 === 0) {
        return _b_0;
      } else {
        const _p_0 = (_k_0 - 1);
        const _x_0 = (_p_0 >= 32 ? 0 : (1 << _p_0) >>> 0);
        const _s_0 = _x_0;
        const _x_1 = (_s_0 >= 32 ? 0 : (_n_0 >>> _s_0) >>> 0);
        const _x_2 = ($Bool$to_u32$((_x_1 !== 0)));
        const _t_0 = nat_chk(_s_0 * _x_2);
        $0 = _p_0;
        $1 = (_t_0 >= 32 ? 0 : (_n_0 >>> _t_0) >>> 0);
        $2 = nat_chk(_b_0 + _t_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1261$(_target_0, _column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, _observed_0) {
  const _changed_0 = _observed_0["fst"];
  const _last_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../../../src/ecs/lifecycle.Stamp", "added": _first_0, "changed": _last_0}};
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_store$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_store$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_store$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1262$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058action$1260$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047src$047ecs$047capabilities$058action_field$1260$(($damage$045body$058despawn_cap$1260$(($$$$047$$$047$$$047src$047ecs$047compose$058plan_caps$1260$(($damage$058plan$1260$()))))))), _ctx_0);
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058send_field$1260$(_cap_0) {
  const _send_0 = _cap_0["send"];
  return _send_0;
}

function $damage$045body$058events_cap$1260$(_ops_0) {
  const _events_0 = _ops_0["events"];
  return _events_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_swap$1260$(_rest_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": ($storage$058put_health$1260$(_rest_0, _column_0)), "snd": {$: "Unit"}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": ($storage$058put_health$1260$(_rest_0, _column_1)), "snd": {$: "Unit"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058cleared$1260$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _outcome_0["column"];
    const _previous_0 = _outcome_0["previous"];
    return {$: "../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047src$047ecs$047column$058clear_stamp$1260$(_column_0, _id_0)), "previous": _previous_0};
  } else {
    const _column_1 = _outcome_0["column"];
    const _incoming_0 = _outcome_0["incoming"];
    return {$: "../../../src/ecs/column.Rejected", "column": _column_1, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1261$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047src$047ecs$047column$058restored$1261$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047$$$047src$047ecs$047column$058viewed$1261$(($geometry$058project$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058seek_view$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($geometry$058project$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1261$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, ($geometry$058project$(_owner_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($geometry$058project$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1260$(_column_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1260$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1264$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($storage$058put_velocity$1261$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058clear_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_clear_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_clear_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1263$(_view_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1263$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1263$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1263$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_grow$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _id_0 = $1;
      const _stamp_0 = $2;
      const _added_0 = $3;
      const _changed_0 = $4;
      const _capacity_0 = $5;
      const _depth_0 = $6;
      const _exceptional_0 = $7;
      const _fits_0 = $8;
      if (_fuel_0 === 0) {
        if (_fits_0) {
          return $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          return {$: "../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_fits_0) {
          return $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          const _next_0 = ((_capacity_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _stamp_0;
          $3 = array_node(_added_0, array_new(_depth_0, 0));
          $4 = array_node(_changed_0, array_new(_depth_0, 0));
          $5 = _next_0;
          $6 = nat_chk(_depth_0 + 1);
          $7 = _exceptional_0;
          $8 = (_id_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $Bool$to_u32$(_b_0) {
  if (!_b_0) {
    return 0;
  } else {
    return 1;
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1261$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($storage$058put_velocity$1260$(_rest_0, _column_1)), "snd": {$: "../../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058action_field$1260$(_cap_0) {
  const _run_0 = _cap_0["run"];
  return _run_0;
}

function $damage$045body$058despawn_cap$1260$(_ops_0) {
  const _despawn_0 = _ops_0["despawn"];
  return _despawn_0;
}

function $$$$047$$$047$$$047src$047ecs$047column$058clear_stamp$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058clear_state$1260$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_clear_state$1260$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_clear_state$1260$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058restored$1261$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058viewed$1261$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047$$$047src$047ecs$047column$058restored$1261$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_result_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1260$({$: "../../../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1261$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_result_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1260$({$: "../../../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1261$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, _column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)), (_id_0 <= _capacity_0));
}

function $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0) {
  const _first_0 = _stamp_0["added"];
  const _last_0 = _stamp_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = ((_id_0 - 1) >>> 0);
  return {$: "../../../src/ecs/indexed-lifecycle.Metadata", "added": (_added_0[_x_0 % _added_0.length] = _first_0, _added_0), "changed": (_changed_0[_x_1 % _changed_0.length] = _last_0, _changed_0), "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1261$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($storage$058put_velocity$1260$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058clear_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_clear_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_clear_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_view_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1261$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1261$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0, _fits_0) {
  if (!_isnormal_0) {
    return {$: "../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_exceptional_0, _id_0))};
  } else {
    if (!_fits_0) {
      return {$: "../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, {$: "../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0});
    }
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, [[7,0,2,0,0,2,0,1,17,2,643,1,0,1,0,1,106,7,1,2,2,0,0,1,3,0,2,1,0,32,1,17,7,1,1,4,0,2,0,0,43,21,313,7,0,1,5,0,3,0,0,56,19,276,20,276,7,0,1,6,0,10,0,0,83,10,118,11,222,12,248,13,118,14,130,15,130,16,130,17,130,18,130,7,0,1,7,0,8,0,0,106,1,107,3,119,5,147,6,190,7,118,8,118,9,131,4,7,0,1,8,0,2,0,0,118,1,118,0,7,0,1,9,0,2,0,0,130,1,131,2,7,1,2,10,0,0,1,11,0,2,1,0,146,1,131,0,7,1,2,12,0,0,1,13,0,2,1,0,162,1,147,7,1,1,14,0,4,0,0,118,1,177,4,177,7,177,7,0,2,15,0,0,0,16,0,1,0,1,119,7,1,2,17,0,0,1,18,0,2,1,0,205,1,190,7,1,2,19,0,2,0,0,118,1,118,20,0,1,0,0,118,7,1,2,21,0,0,1,22,0,2,1,0,237,1,222,7,1,1,23,0,2,0,0,130,1,190,7,1,2,24,0,0,1,25,0,2,1,0,263,1,248,7,1,1,26,0,3,0,0,118,1,130,2,130,7,1,2,27,0,0,1,28,0,2,1,0,291,1,276,7,1,1,29,0,2,0,0,190,1,302,7,0,2,30,0,0,0,31,0,0,0,7,0,4,32,0,1,0,1,338,33,0,0,0,34,0,1,0,1,424,35,0,1,0,1,587,7,0,3,36,0,1,0,1,357,37,0,1,0,1,417,38,0,0,0,7,1,2,39,0,0,1,40,0,2,1,0,372,1,357,7,1,2,41,0,1,0,0,387,42,0,1,0,0,398,7,0,1,43,0,2,0,0,118,1,118,7,0,4,44,0,0,0,45,0,0,0,46,0,0,0,47,0,0,0,7,0,1,48,0,0,0,7,0,4,49,0,1,0,1,445,50,0,0,0,51,0,0,0,52,0,0,0,7,0,1,53,0,3,0,0,458,4,561,5,561,7,0,2,54,0,0,0,55,0,1,0,1,471,7,0,4,56,0,1,0,1,498,57,0,1,0,1,524,58,0,1,0,1,118,59,0,1,0,1,550,7,0,2,60,0,1,0,1,513,61,0,1,0,1,398,7,0,2,62,0,0,0,63,0,0,0,7,0,2,64,0,1,0,1,539,65,0,1,0,1,398,7,0,2,66,0,0,0,67,0,0,0,7,0,1,68,0,2,0,0,118,1,118,7,1,2,69,0,0,1,70,0,2,1,0,576,1,561,7,1,1,71,0,2,0,0,118,1,118,7,0,1,72,0,2,0,0,598,3,598,7,0,4,73,0,1,0,1,276,74,0,1,0,1,623,75,0,1,0,1,632,76,0,0,0,7,0,1,77,0,1,0,0,276,7,0,1,78,0,2,0,0,276,1,302,7,1,2,79,0,0,1,80,0,2,1,0,658,1,643,7,1,1,81,0,2,0,0,43,21,669,7,0,4,82,0,1,0,1,694,83,0,0,0,84,0,1,0,1,424,85,0,1,0,1,587,7,0,3,86,0,1,0,1,713,87,0,1,0,1,417,88,0,0,0,7,1,2,89,0,0,1,90,0,2,1,0,728,1,713,7,1,2,91,0,1,0,0,743,92,0,1,0,0,398,7,0,1,93,0,2,0,0,118,1,118],["TwoSchemaReport","InitializationRefused","Nil","Con","scenario.Phase","consumer-state.Observation","runtime-checkpoint.Snapshot","checkpoint.Snapshot","world-view.Allocation","owner-view.FullCell","Nil","Con","Nil","Con","store-view.EntityCells","None","Some","Nil","Con","events.SimulationHit","events.SimulationDeath","Nil","Con","../../../src/ecs/event-runtime.Batch","Nil","Con","../../../src/ecs/event-runtime.Position","Nil","Con","../../../src/ecs/event-runtime.Reading","False","True","scenario-actions.SpawnResult","scenario-actions.BarrierResult","scenario-actions.GameplayResult","scenario-actions.ReadersResult","runtime-spawn.SpawnSucceeded","runtime-spawn.SpawnFailed","runtime-spawn.SpawnRegistrationRejected","Nil","Con","../../../src/ecs/world.Reserved","../../../src/ecs/world.ReservationRejected","../../../src/ecs/world.Handle","../../../src/ecs/world.MissingEntity","../../../src/ecs/world.CapacityExceeded","../../../src/ecs/world.NamespaceExhausted","../../../src/ecs/world.SystemIdExhausted","spawn-system.SpawnFixtureError","consumer-gameplay.GameplayRan","consumer-gameplay.MovementRegistrationFailed","consumer-gameplay.DamageRegistrationFailed","consumer-gameplay.GameplayIncompleteRegistration","runtime-gameplay.FrameOutput","../../../src/ecs/transaction.Success","../../../src/ecs/transaction.Failure","gameplay-run.MovementRunFailed","gameplay-run.DamageRunFailed","gameplay-run.MovementRunRegistrationRefused","gameplay-run.DamageRunRegistrationRefused","../../../src/ecs/compose.UserError","../../../src/ecs/compose.AccessError","movement.MovementMissingPosition","movement.MovementMissingVelocity","../../../src/ecs/compose.UserError","../../../src/ecs/compose.AccessError","damage-body.DamageMissingPosition","damage-body.DamageMissingHealth","damage-body.DamageArgs","Nil","Con","geometry.Cell","consumer-state.ReaderResults","../readers-v1/pair.Succeeded","../readers-v1/pair.Failed","../readers-v1/pair.Rejected","../readers-v1/pair.Skipped","../readers-v1/readers.ReaderFailed","../readers-v1/readers.Args","Nil","Con","scenario.Phase","scenario-actions.SpawnResult","scenario-actions.BarrierResult","scenario-actions.GameplayResult","scenario-actions.ReadersResult","runtime-spawn.SpawnSucceeded","runtime-spawn.SpawnFailed","runtime-spawn.SpawnRegistrationRejected","Nil","Con","../../../src/ecs/world.Reserved","../../../src/ecs/world.ReservationRejected","../../../src/ecs/world.Handle"]]);