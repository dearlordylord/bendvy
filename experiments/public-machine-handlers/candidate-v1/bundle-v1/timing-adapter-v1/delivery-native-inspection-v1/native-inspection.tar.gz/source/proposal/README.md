# Native dependency inspection proposal

Source-only first gate: source5 then Cemit30, CPU8/25 ordinary guard probes. No Clang, execution, timing samples or workload qualification. Freeze fresh owned stage and canonical participating configs (including bend.toml, reachableHOME/.bend, resolved tool/Base/resource/import ancestry and target-kind coverage) before exact plan review.

The thin root retains one actual affine application through Queue(Play) → Marker → Read, with a start/end IO request around each operation. It consumes returned owners in the full physical observer after the final endclock, preventing a discarded-owner code-inspection shortcut. Setup occurs before those clock actions. IO values are not interpreted as speed samples because no runtime execution is admitted. Literal one is code reachability, not a selected measurement population.

Inspect emitted start continuation → actual Batch.step/selected application action → returned owner → completed/endNow and native corpus_eval/IO dispatch dependency, including any scheduler tasks/optimizer movement. Preserve actualC hash/ranges and any source/emit failures. No universal claim from a single schema/operation sequence. Full42 current JS correctness and six separate Bend-only baseline controls remain required; no reduced Native feature-qualification claim.

Use exact immutable stage/root/clock/independent ledger joins from inspection0c699. Do not repeat TS or JS baseline. The successful developer configuration receipt remains historical, with its missing bend.toml/fullresolver limitation explicit; new diagnostics must not silently rewrite it.
