// Source-only batched same-owner adapter; no population is selected or executed.
import {readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import {application} from './reference-ts.mjs';
const ledger=JSON.parse(readFileSync(new URL('./operations.json',import.meta.url)));
const expected=JSON.parse(readFileSync(new URL('./common-expected.json',import.meta.url))).comparable;
const failures={0:null,1:'enterPlay1',2:'exitBoot0',4:'enterPlay0',5:'exitBoot1',6:'transitionBootPlay'};
// actual operations are synchronous; the loop returns all actual applications
// before the endclock, matching Bend Batch.step's returned-owner barrier.
function step(apps,operation){
 for(const app of apps){
  if(operation.kind==='queue')app.queue(operation.value,operation.skip);
  else if(operation.kind==='marker')app.marker();
  else if(operation.kind==='read')app.read();
  else throw new Error('unknown operation');
 }
 return apps;
}
export function completeBatch(population,clock){
 if(!Number.isSafeInteger(population)||population<1)throw new Error('explicit population required');
 if(typeof clock!=='function')throw new Error('reviewed explicit clock required');
 const schemas={},samples=[];
 for(const schema of ledger.schemas){
  const rows=Array.from({length:population},()=>({}));
  for(const scenario of ledger.scenarios){
   const start=clock();
   let apps=Array.from({length:population},()=>application(schema,scenario.current,scenario.extra,failures[scenario.failureId]));
   const end=clock();samples.push({schema,scenario:scenario.scenario,kind:'setup',start:String(start),end:String(end)});
   for(const app of apps)app.capture('seed');
   for(const operation of scenario.steps){
    const before=clock();apps=step(apps,operation);const after=clock();
    samples.push({schema,scenario:scenario.scenario,kind:operation.kind,start:String(before),end:String(after)});
    for(const app of apps)app.capture(operation.kind);
    if(operation.checkpoint)apps.forEach((app,index)=>{rows[index][operation.checkpoint]=app.observe();});
   }
  }
  // Deep, type-sensitive correctness is outside every measured interval.
  for(const instance of rows)assert.deepEqual(Object.fromEntries(Object.entries(instance).map(([name,value])=>[name,value.common])),expected[schema]);
  schemas[schema]=rows;
 }
 return {status:'UNQUALIFIED_SOURCE_BATCH_TIMING_ADAPTER',population,schemas,samples};
}
