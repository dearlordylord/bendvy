// Complete correctness outside all recorded operation intervals; no timing gate.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {complete} from './reference-ts.mjs';
const expected=JSON.parse(readFileSync(new URL('./common-expected.json',import.meta.url),'utf8'));
const actual=complete();
console.log(JSON.stringify(actual));
for(const schema of ['A','B']){
 const rows=Object.fromEntries(Object.entries(actual.schemas[schema].rows).map(([name,row])=>[name,row.common]));
 assert.deepEqual(rows,expected.comparable[schema]);
 assert.equal(Object.keys(rows).length,21);
}
