// Full common correctness only. Never executes clock_inspection or records time.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
const expected=JSON.parse(fs.readFileSync(new URL('./common-expected.json',import.meta.url))).comparable;
const generated=(await import(pathToFileURL(process.argv[2]))).default;
const observed={},physical={};
const fields=['component','resource','extraPresent','extraPayload','current','previous','locals','attempts','prefix','pendingStructural','structuralApplied','deliveries','requirements','missing','outcome'];
for(const schema of ['A','B']){
 const records=JSON.parse(generated[schema+'_rows']());
 assert.deepEqual(records.map(row=>row.name),Object.keys(expected[schema]));
 physical[schema]=Object.fromEntries(records.map(row=>[row.name,row.value]));
 observed[schema]=Object.fromEntries(records.map(({name,value})=>[name,{...Object.fromEntries(fields.map(key=>[key,value[key]])),pending:value.pending===null?null:value.pending.value}]));
}
console.log(JSON.stringify({physical,common:observed}));
assert.deepEqual(observed,expected);
