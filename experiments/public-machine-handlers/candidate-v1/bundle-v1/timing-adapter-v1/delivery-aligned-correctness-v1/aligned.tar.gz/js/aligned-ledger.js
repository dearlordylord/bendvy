function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

(() => {
// IO
// ==

function io_now() {
  return BigInt(Math.floor(performance.now()));
}

io_eff("IO.now", io_now);

})();

for (const k of ["IO.print","IO.now"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return run_clo((_x_0) => {
  return $IO$bind$(($ledger$045driver$058run$1261$({$: "ledger-driver.Correctness"}, 1)), run_clo((_x_1) => {
  return $print_A$(_x_1);
}), _x_0);
});
}

function $IO$bind$(_m_0, _f_0, _k_0) {
  return run_tail(_m_0, run_clo((_x_0) => {
  return run_tail(_f_0(_x_0), _k_0);
}));
}

function $ledger$045driver$058run$1261$(_mode_0, _count_0) {
  return $ledger$045driver$058scenarios$1261$(_mode_0, _count_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047stateful$045driver$058scenarios$()), {$: "Nil"});
}

function $print_A$(_result_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($ledger$045driver$058run$1260$({$: "ledger-driver.Correctness"}, 1)), run_clo((_x_1) => {
  return $print_B$(($rendered$1261$(_result_0)), _x_1);
}), _x_0);
});
}

function $ledger$045driver$058scenarios$1261$(_mode_0, _count_0, _items_0, _completed_0) {
  if (_items_0.$ === "Nil") {
    return run_clo((_x_0) => {
  return $IO$pure$({$: "ledger-driver.Ledger", "scenarios": _completed_0}, _x_0);
});
  } else {
    const _descriptor_0 = _items_0["head"];
    const _remaining_0 = _items_0["tail"];
    return run_clo((_x_1) => {
  return $IO$bind$(($ledger$045driver$058scenario$1261$(_mode_0, _count_0, _descriptor_0)), run_clo((_x_2) => {
  return $ledger$045driver$058scenarios$1261$(_mode_0, _count_0, _remaining_0, ($List$append$(_completed_0, {$: "Con", "head": _x_2, "tail": {$: "Nil"}})));
}), _x_1);
});
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047stateful$045driver$058scenarios$() {
  return {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Scenario", "current": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot"}, "extra": true, "failure": 0, "operations": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Queue", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Play"}, "skip": false}, "checkpoint": {$: "Some", "value": "boot_Play_queued"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Marker"}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Read"}, "checkpoint": {$: "Some", "value": "boot_Play_applied"}}, "tail": {$: "Nil"}}}}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Scenario", "current": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot"}, "extra": true, "failure": 0, "operations": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Queue", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Pause"}, "skip": false}, "checkpoint": {$: "Some", "value": "boot_Pause_queued"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Marker"}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Read"}, "checkpoint": {$: "Some", "value": "boot_Pause_applied"}}, "tail": {$: "Nil"}}}}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Scenario", "current": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot"}, "extra": true, "failure": 0, "operations": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Queue", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Play"}, "skip": false}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Marker"}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Read"}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Marker"}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Read"}, "checkpoint": {$: "Some", "value": "self_queued_next"}}, "tail": {$: "Nil"}}}}}}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Scenario", "current": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot"}, "extra": true, "failure": 0, "operations": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Queue", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot"}, "skip": false}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Marker"}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Read"}, "checkpoint": {$: "Some", "value": "same_Boot_false"}}, "tail": {$: "Nil"}}}}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Scenario", "current": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot"}, "extra": true, "failure": 0, "operations": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Queue", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot"}, "skip": true}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Marker"}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Read"}, "checkpoint": {$: "Some", "value": "same_Boot_true"}}, "tail": {$: "Nil"}}}}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Scenario", "current": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Play"}, "extra": true, "failure": 0, "operations": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Queue", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Play"}, "skip": false}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Marker"}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Read"}, "checkpoint": {$: "Some", "value": "same_Play_false"}}, "tail": {$: "Nil"}}}}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Scenario", "current": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Play"}, "extra": true, "failure": 0, "operations": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Queue", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Play"}, "skip": true}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Marker"}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Read"}, "checkpoint": {$: "Some", "value": "same_Play_true"}}, "tail": {$: "Nil"}}}}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Scenario", "current": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot"}, "extra": true, "failure": 2, "operations": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Queue", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Play"}, "skip": false}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Marker"}, "checkpoint": {$: "Some", "value": "failed_exitBoot0"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Marker"}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Read"}, "checkpoint": {$: "Some", "value": "later_exitBoot0"}}, "tail": {$: "Nil"}}}}}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Scenario", "current": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot"}, "extra": true, "failure": 5, "operations": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Queue", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Play"}, "skip": false}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Marker"}, "checkpoint": {$: "Some", "value": "failed_exitBoot1"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Marker"}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Read"}, "checkpoint": {$: "Some", "value": "later_exitBoot1"}}, "tail": {$: "Nil"}}}}}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Scenario", "current": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot"}, "extra": true, "failure": 6, "operations": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Queue", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Play"}, "skip": false}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Marker"}, "checkpoint": {$: "Some", "value": "failed_transitionBootPlay"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Marker"}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Read"}, "checkpoint": {$: "Some", "value": "later_transitionBootPlay"}}, "tail": {$: "Nil"}}}}}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Scenario", "current": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot"}, "extra": true, "failure": 1, "operations": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Queue", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Play"}, "skip": false}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Marker"}, "checkpoint": {$: "Some", "value": "failed_enterPlay1"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Marker"}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Read"}, "checkpoint": {$: "Some", "value": "later_enterPlay1"}}, "tail": {$: "Nil"}}}}}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Scenario", "current": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot"}, "extra": true, "failure": 4, "operations": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Queue", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Play"}, "skip": false}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Marker"}, "checkpoint": {$: "Some", "value": "failed_enterPlay0"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Marker"}, "checkpoint": {$: "None"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Read"}, "checkpoint": {$: "Some", "value": "later_enterPlay0"}}, "tail": {$: "Nil"}}}}}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Scenario", "current": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot"}, "extra": false, "failure": 0, "operations": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Queue", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Play"}, "skip": false}, "checkpoint": {$: "Some", "value": "missing_queued"}}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Marker"}, "checkpoint": {$: "Some", "value": "inactive_missing"}}, "tail": {$: "Nil"}}}}, "tail": {$: "Nil"}}}}}}}}}}}}}};
}

function $ledger$045driver$058run$1260$(_mode_0, _count_0) {
  return $ledger$045driver$058scenarios$1260$(_mode_0, _count_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047stateful$045driver$058scenarios$()), {$: "Nil"});
}

function $print_B$(_text_0, _result_0) {
  const _x_0 = ($rendered$1260$(_result_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = (",\"B\":" + _x_1);
  const _x_3 = (_text_0 + _x_2);
  return (_x_4) => $IO$print$(("{\"A\":" + _x_3), _x_4);
}

function $rendered$1261$(_ledger_0) {
  const _items_0 = _ledger_0["scenarios"];
  return $List$show$1260$(($scenarios$1261$(_items_0)));
}

function $IO$pure$(_x_0, _k_0) {
  return run_tail(_k_0, _x_0);
}

function $ledger$045driver$058scenario$1261$(_mode_0, _count_0, _descriptor_0) {
  const _current_0 = _descriptor_0["current"];
  const _extra_0 = _descriptor_0["extra"];
  const _failure_0 = _descriptor_0["failure"];
  const _items_0 = _descriptor_0["operations"];
  return run_clo((_x_0) => {
  return $IO$bind$(($ledger$045driver$058now$(_mode_0)), run_clo((_x_1) => {
  return $ledger$045driver$058setup_returned$1261$(_mode_0, _items_0, _x_1, run_loop($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058setup$1261$(_count_0, _current_0, _extra_0, _failure_0)));
}), _x_0);
});
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $ledger$045driver$058scenarios$1260$(_mode_0, _count_0, _items_0, _completed_0) {
  if (_items_0.$ === "Nil") {
    return run_clo((_x_0) => {
  return $IO$pure$({$: "ledger-driver.Ledger", "scenarios": _completed_0}, _x_0);
});
  } else {
    const _descriptor_0 = _items_0["head"];
    const _remaining_0 = _items_0["tail"];
    return run_clo((_x_1) => {
  return $IO$bind$(($ledger$045driver$058scenario$1260$(_mode_0, _count_0, _descriptor_0)), run_clo((_x_2) => {
  return $ledger$045driver$058scenarios$1260$(_mode_0, _count_0, _remaining_0, ($List$append$(_completed_0, {$: "Con", "head": _x_2, "tail": {$: "Nil"}})));
}), _x_1);
});
  }
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $rendered$1260$(_ledger_0) {
  const _items_0 = _ledger_0["scenarios"];
  return $List$show$1260$(($scenarios$1260$(_items_0)));
}

function $List$show$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1260$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return ("[" + _x_1);
  }
}

function $scenarios$1261$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _result_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    return {$: "Con", "head": ($scenario$1261$(_result_0)), "tail": ($scenarios$1261$(_rest_0))};
  }
}

function $ledger$045driver$058now$(_mode_0) {
  if (_mode_0.$ === "ledger-driver.Correctness") {
    return run_clo((_x_0) => {
  return $IO$pure$(0, _x_0);
});
  } else {
    return (_x_1) => $IO$now$(_x_1);
  }
}

function $ledger$045driver$058setup_returned$1261$(_mode_0, _items_0, _started_0, _result_0) {
  if (_result_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/batch.Ready") {
    const _batch_0 = _result_0["batch"];
    return run_clo((_x_0) => {
  return $IO$bind$(($ledger$045driver$058now$(_mode_0)), run_clo((_x_1) => {
  return $ledger$045driver$058setup_stopped$1261$(_mode_0, _items_0, _batch_0, _started_0, _x_1);
}), _x_0);
});
  } else {
    const _batch_1 = _result_0["batch"];
    return run_clo((_x_2) => {
  return $IO$bind$(($ledger$045driver$058now$(_mode_0)), run_clo((_x_3) => {
  return run_clo((_x_4) => {
  return $IO$pure$({$: "ledger-driver.ConstructionRefused", "batch": _batch_1, "started": _started_0, "finished": _x_3}, _x_4);
});
}), _x_2);
});
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058setup$1261$(_count_0, _current_0, _extra_0, _failure_0) {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058setups$1261$(_count_0, ($$$$047stage$047src$047ecs$047world$058factory$()), {$: "Nil"}, _current_0, _extra_0, _failure_0);
}

function $ledger$045driver$058scenario$1260$(_mode_0, _count_0, _descriptor_0) {
  const _current_0 = _descriptor_0["current"];
  const _extra_0 = _descriptor_0["extra"];
  const _failure_0 = _descriptor_0["failure"];
  const _items_0 = _descriptor_0["operations"];
  return run_clo((_x_0) => {
  return $IO$bind$(($ledger$045driver$058now$(_mode_0)), run_clo((_x_1) => {
  return $ledger$045driver$058setup_returned$1260$(_mode_0, _items_0, _x_1, run_loop($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058setup$1260$(_count_0, _current_0, _extra_0, _failure_0)));
}), _x_0);
});
}

function $scenarios$1260$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _result_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    return {$: "Con", "head": ($scenario$1260$(_result_0)), "tail": ($scenarios$1260$(_rest_0))};
  }
}

function $List$show$go$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1260$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return (", " + _x_1);
  }
}

function $scenario$1261$(_result_0) {
  if (_result_0.$ === "ledger-driver.Completed") {
    const _rows_0 = _result_0["rows"];
    const _samples_0 = _result_0["samples"];
    const _captures_0 = _result_0["captures"];
    const _x_0 = ($List$show$1260$(_captures_0));
    const _x_1 = (_x_0 + "}");
    const _x_2 = ($List$show$1266$(_samples_0));
    const _x_3 = (",\"captures\":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($List$show$1260$(_rows_0));
    const _x_6 = (",\"sampleKinds\":" + _x_4);
    const _x_7 = (_x_5 + _x_6);
    return ("{\"rows\":" + _x_7);
  } else {
    return "{\"error\":\"ConstructionRefused\"}";
  }
}

function $IO$now$(_k_0) {
  return { $: "$FFI", run: $0eff["IO.now"].run, need: $0eff["IO.now"].need, args: [], kont: ((f) => (x) => (f(nat_host(x))))(_k_0) };
}
function $ledger$045driver$058setup_stopped$1261$(_mode_0, _items_0, _batch_0, _started_0, _finished_0) {
  return $ledger$045driver$058operations$1261$(_mode_0, _items_0, ($ledger$045driver$058capture$1261$(_batch_0, {$: "Nil"}, {$: "Con", "head": {$: "ledger-driver.SetupSample", "started": _started_0, "finished": _finished_0}, "tail": {$: "Nil"}}, {$: "Nil"}, "setup", {$: "None"})));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058setups$1261$(_remaining_0, _factory_0, _apps_0, _current_0, _extra_0, _failure_0) {
  if (_remaining_0 === 0) {
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/batch.Ready", "factory": _factory_0, "batch": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/batch.Batch", "applications": _apps_0}};
  } else {
    const _remaining_1 = (_remaining_0 - 1);
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058setup_next$1261$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047stepper$058configured$1260$(_current_0, _extra_0, _failure_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058create$1260$(_factory_0)))), _apps_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058setups$1261$(_remaining_1, _x_0, _x_1, _current_0, _extra_0, _failure_0);
});
}));
  }
}

function $$$$047stage$047src$047ecs$047world$058factory$() {
  return {$: "../stage/src/ecs/world.Factory", "nextNamespace": 1};
}

function $ledger$045driver$058setup_returned$1260$(_mode_0, _items_0, _started_0, _result_0) {
  if (_result_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/batch.Ready") {
    const _batch_0 = _result_0["batch"];
    return run_clo((_x_0) => {
  return $IO$bind$(($ledger$045driver$058now$(_mode_0)), run_clo((_x_1) => {
  return $ledger$045driver$058setup_stopped$1260$(_mode_0, _items_0, _batch_0, _started_0, _x_1);
}), _x_0);
});
  } else {
    const _batch_1 = _result_0["batch"];
    return run_clo((_x_2) => {
  return $IO$bind$(($ledger$045driver$058now$(_mode_0)), run_clo((_x_3) => {
  return run_clo((_x_4) => {
  return $IO$pure$({$: "ledger-driver.ConstructionRefused", "batch": _batch_1, "started": _started_0, "finished": _x_3}, _x_4);
});
}), _x_2);
});
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058setup$1260$(_count_0, _current_0, _extra_0, _failure_0) {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058setups$1260$(_count_0, ($$$$047stage$047src$047ecs$047world$058factory$()), {$: "Nil"}, _current_0, _extra_0, _failure_0);
}

function $scenario$1260$(_result_0) {
  if (_result_0.$ === "ledger-driver.Completed") {
    const _rows_0 = _result_0["rows"];
    const _samples_0 = _result_0["samples"];
    const _captures_0 = _result_0["captures"];
    const _x_0 = ($List$show$1260$(_captures_0));
    const _x_1 = (_x_0 + "}");
    const _x_2 = ($List$show$1266$(_samples_0));
    const _x_3 = (",\"captures\":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($List$show$1260$(_rows_0));
    const _x_6 = (",\"sampleKinds\":" + _x_4);
    const _x_7 = (_x_5 + _x_6);
    return ("{\"rows\":" + _x_7);
  } else {
    return "{\"error\":\"ConstructionRefused\"}";
  }
}

function $List$show$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($sample$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $ledger$045driver$058operations$1261$(_mode_0, _items_0, _result_0) {
  if (_items_0.$ === "Nil") {
    if (_result_0.$ === "ledger-driver.ConstructionRefused") {
      const _batch_0 = _result_0["batch"];
      const _started_0 = _result_0["started"];
      const _finished_0 = _result_0["finished"];
      return run_clo((_x_0) => {
  return $IO$pure$({$: "ledger-driver.ConstructionRefused", "batch": _batch_0, "started": _started_0, "finished": _finished_0}, _x_0);
});
    } else {
      return run_clo((_x_1) => {
  return $IO$pure$(_result_0, _x_1);
});
    }
  } else {
    const _t_0 = _items_0["head"];
    const _step_0 = _t_0["step"];
    const _name_0 = _t_0["checkpoint"];
    const _remaining_0 = _items_0["tail"];
    if (_result_0.$ === "ledger-driver.ConstructionRefused") {
      const _batch_1 = _result_0["batch"];
      const _started_1 = _result_0["started"];
      const _finished_1 = _result_0["finished"];
      return run_clo((_x_2) => {
  return $IO$pure$({$: "ledger-driver.ConstructionRefused", "batch": _batch_1, "started": _started_1, "finished": _finished_1}, _x_2);
});
    } else {
      const _batch_2 = _result_0["batch"];
      const _rows_0 = _result_0["rows"];
      const _samples_0 = _result_0["samples"];
      const _captures_0 = _result_0["captures"];
      return run_clo((_x_3) => {
  return $IO$bind$(($ledger$045driver$058timed$1261$(_mode_0, _batch_2, {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": _step_0, "checkpoint": _name_0})), run_clo((_x_4) => {
  return $ledger$045driver$058operation_returned$1261$(_x_4, _rows_0, _samples_0, _captures_0, {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": _step_0, "checkpoint": _name_0}, run_clo((_x_5) => {
  return $ledger$045driver$058operations$1261$(_mode_0, _remaining_0, _x_5);
}));
}), _x_3);
});
    }
  }
}

function $ledger$045driver$058capture$1261$(_batch_0, _rows_0, _samples_0, _captures_0, _label_0, _name_0) {
  return $ledger$045driver$058captured$1261$(_label_0, _name_0, _rows_0, _samples_0, _captures_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058observe$1261$(_batch_0)));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058setup_next$1261$(_result_0, _apps_0, _next_0) {
  if (_result_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Ready") {
    const _factory_0 = _result_0["factory"];
    const _app_0 = _result_0["application"];
    return run_tail(_next_0(_factory_0), ($List$append$(_apps_0, {$: "Con", "head": _app_0, "tail": {$: "Nil"}})));
  } else {
    const _factory_1 = _result_0["factory"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/batch.Refused", "factory": _factory_1, "batch": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/batch.Batch", "applications": _apps_0}};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047stepper$058configured$1260$(_current_0, _extra_0, _failure_0, _result_0) {
  if (_result_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Constructed") {
    const _factory_0 = _result_0["factory"];
    const _app_0 = _result_0["application"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Ready", "factory": _factory_0, "application": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058failing$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058supply$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058initialized$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058install_reader$1260$(_app_0)), _current_0)), _extra_0)), _failure_0))};
  } else {
    const _factory_1 = _result_0["factory"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Refused", "factory": _factory_1};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058create$1260$(_factory_0) {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058created$1260$(($$$$047stage$047src$047ecs$047world$058create$1260$(_factory_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058initial_resources$1260$()))));
}

function $ledger$045driver$058setup_stopped$1260$(_mode_0, _items_0, _batch_0, _started_0, _finished_0) {
  return $ledger$045driver$058operations$1260$(_mode_0, _items_0, ($ledger$045driver$058capture$1260$(_batch_0, {$: "Nil"}, {$: "Con", "head": {$: "ledger-driver.SetupSample", "started": _started_0, "finished": _finished_0}, "tail": {$: "Nil"}}, {$: "Nil"}, "setup", {$: "None"})));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058setups$1260$(_remaining_0, _factory_0, _apps_0, _current_0, _extra_0, _failure_0) {
  if (_remaining_0 === 0) {
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/batch.Ready", "factory": _factory_0, "batch": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/batch.Batch", "applications": _apps_0}};
  } else {
    const _remaining_1 = (_remaining_0 - 1);
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058setup_next$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047stepper$058configured$1261$(_current_0, _extra_0, _failure_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058create$1261$(_factory_0)))), _apps_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058setups$1260$(_remaining_1, _x_0, _x_1, _current_0, _extra_0, _failure_0);
});
}));
  }
}

function $sample$(_sample_0) {
  if (_sample_0.$ === "ledger-driver.SetupSample") {
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058quote$("setup");
  } else {
    const _t_0 = _sample_0["operation"];
    const _step_0 = _t_0["step"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058quote$(($kind$(_step_0)));
  }
}

function $List$show$go$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($sample$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $ledger$045driver$058timed$1261$(_mode_0, _batch_0, _step_0) {
  if (_mode_0.$ === "ledger-driver.Correctness") {
    const _operation_0 = _step_0["step"];
    return run_clo((_x_0) => {
  return $IO$pure$({$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/clock-step.Timed", "batch": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058step$1261$(_batch_0, _operation_0)), "started": 0, "finished": 0}, _x_0);
});
  } else {
    const _operation_1 = _step_0["step"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047clock$045step$058step$1261$(_batch_0, _operation_1);
  }
}

function $ledger$045driver$058operation_returned$1261$(_result_0, _rows_0, _samples_0, _captures_0, _operation_0, _next_0) {
  const _batch_0 = _result_0["batch"];
  const _started_0 = _result_0["started"];
  const _finished_0 = _result_0["finished"];
  const _step_0 = _operation_0["step"];
  const _name_0 = _operation_0["checkpoint"];
  return run_tail(_next_0, ($ledger$045driver$058capture$1261$(_batch_0, _rows_0, ($List$append$(_samples_0, {$: "Con", "head": {$: "ledger-driver.StepSample", "operation": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": _step_0, "checkpoint": _name_0}, "started": _started_0, "finished": _finished_0}, "tail": {$: "Nil"}})), _captures_0, ($ledger$045driver$058kind$(_step_0)), _name_0)));
}

function $ledger$045driver$058captured$1261$(_label_0, _name_0, _rows_0, _samples_0, _captures_0, _result_0) {
  const _batch_0 = _result_0["batch"];
  const _values_0 = _result_0["rows"];
  const _x_0 = ($List$show$1260$(_values_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($ledger$045driver$058maybe_name$(_name_0));
  const _x_3 = (",\"values\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058quote$(_label_0));
  const _x_6 = (",\"checkpoint\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  return {$: "ledger-driver.Completed", "batch": _batch_0, "rows": ($ledger$045driver$058checkpoint_rows$(_name_0, _rows_0, _values_0)), "samples": _samples_0, "captures": ($List$append$(_captures_0, {$: "Con", "head": ("{\"kind\":" + _x_7), "tail": {$: "Nil"}}))};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058observe$1261$(_batch_0) {
  const _apps_0 = _batch_0["applications"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058captured$1261$(_apps_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058failing$1260$(_app_0, _id_0) {
  if (_app_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application") {
    const _world_0 = _app_0["world"];
    const _bundle_0 = _app_0["bundle"];
    const _reader_0 = _app_0["readerRegistry"];
    const _status_0 = _app_0["status"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058set_failure$1260$(_world_0, _id_0)), "bundle": _bundle_0, "readerRegistry": _reader_0, "status": _status_0};
  } else {
    return _app_0;
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058supply$1260$(_app_0, _present_0) {
  if (_app_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application") {
    const _world_0 = _app_0["world"];
    const _bundle_0 = _app_0["bundle"];
    const _reader_0 = _app_0["readerRegistry"];
    const _status_0 = _app_0["status"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058set_extra$1260$(_world_0, _present_0)), "bundle": _bundle_0, "readerRegistry": _reader_0, "status": _status_0};
  } else {
    return _app_0;
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058initialized$1260$(_app_0, _state_0) {
  if (_app_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application") {
    const _world_0 = _app_0["world"];
    const _bundle_0 = _app_0["bundle"];
    const _reader_0 = _app_0["readerRegistry"];
    const _status_0 = _app_0["status"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058initial_state$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058take$1260$(_world_0)), _state_0)), "bundle": _bundle_0, "readerRegistry": _reader_0, "status": _status_0};
  } else {
    return _app_0;
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058install_reader$1260$(_app_0) {
  if (_app_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application") {
    const _world_0 = _app_0["world"];
    const _bundle_0 = _app_0["bundle"];
    const _status_0 = _app_0["status"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058reader_registered$1260$(_bundle_0, _status_0, ($$$$047stage$047src$047ecs$047system$058register$1260$(_world_0, "reader", {$: "Con", "head": "machine:read", "tail": {$: "Nil"}})));
  } else {
    return _app_0;
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058created$1260$(_result_0) {
  if (_result_0.$ === "../stage/src/ecs/world.CreateRejected") {
    const _factory_0 = _result_0["factory"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.ConstructionRefused", "factory": _factory_0};
  } else {
    const _factory_1 = _result_0["factory"];
    const _world_0 = _result_0["world"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058reserved$1260$(_factory_1, ($$$$047stage$047src$047ecs$047world$058reserve_id$1260$(_world_0)));
  }
}

function $$$$047stage$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047stage$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058initial_resources$1260$() {
  return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": array_node([0], [19]), "slot": {$: "../stage/src/ecs/machine.Present", "current": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot"}, "pending": {$: "../stage/src/ecs/machine.NoPending"}, "previous": {$: "None"}, "changed": false}, "stream": ($$$$047stage$047src$047ecs$047machine$045stream$058empty$1260$()), "reader": {$: "None"}, "locals": {$: "Nil"}, "tick": 0, "prefix": {$: "Nil"}, "delivered": {$: "Nil"}, "structuralApplied": 0, "extra": {$: "Some", "value": array_node([5], [29])}, "failureId": 0, "attemptLog": {$: "Nil"}};
}

function $ledger$045driver$058operations$1260$(_mode_0, _items_0, _result_0) {
  if (_items_0.$ === "Nil") {
    if (_result_0.$ === "ledger-driver.ConstructionRefused") {
      const _batch_0 = _result_0["batch"];
      const _started_0 = _result_0["started"];
      const _finished_0 = _result_0["finished"];
      return run_clo((_x_0) => {
  return $IO$pure$({$: "ledger-driver.ConstructionRefused", "batch": _batch_0, "started": _started_0, "finished": _finished_0}, _x_0);
});
    } else {
      return run_clo((_x_1) => {
  return $IO$pure$(_result_0, _x_1);
});
    }
  } else {
    const _t_0 = _items_0["head"];
    const _step_0 = _t_0["step"];
    const _name_0 = _t_0["checkpoint"];
    const _remaining_0 = _items_0["tail"];
    if (_result_0.$ === "ledger-driver.ConstructionRefused") {
      const _batch_1 = _result_0["batch"];
      const _started_1 = _result_0["started"];
      const _finished_1 = _result_0["finished"];
      return run_clo((_x_2) => {
  return $IO$pure$({$: "ledger-driver.ConstructionRefused", "batch": _batch_1, "started": _started_1, "finished": _finished_1}, _x_2);
});
    } else {
      const _batch_2 = _result_0["batch"];
      const _rows_0 = _result_0["rows"];
      const _samples_0 = _result_0["samples"];
      const _captures_0 = _result_0["captures"];
      return run_clo((_x_3) => {
  return $IO$bind$(($ledger$045driver$058timed$1260$(_mode_0, _batch_2, {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": _step_0, "checkpoint": _name_0})), run_clo((_x_4) => {
  return $ledger$045driver$058operation_returned$1260$(_x_4, _rows_0, _samples_0, _captures_0, {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": _step_0, "checkpoint": _name_0}, run_clo((_x_5) => {
  return $ledger$045driver$058operations$1260$(_mode_0, _remaining_0, _x_5);
}));
}), _x_3);
});
    }
  }
}

function $ledger$045driver$058capture$1260$(_batch_0, _rows_0, _samples_0, _captures_0, _label_0, _name_0) {
  return $ledger$045driver$058captured$1260$(_label_0, _name_0, _rows_0, _samples_0, _captures_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058observe$1260$(_batch_0)));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058setup_next$1260$(_result_0, _apps_0, _next_0) {
  if (_result_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Ready") {
    const _factory_0 = _result_0["factory"];
    const _app_0 = _result_0["application"];
    return run_tail(_next_0(_factory_0), ($List$append$(_apps_0, {$: "Con", "head": _app_0, "tail": {$: "Nil"}})));
  } else {
    const _factory_1 = _result_0["factory"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/batch.Refused", "factory": _factory_1, "batch": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/batch.Batch", "applications": _apps_0}};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047stepper$058configured$1261$(_current_0, _extra_0, _failure_0, _result_0) {
  if (_result_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Constructed") {
    const _factory_0 = _result_0["factory"];
    const _app_0 = _result_0["application"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Ready", "factory": _factory_0, "application": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058failing$1261$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058supply$1261$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058initialized$1261$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058install_reader$1261$(_app_0)), _current_0)), _extra_0)), _failure_0))};
  } else {
    const _factory_1 = _result_0["factory"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Refused", "factory": _factory_1};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058create$1261$(_factory_0) {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058created$1261$(($$$$047stage$047src$047ecs$047world$058create$1261$(_factory_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058initial_resources$1261$()))));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058quote$(_text_0) {
  const _x_0 = (_text_0 + "\"");
  return ("\"" + _x_0);
}

function $kind$(_step_0) {
  if (_step_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Queue") {
    return "queue";
  } else if (_step_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Marker") {
    return "marker";
  } else {
    return "read";
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058step$1261$(_batch_0, _operation_0) {
  const _apps_0 = _batch_0["applications"];
  return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/batch.Batch", "applications": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058stepped$1261$(_apps_0, _operation_0))};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047clock$045step$058step$1261$(_batch_0, _operation_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $IO$now$(_x_1), run_clo((_x_2) => {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047clock$045step$058completed$1261$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058step$1261$(_batch_0, _operation_0)), _x_2);
}), _x_0);
});
}

function $ledger$045driver$058kind$(_step_0) {
  if (_step_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Queue") {
    return "queue";
  } else if (_step_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Marker") {
    return "marker";
  } else {
    return "read";
  }
}

function $ledger$045driver$058checkpoint_rows$(_name_0, _rows_0, _values_0) {
  if (_name_0.$ === "None") {
    return _rows_0;
  } else {
    const _name_1 = _name_0["value"];
    return $List$append$(_rows_0, {$: "Con", "head": ($ledger$045driver$058row$(_name_1, _values_0)), "tail": {$: "Nil"}});
  }
}

function $ledger$045driver$058maybe_name$(_name_0) {
  if (_name_0.$ === "None") {
    return "null";
  } else {
    const _name_1 = _name_0["value"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058quote$(_name_1);
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058captured$1261$(_apps_0) {
  if (_apps_0.$ === "Nil") {
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/batch.Observed", "batch": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/batch.Batch", "applications": {$: "Nil"}}, "rows": {$: "Nil"}};
  } else {
    const _app_0 = _apps_0["head"];
    const _tail_0 = _apps_0["tail"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058captured_head$1261$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047stepper$058observe$1260$(_app_0)), ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058captured$1261$(_tail_0)));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058set_failure$1260$(_world_0, _failure_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failure_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058set_extra$1260$(_world_0, _present_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058extra_selected$(_present_0, _extra_0)), "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058initial_state$1260$(_pair_0, _state_0) {
  const _world_0 = _pair_0["fst"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put$1260$(_world_0, {$: "../stage/src/ecs/machine.Present", "current": _state_0, "pending": {$: "../stage/src/ecs/machine.NoPending"}, "previous": {$: "None"}, "changed": false});
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058take$1260$(_world_0) {
  return $$$$047stage$047src$047ecs$047machine$045world$058take$1260$(_world_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058reader_registered$1260$(_bundle_0, _status_0, _result_0) {
  if (_result_0.$ === "../stage/src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": _world_0, "bundle": _bundle_0, "readerRegistry": {$: "None"}, "status": _status_0};
  } else {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["registry"];
    const _namespace_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _name_0 = _t_0["name"];
    const _access_0 = _t_0["access"];
    const _cursor_0 = _t_0["cursor"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058reader_installed$1260$(_world_1, _namespace_0, _id_0)), "bundle": _bundle_0, "readerRegistry": {$: "Some", "value": {$: "../stage/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}}, "status": _status_0};
  }
}

function $$$$047stage$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0) {
  return $$$$047stage$047src$047ecs$047system$058register_namespace$1260$(($$$$047stage$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058reserved$1260$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../stage/src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058activated$1260$(_factory_0, ($$$$047stage$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)));
  } else {
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.ConstructionRefused", "factory": _factory_0};
  }
}

function $$$$047stage$047src$047ecs$047world$058reserve_id$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047stage$047src$047ecs$047world$058reserve_available$1260$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047stage$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../stage/src/ecs/world.CreateRejected", "factory": {$: "../stage/src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../stage/src/ecs/world.Created", "factory": {$: "../stage/src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058empty_store$1260$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $$$$047stage$047src$047ecs$047machine$045stream$058empty$1260$() {
  return {$: "../stage/src/ecs/machine-stream.Stream", "batches": {$: "Nil"}, "positions": {$: "Nil"}, "droppedThrough": 0, "frameStart": 0};
}

function $ledger$045driver$058timed$1260$(_mode_0, _batch_0, _step_0) {
  if (_mode_0.$ === "ledger-driver.Correctness") {
    const _operation_0 = _step_0["step"];
    return run_clo((_x_0) => {
  return $IO$pure$({$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/clock-step.Timed", "batch": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058step$1260$(_batch_0, _operation_0)), "started": 0, "finished": 0}, _x_0);
});
  } else {
    const _operation_1 = _step_0["step"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047clock$045step$058step$1260$(_batch_0, _operation_1);
  }
}

function $ledger$045driver$058operation_returned$1260$(_result_0, _rows_0, _samples_0, _captures_0, _operation_0, _next_0) {
  const _batch_0 = _result_0["batch"];
  const _started_0 = _result_0["started"];
  const _finished_0 = _result_0["finished"];
  const _step_0 = _operation_0["step"];
  const _name_0 = _operation_0["checkpoint"];
  return run_tail(_next_0, ($ledger$045driver$058capture$1260$(_batch_0, _rows_0, ($List$append$(_samples_0, {$: "Con", "head": {$: "ledger-driver.StepSample", "operation": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stateful-driver.Operation", "step": _step_0, "checkpoint": _name_0}, "started": _started_0, "finished": _finished_0}, "tail": {$: "Nil"}})), _captures_0, ($ledger$045driver$058kind$(_step_0)), _name_0)));
}

function $ledger$045driver$058captured$1260$(_label_0, _name_0, _rows_0, _samples_0, _captures_0, _result_0) {
  const _batch_0 = _result_0["batch"];
  const _values_0 = _result_0["rows"];
  const _x_0 = ($List$show$1260$(_values_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($ledger$045driver$058maybe_name$(_name_0));
  const _x_3 = (",\"values\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058quote$(_label_0));
  const _x_6 = (",\"checkpoint\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  return {$: "ledger-driver.Completed", "batch": _batch_0, "rows": ($ledger$045driver$058checkpoint_rows$(_name_0, _rows_0, _values_0)), "samples": _samples_0, "captures": ($List$append$(_captures_0, {$: "Con", "head": ("{\"kind\":" + _x_7), "tail": {$: "Nil"}}))};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058observe$1260$(_batch_0) {
  const _apps_0 = _batch_0["applications"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058captured$1260$(_apps_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058failing$1261$(_app_0, _id_0) {
  if (_app_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application") {
    const _world_0 = _app_0["world"];
    const _bundle_0 = _app_0["bundle"];
    const _reader_0 = _app_0["readerRegistry"];
    const _status_0 = _app_0["status"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058set_failure$1261$(_world_0, _id_0)), "bundle": _bundle_0, "readerRegistry": _reader_0, "status": _status_0};
  } else {
    return _app_0;
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058supply$1261$(_app_0, _present_0) {
  if (_app_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application") {
    const _world_0 = _app_0["world"];
    const _bundle_0 = _app_0["bundle"];
    const _reader_0 = _app_0["readerRegistry"];
    const _status_0 = _app_0["status"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058set_extra$1261$(_world_0, _present_0)), "bundle": _bundle_0, "readerRegistry": _reader_0, "status": _status_0};
  } else {
    return _app_0;
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058initialized$1261$(_app_0, _state_0) {
  if (_app_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application") {
    const _world_0 = _app_0["world"];
    const _bundle_0 = _app_0["bundle"];
    const _reader_0 = _app_0["readerRegistry"];
    const _status_0 = _app_0["status"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058initial_state$1261$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058take$1261$(_world_0)), _state_0)), "bundle": _bundle_0, "readerRegistry": _reader_0, "status": _status_0};
  } else {
    return _app_0;
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058install_reader$1261$(_app_0) {
  if (_app_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application") {
    const _world_0 = _app_0["world"];
    const _bundle_0 = _app_0["bundle"];
    const _status_0 = _app_0["status"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058reader_registered$1261$(_bundle_0, _status_0, ($$$$047stage$047src$047ecs$047system$058register$1262$(_world_0, "reader", {$: "Con", "head": "machine:read", "tail": {$: "Nil"}})));
  } else {
    return _app_0;
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058created$1261$(_result_0) {
  if (_result_0.$ === "../stage/src/ecs/world.CreateRejected") {
    const _factory_0 = _result_0["factory"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.ConstructionRefused", "factory": _factory_0};
  } else {
    const _factory_1 = _result_0["factory"];
    const _world_0 = _result_0["world"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058reserved$1261$(_factory_1, ($$$$047stage$047src$047ecs$047world$058reserve_id$1261$(_world_0)));
  }
}

function $$$$047stage$047src$047ecs$047world$058create$1261$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047stage$047src$047ecs$047world$058create_checked$1261$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058initial_resources$1261$() {
  return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": array_node([0], [19]), "slot": {$: "../stage/src/ecs/machine.Present", "current": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot"}, "pending": {$: "../stage/src/ecs/machine.NoPending"}, "previous": {$: "None"}, "changed": false}, "stream": ($$$$047stage$047src$047ecs$047machine$045stream$058empty$1260$()), "reader": {$: "None"}, "locals": {$: "Nil"}, "tick": 0, "prefix": {$: "Nil"}, "delivered": {$: "Nil"}, "structuralApplied": 0, "extra": {$: "Some", "value": array_node([5], [29])}, "failureId": 0, "attemptLog": {$: "Nil"}};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058stepped$1261$(_apps_0, _operation_0) {
  if (_apps_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _app_0 = _apps_0["head"];
    const _tail_0 = _apps_0["tail"];
    return {$: "Con", "head": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047stepper$058step$1260$(_app_0, _operation_0)), "tail": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058stepped$1261$(_tail_0, _operation_0))};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047clock$045step$058completed$1261$(_batch_0, _started_0) {
  const _apps_0 = _batch_0["applications"];
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $IO$now$(_x_1), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $IO$pure$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047clock$045step$058stopped$1261$(_apps_0, _started_0, _x_2)), _x_3);
});
}), _x_0);
});
}

function $ledger$045driver$058row$(_name_0, _values_0) {
  const _x_0 = ($List$show$1260$(_values_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058quote$(_name_0));
  const _x_3 = (",\"values\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  return ("{\"name\":" + _x_4);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058captured_head$1261$(_observed_0, _tail_0) {
  const _app_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _t_0 = _tail_0["batch"];
  const _apps_0 = _t_0["applications"];
  const _rows_0 = _tail_0["rows"];
  return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/batch.Observed", "batch": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/batch.Batch", "applications": {$: "Con", "head": _app_0, "tail": _apps_0}}, "rows": {$: "Con", "head": _text_0, "tail": _rows_0}};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047stepper$058observe$1260$(_app_0) {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058observe$1260$(_app_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058extra_selected$(_present_0, _owner_0) {
  if (_present_0) {
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058extra_supplied$(_owner_0);
  } else {
    return {$: "None"};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put$1260$(_world_0, _slot_0) {
  return $$$$047stage$047src$047ecs$047machine$045world$058put$1260$(_world_0, _slot_0);
}

function $$$$047stage$047src$047ecs$047machine$045world$058take$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047stage$047src$047ecs$047machine$045world$058take_join$1260$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058take_resource$1260$(_resources_0)), _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058reader_installed$1260$(_world_0, _namespace_0, _id_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": {$: "Some", "value": {$: "../stage/src/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": _id_0}}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047src$047ecs$047system$058register_namespace$1260$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047stage$047src$047ecs$047system$058register_join$1260$(($$$$047stage$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047stage$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058activated$1260$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../stage/src/ecs/world.Accepted") {
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Constructed", "factory": _factory_0, "application": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058install_namespace$1260$(($$$$047stage$047src$047ecs$047world$058namespace$1260$(_world_0))))};
  } else {
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.ConstructionRefused", "factory": _factory_0};
  }
}

function $$$$047stage$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0) {
  return $$$$047stage$047src$047ecs$047world$058set_live_join$1260$(true, _handle_0, ($$$$047stage$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047stage$047src$047ecs$047world$058reserve_available$1260$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../stage/src/ecs/world.ReservationRejected", "error": {$: "../stage/src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047stage$047src$047ecs$047world$058reserve_finish$1260$({$: "../stage/src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047stage$047src$047ecs$047world$058reserve_finish$1260$(($$$$047stage$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058empty_store$1260$(__0) {
  return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Store", "column": {$: "../stage/src/ecs/column.Column", "values": [{$: "Some", "value": array_node([0], [7])}], "stamps": {$: "Nil"}}};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058step$1260$(_batch_0, _operation_0) {
  const _apps_0 = _batch_0["applications"];
  return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/batch.Batch", "applications": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058stepped$1260$(_apps_0, _operation_0))};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047clock$045step$058step$1260$(_batch_0, _operation_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $IO$now$(_x_1), run_clo((_x_2) => {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047clock$045step$058completed$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058step$1260$(_batch_0, _operation_0)), _x_2);
}), _x_0);
});
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058captured$1260$(_apps_0) {
  if (_apps_0.$ === "Nil") {
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/batch.Observed", "batch": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/batch.Batch", "applications": {$: "Nil"}}, "rows": {$: "Nil"}};
  } else {
    const _app_0 = _apps_0["head"];
    const _tail_0 = _apps_0["tail"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058captured_head$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047stepper$058observe$1261$(_app_0)), ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058captured$1260$(_tail_0)));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058set_failure$1261$(_world_0, _failure_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failure_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058set_extra$1261$(_world_0, _present_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058extra_selected$(_present_0, _extra_0)), "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058initial_state$1261$(_pair_0, _state_0) {
  const _world_0 = _pair_0["fst"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put$1261$(_world_0, {$: "../stage/src/ecs/machine.Present", "current": _state_0, "pending": {$: "../stage/src/ecs/machine.NoPending"}, "previous": {$: "None"}, "changed": false});
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058take$1261$(_world_0) {
  return $$$$047stage$047src$047ecs$047machine$045world$058take$1261$(_world_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058reader_registered$1261$(_bundle_0, _status_0, _result_0) {
  if (_result_0.$ === "../stage/src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": _world_0, "bundle": _bundle_0, "readerRegistry": {$: "None"}, "status": _status_0};
  } else {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["registry"];
    const _namespace_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _name_0 = _t_0["name"];
    const _access_0 = _t_0["access"];
    const _cursor_0 = _t_0["cursor"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058reader_installed$1261$(_world_1, _namespace_0, _id_0)), "bundle": _bundle_0, "readerRegistry": {$: "Some", "value": {$: "../stage/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}}, "status": _status_0};
  }
}

function $$$$047stage$047src$047ecs$047system$058register$1262$(_world_0, _name_0, _access_0) {
  return $$$$047stage$047src$047ecs$047system$058register_namespace$1262$(($$$$047stage$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058reserved$1261$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../stage/src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058activated$1261$(_factory_0, ($$$$047stage$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0)));
  } else {
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.ConstructionRefused", "factory": _factory_0};
  }
}

function $$$$047stage$047src$047ecs$047world$058reserve_id$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047stage$047src$047ecs$047world$058reserve_available$1261$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047stage$047src$047ecs$047world$058create_checked$1261$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../stage/src/ecs/world.CreateRejected", "factory": {$: "../stage/src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../stage/src/ecs/world.Created", "factory": {$: "../stage/src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058empty_store$1261$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047stepper$058step$1260$(_app_0, _operation_0) {
  if (_operation_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Queue") {
    const _value_0 = _operation_0["value"];
    const _skip_0 = _operation_0["skip"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058queue$1260$(_app_0, _value_0, _skip_0);
  } else if (_operation_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Marker") {
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058marker$1260$(_app_0);
  } else {
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058read$1260$(_app_0);
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047clock$045step$058stopped$1261$(_apps_0, _started_0, _finished_0) {
  return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/clock-step.Timed", "batch": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/batch.Batch", "applications": _apps_0}, "started": _started_0, "finished": _finished_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058observe$1260$(_app_0) {
  if (_app_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application") {
    const _owner_0 = _app_0["world"];
    const _t_0 = _app_0["bundle"];
    const _namespace_0 = _t_0["namespace"];
    const _items_0 = _t_0["entries"];
    const _readerRegistry_0 = _app_0["readerRegistry"];
    const _status_0 = _app_0["status"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058observed$1260$(_namespace_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058world$1260$(_owner_0, _status_0)), ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058entries$1260$(_items_0)), _readerRegistry_0, _status_0);
  } else {
    return {$: "Tuple", "fst": _app_0, "snd": "{\"error\":\"OwnerRemainder\"}"};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058extra_supplied$(_owner_0) {
  if (_owner_0.$ === "Some") {
    const _owner_1 = _owner_0["value"];
    return {$: "Some", "value": _owner_1};
  } else {
    return {$: "Some", "value": array_node([5], [29])};
  }
}

function $$$$047stage$047src$047ecs$047machine$045world$058put$1260$(_world_0, _slot_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put_resource$1260$(_resources_0, _slot_0)), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047src$047ecs$047machine$045world$058take_join$1260$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _split_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _resources_0 = _split_0["fst"];
  const _slot_0 = _split_0["snd"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _slot_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058take_resource$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _slot_0 = _resources_0["slot"];
  const _stream_0 = _resources_0["stream"];
  const _reader_0 = _resources_0["reader"];
  const _locals_0 = _resources_0["locals"];
  const _tick_0 = _resources_0["tick"];
  const _prefix_0 = _resources_0["prefix"];
  const _delivered_0 = _resources_0["delivered"];
  const _applied_0 = _resources_0["structuralApplied"];
  const _extra_0 = _resources_0["extra"];
  const _failureId_0 = _resources_0["failureId"];
  const _attemptLog_0 = _resources_0["attemptLog"];
  return {$: "Tuple", "fst": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "snd": _slot_0};
}

function $$$$047stage$047src$047ecs$047system$058register_join$1260$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047stage$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047stage$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047stage$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058install_namespace$1260$(_pair_0) {
  const _world_0 = _pair_0["fst"];
  const _namespace_0 = _pair_0["snd"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058assembled$1260$(_namespace_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058install$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058specs$1260$()), _world_0)));
}

function $$$$047stage$047src$047ecs$047world$058set_live_join$1260$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047stage$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047stage$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047stage$047src$047ecs$047world$058reserve_finish$1260$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../stage/src/ecs/world.Reserved", "handle": {$: "../stage/src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047stage$047src$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "../stage/src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058stepped$1260$(_apps_0, _operation_0) {
  if (_apps_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _app_0 = _apps_0["head"];
    const _tail_0 = _apps_0["tail"];
    return {$: "Con", "head": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047stepper$058step$1261$(_app_0, _operation_0)), "tail": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058stepped$1260$(_tail_0, _operation_0))};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047clock$045step$058completed$1260$(_batch_0, _started_0) {
  const _apps_0 = _batch_0["applications"];
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $IO$now$(_x_1), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $IO$pure$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047clock$045step$058stopped$1260$(_apps_0, _started_0, _x_2)), _x_3);
});
}), _x_0);
});
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047batch$058captured_head$1260$(_observed_0, _tail_0) {
  const _app_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _t_0 = _tail_0["batch"];
  const _apps_0 = _t_0["applications"];
  const _rows_0 = _tail_0["rows"];
  return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/batch.Observed", "batch": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/batch.Batch", "applications": {$: "Con", "head": _app_0, "tail": _apps_0}}, "rows": {$: "Con", "head": _text_0, "tail": _rows_0}};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047stepper$058observe$1261$(_app_0) {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058observe$1261$(_app_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put$1261$(_world_0, _slot_0) {
  return $$$$047stage$047src$047ecs$047machine$045world$058put$1261$(_world_0, _slot_0);
}

function $$$$047stage$047src$047ecs$047machine$045world$058take$1261$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047stage$047src$047ecs$047machine$045world$058take_join$1261$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058take_resource$1261$(_resources_0)), _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058reader_installed$1261$(_world_0, _namespace_0, _id_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": {$: "Some", "value": {$: "../stage/src/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": _id_0}}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047src$047ecs$047system$058register_namespace$1262$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047stage$047src$047ecs$047system$058register_join$1262$(($$$$047stage$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047stage$047src$047ecs$047world$058namespace$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058activated$1261$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../stage/src/ecs/world.Accepted") {
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Constructed", "factory": _factory_0, "application": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058install_namespace$1261$(($$$$047stage$047src$047ecs$047world$058namespace$1261$(_world_0))))};
  } else {
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.ConstructionRefused", "factory": _factory_0};
  }
}

function $$$$047stage$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0) {
  return $$$$047stage$047src$047ecs$047world$058set_live_join$1261$(true, _handle_0, ($$$$047stage$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047stage$047src$047ecs$047world$058reserve_available$1261$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../stage/src/ecs/world.ReservationRejected", "error": {$: "../stage/src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047stage$047src$047ecs$047world$058reserve_finish$1261$({$: "../stage/src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047stage$047src$047ecs$047world$058reserve_finish$1261$(($$$$047stage$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058empty_store$1261$(__0) {
  return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Store", "column": {$: "../stage/src/ecs/column.Column", "values": [{$: "Some", "value": array_node([0], [7])}], "stamps": {$: "Nil"}}};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058queue$1260$(_app_0, _value_0, _skip_0) {
  if (_app_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application") {
    const _world_0 = _app_0["world"];
    const _bundle_0 = _app_0["bundle"];
    const _reader_0 = _app_0["readerRegistry"];
    const _status_0 = _app_0["status"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058queued$1260$(_bundle_0, _reader_0, _status_0, _value_0, _skip_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058take$1260$(_world_0)));
  } else {
    return _app_0;
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058marker$1260$(_app_0) {
  if (_app_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application") {
    const _world_0 = _app_0["world"];
    const _bundle_0 = _app_0["bundle"];
    const _readerRegistry_0 = _app_0["readerRegistry"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058retained$1260$(_readerRegistry_0, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058run$1260$(_bundle_0, _world_0)));
  } else {
    return _app_0;
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058read$1260$(_app_0) {
  if (_app_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application") {
    const _world_0 = _app_0["world"];
    const _bundle_0 = _app_0["bundle"];
    const _t_0 = _app_0["readerRegistry"];
    if (_t_0.$ === "Some") {
      const _registry_0 = _t_0["value"];
      const _status_0 = _app_0["status"];
      return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058read_result$1260$(_bundle_0, _status_0, ($$$$047stage$047src$047ecs$047system$058run_tracked$1261$(_registry_0, _world_0, {$: "Unit"})));
    } else {
      const _status_1 = _app_0["status"];
      return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": _world_0, "bundle": _bundle_0, "readerRegistry": _t_0, "status": _status_1};
    }
  } else {
    return _app_0;
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058observed$1260$(_namespace_0, _world_0, _entryValues_0, _readerRegistry_0, _status_0) {
  const _world_1 = _world_0["fst"];
  const _text_0 = _world_0["snd"];
  const _entries_0 = _entryValues_0["entries"];
  const _texts_0 = _entryValues_0["texts"];
  const _ids_0 = _entryValues_0["ids"];
  const _names_0 = _entryValues_0["names"];
  const _namespaces_0 = _entryValues_0["namespaces"];
  const _cursors_0 = _entryValues_0["cursors"];
  const _requirements_0 = _entryValues_0["requirements"];
  if (_readerRegistry_0.$ === "Some") {
    const _t_0 = _readerRegistry_0["value"];
    const _ns_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _name_0 = _t_0["name"];
    const _access_0 = _t_0["access"];
    const _cursor_0 = _t_0["cursor"];
    const _x_0 = ($List$show$1263$(($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058collect$1260$(_requirements_0, {$: "Nil"}))));
    const _x_1 = (_x_0 + "}");
    const _x_2 = ($List$show$1260$(_texts_0));
    const _x_3 = (",\"requirements\":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($U32$show$(_cursor_0));
    const _x_6 = (",\"entries\":" + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($List$show$1261$(_cursors_0));
    const _x_9 = (",\"readerCursor\":" + _x_7);
    const _x_10 = (_x_8 + _x_9);
    const _x_11 = ($List$show$1261$(_namespaces_0));
    const _x_12 = (",\"registryCursors\":" + _x_10);
    const _x_13 = (_x_11 + _x_12);
    const _x_14 = ($List$show$1262$(_names_0));
    const _x_15 = (",\"registryNamespaces\":" + _x_13);
    const _x_16 = (_x_14 + _x_15);
    const _x_17 = ($List$show$1261$(_ids_0));
    const _x_18 = (",\"registryNames\":" + _x_16);
    const _x_19 = (_x_17 + _x_18);
    const _x_20 = (",\"registryIds\":" + _x_19);
    const _x_21 = (_text_0 + _x_20);
    return {$: "Tuple", "fst": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": _world_1, "bundle": {$: "../stage/src/ecs/machine-handler-bundle.Bundle", "namespace": _namespace_0, "entries": _entries_0}, "readerRegistry": {$: "Some", "value": {$: "../stage/src/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}}, "status": _status_0}, "snd": ("{" + _x_21)};
  } else {
    return {$: "Tuple", "fst": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": _world_1, "bundle": {$: "../stage/src/ecs/machine-handler-bundle.Bundle", "namespace": _namespace_0, "entries": _entries_0}, "readerRegistry": {$: "None"}, "status": _status_0}, "snd": "{\"error\":\"MissingRegistry\"}"};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058world$1260$(_owner_0, _status_0) {
  const _ns_0 = _owner_0["namespace"];
  const _next_0 = _owner_0["nextId"];
  const _high_0 = _owner_0["highWater"];
  const _live_0 = _owner_0["live"];
  const _capacity_0 = _owner_0["capacity"];
  const _depth_0 = _owner_0["depth"];
  const _t_0 = _owner_0["store"];
  const _column_0 = _t_0["column"];
  const _resource_0 = _owner_0["resource"];
  const _events_0 = _owner_0["events"];
  const _pending_0 = _owner_0["pending"];
  const _registrations_0 = _owner_0["registrations"];
  const _nextSystem_0 = _owner_0["nextSystemId"];
  const _clock_0 = _owner_0["clock"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058world_join$1260$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, ($$$$047stage$047src$047ecs$047column$058view$1260$(_column_0, 1)), ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058resources$1260$(_resource_0, _status_0)), _events_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058commands$1260$(_pending_0)), _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058entries$1260$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/observe.EntriesObserved", "entries": {$: "Nil"}, "texts": {$: "Nil"}, "ids": {$: "Nil"}, "names": {$: "Nil"}, "namespaces": {$: "Nil"}, "cursors": {$: "Nil"}, "requirements": {$: "Nil"}};
  } else {
    const _t_0 = _items_0["head"];
    const _selected_0 = _t_0["selector"];
    const _needs_0 = _t_0["requirements"];
    const _t_1 = _t_0["entry"];
    const _ordinal_0 = _t_1["ordinal"];
    const _t_2 = _t_1["registry"];
    const _ns_0 = _t_2["namespace"];
    const _id_0 = _t_2["id"];
    const _name_0 = _t_2["name"];
    const _access_0 = _t_2["access"];
    const _cursor_0 = _t_2["cursor"];
    const _rest_0 = _items_0["tail"];
    const _x_0 = ($List$show$1263$(_needs_0));
    const _x_1 = (_x_0 + "}");
    const _x_2 = ($U32$show$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058amount$(_ordinal_0))));
    const _x_3 = (",\"requirements\":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058selector$1260$(_selected_0));
    const _x_6 = (",\"delta\":" + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058quote$(_name_0));
    const _x_9 = ("," + _x_7);
    const _x_10 = (_x_8 + _x_9);
    const _x_11 = ($U32$show$(_id_0));
    const _x_12 = (",\"name\":" + _x_10);
    const _x_13 = (_x_11 + _x_12);
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058entry_join$1260$({$: "../stage/src/ecs/machine-handler-bundle.Scheduled", "selector": _selected_0, "requirements": _needs_0, "entry": {$: "../stage/src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": {$: "../stage/src/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}}}, ("{\"id\":" + _x_13), _id_0, _name_0, _ns_0, _cursor_0, _needs_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058entries$1260$(_rest_0)));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put_resource$1260$(_resources_0, _slot_0) {
  const _owned_0 = _resources_0["owned"];
  const _stream_0 = _resources_0["stream"];
  const _reader_0 = _resources_0["reader"];
  const _locals_0 = _resources_0["locals"];
  const _tick_0 = _resources_0["tick"];
  const _prefix_0 = _resources_0["prefix"];
  const _delivered_0 = _resources_0["delivered"];
  const _applied_0 = _resources_0["structuralApplied"];
  const _extra_0 = _resources_0["extra"];
  const _failureId_0 = _resources_0["failureId"];
  const _attemptLog_0 = _resources_0["attemptLog"];
  return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0};
}

function $$$$047stage$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../stage/src/ecs/world.RegistrationRejected") {
    return {$: "../stage/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../stage/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../stage/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047stage$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../stage/src/ecs/world.RegistrationRejected", "error": {$: "../stage/src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../stage/src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../stage/src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058assembled$1260$(_namespace_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _tree_0 = _result_0["tree"];
  return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": _world_0, "bundle": ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058bundle$1260$(_namespace_0, _tree_0)), "readerRegistry": {$: "None"}, "status": {$: "None"}};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058install$1260$(_spec_0, _world_0) {
  if (_spec_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.NoSpecs") {
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Installed", "world": _world_0, "tree": {$: "../stage/src/ecs/machine-handler-bundle.Empty"}};
  } else if (_spec_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.OneSpec") {
    const _selector_0 = _spec_0["selector"];
    const _needs_0 = _spec_0["needs"];
    const _name_0 = _spec_0["name"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058installed_one$1260$(_selector_0, _needs_0, ($$$$047stage$047src$047ecs$047system$058register$1261$(_world_0, _name_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058access_for$(_name_0)))));
  } else {
    const _left_0 = _spec_0["left"];
    const _right_0 = _spec_0["right"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058installed_left$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058install$1260$(_left_0, _world_0)), run_clo((_x_0) => {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058install$1260$(_right_0, _x_0);
}));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058specs$1260$() {
  return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.MoreSpecs", "left": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.OneSpec", "selector": {$: "../stage/src/ecs/machine-handler-bundle.EnterTo", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Play"}}, "needs": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement"}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement"}, "tail": {$: "Nil"}}}, "name": "enterPlay1"}, "right": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.MoreSpecs", "left": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.MoreSpecs", "left": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.OneSpec", "selector": {$: "../stage/src/ecs/machine-handler-bundle.ExitFrom", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot"}}, "needs": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement"}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement"}, "tail": {$: "Nil"}}}, "name": "exitBoot0"}, "right": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.MoreSpecs", "left": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.OneSpec", "selector": {$: "../stage/src/ecs/machine-handler-bundle.TransitionPair", "from": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot"}, "to": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Pause"}}, "needs": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement"}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement"}, "tail": {$: "Nil"}}}, "name": "transitionBootPause"}, "right": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.OneSpec", "selector": {$: "../stage/src/ecs/machine-handler-bundle.EnterTo", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Play"}}, "needs": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement"}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement"}, "tail": {$: "Nil"}}}, "name": "enterPlay0"}}}, "right": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.MoreSpecs", "left": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.OneSpec", "selector": {$: "../stage/src/ecs/machine-handler-bundle.ExitFrom", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot"}}, "needs": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement"}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement"}, "tail": {$: "Nil"}}}, "name": "exitBoot1"}, "right": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.MoreSpecs", "left": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.OneSpec", "selector": {$: "../stage/src/ecs/machine-handler-bundle.TransitionPair", "from": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot"}, "to": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Play"}}, "needs": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement"}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement"}, "tail": {$: "Nil"}}}, "name": "transitionBootPlay"}, "right": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.MoreSpecs", "left": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.OneSpec", "selector": {$: "../stage/src/ecs/machine-handler-bundle.EnterTo", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Pause"}}, "needs": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement"}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement"}, "tail": {$: "Nil"}}}, "name": "enterPause"}, "right": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.OneSpec", "selector": {$: "../stage/src/ecs/machine-handler-bundle.ExitFrom", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Pause"}}, "needs": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement"}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.ExtraRequirement"}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement"}, "tail": {$: "Nil"}}}}, "name": "inactiveExitPause"}}}}}};
}

function $$$$047stage$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../stage/src/ecs/world.Rejected", "error": {$: "../stage/src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../stage/src/ecs/world.Accepted"}};
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047stepper$058step$1261$(_app_0, _operation_0) {
  if (_operation_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Queue") {
    const _value_0 = _operation_0["value"];
    const _skip_0 = _operation_0["skip"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058queue$1261$(_app_0, _value_0, _skip_0);
  } else if (_operation_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/stepper.Marker") {
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058marker$1261$(_app_0);
  } else {
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058read$1261$(_app_0);
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047clock$045step$058stopped$1260$(_apps_0, _started_0, _finished_0) {
  return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/clock-step.Timed", "batch": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/batch.Batch", "applications": _apps_0}, "started": _started_0, "finished": _finished_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058observe$1261$(_app_0) {
  if (_app_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application") {
    const _owner_0 = _app_0["world"];
    const _t_0 = _app_0["bundle"];
    const _namespace_0 = _t_0["namespace"];
    const _items_0 = _t_0["entries"];
    const _readerRegistry_0 = _app_0["readerRegistry"];
    const _status_0 = _app_0["status"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058observed$1261$(_namespace_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058world$1261$(_owner_0, _status_0)), ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058entries$1261$(_items_0)), _readerRegistry_0, _status_0);
  } else {
    return {$: "Tuple", "fst": _app_0, "snd": "{\"error\":\"OwnerRemainder\"}"};
  }
}

function $$$$047stage$047src$047ecs$047machine$045world$058put$1261$(_world_0, _slot_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put_resource$1261$(_resources_0, _slot_0)), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047src$047ecs$047machine$045world$058take_join$1261$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _split_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _resources_0 = _split_0["fst"];
  const _slot_0 = _split_0["snd"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _slot_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058take_resource$1261$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _slot_0 = _resources_0["slot"];
  const _stream_0 = _resources_0["stream"];
  const _reader_0 = _resources_0["reader"];
  const _locals_0 = _resources_0["locals"];
  const _tick_0 = _resources_0["tick"];
  const _prefix_0 = _resources_0["prefix"];
  const _delivered_0 = _resources_0["delivered"];
  const _applied_0 = _resources_0["structuralApplied"];
  const _extra_0 = _resources_0["extra"];
  const _failureId_0 = _resources_0["failureId"];
  const _attemptLog_0 = _resources_0["attemptLog"];
  return {$: "Tuple", "fst": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "snd": _slot_0};
}

function $$$$047stage$047src$047ecs$047system$058register_join$1262$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047stage$047src$047ecs$047system$058register_meta$1262$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047stage$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047stage$047src$047ecs$047world$058register_checked$1261$((_nextSystemId_0 < 4294967295), {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058install_namespace$1261$(_pair_0) {
  const _world_0 = _pair_0["fst"];
  const _namespace_0 = _pair_0["snd"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058assembled$1261$(_namespace_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058install$1261$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058specs$1261$()), _world_0)));
}

function $$$$047stage$047src$047ecs$047world$058set_live_join$1261$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047stage$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047stage$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047stage$047src$047ecs$047world$058reserve_finish$1261$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../stage/src/ecs/world.Reserved", "handle": {$: "../stage/src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058queued$1260$(_bundle_0, _reader_0, _status_0, _value_0, _skip_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put$1260$(_world_0, ($$$$047stage$047src$047ecs$047machine$058queue$1260$(_slot_0, _value_0, _skip_0)))), "bundle": _bundle_0, "readerRegistry": _reader_0, "status": _status_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058retained$1260$(_readerRegistry_0, _result_0) {
  if (_result_0.$ === "../stage/src/ecs/machine-handler-bundle.Returned") {
    const _bundle_0 = _result_0["bundle"];
    const _world_0 = _result_0["world"];
    const _status_0 = _result_0["status"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": _world_0, "bundle": _bundle_0, "readerRegistry": _readerRegistry_0, "status": {$: "Some", "value": _status_0}};
  } else {
    const _namespace_0 = _result_0["namespace"];
    const _recovery_0 = _result_0["recovery"];
    const _world_1 = _result_0["world"];
    const _status_1 = _result_0["status"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.ApplicationRemainder", "namespace": _namespace_0, "recovery": _recovery_0, "world": _world_1, "readerRegistry": _readerRegistry_0, "status": {$: "Some", "value": _status_1}};
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058run$1260$(_bundle_0, _world_0) {
  const _namespace_0 = _bundle_0["namespace"];
  const _entries_0 = _bundle_0["entries"];
  return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058namespace_join$1260$(_namespace_0, _entries_0, ($$$$047stage$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058read_result$1260$(_bundle_0, _status_0, _result_0) {
  if (_result_0.$ === "../stage/src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058read_completed$1260$(_bundle_0, _status_0, _registry_0, _outcome_0);
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": _world_0, "bundle": _bundle_0, "readerRegistry": {$: "Some", "value": _registry_1}, "status": _status_0};
  }
}

function $$$$047stage$047src$047ecs$047system$058run_tracked$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047stage$047src$047ecs$047system$058tracked_result$1261$(($$$$047stage$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0)));
}

function $List$show$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058quote$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $List$show$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058requirement$1260$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058collect$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _prior_0 = $1;
      if (_items_0.$ === "Nil") {
        return _prior_0;
      } else {
        const _head_0 = _items_0["head"];
        const _tail_0 = _items_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058collected$1260$(($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058contains$1260$(_prior_0, _head_0)), _prior_0, _head_0));
        continue;
      }
    }
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058world_join$1260$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _column_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _column_1 = _column_0["fst"];
  const _t_0 = _column_0["snd"];
  if (_t_0.$ === "Some") {
    const _cells_0 = _t_0["value"];
    const _owner_0 = _resource_0["fst"];
    const _text_0 = _resource_0["snd"];
    const _pending_1 = _pending_0["fst"];
    const _count_0 = _pending_0["snd"];
    const _x_0 = ($Nat$show$(_count_0));
    const _x_1 = ($U32$show$(_clock_0));
    const _x_2 = (",\"pendingStructural\":" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = (",\"clock\":" + _x_3);
    const _x_5 = (_text_0 + _x_4);
    const _x_6 = ("," + _x_5);
    const _x_7 = (_cells_0 + _x_6);
    const _x_8 = ($U32$show$(_ns_0));
    const _x_9 = (",\"entity\":1,\"component\":" + _x_7);
    const _x_10 = (_x_8 + _x_9);
    return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Store", "column": _column_1}, "resource": _owner_0, "events": _events_0, "pending": _pending_1, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ("\"namespace\":" + _x_10)};
  } else {
    const _owner_1 = _resource_0["fst"];
    const _text_1 = _resource_0["snd"];
    const _pending_2 = _pending_0["fst"];
    const _count_1 = _pending_0["snd"];
    const _x_11 = ($Nat$show$(_count_1));
    const _x_12 = ($U32$show$(_clock_0));
    const _x_13 = (",\"pendingStructural\":" + _x_11);
    const _x_14 = (_x_12 + _x_13);
    const _x_15 = (",\"clock\":" + _x_14);
    const _x_16 = (_text_1 + _x_15);
    const _x_17 = ($U32$show$(_ns_0));
    const _x_18 = (",\"entity\":1,\"component\":null," + _x_16);
    const _x_19 = (_x_17 + _x_18);
    return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Store", "column": _column_1}, "resource": _owner_1, "events": _events_0, "pending": _pending_2, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ("\"namespace\":" + _x_19)};
  }
}

function $$$$047stage$047src$047ecs$047column$058view$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../stage/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047stage$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../stage/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, ($$$$047stage$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../stage/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, ($$$$047stage$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, ($$$$047stage$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058resources$1260$(_owner_0, _runStatus_0) {
  const _owned_0 = _owner_0["owned"];
  const _slotValue_0 = _owner_0["slot"];
  const _stream_0 = _owner_0["stream"];
  const _readerOwner_0 = _owner_0["reader"];
  const _localOwners_0 = _owner_0["locals"];
  const _tick_0 = _owner_0["tick"];
  const _prefix_0 = _owner_0["prefix"];
  const _delivered_0 = _owner_0["delivered"];
  const _applied_0 = _owner_0["structuralApplied"];
  const _extra_0 = _owner_0["extra"];
  const _failureId_0 = _owner_0["failureId"];
  const _attemptLog_0 = _owner_0["attemptLog"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058resources_from_stream$1260$({$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": [0], "slot": _slotValue_0, "stream": _stream_0, "reader": {$: "None"}, "locals": {$: "Nil"}, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": {$: "None"}, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, _stream_0, _owned_0, _extra_0, _localOwners_0, _readerOwner_0, _runStatus_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058commands$1260$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _head_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058commands_join$1260$(_head_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058commands$1260$(_rest_0)));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058entry_join$1260$(_head_0, _text_0, _id_0, _name_0, _ns_0, _cursor_0, _needs_0, _tail_0) {
  const _entries_0 = _tail_0["entries"];
  const _texts_0 = _tail_0["texts"];
  const _ids_0 = _tail_0["ids"];
  const _names_0 = _tail_0["names"];
  const _namespaces_0 = _tail_0["namespaces"];
  const _cursors_0 = _tail_0["cursors"];
  const _requirements_0 = _tail_0["requirements"];
  return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/observe.EntriesObserved", "entries": {$: "Con", "head": _head_0, "tail": _entries_0}, "texts": {$: "Con", "head": _text_0, "tail": _texts_0}, "ids": {$: "Con", "head": _id_0, "tail": _ids_0}, "names": {$: "Con", "head": _name_0, "tail": _names_0}, "namespaces": {$: "Con", "head": _ns_0, "tail": _namespaces_0}, "cursors": {$: "Con", "head": _cursor_0, "tail": _cursors_0}, "requirements": ($List$append$(_needs_0, _requirements_0))};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058selector$1260$(_value_0) {
  if (_value_0.$ === "../stage/src/ecs/machine-handler-bundle.ExitFrom") {
    const _old_0 = _value_0["value"];
    const _x_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058state$(_old_0));
    const _x_1 = (_x_0 + ",\"to\":null");
    return ("\"phase\":\"exit\",\"from\":" + _x_1);
  } else if (_value_0.$ === "../stage/src/ecs/machine-handler-bundle.TransitionPair") {
    const _old_1 = _value_0["from"];
    const _new_0 = _value_0["to"];
    const _x_2 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058state$(_new_0));
    const _x_3 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058state$(_old_1));
    const _x_4 = (",\"to\":" + _x_2);
    const _x_5 = (_x_3 + _x_4);
    return ("\"phase\":\"transition\",\"from\":" + _x_5);
  } else {
    const _new_1 = _value_0["value"];
    const _x_6 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058state$(_new_1));
    return ("\"phase\":\"enter\",\"from\":null,\"to\":" + _x_6);
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058amount$(_id_0) {
  return TAB_0[Math.min(_id_0, 9)];
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058bundle$1260$(_namespace_0, _tree_0) {
  return {$: "../stage/src/ecs/machine-handler-bundle.Bundle", "namespace": _namespace_0, "entries": ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058flattened$1260$(_tree_0))};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058installed_one$1260$(_selector_0, _needs_0, _observed_0) {
  if (_observed_0.$ === "../stage/src/ecs/system.RegistrationFailed") {
    const _world_0 = _observed_0["world"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Installed", "world": _world_0, "tree": {$: "../stage/src/ecs/machine-handler-bundle.Empty"}};
  } else {
    const _world_1 = _observed_0["world"];
    const _t_0 = _observed_0["registry"];
    const _namespace_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _name_0 = _t_0["name"];
    const _access_0 = _t_0["access"];
    const _cursor_0 = _t_0["cursor"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Installed", "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058install_local$1260$(_world_1, _id_0)), "tree": {$: "../stage/src/ecs/machine-handler-bundle.Single", "scheduled": {$: "../stage/src/ecs/machine-handler-bundle.Scheduled", "selector": _selector_0, "requirements": _needs_0, "entry": {$: "../stage/src/ecs/machine-handlers.Entry", "ordinal": _id_0, "registry": {$: "../stage/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}}}}};
  }
}

function $$$$047stage$047src$047ecs$047system$058register$1261$(_world_0, _name_0, _access_0) {
  return $$$$047stage$047src$047ecs$047system$058register_namespace$1261$(($$$$047stage$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058access_for$(_name_0) {
  if (_name_0 !== "") {
    const _t_0 = (_name_0.codePointAt(0) > 0xFFFF ? _name_0.slice(0, 2) : _name_0[0]);
    const _t_1 = _t_0.codePointAt(0);
    if (_t_1 == 105) {
      const _t_2 = (_name_0.codePointAt(0) > 0xFFFF ? _name_0.slice(2) : _name_0.slice(1));
      if (_t_2 !== "") {
        const _t_3 = (_t_2.codePointAt(0) > 0xFFFF ? _t_2.slice(0, 2) : _t_2[0]);
        const _t_4 = _t_3.codePointAt(0);
        if (_t_4 == 110) {
          const _t_5 = (_t_2.codePointAt(0) > 0xFFFF ? _t_2.slice(2) : _t_2.slice(1));
          if (_t_5 !== "") {
            const _t_6 = (_t_5.codePointAt(0) > 0xFFFF ? _t_5.slice(0, 2) : _t_5[0]);
            const _t_7 = _t_6.codePointAt(0);
            if (_t_7 == 97) {
              const _t_8 = (_t_5.codePointAt(0) > 0xFFFF ? _t_5.slice(2) : _t_5.slice(1));
              if (_t_8 !== "") {
                const _t_9 = (_t_8.codePointAt(0) > 0xFFFF ? _t_8.slice(0, 2) : _t_8[0]);
                const _t_10 = _t_9.codePointAt(0);
                if (_t_10 == 99) {
                  const _t_11 = (_t_8.codePointAt(0) > 0xFFFF ? _t_8.slice(2) : _t_8.slice(1));
                  if (_t_11 !== "") {
                    const _t_12 = (_t_11.codePointAt(0) > 0xFFFF ? _t_11.slice(0, 2) : _t_11[0]);
                    const _t_13 = _t_12.codePointAt(0);
                    if (_t_13 == 116) {
                      const _t_14 = (_t_11.codePointAt(0) > 0xFFFF ? _t_11.slice(2) : _t_11.slice(1));
                      if (_t_14 !== "") {
                        const _t_15 = (_t_14.codePointAt(0) > 0xFFFF ? _t_14.slice(0, 2) : _t_14[0]);
                        const _t_16 = _t_15.codePointAt(0);
                        if (_t_16 == 105) {
                          const _t_17 = (_t_14.codePointAt(0) > 0xFFFF ? _t_14.slice(2) : _t_14.slice(1));
                          if (_t_17 !== "") {
                            const _t_18 = (_t_17.codePointAt(0) > 0xFFFF ? _t_17.slice(0, 2) : _t_17[0]);
                            const _t_19 = _t_18.codePointAt(0);
                            if (_t_19 == 118) {
                              const _t_20 = (_t_17.codePointAt(0) > 0xFFFF ? _t_17.slice(2) : _t_17.slice(1));
                              if (_t_20 !== "") {
                                const _t_21 = (_t_20.codePointAt(0) > 0xFFFF ? _t_20.slice(0, 2) : _t_20[0]);
                                const _t_22 = _t_21.codePointAt(0);
                                if (_t_22 == 101) {
                                  const _t_23 = (_t_20.codePointAt(0) > 0xFFFF ? _t_20.slice(2) : _t_20.slice(1));
                                  if (_t_23 !== "") {
                                    const _t_24 = (_t_23.codePointAt(0) > 0xFFFF ? _t_23.slice(0, 2) : _t_23[0]);
                                    const _t_25 = _t_24.codePointAt(0);
                                    if (_t_25 == 69) {
                                      const _t_26 = (_t_23.codePointAt(0) > 0xFFFF ? _t_23.slice(2) : _t_23.slice(1));
                                      if (_t_26 !== "") {
                                        const _t_27 = (_t_26.codePointAt(0) > 0xFFFF ? _t_26.slice(0, 2) : _t_26[0]);
                                        const _t_28 = _t_27.codePointAt(0);
                                        if (_t_28 == 120) {
                                          const _t_29 = (_t_26.codePointAt(0) > 0xFFFF ? _t_26.slice(2) : _t_26.slice(1));
                                          if (_t_29 !== "") {
                                            const _t_30 = (_t_29.codePointAt(0) > 0xFFFF ? _t_29.slice(0, 2) : _t_29[0]);
                                            const _t_31 = _t_30.codePointAt(0);
                                            if (_t_31 == 105) {
                                              const _t_32 = (_t_29.codePointAt(0) > 0xFFFF ? _t_29.slice(2) : _t_29.slice(1));
                                              if (_t_32 !== "") {
                                                const _t_33 = (_t_32.codePointAt(0) > 0xFFFF ? _t_32.slice(0, 2) : _t_32[0]);
                                                const _t_34 = _t_33.codePointAt(0);
                                                if (_t_34 == 116) {
                                                  const _t_35 = (_t_32.codePointAt(0) > 0xFFFF ? _t_32.slice(2) : _t_32.slice(1));
                                                  if (_t_35 !== "") {
                                                    const _t_36 = (_t_35.codePointAt(0) > 0xFFFF ? _t_35.slice(0, 2) : _t_35[0]);
                                                    const _t_37 = _t_36.codePointAt(0);
                                                    if (_t_37 == 80) {
                                                      const _t_38 = (_t_35.codePointAt(0) > 0xFFFF ? _t_35.slice(2) : _t_35.slice(1));
                                                      if (_t_38 !== "") {
                                                        const _t_39 = (_t_38.codePointAt(0) > 0xFFFF ? _t_38.slice(0, 2) : _t_38[0]);
                                                        const _t_40 = _t_39.codePointAt(0);
                                                        if (_t_40 == 97) {
                                                          const _t_41 = (_t_38.codePointAt(0) > 0xFFFF ? _t_38.slice(2) : _t_38.slice(1));
                                                          if (_t_41 !== "") {
                                                            const _t_42 = (_t_41.codePointAt(0) > 0xFFFF ? _t_41.slice(0, 2) : _t_41[0]);
                                                            const _t_43 = _t_42.codePointAt(0);
                                                            if (_t_43 == 117) {
                                                              const _t_44 = (_t_41.codePointAt(0) > 0xFFFF ? _t_41.slice(2) : _t_41.slice(1));
                                                              if (_t_44 !== "") {
                                                                const _t_45 = (_t_44.codePointAt(0) > 0xFFFF ? _t_44.slice(0, 2) : _t_44[0]);
                                                                const _t_46 = _t_45.codePointAt(0);
                                                                if (_t_46 == 115) {
                                                                  const _t_47 = (_t_44.codePointAt(0) > 0xFFFF ? _t_44.slice(2) : _t_44.slice(1));
                                                                  if (_t_47 !== "") {
                                                                    const _t_48 = (_t_47.codePointAt(0) > 0xFFFF ? _t_47.slice(0, 2) : _t_47[0]);
                                                                    const _t_49 = _t_48.codePointAt(0);
                                                                    if (_t_49 == 101) {
                                                                      const _t_50 = (_t_47.codePointAt(0) > 0xFFFF ? _t_47.slice(2) : _t_47.slice(1));
                                                                      if (_t_50 === "") {
                                                                        return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Con", "head": "extra:read", "tail": {$: "Nil"}}}}};
                                                                      } else {
                                                                        return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                                                                      }
                                                                    } else {
                                                                      return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                                                                    }
                                                                  } else {
                                                                    return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                                                                  }
                                                                } else {
                                                                  return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                                                                }
                                                              } else {
                                                                return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                                                              }
                                                            } else {
                                                              return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                                                            }
                                                          } else {
                                                            return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                                                          }
                                                        } else {
                                                          return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                                                        }
                                                      } else {
                                                        return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                                                      }
                                                    } else {
                                                      return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                                                    }
                                                  } else {
                                                    return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                                                  }
                                                } else {
                                                  return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                                                }
                                              } else {
                                                return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                                              }
                                            } else {
                                              return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                                            }
                                          } else {
                                            return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                                          }
                                        } else {
                                          return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                                        }
                                      } else {
                                        return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                                      }
                                    } else {
                                      return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                                    }
                                  } else {
                                    return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                                  }
                                } else {
                                  return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                                }
                              } else {
                                return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                              }
                            } else {
                              return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                            }
                          } else {
                            return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                          }
                        } else {
                          return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                        }
                      } else {
                        return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                      }
                    } else {
                      return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                    }
                  } else {
                    return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                  }
                } else {
                  return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
                }
              } else {
                return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
              }
            } else {
              return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
            }
          } else {
            return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
          }
        } else {
          return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
        }
      } else {
        return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
      }
    } else {
      return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
    }
  } else {
    return {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058installed_left$1260$(_left_0, _next_0) {
  const _world_0 = _left_0["world"];
  const _left_1 = _left_0["tree"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058installed_pair$1260$(_left_1, _next_0(_world_0));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058queue$1261$(_app_0, _value_0, _skip_0) {
  if (_app_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application") {
    const _world_0 = _app_0["world"];
    const _bundle_0 = _app_0["bundle"];
    const _reader_0 = _app_0["readerRegistry"];
    const _status_0 = _app_0["status"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058queued$1261$(_bundle_0, _reader_0, _status_0, _value_0, _skip_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058take$1261$(_world_0)));
  } else {
    return _app_0;
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058marker$1261$(_app_0) {
  if (_app_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application") {
    const _world_0 = _app_0["world"];
    const _bundle_0 = _app_0["bundle"];
    const _readerRegistry_0 = _app_0["readerRegistry"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058retained$1261$(_readerRegistry_0, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058run$1261$(_bundle_0, _world_0)));
  } else {
    return _app_0;
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058read$1261$(_app_0) {
  if (_app_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application") {
    const _world_0 = _app_0["world"];
    const _bundle_0 = _app_0["bundle"];
    const _t_0 = _app_0["readerRegistry"];
    if (_t_0.$ === "Some") {
      const _registry_0 = _t_0["value"];
      const _status_0 = _app_0["status"];
      return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058read_result$1261$(_bundle_0, _status_0, ($$$$047stage$047src$047ecs$047system$058run_tracked$1263$(_registry_0, _world_0, {$: "Unit"})));
    } else {
      const _status_1 = _app_0["status"];
      return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": _world_0, "bundle": _bundle_0, "readerRegistry": _t_0, "status": _status_1};
    }
  } else {
    return _app_0;
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058observed$1261$(_namespace_0, _world_0, _entryValues_0, _readerRegistry_0, _status_0) {
  const _world_1 = _world_0["fst"];
  const _text_0 = _world_0["snd"];
  const _entries_0 = _entryValues_0["entries"];
  const _texts_0 = _entryValues_0["texts"];
  const _ids_0 = _entryValues_0["ids"];
  const _names_0 = _entryValues_0["names"];
  const _namespaces_0 = _entryValues_0["namespaces"];
  const _cursors_0 = _entryValues_0["cursors"];
  const _requirements_0 = _entryValues_0["requirements"];
  if (_readerRegistry_0.$ === "Some") {
    const _t_0 = _readerRegistry_0["value"];
    const _ns_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _name_0 = _t_0["name"];
    const _access_0 = _t_0["access"];
    const _cursor_0 = _t_0["cursor"];
    const _x_0 = ($List$show$1265$(($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058collect$1261$(_requirements_0, {$: "Nil"}))));
    const _x_1 = (_x_0 + "}");
    const _x_2 = ($List$show$1260$(_texts_0));
    const _x_3 = (",\"requirements\":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($U32$show$(_cursor_0));
    const _x_6 = (",\"entries\":" + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($List$show$1261$(_cursors_0));
    const _x_9 = (",\"readerCursor\":" + _x_7);
    const _x_10 = (_x_8 + _x_9);
    const _x_11 = ($List$show$1261$(_namespaces_0));
    const _x_12 = (",\"registryCursors\":" + _x_10);
    const _x_13 = (_x_11 + _x_12);
    const _x_14 = ($List$show$1262$(_names_0));
    const _x_15 = (",\"registryNamespaces\":" + _x_13);
    const _x_16 = (_x_14 + _x_15);
    const _x_17 = ($List$show$1261$(_ids_0));
    const _x_18 = (",\"registryNames\":" + _x_16);
    const _x_19 = (_x_17 + _x_18);
    const _x_20 = (",\"registryIds\":" + _x_19);
    const _x_21 = (_text_0 + _x_20);
    return {$: "Tuple", "fst": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": _world_1, "bundle": {$: "../stage/src/ecs/machine-handler-bundle.Bundle", "namespace": _namespace_0, "entries": _entries_0}, "readerRegistry": {$: "Some", "value": {$: "../stage/src/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}}, "status": _status_0}, "snd": ("{" + _x_21)};
  } else {
    return {$: "Tuple", "fst": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": _world_1, "bundle": {$: "../stage/src/ecs/machine-handler-bundle.Bundle", "namespace": _namespace_0, "entries": _entries_0}, "readerRegistry": {$: "None"}, "status": _status_0}, "snd": "{\"error\":\"MissingRegistry\"}"};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058world$1261$(_owner_0, _status_0) {
  const _ns_0 = _owner_0["namespace"];
  const _next_0 = _owner_0["nextId"];
  const _high_0 = _owner_0["highWater"];
  const _live_0 = _owner_0["live"];
  const _capacity_0 = _owner_0["capacity"];
  const _depth_0 = _owner_0["depth"];
  const _t_0 = _owner_0["store"];
  const _column_0 = _t_0["column"];
  const _resource_0 = _owner_0["resource"];
  const _events_0 = _owner_0["events"];
  const _pending_0 = _owner_0["pending"];
  const _registrations_0 = _owner_0["registrations"];
  const _nextSystem_0 = _owner_0["nextSystemId"];
  const _clock_0 = _owner_0["clock"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058world_join$1261$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, ($$$$047stage$047src$047ecs$047column$058view$1261$(_column_0, 1)), ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058resources$1261$(_resource_0, _status_0)), _events_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058commands$1261$(_pending_0)), _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058entries$1261$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/observe.EntriesObserved", "entries": {$: "Nil"}, "texts": {$: "Nil"}, "ids": {$: "Nil"}, "names": {$: "Nil"}, "namespaces": {$: "Nil"}, "cursors": {$: "Nil"}, "requirements": {$: "Nil"}};
  } else {
    const _t_0 = _items_0["head"];
    const _selected_0 = _t_0["selector"];
    const _needs_0 = _t_0["requirements"];
    const _t_1 = _t_0["entry"];
    const _ordinal_0 = _t_1["ordinal"];
    const _t_2 = _t_1["registry"];
    const _ns_0 = _t_2["namespace"];
    const _id_0 = _t_2["id"];
    const _name_0 = _t_2["name"];
    const _access_0 = _t_2["access"];
    const _cursor_0 = _t_2["cursor"];
    const _rest_0 = _items_0["tail"];
    const _x_0 = ($List$show$1265$(_needs_0));
    const _x_1 = (_x_0 + "}");
    const _x_2 = ($U32$show$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058amount$(_ordinal_0))));
    const _x_3 = (",\"requirements\":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058selector$1261$(_selected_0));
    const _x_6 = (",\"delta\":" + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058quote$(_name_0));
    const _x_9 = ("," + _x_7);
    const _x_10 = (_x_8 + _x_9);
    const _x_11 = ($U32$show$(_id_0));
    const _x_12 = (",\"name\":" + _x_10);
    const _x_13 = (_x_11 + _x_12);
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058entry_join$1261$({$: "../stage/src/ecs/machine-handler-bundle.Scheduled", "selector": _selected_0, "requirements": _needs_0, "entry": {$: "../stage/src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": {$: "../stage/src/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}}}, ("{\"id\":" + _x_13), _id_0, _name_0, _ns_0, _cursor_0, _needs_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058entries$1261$(_rest_0)));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put_resource$1261$(_resources_0, _slot_0) {
  const _owned_0 = _resources_0["owned"];
  const _stream_0 = _resources_0["stream"];
  const _reader_0 = _resources_0["reader"];
  const _locals_0 = _resources_0["locals"];
  const _tick_0 = _resources_0["tick"];
  const _prefix_0 = _resources_0["prefix"];
  const _delivered_0 = _resources_0["delivered"];
  const _applied_0 = _resources_0["structuralApplied"];
  const _extra_0 = _resources_0["extra"];
  const _failureId_0 = _resources_0["failureId"];
  const _attemptLog_0 = _resources_0["attemptLog"];
  return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0};
}

function $$$$047stage$047src$047ecs$047system$058register_meta$1262$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../stage/src/ecs/world.RegistrationRejected") {
    return {$: "../stage/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../stage/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../stage/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047stage$047src$047ecs$047world$058register_checked$1261$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../stage/src/ecs/world.RegistrationRejected", "error": {$: "../stage/src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../stage/src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../stage/src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058assembled$1261$(_namespace_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _tree_0 = _result_0["tree"];
  return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": _world_0, "bundle": ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058bundle$1261$(_namespace_0, _tree_0)), "readerRegistry": {$: "None"}, "status": {$: "None"}};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058install$1261$(_spec_0, _world_0) {
  if (_spec_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.NoSpecs") {
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Installed", "world": _world_0, "tree": {$: "../stage/src/ecs/machine-handler-bundle.Empty"}};
  } else if (_spec_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.OneSpec") {
    const _selector_0 = _spec_0["selector"];
    const _needs_0 = _spec_0["needs"];
    const _name_0 = _spec_0["name"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058installed_one$1261$(_selector_0, _needs_0, ($$$$047stage$047src$047ecs$047system$058register$1263$(_world_0, _name_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058access_for$(_name_0)))));
  } else {
    const _left_0 = _spec_0["left"];
    const _right_0 = _spec_0["right"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058installed_left$1261$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058install$1261$(_left_0, _world_0)), run_clo((_x_0) => {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058install$1261$(_right_0, _x_0);
}));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058specs$1261$() {
  return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.MoreSpecs", "left": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.OneSpec", "selector": {$: "../stage/src/ecs/machine-handler-bundle.EnterTo", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Play"}}, "needs": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement"}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement"}, "tail": {$: "Nil"}}}, "name": "enterPlay1"}, "right": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.MoreSpecs", "left": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.MoreSpecs", "left": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.OneSpec", "selector": {$: "../stage/src/ecs/machine-handler-bundle.ExitFrom", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot"}}, "needs": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement"}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement"}, "tail": {$: "Nil"}}}, "name": "exitBoot0"}, "right": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.MoreSpecs", "left": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.OneSpec", "selector": {$: "../stage/src/ecs/machine-handler-bundle.TransitionPair", "from": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot"}, "to": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Pause"}}, "needs": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement"}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement"}, "tail": {$: "Nil"}}}, "name": "transitionBootPause"}, "right": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.OneSpec", "selector": {$: "../stage/src/ecs/machine-handler-bundle.EnterTo", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Play"}}, "needs": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement"}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement"}, "tail": {$: "Nil"}}}, "name": "enterPlay0"}}}, "right": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.MoreSpecs", "left": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.OneSpec", "selector": {$: "../stage/src/ecs/machine-handler-bundle.ExitFrom", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot"}}, "needs": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement"}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement"}, "tail": {$: "Nil"}}}, "name": "exitBoot1"}, "right": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.MoreSpecs", "left": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.OneSpec", "selector": {$: "../stage/src/ecs/machine-handler-bundle.TransitionPair", "from": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot"}, "to": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Play"}}, "needs": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement"}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement"}, "tail": {$: "Nil"}}}, "name": "transitionBootPlay"}, "right": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.MoreSpecs", "left": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.OneSpec", "selector": {$: "../stage/src/ecs/machine-handler-bundle.EnterTo", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Pause"}}, "needs": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement"}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement"}, "tail": {$: "Nil"}}}, "name": "enterPause"}, "right": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.OneSpec", "selector": {$: "../stage/src/ecs/machine-handler-bundle.ExitFrom", "value": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Pause"}}, "needs": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement"}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.ExtraRequirement"}, "tail": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement"}, "tail": {$: "Nil"}}}}, "name": "inactiveExitPause"}}}}}};
}

function $$$$047stage$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../stage/src/ecs/world.Rejected", "error": {$: "../stage/src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../stage/src/ecs/world.Accepted"}};
  }
}

function $$$$047stage$047src$047ecs$047machine$058queue$1260$(_slot_0, _value_0, _skipSame_0) {
  if (_slot_0.$ === "../stage/src/ecs/machine.Missing") {
    return {$: "../stage/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../stage/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../stage/src/ecs/machine.Queued", "value": _value_0, "skipSame": _skipSame_0}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058namespace_join$1260$(_namespace_0, _entries_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _actual_0 = _pair_0["snd"];
  return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../stage/src/ecs/machine-handler-bundle.Bundle", "namespace": _namespace_0, "entries": _entries_0}, _world_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058read_completed$1260$(_bundle_0, _status_0, _registry_0, _result_0) {
  if (_result_0.$ === "../stage/src/ecs/system.Succeeded") {
    const _world_0 = _result_0["world"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": _world_0, "bundle": _bundle_0, "readerRegistry": {$: "Some", "value": _registry_0}, "status": _status_0};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": _world_1, "bundle": _bundle_0, "readerRegistry": {$: "Some", "value": _registry_0}, "status": _status_0};
  }
}

function $$$$047stage$047src$047ecs$047system$058tracked_result$1261$(_result_0) {
  if (_result_0.$ === "../stage/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../stage/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047stage$047src$047ecs$047system$058tracked_outcome$1261$(_registry_1, _outcome_0);
  }
}

function $$$$047stage$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047stage$047src$047ecs$047system$058run_namespace$1261$(_registry_0, ($$$$047stage$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $List$show$go$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $List$show$go$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058quote$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058requirement$1260$(_value_0) {
  if (_value_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement") {
    return "\"machine\"";
  } else if (_value_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement") {
    return "\"owned\"";
  } else {
    return "\"extra\"";
  }
}

function $List$show$go$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058requirement$1260$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058collected$1260$(_seen_0, _prior_0, _value_0) {
  if (_seen_0) {
    return _prior_0;
  } else {
    return $List$append$(_prior_0, {$: "Con", "head": _value_0, "tail": {$: "Nil"}});
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058contains$1260$(_items_0, _value_0) {
  if (_items_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _items_0["head"];
    const _tail_0 = _items_0["tail"];
    const _x_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058requirement_same$1260$(_head_0, _value_0));
    const _x_1 = ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058contains$1260$(_tail_0, _value_0));
    return (_x_0 || _x_1);
  }
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $$$$047stage$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047stage$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047stage$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047stage$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047stage$047src$047ecs$047column$058unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../stage/src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047stage$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047stage$047src$047ecs$047column$058indexed_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../stage/src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047stage$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../stage/src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058resources_from_stream$1260$(_rest_0, _stream_0, _owned_0, _extra_0, _localOwners_0, _readerOwner_0, _runStatus_0) {
  const _positions_0 = _stream_0["positions"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058resources_join$1260$(_rest_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058array$(_owned_0)), ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058extra_view$(_extra_0)), ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058locals$(_localOwners_0)), ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058reader$1260$(_readerOwner_0, _positions_0)), _runStatus_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058commands_join$1260$(_head_0, _tail_0) {
  const _rest_0 = _tail_0["fst"];
  const _count_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_0, "tail": _rest_0}, "snd": nat_chk(_count_0 + 1)};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058state$(_value_0) {
  if (_value_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot") {
    return "\"Boot\"";
  } else if (_value_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Play") {
    return "\"Play\"";
  } else {
    return "\"Pause\"";
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058flattened$1260$(_tree_0) {
  if (_tree_0.$ === "../stage/src/ecs/machine-handler-bundle.Empty") {
    return {$: "Nil"};
  } else if (_tree_0.$ === "../stage/src/ecs/machine-handler-bundle.Single") {
    const _scheduled_0 = _tree_0["scheduled"];
    return {$: "Con", "head": _scheduled_0, "tail": {$: "Nil"}};
  } else {
    const _left_0 = _tree_0["left"];
    const _right_0 = _tree_0["right"];
    return $List$append$(($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058flattened$1260$(_left_0)), ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058flattened$1260$(_right_0)));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058install_local$1260$(_world_0, _id_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": ($List$append$(_locals_0, {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.LocalOwner", "namespace": _ns_0, "id": _id_0, "cell": {$: "../stage/src/ecs/local.Cell", "local": [0]}}, "tail": {$: "Nil"}})), "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047src$047ecs$047system$058register_namespace$1261$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047stage$047src$047ecs$047system$058register_join$1261$(($$$$047stage$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058installed_pair$1260$(_left_0, _right_0) {
  const _world_0 = _right_0["world"];
  const _right_1 = _right_0["tree"];
  return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Installed", "world": _world_0, "tree": {$: "../stage/src/ecs/machine-handler-bundle.Join", "left": _left_0, "right": _right_1}};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058queued$1261$(_bundle_0, _reader_0, _status_0, _value_0, _skip_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put$1261$(_world_0, ($$$$047stage$047src$047ecs$047machine$058queue$1261$(_slot_0, _value_0, _skip_0)))), "bundle": _bundle_0, "readerRegistry": _reader_0, "status": _status_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058retained$1261$(_readerRegistry_0, _result_0) {
  if (_result_0.$ === "../stage/src/ecs/machine-handler-bundle.Returned") {
    const _bundle_0 = _result_0["bundle"];
    const _world_0 = _result_0["world"];
    const _status_0 = _result_0["status"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": _world_0, "bundle": _bundle_0, "readerRegistry": _readerRegistry_0, "status": {$: "Some", "value": _status_0}};
  } else {
    const _namespace_0 = _result_0["namespace"];
    const _recovery_0 = _result_0["recovery"];
    const _world_1 = _result_0["world"];
    const _status_1 = _result_0["status"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.ApplicationRemainder", "namespace": _namespace_0, "recovery": _recovery_0, "world": _world_1, "readerRegistry": _readerRegistry_0, "status": {$: "Some", "value": _status_1}};
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058run$1261$(_bundle_0, _world_0) {
  const _namespace_0 = _bundle_0["namespace"];
  const _entries_0 = _bundle_0["entries"];
  return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058namespace_join$1261$(_namespace_0, _entries_0, ($$$$047stage$047src$047ecs$047world$058namespace$1261$(_world_0)));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058read_result$1261$(_bundle_0, _status_0, _result_0) {
  if (_result_0.$ === "../stage/src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058read_completed$1261$(_bundle_0, _status_0, _registry_0, _outcome_0);
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": _world_0, "bundle": _bundle_0, "readerRegistry": {$: "Some", "value": _registry_1}, "status": _status_0};
  }
}

function $$$$047stage$047src$047ecs$047system$058run_tracked$1263$(_registry_0, _world_0, _args_0) {
  return $$$$047stage$047src$047ecs$047system$058tracked_result$1263$(($$$$047stage$047src$047ecs$047system$058run$1263$(_registry_0, _world_0, _args_0)));
}

function $List$show$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058requirement$1261$(_h_0));
    const _x_1 = ($List$show$go$1265$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058collect$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _prior_0 = $1;
      if (_items_0.$ === "Nil") {
        return _prior_0;
      } else {
        const _head_0 = _items_0["head"];
        const _tail_0 = _items_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058collected$1261$(($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058contains$1261$(_prior_0, _head_0)), _prior_0, _head_0));
        continue;
      }
    }
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058world_join$1261$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _column_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _column_1 = _column_0["fst"];
  const _t_0 = _column_0["snd"];
  if (_t_0.$ === "Some") {
    const _cells_0 = _t_0["value"];
    const _owner_0 = _resource_0["fst"];
    const _text_0 = _resource_0["snd"];
    const _pending_1 = _pending_0["fst"];
    const _count_0 = _pending_0["snd"];
    const _x_0 = ($Nat$show$(_count_0));
    const _x_1 = ($U32$show$(_clock_0));
    const _x_2 = (",\"pendingStructural\":" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = (",\"clock\":" + _x_3);
    const _x_5 = (_text_0 + _x_4);
    const _x_6 = ("," + _x_5);
    const _x_7 = (_cells_0 + _x_6);
    const _x_8 = ($U32$show$(_ns_0));
    const _x_9 = (",\"entity\":1,\"component\":" + _x_7);
    const _x_10 = (_x_8 + _x_9);
    return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Store", "column": _column_1}, "resource": _owner_0, "events": _events_0, "pending": _pending_1, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ("\"namespace\":" + _x_10)};
  } else {
    const _owner_1 = _resource_0["fst"];
    const _text_1 = _resource_0["snd"];
    const _pending_2 = _pending_0["fst"];
    const _count_1 = _pending_0["snd"];
    const _x_11 = ($Nat$show$(_count_1));
    const _x_12 = ($U32$show$(_clock_0));
    const _x_13 = (",\"pendingStructural\":" + _x_11);
    const _x_14 = (_x_12 + _x_13);
    const _x_15 = (",\"clock\":" + _x_14);
    const _x_16 = (_text_1 + _x_15);
    const _x_17 = ($U32$show$(_ns_0));
    const _x_18 = (",\"entity\":1,\"component\":null," + _x_16);
    const _x_19 = (_x_17 + _x_18);
    return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Store", "column": _column_1}, "resource": _owner_1, "events": _events_0, "pending": _pending_2, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ("\"namespace\":" + _x_19)};
  }
}

function $$$$047stage$047src$047ecs$047column$058view$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../stage/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047stage$047src$047ecs$047column$058plain_view_sized$1261$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../stage/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058prepared_view_state$1261$(_id_0, ($$$$047stage$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../stage/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_view_state$1261$(_id_0, ($$$$047stage$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_prepared_view_state$1261$(_id_0, ($$$$047stage$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058resources$1261$(_owner_0, _runStatus_0) {
  const _owned_0 = _owner_0["owned"];
  const _slotValue_0 = _owner_0["slot"];
  const _stream_0 = _owner_0["stream"];
  const _readerOwner_0 = _owner_0["reader"];
  const _localOwners_0 = _owner_0["locals"];
  const _tick_0 = _owner_0["tick"];
  const _prefix_0 = _owner_0["prefix"];
  const _delivered_0 = _owner_0["delivered"];
  const _applied_0 = _owner_0["structuralApplied"];
  const _extra_0 = _owner_0["extra"];
  const _failureId_0 = _owner_0["failureId"];
  const _attemptLog_0 = _owner_0["attemptLog"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058resources_from_stream$1261$({$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": [0], "slot": _slotValue_0, "stream": _stream_0, "reader": {$: "None"}, "locals": {$: "Nil"}, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": {$: "None"}, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, _stream_0, _owned_0, _extra_0, _localOwners_0, _readerOwner_0, _runStatus_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058commands$1261$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _head_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058commands_join$1261$(_head_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058commands$1261$(_rest_0)));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058entry_join$1261$(_head_0, _text_0, _id_0, _name_0, _ns_0, _cursor_0, _needs_0, _tail_0) {
  const _entries_0 = _tail_0["entries"];
  const _texts_0 = _tail_0["texts"];
  const _ids_0 = _tail_0["ids"];
  const _names_0 = _tail_0["names"];
  const _namespaces_0 = _tail_0["namespaces"];
  const _cursors_0 = _tail_0["cursors"];
  const _requirements_0 = _tail_0["requirements"];
  return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/observe.EntriesObserved", "entries": {$: "Con", "head": _head_0, "tail": _entries_0}, "texts": {$: "Con", "head": _text_0, "tail": _texts_0}, "ids": {$: "Con", "head": _id_0, "tail": _ids_0}, "names": {$: "Con", "head": _name_0, "tail": _names_0}, "namespaces": {$: "Con", "head": _ns_0, "tail": _namespaces_0}, "cursors": {$: "Con", "head": _cursor_0, "tail": _cursors_0}, "requirements": ($List$append$(_needs_0, _requirements_0))};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058selector$1261$(_value_0) {
  if (_value_0.$ === "../stage/src/ecs/machine-handler-bundle.ExitFrom") {
    const _old_0 = _value_0["value"];
    const _x_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058state$(_old_0));
    const _x_1 = (_x_0 + ",\"to\":null");
    return ("\"phase\":\"exit\",\"from\":" + _x_1);
  } else if (_value_0.$ === "../stage/src/ecs/machine-handler-bundle.TransitionPair") {
    const _old_1 = _value_0["from"];
    const _new_0 = _value_0["to"];
    const _x_2 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058state$(_new_0));
    const _x_3 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058state$(_old_1));
    const _x_4 = (",\"to\":" + _x_2);
    const _x_5 = (_x_3 + _x_4);
    return ("\"phase\":\"transition\",\"from\":" + _x_5);
  } else {
    const _new_1 = _value_0["value"];
    const _x_6 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058state$(_new_1));
    return ("\"phase\":\"enter\",\"from\":null,\"to\":" + _x_6);
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058bundle$1261$(_namespace_0, _tree_0) {
  return {$: "../stage/src/ecs/machine-handler-bundle.Bundle", "namespace": _namespace_0, "entries": ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058flattened$1261$(_tree_0))};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058installed_one$1261$(_selector_0, _needs_0, _observed_0) {
  if (_observed_0.$ === "../stage/src/ecs/system.RegistrationFailed") {
    const _world_0 = _observed_0["world"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Installed", "world": _world_0, "tree": {$: "../stage/src/ecs/machine-handler-bundle.Empty"}};
  } else {
    const _world_1 = _observed_0["world"];
    const _t_0 = _observed_0["registry"];
    const _namespace_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _name_0 = _t_0["name"];
    const _access_0 = _t_0["access"];
    const _cursor_0 = _t_0["cursor"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Installed", "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058install_local$1261$(_world_1, _id_0)), "tree": {$: "../stage/src/ecs/machine-handler-bundle.Single", "scheduled": {$: "../stage/src/ecs/machine-handler-bundle.Scheduled", "selector": _selector_0, "requirements": _needs_0, "entry": {$: "../stage/src/ecs/machine-handlers.Entry", "ordinal": _id_0, "registry": {$: "../stage/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}}}}};
  }
}

function $$$$047stage$047src$047ecs$047system$058register$1263$(_world_0, _name_0, _access_0) {
  return $$$$047stage$047src$047ecs$047system$058register_namespace$1263$(($$$$047stage$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058installed_left$1261$(_left_0, _next_0) {
  const _world_0 = _left_0["world"];
  const _left_1 = _left_0["tree"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058installed_pair$1261$(_left_1, _next_0(_world_0));
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058namespace_checked$1260$(_allowed_0, _bundle_0, _world_0) {
  if (!_allowed_0) {
    return {$: "../stage/src/ecs/machine-handler-bundle.Returned", "bundle": _bundle_0, "world": _world_0, "status": {$: "../stage/src/ecs/machine-handler-bundle.ForeignBundle"}};
  } else {
    const _namespace_0 = _bundle_0["namespace"];
    const _entries_0 = _bundle_0["entries"];
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058gathered$1260$(_namespace_0, _world_0, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058requirements$1260$(_entries_0)));
  }
}

function $$$$047stage$047src$047ecs$047system$058tracked_outcome$1261$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../stage/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../stage/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../stage/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047stage$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, ($$$$047stage$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047stage$047src$047ecs$047system$058run_namespace$1261$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047stage$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0);
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058requirement_same$1260$(_left_0, _right_0) {
  if (_left_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement") {
    if (_right_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement") {
      return true;
    } else {
      return false;
    }
  } else if (_left_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement") {
    if (_right_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_right_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.ExtraRequirement") {
      return true;
    } else {
      return false;
    }
  }
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $$$$047stage$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047stage$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047stage$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047stage$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047stage$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047stage$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047stage$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047stage$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058resources_join$1260$(_rest_0, _owned_0, _extra_0, _localValues_0, _readerValue_0, _runStatus_0) {
  const _slotValue_0 = _rest_0["slot"];
  const _t_0 = _rest_0["stream"];
  const _batches_0 = _t_0["batches"];
  const _positions_0 = _t_0["positions"];
  const _dropped_0 = _t_0["droppedThrough"];
  const _start_0 = _t_0["frameStart"];
  const _tick_0 = _rest_0["tick"];
  const _prefix_0 = _rest_0["prefix"];
  const _delivered_0 = _rest_0["delivered"];
  const _applied_0 = _rest_0["structuralApplied"];
  const _failureId_0 = _rest_0["failureId"];
  const _attemptLog_0 = _rest_0["attemptLog"];
  const _owned_1 = _owned_0["fst"];
  const _ownedText_0 = _owned_0["snd"];
  const _extra_1 = _extra_0["fst"];
  const _t_1 = _extra_0["snd"];
  const _extraText_0 = _t_1["fst"];
  const _available_0 = _t_1["snd"];
  const _locals_0 = _localValues_0["fst"];
  const _values_0 = _localValues_0["snd"];
  const _reader_0 = _readerValue_0["fst"];
  const _readerText_0 = _readerValue_0["snd"];
  const _x_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058status$1260$(_runStatus_0, _attemptLog_0));
  const _x_1 = ($U32$show$(_applied_0));
  const _x_2 = ("," + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($List$show$1262$(_attemptLog_0));
  const _x_5 = (",\"structuralApplied\":" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($List$show$1262$(_prefix_0));
  const _x_8 = (",\"attempts\":" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($Nat$show$(_tick_0));
  const _x_11 = (",\"prefix\":" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($List$show$1264$(_delivered_0));
  const _x_14 = (",\"tick\":" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($List$show$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058publications$(_batches_0))));
  const _x_17 = (",\"deliveries\":" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = (",\"publications\":" + _x_18);
  const _x_20 = (_readerText_0 + _x_19);
  const _x_21 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058slot$1260$(_slotValue_0));
  const _x_22 = ("," + _x_20);
  const _x_23 = (_x_21 + _x_22);
  const _x_24 = ($List$show$1261$(_values_0));
  const _x_25 = ("," + _x_23);
  const _x_26 = (_x_24 + _x_25);
  const _x_27 = (",\"locals\":" + _x_26);
  const _x_28 = (_extraText_0 + _x_27);
  const _x_29 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058bool$(_available_0));
  const _x_30 = (",\"extraPayload\":" + _x_28);
  const _x_31 = (_x_29 + _x_30);
  const _x_32 = (",\"extraPresent\":" + _x_31);
  const _x_33 = (_ownedText_0 + _x_32);
  return {$: "Tuple", "fst": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_1, "slot": _slotValue_0, "stream": {$: "../stage/src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _start_0}, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_1, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "snd": ("\"resource\":" + _x_33)};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058array$(_owner_0) {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058array_first$({$: "Tuple", fst: _owner_0, snd: _owner_0[0 % _owner_0.length]});
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058extra_view$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": {$: "Tuple", "fst": "null", "snd": false}};
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058extra_viewed$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058array$(_owner_1)));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058locals$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _t_0 = _items_0["head"];
    const _ns_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _cell_0 = _t_0["cell"];
    const _rest_0 = _items_0["tail"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058local_observed$(_ns_0, _id_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058local_count$(_cell_0)), ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058locals$(_rest_0)));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058reader$1260$(_owner_0, _positions_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": "\"readerNamespace\":null,\"readerId\":null,\"readerPosition\":null"};
  } else {
    const _t_0 = _owner_0["value"];
    const _ns_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _x_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058position$(_positions_0));
    const _x_1 = ($U32$show$(_id_0));
    const _x_2 = (",\"readerPosition\":" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($U32$show$(_ns_0));
    const _x_5 = (",\"readerId\":" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    return {$: "Tuple", "fst": {$: "Some", "value": {$: "../stage/src/ecs/machine-stream.Reader", "namespace": _ns_0, "id": _id_0}}, "snd": ("\"readerNamespace\":" + _x_6)};
  }
}

function $$$$047stage$047src$047ecs$047system$058register_join$1261$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047stage$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047stage$047src$047ecs$047machine$058queue$1261$(_slot_0, _value_0, _skipSame_0) {
  if (_slot_0.$ === "../stage/src/ecs/machine.Missing") {
    return {$: "../stage/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../stage/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../stage/src/ecs/machine.Queued", "value": _value_0, "skipSame": _skipSame_0}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058namespace_join$1261$(_namespace_0, _entries_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _actual_0 = _pair_0["snd"];
  return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058namespace_checked$1261$((_namespace_0 === _actual_0), {$: "../stage/src/ecs/machine-handler-bundle.Bundle", "namespace": _namespace_0, "entries": _entries_0}, _world_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058read_completed$1261$(_bundle_0, _status_0, _registry_0, _result_0) {
  if (_result_0.$ === "../stage/src/ecs/system.Succeeded") {
    const _world_0 = _result_0["world"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": _world_0, "bundle": _bundle_0, "readerRegistry": {$: "Some", "value": _registry_0}, "status": _status_0};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Application", "world": _world_1, "bundle": _bundle_0, "readerRegistry": {$: "Some", "value": _registry_0}, "status": _status_0};
  }
}

function $$$$047stage$047src$047ecs$047system$058tracked_result$1263$(_result_0) {
  if (_result_0.$ === "../stage/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../stage/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047stage$047src$047ecs$047system$058tracked_outcome$1263$(_registry_1, _outcome_0);
  }
}

function $$$$047stage$047src$047ecs$047system$058run$1263$(_registry_0, _world_0, _args_0) {
  return $$$$047stage$047src$047ecs$047system$058run_namespace$1263$(_registry_0, ($$$$047stage$047src$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058requirement$1261$(_value_0) {
  if (_value_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement") {
    return "\"machine\"";
  } else if (_value_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement") {
    return "\"owned\"";
  } else {
    return "\"extra\"";
  }
}

function $List$show$go$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058requirement$1261$(_h_0));
    const _x_1 = ($List$show$go$1265$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058collected$1261$(_seen_0, _prior_0, _value_0) {
  if (_seen_0) {
    return _prior_0;
  } else {
    return $List$append$(_prior_0, {$: "Con", "head": _value_0, "tail": {$: "Nil"}});
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058contains$1261$(_items_0, _value_0) {
  if (_items_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _items_0["head"];
    const _tail_0 = _items_0["tail"];
    const _x_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058requirement_same$1261$(_head_0, _value_0));
    const _x_1 = ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058contains$1261$(_tail_0, _value_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047stage$047src$047ecs$047column$058plain_view_sized$1261$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047stage$047src$047ecs$047column$058plain_view_checked$1261$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047stage$047src$047ecs$047column$058prepared_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047stage$047src$047ecs$047column$058prepared_view_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047stage$047src$047ecs$047column$058unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../stage/src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047stage$047src$047ecs$047column$058indexed_view_sized$1261$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047stage$047src$047ecs$047column$058indexed_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../stage/src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047stage$047src$047ecs$047column$058indexed_prepared_view_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../stage/src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058resources_from_stream$1261$(_rest_0, _stream_0, _owned_0, _extra_0, _localOwners_0, _readerOwner_0, _runStatus_0) {
  const _positions_0 = _stream_0["positions"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058resources_join$1261$(_rest_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058array$(_owned_0)), ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058extra_view$(_extra_0)), ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058locals$(_localOwners_0)), ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058reader$1261$(_readerOwner_0, _positions_0)), _runStatus_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058commands_join$1261$(_head_0, _tail_0) {
  const _rest_0 = _tail_0["fst"];
  const _count_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_0, "tail": _rest_0}, "snd": nat_chk(_count_0 + 1)};
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058flattened$1261$(_tree_0) {
  if (_tree_0.$ === "../stage/src/ecs/machine-handler-bundle.Empty") {
    return {$: "Nil"};
  } else if (_tree_0.$ === "../stage/src/ecs/machine-handler-bundle.Single") {
    const _scheduled_0 = _tree_0["scheduled"];
    return {$: "Con", "head": _scheduled_0, "tail": {$: "Nil"}};
  } else {
    const _left_0 = _tree_0["left"];
    const _right_0 = _tree_0["right"];
    return $List$append$(($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058flattened$1261$(_left_0)), ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058flattened$1261$(_right_0)));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058install_local$1261$(_world_0, _id_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": ($List$append$(_locals_0, {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.LocalOwner", "namespace": _ns_0, "id": _id_0, "cell": {$: "../stage/src/ecs/local.Cell", "local": [0]}}, "tail": {$: "Nil"}})), "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047src$047ecs$047system$058register_namespace$1263$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047stage$047src$047ecs$047system$058register_join$1263$(($$$$047stage$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058installed_pair$1261$(_left_0, _right_0) {
  const _world_0 = _right_0["world"];
  const _right_1 = _right_0["tree"];
  return {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/application.Installed", "world": _world_0, "tree": {$: "../stage/src/ecs/machine-handler-bundle.Join", "left": _left_0, "right": _right_1}};
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058gathered$1260$(_namespace_0, _world_0, _pair_0) {
  const _entries_0 = _pair_0["fst"];
  const _needs_0 = _pair_0["snd"];
  return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058preflighted$1260$(_namespace_0, _entries_0, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058missing$1260$(($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058collect$1260$(_needs_0, {$: "Nil"})), _world_0)));
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058requirements$1260$(_entries_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _selector_0 = _t_0["selector"];
    const _needs_0 = _t_0["requirements"];
    const _entry_0 = _t_0["entry"];
    const _tail_0 = _entries_0["tail"];
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058requirements_join$1260$(_selector_0, _needs_0, _entry_0, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058requirements$1260$(_tail_0)));
  }
}

function $$$$047stage$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047stage$047src$047ecs$047system$058cursor_outcome$1261$({$: "../stage/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047stage$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047stage$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047stage$047src$047ecs$047system$058run_namespace_checked$1261$((_namespace_0 === _actual_0), {$: "../stage/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047stage$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058array$(_owner_0)));
  }
}

function $$$$047stage$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047stage$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058array$(_owned_0)));
  }
}

function $$$$047stage$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047stage$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047stage$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047stage$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047stage$047src$047ecs$047column$058seek_view$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047stage$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../stage/src/ecs/column.Inspect"});
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047stage$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047stage$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047stage$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058array$(_owned_0)));
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047stage$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047stage$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047stage$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047stage$047src$047ecs$047column$058indexed_seek_view$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047stage$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../stage/src/ecs/column.Inspect"});
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058bool$(_value_0) {
  if (!_value_0) {
    return "false";
  } else {
    return "true";
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058slot$1260$(_value_0) {
  if (_value_0.$ === "../stage/src/ecs/machine.Missing") {
    return "\"current\":null,\"pending\":null,\"previous\":null,\"changed\":false";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _prior_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058bool$(_changed_0));
    const _x_1 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058previous$(_prior_0));
    const _x_2 = (",\"changed\":" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058pending$(_next_0));
    const _x_5 = (",\"previous\":" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    const _x_7 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058state$(_current_0));
    const _x_8 = (",\"pending\":" + _x_6);
    const _x_9 = (_x_7 + _x_8);
    return ("\"current\":" + _x_9);
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058publications$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _items_0["head"];
    const _tick_0 = _t_0["tick"];
    const _values_0 = _t_0["values"];
    const _rest_0 = _items_0["tail"];
    return $List$append$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058publications_values$(_values_0, _tick_0)), ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058publications$(_rest_0)));
  }
}

function $List$show$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058transition$(_h_0));
    const _x_1 = ($List$show$go$1264$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058status$1260$(_value_0, _attemptLog_0) {
  if (_value_0.$ === "None") {
    return "\"outcome\":\"idle\",\"missing\":[]";
  } else {
    const _t_0 = _value_0["value"];
    if (_t_0.$ === "../stage/src/ecs/machine-handler-bundle.Completed") {
      return "\"outcome\":\"ok\",\"missing\":[]";
    } else if (_t_0.$ === "../stage/src/ecs/machine-handler-bundle.HandlerFailed") {
      const _x_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058last$(_attemptLog_0, "unknown"));
      const _x_1 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058quote$(("failed:" + _x_0)));
      const _x_2 = (_x_1 + ",\"missing\":[]");
      return ("\"outcome\":" + _x_2);
    } else if (_t_0.$ === "../stage/src/ecs/machine-handler-bundle.MissingRequirements") {
      const _missing_0 = _t_0["missing"];
      const _x_3 = ($List$show$1263$(_missing_0));
      return ("\"outcome\":\"requirements\",\"missing\":" + _x_3);
    } else if (_t_0.$ === "../stage/src/ecs/machine-handler-bundle.ForeignBundle") {
      return "\"outcome\":\"foreign\",\"missing\":[]";
    } else {
      return "\"outcome\":\"machineUnavailable\",\"missing\":[]";
    }
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058array_first$(_pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _first_0 = _pair_0["snd"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058array_second$(_first_0, {$: "Tuple", fst: _owner_0, snd: _owner_0[1 % _owner_0.length]});
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058extra_viewed$(_pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": _owner_0}, "snd": {$: "Tuple", "fst": _text_0, "snd": true}};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058local_observed$(_ns_0, _id_0, _pair_0, _tail_0) {
  const _cell_0 = _pair_0["fst"];
  const _value_0 = _pair_0["snd"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058locals_join$({$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.LocalOwner", "namespace": _ns_0, "id": _id_0, "cell": _cell_0}, _value_0, _tail_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058local_count$(_cell_0) {
  return $$$$047stage$047src$047ecs$047local$058read_cell$1260$(_cell_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058position$(_items_0) {
  if (_items_0.$ === "Nil") {
    return "null";
  } else {
    const _t_0 = _items_0["head"];
    const _cursor_0 = _t_0["cursor"];
    const _at_0 = _t_0["registeredAt"];
    const _x_0 = ($Nat$show$(_at_0));
    const _x_1 = (_x_0 + "}");
    const _x_2 = ($Nat$show$(_cursor_0));
    const _x_3 = (",\"registeredAt\":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("{\"cursor\":" + _x_4);
  }
}

function $$$$047stage$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../stage/src/ecs/world.RegistrationRejected") {
    return {$: "../stage/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../stage/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../stage/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058namespace_checked$1261$(_allowed_0, _bundle_0, _world_0) {
  if (!_allowed_0) {
    return {$: "../stage/src/ecs/machine-handler-bundle.Returned", "bundle": _bundle_0, "world": _world_0, "status": {$: "../stage/src/ecs/machine-handler-bundle.ForeignBundle"}};
  } else {
    const _namespace_0 = _bundle_0["namespace"];
    const _entries_0 = _bundle_0["entries"];
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058gathered$1261$(_namespace_0, _world_0, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058requirements$1261$(_entries_0)));
  }
}

function $$$$047stage$047src$047ecs$047system$058tracked_outcome$1263$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../stage/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../stage/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../stage/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047stage$047src$047ecs$047system$058tracked_clock$1263$(_registry_0, _output_0, ($$$$047stage$047src$047ecs$047world$058clock$1261$(_world_1)));
  }
}

function $$$$047stage$047src$047ecs$047system$058run_namespace$1263$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047stage$047src$047ecs$047system$058run_namespace_value$1263$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058requirement_same$1261$(_left_0, _right_0) {
  if (_left_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement") {
    if (_right_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement") {
      return true;
    } else {
      return false;
    }
  } else if (_left_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement") {
    if (_right_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_right_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.ExtraRequirement") {
      return true;
    } else {
      return false;
    }
  }
}

function $$$$047stage$047src$047ecs$047column$058plain_view_checked$1261$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047stage$047src$047ecs$047column$058plain_view_taken$1261$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047stage$047src$047ecs$047column$058prepared_view_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047stage$047src$047ecs$047column$058prepared_view_current$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047stage$047src$047ecs$047column$058prepared_view_different$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_view_sized$1261$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047stage$047src$047ecs$047column$058indexed_view_checked$1261$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_view_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047stage$047src$047ecs$047column$058indexed_prepared_view_current$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047stage$047src$047ecs$047column$058indexed_prepared_view_different$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058resources_join$1261$(_rest_0, _owned_0, _extra_0, _localValues_0, _readerValue_0, _runStatus_0) {
  const _slotValue_0 = _rest_0["slot"];
  const _t_0 = _rest_0["stream"];
  const _batches_0 = _t_0["batches"];
  const _positions_0 = _t_0["positions"];
  const _dropped_0 = _t_0["droppedThrough"];
  const _start_0 = _t_0["frameStart"];
  const _tick_0 = _rest_0["tick"];
  const _prefix_0 = _rest_0["prefix"];
  const _delivered_0 = _rest_0["delivered"];
  const _applied_0 = _rest_0["structuralApplied"];
  const _failureId_0 = _rest_0["failureId"];
  const _attemptLog_0 = _rest_0["attemptLog"];
  const _owned_1 = _owned_0["fst"];
  const _ownedText_0 = _owned_0["snd"];
  const _extra_1 = _extra_0["fst"];
  const _t_1 = _extra_0["snd"];
  const _extraText_0 = _t_1["fst"];
  const _available_0 = _t_1["snd"];
  const _locals_0 = _localValues_0["fst"];
  const _values_0 = _localValues_0["snd"];
  const _reader_0 = _readerValue_0["fst"];
  const _readerText_0 = _readerValue_0["snd"];
  const _x_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058status$1261$(_runStatus_0, _attemptLog_0));
  const _x_1 = ($U32$show$(_applied_0));
  const _x_2 = ("," + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($List$show$1262$(_attemptLog_0));
  const _x_5 = (",\"structuralApplied\":" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($List$show$1262$(_prefix_0));
  const _x_8 = (",\"attempts\":" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($Nat$show$(_tick_0));
  const _x_11 = (",\"prefix\":" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($List$show$1264$(_delivered_0));
  const _x_14 = (",\"tick\":" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($List$show$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058publications$(_batches_0))));
  const _x_17 = (",\"deliveries\":" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = (",\"publications\":" + _x_18);
  const _x_20 = (_readerText_0 + _x_19);
  const _x_21 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058slot$1261$(_slotValue_0));
  const _x_22 = ("," + _x_20);
  const _x_23 = (_x_21 + _x_22);
  const _x_24 = ($List$show$1261$(_values_0));
  const _x_25 = ("," + _x_23);
  const _x_26 = (_x_24 + _x_25);
  const _x_27 = (",\"locals\":" + _x_26);
  const _x_28 = (_extraText_0 + _x_27);
  const _x_29 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058bool$(_available_0));
  const _x_30 = (",\"extraPayload\":" + _x_28);
  const _x_31 = (_x_29 + _x_30);
  const _x_32 = (",\"extraPresent\":" + _x_31);
  const _x_33 = (_ownedText_0 + _x_32);
  return {$: "Tuple", "fst": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_1, "slot": _slotValue_0, "stream": {$: "../stage/src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _start_0}, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_1, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "snd": ("\"resource\":" + _x_33)};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058reader$1261$(_owner_0, _positions_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": "\"readerNamespace\":null,\"readerId\":null,\"readerPosition\":null"};
  } else {
    const _t_0 = _owner_0["value"];
    const _ns_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _x_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058position$(_positions_0));
    const _x_1 = ($U32$show$(_id_0));
    const _x_2 = (",\"readerPosition\":" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($U32$show$(_ns_0));
    const _x_5 = (",\"readerId\":" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    return {$: "Tuple", "fst": {$: "Some", "value": {$: "../stage/src/ecs/machine-stream.Reader", "namespace": _ns_0, "id": _id_0}}, "snd": ("\"readerNamespace\":" + _x_6)};
  }
}

function $$$$047stage$047src$047ecs$047system$058register_join$1263$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047stage$047src$047ecs$047system$058register_meta$1263$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058preflighted$1260$(_namespace_0, _entries_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058taken_run$1260$(_namespace_0, _entries_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058take$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058frame$1260$(_world_0)))));
  } else {
    return {$: "../stage/src/ecs/machine-handler-bundle.Returned", "bundle": {$: "../stage/src/ecs/machine-handler-bundle.Bundle", "namespace": _namespace_0, "entries": _entries_0}, "world": _world_0, "status": {$: "../stage/src/ecs/machine-handler-bundle.MissingRequirements", "missing": _t_0}};
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058missing$1260$(_needs_0, _world_0) {
  if (_needs_0.$ === "Nil") {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Nil"}};
  } else {
    const _value_0 = _needs_0["head"];
    const _rest_0 = _needs_0["tail"];
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058missing_checked$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058has_requirement$1260$(_world_0, _value_0)), _value_0, run_clo((_x_0) => {
  return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058missing$1260$(_rest_0, _x_0);
}));
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058requirements_join$1260$(_selector_0, _needs_0, _entry_0, _tail_0) {
  const _entries_0 = _tail_0["fst"];
  const _all_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": {$: "../stage/src/ecs/machine-handler-bundle.Scheduled", "selector": _selector_0, "requirements": _needs_0, "entry": _entry_0}, "tail": _entries_0}, "snd": ($List$append$(_needs_0, _all_0))};
}

function $$$$047stage$047src$047ecs$047system$058cursor_outcome$1261$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../stage/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../stage/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../stage/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../stage/src/ecs/system.Completed", "registry": {$: "../stage/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../stage/src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047stage$047src$047ecs$047system$058run_namespace_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../stage/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047stage$047src$047ecs$047system$058run_metadata$1261$({$: "../stage/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047stage$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047stage$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047stage$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047stage$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047stage$047src$047ecs$047column$058view_taken$1260$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../stage/src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047stage$047src$047ecs$047column$058viewed$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058array$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047stage$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../stage/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047stage$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../stage/src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047stage$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return {$: "../stage/src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047stage$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../stage/src/ecs/column.Column", "values": ($$$$047stage$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047stage$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../stage/src/ecs/column.Column", "values": ($$$$047stage$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047stage$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047stage$047src$047ecs$047column$058seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../stage/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../stage/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../stage/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../stage/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047stage$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058array$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../stage/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../stage/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../stage/src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0) {
  return {$: "../stage/src/ecs/column.Indexed", "state": {$: "../stage/src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../stage/src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047stage$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047stage$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047stage$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058array$(_owner_0)));
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047stage$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047stage$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047stage$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047stage$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047stage$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047stage$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047stage$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../stage/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../stage/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../stage/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../stage/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047stage$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058array$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../stage/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../stage/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058pending$(_value_0) {
  if (_value_0.$ === "../stage/src/ecs/machine.NoPending") {
    return "null";
  } else {
    const _value_1 = _value_0["value"];
    const _skip_0 = _value_0["skipSame"];
    const _x_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058bool$(_skip_0));
    const _x_1 = (_x_0 + "}");
    const _x_2 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058state$(_value_1));
    const _x_3 = (",\"skipIfSame\":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("{\"value\":" + _x_4);
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058previous$(_value_0) {
  if (_value_0.$ === "None") {
    return "null";
  } else {
    const _value_1 = _value_0["value"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058state$(_value_1);
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058publications_values$(_values_0, _tick_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _value_0 = _values_0["head"];
    const _tail_0 = _values_0["tail"];
    return {$: "Con", "head": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058publication$(_value_0, _tick_0)), "tail": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058publications_values$(_tail_0, _tick_0))};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058transition$(_event_0) {
  const _from_0 = _event_0["from"];
  const _to_0 = _event_0["to"];
  const _x_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058state$(_to_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058state$(_from_0));
  const _x_3 = (",\"to\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  return ("{\"from\":" + _x_4);
}

function $List$show$go$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058transition$(_h_0));
    const _x_1 = ($List$show$go$1264$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058last$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _prior_0 = $1;
      if (_items_0.$ === "Nil") {
        return _prior_0;
      } else {
        const _head_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = _head_0;
        continue;
      }
    }
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058array_second$(_first_0, _pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _last_0 = _pair_0["snd"];
  const _x_0 = ($U32$show$(_last_0));
  const _x_1 = (_x_0 + "]");
  const _x_2 = ($U32$show$(_first_0));
  const _x_3 = ("," + _x_1);
  const _x_4 = (_x_2 + _x_3);
  return {$: "Tuple", "fst": _owner_0, "snd": ("[" + _x_4)};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058locals_join$(_head_0, _value_0, _tail_0) {
  const _rest_0 = _tail_0["fst"];
  const _values_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_0, "tail": _rest_0}, "snd": {$: "Con", "head": _value_0, "tail": _values_0}};
}

function $$$$047stage$047src$047ecs$047local$058read_cell$1260$(_cell_0) {
  const _local_0 = _cell_0["local"];
  return $$$$047stage$047src$047ecs$047local$058projected$1260$({$: "Tuple", fst: _local_0, snd: _local_0[0 % _local_0.length]});
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058gathered$1261$(_namespace_0, _world_0, _pair_0) {
  const _entries_0 = _pair_0["fst"];
  const _needs_0 = _pair_0["snd"];
  return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058preflighted$1261$(_namespace_0, _entries_0, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058missing$1261$(($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058collect$1261$(_needs_0, {$: "Nil"})), _world_0)));
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058requirements$1261$(_entries_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _selector_0 = _t_0["selector"];
    const _needs_0 = _t_0["requirements"];
    const _entry_0 = _t_0["entry"];
    const _tail_0 = _entries_0["tail"];
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058requirements_join$1261$(_selector_0, _needs_0, _entry_0, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058requirements$1261$(_tail_0)));
  }
}

function $$$$047stage$047src$047ecs$047system$058tracked_clock$1263$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047stage$047src$047ecs$047system$058cursor_outcome$1263$({$: "../stage/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047stage$047src$047ecs$047world$058clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047stage$047src$047ecs$047system$058run_namespace_value$1263$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047stage$047src$047ecs$047system$058run_namespace_checked$1263$((_namespace_0 === _actual_0), {$: "../stage/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047stage$047src$047ecs$047column$058plain_view_taken$1261$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047stage$047src$047ecs$047column$058plain_view_projected$1261$(_values_0, _stamps_0, _id_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058array$(_owner_0)));
  }
}

function $$$$047stage$047src$047ecs$047column$058prepared_view_current$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047stage$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058array$(_owned_0)));
  }
}

function $$$$047stage$047src$047ecs$047column$058prepared_view_different$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047stage$047src$047ecs$047column$058view_taken$1261$(_id_0, ($$$$047stage$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047stage$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047stage$047src$047ecs$047column$058seek_view$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047stage$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../stage/src/ecs/column.Inspect"});
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_view_checked$1261$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047stage$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047stage$047src$047ecs$047column$058indexed_view_taken$1261$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_view_current$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047stage$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058array$(_owned_0)));
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_view_different$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047stage$047src$047ecs$047column$058view_taken$1261$(_id_0, ($$$$047stage$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047stage$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047stage$047src$047ecs$047column$058indexed_seek_view$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047stage$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../stage/src/ecs/column.Inspect"});
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058slot$1261$(_value_0) {
  if (_value_0.$ === "../stage/src/ecs/machine.Missing") {
    return "\"current\":null,\"pending\":null,\"previous\":null,\"changed\":false";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _prior_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058bool$(_changed_0));
    const _x_1 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058previous$(_prior_0));
    const _x_2 = (",\"changed\":" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058pending$(_next_0));
    const _x_5 = (",\"previous\":" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    const _x_7 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058state$(_current_0));
    const _x_8 = (",\"pending\":" + _x_6);
    const _x_9 = (_x_7 + _x_8);
    return ("\"current\":" + _x_9);
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058status$1261$(_value_0, _attemptLog_0) {
  if (_value_0.$ === "None") {
    return "\"outcome\":\"idle\",\"missing\":[]";
  } else {
    const _t_0 = _value_0["value"];
    if (_t_0.$ === "../stage/src/ecs/machine-handler-bundle.Completed") {
      return "\"outcome\":\"ok\",\"missing\":[]";
    } else if (_t_0.$ === "../stage/src/ecs/machine-handler-bundle.HandlerFailed") {
      const _x_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058last$(_attemptLog_0, "unknown"));
      const _x_1 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058quote$(("failed:" + _x_0)));
      const _x_2 = (_x_1 + ",\"missing\":[]");
      return ("\"outcome\":" + _x_2);
    } else if (_t_0.$ === "../stage/src/ecs/machine-handler-bundle.MissingRequirements") {
      const _missing_0 = _t_0["missing"];
      const _x_3 = ($List$show$1265$(_missing_0));
      return ("\"outcome\":\"requirements\",\"missing\":" + _x_3);
    } else if (_t_0.$ === "../stage/src/ecs/machine-handler-bundle.ForeignBundle") {
      return "\"outcome\":\"foreign\",\"missing\":[]";
    } else {
      return "\"outcome\":\"machineUnavailable\",\"missing\":[]";
    }
  }
}

function $$$$047stage$047src$047ecs$047system$058register_meta$1263$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../stage/src/ecs/world.RegistrationRejected") {
    return {$: "../stage/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../stage/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../stage/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058taken_run$1260$(_namespace_0, _entries_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058selected_run$1260$(_namespace_0, _entries_0, _world_0, _slot_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058frame$1260$(_world_0) {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058marker_tick$1260$(run_loop($$$$047stage$047src$047ecs$047world$058barrier$1260$(_world_0)));
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058missing_checked$1260$(_pair_0, _value_0, _next_0) {
  const _world_0 = _pair_0["fst"];
  const _allowed_0 = _pair_0["snd"];
  return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058missing_join$1260$(_allowed_0, _value_0, _next_0(_world_0));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058has_requirement$1260$(_world_0, _requirement_0) {
  if (_requirement_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement") {
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058has_machine$1260$(_world_0);
  } else if (_requirement_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement") {
    return {$: "Tuple", "fst": _world_0, "snd": true};
  } else {
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058has_extra$1260$(_world_0);
  }
}

function $$$$047stage$047src$047ecs$047system$058run_metadata$1261$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047stage$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047stage$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047stage$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047stage$047src$047ecs$047column$058restored$1260$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047stage$047src$047ecs$047column$058viewed$1260$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../stage/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047stage$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../stage/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047stage$047src$047ecs$047column$058swap$1260$({$: "../stage/src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../stage/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047stage$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047stage$047src$047ecs$047column$058swap$1260$({$: "../stage/src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047stage$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047stage$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047stage$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047stage$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047stage$047src$047ecs$047column$058recover_selected_rows$($0, $1) {
  for (;;) {
    {
      const _rows_0 = $0;
      const _values_0 = $1;
      if (_rows_0.$ === "../stage/src/ecs/owner-handoff.HandoffNil") {
        return _values_0;
      } else {
        const _id_0 = _rows_0["id"];
        const _owner_0 = _rows_0["owner"];
        const _rest_0 = _rows_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        const _x_1 = {$: "Some", "value": _owner_0};
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _x_1, _values_0);
        continue;
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047column$058recover_past$1260$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../stage/src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047stage$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058publication$(_event_0, _tick_0) {
  const _from_0 = _event_0["from"];
  const _to_0 = _event_0["to"];
  const _x_0 = ($Nat$show$(_tick_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058state$(_to_0));
  const _x_3 = (",\"tick\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058state$(_from_0));
  const _x_6 = (",\"to\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  return ("{\"from\":" + _x_7);
}

function $$$$047stage$047src$047ecs$047local$058projected$1260$(_result_0) {
  const _local_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/local.Cell", "local": _local_0}, "snd": _value_0};
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058preflighted$1261$(_namespace_0, _entries_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058taken_run$1261$(_namespace_0, _entries_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058take$1261$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058frame$1261$(_world_0)))));
  } else {
    return {$: "../stage/src/ecs/machine-handler-bundle.Returned", "bundle": {$: "../stage/src/ecs/machine-handler-bundle.Bundle", "namespace": _namespace_0, "entries": _entries_0}, "world": _world_0, "status": {$: "../stage/src/ecs/machine-handler-bundle.MissingRequirements", "missing": _t_0}};
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058missing$1261$(_needs_0, _world_0) {
  if (_needs_0.$ === "Nil") {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Nil"}};
  } else {
    const _value_0 = _needs_0["head"];
    const _rest_0 = _needs_0["tail"];
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058missing_checked$1261$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058has_requirement$1261$(_world_0, _value_0)), _value_0, run_clo((_x_0) => {
  return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058missing$1261$(_rest_0, _x_0);
}));
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058requirements_join$1261$(_selector_0, _needs_0, _entry_0, _tail_0) {
  const _entries_0 = _tail_0["fst"];
  const _all_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": {$: "../stage/src/ecs/machine-handler-bundle.Scheduled", "selector": _selector_0, "requirements": _needs_0, "entry": _entry_0}, "tail": _entries_0}, "snd": ($List$append$(_needs_0, _all_0))};
}

function $$$$047stage$047src$047ecs$047system$058cursor_outcome$1263$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../stage/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../stage/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../stage/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../stage/src/ecs/system.Completed", "registry": {$: "../stage/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../stage/src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047stage$047src$047ecs$047system$058run_namespace_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../stage/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047stage$047src$047ecs$047system$058run_metadata$1263$({$: "../stage/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047stage$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047stage$047src$047ecs$047column$058plain_view_projected$1261$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047stage$047src$047ecs$047column$058restored$1261$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047stage$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047stage$047src$047ecs$047column$058view_taken$1261$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../stage/src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047stage$047src$047ecs$047column$058viewed$1261$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058array$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047stage$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../stage/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047stage$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../stage/src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047stage$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return {$: "../stage/src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047stage$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../stage/src/ecs/column.Column", "values": ($$$$047stage$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047stage$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../stage/src/ecs/column.Column", "values": ($$$$047stage$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047stage$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047stage$047src$047ecs$047column$058seek_view$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../stage/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../stage/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../stage/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../stage/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047stage$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058array$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../stage/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../stage/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../stage/src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0) {
  return {$: "../stage/src/ecs/column.Indexed", "state": {$: "../stage/src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../stage/src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047stage$047src$047ecs$047column$058indexed_view_taken$1261$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047stage$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047stage$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058array$(_owner_0)));
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047stage$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047stage$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047stage$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047stage$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047stage$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047stage$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047stage$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_seek_view$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../stage/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../stage/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../stage/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../stage/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047stage$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047observe$058array$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../stage/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../stage/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058selected_run$1260$(_namespace_0, _entries_0, _world_0, _slot_0) {
  if (_slot_0.$ === "../stage/src/ecs/machine.Missing") {
    return {$: "../stage/src/ecs/machine-handler-bundle.Returned", "bundle": {$: "../stage/src/ecs/machine-handler-bundle.Bundle", "namespace": _namespace_0, "entries": _entries_0}, "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put$1260$(_world_0, {$: "../stage/src/ecs/machine.Missing"})), "status": {$: "../stage/src/ecs/machine-handler-bundle.MachineUnavailable"}};
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058selected_target$1260$(_namespace_0, _entries_0, _world_0, {$: "../stage/src/ecs/machine.Present", "current": _current_0, "pending": _pending_0, "previous": _previous_0, "changed": _changed_0}, _current_0, _pending_0);
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058marker_tick$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": nat_chk(_tick_0 + 1), "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047src$047ecs$047world$058barrier$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047stage$047src$047ecs$047world$058drain_fifo$1260$(_pending_0, {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058missing_join$1260$(_allowed_0, _value_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _rest_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058missing_selected$1260$(_allowed_0, _value_0, _rest_0))};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058has_machine$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058machine_present$1260$(_slot_0))};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058has_extra$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058extra_checked$1260$({$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": {$: "None"}, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058extra_present$(_extra_0)));
}

function $$$$047stage$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../stage/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047stage$047src$047ecs$047system$058complete$1261$(_registry_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058reader_runner$1260$(_world_0, _args_0)));
  }
}

function $$$$047stage$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $$$$047stage$047src$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $$$$047stage$047src$047ecs$047column$058viewed_return$1260$(_view_0, _result_0) {
  if (_result_0.$ === "../stage/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047stage$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../stage/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047stage$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../stage/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, ($$$$047stage$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../stage/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047stage$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, ($$$$047stage$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047stage$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047stage$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../stage/src/ecs/column.Rejected", "column": {$: "../stage/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047stage$047src$047ecs$047column$058swapped$1260$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047stage$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047stage$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047stage$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058taken_run$1261$(_namespace_0, _entries_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058selected_run$1261$(_namespace_0, _entries_0, _world_0, _slot_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058frame$1261$(_world_0) {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058marker_tick$1261$(run_loop($$$$047stage$047src$047ecs$047world$058barrier$1261$(_world_0)));
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058missing_checked$1261$(_pair_0, _value_0, _next_0) {
  const _world_0 = _pair_0["fst"];
  const _allowed_0 = _pair_0["snd"];
  return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058missing_join$1261$(_allowed_0, _value_0, _next_0(_world_0));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058has_requirement$1261$(_world_0, _requirement_0) {
  if (_requirement_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.MachineRequirement") {
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058has_machine$1261$(_world_0);
  } else if (_requirement_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.OwnedRequirement") {
    return {$: "Tuple", "fst": _world_0, "snd": true};
  } else {
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058has_extra$1261$(_world_0);
  }
}

function $$$$047stage$047src$047ecs$047system$058run_metadata$1263$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047stage$047src$047ecs$047system$058run_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047stage$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047stage$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047stage$047src$047ecs$047column$058restored$1261$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047stage$047src$047ecs$047column$058viewed$1261$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../stage/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047stage$047src$047ecs$047column$058restored$1261$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../stage/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058viewed_return$1261$(_result_0, ($$$$047stage$047src$047ecs$047column$058swap$1261$({$: "../stage/src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../stage/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_projected_state$1261$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047stage$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058viewed_return$1261$(_result_0, ($$$$047stage$047src$047ecs$047column$058swap$1261$({$: "../stage/src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047stage$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047stage$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047stage$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047stage$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047stage$047src$047ecs$047column$058recover_past$1261$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../stage/src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047stage$047src$047ecs$047column$058indexed_view_restored$1261$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058selected_target$1260$(_namespace_0, _entries_0, _world_0, _slot_0, _current_0, _pending_0) {
  if (_pending_0.$ === "../stage/src/ecs/machine.NoPending") {
    return {$: "../stage/src/ecs/machine-handler-bundle.Returned", "bundle": {$: "../stage/src/ecs/machine-handler-bundle.Bundle", "namespace": _namespace_0, "entries": _entries_0}, "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put$1260$(_world_0, ($$$$047stage$047src$047ecs$047machine$058clear_changed$1260$(_slot_0)))), "status": {$: "../stage/src/ecs/machine-handler-bundle.Completed"}};
  } else {
    const _value_0 = _pending_0["value"];
    const _skipSame_0 = _pending_0["skipSame"];
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058partitioned_run$1260$(_namespace_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put$1260$(_world_0, _slot_0)), {$: "../stage/src/ecs/machine.Scheduled", "value": _value_0, "skipSame": _skipSame_0}, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058partition$1260$(_entries_0, _current_0, _value_0)));
  }
}

function $$$$047stage$047src$047ecs$047world$058drain_fifo$1260$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047stage$047src$047ecs$047world$058drain_fifo$1260$(_rest_0, _world_0)));
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058missing_selected$1260$(_allowed_0, _value_0, _rest_0) {
  if (_allowed_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _value_0, "tail": _rest_0};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058machine_present$1260$(_slot_0) {
  if (_slot_0.$ === "../stage/src/ecs/machine.Missing") {
    return false;
  } else {
    return true;
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058extra_checked$1260$(_world_0, _pair_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _extra_0 = _pair_0["fst"];
  const _allowed_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _allowed_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058extra_present$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047stage$047src$047ecs$047system$058complete$1261$(_registry_0, _outcome_0) {
  return {$: "../stage/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058reader_runner$1260$(_world_0, __0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058reader_selected$1260$({$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": ($$$$047stage$047src$047ecs$047machine$045stream$058empty$1260$()), "reader": {$: "None"}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, _reader_0, _stream_0, _ns_0, _tick_0);
}

function $$$$047stage$047src$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($$$$047stage$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047stage$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047stage$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047stage$047src$047ecs$047column$058swapped$1260$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../stage/src/ecs/column.Accepted", "column": {$: "../stage/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047stage$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../stage/src/ecs/column.Rejected", "column": ($$$$047stage$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047stage$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058selected_run$1261$(_namespace_0, _entries_0, _world_0, _slot_0) {
  if (_slot_0.$ === "../stage/src/ecs/machine.Missing") {
    return {$: "../stage/src/ecs/machine-handler-bundle.Returned", "bundle": {$: "../stage/src/ecs/machine-handler-bundle.Bundle", "namespace": _namespace_0, "entries": _entries_0}, "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put$1261$(_world_0, {$: "../stage/src/ecs/machine.Missing"})), "status": {$: "../stage/src/ecs/machine-handler-bundle.MachineUnavailable"}};
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058selected_target$1261$(_namespace_0, _entries_0, _world_0, {$: "../stage/src/ecs/machine.Present", "current": _current_0, "pending": _pending_0, "previous": _previous_0, "changed": _changed_0}, _current_0, _pending_0);
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058marker_tick$1261$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": nat_chk(_tick_0 + 1), "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047src$047ecs$047world$058barrier$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047stage$047src$047ecs$047world$058drain_fifo$1261$(_pending_0, {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058missing_join$1261$(_allowed_0, _value_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _rest_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058missing_selected$1261$(_allowed_0, _value_0, _rest_0))};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058has_machine$1261$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058machine_present$1261$(_slot_0))};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058has_extra$1261$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058extra_checked$1261$({$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": {$: "None"}, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058extra_present$(_extra_0)));
}

function $$$$047stage$047src$047ecs$047system$058run_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../stage/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047stage$047src$047ecs$047system$058complete$1263$(_registry_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058reader_runner$1261$(_world_0, _args_0)));
  }
}

function $$$$047stage$047src$047ecs$047column$058viewed_return$1261$(_view_0, _result_0) {
  if (_result_0.$ === "../stage/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047stage$047src$047ecs$047column$058swap$1261$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../stage/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047stage$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../stage/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, ($$$$047stage$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../stage/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047stage$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, ($$$$047stage$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_projected_state$1261$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047stage$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047stage$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../stage/src/ecs/column.Rejected", "column": {$: "../stage/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047stage$047src$047ecs$047column$058swapped$1261$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047stage$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047stage$047src$047ecs$047column$058indexed_view_restored$1261$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047stage$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047stage$047src$047ecs$047machine$058clear_changed$1260$(_slot_0) {
  if (_slot_0.$ === "../stage/src/ecs/machine.Missing") {
    return {$: "../stage/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    return {$: "../stage/src/ecs/machine.Present", "current": _current_0, "pending": _pending_0, "previous": _previous_0, "changed": false};
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058partitioned_run$1260$(_namespace_0, _world_0, _captured_0, _selected_0) {
  const _positions_0 = _selected_0["positions"];
  const _kept_0 = _selected_0["kept"];
  const _owners_0 = _selected_0["owners"];
  return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058finished$1260$(_namespace_0, _positions_0, _kept_0, ($$$$047stage$047src$047ecs$047machine$045handlers$058run$1260$(_owners_0, _world_0, _captured_0)));
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058partition$1260$(_entries_0, _from_0, _to_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "../stage/src/ecs/machine-handler-bundle.Partition", "positions": {$: "Nil"}, "kept": {$: "Nil"}, "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": {$: "Nil"}, "transition": {$: "Nil"}, "enter": {$: "Nil"}}};
  } else {
    const _t_0 = _entries_0["head"];
    const _selector_0 = _t_0["selector"];
    const _needs_0 = _t_0["requirements"];
    const _entry_0 = _t_0["entry"];
    const _tail_0 = _entries_0["tail"];
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058placed$1260$(($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058choose$1260$(_selector_0, _from_0, _to_0)), _selector_0, _needs_0, _entry_0, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058partition$1260$(_tail_0, _from_0, _to_0)));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058reader_selected$1260$(_world_0, _reader_0, _stream_0, _ns_0, _tick_0) {
  if (_reader_0.$ === "None") {
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058read_missing$1260$(_world_0, _stream_0);
  } else {
    const _reader_1 = _reader_0["value"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058read_opened$1260$(_world_0, _tick_0, ($$$$047stage$047src$047ecs$047machine$045stream$058open$1260$(_reader_1, _stream_0, _ns_0, _tick_0)));
  }
}

function $$$$047stage$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $$$$047stage$047src$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $$$$047stage$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../stage/src/ecs/column.Rejected", "column": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../stage/src/ecs/column.Accepted", "column": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047stage$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047stage$047src$047ecs$047column$058recover$1260$({$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047stage$047src$047ecs$047column$058seek$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047stage$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../stage/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../stage/src/ecs/column.Rejected", "column": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../stage/src/ecs/column.Accepted", "column": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047stage$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047stage$047src$047ecs$047column$058recover$1260$({$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047stage$047src$047ecs$047column$058indexed_seek$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047stage$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../stage/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../stage/src/ecs/column.Accepted", "column": ($$$$047stage$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058selected_target$1261$(_namespace_0, _entries_0, _world_0, _slot_0, _current_0, _pending_0) {
  if (_pending_0.$ === "../stage/src/ecs/machine.NoPending") {
    return {$: "../stage/src/ecs/machine-handler-bundle.Returned", "bundle": {$: "../stage/src/ecs/machine-handler-bundle.Bundle", "namespace": _namespace_0, "entries": _entries_0}, "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put$1261$(_world_0, ($$$$047stage$047src$047ecs$047machine$058clear_changed$1261$(_slot_0)))), "status": {$: "../stage/src/ecs/machine-handler-bundle.Completed"}};
  } else {
    const _value_0 = _pending_0["value"];
    const _skipSame_0 = _pending_0["skipSame"];
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058partitioned_run$1261$(_namespace_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put$1261$(_world_0, _slot_0)), {$: "../stage/src/ecs/machine.Scheduled", "value": _value_0, "skipSame": _skipSame_0}, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058partition$1261$(_entries_0, _current_0, _value_0)));
  }
}

function $$$$047stage$047src$047ecs$047world$058drain_fifo$1261$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047stage$047src$047ecs$047world$058drain_fifo$1261$(_rest_0, _world_0)));
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058missing_selected$1261$(_allowed_0, _value_0, _rest_0) {
  if (_allowed_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _value_0, "tail": _rest_0};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058machine_present$1261$(_slot_0) {
  if (_slot_0.$ === "../stage/src/ecs/machine.Missing") {
    return false;
  } else {
    return true;
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058extra_checked$1261$(_world_0, _pair_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _extra_0 = _pair_0["fst"];
  const _allowed_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _allowed_0};
}

function $$$$047stage$047src$047ecs$047system$058complete$1263$(_registry_0, _outcome_0) {
  return {$: "../stage/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058reader_runner$1261$(_world_0, __0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058reader_selected$1261$({$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": ($$$$047stage$047src$047ecs$047machine$045stream$058empty$1260$()), "reader": {$: "None"}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, _reader_0, _stream_0, _ns_0, _tick_0);
}

function $$$$047stage$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047stage$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047stage$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047stage$047src$047ecs$047column$058swapped$1261$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../stage/src/ecs/column.Accepted", "column": {$: "../stage/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047stage$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../stage/src/ecs/column.Rejected", "column": ($$$$047stage$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047stage$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058finished$1260$(_namespace_0, _positions_0, _kept_0, _result_0) {
  if (_result_0.$ === "../stage/src/ecs/machine-handlers.Completed") {
    const _owners_0 = _result_0["owners"];
    const _world_0 = _result_0["world"];
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recovered$1260$(_namespace_0, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recover$1260$(_positions_0, _kept_0, _owners_0)), _world_0, {$: "../stage/src/ecs/machine-handler-bundle.Completed"});
  } else {
    const _owners_1 = _result_0["owners"];
    const _world_1 = _result_0["world"];
    const _phase_0 = _result_0["phase"];
    const _error_0 = _result_0["error"];
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recovered$1260$(_namespace_0, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recover$1260$(_positions_0, _kept_0, _owners_1)), _world_1, {$: "../stage/src/ecs/machine-handler-bundle.HandlerFailed", "phase": _phase_0, "error": _error_0});
  }
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058run$1260$(_owners_0, _world_0, _captured_0) {
  return $$$$047stage$047src$047ecs$047machine$045handlers$058taken$1260$(_owners_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058take$1260$(_world_0)), _captured_0);
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058placed$1260$(_choice_0, _selector_0, _needs_0, _entry_0, _tail_0) {
  if (_choice_0.$ === "../stage/src/ecs/machine-handler-bundle.Kept") {
    const _positions_0 = _tail_0["positions"];
    const _kept_0 = _tail_0["kept"];
    const _owners_0 = _tail_0["owners"];
    return {$: "../stage/src/ecs/machine-handler-bundle.Partition", "positions": {$: "Con", "head": {$: "../stage/src/ecs/machine-handler-bundle.Position", "selector": _selector_0, "requirements": _needs_0, "choice": {$: "../stage/src/ecs/machine-handler-bundle.Kept"}}, "tail": _positions_0}, "kept": {$: "Con", "head": _entry_0, "tail": _kept_0}, "owners": _owners_0};
  } else if (_choice_0.$ === "../stage/src/ecs/machine-handler-bundle.SelectedExit") {
    const _positions_1 = _tail_0["positions"];
    const _kept_1 = _tail_0["kept"];
    const _t_0 = _tail_0["owners"];
    const _exit_0 = _t_0["exit"];
    const _transition_0 = _t_0["transition"];
    const _enter_0 = _t_0["enter"];
    return {$: "../stage/src/ecs/machine-handler-bundle.Partition", "positions": {$: "Con", "head": {$: "../stage/src/ecs/machine-handler-bundle.Position", "selector": _selector_0, "requirements": _needs_0, "choice": {$: "../stage/src/ecs/machine-handler-bundle.SelectedExit"}}, "tail": _positions_1}, "kept": _kept_1, "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": {$: "Con", "head": _entry_0, "tail": _exit_0}, "transition": _transition_0, "enter": _enter_0}};
  } else if (_choice_0.$ === "../stage/src/ecs/machine-handler-bundle.SelectedTransition") {
    const _positions_2 = _tail_0["positions"];
    const _kept_2 = _tail_0["kept"];
    const _t_1 = _tail_0["owners"];
    const _exit_1 = _t_1["exit"];
    const _transition_1 = _t_1["transition"];
    const _enter_1 = _t_1["enter"];
    return {$: "../stage/src/ecs/machine-handler-bundle.Partition", "positions": {$: "Con", "head": {$: "../stage/src/ecs/machine-handler-bundle.Position", "selector": _selector_0, "requirements": _needs_0, "choice": {$: "../stage/src/ecs/machine-handler-bundle.SelectedTransition"}}, "tail": _positions_2}, "kept": _kept_2, "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _exit_1, "transition": {$: "Con", "head": _entry_0, "tail": _transition_1}, "enter": _enter_1}};
  } else {
    const _positions_3 = _tail_0["positions"];
    const _kept_3 = _tail_0["kept"];
    const _t_2 = _tail_0["owners"];
    const _exit_2 = _t_2["exit"];
    const _transition_2 = _t_2["transition"];
    const _enter_2 = _t_2["enter"];
    return {$: "../stage/src/ecs/machine-handler-bundle.Partition", "positions": {$: "Con", "head": {$: "../stage/src/ecs/machine-handler-bundle.Position", "selector": _selector_0, "requirements": _needs_0, "choice": {$: "../stage/src/ecs/machine-handler-bundle.SelectedEnter"}}, "tail": _positions_3}, "kept": _kept_3, "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _exit_2, "transition": _transition_2, "enter": {$: "Con", "head": _entry_0, "tail": _enter_2}}};
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058choose$1260$(_selector_0, _from_0, _to_0) {
  if (_selector_0.$ === "../stage/src/ecs/machine-handler-bundle.ExitFrom") {
    const _value_0 = _selector_0["value"];
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058exit_choice$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047types$058same$(_value_0, _from_0)));
  } else if (_selector_0.$ === "../stage/src/ecs/machine-handler-bundle.TransitionPair") {
    const _old_0 = _selector_0["from"];
    const _new_0 = _selector_0["to"];
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058transition_choice$(($Bool$and$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047types$058same$(_old_0, _from_0)), ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047types$058same$(_new_0, _to_0)))));
  } else {
    const _value_1 = _selector_0["value"];
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058enter_choice$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047types$058same$(_value_1, _to_0)));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058read_missing$1260$(_world_0, _stream_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/system.Failed", "world": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": {$: "None"}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "error": "MissingReader"};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058read_opened$1260$(_world_0, _tick_0, _result_0) {
  if (_result_0.$ === "../stage/src/ecs/machine-stream.ReaderRefused") {
    const _reader_0 = _result_0["reader"];
    const _stream_0 = _result_0["stream"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058read_refused$1260$(_world_0, _reader_0, _stream_0);
  } else {
    const _reader_1 = _result_0["reader"];
    const _stream_1 = _result_0["stream"];
    const _t_0 = _result_0["reading"];
    const _values_0 = _t_0["values"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058read_finished$1260$(_world_0, ($$$$047stage$047src$047ecs$047machine$045stream$058finish$1260$(_reader_1, _stream_1, _tick_0, true)), _values_0);
  }
}

function $$$$047stage$047src$047ecs$047machine$045stream$058open$1260$(_reader_0, _stream_0, _namespace_0, _tick_0) {
  const _owner_0 = _reader_0["namespace"];
  const _id_0 = _reader_0["id"];
  return $$$$047stage$047src$047ecs$047machine$045stream$058open_checked$1260$((_owner_0 === _namespace_0), {$: "../stage/src/ecs/machine-stream.Reader", "namespace": _owner_0, "id": _id_0}, _stream_0, _tick_0);
}

function $$$$047stage$047src$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $$$$047stage$047src$047ecs$047world$058matching_access$(($$$$047stage$047src$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047stage$047src$047ecs$047column$058recover$1260$(_column_0) {
  if (_column_0.$ === "../stage/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../stage/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../stage/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058recover_state$1260$(($$$$047stage$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../stage/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../stage/src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_recover_state$1260$(($$$$047stage$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047stage$047src$047ecs$047column$058seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../stage/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../stage/src/ecs/column.Accepted", "column": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../stage/src/ecs/column.Rejected", "column": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../stage/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../stage/src/ecs/column.Accepted", "column": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../stage/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../stage/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../stage/src/ecs/column.Accepted", "column": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../stage/src/ecs/column.Accepted", "column": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../stage/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../stage/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../stage/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../stage/src/ecs/column.Accepted", "column": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../stage/src/ecs/column.Rejected", "column": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../stage/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../stage/src/ecs/column.Accepted", "column": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../stage/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../stage/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../stage/src/ecs/column.Accepted", "column": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../stage/src/ecs/column.Accepted", "column": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../stage/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../stage/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047machine$058clear_changed$1261$(_slot_0) {
  if (_slot_0.$ === "../stage/src/ecs/machine.Missing") {
    return {$: "../stage/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    return {$: "../stage/src/ecs/machine.Present", "current": _current_0, "pending": _pending_0, "previous": _previous_0, "changed": false};
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058partitioned_run$1261$(_namespace_0, _world_0, _captured_0, _selected_0) {
  const _positions_0 = _selected_0["positions"];
  const _kept_0 = _selected_0["kept"];
  const _owners_0 = _selected_0["owners"];
  return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058finished$1261$(_namespace_0, _positions_0, _kept_0, ($$$$047stage$047src$047ecs$047machine$045handlers$058run$1261$(_owners_0, _world_0, _captured_0)));
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058partition$1261$(_entries_0, _from_0, _to_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "../stage/src/ecs/machine-handler-bundle.Partition", "positions": {$: "Nil"}, "kept": {$: "Nil"}, "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": {$: "Nil"}, "transition": {$: "Nil"}, "enter": {$: "Nil"}}};
  } else {
    const _t_0 = _entries_0["head"];
    const _selector_0 = _t_0["selector"];
    const _needs_0 = _t_0["requirements"];
    const _entry_0 = _t_0["entry"];
    const _tail_0 = _entries_0["tail"];
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058placed$1261$(($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058choose$1261$(_selector_0, _from_0, _to_0)), _selector_0, _needs_0, _entry_0, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058partition$1261$(_tail_0, _from_0, _to_0)));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058reader_selected$1261$(_world_0, _reader_0, _stream_0, _ns_0, _tick_0) {
  if (_reader_0.$ === "None") {
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058read_missing$1261$(_world_0, _stream_0);
  } else {
    const _reader_1 = _reader_0["value"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058read_opened$1261$(_world_0, _tick_0, ($$$$047stage$047src$047ecs$047machine$045stream$058open$1261$(_reader_1, _stream_0, _ns_0, _tick_0)));
  }
}

function $$$$047stage$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../stage/src/ecs/column.Rejected", "column": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../stage/src/ecs/column.Accepted", "column": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047stage$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047stage$047src$047ecs$047column$058recover$1261$({$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047stage$047src$047ecs$047column$058seek$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047stage$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../stage/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../stage/src/ecs/column.Rejected", "column": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../stage/src/ecs/column.Accepted", "column": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047stage$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047stage$047src$047ecs$047column$058recover$1261$({$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047stage$047src$047ecs$047column$058indexed_seek$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047stage$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../stage/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../stage/src/ecs/column.Accepted", "column": ($$$$047stage$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recovered$1260$(_namespace_0, _recovery_0, _world_0, _status_0) {
  const _entries_0 = _recovery_0["entries"];
  const _t_0 = _recovery_0["positions"];
  if (_t_0.$ === "Nil") {
    const _t_1 = _recovery_0["kept"];
    if (_t_1.$ === "Nil") {
      const _t_2 = _recovery_0["owners"];
      const _t_3 = _t_2["exit"];
      if (_t_3.$ === "Nil") {
        const _t_4 = _t_2["transition"];
        if (_t_4.$ === "Nil") {
          const _t_5 = _t_2["enter"];
          if (_t_5.$ === "Nil") {
            return {$: "../stage/src/ecs/machine-handler-bundle.Returned", "bundle": {$: "../stage/src/ecs/machine-handler-bundle.Bundle", "namespace": _namespace_0, "entries": _entries_0}, "world": _world_0, "status": _status_0};
          } else {
            return {$: "../stage/src/ecs/machine-handler-bundle.InternalOwnerRemainder", "namespace": _namespace_0, "recovery": {$: "../stage/src/ecs/machine-handler-bundle.Recovery", "entries": _entries_0, "positions": {$: "Nil"}, "kept": {$: "Nil"}, "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": {$: "Nil"}, "transition": {$: "Nil"}, "enter": _t_5}}, "world": _world_0, "status": _status_0};
          }
        } else {
          const _28_0 = _t_2["enter"];
          return {$: "../stage/src/ecs/machine-handler-bundle.InternalOwnerRemainder", "namespace": _namespace_0, "recovery": {$: "../stage/src/ecs/machine-handler-bundle.Recovery", "entries": _entries_0, "positions": {$: "Nil"}, "kept": {$: "Nil"}, "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": {$: "Nil"}, "transition": _t_4, "enter": _28_0}}, "world": _world_0, "status": _status_0};
        }
      } else {
        const _27_0 = _t_2["transition"];
        const _28_1 = _t_2["enter"];
        return {$: "../stage/src/ecs/machine-handler-bundle.InternalOwnerRemainder", "namespace": _namespace_0, "recovery": {$: "../stage/src/ecs/machine-handler-bundle.Recovery", "entries": _entries_0, "positions": {$: "Nil"}, "kept": {$: "Nil"}, "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _t_3, "transition": _27_0, "enter": _28_1}}, "world": _world_0, "status": _status_0};
      }
    } else {
      const _25_0 = _recovery_0["owners"];
      return {$: "../stage/src/ecs/machine-handler-bundle.InternalOwnerRemainder", "namespace": _namespace_0, "recovery": {$: "../stage/src/ecs/machine-handler-bundle.Recovery", "entries": _entries_0, "positions": {$: "Nil"}, "kept": _t_1, "owners": _25_0}, "world": _world_0, "status": _status_0};
    }
  } else {
    const _24_0 = _recovery_0["kept"];
    const _25_1 = _recovery_0["owners"];
    return {$: "../stage/src/ecs/machine-handler-bundle.InternalOwnerRemainder", "namespace": _namespace_0, "recovery": {$: "../stage/src/ecs/machine-handler-bundle.Recovery", "entries": _entries_0, "positions": _t_0, "kept": _24_0, "owners": _25_1}, "world": _world_0, "status": _status_0};
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recover$1260$(_positions_0, _kept_0, _owners_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "../stage/src/ecs/machine-handler-bundle.Recovery", "entries": {$: "Nil"}, "positions": {$: "Nil"}, "kept": _kept_0, "owners": _owners_0};
  } else {
    const _t_0 = _positions_0["head"];
    const _selector_0 = _t_0["selector"];
    const _needs_0 = _t_0["requirements"];
    const _t_1 = _t_0["choice"];
    if (_t_1.$ === "../stage/src/ecs/machine-handler-bundle.Kept") {
      const _rest_0 = _positions_0["tail"];
      if (_kept_0.$ === "Con") {
        const _head_0 = _kept_0["head"];
        const _tail_0 = _kept_0["tail"];
        return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recovery_join$1260$(_selector_0, _needs_0, _head_0, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recover$1260$(_rest_0, _tail_0, _owners_0)));
      } else {
        return {$: "../stage/src/ecs/machine-handler-bundle.Recovery", "entries": {$: "Nil"}, "positions": {$: "Con", "head": {$: "../stage/src/ecs/machine-handler-bundle.Position", "selector": _selector_0, "requirements": _needs_0, "choice": {$: "../stage/src/ecs/machine-handler-bundle.Kept"}}, "tail": _rest_0}, "kept": _kept_0, "owners": _owners_0};
      }
    } else if (_t_1.$ === "../stage/src/ecs/machine-handler-bundle.SelectedExit") {
      const _rest_1 = _positions_0["tail"];
      const _t_2 = _owners_0["exit"];
      if (_t_2.$ === "Con") {
        const _head_1 = _t_2["head"];
        const _tail_1 = _t_2["tail"];
        const _transition_0 = _owners_0["transition"];
        const _enter_0 = _owners_0["enter"];
        return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recovery_join$1260$(_selector_0, _needs_0, _head_1, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recover$1260$(_rest_1, _kept_0, {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _tail_1, "transition": _transition_0, "enter": _enter_0})));
      } else {
        const _transition_1 = _owners_0["transition"];
        const _enter_1 = _owners_0["enter"];
        return {$: "../stage/src/ecs/machine-handler-bundle.Recovery", "entries": {$: "Nil"}, "positions": {$: "Con", "head": {$: "../stage/src/ecs/machine-handler-bundle.Position", "selector": _selector_0, "requirements": _needs_0, "choice": {$: "../stage/src/ecs/machine-handler-bundle.SelectedExit"}}, "tail": _rest_1}, "kept": _kept_0, "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _t_2, "transition": _transition_1, "enter": _enter_1}};
      }
    } else if (_t_1.$ === "../stage/src/ecs/machine-handler-bundle.SelectedTransition") {
      const _rest_2 = _positions_0["tail"];
      const _exit_0 = _owners_0["exit"];
      const _t_3 = _owners_0["transition"];
      if (_t_3.$ === "Con") {
        const _head_2 = _t_3["head"];
        const _tail_2 = _t_3["tail"];
        const _enter_2 = _owners_0["enter"];
        return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recovery_join$1260$(_selector_0, _needs_0, _head_2, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recover$1260$(_rest_2, _kept_0, {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _tail_2, "enter": _enter_2})));
      } else {
        const _enter_3 = _owners_0["enter"];
        return {$: "../stage/src/ecs/machine-handler-bundle.Recovery", "entries": {$: "Nil"}, "positions": {$: "Con", "head": {$: "../stage/src/ecs/machine-handler-bundle.Position", "selector": _selector_0, "requirements": _needs_0, "choice": {$: "../stage/src/ecs/machine-handler-bundle.SelectedTransition"}}, "tail": _rest_2}, "kept": _kept_0, "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _t_3, "enter": _enter_3}};
      }
    } else {
      const _rest_3 = _positions_0["tail"];
      const _exit_1 = _owners_0["exit"];
      const _transition_2 = _owners_0["transition"];
      const _t_4 = _owners_0["enter"];
      if (_t_4.$ === "Con") {
        const _head_3 = _t_4["head"];
        const _tail_3 = _t_4["tail"];
        return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recovery_join$1260$(_selector_0, _needs_0, _head_3, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recover$1260$(_rest_3, _kept_0, {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _exit_1, "transition": _transition_2, "enter": _tail_3})));
      } else {
        return {$: "../stage/src/ecs/machine-handler-bundle.Recovery", "entries": {$: "Nil"}, "positions": {$: "Con", "head": {$: "../stage/src/ecs/machine-handler-bundle.Position", "selector": _selector_0, "requirements": _needs_0, "choice": {$: "../stage/src/ecs/machine-handler-bundle.SelectedEnter"}}, "tail": _rest_3}, "kept": _kept_0, "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _exit_1, "transition": _transition_2, "enter": _t_4}};
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058taken$1260$(_owners_0, _observed_0, _captured_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return $$$$047stage$047src$047ecs$047machine$045handlers$058prepared$1260$(_owners_0, _world_0, ($$$$047stage$047src$047ecs$047machine$045handlers$058prepare$1260$(_slot_0, _captured_0)));
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058exit_choice$(_yes_0) {
  if (_yes_0) {
    return {$: "../stage/src/ecs/machine-handler-bundle.SelectedExit"};
  } else {
    return {$: "../stage/src/ecs/machine-handler-bundle.Kept"};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047types$058same$(_left_0, _right_0) {
  if (_left_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot") {
    if (_right_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Boot") {
      return true;
    } else {
      return false;
    }
  } else if (_left_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Play") {
    if (_right_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Play") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_right_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Pause") {
      return true;
    } else {
      return false;
    }
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058transition_choice$(_yes_0) {
  if (_yes_0) {
    return {$: "../stage/src/ecs/machine-handler-bundle.SelectedTransition"};
  } else {
    return {$: "../stage/src/ecs/machine-handler-bundle.Kept"};
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058enter_choice$(_yes_0) {
  if (_yes_0) {
    return {$: "../stage/src/ecs/machine-handler-bundle.SelectedEnter"};
  } else {
    return {$: "../stage/src/ecs/machine-handler-bundle.Kept"};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058read_refused$1260$(_world_0, _reader_0, _stream_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/system.Failed", "world": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": {$: "Some", "value": _reader_0}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "error": "ForeignReader"};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058read_finished$1260$(_world_0, _pair_0, _values_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _reader_0 = _pair_0["fst"];
  const _stream_0 = _pair_0["snd"];
  return {$: "../stage/src/ecs/system.Succeeded", "world": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": {$: "Some", "value": _reader_0}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": ($List$append$(_delivered_0, _values_0)), "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "output": {$: "Unit"}};
}

function $$$$047stage$047src$047ecs$047machine$045stream$058finish$1260$(_reader_0, _stream_0, _tick_0, _success_0) {
  const _namespace_0 = _reader_0["namespace"];
  const _id_0 = _reader_0["id"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": _id_0}, "snd": ($$$$047stage$047src$047ecs$047machine$045stream$058complete$1260$(_stream_0, _id_0, _tick_0, _success_0))};
}

function $$$$047stage$047src$047ecs$047machine$045stream$058open_checked$1260$(_allowed_0, _reader_0, _stream_0, _tick_0) {
  if (!_allowed_0) {
    return {$: "../stage/src/ecs/machine-stream.ReaderRefused", "reader": _reader_0, "stream": _stream_0};
  } else {
    const _namespace_0 = _reader_0["namespace"];
    const _id_0 = _reader_0["id"];
    return {$: "../stage/src/ecs/machine-stream.Opened", "reader": {$: "../stage/src/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": _id_0}, "stream": ($$$$047stage$047src$047ecs$047machine$045stream$058activate$1260$(_stream_0, _id_0, _tick_0)), "reading": ($$$$047stage$047src$047ecs$047machine$045stream$058observe$1260$(_stream_0, _id_0, _tick_0))};
  }
}

function $$$$047stage$047src$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $$$$047stage$047src$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047stage$047src$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $$$$047stage$047src$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $$$$047stage$047src$047ecs$047column$058recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047stage$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047stage$047src$047ecs$047column$058indexed_recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047stage$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058finished$1261$(_namespace_0, _positions_0, _kept_0, _result_0) {
  if (_result_0.$ === "../stage/src/ecs/machine-handlers.Completed") {
    const _owners_0 = _result_0["owners"];
    const _world_0 = _result_0["world"];
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recovered$1261$(_namespace_0, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recover$1261$(_positions_0, _kept_0, _owners_0)), _world_0, {$: "../stage/src/ecs/machine-handler-bundle.Completed"});
  } else {
    const _owners_1 = _result_0["owners"];
    const _world_1 = _result_0["world"];
    const _phase_0 = _result_0["phase"];
    const _error_0 = _result_0["error"];
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recovered$1261$(_namespace_0, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recover$1261$(_positions_0, _kept_0, _owners_1)), _world_1, {$: "../stage/src/ecs/machine-handler-bundle.HandlerFailed", "phase": _phase_0, "error": _error_0});
  }
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058run$1261$(_owners_0, _world_0, _captured_0) {
  return $$$$047stage$047src$047ecs$047machine$045handlers$058taken$1261$(_owners_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058take$1261$(_world_0)), _captured_0);
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058placed$1261$(_choice_0, _selector_0, _needs_0, _entry_0, _tail_0) {
  if (_choice_0.$ === "../stage/src/ecs/machine-handler-bundle.Kept") {
    const _positions_0 = _tail_0["positions"];
    const _kept_0 = _tail_0["kept"];
    const _owners_0 = _tail_0["owners"];
    return {$: "../stage/src/ecs/machine-handler-bundle.Partition", "positions": {$: "Con", "head": {$: "../stage/src/ecs/machine-handler-bundle.Position", "selector": _selector_0, "requirements": _needs_0, "choice": {$: "../stage/src/ecs/machine-handler-bundle.Kept"}}, "tail": _positions_0}, "kept": {$: "Con", "head": _entry_0, "tail": _kept_0}, "owners": _owners_0};
  } else if (_choice_0.$ === "../stage/src/ecs/machine-handler-bundle.SelectedExit") {
    const _positions_1 = _tail_0["positions"];
    const _kept_1 = _tail_0["kept"];
    const _t_0 = _tail_0["owners"];
    const _exit_0 = _t_0["exit"];
    const _transition_0 = _t_0["transition"];
    const _enter_0 = _t_0["enter"];
    return {$: "../stage/src/ecs/machine-handler-bundle.Partition", "positions": {$: "Con", "head": {$: "../stage/src/ecs/machine-handler-bundle.Position", "selector": _selector_0, "requirements": _needs_0, "choice": {$: "../stage/src/ecs/machine-handler-bundle.SelectedExit"}}, "tail": _positions_1}, "kept": _kept_1, "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": {$: "Con", "head": _entry_0, "tail": _exit_0}, "transition": _transition_0, "enter": _enter_0}};
  } else if (_choice_0.$ === "../stage/src/ecs/machine-handler-bundle.SelectedTransition") {
    const _positions_2 = _tail_0["positions"];
    const _kept_2 = _tail_0["kept"];
    const _t_1 = _tail_0["owners"];
    const _exit_1 = _t_1["exit"];
    const _transition_1 = _t_1["transition"];
    const _enter_1 = _t_1["enter"];
    return {$: "../stage/src/ecs/machine-handler-bundle.Partition", "positions": {$: "Con", "head": {$: "../stage/src/ecs/machine-handler-bundle.Position", "selector": _selector_0, "requirements": _needs_0, "choice": {$: "../stage/src/ecs/machine-handler-bundle.SelectedTransition"}}, "tail": _positions_2}, "kept": _kept_2, "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _exit_1, "transition": {$: "Con", "head": _entry_0, "tail": _transition_1}, "enter": _enter_1}};
  } else {
    const _positions_3 = _tail_0["positions"];
    const _kept_3 = _tail_0["kept"];
    const _t_2 = _tail_0["owners"];
    const _exit_2 = _t_2["exit"];
    const _transition_2 = _t_2["transition"];
    const _enter_2 = _t_2["enter"];
    return {$: "../stage/src/ecs/machine-handler-bundle.Partition", "positions": {$: "Con", "head": {$: "../stage/src/ecs/machine-handler-bundle.Position", "selector": _selector_0, "requirements": _needs_0, "choice": {$: "../stage/src/ecs/machine-handler-bundle.SelectedEnter"}}, "tail": _positions_3}, "kept": _kept_3, "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _exit_2, "transition": _transition_2, "enter": {$: "Con", "head": _entry_0, "tail": _enter_2}}};
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058choose$1261$(_selector_0, _from_0, _to_0) {
  if (_selector_0.$ === "../stage/src/ecs/machine-handler-bundle.ExitFrom") {
    const _value_0 = _selector_0["value"];
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058exit_choice$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047types$058same$(_value_0, _from_0)));
  } else if (_selector_0.$ === "../stage/src/ecs/machine-handler-bundle.TransitionPair") {
    const _old_0 = _selector_0["from"];
    const _new_0 = _selector_0["to"];
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058transition_choice$(($Bool$and$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047types$058same$(_old_0, _from_0)), ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047types$058same$(_new_0, _to_0)))));
  } else {
    const _value_1 = _selector_0["value"];
    return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058enter_choice$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047types$058same$(_value_1, _to_0)));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058read_missing$1261$(_world_0, _stream_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/system.Failed", "world": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": {$: "None"}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "error": "MissingReader"};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058read_opened$1261$(_world_0, _tick_0, _result_0) {
  if (_result_0.$ === "../stage/src/ecs/machine-stream.ReaderRefused") {
    const _reader_0 = _result_0["reader"];
    const _stream_0 = _result_0["stream"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058read_refused$1261$(_world_0, _reader_0, _stream_0);
  } else {
    const _reader_1 = _result_0["reader"];
    const _stream_1 = _result_0["stream"];
    const _t_0 = _result_0["reading"];
    const _values_0 = _t_0["values"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058read_finished$1261$(_world_0, ($$$$047stage$047src$047ecs$047machine$045stream$058finish$1261$(_reader_1, _stream_1, _tick_0, true)), _values_0);
  }
}

function $$$$047stage$047src$047ecs$047machine$045stream$058open$1261$(_reader_0, _stream_0, _namespace_0, _tick_0) {
  const _owner_0 = _reader_0["namespace"];
  const _id_0 = _reader_0["id"];
  return $$$$047stage$047src$047ecs$047machine$045stream$058open_checked$1261$((_owner_0 === _namespace_0), {$: "../stage/src/ecs/machine-stream.Reader", "namespace": _owner_0, "id": _id_0}, _stream_0, _tick_0);
}

function $$$$047stage$047src$047ecs$047column$058recover$1261$(_column_0) {
  if (_column_0.$ === "../stage/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../stage/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../stage/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058recover_state$1261$(($$$$047stage$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../stage/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../stage/src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_recover_state$1261$(($$$$047stage$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047stage$047src$047ecs$047column$058seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../stage/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../stage/src/ecs/column.Accepted", "column": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../stage/src/ecs/column.Rejected", "column": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../stage/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../stage/src/ecs/column.Accepted", "column": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../stage/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../stage/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../stage/src/ecs/column.Accepted", "column": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../stage/src/ecs/column.Accepted", "column": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../stage/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../stage/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../stage/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../stage/src/ecs/column.Accepted", "column": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../stage/src/ecs/column.Rejected", "column": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../stage/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../stage/src/ecs/column.Accepted", "column": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../stage/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../stage/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../stage/src/ecs/column.Accepted", "column": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../stage/src/ecs/column.Accepted", "column": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../stage/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../stage/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../stage/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recovery_join$1260$(_selector_0, _needs_0, _entry_0, _tail_0) {
  const _entries_0 = _tail_0["entries"];
  const _positions_0 = _tail_0["positions"];
  const _kept_0 = _tail_0["kept"];
  const _owners_0 = _tail_0["owners"];
  return {$: "../stage/src/ecs/machine-handler-bundle.Recovery", "entries": {$: "Con", "head": {$: "../stage/src/ecs/machine-handler-bundle.Scheduled", "selector": _selector_0, "requirements": _needs_0, "entry": _entry_0}, "tail": _entries_0}, "positions": _positions_0, "kept": _kept_0, "owners": _owners_0};
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058prepared$1260$(_owners_0, _world_0, _prepared_0) {
  const _exit_0 = _owners_0["exit"];
  const _transition_0 = _owners_0["transition"];
  const _enter_0 = _owners_0["enter"];
  if (_prepared_0.$ === "../stage/src/ecs/machine-handlers.Idle") {
    const _slot_0 = _prepared_0["slot"];
    return {$: "../stage/src/ecs/machine-handlers.Completed", "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put$1260$(_world_0, _slot_0))};
  } else {
    const _slot_1 = _prepared_0["slot"];
    const _t_0 = _prepared_0["transition"];
    const _from_0 = _t_0["from"];
    const _to_0 = _t_0["to"];
    const _skipSame_0 = _prepared_0["skipSame"];
    return $$$$047stage$047src$047ecs$047machine$045handlers$058after_exit$1260$(_transition_0, _enter_0, ($$$$047stage$047src$047ecs$047machine$045handlers$058run_phase$1260$(_exit_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put$1260$(_world_0, _slot_1)), {$: "../stage/src/ecs/machine-handlers.Exit"}, _from_0, _to_0, {$: "None"})), _from_0, _to_0, _skipSame_0);
  }
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058prepare$1260$(_slot_0, _captured_0) {
  if (_slot_0.$ === "../stage/src/ecs/machine.Missing") {
    if (_captured_0.$ === "../stage/src/ecs/machine.Unscheduled") {
      return {$: "../stage/src/ecs/machine-handlers.Idle", "slot": ($$$$047stage$047src$047ecs$047machine$058clear_changed$1260$({$: "../stage/src/ecs/machine.Missing"}))};
    } else {
      return {$: "../stage/src/ecs/machine-handlers.Idle", "slot": {$: "../stage/src/ecs/machine.Missing"}};
    }
  } else {
    const _current_0 = _slot_0["current"];
    const __2 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const __3 = _slot_0["changed"];
    if (_captured_0.$ === "../stage/src/ecs/machine.Unscheduled") {
      return {$: "../stage/src/ecs/machine-handlers.Idle", "slot": ($$$$047stage$047src$047ecs$047machine$058clear_changed$1260$({$: "../stage/src/ecs/machine.Present", "current": _current_0, "pending": __2, "previous": _previous_0, "changed": __3}))};
    } else {
      const _value_0 = _captured_0["value"];
      const _skipSame_0 = _captured_0["skipSame"];
      return $$$$047stage$047src$047ecs$047machine$045handlers$058choose$1260$(($Bool$and$(_skipSame_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047types$058same$(_current_0, _value_0)))), _current_0, _value_0, _previous_0, _skipSame_0);
    }
  }
}

function $$$$047stage$047src$047ecs$047machine$045stream$058complete$1260$(_stream_0, _id_0, _tick_0, _success_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  if (_success_0) {
    return {$: "../stage/src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": ($$$$047stage$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _tick_0, false)), "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
  } else {
    return {$: "../stage/src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
  }
}

function $$$$047stage$047src$047ecs$047machine$045stream$058activate$1260$(_stream_0, _id_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return {$: "../stage/src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": ($$$$047stage$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _tick_0)), "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $$$$047stage$047src$047ecs$047machine$045stream$058observe$1260$(_stream_0, _id_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  return $$$$047stage$047src$047ecs$047machine$045stream$058observe_position$1260$(($$$$047stage$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _batches_0, _dropped_0, _id_0, _tick_0);
}

function $$$$047stage$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047stage$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047stage$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047stage$047src$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recovered$1261$(_namespace_0, _recovery_0, _world_0, _status_0) {
  const _entries_0 = _recovery_0["entries"];
  const _t_0 = _recovery_0["positions"];
  if (_t_0.$ === "Nil") {
    const _t_1 = _recovery_0["kept"];
    if (_t_1.$ === "Nil") {
      const _t_2 = _recovery_0["owners"];
      const _t_3 = _t_2["exit"];
      if (_t_3.$ === "Nil") {
        const _t_4 = _t_2["transition"];
        if (_t_4.$ === "Nil") {
          const _t_5 = _t_2["enter"];
          if (_t_5.$ === "Nil") {
            return {$: "../stage/src/ecs/machine-handler-bundle.Returned", "bundle": {$: "../stage/src/ecs/machine-handler-bundle.Bundle", "namespace": _namespace_0, "entries": _entries_0}, "world": _world_0, "status": _status_0};
          } else {
            return {$: "../stage/src/ecs/machine-handler-bundle.InternalOwnerRemainder", "namespace": _namespace_0, "recovery": {$: "../stage/src/ecs/machine-handler-bundle.Recovery", "entries": _entries_0, "positions": {$: "Nil"}, "kept": {$: "Nil"}, "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": {$: "Nil"}, "transition": {$: "Nil"}, "enter": _t_5}}, "world": _world_0, "status": _status_0};
          }
        } else {
          const _28_0 = _t_2["enter"];
          return {$: "../stage/src/ecs/machine-handler-bundle.InternalOwnerRemainder", "namespace": _namespace_0, "recovery": {$: "../stage/src/ecs/machine-handler-bundle.Recovery", "entries": _entries_0, "positions": {$: "Nil"}, "kept": {$: "Nil"}, "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": {$: "Nil"}, "transition": _t_4, "enter": _28_0}}, "world": _world_0, "status": _status_0};
        }
      } else {
        const _27_0 = _t_2["transition"];
        const _28_1 = _t_2["enter"];
        return {$: "../stage/src/ecs/machine-handler-bundle.InternalOwnerRemainder", "namespace": _namespace_0, "recovery": {$: "../stage/src/ecs/machine-handler-bundle.Recovery", "entries": _entries_0, "positions": {$: "Nil"}, "kept": {$: "Nil"}, "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _t_3, "transition": _27_0, "enter": _28_1}}, "world": _world_0, "status": _status_0};
      }
    } else {
      const _25_0 = _recovery_0["owners"];
      return {$: "../stage/src/ecs/machine-handler-bundle.InternalOwnerRemainder", "namespace": _namespace_0, "recovery": {$: "../stage/src/ecs/machine-handler-bundle.Recovery", "entries": _entries_0, "positions": {$: "Nil"}, "kept": _t_1, "owners": _25_0}, "world": _world_0, "status": _status_0};
    }
  } else {
    const _24_0 = _recovery_0["kept"];
    const _25_1 = _recovery_0["owners"];
    return {$: "../stage/src/ecs/machine-handler-bundle.InternalOwnerRemainder", "namespace": _namespace_0, "recovery": {$: "../stage/src/ecs/machine-handler-bundle.Recovery", "entries": _entries_0, "positions": _t_0, "kept": _24_0, "owners": _25_1}, "world": _world_0, "status": _status_0};
  }
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recover$1261$(_positions_0, _kept_0, _owners_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "../stage/src/ecs/machine-handler-bundle.Recovery", "entries": {$: "Nil"}, "positions": {$: "Nil"}, "kept": _kept_0, "owners": _owners_0};
  } else {
    const _t_0 = _positions_0["head"];
    const _selector_0 = _t_0["selector"];
    const _needs_0 = _t_0["requirements"];
    const _t_1 = _t_0["choice"];
    if (_t_1.$ === "../stage/src/ecs/machine-handler-bundle.Kept") {
      const _rest_0 = _positions_0["tail"];
      if (_kept_0.$ === "Con") {
        const _head_0 = _kept_0["head"];
        const _tail_0 = _kept_0["tail"];
        return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recovery_join$1261$(_selector_0, _needs_0, _head_0, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recover$1261$(_rest_0, _tail_0, _owners_0)));
      } else {
        return {$: "../stage/src/ecs/machine-handler-bundle.Recovery", "entries": {$: "Nil"}, "positions": {$: "Con", "head": {$: "../stage/src/ecs/machine-handler-bundle.Position", "selector": _selector_0, "requirements": _needs_0, "choice": {$: "../stage/src/ecs/machine-handler-bundle.Kept"}}, "tail": _rest_0}, "kept": _kept_0, "owners": _owners_0};
      }
    } else if (_t_1.$ === "../stage/src/ecs/machine-handler-bundle.SelectedExit") {
      const _rest_1 = _positions_0["tail"];
      const _t_2 = _owners_0["exit"];
      if (_t_2.$ === "Con") {
        const _head_1 = _t_2["head"];
        const _tail_1 = _t_2["tail"];
        const _transition_0 = _owners_0["transition"];
        const _enter_0 = _owners_0["enter"];
        return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recovery_join$1261$(_selector_0, _needs_0, _head_1, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recover$1261$(_rest_1, _kept_0, {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _tail_1, "transition": _transition_0, "enter": _enter_0})));
      } else {
        const _transition_1 = _owners_0["transition"];
        const _enter_1 = _owners_0["enter"];
        return {$: "../stage/src/ecs/machine-handler-bundle.Recovery", "entries": {$: "Nil"}, "positions": {$: "Con", "head": {$: "../stage/src/ecs/machine-handler-bundle.Position", "selector": _selector_0, "requirements": _needs_0, "choice": {$: "../stage/src/ecs/machine-handler-bundle.SelectedExit"}}, "tail": _rest_1}, "kept": _kept_0, "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _t_2, "transition": _transition_1, "enter": _enter_1}};
      }
    } else if (_t_1.$ === "../stage/src/ecs/machine-handler-bundle.SelectedTransition") {
      const _rest_2 = _positions_0["tail"];
      const _exit_0 = _owners_0["exit"];
      const _t_3 = _owners_0["transition"];
      if (_t_3.$ === "Con") {
        const _head_2 = _t_3["head"];
        const _tail_2 = _t_3["tail"];
        const _enter_2 = _owners_0["enter"];
        return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recovery_join$1261$(_selector_0, _needs_0, _head_2, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recover$1261$(_rest_2, _kept_0, {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _tail_2, "enter": _enter_2})));
      } else {
        const _enter_3 = _owners_0["enter"];
        return {$: "../stage/src/ecs/machine-handler-bundle.Recovery", "entries": {$: "Nil"}, "positions": {$: "Con", "head": {$: "../stage/src/ecs/machine-handler-bundle.Position", "selector": _selector_0, "requirements": _needs_0, "choice": {$: "../stage/src/ecs/machine-handler-bundle.SelectedTransition"}}, "tail": _rest_2}, "kept": _kept_0, "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _t_3, "enter": _enter_3}};
      }
    } else {
      const _rest_3 = _positions_0["tail"];
      const _exit_1 = _owners_0["exit"];
      const _transition_2 = _owners_0["transition"];
      const _t_4 = _owners_0["enter"];
      if (_t_4.$ === "Con") {
        const _head_3 = _t_4["head"];
        const _tail_3 = _t_4["tail"];
        return $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recovery_join$1261$(_selector_0, _needs_0, _head_3, ($$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recover$1261$(_rest_3, _kept_0, {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _exit_1, "transition": _transition_2, "enter": _tail_3})));
      } else {
        return {$: "../stage/src/ecs/machine-handler-bundle.Recovery", "entries": {$: "Nil"}, "positions": {$: "Con", "head": {$: "../stage/src/ecs/machine-handler-bundle.Position", "selector": _selector_0, "requirements": _needs_0, "choice": {$: "../stage/src/ecs/machine-handler-bundle.SelectedEnter"}}, "tail": _rest_3}, "kept": _kept_0, "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _exit_1, "transition": _transition_2, "enter": _t_4}};
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058taken$1261$(_owners_0, _observed_0, _captured_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return $$$$047stage$047src$047ecs$047machine$045handlers$058prepared$1261$(_owners_0, _world_0, ($$$$047stage$047src$047ecs$047machine$045handlers$058prepare$1261$(_slot_0, _captured_0)));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058read_refused$1261$(_world_0, _reader_0, _stream_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/system.Failed", "world": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": {$: "Some", "value": _reader_0}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "error": "ForeignReader"};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058read_finished$1261$(_world_0, _pair_0, _values_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _reader_0 = _pair_0["fst"];
  const _stream_0 = _pair_0["snd"];
  return {$: "../stage/src/ecs/system.Succeeded", "world": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": {$: "Some", "value": _reader_0}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": ($List$append$(_delivered_0, _values_0)), "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "output": {$: "Unit"}};
}

function $$$$047stage$047src$047ecs$047machine$045stream$058finish$1261$(_reader_0, _stream_0, _tick_0, _success_0) {
  const _namespace_0 = _reader_0["namespace"];
  const _id_0 = _reader_0["id"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": _id_0}, "snd": ($$$$047stage$047src$047ecs$047machine$045stream$058complete$1260$(_stream_0, _id_0, _tick_0, _success_0))};
}

function $$$$047stage$047src$047ecs$047machine$045stream$058open_checked$1261$(_allowed_0, _reader_0, _stream_0, _tick_0) {
  if (!_allowed_0) {
    return {$: "../stage/src/ecs/machine-stream.ReaderRefused", "reader": _reader_0, "stream": _stream_0};
  } else {
    const _namespace_0 = _reader_0["namespace"];
    const _id_0 = _reader_0["id"];
    return {$: "../stage/src/ecs/machine-stream.Opened", "reader": {$: "../stage/src/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": _id_0}, "stream": ($$$$047stage$047src$047ecs$047machine$045stream$058activate$1260$(_stream_0, _id_0, _tick_0)), "reading": ($$$$047stage$047src$047ecs$047machine$045stream$058observe$1260$(_stream_0, _id_0, _tick_0))};
  }
}

function $$$$047stage$047src$047ecs$047column$058recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047stage$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047stage$047src$047ecs$047column$058indexed_recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047stage$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058after_exit$1260$(_transition_0, _enter_0, _observed_0, _from_0, _to_0, _skipSame_0) {
  if (_observed_0.$ === "../stage/src/ecs/machine-handlers.Failed") {
    const _exit_0 = _observed_0["entries"];
    const _world_0 = _observed_0["world"];
    const _error_0 = _observed_0["error"];
    return {$: "../stage/src/ecs/machine-handlers.Stopped", "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": ($$$$047stage$047src$047ecs$047machine$045handlers$058requeued$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058take$1260$(_world_0)), _to_0, _skipSame_0)), "phase": {$: "../stage/src/ecs/machine-handlers.Exit"}, "error": _error_0};
  } else {
    const _exit_1 = _observed_0["entries"];
    const _world_1 = _observed_0["world"];
    return $$$$047stage$047src$047ecs$047machine$045handlers$058after_transition$1260$(_exit_1, _enter_0, ($$$$047stage$047src$047ecs$047machine$045handlers$058run_phase$1260$(_transition_0, _world_1, {$: "../stage/src/ecs/machine-handlers.Transition"}, _from_0, _to_0, {$: "None"})), _from_0, _to_0, _skipSame_0);
  }
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058run_phase$1260$(_entries_0, _world_0, _phase_0, _from_0, _to_0, _error_0) {
  if (_entries_0.$ === "Nil") {
    if (_error_0.$ === "Some") {
      const _error_1 = _error_0["value"];
      return {$: "../stage/src/ecs/machine-handlers.Failed", "entries": {$: "Nil"}, "world": _world_0, "error": _error_1};
    } else {
      return {$: "../stage/src/ecs/machine-handlers.Complete", "entries": {$: "Nil"}, "world": _world_0};
    }
  } else {
    const _t_0 = _entries_0["head"];
    const _ordinal_0 = _t_0["ordinal"];
    const _registry_0 = _t_0["registry"];
    const _rest_0 = _entries_0["tail"];
    if (_error_0.$ === "Some") {
      const _error_2 = _error_0["value"];
      return {$: "../stage/src/ecs/machine-handlers.Failed", "entries": {$: "Con", "head": {$: "../stage/src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_0}, "tail": _rest_0}, "world": _world_0, "error": _error_2};
    } else {
      return $$$$047stage$047src$047ecs$047machine$045handlers$058entry_result$1260$(_ordinal_0, ($$$$047stage$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, {$: "../stage/src/ecs/machine-handlers.Invocation", "phase": _phase_0, "ordinal": _ordinal_0, "from": _from_0, "to": _to_0})), run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047stage$047src$047ecs$047machine$045handlers$058run_phase$1260$(_rest_0, _x_0, _phase_0, _from_0, _to_0, _x_1);
});
}));
    }
  }
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058choose$1260$(_skip_0, _current_0, _value_0, _previous_0, _skipSame_0) {
  if (_skip_0) {
    return {$: "../stage/src/ecs/machine-handlers.Idle", "slot": {$: "../stage/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../stage/src/ecs/machine.NoPending"}, "previous": _previous_0, "changed": false}};
  } else {
    return {$: "../stage/src/ecs/machine-handlers.Ready", "slot": {$: "../stage/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../stage/src/ecs/machine.NoPending"}, "previous": {$: "Some", "value": _current_0}, "changed": false}, "transition": {$: "../stage/src/ecs/machine.Transition", "from": _current_0, "to": _value_0}, "skipSame": _skipSame_0};
  }
}

function $$$$047stage$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _cursor_0, _dispose_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _positions_0["head"];
    const _actual_0 = _t_0["id"];
    const _old_0 = _t_0["cursor"];
    const _registered_0 = _t_0["registeredAt"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047stage$047src$047ecs$047event$045runtime$058update_checked$((_actual_0 === _id_0), _dispose_0, _actual_0, _old_0, _registered_0, ($$$$047stage$047src$047ecs$047event$045runtime$058update$(_rest_0, _id_0, _cursor_0, _dispose_0)), _cursor_0);
  }
}

function $$$$047stage$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _registered_0) {
  return $$$$047stage$047src$047ecs$047event$045runtime$058activation$(($$$$047stage$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _positions_0, _id_0, _registered_0);
}

function $$$$047stage$047src$047ecs$047machine$045stream$058observe_position$1260$(_position_0, _batches_0, _dropped_0, _id_0, _tick_0) {
  if (_position_0.$ === "None") {
    return $$$$047stage$047src$047ecs$047event$045runtime$058reading$1260$({$: "../stage/src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _tick_0}, _batches_0, _dropped_0);
  } else {
    const _position_1 = _position_0["value"];
    return $$$$047stage$047src$047ecs$047event$045runtime$058reading$1260$(_position_1, _batches_0, _dropped_0);
  }
}

function $$$$047stage$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _position_0 = _positions_0["head"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047stage$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, ($$$$047stage$047src$047ecs$047event$045runtime$058lookup$(_rest_0, _id_0)));
  }
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

function $$$$047stage$047src$047ecs$047machine$045handler$045bundle$058recovery_join$1261$(_selector_0, _needs_0, _entry_0, _tail_0) {
  const _entries_0 = _tail_0["entries"];
  const _positions_0 = _tail_0["positions"];
  const _kept_0 = _tail_0["kept"];
  const _owners_0 = _tail_0["owners"];
  return {$: "../stage/src/ecs/machine-handler-bundle.Recovery", "entries": {$: "Con", "head": {$: "../stage/src/ecs/machine-handler-bundle.Scheduled", "selector": _selector_0, "requirements": _needs_0, "entry": _entry_0}, "tail": _entries_0}, "positions": _positions_0, "kept": _kept_0, "owners": _owners_0};
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058prepared$1261$(_owners_0, _world_0, _prepared_0) {
  const _exit_0 = _owners_0["exit"];
  const _transition_0 = _owners_0["transition"];
  const _enter_0 = _owners_0["enter"];
  if (_prepared_0.$ === "../stage/src/ecs/machine-handlers.Idle") {
    const _slot_0 = _prepared_0["slot"];
    return {$: "../stage/src/ecs/machine-handlers.Completed", "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put$1261$(_world_0, _slot_0))};
  } else {
    const _slot_1 = _prepared_0["slot"];
    const _t_0 = _prepared_0["transition"];
    const _from_0 = _t_0["from"];
    const _to_0 = _t_0["to"];
    const _skipSame_0 = _prepared_0["skipSame"];
    return $$$$047stage$047src$047ecs$047machine$045handlers$058after_exit$1261$(_transition_0, _enter_0, ($$$$047stage$047src$047ecs$047machine$045handlers$058run_phase$1261$(_exit_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put$1261$(_world_0, _slot_1)), {$: "../stage/src/ecs/machine-handlers.Exit"}, _from_0, _to_0, {$: "None"})), _from_0, _to_0, _skipSame_0);
  }
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058prepare$1261$(_slot_0, _captured_0) {
  if (_slot_0.$ === "../stage/src/ecs/machine.Missing") {
    if (_captured_0.$ === "../stage/src/ecs/machine.Unscheduled") {
      return {$: "../stage/src/ecs/machine-handlers.Idle", "slot": ($$$$047stage$047src$047ecs$047machine$058clear_changed$1261$({$: "../stage/src/ecs/machine.Missing"}))};
    } else {
      return {$: "../stage/src/ecs/machine-handlers.Idle", "slot": {$: "../stage/src/ecs/machine.Missing"}};
    }
  } else {
    const _current_0 = _slot_0["current"];
    const __2 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const __3 = _slot_0["changed"];
    if (_captured_0.$ === "../stage/src/ecs/machine.Unscheduled") {
      return {$: "../stage/src/ecs/machine-handlers.Idle", "slot": ($$$$047stage$047src$047ecs$047machine$058clear_changed$1261$({$: "../stage/src/ecs/machine.Present", "current": _current_0, "pending": __2, "previous": _previous_0, "changed": __3}))};
    } else {
      const _value_0 = _captured_0["value"];
      const _skipSame_0 = _captured_0["skipSame"];
      return $$$$047stage$047src$047ecs$047machine$045handlers$058choose$1261$(($Bool$and$(_skipSame_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047types$058same$(_current_0, _value_0)))), _current_0, _value_0, _previous_0, _skipSame_0);
    }
  }
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058requeued$1260$(_observed_0, _to_0, _skipSame_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put$1260$(_world_0, ($$$$047stage$047src$047ecs$047machine$058queue$1260$(_slot_0, _to_0, _skipSame_0)));
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058after_transition$1260$(_exit_0, _enter_0, _observed_0, _from_0, _to_0, _skipSame_0) {
  if (_observed_0.$ === "../stage/src/ecs/machine-handlers.Failed") {
    const _transition_0 = _observed_0["entries"];
    const _world_0 = _observed_0["world"];
    const _error_0 = _observed_0["error"];
    return {$: "../stage/src/ecs/machine-handlers.Stopped", "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": ($$$$047stage$047src$047ecs$047machine$045handlers$058requeued$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058take$1260$(_world_0)), _to_0, _skipSame_0)), "phase": {$: "../stage/src/ecs/machine-handlers.Transition"}, "error": _error_0};
  } else {
    const _transition_1 = _observed_0["entries"];
    const _world_1 = _observed_0["world"];
    return $$$$047stage$047src$047ecs$047machine$045handlers$058after_enter$1260$(_exit_0, _transition_1, ($$$$047stage$047src$047ecs$047machine$045handlers$058run_phase$1260$(_enter_0, ($$$$047stage$047src$047ecs$047machine$045handlers$058published$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058take$1260$(_world_1)), _from_0, _to_0)), {$: "../stage/src/ecs/machine-handlers.Enter"}, _from_0, _to_0, {$: "None"})));
  }
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058entry_result$1260$(_ordinal_0, _observed_0, _next_0) {
  if (_observed_0.$ === "../stage/src/ecs/system.Completed") {
    const _registry_0 = _observed_0["registry"];
    const _outcome_0 = _observed_0["outcome"];
    return $$$$047stage$047src$047ecs$047machine$045handlers$058entry_outcome$1260$(_ordinal_0, _registry_0, _outcome_0, _next_0);
  } else {
    const _registry_1 = _observed_0["registry"];
    const _world_0 = _observed_0["world"];
    return $$$$047stage$047src$047ecs$047machine$045handlers$058prepend$1260$({$: "../stage/src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_1}, _next_0(_world_0)({$: "Some", "value": "HandlerRegistrationRejected"}));
  }
}

function $$$$047stage$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047stage$047src$047ecs$047system$058tracked_result$1260$(($$$$047stage$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0)));
}

function $$$$047stage$047src$047ecs$047event$045runtime$058update_checked$(_found_0, _dispose_0, _id_0, _old_0, _registered_0, _rest_0, _cursor_0) {
  if (!_found_0) {
    return {$: "Con", "head": {$: "../stage/src/ecs/event-runtime.Position", "id": _id_0, "cursor": _old_0, "registeredAt": _registered_0}, "tail": _rest_0};
  } else {
    if (!_dispose_0) {
      return {$: "Con", "head": {$: "../stage/src/ecs/event-runtime.Position", "id": _id_0, "cursor": _cursor_0, "registeredAt": _registered_0}, "tail": _rest_0};
    } else {
      return _rest_0;
    }
  }
}

function $$$$047stage$047src$047ecs$047event$045runtime$058activation$(_position_0, _positions_0, _id_0, _registered_0) {
  if (_position_0.$ === "None") {
    return {$: "Con", "head": {$: "../stage/src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _registered_0}, "tail": _positions_0};
  } else {
    return _positions_0;
  }
}

function $$$$047stage$047src$047ecs$047event$045runtime$058reading$1260$(_position_0, _batches_0, _dropped_0) {
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../stage/src/ecs/event-runtime.Reading", "values": ($$$$047stage$047src$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $$$$047stage$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, _fallback_0) {
  const _actual_0 = _position_0["id"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  return $$$$047stage$047src$047ecs$047event$045runtime$058choose_position$((_actual_0 === _id_0), {$: "../stage/src/ecs/event-runtime.Position", "id": _actual_0, "cursor": _cursor_0, "registeredAt": _registered_0}, _fallback_0);
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058after_exit$1261$(_transition_0, _enter_0, _observed_0, _from_0, _to_0, _skipSame_0) {
  if (_observed_0.$ === "../stage/src/ecs/machine-handlers.Failed") {
    const _exit_0 = _observed_0["entries"];
    const _world_0 = _observed_0["world"];
    const _error_0 = _observed_0["error"];
    return {$: "../stage/src/ecs/machine-handlers.Stopped", "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": ($$$$047stage$047src$047ecs$047machine$045handlers$058requeued$1261$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058take$1261$(_world_0)), _to_0, _skipSame_0)), "phase": {$: "../stage/src/ecs/machine-handlers.Exit"}, "error": _error_0};
  } else {
    const _exit_1 = _observed_0["entries"];
    const _world_1 = _observed_0["world"];
    return $$$$047stage$047src$047ecs$047machine$045handlers$058after_transition$1261$(_exit_1, _enter_0, ($$$$047stage$047src$047ecs$047machine$045handlers$058run_phase$1261$(_transition_0, _world_1, {$: "../stage/src/ecs/machine-handlers.Transition"}, _from_0, _to_0, {$: "None"})), _from_0, _to_0, _skipSame_0);
  }
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058run_phase$1261$(_entries_0, _world_0, _phase_0, _from_0, _to_0, _error_0) {
  if (_entries_0.$ === "Nil") {
    if (_error_0.$ === "Some") {
      const _error_1 = _error_0["value"];
      return {$: "../stage/src/ecs/machine-handlers.Failed", "entries": {$: "Nil"}, "world": _world_0, "error": _error_1};
    } else {
      return {$: "../stage/src/ecs/machine-handlers.Complete", "entries": {$: "Nil"}, "world": _world_0};
    }
  } else {
    const _t_0 = _entries_0["head"];
    const _ordinal_0 = _t_0["ordinal"];
    const _registry_0 = _t_0["registry"];
    const _rest_0 = _entries_0["tail"];
    if (_error_0.$ === "Some") {
      const _error_2 = _error_0["value"];
      return {$: "../stage/src/ecs/machine-handlers.Failed", "entries": {$: "Con", "head": {$: "../stage/src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_0}, "tail": _rest_0}, "world": _world_0, "error": _error_2};
    } else {
      return $$$$047stage$047src$047ecs$047machine$045handlers$058entry_result$1261$(_ordinal_0, ($$$$047stage$047src$047ecs$047system$058run_tracked$1262$(_registry_0, _world_0, {$: "../stage/src/ecs/machine-handlers.Invocation", "phase": _phase_0, "ordinal": _ordinal_0, "from": _from_0, "to": _to_0})), run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047stage$047src$047ecs$047machine$045handlers$058run_phase$1261$(_rest_0, _x_0, _phase_0, _from_0, _to_0, _x_1);
});
}));
    }
  }
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058choose$1261$(_skip_0, _current_0, _value_0, _previous_0, _skipSame_0) {
  if (_skip_0) {
    return {$: "../stage/src/ecs/machine-handlers.Idle", "slot": {$: "../stage/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../stage/src/ecs/machine.NoPending"}, "previous": _previous_0, "changed": false}};
  } else {
    return {$: "../stage/src/ecs/machine-handlers.Ready", "slot": {$: "../stage/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../stage/src/ecs/machine.NoPending"}, "previous": {$: "Some", "value": _current_0}, "changed": false}, "transition": {$: "../stage/src/ecs/machine.Transition", "from": _current_0, "to": _value_0}, "skipSame": _skipSame_0};
  }
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058after_enter$1260$(_exit_0, _transition_0, _observed_0) {
  if (_observed_0.$ === "../stage/src/ecs/machine-handlers.Complete") {
    const _enter_0 = _observed_0["entries"];
    const _world_0 = _observed_0["world"];
    return {$: "../stage/src/ecs/machine-handlers.Completed", "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": _world_0};
  } else {
    const _enter_1 = _observed_0["entries"];
    const _world_1 = _observed_0["world"];
    const _error_0 = _observed_0["error"];
    return {$: "../stage/src/ecs/machine-handlers.Stopped", "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_1}, "world": _world_1, "phase": {$: "../stage/src/ecs/machine-handlers.Enter"}, "error": _error_0};
  }
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058published$1260$(_observed_0, _from_0, _to_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058published$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put$1260$(_world_0, ($$$$047stage$047src$047ecs$047machine$045handlers$058committed$1260$(_slot_0, _from_0, _to_0)))), {$: "../stage/src/ecs/machine.Transition", "from": _from_0, "to": _to_0});
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058entry_outcome$1260$(_ordinal_0, _registry_0, _outcome_0, _next_0) {
  if (_outcome_0.$ === "../stage/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return $$$$047stage$047src$047ecs$047machine$045handlers$058prepend$1260$({$: "../stage/src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_0}, _next_0(_world_0)({$: "Some", "value": _error_0}));
  } else {
    const _world_1 = _outcome_0["world"];
    return $$$$047stage$047src$047ecs$047machine$045handlers$058prepend$1260$({$: "../stage/src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_0}, _next_0(_world_1)({$: "None"}));
  }
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058prepend$1260$(_head_0, _tail_0) {
  if (_tail_0.$ === "../stage/src/ecs/machine-handlers.Complete") {
    const _entries_0 = _tail_0["entries"];
    const _world_0 = _tail_0["world"];
    return {$: "../stage/src/ecs/machine-handlers.Complete", "entries": {$: "Con", "head": _head_0, "tail": _entries_0}, "world": _world_0};
  } else {
    const _entries_1 = _tail_0["entries"];
    const _world_1 = _tail_0["world"];
    const _error_0 = _tail_0["error"];
    return {$: "../stage/src/ecs/machine-handlers.Failed", "entries": {$: "Con", "head": _head_0, "tail": _entries_1}, "world": _world_1, "error": _error_0};
  }
}

function $$$$047stage$047src$047ecs$047system$058tracked_result$1260$(_result_0) {
  if (_result_0.$ === "../stage/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../stage/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047stage$047src$047ecs$047system$058tracked_outcome$1260$(_registry_1, _outcome_0);
  }
}

function $$$$047stage$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047stage$047src$047ecs$047system$058run_namespace$1260$(_registry_0, ($$$$047stage$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047stage$047src$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047stage$047src$047ecs$047event$045runtime$058since_checked$1260$((_cursor_0 < _tick_0), _items_0, ($$$$047stage$047src$047ecs$047event$045runtime$058since$1260$(_rest_0, _cursor_0)));
  }
}

function $$$$047stage$047src$047ecs$047event$045runtime$058choose_position$(_found_0, _position_0, _fallback_0) {
  if (!_found_0) {
    return _fallback_0;
  } else {
    return {$: "Some", "value": _position_0};
  }
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058requeued$1261$(_observed_0, _to_0, _skipSame_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put$1261$(_world_0, ($$$$047stage$047src$047ecs$047machine$058queue$1261$(_slot_0, _to_0, _skipSame_0)));
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058after_transition$1261$(_exit_0, _enter_0, _observed_0, _from_0, _to_0, _skipSame_0) {
  if (_observed_0.$ === "../stage/src/ecs/machine-handlers.Failed") {
    const _transition_0 = _observed_0["entries"];
    const _world_0 = _observed_0["world"];
    const _error_0 = _observed_0["error"];
    return {$: "../stage/src/ecs/machine-handlers.Stopped", "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": ($$$$047stage$047src$047ecs$047machine$045handlers$058requeued$1261$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058take$1261$(_world_0)), _to_0, _skipSame_0)), "phase": {$: "../stage/src/ecs/machine-handlers.Transition"}, "error": _error_0};
  } else {
    const _transition_1 = _observed_0["entries"];
    const _world_1 = _observed_0["world"];
    return $$$$047stage$047src$047ecs$047machine$045handlers$058after_enter$1261$(_exit_0, _transition_1, ($$$$047stage$047src$047ecs$047machine$045handlers$058run_phase$1261$(_enter_0, ($$$$047stage$047src$047ecs$047machine$045handlers$058published$1261$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058take$1261$(_world_1)), _from_0, _to_0)), {$: "../stage/src/ecs/machine-handlers.Enter"}, _from_0, _to_0, {$: "None"})));
  }
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058entry_result$1261$(_ordinal_0, _observed_0, _next_0) {
  if (_observed_0.$ === "../stage/src/ecs/system.Completed") {
    const _registry_0 = _observed_0["registry"];
    const _outcome_0 = _observed_0["outcome"];
    return $$$$047stage$047src$047ecs$047machine$045handlers$058entry_outcome$1261$(_ordinal_0, _registry_0, _outcome_0, _next_0);
  } else {
    const _registry_1 = _observed_0["registry"];
    const _world_0 = _observed_0["world"];
    return $$$$047stage$047src$047ecs$047machine$045handlers$058prepend$1261$({$: "../stage/src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_1}, _next_0(_world_0)({$: "Some", "value": "HandlerRegistrationRejected"}));
  }
}

function $$$$047stage$047src$047ecs$047system$058run_tracked$1262$(_registry_0, _world_0, _args_0) {
  return $$$$047stage$047src$047ecs$047system$058tracked_result$1262$(($$$$047stage$047src$047ecs$047system$058run$1262$(_registry_0, _world_0, _args_0)));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058published$1260$(_world_0, _event_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": ($$$$047stage$047src$047ecs$047machine$045stream$058publish$1260$(_stream_0, _tick_0, _event_0)), "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058committed$1260$(_slot_0, _from_0, _to_0) {
  if (_slot_0.$ === "../stage/src/ecs/machine.Missing") {
    return {$: "../stage/src/ecs/machine.Missing"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return {$: "../stage/src/ecs/machine.Present", "current": _to_0, "pending": _pending_0, "previous": {$: "Some", "value": _from_0}, "changed": true};
  }
}

function $$$$047stage$047src$047ecs$047system$058tracked_outcome$1260$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../stage/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../stage/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../stage/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047stage$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, ($$$$047stage$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047stage$047src$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047stage$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047stage$047src$047ecs$047event$045runtime$058since_checked$1260$(_visible_0, _items_0, _rest_0) {
  if (!_visible_0) {
    return _rest_0;
  } else {
    return $$$$047stage$047src$047ecs$047event$045runtime$058append$1261$(_items_0, _rest_0);
  }
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058after_enter$1261$(_exit_0, _transition_0, _observed_0) {
  if (_observed_0.$ === "../stage/src/ecs/machine-handlers.Complete") {
    const _enter_0 = _observed_0["entries"];
    const _world_0 = _observed_0["world"];
    return {$: "../stage/src/ecs/machine-handlers.Completed", "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": _world_0};
  } else {
    const _enter_1 = _observed_0["entries"];
    const _world_1 = _observed_0["world"];
    const _error_0 = _observed_0["error"];
    return {$: "../stage/src/ecs/machine-handlers.Stopped", "owners": {$: "../stage/src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_1}, "world": _world_1, "phase": {$: "../stage/src/ecs/machine-handlers.Enter"}, "error": _error_0};
  }
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058published$1261$(_observed_0, _from_0, _to_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058published$1261$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put$1261$(_world_0, ($$$$047stage$047src$047ecs$047machine$045handlers$058committed$1261$(_slot_0, _from_0, _to_0)))), {$: "../stage/src/ecs/machine.Transition", "from": _from_0, "to": _to_0});
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058entry_outcome$1261$(_ordinal_0, _registry_0, _outcome_0, _next_0) {
  if (_outcome_0.$ === "../stage/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return $$$$047stage$047src$047ecs$047machine$045handlers$058prepend$1261$({$: "../stage/src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_0}, _next_0(_world_0)({$: "Some", "value": _error_0}));
  } else {
    const _world_1 = _outcome_0["world"];
    return $$$$047stage$047src$047ecs$047machine$045handlers$058prepend$1261$({$: "../stage/src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_0}, _next_0(_world_1)({$: "None"}));
  }
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058prepend$1261$(_head_0, _tail_0) {
  if (_tail_0.$ === "../stage/src/ecs/machine-handlers.Complete") {
    const _entries_0 = _tail_0["entries"];
    const _world_0 = _tail_0["world"];
    return {$: "../stage/src/ecs/machine-handlers.Complete", "entries": {$: "Con", "head": _head_0, "tail": _entries_0}, "world": _world_0};
  } else {
    const _entries_1 = _tail_0["entries"];
    const _world_1 = _tail_0["world"];
    const _error_0 = _tail_0["error"];
    return {$: "../stage/src/ecs/machine-handlers.Failed", "entries": {$: "Con", "head": _head_0, "tail": _entries_1}, "world": _world_1, "error": _error_0};
  }
}

function $$$$047stage$047src$047ecs$047system$058tracked_result$1262$(_result_0) {
  if (_result_0.$ === "../stage/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../stage/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047stage$047src$047ecs$047system$058tracked_outcome$1262$(_registry_1, _outcome_0);
  }
}

function $$$$047stage$047src$047ecs$047system$058run$1262$(_registry_0, _world_0, _args_0) {
  return $$$$047stage$047src$047ecs$047system$058run_namespace$1262$(_registry_0, ($$$$047stage$047src$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $$$$047stage$047src$047ecs$047machine$045stream$058publish$1260$(_stream_0, _tick_0, _event_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return {$: "../stage/src/ecs/machine-stream.Stream", "batches": ($$$$047stage$047src$047ecs$047event$045runtime$058append$1260$(_batches_0, {$: "Con", "head": {$: "../stage/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": {$: "Con", "head": _event_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}})), "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $$$$047stage$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047stage$047src$047ecs$047system$058cursor_outcome$1260$({$: "../stage/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047stage$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047stage$047src$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../stage/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047stage$047src$047ecs$047event$045runtime$058append$1261$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047stage$047src$047ecs$047event$045runtime$058append_loop$1261$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047application$058published$1261$(_world_0, _event_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": ($$$$047stage$047src$047ecs$047machine$045stream$058publish$1260$(_stream_0, _tick_0, _event_0)), "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047src$047ecs$047machine$045handlers$058committed$1261$(_slot_0, _from_0, _to_0) {
  if (_slot_0.$ === "../stage/src/ecs/machine.Missing") {
    return {$: "../stage/src/ecs/machine.Missing"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return {$: "../stage/src/ecs/machine.Present", "current": _to_0, "pending": _pending_0, "previous": {$: "Some", "value": _from_0}, "changed": true};
  }
}

function $$$$047stage$047src$047ecs$047system$058tracked_outcome$1262$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../stage/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../stage/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../stage/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047stage$047src$047ecs$047system$058tracked_clock$1262$(_registry_0, _output_0, ($$$$047stage$047src$047ecs$047world$058clock$1261$(_world_1)));
  }
}

function $$$$047stage$047src$047ecs$047system$058run_namespace$1262$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047stage$047src$047ecs$047system$058run_namespace_value$1262$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047stage$047src$047ecs$047event$045runtime$058append$1260$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047stage$047src$047ecs$047event$045runtime$058append_loop$1260$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047stage$047src$047ecs$047system$058cursor_outcome$1260$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../stage/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../stage/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../stage/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../stage/src/ecs/system.Completed", "registry": {$: "../stage/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../stage/src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047stage$047src$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../stage/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047stage$047src$047ecs$047system$058run_metadata$1260$({$: "../stage/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047stage$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047stage$047src$047ecs$047event$045runtime$058append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047stage$047src$047ecs$047system$058tracked_clock$1262$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047stage$047src$047ecs$047system$058cursor_outcome$1262$({$: "../stage/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047stage$047src$047ecs$047system$058run_namespace_value$1262$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047stage$047src$047ecs$047system$058run_namespace_checked$1262$((_namespace_0 === _actual_0), {$: "../stage/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047stage$047src$047ecs$047event$045runtime$058append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047stage$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047system$058cursor_outcome$1262$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../stage/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../stage/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../stage/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../stage/src/ecs/system.Completed", "registry": {$: "../stage/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../stage/src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047stage$047src$047ecs$047system$058run_namespace_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../stage/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047stage$047src$047ecs$047system$058run_metadata$1262$({$: "../stage/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047stage$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047stage$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../stage/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047stage$047src$047ecs$047system$058complete$1260$(_registry_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058runner$1260$(_world_0, _args_0)));
  }
}

function $$$$047stage$047src$047ecs$047system$058run_metadata$1262$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047stage$047src$047ecs$047system$058run_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047stage$047src$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "../stage/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058runner$1260$(_world_0, _invocation_0) {
  const _phase_0 = _invocation_0["phase"];
  const _ordinal_0 = _invocation_0["ordinal"];
  const _from_0 = _invocation_0["from"];
  const _to_0 = _invocation_0["to"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058invoked$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058attempt_world$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058touch_local$1260$(_world_0, _ordinal_0)), _ordinal_0)), {$: "../stage/src/ecs/machine-handlers.Invocation", "phase": _phase_0, "ordinal": _ordinal_0, "from": _from_0, "to": _to_0});
}

function $$$$047stage$047src$047ecs$047system$058run_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../stage/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047stage$047src$047ecs$047system$058complete$1262$(_registry_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058runner$1261$(_world_0, _args_0)));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058invoked$1260$(_observed_0, _invocation_0) {
  const _world_0 = _observed_0["fst"];
  const _count_0 = _observed_0["snd"];
  const _id_0 = _invocation_0["ordinal"];
  const _to_0 = _invocation_0["to"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058invoked_failure$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058failure$1260$(_world_0)), _id_0, _count_0, _to_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058attempt_world$1260$(_world_0, _id_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058attempt_world_join$1260$({$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": {$: "Nil"}, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058attempts$(_locals_0, _ns_0, _id_0)));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058touch_local$1260$(_world_0, _id_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058locals_increment$(_locals_0, _ns_0, _id_0)), "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047src$047ecs$047system$058complete$1262$(_registry_0, _outcome_0) {
  return {$: "../stage/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058runner$1261$(_world_0, _invocation_0) {
  const _phase_0 = _invocation_0["phase"];
  const _ordinal_0 = _invocation_0["ordinal"];
  const _from_0 = _invocation_0["from"];
  const _to_0 = _invocation_0["to"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058invoked$1261$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058attempt_world$1261$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058touch_local$1261$(_world_0, _ordinal_0)), _ordinal_0)), {$: "../stage/src/ecs/machine-handlers.Invocation", "phase": _phase_0, "ordinal": _ordinal_0, "from": _from_0, "to": _to_0});
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058invoked_failure$1260$(_observed_0, _id_0, _count_0, _to_0) {
  const _world_0 = _observed_0["fst"];
  const _selected_0 = _observed_0["snd"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058maybe_entered$1260$(_id_0, _to_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058gameplay$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058attempt_logged$1260$(_world_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058handler_name$(_id_0)))), ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058amount$(_id_0)), ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058handler_name$(_id_0)), ($Bool$and$((_selected_0 === _id_0), (_count_0 === 1))))));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058failure$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _failureId_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058attempt_world_join$1260$(_world_0, _pair_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _locals_0 = _pair_0["fst"];
  const _count_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _count_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058attempts$(_items_0, _namespace_0, _id_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _t_0 = _items_0["head"];
    const _owner_0 = _t_0["namespace"];
    const _key_0 = _t_0["id"];
    const _cell_0 = _t_0["cell"];
    const _rest_0 = _items_0["tail"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058attempt_selected$(($Bool$and$((_owner_0 === _namespace_0), (_key_0 === _id_0))), _owner_0, _key_0, _cell_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058attempts$(_rest_0, _namespace_0, _id_0)));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058locals_increment$(_items_0, _namespace_0, _id_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _items_0["head"];
    const _owner_0 = _t_0["namespace"];
    const _key_0 = _t_0["id"];
    const _cell_0 = _t_0["cell"];
    const _rest_0 = _items_0["tail"];
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058local_selected$(($Bool$and$((_owner_0 === _namespace_0), (_key_0 === _id_0))), _owner_0, _key_0, _cell_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058locals_increment$(_rest_0, _namespace_0, _id_0)));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058invoked$1261$(_observed_0, _invocation_0) {
  const _world_0 = _observed_0["fst"];
  const _count_0 = _observed_0["snd"];
  const _id_0 = _invocation_0["ordinal"];
  const _to_0 = _invocation_0["to"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058invoked_failure$1261$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058failure$1261$(_world_0)), _id_0, _count_0, _to_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058attempt_world$1261$(_world_0, _id_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058attempt_world_join$1261$({$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": {$: "Nil"}, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058attempts$(_locals_0, _ns_0, _id_0)));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058touch_local$1261$(_world_0, _id_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058locals_increment$(_locals_0, _ns_0, _id_0)), "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058maybe_entered$1260$(_id_0, _to_0, _result_0) {
  if (_id_0 == 1) {
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058entered$1260$(_to_0, _result_0);
  } else {
    return _result_0;
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058gameplay$1260$(_world_0, _amount_0, _name_0, _fail_0) {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058finished$1260$(run_loop($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058gameplay_body$({$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/systems.Work", "resource": {$: "../stage/src/ecs/capabilities.ValueWrite", "get": run_clo((_x_0) => {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_tx_read$1260$(_x_0);
}), "set": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_tx_write$1260$(_x_1, _x_2);
});
})}, "component": {$: "../stage/src/ecs/capabilities.Action", "run": run_clo((_x_3) => {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058change_component$1260$(_x_3, _amount_0);
})}, "deferred": {$: "../stage/src/ecs/capabilities.Action", "run": run_clo((_x_4) => {
  return $$$$047stage$047src$047ecs$047transaction$058stage$1260$(_x_4, run_clo((_x_5) => {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058structural$1260$(_x_5);
}));
})}}, ($$$$047stage$047src$047ecs$047transaction$058begin$1260$(_world_0)), _amount_0)), _name_0, _fail_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058attempt_logged$1260$(_world_0, _name_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _log_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": ($List$append$(_log_0, {$: "Con", "head": _name_0, "tail": {$: "Nil"}}))}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058handler_name$(_id_0) {
  if (_id_0 == 1) {
    return "enterPlay1";
  } else if ((_id_0 & 7) == 1) {
    return "unknown";
  } else if (_id_0 == 5) {
    return "exitBoot1";
  } else if ((_id_0 & 7) == 5) {
    return "unknown";
  } else if (_id_0 == 3) {
    return "transitionBootPause";
  } else if ((_id_0 & 7) == 3) {
    return "unknown";
  } else if (_id_0 == 7) {
    return "enterPause";
  } else if ((_id_0 & 7) == 7) {
    return "unknown";
  } else if (_id_0 == 2) {
    return "exitBoot0";
  } else if ((_id_0 & 7) == 2) {
    return "unknown";
  } else if (_id_0 == 6) {
    return "transitionBootPlay";
  } else if ((_id_0 & 7) == 6) {
    return "unknown";
  } else if (_id_0 == 4) {
    return "enterPlay0";
  } else if ((_id_0 & 7) == 4) {
    return "unknown";
  } else if (_id_0 == 8) {
    return "inactiveExitPause";
  } else {
    return "unknown";
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058attempt_selected$(_yes_0, _namespace_0, _id_0, _cell_0, _tail_0) {
  if (!_yes_0) {
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058attempt_join$({$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.LocalOwner", "namespace": _namespace_0, "id": _id_0, "cell": _cell_0}, _tail_0);
  } else {
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058attempt_observed$(_namespace_0, _id_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058local_count$(_cell_0)), _tail_0);
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058local_selected$(_yes_0, _namespace_0, _id_0, _cell_0, _rest_0) {
  if (_yes_0) {
    return {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.LocalOwner", "namespace": _namespace_0, "id": _id_0, "cell": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058local_increment$(_cell_0))}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.LocalOwner", "namespace": _namespace_0, "id": _id_0, "cell": _cell_0}, "tail": _rest_0};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058invoked_failure$1261$(_observed_0, _id_0, _count_0, _to_0) {
  const _world_0 = _observed_0["fst"];
  const _selected_0 = _observed_0["snd"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058maybe_entered$1261$(_id_0, _to_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058gameplay$1261$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058attempt_logged$1261$(_world_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058handler_name$(_id_0)))), ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058amount$(_id_0)), ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058handler_name$(_id_0)), ($Bool$and$((_selected_0 === _id_0), (_count_0 === 1))))));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058failure$1261$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _failureId_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058attempt_world_join$1261$(_world_0, _pair_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _locals_0 = _pair_0["fst"];
  const _count_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _count_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058entered$1260$(_to_0, _result_0) {
  if (_to_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Play") {
    if (_result_0.$ === "../stage/src/ecs/system.Succeeded") {
      const _world_0 = _result_0["world"];
      const _output_0 = _result_0["output"];
      return {$: "../stage/src/ecs/system.Succeeded", "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058queue_join$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058take$1260$(_world_0)))), "output": _output_0};
    } else {
      return _result_0;
    }
  } else {
    return _result_0;
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058finished$1260$(_tx_0, _name_0, _fail_0) {
  if (_fail_0) {
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058committed_prefix$1260$(_name_0, ($$$$047stage$047src$047ecs$047transaction$058finish$1260$(_tx_0, {$: "../stage/src/ecs/transaction.Failure", "error": "once"})));
  } else {
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058committed_prefix$1260$(_name_0, ($$$$047stage$047src$047ecs$047transaction$058finish$1260$(_tx_0, {$: "../stage/src/ecs/transaction.Success"})));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058gameplay_body$(_caps_0, _owner_0, _amount_0) {
  const _resource_0 = _caps_0["resource"];
  const _component_0 = _caps_0["component"];
  const _deferred_0 = _caps_0["deferred"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058act$(run_loop($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058act$(run_loop($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058gameplay_write$(_resource_0, _owner_0, _amount_0)), _component_0)), _deferred_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_tx_read$1260$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _undo_0 = _frame_0["undo"];
  const _commands_0 = _frame_0["commands"];
  const _events_0 = _frame_0["events"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_tx_read_join$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_read$1260$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_tx_write$1260$(_frame_0, _amount_0) {
  const _world_0 = _frame_0["world"];
  const _undo_0 = _frame_0["undo"];
  const _commands_0 = _frame_0["commands"];
  const _events_0 = _frame_0["events"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_tx_join$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058change_resource$1260$(_world_0, _amount_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058change_component$1260$(_tx_0, _amount_0) {
  const _t_0 = _tx_0["world"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["nextId"];
  const _high_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _capacity_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _t_1 = _t_0["store"];
  const _column_0 = _t_1["column"];
  const _resources_0 = _t_0["resource"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSystem_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _emitted_0 = _tx_0["events"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058component_stamp$1260$({$: "../stage/src/ecs/transaction.Tx", "world": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Store", "column": {$: "../stage/src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}}}, "resource": _resources_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "undo": _undo_0, "commands": _commands_0, "events": _emitted_0}, ($$$$047stage$047src$047ecs$047column$058lifecycle$1260$(_column_0, 1)), _amount_0, _clock_0);
}

function $$$$047stage$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../stage/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058structural$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": ((_applied_0 + 1) >>> 0), "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../stage/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058attempt_join$(_head_0, _tail_0) {
  const _rest_0 = _tail_0["fst"];
  const _value_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_0, "tail": _rest_0}, "snd": _value_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058attempt_observed$(_namespace_0, _id_0, _observed_0, _tail_0) {
  const _cell_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  const _rest_0 = _tail_0["fst"];
  return {$: "Tuple", "fst": {$: "Con", "head": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.LocalOwner", "namespace": _namespace_0, "id": _id_0, "cell": _cell_0}, "tail": _rest_0}, "snd": _value_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058local_increment$(_cell_0) {
  const _owner_0 = _cell_0["local"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058local_incremented$(($$$$047stage$047src$047ecs$047local$058projected$1260$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058increment$(_owner_0, 1)))));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058maybe_entered$1261$(_id_0, _to_0, _result_0) {
  if (_id_0 == 1) {
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058entered$1261$(_to_0, _result_0);
  } else {
    return _result_0;
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058gameplay$1261$(_world_0, _amount_0, _name_0, _fail_0) {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058finished$1261$(run_loop($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058gameplay_body$({$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/systems.Work", "resource": {$: "../stage/src/ecs/capabilities.ValueWrite", "get": run_clo((_x_0) => {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_tx_read$1261$(_x_0);
}), "set": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_tx_write$1261$(_x_1, _x_2);
});
})}, "component": {$: "../stage/src/ecs/capabilities.Action", "run": run_clo((_x_3) => {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058change_component$1261$(_x_3, _amount_0);
})}, "deferred": {$: "../stage/src/ecs/capabilities.Action", "run": run_clo((_x_4) => {
  return $$$$047stage$047src$047ecs$047transaction$058stage$1261$(_x_4, run_clo((_x_5) => {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058structural$1261$(_x_5);
}));
})}}, ($$$$047stage$047src$047ecs$047transaction$058begin$1261$(_world_0)), _amount_0)), _name_0, _fail_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058attempt_logged$1261$(_world_0, _name_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _log_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": ($List$append$(_log_0, {$: "Con", "head": _name_0, "tail": {$: "Nil"}}))}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058queue_join$1260$(_pair_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put$1260$(_world_0, ($$$$047stage$047src$047ecs$047machine$058queue$1260$(_slot_0, {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Pause"}, false)));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058committed_prefix$1260$(_name_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../stage/src/ecs/transaction.Failure") {
    const _error_0 = _t_0["error"];
    return {$: "../stage/src/ecs/system.Failed", "world": _world_0, "error": _error_0};
  } else {
    return {$: "../stage/src/ecs/system.Succeeded", "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058prefix$1260$(_world_0, _name_0)), "output": {$: "Unit"}};
  }
}

function $$$$047stage$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047stage$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058act$(_owner_0, _cap_0) {
  const _apply_0 = _cap_0["run"];
  return run_tail(_apply_0, _owner_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058gameplay_write$(_cap_0, _owner_0, _amount_0) {
  const _write_0 = _cap_0["set"];
  return run_tail(_write_0(_owner_0), _amount_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_tx_read_join$1260$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _value_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_read$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_read_world$1260$({$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": [0], "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, {$: "Tuple", fst: _owned_0, snd: _owned_0[0 % _owned_0.length]});
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_tx_join$1260$(_changed_0, _oldUndo_0, _oldCommands_0, _oldEvents_0) {
  const _world_0 = _changed_0["world"];
  const _undo_0 = _changed_0["undo"];
  return {$: "../stage/src/ecs/transaction.Tx", "world": _world_0, "undo": ($List$append$(_undo_0, _oldUndo_0)), "commands": _oldCommands_0, "events": _oldEvents_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058change_resource$1260$(_world_0, _amount_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_changed$1260$({$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": [0], "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058increment$(_owned_0, _amount_0)));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058component_stamp$1260$(_tx_0, _pair_0, _amount_0, _clock_0) {
  const _column_0 = _pair_0["fst"];
  const _stamp_0 = _pair_0["snd"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058component_written$1260$(_tx_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058changed_taken$1260$(($$$$047stage$047src$047ecs$047column$058swap$1260$(_column_0, 1, {$: "None"})), _amount_0)), _stamp_0, _clock_0);
}

function $$$$047stage$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../stage/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047stage$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../stage/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, ($$$$047stage$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../stage/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, ($$$$047stage$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, ($$$$047stage$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058local_incremented$(_pair_0) {
  const _cell_0 = _pair_0["fst"];
  return _cell_0;
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058increment$(_owner_0, _amount_0) {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058projected$({$: "Tuple", fst: _owner_0, snd: _owner_0[0 % _owner_0.length]}, _amount_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058entered$1261$(_to_0, _result_0) {
  if (_to_0.$ === "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Play") {
    if (_result_0.$ === "../stage/src/ecs/system.Succeeded") {
      const _world_0 = _result_0["world"];
      const _output_0 = _result_0["output"];
      return {$: "../stage/src/ecs/system.Succeeded", "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058queue_join$1261$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058take$1261$(_world_0)))), "output": _output_0};
    } else {
      return _result_0;
    }
  } else {
    return _result_0;
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058finished$1261$(_tx_0, _name_0, _fail_0) {
  if (_fail_0) {
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058committed_prefix$1261$(_name_0, ($$$$047stage$047src$047ecs$047transaction$058finish$1261$(_tx_0, {$: "../stage/src/ecs/transaction.Failure", "error": "once"})));
  } else {
    return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058committed_prefix$1261$(_name_0, ($$$$047stage$047src$047ecs$047transaction$058finish$1261$(_tx_0, {$: "../stage/src/ecs/transaction.Success"})));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_tx_read$1261$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _undo_0 = _frame_0["undo"];
  const _commands_0 = _frame_0["commands"];
  const _events_0 = _frame_0["events"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_tx_read_join$1261$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_read$1261$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_tx_write$1261$(_frame_0, _amount_0) {
  const _world_0 = _frame_0["world"];
  const _undo_0 = _frame_0["undo"];
  const _commands_0 = _frame_0["commands"];
  const _events_0 = _frame_0["events"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_tx_join$1261$(($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058change_resource$1261$(_world_0, _amount_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058change_component$1261$(_tx_0, _amount_0) {
  const _t_0 = _tx_0["world"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["nextId"];
  const _high_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _capacity_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _t_1 = _t_0["store"];
  const _column_0 = _t_1["column"];
  const _resources_0 = _t_0["resource"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSystem_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _emitted_0 = _tx_0["events"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058component_stamp$1261$({$: "../stage/src/ecs/transaction.Tx", "world": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Store", "column": {$: "../stage/src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}}}, "resource": _resources_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "undo": _undo_0, "commands": _commands_0, "events": _emitted_0}, ($$$$047stage$047src$047ecs$047column$058lifecycle$1261$(_column_0, 1)), _amount_0, _clock_0);
}

function $$$$047stage$047src$047ecs$047transaction$058stage$1261$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../stage/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058structural$1261$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": ((_applied_0 + 1) >>> 0), "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047src$047ecs$047transaction$058begin$1261$(_world_0) {
  return {$: "../stage/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058prefix$1260$(_world_0, _name_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prior_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": ($List$append$(_prior_0, {$: "Con", "head": _name_0, "tail": {$: "Nil"}})), "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../stage/src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../stage/src/ecs/transaction.Returned", "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058discard_unit_events$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../stage/src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../stage/src/ecs/transaction.Returned", "world": ($$$$047stage$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../stage/src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_read_world$1260$(_world_0, _pair_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _owned_0 = _pair_0["fst"];
  const _value_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_changed$1260$(_world_0, _pair_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _owned_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return $$$$047stage$047src$047ecs$047transaction$058add_undo$1260$(($$$$047stage$047src$047ecs$047transaction$058begin$1260$({$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0})), run_clo((_x_0) => {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058restore_resource$1260$(_x_0, _old_0);
}));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058component_written$1260$(_tx_0, _pair_0, _stamp_0, _oldClock_0) {
  const _t_0 = _tx_0["world"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["nextId"];
  const _high_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _capacity_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _resources_0 = _t_0["resource"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSystem_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _emitted_0 = _tx_0["events"];
  const _column_0 = _pair_0["fst"];
  const _t_1 = _pair_0["snd"];
  if (_t_1.$ === "Some") {
    const _old_0 = _t_1["value"];
    return $$$$047stage$047src$047ecs$047transaction$058add_undo$1260$({$: "../stage/src/ecs/transaction.Tx", "world": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Store", "column": ($$$$047stage$047src$047ecs$047column$058mark$1260$(_column_0, 1, true, true, ((_clock_0 + 1) >>> 0)))}, "resource": _resources_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": ((_clock_0 + 1) >>> 0)}, "undo": _undo_0, "commands": _commands_0, "events": _emitted_0}, run_clo((_x_0) => {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058restore_component$1260$(_x_0, _old_0, _stamp_0, _oldClock_0);
}));
  } else {
    return {$: "../stage/src/ecs/transaction.Tx", "world": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Store", "column": _column_0}, "resource": _resources_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "undo": _undo_0, "commands": _commands_0, "events": _emitted_0};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058changed_taken$1260$(_result_0, _amount_0) {
  if (_result_0.$ === "../stage/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _t_0 = _result_0["previous"];
    if (_t_0.$ === "Some") {
      const _owner_0 = _t_0["value"];
      return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058changed_owner$1260$(_column_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058increment$(_owner_0, _amount_0)));
    } else {
      return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
    }
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047stage$047src$047ecs$047lifecycle$058get$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "../stage/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047stage$047src$047ecs$047lifecycle$058choose$((_key_0 === _id_0), _stamp_0, ($$$$047stage$047src$047ecs$047lifecycle$058get$(_rest_0, _id_0)));
  }
}

function $$$$047stage$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047stage$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047stage$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047stage$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, ($$$$047stage$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047stage$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047stage$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058projected$(_pair_0, _amount_0) {
  const _owner_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  const _x_0 = ((_old_0 + _amount_0) >>> 0);
  return {$: "Tuple", "fst": (_owner_0[0 % _owner_0.length] = _x_0, _owner_0), "snd": _old_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058queue_join$1261$(_pair_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047world$058put$1261$(_world_0, ($$$$047stage$047src$047ecs$047machine$058queue$1261$(_slot_0, {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Pause"}, false)));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058committed_prefix$1261$(_name_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../stage/src/ecs/transaction.Failure") {
    const _error_0 = _t_0["error"];
    return {$: "../stage/src/ecs/system.Failed", "world": _world_0, "error": _error_0};
  } else {
    return {$: "../stage/src/ecs/system.Succeeded", "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058prefix$1261$(_world_0, _name_0)), "output": {$: "Unit"}};
  }
}

function $$$$047stage$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047stage$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_tx_read_join$1261$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _value_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_read$1261$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_read_world$1261$({$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": [0], "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, {$: "Tuple", fst: _owned_0, snd: _owned_0[0 % _owned_0.length]});
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_tx_join$1261$(_changed_0, _oldUndo_0, _oldCommands_0, _oldEvents_0) {
  const _world_0 = _changed_0["world"];
  const _undo_0 = _changed_0["undo"];
  return {$: "../stage/src/ecs/transaction.Tx", "world": _world_0, "undo": ($List$append$(_undo_0, _oldUndo_0)), "commands": _oldCommands_0, "events": _oldEvents_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058change_resource$1261$(_world_0, _amount_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_changed$1261$({$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": [0], "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058increment$(_owned_0, _amount_0)));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058component_stamp$1261$(_tx_0, _pair_0, _amount_0, _clock_0) {
  const _column_0 = _pair_0["fst"];
  const _stamp_0 = _pair_0["snd"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058component_written$1261$(_tx_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058changed_taken$1261$(($$$$047stage$047src$047ecs$047column$058swap$1261$(_column_0, 1, {$: "None"})), _amount_0)), _stamp_0, _clock_0);
}

function $$$$047stage$047src$047ecs$047column$058lifecycle$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../stage/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047stage$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../stage/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058lifecycle_state$1261$(_id_0, ($$$$047stage$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../stage/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_lifecycle_state$1261$(_id_0, ($$$$047stage$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1261$(_id_0, ($$$$047stage$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058enqueue$1260$(_world_0, _commands_0) {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058enqueue_all$1260$(_commands_0, _world_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058discard_unit_events$1260$(_world_0, __0) {
  return _world_0;
}

function $$$$047stage$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047transaction$058add_undo$1260$(_tx_0, _inverse_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../stage/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": _inverse_0, "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058restore_resource$1260$(_world_0, _value_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": (_owned_0[0 % _owned_0.length] = _value_0, _owned_0), "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../stage/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../stage/src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047stage$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047stage$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047stage$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../stage/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047stage$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../stage/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047stage$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047stage$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058restore_component$1260$(_world_0, _value_0, _stamp_0, _oldClock_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _t_0 = _world_0["store"];
  const _column_0 = _t_0["column"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058restore_component_result$1260$({$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Store", "column": {$: "../stage/src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}}}, "resource": _resources_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058restore_taken$1260$(($$$$047stage$047src$047ecs$047column$058swap$1260$(_column_0, 1, {$: "None"})), _value_0)), _stamp_0, _oldClock_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058changed_owner$1260$(_column_0, _pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058restored_swap$1260$(($$$$047stage$047src$047ecs$047column$058swap$1260$(_column_0, 1, {$: "Some", "value": _owner_0})))), "snd": {$: "Some", "value": _old_0}};
}

function $$$$047stage$047src$047ecs$047lifecycle$058choose$(_found_0, _stamp_0, _other_0) {
  if (_found_0) {
    return _stamp_0;
  } else {
    return _other_0;
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047stage$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047stage$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047stage$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047stage$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)), (_id_0 <= _capacity_0));
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058prefix$1261$(_world_0, _name_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prior_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": ($List$append$(_prior_0, {$: "Con", "head": _name_0, "tail": {$: "Nil"}})), "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../stage/src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058enqueue$1261$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../stage/src/ecs/transaction.Returned", "world": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058discard_unit_events$1261$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../stage/src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../stage/src/ecs/transaction.Returned", "world": ($$$$047stage$047src$047ecs$047transaction$058rollback$1261$(_undo_0, _world_0)), "outcome": {$: "../stage/src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_read_world$1261$(_world_0, _pair_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _owned_0 = _pair_0["fst"];
  const _value_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058resource_changed$1261$(_world_0, _pair_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _owned_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return $$$$047stage$047src$047ecs$047transaction$058add_undo$1261$(($$$$047stage$047src$047ecs$047transaction$058begin$1261$({$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0})), run_clo((_x_0) => {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058restore_resource$1261$(_x_0, _old_0);
}));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058component_written$1261$(_tx_0, _pair_0, _stamp_0, _oldClock_0) {
  const _t_0 = _tx_0["world"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["nextId"];
  const _high_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _capacity_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _resources_0 = _t_0["resource"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSystem_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _emitted_0 = _tx_0["events"];
  const _column_0 = _pair_0["fst"];
  const _t_1 = _pair_0["snd"];
  if (_t_1.$ === "Some") {
    const _old_0 = _t_1["value"];
    return $$$$047stage$047src$047ecs$047transaction$058add_undo$1261$({$: "../stage/src/ecs/transaction.Tx", "world": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Store", "column": ($$$$047stage$047src$047ecs$047column$058mark$1261$(_column_0, 1, true, true, ((_clock_0 + 1) >>> 0)))}, "resource": _resources_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": ((_clock_0 + 1) >>> 0)}, "undo": _undo_0, "commands": _commands_0, "events": _emitted_0}, run_clo((_x_0) => {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058restore_component$1261$(_x_0, _old_0, _stamp_0, _oldClock_0);
}));
  } else {
    return {$: "../stage/src/ecs/transaction.Tx", "world": {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Store", "column": _column_0}, "resource": _resources_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "undo": _undo_0, "commands": _commands_0, "events": _emitted_0};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058changed_taken$1261$(_result_0, _amount_0) {
  if (_result_0.$ === "../stage/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _t_0 = _result_0["previous"];
    if (_t_0.$ === "Some") {
      const _owner_0 = _t_0["value"];
      return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058changed_owner$1261$(_column_0, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058increment$(_owner_0, _amount_0)));
    } else {
      return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
    }
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047stage$047src$047ecs$047column$058lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047stage$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047stage$047src$047ecs$047column$058indexed_lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047stage$047src$047ecs$047column$058indexed_lifecycle_got$1261$(_values_0, ($$$$047stage$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047stage$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1261$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047stage$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058enqueue_all$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047stage$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047lifecycle$058set$(_entries_0, _id_0, _stamp_0) {
  return {$: "Con", "head": {$: "../stage/src/ecs/lifecycle.Entry", "id": _id_0, "stamp": _stamp_0}, "tail": ($$$$047stage$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0))};
}

function $$$$047stage$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0) {
  if (!_incoming_0) {
    return {$: "../stage/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    return $$$$047stage$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0);
  }
}

function $$$$047stage$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": ($$$$047stage$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047stage$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047stage$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047stage$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047stage$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047stage$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047stage$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047stage$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058restore_component_result$1260$(_world_0, _pair_0, _stamp_0, _oldClock_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _column_0 = _pair_0["fst"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Store", "column": ($$$$047stage$047src$047ecs$047column$058restore_stamp$1260$(_column_0, 1, _stamp_0))}, "resource": _resources_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _oldClock_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058restore_taken$1260$(_result_0, _value_0) {
  if (_result_0.$ === "../stage/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _t_0 = _result_0["previous"];
    if (_t_0.$ === "Some") {
      const _owner_0 = _t_0["value"];
      return {$: "Tuple", "fst": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058restored_swap$1260$(($$$$047stage$047src$047ecs$047column$058swap$1260$(_column_0, 1, {$: "Some", "value": (_owner_0[0 % _owner_0.length] = _value_0, _owner_0)})))), "snd": {$: "Some", "value": {$: "Unit"}}};
    } else {
      return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
    }
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058restored_swap$1260$(_result_0) {
  if (_result_0.$ === "../stage/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return _column_0;
  } else {
    const _column_1 = _result_0["column"];
    return _column_1;
  }
}

function $$$$047stage$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0, _fits_0) {
  if (!_isnormal_0) {
    return {$: "Tuple", "fst": {$: "../stage/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": ($$$$047stage$047src$047ecs$047lifecycle$058get$(_exceptional_0, _id_0))};
  } else {
    if (!_fits_0) {
      return {$: "Tuple", "fst": {$: "../stage/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../stage/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
    } else {
      const _x_0 = ((_id_0 - 1) >>> 0);
      return $$$$047stage$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, {$: "Tuple", fst: _added_0, snd: _added_0[_x_0 % _added_0.length]});
    }
  }
}

function $$$$047stage$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0) {
  return $Bool$and$((_id_0 > 0), (_id_0 <= 131072));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058enqueue$1261$(_world_0, _commands_0) {
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058enqueue_all$1261$(_commands_0, _world_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058discard_unit_events$1261$(_world_0, __0) {
  return _world_0;
}

function $$$$047stage$047src$047ecs$047transaction$058rollback$1261$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047transaction$058add_undo$1261$(_tx_0, _inverse_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../stage/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": _inverse_0, "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058restore_resource$1261$(_world_0, _value_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _extra_0 = _t_0["extra"];
  const _failureId_0 = _t_0["failureId"];
  const _attemptLog_0 = _t_0["attemptLog"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Resources", "owned": (_owned_0[0 % _owned_0.length] = _value_0, _owned_0), "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0, "extra": _extra_0, "failureId": _failureId_0, "attemptLog": _attemptLog_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047stage$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../stage/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../stage/src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047stage$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047stage$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047stage$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../stage/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047stage$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../stage/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047stage$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047stage$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058restore_component$1261$(_world_0, _value_0, _stamp_0, _oldClock_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _t_0 = _world_0["store"];
  const _column_0 = _t_0["column"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058restore_component_result$1261$({$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Store", "column": {$: "../stage/src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}}}, "resource": _resources_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058restore_taken$1261$(($$$$047stage$047src$047ecs$047column$058swap$1261$(_column_0, 1, {$: "None"})), _value_0)), _stamp_0, _oldClock_0);
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058changed_owner$1261$(_column_0, _pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058restored_swap$1261$(($$$$047stage$047src$047ecs$047column$058swap$1261$(_column_0, 1, {$: "Some", "value": _owner_0})))), "snd": {$: "Some", "value": _old_0}};
}

function $$$$047stage$047src$047ecs$047column$058indexed_lifecycle_got$1261$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047stage$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1261$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047stage$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047stage$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047stage$047src$047ecs$047lifecycle$058keep$((_key_0 === _id_0), {$: "../stage/src/ecs/lifecycle.Entry", "id": _key_0, "stamp": _stamp_0}, ($$$$047stage$047src$047ecs$047lifecycle$058clear$(_rest_0, _id_0)));
  }
}

function $$$$047stage$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0) {
  if (!_wasPresent_0) {
    return {$: "../stage/src/ecs/lifecycle.Stamp", "added": _tick_0, "changed": _tick_0};
  } else {
    const _added_0 = _stamp_0["added"];
    return {$: "../stage/src/ecs/lifecycle.Stamp", "added": _added_0, "changed": _tick_0};
  }
}

function $$$$047stage$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047stage$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047stage$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047stage$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047stage$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047stage$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047stage$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../stage/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../stage/src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047stage$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../stage/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, ($$$$047stage$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../stage/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, ($$$$047stage$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, ($$$$047stage$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047stage$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _observed_0) {
  const _added_0 = _observed_0["fst"];
  const _first_0 = _observed_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return $$$$047stage$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, {$: "Tuple", fst: _changed_0, snd: _changed_0[_x_0 % _changed_0.length]});
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058enqueue_all$1261$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047stage$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": ($$$$047stage$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047stage$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047stage$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047stage$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047stage$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047stage$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047stage$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047stage$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058restore_component_result$1261$(_world_0, _pair_0, _stamp_0, _oldClock_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _column_0 = _pair_0["fst"];
  return {$: "../stage/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "../stage/experiments/public-machine-handlers/candidate-v1/bundle-v1/types.Store", "column": ($$$$047stage$047src$047ecs$047column$058restore_stamp$1261$(_column_0, 1, _stamp_0))}, "resource": _resources_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _oldClock_0};
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058restore_taken$1261$(_result_0, _value_0) {
  if (_result_0.$ === "../stage/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _t_0 = _result_0["previous"];
    if (_t_0.$ === "Some") {
      const _owner_0 = _t_0["value"];
      return {$: "Tuple", "fst": ($$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058restored_swap$1261$(($$$$047stage$047src$047ecs$047column$058swap$1261$(_column_0, 1, {$: "Some", "value": (_owner_0[0 % _owner_0.length] = _value_0, _owner_0)})))), "snd": {$: "Some", "value": {$: "Unit"}}};
    } else {
      return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
    }
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047stage$047experiments$047public$045machine$045handlers$047candidate$045v1$047bundle$045v1$047systems$058restored_swap$1261$(_result_0) {
  if (_result_0.$ === "../stage/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return _column_0;
  } else {
    const _column_1 = _result_0["column"];
    return _column_1;
  }
}

function $$$$047stage$047src$047ecs$047lifecycle$058keep$(_equal_0, _entry_0, _rest_0) {
  if (_equal_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _entry_0, "tail": _rest_0};
  }
}

function $$$$047stage$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047stage$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047stage$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)));
}

function $$$$047stage$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": ($$$$047stage$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047stage$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047stage$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047stage$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047stage$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047stage$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, _observed_0) {
  const _changed_0 = _observed_0["fst"];
  const _last_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../stage/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../stage/src/ecs/lifecycle.Stamp", "added": _first_0, "changed": _last_0}};
}

function $$$$047stage$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../stage/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047stage$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047stage$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047stage$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047stage$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047stage$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047stage$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047stage$047src$047ecs$047column$058restore_stamp$1261$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../stage/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../stage/src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047stage$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../stage/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058restore_state$1261$(_id_0, _stamp_0, ($$$$047stage$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../stage/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_restore_state$1261$(_id_0, _stamp_0, ($$$$047stage$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047stage$047src$047ecs$047column$058indexed_prepared_restore_state$1261$(_id_0, _stamp_0, ($$$$047stage$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047stage$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0) {
  if (!_isnormal_0) {
    return {$: "../stage/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": ($$$$047stage$047src$047ecs$047lifecycle$058set$(_exceptional_0, _id_0, _stamp_0))};
  } else {
    return $$$$047stage$047src$047ecs$047indexed$045lifecycle$058write_grow$(17, _id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, (_id_0 <= _capacity_0));
  }
}

function $$$$047stage$047src$047ecs$047column$058restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../stage/src/ecs/column.Prepared", "state": {$: "../stage/src/ecs/column.Owned", "state": {$: "../stage/src/ecs/column.State", "values": _values_0, "stamps": ($$$$047stage$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047stage$047src$047ecs$047column$058indexed_restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047stage$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047stage$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047stage$047src$047ecs$047column$058indexed_prepared_restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../stage/src/ecs/column.PreparedIndexed", "state": {$: "../stage/src/ecs/column.IndexedPreparedOwned", "state": {$: "../stage/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047stage$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047stage$047src$047ecs$047indexed$045lifecycle$058write_grow$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _id_0 = $1;
      const _stamp_0 = $2;
      const _added_0 = $3;
      const _changed_0 = $4;
      const _capacity_0 = $5;
      const _depth_0 = $6;
      const _exceptional_0 = $7;
      const _fits_0 = $8;
      if (_fuel_0 === 0) {
        if (_fits_0) {
          return $$$$047stage$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          return {$: "../stage/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_fits_0) {
          return $$$$047stage$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          const _next_0 = ((_capacity_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _stamp_0;
          $3 = array_node(_added_0, array_new(_depth_0, 0));
          $4 = array_node(_changed_0, array_new(_depth_0, 0));
          $5 = _next_0;
          $6 = nat_chk(_depth_0 + 1);
          $7 = _exceptional_0;
          $8 = (_id_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047stage$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0) {
  const _first_0 = _stamp_0["added"];
  const _last_0 = _stamp_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = ((_id_0 - 1) >>> 0);
  return {$: "../stage/src/ecs/indexed-lifecycle.Metadata", "added": (_added_0[_x_0 % _added_0.length] = _first_0, _added_0), "changed": (_changed_0[_x_1 % _changed_0.length] = _last_0, _changed_0), "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
}

const TAB_0 = [0, 1000, 1, 20, 100, 10, 30, 200, 10000, 0];
// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);