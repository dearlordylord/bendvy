"""Coordinator-authorized blocking lock shim; frozen subject runner unchanged."""
import fcntl
import runpy
import sys
from pathlib import Path

sys.dont_write_bytecode = True
original = fcntl.flock

def queued(fd, flags):
    if getattr(fd, 'name', None) == '/tmp/bendvy-parity-heavy.lock' and flags == fcntl.LOCK_EX | fcntl.LOCK_NB:
        flags = fcntl.LOCK_EX
    return original(fd, flags)

fcntl.flock = queued
h = Path(__file__).resolve().parents[2]
runner = h / 'run-handler-helper-lost-exit-a-diagnostic.py'
plan = h / 'development/handler-helper-lost-exit-a-diagnostic-1791428738577520584/plan.json'
sys.argv = [str(runner), '--run', str(plan)]
runpy.run_path(str(runner), run_name='__main__')
