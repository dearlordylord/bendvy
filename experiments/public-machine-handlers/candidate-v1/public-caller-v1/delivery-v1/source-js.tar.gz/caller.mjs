function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058registration_equal$(_id_0, _name_0, _access_0, _otherId_0, _otherName_0, _otherAccess_0) {
  return $Bool$and$((_id_0 === _otherId_0), ($Bool$and$(($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_name_0, _otherName_0)), ($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058access_equal$(_access_0, _otherAccess_0)))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$() {
  return {$: "../../../../src/ecs/world.Factory", "nextNamespace": 1};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "../../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047$$$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_access$(($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058choose$(_found_0, _stamp_0, _other_0) {
  if (_found_0) {
    return _stamp_0;
  } else {
    return _other_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "../../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058choose$((_key_0 === _id_0), _stamp_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058keep$(_equal_0, _entry_0, _rest_0) {
  if (_equal_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _entry_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058keep$((_key_0 === _id_0), {$: "../../../../src/ecs/lifecycle.Entry", "id": _key_0, "stamp": _stamp_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_entries_0, _id_0, _stamp_0) {
  return {$: "Con", "head": {$: "../../../../src/ecs/lifecycle.Entry", "id": _id_0, "stamp": _stamp_0}, "tail": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0) {
  if (!_wasPresent_0) {
    return {$: "../../../../src/ecs/lifecycle.Stamp", "added": _tick_0, "changed": _tick_0};
  } else {
    const _added_0 = _stamp_0["added"];
    return {$: "../../../../src/ecs/lifecycle.Stamp", "added": _added_0, "changed": _tick_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0) {
  if (!_incoming_0) {
    return {$: "../../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058added$(_stamp_0, _cursor_0) {
  const _value_0 = _stamp_0["added"];
  return (_value_0 > _cursor_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058changed$(_stamp_0, _cursor_0) {
  const _value_0 = _stamp_0["changed"];
  return (_value_0 > _cursor_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058selected$(_selection_0, _flag_0) {
  if (_selection_0.$ === "../../../../src/ecs/owner-handoff.Present") {
    if (_flag_0.$ === "None") {
      return false;
    } else {
      return true;
    }
  } else if (_selection_0.$ === "../../../../src/ecs/owner-handoff.Absent") {
    if (_flag_0.$ === "Some") {
      return false;
    } else {
      return true;
    }
  } else {
    return true;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_restore_state$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "../../../../src/ecs/owner-handoff.PrototypeHandoffState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _owner_0 = _t_0["value"];
    return {$: "../../../../src/ecs/owner-handoff.PrototypeHandoffState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _values_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_inspect_state$(_id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0) {
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "None"};
  return $$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_restore_state$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, array_rmw(_main_0, _x_0, () => _x_1));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_finish_forward$(_capacity_0, _depth_0, _high_0, _state_0) {
  const _main_0 = _state_0["main"];
  const _aux_0 = _state_0["aux"];
  const _live_0 = _state_0["live"];
  const _flags_0 = _state_0["flags"];
  const _added_0 = _state_0["added"];
  const _changed_0 = _state_0["changed"];
  const _values_0 = _state_0["values"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/owner-handoff.Rows", "main": _main_0, "aux": _aux_0, "metadata": {$: "../../../../src/ecs/owner-handoff.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": _values_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_recover_go$($0, $1, $2) {
  for (;;) {
    {
      const _rows_0 = $0;
      const _columns_0 = $1;
      const _ids_0 = $2;
      if (_rows_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
        return {$: "Tuple", "fst": _columns_0, "snd": ($List$reverse$(_ids_0))};
      } else {
        const _id_0 = _rows_0["id"];
        const _owner_0 = _rows_0["owner"];
        const _rest_0 = _rows_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        const _x_1 = {$: "Some", "value": _owner_0};
        $0 = _rest_0;
        $1 = (_columns_0[_x_0 % _columns_0.length] = _x_1, _columns_0);
        $2 = {$: "Con", "head": _id_0, "tail": _ids_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_recover$(_rows_0, _columns_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_recover_go$(_rows_0, _columns_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058empty$() {
  return {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": [0], "changed": [0], "capacity": 1, "depth": 0, "exceptional": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0) {
  return $Bool$and$((_id_0 > 0), (_id_0 <= 131072));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, _observed_0) {
  const _changed_0 = _observed_0["fst"];
  const _last_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../../../../src/ecs/lifecycle.Stamp", "added": _first_0, "changed": _last_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _observed_0) {
  const _added_0 = _observed_0["fst"];
  const _first_0 = _observed_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, {$: "Tuple", fst: _changed_0, snd: _changed_0[_x_0 % _changed_0.length]});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0, _fits_0) {
  if (!_isnormal_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_exceptional_0, _id_0))};
  } else {
    if (!_fits_0) {
      return {$: "Tuple", "fst": {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
    } else {
      const _x_0 = ((_id_0 - 1) >>> 0);
      return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, {$: "Tuple", fst: _added_0, snd: _added_0[_x_0 % _added_0.length]});
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)), (_id_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0) {
  const _first_0 = _stamp_0["added"];
  const _last_0 = _stamp_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = ((_id_0 - 1) >>> 0);
  return {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": (_added_0[_x_0 % _added_0.length] = _first_0, _added_0), "changed": (_changed_0[_x_1 % _changed_0.length] = _last_0, _changed_0), "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_grow$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _id_0 = $1;
      const _stamp_0 = $2;
      const _added_0 = $3;
      const _changed_0 = $4;
      const _capacity_0 = $5;
      const _depth_0 = $6;
      const _exceptional_0 = $7;
      const _fits_0 = $8;
      if (_fuel_0 === 0) {
        if (_fits_0) {
          return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          return {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_fits_0) {
          return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          const _next_0 = ((_capacity_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _stamp_0;
          $3 = array_node(_added_0, array_new(_depth_0, 0));
          $4 = array_node(_changed_0, array_new(_depth_0, 0));
          $5 = _next_0;
          $6 = nat_chk(_depth_0 + 1);
          $7 = _exceptional_0;
          $8 = (_id_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0) {
  if (!_isnormal_0) {
    return {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_exceptional_0, _id_0, _stamp_0))};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_grow$(17, _id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, (_id_0 <= _capacity_0));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0, _fits_0) {
  if (!_isnormal_0) {
    return {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_exceptional_0, _id_0))};
  } else {
    if (!_fits_0) {
      return {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, {$: "../../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0});
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)), (_id_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$($0, $1) {
  for (;;) {
    {
      const _rows_0 = $0;
      const _values_0 = $1;
      if (_rows_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
        return _values_0;
      } else {
        const _id_0 = _rows_0["id"];
        const _owner_0 = _rows_0["owner"];
        const _rest_0 = _rows_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        const _x_1 = {$: "Some", "value": _owner_0};
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _x_1, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047registration$058retained$(_keep_0, _meta_0, _rest_0) {
  if (_keep_0) {
    return {$: "Con", "head": _meta_0, "tail": _rest_0};
  } else {
    return _rest_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047registration$058without$(_registrations_0, _id_0, _name_0, _access_0) {
  if (_registrations_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _meta_0 = _registrations_0["head"];
    const _rest_0 = _registrations_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047registration$058retained$(($Bool$not$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0)))), _meta_0, ($$$$047$$$047$$$047$$$047src$047ecs$047registration$058without$(_rest_0, _id_0, _name_0, _access_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058hold_boundary$($0, $1) {
  for (;;) {
    {
      const _positions_0 = $0;
      const _boundary_0 = $1;
      if (_positions_0.$ === "Nil") {
        return _boundary_0;
      } else {
        const _t_0 = _positions_0["head"];
        const _cursor_0 = _t_0["cursor"];
        const _rest_0 = _positions_0["tail"];
        $0 = _rest_0;
        $1 = (_boundary_0 < _cursor_0 ? _boundary_0 : _cursor_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update_checked$(_found_0, _dispose_0, _id_0, _old_0, _registered_0, _rest_0, _cursor_0) {
  if (!_found_0) {
    return {$: "Con", "head": {$: "../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": _old_0, "registeredAt": _registered_0}, "tail": _rest_0};
  } else {
    if (!_dispose_0) {
      return {$: "Con", "head": {$: "../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": _cursor_0, "registeredAt": _registered_0}, "tail": _rest_0};
    } else {
      return _rest_0;
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _cursor_0, _dispose_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _positions_0["head"];
    const _actual_0 = _t_0["id"];
    const _old_0 = _t_0["cursor"];
    const _registered_0 = _t_0["registeredAt"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update_checked$((_actual_0 === _id_0), _dispose_0, _actual_0, _old_0, _registered_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_rest_0, _id_0, _cursor_0, _dispose_0)), _cursor_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058choose_position$(_found_0, _position_0, _fallback_0) {
  if (!_found_0) {
    return _fallback_0;
  } else {
    return {$: "Some", "value": _position_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, _fallback_0) {
  const _actual_0 = _position_0["id"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058choose_position$((_actual_0 === _id_0), {$: "../../../../src/ecs/event-runtime.Position", "id": _actual_0, "cursor": _cursor_0, "registeredAt": _registered_0}, _fallback_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _position_0 = _positions_0["head"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activation$(_position_0, _positions_0, _id_0, _registered_0) {
  if (_position_0.$ === "None") {
    return {$: "Con", "head": {$: "../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _registered_0}, "tail": _positions_0};
  } else {
    return _positions_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _registered_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activation$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _positions_0, _id_0, _registered_0);
}

function $types$058same$(_left_0, _right_0) {
  if (_left_0.$ === "types.Boot") {
    if (_right_0.$ === "types.Boot") {
      return true;
    } else {
      return false;
    }
  } else if (_left_0.$ === "types.Play") {
    if (_right_0.$ === "types.Play") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_right_0.$ === "types.Pause") {
      return true;
    } else {
      return false;
    }
  }
}

function $systems$058projected$(_pair_0, _amount_0) {
  const _owner_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  const _x_0 = ((_old_0 + _amount_0) >>> 0);
  return {$: "Tuple", "fst": (_owner_0[0 % _owner_0.length] = _x_0, _owner_0), "snd": _old_0};
}

function $systems$058increment$(_owner_0, _amount_0) {
  return $systems$058projected$({$: "Tuple", fst: _owner_0, snd: _owner_0[0 % _owner_0.length]}, _amount_0);
}

function $systems$058local_incremented$(_pair_0) {
  const _cell_0 = _pair_0["fst"];
  return _cell_0;
}

function $systems$058local_increment$(_cell_0) {
  const _owner_0 = _cell_0["local"];
  return $systems$058local_incremented$(($$$$047$$$047$$$047$$$047src$047ecs$047local$058projected$1260$(($systems$058increment$(_owner_0, 1)))));
}

function $systems$058local_join$(_head_0, _tail_0) {
  return {$: "Con", "head": _head_0, "tail": _tail_0};
}

function $systems$058local_selected$(_yes_0, _namespace_0, _id_0, _cell_0, _rest_0) {
  if (_yes_0) {
    return {$: "Con", "head": {$: "types.LocalOwner", "namespace": _namespace_0, "id": _id_0, "cell": ($systems$058local_increment$(_cell_0))}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "types.LocalOwner", "namespace": _namespace_0, "id": _id_0, "cell": _cell_0}, "tail": _rest_0};
  }
}

function $systems$058locals_increment$(_items_0, _namespace_0, _id_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _items_0["head"];
    const _owner_0 = _t_0["namespace"];
    const _key_0 = _t_0["id"];
    const _cell_0 = _t_0["cell"];
    const _rest_0 = _items_0["tail"];
    return $systems$058local_selected$(($Bool$and$((_owner_0 === _namespace_0), (_key_0 === _id_0))), _owner_0, _key_0, _cell_0, ($systems$058locals_increment$(_rest_0, _namespace_0, _id_0)));
  }
}

function $systems$058set_value$(_owner_0, _value_0) {
  return {$: "Tuple", "fst": (_owner_0[0 % _owner_0.length] = _value_0, _owner_0), "snd": {$: "Unit"}};
}

function $systems$058local_count_value$(_pair_0) {
  return _pair_0;
}

function $systems$058local_count$(_cell_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047local$058read_cell$1260$(_cell_0);
}

function $systems$058attempt_join$(_head_0, _tail_0) {
  const _rest_0 = _tail_0["fst"];
  const _value_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_0, "tail": _rest_0}, "snd": _value_0};
}

function $systems$058attempt_observed$(_namespace_0, _id_0, _observed_0, _tail_0) {
  const _cell_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  const _rest_0 = _tail_0["fst"];
  return {$: "Tuple", "fst": {$: "Con", "head": {$: "types.LocalOwner", "namespace": _namespace_0, "id": _id_0, "cell": _cell_0}, "tail": _rest_0}, "snd": _value_0};
}

function $systems$058attempt_selected$(_yes_0, _namespace_0, _id_0, _cell_0, _tail_0) {
  if (!_yes_0) {
    return $systems$058attempt_join$({$: "types.LocalOwner", "namespace": _namespace_0, "id": _id_0, "cell": _cell_0}, _tail_0);
  } else {
    return $systems$058attempt_observed$(_namespace_0, _id_0, ($systems$058local_count$(_cell_0)), _tail_0);
  }
}

function $systems$058attempts$(_items_0, _namespace_0, _id_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _t_0 = _items_0["head"];
    const _owner_0 = _t_0["namespace"];
    const _key_0 = _t_0["id"];
    const _cell_0 = _t_0["cell"];
    const _rest_0 = _items_0["tail"];
    return $systems$058attempt_selected$(($Bool$and$((_owner_0 === _namespace_0), (_key_0 === _id_0))), _owner_0, _key_0, _cell_0, ($systems$058attempts$(_rest_0, _namespace_0, _id_0)));
  }
}

function $state$(_value_0) {
  if (_value_0.$ === "types.Boot") {
    return "\"Boot\"";
  } else if (_value_0.$ === "types.Play") {
    return "\"Play\"";
  } else {
    return "\"Pause\"";
  }
}

function $bool$(_value_0) {
  if (!_value_0) {
    return "false";
  } else {
    return "true";
  }
}

function $previous$(_value_0) {
  if (_value_0.$ === "None") {
    return "null";
  } else {
    const _value_1 = _value_0["value"];
    return $state$(_value_1);
  }
}

function $pending$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/machine.NoPending") {
    return "null";
  } else {
    const _value_1 = _value_0["value"];
    return $state$(_value_1);
  }
}

function $quote$(_text_0) {
  const _x_0 = (_text_0 + "\"");
  return ("\"" + _x_0);
}

function $transition$(_event_0) {
  const _from_0 = _event_0["from"];
  const _to_0 = _event_0["to"];
  const _x_0 = ($state$(_to_0));
  const _x_1 = (_x_0 + "]");
  const _x_2 = ($state$(_from_0));
  const _x_3 = ("," + _x_1);
  const _x_4 = (_x_2 + _x_3);
  return ("[" + _x_4);
}

function $array_second$(_first_0, _pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _last_0 = _pair_0["snd"];
  const _x_0 = ($U32$show$(_last_0));
  const _x_1 = (_x_0 + "]");
  const _x_2 = ($U32$show$(_first_0));
  const _x_3 = ("," + _x_1);
  const _x_4 = (_x_2 + _x_3);
  return {$: "Tuple", "fst": _owner_0, "snd": ("[" + _x_4)};
}

function $array_first$(_pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _first_0 = _pair_0["snd"];
  return $array_second$(_first_0, {$: "Tuple", fst: _owner_0, snd: _owner_0[1 % _owner_0.length]});
}

function $array$(_owner_0) {
  return $array_first$({$: "Tuple", fst: _owner_0, snd: _owner_0[0 % _owner_0.length]});
}

function $locals_join$(_head_0, _value_0, _tail_0) {
  const _rest_0 = _tail_0["fst"];
  const _values_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_0, "tail": _rest_0}, "snd": {$: "Con", "head": _value_0, "tail": _values_0}};
}

function $local_observed$(_ns_0, _id_0, _pair_0, _tail_0) {
  const _cell_0 = _pair_0["fst"];
  const _value_0 = _pair_0["snd"];
  return $locals_join$({$: "types.LocalOwner", "namespace": _ns_0, "id": _id_0, "cell": _cell_0}, _value_0, _tail_0);
}

function $locals$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _t_0 = _items_0["head"];
    const _ns_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _cell_0 = _t_0["cell"];
    const _rest_0 = _items_0["tail"];
    return $local_observed$(_ns_0, _id_0, ($systems$058local_count$(_cell_0)), ($locals$(_rest_0)));
  }
}

function $batch_values$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _items_0["head"];
    const _values_0 = _t_0["values"];
    const _rest_0 = _items_0["tail"];
    return $List$append$(_values_0, ($batch_values$(_rest_0)));
  }
}

function $batch_ticks$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _items_0["head"];
    const _tick_0 = _t_0["tick"];
    const _rest_0 = _items_0["tail"];
    return {$: "Con", "head": _tick_0, "tail": ($batch_ticks$(_rest_0))};
  }
}

function $position$(_items_0) {
  if (_items_0.$ === "Nil") {
    return "null";
  } else {
    const _t_0 = _items_0["head"];
    const _cursor_0 = _t_0["cursor"];
    const _at_0 = _t_0["registeredAt"];
    const _x_0 = ($Nat$show$(_at_0));
    const _x_1 = (_x_0 + "}");
    const _x_2 = ($Nat$show$(_cursor_0));
    const _x_3 = (",\"registeredAt\":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("{\"cursor\":" + _x_4);
  }
}

function $after_a$(_name_0, _result_0) {
  if (_result_0.$ === "application.ConstructionRefused") {
    return "{\"error\":\"FirstConstructionRefused\"}";
  } else {
    const _factory_0 = _result_0["factory"];
    return $constructed$1260$(_name_0, ($application$058create$1260$(_factory_0)));
  }
}

function $A_initial$() {
  return $constructed$1261$("initial", ($application$058create$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()))));
}

function $A_failed$() {
  return $constructed$1261$("failed", ($application$058create$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()))));
}

function $A_retry$() {
  return $constructed$1261$("retry", ($application$058create$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()))));
}

function $A_next$() {
  return $constructed$1261$("next", ($application$058create$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()))));
}

function $A_condition_false$() {
  return $constructed$1261$("condition_false", ($application$058create$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()))));
}

function $A_requirement_missing$() {
  return $constructed$1261$("requirement_missing", ($application$058create$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()))));
}

function $B_initial$() {
  return $after_a$("initial", ($application$058create$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()))));
}

function $B_failed$() {
  return $after_a$("failed", ($application$058create$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()))));
}

function $B_retry$() {
  return $after_a$("retry", ($application$058create$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()))));
}

function $B_next$() {
  return $after_a$("next", ($application$058create$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()))));
}

function $B_condition_false$() {
  return $after_a$("condition_false", ($application$058create$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()))));
}

function $B_requirement_missing$() {
  return $after_a$("requirement_missing", ($application$058create$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()))));
}

function $A_missing_reader$() {
  return $constructed$1261$("missing_reader", ($application$058create$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()))));
}

function $B_missing_reader$() {
  return $after_a$("missing_reader", ($application$058create$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()))));
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047local$058projected$1260$(_result_0) {
  const _local_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/local.Cell", "local": _local_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047local$058read_cell$1260$(_cell_0) {
  const _local_0 = _cell_0["local"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047local$058projected$1260$({$: "Tuple", fst: _local_0, snd: _local_0[0 % _local_0.length]});
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $constructed$1260$(_name_0, _result_0) {
  if (_result_0.$ === "application.ConstructionRefused") {
    return "{\"error\":\"ConstructionRefused\"}";
  } else {
    const _app_0 = _result_0["application"];
    return $rendered$1260$(($observe$1260$(($selected$1260$(_name_0, ($application$058install_reader$1260$(_app_0)))))));
  }
}

function $application$058create$1260$(_factory_0) {
  return $application$058created$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1260$(_factory_0, ($application$058initial_resources$1260$()))));
}

function $constructed$1261$(_name_0, _result_0) {
  if (_result_0.$ === "application.ConstructionRefused") {
    return "{\"error\":\"ConstructionRefused\"}";
  } else {
    const _app_0 = _result_0["application"];
    return $rendered$1261$(($observe$1261$(($selected$1261$(_name_0, ($application$058install_reader$1261$(_app_0)))))));
  }
}

function $application$058create$1261$(_factory_0) {
  return $application$058created$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1261$(_factory_0, ($application$058initial_resources$1261$()))));
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $rendered$1260$(_pair_0) {
  const _text_0 = _pair_0["snd"];
  return _text_0;
}

function $observe$1260$(_application_0) {
  const _owner_0 = _application_0["world"];
  const _t_0 = _application_0["owners"];
  const _exit_0 = _t_0["exit"];
  const _transition_0 = _t_0["transition"];
  const _enter_0 = _t_0["enter"];
  const _readerRegistry_0 = _application_0["readerRegistry"];
  return $observed$1260$(($world$1260$(_owner_0)), ($entries$1260$(_exit_0)), ($entries$1260$(_transition_0)), ($entries$1260$(_enter_0)), _readerRegistry_0);
}

function $selected$1260$(_name_0, _app_0) {
  if (_name_0 !== "") {
    const _t_0 = (_name_0.codePointAt(0) > 0xFFFF ? _name_0.slice(0, 2) : _name_0[0]);
    const _t_1 = _t_0.codePointAt(0);
    if (_t_1 == 105) {
      const _t_2 = (_name_0.codePointAt(0) > 0xFFFF ? _name_0.slice(2) : _name_0.slice(1));
      if (_t_2 !== "") {
        const _t_3 = (_t_2.codePointAt(0) > 0xFFFF ? _t_2.slice(0, 2) : _t_2[0]);
        const _t_4 = _t_3.codePointAt(0);
        if (_t_4 == 110) {
          const _t_5 = (_t_2.codePointAt(0) > 0xFFFF ? _t_2.slice(2) : _t_2.slice(1));
          if (_t_5 !== "") {
            const _t_6 = (_t_5.codePointAt(0) > 0xFFFF ? _t_5.slice(0, 2) : _t_5[0]);
            const _t_7 = _t_6.codePointAt(0);
            if (_t_7 == 105) {
              const _t_8 = (_t_5.codePointAt(0) > 0xFFFF ? _t_5.slice(2) : _t_5.slice(1));
              if (_t_8 !== "") {
                const _t_9 = (_t_8.codePointAt(0) > 0xFFFF ? _t_8.slice(0, 2) : _t_8[0]);
                const _t_10 = _t_9.codePointAt(0);
                if (_t_10 == 116) {
                  const _t_11 = (_t_8.codePointAt(0) > 0xFFFF ? _t_8.slice(2) : _t_8.slice(1));
                  if (_t_11 !== "") {
                    const _t_12 = (_t_11.codePointAt(0) > 0xFFFF ? _t_11.slice(0, 2) : _t_11[0]);
                    const _t_13 = _t_12.codePointAt(0);
                    if (_t_13 == 105) {
                      const _t_14 = (_t_11.codePointAt(0) > 0xFFFF ? _t_11.slice(2) : _t_11.slice(1));
                      if (_t_14 !== "") {
                        const _t_15 = (_t_14.codePointAt(0) > 0xFFFF ? _t_14.slice(0, 2) : _t_14[0]);
                        const _t_16 = _t_15.codePointAt(0);
                        if (_t_16 == 97) {
                          const _t_17 = (_t_14.codePointAt(0) > 0xFFFF ? _t_14.slice(2) : _t_14.slice(1));
                          if (_t_17 !== "") {
                            const _t_18 = (_t_17.codePointAt(0) > 0xFFFF ? _t_17.slice(0, 2) : _t_17[0]);
                            const _t_19 = _t_18.codePointAt(0);
                            if (_t_19 == 108) {
                              const _t_20 = (_t_17.codePointAt(0) > 0xFFFF ? _t_17.slice(2) : _t_17.slice(1));
                              if (_t_20 === "") {
                                return _app_0;
                              } else {
                                return _app_0;
                              }
                            } else {
                              return _app_0;
                            }
                          } else {
                            return _app_0;
                          }
                        } else {
                          return _app_0;
                        }
                      } else {
                        return _app_0;
                      }
                    } else {
                      return _app_0;
                    }
                  } else {
                    return _app_0;
                  }
                } else {
                  return _app_0;
                }
              } else {
                return _app_0;
              }
            } else {
              return _app_0;
            }
          } else {
            return _app_0;
          }
        } else {
          return _app_0;
        }
      } else {
        return _app_0;
      }
    } else if ((_t_1 & 7) == 1) {
      return _app_0;
    } else if (_t_1 == 109) {
      const _t_21 = (_name_0.codePointAt(0) > 0xFFFF ? _name_0.slice(2) : _name_0.slice(1));
      if (_t_21 !== "") {
        const _t_22 = (_t_21.codePointAt(0) > 0xFFFF ? _t_21.slice(0, 2) : _t_21[0]);
        const _t_23 = _t_22.codePointAt(0);
        if (_t_23 == 105) {
          const _t_24 = (_t_21.codePointAt(0) > 0xFFFF ? _t_21.slice(2) : _t_21.slice(1));
          if (_t_24 !== "") {
            const _t_25 = (_t_24.codePointAt(0) > 0xFFFF ? _t_24.slice(0, 2) : _t_24[0]);
            const _t_26 = _t_25.codePointAt(0);
            if (_t_26 == 115) {
              const _t_27 = (_t_24.codePointAt(0) > 0xFFFF ? _t_24.slice(2) : _t_24.slice(1));
              if (_t_27 !== "") {
                const _t_28 = (_t_27.codePointAt(0) > 0xFFFF ? _t_27.slice(0, 2) : _t_27[0]);
                const _t_29 = _t_28.codePointAt(0);
                if (_t_29 == 115) {
                  const _t_30 = (_t_27.codePointAt(0) > 0xFFFF ? _t_27.slice(2) : _t_27.slice(1));
                  if (_t_30 !== "") {
                    const _t_31 = (_t_30.codePointAt(0) > 0xFFFF ? _t_30.slice(0, 2) : _t_30[0]);
                    const _t_32 = _t_31.codePointAt(0);
                    if (_t_32 == 105) {
                      const _t_33 = (_t_30.codePointAt(0) > 0xFFFF ? _t_30.slice(2) : _t_30.slice(1));
                      if (_t_33 !== "") {
                        const _t_34 = (_t_33.codePointAt(0) > 0xFFFF ? _t_33.slice(0, 2) : _t_33[0]);
                        const _t_35 = _t_34.codePointAt(0);
                        if (_t_35 == 110) {
                          const _t_36 = (_t_33.codePointAt(0) > 0xFFFF ? _t_33.slice(2) : _t_33.slice(1));
                          if (_t_36 !== "") {
                            const _t_37 = (_t_36.codePointAt(0) > 0xFFFF ? _t_36.slice(0, 2) : _t_36[0]);
                            const _t_38 = _t_37.codePointAt(0);
                            if (_t_38 == 103) {
                              const _t_39 = (_t_36.codePointAt(0) > 0xFFFF ? _t_36.slice(2) : _t_36.slice(1));
                              if (_t_39 !== "") {
                                const _t_40 = (_t_39.codePointAt(0) > 0xFFFF ? _t_39.slice(0, 2) : _t_39[0]);
                                const _t_41 = _t_40.codePointAt(0);
                                if (_t_41 == 95) {
                                  const _t_42 = (_t_39.codePointAt(0) > 0xFFFF ? _t_39.slice(2) : _t_39.slice(1));
                                  if (_t_42 !== "") {
                                    const _t_43 = (_t_42.codePointAt(0) > 0xFFFF ? _t_42.slice(0, 2) : _t_42[0]);
                                    const _t_44 = _t_43.codePointAt(0);
                                    if (_t_44 == 114) {
                                      const _t_45 = (_t_42.codePointAt(0) > 0xFFFF ? _t_42.slice(2) : _t_42.slice(1));
                                      if (_t_45 !== "") {
                                        const _t_46 = (_t_45.codePointAt(0) > 0xFFFF ? _t_45.slice(0, 2) : _t_45[0]);
                                        const _t_47 = _t_46.codePointAt(0);
                                        if (_t_47 == 101) {
                                          const _t_48 = (_t_45.codePointAt(0) > 0xFFFF ? _t_45.slice(2) : _t_45.slice(1));
                                          if (_t_48 !== "") {
                                            const _t_49 = (_t_48.codePointAt(0) > 0xFFFF ? _t_48.slice(0, 2) : _t_48[0]);
                                            const _t_50 = _t_49.codePointAt(0);
                                            if (_t_50 == 97) {
                                              const _t_51 = (_t_48.codePointAt(0) > 0xFFFF ? _t_48.slice(2) : _t_48.slice(1));
                                              if (_t_51 !== "") {
                                                const _t_52 = (_t_51.codePointAt(0) > 0xFFFF ? _t_51.slice(0, 2) : _t_51[0]);
                                                const _t_53 = _t_52.codePointAt(0);
                                                if (_t_53 == 100) {
                                                  const _t_54 = (_t_51.codePointAt(0) > 0xFFFF ? _t_51.slice(2) : _t_51.slice(1));
                                                  if (_t_54 !== "") {
                                                    const _t_55 = (_t_54.codePointAt(0) > 0xFFFF ? _t_54.slice(0, 2) : _t_54[0]);
                                                    const _t_56 = _t_55.codePointAt(0);
                                                    if (_t_56 == 101) {
                                                      const _t_57 = (_t_54.codePointAt(0) > 0xFFFF ? _t_54.slice(2) : _t_54.slice(1));
                                                      if (_t_57 !== "") {
                                                        const _t_58 = (_t_57.codePointAt(0) > 0xFFFF ? _t_57.slice(0, 2) : _t_57[0]);
                                                        const _t_59 = _t_58.codePointAt(0);
                                                        if (_t_59 == 114) {
                                                          const _t_60 = (_t_57.codePointAt(0) > 0xFFFF ? _t_57.slice(2) : _t_57.slice(1));
                                                          if (_t_60 === "") {
                                                            return $application$058read$1260$(($application$058missing_reader$1260$(($application$058marker$1260$(($application$058marker$1260$(($application$058queue_play$1260$(_app_0)))))))));
                                                          } else {
                                                            return _app_0;
                                                          }
                                                        } else {
                                                          return _app_0;
                                                        }
                                                      } else {
                                                        return _app_0;
                                                      }
                                                    } else {
                                                      return _app_0;
                                                    }
                                                  } else {
                                                    return _app_0;
                                                  }
                                                } else {
                                                  return _app_0;
                                                }
                                              } else {
                                                return _app_0;
                                              }
                                            } else {
                                              return _app_0;
                                            }
                                          } else {
                                            return _app_0;
                                          }
                                        } else {
                                          return _app_0;
                                        }
                                      } else {
                                        return _app_0;
                                      }
                                    } else {
                                      return _app_0;
                                    }
                                  } else {
                                    return _app_0;
                                  }
                                } else {
                                  return _app_0;
                                }
                              } else {
                                return _app_0;
                              }
                            } else {
                              return _app_0;
                            }
                          } else {
                            return _app_0;
                          }
                        } else {
                          return _app_0;
                        }
                      } else {
                        return _app_0;
                      }
                    } else {
                      return _app_0;
                    }
                  } else {
                    return _app_0;
                  }
                } else {
                  return _app_0;
                }
              } else {
                return _app_0;
              }
            } else {
              return _app_0;
            }
          } else {
            return _app_0;
          }
        } else {
          return _app_0;
        }
      } else {
        return _app_0;
      }
    } else if ((_t_1 & 7) == 5) {
      return _app_0;
    } else if (_t_1 == 99) {
      const _t_61 = (_name_0.codePointAt(0) > 0xFFFF ? _name_0.slice(2) : _name_0.slice(1));
      if (_t_61 !== "") {
        const _t_62 = (_t_61.codePointAt(0) > 0xFFFF ? _t_61.slice(0, 2) : _t_61[0]);
        const _t_63 = _t_62.codePointAt(0);
        if (_t_63 == 111) {
          const _t_64 = (_t_61.codePointAt(0) > 0xFFFF ? _t_61.slice(2) : _t_61.slice(1));
          if (_t_64 !== "") {
            const _t_65 = (_t_64.codePointAt(0) > 0xFFFF ? _t_64.slice(0, 2) : _t_64[0]);
            const _t_66 = _t_65.codePointAt(0);
            if (_t_66 == 110) {
              const _t_67 = (_t_64.codePointAt(0) > 0xFFFF ? _t_64.slice(2) : _t_64.slice(1));
              if (_t_67 !== "") {
                const _t_68 = (_t_67.codePointAt(0) > 0xFFFF ? _t_67.slice(0, 2) : _t_67[0]);
                const _t_69 = _t_68.codePointAt(0);
                if (_t_69 == 100) {
                  const _t_70 = (_t_67.codePointAt(0) > 0xFFFF ? _t_67.slice(2) : _t_67.slice(1));
                  if (_t_70 !== "") {
                    const _t_71 = (_t_70.codePointAt(0) > 0xFFFF ? _t_70.slice(0, 2) : _t_70[0]);
                    const _t_72 = _t_71.codePointAt(0);
                    if (_t_72 == 105) {
                      const _t_73 = (_t_70.codePointAt(0) > 0xFFFF ? _t_70.slice(2) : _t_70.slice(1));
                      if (_t_73 !== "") {
                        const _t_74 = (_t_73.codePointAt(0) > 0xFFFF ? _t_73.slice(0, 2) : _t_73[0]);
                        const _t_75 = _t_74.codePointAt(0);
                        if (_t_75 == 116) {
                          const _t_76 = (_t_73.codePointAt(0) > 0xFFFF ? _t_73.slice(2) : _t_73.slice(1));
                          if (_t_76 !== "") {
                            const _t_77 = (_t_76.codePointAt(0) > 0xFFFF ? _t_76.slice(0, 2) : _t_76[0]);
                            const _t_78 = _t_77.codePointAt(0);
                            if (_t_78 == 105) {
                              const _t_79 = (_t_76.codePointAt(0) > 0xFFFF ? _t_76.slice(2) : _t_76.slice(1));
                              if (_t_79 !== "") {
                                const _t_80 = (_t_79.codePointAt(0) > 0xFFFF ? _t_79.slice(0, 2) : _t_79[0]);
                                const _t_81 = _t_80.codePointAt(0);
                                if (_t_81 == 111) {
                                  const _t_82 = (_t_79.codePointAt(0) > 0xFFFF ? _t_79.slice(2) : _t_79.slice(1));
                                  if (_t_82 !== "") {
                                    const _t_83 = (_t_82.codePointAt(0) > 0xFFFF ? _t_82.slice(0, 2) : _t_82[0]);
                                    const _t_84 = _t_83.codePointAt(0);
                                    if (_t_84 == 110) {
                                      const _t_85 = (_t_82.codePointAt(0) > 0xFFFF ? _t_82.slice(2) : _t_82.slice(1));
                                      if (_t_85 !== "") {
                                        const _t_86 = (_t_85.codePointAt(0) > 0xFFFF ? _t_85.slice(0, 2) : _t_85[0]);
                                        const _t_87 = _t_86.codePointAt(0);
                                        if (_t_87 == 95) {
                                          const _t_88 = (_t_85.codePointAt(0) > 0xFFFF ? _t_85.slice(2) : _t_85.slice(1));
                                          if (_t_88 !== "") {
                                            const _t_89 = (_t_88.codePointAt(0) > 0xFFFF ? _t_88.slice(0, 2) : _t_88[0]);
                                            const _t_90 = _t_89.codePointAt(0);
                                            if (_t_90 == 102) {
                                              const _t_91 = (_t_88.codePointAt(0) > 0xFFFF ? _t_88.slice(2) : _t_88.slice(1));
                                              if (_t_91 !== "") {
                                                const _t_92 = (_t_91.codePointAt(0) > 0xFFFF ? _t_91.slice(0, 2) : _t_91[0]);
                                                const _t_93 = _t_92.codePointAt(0);
                                                if (_t_93 == 97) {
                                                  const _t_94 = (_t_91.codePointAt(0) > 0xFFFF ? _t_91.slice(2) : _t_91.slice(1));
                                                  if (_t_94 !== "") {
                                                    const _t_95 = (_t_94.codePointAt(0) > 0xFFFF ? _t_94.slice(0, 2) : _t_94[0]);
                                                    const _t_96 = _t_95.codePointAt(0);
                                                    if (_t_96 == 108) {
                                                      const _t_97 = (_t_94.codePointAt(0) > 0xFFFF ? _t_94.slice(2) : _t_94.slice(1));
                                                      if (_t_97 !== "") {
                                                        const _t_98 = (_t_97.codePointAt(0) > 0xFFFF ? _t_97.slice(0, 2) : _t_97[0]);
                                                        const _t_99 = _t_98.codePointAt(0);
                                                        if (_t_99 == 115) {
                                                          const _t_100 = (_t_97.codePointAt(0) > 0xFFFF ? _t_97.slice(2) : _t_97.slice(1));
                                                          if (_t_100 !== "") {
                                                            const _t_101 = (_t_100.codePointAt(0) > 0xFFFF ? _t_100.slice(0, 2) : _t_100[0]);
                                                            const _t_102 = _t_101.codePointAt(0);
                                                            if (_t_102 == 101) {
                                                              const _t_103 = (_t_100.codePointAt(0) > 0xFFFF ? _t_100.slice(2) : _t_100.slice(1));
                                                              if (_t_103 === "") {
                                                                return $application$058gated_marker$1260$(_app_0, {$: "../../../../src/ecs/machine-conditions.Constant", "value": false});
                                                              } else {
                                                                return _app_0;
                                                              }
                                                            } else {
                                                              return _app_0;
                                                            }
                                                          } else {
                                                            return _app_0;
                                                          }
                                                        } else {
                                                          return _app_0;
                                                        }
                                                      } else {
                                                        return _app_0;
                                                      }
                                                    } else {
                                                      return _app_0;
                                                    }
                                                  } else {
                                                    return _app_0;
                                                  }
                                                } else {
                                                  return _app_0;
                                                }
                                              } else {
                                                return _app_0;
                                              }
                                            } else {
                                              return _app_0;
                                            }
                                          } else {
                                            return _app_0;
                                          }
                                        } else {
                                          return _app_0;
                                        }
                                      } else {
                                        return _app_0;
                                      }
                                    } else {
                                      return _app_0;
                                    }
                                  } else {
                                    return _app_0;
                                  }
                                } else {
                                  return _app_0;
                                }
                              } else {
                                return _app_0;
                              }
                            } else {
                              return _app_0;
                            }
                          } else {
                            return _app_0;
                          }
                        } else {
                          return _app_0;
                        }
                      } else {
                        return _app_0;
                      }
                    } else {
                      return _app_0;
                    }
                  } else {
                    return _app_0;
                  }
                } else {
                  return _app_0;
                }
              } else {
                return _app_0;
              }
            } else {
              return _app_0;
            }
          } else {
            return _app_0;
          }
        } else {
          return _app_0;
        }
      } else {
        return _app_0;
      }
    } else if ((_t_1 & 3) == 3) {
      return _app_0;
    } else if (_t_1 == 114) {
      const _t_104 = (_name_0.codePointAt(0) > 0xFFFF ? _name_0.slice(2) : _name_0.slice(1));
      if (_t_104 !== "") {
        const _t_105 = (_t_104.codePointAt(0) > 0xFFFF ? _t_104.slice(0, 2) : _t_104[0]);
        const _t_106 = _t_105.codePointAt(0);
        if (_t_106 == 101) {
          const _t_107 = (_t_104.codePointAt(0) > 0xFFFF ? _t_104.slice(2) : _t_104.slice(1));
          if (_t_107 !== "") {
            const _t_108 = (_t_107.codePointAt(0) > 0xFFFF ? _t_107.slice(0, 2) : _t_107[0]);
            const _t_109 = _t_108.codePointAt(0);
            if (_t_109 == 113) {
              const _t_110 = (_t_107.codePointAt(0) > 0xFFFF ? _t_107.slice(2) : _t_107.slice(1));
              if (_t_110 !== "") {
                const _t_111 = (_t_110.codePointAt(0) > 0xFFFF ? _t_110.slice(0, 2) : _t_110[0]);
                const _t_112 = _t_111.codePointAt(0);
                if (_t_112 == 117) {
                  const _t_113 = (_t_110.codePointAt(0) > 0xFFFF ? _t_110.slice(2) : _t_110.slice(1));
                  if (_t_113 !== "") {
                    const _t_114 = (_t_113.codePointAt(0) > 0xFFFF ? _t_113.slice(0, 2) : _t_113[0]);
                    const _t_115 = _t_114.codePointAt(0);
                    if (_t_115 == 105) {
                      const _t_116 = (_t_113.codePointAt(0) > 0xFFFF ? _t_113.slice(2) : _t_113.slice(1));
                      if (_t_116 !== "") {
                        const _t_117 = (_t_116.codePointAt(0) > 0xFFFF ? _t_116.slice(0, 2) : _t_116[0]);
                        const _t_118 = _t_117.codePointAt(0);
                        if (_t_118 == 114) {
                          const _t_119 = (_t_116.codePointAt(0) > 0xFFFF ? _t_116.slice(2) : _t_116.slice(1));
                          if (_t_119 !== "") {
                            const _t_120 = (_t_119.codePointAt(0) > 0xFFFF ? _t_119.slice(0, 2) : _t_119[0]);
                            const _t_121 = _t_120.codePointAt(0);
                            if (_t_121 == 101) {
                              const _t_122 = (_t_119.codePointAt(0) > 0xFFFF ? _t_119.slice(2) : _t_119.slice(1));
                              if (_t_122 !== "") {
                                const _t_123 = (_t_122.codePointAt(0) > 0xFFFF ? _t_122.slice(0, 2) : _t_122[0]);
                                const _t_124 = _t_123.codePointAt(0);
                                if (_t_124 == 109) {
                                  const _t_125 = (_t_122.codePointAt(0) > 0xFFFF ? _t_122.slice(2) : _t_122.slice(1));
                                  if (_t_125 !== "") {
                                    const _t_126 = (_t_125.codePointAt(0) > 0xFFFF ? _t_125.slice(0, 2) : _t_125[0]);
                                    const _t_127 = _t_126.codePointAt(0);
                                    if (_t_127 == 101) {
                                      const _t_128 = (_t_125.codePointAt(0) > 0xFFFF ? _t_125.slice(2) : _t_125.slice(1));
                                      if (_t_128 !== "") {
                                        const _t_129 = (_t_128.codePointAt(0) > 0xFFFF ? _t_128.slice(0, 2) : _t_128[0]);
                                        const _t_130 = _t_129.codePointAt(0);
                                        if (_t_130 == 110) {
                                          const _t_131 = (_t_128.codePointAt(0) > 0xFFFF ? _t_128.slice(2) : _t_128.slice(1));
                                          if (_t_131 !== "") {
                                            const _t_132 = (_t_131.codePointAt(0) > 0xFFFF ? _t_131.slice(0, 2) : _t_131[0]);
                                            const _t_133 = _t_132.codePointAt(0);
                                            if (_t_133 == 116) {
                                              const _t_134 = (_t_131.codePointAt(0) > 0xFFFF ? _t_131.slice(2) : _t_131.slice(1));
                                              if (_t_134 !== "") {
                                                const _t_135 = (_t_134.codePointAt(0) > 0xFFFF ? _t_134.slice(0, 2) : _t_134[0]);
                                                const _t_136 = _t_135.codePointAt(0);
                                                if (_t_136 == 95) {
                                                  const _t_137 = (_t_134.codePointAt(0) > 0xFFFF ? _t_134.slice(2) : _t_134.slice(1));
                                                  if (_t_137 !== "") {
                                                    const _t_138 = (_t_137.codePointAt(0) > 0xFFFF ? _t_137.slice(0, 2) : _t_137[0]);
                                                    const _t_139 = _t_138.codePointAt(0);
                                                    if (_t_139 == 109) {
                                                      const _t_140 = (_t_137.codePointAt(0) > 0xFFFF ? _t_137.slice(2) : _t_137.slice(1));
                                                      if (_t_140 !== "") {
                                                        const _t_141 = (_t_140.codePointAt(0) > 0xFFFF ? _t_140.slice(0, 2) : _t_140[0]);
                                                        const _t_142 = _t_141.codePointAt(0);
                                                        if (_t_142 == 105) {
                                                          const _t_143 = (_t_140.codePointAt(0) > 0xFFFF ? _t_140.slice(2) : _t_140.slice(1));
                                                          if (_t_143 !== "") {
                                                            const _t_144 = (_t_143.codePointAt(0) > 0xFFFF ? _t_143.slice(0, 2) : _t_143[0]);
                                                            const _t_145 = _t_144.codePointAt(0);
                                                            if (_t_145 == 115) {
                                                              const _t_146 = (_t_143.codePointAt(0) > 0xFFFF ? _t_143.slice(2) : _t_143.slice(1));
                                                              if (_t_146 !== "") {
                                                                const _t_147 = (_t_146.codePointAt(0) > 0xFFFF ? _t_146.slice(0, 2) : _t_146[0]);
                                                                const _t_148 = _t_147.codePointAt(0);
                                                                if (_t_148 == 115) {
                                                                  const _t_149 = (_t_146.codePointAt(0) > 0xFFFF ? _t_146.slice(2) : _t_146.slice(1));
                                                                  if (_t_149 !== "") {
                                                                    const _t_150 = (_t_149.codePointAt(0) > 0xFFFF ? _t_149.slice(0, 2) : _t_149[0]);
                                                                    const _t_151 = _t_150.codePointAt(0);
                                                                    if (_t_151 == 105) {
                                                                      const _t_152 = (_t_149.codePointAt(0) > 0xFFFF ? _t_149.slice(2) : _t_149.slice(1));
                                                                      if (_t_152 !== "") {
                                                                        const _t_153 = (_t_152.codePointAt(0) > 0xFFFF ? _t_152.slice(0, 2) : _t_152[0]);
                                                                        const _t_154 = _t_153.codePointAt(0);
                                                                        if (_t_154 == 110) {
                                                                          const _t_155 = (_t_152.codePointAt(0) > 0xFFFF ? _t_152.slice(2) : _t_152.slice(1));
                                                                          if (_t_155 !== "") {
                                                                            const _t_156 = (_t_155.codePointAt(0) > 0xFFFF ? _t_155.slice(0, 2) : _t_155[0]);
                                                                            const _t_157 = _t_156.codePointAt(0);
                                                                            if (_t_157 == 103) {
                                                                              const _t_158 = (_t_155.codePointAt(0) > 0xFFFF ? _t_155.slice(2) : _t_155.slice(1));
                                                                              if (_t_158 === "") {
                                                                                return $application$058gated_marker$1260$(($application$058missing_requirement$1260$(_app_0)), {$: "../../../../src/ecs/machine-conditions.Constant", "value": true});
                                                                              } else {
                                                                                return _app_0;
                                                                              }
                                                                            } else {
                                                                              return _app_0;
                                                                            }
                                                                          } else {
                                                                            return _app_0;
                                                                          }
                                                                        } else {
                                                                          return _app_0;
                                                                        }
                                                                      } else {
                                                                        return _app_0;
                                                                      }
                                                                    } else {
                                                                      return _app_0;
                                                                    }
                                                                  } else {
                                                                    return _app_0;
                                                                  }
                                                                } else {
                                                                  return _app_0;
                                                                }
                                                              } else {
                                                                return _app_0;
                                                              }
                                                            } else {
                                                              return _app_0;
                                                            }
                                                          } else {
                                                            return _app_0;
                                                          }
                                                        } else {
                                                          return _app_0;
                                                        }
                                                      } else {
                                                        return _app_0;
                                                      }
                                                    } else {
                                                      return _app_0;
                                                    }
                                                  } else {
                                                    return _app_0;
                                                  }
                                                } else {
                                                  return _app_0;
                                                }
                                              } else {
                                                return _app_0;
                                              }
                                            } else {
                                              return _app_0;
                                            }
                                          } else {
                                            return _app_0;
                                          }
                                        } else {
                                          return _app_0;
                                        }
                                      } else {
                                        return _app_0;
                                      }
                                    } else {
                                      return _app_0;
                                    }
                                  } else {
                                    return _app_0;
                                  }
                                } else {
                                  return _app_0;
                                }
                              } else {
                                return _app_0;
                              }
                            } else {
                              return _app_0;
                            }
                          } else {
                            return _app_0;
                          }
                        } else {
                          return _app_0;
                        }
                      } else {
                        return _app_0;
                      }
                    } else {
                      return _app_0;
                    }
                  } else {
                    return _app_0;
                  }
                } else {
                  return _app_0;
                }
              } else {
                return _app_0;
              }
            } else if ((_t_109 & 1) == 1) {
              return _app_0;
            } else if (_t_109 == 116) {
              const _t_159 = (_t_107.codePointAt(0) > 0xFFFF ? _t_107.slice(2) : _t_107.slice(1));
              if (_t_159 !== "") {
                const _t_160 = (_t_159.codePointAt(0) > 0xFFFF ? _t_159.slice(0, 2) : _t_159[0]);
                const _t_161 = _t_160.codePointAt(0);
                if (_t_161 == 114) {
                  const _t_162 = (_t_159.codePointAt(0) > 0xFFFF ? _t_159.slice(2) : _t_159.slice(1));
                  if (_t_162 !== "") {
                    const _t_163 = (_t_162.codePointAt(0) > 0xFFFF ? _t_162.slice(0, 2) : _t_162[0]);
                    const _t_164 = _t_163.codePointAt(0);
                    if (_t_164 == 121) {
                      const _t_165 = (_t_162.codePointAt(0) > 0xFFFF ? _t_162.slice(2) : _t_162.slice(1));
                      if (_t_165 === "") {
                        return $application$058read$1260$(($application$058marker$1260$(($application$058marker$1260$(($application$058queue_play$1260$(_app_0)))))));
                      } else {
                        return _app_0;
                      }
                    } else {
                      return _app_0;
                    }
                  } else {
                    return _app_0;
                  }
                } else {
                  return _app_0;
                }
              } else {
                return _app_0;
              }
            } else {
              return _app_0;
            }
          } else {
            return _app_0;
          }
        } else {
          return _app_0;
        }
      } else {
        return _app_0;
      }
    } else if (_t_1 == 102) {
      const _t_166 = (_name_0.codePointAt(0) > 0xFFFF ? _name_0.slice(2) : _name_0.slice(1));
      if (_t_166 !== "") {
        const _t_167 = (_t_166.codePointAt(0) > 0xFFFF ? _t_166.slice(0, 2) : _t_166[0]);
        const _t_168 = _t_167.codePointAt(0);
        if (_t_168 == 97) {
          const _t_169 = (_t_166.codePointAt(0) > 0xFFFF ? _t_166.slice(2) : _t_166.slice(1));
          if (_t_169 !== "") {
            const _t_170 = (_t_169.codePointAt(0) > 0xFFFF ? _t_169.slice(0, 2) : _t_169[0]);
            const _t_171 = _t_170.codePointAt(0);
            if (_t_171 == 105) {
              const _t_172 = (_t_169.codePointAt(0) > 0xFFFF ? _t_169.slice(2) : _t_169.slice(1));
              if (_t_172 !== "") {
                const _t_173 = (_t_172.codePointAt(0) > 0xFFFF ? _t_172.slice(0, 2) : _t_172[0]);
                const _t_174 = _t_173.codePointAt(0);
                if (_t_174 == 108) {
                  const _t_175 = (_t_172.codePointAt(0) > 0xFFFF ? _t_172.slice(2) : _t_172.slice(1));
                  if (_t_175 !== "") {
                    const _t_176 = (_t_175.codePointAt(0) > 0xFFFF ? _t_175.slice(0, 2) : _t_175[0]);
                    const _t_177 = _t_176.codePointAt(0);
                    if (_t_177 == 101) {
                      const _t_178 = (_t_175.codePointAt(0) > 0xFFFF ? _t_175.slice(2) : _t_175.slice(1));
                      if (_t_178 !== "") {
                        const _t_179 = (_t_178.codePointAt(0) > 0xFFFF ? _t_178.slice(0, 2) : _t_178[0]);
                        const _t_180 = _t_179.codePointAt(0);
                        if (_t_180 == 100) {
                          const _t_181 = (_t_178.codePointAt(0) > 0xFFFF ? _t_178.slice(2) : _t_178.slice(1));
                          if (_t_181 === "") {
                            return $application$058marker$1260$(($application$058queue_play$1260$(_app_0)));
                          } else {
                            return _app_0;
                          }
                        } else {
                          return _app_0;
                        }
                      } else {
                        return _app_0;
                      }
                    } else {
                      return _app_0;
                    }
                  } else {
                    return _app_0;
                  }
                } else {
                  return _app_0;
                }
              } else {
                return _app_0;
              }
            } else {
              return _app_0;
            }
          } else {
            return _app_0;
          }
        } else {
          return _app_0;
        }
      } else {
        return _app_0;
      }
    } else if (_t_1 == 110) {
      const _t_182 = (_name_0.codePointAt(0) > 0xFFFF ? _name_0.slice(2) : _name_0.slice(1));
      if (_t_182 !== "") {
        const _t_183 = (_t_182.codePointAt(0) > 0xFFFF ? _t_182.slice(0, 2) : _t_182[0]);
        const _t_184 = _t_183.codePointAt(0);
        if (_t_184 == 101) {
          const _t_185 = (_t_182.codePointAt(0) > 0xFFFF ? _t_182.slice(2) : _t_182.slice(1));
          if (_t_185 !== "") {
            const _t_186 = (_t_185.codePointAt(0) > 0xFFFF ? _t_185.slice(0, 2) : _t_185[0]);
            const _t_187 = _t_186.codePointAt(0);
            if (_t_187 == 120) {
              const _t_188 = (_t_185.codePointAt(0) > 0xFFFF ? _t_185.slice(2) : _t_185.slice(1));
              if (_t_188 !== "") {
                const _t_189 = (_t_188.codePointAt(0) > 0xFFFF ? _t_188.slice(0, 2) : _t_188[0]);
                const _t_190 = _t_189.codePointAt(0);
                if (_t_190 == 116) {
                  const _t_191 = (_t_188.codePointAt(0) > 0xFFFF ? _t_188.slice(2) : _t_188.slice(1));
                  if (_t_191 === "") {
                    return $application$058read$1260$(($application$058marker$1260$(($application$058read$1260$(($application$058marker$1260$(($application$058marker$1260$(($application$058queue_play$1260$(_app_0)))))))))));
                  } else {
                    return _app_0;
                  }
                } else {
                  return _app_0;
                }
              } else {
                return _app_0;
              }
            } else {
              return _app_0;
            }
          } else {
            return _app_0;
          }
        } else {
          return _app_0;
        }
      } else {
        return _app_0;
      }
    } else {
      return _app_0;
    }
  } else {
    return _app_0;
  }
}

function $application$058install_reader$1260$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  return $application$058reader_registered$1260$(_owners_0, ($$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1260$(_world_0, "reader", {$: "Con", "head": "machine:read", "tail": {$: "Nil"}})));
}

function $application$058created$1260$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/world.CreateRejected") {
    const _factory_0 = _result_0["factory"];
    return {$: "application.ConstructionRefused", "factory": _factory_0};
  } else {
    const _factory_1 = _result_0["factory"];
    const _world_0 = _result_0["world"];
    return $application$058reserved$1260$(_factory_1, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $application$058initial_resources$1260$() {
  return {$: "types.Resources", "owned": array_node([0], [19]), "slot": {$: "../../../../src/ecs/machine.Present", "current": {$: "types.Boot"}, "pending": {$: "../../../../src/ecs/machine.NoPending"}, "previous": {$: "None"}, "changed": false}, "stream": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058empty$1260$()), "reader": {$: "None"}, "locals": {$: "Nil"}, "tick": 0, "prefix": {$: "Nil"}, "delivered": {$: "Nil"}, "structuralApplied": 0};
}

function $rendered$1261$(_pair_0) {
  const _text_0 = _pair_0["snd"];
  return _text_0;
}

function $observe$1261$(_application_0) {
  const _owner_0 = _application_0["world"];
  const _t_0 = _application_0["owners"];
  const _exit_0 = _t_0["exit"];
  const _transition_0 = _t_0["transition"];
  const _enter_0 = _t_0["enter"];
  const _readerRegistry_0 = _application_0["readerRegistry"];
  return $observed$1261$(($world$1261$(_owner_0)), ($entries$1261$(_exit_0)), ($entries$1261$(_transition_0)), ($entries$1261$(_enter_0)), _readerRegistry_0);
}

function $selected$1261$(_name_0, _app_0) {
  if (_name_0 !== "") {
    const _t_0 = (_name_0.codePointAt(0) > 0xFFFF ? _name_0.slice(0, 2) : _name_0[0]);
    const _t_1 = _t_0.codePointAt(0);
    if (_t_1 == 105) {
      const _t_2 = (_name_0.codePointAt(0) > 0xFFFF ? _name_0.slice(2) : _name_0.slice(1));
      if (_t_2 !== "") {
        const _t_3 = (_t_2.codePointAt(0) > 0xFFFF ? _t_2.slice(0, 2) : _t_2[0]);
        const _t_4 = _t_3.codePointAt(0);
        if (_t_4 == 110) {
          const _t_5 = (_t_2.codePointAt(0) > 0xFFFF ? _t_2.slice(2) : _t_2.slice(1));
          if (_t_5 !== "") {
            const _t_6 = (_t_5.codePointAt(0) > 0xFFFF ? _t_5.slice(0, 2) : _t_5[0]);
            const _t_7 = _t_6.codePointAt(0);
            if (_t_7 == 105) {
              const _t_8 = (_t_5.codePointAt(0) > 0xFFFF ? _t_5.slice(2) : _t_5.slice(1));
              if (_t_8 !== "") {
                const _t_9 = (_t_8.codePointAt(0) > 0xFFFF ? _t_8.slice(0, 2) : _t_8[0]);
                const _t_10 = _t_9.codePointAt(0);
                if (_t_10 == 116) {
                  const _t_11 = (_t_8.codePointAt(0) > 0xFFFF ? _t_8.slice(2) : _t_8.slice(1));
                  if (_t_11 !== "") {
                    const _t_12 = (_t_11.codePointAt(0) > 0xFFFF ? _t_11.slice(0, 2) : _t_11[0]);
                    const _t_13 = _t_12.codePointAt(0);
                    if (_t_13 == 105) {
                      const _t_14 = (_t_11.codePointAt(0) > 0xFFFF ? _t_11.slice(2) : _t_11.slice(1));
                      if (_t_14 !== "") {
                        const _t_15 = (_t_14.codePointAt(0) > 0xFFFF ? _t_14.slice(0, 2) : _t_14[0]);
                        const _t_16 = _t_15.codePointAt(0);
                        if (_t_16 == 97) {
                          const _t_17 = (_t_14.codePointAt(0) > 0xFFFF ? _t_14.slice(2) : _t_14.slice(1));
                          if (_t_17 !== "") {
                            const _t_18 = (_t_17.codePointAt(0) > 0xFFFF ? _t_17.slice(0, 2) : _t_17[0]);
                            const _t_19 = _t_18.codePointAt(0);
                            if (_t_19 == 108) {
                              const _t_20 = (_t_17.codePointAt(0) > 0xFFFF ? _t_17.slice(2) : _t_17.slice(1));
                              if (_t_20 === "") {
                                return _app_0;
                              } else {
                                return _app_0;
                              }
                            } else {
                              return _app_0;
                            }
                          } else {
                            return _app_0;
                          }
                        } else {
                          return _app_0;
                        }
                      } else {
                        return _app_0;
                      }
                    } else {
                      return _app_0;
                    }
                  } else {
                    return _app_0;
                  }
                } else {
                  return _app_0;
                }
              } else {
                return _app_0;
              }
            } else {
              return _app_0;
            }
          } else {
            return _app_0;
          }
        } else {
          return _app_0;
        }
      } else {
        return _app_0;
      }
    } else if ((_t_1 & 7) == 1) {
      return _app_0;
    } else if (_t_1 == 109) {
      const _t_21 = (_name_0.codePointAt(0) > 0xFFFF ? _name_0.slice(2) : _name_0.slice(1));
      if (_t_21 !== "") {
        const _t_22 = (_t_21.codePointAt(0) > 0xFFFF ? _t_21.slice(0, 2) : _t_21[0]);
        const _t_23 = _t_22.codePointAt(0);
        if (_t_23 == 105) {
          const _t_24 = (_t_21.codePointAt(0) > 0xFFFF ? _t_21.slice(2) : _t_21.slice(1));
          if (_t_24 !== "") {
            const _t_25 = (_t_24.codePointAt(0) > 0xFFFF ? _t_24.slice(0, 2) : _t_24[0]);
            const _t_26 = _t_25.codePointAt(0);
            if (_t_26 == 115) {
              const _t_27 = (_t_24.codePointAt(0) > 0xFFFF ? _t_24.slice(2) : _t_24.slice(1));
              if (_t_27 !== "") {
                const _t_28 = (_t_27.codePointAt(0) > 0xFFFF ? _t_27.slice(0, 2) : _t_27[0]);
                const _t_29 = _t_28.codePointAt(0);
                if (_t_29 == 115) {
                  const _t_30 = (_t_27.codePointAt(0) > 0xFFFF ? _t_27.slice(2) : _t_27.slice(1));
                  if (_t_30 !== "") {
                    const _t_31 = (_t_30.codePointAt(0) > 0xFFFF ? _t_30.slice(0, 2) : _t_30[0]);
                    const _t_32 = _t_31.codePointAt(0);
                    if (_t_32 == 105) {
                      const _t_33 = (_t_30.codePointAt(0) > 0xFFFF ? _t_30.slice(2) : _t_30.slice(1));
                      if (_t_33 !== "") {
                        const _t_34 = (_t_33.codePointAt(0) > 0xFFFF ? _t_33.slice(0, 2) : _t_33[0]);
                        const _t_35 = _t_34.codePointAt(0);
                        if (_t_35 == 110) {
                          const _t_36 = (_t_33.codePointAt(0) > 0xFFFF ? _t_33.slice(2) : _t_33.slice(1));
                          if (_t_36 !== "") {
                            const _t_37 = (_t_36.codePointAt(0) > 0xFFFF ? _t_36.slice(0, 2) : _t_36[0]);
                            const _t_38 = _t_37.codePointAt(0);
                            if (_t_38 == 103) {
                              const _t_39 = (_t_36.codePointAt(0) > 0xFFFF ? _t_36.slice(2) : _t_36.slice(1));
                              if (_t_39 !== "") {
                                const _t_40 = (_t_39.codePointAt(0) > 0xFFFF ? _t_39.slice(0, 2) : _t_39[0]);
                                const _t_41 = _t_40.codePointAt(0);
                                if (_t_41 == 95) {
                                  const _t_42 = (_t_39.codePointAt(0) > 0xFFFF ? _t_39.slice(2) : _t_39.slice(1));
                                  if (_t_42 !== "") {
                                    const _t_43 = (_t_42.codePointAt(0) > 0xFFFF ? _t_42.slice(0, 2) : _t_42[0]);
                                    const _t_44 = _t_43.codePointAt(0);
                                    if (_t_44 == 114) {
                                      const _t_45 = (_t_42.codePointAt(0) > 0xFFFF ? _t_42.slice(2) : _t_42.slice(1));
                                      if (_t_45 !== "") {
                                        const _t_46 = (_t_45.codePointAt(0) > 0xFFFF ? _t_45.slice(0, 2) : _t_45[0]);
                                        const _t_47 = _t_46.codePointAt(0);
                                        if (_t_47 == 101) {
                                          const _t_48 = (_t_45.codePointAt(0) > 0xFFFF ? _t_45.slice(2) : _t_45.slice(1));
                                          if (_t_48 !== "") {
                                            const _t_49 = (_t_48.codePointAt(0) > 0xFFFF ? _t_48.slice(0, 2) : _t_48[0]);
                                            const _t_50 = _t_49.codePointAt(0);
                                            if (_t_50 == 97) {
                                              const _t_51 = (_t_48.codePointAt(0) > 0xFFFF ? _t_48.slice(2) : _t_48.slice(1));
                                              if (_t_51 !== "") {
                                                const _t_52 = (_t_51.codePointAt(0) > 0xFFFF ? _t_51.slice(0, 2) : _t_51[0]);
                                                const _t_53 = _t_52.codePointAt(0);
                                                if (_t_53 == 100) {
                                                  const _t_54 = (_t_51.codePointAt(0) > 0xFFFF ? _t_51.slice(2) : _t_51.slice(1));
                                                  if (_t_54 !== "") {
                                                    const _t_55 = (_t_54.codePointAt(0) > 0xFFFF ? _t_54.slice(0, 2) : _t_54[0]);
                                                    const _t_56 = _t_55.codePointAt(0);
                                                    if (_t_56 == 101) {
                                                      const _t_57 = (_t_54.codePointAt(0) > 0xFFFF ? _t_54.slice(2) : _t_54.slice(1));
                                                      if (_t_57 !== "") {
                                                        const _t_58 = (_t_57.codePointAt(0) > 0xFFFF ? _t_57.slice(0, 2) : _t_57[0]);
                                                        const _t_59 = _t_58.codePointAt(0);
                                                        if (_t_59 == 114) {
                                                          const _t_60 = (_t_57.codePointAt(0) > 0xFFFF ? _t_57.slice(2) : _t_57.slice(1));
                                                          if (_t_60 === "") {
                                                            return $application$058read$1261$(($application$058missing_reader$1261$(($application$058marker$1261$(($application$058marker$1261$(($application$058queue_play$1261$(_app_0)))))))));
                                                          } else {
                                                            return _app_0;
                                                          }
                                                        } else {
                                                          return _app_0;
                                                        }
                                                      } else {
                                                        return _app_0;
                                                      }
                                                    } else {
                                                      return _app_0;
                                                    }
                                                  } else {
                                                    return _app_0;
                                                  }
                                                } else {
                                                  return _app_0;
                                                }
                                              } else {
                                                return _app_0;
                                              }
                                            } else {
                                              return _app_0;
                                            }
                                          } else {
                                            return _app_0;
                                          }
                                        } else {
                                          return _app_0;
                                        }
                                      } else {
                                        return _app_0;
                                      }
                                    } else {
                                      return _app_0;
                                    }
                                  } else {
                                    return _app_0;
                                  }
                                } else {
                                  return _app_0;
                                }
                              } else {
                                return _app_0;
                              }
                            } else {
                              return _app_0;
                            }
                          } else {
                            return _app_0;
                          }
                        } else {
                          return _app_0;
                        }
                      } else {
                        return _app_0;
                      }
                    } else {
                      return _app_0;
                    }
                  } else {
                    return _app_0;
                  }
                } else {
                  return _app_0;
                }
              } else {
                return _app_0;
              }
            } else {
              return _app_0;
            }
          } else {
            return _app_0;
          }
        } else {
          return _app_0;
        }
      } else {
        return _app_0;
      }
    } else if ((_t_1 & 7) == 5) {
      return _app_0;
    } else if (_t_1 == 99) {
      const _t_61 = (_name_0.codePointAt(0) > 0xFFFF ? _name_0.slice(2) : _name_0.slice(1));
      if (_t_61 !== "") {
        const _t_62 = (_t_61.codePointAt(0) > 0xFFFF ? _t_61.slice(0, 2) : _t_61[0]);
        const _t_63 = _t_62.codePointAt(0);
        if (_t_63 == 111) {
          const _t_64 = (_t_61.codePointAt(0) > 0xFFFF ? _t_61.slice(2) : _t_61.slice(1));
          if (_t_64 !== "") {
            const _t_65 = (_t_64.codePointAt(0) > 0xFFFF ? _t_64.slice(0, 2) : _t_64[0]);
            const _t_66 = _t_65.codePointAt(0);
            if (_t_66 == 110) {
              const _t_67 = (_t_64.codePointAt(0) > 0xFFFF ? _t_64.slice(2) : _t_64.slice(1));
              if (_t_67 !== "") {
                const _t_68 = (_t_67.codePointAt(0) > 0xFFFF ? _t_67.slice(0, 2) : _t_67[0]);
                const _t_69 = _t_68.codePointAt(0);
                if (_t_69 == 100) {
                  const _t_70 = (_t_67.codePointAt(0) > 0xFFFF ? _t_67.slice(2) : _t_67.slice(1));
                  if (_t_70 !== "") {
                    const _t_71 = (_t_70.codePointAt(0) > 0xFFFF ? _t_70.slice(0, 2) : _t_70[0]);
                    const _t_72 = _t_71.codePointAt(0);
                    if (_t_72 == 105) {
                      const _t_73 = (_t_70.codePointAt(0) > 0xFFFF ? _t_70.slice(2) : _t_70.slice(1));
                      if (_t_73 !== "") {
                        const _t_74 = (_t_73.codePointAt(0) > 0xFFFF ? _t_73.slice(0, 2) : _t_73[0]);
                        const _t_75 = _t_74.codePointAt(0);
                        if (_t_75 == 116) {
                          const _t_76 = (_t_73.codePointAt(0) > 0xFFFF ? _t_73.slice(2) : _t_73.slice(1));
                          if (_t_76 !== "") {
                            const _t_77 = (_t_76.codePointAt(0) > 0xFFFF ? _t_76.slice(0, 2) : _t_76[0]);
                            const _t_78 = _t_77.codePointAt(0);
                            if (_t_78 == 105) {
                              const _t_79 = (_t_76.codePointAt(0) > 0xFFFF ? _t_76.slice(2) : _t_76.slice(1));
                              if (_t_79 !== "") {
                                const _t_80 = (_t_79.codePointAt(0) > 0xFFFF ? _t_79.slice(0, 2) : _t_79[0]);
                                const _t_81 = _t_80.codePointAt(0);
                                if (_t_81 == 111) {
                                  const _t_82 = (_t_79.codePointAt(0) > 0xFFFF ? _t_79.slice(2) : _t_79.slice(1));
                                  if (_t_82 !== "") {
                                    const _t_83 = (_t_82.codePointAt(0) > 0xFFFF ? _t_82.slice(0, 2) : _t_82[0]);
                                    const _t_84 = _t_83.codePointAt(0);
                                    if (_t_84 == 110) {
                                      const _t_85 = (_t_82.codePointAt(0) > 0xFFFF ? _t_82.slice(2) : _t_82.slice(1));
                                      if (_t_85 !== "") {
                                        const _t_86 = (_t_85.codePointAt(0) > 0xFFFF ? _t_85.slice(0, 2) : _t_85[0]);
                                        const _t_87 = _t_86.codePointAt(0);
                                        if (_t_87 == 95) {
                                          const _t_88 = (_t_85.codePointAt(0) > 0xFFFF ? _t_85.slice(2) : _t_85.slice(1));
                                          if (_t_88 !== "") {
                                            const _t_89 = (_t_88.codePointAt(0) > 0xFFFF ? _t_88.slice(0, 2) : _t_88[0]);
                                            const _t_90 = _t_89.codePointAt(0);
                                            if (_t_90 == 102) {
                                              const _t_91 = (_t_88.codePointAt(0) > 0xFFFF ? _t_88.slice(2) : _t_88.slice(1));
                                              if (_t_91 !== "") {
                                                const _t_92 = (_t_91.codePointAt(0) > 0xFFFF ? _t_91.slice(0, 2) : _t_91[0]);
                                                const _t_93 = _t_92.codePointAt(0);
                                                if (_t_93 == 97) {
                                                  const _t_94 = (_t_91.codePointAt(0) > 0xFFFF ? _t_91.slice(2) : _t_91.slice(1));
                                                  if (_t_94 !== "") {
                                                    const _t_95 = (_t_94.codePointAt(0) > 0xFFFF ? _t_94.slice(0, 2) : _t_94[0]);
                                                    const _t_96 = _t_95.codePointAt(0);
                                                    if (_t_96 == 108) {
                                                      const _t_97 = (_t_94.codePointAt(0) > 0xFFFF ? _t_94.slice(2) : _t_94.slice(1));
                                                      if (_t_97 !== "") {
                                                        const _t_98 = (_t_97.codePointAt(0) > 0xFFFF ? _t_97.slice(0, 2) : _t_97[0]);
                                                        const _t_99 = _t_98.codePointAt(0);
                                                        if (_t_99 == 115) {
                                                          const _t_100 = (_t_97.codePointAt(0) > 0xFFFF ? _t_97.slice(2) : _t_97.slice(1));
                                                          if (_t_100 !== "") {
                                                            const _t_101 = (_t_100.codePointAt(0) > 0xFFFF ? _t_100.slice(0, 2) : _t_100[0]);
                                                            const _t_102 = _t_101.codePointAt(0);
                                                            if (_t_102 == 101) {
                                                              const _t_103 = (_t_100.codePointAt(0) > 0xFFFF ? _t_100.slice(2) : _t_100.slice(1));
                                                              if (_t_103 === "") {
                                                                return $application$058gated_marker$1261$(_app_0, {$: "../../../../src/ecs/machine-conditions.Constant", "value": false});
                                                              } else {
                                                                return _app_0;
                                                              }
                                                            } else {
                                                              return _app_0;
                                                            }
                                                          } else {
                                                            return _app_0;
                                                          }
                                                        } else {
                                                          return _app_0;
                                                        }
                                                      } else {
                                                        return _app_0;
                                                      }
                                                    } else {
                                                      return _app_0;
                                                    }
                                                  } else {
                                                    return _app_0;
                                                  }
                                                } else {
                                                  return _app_0;
                                                }
                                              } else {
                                                return _app_0;
                                              }
                                            } else {
                                              return _app_0;
                                            }
                                          } else {
                                            return _app_0;
                                          }
                                        } else {
                                          return _app_0;
                                        }
                                      } else {
                                        return _app_0;
                                      }
                                    } else {
                                      return _app_0;
                                    }
                                  } else {
                                    return _app_0;
                                  }
                                } else {
                                  return _app_0;
                                }
                              } else {
                                return _app_0;
                              }
                            } else {
                              return _app_0;
                            }
                          } else {
                            return _app_0;
                          }
                        } else {
                          return _app_0;
                        }
                      } else {
                        return _app_0;
                      }
                    } else {
                      return _app_0;
                    }
                  } else {
                    return _app_0;
                  }
                } else {
                  return _app_0;
                }
              } else {
                return _app_0;
              }
            } else {
              return _app_0;
            }
          } else {
            return _app_0;
          }
        } else {
          return _app_0;
        }
      } else {
        return _app_0;
      }
    } else if ((_t_1 & 3) == 3) {
      return _app_0;
    } else if (_t_1 == 114) {
      const _t_104 = (_name_0.codePointAt(0) > 0xFFFF ? _name_0.slice(2) : _name_0.slice(1));
      if (_t_104 !== "") {
        const _t_105 = (_t_104.codePointAt(0) > 0xFFFF ? _t_104.slice(0, 2) : _t_104[0]);
        const _t_106 = _t_105.codePointAt(0);
        if (_t_106 == 101) {
          const _t_107 = (_t_104.codePointAt(0) > 0xFFFF ? _t_104.slice(2) : _t_104.slice(1));
          if (_t_107 !== "") {
            const _t_108 = (_t_107.codePointAt(0) > 0xFFFF ? _t_107.slice(0, 2) : _t_107[0]);
            const _t_109 = _t_108.codePointAt(0);
            if (_t_109 == 113) {
              const _t_110 = (_t_107.codePointAt(0) > 0xFFFF ? _t_107.slice(2) : _t_107.slice(1));
              if (_t_110 !== "") {
                const _t_111 = (_t_110.codePointAt(0) > 0xFFFF ? _t_110.slice(0, 2) : _t_110[0]);
                const _t_112 = _t_111.codePointAt(0);
                if (_t_112 == 117) {
                  const _t_113 = (_t_110.codePointAt(0) > 0xFFFF ? _t_110.slice(2) : _t_110.slice(1));
                  if (_t_113 !== "") {
                    const _t_114 = (_t_113.codePointAt(0) > 0xFFFF ? _t_113.slice(0, 2) : _t_113[0]);
                    const _t_115 = _t_114.codePointAt(0);
                    if (_t_115 == 105) {
                      const _t_116 = (_t_113.codePointAt(0) > 0xFFFF ? _t_113.slice(2) : _t_113.slice(1));
                      if (_t_116 !== "") {
                        const _t_117 = (_t_116.codePointAt(0) > 0xFFFF ? _t_116.slice(0, 2) : _t_116[0]);
                        const _t_118 = _t_117.codePointAt(0);
                        if (_t_118 == 114) {
                          const _t_119 = (_t_116.codePointAt(0) > 0xFFFF ? _t_116.slice(2) : _t_116.slice(1));
                          if (_t_119 !== "") {
                            const _t_120 = (_t_119.codePointAt(0) > 0xFFFF ? _t_119.slice(0, 2) : _t_119[0]);
                            const _t_121 = _t_120.codePointAt(0);
                            if (_t_121 == 101) {
                              const _t_122 = (_t_119.codePointAt(0) > 0xFFFF ? _t_119.slice(2) : _t_119.slice(1));
                              if (_t_122 !== "") {
                                const _t_123 = (_t_122.codePointAt(0) > 0xFFFF ? _t_122.slice(0, 2) : _t_122[0]);
                                const _t_124 = _t_123.codePointAt(0);
                                if (_t_124 == 109) {
                                  const _t_125 = (_t_122.codePointAt(0) > 0xFFFF ? _t_122.slice(2) : _t_122.slice(1));
                                  if (_t_125 !== "") {
                                    const _t_126 = (_t_125.codePointAt(0) > 0xFFFF ? _t_125.slice(0, 2) : _t_125[0]);
                                    const _t_127 = _t_126.codePointAt(0);
                                    if (_t_127 == 101) {
                                      const _t_128 = (_t_125.codePointAt(0) > 0xFFFF ? _t_125.slice(2) : _t_125.slice(1));
                                      if (_t_128 !== "") {
                                        const _t_129 = (_t_128.codePointAt(0) > 0xFFFF ? _t_128.slice(0, 2) : _t_128[0]);
                                        const _t_130 = _t_129.codePointAt(0);
                                        if (_t_130 == 110) {
                                          const _t_131 = (_t_128.codePointAt(0) > 0xFFFF ? _t_128.slice(2) : _t_128.slice(1));
                                          if (_t_131 !== "") {
                                            const _t_132 = (_t_131.codePointAt(0) > 0xFFFF ? _t_131.slice(0, 2) : _t_131[0]);
                                            const _t_133 = _t_132.codePointAt(0);
                                            if (_t_133 == 116) {
                                              const _t_134 = (_t_131.codePointAt(0) > 0xFFFF ? _t_131.slice(2) : _t_131.slice(1));
                                              if (_t_134 !== "") {
                                                const _t_135 = (_t_134.codePointAt(0) > 0xFFFF ? _t_134.slice(0, 2) : _t_134[0]);
                                                const _t_136 = _t_135.codePointAt(0);
                                                if (_t_136 == 95) {
                                                  const _t_137 = (_t_134.codePointAt(0) > 0xFFFF ? _t_134.slice(2) : _t_134.slice(1));
                                                  if (_t_137 !== "") {
                                                    const _t_138 = (_t_137.codePointAt(0) > 0xFFFF ? _t_137.slice(0, 2) : _t_137[0]);
                                                    const _t_139 = _t_138.codePointAt(0);
                                                    if (_t_139 == 109) {
                                                      const _t_140 = (_t_137.codePointAt(0) > 0xFFFF ? _t_137.slice(2) : _t_137.slice(1));
                                                      if (_t_140 !== "") {
                                                        const _t_141 = (_t_140.codePointAt(0) > 0xFFFF ? _t_140.slice(0, 2) : _t_140[0]);
                                                        const _t_142 = _t_141.codePointAt(0);
                                                        if (_t_142 == 105) {
                                                          const _t_143 = (_t_140.codePointAt(0) > 0xFFFF ? _t_140.slice(2) : _t_140.slice(1));
                                                          if (_t_143 !== "") {
                                                            const _t_144 = (_t_143.codePointAt(0) > 0xFFFF ? _t_143.slice(0, 2) : _t_143[0]);
                                                            const _t_145 = _t_144.codePointAt(0);
                                                            if (_t_145 == 115) {
                                                              const _t_146 = (_t_143.codePointAt(0) > 0xFFFF ? _t_143.slice(2) : _t_143.slice(1));
                                                              if (_t_146 !== "") {
                                                                const _t_147 = (_t_146.codePointAt(0) > 0xFFFF ? _t_146.slice(0, 2) : _t_146[0]);
                                                                const _t_148 = _t_147.codePointAt(0);
                                                                if (_t_148 == 115) {
                                                                  const _t_149 = (_t_146.codePointAt(0) > 0xFFFF ? _t_146.slice(2) : _t_146.slice(1));
                                                                  if (_t_149 !== "") {
                                                                    const _t_150 = (_t_149.codePointAt(0) > 0xFFFF ? _t_149.slice(0, 2) : _t_149[0]);
                                                                    const _t_151 = _t_150.codePointAt(0);
                                                                    if (_t_151 == 105) {
                                                                      const _t_152 = (_t_149.codePointAt(0) > 0xFFFF ? _t_149.slice(2) : _t_149.slice(1));
                                                                      if (_t_152 !== "") {
                                                                        const _t_153 = (_t_152.codePointAt(0) > 0xFFFF ? _t_152.slice(0, 2) : _t_152[0]);
                                                                        const _t_154 = _t_153.codePointAt(0);
                                                                        if (_t_154 == 110) {
                                                                          const _t_155 = (_t_152.codePointAt(0) > 0xFFFF ? _t_152.slice(2) : _t_152.slice(1));
                                                                          if (_t_155 !== "") {
                                                                            const _t_156 = (_t_155.codePointAt(0) > 0xFFFF ? _t_155.slice(0, 2) : _t_155[0]);
                                                                            const _t_157 = _t_156.codePointAt(0);
                                                                            if (_t_157 == 103) {
                                                                              const _t_158 = (_t_155.codePointAt(0) > 0xFFFF ? _t_155.slice(2) : _t_155.slice(1));
                                                                              if (_t_158 === "") {
                                                                                return $application$058gated_marker$1261$(($application$058missing_requirement$1261$(_app_0)), {$: "../../../../src/ecs/machine-conditions.Constant", "value": true});
                                                                              } else {
                                                                                return _app_0;
                                                                              }
                                                                            } else {
                                                                              return _app_0;
                                                                            }
                                                                          } else {
                                                                            return _app_0;
                                                                          }
                                                                        } else {
                                                                          return _app_0;
                                                                        }
                                                                      } else {
                                                                        return _app_0;
                                                                      }
                                                                    } else {
                                                                      return _app_0;
                                                                    }
                                                                  } else {
                                                                    return _app_0;
                                                                  }
                                                                } else {
                                                                  return _app_0;
                                                                }
                                                              } else {
                                                                return _app_0;
                                                              }
                                                            } else {
                                                              return _app_0;
                                                            }
                                                          } else {
                                                            return _app_0;
                                                          }
                                                        } else {
                                                          return _app_0;
                                                        }
                                                      } else {
                                                        return _app_0;
                                                      }
                                                    } else {
                                                      return _app_0;
                                                    }
                                                  } else {
                                                    return _app_0;
                                                  }
                                                } else {
                                                  return _app_0;
                                                }
                                              } else {
                                                return _app_0;
                                              }
                                            } else {
                                              return _app_0;
                                            }
                                          } else {
                                            return _app_0;
                                          }
                                        } else {
                                          return _app_0;
                                        }
                                      } else {
                                        return _app_0;
                                      }
                                    } else {
                                      return _app_0;
                                    }
                                  } else {
                                    return _app_0;
                                  }
                                } else {
                                  return _app_0;
                                }
                              } else {
                                return _app_0;
                              }
                            } else {
                              return _app_0;
                            }
                          } else {
                            return _app_0;
                          }
                        } else {
                          return _app_0;
                        }
                      } else {
                        return _app_0;
                      }
                    } else {
                      return _app_0;
                    }
                  } else {
                    return _app_0;
                  }
                } else {
                  return _app_0;
                }
              } else {
                return _app_0;
              }
            } else if ((_t_109 & 1) == 1) {
              return _app_0;
            } else if (_t_109 == 116) {
              const _t_159 = (_t_107.codePointAt(0) > 0xFFFF ? _t_107.slice(2) : _t_107.slice(1));
              if (_t_159 !== "") {
                const _t_160 = (_t_159.codePointAt(0) > 0xFFFF ? _t_159.slice(0, 2) : _t_159[0]);
                const _t_161 = _t_160.codePointAt(0);
                if (_t_161 == 114) {
                  const _t_162 = (_t_159.codePointAt(0) > 0xFFFF ? _t_159.slice(2) : _t_159.slice(1));
                  if (_t_162 !== "") {
                    const _t_163 = (_t_162.codePointAt(0) > 0xFFFF ? _t_162.slice(0, 2) : _t_162[0]);
                    const _t_164 = _t_163.codePointAt(0);
                    if (_t_164 == 121) {
                      const _t_165 = (_t_162.codePointAt(0) > 0xFFFF ? _t_162.slice(2) : _t_162.slice(1));
                      if (_t_165 === "") {
                        return $application$058read$1261$(($application$058marker$1261$(($application$058marker$1261$(($application$058queue_play$1261$(_app_0)))))));
                      } else {
                        return _app_0;
                      }
                    } else {
                      return _app_0;
                    }
                  } else {
                    return _app_0;
                  }
                } else {
                  return _app_0;
                }
              } else {
                return _app_0;
              }
            } else {
              return _app_0;
            }
          } else {
            return _app_0;
          }
        } else {
          return _app_0;
        }
      } else {
        return _app_0;
      }
    } else if (_t_1 == 102) {
      const _t_166 = (_name_0.codePointAt(0) > 0xFFFF ? _name_0.slice(2) : _name_0.slice(1));
      if (_t_166 !== "") {
        const _t_167 = (_t_166.codePointAt(0) > 0xFFFF ? _t_166.slice(0, 2) : _t_166[0]);
        const _t_168 = _t_167.codePointAt(0);
        if (_t_168 == 97) {
          const _t_169 = (_t_166.codePointAt(0) > 0xFFFF ? _t_166.slice(2) : _t_166.slice(1));
          if (_t_169 !== "") {
            const _t_170 = (_t_169.codePointAt(0) > 0xFFFF ? _t_169.slice(0, 2) : _t_169[0]);
            const _t_171 = _t_170.codePointAt(0);
            if (_t_171 == 105) {
              const _t_172 = (_t_169.codePointAt(0) > 0xFFFF ? _t_169.slice(2) : _t_169.slice(1));
              if (_t_172 !== "") {
                const _t_173 = (_t_172.codePointAt(0) > 0xFFFF ? _t_172.slice(0, 2) : _t_172[0]);
                const _t_174 = _t_173.codePointAt(0);
                if (_t_174 == 108) {
                  const _t_175 = (_t_172.codePointAt(0) > 0xFFFF ? _t_172.slice(2) : _t_172.slice(1));
                  if (_t_175 !== "") {
                    const _t_176 = (_t_175.codePointAt(0) > 0xFFFF ? _t_175.slice(0, 2) : _t_175[0]);
                    const _t_177 = _t_176.codePointAt(0);
                    if (_t_177 == 101) {
                      const _t_178 = (_t_175.codePointAt(0) > 0xFFFF ? _t_175.slice(2) : _t_175.slice(1));
                      if (_t_178 !== "") {
                        const _t_179 = (_t_178.codePointAt(0) > 0xFFFF ? _t_178.slice(0, 2) : _t_178[0]);
                        const _t_180 = _t_179.codePointAt(0);
                        if (_t_180 == 100) {
                          const _t_181 = (_t_178.codePointAt(0) > 0xFFFF ? _t_178.slice(2) : _t_178.slice(1));
                          if (_t_181 === "") {
                            return $application$058marker$1261$(($application$058queue_play$1261$(_app_0)));
                          } else {
                            return _app_0;
                          }
                        } else {
                          return _app_0;
                        }
                      } else {
                        return _app_0;
                      }
                    } else {
                      return _app_0;
                    }
                  } else {
                    return _app_0;
                  }
                } else {
                  return _app_0;
                }
              } else {
                return _app_0;
              }
            } else {
              return _app_0;
            }
          } else {
            return _app_0;
          }
        } else {
          return _app_0;
        }
      } else {
        return _app_0;
      }
    } else if (_t_1 == 110) {
      const _t_182 = (_name_0.codePointAt(0) > 0xFFFF ? _name_0.slice(2) : _name_0.slice(1));
      if (_t_182 !== "") {
        const _t_183 = (_t_182.codePointAt(0) > 0xFFFF ? _t_182.slice(0, 2) : _t_182[0]);
        const _t_184 = _t_183.codePointAt(0);
        if (_t_184 == 101) {
          const _t_185 = (_t_182.codePointAt(0) > 0xFFFF ? _t_182.slice(2) : _t_182.slice(1));
          if (_t_185 !== "") {
            const _t_186 = (_t_185.codePointAt(0) > 0xFFFF ? _t_185.slice(0, 2) : _t_185[0]);
            const _t_187 = _t_186.codePointAt(0);
            if (_t_187 == 120) {
              const _t_188 = (_t_185.codePointAt(0) > 0xFFFF ? _t_185.slice(2) : _t_185.slice(1));
              if (_t_188 !== "") {
                const _t_189 = (_t_188.codePointAt(0) > 0xFFFF ? _t_188.slice(0, 2) : _t_188[0]);
                const _t_190 = _t_189.codePointAt(0);
                if (_t_190 == 116) {
                  const _t_191 = (_t_188.codePointAt(0) > 0xFFFF ? _t_188.slice(2) : _t_188.slice(1));
                  if (_t_191 === "") {
                    return $application$058read$1261$(($application$058marker$1261$(($application$058read$1261$(($application$058marker$1261$(($application$058marker$1261$(($application$058queue_play$1261$(_app_0)))))))))));
                  } else {
                    return _app_0;
                  }
                } else {
                  return _app_0;
                }
              } else {
                return _app_0;
              }
            } else {
              return _app_0;
            }
          } else {
            return _app_0;
          }
        } else {
          return _app_0;
        }
      } else {
        return _app_0;
      }
    } else {
      return _app_0;
    }
  } else {
    return _app_0;
  }
}

function $application$058install_reader$1261$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  return $application$058reader_registered$1261$(_owners_0, ($$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1262$(_world_0, "reader", {$: "Con", "head": "machine:read", "tail": {$: "Nil"}})));
}

function $application$058created$1261$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/world.CreateRejected") {
    const _factory_0 = _result_0["factory"];
    return {$: "application.ConstructionRefused", "factory": _factory_0};
  } else {
    const _factory_1 = _result_0["factory"];
    const _world_0 = _result_0["world"];
    return $application$058reserved$1261$(_factory_1, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1261$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1261$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $application$058initial_resources$1261$() {
  return {$: "types.Resources", "owned": array_node([0], [19]), "slot": {$: "../../../../src/ecs/machine.Present", "current": {$: "types.Boot"}, "pending": {$: "../../../../src/ecs/machine.NoPending"}, "previous": {$: "None"}, "changed": false}, "stream": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058empty$1260$()), "reader": {$: "None"}, "locals": {$: "Nil"}, "tick": 0, "prefix": {$: "Nil"}, "delivered": {$: "Nil"}, "structuralApplied": 0};
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $observed$1260$(_world_0, _exit_0, _transition_0, _enter_0, _readerRegistry_0) {
  const _world_1 = _world_0["fst"];
  const _text_0 = _world_0["snd"];
  const _exit_1 = _exit_0["fst"];
  const _t_0 = _exit_0["snd"];
  const _a_0 = _t_0["fst"];
  const _ac_0 = _t_0["snd"];
  const _transition_1 = _transition_0["fst"];
  const _t_1 = _transition_0["snd"];
  const _b_0 = _t_1["fst"];
  const _bc_0 = _t_1["snd"];
  const _enter_1 = _enter_0["fst"];
  const _t_2 = _enter_0["snd"];
  const _c_0 = _t_2["fst"];
  const _cc_0 = _t_2["snd"];
  if (_readerRegistry_0.$ === "Some") {
    const _t_3 = _readerRegistry_0["value"];
    const _ns_0 = _t_3["namespace"];
    const _id_0 = _t_3["id"];
    const _name_0 = _t_3["name"];
    const _access_0 = _t_3["access"];
    const _cursor_0 = _t_3["cursor"];
    const _x_0 = ($List$show$1260$(($List$append$(_ac_0, ($List$append$(_bc_0, ($List$append$(_cc_0, {$: "Con", "head": _cursor_0, "tail": {$: "Nil"}}))))))));
    const _x_1 = (_x_0 + "}");
    const _x_2 = ($List$show$1260$(($List$append$(_a_0, ($List$append$(_b_0, ($List$append$(_c_0, {$: "Con", "head": _id_0, "tail": {$: "Nil"}}))))))));
    const _x_3 = (",\"registryCursors\":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = (",\"registryIds\":" + _x_4);
    const _x_6 = (_text_0 + _x_5);
    return {$: "Tuple", "fst": {$: "application.Application", "world": _world_1, "owners": {$: "../../../../src/ecs/machine-handlers.Owners", "exit": _exit_1, "transition": _transition_1, "enter": _enter_1}, "readerRegistry": {$: "Some", "value": {$: "../../../../src/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}}}, "snd": ("{" + _x_6)};
  } else {
    return {$: "Tuple", "fst": {$: "application.Application", "world": _world_1, "owners": {$: "../../../../src/ecs/machine-handlers.Owners", "exit": _exit_1, "transition": _transition_1, "enter": _enter_1}, "readerRegistry": {$: "None"}}, "snd": "{\"error\":\"MissingRegistry\"}"};
  }
}

function $world$1260$(_owner_0) {
  const _ns_0 = _owner_0["namespace"];
  const _next_0 = _owner_0["nextId"];
  const _high_0 = _owner_0["highWater"];
  const _live_0 = _owner_0["live"];
  const _capacity_0 = _owner_0["capacity"];
  const _depth_0 = _owner_0["depth"];
  const _t_0 = _owner_0["store"];
  const _column_0 = _t_0["column"];
  const _resource_0 = _owner_0["resource"];
  const _events_0 = _owner_0["events"];
  const _pending_0 = _owner_0["pending"];
  const _registrations_0 = _owner_0["registrations"];
  const _nextSystem_0 = _owner_0["nextSystemId"];
  const _clock_0 = _owner_0["clock"];
  return $world_join$1260$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058view$1260$(_column_0, 1)), ($resources$1260$(_resource_0)), _events_0, ($commands$1260$(_pending_0)), _registrations_0, _nextSystem_0, _clock_0);
}

function $entries$1260$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}}};
  } else {
    const _t_0 = _items_0["head"];
    const _ordinal_0 = _t_0["ordinal"];
    const _t_1 = _t_0["registry"];
    const _ns_0 = _t_1["namespace"];
    const _id_0 = _t_1["id"];
    const _name_0 = _t_1["name"];
    const _access_0 = _t_1["access"];
    const _cursor_0 = _t_1["cursor"];
    const _rest_0 = _items_0["tail"];
    return $entries_join$1260$({$: "../../../../src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}}, _id_0, _cursor_0, ($entries$1260$(_rest_0)));
  }
}

function $application$058read$1260$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _t_0 = _app_0["readerRegistry"];
  if (_t_0.$ === "None") {
    return {$: "application.Application", "world": _world_0, "owners": _owners_0, "readerRegistry": {$: "None"}};
  } else {
    const _registry_0 = _t_0["value"];
    return $application$058read_result$1260$(_owners_0, ($$$$047$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, {$: "Unit"})));
  }
}

function $application$058missing_reader$1260$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _readerRegistry_0 = _app_0["readerRegistry"];
  return {$: "application.Application", "world": ($application$058without_reader$1260$(_world_0)), "owners": _owners_0, "readerRegistry": _readerRegistry_0};
}

function $application$058marker$1260$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _readerRegistry_0 = _app_0["readerRegistry"];
  return $application$058marker_slot$1260$(_readerRegistry_0, _owners_0, ($world$058take$1260$(($application$058marker_tick$1260$(_world_0)))));
}

function $application$058queue_play$1260$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _readerRegistry_0 = _app_0["readerRegistry"];
  return $application$058queue_slot$1260$(_readerRegistry_0, _owners_0, ($world$058take$1260$(_world_0)));
}

function $application$058gated_marker$1260$(_app_0, _tree_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _readerRegistry_0 = _app_0["readerRegistry"];
  return $application$058gate_slot$1260$(_readerRegistry_0, _owners_0, ($world$058take$1260$(_world_0)), _tree_0);
}

function $application$058missing_requirement$1260$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _readerRegistry_0 = _app_0["readerRegistry"];
  return {$: "application.Application", "world": ($world$058put$1260$(_world_0, {$: "../../../../src/ecs/machine.Missing"})), "owners": _owners_0, "readerRegistry": _readerRegistry_0};
}

function $application$058reader_registered$1260$(_owners_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "application.Application", "world": _world_0, "owners": _owners_0, "readerRegistry": {$: "None"}};
  } else {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["registry"];
    const _namespace_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _name_0 = _t_0["name"];
    const _access_0 = _t_0["access"];
    const _cursor_0 = _t_0["cursor"];
    return {$: "application.Application", "world": ($application$058reader_installed$1260$(_world_1, _namespace_0, _id_0)), "owners": _owners_0, "readerRegistry": {$: "Some", "value": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $application$058reserved$1260$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $application$058activated$1260$(_factory_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)));
  } else {
    return {$: "application.ConstructionRefused", "factory": _factory_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1260$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../src/ecs/world.CreateRejected", "factory": {$: "../../../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../src/ecs/world.Created", "factory": {$: "../../../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($application$058empty_store$1260$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058empty$1260$() {
  return {$: "../../../../src/ecs/machine-stream.Stream", "batches": {$: "Nil"}, "positions": {$: "Nil"}, "droppedThrough": 0, "frameStart": 0};
}

function $observed$1261$(_world_0, _exit_0, _transition_0, _enter_0, _readerRegistry_0) {
  const _world_1 = _world_0["fst"];
  const _text_0 = _world_0["snd"];
  const _exit_1 = _exit_0["fst"];
  const _t_0 = _exit_0["snd"];
  const _a_0 = _t_0["fst"];
  const _ac_0 = _t_0["snd"];
  const _transition_1 = _transition_0["fst"];
  const _t_1 = _transition_0["snd"];
  const _b_0 = _t_1["fst"];
  const _bc_0 = _t_1["snd"];
  const _enter_1 = _enter_0["fst"];
  const _t_2 = _enter_0["snd"];
  const _c_0 = _t_2["fst"];
  const _cc_0 = _t_2["snd"];
  if (_readerRegistry_0.$ === "Some") {
    const _t_3 = _readerRegistry_0["value"];
    const _ns_0 = _t_3["namespace"];
    const _id_0 = _t_3["id"];
    const _name_0 = _t_3["name"];
    const _access_0 = _t_3["access"];
    const _cursor_0 = _t_3["cursor"];
    const _x_0 = ($List$show$1260$(($List$append$(_ac_0, ($List$append$(_bc_0, ($List$append$(_cc_0, {$: "Con", "head": _cursor_0, "tail": {$: "Nil"}}))))))));
    const _x_1 = (_x_0 + "}");
    const _x_2 = ($List$show$1260$(($List$append$(_a_0, ($List$append$(_b_0, ($List$append$(_c_0, {$: "Con", "head": _id_0, "tail": {$: "Nil"}}))))))));
    const _x_3 = (",\"registryCursors\":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = (",\"registryIds\":" + _x_4);
    const _x_6 = (_text_0 + _x_5);
    return {$: "Tuple", "fst": {$: "application.Application", "world": _world_1, "owners": {$: "../../../../src/ecs/machine-handlers.Owners", "exit": _exit_1, "transition": _transition_1, "enter": _enter_1}, "readerRegistry": {$: "Some", "value": {$: "../../../../src/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}}}, "snd": ("{" + _x_6)};
  } else {
    return {$: "Tuple", "fst": {$: "application.Application", "world": _world_1, "owners": {$: "../../../../src/ecs/machine-handlers.Owners", "exit": _exit_1, "transition": _transition_1, "enter": _enter_1}, "readerRegistry": {$: "None"}}, "snd": "{\"error\":\"MissingRegistry\"}"};
  }
}

function $world$1261$(_owner_0) {
  const _ns_0 = _owner_0["namespace"];
  const _next_0 = _owner_0["nextId"];
  const _high_0 = _owner_0["highWater"];
  const _live_0 = _owner_0["live"];
  const _capacity_0 = _owner_0["capacity"];
  const _depth_0 = _owner_0["depth"];
  const _t_0 = _owner_0["store"];
  const _column_0 = _t_0["column"];
  const _resource_0 = _owner_0["resource"];
  const _events_0 = _owner_0["events"];
  const _pending_0 = _owner_0["pending"];
  const _registrations_0 = _owner_0["registrations"];
  const _nextSystem_0 = _owner_0["nextSystemId"];
  const _clock_0 = _owner_0["clock"];
  return $world_join$1261$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058view$1261$(_column_0, 1)), ($resources$1261$(_resource_0)), _events_0, ($commands$1261$(_pending_0)), _registrations_0, _nextSystem_0, _clock_0);
}

function $entries$1261$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}}};
  } else {
    const _t_0 = _items_0["head"];
    const _ordinal_0 = _t_0["ordinal"];
    const _t_1 = _t_0["registry"];
    const _ns_0 = _t_1["namespace"];
    const _id_0 = _t_1["id"];
    const _name_0 = _t_1["name"];
    const _access_0 = _t_1["access"];
    const _cursor_0 = _t_1["cursor"];
    const _rest_0 = _items_0["tail"];
    return $entries_join$1261$({$: "../../../../src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}}, _id_0, _cursor_0, ($entries$1261$(_rest_0)));
  }
}

function $application$058read$1261$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _t_0 = _app_0["readerRegistry"];
  if (_t_0.$ === "None") {
    return {$: "application.Application", "world": _world_0, "owners": _owners_0, "readerRegistry": {$: "None"}};
  } else {
    const _registry_0 = _t_0["value"];
    return $application$058read_result$1261$(_owners_0, ($$$$047$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1262$(_registry_0, _world_0, {$: "Unit"})));
  }
}

function $application$058missing_reader$1261$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _readerRegistry_0 = _app_0["readerRegistry"];
  return {$: "application.Application", "world": ($application$058without_reader$1261$(_world_0)), "owners": _owners_0, "readerRegistry": _readerRegistry_0};
}

function $application$058marker$1261$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _readerRegistry_0 = _app_0["readerRegistry"];
  return $application$058marker_slot$1261$(_readerRegistry_0, _owners_0, ($world$058take$1261$(($application$058marker_tick$1261$(_world_0)))));
}

function $application$058queue_play$1261$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _readerRegistry_0 = _app_0["readerRegistry"];
  return $application$058queue_slot$1261$(_readerRegistry_0, _owners_0, ($world$058take$1261$(_world_0)));
}

function $application$058gated_marker$1261$(_app_0, _tree_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _readerRegistry_0 = _app_0["readerRegistry"];
  return $application$058gate_slot$1261$(_readerRegistry_0, _owners_0, ($world$058take$1261$(_world_0)), _tree_0);
}

function $application$058missing_requirement$1261$(_app_0) {
  const _world_0 = _app_0["world"];
  const _owners_0 = _app_0["owners"];
  const _readerRegistry_0 = _app_0["readerRegistry"];
  return {$: "application.Application", "world": ($world$058put$1261$(_world_0, {$: "../../../../src/ecs/machine.Missing"})), "owners": _owners_0, "readerRegistry": _readerRegistry_0};
}

function $application$058reader_registered$1261$(_owners_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "application.Application", "world": _world_0, "owners": _owners_0, "readerRegistry": {$: "None"}};
  } else {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["registry"];
    const _namespace_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _name_0 = _t_0["name"];
    const _access_0 = _t_0["access"];
    const _cursor_0 = _t_0["cursor"];
    return {$: "application.Application", "world": ($application$058reader_installed$1261$(_world_1, _namespace_0, _id_0)), "owners": _owners_0, "readerRegistry": {$: "Some", "value": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1262$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $application$058reserved$1261$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $application$058activated$1261$(_factory_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0)));
  } else {
    return {$: "application.ConstructionRefused", "factory": _factory_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1261$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1261$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../src/ecs/world.CreateRejected", "factory": {$: "../../../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../src/ecs/world.Created", "factory": {$: "../../../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($application$058empty_store$1261$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $List$show$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $world_join$1260$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _column_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _column_1 = _column_0["fst"];
  const _t_0 = _column_0["snd"];
  if (_t_0.$ === "Some") {
    const _cells_0 = _t_0["value"];
    const _owner_0 = _resource_0["fst"];
    const _text_0 = _resource_0["snd"];
    const _pending_1 = _pending_0["fst"];
    const _count_0 = _pending_0["snd"];
    const _x_0 = ($Nat$show$(_count_0));
    const _x_1 = ($U32$show$(_clock_0));
    const _x_2 = (",\"pendingStructural\":" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = (",\"clock\":" + _x_3);
    const _x_5 = (_text_0 + _x_4);
    const _x_6 = ("," + _x_5);
    const _x_7 = (_cells_0 + _x_6);
    const _x_8 = ($U32$show$(_ns_0));
    const _x_9 = (",\"entity\":1,\"component\":" + _x_7);
    const _x_10 = (_x_8 + _x_9);
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "types.Store", "column": _column_1}, "resource": _owner_0, "events": _events_0, "pending": _pending_1, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ("\"namespace\":" + _x_10)};
  } else {
    const _owner_1 = _resource_0["fst"];
    const _text_1 = _resource_0["snd"];
    const _pending_2 = _pending_0["fst"];
    const _count_1 = _pending_0["snd"];
    const _x_11 = ($Nat$show$(_count_1));
    const _x_12 = ($U32$show$(_clock_0));
    const _x_13 = (",\"pendingStructural\":" + _x_11);
    const _x_14 = (_x_12 + _x_13);
    const _x_15 = (",\"clock\":" + _x_14);
    const _x_16 = (_text_1 + _x_15);
    const _x_17 = ($U32$show$(_ns_0));
    const _x_18 = (",\"entity\":1,\"component\":null," + _x_16);
    const _x_19 = (_x_17 + _x_18);
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "types.Store", "column": _column_1}, "resource": _owner_1, "events": _events_0, "pending": _pending_2, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ("\"namespace\":" + _x_19)};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058view$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $resources$1260$(_owner_0) {
  const _owned_0 = _owner_0["owned"];
  const _slotValue_0 = _owner_0["slot"];
  const _stream_0 = _owner_0["stream"];
  const _readerOwner_0 = _owner_0["reader"];
  const _localOwners_0 = _owner_0["locals"];
  const _tick_0 = _owner_0["tick"];
  const _prefix_0 = _owner_0["prefix"];
  const _delivered_0 = _owner_0["delivered"];
  const _applied_0 = _owner_0["structuralApplied"];
  return $resource_locals$1260$(_owned_0, _slotValue_0, _stream_0, _readerOwner_0, _tick_0, _prefix_0, _delivered_0, _applied_0, ($locals$(_localOwners_0)));
}

function $commands$1260$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _head_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    return $commands_join$1260$(_head_0, ($commands$1260$(_rest_0)));
  }
}

function $entries_join$1260$(_head_0, _id_0, _cursor_0, _tail_0) {
  const _rest_0 = _tail_0["fst"];
  const _t_0 = _tail_0["snd"];
  const _ids_0 = _t_0["fst"];
  const _cursors_0 = _t_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_0, "tail": _rest_0}, "snd": {$: "Tuple", "fst": {$: "Con", "head": _id_0, "tail": _ids_0}, "snd": {$: "Con", "head": _cursor_0, "tail": _cursors_0}}};
}

function $application$058read_result$1260$(_owners_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $application$058read_completed$1260$(_owners_0, _registry_0, _outcome_0);
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    return {$: "application.Application", "world": _world_0, "owners": _owners_0, "readerRegistry": {$: "Some", "value": _registry_1}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0)));
}

function $application$058without_reader$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": {$: "None"}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $application$058marker_slot$1260$(_readerRegistry_0, _owners_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return $application$058retained$1260$(_readerRegistry_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058run$1260$(_owners_0, ($world$058put$1260$(_world_0, _slot_0)), ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058snapshot$1260$(_slot_0)))));
}

function $world$058take$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1260$(_world_0);
}

function $application$058marker_tick$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": nat_chk(_tick_0 + 1), "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $application$058queue_slot$1260$(_readerRegistry_0, _owners_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "application.Application", "world": ($world$058put$1260$(_world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058queue$1260$(_slot_0, {$: "types.Play"}, false)))), "owners": _owners_0, "readerRegistry": _readerRegistry_0};
}

function $application$058gate_slot$1260$(_readerRegistry_0, _owners_0, _pair_0, _tree_0) {
  const _world_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "application.Application", "world": ($world$058put$1260$(_world_0, {$: "../../../../src/ecs/machine.Missing"})), "owners": _owners_0, "readerRegistry": _readerRegistry_0};
  } else {
    const _current_0 = _t_0["current"];
    const _pending_0 = _t_0["pending"];
    const _previous_0 = _t_0["previous"];
    const _changed_0 = _t_0["changed"];
    return $application$058gate_decided$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047machine$045conditions$058evaluate$1260$(_tree_0, {$: "types.Environment", "current": _current_0, "hasResource": true})), {$: "application.Application", "world": ($world$058put$1260$(_world_0, {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": _pending_0, "previous": _previous_0, "changed": _changed_0})), "owners": _owners_0, "readerRegistry": _readerRegistry_0});
  }
}

function $world$058put$1260$(_world_0, _slot_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1260$(_world_0, _slot_0);
}

function $application$058reader_installed$1260$(_world_0, _namespace_0, _id_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": {$: "Some", "value": {$: "../../../../src/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": _id_0}}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1260$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $application$058activated$1260$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Accepted") {
    return {$: "application.Constructed", "factory": _factory_0, "application": ($application$058registered_exit$1260$(($application$058register$1260$(_world_0, "exit"))))};
  } else {
    return {$: "application.ConstructionRefused", "factory": _factory_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1260$(true, _handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1260$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.ReservationRejected", "error": {$: "../../../../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$({$: "../../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $application$058empty_store$1260$(__0) {
  return {$: "types.Store", "column": {$: "../../../../src/ecs/column.Column", "values": [{$: "Some", "value": array_node([0], [7])}], "stamps": {$: "Nil"}}};
}

function $world_join$1261$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _column_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _column_1 = _column_0["fst"];
  const _t_0 = _column_0["snd"];
  if (_t_0.$ === "Some") {
    const _cells_0 = _t_0["value"];
    const _owner_0 = _resource_0["fst"];
    const _text_0 = _resource_0["snd"];
    const _pending_1 = _pending_0["fst"];
    const _count_0 = _pending_0["snd"];
    const _x_0 = ($Nat$show$(_count_0));
    const _x_1 = ($U32$show$(_clock_0));
    const _x_2 = (",\"pendingStructural\":" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = (",\"clock\":" + _x_3);
    const _x_5 = (_text_0 + _x_4);
    const _x_6 = ("," + _x_5);
    const _x_7 = (_cells_0 + _x_6);
    const _x_8 = ($U32$show$(_ns_0));
    const _x_9 = (",\"entity\":1,\"component\":" + _x_7);
    const _x_10 = (_x_8 + _x_9);
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "types.Store", "column": _column_1}, "resource": _owner_0, "events": _events_0, "pending": _pending_1, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ("\"namespace\":" + _x_10)};
  } else {
    const _owner_1 = _resource_0["fst"];
    const _text_1 = _resource_0["snd"];
    const _pending_2 = _pending_0["fst"];
    const _count_1 = _pending_0["snd"];
    const _x_11 = ($Nat$show$(_count_1));
    const _x_12 = ($U32$show$(_clock_0));
    const _x_13 = (",\"pendingStructural\":" + _x_11);
    const _x_14 = (_x_12 + _x_13);
    const _x_15 = (",\"clock\":" + _x_14);
    const _x_16 = (_text_1 + _x_15);
    const _x_17 = ($U32$show$(_ns_0));
    const _x_18 = (",\"entity\":1,\"component\":null," + _x_16);
    const _x_19 = (_x_17 + _x_18);
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "types.Store", "column": _column_1}, "resource": _owner_1, "events": _events_0, "pending": _pending_2, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ("\"namespace\":" + _x_19)};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058view$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1261$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $resources$1261$(_owner_0) {
  const _owned_0 = _owner_0["owned"];
  const _slotValue_0 = _owner_0["slot"];
  const _stream_0 = _owner_0["stream"];
  const _readerOwner_0 = _owner_0["reader"];
  const _localOwners_0 = _owner_0["locals"];
  const _tick_0 = _owner_0["tick"];
  const _prefix_0 = _owner_0["prefix"];
  const _delivered_0 = _owner_0["delivered"];
  const _applied_0 = _owner_0["structuralApplied"];
  return $resource_locals$1261$(_owned_0, _slotValue_0, _stream_0, _readerOwner_0, _tick_0, _prefix_0, _delivered_0, _applied_0, ($locals$(_localOwners_0)));
}

function $commands$1261$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _head_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    return $commands_join$1261$(_head_0, ($commands$1261$(_rest_0)));
  }
}

function $entries_join$1261$(_head_0, _id_0, _cursor_0, _tail_0) {
  const _rest_0 = _tail_0["fst"];
  const _t_0 = _tail_0["snd"];
  const _ids_0 = _t_0["fst"];
  const _cursors_0 = _t_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_0, "tail": _rest_0}, "snd": {$: "Tuple", "fst": {$: "Con", "head": _id_0, "tail": _ids_0}, "snd": {$: "Con", "head": _cursor_0, "tail": _cursors_0}}};
}

function $application$058read_result$1261$(_owners_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $application$058read_completed$1261$(_owners_0, _registry_0, _outcome_0);
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    return {$: "application.Application", "world": _world_0, "owners": _owners_0, "readerRegistry": {$: "Some", "value": _registry_1}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1262$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1262$(_registry_0, _world_0, _args_0)));
}

function $application$058without_reader$1261$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": {$: "None"}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $application$058marker_slot$1261$(_readerRegistry_0, _owners_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return $application$058retained$1261$(_readerRegistry_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058run$1261$(_owners_0, ($world$058put$1261$(_world_0, _slot_0)), ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058snapshot$1261$(_slot_0)))));
}

function $world$058take$1261$(_world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1261$(_world_0);
}

function $application$058marker_tick$1261$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": nat_chk(_tick_0 + 1), "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $application$058queue_slot$1261$(_readerRegistry_0, _owners_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "application.Application", "world": ($world$058put$1261$(_world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058queue$1261$(_slot_0, {$: "types.Play"}, false)))), "owners": _owners_0, "readerRegistry": _readerRegistry_0};
}

function $application$058gate_slot$1261$(_readerRegistry_0, _owners_0, _pair_0, _tree_0) {
  const _world_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "application.Application", "world": ($world$058put$1261$(_world_0, {$: "../../../../src/ecs/machine.Missing"})), "owners": _owners_0, "readerRegistry": _readerRegistry_0};
  } else {
    const _current_0 = _t_0["current"];
    const _pending_0 = _t_0["pending"];
    const _previous_0 = _t_0["previous"];
    const _changed_0 = _t_0["changed"];
    return $application$058gate_decided$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047machine$045conditions$058evaluate$1261$(_tree_0, {$: "types.Environment", "current": _current_0, "hasResource": true})), {$: "application.Application", "world": ($world$058put$1261$(_world_0, {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": _pending_0, "previous": _previous_0, "changed": _changed_0})), "owners": _owners_0, "readerRegistry": _readerRegistry_0});
  }
}

function $world$058put$1261$(_world_0, _slot_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1261$(_world_0, _slot_0);
}

function $application$058reader_installed$1261$(_world_0, _namespace_0, _id_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": {$: "Some", "value": {$: "../../../../src/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": _id_0}}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1262$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $application$058activated$1261$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Accepted") {
    return {$: "application.Constructed", "factory": _factory_0, "application": ($application$058registered_exit$1261$(($application$058register$1261$(_world_0, "exit"))))};
  } else {
    return {$: "application.ConstructionRefused", "factory": _factory_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1261$(true, _handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1261$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.ReservationRejected", "error": {$: "../../../../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$({$: "../../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $application$058empty_store$1261$(__0) {
  return {$: "types.Store", "column": {$: "../../../../src/ecs/column.Column", "values": [{$: "Some", "value": array_node([0], [7])}], "stamps": {$: "Nil"}}};
}

function $List$show$go$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $resource_locals$1260$(_owned_0, _slotValue_0, _stream_0, _readerOwner_0, _tick_0, _prefix_0, _delivered_0, _applied_0, _pair_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _start_0 = _stream_0["frameStart"];
  const _locals_0 = _pair_0["fst"];
  const _values_0 = _pair_0["snd"];
  return $resource_reader$1260$({$: "types.Resources", "owned": [0], "slot": _slotValue_0, "stream": {$: "../../../../src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _start_0}, "reader": {$: "None"}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, ($reader$1260$(_readerOwner_0, _positions_0)), _owned_0, _values_0);
}

function $commands_join$1260$(_head_0, _tail_0) {
  const _rest_0 = _tail_0["fst"];
  const _count_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_0, "tail": _rest_0}, "snd": nat_chk(_count_0 + 1)};
}

function $application$058read_completed$1260$(_owners_0, _registry_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/system.Succeeded") {
    const _world_0 = _result_0["world"];
    return {$: "application.Application", "world": _world_0, "owners": _owners_0, "readerRegistry": {$: "Some", "value": _registry_0}};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "application.Application", "world": _world_1, "owners": _owners_0, "readerRegistry": {$: "Some", "value": _registry_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1260$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1260$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $application$058retained$1260$(_readerRegistry_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/machine-handlers.Completed") {
    const _owners_0 = _result_0["owners"];
    const _world_0 = _result_0["world"];
    return {$: "application.Application", "world": _world_0, "owners": _owners_0, "readerRegistry": _readerRegistry_0};
  } else {
    const _owners_1 = _result_0["owners"];
    const _world_1 = _result_0["world"];
    return {$: "application.Application", "world": _world_1, "owners": _owners_1, "readerRegistry": _readerRegistry_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058run$1260$(_owners_0, _world_0, _captured_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058taken$1260$(_owners_0, ($world$058take$1260$(_world_0)), _captured_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058snapshot$1260$(_slot_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Unscheduled"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058snapshot_pending$1260$(_pending_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take_join$1260$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, ($world$058take_resource$1260$(_resources_0)), _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058queue$1260$(_slot_0, _value_0, _skipSame_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../src/ecs/machine.Queued", "value": _value_0, "skipSame": _skipSame_0}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $application$058gate_decided$1260$(_allowed_0, _app_0) {
  if (!_allowed_0) {
    return _app_0;
  } else {
    return $application$058marker$1260$(_app_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045conditions$058evaluate$1260$(_tree_0, _env_0) {
  if (_tree_0.$ === "../../../../src/ecs/machine-conditions.Leaf") {
    const _atom_0 = _tree_0["atom"];
    return $types$058condition$1260$(_atom_0, _env_0);
  } else if (_tree_0.$ === "../../../../src/ecs/machine-conditions.Constant") {
    const _value_0 = _tree_0["value"];
    return _value_0;
  } else if (_tree_0.$ === "../../../../src/ecs/machine-conditions.Negate") {
    const _inner_0 = _tree_0["inner"];
    return $Bool$not$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047machine$045conditions$058evaluate$1260$(_inner_0, _env_0)));
  } else if (_tree_0.$ === "../../../../src/ecs/machine-conditions.Both") {
    const _left_0 = _tree_0["left"];
    const _right_0 = _tree_0["right"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045conditions$058both_next$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047machine$045conditions$058evaluate$1260$(_left_0, _env_0)), _env_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045conditions$058evaluate$1260$(_right_0, _x_0);
}));
  } else {
    const _left_1 = _tree_0["left"];
    const _right_1 = _tree_0["right"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045conditions$058either_next$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047machine$045conditions$058evaluate$1260$(_left_1, _env_0)), _env_0, run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045conditions$058evaluate$1260$(_right_1, _x_1);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1260$(_world_0, _slot_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": ($world$058put_resource$1260$(_resources_0, _slot_0)), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1260$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $application$058registered_exit$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _exit_0 = _result_0["snd"];
  return $application$058registered_transition$1260$(_exit_0, ($application$058register$1260$(_world_0, "transition")));
}

function $application$058register$1260$(_world_0, _name_0) {
  return $application$058entry_registered$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1261$(_world_0, _name_0, {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}})));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1260$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Reserved", "handle": {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1261$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1261$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1261$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $resource_locals$1261$(_owned_0, _slotValue_0, _stream_0, _readerOwner_0, _tick_0, _prefix_0, _delivered_0, _applied_0, _pair_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _start_0 = _stream_0["frameStart"];
  const _locals_0 = _pair_0["fst"];
  const _values_0 = _pair_0["snd"];
  return $resource_reader$1261$({$: "types.Resources", "owned": [0], "slot": _slotValue_0, "stream": {$: "../../../../src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _start_0}, "reader": {$: "None"}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, ($reader$1261$(_readerOwner_0, _positions_0)), _owned_0, _values_0);
}

function $commands_join$1261$(_head_0, _tail_0) {
  const _rest_0 = _tail_0["fst"];
  const _count_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_0, "tail": _rest_0}, "snd": nat_chk(_count_0 + 1)};
}

function $application$058read_completed$1261$(_owners_0, _registry_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/system.Succeeded") {
    const _world_0 = _result_0["world"];
    return {$: "application.Application", "world": _world_0, "owners": _owners_0, "readerRegistry": {$: "Some", "value": _registry_0}};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "application.Application", "world": _world_1, "owners": _owners_0, "readerRegistry": {$: "Some", "value": _registry_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1262$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1262$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1262$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1262$(_registry_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $application$058retained$1261$(_readerRegistry_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/machine-handlers.Completed") {
    const _owners_0 = _result_0["owners"];
    const _world_0 = _result_0["world"];
    return {$: "application.Application", "world": _world_0, "owners": _owners_0, "readerRegistry": _readerRegistry_0};
  } else {
    const _owners_1 = _result_0["owners"];
    const _world_1 = _result_0["world"];
    return {$: "application.Application", "world": _world_1, "owners": _owners_1, "readerRegistry": _readerRegistry_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058run$1261$(_owners_0, _world_0, _captured_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058taken$1261$(_owners_0, ($world$058take$1261$(_world_0)), _captured_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058snapshot$1261$(_slot_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Unscheduled"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$058snapshot_pending$1260$(_pending_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take$1261$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take_join$1261$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, ($world$058take_resource$1261$(_resources_0)), _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058queue$1261$(_slot_0, _value_0, _skipSame_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../src/ecs/machine.Queued", "value": _value_0, "skipSame": _skipSame_0}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $application$058gate_decided$1261$(_allowed_0, _app_0) {
  if (!_allowed_0) {
    return _app_0;
  } else {
    return $application$058marker$1261$(_app_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045conditions$058evaluate$1261$(_tree_0, _env_0) {
  if (_tree_0.$ === "../../../../src/ecs/machine-conditions.Leaf") {
    const _atom_0 = _tree_0["atom"];
    return $types$058condition$1261$(_atom_0, _env_0);
  } else if (_tree_0.$ === "../../../../src/ecs/machine-conditions.Constant") {
    const _value_0 = _tree_0["value"];
    return _value_0;
  } else if (_tree_0.$ === "../../../../src/ecs/machine-conditions.Negate") {
    const _inner_0 = _tree_0["inner"];
    return $Bool$not$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047machine$045conditions$058evaluate$1261$(_inner_0, _env_0)));
  } else if (_tree_0.$ === "../../../../src/ecs/machine-conditions.Both") {
    const _left_0 = _tree_0["left"];
    const _right_0 = _tree_0["right"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045conditions$058both_next$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047machine$045conditions$058evaluate$1261$(_left_0, _env_0)), _env_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045conditions$058evaluate$1261$(_right_0, _x_0);
}));
  } else {
    const _left_1 = _tree_0["left"];
    const _right_1 = _tree_0["right"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045conditions$058either_next$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047machine$045conditions$058evaluate$1261$(_left_1, _env_0)), _env_0, run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045conditions$058evaluate$1261$(_right_1, _x_1);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058put$1261$(_world_0, _slot_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": ($world$058put_resource$1261$(_resources_0, _slot_0)), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1262$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1262$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058register_checked$1261$((_nextSystemId_0 < 4294967295), {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $application$058registered_exit$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _exit_0 = _result_0["snd"];
  return $application$058registered_transition$1261$(_exit_0, ($application$058register$1261$(_world_0, "transition")));
}

function $application$058register$1261$(_world_0, _name_0) {
  return $application$058entry_registered$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1263$(_world_0, _name_0, {$: "Con", "head": "cells:write", "tail": {$: "Con", "head": "owned:write", "tail": {$: "Con", "head": "machine:write", "tail": {$: "Nil"}}}})));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1261$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Reserved", "handle": {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $resource_reader$1260$(_rest_0, _pair_0, _owned_0, _localValues_0) {
  const _slotValue_0 = _rest_0["slot"];
  const _stream_0 = _rest_0["stream"];
  const _locals_0 = _rest_0["locals"];
  const _tick_0 = _rest_0["tick"];
  const _prefix_0 = _rest_0["prefix"];
  const _delivered_0 = _rest_0["delivered"];
  const _applied_0 = _rest_0["structuralApplied"];
  const _readerOwner_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  return $resource_arrays$1260$({$: "types.Resources", "owned": [0], "slot": _slotValue_0, "stream": _stream_0, "reader": _readerOwner_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, ($array$(_owned_0)), _localValues_0, _text_0);
}

function $reader$1260$(_owner_0, _positions_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": "null"};
  } else {
    const _t_0 = _owner_0["value"];
    const _ns_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _x_0 = ($position$(_positions_0));
    const _x_1 = (_x_0 + "}");
    const _x_2 = ($U32$show$(_id_0));
    const _x_3 = (",\"position\":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($U32$show$(_ns_0));
    const _x_6 = (",\"id\":" + _x_4);
    const _x_7 = (_x_5 + _x_6);
    return {$: "Tuple", "fst": {$: "Some", "value": {$: "../../../../src/ecs/machine-stream.Reader", "namespace": _ns_0, "id": _id_0}}, "snd": ("{\"namespace\":" + _x_7)};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1260$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058taken$1260$(_owners_0, _observed_0, _captured_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058prepared$1260$(_owners_0, _world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058prepare$1260$(_slot_0, _captured_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058snapshot_pending$1260$(_pending_0) {
  if (_pending_0.$ === "../../../../src/ecs/machine.NoPending") {
    return {$: "../../../../src/ecs/machine.Unscheduled"};
  } else {
    const _value_0 = _pending_0["value"];
    const _skipSame_0 = _pending_0["skipSame"];
    return {$: "../../../../src/ecs/machine.Scheduled", "value": _value_0, "skipSame": _skipSame_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take_join$1260$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _split_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _resources_0 = _split_0["fst"];
  const _slot_0 = _split_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _slot_0};
}

function $world$058take_resource$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _slot_0 = _resources_0["slot"];
  const _stream_0 = _resources_0["stream"];
  const _reader_0 = _resources_0["reader"];
  const _locals_0 = _resources_0["locals"];
  const _tick_0 = _resources_0["tick"];
  const _prefix_0 = _resources_0["prefix"];
  const _delivered_0 = _resources_0["delivered"];
  const _applied_0 = _resources_0["structuralApplied"];
  return {$: "Tuple", "fst": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "snd": _slot_0};
}

function $types$058condition$1260$(_atom_0, _env_0) {
  if (_atom_0.$ === "types.Current") {
    const _wanted_0 = _atom_0["value"];
    const _current_0 = _env_0["current"];
    return $types$058same$(_wanted_0, _current_0);
  } else {
    const _available_0 = _env_0["hasResource"];
    return _available_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045conditions$058both_next$1260$(_first_0, _env_0, _next_0) {
  if (!_first_0) {
    return false;
  } else {
    return run_tail(_next_0, _env_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045conditions$058either_next$1260$(_first_0, _env_0, _next_0) {
  if (!_first_0) {
    return run_tail(_next_0, _env_0);
  } else {
    return true;
  }
}

function $world$058put_resource$1260$(_resources_0, _slot_0) {
  const _owned_0 = _resources_0["owned"];
  const _stream_0 = _resources_0["stream"];
  const _reader_0 = _resources_0["reader"];
  const _locals_0 = _resources_0["locals"];
  const _tick_0 = _resources_0["tick"];
  const _prefix_0 = _resources_0["prefix"];
  const _delivered_0 = _resources_0["delivered"];
  const _applied_0 = _resources_0["structuralApplied"];
  return {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.RegistrationRejected", "error": {$: "../../../../src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $application$058registered_transition$1260$(_exit_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _transition_0 = _result_0["snd"];
  return $application$058assembled$1260$(_exit_0, _transition_0, ($application$058register$1260$(_world_0, "enter")));
}

function $application$058entry_registered$1260$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Nil"}};
  } else {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["registry"];
    const _namespace_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _name_0 = _t_0["name"];
    const _access_0 = _t_0["access"];
    const _cursor_0 = _t_0["cursor"];
    return {$: "Tuple", "fst": ($application$058install_local$1260$(_world_1, _id_0)), "snd": {$: "Con", "head": {$: "../../../../src/ecs/machine-handlers.Entry", "ordinal": _id_0, "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}}, "tail": {$: "Nil"}}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1261$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.Rejected", "error": {$: "../../../../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Accepted"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1261$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1261$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1261$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1261$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $resource_reader$1261$(_rest_0, _pair_0, _owned_0, _localValues_0) {
  const _slotValue_0 = _rest_0["slot"];
  const _stream_0 = _rest_0["stream"];
  const _locals_0 = _rest_0["locals"];
  const _tick_0 = _rest_0["tick"];
  const _prefix_0 = _rest_0["prefix"];
  const _delivered_0 = _rest_0["delivered"];
  const _applied_0 = _rest_0["structuralApplied"];
  const _readerOwner_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  return $resource_arrays$1261$({$: "types.Resources", "owned": [0], "slot": _slotValue_0, "stream": _stream_0, "reader": _readerOwner_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, ($array$(_owned_0)), _localValues_0, _text_0);
}

function $reader$1261$(_owner_0, _positions_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": "null"};
  } else {
    const _t_0 = _owner_0["value"];
    const _ns_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _x_0 = ($position$(_positions_0));
    const _x_1 = (_x_0 + "}");
    const _x_2 = ($U32$show$(_id_0));
    const _x_3 = (",\"position\":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($U32$show$(_ns_0));
    const _x_6 = (",\"id\":" + _x_4);
    const _x_7 = (_x_5 + _x_6);
    return {$: "Tuple", "fst": {$: "Some", "value": {$: "../../../../src/ecs/machine-stream.Reader", "namespace": _ns_0, "id": _id_0}}, "snd": ("{\"namespace\":" + _x_7)};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1262$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1262$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1262$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1262$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058taken$1261$(_owners_0, _observed_0, _captured_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058prepared$1261$(_owners_0, _world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058prepare$1261$(_slot_0, _captured_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045world$058take_join$1261$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _split_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _resources_0 = _split_0["fst"];
  const _slot_0 = _split_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _slot_0};
}

function $world$058take_resource$1261$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _slot_0 = _resources_0["slot"];
  const _stream_0 = _resources_0["stream"];
  const _reader_0 = _resources_0["reader"];
  const _locals_0 = _resources_0["locals"];
  const _tick_0 = _resources_0["tick"];
  const _prefix_0 = _resources_0["prefix"];
  const _delivered_0 = _resources_0["delivered"];
  const _applied_0 = _resources_0["structuralApplied"];
  return {$: "Tuple", "fst": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "snd": _slot_0};
}

function $types$058condition$1261$(_atom_0, _env_0) {
  if (_atom_0.$ === "types.Current") {
    const _wanted_0 = _atom_0["value"];
    const _current_0 = _env_0["current"];
    return $types$058same$(_wanted_0, _current_0);
  } else {
    const _available_0 = _env_0["hasResource"];
    return _available_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045conditions$058both_next$1261$(_first_0, _env_0, _next_0) {
  if (!_first_0) {
    return false;
  } else {
    return run_tail(_next_0, _env_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045conditions$058either_next$1261$(_first_0, _env_0, _next_0) {
  if (!_first_0) {
    return run_tail(_next_0, _env_0);
  } else {
    return true;
  }
}

function $world$058put_resource$1261$(_resources_0, _slot_0) {
  const _owned_0 = _resources_0["owned"];
  const _stream_0 = _resources_0["stream"];
  const _reader_0 = _resources_0["reader"];
  const _locals_0 = _resources_0["locals"];
  const _tick_0 = _resources_0["tick"];
  const _prefix_0 = _resources_0["prefix"];
  const _delivered_0 = _resources_0["delivered"];
  const _applied_0 = _resources_0["structuralApplied"];
  return {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1262$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058register_checked$1261$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.RegistrationRejected", "error": {$: "../../../../src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $application$058registered_transition$1261$(_exit_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _transition_0 = _result_0["snd"];
  return $application$058assembled$1261$(_exit_0, _transition_0, ($application$058register$1261$(_world_0, "enter")));
}

function $application$058entry_registered$1261$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Nil"}};
  } else {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["registry"];
    const _namespace_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _name_0 = _t_0["name"];
    const _access_0 = _t_0["access"];
    const _cursor_0 = _t_0["cursor"];
    return {$: "Tuple", "fst": ($application$058install_local$1261$(_world_1, _id_0)), "snd": {$: "Con", "head": {$: "../../../../src/ecs/machine-handlers.Entry", "ordinal": _id_0, "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}}, "tail": {$: "Nil"}}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1263$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.Rejected", "error": {$: "../../../../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Accepted"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, ($array$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($array$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek_view$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($array$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
  }
}

function $resource_arrays$1260$(_rest_0, _owner_0, _localValues_0, _readerText_0) {
  const _slotValue_0 = _rest_0["slot"];
  const _t_0 = _rest_0["stream"];
  const _batches_0 = _t_0["batches"];
  const _positions_0 = _t_0["positions"];
  const _dropped_0 = _t_0["droppedThrough"];
  const _start_0 = _t_0["frameStart"];
  const _readerOwner_0 = _rest_0["reader"];
  const _locals_0 = _rest_0["locals"];
  const _tick_0 = _rest_0["tick"];
  const _prefix_0 = _rest_0["prefix"];
  const _delivered_0 = _rest_0["delivered"];
  const _applied_0 = _rest_0["structuralApplied"];
  const _owned_0 = _owner_0["fst"];
  const _text_0 = _owner_0["snd"];
  const _x_0 = ($List$show$1263$(_prefix_0));
  const _x_1 = ($U32$show$(_applied_0));
  const _x_2 = (",\"prefix\":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($Nat$show$(_tick_0));
  const _x_5 = (",\"structuralApplied\":" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($List$show$1261$(_delivered_0));
  const _x_8 = (",\"tick\":" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($List$show$1262$(($batch_ticks$(_batches_0))));
  const _x_11 = (",\"deliveries\":" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($List$show$1261$(($batch_values$(_batches_0))));
  const _x_14 = (",\"publicationTicks\":" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = (",\"publications\":" + _x_15);
  const _x_17 = (_readerText_0 + _x_16);
  const _x_18 = ($slot$1260$(_slotValue_0));
  const _x_19 = (",\"streamReader\":" + _x_17);
  const _x_20 = (_x_18 + _x_19);
  const _x_21 = ($List$show$1260$(_localValues_0));
  const _x_22 = ("," + _x_20);
  const _x_23 = (_x_21 + _x_22);
  const _x_24 = (",\"locals\":" + _x_23);
  const _x_25 = (_text_0 + _x_24);
  return {$: "Tuple", "fst": {$: "types.Resources", "owned": _owned_0, "slot": _slotValue_0, "stream": {$: "../../../../src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _start_0}, "reader": _readerOwner_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "snd": ("\"resource\":" + _x_25)};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1260$({$: "../../../../src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058prepared$1260$(_owners_0, _world_0, _prepared_0) {
  const _exit_0 = _owners_0["exit"];
  const _transition_0 = _owners_0["transition"];
  const _enter_0 = _owners_0["enter"];
  if (_prepared_0.$ === "../../../../src/ecs/machine-handlers.Idle") {
    const _slot_0 = _prepared_0["slot"];
    return {$: "../../../../src/ecs/machine-handlers.Completed", "owners": {$: "../../../../src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": ($world$058put$1260$(_world_0, _slot_0))};
  } else {
    const _slot_1 = _prepared_0["slot"];
    const _t_0 = _prepared_0["transition"];
    const _from_0 = _t_0["from"];
    const _to_0 = _t_0["to"];
    const _skipSame_0 = _prepared_0["skipSame"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058after_exit$1260$(_transition_0, _enter_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058run_phase$1260$(_exit_0, ($world$058put$1260$(_world_0, _slot_1)), {$: "../../../../src/ecs/machine-handlers.Exit"}, _from_0, _to_0, {$: "None"})), _from_0, _to_0, _skipSame_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058prepare$1260$(_slot_0, _captured_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    if (_captured_0.$ === "../../../../src/ecs/machine.Unscheduled") {
      return {$: "../../../../src/ecs/machine-handlers.Idle", "slot": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058clear_changed$1260$({$: "../../../../src/ecs/machine.Missing"}))};
    } else {
      return {$: "../../../../src/ecs/machine-handlers.Idle", "slot": {$: "../../../../src/ecs/machine.Missing"}};
    }
  } else {
    const _current_0 = _slot_0["current"];
    const __2 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const __3 = _slot_0["changed"];
    if (_captured_0.$ === "../../../../src/ecs/machine.Unscheduled") {
      return {$: "../../../../src/ecs/machine-handlers.Idle", "slot": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058clear_changed$1260$({$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": __2, "previous": _previous_0, "changed": __3}))};
    } else {
      const _value_0 = _captured_0["value"];
      const _skipSame_0 = _captured_0["skipSame"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058choose$1260$(($Bool$and$(_skipSame_0, ($types$058same$(_current_0, _value_0)))), _current_0, _value_0, _previous_0, _skipSame_0);
    }
  }
}

function $application$058assembled$1260$(_exit_0, _transition_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _enter_0 = _result_0["snd"];
  return {$: "application.Application", "world": _world_0, "owners": {$: "../../../../src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "readerRegistry": {$: "None"}};
}

function $application$058install_local$1260$(_world_0, _id_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": ($List$append$(_locals_0, {$: "Con", "head": {$: "types.LocalOwner", "namespace": _ns_0, "id": _id_0, "cell": {$: "../../../../src/ecs/local.Cell", "local": [0]}}, "tail": {$: "Nil"}})), "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1261$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1261$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1261$(_values_0, _stamps_0, _id_0, ($array$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($array$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek_view$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1261$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1261$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($array$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
  }
}

function $resource_arrays$1261$(_rest_0, _owner_0, _localValues_0, _readerText_0) {
  const _slotValue_0 = _rest_0["slot"];
  const _t_0 = _rest_0["stream"];
  const _batches_0 = _t_0["batches"];
  const _positions_0 = _t_0["positions"];
  const _dropped_0 = _t_0["droppedThrough"];
  const _start_0 = _t_0["frameStart"];
  const _readerOwner_0 = _rest_0["reader"];
  const _locals_0 = _rest_0["locals"];
  const _tick_0 = _rest_0["tick"];
  const _prefix_0 = _rest_0["prefix"];
  const _delivered_0 = _rest_0["delivered"];
  const _applied_0 = _rest_0["structuralApplied"];
  const _owned_0 = _owner_0["fst"];
  const _text_0 = _owner_0["snd"];
  const _x_0 = ($List$show$1263$(_prefix_0));
  const _x_1 = ($U32$show$(_applied_0));
  const _x_2 = (",\"prefix\":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($Nat$show$(_tick_0));
  const _x_5 = (",\"structuralApplied\":" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($List$show$1261$(_delivered_0));
  const _x_8 = (",\"tick\":" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($List$show$1262$(($batch_ticks$(_batches_0))));
  const _x_11 = (",\"deliveries\":" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($List$show$1261$(($batch_values$(_batches_0))));
  const _x_14 = (",\"publicationTicks\":" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = (",\"publications\":" + _x_15);
  const _x_17 = (_readerText_0 + _x_16);
  const _x_18 = ($slot$1261$(_slotValue_0));
  const _x_19 = (",\"streamReader\":" + _x_17);
  const _x_20 = (_x_18 + _x_19);
  const _x_21 = ($List$show$1260$(_localValues_0));
  const _x_22 = ("," + _x_20);
  const _x_23 = (_x_21 + _x_22);
  const _x_24 = (",\"locals\":" + _x_23);
  const _x_25 = (_text_0 + _x_24);
  return {$: "Tuple", "fst": {$: "types.Resources", "owned": _owned_0, "slot": _slotValue_0, "stream": {$: "../../../../src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _start_0}, "reader": _readerOwner_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "snd": ("\"resource\":" + _x_25)};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1262$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1262$({$: "../../../../src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1262$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1262$((_namespace_0 === _actual_0), {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058prepared$1261$(_owners_0, _world_0, _prepared_0) {
  const _exit_0 = _owners_0["exit"];
  const _transition_0 = _owners_0["transition"];
  const _enter_0 = _owners_0["enter"];
  if (_prepared_0.$ === "../../../../src/ecs/machine-handlers.Idle") {
    const _slot_0 = _prepared_0["slot"];
    return {$: "../../../../src/ecs/machine-handlers.Completed", "owners": {$: "../../../../src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": ($world$058put$1261$(_world_0, _slot_0))};
  } else {
    const _slot_1 = _prepared_0["slot"];
    const _t_0 = _prepared_0["transition"];
    const _from_0 = _t_0["from"];
    const _to_0 = _t_0["to"];
    const _skipSame_0 = _prepared_0["skipSame"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058after_exit$1261$(_transition_0, _enter_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058run_phase$1261$(_exit_0, ($world$058put$1261$(_world_0, _slot_1)), {$: "../../../../src/ecs/machine-handlers.Exit"}, _from_0, _to_0, {$: "None"})), _from_0, _to_0, _skipSame_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058prepare$1261$(_slot_0, _captured_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    if (_captured_0.$ === "../../../../src/ecs/machine.Unscheduled") {
      return {$: "../../../../src/ecs/machine-handlers.Idle", "slot": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058clear_changed$1261$({$: "../../../../src/ecs/machine.Missing"}))};
    } else {
      return {$: "../../../../src/ecs/machine-handlers.Idle", "slot": {$: "../../../../src/ecs/machine.Missing"}};
    }
  } else {
    const _current_0 = _slot_0["current"];
    const __2 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const __3 = _slot_0["changed"];
    if (_captured_0.$ === "../../../../src/ecs/machine.Unscheduled") {
      return {$: "../../../../src/ecs/machine-handlers.Idle", "slot": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058clear_changed$1261$({$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": __2, "previous": _previous_0, "changed": __3}))};
    } else {
      const _value_0 = _captured_0["value"];
      const _skipSame_0 = _captured_0["skipSame"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058choose$1261$(($Bool$and$(_skipSame_0, ($types$058same$(_current_0, _value_0)))), _current_0, _value_0, _previous_0, _skipSame_0);
    }
  }
}

function $application$058assembled$1261$(_exit_0, _transition_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _enter_0 = _result_0["snd"];
  return {$: "application.Application", "world": _world_0, "owners": {$: "../../../../src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "readerRegistry": {$: "None"}};
}

function $application$058install_local$1261$(_world_0, _id_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": ($List$append$(_locals_0, {$: "Con", "head": {$: "types.LocalOwner", "namespace": _ns_0, "id": _id_0, "cell": {$: "../../../../src/ecs/local.Cell", "local": [0]}}, "tail": {$: "Nil"}})), "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1263$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed$1260$(($array$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return {$: "../../../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($array$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0) {
  return {$: "../../../../src/ecs/column.Indexed", "state": {$: "../../../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, ($array$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($array$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $slot$1260$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/machine.Missing") {
    return "\"current\":null,\"pending\":null,\"previous\":null,\"changed\":false";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _prior_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($bool$(_changed_0));
    const _x_1 = ($previous$(_prior_0));
    const _x_2 = (",\"changed\":" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($pending$(_next_0));
    const _x_5 = (",\"previous\":" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    const _x_7 = ($state$(_current_0));
    const _x_8 = (",\"pending\":" + _x_6);
    const _x_9 = (_x_7 + _x_8);
    return ("\"current\":" + _x_9);
  }
}

function $List$show$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($transition$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($Nat$show$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($quote$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1260$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../src/ecs/system.Completed", "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1260$({$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058after_exit$1260$(_transition_0, _enter_0, _observed_0, _from_0, _to_0, _skipSame_0) {
  if (_observed_0.$ === "../../../../src/ecs/machine-handlers.Failed") {
    const _exit_0 = _observed_0["entries"];
    const _world_0 = _observed_0["world"];
    const _error_0 = _observed_0["error"];
    return {$: "../../../../src/ecs/machine-handlers.Stopped", "owners": {$: "../../../../src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058requeued$1260$(($world$058take$1260$(_world_0)), _to_0, _skipSame_0)), "phase": {$: "../../../../src/ecs/machine-handlers.Exit"}, "error": _error_0};
  } else {
    const _exit_1 = _observed_0["entries"];
    const _world_1 = _observed_0["world"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058after_transition$1260$(_exit_1, _enter_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058run_phase$1260$(_transition_0, _world_1, {$: "../../../../src/ecs/machine-handlers.Transition"}, _from_0, _to_0, {$: "None"})), _from_0, _to_0, _skipSame_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058run_phase$1260$(_entries_0, _world_0, _phase_0, _from_0, _to_0, _error_0) {
  if (_entries_0.$ === "Nil") {
    if (_error_0.$ === "Some") {
      const _error_1 = _error_0["value"];
      return {$: "../../../../src/ecs/machine-handlers.Failed", "entries": {$: "Nil"}, "world": _world_0, "error": _error_1};
    } else {
      return {$: "../../../../src/ecs/machine-handlers.Complete", "entries": {$: "Nil"}, "world": _world_0};
    }
  } else {
    const _t_0 = _entries_0["head"];
    const _ordinal_0 = _t_0["ordinal"];
    const _registry_0 = _t_0["registry"];
    const _rest_0 = _entries_0["tail"];
    if (_error_0.$ === "Some") {
      const _error_2 = _error_0["value"];
      return {$: "../../../../src/ecs/machine-handlers.Failed", "entries": {$: "Con", "head": {$: "../../../../src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_0}, "tail": _rest_0}, "world": _world_0, "error": _error_2};
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058entry_result$1260$(_ordinal_0, ($$$$047$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1261$(_registry_0, _world_0, {$: "../../../../src/ecs/machine-handlers.Invocation", "phase": _phase_0, "ordinal": _ordinal_0, "from": _from_0, "to": _to_0})), run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058run_phase$1260$(_rest_0, _x_0, _phase_0, _from_0, _to_0, _x_1);
});
}));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058clear_changed$1260$(_slot_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    return {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": _pending_0, "previous": _previous_0, "changed": false};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058choose$1260$(_skip_0, _current_0, _value_0, _previous_0, _skipSame_0) {
  if (_skip_0) {
    return {$: "../../../../src/ecs/machine-handlers.Idle", "slot": {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../src/ecs/machine.NoPending"}, "previous": _previous_0, "changed": false}};
  } else {
    return {$: "../../../../src/ecs/machine-handlers.Ready", "slot": {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../src/ecs/machine.NoPending"}, "previous": {$: "Some", "value": _current_0}, "changed": false}, "transition": {$: "../../../../src/ecs/machine.Transition", "from": _current_0, "to": _value_0}, "skipSame": _skipSame_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1261$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1261$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1261$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed$1261$(($array$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return {$: "../../../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek_view$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($array$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0) {
  return {$: "../../../../src/ecs/column.Indexed", "state": {$: "../../../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1261$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, ($array$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($array$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $slot$1261$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/machine.Missing") {
    return "\"current\":null,\"pending\":null,\"previous\":null,\"changed\":false";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _prior_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($bool$(_changed_0));
    const _x_1 = ($previous$(_prior_0));
    const _x_2 = (",\"changed\":" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($pending$(_next_0));
    const _x_5 = (",\"previous\":" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    const _x_7 = ($state$(_current_0));
    const _x_8 = (",\"pending\":" + _x_6);
    const _x_9 = (_x_7 + _x_8);
    return ("\"current\":" + _x_9);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1262$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../src/ecs/system.Completed", "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1262$({$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058after_exit$1261$(_transition_0, _enter_0, _observed_0, _from_0, _to_0, _skipSame_0) {
  if (_observed_0.$ === "../../../../src/ecs/machine-handlers.Failed") {
    const _exit_0 = _observed_0["entries"];
    const _world_0 = _observed_0["world"];
    const _error_0 = _observed_0["error"];
    return {$: "../../../../src/ecs/machine-handlers.Stopped", "owners": {$: "../../../../src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058requeued$1261$(($world$058take$1261$(_world_0)), _to_0, _skipSame_0)), "phase": {$: "../../../../src/ecs/machine-handlers.Exit"}, "error": _error_0};
  } else {
    const _exit_1 = _observed_0["entries"];
    const _world_1 = _observed_0["world"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058after_transition$1261$(_exit_1, _enter_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058run_phase$1261$(_transition_0, _world_1, {$: "../../../../src/ecs/machine-handlers.Transition"}, _from_0, _to_0, {$: "None"})), _from_0, _to_0, _skipSame_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058run_phase$1261$(_entries_0, _world_0, _phase_0, _from_0, _to_0, _error_0) {
  if (_entries_0.$ === "Nil") {
    if (_error_0.$ === "Some") {
      const _error_1 = _error_0["value"];
      return {$: "../../../../src/ecs/machine-handlers.Failed", "entries": {$: "Nil"}, "world": _world_0, "error": _error_1};
    } else {
      return {$: "../../../../src/ecs/machine-handlers.Complete", "entries": {$: "Nil"}, "world": _world_0};
    }
  } else {
    const _t_0 = _entries_0["head"];
    const _ordinal_0 = _t_0["ordinal"];
    const _registry_0 = _t_0["registry"];
    const _rest_0 = _entries_0["tail"];
    if (_error_0.$ === "Some") {
      const _error_2 = _error_0["value"];
      return {$: "../../../../src/ecs/machine-handlers.Failed", "entries": {$: "Con", "head": {$: "../../../../src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_0}, "tail": _rest_0}, "world": _world_0, "error": _error_2};
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058entry_result$1261$(_ordinal_0, ($$$$047$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1263$(_registry_0, _world_0, {$: "../../../../src/ecs/machine-handlers.Invocation", "phase": _phase_0, "ordinal": _ordinal_0, "from": _from_0, "to": _to_0})), run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058run_phase$1261$(_rest_0, _x_0, _phase_0, _from_0, _to_0, _x_1);
});
}));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$058clear_changed$1261$(_slot_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    return {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": _pending_0, "previous": _previous_0, "changed": false};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058choose$1261$(_skip_0, _current_0, _value_0, _previous_0, _skipSame_0) {
  if (_skip_0) {
    return {$: "../../../../src/ecs/machine-handlers.Idle", "slot": {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../src/ecs/machine.NoPending"}, "previous": _previous_0, "changed": false}};
  } else {
    return {$: "../../../../src/ecs/machine-handlers.Ready", "slot": {$: "../../../../src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../src/ecs/machine.NoPending"}, "previous": {$: "Some", "value": _current_0}, "changed": false}, "transition": {$: "../../../../src/ecs/machine.Transition", "from": _current_0, "to": _value_0}, "skipSame": _skipSame_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1263$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1263$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1260$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed$1260$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$({$: "../../../../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$({$: "../../../../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $List$show$go$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($transition$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $List$show$go$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($Nat$show$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $List$show$go$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($quote$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058requeued$1260$(_observed_0, _to_0, _skipSame_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return $world$058put$1260$(_world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058queue$1260$(_slot_0, _to_0, _skipSame_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058after_transition$1260$(_exit_0, _enter_0, _observed_0, _from_0, _to_0, _skipSame_0) {
  if (_observed_0.$ === "../../../../src/ecs/machine-handlers.Failed") {
    const _transition_0 = _observed_0["entries"];
    const _world_0 = _observed_0["world"];
    const _error_0 = _observed_0["error"];
    return {$: "../../../../src/ecs/machine-handlers.Stopped", "owners": {$: "../../../../src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058requeued$1260$(($world$058take$1260$(_world_0)), _to_0, _skipSame_0)), "phase": {$: "../../../../src/ecs/machine-handlers.Transition"}, "error": _error_0};
  } else {
    const _transition_1 = _observed_0["entries"];
    const _world_1 = _observed_0["world"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058after_enter$1260$(_exit_0, _transition_1, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058run_phase$1260$(_enter_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058published$1260$(($world$058take$1260$(_world_1)), _from_0, _to_0)), {$: "../../../../src/ecs/machine-handlers.Enter"}, _from_0, _to_0, {$: "None"})));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058entry_result$1260$(_ordinal_0, _observed_0, _next_0) {
  if (_observed_0.$ === "../../../../src/ecs/system.Completed") {
    const _registry_0 = _observed_0["registry"];
    const _outcome_0 = _observed_0["outcome"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058entry_outcome$1260$(_ordinal_0, _registry_0, _outcome_0, _next_0);
  } else {
    const _registry_1 = _observed_0["registry"];
    const _world_0 = _observed_0["world"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058prepend$1260$({$: "../../../../src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_1}, _next_0(_world_0)({$: "Some", "value": "HandlerRegistrationRejected"}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1261$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed$1261$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1261$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_result_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$({$: "../../../../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1261$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_result_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$({$: "../../../../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1261$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1262$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058requeued$1261$(_observed_0, _to_0, _skipSame_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return $world$058put$1261$(_world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058queue$1261$(_slot_0, _to_0, _skipSame_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058after_transition$1261$(_exit_0, _enter_0, _observed_0, _from_0, _to_0, _skipSame_0) {
  if (_observed_0.$ === "../../../../src/ecs/machine-handlers.Failed") {
    const _transition_0 = _observed_0["entries"];
    const _world_0 = _observed_0["world"];
    const _error_0 = _observed_0["error"];
    return {$: "../../../../src/ecs/machine-handlers.Stopped", "owners": {$: "../../../../src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058requeued$1261$(($world$058take$1261$(_world_0)), _to_0, _skipSame_0)), "phase": {$: "../../../../src/ecs/machine-handlers.Transition"}, "error": _error_0};
  } else {
    const _transition_1 = _observed_0["entries"];
    const _world_1 = _observed_0["world"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058after_enter$1261$(_exit_0, _transition_1, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058run_phase$1261$(_enter_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058published$1261$(($world$058take$1261$(_world_1)), _from_0, _to_0)), {$: "../../../../src/ecs/machine-handlers.Enter"}, _from_0, _to_0, {$: "None"})));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058entry_result$1261$(_ordinal_0, _observed_0, _next_0) {
  if (_observed_0.$ === "../../../../src/ecs/system.Completed") {
    const _registry_0 = _observed_0["registry"];
    const _outcome_0 = _observed_0["outcome"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058entry_outcome$1261$(_ordinal_0, _registry_0, _outcome_0, _next_0);
  } else {
    const _registry_1 = _observed_0["registry"];
    const _world_0 = _observed_0["world"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058prepend$1261$({$: "../../../../src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_1}, _next_0(_world_0)({$: "Some", "value": "HandlerRegistrationRejected"}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1263$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1263$(_registry_0, _world_0, _args_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1263$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_view_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swapped$1260$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1260$(_registry_0, ($systems$058reader_runner$1260$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058after_enter$1260$(_exit_0, _transition_0, _observed_0) {
  if (_observed_0.$ === "../../../../src/ecs/machine-handlers.Complete") {
    const _enter_0 = _observed_0["entries"];
    const _world_0 = _observed_0["world"];
    return {$: "../../../../src/ecs/machine-handlers.Completed", "owners": {$: "../../../../src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": _world_0};
  } else {
    const _enter_1 = _observed_0["entries"];
    const _world_1 = _observed_0["world"];
    const _error_0 = _observed_0["error"];
    return {$: "../../../../src/ecs/machine-handlers.Stopped", "owners": {$: "../../../../src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_1}, "world": _world_1, "phase": {$: "../../../../src/ecs/machine-handlers.Enter"}, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058published$1260$(_observed_0, _from_0, _to_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return $application$058published$1260$(($world$058put$1260$(_world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058committed$1260$(_slot_0, _from_0, _to_0)))), {$: "../../../../src/ecs/machine.Transition", "from": _from_0, "to": _to_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058entry_outcome$1260$(_ordinal_0, _registry_0, _outcome_0, _next_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058prepend$1260$({$: "../../../../src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_0}, _next_0(_world_0)({$: "Some", "value": _error_0}));
  } else {
    const _world_1 = _outcome_0["world"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058prepend$1260$({$: "../../../../src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_0}, _next_0(_world_1)({$: "None"}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058prepend$1260$(_head_0, _tail_0) {
  if (_tail_0.$ === "../../../../src/ecs/machine-handlers.Complete") {
    const _entries_0 = _tail_0["entries"];
    const _world_0 = _tail_0["world"];
    return {$: "../../../../src/ecs/machine-handlers.Complete", "entries": {$: "Con", "head": _head_0, "tail": _entries_0}, "world": _world_0};
  } else {
    const _entries_1 = _tail_0["entries"];
    const _world_1 = _tail_0["world"];
    const _error_0 = _tail_0["error"];
    return {$: "../../../../src/ecs/machine-handlers.Failed", "entries": {$: "Con", "head": _head_0, "tail": _entries_1}, "world": _world_1, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1261$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1261$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1261$(_registry_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_view_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1261$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swapped$1261$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1261$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1262$(_registry_0, ($systems$058reader_runner$1261$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058after_enter$1261$(_exit_0, _transition_0, _observed_0) {
  if (_observed_0.$ === "../../../../src/ecs/machine-handlers.Complete") {
    const _enter_0 = _observed_0["entries"];
    const _world_0 = _observed_0["world"];
    return {$: "../../../../src/ecs/machine-handlers.Completed", "owners": {$: "../../../../src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_0}, "world": _world_0};
  } else {
    const _enter_1 = _observed_0["entries"];
    const _world_1 = _observed_0["world"];
    const _error_0 = _observed_0["error"];
    return {$: "../../../../src/ecs/machine-handlers.Stopped", "owners": {$: "../../../../src/ecs/machine-handlers.Owners", "exit": _exit_0, "transition": _transition_0, "enter": _enter_1}, "world": _world_1, "phase": {$: "../../../../src/ecs/machine-handlers.Enter"}, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058published$1261$(_observed_0, _from_0, _to_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return $application$058published$1261$(($world$058put$1261$(_world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058committed$1261$(_slot_0, _from_0, _to_0)))), {$: "../../../../src/ecs/machine.Transition", "from": _from_0, "to": _to_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058entry_outcome$1261$(_ordinal_0, _registry_0, _outcome_0, _next_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058prepend$1261$({$: "../../../../src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_0}, _next_0(_world_0)({$: "Some", "value": _error_0}));
  } else {
    const _world_1 = _outcome_0["world"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058prepend$1261$({$: "../../../../src/ecs/machine-handlers.Entry", "ordinal": _ordinal_0, "registry": _registry_0}, _next_0(_world_1)({$: "None"}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058prepend$1261$(_head_0, _tail_0) {
  if (_tail_0.$ === "../../../../src/ecs/machine-handlers.Complete") {
    const _entries_0 = _tail_0["entries"];
    const _world_0 = _tail_0["world"];
    return {$: "../../../../src/ecs/machine-handlers.Complete", "entries": {$: "Con", "head": _head_0, "tail": _entries_0}, "world": _world_0};
  } else {
    const _entries_1 = _tail_0["entries"];
    const _world_1 = _tail_0["world"];
    const _error_0 = _tail_0["error"];
    return {$: "../../../../src/ecs/machine-handlers.Failed", "entries": {$: "Con", "head": _head_0, "tail": _entries_1}, "world": _world_1, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1263$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1263$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1263$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1263$(_registry_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swapped$1260$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $systems$058reader_runner$1260$(_world_0, __0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $systems$058reader_selected$1260$({$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058empty$1260$()), "reader": {$: "None"}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, _reader_0, _stream_0, _ns_0, _tick_0);
}

function $application$058published$1260$(_world_0, _event_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058publish$1260$(_stream_0, _tick_0, _event_0)), "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058committed$1260$(_slot_0, _from_0, _to_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Missing"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return {$: "../../../../src/ecs/machine.Present", "current": _to_0, "pending": _pending_0, "previous": {$: "Some", "value": _from_0}, "changed": true};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1261$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1261$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swapped$1261$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1262$(_registry_0, _outcome_0) {
  return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $systems$058reader_runner$1261$(_world_0, __0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $systems$058reader_selected$1261$({$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058empty$1260$()), "reader": {$: "None"}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, _reader_0, _stream_0, _ns_0, _tick_0);
}

function $application$058published$1261$(_world_0, _event_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058publish$1260$(_stream_0, _tick_0, _event_0)), "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045handlers$058committed$1261$(_slot_0, _from_0, _to_0) {
  if (_slot_0.$ === "../../../../src/ecs/machine.Missing") {
    return {$: "../../../../src/ecs/machine.Missing"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return {$: "../../../../src/ecs/machine.Present", "current": _to_0, "pending": _pending_0, "previous": {$: "Some", "value": _from_0}, "changed": true};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1263$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1263$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1263$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1263$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1260$({$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1260$({$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $systems$058reader_selected$1260$(_world_0, _reader_0, _stream_0, _ns_0, _tick_0) {
  if (_reader_0.$ === "None") {
    return $systems$058read_missing$1260$(_world_0, _stream_0);
  } else {
    const _reader_1 = _reader_0["value"];
    return $systems$058read_opened$1260$(_world_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058open$1260$(_reader_1, _stream_0, _ns_0, _tick_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058publish$1260$(_stream_0, _tick_0, _event_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return {$: "../../../../src/ecs/machine-stream.Stream", "batches": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1261$(_batches_0, {$: "Con", "head": {$: "../../../../src/ecs/event-runtime.Batch", "tick": _tick_0, "values": {$: "Con", "head": _event_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}})), "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1261$({$: "../../../../src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1261$((_namespace_0 === _actual_0), {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1261$({$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1261$({$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $systems$058reader_selected$1261$(_world_0, _reader_0, _stream_0, _ns_0, _tick_0) {
  if (_reader_0.$ === "None") {
    return $systems$058read_missing$1261$(_world_0, _stream_0);
  } else {
    const _reader_1 = _reader_0["value"];
    return $systems$058read_opened$1261$(_world_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058open$1261$(_reader_1, _stream_0, _ns_0, _tick_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1263$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1263$({$: "../../../../src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1263$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1263$((_namespace_0 === _actual_0), {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1260$(_column_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_state$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $systems$058read_missing$1260$(_world_0, _stream_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/system.Failed", "world": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": {$: "None"}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "error": "MissingReader"};
}

function $systems$058read_opened$1260$(_world_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/machine-stream.ReaderRefused") {
    const _reader_0 = _result_0["reader"];
    const _stream_0 = _result_0["stream"];
    return $systems$058read_refused$1260$(_world_0, _reader_0, _stream_0);
  } else {
    const _reader_1 = _result_0["reader"];
    const _stream_1 = _result_0["stream"];
    const _t_0 = _result_0["reading"];
    const _values_0 = _t_0["values"];
    return $systems$058read_finished$1260$(_world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058finish$1260$(_reader_1, _stream_1, _tick_0, true)), _values_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058open$1260$(_reader_0, _stream_0, _namespace_0, _tick_0) {
  const _owner_0 = _reader_0["namespace"];
  const _id_0 = _reader_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058open_checked$1260$((_owner_0 === _namespace_0), {$: "../../../../src/ecs/machine-stream.Reader", "namespace": _owner_0, "id": _id_0}, _stream_0, _tick_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1261$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1261$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1261$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../src/ecs/system.Completed", "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1261$({$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1261$(_column_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_state$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $systems$058read_missing$1261$(_world_0, _stream_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/system.Failed", "world": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": {$: "None"}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "error": "MissingReader"};
}

function $systems$058read_opened$1261$(_world_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/machine-stream.ReaderRefused") {
    const _reader_0 = _result_0["reader"];
    const _stream_0 = _result_0["stream"];
    return $systems$058read_refused$1261$(_world_0, _reader_0, _stream_0);
  } else {
    const _reader_1 = _result_0["reader"];
    const _stream_1 = _result_0["stream"];
    const _t_0 = _result_0["reading"];
    const _values_0 = _t_0["values"];
    return $systems$058read_finished$1261$(_world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058finish$1261$(_reader_1, _stream_1, _tick_0, true)), _values_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058open$1261$(_reader_0, _stream_0, _namespace_0, _tick_0) {
  const _owner_0 = _reader_0["namespace"];
  const _id_0 = _reader_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058open_checked$1261$((_owner_0 === _namespace_0), {$: "../../../../src/ecs/machine-stream.Reader", "namespace": _owner_0, "id": _id_0}, _stream_0, _tick_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1263$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../src/ecs/system.Completed", "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1263$({$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $systems$058read_refused$1260$(_world_0, _reader_0, _stream_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/system.Failed", "world": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": {$: "Some", "value": _reader_0}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "error": "ForeignReader"};
}

function $systems$058read_finished$1260$(_world_0, _pair_0, _values_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _reader_0 = _pair_0["fst"];
  const _stream_0 = _pair_0["snd"];
  return {$: "../../../../src/ecs/system.Succeeded", "world": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": {$: "Some", "value": _reader_0}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": ($List$append$(_delivered_0, _values_0)), "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "output": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058finish$1260$(_reader_0, _stream_0, _tick_0, _success_0) {
  const _namespace_0 = _reader_0["namespace"];
  const _id_0 = _reader_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": _id_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058complete$1260$(_stream_0, _id_0, _tick_0, _success_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058open_checked$1260$(_allowed_0, _reader_0, _stream_0, _tick_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/machine-stream.ReaderRefused", "reader": _reader_0, "stream": _stream_0};
  } else {
    const _namespace_0 = _reader_0["namespace"];
    const _id_0 = _reader_0["id"];
    return {$: "../../../../src/ecs/machine-stream.Opened", "reader": {$: "../../../../src/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": _id_0}, "stream": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058activate$1260$(_stream_0, _id_0, _tick_0)), "reading": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058observe$1260$(_stream_0, _id_0, _tick_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1261$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $systems$058read_refused$1261$(_world_0, _reader_0, _stream_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/system.Failed", "world": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": {$: "Some", "value": _reader_0}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "error": "ForeignReader"};
}

function $systems$058read_finished$1261$(_world_0, _pair_0, _values_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _reader_0 = _pair_0["fst"];
  const _stream_0 = _pair_0["snd"];
  return {$: "../../../../src/ecs/system.Succeeded", "world": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": {$: "Some", "value": _reader_0}, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": ($List$append$(_delivered_0, _values_0)), "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "output": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058finish$1261$(_reader_0, _stream_0, _tick_0, _success_0) {
  const _namespace_0 = _reader_0["namespace"];
  const _id_0 = _reader_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": _id_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058complete$1260$(_stream_0, _id_0, _tick_0, _success_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058open_checked$1261$(_allowed_0, _reader_0, _stream_0, _tick_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/machine-stream.ReaderRefused", "reader": _reader_0, "stream": _stream_0};
  } else {
    const _namespace_0 = _reader_0["namespace"];
    const _id_0 = _reader_0["id"];
    return {$: "../../../../src/ecs/machine-stream.Opened", "reader": {$: "../../../../src/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": _id_0}, "stream": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058activate$1260$(_stream_0, _id_0, _tick_0)), "reading": ($$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058observe$1260$(_stream_0, _id_0, _tick_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1263$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058complete$1260$(_stream_0, _id_0, _tick_0, _success_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  if (_success_0) {
    return {$: "../../../../src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _tick_0, false)), "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
  } else {
    return {$: "../../../../src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058activate$1260$(_stream_0, _id_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return {$: "../../../../src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _tick_0)), "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058observe$1260$(_stream_0, _id_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058observe_position$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _batches_0, _dropped_0, _id_0, _tick_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1261$(_registry_0, ($systems$058runner$1260$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1263$(_registry_0, ($systems$058runner$1261$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047machine$045stream$058observe_position$1260$(_position_0, _batches_0, _dropped_0, _id_0, _tick_0) {
  if (_position_0.$ === "None") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058reading$1260$({$: "../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _tick_0}, _batches_0, _dropped_0);
  } else {
    const _position_1 = _position_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058reading$1260$(_position_1, _batches_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1261$(_registry_0, _outcome_0) {
  return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $systems$058runner$1260$(_world_0, _invocation_0) {
  const _phase_0 = _invocation_0["phase"];
  const _ordinal_0 = _invocation_0["ordinal"];
  const _from_0 = _invocation_0["from"];
  const _to_0 = _invocation_0["to"];
  return $systems$058invoked$1260$(($systems$058attempt_world$1260$(($systems$058touch_local$1260$(_world_0, _ordinal_0)), _ordinal_0)), {$: "../../../../src/ecs/machine-handlers.Invocation", "phase": _phase_0, "ordinal": _ordinal_0, "from": _from_0, "to": _to_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1263$(_registry_0, _outcome_0) {
  return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $systems$058runner$1261$(_world_0, _invocation_0) {
  const _phase_0 = _invocation_0["phase"];
  const _ordinal_0 = _invocation_0["ordinal"];
  const _from_0 = _invocation_0["from"];
  const _to_0 = _invocation_0["to"];
  return $systems$058invoked$1261$(($systems$058attempt_world$1261$(($systems$058touch_local$1261$(_world_0, _ordinal_0)), _ordinal_0)), {$: "../../../../src/ecs/machine-handlers.Invocation", "phase": _phase_0, "ordinal": _ordinal_0, "from": _from_0, "to": _to_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058reading$1260$(_position_0, _batches_0, _dropped_0) {
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../../../../src/ecs/event-runtime.Reading", "values": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $systems$058invoked$1260$(_observed_0, _invocation_0) {
  const _world_0 = _observed_0["fst"];
  const __0 = _observed_0["snd"];
  const _t_0 = _invocation_0["phase"];
  if (_t_0.$ === "../../../../src/ecs/machine-handlers.Exit") {
    return $systems$058gameplay$1260$(_world_0, 1, "exit", false);
  } else if (_t_0.$ === "../../../../src/ecs/machine-handlers.Transition") {
    return $systems$058gameplay$1260$(_world_0, 10, "transition", (__0 === 1));
  } else {
    const __9 = _invocation_0["to"];
    return $systems$058entered$1260$(__9, ($systems$058gameplay$1260$(_world_0, 100, "enter", false)));
  }
}

function $systems$058attempt_world$1260$(_world_0, _id_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $systems$058attempt_world_join$1260$({$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": {$: "Nil"}, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, ($systems$058attempts$(_locals_0, _ns_0, _id_0)));
}

function $systems$058touch_local$1260$(_world_0, _id_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": ($systems$058locals_increment$(_locals_0, _ns_0, _id_0)), "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $systems$058invoked$1261$(_observed_0, _invocation_0) {
  const _world_0 = _observed_0["fst"];
  const __0 = _observed_0["snd"];
  const _t_0 = _invocation_0["phase"];
  if (_t_0.$ === "../../../../src/ecs/machine-handlers.Exit") {
    return $systems$058gameplay$1261$(_world_0, 1, "exit", false);
  } else if (_t_0.$ === "../../../../src/ecs/machine-handlers.Transition") {
    return $systems$058gameplay$1261$(_world_0, 10, "transition", (__0 === 1));
  } else {
    const __9 = _invocation_0["to"];
    return $systems$058entered$1261$(__9, ($systems$058gameplay$1261$(_world_0, 100, "enter", false)));
  }
}

function $systems$058attempt_world$1261$(_world_0, _id_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $systems$058attempt_world_join$1261$({$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": {$: "Nil"}, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, ($systems$058attempts$(_locals_0, _ns_0, _id_0)));
}

function $systems$058touch_local$1261$(_world_0, _id_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": ($systems$058locals_increment$(_locals_0, _ns_0, _id_0)), "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since_checked$1260$((_cursor_0 < _tick_0), _items_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since$1260$(_rest_0, _cursor_0)));
  }
}

function $systems$058gameplay$1260$(_world_0, _amount_0, _name_0, _fail_0) {
  return $systems$058finished$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(($systems$058change_component$1260$(($systems$058change_resource$1260$(_world_0, _amount_0)), _amount_0)), run_clo((_x_0) => {
  return $systems$058structural$1260$(_x_0);
}))), _name_0, _fail_0);
}

function $systems$058entered$1260$(_to_0, _result_0) {
  if (_to_0.$ === "types.Play") {
    if (_result_0.$ === "../../../../src/ecs/system.Succeeded") {
      const _world_0 = _result_0["world"];
      const _output_0 = _result_0["output"];
      return {$: "../../../../src/ecs/system.Succeeded", "world": ($systems$058queue_join$1260$(($world$058take$1260$(_world_0)))), "output": _output_0};
    } else {
      return _result_0;
    }
  } else {
    return _result_0;
  }
}

function $systems$058attempt_world_join$1260$(_world_0, _pair_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _locals_0 = _pair_0["fst"];
  const _count_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _count_0};
}

function $systems$058gameplay$1261$(_world_0, _amount_0, _name_0, _fail_0) {
  return $systems$058finished$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1261$(($systems$058change_component$1261$(($systems$058change_resource$1261$(_world_0, _amount_0)), _amount_0)), run_clo((_x_0) => {
  return $systems$058structural$1261$(_x_0);
}))), _name_0, _fail_0);
}

function $systems$058entered$1261$(_to_0, _result_0) {
  if (_to_0.$ === "types.Play") {
    if (_result_0.$ === "../../../../src/ecs/system.Succeeded") {
      const _world_0 = _result_0["world"];
      const _output_0 = _result_0["output"];
      return {$: "../../../../src/ecs/system.Succeeded", "world": ($systems$058queue_join$1261$(($world$058take$1261$(_world_0)))), "output": _output_0};
    } else {
      return _result_0;
    }
  } else {
    return _result_0;
  }
}

function $systems$058attempt_world_join$1261$(_world_0, _pair_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _locals_0 = _pair_0["fst"];
  const _count_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _count_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since_checked$1260$(_visible_0, _items_0, _rest_0) {
  if (!_visible_0) {
    return _rest_0;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1260$(_items_0, _rest_0);
  }
}

function $systems$058finished$1260$(_tx_0, _name_0, _fail_0) {
  if (_fail_0) {
    return $systems$058committed_prefix$1260$(_name_0, ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, {$: "../../../../src/ecs/transaction.Failure", "error": "once"})));
  } else {
    return $systems$058committed_prefix$1260$(_name_0, ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, {$: "../../../../src/ecs/transaction.Success"})));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $systems$058change_component$1260$(_tx_0, _amount_0) {
  const _t_0 = _tx_0["world"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["nextId"];
  const _high_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _capacity_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _t_1 = _t_0["store"];
  const _column_0 = _t_1["column"];
  const _resources_0 = _t_0["resource"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSystem_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _emitted_0 = _tx_0["events"];
  return $systems$058component_stamp$1260$({$: "../../../../src/ecs/transaction.Tx", "world": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "types.Store", "column": {$: "../../../../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}}}, "resource": _resources_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "undo": _undo_0, "commands": _commands_0, "events": _emitted_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1260$(_column_0, 1)), _amount_0, _clock_0);
}

function $systems$058change_resource$1260$(_world_0, _amount_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $systems$058resource_changed$1260$({$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": [0], "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, ($systems$058increment$(_owned_0, _amount_0)));
}

function $systems$058structural$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": ((_applied_0 + 1) >>> 0)}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $systems$058queue_join$1260$(_pair_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return $world$058put$1260$(_world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058queue$1260$(_slot_0, {$: "types.Pause"}, false)));
}

function $systems$058finished$1261$(_tx_0, _name_0, _fail_0) {
  if (_fail_0) {
    return $systems$058committed_prefix$1261$(_name_0, ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, {$: "../../../../src/ecs/transaction.Failure", "error": "once"})));
  } else {
    return $systems$058committed_prefix$1261$(_name_0, ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, {$: "../../../../src/ecs/transaction.Success"})));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1261$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $systems$058change_component$1261$(_tx_0, _amount_0) {
  const _t_0 = _tx_0["world"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["nextId"];
  const _high_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _capacity_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _t_1 = _t_0["store"];
  const _column_0 = _t_1["column"];
  const _resources_0 = _t_0["resource"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSystem_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _emitted_0 = _tx_0["events"];
  return $systems$058component_stamp$1261$({$: "../../../../src/ecs/transaction.Tx", "world": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "types.Store", "column": {$: "../../../../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}}}, "resource": _resources_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "undo": _undo_0, "commands": _commands_0, "events": _emitted_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1261$(_column_0, 1)), _amount_0, _clock_0);
}

function $systems$058change_resource$1261$(_world_0, _amount_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $systems$058resource_changed$1261$({$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": [0], "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, ($systems$058increment$(_owned_0, _amount_0)));
}

function $systems$058structural$1261$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": ((_applied_0 + 1) >>> 0)}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $systems$058queue_join$1261$(_pair_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return $world$058put$1261$(_world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047machine$058queue$1261$(_slot_0, {$: "types.Pause"}, false)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1260$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1260$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $systems$058committed_prefix$1260$(_name_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../../../src/ecs/transaction.Failure") {
    const _error_0 = _t_0["error"];
    return {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0};
  } else {
    return {$: "../../../../src/ecs/system.Succeeded", "world": ($systems$058prefix$1260$(_world_0, _name_0)), "output": {$: "Unit"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $systems$058component_stamp$1260$(_tx_0, _pair_0, _amount_0, _clock_0) {
  const _column_0 = _pair_0["fst"];
  const _stamp_0 = _pair_0["snd"];
  return $systems$058component_written$1260$(_tx_0, ($systems$058changed_taken$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(_column_0, 1, {$: "None"})), _amount_0)), _stamp_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $systems$058resource_changed$1260$(_world_0, _pair_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _owned_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058add_undo$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$({$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0})), run_clo((_x_0) => {
  return $systems$058restore_resource$1260$(_x_0, _old_0);
}));
}

function $systems$058committed_prefix$1261$(_name_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../../../src/ecs/transaction.Failure") {
    const _error_0 = _t_0["error"];
    return {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0};
  } else {
    return {$: "../../../../src/ecs/system.Succeeded", "world": ($systems$058prefix$1261$(_world_0, _name_0)), "output": {$: "Unit"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $systems$058component_stamp$1261$(_tx_0, _pair_0, _amount_0, _clock_0) {
  const _column_0 = _pair_0["fst"];
  const _stamp_0 = _pair_0["snd"];
  return $systems$058component_written$1261$(_tx_0, ($systems$058changed_taken$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(_column_0, 1, {$: "None"})), _amount_0)), _stamp_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $systems$058resource_changed$1261$(_world_0, _pair_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _owned_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058add_undo$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$({$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0})), run_clo((_x_0) => {
  return $systems$058restore_resource$1261$(_x_0, _old_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $systems$058prefix$1260$(_world_0, _name_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prior_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": ($List$append$(_prior_0, {$: "Con", "head": _name_0, "tail": {$: "Nil"}})), "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/transaction.Success") {
    const _committed_0 = ($systems$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../src/ecs/transaction.Returned", "world": ($systems$058discard_unit_events$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $systems$058component_written$1260$(_tx_0, _pair_0, _stamp_0, _oldClock_0) {
  const _t_0 = _tx_0["world"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["nextId"];
  const _high_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _capacity_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _resources_0 = _t_0["resource"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSystem_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _emitted_0 = _tx_0["events"];
  const _column_0 = _pair_0["fst"];
  const _t_1 = _pair_0["snd"];
  if (_t_1.$ === "Some") {
    const _old_0 = _t_1["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058add_undo$1260$({$: "../../../../src/ecs/transaction.Tx", "world": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "types.Store", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058mark$1260$(_column_0, 1, true, true, ((_clock_0 + 1) >>> 0)))}, "resource": _resources_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": ((_clock_0 + 1) >>> 0)}, "undo": _undo_0, "commands": _commands_0, "events": _emitted_0}, run_clo((_x_0) => {
  return $systems$058restore_component$1260$(_x_0, _old_0, _stamp_0, _oldClock_0);
}));
  } else {
    return {$: "../../../../src/ecs/transaction.Tx", "world": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "types.Store", "column": _column_0}, "resource": _resources_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "undo": _undo_0, "commands": _commands_0, "events": _emitted_0};
  }
}

function $systems$058changed_taken$1260$(_result_0, _amount_0) {
  if (_result_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _t_0 = _result_0["previous"];
    if (_t_0.$ === "Some") {
      const _owner_0 = _t_0["value"];
      return $systems$058changed_owner$1260$(_column_0, ($systems$058increment$(_owner_0, _amount_0)));
    } else {
      return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
    }
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058add_undo$1260$(_tx_0, _inverse_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": _inverse_0, "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $systems$058restore_resource$1260$(_world_0, _value_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": (_owned_0[0 % _owned_0.length] = _value_0, _owned_0), "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $systems$058prefix$1261$(_world_0, _name_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prior_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": _owned_0, "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": ($List$append$(_prior_0, {$: "Con", "head": _name_0, "tail": {$: "Nil"}})), "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/transaction.Success") {
    const _committed_0 = ($systems$058enqueue$1261$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../src/ecs/transaction.Returned", "world": ($systems$058discard_unit_events$1261$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1261$(_undo_0, _world_0)), "outcome": {$: "../../../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $systems$058component_written$1261$(_tx_0, _pair_0, _stamp_0, _oldClock_0) {
  const _t_0 = _tx_0["world"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["nextId"];
  const _high_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _capacity_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _resources_0 = _t_0["resource"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSystem_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _emitted_0 = _tx_0["events"];
  const _column_0 = _pair_0["fst"];
  const _t_1 = _pair_0["snd"];
  if (_t_1.$ === "Some") {
    const _old_0 = _t_1["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058add_undo$1261$({$: "../../../../src/ecs/transaction.Tx", "world": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "types.Store", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058mark$1261$(_column_0, 1, true, true, ((_clock_0 + 1) >>> 0)))}, "resource": _resources_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": ((_clock_0 + 1) >>> 0)}, "undo": _undo_0, "commands": _commands_0, "events": _emitted_0}, run_clo((_x_0) => {
  return $systems$058restore_component$1261$(_x_0, _old_0, _stamp_0, _oldClock_0);
}));
  } else {
    return {$: "../../../../src/ecs/transaction.Tx", "world": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "types.Store", "column": _column_0}, "resource": _resources_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "undo": _undo_0, "commands": _commands_0, "events": _emitted_0};
  }
}

function $systems$058changed_taken$1261$(_result_0, _amount_0) {
  if (_result_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _t_0 = _result_0["previous"];
    if (_t_0.$ === "Some") {
      const _owner_0 = _t_0["value"];
      return $systems$058changed_owner$1261$(_column_0, ($systems$058increment$(_owner_0, _amount_0)));
    } else {
      return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
    }
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1261$(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1261$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058add_undo$1261$(_tx_0, _inverse_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": _inverse_0, "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0) {
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $systems$058restore_resource$1261$(_world_0, _value_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _stream_0 = _t_0["stream"];
  const _reader_0 = _t_0["reader"];
  const _locals_0 = _t_0["locals"];
  const _tick_0 = _t_0["tick"];
  const _prefix_0 = _t_0["prefix"];
  const _delivered_0 = _t_0["delivered"];
  const _applied_0 = _t_0["structuralApplied"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "types.Resources", "owned": (_owned_0[0 % _owned_0.length] = _value_0, _owned_0), "slot": _slot_0, "stream": _stream_0, "reader": _reader_0, "locals": _locals_0, "tick": _tick_0, "prefix": _prefix_0, "delivered": _delivered_0, "structuralApplied": _applied_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $systems$058enqueue$1260$(_world_0, _commands_0) {
  return $systems$058enqueue_all$1260$(_commands_0, _world_0);
}

function $systems$058discard_unit_events$1260$(_world_0, __0) {
  return _world_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $systems$058restore_component$1260$(_world_0, _value_0, _stamp_0, _oldClock_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _t_0 = _world_0["store"];
  const _column_0 = _t_0["column"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $systems$058restore_component_result$1260$({$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "types.Store", "column": {$: "../../../../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}}}, "resource": _resources_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, ($systems$058restore_taken$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(_column_0, 1, {$: "None"})), _value_0)), _stamp_0, _oldClock_0);
}

function $systems$058changed_owner$1260$(_column_0, _pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": ($systems$058restored_swap$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(_column_0, 1, {$: "Some", "value": _owner_0})))), "snd": {$: "Some", "value": _old_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $systems$058enqueue$1261$(_world_0, _commands_0) {
  return $systems$058enqueue_all$1261$(_commands_0, _world_0);
}

function $systems$058discard_unit_events$1261$(_world_0, __0) {
  return _world_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1261$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $systems$058restore_component$1261$(_world_0, _value_0, _stamp_0, _oldClock_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _t_0 = _world_0["store"];
  const _column_0 = _t_0["column"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $systems$058restore_component_result$1261$({$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "types.Store", "column": {$: "../../../../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}}}, "resource": _resources_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, ($systems$058restore_taken$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(_column_0, 1, {$: "None"})), _value_0)), _stamp_0, _oldClock_0);
}

function $systems$058changed_owner$1261$(_column_0, _pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": ($systems$058restored_swap$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(_column_0, 1, {$: "Some", "value": _owner_0})))), "snd": {$: "Some", "value": _old_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1261$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1261$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $systems$058enqueue_all$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $systems$058restore_component_result$1260$(_world_0, _pair_0, _stamp_0, _oldClock_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _column_0 = _pair_0["fst"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "types.Store", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1260$(_column_0, 1, _stamp_0))}, "resource": _resources_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _oldClock_0};
}

function $systems$058restore_taken$1260$(_result_0, _value_0) {
  if (_result_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _t_0 = _result_0["previous"];
    if (_t_0.$ === "Some") {
      const _owner_0 = _t_0["value"];
      return {$: "Tuple", "fst": ($systems$058restored_swap$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(_column_0, 1, {$: "Some", "value": (_owner_0[0 % _owner_0.length] = _value_0, _owner_0)})))), "snd": {$: "Some", "value": {$: "Unit"}}};
    } else {
      return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
    }
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $systems$058restored_swap$1260$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return _column_0;
  } else {
    const _column_1 = _result_0["column"];
    return _column_1;
  }
}

function $systems$058enqueue_all$1261$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $systems$058restore_component_result$1261$(_world_0, _pair_0, _stamp_0, _oldClock_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _column_0 = _pair_0["fst"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": {$: "types.Store", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1261$(_column_0, 1, _stamp_0))}, "resource": _resources_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _oldClock_0};
}

function $systems$058restore_taken$1261$(_result_0, _value_0) {
  if (_result_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _t_0 = _result_0["previous"];
    if (_t_0.$ === "Some") {
      const _owner_0 = _t_0["value"];
      return {$: "Tuple", "fst": ($systems$058restored_swap$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(_column_0, 1, {$: "Some", "value": (_owner_0[0 % _owner_0.length] = _value_0, _owner_0)})))), "snd": {$: "Some", "value": {$: "Unit"}}};
    } else {
      return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
    }
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $systems$058restored_swap$1261$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return _column_0;
  } else {
    const _column_1 = _result_0["column"];
    return _column_1;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1261$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $0m0(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/world.Growth": at = at[key] = {...v, "depth": BigInt(v["depth"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/world.Growth has no tag " + v?.$ + " (its tags: ../../../../src/ecs/world.Growth); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m2(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/owner-handoff.Rows": at = at[key] = {...v, "depth": BigInt(v["depth"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/owner-handoff.Rows has no tag " + v?.$ + " (its tags: ../../../../src/ecs/owner-handoff.Rows); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m1(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m2(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m3(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/indexed-lifecycle.Metadata": at = at[key] = {...v, "depth": BigInt(v["depth"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/indexed-lifecycle.Metadata has no tag " + v?.$ + " (its tags: ../../../../src/ecs/indexed-lifecycle.Metadata); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m4(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m3(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m5(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/indexed-lifecycle.Metadata": at = at[key] = {...v, "depth": nat_host(v["depth"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/indexed-lifecycle.Metadata has no tag " + v?.$ + " (its tags: ../../../../src/ecs/indexed-lifecycle.Metadata); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m7(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/event-runtime.Position": at = at[key] = {...v, "cursor": nat_host(v["cursor"]), "registeredAt": nat_host(v["registeredAt"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/event-runtime.Position has no tag " + v?.$ + " (its tags: ../../../../src/ecs/event-runtime.Position); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m6(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m7(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m9(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/event-runtime.Position": at = at[key] = {...v, "cursor": BigInt(v["cursor"]), "registeredAt": BigInt(v["registeredAt"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/event-runtime.Position has no tag " + v?.$ + " (its tags: ../../../../src/ecs/event-runtime.Position); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m8(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m9(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m10(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "None": at[key] = v; return top[0];
      case "Some": at = at[key] = {...v, "value": $0m7(v["value"])}; return top[0];
      default: throw "bend: Maybe has no tag " + v?.$ + " (its tags: None, Some); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m11(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "None": at[key] = v; return top[0];
      case "Some": at = at[key] = {...v, "value": $0m9(v["value"])}; return top[0];
      default: throw "bend: Maybe has no tag " + v?.$ + " (its tags: None, Some); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m13(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/event-runtime.Batch": at = at[key] = {...v, "tick": nat_host(v["tick"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/event-runtime.Batch has no tag " + v?.$ + " (its tags: ../../../../src/ecs/event-runtime.Batch); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m12(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m13(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m15(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/event-runtime.Batch": at = at[key] = {...v, "tick": BigInt(v["tick"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/event-runtime.Batch has no tag " + v?.$ + " (its tags: ../../../../src/ecs/event-runtime.Batch); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m14(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m15(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m16(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": BigInt(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m23(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/column.IndexedOrdinaryState": at = at[key] = {...v, "metadata": $0m5(v["metadata"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/column.IndexedOrdinaryState has no tag " + v?.$ + " (its tags: ../../../../src/ecs/column.IndexedOrdinaryState); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m22(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/column.IndexedOrdinaryOwned": at = at[key] = {...v, "state": $0m23(v["state"])}; return top[0];
      case "../../../../src/ecs/column.IndexedOrdinaryWrapped": at = at[key] = {...v}; key = "inner"; v = v[key]; continue;
      default: throw "bend: ../../../../src/ecs/column.IndexedOrdinaryCarrier has no tag " + v?.$ + " (its tags: ../../../../src/ecs/column.IndexedOrdinaryOwned, ../../../../src/ecs/column.IndexedOrdinaryWrapped); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m25(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/column.IndexedPreparedState": at = at[key] = {...v, "metadata": $0m5(v["metadata"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/column.IndexedPreparedState has no tag " + v?.$ + " (its tags: ../../../../src/ecs/column.IndexedPreparedState); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m24(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/column.IndexedPreparedOwned": at = at[key] = {...v, "state": $0m25(v["state"])}; return top[0];
      case "../../../../src/ecs/column.IndexedPreparedWrapped": at = at[key] = {...v}; key = "inner"; v = v[key]; continue;
      default: throw "bend: ../../../../src/ecs/column.IndexedPreparedCarrier has no tag " + v?.$ + " (its tags: ../../../../src/ecs/column.IndexedPreparedOwned, ../../../../src/ecs/column.IndexedPreparedWrapped); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m21(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/column.Column": at[key] = v; return top[0];
      case "../../../../src/ecs/column.Prepared": at[key] = v; return top[0];
      case "../../../../src/ecs/column.Indexed": at = at[key] = {...v, "state": $0m22(v["state"])}; return top[0];
      case "../../../../src/ecs/column.PreparedIndexed": at = at[key] = {...v, "state": $0m24(v["state"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/column.Column has no tag " + v?.$ + " (its tags: ../../../../src/ecs/column.Column, ../../../../src/ecs/column.Prepared, ../../../../src/ecs/column.Indexed, ../../../../src/ecs/column.PreparedIndexed); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m20(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "types.Store": at = at[key] = {...v, "column": $0m21(v["column"])}; return top[0];
      default: throw "bend: types.Store has no tag " + v?.$ + " (its tags: types.Store); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m27(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/machine-stream.Stream": at = at[key] = {...v, "batches": $0m12(v["batches"]), "positions": $0m6(v["positions"]), "droppedThrough": nat_host(v["droppedThrough"]), "frameStart": nat_host(v["frameStart"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/machine-stream.Stream has no tag " + v?.$ + " (its tags: ../../../../src/ecs/machine-stream.Stream); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m26(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "types.Resources": at = at[key] = {...v, "stream": $0m27(v["stream"]), "tick": nat_host(v["tick"])}; return top[0];
      default: throw "bend: types.Resources has no tag " + v?.$ + " (its tags: types.Resources); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m33(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/column.IndexedOrdinaryState": at = at[key] = {...v, "metadata": $0m3(v["metadata"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/column.IndexedOrdinaryState has no tag " + v?.$ + " (its tags: ../../../../src/ecs/column.IndexedOrdinaryState); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m32(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/column.IndexedOrdinaryOwned": at = at[key] = {...v, "state": $0m33(v["state"])}; return top[0];
      case "../../../../src/ecs/column.IndexedOrdinaryWrapped": at = at[key] = {...v}; key = "inner"; v = v[key]; continue;
      default: throw "bend: ../../../../src/ecs/column.IndexedOrdinaryCarrier has no tag " + v?.$ + " (its tags: ../../../../src/ecs/column.IndexedOrdinaryOwned, ../../../../src/ecs/column.IndexedOrdinaryWrapped); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m35(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/column.IndexedPreparedState": at = at[key] = {...v, "metadata": $0m3(v["metadata"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/column.IndexedPreparedState has no tag " + v?.$ + " (its tags: ../../../../src/ecs/column.IndexedPreparedState); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m34(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/column.IndexedPreparedOwned": at = at[key] = {...v, "state": $0m35(v["state"])}; return top[0];
      case "../../../../src/ecs/column.IndexedPreparedWrapped": at = at[key] = {...v}; key = "inner"; v = v[key]; continue;
      default: throw "bend: ../../../../src/ecs/column.IndexedPreparedCarrier has no tag " + v?.$ + " (its tags: ../../../../src/ecs/column.IndexedPreparedOwned, ../../../../src/ecs/column.IndexedPreparedWrapped); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m31(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/column.Column": at[key] = v; return top[0];
      case "../../../../src/ecs/column.Prepared": at[key] = v; return top[0];
      case "../../../../src/ecs/column.Indexed": at = at[key] = {...v, "state": $0m32(v["state"])}; return top[0];
      case "../../../../src/ecs/column.PreparedIndexed": at = at[key] = {...v, "state": $0m34(v["state"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/column.Column has no tag " + v?.$ + " (its tags: ../../../../src/ecs/column.Column, ../../../../src/ecs/column.Prepared, ../../../../src/ecs/column.Indexed, ../../../../src/ecs/column.PreparedIndexed); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m30(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "types.Store": at = at[key] = {...v, "column": $0m31(v["column"])}; return top[0];
      default: throw "bend: types.Store has no tag " + v?.$ + " (its tags: types.Store); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m37(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/machine-stream.Stream": at = at[key] = {...v, "batches": $0m14(v["batches"]), "positions": $0m8(v["positions"]), "droppedThrough": BigInt(v["droppedThrough"]), "frameStart": BigInt(v["frameStart"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/machine-stream.Stream has no tag " + v?.$ + " (its tags: ../../../../src/ecs/machine-stream.Stream); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m36(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "types.Resources": at = at[key] = {...v, "stream": $0m37(v["stream"]), "tick": BigInt(v["tick"])}; return top[0];
      default: throw "bend: types.Resources has no tag " + v?.$ + " (its tags: types.Resources); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m38(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": ((f) => (x) => $0m29(f($0m19(x))))(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m29(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/world.World": at = at[key] = {...v, "depth": BigInt(v["depth"]), "store": $0m30(v["store"]), "resource": $0m36(v["resource"]), "pending": $0m38(v["pending"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/world.World has no tag " + v?.$ + " (its tags: ../../../../src/ecs/world.World); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m28(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": ((f) => (x) => $0m19(f($0m29(x))))(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m19(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/world.World": at = at[key] = {...v, "depth": nat_host(v["depth"]), "store": $0m20(v["store"]), "resource": $0m26(v["resource"]), "pending": $0m28(v["pending"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/world.World has no tag " + v?.$ + " (its tags: ../../../../src/ecs/world.World); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m42(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/system.Registry": at[key] = v; return top[0];
      default: throw "bend: ../../../../src/ecs/system.Registry has no tag " + v?.$ + " (its tags: ../../../../src/ecs/system.Registry); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m41(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/machine-handlers.Entry": at = at[key] = {...v, "registry": $0m42(v["registry"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/machine-handlers.Entry has no tag " + v?.$ + " (its tags: ../../../../src/ecs/machine-handlers.Entry); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m40(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m41(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m39(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/machine-handlers.Owners": at = at[key] = {...v, "exit": $0m40(v["exit"]), "transition": $0m40(v["transition"]), "enter": $0m40(v["enter"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/machine-handlers.Owners has no tag " + v?.$ + " (its tags: ../../../../src/ecs/machine-handlers.Owners); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m44(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/system.Registry": at[key] = v; return top[0];
      default: throw "bend: ../../../../src/ecs/system.Registry has no tag " + v?.$ + " (its tags: ../../../../src/ecs/system.Registry); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m43(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "None": at[key] = v; return top[0];
      case "Some": at = at[key] = {...v, "value": $0m44(v["value"])}; return top[0];
      default: throw "bend: Maybe has no tag " + v?.$ + " (its tags: None, Some); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m18(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "application.Application": at = at[key] = {...v, "world": $0m19(v["world"]), "owners": $0m39(v["owners"]), "readerRegistry": $0m43(v["readerRegistry"])}; return top[0];
      default: throw "bend: application.Application has no tag " + v?.$ + " (its tags: application.Application); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m17(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "application.Constructed": at = at[key] = {...v, "application": $0m18(v["application"])}; return top[0];
      case "application.ConstructionRefused": at[key] = v; return top[0];
      default: throw "bend: application.Construction has no tag " + v?.$ + " (its tags: application.Constructed, application.ConstructionRefused); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m50(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/system.Registry": at[key] = v; return top[0];
      default: throw "bend: ../../../../src/ecs/system.Registry has no tag " + v?.$ + " (its tags: ../../../../src/ecs/system.Registry); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m49(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/machine-handlers.Entry": at = at[key] = {...v, "registry": $0m50(v["registry"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/machine-handlers.Entry has no tag " + v?.$ + " (its tags: ../../../../src/ecs/machine-handlers.Entry); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m48(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m49(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m47(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/machine-handlers.Owners": at = at[key] = {...v, "exit": $0m48(v["exit"]), "transition": $0m48(v["transition"]), "enter": $0m48(v["enter"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/machine-handlers.Owners has no tag " + v?.$ + " (its tags: ../../../../src/ecs/machine-handlers.Owners); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m52(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/system.Registry": at[key] = v; return top[0];
      default: throw "bend: ../../../../src/ecs/system.Registry has no tag " + v?.$ + " (its tags: ../../../../src/ecs/system.Registry); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m51(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "None": at[key] = v; return top[0];
      case "Some": at = at[key] = {...v, "value": $0m52(v["value"])}; return top[0];
      default: throw "bend: Maybe has no tag " + v?.$ + " (its tags: None, Some); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m46(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "application.Application": at = at[key] = {...v, "world": $0m29(v["world"]), "owners": $0m47(v["owners"]), "readerRegistry": $0m51(v["readerRegistry"])}; return top[0];
      default: throw "bend: application.Application has no tag " + v?.$ + " (its tags: application.Application); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m45(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "application.Constructed": at = at[key] = {...v, "application": $0m46(v["application"])}; return top[0];
      case "application.ConstructionRefused": at[key] = v; return top[0];
      default: throw "bend: application.Construction has no tag " + v?.$ + " (its tags: application.Constructed, application.ConstructionRefused); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}
export default {
  "../../../../src/ecs/string-equality.equal_walk": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/string-equality.equal": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/string-equality.access_equal": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058access_equal$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/string-equality.registration_equal": run_lib((a0, a1, a2, a3, a4, a5) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058registration_equal$((a0), (a1), (a2), (a3), (a4), (a5)))); (a0); (a1); (a2); (a3); (a4); (a5); return r; }, 6),
  "../../../../src/ecs/world.factory": run_lib(() => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()));  return r; }, 0),
  "../../../../src/ecs/world.grow_live": run_lib((a0, a1, a2, a3) => { const r = $0m0(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058grow_live$(nat_host(a0), (a1), nat_host(a2), (a3)))); BigInt(a0); (a1); BigInt(a2); (a3); return r; }, 4),
  "../../../../src/ecs/world.access_equal": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058access_equal$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/world.matching_access": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_access$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/world.matching_id": run_lib((a0, a1, a2, a3, a4) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_id$((a0), (a1), (a2), (a3), (a4)))); (a0); (a1); (a2); (a3); (a4); return r; }, 5),
  "../../../../src/ecs/world.registration_meta_matches": run_lib((a0, a1, a2, a3) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$((a0), (a1), (a2), (a3)))); (a0); (a1); (a2); (a3); return r; }, 4),
  "../../../../src/ecs/world.registration_list_walk": run_lib((a0, a1, a2, a3, a4) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$((a0), (a1), (a2), (a3), (a4)))); (a0); (a1); (a2); (a3); (a4); return r; }, 5),
  "../../../../src/ecs/world.registration_list_matches": run_lib((a0, a1, a2, a3) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$((a0), (a1), (a2), (a3)))); (a0); (a1); (a2); (a3); return r; }, 4),
  "../../../../src/ecs/world.next_clock": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/lifecycle.choose": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058choose$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/lifecycle.get": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/lifecycle.keep": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058keep$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/lifecycle.clear": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/lifecycle.set": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/lifecycle.written": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058written$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/lifecycle.after_write": run_lib((a0, a1, a2, a3) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$((a0), (a1), (a2), (a3)))); (a0); (a1); (a2); (a3); return r; }, 4),
  "../../../../src/ecs/lifecycle.added": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058added$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/lifecycle.changed": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058changed$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/owner-handoff.selected": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058selected$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/owner-handoff.prototype_handoff_restore_state": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_restore_state$((a0), (a1), (a2), (a3), (a4), (a5), (a6), (a7), (a8)))); (a0); (a1); (a2); (a3); (a4); (a5); (a6); (a7); (a8); return r; }, 9),
  "../../../../src/ecs/owner-handoff.prototype_handoff_inspect_state": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_inspect_state$((a0), (a1), (a2), (a3), (a4), (a5), (a6), (a7), (a8)))); (a0); (a1); (a2); (a3); (a4); (a5); (a6); (a7); (a8); return r; }, 9),
  "../../../../src/ecs/owner-handoff.prototype_handoff_finish_forward": run_lib((a0, a1, a2, a3) => { const r = $0m1(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_finish_forward$((a0), nat_host(a1), (a2), (a3)))); (a0); BigInt(a1); (a2); (a3); return r; }, 4),
  "../../../../src/ecs/owner-handoff.prototype_handoff_recover_go": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_recover_go$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/owner-handoff.prototype_handoff_recover": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_recover$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/indexed-lifecycle.empty": run_lib(() => { const r = $0m3(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058empty$()));  return r; }, 0),
  "../../../../src/ecs/indexed-lifecycle.normal": run_lib((a0) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$((a0)))); (a0); return r; }, 1),
  "../../../../src/ecs/indexed-lifecycle.got_changed": run_lib((a0, a1, a2, a3, a4, a5) => { const r = $0m4(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_changed$((a0), (a1), nat_host(a2), (a3), (a4), (a5)))); (a0); (a1); BigInt(a2); (a3); (a4); (a5); return r; }, 6),
  "../../../../src/ecs/indexed-lifecycle.got_added": run_lib((a0, a1, a2, a3, a4, a5) => { const r = $0m4(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_added$((a0), (a1), (a2), nat_host(a3), (a4), (a5)))); (a0); (a1); (a2); BigInt(a3); (a4); (a5); return r; }, 6),
  "../../../../src/ecs/indexed-lifecycle.get_checked": run_lib((a0, a1, a2, a3, a4, a5, a6, a7) => { const r = $0m4(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get_checked$((a0), (a1), (a2), (a3), nat_host(a4), (a5), (a6), (a7)))); (a0); (a1); (a2); (a3); BigInt(a4); (a5); (a6); (a7); return r; }, 8),
  "../../../../src/ecs/indexed-lifecycle.get": run_lib((a0, a1) => { const r = $0m4(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$($0m5(a0), (a1)))); $0m3(a0); (a1); return r; }, 2),
  "../../../../src/ecs/indexed-lifecycle.write_ready": run_lib((a0, a1, a2, a3, a4, a5, a6) => { const r = $0m3(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$((a0), (a1), (a2), (a3), nat_host(a4), (a5), (a6)))); (a0); (a1); (a2); (a3); BigInt(a4); (a5); (a6); return r; }, 7),
  "../../../../src/ecs/indexed-lifecycle.write_grow": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8) => { const r = $0m3(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_grow$(nat_host(a0), (a1), (a2), (a3), (a4), (a5), nat_host(a6), (a7), (a8)))); BigInt(a0); (a1); (a2); (a3); (a4); (a5); BigInt(a6); (a7); (a8); return r; }, 9),
  "../../../../src/ecs/indexed-lifecycle.set_checked": run_lib((a0, a1, a2, a3, a4, a5, a6, a7) => { const r = $0m3(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set_checked$((a0), (a1), (a2), (a3), (a4), nat_host(a5), (a6), (a7)))); (a0); (a1); (a2); (a3); (a4); BigInt(a5); (a6); (a7); return r; }, 8),
  "../../../../src/ecs/indexed-lifecycle.set": run_lib((a0, a1, a2) => { const r = $0m3(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$($0m5(a0), (a1), (a2)))); $0m3(a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/indexed-lifecycle.clear_checked": run_lib((a0, a1, a2, a3, a4, a5, a6, a7) => { const r = $0m3(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear_checked$((a0), (a1), (a2), (a3), nat_host(a4), (a5), (a6), (a7)))); (a0); (a1); (a2); (a3); BigInt(a4); (a5); (a6); (a7); return r; }, 8),
  "../../../../src/ecs/indexed-lifecycle.clear": run_lib((a0, a1) => { const r = $0m3(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$($0m5(a0), (a1)))); $0m3(a0); (a1); return r; }, 2),
  "../../../../src/ecs/column.recover_selected_rows": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/registration.retained": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047registration$058retained$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/registration.without": run_lib((a0, a1, a2, a3) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047registration$058without$((a0), (a1), (a2), (a3)))); (a0); (a1); (a2); (a3); return r; }, 4),
  "../../../../src/ecs/event-runtime.hold_boundary": run_lib((a0, a1) => { const r = BigInt(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058hold_boundary$($0m6(a0), nat_host(a1)))); $0m8(a0); BigInt(a1); return r; }, 2),
  "../../../../src/ecs/event-runtime.update_checked": run_lib((a0, a1, a2, a3, a4, a5, a6) => { const r = $0m8(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update_checked$((a0), (a1), (a2), nat_host(a3), nat_host(a4), $0m6(a5), nat_host(a6)))); (a0); (a1); (a2); BigInt(a3); BigInt(a4); $0m8(a5); BigInt(a6); return r; }, 7),
  "../../../../src/ecs/event-runtime.update": run_lib((a0, a1, a2, a3) => { const r = $0m8(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$($0m6(a0), (a1), nat_host(a2), (a3)))); $0m8(a0); (a1); BigInt(a2); (a3); return r; }, 4),
  "../../../../src/ecs/event-runtime.choose_position": run_lib((a0, a1, a2) => { const r = $0m11(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058choose_position$((a0), $0m7(a1), $0m10(a2)))); (a0); $0m9(a1); $0m11(a2); return r; }, 3),
  "../../../../src/ecs/event-runtime.lookup_checked": run_lib((a0, a1, a2) => { const r = $0m11(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup_checked$($0m7(a0), (a1), $0m10(a2)))); $0m9(a0); (a1); $0m11(a2); return r; }, 3),
  "../../../../src/ecs/event-runtime.lookup": run_lib((a0, a1) => { const r = $0m11(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$($0m6(a0), (a1)))); $0m8(a0); (a1); return r; }, 2),
  "../../../../src/ecs/event-runtime.activation": run_lib((a0, a1, a2, a3) => { const r = $0m8(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activation$($0m10(a0), $0m6(a1), (a2), nat_host(a3)))); $0m11(a0); $0m8(a1); (a2); BigInt(a3); return r; }, 4),
  "../../../../src/ecs/event-runtime.activate": run_lib((a0, a1, a2) => { const r = $0m8(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$($0m6(a0), (a1), nat_host(a2)))); $0m8(a0); (a1); BigInt(a2); return r; }, 3),
  "types.same": run_lib((a0, a1) => { const r = (run_loop($types$058same$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "systems.projected": run_lib((a0, a1) => { const r = (run_loop($systems$058projected$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "systems.increment": run_lib((a0, a1) => { const r = (run_loop($systems$058increment$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "systems.local_incremented": run_lib((a0) => { const r = (run_loop($systems$058local_incremented$((a0)))); (a0); return r; }, 1),
  "systems.local_increment": run_lib((a0) => { const r = (run_loop($systems$058local_increment$((a0)))); (a0); return r; }, 1),
  "systems.local_join": run_lib((a0, a1) => { const r = (run_loop($systems$058local_join$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "systems.local_selected": run_lib((a0, a1, a2, a3, a4) => { const r = (run_loop($systems$058local_selected$((a0), (a1), (a2), (a3), (a4)))); (a0); (a1); (a2); (a3); (a4); return r; }, 5),
  "systems.locals_increment": run_lib((a0, a1, a2) => { const r = (run_loop($systems$058locals_increment$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "systems.set_value": run_lib((a0, a1) => { const r = (run_loop($systems$058set_value$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "systems.local_count_value": run_lib((a0) => { const r = (run_loop($systems$058local_count_value$((a0)))); (a0); return r; }, 1),
  "systems.local_count": run_lib((a0) => { const r = (run_loop($systems$058local_count$((a0)))); (a0); return r; }, 1),
  "systems.attempt_join": run_lib((a0, a1) => { const r = (run_loop($systems$058attempt_join$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "systems.attempt_observed": run_lib((a0, a1, a2, a3) => { const r = (run_loop($systems$058attempt_observed$((a0), (a1), (a2), (a3)))); (a0); (a1); (a2); (a3); return r; }, 4),
  "systems.attempt_selected": run_lib((a0, a1, a2, a3, a4) => { const r = (run_loop($systems$058attempt_selected$((a0), (a1), (a2), (a3), (a4)))); (a0); (a1); (a2); (a3); (a4); return r; }, 5),
  "systems.attempts": run_lib((a0, a1, a2) => { const r = (run_loop($systems$058attempts$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "state": run_lib((a0) => { const r = (run_loop($state$((a0)))); (a0); return r; }, 1),
  "bool": run_lib((a0) => { const r = (run_loop($bool$((a0)))); (a0); return r; }, 1),
  "previous": run_lib((a0) => { const r = (run_loop($previous$((a0)))); (a0); return r; }, 1),
  "pending": run_lib((a0) => { const r = (run_loop($pending$((a0)))); (a0); return r; }, 1),
  "quote": run_lib((a0) => { const r = (run_loop($quote$((a0)))); (a0); return r; }, 1),
  "transition": run_lib((a0) => { const r = (run_loop($transition$((a0)))); (a0); return r; }, 1),
  "array_second": run_lib((a0, a1) => { const r = (run_loop($array_second$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "array_first": run_lib((a0) => { const r = (run_loop($array_first$((a0)))); (a0); return r; }, 1),
  "array": run_lib((a0) => { const r = (run_loop($array$((a0)))); (a0); return r; }, 1),
  "locals_join": run_lib((a0, a1, a2) => { const r = (run_loop($locals_join$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "local_observed": run_lib((a0, a1, a2, a3) => { const r = (run_loop($local_observed$((a0), (a1), (a2), (a3)))); (a0); (a1); (a2); (a3); return r; }, 4),
  "locals": run_lib((a0) => { const r = (run_loop($locals$((a0)))); (a0); return r; }, 1),
  "batch_values": run_lib((a0) => { const r = (run_loop($batch_values$($0m12(a0)))); $0m14(a0); return r; }, 1),
  "batch_ticks": run_lib((a0) => { const r = $0m16(run_loop($batch_ticks$($0m12(a0)))); $0m14(a0); return r; }, 1),
  "position": run_lib((a0) => { const r = (run_loop($position$($0m6(a0)))); $0m8(a0); return r; }, 1),
  "after_a": run_lib((a0, a1) => { const r = (run_loop($after_a$((a0), $0m17(a1)))); (a0); $0m45(a1); return r; }, 2),
  "A_initial": run_lib(() => { const r = (run_loop($A_initial$()));  return r; }, 0),
  "A_failed": run_lib(() => { const r = (run_loop($A_failed$()));  return r; }, 0),
  "A_retry": run_lib(() => { const r = (run_loop($A_retry$()));  return r; }, 0),
  "A_next": run_lib(() => { const r = (run_loop($A_next$()));  return r; }, 0),
  "A_condition_false": run_lib(() => { const r = (run_loop($A_condition_false$()));  return r; }, 0),
  "A_requirement_missing": run_lib(() => { const r = (run_loop($A_requirement_missing$()));  return r; }, 0),
  "B_initial": run_lib(() => { const r = (run_loop($B_initial$()));  return r; }, 0),
  "B_failed": run_lib(() => { const r = (run_loop($B_failed$()));  return r; }, 0),
  "B_retry": run_lib(() => { const r = (run_loop($B_retry$()));  return r; }, 0),
  "B_next": run_lib(() => { const r = (run_loop($B_next$()));  return r; }, 0),
  "B_condition_false": run_lib(() => { const r = (run_loop($B_condition_false$()));  return r; }, 0),
  "B_requirement_missing": run_lib(() => { const r = (run_loop($B_requirement_missing$()));  return r; }, 0),
  "A_missing_reader": run_lib(() => { const r = (run_loop($A_missing_reader$()));  return r; }, 0),
  "B_missing_reader": run_lib(() => { const r = (run_loop($B_missing_reader$()));  return r; }, 0),
};
