The unchanged default #28 gate completed with `NO_CONFIRMED_REGRESSION` for 20 balanced pairs per backend. Both project revisions were rebuilt with the candidate graph+lookup compiler; this comparison does not isolate compiler impact.

All complete outputs passed. JS median paired current/baseline ratio was 0.924013625331827; Native was 1.0085250657735516. The Native result permits no claim that slowdown is absent: 10 of 20 pairs were slower, and the unchanged Holm test did not confirm regression.

The retained admission is a qualitative five-second CPU11 observation and serialized heavy queue, not proof of sustained host isolation. Per-feature/global speedups, final #54 acceptance, and compiler adoption do not follow from this result. The separately labelled same-source old/new compiler comparison has its own receipt.
