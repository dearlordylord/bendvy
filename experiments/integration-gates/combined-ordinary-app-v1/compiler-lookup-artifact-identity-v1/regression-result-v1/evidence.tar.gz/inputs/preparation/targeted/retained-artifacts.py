#!/usr/bin/env python3
"""Narrow retained-artifact selector over the unchanged protected paired loop."""
from pathlib import Path
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
RUNNER = Path('/workspace/formal-proofs/bendvy/benchmarks/run.py')
RUNNER_SHA = '019071aea358e84e902931822d480b47703756278610a73a496437fc40ed54a3'

def validate(bindings):
    for role in ('baseline', 'candidate'):
        for backend in ('JS', 'Native'):
            row = bindings[role + '-' + backend]
            path = Path(row['path'])
            if hashlib.sha256(path.read_bytes()).hexdigest() != row['sha256']:
                raise ValueError('Retained artifact drift: ' + str(path))
    return bindings

def prepare():
    source = RUNNER.read_text()
    if hashlib.sha256(source.encode()).hexdigest() != RUNNER_SHA:
        raise ValueError('Runner source drift')
    bindings = validate(json.loads((HERE / 'ARTIFACTS.json').read_text()))
    old = (HERE / 'compile-block.txt').read_text()
    if source.count(old) != 1:
        raise ValueError('Compile block join is not unique')
    replacement = '        retained_bindings = ' + repr(bindings) + '\n'
    replacement += "        receipt['comparisonScope'] = 'OLD_VS_NEW_COMPILER_SAME_CURRENT_SOURCE_RETAINED_ARTIFACTS_NOT_DEFAULT28'\n"
    replacement += "        receipt['retainedArtifacts'] = retained_bindings\n"
    replacement += "        for role in ('baseline', 'candidate'):\n"
    replacement += "            stage = output / role\n"
    replacement += "            for backend, extension in [('JS', 'js'), ('Native', 'native')]:\n"
    replacement += "                artifact = retained_bindings[role + '-' + backend]\n"
    replacement += "                shutil.copyfile(artifact['path'], stage / ('workshop.' + extension))\n"
    replacement += "                if backend == 'Native': (stage / 'workshop.native').chmod(0o755)\n"
    replacement += "            programs[role + '-JS'] = ['node', stage / 'workshop.js']\n"
    replacement += "            programs[role + '-Native'] = [stage / 'workshop.native']\n"
    modified = source.replace(old, replacement)
    # Source staging, complete output checks, TS noise role, seeded group order,
    # real JS/Native warmups and pairs, assess(), and all final guards remain.
    return modified

if __name__ == '__main__':
    sys.path.insert(0, str(RUNNER.parent))
    namespace = {'__name__': '__main__', '__file__': str(RUNNER)}
    exec(compile(prepare(), str(RUNNER), 'exec'), namespace)
