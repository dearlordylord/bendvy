from pathlib import Path
import json,hashlib,copy
ROOT=Path('/workspace/formal-proofs/bendvy');PREP=Path('/tmp/bendvy38-pending28-preparation');OLD=Path('/tmp/bendvy-combined220-stock28-01/plan.json');OUT=Path('/tmp/bendvy38-pending-stock28-01');BOUND=Path('/tmp/bendvy38-reviewed-benchmark-boundary.py')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
old=json.loads(OLD.read_text());plan=copy.deepcopy(old);drift=[];changes={}
assert sha(BOUND)=='a32c1e74a5862ee468f6b3e38a2d102e2ebe4ee8650a9f8e7ed810e3b617f050'
for p,s in old['pins'].items():
 try:now=sha(p)
 except FileNotFoundError:drift.append({'path':p,'expected':s,'actual':'MISSING'});continue
 if now==s:continue
 if p.startswith(str(ROOT)+'/') and not p.startswith(str(ROOT)+'/benchmarks/') and not p.startswith(str(ROOT)+'/scripts/'):
  plan['pins'][p]=now;changes[p]={'previous':s,'current':now}
 else:drift.append({'path':p,'expected':s,'actual':now})
added={}
for p in sorted((ROOT/'src/ecs').glob('*.bend')):
 k=str(p);s=sha(p)
 if k not in plan['pins']:plan['pins'][k]=s;added[k]=s
 else:assert plan['pins'][k]==s
assert plan['contract']==old['contract'];assert sha(ROOT/'benchmarks/contract.json')=='c0e13575f6e4d25ca8ca669936eef39c93a66b57ac1e4bfa42186f6f2d58bb6a'
assert plan['baselineCommit']=='327bec49d41f00f88950343dea1edc1e0ec97dc4' and plan['baselineArchiveSHA256']=='567e1e0e7d27a4c111791fcd89f9afc84e301c008741a323de258b5ca1e793e3'
assert str(Path(plan['nodeAlias']).resolve(strict=True))==plan['nodeAliasTarget']==plan['tools']['node'];assert sha(plan['tools']['node'])==old['pins'][plan['tools']['node']]
core=Path('/tmp/bendvy38-pending-working-core.json');manifest=json.loads(core.read_text());assert all(sha(x['path'])==x['sha256'] for x in manifest)
first=Path('/tmp/bendvy38-pending-first-actual01/normal');evidence={}
for p in sorted(first.rglob('*')):
 if p.is_file():evidence[str(p)]=sha(p)
for role in ['js','native']:
 receipt=json.loads((first/role/'receipt.json').read_text());stdout=first/role/'consumer.stdout';assert len(stdout.read_bytes())==22406 and sha(stdout)=='9bb243df7d81dec354357eb2966a564aecc677a7d2b1788abe2aab611692ebe0';assert not(first/role/'consumer.stderr').read_bytes()
OUT.mkdir(exist_ok=False);plan['scope']='Fresh unchanged default #28 on current root with actual Pending-bitplane candidate7eb6; whole-process Workshop regression only, no feature timing or full38 claim.';plan['output']=str(OUT/'cohort');plan['argv']=[str(OUT/'cohort') if a==old['output'] else a for a in old['argv']]
plan['provenance']['pendingCancellation']={'sourceCommit':'7eb6c90e5f255aa4e34b1996e7f4291ece7e27c9','predecessorPlan':str(OLD),'predecessorPlanSHA256':sha(OLD),'reviewedBoundary':str(BOUND),'reviewedBoundarySHA256':sha(BOUND),'currentCoreManifest':str(core),'currentCoreManifestSHA256':sha(core),'firstActualNormalRoot':str(first),'firstActualEvidence':evidence,'changedProjectInputs':changes,'addedCoreInputs':added,'scope':'Current root source pins refreshed; exact historical stock tool/resource identities retained. First normal full22406-byte JS/Native actual oracle match is semantic prerequisite, not regression/performance evidence.'}
plan['pins'][str(core)]=sha(core);plan['pins'][str(BOUND)]=sha(BOUND)
for p,s in evidence.items():plan['pins'][p]=s
plan['quietnessCondition']='Root must assess fresh allowed/quiet/exclusive CPU11 immediately before launch; this preparation performs no quietness admission or benchmark execution.'
(OUT/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
report={'status':'STATIC_READY' if not drift else 'BLOCKED_EXTERNAL_PIN_DRIFT','plan':str(OUT/'plan.json'),'planSHA256':sha(OUT/'plan.json'),'oldPins':len(old['pins']),'currentPins':len(plan['pins']),'currentCoreModules':len(list((ROOT/'src/ecs').glob('*.bend'))),'changedProjectPins':len(changes),'addedCorePins':len(added),'unrepinnedToolResourceOrRunnerDrift':drift,'nodeAliasExact':True,'stockContractUnchanged':True,'boundaryUnchanged':True,'allCurrentCorePinsExact':True,'newExecution':False,'quietnessAssessmentPerformed':False}
(PREP/'REPORT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
