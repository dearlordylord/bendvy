# #49 unobserved copied payload — focused launch review

**PASS: Spec and Standards**, diagnostic control only. Immutable author `887c9ef0d`; exact plan SHA256 `16d680d1bb036bb077c1a27d7127530caf719ad3ff48220e4c1de7c4df7c60dc` at shared-round-v1/native-emit-diagnostic-v1/unobserved-v1/plan.json. Previous observed launch review/runtime failure histories remain unchanged.

Independently reconstructed all seven observation patches in reverse and obtained exactly the new333165-byte unmodified copied CLI, SHA256 `015d68644efcd3ed53a5dbf17f5672c3f4fcb70c8c64cd2c895b4955e1f78e62`. The identical full payload occurs once in the pinned Bend2.0.35 ELF at offset82378778. Helper import/marks are absent; original compiler source is not modified. Byte membership does not prove bundled and filesystem engine/configuration equivalence or identify an upstream Git revision.

Actual argv selects the same pinned ELF + BUN_BE_BUN=1 embedded runtime and frozen shared-round main, CPU11/emit30, exact installed Base/Lean/effects resources. Observer environment is removed. Working directory exactly matches failed stock83434 plan: ordinary-app-generated-observation-v1/.../ordinary-mixed-app-v1. The local launcher diff consists only of forcing explicit plan.cwd into existing execute_result kwargs and changing terminal descriptive scope; interpreter assertion, internal lock, raw split capture, unconditional primary-preserving terminal/post/host/resource/link capture are unchanged. A nonexistent boundary page is expected for this unobserved control, not failed instrumentation evidence.

All80 current pins, resource membership, three readlinks/resolved targets and absent fresh actual01 independently verified. Retained controls bind final plan/env/cwd and actual literal version command: exit0, rawstdout `bend 2.0.35` and empty stderr match recorded SHA. Earlier unsupported --version failure is preserved and excluded from acceptance. No compiler workload ran in those controls.

Exact launch argv:

```sh
/usr/bin/python3.11 /workspace/formal-proofs/bendvy-worktrees/handlers49-current-ordinary-v1/experiments/public-machines/ordinary-heterogeneous-handlers-v1/shared-round-v1/native-emit-diagnostic-v1/unobserved-v1/launch.py.source /workspace/formal-proofs/bendvy-worktrees/handlers49-current-ordinary-v1/experiments/public-machines/ordinary-heterogeneous-handlers-v1/shared-round-v1/native-emit-diagnostic-v1/unobserved-v1/plan.json 16d680d1bb036bb077c1a27d7127530caf719ad3ff48220e4c1de7c4df7c60dc
```

Prerequisites: exact current pins/resources/links and stock cwd, fresh actual01 plus distinct fresh outerstdout/stderr, original tool terminal retained, all peer heavy owners/hooks released and exclusive reservations honored. Existing launcher internal lock only; no outer reacquisition. One30-second emit, no cap increase, build/runtime execution or new dependency.

Observed actual02 C success and this proposed unobserved control are not stock Native qualification or evidence of causal emitter cost. No runtime-engine equivalence, complete #49 acceptance or performance credit is granted. No installed/reference/core mutation or reviewer child execution occurred.
