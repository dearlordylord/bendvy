import {run} from "./reference.mjs";
import {timed} from "/workspace/formal-proofs/bendvy/benchmarks/parity-features/capture.mjs";
await timed(() => {
 console.log(JSON.stringify(run()));
 console.log(JSON.stringify(run()));
 console.log(JSON.stringify(run()));
 console.log(JSON.stringify(run()));
});
