"""Independent source-only finite tryTick preflight and full debug serialization."""
import copy,json
def expected_value():
    traces=[];reads=[];records=[]
    def point(label,result,queued):
        world=dict(version=1,frame=1 if queued else 0,tick=1 if queued else 0,entityCount=0,entities=[],resources=dict(Owned=[11,12],SiblingOwner=[21,22]),machines=dict(First=dict(current='Cold')),pendingCommands=[dict(tag='spawn',system='seed')] if queued else [])
        streams=[dict(kind=k,stream=n,size=0,capacity=65536,readers=[dict(system='seed',unread=0,lagged=False)]) for k,n in [('event','Pulse'),('transitionEvent','First')]] if queued else []
        records.append(copy.deepcopy(dict(label=label,result=result,world=world,streams=streams,callbacks=[],seedReads=reads,traces=traces)))
    point('before',None,False)
    traces.extend([dict(type='frame',frame=1,tick=0),dict(type='schedule.start',frame=1,schedule='schedule#1')])
    reads.append(dict(pulse=[],first=[]))
    traces.append(dict(type='system',frame=1,tick=1,schedule='schedule#1',system='seed',outcome='ok',writes=[],resources=[],events=[],nextStates=[],commands=['spawn'],missed=[]))
    traces.append(dict(type='schedule.end',frame=1,schedule='schedule#1',ok=True))
    point('queued',dict(ok=True),True)
    # Runtime checks carried requirements before advanceFrame/runScheduleUnsafe.
    point('missing-unselected-rejected',dict(ok=False,error=dict(kind='MissingRuntimeRequirements',requirements=[dict(kind='stateMachine',name='Second')])),True)
    # Actual runtime transitionSchedule does not append selector First.
    return dict(requirements=[dict(kind='resource',name='Owned'),dict(kind='stateMachine',name='Second')],records=records)
def expected():return (json.dumps(expected_value(),separators=(',',':'),ensure_ascii=False)+'\n').encode()
