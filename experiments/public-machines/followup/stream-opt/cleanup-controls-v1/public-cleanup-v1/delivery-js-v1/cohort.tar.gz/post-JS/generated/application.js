function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

(() => {
// One allocator per emitted program, shared by all canonical world creations.
let bendvy_namespace_next = 1;
function bendvy_namespace_fresh() {
  if (bendvy_namespace_next >= 0xffffffff) return 0;
  return bendvy_namespace_next++;
}
io_eff("../../../../../src/ecs/world-namespace.fresh", bendvy_namespace_fresh);

})();

for (const k of ["IO.print","../../../../../src/ecs/world-namespace.fresh"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return run_clo((_x_0) => {
  return $IO$bind$(($scenario$1260$()), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$bind$(($scenario$1261$()), run_clo((_x_3) => {
  const _x_4 = ("\nSCHEMA=B\n" + _x_3);
  const _x_5 = (_x_1 + _x_4);
  return (_x_6) => $IO$print$(("SCHEMA=A\n" + _x_5), _x_6);
}), _x_2);
});
}), _x_0);
});
}

function $IO$bind$(_m_0, _f_0, _k_0) {
  return run_tail(_m_0, run_clo((_x_0) => {
  return run_tail(_f_0(_x_0), _k_0);
}));
}

function $scenario$1260$() {
  return run_clo((_x_0) => {
  return $IO$bind$(($initial$1260$(false)), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$bind$(($initial$1260$(true)), run_clo((_x_3) => {
  return run_clo((_x_4) => {
  return $IO$pure$(($caller$045core$058assembled$1260$(_x_1, _x_3)), _x_4);
});
}), _x_2);
});
}), _x_0);
});
}

function $scenario$1261$() {
  return run_clo((_x_0) => {
  return $IO$bind$(($initial$1261$(false)), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$bind$(($initial$1261$(true)), run_clo((_x_3) => {
  return run_clo((_x_4) => {
  return $IO$pure$(($caller$045core$058assembled$1261$(_x_1, _x_3)), _x_4);
});
}), _x_2);
});
}), _x_0);
});
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $initial$1260$(_other_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$045io$058create$1260$(($caller$045core$058resource$1260$(_other_0)))), run_clo((_x_1) => {
  return $initial_created$1260$(_x_1);
}), _x_0);
});
}

function $IO$pure$(_x_0, _k_0) {
  return run_tail(_k_0, _x_0);
}

function $caller$045core$058assembled$1260$(_a_0, _b_0) {
  if (_a_0.$ === "caller-core.Initialized") {
    const _t_0 = _a_0["value"];
    const _ao_0 = _t_0["owners"];
    const _aw_0 = _t_0["world"];
    const _ar_0 = _t_0["rows"];
    if (_b_0.$ === "caller-core.Initialized") {
      const _b_1 = _b_0["value"];
      return $caller$045core$058a_registered$1260$(_ao_0, _ar_0, _b_1, ($$$$047$$$047$$$047readers$058provision$1260$(_aw_0, "shared-definition")));
    } else {
      return "INITIALIZATION_REJECTED";
    }
  } else {
    return "INITIALIZATION_REJECTED";
  }
}

function $initial$1261$(_other_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$045io$058create$1261$(($caller$045core$058resource$1261$(_other_0)))), run_clo((_x_1) => {
  return $initial_created$1261$(_x_1);
}), _x_0);
});
}

function $caller$045core$058assembled$1261$(_a_0, _b_0) {
  if (_a_0.$ === "caller-core.Initialized") {
    const _t_0 = _a_0["value"];
    const _ao_0 = _t_0["owners"];
    const _aw_0 = _t_0["world"];
    const _ar_0 = _t_0["rows"];
    if (_b_0.$ === "caller-core.Initialized") {
      const _b_1 = _b_0["value"];
      return $caller$045core$058a_registered$1261$(_ao_0, _ar_0, _b_1, ($$$$047$$$047$$$047readers$058provision$1261$(_aw_0, "shared-definition")));
    } else {
      return "INITIALIZATION_REJECTED";
    }
  } else {
    return "INITIALIZATION_REJECTED";
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$045io$058create$1260$(_resource_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$045namespace$058fresh$(_x_1), run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$045io$058with_namespace$1260$(_x_2, _resource_0);
}), _x_0);
});
}

function $caller$045core$058resource$1260$(_other_0) {
  return $caller$045core$058resource_selected$1260$(_other_0, ($$$$047$$$047$$$047provider$058initial_resources$1260$()));
}

function $initial_created$1260$(_result_0) {
  if (_result_0.$ === "../../../../../src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    return run_clo((_x_0) => {
  return $IO$pure$(($caller$045core$058initialized$1260$(($$$$047$$$047$$$047hooks$058provision$1260$(_world_0)))), _x_0);
});
  } else {
    const _resource_0 = _result_0["resource"];
    return run_clo((_x_1) => {
  return $IO$pure$({$: "caller-core.CreationRefused", "resource": _resource_0}, _x_1);
});
  }
}

function $caller$045core$058a_registered$1260$(_ao_0, _ar_0, _b_0, _result_0) {
  const _bo_0 = _b_0["owners"];
  const _bw_0 = _b_0["world"];
  const _br_0 = _b_0["rows"];
  if (_result_0.$ === "../../../readers.Provisioned") {
    const _world_0 = _result_0["world"];
    const _aReader_0 = _result_0["instance"];
    return $caller$045core$058b_registered$1260$({$: "../../observations.Observed", "owners": _ao_0, "world": _world_0, "rows": _ar_0}, _aReader_0, _bo_0, _br_0, ($$$$047$$$047$$$047readers$058provision$1260$(_bw_0, "shared-definition")));
  } else {
    return "READER_A_PROVISION_REJECTED";
  }
}

function $$$$047$$$047$$$047readers$058provision$1260$(_world_0, _name_0) {
  return $$$$047$$$047$$$047readers$058registered$1260$(($public$045cleanup$045v1$047current$045core$047ecs$047system$058register$1261$(_world_0, _name_0, {$: "Con", "head": "transition.Flow.read", "tail": {$: "Con", "head": "transition.Level.read", "tail": {$: "Nil"}}})));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$045io$058create$1261$(_resource_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$045namespace$058fresh$(_x_1), run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$045io$058with_namespace$1261$(_x_2, _resource_0);
}), _x_0);
});
}

function $caller$045core$058resource$1261$(_other_0) {
  return $caller$045core$058resource_selected$1261$(_other_0, ($$$$047$$$047$$$047provider$058initial_resources$1261$()));
}

function $initial_created$1261$(_result_0) {
  if (_result_0.$ === "../../../../../src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    return run_clo((_x_0) => {
  return $IO$pure$(($caller$045core$058initialized$1261$(($$$$047$$$047$$$047hooks$058provision$1261$(_world_0)))), _x_0);
});
  } else {
    const _resource_0 = _result_0["resource"];
    return run_clo((_x_1) => {
  return $IO$pure$({$: "caller-core.CreationRefused", "resource": _resource_0}, _x_1);
});
  }
}

function $caller$045core$058a_registered$1261$(_ao_0, _ar_0, _b_0, _result_0) {
  const _bo_0 = _b_0["owners"];
  const _bw_0 = _b_0["world"];
  const _br_0 = _b_0["rows"];
  if (_result_0.$ === "../../../readers.Provisioned") {
    const _world_0 = _result_0["world"];
    const _aReader_0 = _result_0["instance"];
    return $caller$045core$058b_registered$1261$({$: "../../observations.Observed", "owners": _ao_0, "world": _world_0, "rows": _ar_0}, _aReader_0, _bo_0, _br_0, ($$$$047$$$047$$$047readers$058provision$1261$(_bw_0, "shared-definition")));
  } else {
    return "READER_A_PROVISION_REJECTED";
  }
}

function $$$$047$$$047$$$047readers$058provision$1261$(_world_0, _name_0) {
  return $$$$047$$$047$$$047readers$058registered$1261$(($public$045cleanup$045v1$047current$045core$047ecs$047system$058register$1264$(_world_0, _name_0, {$: "Con", "head": "transition.Flow.read", "tail": {$: "Con", "head": "transition.Level.read", "tail": {$: "Nil"}}})));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$045namespace$058fresh$(_k_0) {
  return { $: "$FFI", run: $0eff["../../../../../src/ecs/world-namespace.fresh"].run, need: $0eff["../../../../../src/ecs/world-namespace.fresh"].need, args: [], kont: (_k_0) };
}
function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$045io$058with_namespace$1260$(_namespace_0, _resource_0) {
  return run_clo((_x_0) => {
  return $IO$pure$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$045io$058convert$1260$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058create_checked$1260$(($Bool$and$((0 < _namespace_0), (_namespace_0 < 4294967295))), _namespace_0, _resource_0)))), _x_0);
});
}

function $caller$045core$058resource_selected$1260$(_other_0, _resources_0) {
  if (!_other_0) {
    return _resources_0;
  } else {
    const _flow_0 = _resources_0["flow"];
    const _level_0 = _resources_0["level"];
    const _fs_0 = _resources_0["flowStream"];
    const _ls_0 = _resources_0["levelStream"];
    const _frame_0 = _resources_0["frame"];
    const _tick_0 = _resources_0["tick"];
    const _trace_0 = _resources_0["trace"];
    return {$: "../../../provider.Resources", "owned": array_node([1030], [1130]), "flow": _flow_0, "level": _level_0, "flowStream": _fs_0, "levelStream": _ls_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0};
  }
}

function $$$$047$$$047$$$047provider$058initial_resources$1260$() {
  return {$: "../../../provider.Resources", "owned": array_node([30], [130]), "flow": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": {$: "../../../provider.Boot"}, "pending": {$: "public-cleanup-v1/current-core/ecs/machine.NoPending"}, "previous": {$: "None"}, "changed": false}, "level": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": {$: "../../../provider.Low"}, "pending": {$: "public-cleanup-v1/current-core/ecs/machine.NoPending"}, "previous": {$: "None"}, "changed": false}, "flowStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058empty$1260$()), "levelStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058empty$1261$()), "frame": 0, "tick": 0, "trace": {$: "Nil"}};
}

function $caller$045core$058initialized$1260$(_result_0) {
  if (_result_0.$ === "../../../hooks.Provisioned") {
    const _world_0 = _result_0["world"];
    const _hooks_0 = _result_0["owners"];
    return {$: "caller-core.Initialized", "value": ($$$$047$$$047observations$058frames$1260$(($caller$045core$058plans$1260$()), {$: "../../observations.Observed", "owners": {$: "../../../application.Owners", "users": {$: "../../../catalog.Catalog", "entries": {$: "Nil"}}, "hooks": _hooks_0, "readers": {$: "Nil"}, "attempts": {$: "Nil"}, "deliveries": {$: "Nil"}, "conditions": {$: "Nil"}, "active": {$: "Nil"}}, "world": _world_0, "rows": {$: "Nil"}}))};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "caller-core.InitializationFailed", "world": _world_1};
  }
}

function $$$$047$$$047$$$047hooks$058provision$1260$(_world_0) {
  return $$$$047$$$047$$$047hooks$058registered_flow$1260$(($public$045cleanup$045v1$047current$045core$047ecs$047system$058register$1262$(_world_0, "flow-hook", {$: "Con", "head": "machine.Flow.next", "tail": {$: "Con", "head": "machine.Level.next", "tail": {$: "Nil"}}})));
}

function $caller$045core$058b_registered$1260$(_a_0, _aReader_0, _bo_0, _br_0, _result_0) {
  if (_result_0.$ === "../../../readers.Provisioned") {
    const _world_0 = _result_0["world"];
    const _bReader_0 = _result_0["instance"];
    return $caller$045core$058completed$1260$(($caller$045core$058local_b$1260$(($caller$045core$058local_a$1260$(($caller$045core$058foreign$1260$(($caller$045core$058record$1260$("two-independent-instances", "ok", {$: "caller-core.Scene", "a": _a_0, "b": {$: "../../observations.Observed", "owners": _bo_0, "world": _world_0, "rows": _br_0}, "aReader": _aReader_0, "bReader": _bReader_0, "instances": {$: "Nil"}})))))))));
  } else {
    return "READER_B_PROVISION_REJECTED";
  }
}

function $$$$047$$$047$$$047readers$058registered$1260$(_result_0) {
  if (_result_0.$ === "public-cleanup-v1/current-core/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return $$$$047$$$047$$$047readers$058registered_identity$1260$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058namespace$1260$(_world_0)), ($public$045cleanup$045v1$047current$045core$047ecs$047system$058identity$1260$(_registry_0)));
  } else {
    const _world_1 = _result_0["world"];
    return {$: "../../../readers.ProvisionFailed", "world": _world_1};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register$1261$(_world_0, _name_0, _access_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_namespace$1261$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$045io$058with_namespace$1261$(_namespace_0, _resource_0) {
  return run_clo((_x_0) => {
  return $IO$pure$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$045io$058convert$1261$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058create_checked$1261$(($Bool$and$((0 < _namespace_0), (_namespace_0 < 4294967295))), _namespace_0, _resource_0)))), _x_0);
});
}

function $caller$045core$058resource_selected$1261$(_other_0, _resources_0) {
  if (!_other_0) {
    return _resources_0;
  } else {
    const _flow_0 = _resources_0["flow"];
    const _level_0 = _resources_0["level"];
    const _fs_0 = _resources_0["flowStream"];
    const _ls_0 = _resources_0["levelStream"];
    const _frame_0 = _resources_0["frame"];
    const _tick_0 = _resources_0["tick"];
    const _trace_0 = _resources_0["trace"];
    return {$: "../../../provider.Resources", "owned": array_node([1030], [1130]), "flow": _flow_0, "level": _level_0, "flowStream": _fs_0, "levelStream": _ls_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0};
  }
}

function $$$$047$$$047$$$047provider$058initial_resources$1261$() {
  return {$: "../../../provider.Resources", "owned": array_node([30], [130]), "flow": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": {$: "../../../provider.Boot"}, "pending": {$: "public-cleanup-v1/current-core/ecs/machine.NoPending"}, "previous": {$: "None"}, "changed": false}, "level": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": {$: "../../../provider.Low"}, "pending": {$: "public-cleanup-v1/current-core/ecs/machine.NoPending"}, "previous": {$: "None"}, "changed": false}, "flowStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058empty$1260$()), "levelStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058empty$1261$()), "frame": 0, "tick": 0, "trace": {$: "Nil"}};
}

function $caller$045core$058initialized$1261$(_result_0) {
  if (_result_0.$ === "../../../hooks.Provisioned") {
    const _world_0 = _result_0["world"];
    const _hooks_0 = _result_0["owners"];
    return {$: "caller-core.Initialized", "value": ($$$$047$$$047observations$058frames$1261$(($caller$045core$058plans$1261$()), {$: "../../observations.Observed", "owners": {$: "../../../application.Owners", "users": {$: "../../../catalog.Catalog", "entries": {$: "Nil"}}, "hooks": _hooks_0, "readers": {$: "Nil"}, "attempts": {$: "Nil"}, "deliveries": {$: "Nil"}, "conditions": {$: "Nil"}, "active": {$: "Nil"}}, "world": _world_0, "rows": {$: "Nil"}}))};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "caller-core.InitializationFailed", "world": _world_1};
  }
}

function $$$$047$$$047$$$047hooks$058provision$1261$(_world_0) {
  return $$$$047$$$047$$$047hooks$058registered_flow$1261$(($public$045cleanup$045v1$047current$045core$047ecs$047system$058register$1265$(_world_0, "flow-hook", {$: "Con", "head": "machine.Flow.next", "tail": {$: "Con", "head": "machine.Level.next", "tail": {$: "Nil"}}})));
}

function $caller$045core$058b_registered$1261$(_a_0, _aReader_0, _bo_0, _br_0, _result_0) {
  if (_result_0.$ === "../../../readers.Provisioned") {
    const _world_0 = _result_0["world"];
    const _bReader_0 = _result_0["instance"];
    return $caller$045core$058completed$1261$(($caller$045core$058local_b$1261$(($caller$045core$058local_a$1261$(($caller$045core$058foreign$1261$(($caller$045core$058record$1261$("two-independent-instances", "ok", {$: "caller-core.Scene", "a": _a_0, "b": {$: "../../observations.Observed", "owners": _bo_0, "world": _world_0, "rows": _br_0}, "aReader": _aReader_0, "bReader": _bReader_0, "instances": {$: "Nil"}})))))))));
  } else {
    return "READER_B_PROVISION_REJECTED";
  }
}

function $$$$047$$$047$$$047readers$058registered$1261$(_result_0) {
  if (_result_0.$ === "public-cleanup-v1/current-core/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return $$$$047$$$047$$$047readers$058registered_identity$1261$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058namespace$1261$(_world_0)), ($public$045cleanup$045v1$047current$045core$047ecs$047system$058identity$1261$(_registry_0)));
  } else {
    const _world_1 = _result_0["world"];
    return {$: "../../../readers.ProvisionFailed", "world": _world_1};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register$1264$(_world_0, _name_0, _access_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_namespace$1264$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$045io$058convert$1260$(_created_0) {
  if (_created_0.$ === "public-cleanup-v1/current-core/ecs/world.Created") {
    const _world_0 = _created_0["world"];
    return {$: "../../../../../src/ecs/world-io.Created", "world": _world_0};
  } else {
    const _resource_0 = _created_0["resource"];
    return {$: "../../../../../src/ecs/world-io.Refused", "resource": _resource_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "public-cleanup-v1/current-core/ecs/world.CreateRejected", "factory": {$: "public-cleanup-v1/current-core/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "public-cleanup-v1/current-core/ecs/world.Created", "factory": {$: "public-cleanup-v1/current-core/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($$$$047$$$047$$$047provider$058empty_store$1260$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058empty$1260$() {
  return {$: "public-cleanup-v1/current-core/ecs/machine-stream.Stream", "batches": {$: "Nil"}, "positions": {$: "Nil"}, "droppedThrough": 0, "frameStart": 0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058empty$1261$() {
  return {$: "public-cleanup-v1/current-core/ecs/machine-stream.Stream", "batches": {$: "Nil"}, "positions": {$: "Nil"}, "droppedThrough": 0, "frameStart": 0};
}

function $$$$047$$$047observations$058frames$1260$($0, $1) {
  for (;;) {
    {
      const _plans_0 = $0;
      const _current_0 = $1;
      if (_plans_0.$ === "Nil") {
        return _current_0;
      } else {
        const _t_0 = _plans_0["head"];
        const _label_0 = _t_0["label"];
        const _actions_0 = _t_0["actions"];
        const _rest_0 = _plans_0["tail"];
        const _owners_0 = _current_0["owners"];
        const _world_0 = _current_0["world"];
        const _rows_0 = _current_0["rows"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047observations$058checkpoint$1260$(_label_0, _rows_0, ($$$$047$$$047$$$047application$058frame$1260$(_owners_0, _world_0, _label_0, _actions_0))));
        continue;
      }
    }
  }
}

function $caller$045core$058plans$1260$() {
  return {$: "Con", "head": {$: "../../../application.FramePlan", "label": "seeded", "actions": {$: "Con", "head": {$: "../../../application.Body", "key": 1, "name": "seed", "operation": {$: "../../../gameplay.Seed"}}, "tail": {$: "Con", "head": {$: "../../../application.Deferred"}, "tail": {$: "Nil"}}}}, "tail": {$: "Con", "head": {$: "../../../application.FramePlan", "label": "published", "actions": {$: "Con", "head": {$: "../../../application.Body", "key": 2, "name": "publish", "operation": {$: "../../../gameplay.PlayRequest"}}, "tail": {$: "Con", "head": {$: "../../../application.Marker", "enabled": false}, "tail": {$: "Nil"}}}}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047hooks$058registered_flow$1260$(_result_0) {
  if (_result_0.$ === "public-cleanup-v1/current-core/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _flow_0 = _result_0["registry"];
    return $$$$047$$$047$$$047hooks$058registered_level$1260$(_flow_0, ($public$045cleanup$045v1$047current$045core$047ecs$047system$058register$1262$(_world_0, "level-hook", {$: "Con", "head": "machine.Flow.next", "tail": {$: "Nil"}})));
  } else {
    const _world_1 = _result_0["world"];
    return {$: "../../../hooks.ProvisionFailed", "world": _world_1};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register$1262$(_world_0, _name_0, _access_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_namespace$1262$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $caller$045core$058completed$1260$(_scene_0) {
  const _a_0 = _scene_0["a"];
  const _t_0 = _scene_0["b"];
  const _bo_0 = _t_0["owners"];
  const _bw_0 = _t_0["world"];
  const _br_0 = _t_0["rows"];
  const _aReader_0 = _scene_0["aReader"];
  const _bReader_0 = _scene_0["bReader"];
  const _rows_0 = _scene_0["instances"];
  return $caller$045core$058foreign_cleanup_returned$1260$(_a_0, _bo_0, _br_0, _bReader_0, _rows_0, ($caller$045core$058cleanup$1260$(_aReader_0, _bw_0)));
}

function $caller$045core$058local_b$1260$(_scene_0) {
  const _a_0 = _scene_0["a"];
  const _t_0 = _scene_0["b"];
  const _bo_0 = _t_0["owners"];
  const _bw_0 = _t_0["world"];
  const _br_0 = _t_0["rows"];
  const _aReader_0 = _scene_0["aReader"];
  const _bReader_0 = _scene_0["bReader"];
  const _rows_0 = _scene_0["instances"];
  return $caller$045core$058local_b_returned$1260$(_a_0, _bo_0, _br_0, _aReader_0, _rows_0, ($$$$047$$$047$$$047readers$058invoke$1260$(_bReader_0, _bw_0, false)));
}

function $caller$045core$058local_a$1260$(_scene_0) {
  const _t_0 = _scene_0["a"];
  const _ao_0 = _t_0["owners"];
  const _aw_0 = _t_0["world"];
  const _ar_0 = _t_0["rows"];
  const _b_0 = _scene_0["b"];
  const _aReader_0 = _scene_0["aReader"];
  const _bReader_0 = _scene_0["bReader"];
  const _rows_0 = _scene_0["instances"];
  return $caller$045core$058local_a_returned$1260$(_ao_0, _ar_0, _b_0, _bReader_0, _rows_0, ($$$$047$$$047$$$047readers$058invoke$1260$(_aReader_0, _aw_0, false)));
}

function $caller$045core$058foreign$1260$(_scene_0) {
  const _a_0 = _scene_0["a"];
  const _t_0 = _scene_0["b"];
  const _bo_0 = _t_0["owners"];
  const _bw_0 = _t_0["world"];
  const _br_0 = _t_0["rows"];
  const _aReader_0 = _scene_0["aReader"];
  const _bReader_0 = _scene_0["bReader"];
  const _rows_0 = _scene_0["instances"];
  return $caller$045core$058foreign_returned$1260$(_a_0, _bo_0, _br_0, _bReader_0, _rows_0, ($$$$047$$$047$$$047readers$058invoke$1260$(_aReader_0, _bw_0, false)));
}

function $caller$045core$058record$1260$(_label_0, _status_0, _scene_0) {
  const _t_0 = _scene_0["a"];
  const _ao_0 = _t_0["owners"];
  const _aw_0 = _t_0["world"];
  const _ar_0 = _t_0["rows"];
  const _t_1 = _scene_0["b"];
  const _bo_0 = _t_1["owners"];
  const _bw_0 = _t_1["world"];
  const _br_0 = _t_1["rows"];
  const _aReader_0 = _scene_0["aReader"];
  const _bReader_0 = _scene_0["bReader"];
  const _rows_0 = _scene_0["instances"];
  return $caller$045core$058record_parts$1260$(_label_0, ($$$$047$$$047observations$058checkpoint$1260$(_label_0, _ar_0, {$: "../../../application.FrameResult", "owners": _ao_0, "world": _aw_0, "status": _status_0})), ($$$$047$$$047observations$058checkpoint$1260$(_label_0, _br_0, {$: "../../../application.FrameResult", "owners": _bo_0, "world": _bw_0, "status": _status_0})), _rows_0, ($caller$045core$058instance_view$1260$(_aReader_0)), ($caller$045core$058instance_view$1260$(_bReader_0)));
}

function $$$$047$$$047$$$047readers$058registered_identity$1260$(_named_0, _pair_0) {
  const _actual_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  const _registry_0 = _pair_0["fst"];
  const _id_0 = _pair_0["snd"];
  return {$: "../../../readers.Provisioned", "world": _actual_0, "instance": {$: "../../../readers.Instance", "registry": _registry_0, "flow": {$: "public-cleanup-v1/current-core/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": _id_0}, "level": {$: "public-cleanup-v1/current-core/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": _id_0}}};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058identity$1260$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _id_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_namespace$1261$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_join$1261$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$045io$058convert$1261$(_created_0) {
  if (_created_0.$ === "public-cleanup-v1/current-core/ecs/world.Created") {
    const _world_0 = _created_0["world"];
    return {$: "../../../../../src/ecs/world-io.Created", "world": _world_0};
  } else {
    const _resource_0 = _created_0["resource"];
    return {$: "../../../../../src/ecs/world-io.Refused", "resource": _resource_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058create_checked$1261$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "public-cleanup-v1/current-core/ecs/world.CreateRejected", "factory": {$: "public-cleanup-v1/current-core/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "public-cleanup-v1/current-core/ecs/world.Created", "factory": {$: "public-cleanup-v1/current-core/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($$$$047$$$047$$$047provider$058empty_store$1261$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $$$$047$$$047observations$058frames$1261$($0, $1) {
  for (;;) {
    {
      const _plans_0 = $0;
      const _current_0 = $1;
      if (_plans_0.$ === "Nil") {
        return _current_0;
      } else {
        const _t_0 = _plans_0["head"];
        const _label_0 = _t_0["label"];
        const _actions_0 = _t_0["actions"];
        const _rest_0 = _plans_0["tail"];
        const _owners_0 = _current_0["owners"];
        const _world_0 = _current_0["world"];
        const _rows_0 = _current_0["rows"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047observations$058checkpoint$1261$(_label_0, _rows_0, ($$$$047$$$047$$$047application$058frame$1261$(_owners_0, _world_0, _label_0, _actions_0))));
        continue;
      }
    }
  }
}

function $caller$045core$058plans$1261$() {
  return {$: "Con", "head": {$: "../../../application.FramePlan", "label": "seeded", "actions": {$: "Con", "head": {$: "../../../application.Body", "key": 1, "name": "seed", "operation": {$: "../../../gameplay.Seed"}}, "tail": {$: "Con", "head": {$: "../../../application.Deferred"}, "tail": {$: "Nil"}}}}, "tail": {$: "Con", "head": {$: "../../../application.FramePlan", "label": "published", "actions": {$: "Con", "head": {$: "../../../application.Body", "key": 2, "name": "publish", "operation": {$: "../../../gameplay.PlayRequest"}}, "tail": {$: "Con", "head": {$: "../../../application.Marker", "enabled": false}, "tail": {$: "Nil"}}}}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047hooks$058registered_flow$1261$(_result_0) {
  if (_result_0.$ === "public-cleanup-v1/current-core/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _flow_0 = _result_0["registry"];
    return $$$$047$$$047$$$047hooks$058registered_level$1261$(_flow_0, ($public$045cleanup$045v1$047current$045core$047ecs$047system$058register$1265$(_world_0, "level-hook", {$: "Con", "head": "machine.Flow.next", "tail": {$: "Nil"}})));
  } else {
    const _world_1 = _result_0["world"];
    return {$: "../../../hooks.ProvisionFailed", "world": _world_1};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register$1265$(_world_0, _name_0, _access_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_namespace$1265$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $caller$045core$058completed$1261$(_scene_0) {
  const _a_0 = _scene_0["a"];
  const _t_0 = _scene_0["b"];
  const _bo_0 = _t_0["owners"];
  const _bw_0 = _t_0["world"];
  const _br_0 = _t_0["rows"];
  const _aReader_0 = _scene_0["aReader"];
  const _bReader_0 = _scene_0["bReader"];
  const _rows_0 = _scene_0["instances"];
  return $caller$045core$058foreign_cleanup_returned$1261$(_a_0, _bo_0, _br_0, _bReader_0, _rows_0, ($caller$045core$058cleanup$1261$(_aReader_0, _bw_0)));
}

function $caller$045core$058local_b$1261$(_scene_0) {
  const _a_0 = _scene_0["a"];
  const _t_0 = _scene_0["b"];
  const _bo_0 = _t_0["owners"];
  const _bw_0 = _t_0["world"];
  const _br_0 = _t_0["rows"];
  const _aReader_0 = _scene_0["aReader"];
  const _bReader_0 = _scene_0["bReader"];
  const _rows_0 = _scene_0["instances"];
  return $caller$045core$058local_b_returned$1261$(_a_0, _bo_0, _br_0, _aReader_0, _rows_0, ($$$$047$$$047$$$047readers$058invoke$1261$(_bReader_0, _bw_0, false)));
}

function $caller$045core$058local_a$1261$(_scene_0) {
  const _t_0 = _scene_0["a"];
  const _ao_0 = _t_0["owners"];
  const _aw_0 = _t_0["world"];
  const _ar_0 = _t_0["rows"];
  const _b_0 = _scene_0["b"];
  const _aReader_0 = _scene_0["aReader"];
  const _bReader_0 = _scene_0["bReader"];
  const _rows_0 = _scene_0["instances"];
  return $caller$045core$058local_a_returned$1261$(_ao_0, _ar_0, _b_0, _bReader_0, _rows_0, ($$$$047$$$047$$$047readers$058invoke$1261$(_aReader_0, _aw_0, false)));
}

function $caller$045core$058foreign$1261$(_scene_0) {
  const _a_0 = _scene_0["a"];
  const _t_0 = _scene_0["b"];
  const _bo_0 = _t_0["owners"];
  const _bw_0 = _t_0["world"];
  const _br_0 = _t_0["rows"];
  const _aReader_0 = _scene_0["aReader"];
  const _bReader_0 = _scene_0["bReader"];
  const _rows_0 = _scene_0["instances"];
  return $caller$045core$058foreign_returned$1261$(_a_0, _bo_0, _br_0, _bReader_0, _rows_0, ($$$$047$$$047$$$047readers$058invoke$1261$(_aReader_0, _bw_0, false)));
}

function $caller$045core$058record$1261$(_label_0, _status_0, _scene_0) {
  const _t_0 = _scene_0["a"];
  const _ao_0 = _t_0["owners"];
  const _aw_0 = _t_0["world"];
  const _ar_0 = _t_0["rows"];
  const _t_1 = _scene_0["b"];
  const _bo_0 = _t_1["owners"];
  const _bw_0 = _t_1["world"];
  const _br_0 = _t_1["rows"];
  const _aReader_0 = _scene_0["aReader"];
  const _bReader_0 = _scene_0["bReader"];
  const _rows_0 = _scene_0["instances"];
  return $caller$045core$058record_parts$1261$(_label_0, ($$$$047$$$047observations$058checkpoint$1261$(_label_0, _ar_0, {$: "../../../application.FrameResult", "owners": _ao_0, "world": _aw_0, "status": _status_0})), ($$$$047$$$047observations$058checkpoint$1261$(_label_0, _br_0, {$: "../../../application.FrameResult", "owners": _bo_0, "world": _bw_0, "status": _status_0})), _rows_0, ($caller$045core$058instance_view$1261$(_aReader_0)), ($caller$045core$058instance_view$1261$(_bReader_0)));
}

function $$$$047$$$047$$$047readers$058registered_identity$1261$(_named_0, _pair_0) {
  const _actual_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  const _registry_0 = _pair_0["fst"];
  const _id_0 = _pair_0["snd"];
  return {$: "../../../readers.Provisioned", "world": _actual_0, "instance": {$: "../../../readers.Instance", "registry": _registry_0, "flow": {$: "public-cleanup-v1/current-core/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": _id_0}, "level": {$: "public-cleanup-v1/current-core/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": _id_0}}};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058namespace$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058identity$1261$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _id_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_namespace$1264$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_join$1264$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047provider$058empty_store$1260$(__0) {
  return {$: "../../../provider.Store", "cells": {$: "../../../../../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}}};
}

function $$$$047$$$047observations$058checkpoint$1260$(_label_0, _rows_0, _result_0) {
  const _owned_0 = _result_0["owners"];
  const _world_0 = _result_0["world"];
  const _status_0 = _result_0["status"];
  return $$$$047$$$047observations$058observed$1260$(_label_0, _status_0, _rows_0, ($$$$047$$$047observations$058owners$1260$(_owned_0)), ($$$$047$$$047$$$047observe$058world$1260$(_world_0)));
}

function $$$$047$$$047$$$047application$058frame$1260$(_owners_0, _world_0, _name_0, _actions_0) {
  return $$$$047$$$047$$$047application$058checked$1260$(_owners_0, _name_0, _actions_0, ($$$$047$$$047$$$047application$058provision_checked$1260$(_world_0, _actions_0)));
}

function $$$$047$$$047$$$047hooks$058registered_level$1260$(_flow_0, _result_0) {
  if (_result_0.$ === "public-cleanup-v1/current-core/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _level_0 = _result_0["registry"];
    return {$: "../../../hooks.Provisioned", "world": _world_0, "owners": {$: "../../../hooks.Owners", "flow": _flow_0, "level": _level_0}};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "../../../hooks.ProvisionFailed", "world": _world_1};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_namespace$1262$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_join$1262$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $caller$045core$058foreign_cleanup_returned$1260$(_a_0, _bo_0, _br_0, _bReader_0, _rows_0, _result_0) {
  if (_result_0.$ === "caller-core.CleanupRejected") {
    const _bw_0 = _result_0["world"];
    const _aReader_0 = _result_0["instance"];
    return $caller$045core$058completed_local$1260$(($caller$045core$058record$1260$("foreign-disposal-rejected", "cleanup-rejected", {$: "caller-core.Scene", "a": _a_0, "b": {$: "../../observations.Observed", "owners": _bo_0, "world": _bw_0, "rows": _br_0}, "aReader": _aReader_0, "bReader": _bReader_0, "instances": _rows_0})));
  } else {
    return "UNEXPECTED_FOREIGN_DISPOSAL_ACCEPTED";
  }
}

function $caller$045core$058cleanup$1260$(_instance_0, _world_0) {
  const _registry_0 = _instance_0["registry"];
  const _flow_0 = _instance_0["flow"];
  const _level_0 = _instance_0["level"];
  return $caller$045core$058cleanup_returned$1260$(_flow_0, _level_0, ($public$045cleanup$045v1$047current$045core$047ecs$047system$058dispose$1260$(_registry_0, _world_0)));
}

function $caller$045core$058local_b_returned$1260$(_a_0, _bOwners_0, _bRows_0, _aReader_0, _rows_0, _result_0) {
  const _bReader_0 = _result_0["instance"];
  const _bWorld_0 = _result_0["world"];
  const _delivery_0 = _result_0["delivery"];
  const _status_0 = _result_0["status"];
  const _x_0 = ($caller$045core$058delivery_view$(_delivery_0));
  return $caller$045core$058record$1260$("B-independent-instance", _status_0, {$: "caller-core.Scene", "a": _a_0, "b": {$: "../../observations.Observed", "owners": _bOwners_0, "world": _bWorld_0, "rows": _bRows_0}, "aReader": _aReader_0, "bReader": _bReader_0, "instances": ($List$append$(_rows_0, {$: "Con", "head": ("B-delivery=" + _x_0), "tail": {$: "Nil"}}))});
}

function $$$$047$$$047$$$047readers$058invoke$1260$(_instance_0, _world_0, _fails_0) {
  const _registry_0 = _instance_0["registry"];
  const _t_0 = _instance_0["flow"];
  const _a_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _t_1 = _instance_0["level"];
  const _b_0 = _t_1["namespace"];
  const _jd_0 = _t_1["id"];
  return $$$$047$$$047$$$047readers$058returned$1260$({$: "public-cleanup-v1/current-core/ecs/machine-stream.Reader", "namespace": _a_0, "id": _id_0}, {$: "public-cleanup-v1/current-core/ecs/machine-stream.Reader", "namespace": _b_0, "id": _jd_0}, ($public$045cleanup$045v1$047current$045core$047ecs$047system$058run$1261$(_registry_0, _world_0, {$: "../../../readers.Input", "flowNamespace": _a_0, "flowId": _id_0, "levelNamespace": _b_0, "levelId": _jd_0, "fails": _fails_0})));
}

function $caller$045core$058local_a_returned$1260$(_aOwners_0, _aRows_0, _b_0, _bReader_0, _rows_0, _result_0) {
  const _aReader_0 = _result_0["instance"];
  const _aWorld_0 = _result_0["world"];
  const _delivery_0 = _result_0["delivery"];
  const _status_0 = _result_0["status"];
  const _x_0 = ($caller$045core$058delivery_view$(_delivery_0));
  return $caller$045core$058record$1260$("A-legitimate-retry", _status_0, {$: "caller-core.Scene", "a": {$: "../../observations.Observed", "owners": _aOwners_0, "world": _aWorld_0, "rows": _aRows_0}, "b": _b_0, "aReader": _aReader_0, "bReader": _bReader_0, "instances": ($List$append$(_rows_0, {$: "Con", "head": ("A-delivery=" + _x_0), "tail": {$: "Nil"}}))});
}

function $caller$045core$058foreign_returned$1260$(_a_0, _bOwners_0, _bRows_0, _bReader_0, _rows_0, _result_0) {
  const _aReader_0 = _result_0["instance"];
  const _bWorld_0 = _result_0["world"];
  const _delivery_0 = _result_0["delivery"];
  const _status_0 = _result_0["status"];
  const _x_0 = ($caller$045core$058delivery_view$(_delivery_0));
  return $caller$045core$058record$1260$("foreign-A-on-B", _status_0, {$: "caller-core.Scene", "a": _a_0, "b": {$: "../../observations.Observed", "owners": _bOwners_0, "world": _bWorld_0, "rows": _bRows_0}, "aReader": _aReader_0, "bReader": _bReader_0, "instances": ($List$append$(_rows_0, {$: "Con", "head": ("foreign-delivery=" + _x_0), "tail": {$: "Nil"}}))});
}

function $caller$045core$058record_parts$1260$(_label_0, _a_0, _b_0, _rows_0, _left_0, _right_0) {
  const _aReader_0 = _left_0["fst"];
  const _av_0 = _left_0["snd"];
  const _bReader_0 = _right_0["fst"];
  const _bv_0 = _right_0["snd"];
  const _x_0 = ("|B=" + _bv_0);
  const _x_1 = (_av_0 + _x_0);
  const _x_2 = ("|A=" + _x_1);
  return {$: "caller-core.Scene", "a": _a_0, "b": _b_0, "aReader": _aReader_0, "bReader": _bReader_0, "instances": ($List$append$(_rows_0, {$: "Con", "head": (_label_0 + _x_2), "tail": {$: "Nil"}}))};
}

function $caller$045core$058instance_view$1260$(_instance_0) {
  return $caller$045core$058instance_view_returned$1260$(($$$$047$$$047observations$058reader$1260$({$: "../../../slots.Entry", "key": 99, "owner": _instance_0})));
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_join$1261$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047$$$047$$$047provider$058empty_store$1261$(__0) {
  return {$: "../../../provider.Store", "cells": {$: "../../../../../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}}};
}

function $$$$047$$$047observations$058checkpoint$1261$(_label_0, _rows_0, _result_0) {
  const _owned_0 = _result_0["owners"];
  const _world_0 = _result_0["world"];
  const _status_0 = _result_0["status"];
  return $$$$047$$$047observations$058observed$1261$(_label_0, _status_0, _rows_0, ($$$$047$$$047observations$058owners$1261$(_owned_0)), ($$$$047$$$047$$$047observe$058world$1261$(_world_0)));
}

function $$$$047$$$047$$$047application$058frame$1261$(_owners_0, _world_0, _name_0, _actions_0) {
  return $$$$047$$$047$$$047application$058checked$1261$(_owners_0, _name_0, _actions_0, ($$$$047$$$047$$$047application$058provision_checked$1261$(_world_0, _actions_0)));
}

function $$$$047$$$047$$$047hooks$058registered_level$1261$(_flow_0, _result_0) {
  if (_result_0.$ === "public-cleanup-v1/current-core/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _level_0 = _result_0["registry"];
    return {$: "../../../hooks.Provisioned", "world": _world_0, "owners": {$: "../../../hooks.Owners", "flow": _flow_0, "level": _level_0}};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "../../../hooks.ProvisionFailed", "world": _world_1};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_namespace$1265$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_join$1265$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $caller$045core$058foreign_cleanup_returned$1261$(_a_0, _bo_0, _br_0, _bReader_0, _rows_0, _result_0) {
  if (_result_0.$ === "caller-core.CleanupRejected") {
    const _bw_0 = _result_0["world"];
    const _aReader_0 = _result_0["instance"];
    return $caller$045core$058completed_local$1261$(($caller$045core$058record$1261$("foreign-disposal-rejected", "cleanup-rejected", {$: "caller-core.Scene", "a": _a_0, "b": {$: "../../observations.Observed", "owners": _bo_0, "world": _bw_0, "rows": _br_0}, "aReader": _aReader_0, "bReader": _bReader_0, "instances": _rows_0})));
  } else {
    return "UNEXPECTED_FOREIGN_DISPOSAL_ACCEPTED";
  }
}

function $caller$045core$058cleanup$1261$(_instance_0, _world_0) {
  const _registry_0 = _instance_0["registry"];
  const _flow_0 = _instance_0["flow"];
  const _level_0 = _instance_0["level"];
  return $caller$045core$058cleanup_returned$1261$(_flow_0, _level_0, ($public$045cleanup$045v1$047current$045core$047ecs$047system$058dispose$1261$(_registry_0, _world_0)));
}

function $caller$045core$058local_b_returned$1261$(_a_0, _bOwners_0, _bRows_0, _aReader_0, _rows_0, _result_0) {
  const _bReader_0 = _result_0["instance"];
  const _bWorld_0 = _result_0["world"];
  const _delivery_0 = _result_0["delivery"];
  const _status_0 = _result_0["status"];
  const _x_0 = ($caller$045core$058delivery_view$(_delivery_0));
  return $caller$045core$058record$1261$("B-independent-instance", _status_0, {$: "caller-core.Scene", "a": _a_0, "b": {$: "../../observations.Observed", "owners": _bOwners_0, "world": _bWorld_0, "rows": _bRows_0}, "aReader": _aReader_0, "bReader": _bReader_0, "instances": ($List$append$(_rows_0, {$: "Con", "head": ("B-delivery=" + _x_0), "tail": {$: "Nil"}}))});
}

function $$$$047$$$047$$$047readers$058invoke$1261$(_instance_0, _world_0, _fails_0) {
  const _registry_0 = _instance_0["registry"];
  const _t_0 = _instance_0["flow"];
  const _a_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _t_1 = _instance_0["level"];
  const _b_0 = _t_1["namespace"];
  const _jd_0 = _t_1["id"];
  return $$$$047$$$047$$$047readers$058returned$1261$({$: "public-cleanup-v1/current-core/ecs/machine-stream.Reader", "namespace": _a_0, "id": _id_0}, {$: "public-cleanup-v1/current-core/ecs/machine-stream.Reader", "namespace": _b_0, "id": _jd_0}, ($public$045cleanup$045v1$047current$045core$047ecs$047system$058run$1264$(_registry_0, _world_0, {$: "../../../readers.Input", "flowNamespace": _a_0, "flowId": _id_0, "levelNamespace": _b_0, "levelId": _jd_0, "fails": _fails_0})));
}

function $caller$045core$058local_a_returned$1261$(_aOwners_0, _aRows_0, _b_0, _bReader_0, _rows_0, _result_0) {
  const _aReader_0 = _result_0["instance"];
  const _aWorld_0 = _result_0["world"];
  const _delivery_0 = _result_0["delivery"];
  const _status_0 = _result_0["status"];
  const _x_0 = ($caller$045core$058delivery_view$(_delivery_0));
  return $caller$045core$058record$1261$("A-legitimate-retry", _status_0, {$: "caller-core.Scene", "a": {$: "../../observations.Observed", "owners": _aOwners_0, "world": _aWorld_0, "rows": _aRows_0}, "b": _b_0, "aReader": _aReader_0, "bReader": _bReader_0, "instances": ($List$append$(_rows_0, {$: "Con", "head": ("A-delivery=" + _x_0), "tail": {$: "Nil"}}))});
}

function $caller$045core$058foreign_returned$1261$(_a_0, _bOwners_0, _bRows_0, _bReader_0, _rows_0, _result_0) {
  const _aReader_0 = _result_0["instance"];
  const _bWorld_0 = _result_0["world"];
  const _delivery_0 = _result_0["delivery"];
  const _status_0 = _result_0["status"];
  const _x_0 = ($caller$045core$058delivery_view$(_delivery_0));
  return $caller$045core$058record$1261$("foreign-A-on-B", _status_0, {$: "caller-core.Scene", "a": _a_0, "b": {$: "../../observations.Observed", "owners": _bOwners_0, "world": _bWorld_0, "rows": _bRows_0}, "aReader": _aReader_0, "bReader": _bReader_0, "instances": ($List$append$(_rows_0, {$: "Con", "head": ("foreign-delivery=" + _x_0), "tail": {$: "Nil"}}))});
}

function $caller$045core$058record_parts$1261$(_label_0, _a_0, _b_0, _rows_0, _left_0, _right_0) {
  const _aReader_0 = _left_0["fst"];
  const _av_0 = _left_0["snd"];
  const _bReader_0 = _right_0["fst"];
  const _bv_0 = _right_0["snd"];
  const _x_0 = ("|B=" + _bv_0);
  const _x_1 = (_av_0 + _x_0);
  const _x_2 = ("|A=" + _x_1);
  return {$: "caller-core.Scene", "a": _a_0, "b": _b_0, "aReader": _aReader_0, "bReader": _bReader_0, "instances": ($List$append$(_rows_0, {$: "Con", "head": (_label_0 + _x_2), "tail": {$: "Nil"}}))};
}

function $caller$045core$058instance_view$1261$(_instance_0) {
  return $caller$045core$058instance_view_returned$1261$(($$$$047$$$047observations$058reader$1261$({$: "../../../slots.Entry", "key": 99, "owner": _instance_0})));
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_join$1264$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_meta$1264$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058register_checked$1261$((_nextSystemId_0 < 4294967295), {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047$$$047observations$058observed$1260$(_label_0, _status_0, _rows_0, _a_0, _b_0) {
  const _owners_0 = _a_0["fst"];
  const _a_1 = _a_0["snd"];
  const _world_0 = _b_0["fst"];
  const _b_1 = _b_0["snd"];
  const _x_0 = (";" + _a_1);
  const _x_1 = (_b_1 + _x_0);
  const _x_2 = ("|" + _x_1);
  const _x_3 = (_status_0 + _x_2);
  const _x_4 = ("|" + _x_3);
  return {$: "../../observations.Observed", "owners": _owners_0, "world": _world_0, "rows": ($List$append$(_rows_0, {$: "Con", "head": (_label_0 + _x_4), "tail": {$: "Nil"}}))};
}

function $$$$047$$$047observations$058owners$1260$(_value_0) {
  const _userCatalog_0 = _value_0["users"];
  const _hookOwners_0 = _value_0["hooks"];
  const _readerEntries_0 = _value_0["readers"];
  const _attempts_0 = _value_0["attempts"];
  const _deliveries_0 = _value_0["deliveries"];
  const _conditions_0 = _value_0["conditions"];
  const _active_0 = _value_0["active"];
  return $$$$047$$$047observations$058owners_join$1260$(($$$$047$$$047observations$058catalog$1260$(_userCatalog_0)), ($$$$047$$$047observations$058hooks$1260$(_hookOwners_0)), ($$$$047$$$047observations$058readers$1260$(_readerEntries_0)), _attempts_0, _deliveries_0, _conditions_0, _active_0);
}

function $$$$047$$$047$$$047observe$058world$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047observe$058world_join$1260$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, ($$$$047$$$047$$$047observe$058live_view$(_live_0)), ($$$$047$$$047$$$047observe$058store_view$1260$(_store_0)), ($$$$047$$$047$$$047observe$058resources_view$1260$(_resources_0)), _events_0, ($$$$047$$$047$$$047observe$058queue_view$1260$(_commands_0)), _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047$$$047$$$047application$058checked$1260$(_owners_0, _name_0, _actions_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (!_t_0) {
    return {$: "../../../application.FrameResult", "owners": _owners_0, "world": _world_0, "status": "machine-provision-rejected"};
  } else {
    return $$$$047$$$047$$$047application$058named$1260$(_owners_0, _name_0, _actions_0, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058namespace$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047application$058provision_checked$1260$(_world_0, _actions_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _flowStream_0 = _t_0["flowStream"];
  const _levelStream_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _trace_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047application$058ready$1260$(_actions_0, {$: "../../../provider.ConditionEnv", "flow": _flow_0, "level": _level_0}))};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_join$1262$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_meta$1262$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $caller$045core$058completed_local$1260$(_scene_0) {
  const _t_0 = _scene_0["a"];
  const _ao_0 = _t_0["owners"];
  const _aw_0 = _t_0["world"];
  const _ar_0 = _t_0["rows"];
  const _b_0 = _scene_0["b"];
  const _aReader_0 = _scene_0["aReader"];
  const _bReader_0 = _scene_0["bReader"];
  const _rows_0 = _scene_0["instances"];
  return $caller$045core$058a_cleaned$1260$(_ao_0, _ar_0, _b_0, _bReader_0, _rows_0, ($caller$045core$058cleanup$1260$(_aReader_0, _aw_0)));
}

function $caller$045core$058cleanup_returned$1260$(_flow_0, _level_0, _result_0) {
  const __0 = _flow_0["namespace"];
  const _id_0 = _flow_0["id"];
  const __1 = _level_0["namespace"];
  const _jd_0 = _level_0["id"];
  if (_result_0.$ === "public-cleanup-v1/current-core/ecs/system.Disposed") {
    const _world_0 = _result_0["world"];
    return {$: "caller-core.Cleaned", "world": ($caller$045core$058dispose_streams$1260$(_world_0, _id_0, _jd_0))};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "caller-core.CleanupRejected", "world": _world_1, "instance": {$: "../../../readers.Instance", "registry": _registry_0, "flow": {$: "public-cleanup-v1/current-core/ecs/machine-stream.Reader", "namespace": __0, "id": _id_0}, "level": {$: "public-cleanup-v1/current-core/ecs/machine-stream.Reader", "namespace": __1, "id": _jd_0}}};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058dispose$1260$(_registry_0, _world_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058dispose_returned$1260$({$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($public$045cleanup$045v1$047current$045core$047ecs$047registration$058remove$1260$(_world_0, _namespace_0, _id_0, _name_0, _access_0)));
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $caller$045core$058delivery_view$(_value_0) {
  if (_value_0.$ === "None") {
    return "none";
  } else {
    const _value_1 = _value_0["value"];
    return $List$show$1264$(($$$$047$$$047$$$047application$058delivery$("actual", {$: "Some", "value": _value_1}, {$: "Nil"})));
  }
}

function $$$$047$$$047$$$047readers$058returned$1260$(_flow_0, _level_0, _result_0) {
  if (_result_0.$ === "public-cleanup-v1/current-core/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _t_0 = _result_0["outcome"];
    if (_t_0.$ === "public-cleanup-v1/current-core/ecs/system.Succeeded") {
      const _world_0 = _t_0["world"];
      const _delivery_0 = _t_0["output"];
      return {$: "../../../readers.Returned", "instance": {$: "../../../readers.Instance", "registry": _registry_0, "flow": _flow_0, "level": _level_0}, "world": _world_0, "delivery": {$: "Some", "value": _delivery_0}, "status": "ok"};
    } else {
      const _world_1 = _t_0["world"];
      const _t_1 = _t_0["error"];
      const _error_0 = _t_1["message"];
      const _delivery_1 = _t_1["delivery"];
      return {$: "../../../readers.Returned", "instance": {$: "../../../readers.Instance", "registry": _registry_0, "flow": _flow_0, "level": _level_0}, "world": _world_1, "delivery": _delivery_1, "status": _error_0};
    }
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_2 = _result_0["world"];
    return {$: "../../../readers.Returned", "instance": {$: "../../../readers.Instance", "registry": _registry_1, "flow": _flow_0, "level": _level_0}, "world": _world_2, "delivery": {$: "None"}, "status": "reader-registration-rejected"};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace$1261$(_registry_0, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $caller$045core$058instance_view_returned$1260$(_pair_0) {
  const _t_0 = _pair_0["fst"];
  const _instance_0 = _t_0["owner"];
  const _view_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": _instance_0, "snd": _view_0};
}

function $$$$047$$$047observations$058reader$1260$(_entry_0) {
  const _key_0 = _entry_0["key"];
  const _t_0 = _entry_0["owner"];
  const _t_1 = _t_0["registry"];
  const _ns_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _name_0 = _t_1["name"];
  const _access_0 = _t_1["access"];
  const _cursor_0 = _t_1["cursor"];
  const _t_2 = _t_0["flow"];
  const _a_0 = _t_2["namespace"];
  const _ai_0 = _t_2["id"];
  const _t_3 = _t_0["level"];
  const _b_0 = _t_3["namespace"];
  const _bi_0 = _t_3["id"];
  const _x_0 = ($U32$show$(_bi_0));
  const _x_1 = ($U32$show$(_b_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_ai_0));
  const _x_5 = (":level=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($U32$show$(_a_0));
  const _x_8 = (":" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($U32$show$(_cursor_0));
  const _x_11 = (":flow=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($List$show$1261$(_access_0));
  const _x_14 = (":" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = (":" + _x_15);
  const _x_17 = (_name_0 + _x_16);
  const _x_18 = ($U32$show$(_id_0));
  const _x_19 = (":" + _x_17);
  const _x_20 = (_x_18 + _x_19);
  const _x_21 = ($U32$show$(_ns_0));
  const _x_22 = (":" + _x_20);
  const _x_23 = (_x_21 + _x_22);
  const _x_24 = ($U32$show$(_key_0));
  const _x_25 = (":" + _x_23);
  return {$: "Tuple", "fst": {$: "../../../slots.Entry", "key": _key_0, "owner": {$: "../../../readers.Instance", "registry": {$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "flow": {$: "public-cleanup-v1/current-core/ecs/machine-stream.Reader", "namespace": _a_0, "id": _ai_0}, "level": {$: "public-cleanup-v1/current-core/ecs/machine-stream.Reader", "namespace": _b_0, "id": _bi_0}}}, "snd": (_x_24 + _x_25)};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "public-cleanup-v1/current-core/ecs/world.RegistrationRejected") {
    return {$: "public-cleanup-v1/current-core/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "public-cleanup-v1/current-core/ecs/system.Registered", "world": _world_0, "registry": {$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "public-cleanup-v1/current-core/ecs/world.RegistrationRejected", "error": {$: "public-cleanup-v1/current-core/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "public-cleanup-v1/current-core/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047$$$047observations$058observed$1261$(_label_0, _status_0, _rows_0, _a_0, _b_0) {
  const _owners_0 = _a_0["fst"];
  const _a_1 = _a_0["snd"];
  const _world_0 = _b_0["fst"];
  const _b_1 = _b_0["snd"];
  const _x_0 = (";" + _a_1);
  const _x_1 = (_b_1 + _x_0);
  const _x_2 = ("|" + _x_1);
  const _x_3 = (_status_0 + _x_2);
  const _x_4 = ("|" + _x_3);
  return {$: "../../observations.Observed", "owners": _owners_0, "world": _world_0, "rows": ($List$append$(_rows_0, {$: "Con", "head": (_label_0 + _x_4), "tail": {$: "Nil"}}))};
}

function $$$$047$$$047observations$058owners$1261$(_value_0) {
  const _userCatalog_0 = _value_0["users"];
  const _hookOwners_0 = _value_0["hooks"];
  const _readerEntries_0 = _value_0["readers"];
  const _attempts_0 = _value_0["attempts"];
  const _deliveries_0 = _value_0["deliveries"];
  const _conditions_0 = _value_0["conditions"];
  const _active_0 = _value_0["active"];
  return $$$$047$$$047observations$058owners_join$1261$(($$$$047$$$047observations$058catalog$1261$(_userCatalog_0)), ($$$$047$$$047observations$058hooks$1261$(_hookOwners_0)), ($$$$047$$$047observations$058readers$1261$(_readerEntries_0)), _attempts_0, _deliveries_0, _conditions_0, _active_0);
}

function $$$$047$$$047$$$047observe$058world$1261$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047observe$058world_join$1261$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, ($$$$047$$$047$$$047observe$058live_view$(_live_0)), ($$$$047$$$047$$$047observe$058store_view$1261$(_store_0)), ($$$$047$$$047$$$047observe$058resources_view$1261$(_resources_0)), _events_0, ($$$$047$$$047$$$047observe$058queue_view$1261$(_commands_0)), _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047$$$047$$$047application$058checked$1261$(_owners_0, _name_0, _actions_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (!_t_0) {
    return {$: "../../../application.FrameResult", "owners": _owners_0, "world": _world_0, "status": "machine-provision-rejected"};
  } else {
    return $$$$047$$$047$$$047application$058named$1261$(_owners_0, _name_0, _actions_0, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058namespace$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047application$058provision_checked$1261$(_world_0, _actions_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _flowStream_0 = _t_0["flowStream"];
  const _levelStream_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _trace_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047application$058ready$1261$(_actions_0, {$: "../../../provider.ConditionEnv", "flow": _flow_0, "level": _level_0}))};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_join$1265$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_meta$1265$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $caller$045core$058completed_local$1261$(_scene_0) {
  const _t_0 = _scene_0["a"];
  const _ao_0 = _t_0["owners"];
  const _aw_0 = _t_0["world"];
  const _ar_0 = _t_0["rows"];
  const _b_0 = _scene_0["b"];
  const _aReader_0 = _scene_0["aReader"];
  const _bReader_0 = _scene_0["bReader"];
  const _rows_0 = _scene_0["instances"];
  return $caller$045core$058a_cleaned$1261$(_ao_0, _ar_0, _b_0, _bReader_0, _rows_0, ($caller$045core$058cleanup$1261$(_aReader_0, _aw_0)));
}

function $caller$045core$058cleanup_returned$1261$(_flow_0, _level_0, _result_0) {
  const __0 = _flow_0["namespace"];
  const _id_0 = _flow_0["id"];
  const __1 = _level_0["namespace"];
  const _jd_0 = _level_0["id"];
  if (_result_0.$ === "public-cleanup-v1/current-core/ecs/system.Disposed") {
    const _world_0 = _result_0["world"];
    return {$: "caller-core.Cleaned", "world": ($caller$045core$058dispose_streams$1261$(_world_0, _id_0, _jd_0))};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "caller-core.CleanupRejected", "world": _world_1, "instance": {$: "../../../readers.Instance", "registry": _registry_0, "flow": {$: "public-cleanup-v1/current-core/ecs/machine-stream.Reader", "namespace": __0, "id": _id_0}, "level": {$: "public-cleanup-v1/current-core/ecs/machine-stream.Reader", "namespace": __1, "id": _jd_0}}};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058dispose$1261$(_registry_0, _world_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058dispose_returned$1261$({$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($public$045cleanup$045v1$047current$045core$047ecs$047registration$058remove$1261$(_world_0, _namespace_0, _id_0, _name_0, _access_0)));
}

function $$$$047$$$047$$$047readers$058returned$1261$(_flow_0, _level_0, _result_0) {
  if (_result_0.$ === "public-cleanup-v1/current-core/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _t_0 = _result_0["outcome"];
    if (_t_0.$ === "public-cleanup-v1/current-core/ecs/system.Succeeded") {
      const _world_0 = _t_0["world"];
      const _delivery_0 = _t_0["output"];
      return {$: "../../../readers.Returned", "instance": {$: "../../../readers.Instance", "registry": _registry_0, "flow": _flow_0, "level": _level_0}, "world": _world_0, "delivery": {$: "Some", "value": _delivery_0}, "status": "ok"};
    } else {
      const _world_1 = _t_0["world"];
      const _t_1 = _t_0["error"];
      const _error_0 = _t_1["message"];
      const _delivery_1 = _t_1["delivery"];
      return {$: "../../../readers.Returned", "instance": {$: "../../../readers.Instance", "registry": _registry_0, "flow": _flow_0, "level": _level_0}, "world": _world_1, "delivery": _delivery_1, "status": _error_0};
    }
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_2 = _result_0["world"];
    return {$: "../../../readers.Returned", "instance": {$: "../../../readers.Instance", "registry": _registry_1, "flow": _flow_0, "level": _level_0}, "world": _world_2, "delivery": {$: "None"}, "status": "reader-registration-rejected"};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run$1264$(_registry_0, _world_0, _args_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace$1264$(_registry_0, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $caller$045core$058instance_view_returned$1261$(_pair_0) {
  const _t_0 = _pair_0["fst"];
  const _instance_0 = _t_0["owner"];
  const _view_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": _instance_0, "snd": _view_0};
}

function $$$$047$$$047observations$058reader$1261$(_entry_0) {
  const _key_0 = _entry_0["key"];
  const _t_0 = _entry_0["owner"];
  const _t_1 = _t_0["registry"];
  const _ns_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _name_0 = _t_1["name"];
  const _access_0 = _t_1["access"];
  const _cursor_0 = _t_1["cursor"];
  const _t_2 = _t_0["flow"];
  const _a_0 = _t_2["namespace"];
  const _ai_0 = _t_2["id"];
  const _t_3 = _t_0["level"];
  const _b_0 = _t_3["namespace"];
  const _bi_0 = _t_3["id"];
  const _x_0 = ($U32$show$(_bi_0));
  const _x_1 = ($U32$show$(_b_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_ai_0));
  const _x_5 = (":level=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($U32$show$(_a_0));
  const _x_8 = (":" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($U32$show$(_cursor_0));
  const _x_11 = (":flow=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($List$show$1261$(_access_0));
  const _x_14 = (":" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = (":" + _x_15);
  const _x_17 = (_name_0 + _x_16);
  const _x_18 = ($U32$show$(_id_0));
  const _x_19 = (":" + _x_17);
  const _x_20 = (_x_18 + _x_19);
  const _x_21 = ($U32$show$(_ns_0));
  const _x_22 = (":" + _x_20);
  const _x_23 = (_x_21 + _x_22);
  const _x_24 = ($U32$show$(_key_0));
  const _x_25 = (":" + _x_23);
  return {$: "Tuple", "fst": {$: "../../../slots.Entry", "key": _key_0, "owner": {$: "../../../readers.Instance", "registry": {$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "flow": {$: "public-cleanup-v1/current-core/ecs/machine-stream.Reader", "namespace": _a_0, "id": _ai_0}, "level": {$: "public-cleanup-v1/current-core/ecs/machine-stream.Reader", "namespace": _b_0, "id": _bi_0}}}, "snd": (_x_24 + _x_25)};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_meta$1264$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "public-cleanup-v1/current-core/ecs/world.RegistrationRejected") {
    return {$: "public-cleanup-v1/current-core/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "public-cleanup-v1/current-core/ecs/system.Registered", "world": _world_0, "registry": {$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058register_checked$1261$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "public-cleanup-v1/current-core/ecs/world.RegistrationRejected", "error": {$: "public-cleanup-v1/current-core/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "public-cleanup-v1/current-core/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047$$$047observations$058owners_join$1260$(_a_0, _b_0, _c_0, _attempts_0, _deliveries_0, _conditions_0, _active_0) {
  const _users_0 = _a_0["fst"];
  const _a_1 = _a_0["snd"];
  const _hooks_0 = _b_0["fst"];
  const _b_1 = _b_0["snd"];
  const _readers_0 = _c_0["fst"];
  const _c_1 = _c_0["snd"];
  const _x_0 = ($List$show$1265$(_active_0));
  const _x_1 = ($List$show$1261$(_conditions_0));
  const _x_2 = (";active=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($List$show$1261$(_deliveries_0));
  const _x_5 = (";conditions=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($List$show$1261$(_attempts_0));
  const _x_8 = (";deliveries=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($List$show$1261$(_c_1));
  const _x_11 = (";attempts=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = (";readerOwners=" + _x_12);
  const _x_14 = (_b_1 + _x_13);
  const _x_15 = (";hookOwners=" + _x_14);
  const _x_16 = (_a_1 + _x_15);
  return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": _readers_0, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, "snd": ("users=" + _x_16)};
}

function $$$$047$$$047observations$058catalog$1260$(_value_0) {
  const _entries_0 = _value_0["entries"];
  return $$$$047$$$047observations$058user_catalog$1260$(($$$$047$$$047observations$058users$1260$(_entries_0)));
}

function $$$$047$$$047observations$058hooks$1260$(_owners_0) {
  const _flow_0 = _owners_0["flow"];
  const _level_0 = _owners_0["level"];
  return $$$$047$$$047observations$058hook_join$1260$(($$$$047$$$047observations$058hook_registry$1260$(_flow_0)), ($$$$047$$$047observations$058hook_registry$1260$(_level_0)));
}

function $$$$047$$$047observations$058readers$1260$(_entries_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _entries_0["head"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047observations$058readers_join$1260$(($$$$047$$$047observations$058reader$1260$(_head_0)), ($$$$047$$$047observations$058readers$1260$(_rest_0)));
  }
}

function $$$$047$$$047$$$047observe$058world_join$1260$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _pairLive_0, _pairStore_0, _pairResources_0, _events_0, _pairCommands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _live_0 = _pairLive_0["fst"];
  const _liveValues_0 = _pairLive_0["snd"];
  const _store_0 = _pairStore_0["fst"];
  const _cells_0 = _pairStore_0["snd"];
  const _resources_0 = _pairResources_0["fst"];
  const _resourceText_0 = _pairResources_0["snd"];
  const _commands_0 = _pairCommands_0["fst"];
  const _commandCount_0 = _pairCommands_0["snd"];
  const _x_0 = ($Nat$show$(($List$length$(_events_0))));
  const _x_1 = ($U32$show$(_clock_0));
  const _x_2 = (";busEvents=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_nextSystem_0));
  const _x_5 = (";componentClock=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($List$show$1267$(_registrations_0));
  const _x_8 = (";nextSystem=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($Nat$show$(_commandCount_0));
  const _x_11 = (";registrations=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = (";queue=" + _x_12);
  const _x_14 = (_resourceText_0 + _x_13);
  const _x_15 = (";" + _x_14);
  const _x_16 = (_cells_0 + _x_15);
  const _x_17 = ($List$show$1266$(_liveValues_0));
  const _x_18 = (";cells=" + _x_16);
  const _x_19 = (_x_17 + _x_18);
  const _x_20 = ($Nat$show$(_depth_0));
  const _x_21 = (";live=" + _x_19);
  const _x_22 = (_x_20 + _x_21);
  const _x_23 = ($U32$show$(_capacity_0));
  const _x_24 = (";depth=" + _x_22);
  const _x_25 = (_x_23 + _x_24);
  const _x_26 = ($U32$show$(_high_0));
  const _x_27 = (";capacity=" + _x_25);
  const _x_28 = (_x_26 + _x_27);
  const _x_29 = ($U32$show$(_next_0));
  const _x_30 = (";high=" + _x_28);
  const _x_31 = (_x_29 + _x_30);
  const _x_32 = ($U32$show$(_ns_0));
  const _x_33 = (";next=" + _x_31);
  const _x_34 = (_x_32 + _x_33);
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ("ns=" + _x_34)};
}

function $$$$047$$$047$$$047observe$058live_view$(_live_0) {
  if (_live_0.length === 1) {
    const _value_0 = _live_0[0];
    return {$: "Tuple", "fst": [_value_0], "snd": {$: "Con", "head": _value_0, "tail": {$: "Nil"}}};
  } else {
    const _left_0 = _live_0.slice(0, _live_0.length >> 1);
    const _right_0 = _live_0.slice(_live_0.length >> 1);
    return $$$$047$$$047$$$047observe$058live_join$(($$$$047$$$047$$$047observe$058live_view$(_left_0)), ($$$$047$$$047$$$047observe$058live_view$(_right_0)));
  }
}

function $$$$047$$$047$$$047observe$058store_view$1260$(_store_0) {
  const _column_0 = _store_0["cells"];
  return $$$$047$$$047$$$047observe$058store_join$1260$(($$$$047$$$047$$$047observe$058column_view$1260$(_column_0)));
}

function $$$$047$$$047$$$047observe$058resources_view$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return $$$$047$$$047$$$047observe$058resources_join$1260$(($$$$047$$$047$$$047observe$058owner_view$(_owned_0)), _flow_0, _level_0, _flowStream_0, _levelStream_0, _frame_0, _tick_0, _trace_0);
}

function $$$$047$$$047$$$047observe$058queue_view$1260$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047observe$058queue_join$1260$(_command_0, ($$$$047$$$047$$$047observe$058queue_view$1260$(_rest_0)));
  }
}

function $$$$047$$$047$$$047application$058named$1260$(_owners_0, _name_0, _actions_0, _pair_0) {
  const _users_0 = _owners_0["users"];
  const _hooks_0 = _owners_0["hooks"];
  const _readers_0 = _owners_0["readers"];
  const _attempts_0 = _owners_0["attempts"];
  const _deliveries_0 = _owners_0["deliveries"];
  const _conditions_0 = _owners_0["conditions"];
  const _world_0 = _pair_0["fst"];
  const _namespace_0 = _pair_0["snd"];
  return $$$$047$$$047$$$047application$058built$1260$(($$$$047$$$047$$$047provider$058frame$1260$(_world_0)), ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058build$1260$(_namespace_0, _name_0, ($$$$047$$$047$$$047application$058steps$1260$(_actions_0)), ($$$$047$$$047$$$047application$058ids$1260$(_actions_0)), {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": _readers_0, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _actions_0})));
}

function $$$$047$$$047$$$047application$058ready$1260$(_actions_0, _env_0) {
  if (_actions_0.$ === "Nil") {
    return true;
  } else {
    const _head_0 = _actions_0["head"];
    const _rest_0 = _actions_0["tail"];
    return $Bool$and$(($$$$047$$$047$$$047application$058action_ready$1260$(_head_0, _env_0)), ($$$$047$$$047$$$047application$058ready$1260$(_rest_0, _env_0)));
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_meta$1262$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "public-cleanup-v1/current-core/ecs/world.RegistrationRejected") {
    return {$: "public-cleanup-v1/current-core/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "public-cleanup-v1/current-core/ecs/system.Registered", "world": _world_0, "registry": {$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $caller$045core$058a_cleaned$1260$(_ao_0, _ar_0, _b_0, _bReader_0, _rows_0, _result_0) {
  const _bo_0 = _b_0["owners"];
  const _bw_0 = _b_0["world"];
  const _br_0 = _b_0["rows"];
  if (_result_0.$ === "caller-core.Cleaned") {
    const _world_0 = _result_0["world"];
    return $caller$045core$058survivor$1260$(($$$$047$$$047observations$058checkpoint$1260$("A-owned-cleanup", _ar_0, {$: "../../../application.FrameResult", "owners": _ao_0, "world": _world_0, "status": "cleaned"})), _bo_0, _br_0, ($List$append$(_rows_0, {$: "Con", "head": "A-owned-cleanup|A=disposed", "tail": {$: "Nil"}})), _bReader_0, _bw_0);
  } else {
    const _world_1 = _result_0["world"];
    return $caller$045core$058finish_pair$1260$(($$$$047$$$047observations$058checkpoint$1260$("A-cleanup-rejected", _ar_0, {$: "../../../application.FrameResult", "owners": _ao_0, "world": _world_1, "status": "cleanup-rejected"})), {$: "../../observations.Observed", "owners": _bo_0, "world": _bw_0, "rows": _br_0}, ($List$append$(_rows_0, {$: "Con", "head": "A-cleanup-rejected", "tail": {$: "Nil"}})));
  }
}

function $caller$045core$058dispose_streams$1260$(_world_0, _flowId_0, _levelId_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _fs_0 = _t_0["flowStream"];
  const _ls_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _trace_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058dispose$1260$(_fs_0, _flowId_0)), "levelStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058dispose$1261$(_ls_0, _levelId_0)), "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "events": _events_0, "pending": _commands_0, "registrations": _regs_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058dispose_returned$1260$(_registry_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0) {
    return {$: "public-cleanup-v1/current-core/ecs/system.Disposed", "world": _world_0};
  } else {
    return {$: "public-cleanup-v1/current-core/ecs/system.DisposalRejected", "world": _world_0, "registry": _registry_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047registration$058remove$1260$(_world_0, _namespace_0, _id_0, _name_0, _access_0) {
  const _actual_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047registration$058remove_checked$1260$(($Bool$and$((_namespace_0 === _actual_0), ($public$045cleanup$045v1$047current$045core$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0)))), {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _actual_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _id_0, _name_0, _access_0);
}

function $List$show$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1264$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return ("[" + _x_1);
  }
}

function $$$$047$$$047$$$047application$058delivery$(_name_0, _result_0, _rows_0) {
  if (_result_0.$ === "None") {
    return _rows_0;
  } else {
    const _t_0 = _result_0["value"];
    const _flow_0 = _t_0["flow"];
    const _level_0 = _t_0["level"];
    const _fl_0 = _t_0["flowLagged"];
    const _ll_0 = _t_0["levelLagged"];
    const _x_0 = ($$$$047$$$047$$$047observe$058bool$(_ll_0));
    const _x_1 = ($$$$047$$$047$$$047observe$058bool$(_fl_0));
    const _x_2 = ("," + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($List$show$1263$(_level_0));
    const _x_5 = (":lagged=" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    const _x_7 = ($List$show$1262$(_flow_0));
    const _x_8 = (":level=" + _x_6);
    const _x_9 = (_x_7 + _x_8);
    const _x_10 = (":flow=" + _x_9);
    return $List$append$(_rows_0, {$: "Con", "head": (_name_0 + _x_10), "tail": {$: "Nil"}});
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace$1261$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0);
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $List$show$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047observe$058text$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047observations$058owners_join$1261$(_a_0, _b_0, _c_0, _attempts_0, _deliveries_0, _conditions_0, _active_0) {
  const _users_0 = _a_0["fst"];
  const _a_1 = _a_0["snd"];
  const _hooks_0 = _b_0["fst"];
  const _b_1 = _b_0["snd"];
  const _readers_0 = _c_0["fst"];
  const _c_1 = _c_0["snd"];
  const _x_0 = ($List$show$12614$(_active_0));
  const _x_1 = ($List$show$1261$(_conditions_0));
  const _x_2 = (";active=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($List$show$1261$(_deliveries_0));
  const _x_5 = (";conditions=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($List$show$1261$(_attempts_0));
  const _x_8 = (";deliveries=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($List$show$1261$(_c_1));
  const _x_11 = (";attempts=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = (";readerOwners=" + _x_12);
  const _x_14 = (_b_1 + _x_13);
  const _x_15 = (";hookOwners=" + _x_14);
  const _x_16 = (_a_1 + _x_15);
  return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": _readers_0, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, "snd": ("users=" + _x_16)};
}

function $$$$047$$$047observations$058catalog$1261$(_value_0) {
  const _entries_0 = _value_0["entries"];
  return $$$$047$$$047observations$058user_catalog$1261$(($$$$047$$$047observations$058users$1261$(_entries_0)));
}

function $$$$047$$$047observations$058hooks$1261$(_owners_0) {
  const _flow_0 = _owners_0["flow"];
  const _level_0 = _owners_0["level"];
  return $$$$047$$$047observations$058hook_join$1261$(($$$$047$$$047observations$058hook_registry$1261$(_flow_0)), ($$$$047$$$047observations$058hook_registry$1261$(_level_0)));
}

function $$$$047$$$047observations$058readers$1261$(_entries_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _entries_0["head"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047observations$058readers_join$1261$(($$$$047$$$047observations$058reader$1261$(_head_0)), ($$$$047$$$047observations$058readers$1261$(_rest_0)));
  }
}

function $$$$047$$$047$$$047observe$058world_join$1261$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _pairLive_0, _pairStore_0, _pairResources_0, _events_0, _pairCommands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _live_0 = _pairLive_0["fst"];
  const _liveValues_0 = _pairLive_0["snd"];
  const _store_0 = _pairStore_0["fst"];
  const _cells_0 = _pairStore_0["snd"];
  const _resources_0 = _pairResources_0["fst"];
  const _resourceText_0 = _pairResources_0["snd"];
  const _commands_0 = _pairCommands_0["fst"];
  const _commandCount_0 = _pairCommands_0["snd"];
  const _x_0 = ($Nat$show$(($List$length$(_events_0))));
  const _x_1 = ($U32$show$(_clock_0));
  const _x_2 = (";busEvents=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_nextSystem_0));
  const _x_5 = (";componentClock=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($List$show$1267$(_registrations_0));
  const _x_8 = (";nextSystem=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($Nat$show$(_commandCount_0));
  const _x_11 = (";registrations=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = (";queue=" + _x_12);
  const _x_14 = (_resourceText_0 + _x_13);
  const _x_15 = (";" + _x_14);
  const _x_16 = (_cells_0 + _x_15);
  const _x_17 = ($List$show$1266$(_liveValues_0));
  const _x_18 = (";cells=" + _x_16);
  const _x_19 = (_x_17 + _x_18);
  const _x_20 = ($Nat$show$(_depth_0));
  const _x_21 = (";live=" + _x_19);
  const _x_22 = (_x_20 + _x_21);
  const _x_23 = ($U32$show$(_capacity_0));
  const _x_24 = (";depth=" + _x_22);
  const _x_25 = (_x_23 + _x_24);
  const _x_26 = ($U32$show$(_high_0));
  const _x_27 = (";capacity=" + _x_25);
  const _x_28 = (_x_26 + _x_27);
  const _x_29 = ($U32$show$(_next_0));
  const _x_30 = (";high=" + _x_28);
  const _x_31 = (_x_29 + _x_30);
  const _x_32 = ($U32$show$(_ns_0));
  const _x_33 = (";next=" + _x_31);
  const _x_34 = (_x_32 + _x_33);
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ("ns=" + _x_34)};
}

function $$$$047$$$047$$$047observe$058store_view$1261$(_store_0) {
  const _column_0 = _store_0["cells"];
  return $$$$047$$$047$$$047observe$058store_join$1261$(($$$$047$$$047$$$047observe$058column_view$1261$(_column_0)));
}

function $$$$047$$$047$$$047observe$058resources_view$1261$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return $$$$047$$$047$$$047observe$058resources_join$1261$(($$$$047$$$047$$$047observe$058owner_view$(_owned_0)), _flow_0, _level_0, _flowStream_0, _levelStream_0, _frame_0, _tick_0, _trace_0);
}

function $$$$047$$$047$$$047observe$058queue_view$1261$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047observe$058queue_join$1261$(_command_0, ($$$$047$$$047$$$047observe$058queue_view$1261$(_rest_0)));
  }
}

function $$$$047$$$047$$$047application$058named$1261$(_owners_0, _name_0, _actions_0, _pair_0) {
  const _users_0 = _owners_0["users"];
  const _hooks_0 = _owners_0["hooks"];
  const _readers_0 = _owners_0["readers"];
  const _attempts_0 = _owners_0["attempts"];
  const _deliveries_0 = _owners_0["deliveries"];
  const _conditions_0 = _owners_0["conditions"];
  const _world_0 = _pair_0["fst"];
  const _namespace_0 = _pair_0["snd"];
  return $$$$047$$$047$$$047application$058built$1261$(($$$$047$$$047$$$047provider$058frame$1261$(_world_0)), ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058build$1261$(_namespace_0, _name_0, ($$$$047$$$047$$$047application$058steps$1261$(_actions_0)), ($$$$047$$$047$$$047application$058ids$1261$(_actions_0)), {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": _readers_0, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _actions_0})));
}

function $$$$047$$$047$$$047application$058ready$1261$(_actions_0, _env_0) {
  if (_actions_0.$ === "Nil") {
    return true;
  } else {
    const _head_0 = _actions_0["head"];
    const _rest_0 = _actions_0["tail"];
    return $Bool$and$(($$$$047$$$047$$$047application$058action_ready$1261$(_head_0, _env_0)), ($$$$047$$$047$$$047application$058ready$1261$(_rest_0, _env_0)));
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_meta$1265$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "public-cleanup-v1/current-core/ecs/world.RegistrationRejected") {
    return {$: "public-cleanup-v1/current-core/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "public-cleanup-v1/current-core/ecs/system.Registered", "world": _world_0, "registry": {$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $caller$045core$058a_cleaned$1261$(_ao_0, _ar_0, _b_0, _bReader_0, _rows_0, _result_0) {
  const _bo_0 = _b_0["owners"];
  const _bw_0 = _b_0["world"];
  const _br_0 = _b_0["rows"];
  if (_result_0.$ === "caller-core.Cleaned") {
    const _world_0 = _result_0["world"];
    return $caller$045core$058survivor$1261$(($$$$047$$$047observations$058checkpoint$1261$("A-owned-cleanup", _ar_0, {$: "../../../application.FrameResult", "owners": _ao_0, "world": _world_0, "status": "cleaned"})), _bo_0, _br_0, ($List$append$(_rows_0, {$: "Con", "head": "A-owned-cleanup|A=disposed", "tail": {$: "Nil"}})), _bReader_0, _bw_0);
  } else {
    const _world_1 = _result_0["world"];
    return $caller$045core$058finish_pair$1261$(($$$$047$$$047observations$058checkpoint$1261$("A-cleanup-rejected", _ar_0, {$: "../../../application.FrameResult", "owners": _ao_0, "world": _world_1, "status": "cleanup-rejected"})), {$: "../../observations.Observed", "owners": _bo_0, "world": _bw_0, "rows": _br_0}, ($List$append$(_rows_0, {$: "Con", "head": "A-cleanup-rejected", "tail": {$: "Nil"}})));
  }
}

function $caller$045core$058dispose_streams$1261$(_world_0, _flowId_0, _levelId_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _fs_0 = _t_0["flowStream"];
  const _ls_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _trace_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058dispose$1260$(_fs_0, _flowId_0)), "levelStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058dispose$1261$(_ls_0, _levelId_0)), "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "events": _events_0, "pending": _commands_0, "registrations": _regs_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058dispose_returned$1261$(_registry_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0) {
    return {$: "public-cleanup-v1/current-core/ecs/system.Disposed", "world": _world_0};
  } else {
    return {$: "public-cleanup-v1/current-core/ecs/system.DisposalRejected", "world": _world_0, "registry": _registry_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047registration$058remove$1261$(_world_0, _namespace_0, _id_0, _name_0, _access_0) {
  const _actual_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047registration$058remove_checked$1261$(($Bool$and$((_namespace_0 === _actual_0), ($public$045cleanup$045v1$047current$045core$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0)))), {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _actual_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _id_0, _name_0, _access_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace$1264$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_value$1264$(_registry_0, _world_0, _actual_0, _args_0);
}

function $List$show$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047application$058action_view$1260$(_h_0));
    const _x_1 = ($List$show$go$1265$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047observations$058user_catalog$1260$(_pair_0) {
  const _entries_0 = _pair_0["fst"];
  const _rows_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../catalog.Catalog", "entries": _entries_0}, "snd": ($List$show$1261$(_rows_0))};
}

function $$$$047$$$047observations$058users$1260$(_entries_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _entries_0["head"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047observations$058users_join$1260$(($$$$047$$$047observations$058user_entry$1260$(_head_0)), ($$$$047$$$047observations$058users$1260$(_rest_0)));
  }
}

function $$$$047$$$047observations$058hook_join$1260$(_a_0, _b_0) {
  const _flow_0 = _a_0["fst"];
  const _a_1 = _a_0["snd"];
  const _level_0 = _b_0["fst"];
  const _b_1 = _b_0["snd"];
  const _x_0 = ("|" + _b_1);
  return {$: "Tuple", "fst": {$: "../../../hooks.Owners", "flow": _flow_0, "level": _level_0}, "snd": (_a_1 + _x_0)};
}

function $$$$047$$$047observations$058hook_registry$1260$(_value_0) {
  const _ns_0 = _value_0["namespace"];
  const _id_0 = _value_0["id"];
  const _name_0 = _value_0["name"];
  const _access_0 = _value_0["access"];
  const _cursor_0 = _value_0["cursor"];
  const _x_0 = ($U32$show$(_cursor_0));
  const _x_1 = ($List$show$1261$(_access_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":" + _x_3);
  const _x_5 = (_name_0 + _x_4);
  const _x_6 = ($U32$show$(_id_0));
  const _x_7 = (":" + _x_5);
  const _x_8 = (_x_6 + _x_7);
  const _x_9 = ($U32$show$(_ns_0));
  const _x_10 = (":" + _x_8);
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": (_x_9 + _x_10)};
}

function $$$$047$$$047observations$058readers_join$1260$(_head_0, _rest_0) {
  const _entry_0 = _head_0["fst"];
  const _text_0 = _head_0["snd"];
  const _rest_1 = _rest_0["fst"];
  const _rows_0 = _rest_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _entry_0, "tail": _rest_1}, "snd": {$: "Con", "head": _text_0, "tail": _rows_0}};
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $List$show$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047observe$058bool$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1267$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047observe$058registration$(_h_0));
    const _x_1 = ($List$show$go$1267$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$length$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = _xs_0["tail"];
    return nat_chk(($List$length$(_t_0)) + 1);
  }
}

function $$$$047$$$047$$$047observe$058live_join$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ($List$append$(_a_0, _b_0))};
}

function $$$$047$$$047$$$047observe$058store_join$1260$(_pair_0) {
  const _column_0 = _pair_0["fst"];
  const _view_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../provider.Store", "cells": _column_0}, "snd": _view_0};
}

function $$$$047$$$047$$$047observe$058column_view$1260$(_column_0) {
  if (_column_0.$ === "../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047observe$058column_join$1260$(($$$$047$$$047$$$047observe$058cells_view$(_values_0)), _stamps_0);
  } else {
    return {$: "Tuple", "fst": _column_0, "snd": "UNSUPPORTED_COLUMN_ROUTE"};
  }
}

function $$$$047$$$047$$$047observe$058resources_join$1260$(_pair_0, _a_0, _b_0, _flowStream_0, _levelStream_0, _frame_0, _tick_0, _trace_0) {
  const _owned_0 = _pair_0["fst"];
  const _view_0 = _pair_0["snd"];
  const _x_0 = ($List$show$1261$(_trace_0));
  const _x_1 = ($Nat$show$(_tick_0));
  const _x_2 = (";hooks=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($Nat$show$(_frame_0));
  const _x_5 = (";tick=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($$$$047$$$047$$$047observe$058stream$1261$(_levelStream_0));
  const _x_8 = (";frame=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($$$$047$$$047$$$047observe$058stream$1260$(_flowStream_0));
  const _x_11 = (";levelStream=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($$$$047$$$047$$$047observe$058slot$1261$(_b_0));
  const _x_14 = (";flowStream=" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($$$$047$$$047$$$047observe$058slot$1260$(_a_0));
  const _x_17 = (";level=" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = (";flow=" + _x_18);
  const _x_20 = (_view_0 + _x_19);
  return {$: "Tuple", "fst": {$: "../../../provider.Resources", "owned": _owned_0, "flow": _a_0, "level": _b_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "snd": ("owned=" + _x_20)};
}

function $$$$047$$$047$$$047observe$058owner_view$(_owner_0) {
  return $$$$047$$$047$$$047observe$058owner_view_join$(($$$$047$$$047$$$047provider$058array_view$(_owner_0)));
}

function $$$$047$$$047$$$047observe$058queue_join$1260$(_command_0, _pair_0) {
  const _rest_0 = _pair_0["fst"];
  const _count_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _rest_0}, "snd": nat_chk(_count_0 + 1)};
}

function $$$$047$$$047$$$047application$058built$1260$(_world_0, _result_0) {
  if (_result_0.$ === "../../../../../src/ecs/schedule.Invalid") {
    const _owners_0 = _result_0["owners"];
    return {$: "../../../application.FrameResult", "owners": _owners_0, "world": _world_0, "status": "invalid-schedule"};
  } else {
    const _schedule_0 = _result_0["schedule"];
    return $$$$047$$$047$$$047application$058schedule_returned$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run$1260$(_schedule_0, _world_0)));
  }
}

function $$$$047$$$047$$$047provider$058frame$1260$(_world_0) {
  return $$$$047$$$047$$$047provider$058map_resources$1260$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047provider$058frame_resources$1260$(_x_0);
}), _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058build$1260$(_namespace_0, _name_0, _steps_0, _catalog_0, _owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058build_checked$1260$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058valid$(_steps_0, _catalog_0, {$: "Nil"})), _namespace_0, _name_0, _steps_0, _owners_0);
}

function $$$$047$$$047$$$047application$058steps$1260$(_actions_0) {
  if (_actions_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _actions_0["head"];
    const _rest_0 = _actions_0["tail"];
    return {$: "Con", "head": {$: "../../../../../src/ecs/schedule.System", "id": ($$$$047$$$047$$$047application$058action_id$1260$(_head_0)), "condition": 0}, "tail": ($$$$047$$$047$$$047application$058steps$1260$(_rest_0))};
  }
}

function $$$$047$$$047$$$047application$058ids$1260$(_actions_0) {
  if (_actions_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _actions_0["head"];
    const _rest_0 = _actions_0["tail"];
    return {$: "Con", "head": ($$$$047$$$047$$$047application$058action_id$1260$(_head_0)), "tail": ($$$$047$$$047$$$047application$058ids$1260$(_rest_0))};
  }
}

function $$$$047$$$047$$$047application$058action_ready$1260$(_action_0, _env_0) {
  if (_action_0.$ === "../../../application.Body") {
    const _t_0 = _action_0["operation"];
    if (_t_0.$ === "../../../gameplay.Seed") {
      return true;
    } else {
      return $$$$047$$$047$$$047application$058slots_present$1260$(_env_0);
    }
  } else if (_action_0.$ === "../../../application.Marker") {
    const _t_1 = _action_0["enabled"];
    if (!_t_1) {
      return true;
    } else {
      return $$$$047$$$047$$$047application$058slots_present$1260$(_env_0);
    }
  } else if (_action_0.$ === "../../../application.Deferred") {
    return true;
  } else if (_action_0.$ === "../../../application.Read") {
    return $$$$047$$$047$$$047application$058slots_present$1260$(_env_0);
  } else if (_action_0.$ === "../../../application.GatedRead") {
    return $$$$047$$$047$$$047application$058slots_present$1260$(_env_0);
  } else {
    const _tree_0 = _action_0["condition"];
    return $$$$047$$$047$$$047provider$058condition_provisioned$1260$(($$$$047$$$047$$$047provider$058condition_needs$1260$(_tree_0)), _env_0);
  }
}

function $caller$045core$058survivor$1260$(_a_0, _bo_0, _br_0, _rows_0, _bReader_0, _bw_0) {
  return $caller$045core$058survivor_returned$1260$(_a_0, _bo_0, _br_0, _rows_0, ($$$$047$$$047$$$047readers$058invoke$1260$(_bReader_0, _bw_0, false)));
}

function $caller$045core$058finish_pair$1260$(_a_0, _b_0, _rows_0) {
  const _x_0 = ($String$join$(_rows_0, "\n"));
  const _x_1 = ($$$$047$$$047observations$058finish$1260$(_b_0));
  const _x_2 = ("\nINSTANCES\n" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($$$$047$$$047observations$058finish$1260$(_a_0));
  const _x_5 = ("\nWORLD=B\n" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  return ("WORLD=A\n" + _x_6);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058dispose$1260$(_stream_0, _id_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return {$: "public-cleanup-v1/current-core/ecs/machine-stream.Stream", "batches": _batches_0, "positions": ($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058update$(_positions_0, _id_0, 0, true)), "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058dispose$1261$(_stream_0, _id_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return {$: "public-cleanup-v1/current-core/ecs/machine-stream.Stream", "batches": _batches_0, "positions": ($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058update$(_positions_0, _id_0, 0, true)), "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047registration$058remove_checked$1260$(_allowed_0, _world_0, _id_0, _name_0, _access_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": ($public$045cleanup$045v1$047current$045core$047ecs$047registration$058without$(_registrations_0, _id_0, _name_0, _access_0)), "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": true};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $List$show$go$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1264$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return (", " + _x_1);
  }
}

function $List$show$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047observe$058transition$1260$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047observe$058transition$1261$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047observe$058bool$(_value_0) {
  if (_value_0) {
    return "true";
  } else {
    return "false";
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_checked$1261$((_namespace_0 === _actual_0), {$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $$$$047$$$047$$$047observe$058text$(_value_0) {
  return _value_0;
}

function $List$show$go$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047observe$058text$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $List$show$12614$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047application$058action_view$1261$(_h_0));
    const _x_1 = ($List$show$go$12614$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047observations$058user_catalog$1261$(_pair_0) {
  const _entries_0 = _pair_0["fst"];
  const _rows_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../catalog.Catalog", "entries": _entries_0}, "snd": ($List$show$1261$(_rows_0))};
}

function $$$$047$$$047observations$058users$1261$(_entries_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _entries_0["head"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047observations$058users_join$1261$(($$$$047$$$047observations$058user_entry$1261$(_head_0)), ($$$$047$$$047observations$058users$1261$(_rest_0)));
  }
}

function $$$$047$$$047observations$058hook_join$1261$(_a_0, _b_0) {
  const _flow_0 = _a_0["fst"];
  const _a_1 = _a_0["snd"];
  const _level_0 = _b_0["fst"];
  const _b_1 = _b_0["snd"];
  const _x_0 = ("|" + _b_1);
  return {$: "Tuple", "fst": {$: "../../../hooks.Owners", "flow": _flow_0, "level": _level_0}, "snd": (_a_1 + _x_0)};
}

function $$$$047$$$047observations$058hook_registry$1261$(_value_0) {
  const _ns_0 = _value_0["namespace"];
  const _id_0 = _value_0["id"];
  const _name_0 = _value_0["name"];
  const _access_0 = _value_0["access"];
  const _cursor_0 = _value_0["cursor"];
  const _x_0 = ($U32$show$(_cursor_0));
  const _x_1 = ($List$show$1261$(_access_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":" + _x_3);
  const _x_5 = (_name_0 + _x_4);
  const _x_6 = ($U32$show$(_id_0));
  const _x_7 = (":" + _x_5);
  const _x_8 = (_x_6 + _x_7);
  const _x_9 = ($U32$show$(_ns_0));
  const _x_10 = (":" + _x_8);
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": (_x_9 + _x_10)};
}

function $$$$047$$$047observations$058readers_join$1261$(_head_0, _rest_0) {
  const _entry_0 = _head_0["fst"];
  const _text_0 = _head_0["snd"];
  const _rest_1 = _rest_0["fst"];
  const _rows_0 = _rest_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _entry_0, "tail": _rest_1}, "snd": {$: "Con", "head": _text_0, "tail": _rows_0}};
}

function $$$$047$$$047$$$047observe$058store_join$1261$(_pair_0) {
  const _column_0 = _pair_0["fst"];
  const _view_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../provider.Store", "cells": _column_0}, "snd": _view_0};
}

function $$$$047$$$047$$$047observe$058column_view$1261$(_column_0) {
  if (_column_0.$ === "../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047observe$058column_join$1261$(($$$$047$$$047$$$047observe$058cells_view$(_values_0)), _stamps_0);
  } else {
    return {$: "Tuple", "fst": _column_0, "snd": "UNSUPPORTED_COLUMN_ROUTE"};
  }
}

function $$$$047$$$047$$$047observe$058resources_join$1261$(_pair_0, _a_0, _b_0, _flowStream_0, _levelStream_0, _frame_0, _tick_0, _trace_0) {
  const _owned_0 = _pair_0["fst"];
  const _view_0 = _pair_0["snd"];
  const _x_0 = ($List$show$1261$(_trace_0));
  const _x_1 = ($Nat$show$(_tick_0));
  const _x_2 = (";hooks=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($Nat$show$(_frame_0));
  const _x_5 = (";tick=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($$$$047$$$047$$$047observe$058stream$1261$(_levelStream_0));
  const _x_8 = (";frame=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($$$$047$$$047$$$047observe$058stream$1260$(_flowStream_0));
  const _x_11 = (";levelStream=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($$$$047$$$047$$$047observe$058slot$1263$(_b_0));
  const _x_14 = (";flowStream=" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($$$$047$$$047$$$047observe$058slot$1262$(_a_0));
  const _x_17 = (";level=" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = (";flow=" + _x_18);
  const _x_20 = (_view_0 + _x_19);
  return {$: "Tuple", "fst": {$: "../../../provider.Resources", "owned": _owned_0, "flow": _a_0, "level": _b_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "snd": ("owned=" + _x_20)};
}

function $$$$047$$$047$$$047observe$058queue_join$1261$(_command_0, _pair_0) {
  const _rest_0 = _pair_0["fst"];
  const _count_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _rest_0}, "snd": nat_chk(_count_0 + 1)};
}

function $$$$047$$$047$$$047application$058built$1261$(_world_0, _result_0) {
  if (_result_0.$ === "../../../../../src/ecs/schedule.Invalid") {
    const _owners_0 = _result_0["owners"];
    return {$: "../../../application.FrameResult", "owners": _owners_0, "world": _world_0, "status": "invalid-schedule"};
  } else {
    const _schedule_0 = _result_0["schedule"];
    return $$$$047$$$047$$$047application$058schedule_returned$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run$1261$(_schedule_0, _world_0)));
  }
}

function $$$$047$$$047$$$047provider$058frame$1261$(_world_0) {
  return $$$$047$$$047$$$047provider$058map_resources$1261$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047provider$058frame_resources$1261$(_x_0);
}), _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058build$1261$(_namespace_0, _name_0, _steps_0, _catalog_0, _owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058build_checked$1261$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058valid$(_steps_0, _catalog_0, {$: "Nil"})), _namespace_0, _name_0, _steps_0, _owners_0);
}

function $$$$047$$$047$$$047application$058steps$1261$(_actions_0) {
  if (_actions_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _actions_0["head"];
    const _rest_0 = _actions_0["tail"];
    return {$: "Con", "head": {$: "../../../../../src/ecs/schedule.System", "id": ($$$$047$$$047$$$047application$058action_id$1261$(_head_0)), "condition": 0}, "tail": ($$$$047$$$047$$$047application$058steps$1261$(_rest_0))};
  }
}

function $$$$047$$$047$$$047application$058ids$1261$(_actions_0) {
  if (_actions_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _actions_0["head"];
    const _rest_0 = _actions_0["tail"];
    return {$: "Con", "head": ($$$$047$$$047$$$047application$058action_id$1261$(_head_0)), "tail": ($$$$047$$$047$$$047application$058ids$1261$(_rest_0))};
  }
}

function $$$$047$$$047$$$047application$058action_ready$1261$(_action_0, _env_0) {
  if (_action_0.$ === "../../../application.Body") {
    const _t_0 = _action_0["operation"];
    if (_t_0.$ === "../../../gameplay.Seed") {
      return true;
    } else {
      return $$$$047$$$047$$$047application$058slots_present$1261$(_env_0);
    }
  } else if (_action_0.$ === "../../../application.Marker") {
    const _t_1 = _action_0["enabled"];
    if (!_t_1) {
      return true;
    } else {
      return $$$$047$$$047$$$047application$058slots_present$1261$(_env_0);
    }
  } else if (_action_0.$ === "../../../application.Deferred") {
    return true;
  } else if (_action_0.$ === "../../../application.Read") {
    return $$$$047$$$047$$$047application$058slots_present$1261$(_env_0);
  } else if (_action_0.$ === "../../../application.GatedRead") {
    return $$$$047$$$047$$$047application$058slots_present$1261$(_env_0);
  } else {
    const _tree_0 = _action_0["condition"];
    return $$$$047$$$047$$$047provider$058condition_provisioned$1261$(($$$$047$$$047$$$047provider$058condition_needs$1261$(_tree_0)), _env_0);
  }
}

function $caller$045core$058survivor$1261$(_a_0, _bo_0, _br_0, _rows_0, _bReader_0, _bw_0) {
  return $caller$045core$058survivor_returned$1261$(_a_0, _bo_0, _br_0, _rows_0, ($$$$047$$$047$$$047readers$058invoke$1261$(_bReader_0, _bw_0, false)));
}

function $caller$045core$058finish_pair$1261$(_a_0, _b_0, _rows_0) {
  const _x_0 = ($String$join$(_rows_0, "\n"));
  const _x_1 = ($$$$047$$$047observations$058finish$1261$(_b_0));
  const _x_2 = ("\nINSTANCES\n" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($$$$047$$$047observations$058finish$1261$(_a_0));
  const _x_5 = ("\nWORLD=B\n" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  return ("WORLD=A\n" + _x_6);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047registration$058remove_checked$1261$(_allowed_0, _world_0, _id_0, _name_0, _access_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": ($public$045cleanup$045v1$047current$045core$047ecs$047registration$058without$(_registrations_0, _id_0, _name_0, _access_0)), "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": true};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_value$1264$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_checked$1264$((_namespace_0 === _actual_0), {$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047application$058action_view$1260$(_action_0) {
  if (_action_0.$ === "../../../application.Body") {
    const _key_0 = _action_0["key"];
    const _name_0 = _action_0["name"];
    const _operation_0 = _action_0["operation"];
    const _x_0 = ($$$$047$$$047$$$047application$058operation_view$(_operation_0));
    const _x_1 = (":" + _x_0);
    const _x_2 = (_name_0 + _x_1);
    const _x_3 = ($U32$show$(_key_0));
    const _x_4 = (":" + _x_2);
    const _x_5 = (_x_3 + _x_4);
    return ("Body:" + _x_5);
  } else if (_action_0.$ === "../../../application.Marker") {
    const _value_0 = _action_0["enabled"];
    const _x_6 = ($$$$047$$$047$$$047observe$058bool$(_value_0));
    return ("Marker:" + _x_6);
  } else if (_action_0.$ === "../../../application.Deferred") {
    return "Deferred";
  } else if (_action_0.$ === "../../../application.Read") {
    const _key_1 = _action_0["key"];
    const _name_1 = _action_0["name"];
    const _fails_0 = _action_0["fails"];
    const _x_7 = ($$$$047$$$047$$$047observe$058bool$(_fails_0));
    const _x_8 = (":" + _x_7);
    const _x_9 = (_name_1 + _x_8);
    const _x_10 = ($U32$show$(_key_1));
    const _x_11 = (":" + _x_9);
    const _x_12 = (_x_10 + _x_11);
    return ("Read:" + _x_12);
  } else if (_action_0.$ === "../../../application.GatedRead") {
    const _key_2 = _action_0["key"];
    const _name_2 = _action_0["name"];
    const _tree_0 = _action_0["condition"];
    const _x_13 = ($$$$047$$$047$$$047application$058condition_view$1260$(_tree_0));
    const _x_14 = (":" + _x_13);
    const _x_15 = (_name_2 + _x_14);
    const _x_16 = ($U32$show$(_key_2));
    const _x_17 = (":" + _x_15);
    const _x_18 = (_x_16 + _x_17);
    return ("GatedRead:" + _x_18);
  } else {
    const _key_3 = _action_0["key"];
    const _name_3 = _action_0["name"];
    const _tree_1 = _action_0["condition"];
    const _x_19 = ($$$$047$$$047$$$047application$058condition_view$1260$(_tree_1));
    const _x_20 = (":" + _x_19);
    const _x_21 = (_name_3 + _x_20);
    const _x_22 = ($U32$show$(_key_3));
    const _x_23 = (":" + _x_21);
    const _x_24 = (_x_22 + _x_23);
    return ("Gate:" + _x_24);
  }
}

function $List$show$go$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047application$058action_view$1260$(_h_0));
    const _x_1 = ($List$show$go$1265$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047observations$058users_join$1260$(_head_0, _rest_0) {
  const _entry_0 = _head_0["fst"];
  const _text_0 = _head_0["snd"];
  const _rest_1 = _rest_0["fst"];
  const _rows_0 = _rest_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _entry_0, "tail": _rest_1}, "snd": {$: "Con", "head": _text_0, "tail": _rows_0}};
}

function $$$$047$$$047observations$058user_entry$1260$(_entry_0) {
  const _key_0 = _entry_0["key"];
  const _t_0 = _entry_0["registry"];
  const _ns_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _name_0 = _t_0["name"];
  const _access_0 = _t_0["access"];
  const _cursor_0 = _t_0["cursor"];
  const _x_0 = ($U32$show$(_cursor_0));
  const _x_1 = ($List$show$1261$(_access_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":" + _x_3);
  const _x_5 = (_name_0 + _x_4);
  const _x_6 = ($U32$show$(_id_0));
  const _x_7 = (":" + _x_5);
  const _x_8 = (_x_6 + _x_7);
  const _x_9 = ($U32$show$(_ns_0));
  const _x_10 = (":" + _x_8);
  const _x_11 = (_x_9 + _x_10);
  const _x_12 = ($U32$show$(_key_0));
  const _x_13 = (":" + _x_11);
  return {$: "Tuple", "fst": {$: "../../../catalog.Entry", "key": _key_0, "registry": {$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}}, "snd": (_x_12 + _x_13)};
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $List$show$go$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047observe$058bool$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047observe$058registration$(_value_0) {
  const _id_0 = _value_0["id"];
  const _name_0 = _value_0["name"];
  const _access_0 = _value_0["access"];
  const _x_0 = ($List$show$1261$(_access_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_name_0 + _x_1);
  const _x_3 = ($U32$show$(_id_0));
  const _x_4 = (":" + _x_2);
  return (_x_3 + _x_4);
}

function $List$show$go$1267$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047observe$058registration$(_h_0));
    const _x_1 = ($List$show$go$1267$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047observe$058column_join$1260$(_pair_0, _stamps_0) {
  const _values_0 = _pair_0["fst"];
  const _views_0 = _pair_0["snd"];
  const _x_0 = ($List$show$1268$(_stamps_0));
  const _x_1 = ($List$show$1261$(_views_0));
  const _x_2 = (":stamps=" + _x_0);
  return {$: "Tuple", "fst": {$: "../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": (_x_1 + _x_2)};
}

function $$$$047$$$047$$$047observe$058cells_view$(_values_0) {
  if (_values_0.length === 1) {
    const _owner_0 = _values_0[0];
    return $$$$047$$$047$$$047observe$058cells_leaf$(($$$$047$$$047$$$047observe$058cell_view$(_owner_0)));
  } else {
    const _left_0 = _values_0.slice(0, _values_0.length >> 1);
    const _right_0 = _values_0.slice(_values_0.length >> 1);
    return $$$$047$$$047$$$047observe$058cells_join$(($$$$047$$$047$$$047observe$058cells_view$(_left_0)), ($$$$047$$$047$$$047observe$058cells_view$(_right_0)));
  }
}

function $$$$047$$$047$$$047observe$058slot$1260$(_value_0) {
  if (_value_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _last_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($$$$047$$$047$$$047observe$058bool$(_changed_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($$$$047$$$047$$$047observe$058previous$1260$(_last_0));
    const _x_3 = (",changed=" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($$$$047$$$047$$$047observe$058pending$1260$(_next_0));
    const _x_6 = (",previous=" + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($$$$047$$$047$$$047observe$058flow$(_current_0));
    const _x_9 = ("(pending=" + _x_7);
    return (_x_8 + _x_9);
  }
}

function $$$$047$$$047$$$047observe$058slot$1261$(_value_0) {
  if (_value_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _last_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($$$$047$$$047$$$047observe$058bool$(_changed_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($$$$047$$$047$$$047observe$058previous$1261$(_last_0));
    const _x_3 = (",changed=" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($$$$047$$$047$$$047observe$058pending$1261$(_next_0));
    const _x_6 = (",previous=" + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($$$$047$$$047$$$047observe$058level$(_current_0));
    const _x_9 = ("(pending=" + _x_7);
    return (_x_8 + _x_9);
  }
}

function $$$$047$$$047$$$047observe$058stream$1260$(_value_0) {
  const _batches_0 = _value_0["batches"];
  const _positions_0 = _value_0["positions"];
  const _dropped_0 = _value_0["droppedThrough"];
  const _frameStart_0 = _value_0["frameStart"];
  const _x_0 = ($Nat$show$(_frameStart_0));
  const _x_1 = ($Nat$show$(_dropped_0));
  const _x_2 = (",frameStart=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($List$show$12611$(_positions_0));
  const _x_5 = (",dropped=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($List$show$1269$(_batches_0));
  const _x_8 = (",positions=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  return ("batches=" + _x_9);
}

function $$$$047$$$047$$$047observe$058stream$1261$(_value_0) {
  const _batches_0 = _value_0["batches"];
  const _positions_0 = _value_0["positions"];
  const _dropped_0 = _value_0["droppedThrough"];
  const _frameStart_0 = _value_0["frameStart"];
  const _x_0 = ($Nat$show$(_frameStart_0));
  const _x_1 = ($Nat$show$(_dropped_0));
  const _x_2 = (",frameStart=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($List$show$12611$(_positions_0));
  const _x_5 = (",dropped=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($List$show$12612$(_batches_0));
  const _x_8 = (",positions=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  return ("batches=" + _x_9);
}

function $$$$047$$$047$$$047observe$058owner_view_join$(_pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _values_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": ($List$show$1260$(_values_0))};
}

function $$$$047$$$047$$$047provider$058array_view$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return {$: "Tuple", "fst": [_value_0], "snd": {$: "Con", "head": _value_0, "tail": {$: "Nil"}}};
  } else {
    const _left_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _right_0 = _owner_0.slice(_owner_0.length >> 1);
    return $$$$047$$$047$$$047provider$058array_join$(($$$$047$$$047$$$047provider$058array_view$(_left_0)), ($$$$047$$$047$$$047provider$058array_view$(_right_0)));
  }
}

function $$$$047$$$047$$$047application$058schedule_returned$1260$(_result_0) {
  if (_result_0.$ === "../../../../../src/ecs/schedule.Finished") {
    const _t_0 = _result_0["schedule"];
    const _owners_0 = _t_0["owners"];
    const _world_0 = _result_0["world"];
    return {$: "../../../application.FrameResult", "owners": _owners_0, "world": _world_0, "status": "ok"};
  } else if (_result_0.$ === "../../../../../src/ecs/schedule.Failed") {
    const _t_1 = _result_0["schedule"];
    const _owners_1 = _t_1["owners"];
    const _world_1 = _result_0["world"];
    const _error_0 = _result_0["error"];
    return {$: "../../../application.FrameResult", "owners": _owners_1, "world": _world_1, "status": ("failed:" + _error_0)};
  } else {
    const _t_2 = _result_0["schedule"];
    const _owners_2 = _t_2["owners"];
    const _world_2 = _result_0["world"];
    return {$: "../../../application.FrameResult", "owners": _owners_2, "world": _world_2, "status": "schedule-namespace-rejected"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run$1260$(_schedule_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_namespace$1260$(_schedule_0, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058namespace$1260$(_world_0)));
}

function $$$$047$$$047$$$047provider$058map_resources$1260$(_effect_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _effect_0(_resources_0), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047provider$058frame_resources$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "../../../provider.Resources", "owned": _owned_0, "flow": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058clear_changed$1260$(_flow_0)), "level": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058clear_changed$1261$(_level_0)), "flowStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058frame$1260$(_flowStream_0, _tick_0)), "levelStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058frame$1261$(_levelStream_0, _tick_0)), "frame": nat_chk(_frame_0 + 1), "tick": _tick_0, "trace": _trace_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058build_checked$1260$(_allowed_0, _namespace_0, _name_0, _steps_0, _owners_0) {
  if (!_allowed_0) {
    return {$: "../../../../../src/ecs/schedule.Invalid", "owners": _owners_0};
  } else {
    return {$: "../../../../../src/ecs/schedule.Built", "schedule": {$: "../../../../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058valid$($0, $1, $2) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _catalog_0 = $1;
      const _seen_0 = $2;
      if (_steps_0.$ === "Nil") {
        return true;
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../../../../../src/ecs/schedule.Phase") {
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _catalog_0;
          $2 = _seen_0;
          continue;
        } else if (_t_0.$ === "../../../../../src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _catalog_0;
          $2 = _seen_0;
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _rest_2 = _steps_0["tail"];
          return $Bool$and$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058contains$(_catalog_0, _id_0)), ($Bool$and$(($Bool$not$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058contains$(_seen_0, _id_0)))), ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058valid$(_rest_2, _catalog_0, {$: "Con", "head": _id_0, "tail": _seen_0})))));
        }
      }
    }
  }
}

function $$$$047$$$047$$$047application$058action_id$1260$(_action_0) {
  if (_action_0.$ === "../../../application.Body") {
    const _key_0 = _action_0["key"];
    return _key_0;
  } else if (_action_0.$ === "../../../application.Read") {
    const _key_1 = _action_0["key"];
    return _key_1;
  } else if (_action_0.$ === "../../../application.GatedRead") {
    const _key_2 = _action_0["key"];
    return _key_2;
  } else if (_action_0.$ === "../../../application.Gate") {
    const _key_3 = _action_0["key"];
    return _key_3;
  } else if (_action_0.$ === "../../../application.Marker") {
    return 100;
  } else {
    return 101;
  }
}

function $$$$047$$$047$$$047application$058slots_present$1260$(_env_0) {
  const _flow_0 = _env_0["flow"];
  const _level_0 = _env_0["level"];
  return $Bool$and$(($$$$047$$$047$$$047provider$058slot_present$1260$(_flow_0)), ($$$$047$$$047$$$047provider$058slot_present$1261$(_level_0)));
}

function $$$$047$$$047$$$047provider$058condition_provisioned$1260$(_needs_0, _env_0) {
  if (_needs_0.$ === "Nil") {
    return true;
  } else {
    const _t_0 = _needs_0["head"];
    if (_t_0 == 1) {
      const _rest_0 = _needs_0["tail"];
      const _flow_0 = _env_0["flow"];
      const _level_0 = _env_0["level"];
      return $Bool$and$(($$$$047$$$047$$$047provider$058slot_present$1260$(_flow_0)), ($$$$047$$$047$$$047provider$058condition_provisioned$1260$(_rest_0, {$: "../../../provider.ConditionEnv", "flow": _flow_0, "level": _level_0})));
    } else if ((_t_0 & 1) == 1) {
      return false;
    } else if (_t_0 == 2) {
      const _rest_2 = _needs_0["tail"];
      const _flow_1 = _env_0["flow"];
      const _level_1 = _env_0["level"];
      return $Bool$and$(($$$$047$$$047$$$047provider$058slot_present$1261$(_level_1)), ($$$$047$$$047$$$047provider$058condition_provisioned$1260$(_rest_2, {$: "../../../provider.ConditionEnv", "flow": _flow_1, "level": _level_1})));
    } else {
      return false;
    }
  }
}

function $$$$047$$$047$$$047provider$058condition_needs$1260$($0) {
  for (;;) {
    {
      const _tree_0 = $0;
      if (_tree_0.$ === "../../../conditions.Leaf") {
        const _atom_0 = _tree_0["atom"];
        return $$$$047$$$047$$$047provider$058atom_needs$1260$(_atom_0);
      } else if (_tree_0.$ === "../../../conditions.Constant") {
        return {$: "Nil"};
      } else if (_tree_0.$ === "../../../conditions.Negate") {
        const _inner_0 = _tree_0["inner"];
        $0 = _inner_0;
        continue;
      } else if (_tree_0.$ === "../../../conditions.Both") {
        const _left_0 = _tree_0["left"];
        const _right_0 = _tree_0["right"];
        return $List$append$(($$$$047$$$047$$$047provider$058condition_needs$1260$(_left_0)), ($$$$047$$$047$$$047provider$058condition_needs$1260$(_right_0)));
      } else {
        const _left_1 = _tree_0["left"];
        const _right_1 = _tree_0["right"];
        return $List$append$(($$$$047$$$047$$$047provider$058condition_needs$1260$(_left_1)), ($$$$047$$$047$$$047provider$058condition_needs$1260$(_right_1)));
      }
    }
  }
}

function $caller$045core$058survivor_returned$1260$(_a_0, _bo_0, _br_0, _rows_0, _result_0) {
  const _ao_0 = _a_0["owners"];
  const _aw_0 = _a_0["world"];
  const _ar_0 = _a_0["rows"];
  const _bReader_0 = _result_0["instance"];
  const _bw_0 = _result_0["world"];
  const _delivery_0 = _result_0["delivery"];
  const _status_0 = _result_0["status"];
  const _x_0 = ($caller$045core$058delivery_view$(_delivery_0));
  return $caller$045core$058survivor_observed$1260$(($$$$047$$$047observations$058checkpoint$1260$("B-survivor-empty", _ar_0, {$: "../../../application.FrameResult", "owners": _ao_0, "world": _aw_0, "status": _status_0})), ($$$$047$$$047observations$058checkpoint$1260$("B-survivor-empty", _br_0, {$: "../../../application.FrameResult", "owners": _bo_0, "world": _bw_0, "status": _status_0})), _bReader_0, ($List$append$(_rows_0, {$: "Con", "head": ("B-survivor-delivery=" + _x_0), "tail": {$: "Nil"}})));
}

function $$$$047$$$047observations$058finish$1260$(_value_0) {
  const _rows_0 = _value_0["rows"];
  return $String$join$(_rows_0, "\n");
}

function $String$join$(_xs_0, _sep_0) {
  if (_xs_0.$ === "Nil") {
    return "";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return $String$join$go$(_t_0, _h_0, _sep_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _cursor_0, _dispose_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _positions_0["head"];
    const _actual_0 = _t_0["id"];
    const _old_0 = _t_0["cursor"];
    const _registered_0 = _t_0["registeredAt"];
    const _rest_0 = _positions_0["tail"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058update_checked$((_actual_0 === _id_0), _dispose_0, _actual_0, _old_0, _registered_0, ($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058update$(_rest_0, _id_0, _cursor_0, _dispose_0)), _cursor_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047registration$058without$(_registrations_0, _id_0, _name_0, _access_0) {
  if (_registrations_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _meta_0 = _registrations_0["head"];
    const _rest_0 = _registrations_0["tail"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047registration$058retained$(($Bool$not$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0)))), _meta_0, ($public$045cleanup$045v1$047current$045core$047ecs$047registration$058without$(_rest_0, _id_0, _name_0, _access_0)));
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($public$045cleanup$045v1$047current$045core$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047observe$058transition$1260$(_value_0) {
  const _from_0 = _value_0["from"];
  const _to_0 = _value_0["to"];
  const _x_0 = ($$$$047$$$047$$$047observe$058flow$(_to_0));
  const _x_1 = ($$$$047$$$047$$$047observe$058flow$(_from_0));
  const _x_2 = (">" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047observe$058transition$1260$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047observe$058transition$1261$(_value_0) {
  const _from_0 = _value_0["from"];
  const _to_0 = _value_0["to"];
  const _x_0 = ($$$$047$$$047$$$047observe$058level$(_to_0));
  const _x_1 = ($$$$047$$$047$$$047observe$058level$(_from_0));
  const _x_2 = (">" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047observe$058transition$1261$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "public-cleanup-v1/current-core/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_metadata$1261$({$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047$$$047application$058action_view$1261$(_action_0) {
  if (_action_0.$ === "../../../application.Body") {
    const _key_0 = _action_0["key"];
    const _name_0 = _action_0["name"];
    const _operation_0 = _action_0["operation"];
    const _x_0 = ($$$$047$$$047$$$047application$058operation_view$(_operation_0));
    const _x_1 = (":" + _x_0);
    const _x_2 = (_name_0 + _x_1);
    const _x_3 = ($U32$show$(_key_0));
    const _x_4 = (":" + _x_2);
    const _x_5 = (_x_3 + _x_4);
    return ("Body:" + _x_5);
  } else if (_action_0.$ === "../../../application.Marker") {
    const _value_0 = _action_0["enabled"];
    const _x_6 = ($$$$047$$$047$$$047observe$058bool$(_value_0));
    return ("Marker:" + _x_6);
  } else if (_action_0.$ === "../../../application.Deferred") {
    return "Deferred";
  } else if (_action_0.$ === "../../../application.Read") {
    const _key_1 = _action_0["key"];
    const _name_1 = _action_0["name"];
    const _fails_0 = _action_0["fails"];
    const _x_7 = ($$$$047$$$047$$$047observe$058bool$(_fails_0));
    const _x_8 = (":" + _x_7);
    const _x_9 = (_name_1 + _x_8);
    const _x_10 = ($U32$show$(_key_1));
    const _x_11 = (":" + _x_9);
    const _x_12 = (_x_10 + _x_11);
    return ("Read:" + _x_12);
  } else if (_action_0.$ === "../../../application.GatedRead") {
    const _key_2 = _action_0["key"];
    const _name_2 = _action_0["name"];
    const _tree_0 = _action_0["condition"];
    const _x_13 = ($$$$047$$$047$$$047application$058condition_view$1261$(_tree_0));
    const _x_14 = (":" + _x_13);
    const _x_15 = (_name_2 + _x_14);
    const _x_16 = ($U32$show$(_key_2));
    const _x_17 = (":" + _x_15);
    const _x_18 = (_x_16 + _x_17);
    return ("GatedRead:" + _x_18);
  } else {
    const _key_3 = _action_0["key"];
    const _name_3 = _action_0["name"];
    const _tree_1 = _action_0["condition"];
    const _x_19 = ($$$$047$$$047$$$047application$058condition_view$1261$(_tree_1));
    const _x_20 = (":" + _x_19);
    const _x_21 = (_name_3 + _x_20);
    const _x_22 = ($U32$show$(_key_3));
    const _x_23 = (":" + _x_21);
    const _x_24 = (_x_22 + _x_23);
    return ("Gate:" + _x_24);
  }
}

function $List$show$go$12614$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047application$058action_view$1261$(_h_0));
    const _x_1 = ($List$show$go$12614$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047observations$058users_join$1261$(_head_0, _rest_0) {
  const _entry_0 = _head_0["fst"];
  const _text_0 = _head_0["snd"];
  const _rest_1 = _rest_0["fst"];
  const _rows_0 = _rest_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _entry_0, "tail": _rest_1}, "snd": {$: "Con", "head": _text_0, "tail": _rows_0}};
}

function $$$$047$$$047observations$058user_entry$1261$(_entry_0) {
  const _key_0 = _entry_0["key"];
  const _t_0 = _entry_0["registry"];
  const _ns_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _name_0 = _t_0["name"];
  const _access_0 = _t_0["access"];
  const _cursor_0 = _t_0["cursor"];
  const _x_0 = ($U32$show$(_cursor_0));
  const _x_1 = ($List$show$1261$(_access_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":" + _x_3);
  const _x_5 = (_name_0 + _x_4);
  const _x_6 = ($U32$show$(_id_0));
  const _x_7 = (":" + _x_5);
  const _x_8 = (_x_6 + _x_7);
  const _x_9 = ($U32$show$(_ns_0));
  const _x_10 = (":" + _x_8);
  const _x_11 = (_x_9 + _x_10);
  const _x_12 = ($U32$show$(_key_0));
  const _x_13 = (":" + _x_11);
  return {$: "Tuple", "fst": {$: "../../../catalog.Entry", "key": _key_0, "registry": {$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}}, "snd": (_x_12 + _x_13)};
}

function $$$$047$$$047$$$047observe$058column_join$1261$(_pair_0, _stamps_0) {
  const _values_0 = _pair_0["fst"];
  const _views_0 = _pair_0["snd"];
  const _x_0 = ($List$show$1268$(_stamps_0));
  const _x_1 = ($List$show$1261$(_views_0));
  const _x_2 = (":stamps=" + _x_0);
  return {$: "Tuple", "fst": {$: "../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": (_x_1 + _x_2)};
}

function $$$$047$$$047$$$047observe$058slot$1262$(_value_0) {
  if (_value_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _last_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($$$$047$$$047$$$047observe$058bool$(_changed_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($$$$047$$$047$$$047observe$058previous$1260$(_last_0));
    const _x_3 = (",changed=" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($$$$047$$$047$$$047observe$058pending$1260$(_next_0));
    const _x_6 = (",previous=" + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($$$$047$$$047$$$047observe$058flow$(_current_0));
    const _x_9 = ("(pending=" + _x_7);
    return (_x_8 + _x_9);
  }
}

function $$$$047$$$047$$$047observe$058slot$1263$(_value_0) {
  if (_value_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _last_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($$$$047$$$047$$$047observe$058bool$(_changed_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($$$$047$$$047$$$047observe$058previous$1261$(_last_0));
    const _x_3 = (",changed=" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($$$$047$$$047$$$047observe$058pending$1261$(_next_0));
    const _x_6 = (",previous=" + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($$$$047$$$047$$$047observe$058level$(_current_0));
    const _x_9 = ("(pending=" + _x_7);
    return (_x_8 + _x_9);
  }
}

function $$$$047$$$047$$$047application$058schedule_returned$1261$(_result_0) {
  if (_result_0.$ === "../../../../../src/ecs/schedule.Finished") {
    const _t_0 = _result_0["schedule"];
    const _owners_0 = _t_0["owners"];
    const _world_0 = _result_0["world"];
    return {$: "../../../application.FrameResult", "owners": _owners_0, "world": _world_0, "status": "ok"};
  } else if (_result_0.$ === "../../../../../src/ecs/schedule.Failed") {
    const _t_1 = _result_0["schedule"];
    const _owners_1 = _t_1["owners"];
    const _world_1 = _result_0["world"];
    const _error_0 = _result_0["error"];
    return {$: "../../../application.FrameResult", "owners": _owners_1, "world": _world_1, "status": ("failed:" + _error_0)};
  } else {
    const _t_2 = _result_0["schedule"];
    const _owners_2 = _t_2["owners"];
    const _world_2 = _result_0["world"];
    return {$: "../../../application.FrameResult", "owners": _owners_2, "world": _world_2, "status": "schedule-namespace-rejected"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run$1261$(_schedule_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_namespace$1261$(_schedule_0, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058namespace$1261$(_world_0)));
}

function $$$$047$$$047$$$047provider$058map_resources$1261$(_effect_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _effect_0(_resources_0), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047provider$058frame_resources$1261$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "../../../provider.Resources", "owned": _owned_0, "flow": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058clear_changed$1262$(_flow_0)), "level": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058clear_changed$1263$(_level_0)), "flowStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058frame$1260$(_flowStream_0, _tick_0)), "levelStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058frame$1261$(_levelStream_0, _tick_0)), "frame": nat_chk(_frame_0 + 1), "tick": _tick_0, "trace": _trace_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058build_checked$1261$(_allowed_0, _namespace_0, _name_0, _steps_0, _owners_0) {
  if (!_allowed_0) {
    return {$: "../../../../../src/ecs/schedule.Invalid", "owners": _owners_0};
  } else {
    return {$: "../../../../../src/ecs/schedule.Built", "schedule": {$: "../../../../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}};
  }
}

function $$$$047$$$047$$$047application$058action_id$1261$(_action_0) {
  if (_action_0.$ === "../../../application.Body") {
    const _key_0 = _action_0["key"];
    return _key_0;
  } else if (_action_0.$ === "../../../application.Read") {
    const _key_1 = _action_0["key"];
    return _key_1;
  } else if (_action_0.$ === "../../../application.GatedRead") {
    const _key_2 = _action_0["key"];
    return _key_2;
  } else if (_action_0.$ === "../../../application.Gate") {
    const _key_3 = _action_0["key"];
    return _key_3;
  } else if (_action_0.$ === "../../../application.Marker") {
    return 100;
  } else {
    return 101;
  }
}

function $$$$047$$$047$$$047application$058slots_present$1261$(_env_0) {
  const _flow_0 = _env_0["flow"];
  const _level_0 = _env_0["level"];
  return $Bool$and$(($$$$047$$$047$$$047provider$058slot_present$1262$(_flow_0)), ($$$$047$$$047$$$047provider$058slot_present$1263$(_level_0)));
}

function $$$$047$$$047$$$047provider$058condition_provisioned$1261$(_needs_0, _env_0) {
  if (_needs_0.$ === "Nil") {
    return true;
  } else {
    const _t_0 = _needs_0["head"];
    if (_t_0 == 1) {
      const _rest_0 = _needs_0["tail"];
      const _flow_0 = _env_0["flow"];
      const _level_0 = _env_0["level"];
      return $Bool$and$(($$$$047$$$047$$$047provider$058slot_present$1262$(_flow_0)), ($$$$047$$$047$$$047provider$058condition_provisioned$1261$(_rest_0, {$: "../../../provider.ConditionEnv", "flow": _flow_0, "level": _level_0})));
    } else if ((_t_0 & 1) == 1) {
      return false;
    } else if (_t_0 == 2) {
      const _rest_2 = _needs_0["tail"];
      const _flow_1 = _env_0["flow"];
      const _level_1 = _env_0["level"];
      return $Bool$and$(($$$$047$$$047$$$047provider$058slot_present$1263$(_level_1)), ($$$$047$$$047$$$047provider$058condition_provisioned$1261$(_rest_2, {$: "../../../provider.ConditionEnv", "flow": _flow_1, "level": _level_1})));
    } else {
      return false;
    }
  }
}

function $$$$047$$$047$$$047provider$058condition_needs$1261$($0) {
  for (;;) {
    {
      const _tree_0 = $0;
      if (_tree_0.$ === "../../../conditions.Leaf") {
        const _atom_0 = _tree_0["atom"];
        return $$$$047$$$047$$$047provider$058atom_needs$1261$(_atom_0);
      } else if (_tree_0.$ === "../../../conditions.Constant") {
        return {$: "Nil"};
      } else if (_tree_0.$ === "../../../conditions.Negate") {
        const _inner_0 = _tree_0["inner"];
        $0 = _inner_0;
        continue;
      } else if (_tree_0.$ === "../../../conditions.Both") {
        const _left_0 = _tree_0["left"];
        const _right_0 = _tree_0["right"];
        return $List$append$(($$$$047$$$047$$$047provider$058condition_needs$1261$(_left_0)), ($$$$047$$$047$$$047provider$058condition_needs$1261$(_right_0)));
      } else {
        const _left_1 = _tree_0["left"];
        const _right_1 = _tree_0["right"];
        return $List$append$(($$$$047$$$047$$$047provider$058condition_needs$1261$(_left_1)), ($$$$047$$$047$$$047provider$058condition_needs$1261$(_right_1)));
      }
    }
  }
}

function $caller$045core$058survivor_returned$1261$(_a_0, _bo_0, _br_0, _rows_0, _result_0) {
  const _ao_0 = _a_0["owners"];
  const _aw_0 = _a_0["world"];
  const _ar_0 = _a_0["rows"];
  const _bReader_0 = _result_0["instance"];
  const _bw_0 = _result_0["world"];
  const _delivery_0 = _result_0["delivery"];
  const _status_0 = _result_0["status"];
  const _x_0 = ($caller$045core$058delivery_view$(_delivery_0));
  return $caller$045core$058survivor_observed$1261$(($$$$047$$$047observations$058checkpoint$1261$("B-survivor-empty", _ar_0, {$: "../../../application.FrameResult", "owners": _ao_0, "world": _aw_0, "status": _status_0})), ($$$$047$$$047observations$058checkpoint$1261$("B-survivor-empty", _br_0, {$: "../../../application.FrameResult", "owners": _bo_0, "world": _bw_0, "status": _status_0})), _bReader_0, ($List$append$(_rows_0, {$: "Con", "head": ("B-survivor-delivery=" + _x_0), "tail": {$: "Nil"}})));
}

function $$$$047$$$047observations$058finish$1261$(_value_0) {
  const _rows_0 = _value_0["rows"];
  return $String$join$(_rows_0, "\n");
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_checked$1264$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "public-cleanup-v1/current-core/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_metadata$1264$({$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047application$058operation_view$(_operation_0) {
  if (_operation_0.$ === "../../../gameplay.Seed") {
    return "Seed";
  } else if (_operation_0.$ === "../../../gameplay.Queue") {
    return "Queue";
  } else if (_operation_0.$ === "../../../gameplay.OldPending") {
    return "OldPending";
  } else if (_operation_0.$ === "../../../gameplay.FailingPublisher") {
    const _error_0 = _operation_0["error"];
    return ("FailingPublisher:" + _error_0);
  } else if (_operation_0.$ === "../../../gameplay.Reset") {
    return "Reset";
  } else if (_operation_0.$ === "../../../gameplay.MarkerQueues") {
    return "MarkerQueues";
  } else if (_operation_0.$ === "../../../gameplay.SameSet") {
    return "SameSet";
  } else if (_operation_0.$ === "../../../gameplay.SameSkip") {
    return "SameSkip";
  } else if (_operation_0.$ === "../../../gameplay.OverwriteSkip") {
    return "OverwriteSkip";
  } else if (_operation_0.$ === "../../../gameplay.PauseRequest") {
    return "PauseRequest";
  } else if (_operation_0.$ === "../../../gameplay.PlayRequest") {
    return "PlayRequest";
  } else {
    return "Noop";
  }
}

function $$$$047$$$047$$$047application$058condition_view$1260$(_tree_0) {
  if (_tree_0.$ === "../../../conditions.Leaf") {
    const _atom_0 = _tree_0["atom"];
    return $$$$047$$$047$$$047application$058atom_view$1260$(_atom_0);
  } else if (_tree_0.$ === "../../../conditions.Constant") {
    const _value_0 = _tree_0["value"];
    return $$$$047$$$047$$$047observe$058bool$(_value_0);
  } else if (_tree_0.$ === "../../../conditions.Negate") {
    const _inner_0 = _tree_0["inner"];
    const _x_0 = ($$$$047$$$047$$$047application$058condition_view$1260$(_inner_0));
    const _x_1 = (_x_0 + ")");
    return ("not(" + _x_1);
  } else if (_tree_0.$ === "../../../conditions.Both") {
    const _left_0 = _tree_0["left"];
    const _right_0 = _tree_0["right"];
    const _x_2 = ($$$$047$$$047$$$047application$058condition_view$1260$(_right_0));
    const _x_3 = (_x_2 + ")");
    const _x_4 = ($$$$047$$$047$$$047application$058condition_view$1260$(_left_0));
    const _x_5 = ("," + _x_3);
    const _x_6 = (_x_4 + _x_5);
    return ("and(" + _x_6);
  } else {
    const _left_1 = _tree_0["left"];
    const _right_1 = _tree_0["right"];
    const _x_7 = ($$$$047$$$047$$$047application$058condition_view$1260$(_right_1));
    const _x_8 = (_x_7 + ")");
    const _x_9 = ($$$$047$$$047$$$047application$058condition_view$1260$(_left_1));
    const _x_10 = ("," + _x_8);
    const _x_11 = (_x_9 + _x_10);
    return ("or(" + _x_11);
  }
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $List$show$1268$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047observe$058entry$(_h_0));
    const _x_1 = ($List$show$go$1268$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047observe$058cells_leaf$(_pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": [_owner_0], "snd": {$: "Con", "head": _text_0, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047observe$058cell_view$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": "none"};
  } else {
    const _owner_0 = _value_0["value"];
    return $$$$047$$$047$$$047observe$058cell_view_join$(($$$$047$$$047$$$047observe$058owner_view$(_owner_0)));
  }
}

function $$$$047$$$047$$$047observe$058cells_join$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ($List$append$(_a_0, _b_0))};
}

function $$$$047$$$047$$$047observe$058flow$(_value_0) {
  if (_value_0.$ === "../../../provider.Boot") {
    return "Boot";
  } else if (_value_0.$ === "../../../provider.Play") {
    return "Play";
  } else {
    return "Pause";
  }
}

function $$$$047$$$047$$$047observe$058pending$1260$(_value_0) {
  if (_value_0.$ === "public-cleanup-v1/current-core/ecs/machine.NoPending") {
    return "none";
  } else {
    const _value_1 = _value_0["value"];
    const _skip_0 = _value_0["skipSame"];
    const _x_0 = ($$$$047$$$047$$$047observe$058bool$(_skip_0));
    const _x_1 = ($$$$047$$$047$$$047observe$058flow$(_value_1));
    const _x_2 = (":" + _x_0);
    return (_x_1 + _x_2);
  }
}

function $$$$047$$$047$$$047observe$058previous$1260$(_value_0) {
  if (_value_0.$ === "None") {
    return "none";
  } else {
    const _value_1 = _value_0["value"];
    return $$$$047$$$047$$$047observe$058flow$(_value_1);
  }
}

function $$$$047$$$047$$$047observe$058level$(_value_0) {
  if (_value_0.$ === "../../../provider.Low") {
    return "0";
  } else if (_value_0.$ === "../../../provider.Middle") {
    return "1";
  } else {
    return "2";
  }
}

function $$$$047$$$047$$$047observe$058pending$1261$(_value_0) {
  if (_value_0.$ === "public-cleanup-v1/current-core/ecs/machine.NoPending") {
    return "none";
  } else {
    const _value_1 = _value_0["value"];
    const _skip_0 = _value_0["skipSame"];
    const _x_0 = ($$$$047$$$047$$$047observe$058bool$(_skip_0));
    const _x_1 = ($$$$047$$$047$$$047observe$058level$(_value_1));
    const _x_2 = (":" + _x_0);
    return (_x_1 + _x_2);
  }
}

function $$$$047$$$047$$$047observe$058previous$1261$(_value_0) {
  if (_value_0.$ === "None") {
    return "none";
  } else {
    const _value_1 = _value_0["value"];
    return $$$$047$$$047$$$047observe$058level$(_value_1);
  }
}

function $List$show$1269$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047observe$058batch$1260$(_h_0));
    const _x_1 = ($List$show$go$12610$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12611$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047observe$058position$(_h_0));
    const _x_1 = ($List$show$go$12611$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12612$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047observe$058batch$1261$(_h_0));
    const _x_1 = ($List$show$go$12613$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047provider$058array_join$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ($List$append$(_a_0, _b_0))};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_namespace$1260$(_schedule_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_actual$1260$(_schedule_0, _world_0, _actual_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058clear_changed$1260$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    return {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _current_0, "pending": _pending_0, "previous": _previous_0, "changed": false};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058clear_changed$1261$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    return {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _current_0, "pending": _pending_0, "previous": _previous_0, "changed": false};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058frame$1260$(_stream_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058trimmed$1260$(_tick_0, _positions_0, run_loop($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058trim_capacity$1260$(run_loop($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058past_window$1260$(_batches_0, ($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058hold_boundary$(_positions_0, _frameStart_0)), _dropped_0)), 65536)));
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058frame$1261$(_stream_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058trimmed$1261$(_tick_0, _positions_0, run_loop($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058trim_capacity$1261$(run_loop($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058past_window$1261$(_batches_0, ($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058hold_boundary$(_positions_0, _frameStart_0)), _dropped_0)), 65536)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058contains$(_ids_0, _id_0) {
  if (_ids_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    const _x_0 = (_head_0 === _id_0);
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058contains$(_rest_0, _id_0));
    return (_x_0 || _x_1);
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047provider$058slot_present$1260$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return false;
  } else {
    return true;
  }
}

function $$$$047$$$047$$$047provider$058slot_present$1261$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return false;
  } else {
    return true;
  }
}

function $$$$047$$$047$$$047provider$058atom_needs$1260$(_atom_0) {
  if (_atom_0.$ === "../../../provider.InFlow") {
    return {$: "Con", "head": 1, "tail": {$: "Nil"}};
  } else if (_atom_0.$ === "../../../provider.InLevel") {
    return {$: "Con", "head": 2, "tail": {$: "Nil"}};
  } else if (_atom_0.$ === "../../../provider.FlowChanged") {
    return {$: "Con", "head": 1, "tail": {$: "Nil"}};
  } else {
    return {$: "Con", "head": 2, "tail": {$: "Nil"}};
  }
}

function $caller$045core$058survivor_observed$1260$(_a_0, _b_0, _bReader_0, _rows_0) {
  const _bo_0 = _b_0["owners"];
  const _bw_0 = _b_0["world"];
  const _br_0 = _b_0["rows"];
  return $caller$045core$058b_cleaned$1260$(_a_0, _bo_0, _br_0, _rows_0, ($caller$045core$058cleanup$1260$(_bReader_0, _bw_0)));
}

function $String$join$go$(_xs_0, _h_0, _sep_0) {
  if (_xs_0.$ === "Nil") {
    return _h_0;
  } else {
    const _h2_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($String$join$go$(_t_0, _h2_0, _sep_0));
    const _x_1 = (_sep_0 + _x_0);
    return (_h_0 + _x_1);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058update_checked$(_found_0, _dispose_0, _id_0, _old_0, _registered_0, _rest_0, _cursor_0) {
  if (!_found_0) {
    return {$: "Con", "head": {$: "public-cleanup-v1/current-core/ecs/event-runtime.Position", "id": _id_0, "cursor": _old_0, "registeredAt": _registered_0}, "tail": _rest_0};
  } else {
    if (!_dispose_0) {
      return {$: "Con", "head": {$: "public-cleanup-v1/current-core/ecs/event-runtime.Position", "id": _id_0, "cursor": _cursor_0, "registeredAt": _registered_0}, "tail": _rest_0};
    } else {
      return _rest_0;
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047registration$058retained$(_keep_0, _meta_0, _rest_0) {
  if (_keep_0) {
    return {$: "Con", "head": _meta_0, "tail": _rest_0};
  } else {
    return _rest_0;
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_metadata$1261$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($public$045cleanup$045v1$047current$045core$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047$$$047application$058condition_view$1261$(_tree_0) {
  if (_tree_0.$ === "../../../conditions.Leaf") {
    const _atom_0 = _tree_0["atom"];
    return $$$$047$$$047$$$047application$058atom_view$1261$(_atom_0);
  } else if (_tree_0.$ === "../../../conditions.Constant") {
    const _value_0 = _tree_0["value"];
    return $$$$047$$$047$$$047observe$058bool$(_value_0);
  } else if (_tree_0.$ === "../../../conditions.Negate") {
    const _inner_0 = _tree_0["inner"];
    const _x_0 = ($$$$047$$$047$$$047application$058condition_view$1261$(_inner_0));
    const _x_1 = (_x_0 + ")");
    return ("not(" + _x_1);
  } else if (_tree_0.$ === "../../../conditions.Both") {
    const _left_0 = _tree_0["left"];
    const _right_0 = _tree_0["right"];
    const _x_2 = ($$$$047$$$047$$$047application$058condition_view$1261$(_right_0));
    const _x_3 = (_x_2 + ")");
    const _x_4 = ($$$$047$$$047$$$047application$058condition_view$1261$(_left_0));
    const _x_5 = ("," + _x_3);
    const _x_6 = (_x_4 + _x_5);
    return ("and(" + _x_6);
  } else {
    const _left_1 = _tree_0["left"];
    const _right_1 = _tree_0["right"];
    const _x_7 = ($$$$047$$$047$$$047application$058condition_view$1261$(_right_1));
    const _x_8 = (_x_7 + ")");
    const _x_9 = ($$$$047$$$047$$$047application$058condition_view$1261$(_left_1));
    const _x_10 = ("," + _x_8);
    const _x_11 = (_x_9 + _x_10);
    return ("or(" + _x_11);
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_namespace$1261$(_schedule_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_actual$1261$(_schedule_0, _world_0, _actual_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058clear_changed$1262$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    return {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _current_0, "pending": _pending_0, "previous": _previous_0, "changed": false};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058clear_changed$1263$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    return {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _current_0, "pending": _pending_0, "previous": _previous_0, "changed": false};
  }
}

function $$$$047$$$047$$$047provider$058slot_present$1262$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return false;
  } else {
    return true;
  }
}

function $$$$047$$$047$$$047provider$058slot_present$1263$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return false;
  } else {
    return true;
  }
}

function $$$$047$$$047$$$047provider$058atom_needs$1261$(_atom_0) {
  if (_atom_0.$ === "../../../provider.InFlow") {
    return {$: "Con", "head": 1, "tail": {$: "Nil"}};
  } else if (_atom_0.$ === "../../../provider.InLevel") {
    return {$: "Con", "head": 2, "tail": {$: "Nil"}};
  } else if (_atom_0.$ === "../../../provider.FlowChanged") {
    return {$: "Con", "head": 1, "tail": {$: "Nil"}};
  } else {
    return {$: "Con", "head": 2, "tail": {$: "Nil"}};
  }
}

function $caller$045core$058survivor_observed$1261$(_a_0, _b_0, _bReader_0, _rows_0) {
  const _bo_0 = _b_0["owners"];
  const _bw_0 = _b_0["world"];
  const _br_0 = _b_0["rows"];
  return $caller$045core$058b_cleaned$1261$(_a_0, _bo_0, _br_0, _rows_0, ($caller$045core$058cleanup$1261$(_bReader_0, _bw_0)));
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_metadata$1264$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_checked$1264$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($public$045cleanup$045v1$047current$045core$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047$$$047$$$047application$058atom_view$1260$(_atom_0) {
  if (_atom_0.$ === "../../../provider.InFlow") {
    const _value_0 = _atom_0["value"];
    const _x_0 = ($$$$047$$$047$$$047observe$058flow$(_value_0));
    return ("Flow=" + _x_0);
  } else if (_atom_0.$ === "../../../provider.InLevel") {
    const _value_1 = _atom_0["value"];
    const _x_1 = ($$$$047$$$047$$$047observe$058level$(_value_1));
    return ("Level=" + _x_1);
  } else if (_atom_0.$ === "../../../provider.FlowChanged") {
    return "FlowChanged";
  } else {
    return "LevelChanged";
  }
}

function $$$$047$$$047$$$047observe$058entry$(_value_0) {
  const _id_0 = _value_0["id"];
  const _t_0 = _value_0["stamp"];
  const _added_0 = _t_0["added"];
  const _changed_0 = _t_0["changed"];
  const _x_0 = ($U32$show$(_changed_0));
  const _x_1 = ($U32$show$(_added_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_id_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$1268$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047observe$058entry$(_h_0));
    const _x_1 = ($List$show$go$1268$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047observe$058cell_view_join$(_value_0) {
  const _owner_0 = _value_0["fst"];
  const _text_0 = _value_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": _owner_0}, "snd": _text_0};
}

function $$$$047$$$047$$$047observe$058batch$1260$(_value_0) {
  const _tick_0 = _value_0["tick"];
  const _values_0 = _value_0["values"];
  const _x_0 = ($List$show$12610$(_values_0));
  const _x_1 = ($Nat$show$(_tick_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$12610$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047observe$058batch$1260$(_h_0));
    const _x_1 = ($List$show$go$12610$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047observe$058position$(_value_0) {
  const _id_0 = _value_0["id"];
  const _cursor_0 = _value_0["cursor"];
  const _registered_0 = _value_0["registeredAt"];
  const _x_0 = ($Nat$show$(_registered_0));
  const _x_1 = ($Nat$show$(_cursor_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_id_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$12611$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047observe$058position$(_h_0));
    const _x_1 = ($List$show$go$12611$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047observe$058batch$1261$(_value_0) {
  const _tick_0 = _value_0["tick"];
  const _values_0 = _value_0["values"];
  const _x_0 = ($List$show$12613$(_values_0));
  const _x_1 = ($Nat$show$(_tick_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$12613$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047observe$058batch$1261$(_h_0));
    const _x_1 = ($List$show$go$12613$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $List$show$go$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_actual$1260$(_schedule_0, _world_0, _actual_0) {
  const _namespace_0 = _schedule_0["namespace"];
  const _name_0 = _schedule_0["name"];
  const _steps_0 = _schedule_0["steps"];
  const _owners_0 = _schedule_0["owners"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_checked$1260$((_namespace_0 === _actual_0), {$: "../../../../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}, _world_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058trimmed$1260$(_frameStart_0, _positions_0, _result_0) {
  const _batches_0 = _result_0["batches"];
  const _dropped_0 = _result_0["dropped"];
  return {$: "public-cleanup-v1/current-core/ecs/machine-stream.Stream", "batches": _batches_0, "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058trim_capacity$1260$(_trimmed_0, _capacity_0) {
  const _batches_0 = _trimmed_0["batches"];
  const _dropped_0 = _trimmed_0["dropped"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058at_capacity$1260$(_batches_0, _capacity_0, _dropped_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058past_window$1260$(_batches_0, _boundary_0, _dropped_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "public-cleanup-v1/current-core/ecs/event-runtime.Trimmed", "batches": {$: "Nil"}, "dropped": _dropped_0};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058past_checked$1260$(($Nat$is_le$(_tick_0, _boundary_0)), _tick_0, _items_0, _rest_0, _dropped_0, run_clo((_x_0) => {
  return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058past_window$1260$(_rest_0, _boundary_0, _x_0);
}));
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058hold_boundary$($0, $1) {
  for (;;) {
    {
      const _positions_0 = $0;
      const _boundary_0 = $1;
      if (_positions_0.$ === "Nil") {
        return _boundary_0;
      } else {
        const _t_0 = _positions_0["head"];
        const _cursor_0 = _t_0["cursor"];
        const _rest_0 = _positions_0["tail"];
        $0 = _rest_0;
        $1 = (_boundary_0 < _cursor_0 ? _boundary_0 : _cursor_0);
        continue;
      }
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058trimmed$1261$(_frameStart_0, _positions_0, _result_0) {
  const _batches_0 = _result_0["batches"];
  const _dropped_0 = _result_0["dropped"];
  return {$: "public-cleanup-v1/current-core/ecs/machine-stream.Stream", "batches": _batches_0, "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058trim_capacity$1261$(_trimmed_0, _capacity_0) {
  const _batches_0 = _trimmed_0["batches"];
  const _dropped_0 = _trimmed_0["dropped"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058at_capacity$1261$(_batches_0, _capacity_0, _dropped_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058past_window$1261$(_batches_0, _boundary_0, _dropped_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "public-cleanup-v1/current-core/ecs/event-runtime.Trimmed", "batches": {$: "Nil"}, "dropped": _dropped_0};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058past_checked$1261$(($Nat$is_le$(_tick_0, _boundary_0)), _tick_0, _items_0, _rest_0, _dropped_0, run_clo((_x_0) => {
  return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058past_window$1261$(_rest_0, _boundary_0, _x_0);
}));
  }
}

function $caller$045core$058b_cleaned$1260$(_a_0, _bo_0, _br_0, _rows_0, _result_0) {
  if (_result_0.$ === "caller-core.Cleaned") {
    const _world_0 = _result_0["world"];
    return $caller$045core$058finish_pair$1260$(_a_0, ($$$$047$$$047observations$058checkpoint$1260$("B-owned-cleanup", _br_0, {$: "../../../application.FrameResult", "owners": _bo_0, "world": _world_0, "status": "cleaned"})), ($List$append$(_rows_0, {$: "Con", "head": "B-owned-cleanup|B=disposed", "tail": {$: "Nil"}})));
  } else {
    const _world_1 = _result_0["world"];
    return $caller$045core$058finish_pair$1260$(_a_0, ($$$$047$$$047observations$058checkpoint$1260$("B-cleanup-rejected", _br_0, {$: "../../../application.FrameResult", "owners": _bo_0, "world": _world_1, "status": "cleanup-rejected"})), ($List$append$(_rows_0, {$: "Con", "head": "B-cleanup-rejected", "tail": {$: "Nil"}})));
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $public$045cleanup$045v1$047current$045core$047ecs$047world$058matching_access$(($public$045cleanup$045v1$047current$045core$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "public-cleanup-v1/current-core/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $public$045cleanup$045v1$047current$045core$047ecs$047system$058complete$1261$(_registry_0, ($$$$047$$$047$$$047readers$058runner$1260$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047application$058atom_view$1261$(_atom_0) {
  if (_atom_0.$ === "../../../provider.InFlow") {
    const _value_0 = _atom_0["value"];
    const _x_0 = ($$$$047$$$047$$$047observe$058flow$(_value_0));
    return ("Flow=" + _x_0);
  } else if (_atom_0.$ === "../../../provider.InLevel") {
    const _value_1 = _atom_0["value"];
    const _x_1 = ($$$$047$$$047$$$047observe$058level$(_value_1));
    return ("Level=" + _x_1);
  } else if (_atom_0.$ === "../../../provider.FlowChanged") {
    return "FlowChanged";
  } else {
    return "LevelChanged";
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_actual$1261$(_schedule_0, _world_0, _actual_0) {
  const _namespace_0 = _schedule_0["namespace"];
  const _name_0 = _schedule_0["name"];
  const _steps_0 = _schedule_0["steps"];
  const _owners_0 = _schedule_0["owners"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_checked$1261$((_namespace_0 === _actual_0), {$: "../../../../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}, _world_0);
}

function $caller$045core$058b_cleaned$1261$(_a_0, _bo_0, _br_0, _rows_0, _result_0) {
  if (_result_0.$ === "caller-core.Cleaned") {
    const _world_0 = _result_0["world"];
    return $caller$045core$058finish_pair$1261$(_a_0, ($$$$047$$$047observations$058checkpoint$1261$("B-owned-cleanup", _br_0, {$: "../../../application.FrameResult", "owners": _bo_0, "world": _world_0, "status": "cleaned"})), ($List$append$(_rows_0, {$: "Con", "head": "B-owned-cleanup|B=disposed", "tail": {$: "Nil"}})));
  } else {
    const _world_1 = _result_0["world"];
    return $caller$045core$058finish_pair$1261$(_a_0, ($$$$047$$$047observations$058checkpoint$1261$("B-cleanup-rejected", _br_0, {$: "../../../application.FrameResult", "owners": _bo_0, "world": _world_1, "status": "cleanup-rejected"})), ($List$append$(_rows_0, {$: "Con", "head": "B-cleanup-rejected", "tail": {$: "Nil"}})));
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_checked$1264$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "public-cleanup-v1/current-core/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $public$045cleanup$045v1$047current$045core$047ecs$047system$058complete$1264$(_registry_0, ($$$$047$$$047$$$047readers$058runner$1261$(_world_0, _args_0)));
  }
}

function $List$show$12610$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047observe$058transition$1260$(_h_0));
    const _x_1 = ($List$show$go$1269$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12613$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047observe$058transition$1261$(_h_0));
    const _x_1 = ($List$show$go$12612$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_checked$1260$(_allowed_0, _schedule_0, _world_0) {
  if (!_allowed_0) {
    return {$: "../../../../../src/ecs/schedule.Rejected", "schedule": _schedule_0, "world": _world_0};
  } else {
    const _namespace_0 = _schedule_0["namespace"];
    const _name_0 = _schedule_0["name"];
    const _steps_0 = _schedule_0["steps"];
    const _owners_0 = _schedule_0["owners"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058execute$1260$(_steps_0, _owners_0, _world_0, _namespace_0, _name_0, _steps_0, {$: "Nil"});
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058at_capacity$1260$(_batches_0, _capacity_0, _dropped_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "public-cleanup-v1/current-core/ecs/event-runtime.Trimmed", "batches": {$: "Nil"}, "dropped": _dropped_0};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    const _x_0 = ($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058size$1260$({$: "Con", "head": {$: "public-cleanup-v1/current-core/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}));
    return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058capacity_checked$1260$((_capacity_0 < _x_0), _tick_0, _items_0, _rest_0, _dropped_0, run_clo((_x_1) => {
  return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058at_capacity$1260$(_rest_0, _capacity_0, _x_1);
}));
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058past_checked$1260$(_remove_0, _tick_0, _items_0, _rest_0, _dropped_0, _ih_0) {
  if (!_remove_0) {
    return {$: "public-cleanup-v1/current-core/ecs/event-runtime.Trimmed", "batches": {$: "Con", "head": {$: "public-cleanup-v1/current-core/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0));
  }
}

function $Nat$is_le$(_a_0, _b_0) {
  return $Cmp$is_le$(cmp_new(_a_0, _b_0));
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058at_capacity$1261$(_batches_0, _capacity_0, _dropped_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "public-cleanup-v1/current-core/ecs/event-runtime.Trimmed", "batches": {$: "Nil"}, "dropped": _dropped_0};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    const _x_0 = ($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058size$1261$({$: "Con", "head": {$: "public-cleanup-v1/current-core/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}));
    return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058capacity_checked$1261$((_capacity_0 < _x_0), _tick_0, _items_0, _rest_0, _dropped_0, run_clo((_x_1) => {
  return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058at_capacity$1261$(_rest_0, _capacity_0, _x_1);
}));
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058past_checked$1261$(_remove_0, _tick_0, _items_0, _rest_0, _dropped_0, _ih_0) {
  if (!_remove_0) {
    return {$: "public-cleanup-v1/current-core/ecs/event-runtime.Trimmed", "batches": {$: "Con", "head": {$: "public-cleanup-v1/current-core/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0));
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $public$045cleanup$045v1$047current$045core$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058complete$1261$(_registry_0, _outcome_0) {
  return {$: "public-cleanup-v1/current-core/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047$$$047$$$047readers$058runner$1260$(_world_0, _input_0) {
  return $$$$047$$$047$$$047readers$058namespace_checked$1260$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058namespace$1260$(_world_0)), _input_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_checked$1261$(_allowed_0, _schedule_0, _world_0) {
  if (!_allowed_0) {
    return {$: "../../../../../src/ecs/schedule.Rejected", "schedule": _schedule_0, "world": _world_0};
  } else {
    const _namespace_0 = _schedule_0["namespace"];
    const _name_0 = _schedule_0["name"];
    const _steps_0 = _schedule_0["steps"];
    const _owners_0 = _schedule_0["owners"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058execute$1261$(_steps_0, _owners_0, _world_0, _namespace_0, _name_0, _steps_0, {$: "Nil"});
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058complete$1264$(_registry_0, _outcome_0) {
  return {$: "public-cleanup-v1/current-core/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047$$$047$$$047readers$058runner$1261$(_world_0, _input_0) {
  return $$$$047$$$047$$$047readers$058namespace_checked$1261$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058namespace$1261$(_world_0)), _input_0);
}

function $List$show$go$1269$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047observe$058transition$1260$(_h_0));
    const _x_1 = ($List$show$go$1269$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $List$show$go$12612$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047observe$058transition$1261$(_h_0));
    const _x_1 = ($List$show$go$12612$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058execute$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _owners_0 = $1;
      const _world_0 = $2;
      const _namespace_0 = $3;
      const _name_0 = $4;
      const _all_0 = $5;
      const _observations_0 = $6;
      if (_steps_0.$ === "Nil") {
        return {$: "../../../../../src/ecs/schedule.Finished", "schedule": {$: "../../../../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "observations": _observations_0};
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../../../../../src/ecs/schedule.Phase") {
          const _phase_0 = _t_0["name"];
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _owners_0;
          $2 = _world_0;
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../src/ecs/schedule.Entered", "name": _phase_0}, "tail": {$: "Nil"}}));
          continue;
        } else if (_t_0.$ === "../../../../../src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _owners_0;
          $2 = run_loop($public$045cleanup$045v1$047current$045core$047ecs$047world$058barrier$1260$(_world_0));
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../src/ecs/schedule.Applied"}, "tail": {$: "Nil"}}));
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _slot_0 = _t_0["condition"];
          const _rest_2 = _steps_0["tail"];
          return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_condition$1260$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058execute$1260$(_rest_2, _x_0, _x_1, _namespace_0, _name_0, _all_0, _x_2);
});
});
}), ($$$$047$$$047$$$047application$058condition$1260$(_world_0, _slot_0)), _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
        }
      }
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058capacity_checked$1260$(_overflow_0, _tick_0, _items_0, _rest_0, _dropped_0, _ih_0) {
  if (!_overflow_0) {
    return {$: "public-cleanup-v1/current-core/ecs/event-runtime.Trimmed", "batches": {$: "Con", "head": {$: "public-cleanup-v1/current-core/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0));
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058size$1260$(_batches_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058size_loop$1260$(_batches_0, 0);
}

function $Cmp$is_le$(_c_0) {
  if (_c_0.$ === "GT") {
    return false;
  } else {
    return true;
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058capacity_checked$1261$(_overflow_0, _tick_0, _items_0, _rest_0, _dropped_0, _ih_0) {
  if (!_overflow_0) {
    return {$: "public-cleanup-v1/current-core/ecs/event-runtime.Trimmed", "batches": {$: "Con", "head": {$: "public-cleanup-v1/current-core/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0));
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058size$1261$(_batches_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058size_loop$1261$(_batches_0, 0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($public$045cleanup$045v1$047current$045core$047ecs$047string$045equality$058equal$(__2, _y_0)), ($public$045cleanup$045v1$047current$045core$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047readers$058namespace_checked$1260$(_pair_0, _input_0) {
  const _world_0 = _pair_0["fst"];
  const _actual_0 = _pair_0["snd"];
  const _a_0 = _input_0["flowNamespace"];
  const _id_0 = _input_0["flowId"];
  const _b_0 = _input_0["levelNamespace"];
  const _jd_0 = _input_0["levelId"];
  const _fails_0 = _input_0["fails"];
  return $$$$047$$$047$$$047readers$058prepare_checked$1260$(($Bool$and$((_actual_0 === _a_0), (_actual_0 === _b_0))), _world_0, _id_0, _jd_0, _fails_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058execute$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _owners_0 = $1;
      const _world_0 = $2;
      const _namespace_0 = $3;
      const _name_0 = $4;
      const _all_0 = $5;
      const _observations_0 = $6;
      if (_steps_0.$ === "Nil") {
        return {$: "../../../../../src/ecs/schedule.Finished", "schedule": {$: "../../../../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "observations": _observations_0};
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../../../../../src/ecs/schedule.Phase") {
          const _phase_0 = _t_0["name"];
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _owners_0;
          $2 = _world_0;
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../src/ecs/schedule.Entered", "name": _phase_0}, "tail": {$: "Nil"}}));
          continue;
        } else if (_t_0.$ === "../../../../../src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _owners_0;
          $2 = run_loop($public$045cleanup$045v1$047current$045core$047ecs$047world$058barrier$1261$(_world_0));
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../src/ecs/schedule.Applied"}, "tail": {$: "Nil"}}));
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _slot_0 = _t_0["condition"];
          const _rest_2 = _steps_0["tail"];
          return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_condition$1261$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058execute$1261$(_rest_2, _x_0, _x_1, _namespace_0, _name_0, _all_0, _x_2);
});
});
}), ($$$$047$$$047$$$047application$058condition$1261$(_world_0, _slot_0)), _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
        }
      }
    }
  }
}

function $$$$047$$$047$$$047readers$058namespace_checked$1261$(_pair_0, _input_0) {
  const _world_0 = _pair_0["fst"];
  const _actual_0 = _pair_0["snd"];
  const _a_0 = _input_0["flowNamespace"];
  const _id_0 = _input_0["flowId"];
  const _b_0 = _input_0["levelNamespace"];
  const _jd_0 = _input_0["levelId"];
  const _fails_0 = _input_0["fails"];
  return $$$$047$$$047$$$047readers$058prepare_checked$1261$(($Bool$and$((_actual_0 === _a_0), (_actual_0 === _b_0))), _world_0, _id_0, _jd_0, _fails_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058barrier$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058drain_fifo$1260$(_pending_0, {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_condition$1260$(_next_0, _checked_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058conditioned$1260$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $$$$047$$$047$$$047application$058condition$1260$(_world_0, __0) {
  return {$: "Tuple", "fst": _world_0, "snd": true};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058size_loop$1260$($0, $1) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _acc_0 = $1;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = ($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058count_loop$1260$(_items_0, _acc_0));
        continue;
      }
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058size_loop$1261$($0, $1) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _acc_0 = $1;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = ($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058count_loop$1261$(_items_0, _acc_0));
        continue;
      }
    }
  }
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

function $$$$047$$$047$$$047readers$058prepare_checked$1260$(_allowed_0, _world_0, _flowId_0, _levelId_0, _fails_0) {
  if (!_allowed_0) {
    return {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": {$: "../../../readers.Failure", "message": "ReaderNamespaceRejected", "delivery": {$: "None"}}};
  } else {
    return $$$$047$$$047$$$047readers$058prepare$1260$(_world_0, _flowId_0, _levelId_0, _fails_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058barrier$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058drain_fifo$1261$(_pending_0, {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_condition$1261$(_next_0, _checked_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058conditioned$1261$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $$$$047$$$047$$$047application$058condition$1261$(_world_0, __0) {
  return {$: "Tuple", "fst": _world_0, "snd": true};
}

function $$$$047$$$047$$$047readers$058prepare_checked$1261$(_allowed_0, _world_0, _flowId_0, _levelId_0, _fails_0) {
  if (!_allowed_0) {
    return {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": {$: "../../../readers.Failure", "message": "ReaderNamespaceRejected", "delivery": {$: "None"}}};
  } else {
    return $$$$047$$$047$$$047readers$058prepare$1261$(_world_0, _flowId_0, _levelId_0, _fails_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058drain_fifo$1260$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($public$045cleanup$045v1$047current$045core$047ecs$047world$058drain_fifo$1260$(_rest_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058conditioned$1260$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (!_allowed_0) {
    return run_tail(_next_0(_owners_0)(_world_0), ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../src/ecs/schedule.Skipped", "id": _id_0}, "tail": {$: "Nil"}})));
  } else {
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_dispatch$1260$(_next_0, ($$$$047$$$047$$$047application$058dispatch$1260$(_owners_0, _world_0, _id_0)), _namespace_0, _name_0, _all_0, _observations_0, _id_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058count_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058count_loop$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047readers$058prepare$1260$(_world_0, _flowId_0, _levelId_0, _fails_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _flowStream_0 = _t_0["flowStream"];
  const _levelStream_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _trace_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047readers$058prepared$1260$({$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058activate$1260$(_flowStream_0, _flowId_0, _tick_0)), "levelStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058activate$1261$(_levelStream_0, _levelId_0, _tick_0)), "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, _flowStream_0, _levelStream_0, _flowId_0, _levelId_0, _tick_0, _fails_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058drain_fifo$1261$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($public$045cleanup$045v1$047current$045core$047ecs$047world$058drain_fifo$1261$(_rest_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058conditioned$1261$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (!_allowed_0) {
    return run_tail(_next_0(_owners_0)(_world_0), ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../src/ecs/schedule.Skipped", "id": _id_0}, "tail": {$: "Nil"}})));
  } else {
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_dispatch$1261$(_next_0, ($$$$047$$$047$$$047application$058dispatch$1261$(_owners_0, _world_0, _id_0)), _namespace_0, _name_0, _all_0, _observations_0, _id_0);
  }
}

function $$$$047$$$047$$$047readers$058prepare$1261$(_world_0, _flowId_0, _levelId_0, _fails_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _flowStream_0 = _t_0["flowStream"];
  const _levelStream_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _trace_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047readers$058prepared$1261$({$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058activate$1260$(_flowStream_0, _flowId_0, _tick_0)), "levelStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058activate$1261$(_levelStream_0, _levelId_0, _tick_0)), "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, _flowStream_0, _levelStream_0, _flowId_0, _levelId_0, _tick_0, _fails_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_dispatch$1260$(_next_0, _result_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _owners_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_outcome$1260$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $$$$047$$$047$$$047application$058dispatch$1260$(_owners_0, _world_0, _id_0) {
  const _users_0 = _owners_0["users"];
  const _hooks_0 = _owners_0["hooks"];
  const _readers_0 = _owners_0["readers"];
  const _attempts_0 = _owners_0["attempts"];
  const _deliveries_0 = _owners_0["deliveries"];
  const _conditions_0 = _owners_0["conditions"];
  const _active_0 = _owners_0["active"];
  return $$$$047$$$047$$$047application$058action$1260$({$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": _readers_0, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, _world_0, ($$$$047$$$047$$$047application$058find$1260$(_active_0, _id_0)));
}

function $$$$047$$$047$$$047readers$058prepared$1260$(_world_0, _flowStream_0, _levelStream_0, _flowId_0, _levelId_0, _tick_0, _fails_0) {
  return $$$$047$$$047$$$047readers$058finish$1260$(_flowId_0, _levelId_0, ($$$$047$$$047$$$047readers$058body$1260$(_fails_0, {$: "../../../readers.Frame", "base": {$: "../../../context.Frame", "tx": ($public$045cleanup$045v1$047current$045core$047ecs$047transaction$058begin$1260$(($$$$047$$$047$$$047provider$058pulse$1260$(_world_0)))), "error": {$: "None"}}, "flow": ($$$$047$$$047$$$047readers$058view$1260$(($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058observe$1260$(_flowStream_0, _flowId_0, _tick_0)))), "level": ($$$$047$$$047$$$047readers$058view$1261$(($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058observe$1261$(_levelStream_0, _levelId_0, _tick_0))))})));
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058activate$1260$(_stream_0, _id_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return {$: "public-cleanup-v1/current-core/ecs/machine-stream.Stream", "batches": _batches_0, "positions": ($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _tick_0)), "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058activate$1261$(_stream_0, _id_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return {$: "public-cleanup-v1/current-core/ecs/machine-stream.Stream", "batches": _batches_0, "positions": ($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _tick_0)), "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_dispatch$1261$(_next_0, _result_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _owners_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_outcome$1261$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $$$$047$$$047$$$047application$058dispatch$1261$(_owners_0, _world_0, _id_0) {
  const _users_0 = _owners_0["users"];
  const _hooks_0 = _owners_0["hooks"];
  const _readers_0 = _owners_0["readers"];
  const _attempts_0 = _owners_0["attempts"];
  const _deliveries_0 = _owners_0["deliveries"];
  const _conditions_0 = _owners_0["conditions"];
  const _active_0 = _owners_0["active"];
  return $$$$047$$$047$$$047application$058action$1261$({$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": _readers_0, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, _world_0, ($$$$047$$$047$$$047application$058find$1261$(_active_0, _id_0)));
}

function $$$$047$$$047$$$047readers$058prepared$1261$(_world_0, _flowStream_0, _levelStream_0, _flowId_0, _levelId_0, _tick_0, _fails_0) {
  return $$$$047$$$047$$$047readers$058finish$1261$(_flowId_0, _levelId_0, ($$$$047$$$047$$$047readers$058body$1261$(_fails_0, {$: "../../../readers.Frame", "base": {$: "../../../context.Frame", "tx": ($public$045cleanup$045v1$047current$045core$047ecs$047transaction$058begin$1261$(($$$$047$$$047$$$047provider$058pulse$1261$(_world_0)))), "error": {$: "None"}}, "flow": ($$$$047$$$047$$$047readers$058view$1262$(($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058observe$1260$(_flowStream_0, _flowId_0, _tick_0)))), "level": ($$$$047$$$047$$$047readers$058view$1263$(($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058observe$1261$(_levelStream_0, _levelId_0, _tick_0))))})));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_outcome$1260$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (_outcome_0.$ === "public-cleanup-v1/current-core/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../src/ecs/schedule.Failed", "schedule": {$: "../../../../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "error": _error_0, "observations": ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}}))};
  } else {
    const _world_1 = _outcome_0["world"];
    return run_tail(_next_0(_owners_0)(_world_1), ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}})));
  }
}

function $$$$047$$$047$$$047application$058action$1260$(_owners_0, _world_0, _chosen_0) {
  if (_chosen_0.$ === "None") {
    return {$: "Tuple", "fst": _owners_0, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": "MissingScheduleAction"}};
  } else {
    const _t_0 = _chosen_0["value"];
    if (_t_0.$ === "../../../application.Body") {
      const _key_0 = _t_0["key"];
      const _name_0 = _t_0["name"];
      const _operation_0 = _t_0["operation"];
      return $$$$047$$$047$$$047application$058run_body$1260$(_owners_0, _world_0, _key_0, _name_0, _operation_0);
    } else if (_t_0.$ === "../../../application.Read") {
      const _key_1 = _t_0["key"];
      const _name_1 = _t_0["name"];
      const _fails_0 = _t_0["fails"];
      return $$$$047$$$047$$$047application$058run_reader$1260$(_owners_0, _world_0, _key_1, _name_1, _fails_0);
    } else if (_t_0.$ === "../../../application.GatedRead") {
      const _key_2 = _t_0["key"];
      const _name_2 = _t_0["name"];
      const _condition_0 = _t_0["condition"];
      return $$$$047$$$047$$$047application$058reader_checked$1260$(_owners_0, _key_2, _name_2, ($$$$047$$$047$$$047provider$058condition_world$1260$(_world_0, _condition_0)));
    } else if (_t_0.$ === "../../../application.Gate") {
      const _key_3 = _t_0["key"];
      const _name_3 = _t_0["name"];
      const _condition_1 = _t_0["condition"];
      return $$$$047$$$047$$$047application$058gate_checked$1260$(_owners_0, _key_3, _name_3, ($$$$047$$$047$$$047provider$058condition_world$1260$(_world_0, _condition_1)));
    } else if (_t_0.$ === "../../../application.Marker") {
      const _enabled_0 = _t_0["enabled"];
      return $$$$047$$$047$$$047application$058run_marker$1260$(_owners_0, _world_0, _enabled_0);
    } else {
      return {$: "Tuple", "fst": _owners_0, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Succeeded", "world": ($$$$047$$$047$$$047provider$058pulse$1260$(run_loop($public$045cleanup$045v1$047current$045core$047ecs$047world$058barrier$1260$(_world_0)))), "output": {$: "Unit"}}};
    }
  }
}

function $$$$047$$$047$$$047application$058find$1260$(_actions_0, _id_0) {
  if (_actions_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _action_0 = _actions_0["head"];
    const _rest_0 = _actions_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047application$058action_id$1260$(_action_0));
    return $$$$047$$$047$$$047application$058find_checked$1260$((_x_0 === _id_0), _action_0, ($$$$047$$$047$$$047application$058find$1260$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047readers$058finish$1260$(_flowId_0, _levelId_0, _pair_0) {
  const _t_0 = _pair_0["fst"];
  const _base_0 = _t_0["base"];
  const _t_1 = _pair_0["snd"];
  const _delivery_0 = _t_1["delivery"];
  const _outcome_0 = _t_1["outcome"];
  return $$$$047$$$047$$$047readers$058finished$1260$(_flowId_0, _levelId_0, _delivery_0, ($$$$047$$$047$$$047context$058finish$1260$({$: "Tuple", "fst": _base_0, "snd": _outcome_0})));
}

function $$$$047$$$047$$$047readers$058body$1260$(_fails_0, _ctx_0) {
  return $$$$047$$$047$$$047readers$058level_read$1260$(_fails_0, run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1262$(_ctx_0)));
}

function $public$045cleanup$045v1$047current$045core$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047$$$047$$$047provider$058pulse$1260$(_world_0) {
  return $$$$047$$$047$$$047provider$058map_resources$1260$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047provider$058pulse_resources$1260$(_x_0);
}), _world_0);
}

function $$$$047$$$047$$$047readers$058view$1260$(_reading_0) {
  const _values_0 = _reading_0["values"];
  const _lagged_0 = _reading_0["lagged"];
  return {$: "../../../readers.View", "values": _values_0, "lagged": _lagged_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058observe$1260$(_stream_0, _id_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058observe_position$1260$(($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _batches_0, _dropped_0, _id_0, _tick_0);
}

function $$$$047$$$047$$$047readers$058view$1261$(_reading_0) {
  const _values_0 = _reading_0["values"];
  const _lagged_0 = _reading_0["lagged"];
  return {$: "../../../readers.View", "values": _values_0, "lagged": _lagged_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058observe$1261$(_stream_0, _id_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058observe_position$1261$(($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _batches_0, _dropped_0, _id_0, _tick_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _registered_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058activation$(($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _positions_0, _id_0, _registered_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_outcome$1261$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (_outcome_0.$ === "public-cleanup-v1/current-core/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../src/ecs/schedule.Failed", "schedule": {$: "../../../../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "error": _error_0, "observations": ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}}))};
  } else {
    const _world_1 = _outcome_0["world"];
    return run_tail(_next_0(_owners_0)(_world_1), ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}})));
  }
}

function $$$$047$$$047$$$047application$058action$1261$(_owners_0, _world_0, _chosen_0) {
  if (_chosen_0.$ === "None") {
    return {$: "Tuple", "fst": _owners_0, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": "MissingScheduleAction"}};
  } else {
    const _t_0 = _chosen_0["value"];
    if (_t_0.$ === "../../../application.Body") {
      const _key_0 = _t_0["key"];
      const _name_0 = _t_0["name"];
      const _operation_0 = _t_0["operation"];
      return $$$$047$$$047$$$047application$058run_body$1261$(_owners_0, _world_0, _key_0, _name_0, _operation_0);
    } else if (_t_0.$ === "../../../application.Read") {
      const _key_1 = _t_0["key"];
      const _name_1 = _t_0["name"];
      const _fails_0 = _t_0["fails"];
      return $$$$047$$$047$$$047application$058run_reader$1261$(_owners_0, _world_0, _key_1, _name_1, _fails_0);
    } else if (_t_0.$ === "../../../application.GatedRead") {
      const _key_2 = _t_0["key"];
      const _name_2 = _t_0["name"];
      const _condition_0 = _t_0["condition"];
      return $$$$047$$$047$$$047application$058reader_checked$1261$(_owners_0, _key_2, _name_2, ($$$$047$$$047$$$047provider$058condition_world$1261$(_world_0, _condition_0)));
    } else if (_t_0.$ === "../../../application.Gate") {
      const _key_3 = _t_0["key"];
      const _name_3 = _t_0["name"];
      const _condition_1 = _t_0["condition"];
      return $$$$047$$$047$$$047application$058gate_checked$1261$(_owners_0, _key_3, _name_3, ($$$$047$$$047$$$047provider$058condition_world$1261$(_world_0, _condition_1)));
    } else if (_t_0.$ === "../../../application.Marker") {
      const _enabled_0 = _t_0["enabled"];
      return $$$$047$$$047$$$047application$058run_marker$1261$(_owners_0, _world_0, _enabled_0);
    } else {
      return {$: "Tuple", "fst": _owners_0, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Succeeded", "world": ($$$$047$$$047$$$047provider$058pulse$1261$(run_loop($public$045cleanup$045v1$047current$045core$047ecs$047world$058barrier$1261$(_world_0)))), "output": {$: "Unit"}}};
    }
  }
}

function $$$$047$$$047$$$047application$058find$1261$(_actions_0, _id_0) {
  if (_actions_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _action_0 = _actions_0["head"];
    const _rest_0 = _actions_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047application$058action_id$1261$(_action_0));
    return $$$$047$$$047$$$047application$058find_checked$1261$((_x_0 === _id_0), _action_0, ($$$$047$$$047$$$047application$058find$1261$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047readers$058finish$1261$(_flowId_0, _levelId_0, _pair_0) {
  const _t_0 = _pair_0["fst"];
  const _base_0 = _t_0["base"];
  const _t_1 = _pair_0["snd"];
  const _delivery_0 = _t_1["delivery"];
  const _outcome_0 = _t_1["outcome"];
  return $$$$047$$$047$$$047readers$058finished$1261$(_flowId_0, _levelId_0, _delivery_0, ($$$$047$$$047$$$047context$058finish$1261$({$: "Tuple", "fst": _base_0, "snd": _outcome_0})));
}

function $$$$047$$$047$$$047readers$058body$1261$(_fails_0, _ctx_0) {
  return $$$$047$$$047$$$047readers$058level_read$1261$(_fails_0, run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1265$(_ctx_0)));
}

function $public$045cleanup$045v1$047current$045core$047ecs$047transaction$058begin$1261$(_world_0) {
  return {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047$$$047$$$047provider$058pulse$1261$(_world_0) {
  return $$$$047$$$047$$$047provider$058map_resources$1261$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047provider$058pulse_resources$1261$(_x_0);
}), _world_0);
}

function $$$$047$$$047$$$047readers$058view$1262$(_reading_0) {
  const _values_0 = _reading_0["values"];
  const _lagged_0 = _reading_0["lagged"];
  return {$: "../../../readers.View", "values": _values_0, "lagged": _lagged_0};
}

function $$$$047$$$047$$$047readers$058view$1263$(_reading_0) {
  const _values_0 = _reading_0["values"];
  const _lagged_0 = _reading_0["lagged"];
  return {$: "../../../readers.View", "values": _values_0, "lagged": _lagged_0};
}

function $$$$047$$$047$$$047application$058run_body$1260$(_owners_0, _world_0, _key_0, _name_0, _operation_0) {
  const _users_0 = _owners_0["users"];
  const _hooks_0 = _owners_0["hooks"];
  const _readers_0 = _owners_0["readers"];
  const _attempts_0 = _owners_0["attempts"];
  const _deliveries_0 = _owners_0["deliveries"];
  const _conditions_0 = _owners_0["conditions"];
  const _active_0 = _owners_0["active"];
  return $$$$047$$$047$$$047application$058body_result$1260$({$: "../../../application.Owners", "users": {$: "../../../catalog.Catalog", "entries": {$: "Nil"}}, "hooks": _hooks_0, "readers": _readers_0, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, _operation_0, ($$$$047$$$047$$$047catalog$058invoke$1260$(_users_0, _world_0, _key_0, _name_0, {$: "Con", "head": "machine.Flow.read", "tail": {$: "Con", "head": "machine.Flow.next", "tail": {$: "Con", "head": "machine.Level.next", "tail": {$: "Con", "head": "component.cells.write", "tail": {$: "Con", "head": "resource.owned.write", "tail": {$: "Con", "head": "commands.spawn", "tail": {$: "Nil"}}}}}}}, _operation_0)));
}

function $$$$047$$$047$$$047application$058run_reader$1260$(_owners_0, _world_0, _key_0, _name_0, _fails_0) {
  const _users_0 = _owners_0["users"];
  const _hooks_0 = _owners_0["hooks"];
  const _readers_0 = _owners_0["readers"];
  const _attempts_0 = _owners_0["attempts"];
  const _deliveries_0 = _owners_0["deliveries"];
  const _conditions_0 = _owners_0["conditions"];
  const _active_0 = _owners_0["active"];
  return $$$$047$$$047$$$047application$058read_selected$1260$({$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": {$: "Nil"}, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, _world_0, _key_0, _name_0, _fails_0, ($$$$047$$$047$$$047slots$058take$1260$(_readers_0, _key_0)));
}

function $$$$047$$$047$$$047application$058reader_checked$1260$(_owners_0, _key_0, _name_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (_t_0.$ === "../../../provider.ConditionMissing") {
    return {$: "Tuple", "fst": _owners_0, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": "ConditionProvisionRejected"}};
  } else {
    const _t_1 = _t_0["passes"];
    if (!_t_1) {
      return $$$$047$$$047$$$047application$058skip_reader$1260$(_owners_0, _world_0, _key_0);
    } else {
      return $$$$047$$$047$$$047application$058run_reader$1260$(_owners_0, _world_0, _key_0, _name_0, false);
    }
  }
}

function $$$$047$$$047$$$047provider$058condition_world$1260$(_world_0, _tree_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _flowStream_0 = _t_0["flowStream"];
  const _levelStream_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _trace_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047provider$058condition_check$1260$(_tree_0, {$: "../../../provider.ConditionEnv", "flow": _flow_0, "level": _level_0}))};
}

function $$$$047$$$047$$$047application$058gate_checked$1260$(_owners_0, _key_0, _name_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (_t_0.$ === "../../../provider.ConditionMissing") {
    return {$: "Tuple", "fst": _owners_0, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": "ConditionProvisionRejected"}};
  } else {
    const _t_1 = _t_0["passes"];
    if (!_t_1) {
      return {$: "Tuple", "fst": _owners_0, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}}};
    } else {
      return $$$$047$$$047$$$047application$058gate_completed$1260$(_name_0, ($$$$047$$$047$$$047application$058run_body$1260$(_owners_0, _world_0, _key_0, _name_0, {$: "../../../gameplay.Noop"})));
    }
  }
}

function $$$$047$$$047$$$047application$058run_marker$1260$(_owners_0, _world_0, _enabled_0) {
  const _users_0 = _owners_0["users"];
  const _hooks_0 = _owners_0["hooks"];
  const _readers_0 = _owners_0["readers"];
  const _attempts_0 = _owners_0["attempts"];
  const _deliveries_0 = _owners_0["deliveries"];
  const _conditions_0 = _owners_0["conditions"];
  const _active_0 = _owners_0["active"];
  return $$$$047$$$047$$$047application$058marker_returned$1260$(_users_0, _readers_0, _attempts_0, _deliveries_0, _conditions_0, _active_0, run_loop($$$$047$$$047$$$047hooks$058run$1260$(_hooks_0, _world_0, _enabled_0)));
}

function $$$$047$$$047$$$047application$058find_checked$1260$(_same_0, _action_0, _tail_0) {
  if (_same_0) {
    return {$: "Some", "value": _action_0};
  } else {
    return _tail_0;
  }
}

function $$$$047$$$047$$$047readers$058finished$1260$(_flowId_0, _levelId_0, _delivery_0, _result_0) {
  if (_result_0.$ === "public-cleanup-v1/current-core/ecs/system.Succeeded") {
    const _world_0 = _result_0["world"];
    return {$: "public-cleanup-v1/current-core/ecs/system.Succeeded", "world": ($$$$047$$$047$$$047readers$058stream_completed$1260$(_world_0, _flowId_0, _levelId_0)), "output": _delivery_0};
  } else {
    const _world_1 = _result_0["world"];
    const _error_0 = _result_0["error"];
    return {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_1, "error": {$: "../../../readers.Failure", "message": _error_0, "delivery": {$: "Some", "value": _delivery_0}}};
  }
}

function $$$$047$$$047$$$047context$058finish$1260$(_pair_0) {
  const _t_0 = _pair_0["fst"];
  const _tx_0 = _t_0["tx"];
  const _error_0 = _t_0["error"];
  const _outcome_0 = _pair_0["snd"];
  return $$$$047$$$047$$$047context$058returned$1260$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, ($$$$047$$$047$$$047context$058effective$(_outcome_0, _error_0)))));
}

function $$$$047$$$047$$$047readers$058level_read$1260$(_fails_0, _pair_0) {
  const _ctx_0 = _pair_0["fst"];
  const _flow_0 = _pair_0["snd"];
  return $$$$047$$$047$$$047readers$058completed$1260$(_fails_0, _flow_0, run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1261$(_ctx_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1262$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1262$(($$$$047$$$047$$$047readers$058flow_cap$1260$(($$$$047$$$047$$$047readers$058work$1260$()))))), _ctx_0);
}

function $$$$047$$$047$$$047provider$058pulse_resources$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": nat_chk(_tick_0 + 1), "trace": _trace_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058observe_position$1260$(_position_0, _batches_0, _dropped_0, _id_0, _tick_0) {
  if (_position_0.$ === "None") {
    return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058reading$1260$({$: "public-cleanup-v1/current-core/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _tick_0}, _batches_0, _dropped_0);
  } else {
    const _position_1 = _position_0["value"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058reading$1260$(_position_1, _batches_0, _dropped_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _position_0 = _positions_0["head"];
    const _rest_0 = _positions_0["tail"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, ($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058lookup$(_rest_0, _id_0)));
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058observe_position$1261$(_position_0, _batches_0, _dropped_0, _id_0, _tick_0) {
  if (_position_0.$ === "None") {
    return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058reading$1261$({$: "public-cleanup-v1/current-core/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _tick_0}, _batches_0, _dropped_0);
  } else {
    const _position_1 = _position_0["value"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058reading$1261$(_position_1, _batches_0, _dropped_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058activation$(_position_0, _positions_0, _id_0, _registered_0) {
  if (_position_0.$ === "None") {
    return {$: "Con", "head": {$: "public-cleanup-v1/current-core/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _registered_0}, "tail": _positions_0};
  } else {
    return _positions_0;
  }
}

function $$$$047$$$047$$$047application$058run_body$1261$(_owners_0, _world_0, _key_0, _name_0, _operation_0) {
  const _users_0 = _owners_0["users"];
  const _hooks_0 = _owners_0["hooks"];
  const _readers_0 = _owners_0["readers"];
  const _attempts_0 = _owners_0["attempts"];
  const _deliveries_0 = _owners_0["deliveries"];
  const _conditions_0 = _owners_0["conditions"];
  const _active_0 = _owners_0["active"];
  return $$$$047$$$047$$$047application$058body_result$1261$({$: "../../../application.Owners", "users": {$: "../../../catalog.Catalog", "entries": {$: "Nil"}}, "hooks": _hooks_0, "readers": _readers_0, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, _operation_0, ($$$$047$$$047$$$047catalog$058invoke$1261$(_users_0, _world_0, _key_0, _name_0, {$: "Con", "head": "machine.Flow.read", "tail": {$: "Con", "head": "machine.Flow.next", "tail": {$: "Con", "head": "machine.Level.next", "tail": {$: "Con", "head": "component.cells.write", "tail": {$: "Con", "head": "resource.owned.write", "tail": {$: "Con", "head": "commands.spawn", "tail": {$: "Nil"}}}}}}}, _operation_0)));
}

function $$$$047$$$047$$$047application$058run_reader$1261$(_owners_0, _world_0, _key_0, _name_0, _fails_0) {
  const _users_0 = _owners_0["users"];
  const _hooks_0 = _owners_0["hooks"];
  const _readers_0 = _owners_0["readers"];
  const _attempts_0 = _owners_0["attempts"];
  const _deliveries_0 = _owners_0["deliveries"];
  const _conditions_0 = _owners_0["conditions"];
  const _active_0 = _owners_0["active"];
  return $$$$047$$$047$$$047application$058read_selected$1261$({$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": {$: "Nil"}, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, _world_0, _key_0, _name_0, _fails_0, ($$$$047$$$047$$$047slots$058take$1261$(_readers_0, _key_0)));
}

function $$$$047$$$047$$$047application$058reader_checked$1261$(_owners_0, _key_0, _name_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (_t_0.$ === "../../../provider.ConditionMissing") {
    return {$: "Tuple", "fst": _owners_0, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": "ConditionProvisionRejected"}};
  } else {
    const _t_1 = _t_0["passes"];
    if (!_t_1) {
      return $$$$047$$$047$$$047application$058skip_reader$1261$(_owners_0, _world_0, _key_0);
    } else {
      return $$$$047$$$047$$$047application$058run_reader$1261$(_owners_0, _world_0, _key_0, _name_0, false);
    }
  }
}

function $$$$047$$$047$$$047provider$058condition_world$1261$(_world_0, _tree_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _flowStream_0 = _t_0["flowStream"];
  const _levelStream_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _trace_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047provider$058condition_check$1261$(_tree_0, {$: "../../../provider.ConditionEnv", "flow": _flow_0, "level": _level_0}))};
}

function $$$$047$$$047$$$047application$058gate_checked$1261$(_owners_0, _key_0, _name_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (_t_0.$ === "../../../provider.ConditionMissing") {
    return {$: "Tuple", "fst": _owners_0, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": "ConditionProvisionRejected"}};
  } else {
    const _t_1 = _t_0["passes"];
    if (!_t_1) {
      return {$: "Tuple", "fst": _owners_0, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}}};
    } else {
      return $$$$047$$$047$$$047application$058gate_completed$1261$(_name_0, ($$$$047$$$047$$$047application$058run_body$1261$(_owners_0, _world_0, _key_0, _name_0, {$: "../../../gameplay.Noop"})));
    }
  }
}

function $$$$047$$$047$$$047application$058run_marker$1261$(_owners_0, _world_0, _enabled_0) {
  const _users_0 = _owners_0["users"];
  const _hooks_0 = _owners_0["hooks"];
  const _readers_0 = _owners_0["readers"];
  const _attempts_0 = _owners_0["attempts"];
  const _deliveries_0 = _owners_0["deliveries"];
  const _conditions_0 = _owners_0["conditions"];
  const _active_0 = _owners_0["active"];
  return $$$$047$$$047$$$047application$058marker_returned$1261$(_users_0, _readers_0, _attempts_0, _deliveries_0, _conditions_0, _active_0, run_loop($$$$047$$$047$$$047hooks$058run$1261$(_hooks_0, _world_0, _enabled_0)));
}

function $$$$047$$$047$$$047application$058find_checked$1261$(_same_0, _action_0, _tail_0) {
  if (_same_0) {
    return {$: "Some", "value": _action_0};
  } else {
    return _tail_0;
  }
}

function $$$$047$$$047$$$047readers$058finished$1261$(_flowId_0, _levelId_0, _delivery_0, _result_0) {
  if (_result_0.$ === "public-cleanup-v1/current-core/ecs/system.Succeeded") {
    const _world_0 = _result_0["world"];
    return {$: "public-cleanup-v1/current-core/ecs/system.Succeeded", "world": ($$$$047$$$047$$$047readers$058stream_completed$1261$(_world_0, _flowId_0, _levelId_0)), "output": _delivery_0};
  } else {
    const _world_1 = _result_0["world"];
    const _error_0 = _result_0["error"];
    return {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_1, "error": {$: "../../../readers.Failure", "message": _error_0, "delivery": {$: "Some", "value": _delivery_0}}};
  }
}

function $$$$047$$$047$$$047context$058finish$1261$(_pair_0) {
  const _t_0 = _pair_0["fst"];
  const _tx_0 = _t_0["tx"];
  const _error_0 = _t_0["error"];
  const _outcome_0 = _pair_0["snd"];
  return $$$$047$$$047$$$047context$058returned$1261$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, ($$$$047$$$047$$$047context$058effective$(_outcome_0, _error_0)))));
}

function $$$$047$$$047$$$047readers$058level_read$1261$(_fails_0, _pair_0) {
  const _ctx_0 = _pair_0["fst"];
  const _flow_0 = _pair_0["snd"];
  return $$$$047$$$047$$$047readers$058completed$1261$(_fails_0, _flow_0, run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1264$(_ctx_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1265$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1265$(($$$$047$$$047$$$047readers$058flow_cap$1261$(($$$$047$$$047$$$047readers$058work$1261$()))))), _ctx_0);
}

function $$$$047$$$047$$$047provider$058pulse_resources$1261$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": nat_chk(_tick_0 + 1), "trace": _trace_0};
}

function $$$$047$$$047$$$047application$058body_result$1260$(_rest_0, _operation_0, _result_0) {
  const _hooks_0 = _rest_0["hooks"];
  const _readers_0 = _rest_0["readers"];
  const _attempts_0 = _rest_0["attempts"];
  const _deliveries_0 = _rest_0["deliveries"];
  const _conditions_0 = _rest_0["conditions"];
  const _active_0 = _rest_0["active"];
  if (_result_0.$ === "../../../catalog.Completed") {
    const _users_0 = _result_0["catalog"];
    const _outcome_0 = _result_0["outcome"];
    return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": _readers_0, "attempts": ($$$$047$$$047$$$047application$058attempt$(_operation_0, _attempts_0)), "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, "snd": _outcome_0};
  } else {
    const _users_1 = _result_0["catalog"];
    const _world_0 = _result_0["world"];
    return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_1, "hooks": _hooks_0, "readers": _readers_0, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": "BodyRegistrationRejected"}};
  }
}

function $$$$047$$$047$$$047catalog$058invoke$1260$(_catalog_0, _world_0, _key_0, _name_0, _access_0, _args_0) {
  const _entries_0 = _catalog_0["entries"];
  return $$$$047$$$047$$$047catalog$058run_selected$1260$(($$$$047$$$047$$$047catalog$058select$1260$(_entries_0, _key_0)), _world_0, _key_0, _name_0, _access_0, _args_0);
}

function $$$$047$$$047$$$047application$058read_selected$1260$(_rest_0, _world_0, _key_0, _name_0, _fails_0, _selected_0) {
  const _t_0 = _selected_0["owner"];
  if (_t_0.$ === "Some") {
    const _instance_0 = _t_0["value"];
    const _entries_0 = _selected_0["rest"];
    return $$$$047$$$047$$$047application$058read_result$1260$(_rest_0, _key_0, _name_0, _entries_0, ($$$$047$$$047$$$047readers$058invoke$1260$(_instance_0, _world_0, _fails_0)));
  } else {
    const _entries_1 = _selected_0["rest"];
    return $$$$047$$$047$$$047application$058read_provisioned$1260$(_rest_0, _key_0, _name_0, _fails_0, _entries_1, ($$$$047$$$047$$$047readers$058provision$1260$(_world_0, _name_0)));
  }
}

function $$$$047$$$047$$$047slots$058take$1260$(_entries_0, _key_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "../../../slots.Selected", "owner": {$: "None"}, "rest": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _actual_0 = _t_0["key"];
    const _owner_0 = _t_0["owner"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047slots$058choose$1260$((_actual_0 === _key_0), {$: "../../../slots.Entry", "key": _actual_0, "owner": _owner_0}, ($$$$047$$$047$$$047slots$058take$1260$(_rest_0, _key_0)));
  }
}

function $$$$047$$$047$$$047application$058skip_reader$1260$(_owners_0, _world_0, _key_0) {
  const _users_0 = _owners_0["users"];
  const _hooks_0 = _owners_0["hooks"];
  const _readers_0 = _owners_0["readers"];
  const _attempts_0 = _owners_0["attempts"];
  const _deliveries_0 = _owners_0["deliveries"];
  const _conditions_0 = _owners_0["conditions"];
  const _active_0 = _owners_0["active"];
  return $$$$047$$$047$$$047application$058skip_selected$1260$({$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": {$: "Nil"}, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, _world_0, _key_0, ($$$$047$$$047$$$047slots$058take$1260$(_readers_0, _key_0)));
}

function $$$$047$$$047$$$047provider$058condition_check$1260$(_tree_0, _env_0) {
  return $$$$047$$$047$$$047provider$058condition_ready$1260$(($$$$047$$$047$$$047provider$058condition_provisioned$1260$(($$$$047$$$047$$$047provider$058condition_needs$1260$(_tree_0)), _env_0)), _tree_0, _env_0);
}

function $$$$047$$$047$$$047application$058gate_completed$1260$(_name_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _users_0 = _t_0["users"];
  const _hooks_0 = _t_0["hooks"];
  const _readers_0 = _t_0["readers"];
  const _attempts_0 = _t_0["attempts"];
  const _deliveries_0 = _t_0["deliveries"];
  const _conditions_0 = _t_0["conditions"];
  const _active_0 = _t_0["active"];
  const _t_1 = _result_0["snd"];
  if (_t_1.$ === "public-cleanup-v1/current-core/ecs/system.Succeeded") {
    const _world_0 = _t_1["world"];
    const _output_0 = _t_1["output"];
    return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": _readers_0, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": ($List$append$(_conditions_0, {$: "Con", "head": _name_0, "tail": {$: "Nil"}})), "active": _active_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Succeeded", "world": _world_0, "output": _output_0}};
  } else {
    return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": _readers_0, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, "snd": _t_1};
  }
}

function $$$$047$$$047$$$047application$058marker_returned$1260$(_users_0, _readers_0, _attempts_0, _deliveries_0, _conditions_0, _active_0, _pair_0) {
  const _hooks_0 = _pair_0["fst"];
  const _world_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": _readers_0, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}}};
}

function $$$$047$$$047$$$047hooks$058run$1260$(_owners_0, _world_0, _enabled_0) {
  return $$$$047$$$047$$$047hooks$058captured_marker$1260$(_owners_0, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058observe_resource$1260$(($$$$047$$$047$$$047provider$058pulse$1260$(run_loop($public$045cleanup$045v1$047current$045core$047ecs$047world$058barrier$1260$(_world_0)))))), _enabled_0);
}

function $$$$047$$$047$$$047readers$058stream_completed$1260$(_world_0, _flowId_0, _levelId_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _flowStream_0 = _t_0["flowStream"];
  const _levelStream_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _trace_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058complete$1260$(_flowStream_0, _flowId_0, _tick_0, true)), "levelStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058complete$1261$(_levelStream_0, _levelId_0, _tick_0, true)), "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047context$058returned$1260$(_result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "public-cleanup-v1/current-core/ecs/transaction.Success") {
    return {$: "public-cleanup-v1/current-core/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0);
}

function $$$$047$$$047$$$047context$058effective$(_outcome_0, _error_0) {
  if (_error_0.$ === "None") {
    return _outcome_0;
  } else {
    const _error_1 = _error_0["value"];
    return {$: "public-cleanup-v1/current-core/ecs/transaction.Failure", "error": _error_1};
  }
}

function $$$$047$$$047$$$047readers$058completed$1260$(_fails_0, _flow_0, _pair_0) {
  if (!_fails_0) {
    const _a_0 = _flow_0["values"];
    const _al_0 = _flow_0["lagged"];
    const _ctx_0 = _pair_0["fst"];
    const _t_0 = _pair_0["snd"];
    const _b_0 = _t_0["values"];
    const _bl_0 = _t_0["lagged"];
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "../../../readers.Completion", "delivery": {$: "../../../readers.Delivery", "flow": _a_0, "level": _b_0, "flowLagged": _al_0, "levelLagged": _bl_0}, "outcome": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}}};
  } else {
    const _a_1 = _flow_0["values"];
    const _al_1 = _flow_0["lagged"];
    const _ctx_1 = _pair_0["fst"];
    const _t_1 = _pair_0["snd"];
    const _b_1 = _t_1["values"];
    const _bl_1 = _t_1["lagged"];
    return {$: "Tuple", "fst": _ctx_1, "snd": {$: "../../../readers.Completion", "delivery": {$: "../../../readers.Delivery", "flow": _a_1, "level": _b_1, "flowLagged": _al_1, "levelLagged": _bl_1}, "outcome": {$: "public-cleanup-v1/current-core/ecs/transaction.Failure", "error": "reader-failed"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1261$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1261$(($$$$047$$$047$$$047readers$058level_cap$1260$(($$$$047$$$047$$$047readers$058work$1260$()))))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1262$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047readers$058flow_cap$1260$(_caps_0) {
  const _cap_0 = _caps_0["flow"];
  return _cap_0;
}

function $$$$047$$$047$$$047readers$058work$1260$() {
  return {$: "../../../readers.Work", "flow": {$: "../../../../../src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047readers$058read_flow$1260$(_x_0);
})}, "level": {$: "../../../../../src/ecs/capabilities.ValueRead", "get": run_clo((_x_1) => {
  return $$$$047$$$047$$$047readers$058read_level$1260$(_x_1);
})}};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058reading$1260$(_position_0, _batches_0, _dropped_0) {
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "public-cleanup-v1/current-core/ecs/event-runtime.Reading", "values": ($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, _fallback_0) {
  const _actual_0 = _position_0["id"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058choose_position$((_actual_0 === _id_0), {$: "public-cleanup-v1/current-core/ecs/event-runtime.Position", "id": _actual_0, "cursor": _cursor_0, "registeredAt": _registered_0}, _fallback_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058reading$1261$(_position_0, _batches_0, _dropped_0) {
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "public-cleanup-v1/current-core/ecs/event-runtime.Reading", "values": ($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058since$1261$(_batches_0, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $$$$047$$$047$$$047application$058body_result$1261$(_rest_0, _operation_0, _result_0) {
  const _hooks_0 = _rest_0["hooks"];
  const _readers_0 = _rest_0["readers"];
  const _attempts_0 = _rest_0["attempts"];
  const _deliveries_0 = _rest_0["deliveries"];
  const _conditions_0 = _rest_0["conditions"];
  const _active_0 = _rest_0["active"];
  if (_result_0.$ === "../../../catalog.Completed") {
    const _users_0 = _result_0["catalog"];
    const _outcome_0 = _result_0["outcome"];
    return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": _readers_0, "attempts": ($$$$047$$$047$$$047application$058attempt$(_operation_0, _attempts_0)), "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, "snd": _outcome_0};
  } else {
    const _users_1 = _result_0["catalog"];
    const _world_0 = _result_0["world"];
    return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_1, "hooks": _hooks_0, "readers": _readers_0, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": "BodyRegistrationRejected"}};
  }
}

function $$$$047$$$047$$$047catalog$058invoke$1261$(_catalog_0, _world_0, _key_0, _name_0, _access_0, _args_0) {
  const _entries_0 = _catalog_0["entries"];
  return $$$$047$$$047$$$047catalog$058run_selected$1261$(($$$$047$$$047$$$047catalog$058select$1261$(_entries_0, _key_0)), _world_0, _key_0, _name_0, _access_0, _args_0);
}

function $$$$047$$$047$$$047application$058read_selected$1261$(_rest_0, _world_0, _key_0, _name_0, _fails_0, _selected_0) {
  const _t_0 = _selected_0["owner"];
  if (_t_0.$ === "Some") {
    const _instance_0 = _t_0["value"];
    const _entries_0 = _selected_0["rest"];
    return $$$$047$$$047$$$047application$058read_result$1261$(_rest_0, _key_0, _name_0, _entries_0, ($$$$047$$$047$$$047readers$058invoke$1261$(_instance_0, _world_0, _fails_0)));
  } else {
    const _entries_1 = _selected_0["rest"];
    return $$$$047$$$047$$$047application$058read_provisioned$1261$(_rest_0, _key_0, _name_0, _fails_0, _entries_1, ($$$$047$$$047$$$047readers$058provision$1261$(_world_0, _name_0)));
  }
}

function $$$$047$$$047$$$047slots$058take$1261$(_entries_0, _key_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "../../../slots.Selected", "owner": {$: "None"}, "rest": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _actual_0 = _t_0["key"];
    const _owner_0 = _t_0["owner"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047slots$058choose$1261$((_actual_0 === _key_0), {$: "../../../slots.Entry", "key": _actual_0, "owner": _owner_0}, ($$$$047$$$047$$$047slots$058take$1261$(_rest_0, _key_0)));
  }
}

function $$$$047$$$047$$$047application$058skip_reader$1261$(_owners_0, _world_0, _key_0) {
  const _users_0 = _owners_0["users"];
  const _hooks_0 = _owners_0["hooks"];
  const _readers_0 = _owners_0["readers"];
  const _attempts_0 = _owners_0["attempts"];
  const _deliveries_0 = _owners_0["deliveries"];
  const _conditions_0 = _owners_0["conditions"];
  const _active_0 = _owners_0["active"];
  return $$$$047$$$047$$$047application$058skip_selected$1261$({$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": {$: "Nil"}, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, _world_0, _key_0, ($$$$047$$$047$$$047slots$058take$1261$(_readers_0, _key_0)));
}

function $$$$047$$$047$$$047provider$058condition_check$1261$(_tree_0, _env_0) {
  return $$$$047$$$047$$$047provider$058condition_ready$1261$(($$$$047$$$047$$$047provider$058condition_provisioned$1261$(($$$$047$$$047$$$047provider$058condition_needs$1261$(_tree_0)), _env_0)), _tree_0, _env_0);
}

function $$$$047$$$047$$$047application$058gate_completed$1261$(_name_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _users_0 = _t_0["users"];
  const _hooks_0 = _t_0["hooks"];
  const _readers_0 = _t_0["readers"];
  const _attempts_0 = _t_0["attempts"];
  const _deliveries_0 = _t_0["deliveries"];
  const _conditions_0 = _t_0["conditions"];
  const _active_0 = _t_0["active"];
  const _t_1 = _result_0["snd"];
  if (_t_1.$ === "public-cleanup-v1/current-core/ecs/system.Succeeded") {
    const _world_0 = _t_1["world"];
    const _output_0 = _t_1["output"];
    return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": _readers_0, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": ($List$append$(_conditions_0, {$: "Con", "head": _name_0, "tail": {$: "Nil"}})), "active": _active_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Succeeded", "world": _world_0, "output": _output_0}};
  } else {
    return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": _readers_0, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, "snd": _t_1};
  }
}

function $$$$047$$$047$$$047application$058marker_returned$1261$(_users_0, _readers_0, _attempts_0, _deliveries_0, _conditions_0, _active_0, _pair_0) {
  const _hooks_0 = _pair_0["fst"];
  const _world_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": _readers_0, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}}};
}

function $$$$047$$$047$$$047hooks$058run$1261$(_owners_0, _world_0, _enabled_0) {
  return $$$$047$$$047$$$047hooks$058captured_marker$1261$(_owners_0, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058observe_resource$1261$(($$$$047$$$047$$$047provider$058pulse$1261$(run_loop($public$045cleanup$045v1$047current$045core$047ecs$047world$058barrier$1261$(_world_0)))))), _enabled_0);
}

function $$$$047$$$047$$$047readers$058stream_completed$1261$(_world_0, _flowId_0, _levelId_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _flowStream_0 = _t_0["flowStream"];
  const _levelStream_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _trace_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058complete$1260$(_flowStream_0, _flowId_0, _tick_0, true)), "levelStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058complete$1261$(_levelStream_0, _levelId_0, _tick_0, true)), "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047context$058returned$1261$(_result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "public-cleanup-v1/current-core/ecs/transaction.Success") {
    return {$: "public-cleanup-v1/current-core/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, _outcome_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0);
}

function $$$$047$$$047$$$047readers$058completed$1261$(_fails_0, _flow_0, _pair_0) {
  if (!_fails_0) {
    const _a_0 = _flow_0["values"];
    const _al_0 = _flow_0["lagged"];
    const _ctx_0 = _pair_0["fst"];
    const _t_0 = _pair_0["snd"];
    const _b_0 = _t_0["values"];
    const _bl_0 = _t_0["lagged"];
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "../../../readers.Completion", "delivery": {$: "../../../readers.Delivery", "flow": _a_0, "level": _b_0, "flowLagged": _al_0, "levelLagged": _bl_0}, "outcome": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}}};
  } else {
    const _a_1 = _flow_0["values"];
    const _al_1 = _flow_0["lagged"];
    const _ctx_1 = _pair_0["fst"];
    const _t_1 = _pair_0["snd"];
    const _b_1 = _t_1["values"];
    const _bl_1 = _t_1["lagged"];
    return {$: "Tuple", "fst": _ctx_1, "snd": {$: "../../../readers.Completion", "delivery": {$: "../../../readers.Delivery", "flow": _a_1, "level": _b_1, "flowLagged": _al_1, "levelLagged": _bl_1}, "outcome": {$: "public-cleanup-v1/current-core/ecs/transaction.Failure", "error": "reader-failed"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1264$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1264$(($$$$047$$$047$$$047readers$058level_cap$1261$(($$$$047$$$047$$$047readers$058work$1261$()))))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1265$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047readers$058flow_cap$1261$(_caps_0) {
  const _cap_0 = _caps_0["flow"];
  return _cap_0;
}

function $$$$047$$$047$$$047readers$058work$1261$() {
  return {$: "../../../readers.Work", "flow": {$: "../../../../../src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047readers$058read_flow$1261$(_x_0);
})}, "level": {$: "../../../../../src/ecs/capabilities.ValueRead", "get": run_clo((_x_1) => {
  return $$$$047$$$047$$$047readers$058read_level$1261$(_x_1);
})}};
}

function $$$$047$$$047$$$047application$058attempt$(_operation_0, _rows_0) {
  if (_operation_0.$ === "../../../gameplay.Queue") {
    return $List$append$(_rows_0, {$: "Con", "head": "overwrite:Boot:Pause", "tail": {$: "Nil"}});
  } else if (_operation_0.$ === "../../../gameplay.Reset") {
    return $List$append$(_rows_0, {$: "Con", "head": "reset:none", "tail": {$: "Nil"}});
  } else if (_operation_0.$ === "../../../gameplay.FailingPublisher") {
    return $List$append$(_rows_0, {$: "Con", "head": "failed-publisher", "tail": {$: "Nil"}});
  } else {
    return _rows_0;
  }
}

function $$$$047$$$047$$$047catalog$058run_selected$1260$(_selected_0, _world_0, _key_0, _name_0, _access_0, _args_0) {
  if (_selected_0.$ === "../../../catalog.Found") {
    const _registry_0 = _selected_0["registry"];
    const _rest_0 = _selected_0["rest"];
    return $$$$047$$$047$$$047catalog$058returned$1260$(_key_0, _rest_0, ($public$045cleanup$045v1$047current$045core$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0)));
  } else {
    const _rest_1 = _selected_0["rest"];
    return $$$$047$$$047$$$047catalog$058registered$1260$(_key_0, _rest_1, _args_0, ($public$045cleanup$045v1$047current$045core$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0)));
  }
}

function $$$$047$$$047$$$047catalog$058select$1260$(_entries_0, _key_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "../../../catalog.Absent", "rest": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _actual_0 = _t_0["key"];
    const _registry_0 = _t_0["registry"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047catalog$058select_step$1260$((_actual_0 === _key_0), {$: "../../../catalog.Entry", "key": _actual_0, "registry": _registry_0}, ($$$$047$$$047$$$047catalog$058select$1260$(_rest_0, _key_0)));
  }
}

function $$$$047$$$047$$$047application$058read_result$1260$(_rest_0, _key_0, _name_0, _entries_0, _result_0) {
  const _users_0 = _rest_0["users"];
  const _hooks_0 = _rest_0["hooks"];
  const _attempts_0 = _rest_0["attempts"];
  const _deliveries_0 = _rest_0["deliveries"];
  const _conditions_0 = _rest_0["conditions"];
  const _active_0 = _rest_0["active"];
  const _instance_0 = _result_0["instance"];
  const _world_0 = _result_0["world"];
  const _report_0 = _result_0["delivery"];
  const _t_0 = _result_0["status"];
  if (_t_0 !== "") {
    const _t_1 = (_t_0.codePointAt(0) > 0xFFFF ? _t_0.slice(0, 2) : _t_0[0]);
    const _t_2 = _t_1.codePointAt(0);
    if (_t_2 == 111) {
      const _t_3 = (_t_0.codePointAt(0) > 0xFFFF ? _t_0.slice(2) : _t_0.slice(1));
      if (_t_3 !== "") {
        const _t_4 = (_t_3.codePointAt(0) > 0xFFFF ? _t_3.slice(0, 2) : _t_3[0]);
        const _t_5 = _t_4.codePointAt(0);
        if (_t_5 == 107) {
          const _t_6 = (_t_3.codePointAt(0) > 0xFFFF ? _t_3.slice(2) : _t_3.slice(1));
          if (_t_6 === "") {
            return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": {$: "Con", "head": {$: "../../../slots.Entry", "key": _key_0, "owner": _instance_0}, "tail": _entries_0}, "attempts": _attempts_0, "deliveries": ($$$$047$$$047$$$047application$058delivery$(_name_0, _report_0, _deliveries_0)), "conditions": _conditions_0, "active": _active_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}}};
          } else {
            return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": {$: "Con", "head": {$: "../../../slots.Entry", "key": _key_0, "owner": _instance_0}, "tail": _entries_0}, "attempts": _attempts_0, "deliveries": ($$$$047$$$047$$$047application$058delivery$(_name_0, _report_0, _deliveries_0)), "conditions": _conditions_0, "active": _active_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": ("o" + ("k" + _t_6))}};
          }
        } else {
          const _139_0 = u32_to_word(_t_5)["head"];
          const _140_0 = u32_to_word(_t_5)["tail"];
          const _136_0 = (_t_3.codePointAt(0) > 0xFFFF ? _t_3.slice(2) : _t_3.slice(1));
          return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": {$: "Con", "head": {$: "../../../slots.Entry", "key": _key_0, "owner": _instance_0}, "tail": _entries_0}, "attempts": _attempts_0, "deliveries": ($$$$047$$$047$$$047application$058delivery$(_name_0, _report_0, _deliveries_0)), "conditions": _conditions_0, "active": _active_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": ("o" + (char_new(word_to_u32({$: "WCon", "head": _139_0, "tail": _140_0})) + _136_0))}};
        }
      } else {
        return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": {$: "Con", "head": {$: "../../../slots.Entry", "key": _key_0, "owner": _instance_0}, "tail": _entries_0}, "attempts": _attempts_0, "deliveries": ($$$$047$$$047$$$047application$058delivery$(_name_0, _report_0, _deliveries_0)), "conditions": _conditions_0, "active": _active_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": ("o" + _t_3)}};
      }
    } else {
      const _71_0 = u32_to_word(_t_2)["head"];
      const _72_0 = u32_to_word(_t_2)["tail"];
      const _68_0 = (_t_0.codePointAt(0) > 0xFFFF ? _t_0.slice(2) : _t_0.slice(1));
      return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": {$: "Con", "head": {$: "../../../slots.Entry", "key": _key_0, "owner": _instance_0}, "tail": _entries_0}, "attempts": _attempts_0, "deliveries": ($$$$047$$$047$$$047application$058delivery$(_name_0, _report_0, _deliveries_0)), "conditions": _conditions_0, "active": _active_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": (char_new(word_to_u32({$: "WCon", "head": _71_0, "tail": _72_0})) + _68_0)}};
    }
  } else {
    return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": {$: "Con", "head": {$: "../../../slots.Entry", "key": _key_0, "owner": _instance_0}, "tail": _entries_0}, "attempts": _attempts_0, "deliveries": ($$$$047$$$047$$$047application$058delivery$(_name_0, _report_0, _deliveries_0)), "conditions": _conditions_0, "active": _active_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": _t_0}};
  }
}

function $$$$047$$$047$$$047application$058read_provisioned$1260$(_rest_0, _key_0, _name_0, _fails_0, _entries_0, _result_0) {
  if (_result_0.$ === "../../../readers.Provisioned") {
    const _world_0 = _result_0["world"];
    const _instance_0 = _result_0["instance"];
    return $$$$047$$$047$$$047application$058read_result$1260$(_rest_0, _key_0, _name_0, _entries_0, ($$$$047$$$047$$$047readers$058invoke$1260$(_instance_0, _world_0, _fails_0)));
  } else {
    const _world_1 = _result_0["world"];
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047application$058with_readers$1260$(_rest_0, _entries_0)), "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_1, "error": "ReaderProvisionRejected"}};
  }
}

function $$$$047$$$047$$$047slots$058choose$1260$(_same_0, _entry_0, _tail_0) {
  if (_same_0) {
    const _key_0 = _entry_0["key"];
    const _owner_0 = _entry_0["owner"];
    const _other_0 = _tail_0["owner"];
    const _rest_0 = _tail_0["rest"];
    return {$: "../../../slots.Selected", "owner": {$: "Some", "value": _owner_0}, "rest": ($$$$047$$$047$$$047slots$058restore$1260$(_key_0, _other_0, _rest_0))};
  } else {
    const _owner_1 = _tail_0["owner"];
    const _rest_1 = _tail_0["rest"];
    return {$: "../../../slots.Selected", "owner": _owner_1, "rest": {$: "Con", "head": _entry_0, "tail": _rest_1}};
  }
}

function $$$$047$$$047$$$047application$058skip_selected$1260$(_rest_0, _world_0, _key_0, _selected_0) {
  const _users_0 = _rest_0["users"];
  const _hooks_0 = _rest_0["hooks"];
  const __0 = _rest_0["readers"];
  const _attempts_0 = _rest_0["attempts"];
  const _deliveries_0 = _rest_0["deliveries"];
  const _conditions_0 = _rest_0["conditions"];
  const _active_0 = _rest_0["active"];
  const _t_0 = _selected_0["owner"];
  if (_t_0.$ === "Some") {
    const _instance_0 = _t_0["value"];
    const _entries_0 = _selected_0["rest"];
    return $$$$047$$$047$$$047application$058skip_returned$1260$({$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": __0, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, _key_0, _entries_0, ($$$$047$$$047$$$047readers$058skip$1260$(_instance_0, _world_0)));
  } else {
    const _entries_1 = _selected_0["rest"];
    return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": _entries_1, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}}};
  }
}

function $$$$047$$$047$$$047provider$058condition_ready$1260$(_ready_0, _tree_0, _env_0) {
  if (!_ready_0) {
    return {$: "../../../provider.ConditionMissing"};
  } else {
    return {$: "../../../provider.ConditionValue", "passes": run_loop($$$$047$$$047$$$047conditions$058evaluate$1260$(_tree_0, _env_0))};
  }
}

function $$$$047$$$047$$$047hooks$058captured_marker$1260$(_owners_0, _pair_0, _enabled_0) {
  const _world_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058run_owned_marker$1260$({$: "public-cleanup-v1/current-core/ecs/machine.OwnedMarker", "steps": {$: "Con", "head": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047hooks$058flow_step$1260$(_x_0, _x_1, _flow_0, _enabled_0);
});
}), "tail": {$: "Con", "head": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047hooks$058level_step$1260$(_x_2, _x_3, _level_0, _enabled_0);
});
}), "tail": {$: "Nil"}}}}, _owners_0, _world_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058observe_resource$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058observe_resource_finish$1260$(($$$$047$$$047$$$047marker$058capture_resource$1260$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058complete$1260$(_stream_0, _id_0, _tick_0, _success_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  if (_success_0) {
    return {$: "public-cleanup-v1/current-core/ecs/machine-stream.Stream", "batches": _batches_0, "positions": ($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _tick_0, false)), "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
  } else {
    return {$: "public-cleanup-v1/current-core/ecs/machine-stream.Stream", "batches": _batches_0, "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058complete$1261$(_stream_0, _id_0, _tick_0, _success_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  if (_success_0) {
    return {$: "public-cleanup-v1/current-core/ecs/machine-stream.Stream", "batches": _batches_0, "positions": ($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _tick_0, false)), "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
  } else {
    return {$: "public-cleanup-v1/current-core/ecs/machine-stream.Stream", "batches": _batches_0, "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1261$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047readers$058level_cap$1260$(_caps_0) {
  const _cap_0 = _caps_0["level"];
  return _cap_0;
}

function $$$$047$$$047$$$047readers$058read_flow$1260$(_frame_0) {
  const _base_0 = _frame_0["base"];
  const _flow_0 = _frame_0["flow"];
  const _level_0 = _frame_0["level"];
  return {$: "Tuple", "fst": {$: "../../../readers.Frame", "base": _base_0, "flow": _flow_0, "level": _level_0}, "snd": _flow_0};
}

function $$$$047$$$047$$$047readers$058read_level$1260$(_frame_0) {
  const _base_0 = _frame_0["base"];
  const _flow_0 = _frame_0["flow"];
  const _level_0 = _frame_0["level"];
  return {$: "Tuple", "fst": {$: "../../../readers.Frame", "base": _base_0, "flow": _flow_0, "level": _level_0}, "snd": _level_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058since_checked$1260$((_cursor_0 < _tick_0), _items_0, ($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058since$1260$(_rest_0, _cursor_0)));
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058choose_position$(_found_0, _position_0, _fallback_0) {
  if (!_found_0) {
    return _fallback_0;
  } else {
    return {$: "Some", "value": _position_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058since$1261$(_batches_0, _cursor_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058since_checked$1261$((_cursor_0 < _tick_0), _items_0, ($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058since$1261$(_rest_0, _cursor_0)));
  }
}

function $$$$047$$$047$$$047catalog$058run_selected$1261$(_selected_0, _world_0, _key_0, _name_0, _access_0, _args_0) {
  if (_selected_0.$ === "../../../catalog.Found") {
    const _registry_0 = _selected_0["registry"];
    const _rest_0 = _selected_0["rest"];
    return $$$$047$$$047$$$047catalog$058returned$1261$(_key_0, _rest_0, ($public$045cleanup$045v1$047current$045core$047ecs$047system$058run$1263$(_registry_0, _world_0, _args_0)));
  } else {
    const _rest_1 = _selected_0["rest"];
    return $$$$047$$$047$$$047catalog$058registered$1261$(_key_0, _rest_1, _args_0, ($public$045cleanup$045v1$047current$045core$047ecs$047system$058register$1263$(_world_0, _name_0, _access_0)));
  }
}

function $$$$047$$$047$$$047catalog$058select$1261$(_entries_0, _key_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "../../../catalog.Absent", "rest": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _actual_0 = _t_0["key"];
    const _registry_0 = _t_0["registry"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047catalog$058select_step$1261$((_actual_0 === _key_0), {$: "../../../catalog.Entry", "key": _actual_0, "registry": _registry_0}, ($$$$047$$$047$$$047catalog$058select$1261$(_rest_0, _key_0)));
  }
}

function $$$$047$$$047$$$047application$058read_result$1261$(_rest_0, _key_0, _name_0, _entries_0, _result_0) {
  const _users_0 = _rest_0["users"];
  const _hooks_0 = _rest_0["hooks"];
  const _attempts_0 = _rest_0["attempts"];
  const _deliveries_0 = _rest_0["deliveries"];
  const _conditions_0 = _rest_0["conditions"];
  const _active_0 = _rest_0["active"];
  const _instance_0 = _result_0["instance"];
  const _world_0 = _result_0["world"];
  const _report_0 = _result_0["delivery"];
  const _t_0 = _result_0["status"];
  if (_t_0 !== "") {
    const _t_1 = (_t_0.codePointAt(0) > 0xFFFF ? _t_0.slice(0, 2) : _t_0[0]);
    const _t_2 = _t_1.codePointAt(0);
    if (_t_2 == 111) {
      const _t_3 = (_t_0.codePointAt(0) > 0xFFFF ? _t_0.slice(2) : _t_0.slice(1));
      if (_t_3 !== "") {
        const _t_4 = (_t_3.codePointAt(0) > 0xFFFF ? _t_3.slice(0, 2) : _t_3[0]);
        const _t_5 = _t_4.codePointAt(0);
        if (_t_5 == 107) {
          const _t_6 = (_t_3.codePointAt(0) > 0xFFFF ? _t_3.slice(2) : _t_3.slice(1));
          if (_t_6 === "") {
            return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": {$: "Con", "head": {$: "../../../slots.Entry", "key": _key_0, "owner": _instance_0}, "tail": _entries_0}, "attempts": _attempts_0, "deliveries": ($$$$047$$$047$$$047application$058delivery$(_name_0, _report_0, _deliveries_0)), "conditions": _conditions_0, "active": _active_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}}};
          } else {
            return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": {$: "Con", "head": {$: "../../../slots.Entry", "key": _key_0, "owner": _instance_0}, "tail": _entries_0}, "attempts": _attempts_0, "deliveries": ($$$$047$$$047$$$047application$058delivery$(_name_0, _report_0, _deliveries_0)), "conditions": _conditions_0, "active": _active_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": ("o" + ("k" + _t_6))}};
          }
        } else {
          const _139_0 = u32_to_word(_t_5)["head"];
          const _140_0 = u32_to_word(_t_5)["tail"];
          const _136_0 = (_t_3.codePointAt(0) > 0xFFFF ? _t_3.slice(2) : _t_3.slice(1));
          return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": {$: "Con", "head": {$: "../../../slots.Entry", "key": _key_0, "owner": _instance_0}, "tail": _entries_0}, "attempts": _attempts_0, "deliveries": ($$$$047$$$047$$$047application$058delivery$(_name_0, _report_0, _deliveries_0)), "conditions": _conditions_0, "active": _active_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": ("o" + (char_new(word_to_u32({$: "WCon", "head": _139_0, "tail": _140_0})) + _136_0))}};
        }
      } else {
        return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": {$: "Con", "head": {$: "../../../slots.Entry", "key": _key_0, "owner": _instance_0}, "tail": _entries_0}, "attempts": _attempts_0, "deliveries": ($$$$047$$$047$$$047application$058delivery$(_name_0, _report_0, _deliveries_0)), "conditions": _conditions_0, "active": _active_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": ("o" + _t_3)}};
      }
    } else {
      const _71_0 = u32_to_word(_t_2)["head"];
      const _72_0 = u32_to_word(_t_2)["tail"];
      const _68_0 = (_t_0.codePointAt(0) > 0xFFFF ? _t_0.slice(2) : _t_0.slice(1));
      return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": {$: "Con", "head": {$: "../../../slots.Entry", "key": _key_0, "owner": _instance_0}, "tail": _entries_0}, "attempts": _attempts_0, "deliveries": ($$$$047$$$047$$$047application$058delivery$(_name_0, _report_0, _deliveries_0)), "conditions": _conditions_0, "active": _active_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": (char_new(word_to_u32({$: "WCon", "head": _71_0, "tail": _72_0})) + _68_0)}};
    }
  } else {
    return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": {$: "Con", "head": {$: "../../../slots.Entry", "key": _key_0, "owner": _instance_0}, "tail": _entries_0}, "attempts": _attempts_0, "deliveries": ($$$$047$$$047$$$047application$058delivery$(_name_0, _report_0, _deliveries_0)), "conditions": _conditions_0, "active": _active_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": _t_0}};
  }
}

function $$$$047$$$047$$$047application$058read_provisioned$1261$(_rest_0, _key_0, _name_0, _fails_0, _entries_0, _result_0) {
  if (_result_0.$ === "../../../readers.Provisioned") {
    const _world_0 = _result_0["world"];
    const _instance_0 = _result_0["instance"];
    return $$$$047$$$047$$$047application$058read_result$1261$(_rest_0, _key_0, _name_0, _entries_0, ($$$$047$$$047$$$047readers$058invoke$1261$(_instance_0, _world_0, _fails_0)));
  } else {
    const _world_1 = _result_0["world"];
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047application$058with_readers$1261$(_rest_0, _entries_0)), "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_1, "error": "ReaderProvisionRejected"}};
  }
}

function $$$$047$$$047$$$047slots$058choose$1261$(_same_0, _entry_0, _tail_0) {
  if (_same_0) {
    const _key_0 = _entry_0["key"];
    const _owner_0 = _entry_0["owner"];
    const _other_0 = _tail_0["owner"];
    const _rest_0 = _tail_0["rest"];
    return {$: "../../../slots.Selected", "owner": {$: "Some", "value": _owner_0}, "rest": ($$$$047$$$047$$$047slots$058restore$1261$(_key_0, _other_0, _rest_0))};
  } else {
    const _owner_1 = _tail_0["owner"];
    const _rest_1 = _tail_0["rest"];
    return {$: "../../../slots.Selected", "owner": _owner_1, "rest": {$: "Con", "head": _entry_0, "tail": _rest_1}};
  }
}

function $$$$047$$$047$$$047application$058skip_selected$1261$(_rest_0, _world_0, _key_0, _selected_0) {
  const _users_0 = _rest_0["users"];
  const _hooks_0 = _rest_0["hooks"];
  const __0 = _rest_0["readers"];
  const _attempts_0 = _rest_0["attempts"];
  const _deliveries_0 = _rest_0["deliveries"];
  const _conditions_0 = _rest_0["conditions"];
  const _active_0 = _rest_0["active"];
  const _t_0 = _selected_0["owner"];
  if (_t_0.$ === "Some") {
    const _instance_0 = _t_0["value"];
    const _entries_0 = _selected_0["rest"];
    return $$$$047$$$047$$$047application$058skip_returned$1261$({$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": __0, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, _key_0, _entries_0, ($$$$047$$$047$$$047readers$058skip$1261$(_instance_0, _world_0)));
  } else {
    const _entries_1 = _selected_0["rest"];
    return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": _entries_1, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}}};
  }
}

function $$$$047$$$047$$$047provider$058condition_ready$1261$(_ready_0, _tree_0, _env_0) {
  if (!_ready_0) {
    return {$: "../../../provider.ConditionMissing"};
  } else {
    return {$: "../../../provider.ConditionValue", "passes": run_loop($$$$047$$$047$$$047conditions$058evaluate$1261$(_tree_0, _env_0))};
  }
}

function $$$$047$$$047$$$047hooks$058captured_marker$1261$(_owners_0, _pair_0, _enabled_0) {
  const _world_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058run_owned_marker$1261$({$: "public-cleanup-v1/current-core/ecs/machine.OwnedMarker", "steps": {$: "Con", "head": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047hooks$058flow_step$1261$(_x_0, _x_1, _flow_0, _enabled_0);
});
}), "tail": {$: "Con", "head": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047hooks$058level_step$1261$(_x_2, _x_3, _level_0, _enabled_0);
});
}), "tail": {$: "Nil"}}}}, _owners_0, _world_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058observe_resource$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058observe_resource_finish$1261$(($$$$047$$$047$$$047marker$058capture_resource$1261$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1264$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047readers$058level_cap$1261$(_caps_0) {
  const _cap_0 = _caps_0["level"];
  return _cap_0;
}

function $$$$047$$$047$$$047readers$058read_flow$1261$(_frame_0) {
  const _base_0 = _frame_0["base"];
  const _flow_0 = _frame_0["flow"];
  const _level_0 = _frame_0["level"];
  return {$: "Tuple", "fst": {$: "../../../readers.Frame", "base": _base_0, "flow": _flow_0, "level": _level_0}, "snd": _flow_0};
}

function $$$$047$$$047$$$047readers$058read_level$1261$(_frame_0) {
  const _base_0 = _frame_0["base"];
  const _flow_0 = _frame_0["flow"];
  const _level_0 = _frame_0["level"];
  return {$: "Tuple", "fst": {$: "../../../readers.Frame", "base": _base_0, "flow": _flow_0, "level": _level_0}, "snd": _level_0};
}

function $$$$047$$$047$$$047catalog$058returned$1260$(_key_0, _rest_0, _result_0) {
  if (_result_0.$ === "public-cleanup-v1/current-core/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return {$: "../../../catalog.Completed", "catalog": {$: "../../../catalog.Catalog", "entries": {$: "Con", "head": {$: "../../../catalog.Entry", "key": _key_0, "registry": _registry_0}, "tail": _rest_0}}, "outcome": _outcome_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../catalog.Refused", "catalog": {$: "../../../catalog.Catalog", "entries": {$: "Con", "head": {$: "../../../catalog.Entry", "key": _key_0, "registry": _registry_1}, "tail": _rest_0}}, "world": _world_0, "args": _args_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace$1260$(_registry_0, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047catalog$058registered$1260$(_key_0, _rest_0, _args_0, _result_0) {
  if (_result_0.$ === "public-cleanup-v1/current-core/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return $$$$047$$$047$$$047catalog$058returned$1260$(_key_0, _rest_0, ($public$045cleanup$045v1$047current$045core$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0)));
  } else {
    const _world_1 = _result_0["world"];
    return {$: "../../../catalog.Refused", "catalog": {$: "../../../catalog.Catalog", "entries": _rest_0}, "world": _world_1, "args": _args_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_namespace$1260$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047catalog$058select_step$1260$(_same_0, _entry_0, _tail_0) {
  if (_same_0) {
    const _key_0 = _entry_0["key"];
    const _registry_0 = _entry_0["registry"];
    return {$: "../../../catalog.Found", "registry": _registry_0, "rest": ($$$$047$$$047$$$047catalog$058restore_selected$1260$(_key_0, _tail_0))};
  } else {
    return $$$$047$$$047$$$047catalog$058selected_join$1260$(_entry_0, _tail_0);
  }
}

function $$$$047$$$047$$$047application$058with_readers$1260$(_owners_0, _entries_0) {
  const _users_0 = _owners_0["users"];
  const _hooks_0 = _owners_0["hooks"];
  const _attempts_0 = _owners_0["attempts"];
  const _deliveries_0 = _owners_0["deliveries"];
  const _conditions_0 = _owners_0["conditions"];
  const _active_0 = _owners_0["active"];
  return {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": _entries_0, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0};
}

function $$$$047$$$047$$$047slots$058restore$1260$(_key_0, _owner_0, _rest_0) {
  if (_owner_0.$ === "None") {
    return _rest_0;
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Con", "head": {$: "../../../slots.Entry", "key": _key_0, "owner": _owner_1}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047application$058skip_returned$1260$(_rest_0, _key_0, _entries_0, _pair_0) {
  const _users_0 = _rest_0["users"];
  const _hooks_0 = _rest_0["hooks"];
  const _attempts_0 = _rest_0["attempts"];
  const _deliveries_0 = _rest_0["deliveries"];
  const _conditions_0 = _rest_0["conditions"];
  const _active_0 = _rest_0["active"];
  const _instance_0 = _pair_0["fst"];
  const _world_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": {$: "Con", "head": {$: "../../../slots.Entry", "key": _key_0, "owner": _instance_0}, "tail": _entries_0}, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}}};
}

function $$$$047$$$047$$$047readers$058skip$1260$(_instance_0, _world_0) {
  const _registry_0 = _instance_0["registry"];
  const _t_0 = _instance_0["flow"];
  const _a_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _t_1 = _instance_0["level"];
  const _b_0 = _t_1["namespace"];
  const _jd_0 = _t_1["id"];
  return {$: "Tuple", "fst": {$: "../../../readers.Instance", "registry": _registry_0, "flow": {$: "public-cleanup-v1/current-core/ecs/machine-stream.Reader", "namespace": _a_0, "id": _id_0}, "level": {$: "public-cleanup-v1/current-core/ecs/machine-stream.Reader", "namespace": _b_0, "id": _jd_0}}, "snd": ($$$$047$$$047$$$047readers$058skipped_world$1260$(_world_0, _id_0, _jd_0))};
}

function $$$$047$$$047$$$047conditions$058evaluate$1260$(_tree_0, _env_0) {
  if (_tree_0.$ === "../../../conditions.Leaf") {
    const _atom_0 = _tree_0["atom"];
    return $$$$047$$$047$$$047provider$058condition_leaf$1260$(_atom_0, _env_0);
  } else if (_tree_0.$ === "../../../conditions.Constant") {
    const _value_0 = _tree_0["value"];
    return _value_0;
  } else if (_tree_0.$ === "../../../conditions.Negate") {
    const _inner_0 = _tree_0["inner"];
    return $Bool$not$(run_loop($$$$047$$$047$$$047conditions$058evaluate$1260$(_inner_0, _env_0)));
  } else if (_tree_0.$ === "../../../conditions.Both") {
    const _left_0 = _tree_0["left"];
    const _right_0 = _tree_0["right"];
    return $$$$047$$$047$$$047conditions$058both_next$1260$(run_loop($$$$047$$$047$$$047conditions$058evaluate$1260$(_left_0, _env_0)), _env_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047conditions$058evaluate$1260$(_right_0, _x_0);
}));
  } else {
    const _left_1 = _tree_0["left"];
    const _right_1 = _tree_0["right"];
    return $$$$047$$$047$$$047conditions$058either_next$1260$(run_loop($$$$047$$$047$$$047conditions$058evaluate$1260$(_left_1, _env_0)), _env_0, run_clo((_x_1) => {
  return $$$$047$$$047$$$047conditions$058evaluate$1260$(_right_1, _x_1);
}));
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058run_owned_marker$1260$(_marker_0, _owners_0, _world_0) {
  const _steps_0 = _marker_0["steps"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058owned_marker_steps$1260$(_steps_0, _owners_0, _world_0);
}

function $$$$047$$$047$$$047hooks$058flow_step$1260$(_owners_0, _world_0, _captured_0, _enabled_0) {
  return $$$$047$$$047$$$047hooks$058invoke_flow$1260$(_owners_0, ($$$$047$$$047$$$047provider$058flow_take$1260$(($$$$047$$$047$$$047marker$058flow_step$1260$(_world_0, _captured_0, false)))), _enabled_0);
}

function $$$$047$$$047$$$047hooks$058level_step$1260$(_owners_0, _world_0, _captured_0, _enabled_0) {
  return $$$$047$$$047$$$047hooks$058invoke_level$1260$(_owners_0, ($$$$047$$$047$$$047provider$058level_take$1260$(($$$$047$$$047$$$047marker$058level_step$1260$(_world_0, _captured_0, false)))), _enabled_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058observe_resource_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047marker$058capture_resource$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "Tuple", "fst": {$: "../../../provider.Resources", "owned": _owned_0, "flow": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058clear_changed$1260$(_flow_0)), "level": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058clear_changed$1261$(_level_0)), "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "snd": {$: "../../../marker.Captured", "flow": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058snapshot$1260$(_flow_0)), "level": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058snapshot$1261$(_level_0))}};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "public-cleanup-v1/current-core/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "public-cleanup-v1/current-core/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "public-cleanup-v1/current-core/ecs/transaction.Returned", "world": ($public$045cleanup$045v1$047current$045core$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "public-cleanup-v1/current-core/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058since_checked$1260$(_visible_0, _items_0, _rest_0) {
  if (!_visible_0) {
    return _rest_0;
  } else {
    return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058append$1260$(_items_0, _rest_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058since_checked$1261$(_visible_0, _items_0, _rest_0) {
  if (!_visible_0) {
    return _rest_0;
  } else {
    return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058append$1261$(_items_0, _rest_0);
  }
}

function $$$$047$$$047$$$047catalog$058returned$1261$(_key_0, _rest_0, _result_0) {
  if (_result_0.$ === "public-cleanup-v1/current-core/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return {$: "../../../catalog.Completed", "catalog": {$: "../../../catalog.Catalog", "entries": {$: "Con", "head": {$: "../../../catalog.Entry", "key": _key_0, "registry": _registry_0}, "tail": _rest_0}}, "outcome": _outcome_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../catalog.Refused", "catalog": {$: "../../../catalog.Catalog", "entries": {$: "Con", "head": {$: "../../../catalog.Entry", "key": _key_0, "registry": _registry_1}, "tail": _rest_0}}, "world": _world_0, "args": _args_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run$1263$(_registry_0, _world_0, _args_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace$1263$(_registry_0, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047catalog$058registered$1261$(_key_0, _rest_0, _args_0, _result_0) {
  if (_result_0.$ === "public-cleanup-v1/current-core/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return $$$$047$$$047$$$047catalog$058returned$1261$(_key_0, _rest_0, ($public$045cleanup$045v1$047current$045core$047ecs$047system$058run$1263$(_registry_0, _world_0, _args_0)));
  } else {
    const _world_1 = _result_0["world"];
    return {$: "../../../catalog.Refused", "catalog": {$: "../../../catalog.Catalog", "entries": _rest_0}, "world": _world_1, "args": _args_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register$1263$(_world_0, _name_0, _access_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_namespace$1263$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047catalog$058select_step$1261$(_same_0, _entry_0, _tail_0) {
  if (_same_0) {
    const _key_0 = _entry_0["key"];
    const _registry_0 = _entry_0["registry"];
    return {$: "../../../catalog.Found", "registry": _registry_0, "rest": ($$$$047$$$047$$$047catalog$058restore_selected$1261$(_key_0, _tail_0))};
  } else {
    return $$$$047$$$047$$$047catalog$058selected_join$1261$(_entry_0, _tail_0);
  }
}

function $$$$047$$$047$$$047application$058with_readers$1261$(_owners_0, _entries_0) {
  const _users_0 = _owners_0["users"];
  const _hooks_0 = _owners_0["hooks"];
  const _attempts_0 = _owners_0["attempts"];
  const _deliveries_0 = _owners_0["deliveries"];
  const _conditions_0 = _owners_0["conditions"];
  const _active_0 = _owners_0["active"];
  return {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": _entries_0, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0};
}

function $$$$047$$$047$$$047slots$058restore$1261$(_key_0, _owner_0, _rest_0) {
  if (_owner_0.$ === "None") {
    return _rest_0;
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Con", "head": {$: "../../../slots.Entry", "key": _key_0, "owner": _owner_1}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047application$058skip_returned$1261$(_rest_0, _key_0, _entries_0, _pair_0) {
  const _users_0 = _rest_0["users"];
  const _hooks_0 = _rest_0["hooks"];
  const _attempts_0 = _rest_0["attempts"];
  const _deliveries_0 = _rest_0["deliveries"];
  const _conditions_0 = _rest_0["conditions"];
  const _active_0 = _rest_0["active"];
  const _instance_0 = _pair_0["fst"];
  const _world_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../application.Owners", "users": _users_0, "hooks": _hooks_0, "readers": {$: "Con", "head": {$: "../../../slots.Entry", "key": _key_0, "owner": _instance_0}, "tail": _entries_0}, "attempts": _attempts_0, "deliveries": _deliveries_0, "conditions": _conditions_0, "active": _active_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}}};
}

function $$$$047$$$047$$$047readers$058skip$1261$(_instance_0, _world_0) {
  const _registry_0 = _instance_0["registry"];
  const _t_0 = _instance_0["flow"];
  const _a_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _t_1 = _instance_0["level"];
  const _b_0 = _t_1["namespace"];
  const _jd_0 = _t_1["id"];
  return {$: "Tuple", "fst": {$: "../../../readers.Instance", "registry": _registry_0, "flow": {$: "public-cleanup-v1/current-core/ecs/machine-stream.Reader", "namespace": _a_0, "id": _id_0}, "level": {$: "public-cleanup-v1/current-core/ecs/machine-stream.Reader", "namespace": _b_0, "id": _jd_0}}, "snd": ($$$$047$$$047$$$047readers$058skipped_world$1261$(_world_0, _id_0, _jd_0))};
}

function $$$$047$$$047$$$047conditions$058evaluate$1261$(_tree_0, _env_0) {
  if (_tree_0.$ === "../../../conditions.Leaf") {
    const _atom_0 = _tree_0["atom"];
    return $$$$047$$$047$$$047provider$058condition_leaf$1261$(_atom_0, _env_0);
  } else if (_tree_0.$ === "../../../conditions.Constant") {
    const _value_0 = _tree_0["value"];
    return _value_0;
  } else if (_tree_0.$ === "../../../conditions.Negate") {
    const _inner_0 = _tree_0["inner"];
    return $Bool$not$(run_loop($$$$047$$$047$$$047conditions$058evaluate$1261$(_inner_0, _env_0)));
  } else if (_tree_0.$ === "../../../conditions.Both") {
    const _left_0 = _tree_0["left"];
    const _right_0 = _tree_0["right"];
    return $$$$047$$$047$$$047conditions$058both_next$1261$(run_loop($$$$047$$$047$$$047conditions$058evaluate$1261$(_left_0, _env_0)), _env_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047conditions$058evaluate$1261$(_right_0, _x_0);
}));
  } else {
    const _left_1 = _tree_0["left"];
    const _right_1 = _tree_0["right"];
    return $$$$047$$$047$$$047conditions$058either_next$1261$(run_loop($$$$047$$$047$$$047conditions$058evaluate$1261$(_left_1, _env_0)), _env_0, run_clo((_x_1) => {
  return $$$$047$$$047$$$047conditions$058evaluate$1261$(_right_1, _x_1);
}));
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058run_owned_marker$1261$(_marker_0, _owners_0, _world_0) {
  const _steps_0 = _marker_0["steps"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058owned_marker_steps$1261$(_steps_0, _owners_0, _world_0);
}

function $$$$047$$$047$$$047hooks$058flow_step$1261$(_owners_0, _world_0, _captured_0, _enabled_0) {
  return $$$$047$$$047$$$047hooks$058invoke_flow$1261$(_owners_0, ($$$$047$$$047$$$047provider$058flow_take$1261$(($$$$047$$$047$$$047marker$058flow_step$1261$(_world_0, _captured_0, false)))), _enabled_0);
}

function $$$$047$$$047$$$047hooks$058level_step$1261$(_owners_0, _world_0, _captured_0, _enabled_0) {
  return $$$$047$$$047$$$047hooks$058invoke_level$1261$(_owners_0, ($$$$047$$$047$$$047provider$058level_take$1261$(($$$$047$$$047$$$047marker$058level_step$1261$(_world_0, _captured_0, false)))), _enabled_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058observe_resource_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047marker$058capture_resource$1261$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "Tuple", "fst": {$: "../../../provider.Resources", "owned": _owned_0, "flow": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058clear_changed$1262$(_flow_0)), "level": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058clear_changed$1263$(_level_0)), "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "snd": {$: "../../../marker.Captured", "flow": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058snapshot$1262$(_flow_0)), "level": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058snapshot$1263$(_level_0))}};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "public-cleanup-v1/current-core/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1261$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "public-cleanup-v1/current-core/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058publish$1261$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "public-cleanup-v1/current-core/ecs/transaction.Returned", "world": ($public$045cleanup$045v1$047current$045core$047ecs$047transaction$058rollback$1261$(_undo_0, _world_0)), "outcome": {$: "public-cleanup-v1/current-core/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_namespace$1260$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_join$1260$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047catalog$058restore_selected$1260$(_key_0, _selected_0) {
  if (_selected_0.$ === "../../../catalog.Found") {
    const _registry_0 = _selected_0["registry"];
    const _rest_0 = _selected_0["rest"];
    return {$: "Con", "head": {$: "../../../catalog.Entry", "key": _key_0, "registry": _registry_0}, "tail": _rest_0};
  } else {
    const _rest_1 = _selected_0["rest"];
    return _rest_1;
  }
}

function $$$$047$$$047$$$047catalog$058selected_join$1260$(_head_0, _selected_0) {
  if (_selected_0.$ === "../../../catalog.Found") {
    const _registry_0 = _selected_0["registry"];
    const _rest_0 = _selected_0["rest"];
    return {$: "../../../catalog.Found", "registry": _registry_0, "rest": {$: "Con", "head": _head_0, "tail": _rest_0}};
  } else {
    const _rest_1 = _selected_0["rest"];
    return {$: "../../../catalog.Absent", "rest": {$: "Con", "head": _head_0, "tail": _rest_1}};
  }
}

function $$$$047$$$047$$$047readers$058skipped_world$1260$(_world_0, _flowId_0, _levelId_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _flowStream_0 = _t_0["flowStream"];
  const _levelStream_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _trace_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058skip$1260$(_flowStream_0, _flowId_0, _tick_0)), "levelStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058skip$1261$(_levelStream_0, _levelId_0, _tick_0)), "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047provider$058condition_leaf$1260$(_atom_0, _env_0) {
  if (_atom_0.$ === "../../../provider.InFlow") {
    const _value_0 = _atom_0["value"];
    const _flow_0 = _env_0["flow"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058current_matches$1260$(_flow_0, _value_0);
  } else if (_atom_0.$ === "../../../provider.InLevel") {
    const _value_1 = _atom_0["value"];
    const _level_0 = _env_0["level"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058current_matches$1261$(_level_0, _value_1);
  } else if (_atom_0.$ === "../../../provider.FlowChanged") {
    const _flow_1 = _env_0["flow"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058changed$1260$(_flow_1);
  } else {
    const _level_1 = _env_0["level"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058changed$1261$(_level_1);
  }
}

function $$$$047$$$047$$$047conditions$058both_next$1260$(_first_0, _env_0, _next_0) {
  if (!_first_0) {
    return false;
  } else {
    return run_tail(_next_0, _env_0);
  }
}

function $$$$047$$$047$$$047conditions$058either_next$1260$(_first_0, _env_0, _next_0) {
  if (!_first_0) {
    return run_tail(_next_0, _env_0);
  } else {
    return true;
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058owned_marker_steps$1260$(_steps_0, _owners_0, _world_0) {
  if (_steps_0.$ === "Nil") {
    return {$: "Tuple", "fst": _owners_0, "snd": _world_0};
  } else {
    const _step_0 = _steps_0["head"];
    const _rest_0 = _steps_0["tail"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058marker_next$1260$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058owned_marker_steps$1260$(_rest_0, _x_0, _x_1);
});
}), _step_0(_owners_0)(_world_0));
  }
}

function $$$$047$$$047$$$047hooks$058invoke_flow$1260$(_owners_0, _checked_0, _enabled_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (_t_0.$ === "public-cleanup-v1/current-core/ecs/machine.Present") {
    const _t_1 = _t_0["current"];
    if (_t_1.$ === "../../../provider.Pause") {
      const _t_2 = _t_0["changed"];
      if (_t_2) {
        if (_enabled_0) {
          return $$$$047$$$047$$$047hooks$058hook_completed$1260$("Flow", ($$$$047$$$047$$$047hooks$058run_hook$1260$(_owners_0, _world_0, {$: "../../../gameplay.FlowEnter"})));
        } else {
          return {$: "Tuple", "fst": _owners_0, "snd": _world_0};
        }
      } else {
        return {$: "Tuple", "fst": _owners_0, "snd": _world_0};
      }
    } else {
      return {$: "Tuple", "fst": _owners_0, "snd": _world_0};
    }
  } else {
    return {$: "Tuple", "fst": _owners_0, "snd": _world_0};
  }
}

function $$$$047$$$047$$$047provider$058flow_take$1260$(_world_0) {
  return $$$$047$$$047$$$047world$058take$1260$(_world_0);
}

function $$$$047$$$047$$$047marker$058flow_step$1260$(_world_0, _captured_0, _hooks_0) {
  return $$$$047$$$047$$$047marker$058map_resource$1260$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047marker$058flow_resource$1260$(_x_0, _captured_0, _hooks_0);
}), _world_0);
}

function $$$$047$$$047$$$047hooks$058invoke_level$1260$(_owners_0, _checked_0, _enabled_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (_t_0.$ === "public-cleanup-v1/current-core/ecs/machine.Present") {
    const _t_1 = _t_0["current"];
    if (_t_1.$ === "../../../provider.Middle") {
      const _t_2 = _t_0["changed"];
      if (_t_2) {
        if (_enabled_0) {
          return $$$$047$$$047$$$047hooks$058hook_completed$1260$("Level", ($$$$047$$$047$$$047hooks$058run_hook$1260$(_owners_0, _world_0, {$: "../../../gameplay.LevelEnter"})));
        } else {
          return {$: "Tuple", "fst": _owners_0, "snd": _world_0};
        }
      } else {
        return {$: "Tuple", "fst": _owners_0, "snd": _world_0};
      }
    } else {
      return {$: "Tuple", "fst": _owners_0, "snd": _world_0};
    }
  } else {
    return {$: "Tuple", "fst": _owners_0, "snd": _world_0};
  }
}

function $$$$047$$$047$$$047provider$058level_take$1260$(_world_0) {
  return $$$$047$$$047$$$047world$058take$1261$(_world_0);
}

function $$$$047$$$047$$$047marker$058level_step$1260$(_world_0, _captured_0, _hooks_0) {
  return $$$$047$$$047$$$047marker$058map_resource$1260$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047marker$058level_resource$1260$(_x_0, _captured_0, _hooks_0);
}), _world_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058snapshot$1260$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Unscheduled"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058snapshot_pending$1260$(_pending_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058snapshot$1261$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Unscheduled"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058snapshot_pending$1261$(_pending_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$(_commands_0, _world_0);
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058publish$1260$(_world_0, _events_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058event_publish$1260$(_world_0, _events_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058append$1260$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058append_loop$1260$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058append$1261$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058append_loop$1261$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace$1263$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_value$1263$(_registry_0, _world_0, _actual_0, _args_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_namespace$1263$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_join$1263$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047catalog$058restore_selected$1261$(_key_0, _selected_0) {
  if (_selected_0.$ === "../../../catalog.Found") {
    const _registry_0 = _selected_0["registry"];
    const _rest_0 = _selected_0["rest"];
    return {$: "Con", "head": {$: "../../../catalog.Entry", "key": _key_0, "registry": _registry_0}, "tail": _rest_0};
  } else {
    const _rest_1 = _selected_0["rest"];
    return _rest_1;
  }
}

function $$$$047$$$047$$$047catalog$058selected_join$1261$(_head_0, _selected_0) {
  if (_selected_0.$ === "../../../catalog.Found") {
    const _registry_0 = _selected_0["registry"];
    const _rest_0 = _selected_0["rest"];
    return {$: "../../../catalog.Found", "registry": _registry_0, "rest": {$: "Con", "head": _head_0, "tail": _rest_0}};
  } else {
    const _rest_1 = _selected_0["rest"];
    return {$: "../../../catalog.Absent", "rest": {$: "Con", "head": _head_0, "tail": _rest_1}};
  }
}

function $$$$047$$$047$$$047readers$058skipped_world$1261$(_world_0, _flowId_0, _levelId_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _flowStream_0 = _t_0["flowStream"];
  const _levelStream_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _trace_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058skip$1260$(_flowStream_0, _flowId_0, _tick_0)), "levelStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058skip$1261$(_levelStream_0, _levelId_0, _tick_0)), "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047provider$058condition_leaf$1261$(_atom_0, _env_0) {
  if (_atom_0.$ === "../../../provider.InFlow") {
    const _value_0 = _atom_0["value"];
    const _flow_0 = _env_0["flow"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058current_matches$1262$(_flow_0, _value_0);
  } else if (_atom_0.$ === "../../../provider.InLevel") {
    const _value_1 = _atom_0["value"];
    const _level_0 = _env_0["level"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058current_matches$1263$(_level_0, _value_1);
  } else if (_atom_0.$ === "../../../provider.FlowChanged") {
    const _flow_1 = _env_0["flow"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058changed$1262$(_flow_1);
  } else {
    const _level_1 = _env_0["level"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058changed$1263$(_level_1);
  }
}

function $$$$047$$$047$$$047conditions$058both_next$1261$(_first_0, _env_0, _next_0) {
  if (!_first_0) {
    return false;
  } else {
    return run_tail(_next_0, _env_0);
  }
}

function $$$$047$$$047$$$047conditions$058either_next$1261$(_first_0, _env_0, _next_0) {
  if (!_first_0) {
    return run_tail(_next_0, _env_0);
  } else {
    return true;
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058owned_marker_steps$1261$(_steps_0, _owners_0, _world_0) {
  if (_steps_0.$ === "Nil") {
    return {$: "Tuple", "fst": _owners_0, "snd": _world_0};
  } else {
    const _step_0 = _steps_0["head"];
    const _rest_0 = _steps_0["tail"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058marker_next$1261$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058owned_marker_steps$1261$(_rest_0, _x_0, _x_1);
});
}), _step_0(_owners_0)(_world_0));
  }
}

function $$$$047$$$047$$$047hooks$058invoke_flow$1261$(_owners_0, _checked_0, _enabled_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (_t_0.$ === "public-cleanup-v1/current-core/ecs/machine.Present") {
    const _t_1 = _t_0["current"];
    if (_t_1.$ === "../../../provider.Pause") {
      const _t_2 = _t_0["changed"];
      if (_t_2) {
        if (_enabled_0) {
          return $$$$047$$$047$$$047hooks$058hook_completed$1261$("Flow", ($$$$047$$$047$$$047hooks$058run_hook$1261$(_owners_0, _world_0, {$: "../../../gameplay.FlowEnter"})));
        } else {
          return {$: "Tuple", "fst": _owners_0, "snd": _world_0};
        }
      } else {
        return {$: "Tuple", "fst": _owners_0, "snd": _world_0};
      }
    } else {
      return {$: "Tuple", "fst": _owners_0, "snd": _world_0};
    }
  } else {
    return {$: "Tuple", "fst": _owners_0, "snd": _world_0};
  }
}

function $$$$047$$$047$$$047provider$058flow_take$1261$(_world_0) {
  return $$$$047$$$047$$$047world$058take$1262$(_world_0);
}

function $$$$047$$$047$$$047marker$058flow_step$1261$(_world_0, _captured_0, _hooks_0) {
  return $$$$047$$$047$$$047marker$058map_resource$1261$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047marker$058flow_resource$1261$(_x_0, _captured_0, _hooks_0);
}), _world_0);
}

function $$$$047$$$047$$$047hooks$058invoke_level$1261$(_owners_0, _checked_0, _enabled_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (_t_0.$ === "public-cleanup-v1/current-core/ecs/machine.Present") {
    const _t_1 = _t_0["current"];
    if (_t_1.$ === "../../../provider.Middle") {
      const _t_2 = _t_0["changed"];
      if (_t_2) {
        if (_enabled_0) {
          return $$$$047$$$047$$$047hooks$058hook_completed$1261$("Level", ($$$$047$$$047$$$047hooks$058run_hook$1261$(_owners_0, _world_0, {$: "../../../gameplay.LevelEnter"})));
        } else {
          return {$: "Tuple", "fst": _owners_0, "snd": _world_0};
        }
      } else {
        return {$: "Tuple", "fst": _owners_0, "snd": _world_0};
      }
    } else {
      return {$: "Tuple", "fst": _owners_0, "snd": _world_0};
    }
  } else {
    return {$: "Tuple", "fst": _owners_0, "snd": _world_0};
  }
}

function $$$$047$$$047$$$047provider$058level_take$1261$(_world_0) {
  return $$$$047$$$047$$$047world$058take$1263$(_world_0);
}

function $$$$047$$$047$$$047marker$058level_step$1261$(_world_0, _captured_0, _hooks_0) {
  return $$$$047$$$047$$$047marker$058map_resource$1261$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047marker$058level_resource$1261$(_x_0, _captured_0, _hooks_0);
}), _world_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058snapshot$1262$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Unscheduled"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058snapshot_pending$1260$(_pending_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058snapshot$1263$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Unscheduled"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058snapshot_pending$1261$(_pending_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1261$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1261$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058publish$1261$(_world_0, _events_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058event_publish$1261$(_world_0, _events_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047transaction$058rollback$1261$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_join$1260$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058skip$1260$(_stream_0, _id_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return {$: "public-cleanup-v1/current-core/ecs/machine-stream.Stream", "batches": _batches_0, "positions": ($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _tick_0, false)), "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058skip$1261$(_stream_0, _id_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return {$: "public-cleanup-v1/current-core/ecs/machine-stream.Stream", "batches": _batches_0, "positions": ($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _tick_0, false)), "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058current_matches$1260$(_slot_0, _value_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return false;
  } else {
    const _current_0 = _slot_0["current"];
    return $$$$047$$$047$$$047provider$058flow_same$(_current_0, _value_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058current_matches$1261$(_slot_0, _value_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return false;
  } else {
    const _current_0 = _slot_0["current"];
    return $$$$047$$$047$$$047provider$058level_same$(_current_0, _value_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058changed$1260$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return false;
  } else {
    const _flag_0 = _slot_0["changed"];
    return _flag_0;
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058changed$1261$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return false;
  } else {
    const _flag_0 = _slot_0["changed"];
    return _flag_0;
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058marker_next$1260$(_next_0, _pair_0) {
  const _owners_0 = _pair_0["fst"];
  const _world_0 = _pair_0["snd"];
  return run_tail(_next_0(_owners_0), _world_0);
}

function $$$$047$$$047$$$047hooks$058hook_completed$1260$(_label_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "public-cleanup-v1/current-core/ecs/system.Succeeded") {
    const _world_0 = _t_0["world"];
    return {$: "Tuple", "fst": _owners_0, "snd": ($$$$047$$$047$$$047hooks$058trace$1260$(_label_0, _world_0))};
  } else {
    const _world_1 = _t_0["world"];
    const _error_0 = _t_0["error"];
    return {$: "Tuple", "fst": _owners_0, "snd": ($$$$047$$$047$$$047hooks$058trace$1260$(("HOOK_FAILED:" + _error_0), _world_1))};
  }
}

function $$$$047$$$047$$$047hooks$058run_hook$1260$(_owners_0, _world_0, _operation_0) {
  const _flow_0 = _owners_0["flow"];
  const _level_0 = _owners_0["level"];
  if (_operation_0.$ === "../../../gameplay.FlowEnter") {
    return $$$$047$$$047$$$047hooks$058run_result$1260$(_level_0, true, ($public$045cleanup$045v1$047current$045core$047ecs$047system$058run$1262$(_flow_0, _world_0, {$: "../../../gameplay.FlowEnter"})));
  } else {
    return $$$$047$$$047$$$047hooks$058run_result$1260$(_flow_0, false, ($public$045cleanup$045v1$047current$045core$047ecs$047system$058run$1262$(_level_0, _world_0, {$: "../../../gameplay.LevelEnter"})));
  }
}

function $$$$047$$$047$$$047world$058take$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047world$058take_join$1260$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, ($$$$047$$$047$$$047provider$058flow_take_resource$1260$(_resources_0)), _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047$$$047$$$047marker$058map_resource$1260$(_effect_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _effect_0(_resources_0), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047marker$058flow_resource$1260$(_resources_0, _captured_0, _hooks_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return $$$$047$$$047$$$047marker$058flow_applied$1260$({$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_snapshot$1260$(_flow_0, _captured_0)), _hooks_0);
}

function $$$$047$$$047$$$047world$058take$1261$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047world$058take_join$1261$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, ($$$$047$$$047$$$047provider$058level_take_resource$1260$(_resources_0)), _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047$$$047$$$047marker$058level_resource$1260$(_resources_0, _captured_0, _hooks_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return $$$$047$$$047$$$047marker$058level_applied$1260$({$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_snapshot$1261$(_level_0, _captured_0)), _hooks_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058snapshot_pending$1260$(_pending_0) {
  if (_pending_0.$ === "public-cleanup-v1/current-core/ecs/machine.NoPending") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Unscheduled"};
  } else {
    const _value_0 = _pending_0["value"];
    const _skipSame_0 = _pending_0["skipSame"];
    return {$: "public-cleanup-v1/current-core/ecs/machine.Scheduled", "value": _value_0, "skipSame": _skipSame_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058snapshot_pending$1261$(_pending_0) {
  if (_pending_0.$ === "public-cleanup-v1/current-core/ecs/machine.NoPending") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Unscheduled"};
  } else {
    const _value_0 = _pending_0["value"];
    const _skipSame_0 = _pending_0["skipSame"];
    return {$: "public-cleanup-v1/current-core/ecs/machine.Scheduled", "value": _value_0, "skipSame": _skipSame_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($public$045cleanup$045v1$047current$045core$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_value$1263$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_checked$1263$((_namespace_0 === _actual_0), {$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_join$1263$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_meta$1263$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058current_matches$1262$(_slot_0, _value_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return false;
  } else {
    const _current_0 = _slot_0["current"];
    return $$$$047$$$047$$$047provider$058flow_same$(_current_0, _value_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058current_matches$1263$(_slot_0, _value_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return false;
  } else {
    const _current_0 = _slot_0["current"];
    return $$$$047$$$047$$$047provider$058level_same$(_current_0, _value_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058changed$1262$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return false;
  } else {
    const _flag_0 = _slot_0["changed"];
    return _flag_0;
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058changed$1263$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return false;
  } else {
    const _flag_0 = _slot_0["changed"];
    return _flag_0;
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058marker_next$1261$(_next_0, _pair_0) {
  const _owners_0 = _pair_0["fst"];
  const _world_0 = _pair_0["snd"];
  return run_tail(_next_0(_owners_0), _world_0);
}

function $$$$047$$$047$$$047hooks$058hook_completed$1261$(_label_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "public-cleanup-v1/current-core/ecs/system.Succeeded") {
    const _world_0 = _t_0["world"];
    return {$: "Tuple", "fst": _owners_0, "snd": ($$$$047$$$047$$$047hooks$058trace$1261$(_label_0, _world_0))};
  } else {
    const _world_1 = _t_0["world"];
    const _error_0 = _t_0["error"];
    return {$: "Tuple", "fst": _owners_0, "snd": ($$$$047$$$047$$$047hooks$058trace$1261$(("HOOK_FAILED:" + _error_0), _world_1))};
  }
}

function $$$$047$$$047$$$047hooks$058run_hook$1261$(_owners_0, _world_0, _operation_0) {
  const _flow_0 = _owners_0["flow"];
  const _level_0 = _owners_0["level"];
  if (_operation_0.$ === "../../../gameplay.FlowEnter") {
    return $$$$047$$$047$$$047hooks$058run_result$1261$(_level_0, true, ($public$045cleanup$045v1$047current$045core$047ecs$047system$058run$1265$(_flow_0, _world_0, {$: "../../../gameplay.FlowEnter"})));
  } else {
    return $$$$047$$$047$$$047hooks$058run_result$1261$(_flow_0, false, ($public$045cleanup$045v1$047current$045core$047ecs$047system$058run$1265$(_level_0, _world_0, {$: "../../../gameplay.LevelEnter"})));
  }
}

function $$$$047$$$047$$$047world$058take$1262$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047world$058take_join$1262$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, ($$$$047$$$047$$$047provider$058flow_take_resource$1261$(_resources_0)), _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047$$$047$$$047marker$058map_resource$1261$(_effect_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _effect_0(_resources_0), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047marker$058flow_resource$1261$(_resources_0, _captured_0, _hooks_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return $$$$047$$$047$$$047marker$058flow_applied$1261$({$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_snapshot$1262$(_flow_0, _captured_0)), _hooks_0);
}

function $$$$047$$$047$$$047world$058take$1263$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047world$058take_join$1263$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, ($$$$047$$$047$$$047provider$058level_take_resource$1261$(_resources_0)), _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047$$$047$$$047marker$058level_resource$1261$(_resources_0, _captured_0, _hooks_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return $$$$047$$$047$$$047marker$058level_applied$1261$({$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_snapshot$1263$(_level_0, _captured_0)), _hooks_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1261$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($public$045cleanup$045v1$047current$045core$047ecs$047world$058enqueue$1261$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058event_publish$1261$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047world$058event_publish_nonempty$1261$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "public-cleanup-v1/current-core/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_metadata$1260$({$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "public-cleanup-v1/current-core/ecs/world.RegistrationRejected") {
    return {$: "public-cleanup-v1/current-core/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "public-cleanup-v1/current-core/ecs/system.Registered", "world": _world_0, "registry": {$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047provider$058flow_same$(_a_0, _b_0) {
  if (_a_0.$ === "../../../provider.Boot") {
    if (_b_0.$ === "../../../provider.Boot") {
      return true;
    } else {
      return false;
    }
  } else if (_a_0.$ === "../../../provider.Play") {
    if (_b_0.$ === "../../../provider.Play") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_b_0.$ === "../../../provider.Pause") {
      return true;
    } else {
      return false;
    }
  }
}

function $$$$047$$$047$$$047provider$058level_same$(_a_0, _b_0) {
  if (_a_0.$ === "../../../provider.Low") {
    if (_b_0.$ === "../../../provider.Low") {
      return true;
    } else {
      return false;
    }
  } else if (_a_0.$ === "../../../provider.Middle") {
    if (_b_0.$ === "../../../provider.Middle") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_b_0.$ === "../../../provider.High") {
      return true;
    } else {
      return false;
    }
  }
}

function $$$$047$$$047$$$047hooks$058trace$1260$(_label_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _flowStream_0 = _t_0["flowStream"];
  const _levelStream_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _rows_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": ($List$append$(_rows_0, {$: "Con", "head": _label_0, "tail": {$: "Nil"}}))}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047hooks$058run_result$1260$(_other_0, _isFlow_0, _result_0) {
  if (_isFlow_0) {
    if (_result_0.$ === "public-cleanup-v1/current-core/ecs/system.Completed") {
      const _actual_0 = _result_0["registry"];
      const _outcome_0 = _result_0["outcome"];
      return {$: "Tuple", "fst": {$: "../../../hooks.Owners", "flow": _actual_0, "level": _other_0}, "snd": _outcome_0};
    } else {
      const _actual_1 = _result_0["registry"];
      const _world_0 = _result_0["world"];
      return {$: "Tuple", "fst": {$: "../../../hooks.Owners", "flow": _actual_1, "level": _other_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": "HookRegistrationRejected"}};
    }
  } else {
    if (_result_0.$ === "public-cleanup-v1/current-core/ecs/system.Completed") {
      const _actual_2 = _result_0["registry"];
      const _outcome_1 = _result_0["outcome"];
      return {$: "Tuple", "fst": {$: "../../../hooks.Owners", "flow": _other_0, "level": _actual_2}, "snd": _outcome_1};
    } else {
      const _actual_3 = _result_0["registry"];
      const _world_1 = _result_0["world"];
      return {$: "Tuple", "fst": {$: "../../../hooks.Owners", "flow": _other_0, "level": _actual_3}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_1, "error": "HookRegistrationRejected"}};
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run$1262$(_registry_0, _world_0, _args_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace$1262$(_registry_0, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047world$058take_join$1260$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _split_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _resources_0 = _split_0["fst"];
  const _slot_0 = _split_0["snd"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _slot_0};
}

function $$$$047$$$047$$$047provider$058flow_take_resource$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "Tuple", "fst": {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "snd": _flow_0};
}

function $$$$047$$$047$$$047marker$058flow_applied$1260$(_resources_0, _result_0, _hooks_0) {
  const _owned_0 = _resources_0["owned"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  const _slot_0 = _result_0["slot"];
  const _t_0 = _result_0["event"];
  if (_t_0.$ === "None") {
    return {$: "../../../provider.Resources", "owned": _owned_0, "flow": _slot_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0};
  } else {
    const _event_0 = _t_0["value"];
    if (!_hooks_0) {
      return {$: "../../../provider.Resources", "owned": _owned_0, "flow": _slot_0, "level": _level_0, "flowStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058publish$1260$(_flowStream_0, nat_chk(_tick_0 + 1), _event_0)), "levelStream": _levelStream_0, "frame": _frame_0, "tick": nat_chk(_tick_0 + 1), "trace": _trace_0};
    } else {
      return $$$$047$$$047$$$047marker$058flow_published$1260$(_owned_0, ($$$$047$$$047$$$047marker$058flow_hook$1260$(_slot_0, _level_0)), ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058publish$1260$(_flowStream_0, nat_chk(_tick_0 + 1), _event_0)), _levelStream_0, _frame_0, nat_chk(_tick_0 + 1), _trace_0);
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_snapshot$1260$(_slot_0, _captured_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    if (_captured_0.$ === "public-cleanup-v1/current-core/ecs/machine.Unscheduled") {
      return {$: "public-cleanup-v1/current-core/ecs/machine.Applied", "slot": {$: "public-cleanup-v1/current-core/ecs/machine.Missing"}, "event": {$: "None"}};
    } else {
      return {$: "public-cleanup-v1/current-core/ecs/machine.Applied", "slot": {$: "public-cleanup-v1/current-core/ecs/machine.Missing"}, "event": {$: "None"}};
    }
  } else {
    const _current_0 = _slot_0["current"];
    const __2 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    if (_captured_0.$ === "public-cleanup-v1/current-core/ecs/machine.Unscheduled") {
      return {$: "public-cleanup-v1/current-core/ecs/machine.Applied", "slot": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _current_0, "pending": __2, "previous": _previous_0, "changed": _changed_0}, "event": {$: "None"}};
    } else {
      const _value_0 = _captured_0["value"];
      const _skipSame_0 = _captured_0["skipSame"];
      return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_present$1260$(_current_0, _value_0, _previous_0, _changed_0, _skipSame_0);
    }
  }
}

function $$$$047$$$047$$$047world$058take_join$1261$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _split_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _resources_0 = _split_0["fst"];
  const _slot_0 = _split_0["snd"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _slot_0};
}

function $$$$047$$$047$$$047provider$058level_take_resource$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "Tuple", "fst": {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "snd": _level_0};
}

function $$$$047$$$047$$$047marker$058level_applied$1260$(_resources_0, _result_0, _hooks_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  const _slot_0 = _result_0["slot"];
  const _t_0 = _result_0["event"];
  if (_t_0.$ === "None") {
    return {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _slot_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0};
  } else {
    const _event_0 = _t_0["value"];
    if (!_hooks_0) {
      return {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _slot_0, "flowStream": _flowStream_0, "levelStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058publish$1261$(_levelStream_0, nat_chk(_tick_0 + 1), _event_0)), "frame": _frame_0, "tick": nat_chk(_tick_0 + 1), "trace": _trace_0};
    } else {
      return $$$$047$$$047$$$047marker$058level_published$1260$(_owned_0, ($$$$047$$$047$$$047marker$058level_hook$1260$(_flow_0, _slot_0)), _flowStream_0, ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058publish$1261$(_levelStream_0, nat_chk(_tick_0 + 1), _event_0)), _frame_0, nat_chk(_tick_0 + 1), _trace_0);
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_snapshot$1261$(_slot_0, _captured_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    if (_captured_0.$ === "public-cleanup-v1/current-core/ecs/machine.Unscheduled") {
      return {$: "public-cleanup-v1/current-core/ecs/machine.Applied", "slot": {$: "public-cleanup-v1/current-core/ecs/machine.Missing"}, "event": {$: "None"}};
    } else {
      return {$: "public-cleanup-v1/current-core/ecs/machine.Applied", "slot": {$: "public-cleanup-v1/current-core/ecs/machine.Missing"}, "event": {$: "None"}};
    }
  } else {
    const _current_0 = _slot_0["current"];
    const __2 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    if (_captured_0.$ === "public-cleanup-v1/current-core/ecs/machine.Unscheduled") {
      return {$: "public-cleanup-v1/current-core/ecs/machine.Applied", "slot": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _current_0, "pending": __2, "previous": _previous_0, "changed": _changed_0}, "event": {$: "None"}};
    } else {
      const _value_0 = _captured_0["value"];
      const _skipSame_0 = _captured_0["skipSame"];
      return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_present$1261$(_current_0, _value_0, _previous_0, _changed_0, _skipSame_0);
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($public$045cleanup$045v1$047current$045core$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "public-cleanup-v1/current-core/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_metadata$1263$({$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058register_meta$1263$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "public-cleanup-v1/current-core/ecs/world.RegistrationRejected") {
    return {$: "public-cleanup-v1/current-core/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "public-cleanup-v1/current-core/ecs/system.Registered", "world": _world_0, "registry": {$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047hooks$058trace$1261$(_label_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _flowStream_0 = _t_0["flowStream"];
  const _levelStream_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _rows_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": ($List$append$(_rows_0, {$: "Con", "head": _label_0, "tail": {$: "Nil"}}))}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047hooks$058run_result$1261$(_other_0, _isFlow_0, _result_0) {
  if (_isFlow_0) {
    if (_result_0.$ === "public-cleanup-v1/current-core/ecs/system.Completed") {
      const _actual_0 = _result_0["registry"];
      const _outcome_0 = _result_0["outcome"];
      return {$: "Tuple", "fst": {$: "../../../hooks.Owners", "flow": _actual_0, "level": _other_0}, "snd": _outcome_0};
    } else {
      const _actual_1 = _result_0["registry"];
      const _world_0 = _result_0["world"];
      return {$: "Tuple", "fst": {$: "../../../hooks.Owners", "flow": _actual_1, "level": _other_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_0, "error": "HookRegistrationRejected"}};
    }
  } else {
    if (_result_0.$ === "public-cleanup-v1/current-core/ecs/system.Completed") {
      const _actual_2 = _result_0["registry"];
      const _outcome_1 = _result_0["outcome"];
      return {$: "Tuple", "fst": {$: "../../../hooks.Owners", "flow": _other_0, "level": _actual_2}, "snd": _outcome_1};
    } else {
      const _actual_3 = _result_0["registry"];
      const _world_1 = _result_0["world"];
      return {$: "Tuple", "fst": {$: "../../../hooks.Owners", "flow": _other_0, "level": _actual_3}, "snd": {$: "public-cleanup-v1/current-core/ecs/system.Failed", "world": _world_1, "error": "HookRegistrationRejected"}};
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run$1265$(_registry_0, _world_0, _args_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace$1265$(_registry_0, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047world$058take_join$1262$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _split_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _resources_0 = _split_0["fst"];
  const _slot_0 = _split_0["snd"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _slot_0};
}

function $$$$047$$$047$$$047provider$058flow_take_resource$1261$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "Tuple", "fst": {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "snd": _flow_0};
}

function $$$$047$$$047$$$047marker$058flow_applied$1261$(_resources_0, _result_0, _hooks_0) {
  const _owned_0 = _resources_0["owned"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  const _slot_0 = _result_0["slot"];
  const _t_0 = _result_0["event"];
  if (_t_0.$ === "None") {
    return {$: "../../../provider.Resources", "owned": _owned_0, "flow": _slot_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0};
  } else {
    const _event_0 = _t_0["value"];
    if (!_hooks_0) {
      return {$: "../../../provider.Resources", "owned": _owned_0, "flow": _slot_0, "level": _level_0, "flowStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058publish$1260$(_flowStream_0, nat_chk(_tick_0 + 1), _event_0)), "levelStream": _levelStream_0, "frame": _frame_0, "tick": nat_chk(_tick_0 + 1), "trace": _trace_0};
    } else {
      return $$$$047$$$047$$$047marker$058flow_published$1261$(_owned_0, ($$$$047$$$047$$$047marker$058flow_hook$1261$(_slot_0, _level_0)), ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058publish$1260$(_flowStream_0, nat_chk(_tick_0 + 1), _event_0)), _levelStream_0, _frame_0, nat_chk(_tick_0 + 1), _trace_0);
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_snapshot$1262$(_slot_0, _captured_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    if (_captured_0.$ === "public-cleanup-v1/current-core/ecs/machine.Unscheduled") {
      return {$: "public-cleanup-v1/current-core/ecs/machine.Applied", "slot": {$: "public-cleanup-v1/current-core/ecs/machine.Missing"}, "event": {$: "None"}};
    } else {
      return {$: "public-cleanup-v1/current-core/ecs/machine.Applied", "slot": {$: "public-cleanup-v1/current-core/ecs/machine.Missing"}, "event": {$: "None"}};
    }
  } else {
    const _current_0 = _slot_0["current"];
    const __2 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    if (_captured_0.$ === "public-cleanup-v1/current-core/ecs/machine.Unscheduled") {
      return {$: "public-cleanup-v1/current-core/ecs/machine.Applied", "slot": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _current_0, "pending": __2, "previous": _previous_0, "changed": _changed_0}, "event": {$: "None"}};
    } else {
      const _value_0 = _captured_0["value"];
      const _skipSame_0 = _captured_0["skipSame"];
      return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_present$1262$(_current_0, _value_0, _previous_0, _changed_0, _skipSame_0);
    }
  }
}

function $$$$047$$$047$$$047world$058take_join$1263$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _split_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _resources_0 = _split_0["fst"];
  const _slot_0 = _split_0["snd"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _slot_0};
}

function $$$$047$$$047$$$047provider$058level_take_resource$1261$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "Tuple", "fst": {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "snd": _level_0};
}

function $$$$047$$$047$$$047marker$058level_applied$1261$(_resources_0, _result_0, _hooks_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  const _slot_0 = _result_0["slot"];
  const _t_0 = _result_0["event"];
  if (_t_0.$ === "None") {
    return {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _slot_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0};
  } else {
    const _event_0 = _t_0["value"];
    if (!_hooks_0) {
      return {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _slot_0, "flowStream": _flowStream_0, "levelStream": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058publish$1261$(_levelStream_0, nat_chk(_tick_0 + 1), _event_0)), "frame": _frame_0, "tick": nat_chk(_tick_0 + 1), "trace": _trace_0};
    } else {
      return $$$$047$$$047$$$047marker$058level_published$1261$(_owned_0, ($$$$047$$$047$$$047marker$058level_hook$1261$(_flow_0, _slot_0)), _flowStream_0, ($public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058publish$1261$(_levelStream_0, nat_chk(_tick_0 + 1), _event_0)), _frame_0, nat_chk(_tick_0 + 1), _trace_0);
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_snapshot$1263$(_slot_0, _captured_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    if (_captured_0.$ === "public-cleanup-v1/current-core/ecs/machine.Unscheduled") {
      return {$: "public-cleanup-v1/current-core/ecs/machine.Applied", "slot": {$: "public-cleanup-v1/current-core/ecs/machine.Missing"}, "event": {$: "None"}};
    } else {
      return {$: "public-cleanup-v1/current-core/ecs/machine.Applied", "slot": {$: "public-cleanup-v1/current-core/ecs/machine.Missing"}, "event": {$: "None"}};
    }
  } else {
    const _current_0 = _slot_0["current"];
    const __2 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    if (_captured_0.$ === "public-cleanup-v1/current-core/ecs/machine.Unscheduled") {
      return {$: "public-cleanup-v1/current-core/ecs/machine.Applied", "slot": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _current_0, "pending": __2, "previous": _previous_0, "changed": _changed_0}, "event": {$: "None"}};
    } else {
      const _value_0 = _captured_0["value"];
      const _skipSame_0 = _captured_0["skipSame"];
      return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_present$1263$(_current_0, _value_0, _previous_0, _changed_0, _skipSame_0);
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058enqueue$1261$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058event_publish_nonempty$1261$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($public$045cleanup$045v1$047current$045core$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace$1262$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_value$1262$(_registry_0, _world_0, _actual_0, _args_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058publish$1260$(_stream_0, _tick_0, _event_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return {$: "public-cleanup-v1/current-core/ecs/machine-stream.Stream", "batches": ($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058append$1262$(_batches_0, {$: "Con", "head": {$: "public-cleanup-v1/current-core/ecs/event-runtime.Batch", "tick": _tick_0, "values": {$: "Con", "head": _event_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}})), "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $$$$047$$$047$$$047marker$058flow_published$1260$(_owned_0, _pair_0, _stream_0, _levelStream_0, _frame_0, _tick_0, _trace_0) {
  const _t_0 = _pair_0["fst"];
  if (_t_0.$ === "public-cleanup-v1/current-core/ecs/machine.Present") {
    const _t_1 = _t_0["current"];
    if (_t_1.$ === "../../../provider.Pause") {
      const _pending_0 = _t_0["pending"];
      const _previous_0 = _t_0["previous"];
      const _changed_0 = _t_0["changed"];
      const _level_0 = _pair_0["snd"];
      return {$: "../../../provider.Resources", "owned": _owned_0, "flow": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": {$: "../../../provider.Pause"}, "pending": _pending_0, "previous": _previous_0, "changed": _changed_0}, "level": _level_0, "flowStream": _stream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": nat_chk(_tick_0 + 1), "trace": ($List$append$(_trace_0, {$: "Con", "head": "Flow", "tail": {$: "Nil"}}))};
    } else {
      const _pending_1 = _t_0["pending"];
      const _previous_1 = _t_0["previous"];
      const _changed_1 = _t_0["changed"];
      const _level_1 = _pair_0["snd"];
      return {$: "../../../provider.Resources", "owned": _owned_0, "flow": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _t_1, "pending": _pending_1, "previous": _previous_1, "changed": _changed_1}, "level": _level_1, "flowStream": _stream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0};
    }
  } else {
    const _level_2 = _pair_0["snd"];
    return {$: "../../../provider.Resources", "owned": _owned_0, "flow": _t_0, "level": _level_2, "flowStream": _stream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0};
  }
}

function $$$$047$$$047$$$047marker$058flow_hook$1260$(_slot_0, _level_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Present") {
    const _t_0 = _slot_0["current"];
    if (_t_0.$ === "../../../provider.Pause") {
      const _previous_0 = _slot_0["previous"];
      const _changed_0 = _slot_0["changed"];
      return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": {$: "../../../provider.Pause"}, "pending": {$: "public-cleanup-v1/current-core/ecs/machine.Queued", "value": {$: "../../../provider.Boot"}, "skipSame": false}, "previous": _previous_0, "changed": _changed_0}, "snd": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058queue$1261$(_level_0, {$: "../../../provider.High"}, false))};
    } else {
      const _pending_1 = _slot_0["pending"];
      const _previous_1 = _slot_0["previous"];
      const _changed_1 = _slot_0["changed"];
      return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _t_0, "pending": _pending_1, "previous": _previous_1, "changed": _changed_1}, "snd": _level_0};
    }
  } else {
    return {$: "Tuple", "fst": _slot_0, "snd": _level_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_present$1260$(_current_0, _value_0, _previous_0, _changed_0, _skipSame_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_decision$1260$(_current_0, _value_0, _previous_0, _changed_0, ($Bool$and$(_skipSame_0, ($$$$047$$$047$$$047provider$058flow_same$(_current_0, _value_0)))));
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$045stream$058publish$1261$(_stream_0, _tick_0, _event_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return {$: "public-cleanup-v1/current-core/ecs/machine-stream.Stream", "batches": ($public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058append$1263$(_batches_0, {$: "Con", "head": {$: "public-cleanup-v1/current-core/ecs/event-runtime.Batch", "tick": _tick_0, "values": {$: "Con", "head": _event_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}})), "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $$$$047$$$047$$$047marker$058level_published$1260$(_owned_0, _pair_0, _stream_0, _levelStream_0, _frame_0, _tick_0, _trace_0) {
  const _flow_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "public-cleanup-v1/current-core/ecs/machine.Present") {
    const _t_1 = _t_0["current"];
    if (_t_1.$ === "../../../provider.Middle") {
      const _pending_0 = _t_0["pending"];
      const _previous_0 = _t_0["previous"];
      const _changed_0 = _t_0["changed"];
      return {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": {$: "../../../provider.Middle"}, "pending": _pending_0, "previous": _previous_0, "changed": _changed_0}, "flowStream": _stream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": nat_chk(_tick_0 + 1), "trace": ($List$append$(_trace_0, {$: "Con", "head": "Level", "tail": {$: "Nil"}}))};
    } else {
      const _pending_1 = _t_0["pending"];
      const _previous_1 = _t_0["previous"];
      const _changed_1 = _t_0["changed"];
      return {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _t_1, "pending": _pending_1, "previous": _previous_1, "changed": _changed_1}, "flowStream": _stream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0};
    }
  } else {
    return {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _t_0, "flowStream": _stream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0};
  }
}

function $$$$047$$$047$$$047marker$058level_hook$1260$(_flow_0, _level_0) {
  if (_level_0.$ === "public-cleanup-v1/current-core/ecs/machine.Present") {
    const _t_0 = _level_0["current"];
    if (_t_0.$ === "../../../provider.Middle") {
      const _pending_0 = _level_0["pending"];
      const _previous_0 = _level_0["previous"];
      const _changed_0 = _level_0["changed"];
      return {$: "Tuple", "fst": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058queue$1260$(_flow_0, {$: "../../../provider.Boot"}, false)), "snd": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": {$: "../../../provider.Middle"}, "pending": _pending_0, "previous": _previous_0, "changed": _changed_0}};
    } else {
      const _pending_1 = _level_0["pending"];
      const _previous_1 = _level_0["previous"];
      const _changed_1 = _level_0["changed"];
      return {$: "Tuple", "fst": _flow_0, "snd": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _t_0, "pending": _pending_1, "previous": _previous_1, "changed": _changed_1}};
    }
  } else {
    return {$: "Tuple", "fst": _flow_0, "snd": _level_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_present$1261$(_current_0, _value_0, _previous_0, _changed_0, _skipSame_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_decision$1261$(_current_0, _value_0, _previous_0, _changed_0, ($Bool$and$(_skipSame_0, ($$$$047$$$047$$$047provider$058level_same$(_current_0, _value_0)))));
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_metadata$1263$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace$1265$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_value$1265$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047marker$058flow_published$1261$(_owned_0, _pair_0, _stream_0, _levelStream_0, _frame_0, _tick_0, _trace_0) {
  const _t_0 = _pair_0["fst"];
  if (_t_0.$ === "public-cleanup-v1/current-core/ecs/machine.Present") {
    const _t_1 = _t_0["current"];
    if (_t_1.$ === "../../../provider.Pause") {
      const _pending_0 = _t_0["pending"];
      const _previous_0 = _t_0["previous"];
      const _changed_0 = _t_0["changed"];
      const _level_0 = _pair_0["snd"];
      return {$: "../../../provider.Resources", "owned": _owned_0, "flow": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": {$: "../../../provider.Pause"}, "pending": _pending_0, "previous": _previous_0, "changed": _changed_0}, "level": _level_0, "flowStream": _stream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": nat_chk(_tick_0 + 1), "trace": ($List$append$(_trace_0, {$: "Con", "head": "Flow", "tail": {$: "Nil"}}))};
    } else {
      const _pending_1 = _t_0["pending"];
      const _previous_1 = _t_0["previous"];
      const _changed_1 = _t_0["changed"];
      const _level_1 = _pair_0["snd"];
      return {$: "../../../provider.Resources", "owned": _owned_0, "flow": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _t_1, "pending": _pending_1, "previous": _previous_1, "changed": _changed_1}, "level": _level_1, "flowStream": _stream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0};
    }
  } else {
    const _level_2 = _pair_0["snd"];
    return {$: "../../../provider.Resources", "owned": _owned_0, "flow": _t_0, "level": _level_2, "flowStream": _stream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0};
  }
}

function $$$$047$$$047$$$047marker$058flow_hook$1261$(_slot_0, _level_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Present") {
    const _t_0 = _slot_0["current"];
    if (_t_0.$ === "../../../provider.Pause") {
      const _previous_0 = _slot_0["previous"];
      const _changed_0 = _slot_0["changed"];
      return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": {$: "../../../provider.Pause"}, "pending": {$: "public-cleanup-v1/current-core/ecs/machine.Queued", "value": {$: "../../../provider.Boot"}, "skipSame": false}, "previous": _previous_0, "changed": _changed_0}, "snd": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058queue$1263$(_level_0, {$: "../../../provider.High"}, false))};
    } else {
      const _pending_1 = _slot_0["pending"];
      const _previous_1 = _slot_0["previous"];
      const _changed_1 = _slot_0["changed"];
      return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _t_0, "pending": _pending_1, "previous": _previous_1, "changed": _changed_1}, "snd": _level_0};
    }
  } else {
    return {$: "Tuple", "fst": _slot_0, "snd": _level_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_present$1262$(_current_0, _value_0, _previous_0, _changed_0, _skipSame_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_decision$1262$(_current_0, _value_0, _previous_0, _changed_0, ($Bool$and$(_skipSame_0, ($$$$047$$$047$$$047provider$058flow_same$(_current_0, _value_0)))));
}

function $$$$047$$$047$$$047marker$058level_published$1261$(_owned_0, _pair_0, _stream_0, _levelStream_0, _frame_0, _tick_0, _trace_0) {
  const _flow_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "public-cleanup-v1/current-core/ecs/machine.Present") {
    const _t_1 = _t_0["current"];
    if (_t_1.$ === "../../../provider.Middle") {
      const _pending_0 = _t_0["pending"];
      const _previous_0 = _t_0["previous"];
      const _changed_0 = _t_0["changed"];
      return {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": {$: "../../../provider.Middle"}, "pending": _pending_0, "previous": _previous_0, "changed": _changed_0}, "flowStream": _stream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": nat_chk(_tick_0 + 1), "trace": ($List$append$(_trace_0, {$: "Con", "head": "Level", "tail": {$: "Nil"}}))};
    } else {
      const _pending_1 = _t_0["pending"];
      const _previous_1 = _t_0["previous"];
      const _changed_1 = _t_0["changed"];
      return {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _t_1, "pending": _pending_1, "previous": _previous_1, "changed": _changed_1}, "flowStream": _stream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0};
    }
  } else {
    return {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _t_0, "flowStream": _stream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0};
  }
}

function $$$$047$$$047$$$047marker$058level_hook$1261$(_flow_0, _level_0) {
  if (_level_0.$ === "public-cleanup-v1/current-core/ecs/machine.Present") {
    const _t_0 = _level_0["current"];
    if (_t_0.$ === "../../../provider.Middle") {
      const _pending_0 = _level_0["pending"];
      const _previous_0 = _level_0["previous"];
      const _changed_0 = _level_0["changed"];
      return {$: "Tuple", "fst": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058queue$1262$(_flow_0, {$: "../../../provider.Boot"}, false)), "snd": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": {$: "../../../provider.Middle"}, "pending": _pending_0, "previous": _previous_0, "changed": _changed_0}};
    } else {
      const _pending_1 = _level_0["pending"];
      const _previous_1 = _level_0["previous"];
      const _changed_1 = _level_0["changed"];
      return {$: "Tuple", "fst": _flow_0, "snd": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _t_0, "pending": _pending_1, "previous": _previous_1, "changed": _changed_1}};
    }
  } else {
    return {$: "Tuple", "fst": _flow_0, "snd": _level_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_present$1263$(_current_0, _value_0, _previous_0, _changed_0, _skipSame_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_decision$1263$(_current_0, _value_0, _previous_0, _changed_0, ($Bool$and$(_skipSame_0, ($$$$047$$$047$$$047provider$058level_same$(_current_0, _value_0)))));
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "public-cleanup-v1/current-core/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $public$045cleanup$045v1$047current$045core$047ecs$047system$058complete$1260$(_registry_0, ($$$$047$$$047$$$047context$058runner$1260$(_world_0, _args_0)));
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_value$1262$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_checked$1262$((_namespace_0 === _actual_0), {$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058append$1262$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058append_loop$1262$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058queue$1261$(_slot_0, _value_0, _skipSame_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _current_0, "pending": {$: "public-cleanup-v1/current-core/ecs/machine.Queued", "value": _value_0, "skipSame": _skipSame_0}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_decision$1260$(_current_0, _value_0, _previous_0, _changed_0, _skip_0) {
  if (_skip_0) {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Applied", "slot": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _current_0, "pending": {$: "public-cleanup-v1/current-core/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0}, "event": {$: "None"}};
  } else {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Applied", "slot": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _value_0, "pending": {$: "public-cleanup-v1/current-core/ecs/machine.NoPending"}, "previous": {$: "Some", "value": _current_0}, "changed": true}, "event": {$: "Some", "value": {$: "public-cleanup-v1/current-core/ecs/machine.Transition", "from": _current_0, "to": _value_0}}};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058append$1263$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058append_loop$1263$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058queue$1260$(_slot_0, _value_0, _skipSame_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _current_0, "pending": {$: "public-cleanup-v1/current-core/ecs/machine.Queued", "value": _value_0, "skipSame": _skipSame_0}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_decision$1261$(_current_0, _value_0, _previous_0, _changed_0, _skip_0) {
  if (_skip_0) {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Applied", "slot": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _current_0, "pending": {$: "public-cleanup-v1/current-core/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0}, "event": {$: "None"}};
  } else {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Applied", "slot": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _value_0, "pending": {$: "public-cleanup-v1/current-core/ecs/machine.NoPending"}, "previous": {$: "Some", "value": _current_0}, "changed": true}, "event": {$: "Some", "value": {$: "public-cleanup-v1/current-core/ecs/machine.Transition", "from": _current_0, "to": _value_0}}};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "public-cleanup-v1/current-core/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $public$045cleanup$045v1$047current$045core$047ecs$047system$058complete$1263$(_registry_0, ($$$$047$$$047$$$047context$058runner$1261$(_world_0, _args_0)));
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_value$1265$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_checked$1265$((_namespace_0 === _actual_0), {$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058queue$1263$(_slot_0, _value_0, _skipSame_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _current_0, "pending": {$: "public-cleanup-v1/current-core/ecs/machine.Queued", "value": _value_0, "skipSame": _skipSame_0}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_decision$1262$(_current_0, _value_0, _previous_0, _changed_0, _skip_0) {
  if (_skip_0) {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Applied", "slot": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _current_0, "pending": {$: "public-cleanup-v1/current-core/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0}, "event": {$: "None"}};
  } else {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Applied", "slot": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _value_0, "pending": {$: "public-cleanup-v1/current-core/ecs/machine.NoPending"}, "previous": {$: "Some", "value": _current_0}, "changed": true}, "event": {$: "Some", "value": {$: "public-cleanup-v1/current-core/ecs/machine.Transition", "from": _current_0, "to": _value_0}}};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058queue$1262$(_slot_0, _value_0, _skipSame_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _current_0, "pending": {$: "public-cleanup-v1/current-core/ecs/machine.Queued", "value": _value_0, "skipSame": _skipSame_0}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058apply_decision$1263$(_current_0, _value_0, _previous_0, _changed_0, _skip_0) {
  if (_skip_0) {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Applied", "slot": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _current_0, "pending": {$: "public-cleanup-v1/current-core/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0}, "event": {$: "None"}};
  } else {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Applied", "slot": {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _value_0, "pending": {$: "public-cleanup-v1/current-core/ecs/machine.NoPending"}, "previous": {$: "Some", "value": _current_0}, "changed": true}, "event": {$: "Some", "value": {$: "public-cleanup-v1/current-core/ecs/machine.Transition", "from": _current_0, "to": _value_0}}};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "public-cleanup-v1/current-core/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047$$$047$$$047context$058runner$1260$(_world_0, _operation_0) {
  return $$$$047$$$047$$$047context$058finish$1260$(($$$$047$$$047$$$047gameplay$058body$1260$(_operation_0, {$: "../../../context.Frame", "tx": ($public$045cleanup$045v1$047current$045core$047ecs$047transaction$058begin$1260$(($$$$047$$$047$$$047provider$058pulse$1260$(_world_0)))), "error": {$: "None"}})));
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "public-cleanup-v1/current-core/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_metadata$1262$({$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058append_loop$1262$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047event$045runtime$058append_loop$1263$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058complete$1263$(_registry_0, _outcome_0) {
  return {$: "public-cleanup-v1/current-core/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047$$$047$$$047context$058runner$1261$(_world_0, _operation_0) {
  return $$$$047$$$047$$$047context$058finish$1261$(($$$$047$$$047$$$047gameplay$058body$1261$(_operation_0, {$: "../../../context.Frame", "tx": ($public$045cleanup$045v1$047current$045core$047ecs$047transaction$058begin$1261$(($$$$047$$$047$$$047provider$058pulse$1261$(_world_0)))), "error": {$: "None"}})));
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_namespace_checked$1265$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "public-cleanup-v1/current-core/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_metadata$1265$({$: "public-cleanup-v1/current-core/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047gameplay$058body$1260$(_operation_0, _ctx_0) {
  if (_operation_0.$ === "../../../gameplay.Seed") {
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send$1260$(_ctx_0, {$: "../../../gameplay.SeedCells", "owner": array_node([10], [99])})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  } else if (_operation_0.$ === "../../../gameplay.Queue") {
    const _ctx_1 = run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1260$(_ctx_0, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Middle"}, "skipSame": false}));
    const _ctx_2 = run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1261$(_ctx_1, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Play"}, "skipSame": false}));
    const _ctx_3 = run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1262$(_ctx_2, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Pause"}, "skipSame": false}));
    return $$$$047$$$047$$$047gameplay$058queue_current$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1260$(_ctx_3)));
  } else if (_operation_0.$ === "../../../gameplay.OldPending") {
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1261$(_ctx_0, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Boot"}, "skipSame": false})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  } else if (_operation_0.$ === "../../../gameplay.FailingPublisher") {
    const _error_0 = _operation_0["error"];
    const _ctx_4 = run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send$1261$(_ctx_0, array_node([88], [188])));
    const _ctx_5 = run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send$1262$(_ctx_4, array_node([77], [177])));
    const _ctx_6 = run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1261$(_ctx_5, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Play"}, "skipSame": false}));
    const _ctx_7 = run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1260$(_ctx_6, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.High"}, "skipSame": false}));
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send$1260$(_ctx_7, {$: "../../../gameplay.Empty"})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Failure", "error": _error_0}};
  } else if (_operation_0.$ === "../../../gameplay.Reset") {
    const _ctx_8 = run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1261$(_ctx_0, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Play"}, "skipSame": false}));
    return $$$$047$$$047$$$047gameplay$058reset_observed$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_get$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1262$(_ctx_8, {$: "public-cleanup-v1/current-core/ecs/machine.Reset"})))));
  } else if (_operation_0.$ === "../../../gameplay.MarkerQueues") {
    const _ctx_9 = run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1260$(_ctx_0, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Middle"}, "skipSame": false}));
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1261$(_ctx_9, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Pause"}, "skipSame": false})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  } else if (_operation_0.$ === "../../../gameplay.SameSet") {
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1261$(_ctx_0, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Pause"}, "skipSame": false})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  } else if (_operation_0.$ === "../../../gameplay.SameSkip") {
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1261$(_ctx_0, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Pause"}, "skipSame": true})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  } else if (_operation_0.$ === "../../../gameplay.OverwriteSkip") {
    const _ctx_10 = run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1261$(_ctx_0, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Pause"}, "skipSame": true}));
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1262$(_ctx_10, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Pause"}, "skipSame": false})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  } else if (_operation_0.$ === "../../../gameplay.PauseRequest") {
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1261$(_ctx_0, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Pause"}, "skipSame": false})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  } else if (_operation_0.$ === "../../../gameplay.PlayRequest") {
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1261$(_ctx_0, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Play"}, "skipSame": false})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_metadata$1262$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047gameplay$058body$1261$(_operation_0, _ctx_0) {
  if (_operation_0.$ === "../../../gameplay.Seed") {
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send$1263$(_ctx_0, {$: "../../../gameplay.SeedCells", "owner": array_node([10], [99])})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  } else if (_operation_0.$ === "../../../gameplay.Queue") {
    const _ctx_1 = run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1265$(_ctx_0, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Middle"}, "skipSame": false}));
    const _ctx_2 = run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1266$(_ctx_1, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Play"}, "skipSame": false}));
    const _ctx_3 = run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1267$(_ctx_2, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Pause"}, "skipSame": false}));
    return $$$$047$$$047$$$047gameplay$058queue_current$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1263$(_ctx_3)));
  } else if (_operation_0.$ === "../../../gameplay.OldPending") {
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1266$(_ctx_0, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Boot"}, "skipSame": false})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  } else if (_operation_0.$ === "../../../gameplay.FailingPublisher") {
    const _error_0 = _operation_0["error"];
    const _ctx_4 = run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send$1264$(_ctx_0, array_node([88], [188])));
    const _ctx_5 = run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send$1265$(_ctx_4, array_node([77], [177])));
    const _ctx_6 = run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1266$(_ctx_5, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Play"}, "skipSame": false}));
    const _ctx_7 = run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1265$(_ctx_6, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.High"}, "skipSame": false}));
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send$1263$(_ctx_7, {$: "../../../gameplay.Empty"})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Failure", "error": _error_0}};
  } else if (_operation_0.$ === "../../../gameplay.Reset") {
    const _ctx_8 = run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1266$(_ctx_0, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Play"}, "skipSame": false}));
    return $$$$047$$$047$$$047gameplay$058reset_observed$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_get$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1267$(_ctx_8, {$: "public-cleanup-v1/current-core/ecs/machine.Reset"})))));
  } else if (_operation_0.$ === "../../../gameplay.MarkerQueues") {
    const _ctx_9 = run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1265$(_ctx_0, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Middle"}, "skipSame": false}));
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1266$(_ctx_9, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Pause"}, "skipSame": false})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  } else if (_operation_0.$ === "../../../gameplay.SameSet") {
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1266$(_ctx_0, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Pause"}, "skipSame": false})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  } else if (_operation_0.$ === "../../../gameplay.SameSkip") {
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1266$(_ctx_0, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Pause"}, "skipSame": true})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  } else if (_operation_0.$ === "../../../gameplay.OverwriteSkip") {
    const _ctx_10 = run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1266$(_ctx_0, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Pause"}, "skipSame": true}));
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1267$(_ctx_10, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Pause"}, "skipSame": false})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  } else if (_operation_0.$ === "../../../gameplay.PauseRequest") {
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1266$(_ctx_0, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Pause"}, "skipSame": false})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  } else if (_operation_0.$ === "../../../gameplay.PlayRequest") {
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1266$(_ctx_0, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Play"}, "skipSame": false})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_metadata$1265$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_checked$1265$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send$1260$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send_field$1260$(($$$$047$$$047$$$047gameplay$058spawn$1260$(($$$$047$$$047$$$047context$058work$1260$())))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1260$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_write_field$1260$(($$$$047$$$047$$$047gameplay$058level$1260$(($$$$047$$$047$$$047context$058work$1260$())))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1261$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_write_field$1261$(($$$$047$$$047$$$047gameplay$058flow$1260$(($$$$047$$$047$$$047context$058work$1260$())))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1262$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_write_field$1261$(($$$$047$$$047$$$047gameplay$058alias$1260$(($$$$047$$$047$$$047context$058work$1260$())))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047gameplay$058queue_current$1260$(_pair_0) {
  const _ctx_0 = _pair_0["fst"];
  const _current_0 = _pair_0["snd"];
  return $$$$047$$$047$$$047gameplay$058queue_observed$1260$(_current_0, run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_get$1260$(_ctx_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1260$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1260$(($$$$047$$$047$$$047gameplay$058read_flow$1260$(($$$$047$$$047$$$047context$058work$1260$()))))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send$1261$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send_field$1261$(($$$$047$$$047$$$047gameplay$058cells$1260$(($$$$047$$$047$$$047context$058work$1260$())))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send$1262$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send_field$1261$(($$$$047$$$047$$$047gameplay$058owned$1260$(($$$$047$$$047$$$047context$058work$1260$())))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047gameplay$058reset_observed$1260$(_pair_0) {
  const _ctx_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "public-cleanup-v1/current-core/ecs/machine.NoNext") {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Failure", "error": "ResetObservationMismatch"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_get$1260$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_write_read_field$1260$(($$$$047$$$047$$$047gameplay$058alias$1260$(($$$$047$$$047$$$047context$058work$1260$()))))), _ctx_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "public-cleanup-v1/current-core/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $public$045cleanup$045v1$047current$045core$047ecs$047system$058complete$1262$(_registry_0, ($$$$047$$$047$$$047context$058hook_runner$1260$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send$1263$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send_field$1262$(($$$$047$$$047$$$047gameplay$058spawn$1261$(($$$$047$$$047$$$047context$058work$1261$())))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1265$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_write_field$1262$(($$$$047$$$047$$$047gameplay$058level$1261$(($$$$047$$$047$$$047context$058work$1261$())))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1266$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_write_field$1263$(($$$$047$$$047$$$047gameplay$058flow$1261$(($$$$047$$$047$$$047context$058work$1261$())))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1267$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_write_field$1263$(($$$$047$$$047$$$047gameplay$058alias$1261$(($$$$047$$$047$$$047context$058work$1261$())))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047gameplay$058queue_current$1261$(_pair_0) {
  const _ctx_0 = _pair_0["fst"];
  const _current_0 = _pair_0["snd"];
  return $$$$047$$$047$$$047gameplay$058queue_observed$1261$(_current_0, run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_get$1261$(_ctx_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read$1263$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1263$(($$$$047$$$047$$$047gameplay$058read_flow$1261$(($$$$047$$$047$$$047context$058work$1261$()))))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send$1264$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send_field$1263$(($$$$047$$$047$$$047gameplay$058cells$1261$(($$$$047$$$047$$$047context$058work$1261$())))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send$1265$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send_field$1263$(($$$$047$$$047$$$047gameplay$058owned$1261$(($$$$047$$$047$$$047context$058work$1261$())))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047gameplay$058reset_observed$1261$(_pair_0) {
  const _ctx_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "public-cleanup-v1/current-core/ecs/machine.NoNext") {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Failure", "error": "ResetObservationMismatch"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_get$1261$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_write_read_field$1261$(($$$$047$$$047$$$047gameplay$058alias$1261$(($$$$047$$$047$$$047context$058work$1261$()))))), _ctx_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058run_checked$1265$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "public-cleanup-v1/current-core/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $public$045cleanup$045v1$047current$045core$047ecs$047system$058complete$1265$(_registry_0, ($$$$047$$$047$$$047context$058hook_runner$1261$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send_field$1260$(_cap_0) {
  const _send_0 = _cap_0["send"];
  return _send_0;
}

function $$$$047$$$047$$$047gameplay$058spawn$1260$(_caps_0) {
  const _cap_0 = _caps_0["spawn"];
  return _cap_0;
}

function $$$$047$$$047$$$047context$058work$1260$() {
  return {$: "../../../gameplay.Work", "readFlow": {$: "../../../../../src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047context$058flow_current$1260$(_x_0);
})}, "flow": {$: "../../../../../src/ecs/capabilities.ValueWrite", "get": run_clo((_x_1) => {
  return $$$$047$$$047$$$047context$058flow_pending$1260$(_x_1);
}), "set": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047context$058flow_next$1260$(_x_2, _x_3);
});
})}, "alias": {$: "../../../../../src/ecs/capabilities.ValueWrite", "get": run_clo((_x_4) => {
  return $$$$047$$$047$$$047context$058flow_pending$1260$(_x_4);
}), "set": run_clo((_x_5) => {
  return run_clo((_x_6) => {
  return $$$$047$$$047$$$047context$058flow_next$1260$(_x_5, _x_6);
});
})}, "level": {$: "../../../../../src/ecs/capabilities.ValueWrite", "get": run_clo((_x_7) => {
  return $$$$047$$$047$$$047context$058level_pending$1260$(_x_7);
}), "set": run_clo((_x_8) => {
  return run_clo((_x_9) => {
  return $$$$047$$$047$$$047context$058level_next$1260$(_x_8, _x_9);
});
})}, "cells": {$: "../../../../../src/ecs/capabilities.Send", "send": run_clo((_x_10) => {
  return run_clo((_x_11) => {
  return $$$$047$$$047$$$047context$058cells_write$1260$(_x_10, _x_11);
});
})}, "owned": {$: "../../../../../src/ecs/capabilities.Send", "send": run_clo((_x_12) => {
  return run_clo((_x_13) => {
  return $$$$047$$$047$$$047context$058owned_write$1260$(_x_12, _x_13);
});
})}, "spawn": {$: "../../../../../src/ecs/capabilities.Send", "send": run_clo((_x_14) => {
  return run_clo((_x_15) => {
  return $$$$047$$$047$$$047context$058spawn$1260$(_x_14, _x_15);
});
})}};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_write_field$1260$(_cap_0) {
  const _set_0 = _cap_0["set"];
  return _set_0;
}

function $$$$047$$$047$$$047gameplay$058level$1260$(_caps_0) {
  const _cap_0 = _caps_0["level"];
  return _cap_0;
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_write_field$1261$(_cap_0) {
  const _set_0 = _cap_0["set"];
  return _set_0;
}

function $$$$047$$$047$$$047gameplay$058flow$1260$(_caps_0) {
  const _cap_0 = _caps_0["flow"];
  return _cap_0;
}

function $$$$047$$$047$$$047gameplay$058alias$1260$(_caps_0) {
  const _cap_0 = _caps_0["alias"];
  return _cap_0;
}

function $$$$047$$$047$$$047gameplay$058queue_observed$1260$(_current_0, _pair_0) {
  if (_current_0.$ === "public-cleanup-v1/current-core/ecs/machine.Current") {
    const _t_0 = _current_0["value"];
    if (_t_0.$ === "../../../provider.Boot") {
      const _ctx_0 = _pair_0["fst"];
      const _t_1 = _pair_0["snd"];
      if (_t_1.$ === "public-cleanup-v1/current-core/ecs/machine.Next") {
        const _t_2 = _t_1["value"];
        if (_t_2.$ === "../../../provider.Pause") {
          return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send$1260$(_ctx_0, {$: "../../../gameplay.Empty"})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
        } else {
          return {$: "Tuple", "fst": _ctx_0, "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Failure", "error": "AliasObservationMismatch"}};
        }
      } else {
        return {$: "Tuple", "fst": _ctx_0, "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Failure", "error": "AliasObservationMismatch"}};
      }
    } else {
      const _ctx_1 = _pair_0["fst"];
      return {$: "Tuple", "fst": _ctx_1, "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Failure", "error": "AliasObservationMismatch"}};
    }
  } else {
    const _ctx_2 = _pair_0["fst"];
    return {$: "Tuple", "fst": _ctx_2, "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Failure", "error": "AliasObservationMismatch"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1260$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047gameplay$058read_flow$1260$(_caps_0) {
  const _cap_0 = _caps_0["readFlow"];
  return _cap_0;
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send_field$1261$(_cap_0) {
  const _send_0 = _cap_0["send"];
  return _send_0;
}

function $$$$047$$$047$$$047gameplay$058cells$1260$(_caps_0) {
  const _cap_0 = _caps_0["cells"];
  return _cap_0;
}

function $$$$047$$$047$$$047gameplay$058owned$1260$(_caps_0) {
  const _cap_0 = _caps_0["owned"];
  return _cap_0;
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_write_read_field$1260$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058complete$1262$(_registry_0, _outcome_0) {
  return {$: "public-cleanup-v1/current-core/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047$$$047$$$047context$058hook_runner$1260$(_world_0, _operation_0) {
  return $$$$047$$$047$$$047context$058finish$1260$(($$$$047$$$047$$$047gameplay$058hook_body$1260$(_operation_0, {$: "../../../context.Frame", "tx": ($public$045cleanup$045v1$047current$045core$047ecs$047transaction$058begin$1260$(($$$$047$$$047$$$047provider$058pulse$1260$(_world_0)))), "error": {$: "None"}})));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send_field$1262$(_cap_0) {
  const _send_0 = _cap_0["send"];
  return _send_0;
}

function $$$$047$$$047$$$047gameplay$058spawn$1261$(_caps_0) {
  const _cap_0 = _caps_0["spawn"];
  return _cap_0;
}

function $$$$047$$$047$$$047context$058work$1261$() {
  return {$: "../../../gameplay.Work", "readFlow": {$: "../../../../../src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047context$058flow_current$1261$(_x_0);
})}, "flow": {$: "../../../../../src/ecs/capabilities.ValueWrite", "get": run_clo((_x_1) => {
  return $$$$047$$$047$$$047context$058flow_pending$1261$(_x_1);
}), "set": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047context$058flow_next$1261$(_x_2, _x_3);
});
})}, "alias": {$: "../../../../../src/ecs/capabilities.ValueWrite", "get": run_clo((_x_4) => {
  return $$$$047$$$047$$$047context$058flow_pending$1261$(_x_4);
}), "set": run_clo((_x_5) => {
  return run_clo((_x_6) => {
  return $$$$047$$$047$$$047context$058flow_next$1261$(_x_5, _x_6);
});
})}, "level": {$: "../../../../../src/ecs/capabilities.ValueWrite", "get": run_clo((_x_7) => {
  return $$$$047$$$047$$$047context$058level_pending$1261$(_x_7);
}), "set": run_clo((_x_8) => {
  return run_clo((_x_9) => {
  return $$$$047$$$047$$$047context$058level_next$1261$(_x_8, _x_9);
});
})}, "cells": {$: "../../../../../src/ecs/capabilities.Send", "send": run_clo((_x_10) => {
  return run_clo((_x_11) => {
  return $$$$047$$$047$$$047context$058cells_write$1261$(_x_10, _x_11);
});
})}, "owned": {$: "../../../../../src/ecs/capabilities.Send", "send": run_clo((_x_12) => {
  return run_clo((_x_13) => {
  return $$$$047$$$047$$$047context$058owned_write$1261$(_x_12, _x_13);
});
})}, "spawn": {$: "../../../../../src/ecs/capabilities.Send", "send": run_clo((_x_14) => {
  return run_clo((_x_15) => {
  return $$$$047$$$047$$$047context$058spawn$1261$(_x_14, _x_15);
});
})}};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_write_field$1262$(_cap_0) {
  const _set_0 = _cap_0["set"];
  return _set_0;
}

function $$$$047$$$047$$$047gameplay$058level$1261$(_caps_0) {
  const _cap_0 = _caps_0["level"];
  return _cap_0;
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_write_field$1263$(_cap_0) {
  const _set_0 = _cap_0["set"];
  return _set_0;
}

function $$$$047$$$047$$$047gameplay$058flow$1261$(_caps_0) {
  const _cap_0 = _caps_0["flow"];
  return _cap_0;
}

function $$$$047$$$047$$$047gameplay$058alias$1261$(_caps_0) {
  const _cap_0 = _caps_0["alias"];
  return _cap_0;
}

function $$$$047$$$047$$$047gameplay$058queue_observed$1261$(_current_0, _pair_0) {
  if (_current_0.$ === "public-cleanup-v1/current-core/ecs/machine.Current") {
    const _t_0 = _current_0["value"];
    if (_t_0.$ === "../../../provider.Boot") {
      const _ctx_0 = _pair_0["fst"];
      const _t_1 = _pair_0["snd"];
      if (_t_1.$ === "public-cleanup-v1/current-core/ecs/machine.Next") {
        const _t_2 = _t_1["value"];
        if (_t_2.$ === "../../../provider.Pause") {
          return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send$1263$(_ctx_0, {$: "../../../gameplay.Empty"})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
        } else {
          return {$: "Tuple", "fst": _ctx_0, "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Failure", "error": "AliasObservationMismatch"}};
        }
      } else {
        return {$: "Tuple", "fst": _ctx_0, "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Failure", "error": "AliasObservationMismatch"}};
      }
    } else {
      const _ctx_1 = _pair_0["fst"];
      return {$: "Tuple", "fst": _ctx_1, "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Failure", "error": "AliasObservationMismatch"}};
    }
  } else {
    const _ctx_2 = _pair_0["fst"];
    return {$: "Tuple", "fst": _ctx_2, "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Failure", "error": "AliasObservationMismatch"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_read_field$1263$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047gameplay$058read_flow$1261$(_caps_0) {
  const _cap_0 = _caps_0["readFlow"];
  return _cap_0;
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058send_field$1263$(_cap_0) {
  const _send_0 = _cap_0["send"];
  return _send_0;
}

function $$$$047$$$047$$$047gameplay$058cells$1261$(_caps_0) {
  const _cap_0 = _caps_0["cells"];
  return _cap_0;
}

function $$$$047$$$047$$$047gameplay$058owned$1261$(_caps_0) {
  const _cap_0 = _caps_0["owned"];
  return _cap_0;
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_write_read_field$1261$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $public$045cleanup$045v1$047current$045core$047ecs$047system$058complete$1265$(_registry_0, _outcome_0) {
  return {$: "public-cleanup-v1/current-core/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047$$$047$$$047context$058hook_runner$1261$(_world_0, _operation_0) {
  return $$$$047$$$047$$$047context$058finish$1261$(($$$$047$$$047$$$047gameplay$058hook_body$1261$(_operation_0, {$: "../../../context.Frame", "tx": ($public$045cleanup$045v1$047current$045core$047ecs$047transaction$058begin$1261$(($$$$047$$$047$$$047provider$058pulse$1261$(_world_0)))), "error": {$: "None"}})));
}

function $$$$047$$$047$$$047context$058flow_current$1260$(_frame_0) {
  return $$$$047$$$047$$$047context$058flow_current_pair$1260$(($$$$047$$$047$$$047context$058flow_read$1260$(_frame_0)));
}

function $$$$047$$$047$$$047context$058flow_pending$1260$(_frame_0) {
  return $$$$047$$$047$$$047context$058flow_pending_pair$1260$(($$$$047$$$047$$$047context$058flow_read$1260$(_frame_0)));
}

function $$$$047$$$047$$$047context$058flow_next$1260$(_frame_0, _request_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return {$: "../../../context.Frame", "tx": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058next_declared$1260$({$: "public-cleanup-v1/current-core/ecs/machine.Family", "name": "Flow"}, _tx_0, _request_0)), "error": _error_0};
}

function $$$$047$$$047$$$047context$058level_pending$1260$(_frame_0) {
  return $$$$047$$$047$$$047context$058level_pending_pair$1260$(($$$$047$$$047$$$047context$058level_read$1260$(_frame_0)));
}

function $$$$047$$$047$$$047context$058level_next$1260$(_frame_0, _request_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return {$: "../../../context.Frame", "tx": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058next_declared$1261$({$: "public-cleanup-v1/current-core/ecs/machine.Family", "name": "Level"}, _tx_0, _request_0)), "error": _error_0};
}

function $$$$047$$$047$$$047context$058cells_write$1260$(_frame_0, _incoming_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return $$$$047$$$047$$$047context$058cells_result$1260$(($$$$047$$$047$$$047provider$058cells_set$1260$(_tx_0, _incoming_0)), _error_0);
}

function $$$$047$$$047$$$047context$058owned_write$1260$(_frame_0, _incoming_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return {$: "../../../context.Frame", "tx": ($$$$047$$$047$$$047context$058owned_tx$1260$(_tx_0, _incoming_0)), "error": _error_0};
}

function $$$$047$$$047$$$047context$058spawn$1260$(_frame_0, _payload_0) {
  if (_payload_0.$ === "../../../gameplay.Empty") {
    return $$$$047$$$047$$$047context$058spawn_empty$1260$(_frame_0);
  } else {
    const _owner_0 = _payload_0["owner"];
    return $$$$047$$$047$$$047context$058spawn_seed$1260$(_frame_0, _owner_0);
  }
}

function $$$$047$$$047$$$047gameplay$058hook_body$1260$(_operation_0, _ctx_0) {
  if (_operation_0.$ === "../../../gameplay.FlowEnter") {
    const _ctx_1 = run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1263$(_ctx_0, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Boot"}, "skipSame": false}));
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1264$(_ctx_1, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.High"}, "skipSame": false})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  } else {
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1263$(_ctx_0, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Boot"}, "skipSame": false})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  }
}

function $$$$047$$$047$$$047context$058flow_current$1261$(_frame_0) {
  return $$$$047$$$047$$$047context$058flow_current_pair$1261$(($$$$047$$$047$$$047context$058flow_read$1261$(_frame_0)));
}

function $$$$047$$$047$$$047context$058flow_pending$1261$(_frame_0) {
  return $$$$047$$$047$$$047context$058flow_pending_pair$1261$(($$$$047$$$047$$$047context$058flow_read$1261$(_frame_0)));
}

function $$$$047$$$047$$$047context$058flow_next$1261$(_frame_0, _request_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return {$: "../../../context.Frame", "tx": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058next_declared$1262$({$: "public-cleanup-v1/current-core/ecs/machine.Family", "name": "Flow"}, _tx_0, _request_0)), "error": _error_0};
}

function $$$$047$$$047$$$047context$058level_pending$1261$(_frame_0) {
  return $$$$047$$$047$$$047context$058level_pending_pair$1261$(($$$$047$$$047$$$047context$058level_read$1261$(_frame_0)));
}

function $$$$047$$$047$$$047context$058level_next$1261$(_frame_0, _request_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return {$: "../../../context.Frame", "tx": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058next_declared$1263$({$: "public-cleanup-v1/current-core/ecs/machine.Family", "name": "Level"}, _tx_0, _request_0)), "error": _error_0};
}

function $$$$047$$$047$$$047context$058cells_write$1261$(_frame_0, _incoming_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return $$$$047$$$047$$$047context$058cells_result$1261$(($$$$047$$$047$$$047provider$058cells_set$1261$(_tx_0, _incoming_0)), _error_0);
}

function $$$$047$$$047$$$047context$058owned_write$1261$(_frame_0, _incoming_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return {$: "../../../context.Frame", "tx": ($$$$047$$$047$$$047context$058owned_tx$1261$(_tx_0, _incoming_0)), "error": _error_0};
}

function $$$$047$$$047$$$047context$058spawn$1261$(_frame_0, _payload_0) {
  if (_payload_0.$ === "../../../gameplay.Empty") {
    return $$$$047$$$047$$$047context$058spawn_empty$1261$(_frame_0);
  } else {
    const _owner_0 = _payload_0["owner"];
    return $$$$047$$$047$$$047context$058spawn_seed$1261$(_frame_0, _owner_0);
  }
}

function $$$$047$$$047$$$047gameplay$058hook_body$1261$(_operation_0, _ctx_0) {
  if (_operation_0.$ === "../../../gameplay.FlowEnter") {
    const _ctx_1 = run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1268$(_ctx_0, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Boot"}, "skipSame": false}));
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1269$(_ctx_1, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.High"}, "skipSame": false})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  } else {
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1268$(_ctx_0, {$: "public-cleanup-v1/current-core/ecs/machine.Set", "value": {$: "../../../provider.Boot"}, "skipSame": false})), "snd": {$: "public-cleanup-v1/current-core/ecs/transaction.Success"}};
  }
}

function $$$$047$$$047$$$047context$058flow_current_pair$1260$(_pair_0) {
  const _frame_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058current_view$1260$(_slot_0))};
}

function $$$$047$$$047$$$047context$058flow_read$1260$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return $$$$047$$$047$$$047context$058flow_read_pair$1260$(($public$045cleanup$045v1$047current$045core$047ecs$047machine$058read$1260$(_tx_0)), _error_0);
}

function $$$$047$$$047$$$047context$058flow_pending_pair$1260$(_pair_0) {
  const _frame_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058next_view$1260$(_slot_0))};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058next_declared$1260$(__0, _tx_0, _request_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058next$1260$(_tx_0, _request_0);
}

function $$$$047$$$047$$$047context$058level_pending_pair$1260$(_pair_0) {
  const _frame_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058next_view$1261$(_slot_0))};
}

function $$$$047$$$047$$$047context$058level_read$1260$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return $$$$047$$$047$$$047context$058level_read_pair$1260$(($public$045cleanup$045v1$047current$045core$047ecs$047machine$058read$1261$(_tx_0)), _error_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058next_declared$1261$(__0, _tx_0, _request_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058next$1261$(_tx_0, _request_0);
}

function $$$$047$$$047$$$047context$058cells_result$1260$(_result_0, _error_0) {
  if (_result_0.$ === "../../../../../src/ecs/component.Written") {
    const _tx_0 = _result_0["tx"];
    return {$: "../../../context.Frame", "tx": _tx_0, "error": _error_0};
  } else if (_result_0.$ === "../../../../../src/ecs/component.WriteRejected") {
    const _tx_1 = _result_0["tx"];
    return {$: "../../../context.Frame", "tx": _tx_1, "error": ($$$$047$$$047$$$047context$058first_error$(_error_0, "ComponentWriteRejected"))};
  } else {
    const _tx_2 = _result_0["tx"];
    return {$: "../../../context.Frame", "tx": _tx_2, "error": ($$$$047$$$047$$$047context$058first_error$(_error_0, "ComponentWriteFailure"))};
  }
}

function $$$$047$$$047$$$047provider$058cells_set$1260$(_tx_0, _owner_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047provider$058cells_set_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _owner_0);
}

function $$$$047$$$047$$$047context$058owned_tx$1260$(_tx_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047context$058owned_written$1260$(($$$$047$$$047$$$047context$058owned_replace$1260$(_world_0, _incoming_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047context$058spawn_empty$1260$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return $$$$047$$$047$$$047context$058spawned$1260$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_spawn$1260$(_tx_0, {$: "Unit"})), _error_0);
}

function $$$$047$$$047$$$047context$058spawn_seed$1260$(_frame_0, _owner_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return $$$$047$$$047$$$047context$058spawned$1260$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_spawn$1261$(_tx_0, _owner_0)), _error_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1263$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_write_field$1261$(($$$$047$$$047$$$047gameplay$058hook_flow$1260$(($$$$047$$$047$$$047context$058hook_work$1260$())))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1264$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_write_field$1260$(($$$$047$$$047$$$047gameplay$058hook_level$1260$(($$$$047$$$047$$$047context$058hook_work$1260$())))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047context$058flow_current_pair$1261$(_pair_0) {
  const _frame_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058current_view$1261$(_slot_0))};
}

function $$$$047$$$047$$$047context$058flow_read$1261$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return $$$$047$$$047$$$047context$058flow_read_pair$1261$(($public$045cleanup$045v1$047current$045core$047ecs$047machine$058read$1262$(_tx_0)), _error_0);
}

function $$$$047$$$047$$$047context$058flow_pending_pair$1261$(_pair_0) {
  const _frame_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058next_view$1262$(_slot_0))};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058next_declared$1262$(__0, _tx_0, _request_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058next$1262$(_tx_0, _request_0);
}

function $$$$047$$$047$$$047context$058level_pending_pair$1261$(_pair_0) {
  const _frame_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058next_view$1263$(_slot_0))};
}

function $$$$047$$$047$$$047context$058level_read$1261$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return $$$$047$$$047$$$047context$058level_read_pair$1261$(($public$045cleanup$045v1$047current$045core$047ecs$047machine$058read$1263$(_tx_0)), _error_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058next_declared$1263$(__0, _tx_0, _request_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058next$1263$(_tx_0, _request_0);
}

function $$$$047$$$047$$$047context$058cells_result$1261$(_result_0, _error_0) {
  if (_result_0.$ === "../../../../../src/ecs/component.Written") {
    const _tx_0 = _result_0["tx"];
    return {$: "../../../context.Frame", "tx": _tx_0, "error": _error_0};
  } else if (_result_0.$ === "../../../../../src/ecs/component.WriteRejected") {
    const _tx_1 = _result_0["tx"];
    return {$: "../../../context.Frame", "tx": _tx_1, "error": ($$$$047$$$047$$$047context$058first_error$(_error_0, "ComponentWriteRejected"))};
  } else {
    const _tx_2 = _result_0["tx"];
    return {$: "../../../context.Frame", "tx": _tx_2, "error": ($$$$047$$$047$$$047context$058first_error$(_error_0, "ComponentWriteFailure"))};
  }
}

function $$$$047$$$047$$$047provider$058cells_set$1261$(_tx_0, _owner_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047provider$058cells_set_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _owner_0);
}

function $$$$047$$$047$$$047context$058owned_tx$1261$(_tx_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047context$058owned_written$1261$(($$$$047$$$047$$$047context$058owned_replace$1261$(_world_0, _incoming_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047context$058spawn_empty$1261$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return $$$$047$$$047$$$047context$058spawned$1261$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_spawn$1262$(_tx_0, {$: "Unit"})), _error_0);
}

function $$$$047$$$047$$$047context$058spawn_seed$1261$(_frame_0, _owner_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return $$$$047$$$047$$$047context$058spawned$1261$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_spawn$1263$(_tx_0, _owner_0)), _error_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1268$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_write_field$1263$(($$$$047$$$047$$$047gameplay$058hook_flow$1261$(($$$$047$$$047$$$047context$058hook_work$1261$())))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1269$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058value_write_field$1262$(($$$$047$$$047$$$047gameplay$058hook_level$1261$(($$$$047$$$047$$$047context$058hook_work$1261$())))))(_ctx_0), _value_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058current_view$1260$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Unavailable"};
  } else {
    const _current_0 = _slot_0["current"];
    return {$: "public-cleanup-v1/current-core/ecs/machine.Current", "value": _current_0};
  }
}

function $$$$047$$$047$$$047context$058flow_read_pair$1260$(_pair_0, _error_0) {
  const _tx_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../context.Frame", "tx": _tx_0, "error": _error_0}, "snd": _slot_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058read$1260$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058read_taken$1260$(($$$$047$$$047$$$047provider$058flow_take$1260$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058next_view$1260$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.NoNext"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058pending_view$1260$(_pending_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058next$1260$(_tx_0, _request_0) {
  if (_request_0.$ === "public-cleanup-v1/current-core/ecs/machine.Set") {
    const _value_0 = _request_0["value"];
    const _skipSame_0 = _request_0["skipSame"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058write$1260$(_tx_0, _value_0, _skipSame_0);
  } else {
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset_tx$1260$(_tx_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058next_view$1261$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.NoNext"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058pending_view$1261$(_pending_0);
  }
}

function $$$$047$$$047$$$047context$058level_read_pair$1260$(_pair_0, _error_0) {
  const _tx_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../context.Frame", "tx": _tx_0, "error": _error_0}, "snd": _slot_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058read$1261$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058read_taken$1261$(($$$$047$$$047$$$047provider$058level_take$1260$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058next$1261$(_tx_0, _request_0) {
  if (_request_0.$ === "public-cleanup-v1/current-core/ecs/machine.Set") {
    const _value_0 = _request_0["value"];
    const _skipSame_0 = _request_0["skipSame"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058write$1261$(_tx_0, _value_0, _skipSame_0);
  } else {
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset_tx$1261$(_tx_0);
  }
}

function $$$$047$$$047$$$047context$058first_error$(_old_0, _next_0) {
  if (_old_0.$ === "None") {
    return {$: "Some", "value": _next_0};
  } else {
    return _old_0;
  }
}

function $$$$047$$$047$$$047provider$058cells_set_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _owner_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _bus_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058tx_set$1260$({$: "../../../../../src/ecs/component.Family", "name": "cells"}, {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _bus_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, {$: "public-cleanup-v1/current-core/ecs/world.Handle", "namespace": _ns_0, "id": 1}, _owner_0);
}

function $$$$047$$$047$$$047context$058owned_written$1260$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047context$058owned_restore$1260$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047context$058owned_replace$1260$(_world_0, _incoming_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _old_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _flowStream_0 = _t_0["flowStream"];
  const _levelStream_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _trace_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../../../provider.Resources", "owned": _incoming_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _old_0};
}

function $$$$047$$$047$$$047context$058spawned$1260$(_result_0, _error_0) {
  const _tx_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "public-cleanup-v1/current-core/ecs/world.Reserved") {
    return {$: "../../../context.Frame", "tx": _tx_0, "error": _error_0};
  } else {
    return {$: "../../../context.Frame", "tx": _tx_0, "error": ($$$$047$$$047$$$047context$058first_error$(_error_0, "SpawnRejected"))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_spawn$1260$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_join$1260$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058reserve_id$1260$(_world_0)), _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_spawn$1261$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_join$1261$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058reserve_id$1260$(_world_0)), _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047$$$047$$$047gameplay$058hook_flow$1260$(_caps_0) {
  const _cap_0 = _caps_0["flow"];
  return _cap_0;
}

function $$$$047$$$047$$$047context$058hook_work$1260$() {
  return {$: "../../../gameplay.HookWork", "flow": {$: "../../../../../src/ecs/capabilities.ValueWrite", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047context$058flow_pending$1260$(_x_0);
}), "set": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047context$058flow_next$1260$(_x_1, _x_2);
});
})}, "level": {$: "../../../../../src/ecs/capabilities.ValueWrite", "get": run_clo((_x_3) => {
  return $$$$047$$$047$$$047context$058level_pending$1260$(_x_3);
}), "set": run_clo((_x_4) => {
  return run_clo((_x_5) => {
  return $$$$047$$$047$$$047context$058level_next$1260$(_x_4, _x_5);
});
})}};
}

function $$$$047$$$047$$$047gameplay$058hook_level$1260$(_caps_0) {
  const _cap_0 = _caps_0["level"];
  return _cap_0;
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058current_view$1261$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Unavailable"};
  } else {
    const _current_0 = _slot_0["current"];
    return {$: "public-cleanup-v1/current-core/ecs/machine.Current", "value": _current_0};
  }
}

function $$$$047$$$047$$$047context$058flow_read_pair$1261$(_pair_0, _error_0) {
  const _tx_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../context.Frame", "tx": _tx_0, "error": _error_0}, "snd": _slot_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058read$1262$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058read_taken$1262$(($$$$047$$$047$$$047provider$058flow_take$1261$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058next_view$1262$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.NoNext"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058pending_view$1262$(_pending_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058next$1262$(_tx_0, _request_0) {
  if (_request_0.$ === "public-cleanup-v1/current-core/ecs/machine.Set") {
    const _value_0 = _request_0["value"];
    const _skipSame_0 = _request_0["skipSame"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058write$1262$(_tx_0, _value_0, _skipSame_0);
  } else {
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset_tx$1262$(_tx_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058next_view$1263$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.NoNext"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058pending_view$1263$(_pending_0);
  }
}

function $$$$047$$$047$$$047context$058level_read_pair$1261$(_pair_0, _error_0) {
  const _tx_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../context.Frame", "tx": _tx_0, "error": _error_0}, "snd": _slot_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058read$1263$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058read_taken$1263$(($$$$047$$$047$$$047provider$058level_take$1261$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058next$1263$(_tx_0, _request_0) {
  if (_request_0.$ === "public-cleanup-v1/current-core/ecs/machine.Set") {
    const _value_0 = _request_0["value"];
    const _skipSame_0 = _request_0["skipSame"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058write$1263$(_tx_0, _value_0, _skipSame_0);
  } else {
    return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset_tx$1263$(_tx_0);
  }
}

function $$$$047$$$047$$$047provider$058cells_set_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _owner_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _bus_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058tx_set$1261$({$: "../../../../../src/ecs/component.Family", "name": "cells"}, {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _bus_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, {$: "public-cleanup-v1/current-core/ecs/world.Handle", "namespace": _ns_0, "id": 1}, _owner_0);
}

function $$$$047$$$047$$$047context$058owned_written$1261$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047context$058owned_restore$1261$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047context$058owned_replace$1261$(_world_0, _incoming_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _old_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _flowStream_0 = _t_0["flowStream"];
  const _levelStream_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _trace_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../../../provider.Resources", "owned": _incoming_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _old_0};
}

function $$$$047$$$047$$$047context$058spawned$1261$(_result_0, _error_0) {
  const _tx_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "public-cleanup-v1/current-core/ecs/world.Reserved") {
    return {$: "../../../context.Frame", "tx": _tx_0, "error": _error_0};
  } else {
    return {$: "../../../context.Frame", "tx": _tx_0, "error": ($$$$047$$$047$$$047context$058first_error$(_error_0, "SpawnRejected"))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_spawn$1262$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_join$1262$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058reserve_id$1261$(_world_0)), _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_spawn$1263$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_join$1263$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058reserve_id$1261$(_world_0)), _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047$$$047$$$047gameplay$058hook_flow$1261$(_caps_0) {
  const _cap_0 = _caps_0["flow"];
  return _cap_0;
}

function $$$$047$$$047$$$047context$058hook_work$1261$() {
  return {$: "../../../gameplay.HookWork", "flow": {$: "../../../../../src/ecs/capabilities.ValueWrite", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047context$058flow_pending$1261$(_x_0);
}), "set": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047context$058flow_next$1261$(_x_1, _x_2);
});
})}, "level": {$: "../../../../../src/ecs/capabilities.ValueWrite", "get": run_clo((_x_3) => {
  return $$$$047$$$047$$$047context$058level_pending$1261$(_x_3);
}), "set": run_clo((_x_4) => {
  return run_clo((_x_5) => {
  return $$$$047$$$047$$$047context$058level_next$1261$(_x_4, _x_5);
});
})}};
}

function $$$$047$$$047$$$047gameplay$058hook_level$1261$(_caps_0) {
  const _cap_0 = _caps_0["level"];
  return _cap_0;
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058read_taken$1260$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _slot_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058pending_view$1260$(_pending_0) {
  if (_pending_0.$ === "public-cleanup-v1/current-core/ecs/machine.NoPending") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.NoNext"};
  } else {
    const _value_0 = _pending_0["value"];
    return {$: "public-cleanup-v1/current-core/ecs/machine.Next", "value": _value_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058write$1260$(_tx_0, _value_0, _skipSame_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058write_taken$1260$(($$$$047$$$047$$$047provider$058flow_take$1260$(_world_0)), _undo_0, _commands_0, _events_0, _value_0, _skipSame_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset_tx$1260$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset_taken$1260$(($$$$047$$$047$$$047provider$058flow_take$1260$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058pending_view$1261$(_pending_0) {
  if (_pending_0.$ === "public-cleanup-v1/current-core/ecs/machine.NoPending") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.NoNext"};
  } else {
    const _value_0 = _pending_0["value"];
    return {$: "public-cleanup-v1/current-core/ecs/machine.Next", "value": _value_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058read_taken$1261$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _slot_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058write$1261$(_tx_0, _value_0, _skipSame_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058write_taken$1261$(($$$$047$$$047$$$047provider$058level_take$1260$(_world_0)), _undo_0, _commands_0, _events_0, _value_0, _skipSame_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset_tx$1261$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset_taken$1261$(($$$$047$$$047$$$047provider$058level_take$1260$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058tx_set$1260$(_family_0, _tx_0, _handle_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058tx_set_fused$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_allowed$1260$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047context$058owned_restore$1260$(_world_0, _old_0) {
  return $$$$047$$$047$$$047context$058owned_restored$1260$(($$$$047$$$047$$$047context$058owned_replace$1260$(_world_0, _old_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_join$1260$(_reserved_0, _undo_0, _commands_0, _events_0, _payload_0) {
  const _world_0 = _reserved_0["fst"];
  const _reservation_0 = _reserved_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_reserved$1260$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058reserve_id$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058reserve_available$1260$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_join$1261$(_reserved_0, _undo_0, _commands_0, _events_0, _payload_0) {
  const _world_0 = _reserved_0["fst"];
  const _reservation_0 = _reserved_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_reserved$1261$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058read_taken$1262$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _slot_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058pending_view$1262$(_pending_0) {
  if (_pending_0.$ === "public-cleanup-v1/current-core/ecs/machine.NoPending") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.NoNext"};
  } else {
    const _value_0 = _pending_0["value"];
    return {$: "public-cleanup-v1/current-core/ecs/machine.Next", "value": _value_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058write$1262$(_tx_0, _value_0, _skipSame_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058write_taken$1262$(($$$$047$$$047$$$047provider$058flow_take$1261$(_world_0)), _undo_0, _commands_0, _events_0, _value_0, _skipSame_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset_tx$1262$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset_taken$1262$(($$$$047$$$047$$$047provider$058flow_take$1261$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058pending_view$1263$(_pending_0) {
  if (_pending_0.$ === "public-cleanup-v1/current-core/ecs/machine.NoPending") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.NoNext"};
  } else {
    const _value_0 = _pending_0["value"];
    return {$: "public-cleanup-v1/current-core/ecs/machine.Next", "value": _value_0};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058read_taken$1263$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _slot_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058write$1263$(_tx_0, _value_0, _skipSame_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058write_taken$1263$(($$$$047$$$047$$$047provider$058level_take$1261$(_world_0)), _undo_0, _commands_0, _events_0, _value_0, _skipSame_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset_tx$1263$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset_taken$1263$(($$$$047$$$047$$$047provider$058level_take$1261$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058tx_set$1261$(_family_0, _tx_0, _handle_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058tx_set_fused$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_allowed$1261$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047context$058owned_restore$1261$(_world_0, _old_0) {
  return $$$$047$$$047$$$047context$058owned_restored$1261$(($$$$047$$$047$$$047context$058owned_replace$1261$(_world_0, _old_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_join$1262$(_reserved_0, _undo_0, _commands_0, _events_0, _payload_0) {
  const _world_0 = _reserved_0["fst"];
  const _reservation_0 = _reserved_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_reserved$1262$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058reserve_id$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058reserve_available$1261$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_join$1263$(_reserved_0, _undo_0, _commands_0, _events_0, _payload_0) {
  const _world_0 = _reserved_0["fst"];
  const _reservation_0 = _reserved_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_reserved$1263$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058write_taken$1260$(_pair_0, _undo_0, _commands_0, _events_0, _value_0, _skipSame_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047provider$058flow_put$1260$(_world_0, ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058queue$1260$(_old_0, _value_0, _skipSame_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047provider$058flow_put$1260$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset_taken$1260$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047provider$058flow_put$1260$(_world_0, ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset$1260$(_old_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047provider$058flow_put$1260$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058write_taken$1261$(_pair_0, _undo_0, _commands_0, _events_0, _value_0, _skipSame_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047provider$058level_put$1260$(_world_0, ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058queue$1261$(_old_0, _value_0, _skipSame_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047provider$058level_put$1260$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset_taken$1261$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047provider$058level_put$1260$(_world_0, ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset$1261$(_old_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047provider$058level_put$1260$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058tx_set_fused$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _observed_0) {
  const _result_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058tx_written$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": {$: "Some", "value": _incoming_0}, "error": {$: "public-cleanup-v1/current-core/ecs/world.MissingEntity"}}, "snd": {$: "../../../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_world$1260$(_id_0, _incoming_0, _world_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058valid$1260$(_world_0, _handle_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058valid_join$1260$(_handle_0, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047context$058owned_restored$1260$(_pair_0) {
  const _world_0 = _pair_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_reserved$1260$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0) {
  if (_reservation_0.$ === "public-cleanup-v1/current-core/ecs/world.ReservationRejected") {
    const _error_0 = _reservation_0["error"];
    return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/world.ReservationRejected", "error": _error_0}};
  } else {
    const _handle_0 = _reservation_0["handle"];
    return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_apply$1260$(_x_0, _handle_0, _payload_0);
}), "tail": _commands_0}, "events": _events_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/world.Reserved", "handle": _handle_0}};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058reserve_available$1260$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "public-cleanup-v1/current-core/ecs/world.ReservationRejected", "error": {$: "public-cleanup-v1/current-core/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $public$045cleanup$045v1$047current$045core$047ecs$047world$058reserve_finish$1260$({$: "public-cleanup-v1/current-core/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $public$045cleanup$045v1$047current$045core$047ecs$047world$058reserve_finish$1260$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_reserved$1261$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0) {
  if (_reservation_0.$ === "public-cleanup-v1/current-core/ecs/world.ReservationRejected") {
    const _error_0 = _reservation_0["error"];
    return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/world.ReservationRejected", "error": _error_0}};
  } else {
    const _handle_0 = _reservation_0["handle"];
    return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_apply$1261$(_x_0, _handle_0, _payload_0);
}), "tail": _commands_0}, "events": _events_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/world.Reserved", "handle": _handle_0}};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058write_taken$1262$(_pair_0, _undo_0, _commands_0, _events_0, _value_0, _skipSame_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047provider$058flow_put$1261$(_world_0, ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058queue$1262$(_old_0, _value_0, _skipSame_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047provider$058flow_put$1261$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset_taken$1262$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047provider$058flow_put$1261$(_world_0, ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset$1262$(_old_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047provider$058flow_put$1261$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058write_taken$1263$(_pair_0, _undo_0, _commands_0, _events_0, _value_0, _skipSame_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047provider$058level_put$1261$(_world_0, ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058queue$1263$(_old_0, _value_0, _skipSame_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047provider$058level_put$1261$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset_taken$1263$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047provider$058level_put$1261$(_world_0, ($public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset$1263$(_old_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047provider$058level_put$1261$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058tx_set_fused$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _observed_0) {
  const _result_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058tx_written$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_allowed$1261$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": {$: "Some", "value": _incoming_0}, "error": {$: "public-cleanup-v1/current-core/ecs/world.MissingEntity"}}, "snd": {$: "../../../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_world$1261$(_id_0, _incoming_0, _world_0);
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058valid$1261$(_world_0, _handle_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058valid_join$1261$(_handle_0, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047context$058owned_restored$1261$(_pair_0) {
  const _world_0 = _pair_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_reserved$1262$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0) {
  if (_reservation_0.$ === "public-cleanup-v1/current-core/ecs/world.ReservationRejected") {
    const _error_0 = _reservation_0["error"];
    return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/world.ReservationRejected", "error": _error_0}};
  } else {
    const _handle_0 = _reservation_0["handle"];
    return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_apply$1262$(_x_0, _handle_0, _payload_0);
}), "tail": _commands_0}, "events": _events_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/world.Reserved", "handle": _handle_0}};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058reserve_available$1261$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "public-cleanup-v1/current-core/ecs/world.ReservationRejected", "error": {$: "public-cleanup-v1/current-core/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $public$045cleanup$045v1$047current$045core$047ecs$047world$058reserve_finish$1261$({$: "public-cleanup-v1/current-core/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $public$045cleanup$045v1$047current$045core$047ecs$047world$058reserve_finish$1261$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_reserved$1263$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0) {
  if (_reservation_0.$ === "public-cleanup-v1/current-core/ecs/world.ReservationRejected") {
    const _error_0 = _reservation_0["error"];
    return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/world.ReservationRejected", "error": _error_0}};
  } else {
    const _handle_0 = _reservation_0["handle"];
    return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_apply$1263$(_x_0, _handle_0, _payload_0);
}), "tail": _commands_0}, "events": _events_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/world.Reserved", "handle": _handle_0}};
  }
}

function $$$$047$$$047$$$047provider$058flow_put$1260$(_world_0, _slot_0) {
  return $$$$047$$$047$$$047world$058put$1260$(_world_0, _slot_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset$1260$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _current_0, "pending": {$: "public-cleanup-v1/current-core/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047provider$058level_put$1260$(_world_0, _slot_0) {
  return $$$$047$$$047$$$047world$058put$1261$(_world_0, _slot_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset$1261$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _current_0, "pending": {$: "public-cleanup-v1/current-core/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058tx_written$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../../../../src/ecs/component.Written", "tx": {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1260$(_handle_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore$1260$(_family_0, _handle_0, _previous_0, _x_0)));
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["incoming"];
    if (_t_0.$ === "Some") {
      const _incoming_0 = _t_0["value"];
      const _error_0 = _result_0["error"];
      return {$: "../../../../../src/ecs/component.WriteRejected", "tx": {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "incoming": _incoming_0, "error": _error_0};
    } else {
      const _error_1 = _result_0["error"];
      return {$: "../../../../../src/ecs/component.WriteFailure", "tx": {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "error": _error_1};
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_world$1260$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_replaced$1260$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058with_store_finish$1261$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_store$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))), (_clock_0 < 4294967295), ($$$$047$$$047$$$047provider$058store_take$1260$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))))));
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058valid_join$1260$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_apply$1260$(_world_0, _handle_0, _payload_0) {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawned$1260$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058activate$1260$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058reserve_finish$1260$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/world.Reserved", "handle": {$: "public-cleanup-v1/current-core/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "public-cleanup-v1/current-core/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_apply$1261$(_world_0, _handle_0, _payload_0) {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawned$1261$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058activate$1260$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $$$$047$$$047$$$047provider$058flow_put$1261$(_world_0, _slot_0) {
  return $$$$047$$$047$$$047world$058put$1262$(_world_0, _slot_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset$1262$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _current_0, "pending": {$: "public-cleanup-v1/current-core/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047provider$058level_put$1261$(_world_0, _slot_0) {
  return $$$$047$$$047$$$047world$058put$1263$(_world_0, _slot_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047machine$058reset$1263$(_slot_0) {
  if (_slot_0.$ === "public-cleanup-v1/current-core/ecs/machine.Missing") {
    return {$: "public-cleanup-v1/current-core/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "public-cleanup-v1/current-core/ecs/machine.Present", "current": _current_0, "pending": {$: "public-cleanup-v1/current-core/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058tx_written$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../../../../src/ecs/component.Written", "tx": {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1261$(_handle_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore$1261$(_family_0, _handle_0, _previous_0, _x_0)));
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["incoming"];
    if (_t_0.$ === "Some") {
      const _incoming_0 = _t_0["value"];
      const _error_0 = _result_0["error"];
      return {$: "../../../../../src/ecs/component.WriteRejected", "tx": {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "incoming": _incoming_0, "error": _error_0};
    } else {
      const _error_1 = _result_0["error"];
      return {$: "../../../../../src/ecs/component.WriteFailure", "tx": {$: "public-cleanup-v1/current-core/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "error": _error_1};
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_world$1261$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_replaced$1261$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058with_store_finish$1264$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_store$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))), (_clock_0 < 4294967295), ($$$$047$$$047$$$047provider$058store_take$1261$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))))));
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058valid_join$1261$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_apply$1262$(_world_0, _handle_0, _payload_0) {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawned$1262$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058activate$1261$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058reserve_finish$1261$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/world.Reserved", "handle": {$: "public-cleanup-v1/current-core/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_apply$1263$(_world_0, _handle_0, _payload_0) {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawned$1263$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058activate$1261$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $$$$047$$$047$$$047world$058put$1260$(_world_0, _slot_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": ($$$$047$$$047$$$047provider$058flow_put_resource$1260$(_resources_0, _slot_0)), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047world$058put$1261$(_world_0, _slot_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": ($$$$047$$$047$$$047provider$058level_put_resource$1260$(_resources_0, _slot_0)), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1260$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1260$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1260$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore$1260$(_family_0, _handle_0, _incoming_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_allowed$1260$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_replaced$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _t_1 = _t_0["fst"];
  if (_t_1.$ === "../../../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_1["previous"];
    const _stamp_0 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0}, "snd": _stamp_0};
  } else {
    const _incoming_0 = _t_1["incoming"];
    const _stamp_1 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "public-cleanup-v1/current-core/ecs/world.CapacityExceeded"}}, "snd": _stamp_1};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058with_store_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_store$1260$(_id_0, _incoming_0, _tick_0, _allowed_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_column$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, _allowed_0) {
  if (!_allowed_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047$$$047$$$047provider$058store_take$1260$(_store_0) {
  const _column_0 = _store_0["cells"];
  return {$: "Tuple", "fst": {$: "Unit"}, "snd": _column_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047world$058live_join$1260$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawned$1260$(_activated_0, _handle_0, _payload_0) {
  const _world_0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "public-cleanup-v1/current-core/ecs/world.Accepted") {
    return $$$$047$$$047$$$047context$058populate_empty$1260$(_world_0, _handle_0, _payload_0);
  } else {
    return _world_0;
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058activate$1260$(_world_0, _handle_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058set_live_join$1260$(true, _handle_0, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawned$1261$(_activated_0, _handle_0, _payload_0) {
  const _world_0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "public-cleanup-v1/current-core/ecs/world.Accepted") {
    return $$$$047$$$047$$$047provider$058populate_cells$1260$(_world_0, _handle_0, _payload_0);
  } else {
    return _world_0;
  }
}

function $$$$047$$$047$$$047world$058put$1262$(_world_0, _slot_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": ($$$$047$$$047$$$047provider$058flow_put_resource$1261$(_resources_0, _slot_0)), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047world$058put$1263$(_world_0, _slot_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": ($$$$047$$$047$$$047provider$058level_put_resource$1261$(_resources_0, _slot_0)), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1261$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1261$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1261$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore$1261$(_family_0, _handle_0, _incoming_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_allowed$1261$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_replaced$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _t_1 = _t_0["fst"];
  if (_t_1.$ === "../../../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_1["previous"];
    const _stamp_0 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0}, "snd": _stamp_0};
  } else {
    const _incoming_0 = _t_1["incoming"];
    const _stamp_1 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "public-cleanup-v1/current-core/ecs/world.CapacityExceeded"}}, "snd": _stamp_1};
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058with_store_finish$1264$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_store$1261$(_id_0, _incoming_0, _tick_0, _allowed_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_column$1261$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1261$(_column_0, _id_0)));
}

function $$$$047$$$047$$$047provider$058store_take$1261$(_store_0) {
  const _column_0 = _store_0["cells"];
  return {$: "Tuple", "fst": {$: "Unit"}, "snd": _column_0};
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $public$045cleanup$045v1$047current$045core$047ecs$047world$058live_join$1261$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawned$1262$(_activated_0, _handle_0, _payload_0) {
  const _world_0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "public-cleanup-v1/current-core/ecs/world.Accepted") {
    return $$$$047$$$047$$$047context$058populate_empty$1261$(_world_0, _handle_0, _payload_0);
  } else {
    return _world_0;
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058activate$1261$(_world_0, _handle_0) {
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058set_live_join$1261$(true, _handle_0, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawned$1263$(_activated_0, _handle_0, _payload_0) {
  const _world_0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "public-cleanup-v1/current-core/ecs/world.Accepted") {
    return $$$$047$$$047$$$047provider$058populate_cells$1261$(_world_0, _handle_0, _payload_0);
  } else {
    return _world_0;
  }
}

function $$$$047$$$047$$$047provider$058flow_put_resource$1260$(_resources_0, _flow_0) {
  const _owned_0 = _resources_0["owned"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0};
}

function $$$$047$$$047$$$047provider$058level_put_resource$1260$(_resources_0, _level_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1260$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058with_store_finish$1260$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047provider$058store_take$1260$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return _world_0;
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_observed$1260$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_world$1260$(_id_0, _incoming_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_column$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, _observed_0) {
  if (!_allowed_0) {
    const _column_0 = _observed_0["fst"];
    const _stamp_0 = _observed_0["snd"];
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047provider$058store_put$1260$(_rest_0, _column_0)), "snd": {$: "Tuple", "fst": {$: "../../../../../src/ecs/component.SwapRejected", "incoming": {$: "Some", "value": _incoming_0}}, "snd": _stamp_0}};
  } else {
    const _column_1 = _observed_0["fst"];
    const _stamp_1 = _observed_0["snd"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_store_join$1260$(_stamp_1, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, true, _tick_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_1, _id_0)), _id_0, {$: "Some", "value": _incoming_0})))));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058live_join$1260$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047$$$047$$$047context$058populate_empty$1260$(_world_0, __0, __1) {
  return _world_0;
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058set_live_join$1260$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047provider$058populate_cells$1260$(_world_0, _handle_0, _owner_0) {
  return $$$$047$$$047$$$047provider$058populated$1260$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replace$1260$({$: "../../../../../src/ecs/component.Family", "name": "cells"}, _world_0, _handle_0, {$: "Some", "value": _owner_0})));
}

function $$$$047$$$047$$$047provider$058flow_put_resource$1261$(_resources_0, _flow_0) {
  const _owned_0 = _resources_0["owned"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0};
}

function $$$$047$$$047$$$047provider$058level_put_resource$1261$(_resources_0, _level_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1261$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058with_store_finish$1263$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1261$(_id_0, _stamp_0, ($$$$047$$$047$$$047provider$058store_take$1261$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_allowed$1261$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return _world_0;
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_observed$1261$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_world$1261$(_id_0, _incoming_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_column$1261$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, _observed_0) {
  if (!_allowed_0) {
    const _column_0 = _observed_0["fst"];
    const _stamp_0 = _observed_0["snd"];
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047provider$058store_put$1261$(_rest_0, _column_0)), "snd": {$: "Tuple", "fst": {$: "../../../../../src/ecs/component.SwapRejected", "incoming": {$: "Some", "value": _incoming_0}}, "snd": _stamp_0}};
  } else {
    const _column_1 = _observed_0["fst"];
    const _stamp_1 = _observed_0["snd"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_store_join$1261$(_stamp_1, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, true, _tick_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure$1261$(_column_1, _id_0)), _id_0, {$: "Some", "value": _incoming_0})))));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058live_join$1261$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047$$$047$$$047context$058populate_empty$1261$(_world_0, __0, __1) {
  return _world_0;
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058set_live_join$1261$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047provider$058populate_cells$1261$(_world_0, _handle_0, _owner_0) {
  return $$$$047$$$047$$$047provider$058populated$1261$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replace$1261$({$: "../../../../../src/ecs/component.Family", "name": "cells"}, _world_0, _handle_0, {$: "Some", "value": _owner_0})));
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058with_store_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1260$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047provider$058store_put$1260$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_observed$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_world$1260$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058with_store_finish$1260$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_store$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047provider$058store_take$1260$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047provider$058store_put$1260$(__0, _column_0) {
  return {$: "../../../provider.Store", "cells": _column_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_store_join$1260$(_stamp_0, _result_0) {
  const _store_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _store_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": _stamp_0}};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1260$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047provider$058store_put$1260$(_rest_0, _column_1)), "snd": {$: "../../../../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "../../../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058choose$((_key_0 === _id_0), _stamp_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "public-cleanup-v1/current-core/ecs/world.Rejected", "error": {$: "public-cleanup-v1/current-core/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/world.Accepted"}};
  }
}

function $$$$047$$$047$$$047provider$058populated$1260$(_result_0) {
  if (_result_0.$ === "../../../../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return $$$$047$$$047$$$047provider$058populate_error$1260$(_world_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replace$1260$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1260$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058with_store_finish$1263$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1261$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047provider$058store_put$1261$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1261$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_observed$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_world$1261$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058with_store_finish$1263$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_store$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047provider$058store_take$1261$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047provider$058store_put$1261$(__0, _column_0) {
  return {$: "../../../provider.Store", "cells": _column_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_store_join$1261$(_stamp_0, _result_0) {
  const _store_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _store_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": _stamp_0}};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1261$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047provider$058store_put$1261$(_rest_0, _column_1)), "snd": {$: "../../../../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure$1261$(_column_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1261$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1261$(_values_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1261$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "public-cleanup-v1/current-core/ecs/world.Rejected", "error": {$: "public-cleanup-v1/current-core/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "public-cleanup-v1/current-core/ecs/world.Accepted"}};
  }
}

function $$$$047$$$047$$$047provider$058populated$1261$(_result_0) {
  if (_result_0.$ === "../../../../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return $$$$047$$$047$$$047provider$058populate_error$1261$(_world_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replace$1261$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1261$(($public$045cleanup$045v1$047current$045core$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_store$1260$(_id_0, _incoming_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_swap$1260$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1260$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047provider$058store_put$1260$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058choose$(_found_0, _stamp_0, _other_0) {
  if (_found_0) {
    return _stamp_0;
  } else {
    return _other_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)), (_id_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047$$$047$$$047provider$058populate_error$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _flowStream_0 = _t_0["flowStream"];
  const _levelStream_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _trace_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": ($List$append$(_trace_0, {$: "Con", "head": "POPULATE_REJECTED", "tail": {$: "Nil"}}))}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "public-cleanup-v1/current-core/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1260$(_id_0, _incoming_0, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1261$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_store$1261$(_id_0, _incoming_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_swap$1261$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure$1261$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1261$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047provider$058store_put$1261$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1261$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1261$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1261$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047$$$047$$$047provider$058populate_error$1261$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _flowStream_0 = _t_0["flowStream"];
  const _levelStream_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _trace_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": ($List$append$(_trace_0, {$: "Con", "head": "POPULATE_REJECTED", "tail": {$: "Nil"}}))}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1261$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "public-cleanup-v1/current-core/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1261$(_id_0, _incoming_0, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_entries_0, _id_0, _stamp_0) {
  return {$: "Con", "head": {$: "../../../../../src/ecs/lifecycle.Entry", "id": _id_0, "stamp": _stamp_0}, "tail": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_swap$1260$(_rest_0, _result_0) {
  if (_result_0.$ === "../../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047provider$058store_put$1260$(_rest_0, _column_0)), "snd": {$: "Unit"}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047provider$058store_put$1260$(_rest_0, _column_1)), "snd": {$: "Unit"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../src/ecs/column.Rejected", "column": {$: "../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swapped$1260$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../src/ecs/column.Rejected", "column": {$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1260$({$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058seek$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../src/ecs/column.Rejected", "column": {$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1260$({$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058grow$1260$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0) {
  return {$: "../../../../../src/ecs/column.Indexed", "state": {$: "../../../../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0, _fits_0) {
  if (!_isnormal_0) {
    return {$: "Tuple", "fst": {$: "../../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_exceptional_0, _id_0))};
  } else {
    if (!_fits_0) {
      return {$: "Tuple", "fst": {$: "../../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../../../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
    } else {
      const _x_0 = ((_id_0 - 1) >>> 0);
      return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, {$: "Tuple", fst: _added_0, snd: _added_0[_x_0 % _added_0.length]});
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0) {
  return $Bool$and$((_id_0 > 0), (_id_0 <= 131072));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1260$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1260$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_incoming_0)));
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_swap$1261$(_rest_0, _result_0) {
  if (_result_0.$ === "../../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047provider$058store_put$1261$(_rest_0, _column_0)), "snd": {$: "Unit"}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047provider$058store_put$1261$(_rest_0, _column_1)), "snd": {$: "Unit"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../src/ecs/column.Rejected", "column": {$: "../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swapped$1261$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../src/ecs/column.Rejected", "column": {$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1261$({$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058seek$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../src/ecs/column.Rejected", "column": {$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1261$({$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058grow$1261$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, {$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1261$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, {$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0) {
  return {$: "../../../../../src/ecs/column.Indexed", "state": {$: "../../../../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1261$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1261$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_incoming_0)));
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058keep$((_key_0 === _id_0), {$: "../../../../../src/ecs/lifecycle.Entry", "id": _key_0, "stamp": _stamp_0}, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0) {
  if (!_incoming_0) {
    return {$: "../../../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swapped$1260$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return {$: "../../../../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1260$(_column_0) {
  if (_column_0.$ === "../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_state$1260$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1260$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../src/ecs/column.Rejected", "column": {$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../src/ecs/column.Rejected", "column": {$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $U32$log2$(_n_0) {
  return $U32$log2$go$(5, _n_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1260$(_column_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1260$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _observed_0) {
  const _added_0 = _observed_0["fst"];
  const _first_0 = _observed_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, {$: "Tuple", fst: _changed_0, snd: _changed_0[_x_0 % _changed_0.length]});
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1260$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "public-cleanup-v1/current-core/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1260$(_id_0, _present_0, _incoming_1, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swapped$1261$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return {$: "../../../../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1261$(_column_0) {
  if (_column_0.$ === "../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_state$1261$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1261$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../src/ecs/column.Rejected", "column": {$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../src/ecs/column.Owned", "state": {$: "../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../src/ecs/column.Rejected", "column": {$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058grow$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1261$(_column_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1261$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1261$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1261$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "public-cleanup-v1/current-core/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1261$(_id_0, _present_0, _incoming_1, ($public$045cleanup$045v1$047current$045core$047ecs$047world$058advance_clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058keep$(_equal_0, _entry_0, _rest_0) {
  if (_equal_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _entry_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0) {
  if (!_isnormal_0) {
    return {$: "../../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_exceptional_0, _id_0, _stamp_0))};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_grow$(17, _id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, (_id_0 <= _capacity_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0) {
  if (!_wasPresent_0) {
    return {$: "../../../../../src/ecs/lifecycle.Stamp", "added": _tick_0, "changed": _tick_0};
  } else {
    const _added_0 = _stamp_0["added"];
    return {$: "../../../../../src/ecs/lifecycle.Stamp", "added": _added_0, "changed": _tick_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_rest_0)), ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_rest_0)));
  }
}

function $U32$log2$go$($0, $1, $2) {
  for (;;) {
    {
      const _k_0 = $0;
      const _n_0 = $1;
      const _b_0 = $2;
      if (_k_0 === 0) {
        return _b_0;
      } else {
        const _p_0 = (_k_0 - 1);
        const _x_0 = (_p_0 >= 32 ? 0 : (1 << _p_0) >>> 0);
        const _s_0 = _x_0;
        const _x_1 = (_s_0 >= 32 ? 0 : (_n_0 >>> _s_0) >>> 0);
        const _x_2 = ($Bool$to_u32$((_x_1 !== 0)));
        const _t_0 = nat_chk(_s_0 * _x_2);
        $0 = _p_0;
        $1 = (_t_0 >= 32 ? 0 : (_n_0 >>> _t_0) >>> 0);
        $2 = nat_chk(_b_0 + _t_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, _column_0) {
  if (_column_0.$ === "../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, _observed_0) {
  const _changed_0 = _observed_0["fst"];
  const _last_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../../../../../src/ecs/lifecycle.Stamp", "added": _first_0, "changed": _last_0}};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1260$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replaced$1260$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_world$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058advance_clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($public$045cleanup$045v1$047current$045core$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($public$045cleanup$045v1$047current$045core$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1261$(_target_0, _column_0) {
  if (_column_0.$ === "../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1261$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replaced$1261$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_world$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058advance_clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($public$045cleanup$045v1$047current$045core$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($public$045cleanup$045v1$047current$045core$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_grow$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _id_0 = $1;
      const _stamp_0 = $2;
      const _added_0 = $3;
      const _changed_0 = $4;
      const _capacity_0 = $5;
      const _depth_0 = $6;
      const _exceptional_0 = $7;
      const _fits_0 = $8;
      if (_fuel_0 === 0) {
        if (_fits_0) {
          return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          return {$: "../../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_fits_0) {
          return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          const _next_0 = ((_capacity_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _stamp_0;
          $3 = array_node(_added_0, array_new(_depth_0, 0));
          $4 = array_node(_changed_0, array_new(_depth_0, 0));
          $5 = _next_0;
          $6 = nat_chk(_depth_0 + 1);
          $7 = _exceptional_0;
          $8 = (_id_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $Bool$to_u32$(_b_0) {
  if (!_b_0) {
    return 0;
  } else {
    return 1;
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replaced$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "public-cleanup-v1/current-core/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_world$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058with_store_finish$1262$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_store$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047provider$058store_take$1260$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058replaced$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "public-cleanup-v1/current-core/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_world$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $public$045cleanup$045v1$047current$045core$047ecs$047world$058with_store_finish$1265$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_store$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047provider$058store_take$1261$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0) {
  const _first_0 = _stamp_0["added"];
  const _last_0 = _stamp_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = ((_id_0 - 1) >>> 0);
  return {$: "../../../../../src/ecs/indexed-lifecycle.Metadata", "added": (_added_0[_x_0 % _added_0.length] = _first_0, _added_0), "changed": (_changed_0[_x_1 % _changed_0.length] = _last_0, _changed_0), "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$($0, $1) {
  for (;;) {
    {
      const _rows_0 = $0;
      const _values_0 = $1;
      if (_rows_0.$ === "../../../../../src/ecs/owner-handoff.HandoffNil") {
        return _values_0;
      } else {
        const _id_0 = _rows_0["id"];
        const _owner_0 = _rows_0["owner"];
        const _rest_0 = _rows_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        const _x_1 = {$: "Some", "value": _owner_0};
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _x_1, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058with_store_finish$1262$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_store$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $public$045cleanup$045v1$047current$045core$047ecs$047world$058with_store_finish$1265$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "public-cleanup-v1/current-core/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_store$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(($$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure$1261$(_column_0, _id_0)), _id_0, _incoming_0)));
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);