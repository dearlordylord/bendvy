function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $main$() {
  const _x_0 = ($teardown$1261$(($scenario$1261$())));
  const _x_1 = ($teardown$1260$(($scenario$1260$())));
  const _x_2 = ("\nSCHEMA=B\n" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  return ("SCHEMA=A\n" + _x_3);
}

function $teardown$1260$(_result_0) {
  if (_result_0.$ === "Delivered") {
    const _t_0 = _result_0["observed"];
    const _rows_0 = _t_0["rows"];
    return $String$join$(_rows_0, "\n");
  } else if (_result_0.$ === "RegistrationFailed") {
    return "registration-failed";
  } else {
    return "creation-failed";
  }
}

function $scenario$1260$() {
  return $created$1260$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1260$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$()), ($resources$1260$()))));
}

function $teardown$1261$(_result_0) {
  if (_result_0.$ === "Delivered") {
    const _t_0 = _result_0["observed"];
    const _rows_0 = _t_0["rows"];
    return $String$join$(_rows_0, "\n");
  } else if (_result_0.$ === "RegistrationFailed") {
    return "registration-failed";
  } else {
    return "creation-failed";
  }
}

function $scenario$1261$() {
  return $created$1261$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1261$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$()), ($resources$1261$()))));
}

function $String$join$(_xs_0, _sep_0) {
  if (_xs_0.$ === "Nil") {
    return "";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return $String$join$go$(_t_0, _h_0, _sep_0);
  }
}

function $created$1260$(_result_0) {
  if (_result_0.$ === "../../../../../bendvy/src/ecs/world.CreateRejected") {
    const _factory_0 = _result_0["factory"];
    const _resource_0 = _result_0["resource"];
    return {$: "CreationFailed", "factory": _factory_0, "resource": _resource_0};
  } else {
    const _factory_1 = _result_0["factory"];
    const _world_0 = _result_0["world"];
    return $declared_registered$1260$(_factory_1, _world_0, ($declaration$1260$()));
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$() {
  return {$: "../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": 1};
}

function $resources$1260$() {
  return {$: "scene/provider.Resources", "owned": array_node([30], [130]), "flow": {$: "../../../../../bendvy/src/ecs/machine.Missing"}, "level": {$: "../../../../../bendvy/src/ecs/machine.Missing"}, "flowStream": ($scene$047stream$058empty$1260$()), "levelStream": ($scene$047stream$058empty$1261$()), "frame": 0, "tick": 0, "trace": {$: "Nil"}};
}

function $created$1261$(_result_0) {
  if (_result_0.$ === "../../../../../bendvy/src/ecs/world.CreateRejected") {
    const _factory_0 = _result_0["factory"];
    const _resource_0 = _result_0["resource"];
    return {$: "CreationFailed", "factory": _factory_0, "resource": _resource_0};
  } else {
    const _factory_1 = _result_0["factory"];
    const _world_0 = _result_0["world"];
    return $declared_registered$1261$(_factory_1, _world_0, ($declaration$1261$()));
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1261$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1261$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $resources$1261$() {
  return {$: "scene/provider.Resources", "owned": array_node([30], [130]), "flow": {$: "../../../../../bendvy/src/ecs/machine.Missing"}, "level": {$: "../../../../../bendvy/src/ecs/machine.Missing"}, "flowStream": ($scene$047stream$058empty$1260$()), "levelStream": ($scene$047stream$058empty$1261$()), "frame": 0, "tick": 0, "trace": {$: "Nil"}};
}

function $String$join$go$(_xs_0, _h_0, _sep_0) {
  if (_xs_0.$ === "Nil") {
    return _h_0;
  } else {
    const _h2_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($String$join$go$(_t_0, _h2_0, _sep_0));
    const _x_1 = (_sep_0 + _x_0);
    return (_h_0 + _x_1);
  }
}

function $declared_registered$1260$(_factory_0, _world_0, _declared_0) {
  const _family_0 = _declared_0["family"];
  const _name_0 = _declared_0["name"];
  return $registered$1260$(_factory_0, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1260$(_world_0, _name_0, ($access$1260$({$: "Declaration", "family": _family_0, "name": _name_0})))));
}

function $declaration$1260$() {
  return {$: "Declaration", "family": {$: "../../../../../bendvy/src/ecs/machine.Family", "name": "Flow"}, "name": "flow-only"};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../../bendvy/src/ecs/world.CreateRejected", "factory": {$: "../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../../bendvy/src/ecs/world.Created", "factory": {$: "../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($scene$047provider$058empty_store$1260$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $scene$047stream$058empty$1260$() {
  return {$: "scene/stream.Stream", "batches": {$: "Nil"}, "positions": {$: "Nil"}, "droppedThrough": 0, "frameStart": 0};
}

function $scene$047stream$058empty$1261$() {
  return {$: "scene/stream.Stream", "batches": {$: "Nil"}, "positions": {$: "Nil"}, "droppedThrough": 0, "frameStart": 0};
}

function $declared_registered$1261$(_factory_0, _world_0, _declared_0) {
  const _family_0 = _declared_0["family"];
  const _name_0 = _declared_0["name"];
  return $registered$1261$(_factory_0, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1261$(_world_0, _name_0, ($access$1261$({$: "Declaration", "family": _family_0, "name": _name_0})))));
}

function $declaration$1261$() {
  return {$: "Declaration", "family": {$: "../../../../../bendvy/src/ecs/machine.Family", "name": "Flow"}, "name": "flow-only"};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1261$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../../bendvy/src/ecs/world.CreateRejected", "factory": {$: "../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../../bendvy/src/ecs/world.Created", "factory": {$: "../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($scene$047provider$058empty_store$1261$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $registered$1260$(_factory_0, _result_0) {
  if (_result_0.$ === "../../../../../bendvy/src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "RegistrationFailed", "factory": _factory_0, "world": _world_0};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    const _current_0 = ($snapshot$1260$("registered-missing", "ok", {$: "Observed", "registry": _registry_0, "world": _world_1, "rows": {$: "Nil"}}));
    const _current_1 = ($step$1260$("false-gate-missing", false, _current_0));
    return $install$1260$(_factory_0, ($step$1260$("required-flow-missing", true, _current_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1260$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $access$1260$(_declared_0) {
  const _t_0 = _declared_0["family"];
  const _name_0 = _t_0["name"];
  const _x_0 = (_name_0 + ".read");
  return {$: "Con", "head": ("machine." + _x_0), "tail": {$: "Nil"}};
}

function $scene$047provider$058empty_store$1260$(__0) {
  return {$: "scene/provider.Store", "cells": {$: "../../../../../bendvy/src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}}};
}

function $registered$1261$(_factory_0, _result_0) {
  if (_result_0.$ === "../../../../../bendvy/src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "RegistrationFailed", "factory": _factory_0, "world": _world_0};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    const _current_0 = ($snapshot$1261$("registered-missing", "ok", {$: "Observed", "registry": _registry_0, "world": _world_1, "rows": {$: "Nil"}}));
    const _current_1 = ($step$1261$("false-gate-missing", false, _current_0));
    return $install$1261$(_factory_0, ($step$1261$("required-flow-missing", true, _current_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1261$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1261$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $access$1261$(_declared_0) {
  const _t_0 = _declared_0["family"];
  const _name_0 = _t_0["name"];
  const _x_0 = (_name_0 + ".read");
  return {$: "Con", "head": ("machine." + _x_0), "tail": {$: "Nil"}};
}

function $scene$047provider$058empty_store$1261$(__0) {
  return {$: "scene/provider.Store", "cells": {$: "../../../../../bendvy/src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}}};
}

function $snapshot$1260$(_label_0, _status_0, _current_0) {
  const _registry_0 = _current_0["registry"];
  const _world_0 = _current_0["world"];
  const _rows_0 = _current_0["rows"];
  return $joined$1260$(_label_0, _status_0, _rows_0, ($registry_view$1260$(_registry_0)), ($scene$047observe$058world$1260$(_world_0)));
}

function $step$1260$(_label_0, _enabled_0, _current_0) {
  const _registry_0 = _current_0["registry"];
  const _world_0 = _current_0["world"];
  const _rows_0 = _current_0["rows"];
  return $observed$1260$(_label_0, _rows_0, ($run_if$1260$(_enabled_0, ($declaration$1260$()), _registry_0, _world_0)));
}

function $install$1260$(_factory_0, _current_0) {
  const _registry_0 = _current_0["registry"];
  const _world_0 = _current_0["world"];
  const _rows_0 = _current_0["rows"];
  return $initialized$1260$(_factory_0, _registry_0, _rows_0, ($initial$058install_empty$1260$({$: "../../../../../bendvy/src/ecs/machine.Family", "name": "Flow"}, _world_0, {$: "scene/provider.Boot"})));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1260$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1260$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $snapshot$1261$(_label_0, _status_0, _current_0) {
  const _registry_0 = _current_0["registry"];
  const _world_0 = _current_0["world"];
  const _rows_0 = _current_0["rows"];
  return $joined$1261$(_label_0, _status_0, _rows_0, ($registry_view$1261$(_registry_0)), ($scene$047observe$058world$1261$(_world_0)));
}

function $step$1261$(_label_0, _enabled_0, _current_0) {
  const _registry_0 = _current_0["registry"];
  const _world_0 = _current_0["world"];
  const _rows_0 = _current_0["rows"];
  return $observed$1261$(_label_0, _rows_0, ($run_if$1261$(_enabled_0, ($declaration$1261$()), _registry_0, _world_0)));
}

function $install$1261$(_factory_0, _current_0) {
  const _registry_0 = _current_0["registry"];
  const _world_0 = _current_0["world"];
  const _rows_0 = _current_0["rows"];
  return $initialized$1261$(_factory_0, _registry_0, _rows_0, ($initial$058install_empty$1261$({$: "../../../../../bendvy/src/ecs/machine.Family", "name": "Flow"}, _world_0, {$: "scene/provider.Boot"})));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1261$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1261$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $joined$1260$(_label_0, _status_0, _rows_0, _a_0, _b_0) {
  const _registry_0 = _a_0["fst"];
  const _description_0 = _a_0["snd"];
  const _world_0 = _b_0["fst"];
  const _body_0 = _b_0["snd"];
  const _x_0 = (";flowRegistry=" + _description_0);
  const _x_1 = (_body_0 + _x_0);
  const _x_2 = ("|" + _x_1);
  const _x_3 = (_status_0 + _x_2);
  const _x_4 = ("|" + _x_3);
  return {$: "Observed", "registry": _registry_0, "world": _world_0, "rows": ($List$append$(_rows_0, {$: "Con", "head": (_label_0 + _x_4), "tail": {$: "Nil"}}))};
}

function $registry_view$1260$(_registry_0) {
  const _ns_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  const _x_0 = ($U32$show$(_cursor_0));
  const _x_1 = ($List$show$1261$(_access_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":" + _x_3);
  const _x_5 = (_name_0 + _x_4);
  const _x_6 = ($U32$show$(_id_0));
  const _x_7 = (":" + _x_5);
  const _x_8 = (_x_6 + _x_7);
  const _x_9 = ($U32$show$(_ns_0));
  const _x_10 = (":" + _x_8);
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": (_x_9 + _x_10)};
}

function $scene$047observe$058world$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $scene$047observe$058world_join$1260$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, ($scene$047observe$058live_view$(_live_0)), ($scene$047observe$058store_view$1260$(_store_0)), ($scene$047observe$058resources_view$1260$(_resources_0)), _events_0, ($scene$047observe$058queue_view$1260$(_commands_0)), _registrations_0, _nextSystem_0, _clock_0);
}

function $observed$1260$(_label_0, _rows_0, _result_0) {
  if (_result_0.$ === "Returned") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _status_0 = _result_0["status"];
    return $snapshot$1260$(_label_0, _status_0, {$: "Observed", "registry": _registry_0, "world": _world_0, "rows": _rows_0});
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_1 = _result_0["world"];
    return $snapshot$1260$(_label_0, "registration-rejected", {$: "Observed", "registry": _registry_1, "world": _world_1, "rows": _rows_0});
  }
}

function $run_if$1260$(_enabled_0, _declared_0, _registry_0, _world_0) {
  if (!_enabled_0) {
    return {$: "Returned", "registry": _registry_0, "world": _world_0, "status": "gate-skipped"};
  } else {
    return $checked$1260$(($requirements$058preflight$1260$(($needs$1260$(_declared_0)), _registry_0, _world_0)));
  }
}

function $initialized$1260$(_factory_0, _registry_0, _rows_0, _result_0) {
  if (_result_0.$ === "initial.Occupied") {
    const _world_0 = _result_0["world"];
    const _incoming_0 = _result_0["incoming"];
    return {$: "Delivered", "factory": _factory_0, "observed": ($snapshot$1260$("install", "private-occupied", {$: "Observed", "registry": _registry_0, "world": _world_0, "rows": _rows_0})), "incoming": {$: "Some", "value": _incoming_0}};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "Delivered", "factory": _factory_0, "observed": ($step$1260$("flow-only-level-absent", true, ($snapshot$1260$("install", "ok", {$: "Observed", "registry": _registry_0, "world": _world_1, "rows": _rows_0})))), "incoming": {$: "None"}};
  }
}

function $initial$058install_empty$1260$(__0, _world_0, _value_0) {
  return $initial$058inspected$1260$(_value_0, ($scene$047provider$058flow_take$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1260$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $joined$1261$(_label_0, _status_0, _rows_0, _a_0, _b_0) {
  const _registry_0 = _a_0["fst"];
  const _description_0 = _a_0["snd"];
  const _world_0 = _b_0["fst"];
  const _body_0 = _b_0["snd"];
  const _x_0 = (";flowRegistry=" + _description_0);
  const _x_1 = (_body_0 + _x_0);
  const _x_2 = ("|" + _x_1);
  const _x_3 = (_status_0 + _x_2);
  const _x_4 = ("|" + _x_3);
  return {$: "Observed", "registry": _registry_0, "world": _world_0, "rows": ($List$append$(_rows_0, {$: "Con", "head": (_label_0 + _x_4), "tail": {$: "Nil"}}))};
}

function $registry_view$1261$(_registry_0) {
  const _ns_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  const _x_0 = ($U32$show$(_cursor_0));
  const _x_1 = ($List$show$1261$(_access_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":" + _x_3);
  const _x_5 = (_name_0 + _x_4);
  const _x_6 = ($U32$show$(_id_0));
  const _x_7 = (":" + _x_5);
  const _x_8 = (_x_6 + _x_7);
  const _x_9 = ($U32$show$(_ns_0));
  const _x_10 = (":" + _x_8);
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": (_x_9 + _x_10)};
}

function $scene$047observe$058world$1261$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $scene$047observe$058world_join$1261$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, ($scene$047observe$058live_view$(_live_0)), ($scene$047observe$058store_view$1261$(_store_0)), ($scene$047observe$058resources_view$1261$(_resources_0)), _events_0, ($scene$047observe$058queue_view$1261$(_commands_0)), _registrations_0, _nextSystem_0, _clock_0);
}

function $observed$1261$(_label_0, _rows_0, _result_0) {
  if (_result_0.$ === "Returned") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _status_0 = _result_0["status"];
    return $snapshot$1261$(_label_0, _status_0, {$: "Observed", "registry": _registry_0, "world": _world_0, "rows": _rows_0});
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_1 = _result_0["world"];
    return $snapshot$1261$(_label_0, "registration-rejected", {$: "Observed", "registry": _registry_1, "world": _world_1, "rows": _rows_0});
  }
}

function $run_if$1261$(_enabled_0, _declared_0, _registry_0, _world_0) {
  if (!_enabled_0) {
    return {$: "Returned", "registry": _registry_0, "world": _world_0, "status": "gate-skipped"};
  } else {
    return $checked$1261$(($requirements$058preflight$1261$(($needs$1261$(_declared_0)), _registry_0, _world_0)));
  }
}

function $initialized$1261$(_factory_0, _registry_0, _rows_0, _result_0) {
  if (_result_0.$ === "initial.Occupied") {
    const _world_0 = _result_0["world"];
    const _incoming_0 = _result_0["incoming"];
    return {$: "Delivered", "factory": _factory_0, "observed": ($snapshot$1261$("install", "private-occupied", {$: "Observed", "registry": _registry_0, "world": _world_0, "rows": _rows_0})), "incoming": {$: "Some", "value": _incoming_0}};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "Delivered", "factory": _factory_0, "observed": ($step$1261$("flow-only-level-absent", true, ($snapshot$1261$("install", "ok", {$: "Observed", "registry": _registry_0, "world": _world_1, "rows": _rows_0})))), "incoming": {$: "None"}};
  }
}

function $initial$058install_empty$1261$(__0, _world_0, _value_0) {
  return $initial$058inspected$1261$(_value_0, ($scene$047provider$058flow_take$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1261$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1261$((_nextSystemId_0 < 4294967295), {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $List$show$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($scene$047observe$058text$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $scene$047observe$058world_join$1260$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _pairLive_0, _pairStore_0, _pairResources_0, _events_0, _pairCommands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _live_0 = _pairLive_0["fst"];
  const _liveValues_0 = _pairLive_0["snd"];
  const _store_0 = _pairStore_0["fst"];
  const _cells_0 = _pairStore_0["snd"];
  const _resources_0 = _pairResources_0["fst"];
  const _resourceText_0 = _pairResources_0["snd"];
  const _commands_0 = _pairCommands_0["fst"];
  const _commandCount_0 = _pairCommands_0["snd"];
  const _x_0 = ($Nat$show$(($List$length$(_events_0))));
  const _x_1 = ($U32$show$(_clock_0));
  const _x_2 = (";busEvents=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_nextSystem_0));
  const _x_5 = (";componentClock=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($List$show$1265$(_registrations_0));
  const _x_8 = (";nextSystem=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($Nat$show$(_commandCount_0));
  const _x_11 = (";registrations=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = (";queue=" + _x_12);
  const _x_14 = (_resourceText_0 + _x_13);
  const _x_15 = (";" + _x_14);
  const _x_16 = (_cells_0 + _x_15);
  const _x_17 = ($List$show$1264$(_liveValues_0));
  const _x_18 = (";cells=" + _x_16);
  const _x_19 = (_x_17 + _x_18);
  const _x_20 = ($Nat$show$(_depth_0));
  const _x_21 = (";live=" + _x_19);
  const _x_22 = (_x_20 + _x_21);
  const _x_23 = ($U32$show$(_capacity_0));
  const _x_24 = (";depth=" + _x_22);
  const _x_25 = (_x_23 + _x_24);
  const _x_26 = ($U32$show$(_high_0));
  const _x_27 = (";capacity=" + _x_25);
  const _x_28 = (_x_26 + _x_27);
  const _x_29 = ($U32$show$(_next_0));
  const _x_30 = (";high=" + _x_28);
  const _x_31 = (_x_29 + _x_30);
  const _x_32 = ($U32$show$(_ns_0));
  const _x_33 = (";next=" + _x_31);
  const _x_34 = (_x_32 + _x_33);
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ("ns=" + _x_34)};
}

function $scene$047observe$058live_view$(_live_0) {
  if (_live_0.length === 1) {
    const _value_0 = _live_0[0];
    return {$: "Tuple", "fst": [_value_0], "snd": {$: "Con", "head": _value_0, "tail": {$: "Nil"}}};
  } else {
    const _left_0 = _live_0.slice(0, _live_0.length >> 1);
    const _right_0 = _live_0.slice(_live_0.length >> 1);
    return $scene$047observe$058live_join$(($scene$047observe$058live_view$(_left_0)), ($scene$047observe$058live_view$(_right_0)));
  }
}

function $scene$047observe$058store_view$1260$(_store_0) {
  const _column_0 = _store_0["cells"];
  return $scene$047observe$058store_join$1260$(($scene$047observe$058column_view$1260$(_column_0)));
}

function $scene$047observe$058resources_view$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return $scene$047observe$058resources_join$1260$(($scene$047observe$058owner_view$(_owned_0)), _flow_0, _level_0, _flowStream_0, _levelStream_0, _frame_0, _tick_0, _trace_0);
}

function $scene$047observe$058queue_view$1260$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $scene$047observe$058queue_join$1260$(_command_0, ($scene$047observe$058queue_view$1260$(_rest_0)));
  }
}

function $checked$1260$(_value_0) {
  if (_value_0.$ === "requirements.Missing") {
    const _registry_0 = _value_0["owners"];
    const _world_0 = _value_0["world"];
    return {$: "Returned", "registry": _registry_0, "world": _world_0, "status": "required-flow-missing"};
  } else {
    const _registry_1 = _value_0["owners"];
    const _world_1 = _value_0["world"];
    return $completed$1260$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1260$(_registry_1, _world_1, {$: "Unit"})));
  }
}

function $requirements$058preflight$1260$(_needs_0, _owners_0, _world_0) {
  return $requirements$058inspected$1260$(_owners_0, _needs_0, ($declared$058inspect$1260$(_world_0)));
}

function $needs$1260$(__0) {
  return {$: "requirements.Requirements", "tokens": {$: "Con", "head": {$: "declared.Flow"}, "tail": {$: "Nil"}}};
}

function $initial$058inspected$1260$(_value_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "initial.Installed", "world": ($scene$047provider$058flow_put$1260$(_world_0, ($initial$058selected_initial$1260$(_value_0))))};
  } else {
    return {$: "initial.Occupied", "world": ($scene$047provider$058flow_put$1260$(_world_0, _t_0)), "incoming": _value_0};
  }
}

function $scene$047provider$058flow_take$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1260$(_world_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../../bendvy/src/ecs/world.RegistrationRejected") {
    return {$: "../../../../../bendvy/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../../bendvy/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../bendvy/src/ecs/world.RegistrationRejected", "error": {$: "../../../../../bendvy/src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../../bendvy/src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $scene$047observe$058world_join$1261$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _pairLive_0, _pairStore_0, _pairResources_0, _events_0, _pairCommands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _live_0 = _pairLive_0["fst"];
  const _liveValues_0 = _pairLive_0["snd"];
  const _store_0 = _pairStore_0["fst"];
  const _cells_0 = _pairStore_0["snd"];
  const _resources_0 = _pairResources_0["fst"];
  const _resourceText_0 = _pairResources_0["snd"];
  const _commands_0 = _pairCommands_0["fst"];
  const _commandCount_0 = _pairCommands_0["snd"];
  const _x_0 = ($Nat$show$(($List$length$(_events_0))));
  const _x_1 = ($U32$show$(_clock_0));
  const _x_2 = (";busEvents=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_nextSystem_0));
  const _x_5 = (";componentClock=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($List$show$1265$(_registrations_0));
  const _x_8 = (";nextSystem=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($Nat$show$(_commandCount_0));
  const _x_11 = (";registrations=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = (";queue=" + _x_12);
  const _x_14 = (_resourceText_0 + _x_13);
  const _x_15 = (";" + _x_14);
  const _x_16 = (_cells_0 + _x_15);
  const _x_17 = ($List$show$1264$(_liveValues_0));
  const _x_18 = (";cells=" + _x_16);
  const _x_19 = (_x_17 + _x_18);
  const _x_20 = ($Nat$show$(_depth_0));
  const _x_21 = (";live=" + _x_19);
  const _x_22 = (_x_20 + _x_21);
  const _x_23 = ($U32$show$(_capacity_0));
  const _x_24 = (";depth=" + _x_22);
  const _x_25 = (_x_23 + _x_24);
  const _x_26 = ($U32$show$(_high_0));
  const _x_27 = (";capacity=" + _x_25);
  const _x_28 = (_x_26 + _x_27);
  const _x_29 = ($U32$show$(_next_0));
  const _x_30 = (";high=" + _x_28);
  const _x_31 = (_x_29 + _x_30);
  const _x_32 = ($U32$show$(_ns_0));
  const _x_33 = (";next=" + _x_31);
  const _x_34 = (_x_32 + _x_33);
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ("ns=" + _x_34)};
}

function $scene$047observe$058store_view$1261$(_store_0) {
  const _column_0 = _store_0["cells"];
  return $scene$047observe$058store_join$1261$(($scene$047observe$058column_view$1261$(_column_0)));
}

function $scene$047observe$058resources_view$1261$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return $scene$047observe$058resources_join$1261$(($scene$047observe$058owner_view$(_owned_0)), _flow_0, _level_0, _flowStream_0, _levelStream_0, _frame_0, _tick_0, _trace_0);
}

function $scene$047observe$058queue_view$1261$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $scene$047observe$058queue_join$1261$(_command_0, ($scene$047observe$058queue_view$1261$(_rest_0)));
  }
}

function $checked$1261$(_value_0) {
  if (_value_0.$ === "requirements.Missing") {
    const _registry_0 = _value_0["owners"];
    const _world_0 = _value_0["world"];
    return {$: "Returned", "registry": _registry_0, "world": _world_0, "status": "required-flow-missing"};
  } else {
    const _registry_1 = _value_0["owners"];
    const _world_1 = _value_0["world"];
    return $completed$1261$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1261$(_registry_1, _world_1, {$: "Unit"})));
  }
}

function $requirements$058preflight$1261$(_needs_0, _owners_0, _world_0) {
  return $requirements$058inspected$1261$(_owners_0, _needs_0, ($declared$058inspect$1261$(_world_0)));
}

function $needs$1261$(__0) {
  return {$: "requirements.Requirements", "tokens": {$: "Con", "head": {$: "declared.Flow"}, "tail": {$: "Nil"}}};
}

function $initial$058inspected$1261$(_value_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "initial.Installed", "world": ($scene$047provider$058flow_put$1261$(_world_0, ($initial$058selected_initial$1261$(_value_0))))};
  } else {
    return {$: "initial.Occupied", "world": ($scene$047provider$058flow_put$1261$(_world_0, _t_0)), "incoming": _value_0};
  }
}

function $scene$047provider$058flow_take$1261$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1261$(_world_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../../bendvy/src/ecs/world.RegistrationRejected") {
    return {$: "../../../../../bendvy/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../../bendvy/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1261$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../bendvy/src/ecs/world.RegistrationRejected", "error": {$: "../../../../../bendvy/src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../../bendvy/src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $scene$047observe$058text$(_value_0) {
  return _value_0;
}

function $List$show$go$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($scene$047observe$058text$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $List$show$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($scene$047observe$058bool$(_h_0));
    const _x_1 = ($List$show$go$1264$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($scene$047observe$058registration$(_h_0));
    const _x_1 = ($List$show$go$1265$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$length$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = _xs_0["tail"];
    return nat_chk(($List$length$(_t_0)) + 1);
  }
}

function $scene$047observe$058live_join$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ($List$append$(_a_0, _b_0))};
}

function $scene$047observe$058store_join$1260$(_pair_0) {
  const _column_0 = _pair_0["fst"];
  const _view_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "scene/provider.Store", "cells": _column_0}, "snd": _view_0};
}

function $scene$047observe$058column_view$1260$(_column_0) {
  if (_column_0.$ === "../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $scene$047observe$058column_join$1260$(($scene$047observe$058cells_view$(_values_0)), _stamps_0);
  } else {
    return {$: "Tuple", "fst": _column_0, "snd": "UNSUPPORTED_COLUMN_ROUTE"};
  }
}

function $scene$047observe$058resources_join$1260$(_pair_0, _a_0, _b_0, _flowStream_0, _levelStream_0, _frame_0, _tick_0, _trace_0) {
  const _owned_0 = _pair_0["fst"];
  const _view_0 = _pair_0["snd"];
  const _x_0 = ($List$show$1261$(_trace_0));
  const _x_1 = ($Nat$show$(_tick_0));
  const _x_2 = (";hooks=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($Nat$show$(_frame_0));
  const _x_5 = (";tick=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($scene$047observe$058stream$1261$(_levelStream_0));
  const _x_8 = (";frame=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($scene$047observe$058stream$1260$(_flowStream_0));
  const _x_11 = (";levelStream=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($scene$047observe$058slot$1261$(_b_0));
  const _x_14 = (";flowStream=" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($scene$047observe$058slot$1260$(_a_0));
  const _x_17 = (";level=" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = (";flow=" + _x_18);
  const _x_20 = (_view_0 + _x_19);
  return {$: "Tuple", "fst": {$: "scene/provider.Resources", "owned": _owned_0, "flow": _a_0, "level": _b_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "snd": ("owned=" + _x_20)};
}

function $scene$047observe$058owner_view$(_owner_0) {
  return $scene$047observe$058owner_view_join$(($scene$047provider$058array_view$(_owner_0)));
}

function $scene$047observe$058queue_join$1260$(_command_0, _pair_0) {
  const _rest_0 = _pair_0["fst"];
  const _count_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _rest_0}, "snd": nat_chk(_count_0 + 1)};
}

function $completed$1260$(_result_0) {
  if (_result_0.$ === "../../../../../bendvy/src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _t_0 = _result_0["outcome"];
    if (_t_0.$ === "../../../../../bendvy/src/ecs/system.Succeeded") {
      const _world_0 = _t_0["world"];
      const _t_1 = _t_0["output"];
      if (_t_1.$ === "../../../../../bendvy/src/ecs/machine.Current") {
        const _value_0 = _t_1["value"];
        const _x_0 = ($scene$047observe$058flow$(_value_0));
        return {$: "Returned", "registry": _registry_0, "world": _world_0, "status": ("current:" + _x_0)};
      } else {
        return {$: "Returned", "registry": _registry_0, "world": _world_0, "status": "unexpected-unavailable"};
      }
    } else {
      const _world_1 = _t_0["world"];
      const _error_0 = _t_0["error"];
      return {$: "Returned", "registry": _registry_0, "world": _world_1, "status": ("body-failed:" + _error_0)};
    }
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_2 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "Rejected", "registry": _registry_1, "world": _world_2, "args": _args_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1260$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0)));
}

function $requirements$058inspected$1260$(_owners_0, _needs_0, _pair_0) {
  const _tokens_0 = _needs_0["tokens"];
  const _world_0 = _pair_0["fst"];
  const _env_0 = _pair_0["snd"];
  return $requirements$058checked$1260$(_owners_0, _world_0, ($requirements$058absent$1260$(_tokens_0, _env_0)));
}

function $declared$058inspect$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _fs_0 = _t_0["flowStream"];
  const _ls_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _trace_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "scene/provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _fs_0, "levelStream": _ls_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": {$: "scene/provider.ConditionEnv", "flow": _flow_0, "level": _level_0}};
}

function $scene$047provider$058flow_put$1260$(_world_0, _slot_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1260$(_world_0, _slot_0);
}

function $initial$058selected_initial$1260$(_value_0) {
  return {$: "../../../../../bendvy/src/ecs/machine.Present", "current": _value_0, "pending": {$: "../../../../../bendvy/src/ecs/machine.NoPending"}, "previous": {$: "None"}, "changed": false};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take_join$1260$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, ($scene$047provider$058flow_take_resource$1260$(_resources_0)), _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $scene$047observe$058store_join$1261$(_pair_0) {
  const _column_0 = _pair_0["fst"];
  const _view_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "scene/provider.Store", "cells": _column_0}, "snd": _view_0};
}

function $scene$047observe$058column_view$1261$(_column_0) {
  if (_column_0.$ === "../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $scene$047observe$058column_join$1261$(($scene$047observe$058cells_view$(_values_0)), _stamps_0);
  } else {
    return {$: "Tuple", "fst": _column_0, "snd": "UNSUPPORTED_COLUMN_ROUTE"};
  }
}

function $scene$047observe$058resources_join$1261$(_pair_0, _a_0, _b_0, _flowStream_0, _levelStream_0, _frame_0, _tick_0, _trace_0) {
  const _owned_0 = _pair_0["fst"];
  const _view_0 = _pair_0["snd"];
  const _x_0 = ($List$show$1261$(_trace_0));
  const _x_1 = ($Nat$show$(_tick_0));
  const _x_2 = (";hooks=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($Nat$show$(_frame_0));
  const _x_5 = (";tick=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($scene$047observe$058stream$1261$(_levelStream_0));
  const _x_8 = (";frame=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($scene$047observe$058stream$1260$(_flowStream_0));
  const _x_11 = (";levelStream=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($scene$047observe$058slot$1263$(_b_0));
  const _x_14 = (";flowStream=" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($scene$047observe$058slot$1262$(_a_0));
  const _x_17 = (";level=" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = (";flow=" + _x_18);
  const _x_20 = (_view_0 + _x_19);
  return {$: "Tuple", "fst": {$: "scene/provider.Resources", "owned": _owned_0, "flow": _a_0, "level": _b_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "snd": ("owned=" + _x_20)};
}

function $scene$047observe$058queue_join$1261$(_command_0, _pair_0) {
  const _rest_0 = _pair_0["fst"];
  const _count_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _rest_0}, "snd": nat_chk(_count_0 + 1)};
}

function $completed$1261$(_result_0) {
  if (_result_0.$ === "../../../../../bendvy/src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _t_0 = _result_0["outcome"];
    if (_t_0.$ === "../../../../../bendvy/src/ecs/system.Succeeded") {
      const _world_0 = _t_0["world"];
      const _t_1 = _t_0["output"];
      if (_t_1.$ === "../../../../../bendvy/src/ecs/machine.Current") {
        const _value_0 = _t_1["value"];
        const _x_0 = ($scene$047observe$058flow$(_value_0));
        return {$: "Returned", "registry": _registry_0, "world": _world_0, "status": ("current:" + _x_0)};
      } else {
        return {$: "Returned", "registry": _registry_0, "world": _world_0, "status": "unexpected-unavailable"};
      }
    } else {
      const _world_1 = _t_0["world"];
      const _error_0 = _t_0["error"];
      return {$: "Returned", "registry": _registry_0, "world": _world_1, "status": ("body-failed:" + _error_0)};
    }
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_2 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "Rejected", "registry": _registry_1, "world": _world_2, "args": _args_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1261$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0)));
}

function $requirements$058inspected$1261$(_owners_0, _needs_0, _pair_0) {
  const _tokens_0 = _needs_0["tokens"];
  const _world_0 = _pair_0["fst"];
  const _env_0 = _pair_0["snd"];
  return $requirements$058checked$1261$(_owners_0, _world_0, ($requirements$058absent$1261$(_tokens_0, _env_0)));
}

function $declared$058inspect$1261$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _fs_0 = _t_0["flowStream"];
  const _ls_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _trace_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "scene/provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _fs_0, "levelStream": _ls_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": {$: "scene/provider.ConditionEnv", "flow": _flow_0, "level": _level_0}};
}

function $scene$047provider$058flow_put$1261$(_world_0, _slot_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1261$(_world_0, _slot_0);
}

function $initial$058selected_initial$1261$(_value_0) {
  return {$: "../../../../../bendvy/src/ecs/machine.Present", "current": _value_0, "pending": {$: "../../../../../bendvy/src/ecs/machine.NoPending"}, "previous": {$: "None"}, "changed": false};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1261$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take_join$1261$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, ($scene$047provider$058flow_take_resource$1261$(_resources_0)), _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $scene$047observe$058bool$(_value_0) {
  if (_value_0) {
    return "true";
  } else {
    return "false";
  }
}

function $List$show$go$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($scene$047observe$058bool$(_h_0));
    const _x_1 = ($List$show$go$1264$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $scene$047observe$058registration$(_value_0) {
  const _id_0 = _value_0["id"];
  const _name_0 = _value_0["name"];
  const _access_0 = _value_0["access"];
  const _x_0 = ($List$show$1261$(_access_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_name_0 + _x_1);
  const _x_3 = ($U32$show$(_id_0));
  const _x_4 = (":" + _x_2);
  return (_x_3 + _x_4);
}

function $List$show$go$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($scene$047observe$058registration$(_h_0));
    const _x_1 = ($List$show$go$1265$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $scene$047observe$058column_join$1260$(_pair_0, _stamps_0) {
  const _values_0 = _pair_0["fst"];
  const _views_0 = _pair_0["snd"];
  const _x_0 = ($List$show$1266$(_stamps_0));
  const _x_1 = ($List$show$1261$(_views_0));
  const _x_2 = (":stamps=" + _x_0);
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": (_x_1 + _x_2)};
}

function $scene$047observe$058cells_view$(_values_0) {
  if (_values_0.length === 1) {
    const _owner_0 = _values_0[0];
    return $scene$047observe$058cells_leaf$(($scene$047observe$058cell_view$(_owner_0)));
  } else {
    const _left_0 = _values_0.slice(0, _values_0.length >> 1);
    const _right_0 = _values_0.slice(_values_0.length >> 1);
    return $scene$047observe$058cells_join$(($scene$047observe$058cells_view$(_left_0)), ($scene$047observe$058cells_view$(_right_0)));
  }
}

function $scene$047observe$058slot$1260$(_value_0) {
  if (_value_0.$ === "../../../../../bendvy/src/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _last_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($scene$047observe$058bool$(_changed_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($scene$047observe$058previous$1260$(_last_0));
    const _x_3 = (",changed=" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($scene$047observe$058pending$1260$(_next_0));
    const _x_6 = (",previous=" + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($scene$047observe$058flow$(_current_0));
    const _x_9 = ("(pending=" + _x_7);
    return (_x_8 + _x_9);
  }
}

function $scene$047observe$058slot$1261$(_value_0) {
  if (_value_0.$ === "../../../../../bendvy/src/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _last_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($scene$047observe$058bool$(_changed_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($scene$047observe$058previous$1261$(_last_0));
    const _x_3 = (",changed=" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($scene$047observe$058pending$1261$(_next_0));
    const _x_6 = (",previous=" + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($scene$047observe$058level$(_current_0));
    const _x_9 = ("(pending=" + _x_7);
    return (_x_8 + _x_9);
  }
}

function $scene$047observe$058stream$1260$(_value_0) {
  const _batches_0 = _value_0["batches"];
  const _positions_0 = _value_0["positions"];
  const _dropped_0 = _value_0["droppedThrough"];
  const _frameStart_0 = _value_0["frameStart"];
  const _x_0 = ($Nat$show$(_frameStart_0));
  const _x_1 = ($Nat$show$(_dropped_0));
  const _x_2 = (",frameStart=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($List$show$1269$(_positions_0));
  const _x_5 = (",dropped=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($List$show$1267$(_batches_0));
  const _x_8 = (",positions=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  return ("batches=" + _x_9);
}

function $scene$047observe$058stream$1261$(_value_0) {
  const _batches_0 = _value_0["batches"];
  const _positions_0 = _value_0["positions"];
  const _dropped_0 = _value_0["droppedThrough"];
  const _frameStart_0 = _value_0["frameStart"];
  const _x_0 = ($Nat$show$(_frameStart_0));
  const _x_1 = ($Nat$show$(_dropped_0));
  const _x_2 = (",frameStart=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($List$show$1269$(_positions_0));
  const _x_5 = (",dropped=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($List$show$12610$(_batches_0));
  const _x_8 = (",positions=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  return ("batches=" + _x_9);
}

function $scene$047observe$058owner_view_join$(_pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _values_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": ($List$show$1260$(_values_0))};
}

function $scene$047provider$058array_view$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return {$: "Tuple", "fst": [_value_0], "snd": {$: "Con", "head": _value_0, "tail": {$: "Nil"}}};
  } else {
    const _left_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _right_0 = _owner_0.slice(_owner_0.length >> 1);
    return $scene$047provider$058array_join$(($scene$047provider$058array_view$(_left_0)), ($scene$047provider$058array_view$(_right_0)));
  }
}

function $scene$047observe$058flow$(_value_0) {
  if (_value_0.$ === "scene/provider.Boot") {
    return "Boot";
  } else if (_value_0.$ === "scene/provider.Play") {
    return "Play";
  } else {
    return "Pause";
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1260$(_result_0) {
  if (_result_0.$ === "../../../../../bendvy/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1260$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1260$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $requirements$058checked$1260$(_owners_0, _world_0, _missing_0) {
  if (_missing_0.$ === "Nil") {
    return {$: "requirements.Ready", "owners": _owners_0, "world": _world_0};
  } else {
    return {$: "requirements.Missing", "owners": _owners_0, "world": _world_0, "tokens": _missing_0};
  }
}

function $requirements$058absent$1260$(_tokens_0, _env_0) {
  if (_tokens_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _key_0 = _tokens_0["head"];
    const _rest_0 = _tokens_0["tail"];
    return $requirements$058absent_checked$1260$(($declared$058present$1260$(_key_0, _env_0)), _key_0, ($requirements$058absent$1260$(_rest_0, _env_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1260$(_world_0, _slot_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": ($scene$047provider$058flow_put_resource$1260$(_resources_0, _slot_0)), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take_join$1260$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _split_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _resources_0 = _split_0["fst"];
  const _slot_0 = _split_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _slot_0};
}

function $scene$047provider$058flow_take_resource$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "Tuple", "fst": {$: "scene/provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "snd": _flow_0};
}

function $scene$047observe$058column_join$1261$(_pair_0, _stamps_0) {
  const _values_0 = _pair_0["fst"];
  const _views_0 = _pair_0["snd"];
  const _x_0 = ($List$show$1266$(_stamps_0));
  const _x_1 = ($List$show$1261$(_views_0));
  const _x_2 = (":stamps=" + _x_0);
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": (_x_1 + _x_2)};
}

function $scene$047observe$058slot$1262$(_value_0) {
  if (_value_0.$ === "../../../../../bendvy/src/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _last_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($scene$047observe$058bool$(_changed_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($scene$047observe$058previous$1260$(_last_0));
    const _x_3 = (",changed=" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($scene$047observe$058pending$1260$(_next_0));
    const _x_6 = (",previous=" + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($scene$047observe$058flow$(_current_0));
    const _x_9 = ("(pending=" + _x_7);
    return (_x_8 + _x_9);
  }
}

function $scene$047observe$058slot$1263$(_value_0) {
  if (_value_0.$ === "../../../../../bendvy/src/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _last_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($scene$047observe$058bool$(_changed_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($scene$047observe$058previous$1261$(_last_0));
    const _x_3 = (",changed=" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($scene$047observe$058pending$1261$(_next_0));
    const _x_6 = (",previous=" + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($scene$047observe$058level$(_current_0));
    const _x_9 = ("(pending=" + _x_7);
    return (_x_8 + _x_9);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1261$(_result_0) {
  if (_result_0.$ === "../../../../../bendvy/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1261$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1261$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $requirements$058checked$1261$(_owners_0, _world_0, _missing_0) {
  if (_missing_0.$ === "Nil") {
    return {$: "requirements.Ready", "owners": _owners_0, "world": _world_0};
  } else {
    return {$: "requirements.Missing", "owners": _owners_0, "world": _world_0, "tokens": _missing_0};
  }
}

function $requirements$058absent$1261$(_tokens_0, _env_0) {
  if (_tokens_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _key_0 = _tokens_0["head"];
    const _rest_0 = _tokens_0["tail"];
    return $requirements$058absent_checked$1261$(($declared$058present$1261$(_key_0, _env_0)), _key_0, ($requirements$058absent$1261$(_rest_0, _env_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1261$(_world_0, _slot_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": ($scene$047provider$058flow_put_resource$1261$(_resources_0, _slot_0)), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take_join$1261$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _split_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _resources_0 = _split_0["fst"];
  const _slot_0 = _split_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _slot_0};
}

function $scene$047provider$058flow_take_resource$1261$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "Tuple", "fst": {$: "scene/provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "snd": _flow_0};
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $List$show$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($scene$047observe$058entry$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $scene$047observe$058cells_leaf$(_pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": [_owner_0], "snd": {$: "Con", "head": _text_0, "tail": {$: "Nil"}}};
}

function $scene$047observe$058cell_view$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": "none"};
  } else {
    const _owner_0 = _value_0["value"];
    return $scene$047observe$058cell_view_join$(($scene$047observe$058owner_view$(_owner_0)));
  }
}

function $scene$047observe$058cells_join$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ($List$append$(_a_0, _b_0))};
}

function $scene$047observe$058pending$1260$(_value_0) {
  if (_value_0.$ === "../../../../../bendvy/src/ecs/machine.NoPending") {
    return "none";
  } else {
    const _value_1 = _value_0["value"];
    const _skip_0 = _value_0["skipSame"];
    const _x_0 = ($scene$047observe$058bool$(_skip_0));
    const _x_1 = ($scene$047observe$058flow$(_value_1));
    const _x_2 = (":" + _x_0);
    return (_x_1 + _x_2);
  }
}

function $scene$047observe$058previous$1260$(_value_0) {
  if (_value_0.$ === "None") {
    return "none";
  } else {
    const _value_1 = _value_0["value"];
    return $scene$047observe$058flow$(_value_1);
  }
}

function $scene$047observe$058level$(_value_0) {
  if (_value_0.$ === "scene/provider.Low") {
    return "0";
  } else if (_value_0.$ === "scene/provider.Middle") {
    return "1";
  } else {
    return "2";
  }
}

function $scene$047observe$058pending$1261$(_value_0) {
  if (_value_0.$ === "../../../../../bendvy/src/ecs/machine.NoPending") {
    return "none";
  } else {
    const _value_1 = _value_0["value"];
    const _skip_0 = _value_0["skipSame"];
    const _x_0 = ($scene$047observe$058bool$(_skip_0));
    const _x_1 = ($scene$047observe$058level$(_value_1));
    const _x_2 = (":" + _x_0);
    return (_x_1 + _x_2);
  }
}

function $scene$047observe$058previous$1261$(_value_0) {
  if (_value_0.$ === "None") {
    return "none";
  } else {
    const _value_1 = _value_0["value"];
    return $scene$047observe$058level$(_value_1);
  }
}

function $List$show$1267$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($scene$047observe$058batch$1260$(_h_0));
    const _x_1 = ($List$show$go$1268$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1269$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($scene$047observe$058position$(_h_0));
    const _x_1 = ($List$show$go$1269$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12610$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($scene$047observe$058batch$1261$(_h_0));
    const _x_1 = ($List$show$go$12611$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $scene$047provider$058array_join$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ($List$append$(_a_0, _b_0))};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1260$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $requirements$058absent_checked$1260$(_present_0, _key_0, _tail_0) {
  if (_present_0) {
    return _tail_0;
  } else {
    return {$: "Con", "head": _key_0, "tail": _tail_0};
  }
}

function $declared$058present$1260$(_token_0, _env_0) {
  if (_token_0.$ === "declared.Flow") {
    const _flow_0 = _env_0["flow"];
    return $scene$047provider$058slot_present$1260$(_flow_0);
  } else {
    const _level_0 = _env_0["level"];
    return $scene$047provider$058slot_present$1261$(_level_0);
  }
}

function $scene$047provider$058flow_put_resource$1260$(_resources_0, _flow_0) {
  const _owned_0 = _resources_0["owned"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "scene/provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1261$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1261$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0);
}

function $requirements$058absent_checked$1261$(_present_0, _key_0, _tail_0) {
  if (_present_0) {
    return _tail_0;
  } else {
    return {$: "Con", "head": _key_0, "tail": _tail_0};
  }
}

function $declared$058present$1261$(_token_0, _env_0) {
  if (_token_0.$ === "declared.Flow") {
    const _flow_0 = _env_0["flow"];
    return $scene$047provider$058slot_present$1262$(_flow_0);
  } else {
    const _level_0 = _env_0["level"];
    return $scene$047provider$058slot_present$1263$(_level_0);
  }
}

function $scene$047provider$058flow_put_resource$1261$(_resources_0, _flow_0) {
  const _owned_0 = _resources_0["owned"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "scene/provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0};
}

function $scene$047observe$058entry$(_value_0) {
  const _id_0 = _value_0["id"];
  const _t_0 = _value_0["stamp"];
  const _added_0 = _t_0["added"];
  const _changed_0 = _t_0["changed"];
  const _x_0 = ($U32$show$(_changed_0));
  const _x_1 = ($U32$show$(_added_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_id_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($scene$047observe$058entry$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $scene$047observe$058cell_view_join$(_value_0) {
  const _owner_0 = _value_0["fst"];
  const _text_0 = _value_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": _owner_0}, "snd": _text_0};
}

function $scene$047observe$058batch$1260$(_value_0) {
  const _tick_0 = _value_0["tick"];
  const _values_0 = _value_0["values"];
  const _x_0 = ($List$show$1268$(_values_0));
  const _x_1 = ($Nat$show$(_tick_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$1268$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($scene$047observe$058batch$1260$(_h_0));
    const _x_1 = ($List$show$go$1268$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $scene$047observe$058position$(_value_0) {
  const _id_0 = _value_0["id"];
  const _cursor_0 = _value_0["cursor"];
  const _registered_0 = _value_0["registeredAt"];
  const _x_0 = ($Nat$show$(_registered_0));
  const _x_1 = ($Nat$show$(_cursor_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_id_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$1269$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($scene$047observe$058position$(_h_0));
    const _x_1 = ($List$show$go$1269$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $scene$047observe$058batch$1261$(_value_0) {
  const _tick_0 = _value_0["tick"];
  const _values_0 = _value_0["values"];
  const _x_0 = ($List$show$12611$(_values_0));
  const _x_1 = ($Nat$show$(_tick_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$12611$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($scene$047observe$058batch$1261$(_h_0));
    const _x_1 = ($List$show$go$12611$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $List$show$go$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1260$({$: "../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $scene$047provider$058slot_present$1260$(_slot_0) {
  if (_slot_0.$ === "../../../../../bendvy/src/ecs/machine.Missing") {
    return false;
  } else {
    return true;
  }
}

function $scene$047provider$058slot_present$1261$(_slot_0) {
  if (_slot_0.$ === "../../../../../bendvy/src/ecs/machine.Missing") {
    return false;
  } else {
    return true;
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1261$({$: "../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1261$((_namespace_0 === _actual_0), {$: "../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $scene$047provider$058slot_present$1262$(_slot_0) {
  if (_slot_0.$ === "../../../../../bendvy/src/ecs/machine.Missing") {
    return false;
  } else {
    return true;
  }
}

function $scene$047provider$058slot_present$1263$(_slot_0) {
  if (_slot_0.$ === "../../../../../bendvy/src/ecs/machine.Missing") {
    return false;
  } else {
    return true;
  }
}

function $List$show$1268$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($scene$047observe$058transition$1260$(_h_0));
    const _x_1 = ($List$show$go$1267$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12611$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($scene$047observe$058transition$1261$(_h_0));
    const _x_1 = ($List$show$go$12610$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1260$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../../bendvy/src/ecs/system.Completed", "registry": {$: "../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1260$({$: "../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1261$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../../bendvy/src/ecs/system.Completed", "registry": {$: "../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1261$({$: "../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $scene$047observe$058transition$1260$(_value_0) {
  const _from_0 = _value_0["from"];
  const _to_0 = _value_0["to"];
  const _x_0 = ($scene$047observe$058flow$(_to_0));
  const _x_1 = ($scene$047observe$058flow$(_from_0));
  const _x_2 = (">" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$1267$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($scene$047observe$058transition$1260$(_h_0));
    const _x_1 = ($List$show$go$1267$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $scene$047observe$058transition$1261$(_value_0) {
  const _from_0 = _value_0["from"];
  const _to_0 = _value_0["to"];
  const _x_0 = ($scene$047observe$058level$(_to_0));
  const _x_1 = ($scene$047observe$058level$(_from_0));
  const _x_2 = (">" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$12610$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($scene$047observe$058transition$1261$(_h_0));
    const _x_1 = ($List$show$go$12610$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1261$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1260$(_registry_0, ($runner$1260$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1261$(_registry_0, ($runner$1261$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $runner$1260$(_world_0, __0) {
  return $read_taken$1260$(($scene$047provider$058flow_take$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1261$(_registry_0, _outcome_0) {
  return {$: "../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $runner$1261$(_world_0, __0) {
  return $read_taken$1261$(($scene$047provider$058flow_take$1261$(_world_0)));
}

function $read_taken$1260$(_pair_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058current_view$1260$(_slot_0))};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $read_taken$1261$(_pair_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058current_view$1261$(_slot_0))};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058current_view$1260$(_slot_0) {
  if (_slot_0.$ === "../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../bendvy/src/ecs/machine.Unavailable"};
  } else {
    const _current_0 = _slot_0["current"];
    return {$: "../../../../../bendvy/src/ecs/machine.Current", "value": _current_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_access$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058current_view$1261$(_slot_0) {
  if (_slot_0.$ === "../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../bendvy/src/ecs/machine.Unavailable"};
  } else {
    const _current_0 = _slot_0["current"];
    return {$: "../../../../../bendvy/src/ecs/machine.Current", "value": _current_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, [[4],[]]);