#!/usr/bin/env python3
"""Focused direct development: prepare only, then a separately admitted guarded run.

No relocated imports, installed resolver discovery, or performance work.
This does not establish complete installed-tool/resolver qualification.
"""
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
import sys
import stat
from pathlib import Path

ROOT = Path('/workspace/formal-proofs/bendvy')
HERE = Path(__file__).resolve().parent
TRANSPORT = HERE / 'transport-v1'
CASES = ('main','main-mutant','flow-only')





def sha(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise ValueError('Pinned/generated/raw file must be regular and non-symlink')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as source:
        if not stat.S_ISREG(os.fstat(source.fileno()).st_mode):
            raise ValueError('Pinned/generated/raw descriptor must be regular')
        return hashlib.sha256(source.read()).hexdigest()


def write_raw(path, data):
    path = Path(path)
    if path.exists() or path.is_symlink():
        raise ValueError('Raw capture must start absent and non-symlink')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as output:
        if not stat.S_ISREG(os.fstat(output.fileno()).st_mode):
            raise ValueError('Raw capture descriptor is not regular')
        output.write(data)
    if path.is_symlink() or not path.is_file():
        raise ValueError('Raw capture changed file type')


def publish_result(command, result, out, pins, record, artifact):
    label = command['label']
    row = dict(command)
    row.update({key: {'retainedRawHex': value.hex()} if isinstance(value, bytes) else value
                for key, value in result.items()})
    record['commands'].append(row)  # Actual completed child survives publication failure.
    primary = None
    try:
        for key, value in result.items():
            if isinstance(value, bytes):
                target = out / (label + '.' + key)
                write_raw(target, value)
                row[key] = {'path': str(target), 'sha256': sha(target), 'bytes': len(value)}
                pins[str(target)] = row[key]['sha256']
    except BaseException as error:
        primary = error
        row['publicationError'] = repr(error)
        raise
    finally:
        try:
            if artifact is not None and (artifact.exists() or artifact.is_symlink()):
                pins[str(artifact)] = sha(artifact)
                record['generatedSHA256' if label == 'emit' else 'buildArtifactSHA256'] = pins[str(artifact)]
        except BaseException as error:
            row['artifactCaptureError'] = repr(error)
            if primary is None:
                raise


VERIFIED_SOURCES = {}

def load(name, path):
    import types
    path = Path(path).resolve(strict=True)
    source = VERIFIED_SOURCES[str(path)] if VERIFIED_SOURCES else path.read_bytes()
    module = types.ModuleType(name)
    module.__file__ = str(path)
    module.__dict__['VERIFIED_SOURCES'] = VERIFIED_SOURCES
    exec(compile(source, str(path), 'exec'), module.__dict__)
    return module

def resource_snapshot(roots):
    return {str(Path(root)): {str(p.relative_to(Path(root))): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(Path(root).rglob('*')) if p.is_file()} for root in roots}


def prepare(out, case):
    out=Path(out).resolve()
    if case not in CASES:raise ValueError('Unknown exact scene')
    entry=HERE.parent/(case+'.bend')
    selection=json.loads((HERE/'ORACLE-SELECTION.json').read_text())[case]
    oracle=Path(selection['directory']).resolve(strict=True)
    expected_sha=selection['expectedSHA256']
    parser=load('scenario_parser',TRANSPORT/'transport.py')
    inventory_path=TRANSPORT/(case+'-inventory.json')
    identities=json.loads(inventory_path.read_text())
    if parser.Transport(entry).inventory()!=identities:raise ValueError('Frozen consuming sources changed')
    if sha(selection['json'])!=expected_sha:raise ValueError('Independent full model changed')
    tools = {'bend': '/home/node/.bend/bin/bend-2.0.35', 'node': '/home/node/.local/share/mise/installs/node/24.20.0/bin/node', 'python': str(Path(sys.executable).resolve()), 'taskset': str(Path('/usr/bin/taskset').resolve(strict=True))}
    tools['clangWrapper'] = '/tmp/bendvy-clang19-diagnostic/clang19'
    tools['clangBinary'] = '/tmp/bendvy-clang19-diagnostic/root/usr/lib/llvm-19/bin/clang'
    config = ROOT / 'experiments/public-simulation/delivery-v1/installed-config.py'
    extra=[config,Path(__file__),TRANSPORT/'transport.py',inventory_path,
           ROOT/'scripts/task_runner.py',ROOT/'scripts/evidence_boundary.py',
           HERE/'ORACLE-SELECTION.json',HERE/'RECIPE-REUSE.json',HERE/'test-transport.py',HERE/'test-publication.py',HERE/'test-admission.py',ROOT/'src/ecs/world-namespace.c',ROOT/'src/ecs/world-namespace.js',*map(Path,tools.values())]
    extra += [f for f in oracle.rglob('*') if f.is_file() and '__pycache__' not in f.parts]
    extra += [f for f in HERE.parent.rglob('*') if f.is_file() and HERE not in f.parents and '__pycache__' not in f.parts]
    pins = dict(identities['sourceSHA256'])
    pins.update({str(path.resolve(strict=True)): sha(path) for path in extra})
    configuration = load('installed_configuration', config)
    env = configuration.environment()
    resources = load('task_runner', ROOT / 'scripts/task_runner.py').Inputs(directories=configuration.RESOURCE_ROOTS)
    generated = out / 'scenario.c'
    native = out / 'scenario.native'
    plan = {'scope': 'direct development only; no complete resolver qualification or #48 completion',
            'expectedSHA256': expected_sha, 'entrypoint': identities['entrypoint'], 'constructorInventory': str(inventory_path),
            'resourceRoots': [str(root) for root in resources.directories], 'resourceInventory': resources.expected,
            'pins': pins, 'environment': env, 'cwd': str(HERE), 'oracle': selection['json'],
            'stdoutOracle': selection['stdout'], 'stdoutOracleSHA256': selection['stdoutSHA256'],
            'baselineJSON': selection.get('baselineJSON'), 'baselineSHA256': selection.get('baselineSHA256'),
            'baselineStdout': selection.get('baselineStdout'), 'baselineStdoutSHA256': selection.get('baselineStdoutSHA256'),
            'generated': str(generated), 'native': str(native),
            'tools': tools, 'commands': [
                {'label': 'emit', 'argv': [tools['taskset'], '-c', '5', tools['bend'], identities['entrypoint'], '-o', str(generated)], 'capSeconds': 30},
                {'label': 'build', 'argv': [tools['taskset'], '-c', '5', tools['clangWrapper'], '-O3', str(generated), '-o', str(native), '-pthread', '-lm'], 'capSeconds': 120},
                {'label': 'consumer', 'argv': [tools['taskset'], '-c', '5', str(native), '--threads', '1', '--gpu', 'off'], 'capSeconds': 5}],
            'postConsumer': 'Exact entire independently authored literal application output; no full48/public/performance claim'}
    out.mkdir(parents=True, exist_ok=False)
    (out / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
    print(sha(out / 'plan.json'))


def validate_output(plan, parser, stdout, record):
    expected_stdout = Path(plan['stdoutOracle']).read_bytes()
    if hashlib.sha256(expected_stdout).hexdigest() != plan['stdoutOracleSHA256'] or stdout != expected_stdout:
        raise ValueError('Entire literal stdout differs, including final newline')
    actual = parser.Transport(plan['entrypoint']).normalize(stdout.decode())
    expected_bytes = Path(plan['oracle']).read_bytes()
    if hashlib.sha256(expected_bytes).hexdigest() != plan['expectedSHA256']:
        raise ValueError('Whole oracle changed')
    parser.TERM.strict_equal(actual, json.loads(expected_bytes))
    if plan.get('baselineJSON') is not None:
        baseline_bytes = Path(plan['baselineJSON']).read_bytes()
        if hashlib.sha256(baseline_bytes).hexdigest() != plan['baselineSHA256']:
            raise ValueError('Frozen normal baseline changed')
        baseline_stdout = Path(plan['baselineStdout']).read_bytes()
        if hashlib.sha256(baseline_stdout).hexdigest() != plan['baselineStdoutSHA256']:
            raise ValueError('Frozen normal literal baseline changed')
        if stdout == baseline_stdout or actual == json.loads(baseline_bytes):
            raise ValueError('Reached mutant failed to reject normal baseline')
        record['normalBaselineRejectedSHA256'] = plan['baselineSHA256']
    record['wholeOracleSHA256'] = plan['expectedSHA256']


def run(plan_path, expected_sha):
    plan_path = Path(plan_path).resolve(strict=True)
    if sha(plan_path) != expected_sha:
        raise ValueError('Admitted plan digest mismatch')
    plan = json.loads(plan_path.read_text())
    actual_python = str(Path(sys.executable).resolve(strict=True))
    if actual_python != plan['tools']['python'] or sha(actual_python) != plan['pins'][actual_python]:
        raise ValueError('Actual executor interpreter path/hash differs from admitted plan')
    if {path: sha(path) for path in plan['pins']} != plan['pins']:
        raise ValueError('Frozen boundary changed before helper import')
    global VERIFIED_SOURCES
    VERIFIED_SOURCES = {path: Path(path).read_bytes() for path in plan['pins'] if path.endswith('.py')}
    if any(hashlib.sha256(data).hexdigest() != plan['pins'][path] for path, data in VERIFIED_SOURCES.items()):
        raise ValueError('Captured helper bytes changed before import')
    if resource_snapshot(plan.get('resourceRoots', [])) != plan.get('resourceInventory', {}):
        raise ValueError('Resources changed before helper imports')
    out = plan_path.parent
    parser = load('scenario_parser', TRANSPORT / 'transport.py')
    runner = load('task_runner', ROOT / 'scripts/task_runner.py')
    boundary = load('evidence_boundary', ROOT / 'scripts/evidence_boundary.py')
    inventory = json.loads(Path(plan['constructorInventory']).read_text())
    resources = runner.Inputs(directories=plan['resourceRoots'])
    if resources.expected != plan['resourceInventory']:
        raise ValueError('Frozen Native resources changed before launch')
    pins = dict(plan['pins'])
    pins[str(plan_path)] = expected_sha
    generated = Path(plan['generated'])
    native = Path(plan['native'])
    record = {'scope': plan['scope'], 'planSHA256': expected_sha, 'commands': [], 'guards': []}

    def guard(label):
        for artifact in (generated, native):
            if str(artifact) in pins and (artifact.is_symlink() or not artifact.is_file()):
                raise ValueError('Generated artifact must be a regular non-symlink file')
        actual = {path: sha(path) for path in pins}
        resource_actual = resources.snapshot()
        unchanged = actual == pins and parser.Transport(plan['entrypoint']).inventory() == inventory and resource_actual == plan['resourceInventory']
        receipt = {'label': label, 'actualPins': actual, 'actualResources': resource_actual, 'unchanged': unchanged}
        target = out / (label + '.guard.json')
        target.write_text(json.dumps(receipt, indent=2) + '\n')
        record['guards'].append({'path': str(target), 'sha256': sha(target)})
        if not unchanged:
            raise ValueError('Source/oracle/tool/helper boundary changed: ' + label)

    with boundary.ReceiptBoundary(record, out / 'receipt.json', [('final boundary', lambda: guard('final'))]):
        for command in plan['commands']:
            label = command['label']
            guard(label + '-pre')
            with boundary.GuardBoundary([('post boundary', lambda: guard(label + '-post'))]):
                with open('/tmp/bendvy-parity-heavy.lock', 'a') as lock:
                    fcntl.flock(lock, fcntl.LOCK_EX)
                    try:
                        guard(label + '-acquired')
                        artifact = generated if label == 'emit' else native
                        if label in ('emit', 'build') and (artifact.exists() or artifact.is_symlink()):
                            raise ValueError('Generated output must start absent')
                        result = runner.execute_result(command['argv'], command['capSeconds'], plan['environment'], plan['cwd'], 'split')
                    finally:
                        fcntl.flock(lock, fcntl.LOCK_UN)
                artifact = generated if label == 'emit' else native
                publish_result(command, result, out, pins, record,
                               artifact if label in ('emit', 'build') else None)
                if result['exit'] != 0 or result['failure'] is not None:
                    raise ValueError('Owned child failed: ' + label)
                if label in ('emit', 'build'):
                    if str(artifact) not in pins:
                        raise ValueError('Child did not produce a regular non-symlink artifact')
                else:
                    if result['stderr']:
                        raise ValueError('Consumer stderr is not empty')
                    validate_output(plan, parser, result['stdout'], record)
        record['status'] = 'DEVELOPMENT_PASS'


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest='command', required=True)
    preparation = sub.add_parser('prepare')
    preparation.add_argument('output')
    preparation.add_argument('case',choices=CASES)
    execution = sub.add_parser('run')
    execution.add_argument('plan')
    execution.add_argument('admitted_sha256')
    args = parser.parse_args()
    if args.command == 'prepare':
        prepare(args.output,args.case)
    else:
        run(args.plan, args.admitted_sha256)


if __name__ == '__main__':
    main()
