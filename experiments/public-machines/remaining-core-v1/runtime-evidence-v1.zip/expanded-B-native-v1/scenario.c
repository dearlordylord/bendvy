
// Imports
// =======

// The Objective-C headers take #include, not #import: a build
// (-o) reads an #import as the framework of an effect.

#pragma clang fp contract(off)

#if defined(__CUDACC_RTC__)
#define BEND_RTC 1
#endif

#ifdef __METAL_VERSION__
#include <metal_stdlib>
using namespace metal;
#elif !defined(BEND_RTC)
#ifdef __APPLE__
#define _DARWIN_UNLIMITED_SELECT
#else
#define _GNU_SOURCE
#endif
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <unistd.h>
#include <signal.h>
#include <sys/mman.h>
#include <time.h>
#include <poll.h>
#include <sys/select.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif
#ifdef __OBJC__
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#elif BEND_CUDA
#include <cuda.h>
#include <nvrtc.h>
#include <fcntl.h>
#include <sys/stat.h>
#endif
#endif

// Dialect
// =======

// Metal needs coherent(device) (MSL 3.2), or M1-class parts lose stores
// across the threadgroups of a dispatch. CUDA keeps plain data cacheable
// in L1: lanes hand off through a32 and FENCE. Only clang 19+ has both
// preserve_none and preserve_most, and compiles preserve_most soundly; at
// -O0 its register allocator cannot place a preserve_none segment, so an
// unoptimized build takes neither. A segment is a case of the device's
// switch; on the host, a preserve_none function (WL_SIG) entered by
// musttail, its words fresh at WL_OPEN.

#ifdef __METAL_VERSION__
#if __METAL_VERSION__ >= 320
#define DEV     coherent(device) device
#else
#define DEV     device
#endif
#define THR     thread
#define TG      threadgroup
#define INLINE  inline
#define OUTLINE static
#define CONSTV  constant
#define DEVICE  1
#define CLZ(x)  clz(x)
#define FENCE() atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst)
#define BAR()   threadgroup_barrier(mem_flags::mem_threadgroup)
#define BARD()  threadgroup_barrier(mem_flags::mem_device \
  | mem_flags::mem_threadgroup)
#else
#define DEV
#define THR
#define TG
#define INLINE  static inline
#define CONSTV  static const
#ifdef BEND_RTC
#define OUTLINE static __attribute__((noinline))
#define DEVICE  1
#define CLZ(x)  (u32)__clz((int)(x))
#define FENCE() __threadfence()
#define BAR()   __syncthreads()
#define BARD()  \
  { __threadfence(); __syncthreads(); }
#else
#if __has_attribute(preserve_none) && __has_attribute(preserve_most) \
  && defined(__OPTIMIZE__)
#define PRESERVE(A) __attribute__((A))
#else
#define PRESERVE(A)
#endif
#define OUTLINE static __attribute__((noinline, cold)) PRESERVE(preserve_most)
#define DEVICE  0
#define CLZ(x)  (u32)__builtin_clz(x)
#define FENCE() ((void)0)
#endif
#endif
#define FAR static __attribute__((noinline))

#if DEVICE
#define LOCK(l)
#define UNLOCK(l)
#define WL_CASE(F) case F:
#define WL_OPEN    {
#define WL_JMP(F)  { fid = (F); break; }
#define WL_DYN     WL_JMP
#else
#define LOCK(l)    while (__atomic_exchange_n(&(l), 1, __ATOMIC_ACQUIRE)) {}
#define UNLOCK(l)  __atomic_store_n(&(l), 0, __ATOMIC_RELEASE)
#define WL_FN      static PRESERVE(preserve_none) __attribute__((noinline)) Term
#define WL_CASE(F) WL_FN WL_##F(WL_SIG)
#define WL_OPEN    { WL_BANK u32 rn;
#define WL_JMP(F)  __attribute__((musttail)) return WL_##F(WL_ALL)
#define WL_DYN(F)  __attribute__((musttail)) return wl_tab[F](WL_ALL)
#endif
#define WL_SPIN     for (;;) { if (err_spun(e.mem, &wpoll)) { return 0; }
#define WL_SPUN     } break;
#define WL_AGAIN(F) continue

#define LANE_STEP (DEVICE ? (long)CUBE : 1)
#define STK(I)    sp[(long)(I) * LANE_STEP]

#define WL_RETN(N)  { rn = (N); sp -= LANE_STEP; WL_DYN((u32)STK(0)); }
#define WL_CONT     STK(-3)
#define WL_IDX      STK(-2)
#define WL_POPN(N)  sp -= N * LANE_STEP
#define WL_PUSHN(N) sp += N * LANE_STEP
#define WL_FRAME(T) \
  u64 wtl = task_tail(T); \
  u64 wtw = e.mem[wtl + 1]; \
  STK(0) = e.mem[wtl]; \
  STK(1) = (wtw >> 32) & 0xFFFF; \
  STK(2) = FID_EXIT; \
  sp += 3 * LANE_STEP;
#define WL_ARGS(A, N) \
  for (u32 wi = 0; wi + 1 < N; wi += 1) { \
    STK(wi) = e.mem[A + wi]; \
  } \
  sp += (N - 1) * LANE_STEP;
#define WL_ROOM(N) \
  if (DEVICE && sp + (N) * CUBE >= e.mem + STAT_OFF + CUBE) { \
    err_post(e.mem, ERR_DEEP); \
    return 0; \
  }

// Types
// =====

#ifdef __METAL_VERSION__
typedef ulong u64;
typedef uint  u32;
typedef uchar u8;
#elif defined(BEND_RTC)
typedef unsigned long long u64;
typedef unsigned int       u32;
typedef unsigned char      u8;
#else
typedef uint64_t u64;
typedef uint32_t u32;
typedef uint8_t  u8;
#endif
typedef float f32;

typedef u64 Term;

typedef struct {
  DEV u64* mem;
  DEV u64* alc;
} Env;

typedef struct {
  u64 off;
  u32 rd;
  u32 wr;
  u32 top;
} Bank;

#if DEVICE
typedef u32 u32a;
#else
typedef u32 __attribute__((may_alias)) u32a;
#endif

// Constants
// =========

#define TAG_PAK 1ull
#define TAG_CTR 2ull
#define TAG_CLO 3ull
#define TAG_BUF 4ull
#define TAG_TSK 5ull
#define TAG_ARR 6ull

#define TERM_HOLE (~0ull)
#define LOC_MASK  ((1ull << 40) - 1)
#define RFC_BIT   (1ull << 63)
#define RFC_CNT   ((1u << 24) - 1)
#define NAT_IMM   ((1ull << 48) - 1)

#define ERR_RING 1
#define ERR_TAGS 2
#define ERR_HEAP 3
#define ERR_FIDS 4
#define ERR_NATS 5
#define ERR_RFCS 6
#define ERR_DEEP 7
#define ERR_ARRS 8

#define LINE      16
#define PAGE_BITS 7
#define PAGE_LEN  (1ull << PAGE_BITS)
#define CUBE_T    128
#define CUBE      ((u64)CUBE_T * CUBE_T)
#define CUBE_G    (1u << CUBE_LOG)
#define LANES     ((u64)CUBE_T << CUBE_LOG)
#define RING_LOG  (17 - CUBE_LOG)
#define RING_LEN  (1ull << RING_LOG)
#define STAK_LEN  (1ull << 11)
#define NCLS      8
#define NCLS_ALL  32
#define IO_HELP   64

#define TG_HOLD   2304
#define CHUNK     256
#define CAP_WORDS 32768
#define QUANTUM   (DEVICE ? PAGE_LEN \
  : KEEP_WORDS < 32 * PAGE_LEN ? KEEP_WORDS : 32 * PAGE_LEN)
#if DEVICE
#define KEEP_WORDS CHUNK
#endif
#define RING_WORDS ((1ull << 10) + 2)

#define H_BUMP       0
#define H_CAP        1
#define H_CURSOR     LINE
#define H_ROOT_DONE  (2 * LINE)
#define H_ERROR_CODE (3 * LINE)
#define H_ROOT_WORD  (4 * LINE)
#define H_BANK       (H_ROOT_WORD + WL_RESW)

#define PAGE_UP(n) (((n) + PAGE_LEN - 1) & ~(PAGE_LEN - 1))
#define ALC_OFF  PAGE_UP(H_BANK + 3 * NCLS_ALL)
#define RING_OFF (ALC_OFF + CUBE * 2 * NCLS_ALL)
#define STAK_OFF (RING_OFF + CUBE * RING_WORDS)
#define STAT_OFF (STAK_OFF + CUBE * STAK_LEN)
#define HEAP_OFF (STAT_OFF + PAGE_UP(STAT_LEN))

// Globals
// =======

// The bag is 2^CUBE_LOG groups of CUBE_T lanes (a -D constant on the
// device). The device program compiles from the binary's own text.

#if !DEVICE

static u64*    CORPUS;
static u64    ALC[CUBE_T + 1][3 * NCLS_ALL] __attribute__((aligned(128)));
static u32    KEEP_WORDS;
static u32    CUBE_LOG = 7;
static u32    bank_lock;

static u32             pool_size;
static u32             pool_row;
static u32             pool_done;
static pthread_mutex_t pool_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  pool_wake = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  pool_join = PTHREAD_COND_INITIALIZER;

#if BEND_METAL || BEND_CUDA
#pragma clang diagnostic ignored "-Wc23-extensions"
static const char BEND_SRC[] = {
#embed __FILE__
, 0 };
#endif

#ifdef __OBJC__
static id<MTLDevice>               gpu_dev;
static id<MTLCommandQueue>         gpu_que;
static id<MTLComputePipelineState> gpu_pso;
static id<MTLBuffer>               gpu_buf;
static id<MTLComputeCommandEncoder> gpu_enc;
#elif BEND_CUDA
static CUdevice   gpu_dev;
static CUmodule   gpu_lib;
static CUfunction gpu_pso;
#endif
static bool io_gpu;
static DEV Term*  io_stk;

static const char* CLI_HELP =
  "usage: %s [options] [arguments]\n"
  "  --threads N       worker threads, 1 to 128 (default: the CPU count)\n"
  "  --gpu on|off|4GB  run ! calls on the GPU, over this much of its memory\n"
  "                    (default: on if present, over 2GB on Metal)\n"
  "  --gpu-build       write the GPU program and exit\n"
  "  --bend-help       show this text\n"
  "  --                the rest are the program's arguments (IO.args)\n";

#endif

// Tables
// ======

#define CID_TUPLE 0
#define CID_SNIL 1
#define CID_SCON 2
#define CID_WCON 3
#define CID_EMIT 4
#define CID_HALT 5
#define CID_FAIL 6
#define CID_DONE 7
#define CID_NONE 8
#define CID_SOME 9
#define CID_FALSE 10
#define CID_TRUE 11
#define CID_UNIT 12
#define CID_CONSUMER_EXPANDED_APPLICATION 13
#define CID_CONSUMER_EXPANDED_SCHEMAB 14
#define CID_CHR 15
#define CID________________BENDVY_SRC_ECS_WORLD_WORLD 16
#define CID_CONSUMER_EXPANDED_RESOURCES 17
#define CID________________BENDVY_SRC_ECS_SYSTEM_REGISTRY 18
#define CID_CONSUMER_EXPANDED_REQUEST 19
#define CID_NIL 20
#define CID_CON 21
#define CID_CONSUMER_EXPANDED_STEP 22
#define CID________________BENDVY_SRC_ECS_WORLD_CREATED 23
#define CID________________BENDVY_SRC_ECS_WORLD_CREATEREJECTED 24
#define CID________________BENDVY_SRC_ECS_WORLD_FACTORY 25
#define CID________________BENDVY_SRC_ECS_WORLD_REGISTRATIONMETA 26
#define CID________________BENDVY_SRC_ECS_MACHINE_MISSING 27
#define CID________________BENDVY_SRC_ECS_MACHINE_PRESENT 28
#define CID_CONSUMER_EXPANDED_FLOWKEY 29
#define CID_CONSUMER_EXPANDED_VALUE 30
#define CID________________BENDVY_SRC_ECS_SYSTEM_SUCCEEDED 31
#define CID________________BENDVY_SRC_ECS_SYSTEM_FAILED 32
#define CID________________BENDVY_SRC_ECS_MACHINE_SET 33
#define CID________________BENDVY_SRC_ECS_MACHINE_RESET 34
#define CID________________BENDVY_SRC_ECS_SYSTEM_REGISTERED 35
#define CID________________BENDVY_SRC_ECS_SYSTEM_REGISTRATIONFAILED 36
#define CID________________BENDVY_SRC_ECS_MACHINE_NOPENDING 37
#define CID________________BENDVY_SRC_ECS_MACHINE_QUEUED 38
#define CID_CONSUMER_EXPANDED_BOOT 39
#define CID_CONSUMER_EXPANDED_PLAY 40
#define CID_CONSUMER_EXPANDED_PAUSE 41
#define CID________________BENDVY_SRC_ECS_SYSTEM_COMPLETED 42
#define CID________________BENDVY_SRC_ECS_SYSTEM_REGISTRATIONREJECTED 43
#define CID________________BENDVY_SRC_ECS_WORLD_REGISTERED 44
#define CID________________BENDVY_SRC_ECS_WORLD_REGISTRATIONREJECTED 45
#define CID________________BENDVY_SRC_ECS_WORLD_MISSINGENTITY 46
#define CID________________BENDVY_SRC_ECS_WORLD_CAPACITYEXCEEDED 47
#define CID________________BENDVY_SRC_ECS_WORLD_NAMESPACEEXHAUSTED 48
#define CID________________BENDVY_SRC_ECS_WORLD_SYSTEMIDEXHAUSTED 49
#define CID________________BENDVY_SRC_ECS_TRANSACTION_TX 50
#define CID________________BENDVY_SRC_ECS_MACHINE_FAMILY 51
#define CID________________BENDVY_SRC_ECS_TRANSACTION_RETURNED 52
#define CID________________BENDVY_SRC_ECS_TRANSACTION_SUCCESS 53
#define CID________________BENDVY_SRC_ECS_TRANSACTION_FAILURE 54
#define FID_LIST_APPEND 0
#define FID_LIST_APPEND_K15 1
#define FID________________BENDVY_SRC_ECS_WORLD_ACCESS_EQUAL 2
#define FID________________BENDVY_SRC_ECS_WORLD_ACCESS_EQUAL_K20 3
#define FID________________BENDVY_SRC_ECS_TRANSACTION_ROLLBACK_0 4
#define FID________________BENDVY_SRC_ECS_TRANSACTION_ROLLBACK_0_K27 5
#define FID_CONSUMER_EXPANDED_PUBLISH_0 6
#define FID_CONSUMER_EXPANDED_PUBLISH_0_K29 7
#define FID________________BENDVY_SRC_ECS_MACHINE_RESET_TAKEN_0_C35 8
#define FID_QUEUE_WRITE_TAKEN_0_C37 9
#define FID________________BENDVY_SRC_ECS_TRANSACTION_FINISH_0 10
#define FID________________BENDVY_SRC_ECS_TRANSACTION_FINISH_0_K44 11
#define FID________________BENDVY_SRC_ECS_TRANSACTION_FINISH_0_K45 12
#define FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_META_MATCHES 13
#define FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_WALK 14
#define FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_WALK_K55 15
#define FID_CONSUMER_EXPANDED_RUNNER_0 16
#define FID_CONSUMER_EXPANDED_RUNNER_0_K57 17
#define FID_CONSUMER_EXPANDED_RUNNER_0_K58 18
#define FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES 19
#define FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_MATCHES_0 20
#define FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_MATCHES_0_K64 21
#define FID_LIST_SHOW_GO_1 22
#define FID_LIST_SHOW_GO_1_K98 23
#define FID_LIST_SHOW_GO_1_K99 24
#define FID_LIST_SHOW_GO_1_K100 25
#define FID_CONSUMER_EXPANDED_REGISTRATION 26
#define FID_CONSUMER_EXPANDED_REGISTRATION_K102 27
#define FID_CONSUMER_EXPANDED_REGISTRATION_K103 28
#define FID_CONSUMER_EXPANDED_REGISTRATION_K104 29
#define FID_CONSUMER_EXPANDED_REGISTRATION_K105 30
#define FID_CONSUMER_EXPANDED_REGISTRATION_K106 31
#define FID_CONSUMER_EXPANDED_PREVIOUS 32
#define FID_CONSUMER_EXPANDED_SHOW_PENDING 33
#define FID_CONSUMER_EXPANDED_SHOW_PENDING_K110 34
#define FID_CONSUMER_EXPANDED_SHOW_PENDING_K111 35
#define FID_CONSUMER_EXPANDED_SHOW_VALUE 36
#define FID_CONSUMER_EXPANDED_SHOW_VALUE_K113 37
#define FID_CONSUMER_EXPANDED_SHOW_VALUE_K114 38
#define FID_NAT_SHOW_FIN 39
#define FID_U32_SHOW_GO 40
#define FID_CONSUMER_EXPANDED_NUMBER 41
#define FID_CONSUMER_EXPANDED_NUMBER_K132 42
#define FID_CONSUMER_EXPANDED_PAYLOAD 43
#define FID_LIST_SHOW_1 44
#define FID_LIST_SHOW_1_K156 45
#define FID_LIST_SHOW_1_K157 46
#define FID_LIST_SHOW_1_K158 47
#define FID_CONSUMER_EXPANDED_SHOW_SLOT_0 48
#define FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K160 49
#define FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K161 50
#define FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K162 51
#define FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K163 52
#define FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K164 53
#define FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K165 54
#define FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K166 55
#define FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K167 56
#define FID_NAT_SHOW 57
#define FID_LIST_SHOW_GO_0 58
#define FID_LIST_SHOW_GO_0_K170 59
#define FID_LIST_SHOW_GO_0_K171 60
#define FID________________BENDVY_SRC_ECS_SYSTEM_RUN_0 61
#define FID________________BENDVY_SRC_ECS_SYSTEM_RUN_0_K174 62
#define FID________________BENDVY_SRC_ECS_SYSTEM_RUN_0_K175 63
#define FID_CONSUMER_EXPANDED_TREE_0 64
#define FID_CONSUMER_EXPANDED_TREE_0_K184 65
#define FID_CONSUMER_EXPANDED_TREE_0_K185 66
#define FID_CONSUMER_EXPANDED_TREE_0_K186 67
#define FID_CONSUMER_EXPANDED_TREE_0_K187 68
#define FID_CONSUMER_EXPANDED_TREE_0_K188 69
#define FID_CONSUMER_EXPANDED_TREE_0_K189 70
#define FID_CONSUMER_EXPANDED_TREE_0_K190 71
#define FID_CONSUMER_EXPANDED_TREE_0_K191 72
#define FID_CONSUMER_EXPANDED_TREE_0_K192 73
#define FID_CONSUMER_EXPANDED_TREE_2 74
#define FID_CONSUMER_EXPANDED_TREE_2_K194 75
#define FID_CONSUMER_EXPANDED_TREE_2_K195 76
#define FID_CONSUMER_EXPANDED_TREE_2_K196 77
#define FID_CONSUMER_EXPANDED_TREE_2_K197 78
#define FID_CONSUMER_EXPANDED_TREE_2_K198 79
#define FID_CONSUMER_EXPANDED_TREE_2_K199 80
#define FID_CONSUMER_EXPANDED_TREE_2_K200 81
#define FID_CONSUMER_EXPANDED_TREE_2_K201 82
#define FID_CONSUMER_EXPANDED_TREE_2_K202 83
#define FID_CONSUMER_EXPANDED_TREE_1 84
#define FID_CONSUMER_EXPANDED_TREE_1_K204 85
#define FID_CONSUMER_EXPANDED_TREE_1_K205 86
#define FID_CONSUMER_EXPANDED_TREE_1_K206 87
#define FID_CONSUMER_EXPANDED_TREE_1_K207 88
#define FID_CONSUMER_EXPANDED_TREE_1_K208 89
#define FID_CONSUMER_EXPANDED_TREE_1_K209 90
#define FID_CONSUMER_EXPANDED_TREE_1_K210 91
#define FID_CONSUMER_EXPANDED_TREE_1_K211 92
#define FID_CONSUMER_EXPANDED_COMMANDS_0 93
#define FID_CONSUMER_EXPANDED_COMMANDS_0_K213 94
#define FID_LIST_SHOW_0 95
#define FID_LIST_SHOW_0_K254 96
#define FID_LIST_SHOW_0_K255 97
#define FID_U32_SHOW 98
#define FID________________BENDVY_SRC_ECS_SYSTEM_RUN_TRACKED_0 99
#define FID________________BENDVY_SRC_ECS_SYSTEM_RUN_TRACKED_0_K258 100
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0 101
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K265 102
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K266 103
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K267 104
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K268 105
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K269 106
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K270 107
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K271 108
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K272 109
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K273 110
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K274 111
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K275 112
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K276 113
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K277 114
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K278 115
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K279 116
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K280 117
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K281 118
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K282 119
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K283 120
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K284 121
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K285 122
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K286 123
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K287 124
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K288 125
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K289 126
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K290 127
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K291 128
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K292 129
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K293 130
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K294 131
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K295 132
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K296 133
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K297 134
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K298 135
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K299 136
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K300 137
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K301 138
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K302 139
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K303 140
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K304 141
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K305 142
#define FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K306 143
#define FID_STRING_APPEND 144
#define FID_STRING_APPEND_K327 145
#define FID_CONSUMER_EXPANDED_OBSERVE_0 146
#define FID_CONSUMER_EXPANDED_OBSERVE_0_K337 147
#define FID_CONSUMER_EXPANDED_OBSERVE_0_K338 148
#define FID_CONSUMER_EXPANDED_OBSERVE_0_K339 149
#define FID_CONSUMER_EXPANDED_OBSERVE_0_K340 150
#define FID_CONSUMER_EXPANDED_OBSERVE_0_K341 151
#define FID_CONSUMER_EXPANDED_OBSERVE_0_K342 152
#define FID_CONSUMER_EXPANDED_OBSERVE_0_K343 153
#define FID_CONSUMER_EXPANDED_OBSERVE_0_K344 154
#define FID_CONSUMER_EXPANDED_OBSERVE_0_K345 155
#define FID_CONSUMER_EXPANDED_OBSERVE_0_K346 156
#define FID_CONSUMER_EXPANDED_OBSERVE_0_K347 157
#define FID_CONSUMER_EXPANDED_OBSERVE_0_K348 158
#define FID_CONSUMER_EXPANDED_OBSERVE_0_K349 159
#define FID_CONSUMER_EXPANDED_OBSERVE_0_K350 160
#define FID_CONSUMER_EXPANDED_OBSERVE_0_K351 161
#define FID_CONSUMER_EXPANDED_OBSERVE_0_K352 162
#define FID_CONSUMER_EXPANDED_OBSERVE_0_K353 163
#define FID_CONSUMER_EXPANDED_OBSERVE_0_K354 164
#define FID_CONSUMER_EXPANDED_OBSERVE_0_K355 165
#define FID_CONSUMER_EXPANDED_ACTION_0 166
#define FID_CONSUMER_EXPANDED_ACTION_0_K362 167
#define FID_CONSUMER_EXPANDED_SEED_0_C366 168
#define FID_CONSUMER_EXPANDED_CHECKPOINT_0 169
#define FID_CONSUMER_EXPANDED_CHECKPOINT_0_K368 170
#define FID_CONSUMER_EXPANDED_CHECKPOINT_0_K369 171
#define FID_CONSUMER_EXPANDED_CHECKPOINT_0_K370 172
#define FID_CONSUMER_EXPANDED_CHECKPOINT_0_K371 173
#define FID_CONSUMER_EXPANDED_CHECKPOINT_0_K372 174
#define FID_CONSUMER_EXPANDED_STEPS_0 175
#define FID_CONSUMER_EXPANDED_STEPS_0_K374 176
#define FID_CONSUMER_EXPANDED_STEPS_0_K375 177
#define FID_MAIN 178
#define FID_MAIN_K380 179
#define FID_IO_EMIT 180
#define FID_CLO_APPLY 181
#define FID_EXIT 182
#define FID_ENTER 183
CONSTV u8 FID_T[][3] = { { 2, 0, 2 }, { 2, 1, 2 }, { 2, 0, 2 }, { 3, 1, 2 }, { 25, 0, 2 }, { 2, 1, 2 }, { 25, 0, 2 }, { 24, 1, 2 }, { 12, 0, 2 }, { 12, 0, 2 }, { 29, 0, 2 }, { 24, 24, 2 }, { 25, 24, 2 }, { 6, 0, 2 }, { 5, 0, 2 }, { 5, 1, 2 }, { 29, 0, 2 }, { 26, 26, 2 }, { 26, 26, 2 }, { 4, 0, 2 }, { 27, 0, 2 }, { 25, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 3, 0, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 3, 0, 2 }, { 4, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 4, 0, 2 }, { 3, 0, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 11, 0, 2 }, { 9, 1, 2 }, { 6, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 34, 0, 2 }, { 35, 25, 2 }, { 31, 26, 2 }, { 1, 0, 2 }, { 2, 2, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 3, 2, 2 }, { 4, 2, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 1, 0, 2 }, { 2, 2, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 3, 2, 2 }, { 4, 2, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 3, 2, 2 }, { 4, 2, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 1, 0, 2 }, { 3, 2, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 34, 0, 2 }, { 35, 35, 2 }, { 24, 0, 2 }, { 25, 2, 2 }, { 26, 2, 2 }, { 27, 2, 2 }, { 28, 2, 2 }, { 29, 1, 2 }, { 30, 1, 2 }, { 31, 1, 2 }, { 32, 1, 2 }, { 33, 1, 2 }, { 34, 1, 2 }, { 35, 1, 2 }, { 35, 1, 2 }, { 36, 1, 2 }, { 37, 1, 2 }, { 38, 1, 2 }, { 38, 1, 2 }, { 37, 1, 2 }, { 37, 1, 2 }, { 36, 1, 2 }, { 36, 1, 2 }, { 35, 1, 2 }, { 35, 1, 2 }, { 34, 1, 2 }, { 34, 1, 2 }, { 33, 1, 2 }, { 33, 1, 2 }, { 32, 1, 2 }, { 32, 1, 2 }, { 31, 1, 2 }, { 31, 1, 2 }, { 30, 1, 2 }, { 30, 1, 2 }, { 29, 1, 2 }, { 29, 1, 2 }, { 28, 1, 2 }, { 28, 1, 2 }, { 27, 1, 2 }, { 27, 1, 2 }, { 26, 1, 2 }, { 26, 1, 2 }, { 25, 1, 2 }, { 25, 1, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 31, 0, 2 }, { 32, 25, 2 }, { 27, 1, 2 }, { 26, 1, 2 }, { 32, 1, 2 }, { 33, 1, 2 }, { 34, 1, 2 }, { 35, 1, 2 }, { 36, 1, 2 }, { 35, 1, 2 }, { 35, 1, 2 }, { 34, 1, 2 }, { 34, 1, 2 }, { 34, 1, 2 }, { 34, 1, 2 }, { 33, 1, 2 }, { 33, 1, 2 }, { 32, 1, 2 }, { 32, 1, 2 }, { 31, 1, 2 }, { 37, 0, 2 }, { 35, 35, 2 }, { 1, 0, 2 }, { 33, 0, 2 }, { 34, 32, 2 }, { 34, 1, 2 }, { 34, 1, 2 }, { 33, 1, 2 }, { 32, 1, 2 }, { 33, 0, 2 }, { 34, 31, 2 }, { 33, 32, 2 }, { 0, 0, 2 }, { 32, 32, 2 }, { 1, 0, 2 }, { 2, 0, 2 } };
CONSTV u8 CID_T[][2] = { { 2, 1 }, { 0, 1 }, { 2, 1 }, { 2, 1 }, { 1, 0 }, { 2, 0 }, { 1, 0 }, { 1, 0 }, { 0, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 31, 1 }, { 0, 1 }, { 1, 1 }, { 13, 1 }, { 12, 1 }, { 5, 1 }, { 5, 1 }, { 0, 1 }, { 2, 1 }, { 7, 1 }, { 14, 0 }, { 2, 0 }, { 1, 1 }, { 3, 1 }, { 0, 1 }, { 7, 1 }, { 0, 1 }, { 2, 1 }, { 2, 1 }, { 2, 1 }, { 2, 1 }, { 0, 1 }, { 18, 0 }, { 13, 0 }, { 0, 1 }, { 2, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 20, 1 }, { 19, 1 }, { 1, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 4, 1 }, { 1, 1 }, { 3, 1 }, { 0, 1 }, { 1, 1 } };
#define STAT_LEN 833

#define WL_RESW 35
#define BANGS   0

#define WL_BANK Term r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29, r30, r31, r32, r33, r34, r35, r36;

#define WL_LOAD(A, N) \
  do { \
    if ((N) <= 0) break; r0 = e.mem[(A) + 0]; \
    if ((N) <= 1) break; r1 = e.mem[(A) + 1]; \
    if ((N) <= 2) break; r2 = e.mem[(A) + 2]; \
    if ((N) <= 3) break; r3 = e.mem[(A) + 3]; \
    if ((N) <= 4) break; r4 = e.mem[(A) + 4]; \
    if ((N) <= 5) break; r5 = e.mem[(A) + 5]; \
    if ((N) <= 6) break; r6 = e.mem[(A) + 6]; \
    if ((N) <= 7) break; r7 = e.mem[(A) + 7]; \
    if ((N) <= 8) break; r8 = e.mem[(A) + 8]; \
    if ((N) <= 9) break; r9 = e.mem[(A) + 9]; \
    if ((N) <= 10) break; r10 = e.mem[(A) + 10]; \
    if ((N) <= 11) break; r11 = e.mem[(A) + 11]; \
    if ((N) <= 12) break; r12 = e.mem[(A) + 12]; \
    if ((N) <= 13) break; r13 = e.mem[(A) + 13]; \
    if ((N) <= 14) break; r14 = e.mem[(A) + 14]; \
    if ((N) <= 15) break; r15 = e.mem[(A) + 15]; \
    if ((N) <= 16) break; r16 = e.mem[(A) + 16]; \
    if ((N) <= 17) break; r17 = e.mem[(A) + 17]; \
    if ((N) <= 18) break; r18 = e.mem[(A) + 18]; \
    if ((N) <= 19) break; r19 = e.mem[(A) + 19]; \
    if ((N) <= 20) break; r20 = e.mem[(A) + 20]; \
    if ((N) <= 21) break; r21 = e.mem[(A) + 21]; \
    if ((N) <= 22) break; r22 = e.mem[(A) + 22]; \
    if ((N) <= 23) break; r23 = e.mem[(A) + 23]; \
    if ((N) <= 24) break; r24 = e.mem[(A) + 24]; \
    if ((N) <= 25) break; r25 = e.mem[(A) + 25]; \
    if ((N) <= 26) break; r26 = e.mem[(A) + 26]; \
    if ((N) <= 27) break; r27 = e.mem[(A) + 27]; \
    if ((N) <= 28) break; r28 = e.mem[(A) + 28]; \
    if ((N) <= 29) break; r29 = e.mem[(A) + 29]; \
    if ((N) <= 30) break; r30 = e.mem[(A) + 30]; \
    if ((N) <= 31) break; r31 = e.mem[(A) + 31]; \
    if ((N) <= 32) break; r32 = e.mem[(A) + 32]; \
    if ((N) <= 33) break; r33 = e.mem[(A) + 33]; \
    if ((N) <= 34) break; r34 = e.mem[(A) + 34]; \
    if ((N) <= 35) break; r35 = e.mem[(A) + 35]; \
    if ((N) <= 36) break; r36 = e.mem[(A) + 36]; \
  } while (0);

#define WL_LAST(X) \
  switch (war) { \
    case 0: r0 = (X); \
      break; \
    case 1: r1 = (X); \
      break; \
    case 2: r2 = (X); \
      break; \
    case 3: r3 = (X); \
      break; \
    case 4: r4 = (X); \
      break; \
    case 5: r5 = (X); \
      break; \
    case 6: r6 = (X); \
      break; \
    case 7: r7 = (X); \
      break; \
    case 8: r8 = (X); \
      break; \
    case 9: r9 = (X); \
      break; \
    case 10: r10 = (X); \
      break; \
    case 11: r11 = (X); \
      break; \
    case 12: r12 = (X); \
      break; \
    case 13: r13 = (X); \
      break; \
    case 14: r14 = (X); \
      break; \
    case 15: r15 = (X); \
      break; \
    case 16: r16 = (X); \
      break; \
    case 17: r17 = (X); \
      break; \
    case 18: r18 = (X); \
      break; \
    case 19: r19 = (X); \
      break; \
    case 20: r20 = (X); \
      break; \
    case 21: r21 = (X); \
      break; \
    case 22: r22 = (X); \
      break; \
    case 23: r23 = (X); \
      break; \
    case 24: r24 = (X); \
      break; \
    case 25: r25 = (X); \
      break; \
    case 26: r26 = (X); \
      break; \
    case 27: r27 = (X); \
      break; \
    case 28: r28 = (X); \
      break; \
    case 29: r29 = (X); \
      break; \
    case 30: r30 = (X); \
      break; \
    case 31: r31 = (X); \
      break; \
    case 32: r32 = (X); \
      break; \
    case 33: r33 = (X); \
      break; \
    case 34: r34 = (X); \
      break; \
    case 35: r35 = (X); \
      break; \
    case 36: r36 = (X); \
      break; \
  }

#define WL_SAVE(V) (V)[0] = r0; (V)[1] = r1; (V)[2] = r2; (V)[3] = r3; (V)[4] = r4; (V)[5] = r5; (V)[6] = r6; (V)[7] = r7; (V)[8] = r8; (V)[9] = r9; (V)[10] = r10; (V)[11] = r11; (V)[12] = r12; (V)[13] = r13; (V)[14] = r14; (V)[15] = r15; (V)[16] = r16; (V)[17] = r17; (V)[18] = r18; (V)[19] = r19; (V)[20] = r20; (V)[21] = r21; (V)[22] = r22; (V)[23] = r23; (V)[24] = r24; (V)[25] = r25; (V)[26] = r26; (V)[27] = r27; (V)[28] = r28; (V)[29] = r29; (V)[30] = r30; (V)[31] = r31; (V)[32] = r32; (V)[33] = r33; (V)[34] = r34;

#define WL_TAKE(V) r0 = (V)[0]; r1 = (V)[1]; r2 = (V)[2]; r3 = (V)[3]; r4 = (V)[4]; r5 = (V)[5]; r6 = (V)[6]; r7 = (V)[7]; r8 = (V)[8]; r9 = (V)[9]; r10 = (V)[10]; r11 = (V)[11]; r12 = (V)[12]; r13 = (V)[13]; r14 = (V)[14]; r15 = (V)[15]; r16 = (V)[16]; r17 = (V)[17]; r18 = (V)[18]; r19 = (V)[19]; r20 = (V)[20]; r21 = (V)[21]; r22 = (V)[22]; r23 = (V)[23]; r24 = (V)[24]; r25 = (V)[25]; r26 = (V)[26]; r27 = (V)[27]; r28 = (V)[28]; r29 = (V)[29]; r30 = (V)[30]; r31 = (V)[31]; r32 = (V)[32]; r33 = (V)[33]; r34 = (V)[34];

#define WL_SIG Env e, DEV Term* sp, u32 seq, u32 rn, Term r0, Term r1, Term r2, Term r3, Term r4, Term r5, Term rp, Term r6, Term r7, Term r8, Term r9, Term r10, Term r11, Term r12, Term r13, Term r14, Term r15, Term r16, Term r17, Term r18, Term r19, Term r20, Term r21, Term r22, Term r23, Term r24, Term r25, Term r26, Term r27, Term r28, Term r29, Term r30, Term r31, Term r32, Term r33, Term r34, Term r35, Term r36

#define WL_ALL e, sp, seq, rn, r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29, r30, r31, r32, r33, r34, r35, r36

#define WL_TABLE WL_X(FID_LIST_APPEND) WL_X(FID_LIST_APPEND_K15) WL_X(FID________________BENDVY_SRC_ECS_WORLD_ACCESS_EQUAL) WL_X(FID________________BENDVY_SRC_ECS_WORLD_ACCESS_EQUAL_K20) WL_X(FID________________BENDVY_SRC_ECS_TRANSACTION_ROLLBACK_0) WL_X(FID________________BENDVY_SRC_ECS_TRANSACTION_ROLLBACK_0_K27) WL_X(FID_CONSUMER_EXPANDED_PUBLISH_0) WL_X(FID_CONSUMER_EXPANDED_PUBLISH_0_K29) WL_X(FID________________BENDVY_SRC_ECS_MACHINE_RESET_TAKEN_0_C35) WL_X(FID_QUEUE_WRITE_TAKEN_0_C37) WL_X(FID________________BENDVY_SRC_ECS_TRANSACTION_FINISH_0) WL_X(FID________________BENDVY_SRC_ECS_TRANSACTION_FINISH_0_K44) WL_X(FID________________BENDVY_SRC_ECS_TRANSACTION_FINISH_0_K45) WL_X(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_META_MATCHES) WL_X(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_WALK) WL_X(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_WALK_K55) WL_X(FID_CONSUMER_EXPANDED_RUNNER_0) WL_X(FID_CONSUMER_EXPANDED_RUNNER_0_K57) WL_X(FID_CONSUMER_EXPANDED_RUNNER_0_K58) WL_X(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES) WL_X(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_MATCHES_0) WL_X(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_MATCHES_0_K64) WL_X(FID_LIST_SHOW_GO_1) WL_X(FID_LIST_SHOW_GO_1_K98) WL_X(FID_LIST_SHOW_GO_1_K99) WL_X(FID_LIST_SHOW_GO_1_K100) WL_X(FID_CONSUMER_EXPANDED_REGISTRATION) WL_X(FID_CONSUMER_EXPANDED_REGISTRATION_K102) WL_X(FID_CONSUMER_EXPANDED_REGISTRATION_K103) WL_X(FID_CONSUMER_EXPANDED_REGISTRATION_K104) WL_X(FID_CONSUMER_EXPANDED_REGISTRATION_K105) WL_X(FID_CONSUMER_EXPANDED_REGISTRATION_K106) WL_X(FID_CONSUMER_EXPANDED_PREVIOUS) WL_X(FID_CONSUMER_EXPANDED_SHOW_PENDING) WL_X(FID_CONSUMER_EXPANDED_SHOW_PENDING_K110) WL_X(FID_CONSUMER_EXPANDED_SHOW_PENDING_K111) WL_X(FID_CONSUMER_EXPANDED_SHOW_VALUE) WL_X(FID_CONSUMER_EXPANDED_SHOW_VALUE_K113) WL_X(FID_CONSUMER_EXPANDED_SHOW_VALUE_K114) WL_X(FID_NAT_SHOW_FIN) WL_X(FID_U32_SHOW_GO) WL_X(FID_CONSUMER_EXPANDED_NUMBER) WL_X(FID_CONSUMER_EXPANDED_NUMBER_K132) WL_X(FID_CONSUMER_EXPANDED_PAYLOAD) WL_X(FID_LIST_SHOW_1) WL_X(FID_LIST_SHOW_1_K156) WL_X(FID_LIST_SHOW_1_K157) WL_X(FID_LIST_SHOW_1_K158) WL_X(FID_CONSUMER_EXPANDED_SHOW_SLOT_0) WL_X(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K160) WL_X(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K161) WL_X(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K162) WL_X(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K163) WL_X(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K164) WL_X(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K165) WL_X(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K166) WL_X(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K167) WL_X(FID_NAT_SHOW) WL_X(FID_LIST_SHOW_GO_0) WL_X(FID_LIST_SHOW_GO_0_K170) WL_X(FID_LIST_SHOW_GO_0_K171) WL_X(FID________________BENDVY_SRC_ECS_SYSTEM_RUN_0) WL_X(FID________________BENDVY_SRC_ECS_SYSTEM_RUN_0_K174) WL_X(FID________________BENDVY_SRC_ECS_SYSTEM_RUN_0_K175) WL_X(FID_CONSUMER_EXPANDED_TREE_0) WL_X(FID_CONSUMER_EXPANDED_TREE_0_K184) WL_X(FID_CONSUMER_EXPANDED_TREE_0_K185) WL_X(FID_CONSUMER_EXPANDED_TREE_0_K186) WL_X(FID_CONSUMER_EXPANDED_TREE_0_K187) WL_X(FID_CONSUMER_EXPANDED_TREE_0_K188) WL_X(FID_CONSUMER_EXPANDED_TREE_0_K189) WL_X(FID_CONSUMER_EXPANDED_TREE_0_K190) WL_X(FID_CONSUMER_EXPANDED_TREE_0_K191) WL_X(FID_CONSUMER_EXPANDED_TREE_0_K192) WL_X(FID_CONSUMER_EXPANDED_TREE_2) WL_X(FID_CONSUMER_EXPANDED_TREE_2_K194) WL_X(FID_CONSUMER_EXPANDED_TREE_2_K195) WL_X(FID_CONSUMER_EXPANDED_TREE_2_K196) WL_X(FID_CONSUMER_EXPANDED_TREE_2_K197) WL_X(FID_CONSUMER_EXPANDED_TREE_2_K198) WL_X(FID_CONSUMER_EXPANDED_TREE_2_K199) WL_X(FID_CONSUMER_EXPANDED_TREE_2_K200) WL_X(FID_CONSUMER_EXPANDED_TREE_2_K201) WL_X(FID_CONSUMER_EXPANDED_TREE_2_K202) WL_X(FID_CONSUMER_EXPANDED_TREE_1) WL_X(FID_CONSUMER_EXPANDED_TREE_1_K204) WL_X(FID_CONSUMER_EXPANDED_TREE_1_K205) WL_X(FID_CONSUMER_EXPANDED_TREE_1_K206) WL_X(FID_CONSUMER_EXPANDED_TREE_1_K207) WL_X(FID_CONSUMER_EXPANDED_TREE_1_K208) WL_X(FID_CONSUMER_EXPANDED_TREE_1_K209) WL_X(FID_CONSUMER_EXPANDED_TREE_1_K210) WL_X(FID_CONSUMER_EXPANDED_TREE_1_K211) WL_X(FID_CONSUMER_EXPANDED_COMMANDS_0) WL_X(FID_CONSUMER_EXPANDED_COMMANDS_0_K213) WL_X(FID_LIST_SHOW_0) WL_X(FID_LIST_SHOW_0_K254) WL_X(FID_LIST_SHOW_0_K255) WL_X(FID_U32_SHOW) WL_X(FID________________BENDVY_SRC_ECS_SYSTEM_RUN_TRACKED_0) WL_X(FID________________BENDVY_SRC_ECS_SYSTEM_RUN_TRACKED_0_K258) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K265) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K266) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K267) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K268) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K269) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K270) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K271) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K272) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K273) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K274) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K275) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K276) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K277) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K278) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K279) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K280) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K281) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K282) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K283) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K284) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K285) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K286) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K287) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K288) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K289) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K290) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K291) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K292) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K293) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K294) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K295) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K296) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K297) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K298) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K299) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K300) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K301) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K302) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K303) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K304) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K305) WL_X(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K306) WL_X(FID_STRING_APPEND) WL_X(FID_STRING_APPEND_K327) WL_X(FID_CONSUMER_EXPANDED_OBSERVE_0) WL_X(FID_CONSUMER_EXPANDED_OBSERVE_0_K337) WL_X(FID_CONSUMER_EXPANDED_OBSERVE_0_K338) WL_X(FID_CONSUMER_EXPANDED_OBSERVE_0_K339) WL_X(FID_CONSUMER_EXPANDED_OBSERVE_0_K340) WL_X(FID_CONSUMER_EXPANDED_OBSERVE_0_K341) WL_X(FID_CONSUMER_EXPANDED_OBSERVE_0_K342) WL_X(FID_CONSUMER_EXPANDED_OBSERVE_0_K343) WL_X(FID_CONSUMER_EXPANDED_OBSERVE_0_K344) WL_X(FID_CONSUMER_EXPANDED_OBSERVE_0_K345) WL_X(FID_CONSUMER_EXPANDED_OBSERVE_0_K346) WL_X(FID_CONSUMER_EXPANDED_OBSERVE_0_K347) WL_X(FID_CONSUMER_EXPANDED_OBSERVE_0_K348) WL_X(FID_CONSUMER_EXPANDED_OBSERVE_0_K349) WL_X(FID_CONSUMER_EXPANDED_OBSERVE_0_K350) WL_X(FID_CONSUMER_EXPANDED_OBSERVE_0_K351) WL_X(FID_CONSUMER_EXPANDED_OBSERVE_0_K352) WL_X(FID_CONSUMER_EXPANDED_OBSERVE_0_K353) WL_X(FID_CONSUMER_EXPANDED_OBSERVE_0_K354) WL_X(FID_CONSUMER_EXPANDED_OBSERVE_0_K355) WL_X(FID_CONSUMER_EXPANDED_ACTION_0) WL_X(FID_CONSUMER_EXPANDED_ACTION_0_K362) WL_X(FID_CONSUMER_EXPANDED_SEED_0_C366) WL_X(FID_CONSUMER_EXPANDED_CHECKPOINT_0) WL_X(FID_CONSUMER_EXPANDED_CHECKPOINT_0_K368) WL_X(FID_CONSUMER_EXPANDED_CHECKPOINT_0_K369) WL_X(FID_CONSUMER_EXPANDED_CHECKPOINT_0_K370) WL_X(FID_CONSUMER_EXPANDED_CHECKPOINT_0_K371) WL_X(FID_CONSUMER_EXPANDED_CHECKPOINT_0_K372) WL_X(FID_CONSUMER_EXPANDED_STEPS_0) WL_X(FID_CONSUMER_EXPANDED_STEPS_0_K374) WL_X(FID_CONSUMER_EXPANDED_STEPS_0_K375) WL_X(FID_MAIN) WL_X(FID_MAIN_K380) WL_X(FID_IO_EMIT) WL_X(FID_CLO_APPLY) WL_X(FID_EXIT)
#define MAIN_FID FID_MAIN
#define MAIN_PURE 1
#define BLK_SHR 1

#if !DEVICE

static const u32 SHOW_DESC[] = { 4 };

static const char* SHOW_NAMES[] = {  };

#endif

#define TAB_AT(T, S, I) T[S < I ? S : I]

#define fid_arity(x) ((u32)FID_T[x][0])
#define fid_resw(x)  ((u32)FID_T[x][1])
#define fid_bangs(x) ((bool)(FID_T[x][2] & 1))
#define fid_nofk(x)  ((bool)(FID_T[x][2] & 2))
#define cid_arity(x) ((u32)CID_T[x][0])
#define cid_hot(x)   ((bool)CID_T[x][1])

// A32
// ===

// C11's atomics on every lane; a device FENCE releases or acquires.
// Metal's loads read through a volatile local, or the M1 and M2 pipeline
// builds die. A weak CAS may fail with the cell still x: a32_cmpx loops.

#define A32_LOOP(k, x) \
  INLINE u32 a32_##k(DEV u32* p, u32 v) { \
    u32 o = a32_load(p); \
    while (!a32_cas(p, &o, x)) { \
    } \
    return o; \
  }

#ifdef __METAL_VERSION__

INLINE DEV atomic_uint* A32(DEV u32* p) {
  return (DEV atomic_uint*)p;
}

INLINE TG atomic_uint* A32(TG u32* p) {
  return (TG atomic_uint*)p;
}

#define a32_load(p) \
  ({ volatile thread u32 _a32v = atomic_load_explicit(A32(p), RLX); _a32v; })

#else

#define a32_load(p) atomic_load_explicit(A32(p), RLX)

#ifdef BEND_RTC

#define A32(p) (p)
#define atomic_load_explicit(p, o)     (*(volatile u32*)(p))
#define atomic_store_explicit(p, v, o) (*(volatile u32*)(p) = (v))
#define atomic_fetch_add_explicit(p, v, o) atomicAdd((u32*)(p), v)
#define atomic_fetch_sub_explicit(p, v, o) atomicSub((u32*)(p), v)
#define atomic_fetch_and_explicit(p, v, o) atomicAnd((u32*)(p), v)
#define atomic_fetch_or_explicit(p, v, o) atomicOr((u32*)(p), v)
#define atomic_fetch_xor_explicit(p, v, o) atomicXor((u32*)(p), v)
#define atomic_fetch_min_explicit(p, v, o) atomicMin((u32*)(p), v)
#define atomic_fetch_max_explicit(p, v, o) atomicMax((u32*)(p), v)
#define atomic_compare_exchange_weak_explicit(p, e, v, s, f) a32_swp(p, e, v)

INLINE bool a32_swp(DEV u32* p, u32* e, u32 v) {
  u32 x = *e;
  *e = atomicCAS((u32*)p, x, v);
  return *e == x;
}

#else

#define A32(p) ((_Atomic u32*)(p))
#define atomic_fetch_min_explicit __c11_atomic_fetch_min
#define atomic_fetch_max_explicit __c11_atomic_fetch_max

#endif

#endif

#define RLX memory_order_relaxed

#if DEVICE
#define REL RLX
#define ACQ RLX
#define ACR RLX
#define a32_acq(p) FENCE()
#define w64_load(p) (*(p))
#else
#define REL memory_order_release
#define ACQ memory_order_acquire
#define ACR memory_order_acq_rel
#define a32_acq(p) ((void)a32_load_acq(p))
#define w64_load(p) atomic_load_explicit((_Atomic u64*)(p), RLX)
#endif

#define a32_store(p, v)     atomic_store_explicit(A32(p), v, RLX)
#define a32_add(p, v) atomic_fetch_add_explicit(A32(p), v, RLX)
#define a32_sub(p, v) atomic_fetch_sub_explicit(A32(p), v, RLX)
#define a32_and(p, v) atomic_fetch_and_explicit(A32(p), v, RLX)
#define a32_or(p, v) atomic_fetch_or_explicit(A32(p), v, RLX)
#define a32_xor(p, v) atomic_fetch_xor_explicit(A32(p), v, RLX)
#define a32_min(p, v) atomic_fetch_min_explicit(A32(p), v, RLX)
#define a32_max(p, v) atomic_fetch_max_explicit(A32(p), v, RLX)
#define a32_sub_rel(p, v)   (FENCE(), atomic_fetch_sub_explicit(A32(p), v, REL))
#define a32_store_rel(p, v) (FENCE(), atomic_store_explicit(A32(p), v, REL))
#define a32_at(H, word)     ((DEV u32*)&(H)[word])

INLINE u32 a32_load_acq(DEV u32* p) {
  u32 v = DEVICE ? a32_load(p) : atomic_load_explicit(A32(p), ACQ);
  FENCE();
  return v;
}

INLINE bool a32_cas(DEV u32* p, THR u32* e, u32 v) {
  FENCE();
  bool ok = atomic_compare_exchange_weak_explicit(A32(p), e, v, ACR, ACQ);
  FENCE();
  return ok;
}

A32_LOOP(exch, v)

INLINE u32 a32_cmpx(DEV u32* p, u32 x, u32 v) {
  u32 o = x;
  while (!a32_cas(p, &o, v) && o == x) {
  }
  return o;
}

// Err
// ===

#if DEVICE

INLINE void err_post(DEV u64* H, u32 code) {
  a32_cmpx(a32_at(H, H_ERROR_CODE), 0, code);
}

#else

static const char* ERR_TEXT[] = { "",
  "runtime fail-stop",
  "runtime fail-stop",
  "out of memory: run again with a bigger span, as in --gpu 8GB",
  "a function the device does not hold",
  "a Nat past the largest immediate 2^48-1",
  "runtime fail-stop",
  "memory fault (machine stack overflow?)",
  "an array past the deepest block class 31" };

static void err_fail(const char* msg) {
  fflush(stdout);
  fprintf(stderr, "bend: %s\n", msg);
  _exit(1);
}

static void err_post(u64* H, u32 code) {
  err_fail(ERR_TEXT[code]);
}

static void err_trap(int sig) {
  err_post(NULL, ERR_DEEP);
}

#endif

#define err_seen(H)    (DEVICE && a32_load(a32_at(H, H_ERROR_CODE)) != 0)
#define err_spun(H, n) ((++*(n) & 4095) == 0 && err_seen(H))

#ifdef __METAL_VERSION__
INLINE f32 atan2_c99(f32 y, f32 x) {
  return y == 0.0f && x == x
    ? copysign(signbit(x) ? M_PI_F : 0.0f, y) : atan2(y, x);
}
#define sqrt  precise::sqrt
#define exp   precise::exp
#define log   precise::log
#define log2  precise::log2
#define log10 precise::log10
#define sin   fast::sin
#define cos   fast::cos
#define tan   fast::tan
#define pow   precise::pow
#define fmod  precise::fmod
#define atan2 atan2_c99
#define U32_QUO(a, b) \
  ((a) / 2 / (b) * 2 + ((a) - (a) / 2 / (b) * 2 * (b) >= (b)))
#else
#define U32_QUO(a, b) ((a) / (b))
#endif

#define U32_BIN(a, o, b) ((u64)((u32)(a) o (u32)(b)))

INLINE f32 f32_unbox(u64 x) {
  union { u32 u; f32 f; } p = { (u32)x };
  return p.f;
}

INLINE u64 f32_rewrap(f32 x) {
  union { f32 f; u32 u; } p = { x };
  return p.u;
}

INLINE u64 f32_to_u32(u64 a) {
  f32 v = f32_unbox(a);
  return v >= 0.0f && v < 4294967296.0f ? (u32)v : 0;
}

INLINE u64 nat_chk(Env e, u64 n) {
  if (n > NAT_IMM) {
    err_post(e.mem, ERR_NATS);
    return NAT_IMM;
  }
  return n;
}

INLINE u64 nat_mul(Env e, u64 a, u64 b) {
  return nat_chk(e, b != 0 && a > NAT_IMM / b ? NAT_IMM + 1 : a * b);
}

#if DEVICE

#define f32_show(e, x) (err_post(e.mem, ERR_FIDS), 0)
#define f32_read(e, s) (err_post(e.mem, ERR_FIDS), 0)

#else

static Term f32_show(Env e, Term x);
static Term f32_read(Env e, Term s);

#endif

A32_LOOP(fadd, f32_rewrap(f32_unbox(o) + f32_unbox(v)))

// Bank
// ====

// A stack of exact generations per class. The host pops and pushes at rd;
// a device pass pops below rd and pushes above top, compacted after it.

#define bank_at(H, c) ((DEV Bank*)((H) + H_BANK) + (c))

INLINE u64 bank_pop(DEV u64* H, u32 c) {
  DEV Bank* b = bank_at(H, c);
  u64 got = 0;
  LOCK(bank_lock);
  u32 t = a32_sub(&b->rd, 1);
  if ((int)t > 0) {
    got = H[b->off + t - 1];
  } else {
    a32_add(&b->rd, 1);
  }
  if (!DEVICE) {
    b->wr = b->top = b->rd;
  }
  UNLOCK(bank_lock);
  return got;
}

INLINE void bank_push(DEV u64* H, u32 c, u64 head) {
  DEV Bank* b = bank_at(H, c);
  LOCK(bank_lock);
  H[b->off + a32_add(&b->wr, 1)] = head;
  if (!DEVICE) {
    b->rd = b->top = b->wr;
  }
  UNLOCK(bank_lock);
}

// Heap
// ====

// Per lane and class: HOT, a LIFO free chain; LEN, its length in words;
// on the host COLD, one parked generation. A host free reaching KEEP_WORDS
// parks HOT as COLD and banks the old COLD. A miss takes COLD, a bank entry
// or a fresh quantum. A device lane banks its complete generations at the
// kernel end (dev_cut). The bump grows only when all of these are empty.

#define ALC_AT(e, i)   (e).alc[(i) * LANE_STEP]
#define ALC_LEN(e, c)  ALC_AT(e, NCLS_ALL + (c))
#define ALC_COLD(e, c) ALC_AT(e, 2 * NCLS_ALL + (c))
#define KEEP(c)        (KEEP_WORDS >> (c) ? KEEP_WORDS >> (c) : 1)

INLINE u32 cls_fit(u32 words) {
  return words > 1 ? 32 - CLZ(words - 1) : 0;
}

OUTLINE void heap_hand(Env e, u32 cls) {
  u64 cold = ALC_COLD(e, cls);
  if (cold) {
    bank_push(e.mem, cls, cold);
  }
  ALC_COLD(e, cls) = ALC_AT(e, cls);
  ALC_AT(e, cls)   = 0;
  ALC_LEN(e, cls)  = 0;
}

#if DEVICE
#define corpus_grow(H, n) false
#else
static bool corpus_grow(u64* H, u64 need);
#endif

OUTLINE u64 heap_alloc_miss(Env e, u32 cls) {
  DEV u64* H = e.mem;
  u64  got = 0;
  if (!DEVICE) {
    got = ALC_COLD(e, cls);
    ALC_COLD(e, cls) = 0;
  }
  if (!got) {
    got = bank_pop(H, cls);
  }
  u32 n = got ? KEEP(cls) : cls < NCLS ? QUANTUM >> cls : 1;
  if (!got) {
    u32 pages = (n << cls) >> PAGE_BITS;
    u32 p     = a32_add(a32_at(H, H_BUMP), pages);
    if ((u64)p + pages > a32_load_acq(a32_at(H, H_CAP))
      && !corpus_grow(H, (u64)p + pages)) {
      err_post(H, ERR_HEAP);
      return HEAP_OFF;
    }
    got = HEAP_OFF + ((u64)p << PAGE_BITS);
    for (u32 i = 1; i <= n; i += 1) {
      H[got + ((u64)(i - 1) << cls)] = i < n ? got + ((u64)i << cls) : 0;
    }
  }
  ALC_AT(e, cls)  = H[got];
  ALC_LEN(e, cls) = (u64)(n - 1) << cls;
  return got;
}

INLINE u64 heap_alloc(Env e, u32 cls) {
  u64 h = ALC_AT(e, cls);
  if (h) {
    ALC_AT(e, cls)   = e.mem[h];
    ALC_LEN(e, cls) -= 1ull << cls;
    return h;
  }
  return heap_alloc_miss(e, cls);
}

INLINE void heap_free(Env e, u32 cls, u64 loc) {
  if (err_seen(e.mem)) {
    return;
  }
  e.mem[loc]       = ALC_AT(e, cls);
  ALC_AT(e, cls)   = loc;
  ALC_LEN(e, cls) += 1ull << cls;
  if (!DEVICE && ALC_LEN(e, cls) >= KEEP_WORDS) {
    heap_hand(e, cls);
  }
}

INLINE void spare_free(Env e, u32 cls, u64 loc) {
  if (loc >= HEAP_OFF) {
    heap_free(e, cls, loc);
  }
}

// Term
// ====

#define term_make(tag, aux, loc) \
  (((u64)(tag) << 56) | ((u64)(aux) << 40) | (u64)(loc))

#define term_ctr(cid, loc) term_make(TAG_CTR, cid, loc)
#define term_pak(cid, loc) term_make(TAG_PAK, cid, loc)
#define term_clo(fid, loc) term_make(TAG_CLO, fid, loc)
#define term_buf(cls, loc) term_make(TAG_BUF, cls, loc)
#define term_tsk(fid, loc) term_make(TAG_TSK, fid, loc)

INLINE Term term_blk(bool arr, u32 cls, u64 loc) {
  return term_buf(cls, loc) | ((u64)arr << 57);
}

INLINE u64 term_tag(Term t) {
  return (t >> 56) & 0x7f;
}

INLINE bool term_rfc(Term t) {
  return (t & RFC_BIT) != 0;
}

INLINE u64 term_aux(Term t) {
  return (t >> 40) & 0xFFFF;
}

INLINE u64 term_loc(Term t) {
  return t & LOC_MASK;
}

INLINE bool term_triv(Term t) {
  return term_tag(t) <= TAG_PAK || t == TERM_HOLE || term_loc(t) < HEAP_OFF;
}

OUTLINE Term rfc_wrap(Env e, Term t, u32 cnt) {
  if (term_tag(t) == TAG_CLO || term_tag(t) == TAG_TSK) {
    err_post(e.mem, ERR_RFCS);
    return t;
  }
  u64 r = heap_alloc(e, 0);
  e.mem[r] = ((u64)term_loc(t) << 24) | cnt;
  return (t & ~LOC_MASK) | RFC_BIT | r;
}

INLINE Term rfc_seal(Env e, Term t) {
  if (term_tag(t) != TAG_CTR || term_rfc(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1);
}

// A redirect cell holds its target's loc over a 24-bit count, which
// changes by atomic adds on the low half, so a host never reads it as one
// plain word.
INLINE u64 rfc_view(DEV u64* H, u64 r) {
  DEV u32* w = a32_at(H, r);
  u64 cell = ((u64)a32_load(w + 1) << 32) | a32_load(w);
  if ((cell & RFC_CNT) == 1) {
    a32_acq(w);
  }
  return cell;
}

INLINE void rfc_bump(Env e, u64 r, u32 k) {
  u32 c = a32_add(a32_at(e.mem, r), k);
  if ((c & RFC_CNT) >= RFC_CNT - k) {
    err_post(e.mem, ERR_RFCS);
  }
}

INLINE Term term_keep(Env e, Term t, u32 k) {
  if (term_rfc(t)) {
    rfc_bump(e, term_loc(t), k);
    return t;
  }
  if (term_triv(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1 + k);
}

INLINE u64 term_peek(DEV u64* H, Term t) {
  if (term_rfc(t)) {
    return rfc_view(H, term_loc(t)) >> 24;
  }
  return term_loc(t);
}

#define blk_shr(t) (BLK_SHR && term_rfc(t))

INLINE u64 blk_loc(DEV u64* H, Term a) {
  return blk_shr(a) ? w64_load(&H[term_loc(a)]) >> 24 : term_loc(a);
}

INLINE u32 blk_cls(Term t) {
  return (u32)term_aux(t) & 31;
}

#define buf_wcls(c) ((c) == 0 ? 0 : (c) - 1)

INLINE u32 blk_span(Term t) {
  u32 c = blk_cls(t);
  return term_tag(t) == TAG_ARR ? c : buf_wcls(c);
}

FAR void term_drop(Env e, Term t) {
  DEV u64* H = e.mem;
  u64  cur = 0;
  Term c0  = 0;
  u32  step = 0;
  for (;;) {
    if (!term_triv(t) && term_rfc(t)) {
      u64      r = term_loc(t);
      DEV u32* p = a32_at(H, r);
      if ((a32_sub_rel(p, 1) & RFC_CNT) != 1) {
        t = 0;
      } else {
        a32_acq(p);
        t = (t & ~(RFC_BIT | LOC_MASK)) | (H[r] >> 24);
        heap_free(e, 0, r);
      }
    }
    if (!term_triv(t)) {
      u64 tag = term_tag(t);
      if (tag == TAG_BUF) {
        heap_free(e, blk_span(t), term_loc(t));
      } else {
        u32 aux = (u32)term_aux(t);
        u64 loc = term_loc(t);
        u32 n   = tag == TAG_ARR ? 0 : tag == TAG_CTR ? cid_arity(aux)
          : fid_arity(aux) - (tag == TAG_CLO);
        u32 cls = tag == TAG_ARR ? 64 | blk_cls(t)
          : n > 247 ? 64 | (n - 240)
          : cls_fit(tag == TAG_TSK ? n + 2 : n);
        c0 = H[loc];
        H[loc] = cur;
        cur = loc | ((u64)n << 48) | ((u64)cls << 56);
      }
    }
    for (;;) {
      if (err_spun(H, &step) || cur == 0) {
        return;
      }
      u64  loc = cur & LOC_MASK;
      u32  i   = (u8)(cur >> 40);
      u32  n   = (u8)(cur >> 48);
      u32  cls = (u32)(cur >> 56);
      bool arr = cls > 63;
      u32  j   = i;
      if (arr) {
        cls &= 63;
        n   = 1u << cls;
        if (i == 2) {
          j = (u32)H[loc + 1];
        }
      }
      if (j < n) {
        Term c = j == 0 ? c0 : H[loc + j];
        if (arr && j > 0) {
          H[loc + 1] = j + 1;
        }
        if (!arr || i < 2) {
          cur += 1ull << 40;
        }
        if (!term_triv(c)) {
          t = c;
          break;
        }
      } else {
        u64 up = H[loc];
        heap_free(e, cls, loc);
        cur = up;
      }
    }
  }
}

INLINE void term_sink(Env e, Term t) {
  if (!term_triv(t)) {
    term_drop(e, t);
  }
}

OUTLINE void span_fade(Env e, Term t, u64 src, u32 n) {
  for (u32 j = 0; j < n; j += 1) {
    Term f = e.mem[src + j];
    if (term_rfc(f)) {
      rfc_bump(e, term_loc(f), 1);
    } else if (!term_triv(f)) {
      err_post(e.mem, ERR_RFCS);
    }
  }
  term_drop(e, t);
}

INLINE u64 ctr_take(Env e, Term t, u32 n, THR Term* out) {
  DEV u64* H = e.mem;
  if (!term_rfc(t)) {
    for (u32 j = 0; j < n; j += 1) {
      out[j] = H[term_loc(t) + j];
    }
    return term_loc(t);
  }
  u64 r    = term_loc(t);
  u64 cell = rfc_view(H, r);
  u64 src  = cell >> 24;
  for (u32 j = 0; j < n; j += 1) {
    out[j] = H[src + j];
  }
  if ((cell & RFC_CNT) == 1) {
    heap_free(e, 0, r);
    return src;
  }
  span_fade(e, t, src, n);
  return 0;
}

INLINE Term term_word(Env e, Term w) {
  u32 x = 0;
  Term t = w;
  for (u32 i = 0; i < 32 && term_aux(t) == CID_WCON; i += 1) {
    u64 l = term_peek(e.mem, t);
    x |= (u32)(e.mem[l] & 1) << i;
    t = e.mem[l + 1];
  }
  term_sink(e, w);
  return x;
}

// Blk
// ===

// A block owns one allocation in its class (an ARR 2^c Terms, a BUF 2^c
// u32). Matching ANode is blk_half twice (the high call frees the source);
// ANode{l, r} is blk_node; Array.clone is blk_copy.

#define BLK_ALLOC(n, w) \
  u64 n = heap_alloc(e, w); \
  if (err_seen(e.mem)) { \
    return term_buf(0, n); \
  }

INLINE DEV u32a* blk_ptr(DEV u64* H, u64 loc, u32 i) {
  return (DEV u32a*)(H + loc) + i;
}

INLINE Term blk_read(DEV u64* H, bool arr, u64 loc, u32 i) {
  if (arr) {
    return H[loc + i];
  }
  return (u64)*blk_ptr(H, loc, i);
}

INLINE void blk_write(DEV u64* H, bool arr, u64 loc, u32 i, Term v) {
  if (arr) {
    H[loc + i] = v;
  } else {
    *blk_ptr(H, loc, i) = (u32)v;
  }
}

INLINE u32 blk_at(Term a, u64 i, u32 lgs) {
  return ((u32)i & (u32)((1ull << (blk_cls(a) - lgs)) - 1)) << lgs;
}

INLINE Term blk_keep(Env e, u64 at) {
  Term w = e.mem[at];
  Term v = term_keep(e, w, 1);
  if (v != w) {
    e.mem[at] = v;
  }
  return v;
}

INLINE void blk_fill(Env e, u64 dst, u64 src, u64 n, bool keep) {
  for (u64 j = 0; j < n; j += 1) {
    e.mem[dst + j] = keep ? blk_keep(e, src + j) : e.mem[src + j];
  }
}

INLINE void blk_free(Env e, Term t) {
  blk_shr(t) ? term_drop(e, t) : heap_free(e, blk_span(t), term_loc(t));
}

OUTLINE Term blk_copy(Env e, Term a) {
  bool arr = term_tag(a) == TAG_ARR;
  u32 cls = blk_span(a);
  BLK_ALLOC(dst, cls)
  blk_fill(e, dst, blk_loc(e.mem, a), 1ull << cls, arr);
  return term_blk(arr, blk_cls(a), dst);
}

INLINE Term blk_node(Env e, Term l, Term r) {
  DEV u64* H = e.mem;
  bool arr = term_tag(l) == TAG_ARR;
  u32 c = blk_cls(l);
  if (c != blk_cls(r) || c + 1 >= NCLS_ALL) {
    err_post(H, ERR_TAGS);
    return l;
  }
  u64 pl = blk_loc(H, l);
  u64 pr = blk_loc(H, r);
  BLK_ALLOC(n, arr ? c + 1 : c)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, pl, 0) | ((u64)*blk_ptr(H, pr, 0) << 32);
  } else {
    u64 cw = 1ull << blk_span(l);
    blk_fill(e, n, pl, cw, arr && blk_shr(l));
    blk_fill(e, n + cw, pr, cw, arr && blk_shr(r));
  }
  blk_free(e, l);
  blk_free(e, r);
  return term_blk(arr, c + 1, n);
}

INLINE Term blk_half(Env e, Term a, u32 hi) {
  DEV u64* H = e.mem;
  bool arr = term_tag(a) == TAG_ARR;
  u32 c = blk_cls(a);
  if (c == 0) {
    err_post(H, ERR_TAGS);
    return a;
  }
  c -= 1;
  u32 cw = arr ? c : buf_wcls(c);
  u64 src = blk_loc(H, a);
  BLK_ALLOC(n, cw)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, src, hi);
  } else {
    blk_fill(e, n, src + ((u64)hi << cw), 1ull << cw, arr && blk_shr(a));
  }
  if (hi) {
    blk_free(e, a);
  }
  return term_blk(arr, c, n);
}

INLINE Term blk_new(Env e, bool arr, u64 d, u32 lgs, u32 n, THR Term* v) {
  DEV u64* H = e.mem;
  if (d + lgs > 31) {
    err_post(H, ERR_ARRS);
    d = 0;
  }
  u32 c = (u32)d + lgs;
  BLK_ALLOC(l, arr ? c : buf_wcls(c))
  for (u32 j = 0; arr && d > 0 && j < n; j += 1) {
    if (d >= 24 && !term_triv(v[j])) {
      err_post(H, ERR_RFCS);
    }
    v[j] = term_keep(e, v[j], (1u << d) - 1);
  }
  for (u64 i = 0; i < (1ull << c); i += 1) {
    blk_write(H, arr, l, (u32)i, i % (1u << lgs) < n ? v[i % (1u << lgs)] : 0);
  }
  return term_blk(arr, c, l);
}

// Ring
// ====

#define ring_word(H, r, w) ((H) + RING_OFF + (w) * LANES + (r))
#define ring_slot(H, r, p) ring_word(H, r, (p) & (RING_LEN - 1))
#define ring_get(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN))
#define ring_put(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN + 1))

INLINE u32 ring_lap(u32 pos) {
  return ~(u32)(pos / RING_LEN) & 1;
}

INLINE void ring_push(DEV u64* H, u32 r, Term tsk) {
  u32 pos = a32_add(ring_put(H, r), 1);
  if (pos - a32_load(ring_get(H, r)) >= RING_LEN) {
    err_post(H, ERR_RING);
    return;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, r, pos);
  a32_store(lo, (u32)tsk);
  a32_store_rel(lo + 1, (u32)(tsk >> 32) | (ring_lap(pos) << 31));
}

INLINE u32 ring_flip(u32 i) {
  return (i % CUBE_T << CUBE_LOG) + i / CUBE_T;
}

#define ring_pick(b, s, c) ((b) + (s) * (a32_add(c, 1) & (CUBE_T - 1)))

// Task
// ====

INLINE u64 task_node(Env e, u32 fid, Term cont, u32 idx, u32 rem) {
  u32 ar  = fid_arity(fid);
  u64 loc = heap_alloc(e, cls_fit(ar + 2));
  for (u32 i = 0; rem && i < ar; i += 1) {
    e.mem[loc + i] = TERM_HOLE;
  }
  e.mem[loc + ar]     = cont;
  e.mem[loc + ar + 1] = ((u64)idx << 32) | rem;
  return loc;
}

INLINE u64 task_tail(Term t) {
  return term_loc(t) + fid_arity((u32)term_aux(t));
}

INLINE Term task_deliver(DEV u64* H, Term cont, u32 idx, THR Term* v, u32 n) {
  u64 at = cont == TERM_HOLE ? H_ROOT_WORD : term_loc(cont) + idx;
  for (u32 j = 0; j < WL_RESW; j += 1) {
    if (j < n) {
      H[at + j] = v[j];
    }
  }
  if (cont == TERM_HOLE) {
    a32_store_rel(a32_at(H, H_ROOT_DONE), n + 1);
    return 0;
  }
  u64 tl = task_tail(cont);
  if (a32_sub_rel(a32_at(H, tl + 1), 1) == 1) {
    a32_acq(a32_at(H, tl + 1));
    return cont;
  }
  return 0;
}

INLINE void task_deal(DEV u64* H, Term join, u32 base, u32 stride, TG u32* cur) {
  u64 loc = term_loc(join);
  u32 ar  = fid_arity((u32)term_aux(join));
  u32 g   = 0;
  if (stride == 0) {
    u32 rem = (u32)H[loc + ar + 1];
    g = a32_add(a32_at(H, H_CURSOR), rem);
  }
  for (u32 i = 0; i < ar; i += 1) {
    Term k = H[loc + i];
    if (term_tag(k) == TAG_TSK) {
      H[loc + i] = TERM_HOLE;
      u32 to;
      if (stride != 0) {
        to = ring_pick(base, stride, cur);
      } else {
        to = ring_flip(g & (u32)(LANES - 1));
        g += 1;
      }
      ring_push(H, to, k);
    }
  }
}

// Root
// ====

INLINE bool root_done(DEV u64* H) {
  return a32_load_acq(a32_at(H, H_ROOT_DONE)) != 0;
}

static u32 root_take(DEV u64* H, THR Term* v) {
  u32 n = a32_load_acq(a32_at(H, H_ROOT_DONE)) - 1;
  for (u32 j = 0; j < n; j += 1) {
    v[j] = H[H_ROOT_WORD + j];
  }
  a32_store(a32_at(H, H_ROOT_DONE), 0);
  return n;
}

// Spins
// =====

CONSTV u64 STAT_IMG[] = { 119ull, term_pak(CID_SNIL, 0), 111ull, term_ctr(CID_SCON, STAT_OFF + 0), 108ull, term_ctr(CID_SCON, STAT_OFF + 2), 70ull, term_ctr(CID_SCON, STAT_OFF + 4), 107ull, term_pak(CID_SNIL, 0), 99ull, term_ctr(CID_SCON, STAT_OFF + 8), 97ull, term_ctr(CID_SCON, STAT_OFF + 10), 98ull, term_ctr(CID_SCON, STAT_OFF + 12), 108ull, term_ctr(CID_SCON, STAT_OFF + 14), 108ull, term_ctr(CID_SCON, STAT_OFF + 16), 111ull, term_ctr(CID_SCON, STAT_OFF + 18), 114ull, term_ctr(CID_SCON, STAT_OFF + 20), 116ull, term_pak(CID_SNIL, 0), 111ull, term_ctr(CID_SCON, STAT_OFF + 24), 111ull, term_ctr(CID_SCON, STAT_OFF + 26), 66ull, term_ctr(CID_SCON, STAT_OFF + 28), 121ull, term_pak(CID_SNIL, 0), 97ull, term_ctr(CID_SCON, STAT_OFF + 32), 108ull, term_ctr(CID_SCON, STAT_OFF + 34), 80ull, term_ctr(CID_SCON, STAT_OFF + 36), 101ull, term_pak(CID_SNIL, 0), 115ull, term_ctr(CID_SCON, STAT_OFF + 40), 117ull, term_ctr(CID_SCON, STAT_OFF + 42), 97ull, term_ctr(CID_SCON, STAT_OFF + 44), 80ull, term_ctr(CID_SCON, STAT_OFF + 46), 41ull, term_pak(CID_SNIL, 0), 44ull, term_pak(CID_SNIL, 0), 40ull, term_pak(CID_SNIL, 0), 78ull, term_ctr(CID_SCON, STAT_OFF + 54), 108ull, term_ctr(CID_SCON, STAT_OFF + 42), 97ull, term_ctr(CID_SCON, STAT_OFF + 58), 70ull, term_ctr(CID_SCON, STAT_OFF + 60), 117ull, term_ctr(CID_SCON, STAT_OFF + 40), 114ull, term_ctr(CID_SCON, STAT_OFF + 64), 84ull, term_ctr(CID_SCON, STAT_OFF + 66), 93ull, term_pak(CID_SNIL, 0), 32ull, term_pak(CID_SNIL, 0), 44ull, term_ctr(CID_SCON, STAT_OFF + 72), 58ull, term_pak(CID_SNIL, 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 40), 111ull, term_ctr(CID_SCON, STAT_OFF + 78), 110ull, term_ctr(CID_SCON, STAT_OFF + 80), 61ull, term_pak(CID_SNIL, 0), 112ull, term_ctr(CID_SCON, STAT_OFF + 84), 105ull, term_ctr(CID_SCON, STAT_OFF + 86), 107ull, term_ctr(CID_SCON, STAT_OFF + 88), 115ull, term_ctr(CID_SCON, STAT_OFF + 90), 58ull, term_ctr(CID_SCON, STAT_OFF + 92), 76ull, term_ctr(CID_SCON, STAT_OFF + 54), 91ull, term_ctr(CID_SCON, STAT_OFF + 70), 91ull, term_pak(CID_SNIL, 0), 103ull, term_pak(CID_SNIL, 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 102), 105ull, term_ctr(CID_SCON, STAT_OFF + 104), 115ull, term_ctr(CID_SCON, STAT_OFF + 106), 115ull, term_ctr(CID_SCON, STAT_OFF + 108), 105ull, term_ctr(CID_SCON, STAT_OFF + 110), 109ull, term_ctr(CID_SCON, STAT_OFF + 112), 100ull, term_ctr(CID_SCON, STAT_OFF + 84), 101ull, term_ctr(CID_SCON, STAT_OFF + 116), 103ull, term_ctr(CID_SCON, STAT_OFF + 118), 110ull, term_ctr(CID_SCON, STAT_OFF + 120), 97ull, term_ctr(CID_SCON, STAT_OFF + 122), 104ull, term_ctr(CID_SCON, STAT_OFF + 124), 99ull, term_ctr(CID_SCON, STAT_OFF + 126), 47ull, term_ctr(CID_SCON, STAT_OFF + 128), 115ull, term_ctr(CID_SCON, STAT_OFF + 84), 117ull, term_ctr(CID_SCON, STAT_OFF + 132), 111ull, term_ctr(CID_SCON, STAT_OFF + 134), 105ull, term_ctr(CID_SCON, STAT_OFF + 136), 118ull, term_ctr(CID_SCON, STAT_OFF + 138), 101ull, term_ctr(CID_SCON, STAT_OFF + 140), 114ull, term_ctr(CID_SCON, STAT_OFF + 142), 112ull, term_ctr(CID_SCON, STAT_OFF + 144), 47ull, term_ctr(CID_SCON, STAT_OFF + 146), 47ull, term_pak(CID_SNIL, 0), 48ull, term_pak(CID_SNIL, 0), 111ull, term_ctr(CID_SCON, STAT_OFF + 8), 107ull, term_ctr(CID_SCON, STAT_OFF + 84), 99ull, term_ctr(CID_SCON, STAT_OFF + 156), 111ull, term_ctr(CID_SCON, STAT_OFF + 158), 108ull, term_ctr(CID_SCON, STAT_OFF + 160), 99ull, term_ctr(CID_SCON, STAT_OFF + 162), 47ull, term_ctr(CID_SCON, STAT_OFF + 164), 109ull, term_ctr(CID_SCON, STAT_OFF + 84), 101ull, term_ctr(CID_SCON, STAT_OFF + 168), 116ull, term_ctr(CID_SCON, STAT_OFF + 170), 115ull, term_ctr(CID_SCON, STAT_OFF + 172), 121ull, term_ctr(CID_SCON, STAT_OFF + 174), 83ull, term_ctr(CID_SCON, STAT_OFF + 176), 116ull, term_ctr(CID_SCON, STAT_OFF + 178), 120ull, term_ctr(CID_SCON, STAT_OFF + 180), 101ull, term_ctr(CID_SCON, STAT_OFF + 182), 110ull, term_ctr(CID_SCON, STAT_OFF + 184), 47ull, term_ctr(CID_SCON, STAT_OFF + 186), 110ull, term_ctr(CID_SCON, STAT_OFF + 132), 111ull, term_ctr(CID_SCON, STAT_OFF + 190), 105ull, term_ctr(CID_SCON, STAT_OFF + 192), 116ull, term_ctr(CID_SCON, STAT_OFF + 194), 97ull, term_ctr(CID_SCON, STAT_OFF + 196), 114ull, term_ctr(CID_SCON, STAT_OFF + 198), 116ull, term_ctr(CID_SCON, STAT_OFF + 200), 115ull, term_ctr(CID_SCON, STAT_OFF + 202), 105ull, term_ctr(CID_SCON, STAT_OFF + 204), 103ull, term_ctr(CID_SCON, STAT_OFF + 206), 101ull, term_ctr(CID_SCON, STAT_OFF + 208), 114ull, term_ctr(CID_SCON, STAT_OFF + 210), 47ull, term_ctr(CID_SCON, STAT_OFF + 212), 103ull, term_ctr(CID_SCON, STAT_OFF + 84), 110ull, term_ctr(CID_SCON, STAT_OFF + 216), 105ull, term_ctr(CID_SCON, STAT_OFF + 218), 100ull, term_ctr(CID_SCON, STAT_OFF + 220), 110ull, term_ctr(CID_SCON, STAT_OFF + 222), 101ull, term_ctr(CID_SCON, STAT_OFF + 224), 112ull, term_ctr(CID_SCON, STAT_OFF + 226), 47ull, term_ctr(CID_SCON, STAT_OFF + 228), 116ull, term_ctr(CID_SCON, STAT_OFF + 132), 110ull, term_ctr(CID_SCON, STAT_OFF + 232), 101ull, term_ctr(CID_SCON, STAT_OFF + 234), 118ull, term_ctr(CID_SCON, STAT_OFF + 236), 101ull, term_ctr(CID_SCON, STAT_OFF + 238), 47ull, term_ctr(CID_SCON, STAT_OFF + 240), 116ull, term_ctr(CID_SCON, STAT_OFF + 84), 111ull, term_ctr(CID_SCON, STAT_OFF + 244), 108ull, term_ctr(CID_SCON, STAT_OFF + 246), 115ull, term_ctr(CID_SCON, STAT_OFF + 248), 47ull, term_ctr(CID_SCON, STAT_OFF + 250), 101ull, term_ctr(CID_SCON, STAT_OFF + 84), 99ull, term_ctr(CID_SCON, STAT_OFF + 254), 114ull, term_ctr(CID_SCON, STAT_OFF + 256), 117ull, term_ctr(CID_SCON, STAT_OFF + 258), 111ull, term_ctr(CID_SCON, STAT_OFF + 260), 115ull, term_ctr(CID_SCON, STAT_OFF + 262), 101ull, term_ctr(CID_SCON, STAT_OFF + 264), 114ull, term_ctr(CID_SCON, STAT_OFF + 266), 47ull, term_ctr(CID_SCON, STAT_OFF + 268), 110ull, term_ctr(CID_SCON, STAT_OFF + 236), 111ull, term_ctr(CID_SCON, STAT_OFF + 272), 112ull, term_ctr(CID_SCON, STAT_OFF + 274), 109ull, term_ctr(CID_SCON, STAT_OFF + 276), 111ull, term_ctr(CID_SCON, STAT_OFF + 278), 99ull, term_ctr(CID_SCON, STAT_OFF + 280), 47ull, term_ctr(CID_SCON, STAT_OFF + 282), 118ull, term_ctr(CID_SCON, STAT_OFF + 254), 105ull, term_ctr(CID_SCON, STAT_OFF + 286), 108ull, term_ctr(CID_SCON, STAT_OFF + 288), 47ull, term_ctr(CID_SCON, STAT_OFF + 290), 104ull, term_ctr(CID_SCON, STAT_OFF + 84), 116ull, term_ctr(CID_SCON, STAT_OFF + 294), 112ull, term_ctr(CID_SCON, STAT_OFF + 296), 101ull, term_ctr(CID_SCON, STAT_OFF + 298), 100ull, term_ctr(CID_SCON, STAT_OFF + 300), 47ull, term_ctr(CID_SCON, STAT_OFF + 302), 121ull, term_ctr(CID_SCON, STAT_OFF + 84), 116ull, term_ctr(CID_SCON, STAT_OFF + 306), 105ull, term_ctr(CID_SCON, STAT_OFF + 308), 99ull, term_ctr(CID_SCON, STAT_OFF + 310), 97ull, term_ctr(CID_SCON, STAT_OFF + 312), 112ull, term_ctr(CID_SCON, STAT_OFF + 314), 97ull, term_ctr(CID_SCON, STAT_OFF + 316), 99ull, term_ctr(CID_SCON, STAT_OFF + 318), 47ull, term_ctr(CID_SCON, STAT_OFF + 320), 103ull, term_ctr(CID_SCON, STAT_OFF + 294), 105ull, term_ctr(CID_SCON, STAT_OFF + 324), 104ull, term_ctr(CID_SCON, STAT_OFF + 326), 47ull, term_ctr(CID_SCON, STAT_OFF + 328), 120ull, term_ctr(CID_SCON, STAT_OFF + 244), 101ull, term_ctr(CID_SCON, STAT_OFF + 332), 110ull, term_ctr(CID_SCON, STAT_OFF + 334), 47ull, term_ctr(CID_SCON, STAT_OFF + 336), 100ull, term_pak(CID_SNIL, 0), 101ull, term_ctr(CID_SCON, STAT_OFF + 340), 116ull, term_ctr(CID_SCON, STAT_OFF + 342), 99ull, term_ctr(CID_SCON, STAT_OFF + 344), 101ull, term_ctr(CID_SCON, STAT_OFF + 346), 106ull, term_ctr(CID_SCON, STAT_OFF + 348), 101ull, term_ctr(CID_SCON, STAT_OFF + 350), 114ull, term_ctr(CID_SCON, STAT_OFF + 352), 45ull, term_ctr(CID_SCON, STAT_OFF + 354), 110ull, term_ctr(CID_SCON, STAT_OFF + 356), 111ull, term_ctr(CID_SCON, STAT_OFF + 358), 105ull, term_ctr(CID_SCON, STAT_OFF + 360), 116ull, term_ctr(CID_SCON, STAT_OFF + 362), 97ull, term_ctr(CID_SCON, STAT_OFF + 364), 114ull, term_ctr(CID_SCON, STAT_OFF + 366), 116ull, term_ctr(CID_SCON, STAT_OFF + 368), 115ull, term_ctr(CID_SCON, STAT_OFF + 370), 105ull, term_ctr(CID_SCON, STAT_OFF + 372), 103ull, term_ctr(CID_SCON, STAT_OFF + 374), 101ull, term_ctr(CID_SCON, STAT_OFF + 376), 114ull, term_ctr(CID_SCON, STAT_OFF + 378), 116ull, term_ctr(CID_SCON, STAT_OFF + 134), 97ull, term_ctr(CID_SCON, STAT_OFF + 382), 116ull, term_ctr(CID_SCON, STAT_OFF + 384), 115ull, term_ctr(CID_SCON, STAT_OFF + 386), 47ull, term_ctr(CID_SCON, STAT_OFF + 388), 101ull, term_ctr(CID_SCON, STAT_OFF + 390), 110ull, term_ctr(CID_SCON, STAT_OFF + 392), 111ull, term_ctr(CID_SCON, STAT_OFF + 394), 110ull, term_ctr(CID_SCON, STAT_OFF + 396), 61ull, term_ctr(CID_SCON, STAT_OFF + 398), 121ull, term_ctr(CID_SCON, STAT_OFF + 400), 114ull, term_ctr(CID_SCON, STAT_OFF + 402), 116ull, term_ctr(CID_SCON, STAT_OFF + 404), 115ull, term_ctr(CID_SCON, STAT_OFF + 406), 105ull, term_ctr(CID_SCON, STAT_OFF + 408), 103ull, term_ctr(CID_SCON, STAT_OFF + 410), 101ull, term_ctr(CID_SCON, STAT_OFF + 412), 114ull, term_ctr(CID_SCON, STAT_OFF + 414), 47ull, term_ctr(CID_SCON, STAT_OFF + 416), 114ull, term_ctr(CID_SCON, STAT_OFF + 84), 111ull, term_ctr(CID_SCON, STAT_OFF + 420), 115ull, term_ctr(CID_SCON, STAT_OFF + 422), 114ull, term_ctr(CID_SCON, STAT_OFF + 424), 117ull, term_ctr(CID_SCON, STAT_OFF + 426), 99ull, term_ctr(CID_SCON, STAT_OFF + 428), 58ull, term_ctr(CID_SCON, STAT_OFF + 430), 114ull, term_ctr(CID_SCON, STAT_OFF + 306), 116ull, term_ctr(CID_SCON, STAT_OFF + 434), 115ull, term_ctr(CID_SCON, STAT_OFF + 436), 105ull, term_ctr(CID_SCON, STAT_OFF + 438), 103ull, term_ctr(CID_SCON, STAT_OFF + 440), 101ull, term_ctr(CID_SCON, STAT_OFF + 442), 114ull, term_ctr(CID_SCON, STAT_OFF + 444), 47ull, term_ctr(CID_SCON, STAT_OFF + 446), 101ull, term_ctr(CID_SCON, STAT_OFF + 342), 115ull, term_ctr(CID_SCON, STAT_OFF + 450), term_ctr(CID_SCON, STAT_OFF + 452), term_pak(CID_NIL, 0), 115ull, term_ctr(CID_SCON, STAT_OFF + 342), 117ull, term_ctr(CID_SCON, STAT_OFF + 456), 102ull, term_ctr(CID_SCON, STAT_OFF + 458), 101ull, term_ctr(CID_SCON, STAT_OFF + 460), 114ull, term_ctr(CID_SCON, STAT_OFF + 462), 45ull, term_ctr(CID_SCON, STAT_OFF + 464), 110ull, term_ctr(CID_SCON, STAT_OFF + 466), 111ull, term_ctr(CID_SCON, STAT_OFF + 468), 105ull, term_ctr(CID_SCON, STAT_OFF + 470), 116ull, term_ctr(CID_SCON, STAT_OFF + 472), 97ull, term_ctr(CID_SCON, STAT_OFF + 474), 114ull, term_ctr(CID_SCON, STAT_OFF + 476), 116ull, term_ctr(CID_SCON, STAT_OFF + 478), 115ull, term_ctr(CID_SCON, STAT_OFF + 480), 105ull, term_ctr(CID_SCON, STAT_OFF + 482), 103ull, term_ctr(CID_SCON, STAT_OFF + 484), 101ull, term_ctr(CID_SCON, STAT_OFF + 486), 114ull, term_ctr(CID_SCON, STAT_OFF + 488), 10ull, term_pak(CID_SNIL, 0), 114ull, term_pak(CID_SNIL, 0), 101ull, term_ctr(CID_SCON, STAT_OFF + 494), 104ull, term_ctr(CID_SCON, STAT_OFF + 496), 115ull, term_ctr(CID_SCON, STAT_OFF + 498), 105ull, term_ctr(CID_SCON, STAT_OFF + 500), 108ull, term_ctr(CID_SCON, STAT_OFF + 502), 98ull, term_ctr(CID_SCON, STAT_OFF + 504), 117ull, term_ctr(CID_SCON, STAT_OFF + 506), 112ull, term_ctr(CID_SCON, STAT_OFF + 508), 120ull, term_ctr(CID_SCON, STAT_OFF + 24), 101ull, term_ctr(CID_SCON, STAT_OFF + 512), 110ull, term_ctr(CID_SCON, STAT_OFF + 514), 46ull, term_ctr(CID_SCON, STAT_OFF + 516), 119ull, term_ctr(CID_SCON, STAT_OFF + 518), 111ull, term_ctr(CID_SCON, STAT_OFF + 520), 108ull, term_ctr(CID_SCON, STAT_OFF + 522), 70ull, term_ctr(CID_SCON, STAT_OFF + 524), term_ctr(CID_SCON, STAT_OFF + 526), term_pak(CID_NIL, 0), 99ull, term_ctr(CID_SCON, STAT_OFF + 474), 117ull, term_ctr(CID_SCON, STAT_OFF + 530), 114ull, term_ctr(CID_SCON, STAT_OFF + 532), 116ull, term_ctr(CID_SCON, STAT_OFF + 534), 115ull, term_ctr(CID_SCON, STAT_OFF + 536), 110ull, term_ctr(CID_SCON, STAT_OFF + 538), 111ull, term_ctr(CID_SCON, STAT_OFF + 540), 99ull, term_ctr(CID_SCON, STAT_OFF + 542), 108ull, term_pak(CID_SNIL, 0), 97ull, term_ctr(CID_SCON, STAT_OFF + 546), 105ull, term_ctr(CID_SCON, STAT_OFF + 548), 116ull, term_ctr(CID_SCON, STAT_OFF + 550), 105ull, term_ctr(CID_SCON, STAT_OFF + 552), 110ull, term_ctr(CID_SCON, STAT_OFF + 554), 105ull, term_ctr(CID_SCON, STAT_OFF + 556), 99ull, term_ctr(CID_SCON, STAT_OFF + 342), 114ull, term_ctr(CID_SCON, STAT_OFF + 560), 111ull, term_ctr(CID_SCON, STAT_OFF + 562), 102ull, term_ctr(CID_SCON, STAT_OFF + 564), term_ctr(CID_SCON, STAT_OFF + 566), 1, 0, 1, 20ull, 0, 0, 117ull, term_ctr(CID_SCON, STAT_OFF + 548), 113ull, term_ctr(CID_SCON, STAT_OFF + 575), 101ull, term_ctr(CID_SCON, STAT_OFF + 577), 45ull, term_ctr(CID_SCON, STAT_OFF + 579), 108ull, term_ctr(CID_SCON, STAT_OFF + 581), 97ull, term_ctr(CID_SCON, STAT_OFF + 583), 110ull, term_ctr(CID_SCON, STAT_OFF + 585), 111ull, term_ctr(CID_SCON, STAT_OFF + 587), 105ull, term_ctr(CID_SCON, STAT_OFF + 589), 116ull, term_ctr(CID_SCON, STAT_OFF + 591), 105ull, term_ctr(CID_SCON, STAT_OFF + 593), 100ull, term_ctr(CID_SCON, STAT_OFF + 595), 110ull, term_ctr(CID_SCON, STAT_OFF + 597), 111ull, term_ctr(CID_SCON, STAT_OFF + 599), 99ull, term_ctr(CID_SCON, STAT_OFF + 601), term_ctr(CID_SCON, STAT_OFF + 603), 1, 0, 1, 21ull, 1, 0, 110ull, term_ctr(CID_SCON, STAT_OFF + 24), 101ull, term_ctr(CID_SCON, STAT_OFF + 612), 114ull, term_ctr(CID_SCON, STAT_OFF + 614), 101ull, term_ctr(CID_SCON, STAT_OFF + 616), 102ull, term_ctr(CID_SCON, STAT_OFF + 618), 102ull, term_ctr(CID_SCON, STAT_OFF + 620), 105ull, term_ctr(CID_SCON, STAT_OFF + 622), 100ull, term_ctr(CID_SCON, STAT_OFF + 624), term_ctr(CID_SCON, STAT_OFF + 626), 1, 0, 2, 30ull, 1, 0, 101ull, term_ctr(CID_SCON, STAT_OFF + 24), 115ull, term_ctr(CID_SCON, STAT_OFF + 635), 101ull, term_ctr(CID_SCON, STAT_OFF + 637), 114ull, term_ctr(CID_SCON, STAT_OFF + 639), term_ctr(CID_SCON, STAT_OFF + 641), 1, 1, 0, 0, 0, 0, 110ull, term_ctr(CID_SCON, STAT_OFF + 548), 111ull, term_ctr(CID_SCON, STAT_OFF + 650), 105ull, term_ctr(CID_SCON, STAT_OFF + 652), 116ull, term_ctr(CID_SCON, STAT_OFF + 654), 105ull, term_ctr(CID_SCON, STAT_OFF + 656), 100ull, term_ctr(CID_SCON, STAT_OFF + 658), 110ull, term_ctr(CID_SCON, STAT_OFF + 660), 111ull, term_ctr(CID_SCON, STAT_OFF + 662), 99ull, term_ctr(CID_SCON, STAT_OFF + 664), term_ctr(CID_SCON, STAT_OFF + 666), 1, 0, 1, 21ull, 1, 0, 100ull, term_ctr(CID_SCON, STAT_OFF + 581), 101ull, term_ctr(CID_SCON, STAT_OFF + 675), 99ull, term_ctr(CID_SCON, STAT_OFF + 677), 114ull, term_ctr(CID_SCON, STAT_OFF + 679), 111ull, term_ctr(CID_SCON, STAT_OFF + 681), 102ull, term_ctr(CID_SCON, STAT_OFF + 683), term_ctr(CID_SCON, STAT_OFF + 685), 1, 0, 1, 20ull, 0, 0, term_ctr(CID_SCON, STAT_OFF + 22), 1, 0, 2, 30ull, 1, 1, 110ull, term_pak(CID_SNIL, 0), 105ull, term_ctr(CID_SCON, STAT_OFF + 701), 97ull, term_ctr(CID_SCON, STAT_OFF + 703), 103ull, term_ctr(CID_SCON, STAT_OFF + 705), 97ull, term_ctr(CID_SCON, STAT_OFF + 707), 45ull, term_ctr(CID_SCON, STAT_OFF + 709), 116ull, term_ctr(CID_SCON, STAT_OFF + 711), 101ull, term_ctr(CID_SCON, STAT_OFF + 713), 115ull, term_ctr(CID_SCON, STAT_OFF + 715), 101ull, term_ctr(CID_SCON, STAT_OFF + 717), 114ull, term_ctr(CID_SCON, STAT_OFF + 719), term_ctr(CID_SCON, STAT_OFF + 721), 1, 1, 0, 0, 0, 0, 114ull, term_ctr(CID_SCON, STAT_OFF + 40), 117ull, term_ctr(CID_SCON, STAT_OFF + 730), 116ull, term_ctr(CID_SCON, STAT_OFF + 732), 120ull, term_ctr(CID_SCON, STAT_OFF + 734), 105ull, term_ctr(CID_SCON, STAT_OFF + 736), 102ull, term_ctr(CID_SCON, STAT_OFF + 738), 45ull, term_ctr(CID_SCON, STAT_OFF + 740), 103ull, term_ctr(CID_SCON, STAT_OFF + 742), 110ull, term_ctr(CID_SCON, STAT_OFF + 744), 105ull, term_ctr(CID_SCON, STAT_OFF + 746), 115ull, term_ctr(CID_SCON, STAT_OFF + 748), 115ull, term_ctr(CID_SCON, STAT_OFF + 750), 105ull, term_ctr(CID_SCON, STAT_OFF + 752), 109ull, term_ctr(CID_SCON, STAT_OFF + 754), term_ctr(CID_SCON, STAT_OFF + 756), 0, 0, 0, 0, 0, 0, 45ull, term_ctr(CID_SCON, STAT_OFF + 637), 103ull, term_ctr(CID_SCON, STAT_OFF + 765), 110ull, term_ctr(CID_SCON, STAT_OFF + 767), 105ull, term_ctr(CID_SCON, STAT_OFF + 769), 115ull, term_ctr(CID_SCON, STAT_OFF + 771), 115ull, term_ctr(CID_SCON, STAT_OFF + 773), 105ull, term_ctr(CID_SCON, STAT_OFF + 775), 109ull, term_ctr(CID_SCON, STAT_OFF + 777), term_ctr(CID_SCON, STAT_OFF + 779), 1, 0, 1, 21ull, 1, 0, 45ull, term_ctr(CID_SCON, STAT_OFF + 641), 103ull, term_ctr(CID_SCON, STAT_OFF + 788), 110ull, term_ctr(CID_SCON, STAT_OFF + 790), 105ull, term_ctr(CID_SCON, STAT_OFF + 792), 115ull, term_ctr(CID_SCON, STAT_OFF + 794), 115ull, term_ctr(CID_SCON, STAT_OFF + 796), 105ull, term_ctr(CID_SCON, STAT_OFF + 798), 109ull, term_ctr(CID_SCON, STAT_OFF + 800), term_ctr(CID_SCON, STAT_OFF + 802), 1, 1, 0, 0, 0, 0, term_ctr(CID_CONSUMER_EXPANDED_STEP, STAT_OFF + 804), term_pak(CID_NIL, 0), term_ctr(CID_CONSUMER_EXPANDED_STEP, STAT_OFF + 781), term_ctr(CID_CON, STAT_OFF + 811), term_ctr(CID_CONSUMER_EXPANDED_STEP, STAT_OFF + 758), term_ctr(CID_CON, STAT_OFF + 813), term_ctr(CID_CONSUMER_EXPANDED_STEP, STAT_OFF + 723), term_ctr(CID_CON, STAT_OFF + 815), term_ctr(CID_CONSUMER_EXPANDED_STEP, STAT_OFF + 694), term_ctr(CID_CON, STAT_OFF + 817), term_ctr(CID_CONSUMER_EXPANDED_STEP, STAT_OFF + 687), term_ctr(CID_CON, STAT_OFF + 819), term_ctr(CID_CONSUMER_EXPANDED_STEP, STAT_OFF + 668), term_ctr(CID_CON, STAT_OFF + 821), term_ctr(CID_CONSUMER_EXPANDED_STEP, STAT_OFF + 643), term_ctr(CID_CON, STAT_OFF + 823), term_ctr(CID_CONSUMER_EXPANDED_STEP, STAT_OFF + 628), term_ctr(CID_CON, STAT_OFF + 825), term_ctr(CID_CONSUMER_EXPANDED_STEP, STAT_OFF + 605), term_ctr(CID_CON, STAT_OFF + 827), term_ctr(CID_CONSUMER_EXPANDED_STEP, STAT_OFF + 568), term_ctr(CID_CON, STAT_OFF + 829) };

INLINE Term spin_0(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_1 = 0;
  u32 _a_2 = r0;
  u32 _b_2 = r1;
  WL_SPIN
    if (_a_2 == 0) {
      if (_b_2 == 0) {
        _v_1 = 1;
      } else {
        _v_1 = 0;
      }
    } else if (_a_2 == 1) {
      if (_b_2 == 1) {
        _v_1 = 1;
      } else {
        _v_1 = 0;
      }
    } else {
      if (_b_2 == 2) {
        _v_1 = 1;
      } else {
        _v_1 = 0;
      }
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_1(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3) {
  u32 wpoll = 0;
  u32 _v_2 = 0;
  u32 _a_0 = r0;
  u32 _a_1 = r1;
  u32 _b_0 = r2;
  u32 _b_1 = r3;
  WL_SPIN
    u32 _v_3 = 0;
    Term _o_0[1];
    if (spin_0(e, _o_0, _a_0, _b_0) == 0) {
      return 0;
    }
    _v_3 = _o_0[0];
    _v_2 = _v_3;
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_2(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4) {
  u32 wpoll = 0;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  u32 _v_10 = 0;
  u32 _v_11 = 0;
  u32 _same_0 = r0;
  u32 _prior_0 = r1;
  u32 _prior_1 = r2;
  u32 _value_2 = r3;
  u32 _value_3 = r4;
  WL_SPIN
    if (_same_0 == 1) {
      _v_8 = 1;
      _v_9 = _prior_0;
      _v_10 = _prior_1;
      _v_11 = 0;
    } else {
      _v_8 = 1;
      _v_9 = _value_2;
      _v_10 = _value_3;
      _v_11 = 1;
    }
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  return 1;
}

INLINE Term spin_3(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5) {
  u32 wpoll = 0;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  u32 _v_10 = 0;
  u32 _v_11 = 0;
  u32 _pending_0 = r0;
  u32 _pending_1 = r1;
  u32 _pending_2 = r2;
  u32 _pending_3 = r3;
  u32 _value_2 = r4;
  u32 _value_3 = r5;
  WL_SPIN
    if (_pending_0 == 1) {
      if (_pending_3 == 0) {
        u32 _v_12 = 0;
        u32 _v_13 = 0;
        Term _o_0[1];
        if (spin_1(e, _o_0, _pending_1, _pending_2, _value_2, _value_3) == 0) {
          return 0;
        }
        _v_13 = _o_0[0];
        _v_12 = _v_13;
        u32 _v_14 = 0;
        u32 _v_15 = 0;
        u32 _v_16 = 0;
        u32 _v_17 = 0;
        Term _o_1[4];
        if (spin_2(e, _o_1, _v_12, _pending_1, _pending_2, _value_2, _value_3) == 0) {
          return 0;
        }
        _v_14 = _o_1[0];
        _v_15 = _o_1[1];
        _v_16 = _o_1[2];
        _v_17 = _o_1[3];
        _v_8 = _v_14;
        _v_9 = _v_15;
        _v_10 = _v_16;
        _v_11 = _v_17;
      } else {
        _v_8 = 1;
        _v_9 = _value_2;
        _v_10 = _value_3;
        _v_11 = 1;
      }
    } else {
      _v_8 = 1;
      _v_9 = _value_2;
      _v_10 = _value_3;
      _v_11 = 1;
    }
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  return 1;
}

INLINE Term spin_4(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, u32 r9, u32 r10, u32 r11) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  u32 _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  u32 _v_60 = 0;
  u32 _v_61 = 0;
  u32 _v_62 = 0;
  u32 _v_63 = 0;
  u32 _v_64 = 0;
  u32 _v_65 = 0;
  u32 _v_66 = 0;
  u32 _v_67 = 0;
  u32 _v_68 = 0;
  Term _resources_0 = r0;
  u32 _resources_1 = r1;
  u32 _resources_2 = r2;
  u32 _resources_3 = r3;
  u32 _resources_4 = r4;
  u32 _resources_5 = r5;
  u32 _resources_6 = r6;
  u32 _resources_7 = r7;
  u32 _resources_8 = r8;
  u32 _resources_9 = r9;
  u32 _resources_10 = r10;
  u32 _resources_11 = r11;
  WL_SPIN
    _v_46 = _resources_0;
    _v_47 = _resources_1;
    _v_48 = _resources_2;
    _v_49 = _resources_3;
    _v_50 = _resources_4;
    _v_51 = _resources_5;
    _v_52 = _resources_6;
    _v_53 = _resources_7;
    _v_54 = _resources_8;
    _v_55 = _resources_9;
    _v_56 = _resources_10;
    _v_57 = _resources_11;
    _v_58 = _resources_1;
    _v_59 = _resources_2;
    _v_60 = _resources_3;
    _v_61 = _resources_4;
    _v_62 = _resources_5;
    _v_63 = _resources_6;
    _v_64 = _resources_7;
    _v_65 = _resources_8;
    _v_66 = _resources_9;
    _v_67 = _resources_10;
    _v_68 = _resources_11;
  break;
  }
  o[0] = _v_46;
  o[1] = _v_47;
  o[2] = _v_48;
  o[3] = _v_49;
  o[4] = _v_50;
  o[5] = _v_51;
  o[6] = _v_52;
  o[7] = _v_53;
  o[8] = _v_54;
  o[9] = _v_55;
  o[10] = _v_56;
  o[11] = _v_57;
  o[12] = _v_58;
  o[13] = _v_59;
  o[14] = _v_60;
  o[15] = _v_61;
  o[16] = _v_62;
  o[17] = _v_63;
  o[18] = _v_64;
  o[19] = _v_65;
  o[20] = _v_66;
  o[21] = _v_67;
  o[22] = _v_68;
  return 1;
}

INLINE Term spin_5(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, u32 r19, u32 r20, u32 r21, u32 r22, u32 r23, u32 r24, u32 r25, u32 r26, u32 r27, u32 r28, u32 r29, Term r30, u64 q30, Term r31, u64 q31, Term r32, u64 q32, u32 r33, u32 r34) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h30 = r30;
  Term h31 = r31;
  Term h32 = r32;
  u32 _v_104 = 0;
  u32 _v_105 = 0;
  u32 _v_106 = 0;
  Term _v_107 = 0;
  u32 _v_108 = 0;
  Term _v_109 = 0;
  Term _v_110 = 0;
  Term _v_111 = 0;
  u32 _v_112 = 0;
  u32 _v_113 = 0;
  u32 _v_114 = 0;
  u32 _v_115 = 0;
  u32 _v_116 = 0;
  u32 _v_117 = 0;
  u32 _v_118 = 0;
  u32 _v_119 = 0;
  u32 _v_120 = 0;
  u32 _v_121 = 0;
  u32 _v_122 = 0;
  Term _v_123 = 0;
  Term _v_124 = 0;
  Term _v_125 = 0;
  u32 _v_126 = 0;
  u32 _v_127 = 0;
  u32 _v_128 = 0;
  u32 _v_129 = 0;
  u32 _v_130 = 0;
  u32 _v_131 = 0;
  u32 _v_132 = 0;
  u32 _v_133 = 0;
  u32 _v_134 = 0;
  u32 _v_135 = 0;
  u32 _v_136 = 0;
  u32 _v_137 = 0;
  u32 _v_138 = 0;
  u32 _ns_0 = r0;
  u32 _next_0 = r1;
  u32 _high_0 = r2;
  Term _live_0 = r3;
  u32 _capacity_0 = r4;
  Term _depth_0 = r5;
  Term _store_0 = r6;
  Term _split_0 = r7;
  u32 _split_1 = r8;
  u32 _split_2 = r9;
  u32 _split_3 = r10;
  u32 _split_4 = r11;
  u32 _split_5 = r12;
  u32 _split_6 = r13;
  u32 _split_7 = r14;
  u32 _split_8 = r15;
  u32 _split_9 = r16;
  u32 _split_10 = r17;
  u32 _split_11 = r18;
  u32 _split_12 = r19;
  u32 _split_13 = r20;
  u32 _split_14 = r21;
  u32 _split_15 = r22;
  u32 _split_16 = r23;
  u32 _split_17 = r24;
  u32 _split_18 = r25;
  u32 _split_19 = r26;
  u32 _split_20 = r27;
  u32 _split_21 = r28;
  u32 _split_22 = r29;
  Term _events_0 = r30;
  Term _commands_0 = r31;
  Term _registrations_0 = r32;
  u32 _nextSystem_0 = r33;
  u32 _clock_0 = r34;
  WL_SPIN
    _v_104 = _ns_0;
    _v_105 = _next_0;
    _v_106 = _high_0;
    _v_107 = _live_0;
    _v_108 = _capacity_0;
    _v_109 = _depth_0;
    _v_110 = _store_0;
    _v_111 = _split_0;
    _v_112 = _split_1;
    _v_113 = _split_2;
    _v_114 = _split_3;
    _v_115 = _split_4;
    _v_116 = _split_5;
    _v_117 = _split_6;
    _v_118 = _split_7;
    _v_119 = _split_8;
    _v_120 = _split_9;
    _v_121 = _split_10;
    _v_122 = _split_11;
    _v_123 = _events_0;
    _v_124 = _commands_0;
    _v_125 = _registrations_0;
    _v_126 = _nextSystem_0;
    _v_127 = _clock_0;
    _v_128 = _split_12;
    _v_129 = _split_13;
    _v_130 = _split_14;
    _v_131 = _split_15;
    _v_132 = _split_16;
    _v_133 = _split_17;
    _v_134 = _split_18;
    _v_135 = _split_19;
    _v_136 = _split_20;
    _v_137 = _split_21;
    _v_138 = _split_22;
  break;
  }
  o[0] = _v_104;
  o[1] = _v_105;
  o[2] = _v_106;
  o[3] = _v_107;
  o[4] = _v_108;
  o[5] = _v_109;
  o[6] = _v_110;
  o[7] = _v_111;
  o[8] = _v_112;
  o[9] = _v_113;
  o[10] = _v_114;
  o[11] = _v_115;
  o[12] = _v_116;
  o[13] = _v_117;
  o[14] = _v_118;
  o[15] = _v_119;
  o[16] = _v_120;
  o[17] = _v_121;
  o[18] = _v_122;
  o[19] = _v_123;
  o[20] = _v_124;
  o[21] = _v_125;
  o[22] = _v_126;
  o[23] = _v_127;
  o[24] = _v_128;
  o[25] = _v_129;
  o[26] = _v_130;
  o[27] = _v_131;
  o[28] = _v_132;
  o[29] = _v_133;
  o[30] = _v_134;
  o[31] = _v_135;
  o[32] = _v_136;
  o[33] = _v_137;
  o[34] = _v_138;
  return 1;
}

INLINE Term spin_6(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13) {
  u32 wpoll = 0;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  u32 _slot_11 = r0;
  u32 _slot_12 = r1;
  u32 _slot_13 = r2;
  u32 _slot_14 = r3;
  u32 _slot_15 = r4;
  u32 _slot_16 = r5;
  u32 _slot_17 = r6;
  u32 _slot_18 = r7;
  u32 _slot_19 = r8;
  u32 _slot_20 = r9;
  u32 _slot_21 = r10;
  u32 _value_2 = r11;
  u32 _value_3 = r12;
  u32 _skipSame_1 = r13;
  WL_SPIN
    if (_slot_11 == 0) {
      _v_11 = 0;
      _v_12 = 0;
      _v_13 = 0;
      _v_14 = 0;
      _v_15 = 0;
      _v_16 = 0;
      _v_17 = 0;
      _v_18 = 0;
      _v_19 = 0;
      _v_20 = 0;
      _v_21 = 0;
    } else {
      _v_11 = 1;
      _v_12 = _slot_12;
      _v_13 = _slot_13;
      _v_14 = 1;
      _v_15 = _value_2;
      _v_16 = _value_3;
      _v_17 = _skipSame_1;
      _v_18 = _slot_18;
      _v_19 = _slot_19;
      _v_20 = _slot_20;
      _v_21 = _slot_21;
    }
  break;
  }
  o[0] = _v_11;
  o[1] = _v_12;
  o[2] = _v_13;
  o[3] = _v_14;
  o[4] = _v_15;
  o[5] = _v_16;
  o[6] = _v_17;
  o[7] = _v_18;
  o[8] = _v_19;
  o[9] = _v_20;
  o[10] = _v_21;
  return 1;
}

INLINE Term spin_7(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12) {
  u32 wpoll = 0;
  u32 _v_33 = 0;
  u32 _v_34 = 0;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _slot_22 = r0;
  u32 _slot_23 = r1;
  u32 _slot_24 = r2;
  u32 _slot_25 = r3;
  u32 _slot_26 = r4;
  u32 _slot_27 = r5;
  u32 _slot_28 = r6;
  u32 _slot_29 = r7;
  u32 _slot_30 = r8;
  u32 _slot_31 = r9;
  u32 _slot_32 = r10;
  u32 _value_4 = r11;
  u32 _value_5 = r12;
  WL_SPIN
    if (_slot_22 == 0) {
      _v_33 = 0;
      _v_34 = 0;
      _v_35 = 0;
      _v_36 = 0;
      _v_37 = 0;
      _v_38 = 0;
      _v_39 = 0;
      _v_40 = 0;
      _v_41 = 0;
      _v_42 = 0;
      _v_43 = 0;
    } else {
      u32 _v_44 = 0;
      u32 _v_45 = 0;
      u32 _v_46 = 0;
      u32 _v_47 = 0;
      u32 _v_48 = 0;
      u32 _v_49 = 0;
      u32 _v_50 = 0;
      u32 _v_51 = 0;
      Term _o_1[4];
      if (spin_3(e, _o_1, _slot_25, _slot_26, _slot_27, _slot_28, _value_4, _value_5) == 0) {
        return 0;
      }
      _v_48 = _o_1[0];
      _v_49 = _o_1[1];
      _v_50 = _o_1[2];
      _v_51 = _o_1[3];
      _v_44 = _v_48;
      _v_45 = _v_49;
      _v_46 = _v_50;
      _v_47 = _v_51;
      _v_33 = 1;
      _v_34 = _slot_23;
      _v_35 = _slot_24;
      _v_36 = _v_44;
      _v_37 = _v_45;
      _v_38 = _v_46;
      _v_39 = _v_47;
      _v_40 = _slot_29;
      _v_41 = _slot_30;
      _v_42 = _slot_31;
      _v_43 = _slot_32;
    }
  break;
  }
  o[0] = _v_33;
  o[1] = _v_34;
  o[2] = _v_35;
  o[3] = _v_36;
  o[4] = _v_37;
  o[5] = _v_38;
  o[6] = _v_39;
  o[7] = _v_40;
  o[8] = _v_41;
  o[9] = _v_42;
  o[10] = _v_43;
  return 1;
}

INLINE Term spin_8(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23, Term r24, u64 q24) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  Term h24 = r24;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  Term _v_51 = 0;
  u32 _v_52 = 0;
  Term _v_53 = 0;
  Term _v_54 = 0;
  Term _v_55 = 0;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  u32 _v_60 = 0;
  u32 _v_61 = 0;
  u32 _v_62 = 0;
  u32 _v_63 = 0;
  u32 _v_64 = 0;
  u32 _v_65 = 0;
  u32 _v_66 = 0;
  Term _v_67 = 0;
  Term _v_68 = 0;
  Term _v_69 = 0;
  u32 _v_70 = 0;
  u32 _v_71 = 0;
  u32 _world_24 = r0;
  u32 _world_25 = r1;
  u32 _world_26 = r2;
  Term _world_27 = r3;
  u32 _world_28 = r4;
  Term _world_29 = r5;
  Term _world_30 = r6;
  Term _world_31 = r7;
  u32 _world_32 = r8;
  u32 _world_33 = r9;
  u32 _world_34 = r10;
  u32 _world_35 = r11;
  u32 _world_36 = r12;
  u32 _world_37 = r13;
  u32 _world_38 = r14;
  u32 _world_39 = r15;
  u32 _world_40 = r16;
  u32 _world_41 = r17;
  u32 _world_42 = r18;
  Term _world_43 = r19;
  Term _world_44 = r20;
  Term _world_45 = r21;
  u32 _world_46 = r22;
  u32 _world_47 = r23;
  Term _command_0 = r24;
  WL_SPIN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _command_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _world_44);
    _v_48 = _world_24;
    _v_49 = _world_25;
    _v_50 = _world_26;
    _v_51 = _world_27;
    _v_52 = _world_28;
    _v_53 = _world_29;
    _v_54 = _world_30;
    _v_55 = _world_31;
    _v_56 = _world_32;
    _v_57 = _world_33;
    _v_58 = _world_34;
    _v_59 = _world_35;
    _v_60 = _world_36;
    _v_61 = _world_37;
    _v_62 = _world_38;
    _v_63 = _world_39;
    _v_64 = _world_40;
    _v_65 = _world_41;
    _v_66 = _world_42;
    _v_67 = _world_43;
    _v_68 = term_ctr(CID_CON, _nd_0);
    _v_69 = _world_45;
    _v_70 = _world_46;
    _v_71 = _world_47;
  break;
  }
  o[0] = _v_48;
  o[1] = _v_49;
  o[2] = _v_50;
  o[3] = _v_51;
  o[4] = _v_52;
  o[5] = _v_53;
  o[6] = _v_54;
  o[7] = _v_55;
  o[8] = _v_56;
  o[9] = _v_57;
  o[10] = _v_58;
  o[11] = _v_59;
  o[12] = _v_60;
  o[13] = _v_61;
  o[14] = _v_62;
  o[15] = _v_63;
  o[16] = _v_64;
  o[17] = _v_65;
  o[18] = _v_66;
  o[19] = _v_67;
  o[20] = _v_68;
  o[21] = _v_69;
  o[22] = _v_70;
  o[23] = _v_71;
  return 1;
}

INLINE Term spin_9(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_3 = 0;
  u32 _a_1 = r0;
  u32 _b_1 = r1;
  WL_SPIN
    _v_3 = U32_BIN(_a_1, ==, _b_1);
  break;
  }
  o[0] = _v_3;
  return 1;
}

INLINE Term spin_10(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_5 = 0;
  u32 _a_2 = r0;
  u32 _b_2 = r1;
  WL_SPIN
    if (_a_2 == 0) {
      _v_5 = 0;
    } else {
      _v_5 = _b_2;
    }
  break;
  }
  o[0] = _v_5;
  return 1;
}

INLINE Term spin_12(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  u32 _v_4 = 0;
  Term _a_1 = r0;
  Term _b_1 = r1;
  u32 _same_0 = r2;
  WL_SPIN
    if (term_aux(_a_1) == CID_SNIL) {
      if (term_aux(_b_1) == CID_SNIL) {
        _v_4 = _same_0;
      } else {
        u64 _sp_3 = term_peek(e.mem, _b_1);
        u32 _f_8 = e.mem[_sp_3 + 0];
        Term _f_9 = e.mem[_sp_3 + 1];
        _v_4 = 0;
      }
    } else {
      u64 _sp_4 = term_peek(e.mem, _a_1);
      u32 _f_10 = e.mem[_sp_4 + 0];
      Term _f_11 = e.mem[_sp_4 + 1];
      if (term_aux(_b_1) == CID_SNIL) {
        _v_4 = 0;
      } else {
        u64 _sp_5 = term_peek(e.mem, _b_1);
        u32 _f_12 = e.mem[_sp_5 + 0];
        Term _f_13 = e.mem[_sp_5 + 1];
        u32 _v_5 = 0;
        u32 _v_6 = 0;
        u32 _v_7 = 0;
        Term _o_0[1];
        if (spin_9(e, _o_0, _f_10, _f_12) == 0) {
          return 0;
        }
        _v_7 = _o_0[0];
        _v_6 = _v_7;
        u32 _v_8 = 0;
        Term _o_1[1];
        if (spin_10(e, _o_1, _same_0, _v_6) == 0) {
          return 0;
        }
        _v_8 = _o_1[0];
        _v_5 = _v_8;
        r0 = _f_11;
        r1 = _f_13;
        r2 = _v_5;
        _a_1 = r0;
        _b_1 = r1;
        _same_0 = r2;
        WL_AGAIN(spin_12);
      }
    }
  break;
  }
  o[0] = _v_4;
  return 1;
}

INLINE Term spin_11(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  u32 _v_2 = 0;
  Term _a_0 = r0;
  Term _b_0 = r1;
  WL_SPIN
    u32 _v_3 = 0;
    Term _o_2[1];
    if (spin_12(e, _o_2, _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0), _b_0, _b_0 == h1 ? q1 : blk_loc(e.mem, _b_0), 1) == 0) {
      return 0;
    }
    _v_3 = _o_2[0];
    _v_2 = _v_3;
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_13(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, u32 r9, u32 r10) {
  u32 wpoll = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  u32 _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  u32 _slot_0 = r0;
  u32 _slot_1 = r1;
  u32 _slot_2 = r2;
  u32 _slot_3 = r3;
  u32 _slot_4 = r4;
  u32 _slot_5 = r5;
  u32 _slot_6 = r6;
  u32 _slot_7 = r7;
  u32 _slot_8 = r8;
  u32 _slot_9 = r9;
  u32 _slot_10 = r10;
  WL_SPIN
    if (_slot_0 == 0) {
      _v_46 = 0;
      _v_47 = 0;
      _v_48 = 0;
      _v_49 = 0;
      _v_50 = 0;
      _v_51 = 0;
      _v_52 = 0;
      _v_53 = 0;
      _v_54 = 0;
      _v_55 = 0;
      _v_56 = 0;
    } else {
      _v_46 = 1;
      _v_47 = _slot_1;
      _v_48 = _slot_2;
      _v_49 = 0;
      _v_50 = 0;
      _v_51 = 0;
      _v_52 = 0;
      _v_53 = _slot_7;
      _v_54 = _slot_8;
      _v_55 = _slot_9;
      _v_56 = _slot_10;
    }
  break;
  }
  o[0] = _v_46;
  o[1] = _v_47;
  o[2] = _v_48;
  o[3] = _v_49;
  o[4] = _v_50;
  o[5] = _v_51;
  o[6] = _v_52;
  o[7] = _v_53;
  o[8] = _v_54;
  o[9] = _v_55;
  o[10] = _v_56;
  return 1;
}

INLINE Term spin_16(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, u32 r19, u32 r20, u32 r21, u32 r22) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_177 = 0;
  u32 _v_178 = 0;
  u32 _v_179 = 0;
  u32 _v_180 = 0;
  u32 _v_181 = 0;
  u32 _v_182 = 0;
  u32 _v_183 = 0;
  u32 _v_184 = 0;
  u32 _v_185 = 0;
  u32 _v_186 = 0;
  u32 _v_187 = 0;
  u32 _v_188 = 0;
  Term _resources_0 = r0;
  u32 _resources_1 = r1;
  u32 _resources_2 = r2;
  u32 _resources_3 = r3;
  u32 _resources_4 = r4;
  u32 _resources_5 = r5;
  u32 _resources_6 = r6;
  u32 _resources_7 = r7;
  u32 _resources_8 = r8;
  u32 _resources_9 = r9;
  u32 _resources_10 = r10;
  u32 _resources_11 = r11;
  u32 _slot_33 = r12;
  u32 _slot_34 = r13;
  u32 _slot_35 = r14;
  u32 _slot_36 = r15;
  u32 _slot_37 = r16;
  u32 _slot_38 = r17;
  u32 _slot_39 = r18;
  u32 _slot_40 = r19;
  u32 _slot_41 = r20;
  u32 _slot_42 = r21;
  u32 _slot_43 = r22;
  WL_SPIN
    _v_177 = _resources_0;
    _v_178 = _slot_33;
    _v_179 = _slot_34;
    _v_180 = _slot_35;
    _v_181 = _slot_36;
    _v_182 = _slot_37;
    _v_183 = _slot_38;
    _v_184 = _slot_39;
    _v_185 = _slot_40;
    _v_186 = _slot_41;
    _v_187 = _slot_42;
    _v_188 = _slot_43;
  break;
  }
  o[0] = _v_177;
  o[1] = _v_178;
  o[2] = _v_179;
  o[3] = _v_180;
  o[4] = _v_181;
  o[5] = _v_182;
  o[6] = _v_183;
  o[7] = _v_184;
  o[8] = _v_185;
  o[9] = _v_186;
  o[10] = _v_187;
  o[11] = _v_188;
  return 1;
}

INLINE Term spin_15(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23, u32 r24, u32 r25, u32 r26, u32 r27, u32 r28, u32 r29, u32 r30, u32 r31, u32 r32, u32 r33, u32 r34) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  u32 _v_129 = 0;
  u32 _v_130 = 0;
  u32 _v_131 = 0;
  Term _v_132 = 0;
  u32 _v_133 = 0;
  Term _v_134 = 0;
  Term _v_135 = 0;
  Term _v_136 = 0;
  u32 _v_137 = 0;
  u32 _v_138 = 0;
  u32 _v_139 = 0;
  u32 _v_140 = 0;
  u32 _v_141 = 0;
  u32 _v_142 = 0;
  u32 _v_143 = 0;
  u32 _v_144 = 0;
  u32 _v_145 = 0;
  u32 _v_146 = 0;
  u32 _v_147 = 0;
  Term _v_148 = 0;
  Term _v_149 = 0;
  Term _v_150 = 0;
  u32 _v_151 = 0;
  u32 _v_152 = 0;
  u32 _world_24 = r0;
  u32 _world_25 = r1;
  u32 _world_26 = r2;
  Term _world_27 = r3;
  u32 _world_28 = r4;
  Term _world_29 = r5;
  Term _world_30 = r6;
  Term _world_31 = r7;
  u32 _world_32 = r8;
  u32 _world_33 = r9;
  u32 _world_34 = r10;
  u32 _world_35 = r11;
  u32 _world_36 = r12;
  u32 _world_37 = r13;
  u32 _world_38 = r14;
  u32 _world_39 = r15;
  u32 _world_40 = r16;
  u32 _world_41 = r17;
  u32 _world_42 = r18;
  Term _world_43 = r19;
  Term _world_44 = r20;
  Term _world_45 = r21;
  u32 _world_46 = r22;
  u32 _world_47 = r23;
  u32 _slot_22 = r24;
  u32 _slot_23 = r25;
  u32 _slot_24 = r26;
  u32 _slot_25 = r27;
  u32 _slot_26 = r28;
  u32 _slot_27 = r29;
  u32 _slot_28 = r30;
  u32 _slot_29 = r31;
  u32 _slot_30 = r32;
  u32 _slot_31 = r33;
  u32 _slot_32 = r34;
  WL_SPIN
    Term _v_153 = 0;
    u32 _v_154 = 0;
    u32 _v_155 = 0;
    u32 _v_156 = 0;
    u32 _v_157 = 0;
    u32 _v_158 = 0;
    u32 _v_159 = 0;
    u32 _v_160 = 0;
    u32 _v_161 = 0;
    u32 _v_162 = 0;
    u32 _v_163 = 0;
    u32 _v_164 = 0;
    Term _v_165 = 0;
    u32 _v_166 = 0;
    u32 _v_167 = 0;
    u32 _v_168 = 0;
    u32 _v_169 = 0;
    u32 _v_170 = 0;
    u32 _v_171 = 0;
    u32 _v_172 = 0;
    u32 _v_173 = 0;
    u32 _v_174 = 0;
    u32 _v_175 = 0;
    u32 _v_176 = 0;
    Term _o_1[12];
    if (spin_16(e, _o_1, _world_31, _world_31 == h7 ? q7 : blk_loc(e.mem, _world_31), _world_32, _world_33, _world_34, _world_35, _world_36, _world_37, _world_38, _world_39, _world_40, _world_41, _world_42, _slot_22, _slot_23, _slot_24, _slot_25, _slot_26, _slot_27, _slot_28, _slot_29, _slot_30, _slot_31, _slot_32) == 0) {
      return 0;
    }
    _v_165 = _o_1[0];
    _v_166 = _o_1[1];
    _v_167 = _o_1[2];
    _v_168 = _o_1[3];
    _v_169 = _o_1[4];
    _v_170 = _o_1[5];
    _v_171 = _o_1[6];
    _v_172 = _o_1[7];
    _v_173 = _o_1[8];
    _v_174 = _o_1[9];
    _v_175 = _o_1[10];
    _v_176 = _o_1[11];
    _v_153 = _v_165;
    _v_154 = _v_166;
    _v_155 = _v_167;
    _v_156 = _v_168;
    _v_157 = _v_169;
    _v_158 = _v_170;
    _v_159 = _v_171;
    _v_160 = _v_172;
    _v_161 = _v_173;
    _v_162 = _v_174;
    _v_163 = _v_175;
    _v_164 = _v_176;
    _v_129 = _world_24;
    _v_130 = _world_25;
    _v_131 = _world_26;
    _v_132 = _world_27;
    _v_133 = _world_28;
    _v_134 = _world_29;
    _v_135 = _world_30;
    _v_136 = _v_153;
    _v_137 = _v_154;
    _v_138 = _v_155;
    _v_139 = _v_156;
    _v_140 = _v_157;
    _v_141 = _v_158;
    _v_142 = _v_159;
    _v_143 = _v_160;
    _v_144 = _v_161;
    _v_145 = _v_162;
    _v_146 = _v_163;
    _v_147 = _v_164;
    _v_148 = _world_43;
    _v_149 = _world_44;
    _v_150 = _world_45;
    _v_151 = _world_46;
    _v_152 = _world_47;
  break;
  }
  o[0] = _v_129;
  o[1] = _v_130;
  o[2] = _v_131;
  o[3] = _v_132;
  o[4] = _v_133;
  o[5] = _v_134;
  o[6] = _v_135;
  o[7] = _v_136;
  o[8] = _v_137;
  o[9] = _v_138;
  o[10] = _v_139;
  o[11] = _v_140;
  o[12] = _v_141;
  o[13] = _v_142;
  o[14] = _v_143;
  o[15] = _v_144;
  o[16] = _v_145;
  o[17] = _v_146;
  o[18] = _v_147;
  o[19] = _v_148;
  o[20] = _v_149;
  o[21] = _v_150;
  o[22] = _v_151;
  o[23] = _v_152;
  return 1;
}

INLINE Term spin_14(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23, u32 r24, u32 r25, u32 r26, u32 r27, u32 r28, u32 r29, u32 r30, u32 r31, u32 r32, u32 r33, u32 r34) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  u32 _v_81 = 0;
  u32 _v_82 = 0;
  u32 _v_83 = 0;
  Term _v_84 = 0;
  u32 _v_85 = 0;
  Term _v_86 = 0;
  Term _v_87 = 0;
  Term _v_88 = 0;
  u32 _v_89 = 0;
  u32 _v_90 = 0;
  u32 _v_91 = 0;
  u32 _v_92 = 0;
  u32 _v_93 = 0;
  u32 _v_94 = 0;
  u32 _v_95 = 0;
  u32 _v_96 = 0;
  u32 _v_97 = 0;
  u32 _v_98 = 0;
  u32 _v_99 = 0;
  Term _v_100 = 0;
  Term _v_101 = 0;
  Term _v_102 = 0;
  u32 _v_103 = 0;
  u32 _v_104 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  Term _world_6 = r6;
  Term _world_7 = r7;
  u32 _world_8 = r8;
  u32 _world_9 = r9;
  u32 _world_10 = r10;
  u32 _world_11 = r11;
  u32 _world_12 = r12;
  u32 _world_13 = r13;
  u32 _world_14 = r14;
  u32 _world_15 = r15;
  u32 _world_16 = r16;
  u32 _world_17 = r17;
  u32 _world_18 = r18;
  Term _world_19 = r19;
  Term _world_20 = r20;
  Term _world_21 = r21;
  u32 _world_22 = r22;
  u32 _world_23 = r23;
  u32 _slot_11 = r24;
  u32 _slot_12 = r25;
  u32 _slot_13 = r26;
  u32 _slot_14 = r27;
  u32 _slot_15 = r28;
  u32 _slot_16 = r29;
  u32 _slot_17 = r30;
  u32 _slot_18 = r31;
  u32 _slot_19 = r32;
  u32 _slot_20 = r33;
  u32 _slot_21 = r34;
  WL_SPIN
    u32 _v_105 = 0;
    u32 _v_106 = 0;
    u32 _v_107 = 0;
    Term _v_108 = 0;
    u32 _v_109 = 0;
    Term _v_110 = 0;
    Term _v_111 = 0;
    Term _v_112 = 0;
    u32 _v_113 = 0;
    u32 _v_114 = 0;
    u32 _v_115 = 0;
    u32 _v_116 = 0;
    u32 _v_117 = 0;
    u32 _v_118 = 0;
    u32 _v_119 = 0;
    u32 _v_120 = 0;
    u32 _v_121 = 0;
    u32 _v_122 = 0;
    u32 _v_123 = 0;
    Term _v_124 = 0;
    Term _v_125 = 0;
    Term _v_126 = 0;
    u32 _v_127 = 0;
    u32 _v_128 = 0;
    Term _o_2[24];
    if (spin_15(e, _o_2, _world_0, _world_1, _world_2, _world_3, _world_3 == h3 ? q3 : blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_6 == h6 ? q6 : blk_loc(e.mem, _world_6), _world_7, _world_7 == h7 ? q7 : blk_loc(e.mem, _world_7), _world_8, _world_9, _world_10, _world_11, _world_12, _world_13, _world_14, _world_15, _world_16, _world_17, _world_18, _world_19, _world_19 == h19 ? q19 : blk_loc(e.mem, _world_19), _world_20, _world_20 == h20 ? q20 : blk_loc(e.mem, _world_20), _world_21, _world_21 == h21 ? q21 : blk_loc(e.mem, _world_21), _world_22, _world_23, _slot_11, _slot_12, _slot_13, _slot_14, _slot_15, _slot_16, _slot_17, _slot_18, _slot_19, _slot_20, _slot_21) == 0) {
      return 0;
    }
    _v_105 = _o_2[0];
    _v_106 = _o_2[1];
    _v_107 = _o_2[2];
    _v_108 = _o_2[3];
    _v_109 = _o_2[4];
    _v_110 = _o_2[5];
    _v_111 = _o_2[6];
    _v_112 = _o_2[7];
    _v_113 = _o_2[8];
    _v_114 = _o_2[9];
    _v_115 = _o_2[10];
    _v_116 = _o_2[11];
    _v_117 = _o_2[12];
    _v_118 = _o_2[13];
    _v_119 = _o_2[14];
    _v_120 = _o_2[15];
    _v_121 = _o_2[16];
    _v_122 = _o_2[17];
    _v_123 = _o_2[18];
    _v_124 = _o_2[19];
    _v_125 = _o_2[20];
    _v_126 = _o_2[21];
    _v_127 = _o_2[22];
    _v_128 = _o_2[23];
    _v_81 = _v_105;
    _v_82 = _v_106;
    _v_83 = _v_107;
    _v_84 = _v_108;
    _v_85 = _v_109;
    _v_86 = _v_110;
    _v_87 = _v_111;
    _v_88 = _v_112;
    _v_89 = _v_113;
    _v_90 = _v_114;
    _v_91 = _v_115;
    _v_92 = _v_116;
    _v_93 = _v_117;
    _v_94 = _v_118;
    _v_95 = _v_119;
    _v_96 = _v_120;
    _v_97 = _v_121;
    _v_98 = _v_122;
    _v_99 = _v_123;
    _v_100 = _v_124;
    _v_101 = _v_125;
    _v_102 = _v_126;
    _v_103 = _v_127;
    _v_104 = _v_128;
  break;
  }
  o[0] = _v_81;
  o[1] = _v_82;
  o[2] = _v_83;
  o[3] = _v_84;
  o[4] = _v_85;
  o[5] = _v_86;
  o[6] = _v_87;
  o[7] = _v_88;
  o[8] = _v_89;
  o[9] = _v_90;
  o[10] = _v_91;
  o[11] = _v_92;
  o[12] = _v_93;
  o[13] = _v_94;
  o[14] = _v_95;
  o[15] = _v_96;
  o[16] = _v_97;
  o[17] = _v_98;
  o[18] = _v_99;
  o[19] = _v_100;
  o[20] = _v_101;
  o[21] = _v_102;
  o[22] = _v_103;
  o[23] = _v_104;
  return 1;
}

INLINE Term spin_17(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _v_38 = 0;
  u32 _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  Term _v_54 = 0;
  Term _v_55 = 0;
  Term _v_56 = 0;
  u32 _v_57 = 0;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  u32 _v_60 = 0;
  u32 _v_61 = 0;
  u32 _v_62 = 0;
  u32 _v_63 = 0;
  u32 _v_64 = 0;
  u32 _v_65 = 0;
  u32 _v_66 = 0;
  u32 _v_67 = 0;
  u32 _v_68 = 0;
  u32 _v_69 = 0;
  u32 _world_24 = r0;
  u32 _world_25 = r1;
  u32 _world_26 = r2;
  Term _world_27 = r3;
  u32 _world_28 = r4;
  Term _world_29 = r5;
  Term _world_30 = r6;
  Term _world_31 = r7;
  u32 _world_32 = r8;
  u32 _world_33 = r9;
  u32 _world_34 = r10;
  u32 _world_35 = r11;
  u32 _world_36 = r12;
  u32 _world_37 = r13;
  u32 _world_38 = r14;
  u32 _world_39 = r15;
  u32 _world_40 = r16;
  u32 _world_41 = r17;
  u32 _world_42 = r18;
  Term _world_43 = r19;
  Term _world_44 = r20;
  Term _world_45 = r21;
  u32 _world_46 = r22;
  u32 _world_47 = r23;
  WL_SPIN
    Term _v_70 = 0;
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    u32 _v_73 = 0;
    u32 _v_74 = 0;
    u32 _v_75 = 0;
    u32 _v_76 = 0;
    u32 _v_77 = 0;
    u32 _v_78 = 0;
    u32 _v_79 = 0;
    u32 _v_80 = 0;
    u32 _v_81 = 0;
    u32 _v_82 = 0;
    u32 _v_83 = 0;
    u32 _v_84 = 0;
    u32 _v_85 = 0;
    u32 _v_86 = 0;
    u32 _v_87 = 0;
    u32 _v_88 = 0;
    u32 _v_89 = 0;
    u32 _v_90 = 0;
    u32 _v_91 = 0;
    u32 _v_92 = 0;
    Term _v_93 = 0;
    u32 _v_94 = 0;
    u32 _v_95 = 0;
    u32 _v_96 = 0;
    u32 _v_97 = 0;
    u32 _v_98 = 0;
    u32 _v_99 = 0;
    u32 _v_100 = 0;
    u32 _v_101 = 0;
    u32 _v_102 = 0;
    u32 _v_103 = 0;
    u32 _v_104 = 0;
    u32 _v_105 = 0;
    u32 _v_106 = 0;
    u32 _v_107 = 0;
    u32 _v_108 = 0;
    u32 _v_109 = 0;
    u32 _v_110 = 0;
    u32 _v_111 = 0;
    u32 _v_112 = 0;
    u32 _v_113 = 0;
    u32 _v_114 = 0;
    u32 _v_115 = 0;
    Term _o_0[23];
    if (spin_4(e, _o_0, _world_31, _world_31 == h7 ? q7 : blk_loc(e.mem, _world_31), _world_32, _world_33, _world_34, _world_35, _world_36, _world_37, _world_38, _world_39, _world_40, _world_41, _world_42) == 0) {
      return 0;
    }
    _v_93 = _o_0[0];
    _v_94 = _o_0[1];
    _v_95 = _o_0[2];
    _v_96 = _o_0[3];
    _v_97 = _o_0[4];
    _v_98 = _o_0[5];
    _v_99 = _o_0[6];
    _v_100 = _o_0[7];
    _v_101 = _o_0[8];
    _v_102 = _o_0[9];
    _v_103 = _o_0[10];
    _v_104 = _o_0[11];
    _v_105 = _o_0[12];
    _v_106 = _o_0[13];
    _v_107 = _o_0[14];
    _v_108 = _o_0[15];
    _v_109 = _o_0[16];
    _v_110 = _o_0[17];
    _v_111 = _o_0[18];
    _v_112 = _o_0[19];
    _v_113 = _o_0[20];
    _v_114 = _o_0[21];
    _v_115 = _o_0[22];
    _v_70 = _v_93;
    _v_71 = _v_94;
    _v_72 = _v_95;
    _v_73 = _v_96;
    _v_74 = _v_97;
    _v_75 = _v_98;
    _v_76 = _v_99;
    _v_77 = _v_100;
    _v_78 = _v_101;
    _v_79 = _v_102;
    _v_80 = _v_103;
    _v_81 = _v_104;
    _v_82 = _v_105;
    _v_83 = _v_106;
    _v_84 = _v_107;
    _v_85 = _v_108;
    _v_86 = _v_109;
    _v_87 = _v_110;
    _v_88 = _v_111;
    _v_89 = _v_112;
    _v_90 = _v_113;
    _v_91 = _v_114;
    _v_92 = _v_115;
    u32 _v_116 = 0;
    u32 _v_117 = 0;
    u32 _v_118 = 0;
    Term _v_119 = 0;
    u32 _v_120 = 0;
    Term _v_121 = 0;
    Term _v_122 = 0;
    Term _v_123 = 0;
    u32 _v_124 = 0;
    u32 _v_125 = 0;
    u32 _v_126 = 0;
    u32 _v_127 = 0;
    u32 _v_128 = 0;
    u32 _v_129 = 0;
    u32 _v_130 = 0;
    u32 _v_131 = 0;
    u32 _v_132 = 0;
    u32 _v_133 = 0;
    u32 _v_134 = 0;
    Term _v_135 = 0;
    Term _v_136 = 0;
    Term _v_137 = 0;
    u32 _v_138 = 0;
    u32 _v_139 = 0;
    u32 _v_140 = 0;
    u32 _v_141 = 0;
    u32 _v_142 = 0;
    u32 _v_143 = 0;
    u32 _v_144 = 0;
    u32 _v_145 = 0;
    u32 _v_146 = 0;
    u32 _v_147 = 0;
    u32 _v_148 = 0;
    u32 _v_149 = 0;
    u32 _v_150 = 0;
    Term _o_1[35];
    if (spin_5(e, _o_1, _world_24, _world_25, _world_26, _world_27, _world_27 == h3 ? q3 : blk_loc(e.mem, _world_27), _world_28, _world_29, _world_30, _world_30 == h6 ? q6 : blk_loc(e.mem, _world_30), _v_70, _v_70 == h21 ? q21 : _v_70 == h20 ? q20 : _v_70 == h19 ? q19 : _v_70 == h7 ? q7 : _v_70 == h6 ? q6 : _v_70 == h3 ? q3 : blk_loc(e.mem, _v_70), _v_71, _v_72, _v_73, _v_74, _v_75, _v_76, _v_77, _v_78, _v_79, _v_80, _v_81, _v_82, _v_83, _v_84, _v_85, _v_86, _v_87, _v_88, _v_89, _v_90, _v_91, _v_92, _world_43, _world_43 == h19 ? q19 : blk_loc(e.mem, _world_43), _world_44, _world_44 == h20 ? q20 : blk_loc(e.mem, _world_44), _world_45, _world_45 == h21 ? q21 : blk_loc(e.mem, _world_45), _world_46, _world_47) == 0) {
      return 0;
    }
    _v_116 = _o_1[0];
    _v_117 = _o_1[1];
    _v_118 = _o_1[2];
    _v_119 = _o_1[3];
    _v_120 = _o_1[4];
    _v_121 = _o_1[5];
    _v_122 = _o_1[6];
    _v_123 = _o_1[7];
    _v_124 = _o_1[8];
    _v_125 = _o_1[9];
    _v_126 = _o_1[10];
    _v_127 = _o_1[11];
    _v_128 = _o_1[12];
    _v_129 = _o_1[13];
    _v_130 = _o_1[14];
    _v_131 = _o_1[15];
    _v_132 = _o_1[16];
    _v_133 = _o_1[17];
    _v_134 = _o_1[18];
    _v_135 = _o_1[19];
    _v_136 = _o_1[20];
    _v_137 = _o_1[21];
    _v_138 = _o_1[22];
    _v_139 = _o_1[23];
    _v_140 = _o_1[24];
    _v_141 = _o_1[25];
    _v_142 = _o_1[26];
    _v_143 = _o_1[27];
    _v_144 = _o_1[28];
    _v_145 = _o_1[29];
    _v_146 = _o_1[30];
    _v_147 = _o_1[31];
    _v_148 = _o_1[32];
    _v_149 = _o_1[33];
    _v_150 = _o_1[34];
    _v_35 = _v_116;
    _v_36 = _v_117;
    _v_37 = _v_118;
    _v_38 = _v_119;
    _v_39 = _v_120;
    _v_40 = _v_121;
    _v_41 = _v_122;
    _v_42 = _v_123;
    _v_43 = _v_124;
    _v_44 = _v_125;
    _v_45 = _v_126;
    _v_46 = _v_127;
    _v_47 = _v_128;
    _v_48 = _v_129;
    _v_49 = _v_130;
    _v_50 = _v_131;
    _v_51 = _v_132;
    _v_52 = _v_133;
    _v_53 = _v_134;
    _v_54 = _v_135;
    _v_55 = _v_136;
    _v_56 = _v_137;
    _v_57 = _v_138;
    _v_58 = _v_139;
    _v_59 = _v_140;
    _v_60 = _v_141;
    _v_61 = _v_142;
    _v_62 = _v_143;
    _v_63 = _v_144;
    _v_64 = _v_145;
    _v_65 = _v_146;
    _v_66 = _v_147;
    _v_67 = _v_148;
    _v_68 = _v_149;
    _v_69 = _v_150;
  break;
  }
  o[0] = _v_35;
  o[1] = _v_36;
  o[2] = _v_37;
  o[3] = _v_38;
  o[4] = _v_39;
  o[5] = _v_40;
  o[6] = _v_41;
  o[7] = _v_42;
  o[8] = _v_43;
  o[9] = _v_44;
  o[10] = _v_45;
  o[11] = _v_46;
  o[12] = _v_47;
  o[13] = _v_48;
  o[14] = _v_49;
  o[15] = _v_50;
  o[16] = _v_51;
  o[17] = _v_52;
  o[18] = _v_53;
  o[19] = _v_54;
  o[20] = _v_55;
  o[21] = _v_56;
  o[22] = _v_57;
  o[23] = _v_58;
  o[24] = _v_59;
  o[25] = _v_60;
  o[26] = _v_61;
  o[27] = _v_62;
  o[28] = _v_63;
  o[29] = _v_64;
  o[30] = _v_65;
  o[31] = _v_66;
  o[32] = _v_67;
  o[33] = _v_68;
  o[34] = _v_69;
  return 1;
}

INLINE Term spin_18(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13) {
  u32 wpoll = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  u32 _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  u32 _slot_0 = r0;
  u32 _slot_1 = r1;
  u32 _slot_2 = r2;
  u32 _slot_3 = r3;
  u32 _slot_4 = r4;
  u32 _slot_5 = r5;
  u32 _slot_6 = r6;
  u32 _slot_7 = r7;
  u32 _slot_8 = r8;
  u32 _slot_9 = r9;
  u32 _slot_10 = r10;
  u32 _value_2 = r11;
  u32 _value_3 = r12;
  u32 _skipSame_1 = r13;
  WL_SPIN
    if (_skipSame_1 == 0) {
      u32 _v_57 = 0;
      u32 _v_58 = 0;
      u32 _v_59 = 0;
      u32 _v_60 = 0;
      u32 _v_61 = 0;
      u32 _v_62 = 0;
      u32 _v_63 = 0;
      u32 _v_64 = 0;
      u32 _v_65 = 0;
      u32 _v_66 = 0;
      u32 _v_67 = 0;
      Term _o_0[11];
      if (spin_6(e, _o_0, _slot_0, _slot_1, _slot_2, _slot_3, _slot_4, _slot_5, _slot_6, _slot_7, _slot_8, _slot_9, _slot_10, _value_2, _value_3, 0) == 0) {
        return 0;
      }
      _v_57 = _o_0[0];
      _v_58 = _o_0[1];
      _v_59 = _o_0[2];
      _v_60 = _o_0[3];
      _v_61 = _o_0[4];
      _v_62 = _o_0[5];
      _v_63 = _o_0[6];
      _v_64 = _o_0[7];
      _v_65 = _o_0[8];
      _v_66 = _o_0[9];
      _v_67 = _o_0[10];
      _v_46 = _v_57;
      _v_47 = _v_58;
      _v_48 = _v_59;
      _v_49 = _v_60;
      _v_50 = _v_61;
      _v_51 = _v_62;
      _v_52 = _v_63;
      _v_53 = _v_64;
      _v_54 = _v_65;
      _v_55 = _v_66;
      _v_56 = _v_67;
    } else {
      u32 _v_68 = 0;
      u32 _v_69 = 0;
      u32 _v_70 = 0;
      u32 _v_71 = 0;
      u32 _v_72 = 0;
      u32 _v_73 = 0;
      u32 _v_74 = 0;
      u32 _v_75 = 0;
      u32 _v_76 = 0;
      u32 _v_77 = 0;
      u32 _v_78 = 0;
      Term _o_1[11];
      if (spin_7(e, _o_1, _slot_0, _slot_1, _slot_2, _slot_3, _slot_4, _slot_5, _slot_6, _slot_7, _slot_8, _slot_9, _slot_10, _value_2, _value_3) == 0) {
        return 0;
      }
      _v_68 = _o_1[0];
      _v_69 = _o_1[1];
      _v_70 = _o_1[2];
      _v_71 = _o_1[3];
      _v_72 = _o_1[4];
      _v_73 = _o_1[5];
      _v_74 = _o_1[6];
      _v_75 = _o_1[7];
      _v_76 = _o_1[8];
      _v_77 = _o_1[9];
      _v_78 = _o_1[10];
      _v_46 = _v_68;
      _v_47 = _v_69;
      _v_48 = _v_70;
      _v_49 = _v_71;
      _v_50 = _v_72;
      _v_51 = _v_73;
      _v_52 = _v_74;
      _v_53 = _v_75;
      _v_54 = _v_76;
      _v_55 = _v_77;
      _v_56 = _v_78;
    }
  break;
  }
  o[0] = _v_46;
  o[1] = _v_47;
  o[2] = _v_48;
  o[3] = _v_49;
  o[4] = _v_50;
  o[5] = _v_51;
  o[6] = _v_52;
  o[7] = _v_53;
  o[8] = _v_54;
  o[9] = _v_55;
  o[10] = _v_56;
  return 1;
}

INLINE Term spin_19(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_1 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_1 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_19);
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_20(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, Term r4, u64 q4, u32 r5, Term r6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, u32 r19, Term r20, u64 q20, Term r21, u64 q21, Term r22, u64 q22, u32 r23, u32 r24) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h4 = r4;
  Term h7 = r7;
  Term h8 = r8;
  Term h20 = r20;
  Term h21 = r21;
  Term h22 = r22;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  u32 _v_34 = 0;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  Term _v_43 = 0;
  Term _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  Term _commands_1 = r0;
  u32 _world_24 = r1;
  u32 _world_25 = r2;
  u32 _world_26 = r3;
  Term _world_27 = r4;
  u32 _world_28 = r5;
  Term _world_29 = r6;
  Term _world_30 = r7;
  Term _world_31 = r8;
  u32 _world_32 = r9;
  u32 _world_33 = r10;
  u32 _world_34 = r11;
  u32 _world_35 = r12;
  u32 _world_36 = r13;
  u32 _world_37 = r14;
  u32 _world_38 = r15;
  u32 _world_39 = r16;
  u32 _world_40 = r17;
  u32 _world_41 = r18;
  u32 _world_42 = r19;
  Term _world_43 = r20;
  Term _world_44 = r21;
  Term _world_45 = r22;
  u32 _world_46 = r23;
  u32 _world_47 = r24;
  WL_SPIN
    if (term_aux(_commands_1) == CID_NIL) {
      _v_24 = _world_24;
      _v_25 = _world_25;
      _v_26 = _world_26;
      _v_27 = _world_27;
      _v_28 = _world_28;
      _v_29 = _world_29;
      _v_30 = _world_30;
      _v_31 = _world_31;
      _v_32 = _world_32;
      _v_33 = _world_33;
      _v_34 = _world_34;
      _v_35 = _world_35;
      _v_36 = _world_36;
      _v_37 = _world_37;
      _v_38 = _world_38;
      _v_39 = _world_39;
      _v_40 = _world_40;
      _v_41 = _world_41;
      _v_42 = _world_42;
      _v_43 = _world_43;
      _v_44 = _world_44;
      _v_45 = _world_45;
      _v_46 = _world_46;
      _v_47 = _world_47;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _commands_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _v_48 = 0;
      u32 _v_49 = 0;
      u32 _v_50 = 0;
      Term _v_51 = 0;
      u32 _v_52 = 0;
      Term _v_53 = 0;
      Term _v_54 = 0;
      Term _v_55 = 0;
      u32 _v_56 = 0;
      u32 _v_57 = 0;
      u32 _v_58 = 0;
      u32 _v_59 = 0;
      u32 _v_60 = 0;
      u32 _v_61 = 0;
      u32 _v_62 = 0;
      u32 _v_63 = 0;
      u32 _v_64 = 0;
      u32 _v_65 = 0;
      u32 _v_66 = 0;
      Term _v_67 = 0;
      Term _v_68 = 0;
      Term _v_69 = 0;
      u32 _v_70 = 0;
      u32 _v_71 = 0;
      u32 _v_72 = 0;
      u32 _v_73 = 0;
      u32 _v_74 = 0;
      Term _v_75 = 0;
      u32 _v_76 = 0;
      Term _v_77 = 0;
      Term _v_78 = 0;
      Term _v_79 = 0;
      u32 _v_80 = 0;
      u32 _v_81 = 0;
      u32 _v_82 = 0;
      u32 _v_83 = 0;
      u32 _v_84 = 0;
      u32 _v_85 = 0;
      u32 _v_86 = 0;
      u32 _v_87 = 0;
      u32 _v_88 = 0;
      u32 _v_89 = 0;
      u32 _v_90 = 0;
      Term _v_91 = 0;
      Term _v_92 = 0;
      Term _v_93 = 0;
      u32 _v_94 = 0;
      u32 _v_95 = 0;
      Term _o_0[24];
      if (spin_8(e, _o_0, _world_24, _world_25, _world_26, _world_27, _world_27 == h4 ? q4 : blk_loc(e.mem, _world_27), _world_28, _world_29, _world_30, _world_30 == h7 ? q7 : blk_loc(e.mem, _world_30), _world_31, _world_31 == h8 ? q8 : blk_loc(e.mem, _world_31), _world_32, _world_33, _world_34, _world_35, _world_36, _world_37, _world_38, _world_39, _world_40, _world_41, _world_42, _world_43, _world_43 == h20 ? q20 : blk_loc(e.mem, _world_43), _world_44, _world_44 == h21 ? q21 : blk_loc(e.mem, _world_44), _world_45, _world_45 == h22 ? q22 : blk_loc(e.mem, _world_45), _world_46, _world_47, _f_0, _f_0 == h22 ? q22 : _f_0 == h21 ? q21 : _f_0 == h20 ? q20 : _f_0 == h8 ? q8 : _f_0 == h7 ? q7 : _f_0 == h4 ? q4 : _f_0 == h0 ? q0 : blk_loc(e.mem, _f_0)) == 0) {
        return 0;
      }
      _v_72 = _o_0[0];
      _v_73 = _o_0[1];
      _v_74 = _o_0[2];
      _v_75 = _o_0[3];
      _v_76 = _o_0[4];
      _v_77 = _o_0[5];
      _v_78 = _o_0[6];
      _v_79 = _o_0[7];
      _v_80 = _o_0[8];
      _v_81 = _o_0[9];
      _v_82 = _o_0[10];
      _v_83 = _o_0[11];
      _v_84 = _o_0[12];
      _v_85 = _o_0[13];
      _v_86 = _o_0[14];
      _v_87 = _o_0[15];
      _v_88 = _o_0[16];
      _v_89 = _o_0[17];
      _v_90 = _o_0[18];
      _v_91 = _o_0[19];
      _v_92 = _o_0[20];
      _v_93 = _o_0[21];
      _v_94 = _o_0[22];
      _v_95 = _o_0[23];
      _v_48 = _v_72;
      _v_49 = _v_73;
      _v_50 = _v_74;
      _v_51 = _v_75;
      _v_52 = _v_76;
      _v_53 = _v_77;
      _v_54 = _v_78;
      _v_55 = _v_79;
      _v_56 = _v_80;
      _v_57 = _v_81;
      _v_58 = _v_82;
      _v_59 = _v_83;
      _v_60 = _v_84;
      _v_61 = _v_85;
      _v_62 = _v_86;
      _v_63 = _v_87;
      _v_64 = _v_88;
      _v_65 = _v_89;
      _v_66 = _v_90;
      _v_67 = _v_91;
      _v_68 = _v_92;
      _v_69 = _v_93;
      _v_70 = _v_94;
      _v_71 = _v_95;
      spare_free(e, cls_fit(2), _sp_0);
      r0 = _f_1;
      r1 = _v_48;
      r2 = _v_49;
      r3 = _v_50;
      r4 = _v_51;
      r5 = _v_52;
      r6 = _v_53;
      r7 = _v_54;
      r8 = _v_55;
      r9 = _v_56;
      r10 = _v_57;
      r11 = _v_58;
      r12 = _v_59;
      r13 = _v_60;
      r14 = _v_61;
      r15 = _v_62;
      r16 = _v_63;
      r17 = _v_64;
      r18 = _v_65;
      r19 = _v_66;
      r20 = _v_67;
      r21 = _v_68;
      r22 = _v_69;
      r23 = _v_70;
      r24 = _v_71;
      _commands_1 = r0;
      _world_24 = r1;
      _world_25 = r2;
      _world_26 = r3;
      _world_27 = r4;
      _world_28 = r5;
      _world_29 = r6;
      _world_30 = r7;
      _world_31 = r8;
      _world_32 = r9;
      _world_33 = r10;
      _world_34 = r11;
      _world_35 = r12;
      _world_36 = r13;
      _world_37 = r14;
      _world_38 = r15;
      _world_39 = r16;
      _world_40 = r17;
      _world_41 = r18;
      _world_42 = r19;
      _world_43 = r20;
      _world_44 = r21;
      _world_45 = r22;
      _world_46 = r23;
      _world_47 = r24;
      WL_AGAIN(spin_20);
    }
  break;
  }
  o[0] = _v_24;
  o[1] = _v_25;
  o[2] = _v_26;
  o[3] = _v_27;
  o[4] = _v_28;
  o[5] = _v_29;
  o[6] = _v_30;
  o[7] = _v_31;
  o[8] = _v_32;
  o[9] = _v_33;
  o[10] = _v_34;
  o[11] = _v_35;
  o[12] = _v_36;
  o[13] = _v_37;
  o[14] = _v_38;
  o[15] = _v_39;
  o[16] = _v_40;
  o[17] = _v_41;
  o[18] = _v_42;
  o[19] = _v_43;
  o[20] = _v_44;
  o[21] = _v_45;
  o[22] = _v_46;
  o[23] = _v_47;
  return 1;
}

INLINE Term spin_21(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  u32 _v_70 = 0;
  u32 _v_71 = 0;
  u32 _v_72 = 0;
  Term _v_73 = 0;
  u32 _v_74 = 0;
  Term _v_75 = 0;
  Term _v_76 = 0;
  Term _v_77 = 0;
  u32 _v_78 = 0;
  u32 _v_79 = 0;
  u32 _v_80 = 0;
  u32 _v_81 = 0;
  u32 _v_82 = 0;
  u32 _v_83 = 0;
  u32 _v_84 = 0;
  u32 _v_85 = 0;
  u32 _v_86 = 0;
  u32 _v_87 = 0;
  u32 _v_88 = 0;
  Term _v_89 = 0;
  Term _v_90 = 0;
  Term _v_91 = 0;
  u32 _v_92 = 0;
  u32 _v_93 = 0;
  u32 _v_94 = 0;
  u32 _v_95 = 0;
  u32 _v_96 = 0;
  u32 _v_97 = 0;
  u32 _v_98 = 0;
  u32 _v_99 = 0;
  u32 _v_100 = 0;
  u32 _v_101 = 0;
  u32 _v_102 = 0;
  u32 _v_103 = 0;
  u32 _v_104 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  Term _world_6 = r6;
  Term _world_7 = r7;
  u32 _world_8 = r8;
  u32 _world_9 = r9;
  u32 _world_10 = r10;
  u32 _world_11 = r11;
  u32 _world_12 = r12;
  u32 _world_13 = r13;
  u32 _world_14 = r14;
  u32 _world_15 = r15;
  u32 _world_16 = r16;
  u32 _world_17 = r17;
  u32 _world_18 = r18;
  Term _world_19 = r19;
  Term _world_20 = r20;
  Term _world_21 = r21;
  u32 _world_22 = r22;
  u32 _world_23 = r23;
  WL_SPIN
    u32 _v_105 = 0;
    u32 _v_106 = 0;
    u32 _v_107 = 0;
    Term _v_108 = 0;
    u32 _v_109 = 0;
    Term _v_110 = 0;
    Term _v_111 = 0;
    Term _v_112 = 0;
    u32 _v_113 = 0;
    u32 _v_114 = 0;
    u32 _v_115 = 0;
    u32 _v_116 = 0;
    u32 _v_117 = 0;
    u32 _v_118 = 0;
    u32 _v_119 = 0;
    u32 _v_120 = 0;
    u32 _v_121 = 0;
    u32 _v_122 = 0;
    u32 _v_123 = 0;
    Term _v_124 = 0;
    Term _v_125 = 0;
    Term _v_126 = 0;
    u32 _v_127 = 0;
    u32 _v_128 = 0;
    u32 _v_129 = 0;
    u32 _v_130 = 0;
    u32 _v_131 = 0;
    u32 _v_132 = 0;
    u32 _v_133 = 0;
    u32 _v_134 = 0;
    u32 _v_135 = 0;
    u32 _v_136 = 0;
    u32 _v_137 = 0;
    u32 _v_138 = 0;
    u32 _v_139 = 0;
    Term _o_0[35];
    if (spin_17(e, _o_0, _world_0, _world_1, _world_2, _world_3, _world_3 == h3 ? q3 : blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_6 == h6 ? q6 : blk_loc(e.mem, _world_6), _world_7, _world_7 == h7 ? q7 : blk_loc(e.mem, _world_7), _world_8, _world_9, _world_10, _world_11, _world_12, _world_13, _world_14, _world_15, _world_16, _world_17, _world_18, _world_19, _world_19 == h19 ? q19 : blk_loc(e.mem, _world_19), _world_20, _world_20 == h20 ? q20 : blk_loc(e.mem, _world_20), _world_21, _world_21 == h21 ? q21 : blk_loc(e.mem, _world_21), _world_22, _world_23) == 0) {
      return 0;
    }
    _v_105 = _o_0[0];
    _v_106 = _o_0[1];
    _v_107 = _o_0[2];
    _v_108 = _o_0[3];
    _v_109 = _o_0[4];
    _v_110 = _o_0[5];
    _v_111 = _o_0[6];
    _v_112 = _o_0[7];
    _v_113 = _o_0[8];
    _v_114 = _o_0[9];
    _v_115 = _o_0[10];
    _v_116 = _o_0[11];
    _v_117 = _o_0[12];
    _v_118 = _o_0[13];
    _v_119 = _o_0[14];
    _v_120 = _o_0[15];
    _v_121 = _o_0[16];
    _v_122 = _o_0[17];
    _v_123 = _o_0[18];
    _v_124 = _o_0[19];
    _v_125 = _o_0[20];
    _v_126 = _o_0[21];
    _v_127 = _o_0[22];
    _v_128 = _o_0[23];
    _v_129 = _o_0[24];
    _v_130 = _o_0[25];
    _v_131 = _o_0[26];
    _v_132 = _o_0[27];
    _v_133 = _o_0[28];
    _v_134 = _o_0[29];
    _v_135 = _o_0[30];
    _v_136 = _o_0[31];
    _v_137 = _o_0[32];
    _v_138 = _o_0[33];
    _v_139 = _o_0[34];
    _v_70 = _v_105;
    _v_71 = _v_106;
    _v_72 = _v_107;
    _v_73 = _v_108;
    _v_74 = _v_109;
    _v_75 = _v_110;
    _v_76 = _v_111;
    _v_77 = _v_112;
    _v_78 = _v_113;
    _v_79 = _v_114;
    _v_80 = _v_115;
    _v_81 = _v_116;
    _v_82 = _v_117;
    _v_83 = _v_118;
    _v_84 = _v_119;
    _v_85 = _v_120;
    _v_86 = _v_121;
    _v_87 = _v_122;
    _v_88 = _v_123;
    _v_89 = _v_124;
    _v_90 = _v_125;
    _v_91 = _v_126;
    _v_92 = _v_127;
    _v_93 = _v_128;
    _v_94 = _v_129;
    _v_95 = _v_130;
    _v_96 = _v_131;
    _v_97 = _v_132;
    _v_98 = _v_133;
    _v_99 = _v_134;
    _v_100 = _v_135;
    _v_101 = _v_136;
    _v_102 = _v_137;
    _v_103 = _v_138;
    _v_104 = _v_139;
  break;
  }
  o[0] = _v_70;
  o[1] = _v_71;
  o[2] = _v_72;
  o[3] = _v_73;
  o[4] = _v_74;
  o[5] = _v_75;
  o[6] = _v_76;
  o[7] = _v_77;
  o[8] = _v_78;
  o[9] = _v_79;
  o[10] = _v_80;
  o[11] = _v_81;
  o[12] = _v_82;
  o[13] = _v_83;
  o[14] = _v_84;
  o[15] = _v_85;
  o[16] = _v_86;
  o[17] = _v_87;
  o[18] = _v_88;
  o[19] = _v_89;
  o[20] = _v_90;
  o[21] = _v_91;
  o[22] = _v_92;
  o[23] = _v_93;
  o[24] = _v_94;
  o[25] = _v_95;
  o[26] = _v_96;
  o[27] = _v_97;
  o[28] = _v_98;
  o[29] = _v_99;
  o[30] = _v_100;
  o[31] = _v_101;
  o[32] = _v_102;
  o[33] = _v_103;
  o[34] = _v_104;
  return 1;
}

INLINE Term spin_22(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23, u32 r24, u32 r25, u32 r26, u32 r27, u32 r28, u32 r29, u32 r30, u32 r31, u32 r32, u32 r33, u32 r34, Term r35, u64 q35, Term r36, u64 q36, Term r37, u64 q37) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  Term h35 = r35;
  Term h36 = r36;
  Term h37 = r37;
  u32 _v_167 = 0;
  u32 _v_168 = 0;
  u32 _v_169 = 0;
  Term _v_170 = 0;
  u32 _v_171 = 0;
  Term _v_172 = 0;
  Term _v_173 = 0;
  Term _v_174 = 0;
  u32 _v_175 = 0;
  u32 _v_176 = 0;
  u32 _v_177 = 0;
  u32 _v_178 = 0;
  u32 _v_179 = 0;
  u32 _v_180 = 0;
  u32 _v_181 = 0;
  u32 _v_182 = 0;
  u32 _v_183 = 0;
  u32 _v_184 = 0;
  u32 _v_185 = 0;
  Term _v_186 = 0;
  Term _v_187 = 0;
  Term _v_188 = 0;
  u32 _v_189 = 0;
  u32 _v_190 = 0;
  Term _v_191 = 0;
  Term _v_192 = 0;
  Term _v_193 = 0;
  u32 _pair_0 = r0;
  u32 _pair_1 = r1;
  u32 _pair_2 = r2;
  Term _pair_3 = r3;
  u32 _pair_4 = r4;
  Term _pair_5 = r5;
  Term _pair_6 = r6;
  Term _pair_7 = r7;
  u32 _pair_8 = r8;
  u32 _pair_9 = r9;
  u32 _pair_10 = r10;
  u32 _pair_11 = r11;
  u32 _pair_12 = r12;
  u32 _pair_13 = r13;
  u32 _pair_14 = r14;
  u32 _pair_15 = r15;
  u32 _pair_16 = r16;
  u32 _pair_17 = r17;
  u32 _pair_18 = r18;
  Term _pair_19 = r19;
  Term _pair_20 = r20;
  Term _pair_21 = r21;
  u32 _pair_22 = r22;
  u32 _pair_23 = r23;
  u32 _pair_24 = r24;
  u32 _pair_25 = r25;
  u32 _pair_26 = r26;
  u32 _pair_27 = r27;
  u32 _pair_28 = r28;
  u32 _pair_29 = r29;
  u32 _pair_30 = r30;
  u32 _pair_31 = r31;
  u32 _pair_32 = r32;
  u32 _pair_33 = r33;
  u32 _pair_34 = r34;
  Term _undo_0 = r35;
  Term _commands_0 = r36;
  Term _events_0 = r37;
  WL_SPIN
    u32 _v_194 = 0;
    u32 _v_195 = 0;
    u32 _v_196 = 0;
    Term _v_197 = 0;
    u32 _v_198 = 0;
    Term _v_199 = 0;
    Term _v_200 = 0;
    Term _v_201 = 0;
    u32 _v_202 = 0;
    u32 _v_203 = 0;
    u32 _v_204 = 0;
    u32 _v_205 = 0;
    u32 _v_206 = 0;
    u32 _v_207 = 0;
    u32 _v_208 = 0;
    u32 _v_209 = 0;
    u32 _v_210 = 0;
    u32 _v_211 = 0;
    u32 _v_212 = 0;
    Term _v_213 = 0;
    Term _v_214 = 0;
    Term _v_215 = 0;
    u32 _v_216 = 0;
    u32 _v_217 = 0;
    u32 _v_218 = 0;
    u32 _v_219 = 0;
    u32 _v_220 = 0;
    u32 _v_221 = 0;
    u32 _v_222 = 0;
    u32 _v_223 = 0;
    u32 _v_224 = 0;
    u32 _v_225 = 0;
    u32 _v_226 = 0;
    u32 _v_227 = 0;
    u32 _v_228 = 0;
    u32 _v_229 = 0;
    u32 _v_230 = 0;
    u32 _v_231 = 0;
    u32 _v_232 = 0;
    u32 _v_233 = 0;
    u32 _v_234 = 0;
    u32 _v_235 = 0;
    u32 _v_236 = 0;
    u32 _v_237 = 0;
    u32 _v_238 = 0;
    u32 _v_239 = 0;
    Term _o_2[11];
    if (spin_13(e, _o_2, _pair_24, _pair_25, _pair_26, _pair_27, _pair_28, _pair_29, _pair_30, _pair_31, _pair_32, _pair_33, _pair_34) == 0) {
      return 0;
    }
    _v_229 = _o_2[0];
    _v_230 = _o_2[1];
    _v_231 = _o_2[2];
    _v_232 = _o_2[3];
    _v_233 = _o_2[4];
    _v_234 = _o_2[5];
    _v_235 = _o_2[6];
    _v_236 = _o_2[7];
    _v_237 = _o_2[8];
    _v_238 = _o_2[9];
    _v_239 = _o_2[10];
    _v_218 = _v_229;
    _v_219 = _v_230;
    _v_220 = _v_231;
    _v_221 = _v_232;
    _v_222 = _v_233;
    _v_223 = _v_234;
    _v_224 = _v_235;
    _v_225 = _v_236;
    _v_226 = _v_237;
    _v_227 = _v_238;
    _v_228 = _v_239;
    u32 _v_240 = 0;
    u32 _v_241 = 0;
    u32 _v_242 = 0;
    Term _v_243 = 0;
    u32 _v_244 = 0;
    Term _v_245 = 0;
    Term _v_246 = 0;
    Term _v_247 = 0;
    u32 _v_248 = 0;
    u32 _v_249 = 0;
    u32 _v_250 = 0;
    u32 _v_251 = 0;
    u32 _v_252 = 0;
    u32 _v_253 = 0;
    u32 _v_254 = 0;
    u32 _v_255 = 0;
    u32 _v_256 = 0;
    u32 _v_257 = 0;
    u32 _v_258 = 0;
    Term _v_259 = 0;
    Term _v_260 = 0;
    Term _v_261 = 0;
    u32 _v_262 = 0;
    u32 _v_263 = 0;
    Term _o_3[24];
    if (spin_14(e, _o_3, _pair_0, _pair_1, _pair_2, _pair_3, _pair_3 == h3 ? q3 : blk_loc(e.mem, _pair_3), _pair_4, _pair_5, _pair_6, _pair_6 == h6 ? q6 : blk_loc(e.mem, _pair_6), _pair_7, _pair_7 == h7 ? q7 : blk_loc(e.mem, _pair_7), _pair_8, _pair_9, _pair_10, _pair_11, _pair_12, _pair_13, _pair_14, _pair_15, _pair_16, _pair_17, _pair_18, _pair_19, _pair_19 == h19 ? q19 : blk_loc(e.mem, _pair_19), _pair_20, _pair_20 == h20 ? q20 : blk_loc(e.mem, _pair_20), _pair_21, _pair_21 == h21 ? q21 : blk_loc(e.mem, _pair_21), _pair_22, _pair_23, _v_218, _v_219, _v_220, _v_221, _v_222, _v_223, _v_224, _v_225, _v_226, _v_227, _v_228) == 0) {
      return 0;
    }
    _v_240 = _o_3[0];
    _v_241 = _o_3[1];
    _v_242 = _o_3[2];
    _v_243 = _o_3[3];
    _v_244 = _o_3[4];
    _v_245 = _o_3[5];
    _v_246 = _o_3[6];
    _v_247 = _o_3[7];
    _v_248 = _o_3[8];
    _v_249 = _o_3[9];
    _v_250 = _o_3[10];
    _v_251 = _o_3[11];
    _v_252 = _o_3[12];
    _v_253 = _o_3[13];
    _v_254 = _o_3[14];
    _v_255 = _o_3[15];
    _v_256 = _o_3[16];
    _v_257 = _o_3[17];
    _v_258 = _o_3[18];
    _v_259 = _o_3[19];
    _v_260 = _o_3[20];
    _v_261 = _o_3[21];
    _v_262 = _o_3[22];
    _v_263 = _o_3[23];
    _v_194 = _v_240;
    _v_195 = _v_241;
    _v_196 = _v_242;
    _v_197 = _v_243;
    _v_198 = _v_244;
    _v_199 = _v_245;
    _v_200 = _v_246;
    _v_201 = _v_247;
    _v_202 = _v_248;
    _v_203 = _v_249;
    _v_204 = _v_250;
    _v_205 = _v_251;
    _v_206 = _v_252;
    _v_207 = _v_253;
    _v_208 = _v_254;
    _v_209 = _v_255;
    _v_210 = _v_256;
    _v_211 = _v_257;
    _v_212 = _v_258;
    _v_213 = _v_259;
    _v_214 = _v_260;
    _v_215 = _v_261;
    _v_216 = _v_262;
    _v_217 = _v_263;
    u64 _nd_0 = heap_alloc(e, cls_fit(11));
    e.mem[_nd_0 + 0] = _pair_24;
    e.mem[_nd_0 + 1] = _pair_25;
    e.mem[_nd_0 + 2] = _pair_26;
    e.mem[_nd_0 + 3] = _pair_27;
    e.mem[_nd_0 + 4] = _pair_28;
    e.mem[_nd_0 + 5] = _pair_29;
    e.mem[_nd_0 + 6] = _pair_30;
    e.mem[_nd_0 + 7] = _pair_31;
    e.mem[_nd_0 + 8] = _pair_32;
    e.mem[_nd_0 + 9] = _pair_33;
    e.mem[_nd_0 + 10] = _pair_34;
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_clo(FID________________BENDVY_SRC_ECS_MACHINE_RESET_TAKEN_0_C35, _nd_0));
    e.mem[_nd_3 + 1] = rfc_seal(e, _undo_0);
    _v_167 = _v_194;
    _v_168 = _v_195;
    _v_169 = _v_196;
    _v_170 = _v_197;
    _v_171 = _v_198;
    _v_172 = _v_199;
    _v_173 = _v_200;
    _v_174 = _v_201;
    _v_175 = _v_202;
    _v_176 = _v_203;
    _v_177 = _v_204;
    _v_178 = _v_205;
    _v_179 = _v_206;
    _v_180 = _v_207;
    _v_181 = _v_208;
    _v_182 = _v_209;
    _v_183 = _v_210;
    _v_184 = _v_211;
    _v_185 = _v_212;
    _v_186 = _v_213;
    _v_187 = _v_214;
    _v_188 = _v_215;
    _v_189 = _v_216;
    _v_190 = _v_217;
    _v_191 = term_ctr(CID_CON, _nd_3);
    _v_192 = _commands_0;
    _v_193 = _events_0;
  break;
  }
  o[0] = _v_167;
  o[1] = _v_168;
  o[2] = _v_169;
  o[3] = _v_170;
  o[4] = _v_171;
  o[5] = _v_172;
  o[6] = _v_173;
  o[7] = _v_174;
  o[8] = _v_175;
  o[9] = _v_176;
  o[10] = _v_177;
  o[11] = _v_178;
  o[12] = _v_179;
  o[13] = _v_180;
  o[14] = _v_181;
  o[15] = _v_182;
  o[16] = _v_183;
  o[17] = _v_184;
  o[18] = _v_185;
  o[19] = _v_186;
  o[20] = _v_187;
  o[21] = _v_188;
  o[22] = _v_189;
  o[23] = _v_190;
  o[24] = _v_191;
  o[25] = _v_192;
  o[26] = _v_193;
  return 1;
}

INLINE Term spin_23(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23, u32 r24, u32 r25, u32 r26, u32 r27, u32 r28, u32 r29, u32 r30, u32 r31, u32 r32, u32 r33, u32 r34, Term r35, u64 q35, Term r36, u64 q36, Term r37, u64 q37, u32 r38, u32 r39, u32 r40) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  Term h35 = r35;
  Term h36 = r36;
  Term h37 = r37;
  u32 _v_97 = 0;
  u32 _v_98 = 0;
  u32 _v_99 = 0;
  Term _v_100 = 0;
  u32 _v_101 = 0;
  Term _v_102 = 0;
  Term _v_103 = 0;
  Term _v_104 = 0;
  u32 _v_105 = 0;
  u32 _v_106 = 0;
  u32 _v_107 = 0;
  u32 _v_108 = 0;
  u32 _v_109 = 0;
  u32 _v_110 = 0;
  u32 _v_111 = 0;
  u32 _v_112 = 0;
  u32 _v_113 = 0;
  u32 _v_114 = 0;
  u32 _v_115 = 0;
  Term _v_116 = 0;
  Term _v_117 = 0;
  Term _v_118 = 0;
  u32 _v_119 = 0;
  u32 _v_120 = 0;
  Term _v_121 = 0;
  Term _v_122 = 0;
  Term _v_123 = 0;
  u32 _pair_0 = r0;
  u32 _pair_1 = r1;
  u32 _pair_2 = r2;
  Term _pair_3 = r3;
  u32 _pair_4 = r4;
  Term _pair_5 = r5;
  Term _pair_6 = r6;
  Term _pair_7 = r7;
  u32 _pair_8 = r8;
  u32 _pair_9 = r9;
  u32 _pair_10 = r10;
  u32 _pair_11 = r11;
  u32 _pair_12 = r12;
  u32 _pair_13 = r13;
  u32 _pair_14 = r14;
  u32 _pair_15 = r15;
  u32 _pair_16 = r16;
  u32 _pair_17 = r17;
  u32 _pair_18 = r18;
  Term _pair_19 = r19;
  Term _pair_20 = r20;
  Term _pair_21 = r21;
  u32 _pair_22 = r22;
  u32 _pair_23 = r23;
  u32 _pair_24 = r24;
  u32 _pair_25 = r25;
  u32 _pair_26 = r26;
  u32 _pair_27 = r27;
  u32 _pair_28 = r28;
  u32 _pair_29 = r29;
  u32 _pair_30 = r30;
  u32 _pair_31 = r31;
  u32 _pair_32 = r32;
  u32 _pair_33 = r33;
  u32 _pair_34 = r34;
  Term _undo_0 = r35;
  Term _commands_0 = r36;
  Term _events_0 = r37;
  u32 _value_2 = r38;
  u32 _value_3 = r39;
  u32 _skipSame_1 = r40;
  WL_SPIN
    u32 _v_124 = 0;
    u32 _v_125 = 0;
    u32 _v_126 = 0;
    Term _v_127 = 0;
    u32 _v_128 = 0;
    Term _v_129 = 0;
    Term _v_130 = 0;
    Term _v_131 = 0;
    u32 _v_132 = 0;
    u32 _v_133 = 0;
    u32 _v_134 = 0;
    u32 _v_135 = 0;
    u32 _v_136 = 0;
    u32 _v_137 = 0;
    u32 _v_138 = 0;
    u32 _v_139 = 0;
    u32 _v_140 = 0;
    u32 _v_141 = 0;
    u32 _v_142 = 0;
    Term _v_143 = 0;
    Term _v_144 = 0;
    Term _v_145 = 0;
    u32 _v_146 = 0;
    u32 _v_147 = 0;
    u32 _v_148 = 0;
    u32 _v_149 = 0;
    u32 _v_150 = 0;
    u32 _v_151 = 0;
    u32 _v_152 = 0;
    u32 _v_153 = 0;
    u32 _v_154 = 0;
    u32 _v_155 = 0;
    u32 _v_156 = 0;
    u32 _v_157 = 0;
    u32 _v_158 = 0;
    u32 _v_159 = 0;
    u32 _v_160 = 0;
    u32 _v_161 = 0;
    u32 _v_162 = 0;
    u32 _v_163 = 0;
    u32 _v_164 = 0;
    u32 _v_165 = 0;
    u32 _v_166 = 0;
    u32 _v_167 = 0;
    u32 _v_168 = 0;
    u32 _v_169 = 0;
    Term _o_1[11];
    if (spin_18(e, _o_1, _pair_24, _pair_25, _pair_26, _pair_27, _pair_28, _pair_29, _pair_30, _pair_31, _pair_32, _pair_33, _pair_34, _value_2, _value_3, _skipSame_1) == 0) {
      return 0;
    }
    _v_159 = _o_1[0];
    _v_160 = _o_1[1];
    _v_161 = _o_1[2];
    _v_162 = _o_1[3];
    _v_163 = _o_1[4];
    _v_164 = _o_1[5];
    _v_165 = _o_1[6];
    _v_166 = _o_1[7];
    _v_167 = _o_1[8];
    _v_168 = _o_1[9];
    _v_169 = _o_1[10];
    _v_148 = _v_159;
    _v_149 = _v_160;
    _v_150 = _v_161;
    _v_151 = _v_162;
    _v_152 = _v_163;
    _v_153 = _v_164;
    _v_154 = _v_165;
    _v_155 = _v_166;
    _v_156 = _v_167;
    _v_157 = _v_168;
    _v_158 = _v_169;
    u32 _v_170 = 0;
    u32 _v_171 = 0;
    u32 _v_172 = 0;
    Term _v_173 = 0;
    u32 _v_174 = 0;
    Term _v_175 = 0;
    Term _v_176 = 0;
    Term _v_177 = 0;
    u32 _v_178 = 0;
    u32 _v_179 = 0;
    u32 _v_180 = 0;
    u32 _v_181 = 0;
    u32 _v_182 = 0;
    u32 _v_183 = 0;
    u32 _v_184 = 0;
    u32 _v_185 = 0;
    u32 _v_186 = 0;
    u32 _v_187 = 0;
    u32 _v_188 = 0;
    Term _v_189 = 0;
    Term _v_190 = 0;
    Term _v_191 = 0;
    u32 _v_192 = 0;
    u32 _v_193 = 0;
    Term _o_2[24];
    if (spin_14(e, _o_2, _pair_0, _pair_1, _pair_2, _pair_3, _pair_3 == h3 ? q3 : blk_loc(e.mem, _pair_3), _pair_4, _pair_5, _pair_6, _pair_6 == h6 ? q6 : blk_loc(e.mem, _pair_6), _pair_7, _pair_7 == h7 ? q7 : blk_loc(e.mem, _pair_7), _pair_8, _pair_9, _pair_10, _pair_11, _pair_12, _pair_13, _pair_14, _pair_15, _pair_16, _pair_17, _pair_18, _pair_19, _pair_19 == h19 ? q19 : blk_loc(e.mem, _pair_19), _pair_20, _pair_20 == h20 ? q20 : blk_loc(e.mem, _pair_20), _pair_21, _pair_21 == h21 ? q21 : blk_loc(e.mem, _pair_21), _pair_22, _pair_23, _v_148, _v_149, _v_150, _v_151, _v_152, _v_153, _v_154, _v_155, _v_156, _v_157, _v_158) == 0) {
      return 0;
    }
    _v_170 = _o_2[0];
    _v_171 = _o_2[1];
    _v_172 = _o_2[2];
    _v_173 = _o_2[3];
    _v_174 = _o_2[4];
    _v_175 = _o_2[5];
    _v_176 = _o_2[6];
    _v_177 = _o_2[7];
    _v_178 = _o_2[8];
    _v_179 = _o_2[9];
    _v_180 = _o_2[10];
    _v_181 = _o_2[11];
    _v_182 = _o_2[12];
    _v_183 = _o_2[13];
    _v_184 = _o_2[14];
    _v_185 = _o_2[15];
    _v_186 = _o_2[16];
    _v_187 = _o_2[17];
    _v_188 = _o_2[18];
    _v_189 = _o_2[19];
    _v_190 = _o_2[20];
    _v_191 = _o_2[21];
    _v_192 = _o_2[22];
    _v_193 = _o_2[23];
    _v_124 = _v_170;
    _v_125 = _v_171;
    _v_126 = _v_172;
    _v_127 = _v_173;
    _v_128 = _v_174;
    _v_129 = _v_175;
    _v_130 = _v_176;
    _v_131 = _v_177;
    _v_132 = _v_178;
    _v_133 = _v_179;
    _v_134 = _v_180;
    _v_135 = _v_181;
    _v_136 = _v_182;
    _v_137 = _v_183;
    _v_138 = _v_184;
    _v_139 = _v_185;
    _v_140 = _v_186;
    _v_141 = _v_187;
    _v_142 = _v_188;
    _v_143 = _v_189;
    _v_144 = _v_190;
    _v_145 = _v_191;
    _v_146 = _v_192;
    _v_147 = _v_193;
    u64 _nd_0 = heap_alloc(e, cls_fit(11));
    e.mem[_nd_0 + 0] = _pair_24;
    e.mem[_nd_0 + 1] = _pair_25;
    e.mem[_nd_0 + 2] = _pair_26;
    e.mem[_nd_0 + 3] = _pair_27;
    e.mem[_nd_0 + 4] = _pair_28;
    e.mem[_nd_0 + 5] = _pair_29;
    e.mem[_nd_0 + 6] = _pair_30;
    e.mem[_nd_0 + 7] = _pair_31;
    e.mem[_nd_0 + 8] = _pair_32;
    e.mem[_nd_0 + 9] = _pair_33;
    e.mem[_nd_0 + 10] = _pair_34;
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_clo(FID_QUEUE_WRITE_TAKEN_0_C37, _nd_0));
    e.mem[_nd_3 + 1] = rfc_seal(e, _undo_0);
    _v_97 = _v_124;
    _v_98 = _v_125;
    _v_99 = _v_126;
    _v_100 = _v_127;
    _v_101 = _v_128;
    _v_102 = _v_129;
    _v_103 = _v_130;
    _v_104 = _v_131;
    _v_105 = _v_132;
    _v_106 = _v_133;
    _v_107 = _v_134;
    _v_108 = _v_135;
    _v_109 = _v_136;
    _v_110 = _v_137;
    _v_111 = _v_138;
    _v_112 = _v_139;
    _v_113 = _v_140;
    _v_114 = _v_141;
    _v_115 = _v_142;
    _v_116 = _v_143;
    _v_117 = _v_144;
    _v_118 = _v_145;
    _v_119 = _v_146;
    _v_120 = _v_147;
    _v_121 = term_ctr(CID_CON, _nd_3);
    _v_122 = _commands_0;
    _v_123 = _events_0;
  break;
  }
  o[0] = _v_97;
  o[1] = _v_98;
  o[2] = _v_99;
  o[3] = _v_100;
  o[4] = _v_101;
  o[5] = _v_102;
  o[6] = _v_103;
  o[7] = _v_104;
  o[8] = _v_105;
  o[9] = _v_106;
  o[10] = _v_107;
  o[11] = _v_108;
  o[12] = _v_109;
  o[13] = _v_110;
  o[14] = _v_111;
  o[15] = _v_112;
  o[16] = _v_113;
  o[17] = _v_114;
  o[18] = _v_115;
  o[19] = _v_116;
  o[20] = _v_117;
  o[21] = _v_118;
  o[22] = _v_119;
  o[23] = _v_120;
  o[24] = _v_121;
  o[25] = _v_122;
  o[26] = _v_123;
  return 1;
}

INLINE Term spin_24(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_26 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_27 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_19(e, _o_0, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_27 = _o_0[0];
    _v_26 = _v_27;
  break;
  }
  o[0] = _v_26;
  return 1;
}

INLINE Term spin_25(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23, Term r24, u64 q24) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  Term h24 = r24;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  u32 _v_54 = 0;
  Term _v_55 = 0;
  u32 _v_56 = 0;
  Term _v_57 = 0;
  Term _v_58 = 0;
  Term _v_59 = 0;
  u32 _v_60 = 0;
  u32 _v_61 = 0;
  u32 _v_62 = 0;
  u32 _v_63 = 0;
  u32 _v_64 = 0;
  u32 _v_65 = 0;
  u32 _v_66 = 0;
  u32 _v_67 = 0;
  u32 _v_68 = 0;
  u32 _v_69 = 0;
  u32 _v_70 = 0;
  Term _v_71 = 0;
  Term _v_72 = 0;
  Term _v_73 = 0;
  u32 _v_74 = 0;
  u32 _v_75 = 0;
  u32 _world_24 = r0;
  u32 _world_25 = r1;
  u32 _world_26 = r2;
  Term _world_27 = r3;
  u32 _world_28 = r4;
  Term _world_29 = r5;
  Term _world_30 = r6;
  Term _world_31 = r7;
  u32 _world_32 = r8;
  u32 _world_33 = r9;
  u32 _world_34 = r10;
  u32 _world_35 = r11;
  u32 _world_36 = r12;
  u32 _world_37 = r13;
  u32 _world_38 = r14;
  u32 _world_39 = r15;
  u32 _world_40 = r16;
  u32 _world_41 = r17;
  u32 _world_42 = r18;
  Term _world_43 = r19;
  Term _world_44 = r20;
  Term _world_45 = r21;
  u32 _world_46 = r22;
  u32 _world_47 = r23;
  Term _commands_1 = r24;
  WL_SPIN
    u32 _v_76 = 0;
    u32 _v_77 = 0;
    u32 _v_78 = 0;
    Term _v_79 = 0;
    u32 _v_80 = 0;
    Term _v_81 = 0;
    Term _v_82 = 0;
    Term _v_83 = 0;
    u32 _v_84 = 0;
    u32 _v_85 = 0;
    u32 _v_86 = 0;
    u32 _v_87 = 0;
    u32 _v_88 = 0;
    u32 _v_89 = 0;
    u32 _v_90 = 0;
    u32 _v_91 = 0;
    u32 _v_92 = 0;
    u32 _v_93 = 0;
    u32 _v_94 = 0;
    Term _v_95 = 0;
    Term _v_96 = 0;
    Term _v_97 = 0;
    u32 _v_98 = 0;
    u32 _v_99 = 0;
    Term _o_2[24];
    if (spin_20(e, _o_2, _commands_1, _commands_1 == h24 ? q24 : blk_loc(e.mem, _commands_1), _world_24, _world_25, _world_26, _world_27, _world_27 == h3 ? q3 : blk_loc(e.mem, _world_27), _world_28, _world_29, _world_30, _world_30 == h6 ? q6 : blk_loc(e.mem, _world_30), _world_31, _world_31 == h7 ? q7 : blk_loc(e.mem, _world_31), _world_32, _world_33, _world_34, _world_35, _world_36, _world_37, _world_38, _world_39, _world_40, _world_41, _world_42, _world_43, _world_43 == h19 ? q19 : blk_loc(e.mem, _world_43), _world_44, _world_44 == h20 ? q20 : blk_loc(e.mem, _world_44), _world_45, _world_45 == h21 ? q21 : blk_loc(e.mem, _world_45), _world_46, _world_47) == 0) {
      return 0;
    }
    _v_76 = _o_2[0];
    _v_77 = _o_2[1];
    _v_78 = _o_2[2];
    _v_79 = _o_2[3];
    _v_80 = _o_2[4];
    _v_81 = _o_2[5];
    _v_82 = _o_2[6];
    _v_83 = _o_2[7];
    _v_84 = _o_2[8];
    _v_85 = _o_2[9];
    _v_86 = _o_2[10];
    _v_87 = _o_2[11];
    _v_88 = _o_2[12];
    _v_89 = _o_2[13];
    _v_90 = _o_2[14];
    _v_91 = _o_2[15];
    _v_92 = _o_2[16];
    _v_93 = _o_2[17];
    _v_94 = _o_2[18];
    _v_95 = _o_2[19];
    _v_96 = _o_2[20];
    _v_97 = _o_2[21];
    _v_98 = _o_2[22];
    _v_99 = _o_2[23];
    _v_52 = _v_76;
    _v_53 = _v_77;
    _v_54 = _v_78;
    _v_55 = _v_79;
    _v_56 = _v_80;
    _v_57 = _v_81;
    _v_58 = _v_82;
    _v_59 = _v_83;
    _v_60 = _v_84;
    _v_61 = _v_85;
    _v_62 = _v_86;
    _v_63 = _v_87;
    _v_64 = _v_88;
    _v_65 = _v_89;
    _v_66 = _v_90;
    _v_67 = _v_91;
    _v_68 = _v_92;
    _v_69 = _v_93;
    _v_70 = _v_94;
    _v_71 = _v_95;
    _v_72 = _v_96;
    _v_73 = _v_97;
    _v_74 = _v_98;
    _v_75 = _v_99;
  break;
  }
  o[0] = _v_52;
  o[1] = _v_53;
  o[2] = _v_54;
  o[3] = _v_55;
  o[4] = _v_56;
  o[5] = _v_57;
  o[6] = _v_58;
  o[7] = _v_59;
  o[8] = _v_60;
  o[9] = _v_61;
  o[10] = _v_62;
  o[11] = _v_63;
  o[12] = _v_64;
  o[13] = _v_65;
  o[14] = _v_66;
  o[15] = _v_67;
  o[16] = _v_68;
  o[17] = _v_69;
  o[18] = _v_70;
  o[19] = _v_71;
  o[20] = _v_72;
  o[21] = _v_73;
  o[22] = _v_74;
  o[23] = _v_75;
  return 1;
}

INLINE Term spin_26(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23, Term r24, u64 q24, Term r25, u64 q25, Term r26, u64 q26, u32 r27, u32 r28, u32 r29) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  Term h24 = r24;
  Term h25 = r25;
  Term h26 = r26;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  Term _v_30 = 0;
  u32 _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  u32 _v_45 = 0;
  Term _v_46 = 0;
  Term _v_47 = 0;
  Term _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  Term _v_51 = 0;
  Term _v_52 = 0;
  Term _v_53 = 0;
  u32 _tx_27 = r0;
  u32 _tx_28 = r1;
  u32 _tx_29 = r2;
  Term _tx_30 = r3;
  u32 _tx_31 = r4;
  Term _tx_32 = r5;
  Term _tx_33 = r6;
  Term _tx_34 = r7;
  u32 _tx_35 = r8;
  u32 _tx_36 = r9;
  u32 _tx_37 = r10;
  u32 _tx_38 = r11;
  u32 _tx_39 = r12;
  u32 _tx_40 = r13;
  u32 _tx_41 = r14;
  u32 _tx_42 = r15;
  u32 _tx_43 = r16;
  u32 _tx_44 = r17;
  u32 _tx_45 = r18;
  Term _tx_46 = r19;
  Term _tx_47 = r20;
  Term _tx_48 = r21;
  u32 _tx_49 = r22;
  u32 _tx_50 = r23;
  Term _tx_51 = r24;
  Term _tx_52 = r25;
  Term _tx_53 = r26;
  u32 _value_0 = r27;
  u32 _value_1 = r28;
  u32 _skipSame_0 = r29;
  WL_SPIN
    u32 _v_54 = 0;
    u32 _v_55 = 0;
    u32 _v_56 = 0;
    Term _v_57 = 0;
    u32 _v_58 = 0;
    Term _v_59 = 0;
    Term _v_60 = 0;
    Term _v_61 = 0;
    u32 _v_62 = 0;
    u32 _v_63 = 0;
    u32 _v_64 = 0;
    u32 _v_65 = 0;
    u32 _v_66 = 0;
    u32 _v_67 = 0;
    u32 _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    Term _v_73 = 0;
    Term _v_74 = 0;
    Term _v_75 = 0;
    u32 _v_76 = 0;
    u32 _v_77 = 0;
    u32 _v_78 = 0;
    u32 _v_79 = 0;
    u32 _v_80 = 0;
    u32 _v_81 = 0;
    u32 _v_82 = 0;
    u32 _v_83 = 0;
    u32 _v_84 = 0;
    u32 _v_85 = 0;
    u32 _v_86 = 0;
    u32 _v_87 = 0;
    u32 _v_88 = 0;
    u32 _v_89 = 0;
    u32 _v_90 = 0;
    u32 _v_91 = 0;
    Term _v_92 = 0;
    u32 _v_93 = 0;
    Term _v_94 = 0;
    Term _v_95 = 0;
    Term _v_96 = 0;
    u32 _v_97 = 0;
    u32 _v_98 = 0;
    u32 _v_99 = 0;
    u32 _v_100 = 0;
    u32 _v_101 = 0;
    u32 _v_102 = 0;
    u32 _v_103 = 0;
    u32 _v_104 = 0;
    u32 _v_105 = 0;
    u32 _v_106 = 0;
    u32 _v_107 = 0;
    Term _v_108 = 0;
    Term _v_109 = 0;
    Term _v_110 = 0;
    u32 _v_111 = 0;
    u32 _v_112 = 0;
    u32 _v_113 = 0;
    u32 _v_114 = 0;
    u32 _v_115 = 0;
    u32 _v_116 = 0;
    u32 _v_117 = 0;
    u32 _v_118 = 0;
    u32 _v_119 = 0;
    u32 _v_120 = 0;
    u32 _v_121 = 0;
    u32 _v_122 = 0;
    u32 _v_123 = 0;
    Term _o_0[35];
    if (spin_21(e, _o_0, _tx_27, _tx_28, _tx_29, _tx_30, _tx_30 == h3 ? q3 : blk_loc(e.mem, _tx_30), _tx_31, _tx_32, _tx_33, _tx_33 == h6 ? q6 : blk_loc(e.mem, _tx_33), _tx_34, _tx_34 == h7 ? q7 : blk_loc(e.mem, _tx_34), _tx_35, _tx_36, _tx_37, _tx_38, _tx_39, _tx_40, _tx_41, _tx_42, _tx_43, _tx_44, _tx_45, _tx_46, _tx_46 == h19 ? q19 : blk_loc(e.mem, _tx_46), _tx_47, _tx_47 == h20 ? q20 : blk_loc(e.mem, _tx_47), _tx_48, _tx_48 == h21 ? q21 : blk_loc(e.mem, _tx_48), _tx_49, _tx_50) == 0) {
      return 0;
    }
    _v_89 = _o_0[0];
    _v_90 = _o_0[1];
    _v_91 = _o_0[2];
    _v_92 = _o_0[3];
    _v_93 = _o_0[4];
    _v_94 = _o_0[5];
    _v_95 = _o_0[6];
    _v_96 = _o_0[7];
    _v_97 = _o_0[8];
    _v_98 = _o_0[9];
    _v_99 = _o_0[10];
    _v_100 = _o_0[11];
    _v_101 = _o_0[12];
    _v_102 = _o_0[13];
    _v_103 = _o_0[14];
    _v_104 = _o_0[15];
    _v_105 = _o_0[16];
    _v_106 = _o_0[17];
    _v_107 = _o_0[18];
    _v_108 = _o_0[19];
    _v_109 = _o_0[20];
    _v_110 = _o_0[21];
    _v_111 = _o_0[22];
    _v_112 = _o_0[23];
    _v_113 = _o_0[24];
    _v_114 = _o_0[25];
    _v_115 = _o_0[26];
    _v_116 = _o_0[27];
    _v_117 = _o_0[28];
    _v_118 = _o_0[29];
    _v_119 = _o_0[30];
    _v_120 = _o_0[31];
    _v_121 = _o_0[32];
    _v_122 = _o_0[33];
    _v_123 = _o_0[34];
    _v_54 = _v_89;
    _v_55 = _v_90;
    _v_56 = _v_91;
    _v_57 = _v_92;
    _v_58 = _v_93;
    _v_59 = _v_94;
    _v_60 = _v_95;
    _v_61 = _v_96;
    _v_62 = _v_97;
    _v_63 = _v_98;
    _v_64 = _v_99;
    _v_65 = _v_100;
    _v_66 = _v_101;
    _v_67 = _v_102;
    _v_68 = _v_103;
    _v_69 = _v_104;
    _v_70 = _v_105;
    _v_71 = _v_106;
    _v_72 = _v_107;
    _v_73 = _v_108;
    _v_74 = _v_109;
    _v_75 = _v_110;
    _v_76 = _v_111;
    _v_77 = _v_112;
    _v_78 = _v_113;
    _v_79 = _v_114;
    _v_80 = _v_115;
    _v_81 = _v_116;
    _v_82 = _v_117;
    _v_83 = _v_118;
    _v_84 = _v_119;
    _v_85 = _v_120;
    _v_86 = _v_121;
    _v_87 = _v_122;
    _v_88 = _v_123;
    u32 _v_124 = 0;
    u32 _v_125 = 0;
    u32 _v_126 = 0;
    Term _v_127 = 0;
    u32 _v_128 = 0;
    Term _v_129 = 0;
    Term _v_130 = 0;
    Term _v_131 = 0;
    u32 _v_132 = 0;
    u32 _v_133 = 0;
    u32 _v_134 = 0;
    u32 _v_135 = 0;
    u32 _v_136 = 0;
    u32 _v_137 = 0;
    u32 _v_138 = 0;
    u32 _v_139 = 0;
    u32 _v_140 = 0;
    u32 _v_141 = 0;
    u32 _v_142 = 0;
    Term _v_143 = 0;
    Term _v_144 = 0;
    Term _v_145 = 0;
    u32 _v_146 = 0;
    u32 _v_147 = 0;
    Term _v_148 = 0;
    Term _v_149 = 0;
    Term _v_150 = 0;
    Term _o_1[27];
    if (spin_23(e, _o_1, _v_54, _v_55, _v_56, _v_57, _v_57 == h26 ? q26 : _v_57 == h25 ? q25 : _v_57 == h24 ? q24 : _v_57 == h21 ? q21 : _v_57 == h20 ? q20 : _v_57 == h19 ? q19 : _v_57 == h7 ? q7 : _v_57 == h6 ? q6 : _v_57 == h3 ? q3 : blk_loc(e.mem, _v_57), _v_58, _v_59, _v_60, _v_60 == h26 ? q26 : _v_60 == h25 ? q25 : _v_60 == h24 ? q24 : _v_60 == h21 ? q21 : _v_60 == h20 ? q20 : _v_60 == h19 ? q19 : _v_60 == h7 ? q7 : _v_60 == h6 ? q6 : _v_60 == h3 ? q3 : blk_loc(e.mem, _v_60), _v_61, _v_61 == h26 ? q26 : _v_61 == h25 ? q25 : _v_61 == h24 ? q24 : _v_61 == h21 ? q21 : _v_61 == h20 ? q20 : _v_61 == h19 ? q19 : _v_61 == h7 ? q7 : _v_61 == h6 ? q6 : _v_61 == h3 ? q3 : blk_loc(e.mem, _v_61), _v_62, _v_63, _v_64, _v_65, _v_66, _v_67, _v_68, _v_69, _v_70, _v_71, _v_72, _v_73, _v_73 == h26 ? q26 : _v_73 == h25 ? q25 : _v_73 == h24 ? q24 : _v_73 == h21 ? q21 : _v_73 == h20 ? q20 : _v_73 == h19 ? q19 : _v_73 == h7 ? q7 : _v_73 == h6 ? q6 : _v_73 == h3 ? q3 : blk_loc(e.mem, _v_73), _v_74, _v_74 == h26 ? q26 : _v_74 == h25 ? q25 : _v_74 == h24 ? q24 : _v_74 == h21 ? q21 : _v_74 == h20 ? q20 : _v_74 == h19 ? q19 : _v_74 == h7 ? q7 : _v_74 == h6 ? q6 : _v_74 == h3 ? q3 : blk_loc(e.mem, _v_74), _v_75, _v_75 == h26 ? q26 : _v_75 == h25 ? q25 : _v_75 == h24 ? q24 : _v_75 == h21 ? q21 : _v_75 == h20 ? q20 : _v_75 == h19 ? q19 : _v_75 == h7 ? q7 : _v_75 == h6 ? q6 : _v_75 == h3 ? q3 : blk_loc(e.mem, _v_75), _v_76, _v_77, _v_78, _v_79, _v_80, _v_81, _v_82, _v_83, _v_84, _v_85, _v_86, _v_87, _v_88, _tx_51, _tx_51 == h24 ? q24 : blk_loc(e.mem, _tx_51), _tx_52, _tx_52 == h25 ? q25 : blk_loc(e.mem, _tx_52), _tx_53, _tx_53 == h26 ? q26 : blk_loc(e.mem, _tx_53), _value_0, _value_1, _skipSame_0) == 0) {
      return 0;
    }
    _v_124 = _o_1[0];
    _v_125 = _o_1[1];
    _v_126 = _o_1[2];
    _v_127 = _o_1[3];
    _v_128 = _o_1[4];
    _v_129 = _o_1[5];
    _v_130 = _o_1[6];
    _v_131 = _o_1[7];
    _v_132 = _o_1[8];
    _v_133 = _o_1[9];
    _v_134 = _o_1[10];
    _v_135 = _o_1[11];
    _v_136 = _o_1[12];
    _v_137 = _o_1[13];
    _v_138 = _o_1[14];
    _v_139 = _o_1[15];
    _v_140 = _o_1[16];
    _v_141 = _o_1[17];
    _v_142 = _o_1[18];
    _v_143 = _o_1[19];
    _v_144 = _o_1[20];
    _v_145 = _o_1[21];
    _v_146 = _o_1[22];
    _v_147 = _o_1[23];
    _v_148 = _o_1[24];
    _v_149 = _o_1[25];
    _v_150 = _o_1[26];
    _v_27 = _v_124;
    _v_28 = _v_125;
    _v_29 = _v_126;
    _v_30 = _v_127;
    _v_31 = _v_128;
    _v_32 = _v_129;
    _v_33 = _v_130;
    _v_34 = _v_131;
    _v_35 = _v_132;
    _v_36 = _v_133;
    _v_37 = _v_134;
    _v_38 = _v_135;
    _v_39 = _v_136;
    _v_40 = _v_137;
    _v_41 = _v_138;
    _v_42 = _v_139;
    _v_43 = _v_140;
    _v_44 = _v_141;
    _v_45 = _v_142;
    _v_46 = _v_143;
    _v_47 = _v_144;
    _v_48 = _v_145;
    _v_49 = _v_146;
    _v_50 = _v_147;
    _v_51 = _v_148;
    _v_52 = _v_149;
    _v_53 = _v_150;
  break;
  }
  o[0] = _v_27;
  o[1] = _v_28;
  o[2] = _v_29;
  o[3] = _v_30;
  o[4] = _v_31;
  o[5] = _v_32;
  o[6] = _v_33;
  o[7] = _v_34;
  o[8] = _v_35;
  o[9] = _v_36;
  o[10] = _v_37;
  o[11] = _v_38;
  o[12] = _v_39;
  o[13] = _v_40;
  o[14] = _v_41;
  o[15] = _v_42;
  o[16] = _v_43;
  o[17] = _v_44;
  o[18] = _v_45;
  o[19] = _v_46;
  o[20] = _v_47;
  o[21] = _v_48;
  o[22] = _v_49;
  o[23] = _v_50;
  o[24] = _v_51;
  o[25] = _v_52;
  o[26] = _v_53;
  return 1;
}

INLINE Term spin_27(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23, Term r24, u64 q24, Term r25, u64 q25, Term r26, u64 q26) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  Term h24 = r24;
  Term h25 = r25;
  Term h26 = r26;
  u32 _v_178 = 0;
  u32 _v_179 = 0;
  u32 _v_180 = 0;
  Term _v_181 = 0;
  u32 _v_182 = 0;
  Term _v_183 = 0;
  Term _v_184 = 0;
  Term _v_185 = 0;
  u32 _v_186 = 0;
  u32 _v_187 = 0;
  u32 _v_188 = 0;
  u32 _v_189 = 0;
  u32 _v_190 = 0;
  u32 _v_191 = 0;
  u32 _v_192 = 0;
  u32 _v_193 = 0;
  u32 _v_194 = 0;
  u32 _v_195 = 0;
  u32 _v_196 = 0;
  Term _v_197 = 0;
  Term _v_198 = 0;
  Term _v_199 = 0;
  u32 _v_200 = 0;
  u32 _v_201 = 0;
  Term _v_202 = 0;
  Term _v_203 = 0;
  Term _v_204 = 0;
  u32 _tx_54 = r0;
  u32 _tx_55 = r1;
  u32 _tx_56 = r2;
  Term _tx_57 = r3;
  u32 _tx_58 = r4;
  Term _tx_59 = r5;
  Term _tx_60 = r6;
  Term _tx_61 = r7;
  u32 _tx_62 = r8;
  u32 _tx_63 = r9;
  u32 _tx_64 = r10;
  u32 _tx_65 = r11;
  u32 _tx_66 = r12;
  u32 _tx_67 = r13;
  u32 _tx_68 = r14;
  u32 _tx_69 = r15;
  u32 _tx_70 = r16;
  u32 _tx_71 = r17;
  u32 _tx_72 = r18;
  Term _tx_73 = r19;
  Term _tx_74 = r20;
  Term _tx_75 = r21;
  u32 _tx_76 = r22;
  u32 _tx_77 = r23;
  Term _tx_78 = r24;
  Term _tx_79 = r25;
  Term _tx_80 = r26;
  WL_SPIN
    u32 _v_205 = 0;
    u32 _v_206 = 0;
    u32 _v_207 = 0;
    Term _v_208 = 0;
    u32 _v_209 = 0;
    Term _v_210 = 0;
    Term _v_211 = 0;
    Term _v_212 = 0;
    u32 _v_213 = 0;
    u32 _v_214 = 0;
    u32 _v_215 = 0;
    u32 _v_216 = 0;
    u32 _v_217 = 0;
    u32 _v_218 = 0;
    u32 _v_219 = 0;
    u32 _v_220 = 0;
    u32 _v_221 = 0;
    u32 _v_222 = 0;
    u32 _v_223 = 0;
    Term _v_224 = 0;
    Term _v_225 = 0;
    Term _v_226 = 0;
    u32 _v_227 = 0;
    u32 _v_228 = 0;
    u32 _v_229 = 0;
    u32 _v_230 = 0;
    u32 _v_231 = 0;
    u32 _v_232 = 0;
    u32 _v_233 = 0;
    u32 _v_234 = 0;
    u32 _v_235 = 0;
    u32 _v_236 = 0;
    u32 _v_237 = 0;
    u32 _v_238 = 0;
    u32 _v_239 = 0;
    u32 _v_240 = 0;
    u32 _v_241 = 0;
    u32 _v_242 = 0;
    Term _v_243 = 0;
    u32 _v_244 = 0;
    Term _v_245 = 0;
    Term _v_246 = 0;
    Term _v_247 = 0;
    u32 _v_248 = 0;
    u32 _v_249 = 0;
    u32 _v_250 = 0;
    u32 _v_251 = 0;
    u32 _v_252 = 0;
    u32 _v_253 = 0;
    u32 _v_254 = 0;
    u32 _v_255 = 0;
    u32 _v_256 = 0;
    u32 _v_257 = 0;
    u32 _v_258 = 0;
    Term _v_259 = 0;
    Term _v_260 = 0;
    Term _v_261 = 0;
    u32 _v_262 = 0;
    u32 _v_263 = 0;
    u32 _v_264 = 0;
    u32 _v_265 = 0;
    u32 _v_266 = 0;
    u32 _v_267 = 0;
    u32 _v_268 = 0;
    u32 _v_269 = 0;
    u32 _v_270 = 0;
    u32 _v_271 = 0;
    u32 _v_272 = 0;
    u32 _v_273 = 0;
    u32 _v_274 = 0;
    Term _o_3[35];
    if (spin_21(e, _o_3, _tx_54, _tx_55, _tx_56, _tx_57, _tx_57 == h3 ? q3 : blk_loc(e.mem, _tx_57), _tx_58, _tx_59, _tx_60, _tx_60 == h6 ? q6 : blk_loc(e.mem, _tx_60), _tx_61, _tx_61 == h7 ? q7 : blk_loc(e.mem, _tx_61), _tx_62, _tx_63, _tx_64, _tx_65, _tx_66, _tx_67, _tx_68, _tx_69, _tx_70, _tx_71, _tx_72, _tx_73, _tx_73 == h19 ? q19 : blk_loc(e.mem, _tx_73), _tx_74, _tx_74 == h20 ? q20 : blk_loc(e.mem, _tx_74), _tx_75, _tx_75 == h21 ? q21 : blk_loc(e.mem, _tx_75), _tx_76, _tx_77) == 0) {
      return 0;
    }
    _v_240 = _o_3[0];
    _v_241 = _o_3[1];
    _v_242 = _o_3[2];
    _v_243 = _o_3[3];
    _v_244 = _o_3[4];
    _v_245 = _o_3[5];
    _v_246 = _o_3[6];
    _v_247 = _o_3[7];
    _v_248 = _o_3[8];
    _v_249 = _o_3[9];
    _v_250 = _o_3[10];
    _v_251 = _o_3[11];
    _v_252 = _o_3[12];
    _v_253 = _o_3[13];
    _v_254 = _o_3[14];
    _v_255 = _o_3[15];
    _v_256 = _o_3[16];
    _v_257 = _o_3[17];
    _v_258 = _o_3[18];
    _v_259 = _o_3[19];
    _v_260 = _o_3[20];
    _v_261 = _o_3[21];
    _v_262 = _o_3[22];
    _v_263 = _o_3[23];
    _v_264 = _o_3[24];
    _v_265 = _o_3[25];
    _v_266 = _o_3[26];
    _v_267 = _o_3[27];
    _v_268 = _o_3[28];
    _v_269 = _o_3[29];
    _v_270 = _o_3[30];
    _v_271 = _o_3[31];
    _v_272 = _o_3[32];
    _v_273 = _o_3[33];
    _v_274 = _o_3[34];
    _v_205 = _v_240;
    _v_206 = _v_241;
    _v_207 = _v_242;
    _v_208 = _v_243;
    _v_209 = _v_244;
    _v_210 = _v_245;
    _v_211 = _v_246;
    _v_212 = _v_247;
    _v_213 = _v_248;
    _v_214 = _v_249;
    _v_215 = _v_250;
    _v_216 = _v_251;
    _v_217 = _v_252;
    _v_218 = _v_253;
    _v_219 = _v_254;
    _v_220 = _v_255;
    _v_221 = _v_256;
    _v_222 = _v_257;
    _v_223 = _v_258;
    _v_224 = _v_259;
    _v_225 = _v_260;
    _v_226 = _v_261;
    _v_227 = _v_262;
    _v_228 = _v_263;
    _v_229 = _v_264;
    _v_230 = _v_265;
    _v_231 = _v_266;
    _v_232 = _v_267;
    _v_233 = _v_268;
    _v_234 = _v_269;
    _v_235 = _v_270;
    _v_236 = _v_271;
    _v_237 = _v_272;
    _v_238 = _v_273;
    _v_239 = _v_274;
    u32 _v_275 = 0;
    u32 _v_276 = 0;
    u32 _v_277 = 0;
    Term _v_278 = 0;
    u32 _v_279 = 0;
    Term _v_280 = 0;
    Term _v_281 = 0;
    Term _v_282 = 0;
    u32 _v_283 = 0;
    u32 _v_284 = 0;
    u32 _v_285 = 0;
    u32 _v_286 = 0;
    u32 _v_287 = 0;
    u32 _v_288 = 0;
    u32 _v_289 = 0;
    u32 _v_290 = 0;
    u32 _v_291 = 0;
    u32 _v_292 = 0;
    u32 _v_293 = 0;
    Term _v_294 = 0;
    Term _v_295 = 0;
    Term _v_296 = 0;
    u32 _v_297 = 0;
    u32 _v_298 = 0;
    Term _v_299 = 0;
    Term _v_300 = 0;
    Term _v_301 = 0;
    Term _o_4[27];
    if (spin_22(e, _o_4, _v_205, _v_206, _v_207, _v_208, _v_208 == h26 ? q26 : _v_208 == h25 ? q25 : _v_208 == h24 ? q24 : _v_208 == h21 ? q21 : _v_208 == h20 ? q20 : _v_208 == h19 ? q19 : _v_208 == h7 ? q7 : _v_208 == h6 ? q6 : _v_208 == h3 ? q3 : blk_loc(e.mem, _v_208), _v_209, _v_210, _v_211, _v_211 == h26 ? q26 : _v_211 == h25 ? q25 : _v_211 == h24 ? q24 : _v_211 == h21 ? q21 : _v_211 == h20 ? q20 : _v_211 == h19 ? q19 : _v_211 == h7 ? q7 : _v_211 == h6 ? q6 : _v_211 == h3 ? q3 : blk_loc(e.mem, _v_211), _v_212, _v_212 == h26 ? q26 : _v_212 == h25 ? q25 : _v_212 == h24 ? q24 : _v_212 == h21 ? q21 : _v_212 == h20 ? q20 : _v_212 == h19 ? q19 : _v_212 == h7 ? q7 : _v_212 == h6 ? q6 : _v_212 == h3 ? q3 : blk_loc(e.mem, _v_212), _v_213, _v_214, _v_215, _v_216, _v_217, _v_218, _v_219, _v_220, _v_221, _v_222, _v_223, _v_224, _v_224 == h26 ? q26 : _v_224 == h25 ? q25 : _v_224 == h24 ? q24 : _v_224 == h21 ? q21 : _v_224 == h20 ? q20 : _v_224 == h19 ? q19 : _v_224 == h7 ? q7 : _v_224 == h6 ? q6 : _v_224 == h3 ? q3 : blk_loc(e.mem, _v_224), _v_225, _v_225 == h26 ? q26 : _v_225 == h25 ? q25 : _v_225 == h24 ? q24 : _v_225 == h21 ? q21 : _v_225 == h20 ? q20 : _v_225 == h19 ? q19 : _v_225 == h7 ? q7 : _v_225 == h6 ? q6 : _v_225 == h3 ? q3 : blk_loc(e.mem, _v_225), _v_226, _v_226 == h26 ? q26 : _v_226 == h25 ? q25 : _v_226 == h24 ? q24 : _v_226 == h21 ? q21 : _v_226 == h20 ? q20 : _v_226 == h19 ? q19 : _v_226 == h7 ? q7 : _v_226 == h6 ? q6 : _v_226 == h3 ? q3 : blk_loc(e.mem, _v_226), _v_227, _v_228, _v_229, _v_230, _v_231, _v_232, _v_233, _v_234, _v_235, _v_236, _v_237, _v_238, _v_239, _tx_78, _tx_78 == h24 ? q24 : blk_loc(e.mem, _tx_78), _tx_79, _tx_79 == h25 ? q25 : blk_loc(e.mem, _tx_79), _tx_80, _tx_80 == h26 ? q26 : blk_loc(e.mem, _tx_80)) == 0) {
      return 0;
    }
    _v_275 = _o_4[0];
    _v_276 = _o_4[1];
    _v_277 = _o_4[2];
    _v_278 = _o_4[3];
    _v_279 = _o_4[4];
    _v_280 = _o_4[5];
    _v_281 = _o_4[6];
    _v_282 = _o_4[7];
    _v_283 = _o_4[8];
    _v_284 = _o_4[9];
    _v_285 = _o_4[10];
    _v_286 = _o_4[11];
    _v_287 = _o_4[12];
    _v_288 = _o_4[13];
    _v_289 = _o_4[14];
    _v_290 = _o_4[15];
    _v_291 = _o_4[16];
    _v_292 = _o_4[17];
    _v_293 = _o_4[18];
    _v_294 = _o_4[19];
    _v_295 = _o_4[20];
    _v_296 = _o_4[21];
    _v_297 = _o_4[22];
    _v_298 = _o_4[23];
    _v_299 = _o_4[24];
    _v_300 = _o_4[25];
    _v_301 = _o_4[26];
    _v_178 = _v_275;
    _v_179 = _v_276;
    _v_180 = _v_277;
    _v_181 = _v_278;
    _v_182 = _v_279;
    _v_183 = _v_280;
    _v_184 = _v_281;
    _v_185 = _v_282;
    _v_186 = _v_283;
    _v_187 = _v_284;
    _v_188 = _v_285;
    _v_189 = _v_286;
    _v_190 = _v_287;
    _v_191 = _v_288;
    _v_192 = _v_289;
    _v_193 = _v_290;
    _v_194 = _v_291;
    _v_195 = _v_292;
    _v_196 = _v_293;
    _v_197 = _v_294;
    _v_198 = _v_295;
    _v_199 = _v_296;
    _v_200 = _v_297;
    _v_201 = _v_298;
    _v_202 = _v_299;
    _v_203 = _v_300;
    _v_204 = _v_301;
  break;
  }
  o[0] = _v_178;
  o[1] = _v_179;
  o[2] = _v_180;
  o[3] = _v_181;
  o[4] = _v_182;
  o[5] = _v_183;
  o[6] = _v_184;
  o[7] = _v_185;
  o[8] = _v_186;
  o[9] = _v_187;
  o[10] = _v_188;
  o[11] = _v_189;
  o[12] = _v_190;
  o[13] = _v_191;
  o[14] = _v_192;
  o[15] = _v_193;
  o[16] = _v_194;
  o[17] = _v_195;
  o[18] = _v_196;
  o[19] = _v_197;
  o[20] = _v_198;
  o[21] = _v_199;
  o[22] = _v_200;
  o[23] = _v_201;
  o[24] = _v_202;
  o[25] = _v_203;
  o[26] = _v_204;
  return 1;
}

INLINE Term spin_28(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23, Term r24, u64 q24, Term r25, u64 q25, Term r26, u64 q26, u32 r27, u32 r28, u32 r29, u32 r30) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  Term h24 = r24;
  Term h25 = r25;
  Term h26 = r26;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  Term _v_30 = 0;
  u32 _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  u32 _v_45 = 0;
  Term _v_46 = 0;
  Term _v_47 = 0;
  Term _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  Term _v_51 = 0;
  Term _v_52 = 0;
  Term _v_53 = 0;
  u32 _tx_27 = r0;
  u32 _tx_28 = r1;
  u32 _tx_29 = r2;
  Term _tx_30 = r3;
  u32 _tx_31 = r4;
  Term _tx_32 = r5;
  Term _tx_33 = r6;
  Term _tx_34 = r7;
  u32 _tx_35 = r8;
  u32 _tx_36 = r9;
  u32 _tx_37 = r10;
  u32 _tx_38 = r11;
  u32 _tx_39 = r12;
  u32 _tx_40 = r13;
  u32 _tx_41 = r14;
  u32 _tx_42 = r15;
  u32 _tx_43 = r16;
  u32 _tx_44 = r17;
  u32 _tx_45 = r18;
  Term _tx_46 = r19;
  Term _tx_47 = r20;
  Term _tx_48 = r21;
  u32 _tx_49 = r22;
  u32 _tx_50 = r23;
  Term _tx_51 = r24;
  Term _tx_52 = r25;
  Term _tx_53 = r26;
  u32 _request_4 = r27;
  u32 _request_5 = r28;
  u32 _request_6 = r29;
  u32 _request_7 = r30;
  WL_SPIN
    if (_request_4 == 0) {
      u32 _v_54 = 0;
      u32 _v_55 = 0;
      u32 _v_56 = 0;
      Term _v_57 = 0;
      u32 _v_58 = 0;
      Term _v_59 = 0;
      Term _v_60 = 0;
      Term _v_61 = 0;
      u32 _v_62 = 0;
      u32 _v_63 = 0;
      u32 _v_64 = 0;
      u32 _v_65 = 0;
      u32 _v_66 = 0;
      u32 _v_67 = 0;
      u32 _v_68 = 0;
      u32 _v_69 = 0;
      u32 _v_70 = 0;
      u32 _v_71 = 0;
      u32 _v_72 = 0;
      Term _v_73 = 0;
      Term _v_74 = 0;
      Term _v_75 = 0;
      u32 _v_76 = 0;
      u32 _v_77 = 0;
      Term _v_78 = 0;
      Term _v_79 = 0;
      Term _v_80 = 0;
      Term _o_0[27];
      if (spin_26(e, _o_0, _tx_27, _tx_28, _tx_29, _tx_30, _tx_30 == h3 ? q3 : blk_loc(e.mem, _tx_30), _tx_31, _tx_32, _tx_33, _tx_33 == h6 ? q6 : blk_loc(e.mem, _tx_33), _tx_34, _tx_34 == h7 ? q7 : blk_loc(e.mem, _tx_34), _tx_35, _tx_36, _tx_37, _tx_38, _tx_39, _tx_40, _tx_41, _tx_42, _tx_43, _tx_44, _tx_45, _tx_46, _tx_46 == h19 ? q19 : blk_loc(e.mem, _tx_46), _tx_47, _tx_47 == h20 ? q20 : blk_loc(e.mem, _tx_47), _tx_48, _tx_48 == h21 ? q21 : blk_loc(e.mem, _tx_48), _tx_49, _tx_50, _tx_51, _tx_51 == h24 ? q24 : blk_loc(e.mem, _tx_51), _tx_52, _tx_52 == h25 ? q25 : blk_loc(e.mem, _tx_52), _tx_53, _tx_53 == h26 ? q26 : blk_loc(e.mem, _tx_53), _request_5, _request_6, _request_7) == 0) {
        return 0;
      }
      _v_54 = _o_0[0];
      _v_55 = _o_0[1];
      _v_56 = _o_0[2];
      _v_57 = _o_0[3];
      _v_58 = _o_0[4];
      _v_59 = _o_0[5];
      _v_60 = _o_0[6];
      _v_61 = _o_0[7];
      _v_62 = _o_0[8];
      _v_63 = _o_0[9];
      _v_64 = _o_0[10];
      _v_65 = _o_0[11];
      _v_66 = _o_0[12];
      _v_67 = _o_0[13];
      _v_68 = _o_0[14];
      _v_69 = _o_0[15];
      _v_70 = _o_0[16];
      _v_71 = _o_0[17];
      _v_72 = _o_0[18];
      _v_73 = _o_0[19];
      _v_74 = _o_0[20];
      _v_75 = _o_0[21];
      _v_76 = _o_0[22];
      _v_77 = _o_0[23];
      _v_78 = _o_0[24];
      _v_79 = _o_0[25];
      _v_80 = _o_0[26];
      _v_27 = _v_54;
      _v_28 = _v_55;
      _v_29 = _v_56;
      _v_30 = _v_57;
      _v_31 = _v_58;
      _v_32 = _v_59;
      _v_33 = _v_60;
      _v_34 = _v_61;
      _v_35 = _v_62;
      _v_36 = _v_63;
      _v_37 = _v_64;
      _v_38 = _v_65;
      _v_39 = _v_66;
      _v_40 = _v_67;
      _v_41 = _v_68;
      _v_42 = _v_69;
      _v_43 = _v_70;
      _v_44 = _v_71;
      _v_45 = _v_72;
      _v_46 = _v_73;
      _v_47 = _v_74;
      _v_48 = _v_75;
      _v_49 = _v_76;
      _v_50 = _v_77;
      _v_51 = _v_78;
      _v_52 = _v_79;
      _v_53 = _v_80;
    } else {
      u32 _v_81 = 0;
      u32 _v_82 = 0;
      u32 _v_83 = 0;
      Term _v_84 = 0;
      u32 _v_85 = 0;
      Term _v_86 = 0;
      Term _v_87 = 0;
      Term _v_88 = 0;
      u32 _v_89 = 0;
      u32 _v_90 = 0;
      u32 _v_91 = 0;
      u32 _v_92 = 0;
      u32 _v_93 = 0;
      u32 _v_94 = 0;
      u32 _v_95 = 0;
      u32 _v_96 = 0;
      u32 _v_97 = 0;
      u32 _v_98 = 0;
      u32 _v_99 = 0;
      Term _v_100 = 0;
      Term _v_101 = 0;
      Term _v_102 = 0;
      u32 _v_103 = 0;
      u32 _v_104 = 0;
      Term _v_105 = 0;
      Term _v_106 = 0;
      Term _v_107 = 0;
      Term _o_1[27];
      if (spin_27(e, _o_1, _tx_27, _tx_28, _tx_29, _tx_30, _tx_30 == h3 ? q3 : blk_loc(e.mem, _tx_30), _tx_31, _tx_32, _tx_33, _tx_33 == h6 ? q6 : blk_loc(e.mem, _tx_33), _tx_34, _tx_34 == h7 ? q7 : blk_loc(e.mem, _tx_34), _tx_35, _tx_36, _tx_37, _tx_38, _tx_39, _tx_40, _tx_41, _tx_42, _tx_43, _tx_44, _tx_45, _tx_46, _tx_46 == h19 ? q19 : blk_loc(e.mem, _tx_46), _tx_47, _tx_47 == h20 ? q20 : blk_loc(e.mem, _tx_47), _tx_48, _tx_48 == h21 ? q21 : blk_loc(e.mem, _tx_48), _tx_49, _tx_50, _tx_51, _tx_51 == h24 ? q24 : blk_loc(e.mem, _tx_51), _tx_52, _tx_52 == h25 ? q25 : blk_loc(e.mem, _tx_52), _tx_53, _tx_53 == h26 ? q26 : blk_loc(e.mem, _tx_53)) == 0) {
        return 0;
      }
      _v_81 = _o_1[0];
      _v_82 = _o_1[1];
      _v_83 = _o_1[2];
      _v_84 = _o_1[3];
      _v_85 = _o_1[4];
      _v_86 = _o_1[5];
      _v_87 = _o_1[6];
      _v_88 = _o_1[7];
      _v_89 = _o_1[8];
      _v_90 = _o_1[9];
      _v_91 = _o_1[10];
      _v_92 = _o_1[11];
      _v_93 = _o_1[12];
      _v_94 = _o_1[13];
      _v_95 = _o_1[14];
      _v_96 = _o_1[15];
      _v_97 = _o_1[16];
      _v_98 = _o_1[17];
      _v_99 = _o_1[18];
      _v_100 = _o_1[19];
      _v_101 = _o_1[20];
      _v_102 = _o_1[21];
      _v_103 = _o_1[22];
      _v_104 = _o_1[23];
      _v_105 = _o_1[24];
      _v_106 = _o_1[25];
      _v_107 = _o_1[26];
      _v_27 = _v_81;
      _v_28 = _v_82;
      _v_29 = _v_83;
      _v_30 = _v_84;
      _v_31 = _v_85;
      _v_32 = _v_86;
      _v_33 = _v_87;
      _v_34 = _v_88;
      _v_35 = _v_89;
      _v_36 = _v_90;
      _v_37 = _v_91;
      _v_38 = _v_92;
      _v_39 = _v_93;
      _v_40 = _v_94;
      _v_41 = _v_95;
      _v_42 = _v_96;
      _v_43 = _v_97;
      _v_44 = _v_98;
      _v_45 = _v_99;
      _v_46 = _v_100;
      _v_47 = _v_101;
      _v_48 = _v_102;
      _v_49 = _v_103;
      _v_50 = _v_104;
      _v_51 = _v_105;
      _v_52 = _v_106;
      _v_53 = _v_107;
    }
  break;
  }
  o[0] = _v_27;
  o[1] = _v_28;
  o[2] = _v_29;
  o[3] = _v_30;
  o[4] = _v_31;
  o[5] = _v_32;
  o[6] = _v_33;
  o[7] = _v_34;
  o[8] = _v_35;
  o[9] = _v_36;
  o[10] = _v_37;
  o[11] = _v_38;
  o[12] = _v_39;
  o[13] = _v_40;
  o[14] = _v_41;
  o[15] = _v_42;
  o[16] = _v_43;
  o[17] = _v_44;
  o[18] = _v_45;
  o[19] = _v_46;
  o[20] = _v_47;
  o[21] = _v_48;
  o[22] = _v_49;
  o[23] = _v_50;
  o[24] = _v_51;
  o[25] = _v_52;
  o[26] = _v_53;
  return 1;
}

INLINE Term spin_29(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23, u32 r24, Term r25, u64 q25) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  Term h25 = r25;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  Term _v_30 = 0;
  u32 _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  u32 _v_45 = 0;
  Term _v_46 = 0;
  Term _v_47 = 0;
  Term _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  Term _v_51 = 0;
  u32 _result_0 = r0;
  u32 _result_1 = r1;
  u32 _result_2 = r2;
  Term _result_3 = r3;
  u32 _result_4 = r4;
  Term _result_5 = r5;
  Term _result_6 = r6;
  Term _result_7 = r7;
  u32 _result_8 = r8;
  u32 _result_9 = r9;
  u32 _result_10 = r10;
  u32 _result_11 = r11;
  u32 _result_12 = r12;
  u32 _result_13 = r13;
  u32 _result_14 = r14;
  u32 _result_15 = r15;
  u32 _result_16 = r16;
  u32 _result_17 = r17;
  u32 _result_18 = r18;
  Term _result_19 = r19;
  Term _result_20 = r20;
  Term _result_21 = r21;
  u32 _result_22 = r22;
  u32 _result_23 = r23;
  u32 _result_24 = r24;
  Term _result_25 = r25;
  WL_SPIN
    if (_result_24 == 0) {
      _v_26 = 0;
      _v_27 = _result_0;
      _v_28 = _result_1;
      _v_29 = _result_2;
      _v_30 = _result_3;
      _v_31 = _result_4;
      _v_32 = _result_5;
      _v_33 = _result_6;
      _v_34 = _result_7;
      _v_35 = _result_8;
      _v_36 = _result_9;
      _v_37 = _result_10;
      _v_38 = _result_11;
      _v_39 = _result_12;
      _v_40 = _result_13;
      _v_41 = _result_14;
      _v_42 = _result_15;
      _v_43 = _result_16;
      _v_44 = _result_17;
      _v_45 = _result_18;
      _v_46 = _result_19;
      _v_47 = _result_20;
      _v_48 = _result_21;
      _v_49 = _result_22;
      _v_50 = _result_23;
      _v_51 = 0;
    } else {
      _v_26 = 1;
      _v_27 = _result_0;
      _v_28 = _result_1;
      _v_29 = _result_2;
      _v_30 = _result_3;
      _v_31 = _result_4;
      _v_32 = _result_5;
      _v_33 = _result_6;
      _v_34 = _result_7;
      _v_35 = _result_8;
      _v_36 = _result_9;
      _v_37 = _result_10;
      _v_38 = _result_11;
      _v_39 = _result_12;
      _v_40 = _result_13;
      _v_41 = _result_14;
      _v_42 = _result_15;
      _v_43 = _result_16;
      _v_44 = _result_17;
      _v_45 = _result_18;
      _v_46 = _result_19;
      _v_47 = _result_20;
      _v_48 = _result_21;
      _v_49 = _result_22;
      _v_50 = _result_23;
      _v_51 = _result_25;
    }
  break;
  }
  o[0] = _v_26;
  o[1] = _v_27;
  o[2] = _v_28;
  o[3] = _v_29;
  o[4] = _v_30;
  o[5] = _v_31;
  o[6] = _v_32;
  o[7] = _v_33;
  o[8] = _v_34;
  o[9] = _v_35;
  o[10] = _v_36;
  o[11] = _v_37;
  o[12] = _v_38;
  o[13] = _v_39;
  o[14] = _v_40;
  o[15] = _v_41;
  o[16] = _v_42;
  o[17] = _v_43;
  o[18] = _v_44;
  o[19] = _v_45;
  o[20] = _v_46;
  o[21] = _v_47;
  o[22] = _v_48;
  o[23] = _v_49;
  o[24] = _v_50;
  o[25] = _v_51;
  return 1;
}

INLINE Term spin_30(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  u32 _v_81 = 0;
  u32 _v_82 = 0;
  u32 _v_83 = 0;
  Term _v_84 = 0;
  u32 _v_85 = 0;
  Term _v_86 = 0;
  Term _v_87 = 0;
  Term _v_88 = 0;
  u32 _v_89 = 0;
  u32 _v_90 = 0;
  u32 _v_91 = 0;
  u32 _v_92 = 0;
  u32 _v_93 = 0;
  u32 _v_94 = 0;
  u32 _v_95 = 0;
  u32 _v_96 = 0;
  u32 _v_97 = 0;
  u32 _v_98 = 0;
  u32 _v_99 = 0;
  Term _v_100 = 0;
  Term _v_101 = 0;
  Term _v_102 = 0;
  u32 _v_103 = 0;
  u32 _v_104 = 0;
  Term _v_105 = 0;
  Term _v_106 = 0;
  Term _v_107 = 0;
  u32 _world_24 = r0;
  u32 _world_25 = r1;
  u32 _world_26 = r2;
  Term _world_27 = r3;
  u32 _world_28 = r4;
  Term _world_29 = r5;
  Term _world_30 = r6;
  Term _world_31 = r7;
  u32 _world_32 = r8;
  u32 _world_33 = r9;
  u32 _world_34 = r10;
  u32 _world_35 = r11;
  u32 _world_36 = r12;
  u32 _world_37 = r13;
  u32 _world_38 = r14;
  u32 _world_39 = r15;
  u32 _world_40 = r16;
  u32 _world_41 = r17;
  u32 _world_42 = r18;
  Term _world_43 = r19;
  Term _world_44 = r20;
  Term _world_45 = r21;
  u32 _world_46 = r22;
  u32 _world_47 = r23;
  WL_SPIN
    _v_81 = _world_24;
    _v_82 = _world_25;
    _v_83 = _world_26;
    _v_84 = _world_27;
    _v_85 = _world_28;
    _v_86 = _world_29;
    _v_87 = _world_30;
    _v_88 = _world_31;
    _v_89 = _world_32;
    _v_90 = _world_33;
    _v_91 = _world_34;
    _v_92 = _world_35;
    _v_93 = _world_36;
    _v_94 = _world_37;
    _v_95 = _world_38;
    _v_96 = _world_39;
    _v_97 = _world_40;
    _v_98 = _world_41;
    _v_99 = _world_42;
    _v_100 = _world_43;
    _v_101 = _world_44;
    _v_102 = _world_45;
    _v_103 = _world_46;
    _v_104 = _world_47;
    _v_105 = term_pak(CID_NIL, 0);
    _v_106 = term_pak(CID_NIL, 0);
    _v_107 = term_pak(CID_NIL, 0);
  break;
  }
  o[0] = _v_81;
  o[1] = _v_82;
  o[2] = _v_83;
  o[3] = _v_84;
  o[4] = _v_85;
  o[5] = _v_86;
  o[6] = _v_87;
  o[7] = _v_88;
  o[8] = _v_89;
  o[9] = _v_90;
  o[10] = _v_91;
  o[11] = _v_92;
  o[12] = _v_93;
  o[13] = _v_94;
  o[14] = _v_95;
  o[15] = _v_96;
  o[16] = _v_97;
  o[17] = _v_98;
  o[18] = _v_99;
  o[19] = _v_100;
  o[20] = _v_101;
  o[21] = _v_102;
  o[22] = _v_103;
  o[23] = _v_104;
  o[24] = _v_105;
  o[25] = _v_106;
  o[26] = _v_107;
  return 1;
}

INLINE Term spin_31(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, Term r4, u64 q4, u32 r5, Term r6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, u32 r19, Term r20, u64 q20, Term r21, u64 q21, Term r22, u64 q22, u32 r23, u32 r24, Term r25, u64 q25, Term r26, u64 q26, Term r27, u64 q27, u32 r28, u32 r29, u32 r30, u32 r31) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h4 = r4;
  Term h7 = r7;
  Term h8 = r8;
  Term h20 = r20;
  Term h21 = r21;
  Term h22 = r22;
  Term h25 = r25;
  Term h26 = r26;
  Term h27 = r27;
  u32 _v_135 = 0;
  u32 _v_136 = 0;
  u32 _v_137 = 0;
  Term _v_138 = 0;
  u32 _v_139 = 0;
  Term _v_140 = 0;
  Term _v_141 = 0;
  Term _v_142 = 0;
  u32 _v_143 = 0;
  u32 _v_144 = 0;
  u32 _v_145 = 0;
  u32 _v_146 = 0;
  u32 _v_147 = 0;
  u32 _v_148 = 0;
  u32 _v_149 = 0;
  u32 _v_150 = 0;
  u32 _v_151 = 0;
  u32 _v_152 = 0;
  u32 _v_153 = 0;
  Term _v_154 = 0;
  Term _v_155 = 0;
  Term _v_156 = 0;
  u32 _v_157 = 0;
  u32 _v_158 = 0;
  Term _v_159 = 0;
  Term _v_160 = 0;
  Term _v_161 = 0;
  Term __0 = r0;
  u32 _tx_0 = r1;
  u32 _tx_1 = r2;
  u32 _tx_2 = r3;
  Term _tx_3 = r4;
  u32 _tx_4 = r5;
  Term _tx_5 = r6;
  Term _tx_6 = r7;
  Term _tx_7 = r8;
  u32 _tx_8 = r9;
  u32 _tx_9 = r10;
  u32 _tx_10 = r11;
  u32 _tx_11 = r12;
  u32 _tx_12 = r13;
  u32 _tx_13 = r14;
  u32 _tx_14 = r15;
  u32 _tx_15 = r16;
  u32 _tx_16 = r17;
  u32 _tx_17 = r18;
  u32 _tx_18 = r19;
  Term _tx_19 = r20;
  Term _tx_20 = r21;
  Term _tx_21 = r22;
  u32 _tx_22 = r23;
  u32 _tx_23 = r24;
  Term _tx_24 = r25;
  Term _tx_25 = r26;
  Term _tx_26 = r27;
  u32 _request_5 = r28;
  u32 _request_6 = r29;
  u32 _request_7 = r30;
  u32 _request_8 = r31;
  WL_SPIN
    term_sink(e, __0);
    u32 _v_162 = 0;
    u32 _v_163 = 0;
    u32 _v_164 = 0;
    Term _v_165 = 0;
    u32 _v_166 = 0;
    Term _v_167 = 0;
    Term _v_168 = 0;
    Term _v_169 = 0;
    u32 _v_170 = 0;
    u32 _v_171 = 0;
    u32 _v_172 = 0;
    u32 _v_173 = 0;
    u32 _v_174 = 0;
    u32 _v_175 = 0;
    u32 _v_176 = 0;
    u32 _v_177 = 0;
    u32 _v_178 = 0;
    u32 _v_179 = 0;
    u32 _v_180 = 0;
    Term _v_181 = 0;
    Term _v_182 = 0;
    Term _v_183 = 0;
    u32 _v_184 = 0;
    u32 _v_185 = 0;
    Term _v_186 = 0;
    Term _v_187 = 0;
    Term _v_188 = 0;
    Term _o_1[27];
    if (spin_28(e, _o_1, _tx_0, _tx_1, _tx_2, _tx_3, _tx_3 == h4 ? q4 : blk_loc(e.mem, _tx_3), _tx_4, _tx_5, _tx_6, _tx_6 == h7 ? q7 : blk_loc(e.mem, _tx_6), _tx_7, _tx_7 == h8 ? q8 : blk_loc(e.mem, _tx_7), _tx_8, _tx_9, _tx_10, _tx_11, _tx_12, _tx_13, _tx_14, _tx_15, _tx_16, _tx_17, _tx_18, _tx_19, _tx_19 == h20 ? q20 : blk_loc(e.mem, _tx_19), _tx_20, _tx_20 == h21 ? q21 : blk_loc(e.mem, _tx_20), _tx_21, _tx_21 == h22 ? q22 : blk_loc(e.mem, _tx_21), _tx_22, _tx_23, _tx_24, _tx_24 == h25 ? q25 : blk_loc(e.mem, _tx_24), _tx_25, _tx_25 == h26 ? q26 : blk_loc(e.mem, _tx_25), _tx_26, _tx_26 == h27 ? q27 : blk_loc(e.mem, _tx_26), _request_5, _request_6, _request_7, _request_8) == 0) {
      return 0;
    }
    _v_162 = _o_1[0];
    _v_163 = _o_1[1];
    _v_164 = _o_1[2];
    _v_165 = _o_1[3];
    _v_166 = _o_1[4];
    _v_167 = _o_1[5];
    _v_168 = _o_1[6];
    _v_169 = _o_1[7];
    _v_170 = _o_1[8];
    _v_171 = _o_1[9];
    _v_172 = _o_1[10];
    _v_173 = _o_1[11];
    _v_174 = _o_1[12];
    _v_175 = _o_1[13];
    _v_176 = _o_1[14];
    _v_177 = _o_1[15];
    _v_178 = _o_1[16];
    _v_179 = _o_1[17];
    _v_180 = _o_1[18];
    _v_181 = _o_1[19];
    _v_182 = _o_1[20];
    _v_183 = _o_1[21];
    _v_184 = _o_1[22];
    _v_185 = _o_1[23];
    _v_186 = _o_1[24];
    _v_187 = _o_1[25];
    _v_188 = _o_1[26];
    _v_135 = _v_162;
    _v_136 = _v_163;
    _v_137 = _v_164;
    _v_138 = _v_165;
    _v_139 = _v_166;
    _v_140 = _v_167;
    _v_141 = _v_168;
    _v_142 = _v_169;
    _v_143 = _v_170;
    _v_144 = _v_171;
    _v_145 = _v_172;
    _v_146 = _v_173;
    _v_147 = _v_174;
    _v_148 = _v_175;
    _v_149 = _v_176;
    _v_150 = _v_177;
    _v_151 = _v_178;
    _v_152 = _v_179;
    _v_153 = _v_180;
    _v_154 = _v_181;
    _v_155 = _v_182;
    _v_156 = _v_183;
    _v_157 = _v_184;
    _v_158 = _v_185;
    _v_159 = _v_186;
    _v_160 = _v_187;
    _v_161 = _v_188;
  break;
  }
  o[0] = _v_135;
  o[1] = _v_136;
  o[2] = _v_137;
  o[3] = _v_138;
  o[4] = _v_139;
  o[5] = _v_140;
  o[6] = _v_141;
  o[7] = _v_142;
  o[8] = _v_143;
  o[9] = _v_144;
  o[10] = _v_145;
  o[11] = _v_146;
  o[12] = _v_147;
  o[13] = _v_148;
  o[14] = _v_149;
  o[15] = _v_150;
  o[16] = _v_151;
  o[17] = _v_152;
  o[18] = _v_153;
  o[19] = _v_154;
  o[20] = _v_155;
  o[21] = _v_156;
  o[22] = _v_157;
  o[23] = _v_158;
  o[24] = _v_159;
  o[25] = _v_160;
  o[26] = _v_161;
  return 1;
}

INLINE Term spin_32(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9, u32 r10, Term r11, Term r12, u64 q12, Term r13, u64 q13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, u32 r19, u32 r20, u32 r21, u32 r22, u32 r23, u32 r24, Term r25, u64 q25, Term r26, u64 q26, Term r27, u64 q27, u32 r28, u32 r29, Term r30, u64 q30) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h9 = r9;
  Term h12 = r12;
  Term h13 = r13;
  Term h25 = r25;
  Term h26 = r26;
  Term h27 = r27;
  Term h30 = r30;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _v_38 = 0;
  Term _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  Term _v_44 = 0;
  Term _v_45 = 0;
  Term _v_46 = 0;
  Term _v_47 = 0;
  Term _v_48 = 0;
  Term _v_49 = 0;
  u32 _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  u32 _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  Term _v_60 = 0;
  Term _v_61 = 0;
  Term _v_62 = 0;
  Term _v_63 = 0;
  u32 _v_64 = 0;
  u32 _v_65 = 0;
  Term _v_66 = 0;
  u32 _v_67 = 0;
  u32 _v_68 = 0;
  u32 _v_69 = 0;
  u32 _registry_10 = r0;
  u32 _registry_11 = r1;
  Term _registry_12 = r2;
  Term _registry_13 = r3;
  u32 _registry_14 = r4;
  u32 _outcome_0 = r5;
  u32 _outcome_1 = r6;
  u32 _outcome_2 = r7;
  u32 _outcome_3 = r8;
  Term _outcome_4 = r9;
  u32 _outcome_5 = r10;
  Term _outcome_6 = r11;
  Term _outcome_7 = r12;
  Term _outcome_8 = r13;
  u32 _outcome_9 = r14;
  u32 _outcome_10 = r15;
  u32 _outcome_11 = r16;
  u32 _outcome_12 = r17;
  u32 _outcome_13 = r18;
  u32 _outcome_14 = r19;
  u32 _outcome_15 = r20;
  u32 _outcome_16 = r21;
  u32 _outcome_17 = r22;
  u32 _outcome_18 = r23;
  u32 _outcome_19 = r24;
  Term _outcome_20 = r25;
  Term _outcome_21 = r26;
  Term _outcome_22 = r27;
  u32 _outcome_23 = r28;
  u32 _outcome_24 = r29;
  Term _outcome_25 = r30;
  WL_SPIN
    _v_35 = 0;
    _v_36 = _registry_10;
    _v_37 = _registry_11;
    _v_38 = _registry_12;
    _v_39 = _registry_13;
    _v_40 = _registry_14;
    _v_41 = _outcome_0;
    _v_42 = _outcome_1;
    _v_43 = _outcome_2;
    _v_44 = _outcome_3;
    _v_45 = _outcome_4;
    _v_46 = _outcome_5;
    _v_47 = _outcome_6;
    _v_48 = _outcome_7;
    _v_49 = _outcome_8;
    _v_50 = _outcome_9;
    _v_51 = _outcome_10;
    _v_52 = _outcome_11;
    _v_53 = _outcome_12;
    _v_54 = _outcome_13;
    _v_55 = _outcome_14;
    _v_56 = _outcome_15;
    _v_57 = _outcome_16;
    _v_58 = _outcome_17;
    _v_59 = _outcome_18;
    _v_60 = _outcome_19;
    _v_61 = _outcome_20;
    _v_62 = _outcome_21;
    _v_63 = _outcome_22;
    _v_64 = _outcome_23;
    _v_65 = _outcome_24;
    _v_66 = _outcome_25;
    _v_67 = 0;
    _v_68 = 0;
    _v_69 = 0;
  break;
  }
  o[0] = _v_35;
  o[1] = _v_36;
  o[2] = _v_37;
  o[3] = _v_38;
  o[4] = _v_39;
  o[5] = _v_40;
  o[6] = _v_41;
  o[7] = _v_42;
  o[8] = _v_43;
  o[9] = _v_44;
  o[10] = _v_45;
  o[11] = _v_46;
  o[12] = _v_47;
  o[13] = _v_48;
  o[14] = _v_49;
  o[15] = _v_50;
  o[16] = _v_51;
  o[17] = _v_52;
  o[18] = _v_53;
  o[19] = _v_54;
  o[20] = _v_55;
  o[21] = _v_56;
  o[22] = _v_57;
  o[23] = _v_58;
  o[24] = _v_59;
  o[25] = _v_60;
  o[26] = _v_61;
  o[27] = _v_62;
  o[28] = _v_63;
  o[29] = _v_64;
  o[30] = _v_65;
  o[31] = _v_66;
  o[32] = _v_67;
  o[33] = _v_68;
  o[34] = _v_69;
  return 1;
}

INLINE Term spin_33(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  u32 _v_4 = 0;
  Term _v_5 = 0;
  Term _qr_0 = r0;
  Term _qr_1 = r1;
  WL_SPIN
    _v_4 = ((u64)(u32)(nat_chk(e, 48ull + _qr_1)));
    _v_5 = _qr_0;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  return 1;
}

INLINE Term spin_34(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, Term r4, u64 q4, u32 r5, Term r6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, u32 r19, Term r20, u64 q20, Term r21, u64 q21, Term r22, u64 q22, u32 r23, u32 r24, Term r25, u64 q25, u32 r26, u32 r27, Term r28, u64 q28, Term r29, u64 q29, u32 r30, u32 r31) {
  u32 wpoll = 0;
  Term h4 = r4;
  Term h7 = r7;
  Term h8 = r8;
  Term h20 = r20;
  Term h21 = r21;
  Term h22 = r22;
  Term h25 = r25;
  Term h28 = r28;
  Term h29 = r29;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _v_38 = 0;
  Term _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  Term _v_44 = 0;
  Term _v_45 = 0;
  Term _v_46 = 0;
  Term _v_47 = 0;
  Term _v_48 = 0;
  Term _v_49 = 0;
  u32 _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  u32 _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  Term _v_60 = 0;
  Term _v_61 = 0;
  Term _v_62 = 0;
  Term _v_63 = 0;
  u32 _v_64 = 0;
  u32 _v_65 = 0;
  Term _v_66 = 0;
  u32 _v_67 = 0;
  u32 _v_68 = 0;
  u32 _v_69 = 0;
  u32 _outcome_0 = r0;
  u32 _outcome_1 = r1;
  u32 _outcome_2 = r2;
  u32 _outcome_3 = r3;
  Term _outcome_4 = r4;
  u32 _outcome_5 = r5;
  Term _outcome_6 = r6;
  Term _outcome_7 = r7;
  Term _outcome_8 = r8;
  u32 _outcome_9 = r9;
  u32 _outcome_10 = r10;
  u32 _outcome_11 = r11;
  u32 _outcome_12 = r12;
  u32 _outcome_13 = r13;
  u32 _outcome_14 = r14;
  u32 _outcome_15 = r15;
  u32 _outcome_16 = r16;
  u32 _outcome_17 = r17;
  u32 _outcome_18 = r18;
  u32 _outcome_19 = r19;
  Term _outcome_20 = r20;
  Term _outcome_21 = r21;
  Term _outcome_22 = r22;
  u32 _outcome_23 = r23;
  u32 _outcome_24 = r24;
  Term _outcome_25 = r25;
  u32 _registry_5 = r26;
  u32 _registry_6 = r27;
  Term _registry_7 = r28;
  Term _registry_8 = r29;
  u32 _registry_9 = r30;
  u32 _nextCursor_0 = r31;
  WL_SPIN
    if (_outcome_0 == 1) {
      _v_35 = 0;
      _v_36 = _registry_5;
      _v_37 = _registry_6;
      _v_38 = _registry_7;
      _v_39 = _registry_8;
      _v_40 = _registry_9;
      _v_41 = 1;
      _v_42 = _outcome_1;
      _v_43 = _outcome_2;
      _v_44 = _outcome_3;
      _v_45 = _outcome_4;
      _v_46 = _outcome_5;
      _v_47 = _outcome_6;
      _v_48 = _outcome_7;
      _v_49 = _outcome_8;
      _v_50 = _outcome_9;
      _v_51 = _outcome_10;
      _v_52 = _outcome_11;
      _v_53 = _outcome_12;
      _v_54 = _outcome_13;
      _v_55 = _outcome_14;
      _v_56 = _outcome_15;
      _v_57 = _outcome_16;
      _v_58 = _outcome_17;
      _v_59 = _outcome_18;
      _v_60 = _outcome_19;
      _v_61 = _outcome_20;
      _v_62 = _outcome_21;
      _v_63 = _outcome_22;
      _v_64 = _outcome_23;
      _v_65 = _outcome_24;
      _v_66 = _outcome_25;
      _v_67 = 0;
      _v_68 = 0;
      _v_69 = 0;
    } else {
      _v_35 = 0;
      _v_36 = _registry_5;
      _v_37 = _registry_6;
      _v_38 = _registry_7;
      _v_39 = _registry_8;
      _v_40 = _nextCursor_0;
      _v_41 = 0;
      _v_42 = _outcome_1;
      _v_43 = _outcome_2;
      _v_44 = _outcome_3;
      _v_45 = _outcome_4;
      _v_46 = _outcome_5;
      _v_47 = _outcome_6;
      _v_48 = _outcome_7;
      _v_49 = _outcome_8;
      _v_50 = _outcome_9;
      _v_51 = _outcome_10;
      _v_52 = _outcome_11;
      _v_53 = _outcome_12;
      _v_54 = _outcome_13;
      _v_55 = _outcome_14;
      _v_56 = _outcome_15;
      _v_57 = _outcome_16;
      _v_58 = _outcome_17;
      _v_59 = _outcome_18;
      _v_60 = _outcome_19;
      _v_61 = _outcome_20;
      _v_62 = _outcome_21;
      _v_63 = _outcome_22;
      _v_64 = _outcome_23;
      _v_65 = _outcome_24;
      _v_66 = 0;
      _v_67 = 0;
      _v_68 = 0;
      _v_69 = 0;
    }
  break;
  }
  o[0] = _v_35;
  o[1] = _v_36;
  o[2] = _v_37;
  o[3] = _v_38;
  o[4] = _v_39;
  o[5] = _v_40;
  o[6] = _v_41;
  o[7] = _v_42;
  o[8] = _v_43;
  o[9] = _v_44;
  o[10] = _v_45;
  o[11] = _v_46;
  o[12] = _v_47;
  o[13] = _v_48;
  o[14] = _v_49;
  o[15] = _v_50;
  o[16] = _v_51;
  o[17] = _v_52;
  o[18] = _v_53;
  o[19] = _v_54;
  o[20] = _v_55;
  o[21] = _v_56;
  o[22] = _v_57;
  o[23] = _v_58;
  o[24] = _v_59;
  o[25] = _v_60;
  o[26] = _v_61;
  o[27] = _v_62;
  o[28] = _v_63;
  o[29] = _v_64;
  o[30] = _v_65;
  o[31] = _v_66;
  o[32] = _v_67;
  o[33] = _v_68;
  o[34] = _v_69;
  return 1;
}

INLINE Term spin_35(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  Term _v_2 = 0;
  u32 _b_0 = r0;
  WL_SPIN
    if (_b_0 == 0) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 62);
    } else {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 68);
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_36(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  Term _v_2 = 0;
  u32 _tag_0 = r0;
  WL_SPIN
    if (_tag_0 == 0) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 30);
    } else if (_tag_0 == 1) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 38);
    } else {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 48);
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_37(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  u32 _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  Term _v_53 = 0;
  u32 _v_54 = 0;
  Term _v_55 = 0;
  Term _v_56 = 0;
  Term _v_57 = 0;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  u32 _v_60 = 0;
  u32 _v_61 = 0;
  u32 _v_62 = 0;
  u32 _v_63 = 0;
  u32 _v_64 = 0;
  u32 _v_65 = 0;
  u32 _v_66 = 0;
  u32 _v_67 = 0;
  u32 _v_68 = 0;
  Term _v_69 = 0;
  Term _v_70 = 0;
  Term _v_71 = 0;
  u32 _v_72 = 0;
  u32 _v_73 = 0;
  u32 _v_74 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  Term _world_6 = r6;
  Term _world_7 = r7;
  u32 _world_8 = r8;
  u32 _world_9 = r9;
  u32 _world_10 = r10;
  u32 _world_11 = r11;
  u32 _world_12 = r12;
  u32 _world_13 = r13;
  u32 _world_14 = r14;
  u32 _world_15 = r15;
  u32 _world_16 = r16;
  u32 _world_17 = r17;
  u32 _world_18 = r18;
  Term _world_19 = r19;
  Term _world_20 = r20;
  Term _world_21 = r21;
  u32 _world_22 = r22;
  u32 _world_23 = r23;
  WL_SPIN
    _v_50 = _world_0;
    _v_51 = _world_1;
    _v_52 = _world_2;
    _v_53 = _world_3;
    _v_54 = _world_4;
    _v_55 = _world_5;
    _v_56 = _world_6;
    _v_57 = _world_7;
    _v_58 = _world_8;
    _v_59 = _world_9;
    _v_60 = _world_10;
    _v_61 = _world_11;
    _v_62 = _world_12;
    _v_63 = _world_13;
    _v_64 = _world_14;
    _v_65 = _world_15;
    _v_66 = _world_16;
    _v_67 = _world_17;
    _v_68 = _world_18;
    _v_69 = _world_19;
    _v_70 = _world_20;
    _v_71 = _world_21;
    _v_72 = _world_22;
    _v_73 = _world_23;
    _v_74 = _world_23;
  break;
  }
  o[0] = _v_50;
  o[1] = _v_51;
  o[2] = _v_52;
  o[3] = _v_53;
  o[4] = _v_54;
  o[5] = _v_55;
  o[6] = _v_56;
  o[7] = _v_57;
  o[8] = _v_58;
  o[9] = _v_59;
  o[10] = _v_60;
  o[11] = _v_61;
  o[12] = _v_62;
  o[13] = _v_63;
  o[14] = _v_64;
  o[15] = _v_65;
  o[16] = _v_66;
  o[17] = _v_67;
  o[18] = _v_68;
  o[19] = _v_69;
  o[20] = _v_70;
  o[21] = _v_71;
  o[22] = _v_72;
  o[23] = _v_73;
  o[24] = _v_74;
  return 1;
}

INLINE Term spin_38(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5, u32 r6, u32 r7, Term r8, u64 q8, u32 r9, Term r10, Term r11, u64 q11, Term r12, u64 q12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, u32 r19, u32 r20, u32 r21, u32 r22, u32 r23, Term r24, u64 q24, Term r25, u64 q25, Term r26, u64 q26, u32 r27, u32 r28, u32 r29) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h8 = r8;
  Term h11 = r11;
  Term h12 = r12;
  Term h24 = r24;
  Term h25 = r25;
  Term h26 = r26;
  u32 _v_110 = 0;
  u32 _v_111 = 0;
  u32 _v_112 = 0;
  Term _v_113 = 0;
  Term _v_114 = 0;
  u32 _v_115 = 0;
  u32 _v_116 = 0;
  u32 _v_117 = 0;
  u32 _v_118 = 0;
  Term _v_119 = 0;
  Term _v_120 = 0;
  Term _v_121 = 0;
  Term _v_122 = 0;
  Term _v_123 = 0;
  Term _v_124 = 0;
  u32 _v_125 = 0;
  u32 _v_126 = 0;
  u32 _v_127 = 0;
  u32 _v_128 = 0;
  u32 _v_129 = 0;
  u32 _v_130 = 0;
  u32 _v_131 = 0;
  u32 _v_132 = 0;
  u32 _v_133 = 0;
  u32 _v_134 = 0;
  Term _v_135 = 0;
  Term _v_136 = 0;
  Term _v_137 = 0;
  Term _v_138 = 0;
  u32 _v_139 = 0;
  u32 _v_140 = 0;
  Term _v_141 = 0;
  u32 _v_142 = 0;
  u32 _v_143 = 0;
  u32 _v_144 = 0;
  u32 _registry_5 = r0;
  u32 _registry_6 = r1;
  Term _registry_7 = r2;
  Term _registry_8 = r3;
  u32 _registry_9 = r4;
  u32 _observed_0 = r5;
  u32 _observed_1 = r6;
  u32 _observed_2 = r7;
  Term _observed_3 = r8;
  u32 _observed_4 = r9;
  Term _observed_5 = r10;
  Term _observed_6 = r11;
  Term _observed_7 = r12;
  u32 _observed_8 = r13;
  u32 _observed_9 = r14;
  u32 _observed_10 = r15;
  u32 _observed_11 = r16;
  u32 _observed_12 = r17;
  u32 _observed_13 = r18;
  u32 _observed_14 = r19;
  u32 _observed_15 = r20;
  u32 _observed_16 = r21;
  u32 _observed_17 = r22;
  u32 _observed_18 = r23;
  Term _observed_19 = r24;
  Term _observed_20 = r25;
  Term _observed_21 = r26;
  u32 _observed_22 = r27;
  u32 _observed_23 = r28;
  u32 _observed_24 = r29;
  WL_SPIN
    u32 _v_145 = 0;
    u32 _v_146 = 0;
    u32 _v_147 = 0;
    Term _v_148 = 0;
    Term _v_149 = 0;
    u32 _v_150 = 0;
    u32 _v_151 = 0;
    u32 _v_152 = 0;
    u32 _v_153 = 0;
    Term _v_154 = 0;
    Term _v_155 = 0;
    Term _v_156 = 0;
    Term _v_157 = 0;
    Term _v_158 = 0;
    Term _v_159 = 0;
    u32 _v_160 = 0;
    u32 _v_161 = 0;
    u32 _v_162 = 0;
    u32 _v_163 = 0;
    u32 _v_164 = 0;
    u32 _v_165 = 0;
    u32 _v_166 = 0;
    u32 _v_167 = 0;
    u32 _v_168 = 0;
    u32 _v_169 = 0;
    Term _v_170 = 0;
    Term _v_171 = 0;
    Term _v_172 = 0;
    Term _v_173 = 0;
    u32 _v_174 = 0;
    u32 _v_175 = 0;
    Term _v_176 = 0;
    u32 _v_177 = 0;
    u32 _v_178 = 0;
    u32 _v_179 = 0;
    Term _o_1[35];
    Term _a_0 = 0;
    if (spin_34(e, _o_1, 0, _observed_0, _observed_1, _observed_2, _observed_3, _observed_3 == h8 ? q8 : blk_loc(e.mem, _observed_3), _observed_4, _observed_5, _observed_6, _observed_6 == h11 ? q11 : blk_loc(e.mem, _observed_6), _observed_7, _observed_7 == h12 ? q12 : blk_loc(e.mem, _observed_7), _observed_8, _observed_9, _observed_10, _observed_11, _observed_12, _observed_13, _observed_14, _observed_15, _observed_16, _observed_17, _observed_18, _observed_19, _observed_19 == h24 ? q24 : blk_loc(e.mem, _observed_19), _observed_20, _observed_20 == h25 ? q25 : blk_loc(e.mem, _observed_20), _observed_21, _observed_21 == h26 ? q26 : blk_loc(e.mem, _observed_21), _observed_22, _observed_23, _a_0, _a_0 == h26 ? q26 : _a_0 == h25 ? q25 : _a_0 == h24 ? q24 : _a_0 == h12 ? q12 : _a_0 == h11 ? q11 : _a_0 == h8 ? q8 : _a_0 == h3 ? q3 : _a_0 == h2 ? q2 : blk_loc(e.mem, _a_0), _registry_5, _registry_6, _registry_7, _registry_7 == h2 ? q2 : blk_loc(e.mem, _registry_7), _registry_8, _registry_8 == h3 ? q3 : blk_loc(e.mem, _registry_8), _registry_9, _observed_24) == 0) {
      return 0;
    }
    _v_145 = _o_1[0];
    _v_146 = _o_1[1];
    _v_147 = _o_1[2];
    _v_148 = _o_1[3];
    _v_149 = _o_1[4];
    _v_150 = _o_1[5];
    _v_151 = _o_1[6];
    _v_152 = _o_1[7];
    _v_153 = _o_1[8];
    _v_154 = _o_1[9];
    _v_155 = _o_1[10];
    _v_156 = _o_1[11];
    _v_157 = _o_1[12];
    _v_158 = _o_1[13];
    _v_159 = _o_1[14];
    _v_160 = _o_1[15];
    _v_161 = _o_1[16];
    _v_162 = _o_1[17];
    _v_163 = _o_1[18];
    _v_164 = _o_1[19];
    _v_165 = _o_1[20];
    _v_166 = _o_1[21];
    _v_167 = _o_1[22];
    _v_168 = _o_1[23];
    _v_169 = _o_1[24];
    _v_170 = _o_1[25];
    _v_171 = _o_1[26];
    _v_172 = _o_1[27];
    _v_173 = _o_1[28];
    _v_174 = _o_1[29];
    _v_175 = _o_1[30];
    _v_176 = _o_1[31];
    _v_177 = _o_1[32];
    _v_178 = _o_1[33];
    _v_179 = _o_1[34];
    _v_110 = _v_145;
    _v_111 = _v_146;
    _v_112 = _v_147;
    _v_113 = _v_148;
    _v_114 = _v_149;
    _v_115 = _v_150;
    _v_116 = _v_151;
    _v_117 = _v_152;
    _v_118 = _v_153;
    _v_119 = _v_154;
    _v_120 = _v_155;
    _v_121 = _v_156;
    _v_122 = _v_157;
    _v_123 = _v_158;
    _v_124 = _v_159;
    _v_125 = _v_160;
    _v_126 = _v_161;
    _v_127 = _v_162;
    _v_128 = _v_163;
    _v_129 = _v_164;
    _v_130 = _v_165;
    _v_131 = _v_166;
    _v_132 = _v_167;
    _v_133 = _v_168;
    _v_134 = _v_169;
    _v_135 = _v_170;
    _v_136 = _v_171;
    _v_137 = _v_172;
    _v_138 = _v_173;
    _v_139 = _v_174;
    _v_140 = _v_175;
    _v_141 = _v_176;
    _v_142 = _v_177;
    _v_143 = _v_178;
    _v_144 = _v_179;
  break;
  }
  o[0] = _v_110;
  o[1] = _v_111;
  o[2] = _v_112;
  o[3] = _v_113;
  o[4] = _v_114;
  o[5] = _v_115;
  o[6] = _v_116;
  o[7] = _v_117;
  o[8] = _v_118;
  o[9] = _v_119;
  o[10] = _v_120;
  o[11] = _v_121;
  o[12] = _v_122;
  o[13] = _v_123;
  o[14] = _v_124;
  o[15] = _v_125;
  o[16] = _v_126;
  o[17] = _v_127;
  o[18] = _v_128;
  o[19] = _v_129;
  o[20] = _v_130;
  o[21] = _v_131;
  o[22] = _v_132;
  o[23] = _v_133;
  o[24] = _v_134;
  o[25] = _v_135;
  o[26] = _v_136;
  o[27] = _v_137;
  o[28] = _v_138;
  o[29] = _v_139;
  o[30] = _v_140;
  o[31] = _v_141;
  o[32] = _v_142;
  o[33] = _v_143;
  o[34] = _v_144;
  return 1;
}

INLINE Term spin_39(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_2 = 0;
  Term _v_3 = 0;
  u32 _value_1 = r0;
  WL_SPIN
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _o_0[1];
    if (spin_35(e, _o_0, _value_1) == 0) {
      return 0;
    }
    _v_5 = _o_0[0];
    _v_4 = _v_5;
    _v_2 = _value_1;
    _v_3 = _v_4;
  break;
  }
  o[0] = _v_2;
  o[1] = _v_3;
  return 1;
}

INLINE Term spin_40(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  u32 _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  Term _v_53 = 0;
  u32 _v_54 = 0;
  Term _v_55 = 0;
  Term _v_56 = 0;
  Term _v_57 = 0;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  u32 _v_60 = 0;
  u32 _v_61 = 0;
  u32 _v_62 = 0;
  u32 _v_63 = 0;
  u32 _v_64 = 0;
  u32 _v_65 = 0;
  u32 _v_66 = 0;
  u32 _v_67 = 0;
  u32 _v_68 = 0;
  Term _v_69 = 0;
  Term _v_70 = 0;
  Term _v_71 = 0;
  u32 _v_72 = 0;
  u32 _v_73 = 0;
  u32 _v_74 = 0;
  u32 _world_24 = r0;
  u32 _world_25 = r1;
  u32 _world_26 = r2;
  Term _world_27 = r3;
  u32 _world_28 = r4;
  Term _world_29 = r5;
  Term _world_30 = r6;
  Term _world_31 = r7;
  u32 _world_32 = r8;
  u32 _world_33 = r9;
  u32 _world_34 = r10;
  u32 _world_35 = r11;
  u32 _world_36 = r12;
  u32 _world_37 = r13;
  u32 _world_38 = r14;
  u32 _world_39 = r15;
  u32 _world_40 = r16;
  u32 _world_41 = r17;
  u32 _world_42 = r18;
  Term _world_43 = r19;
  Term _world_44 = r20;
  Term _world_45 = r21;
  u32 _world_46 = r22;
  u32 _world_47 = r23;
  WL_SPIN
    _v_50 = _world_24;
    _v_51 = _world_25;
    _v_52 = _world_26;
    _v_53 = _world_27;
    _v_54 = _world_28;
    _v_55 = _world_29;
    _v_56 = _world_30;
    _v_57 = _world_31;
    _v_58 = _world_32;
    _v_59 = _world_33;
    _v_60 = _world_34;
    _v_61 = _world_35;
    _v_62 = _world_36;
    _v_63 = _world_37;
    _v_64 = _world_38;
    _v_65 = _world_39;
    _v_66 = _world_40;
    _v_67 = _world_41;
    _v_68 = _world_42;
    _v_69 = _world_43;
    _v_70 = _world_44;
    _v_71 = _world_45;
    _v_72 = _world_46;
    _v_73 = _world_47;
    _v_74 = _world_24;
  break;
  }
  o[0] = _v_50;
  o[1] = _v_51;
  o[2] = _v_52;
  o[3] = _v_53;
  o[4] = _v_54;
  o[5] = _v_55;
  o[6] = _v_56;
  o[7] = _v_57;
  o[8] = _v_58;
  o[9] = _v_59;
  o[10] = _v_60;
  o[11] = _v_61;
  o[12] = _v_62;
  o[13] = _v_63;
  o[14] = _v_64;
  o[15] = _v_65;
  o[16] = _v_66;
  o[17] = _v_67;
  o[18] = _v_68;
  o[19] = _v_69;
  o[20] = _v_70;
  o[21] = _v_71;
  o[22] = _v_72;
  o[23] = _v_73;
  o[24] = _v_74;
  return 1;
}

INLINE Term spin_41(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9, u32 r10, Term r11, Term r12, u64 q12, Term r13, u64 q13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, u32 r19, u32 r20, u32 r21, u32 r22, u32 r23, u32 r24, Term r25, u64 q25, Term r26, u64 q26, Term r27, u64 q27, u32 r28, u32 r29, Term r30, u64 q30) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h9 = r9;
  Term h12 = r12;
  Term h13 = r13;
  Term h25 = r25;
  Term h26 = r26;
  Term h27 = r27;
  Term h30 = r30;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _v_38 = 0;
  Term _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  Term _v_44 = 0;
  Term _v_45 = 0;
  Term _v_46 = 0;
  Term _v_47 = 0;
  Term _v_48 = 0;
  Term _v_49 = 0;
  u32 _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  u32 _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  Term _v_60 = 0;
  Term _v_61 = 0;
  Term _v_62 = 0;
  Term _v_63 = 0;
  u32 _v_64 = 0;
  u32 _v_65 = 0;
  Term _v_66 = 0;
  u32 _v_67 = 0;
  u32 _v_68 = 0;
  u32 _v_69 = 0;
  u32 _registry_0 = r0;
  u32 _registry_1 = r1;
  Term _registry_2 = r2;
  Term _registry_3 = r3;
  u32 _registry_4 = r4;
  u32 _outcome_0 = r5;
  u32 _outcome_1 = r6;
  u32 _outcome_2 = r7;
  u32 _outcome_3 = r8;
  Term _outcome_4 = r9;
  u32 _outcome_5 = r10;
  Term _outcome_6 = r11;
  Term _outcome_7 = r12;
  Term _outcome_8 = r13;
  u32 _outcome_9 = r14;
  u32 _outcome_10 = r15;
  u32 _outcome_11 = r16;
  u32 _outcome_12 = r17;
  u32 _outcome_13 = r18;
  u32 _outcome_14 = r19;
  u32 _outcome_15 = r20;
  u32 _outcome_16 = r21;
  u32 _outcome_17 = r22;
  u32 _outcome_18 = r23;
  u32 _outcome_19 = r24;
  Term _outcome_20 = r25;
  Term _outcome_21 = r26;
  Term _outcome_22 = r27;
  u32 _outcome_23 = r28;
  u32 _outcome_24 = r29;
  Term _outcome_25 = r30;
  WL_SPIN
    if (_outcome_0 == 1) {
      _v_35 = 0;
      _v_36 = _registry_0;
      _v_37 = _registry_1;
      _v_38 = _registry_2;
      _v_39 = _registry_3;
      _v_40 = _registry_4;
      _v_41 = 1;
      _v_42 = _outcome_1;
      _v_43 = _outcome_2;
      _v_44 = _outcome_3;
      _v_45 = _outcome_4;
      _v_46 = _outcome_5;
      _v_47 = _outcome_6;
      _v_48 = _outcome_7;
      _v_49 = _outcome_8;
      _v_50 = _outcome_9;
      _v_51 = _outcome_10;
      _v_52 = _outcome_11;
      _v_53 = _outcome_12;
      _v_54 = _outcome_13;
      _v_55 = _outcome_14;
      _v_56 = _outcome_15;
      _v_57 = _outcome_16;
      _v_58 = _outcome_17;
      _v_59 = _outcome_18;
      _v_60 = _outcome_19;
      _v_61 = _outcome_20;
      _v_62 = _outcome_21;
      _v_63 = _outcome_22;
      _v_64 = _outcome_23;
      _v_65 = _outcome_24;
      _v_66 = _outcome_25;
      _v_67 = 0;
      _v_68 = 0;
      _v_69 = 0;
    } else {
      u32 _v_70 = 0;
      u32 _v_71 = 0;
      u32 _v_72 = 0;
      Term _v_73 = 0;
      u32 _v_74 = 0;
      Term _v_75 = 0;
      Term _v_76 = 0;
      Term _v_77 = 0;
      u32 _v_78 = 0;
      u32 _v_79 = 0;
      u32 _v_80 = 0;
      u32 _v_81 = 0;
      u32 _v_82 = 0;
      u32 _v_83 = 0;
      u32 _v_84 = 0;
      u32 _v_85 = 0;
      u32 _v_86 = 0;
      u32 _v_87 = 0;
      u32 _v_88 = 0;
      Term _v_89 = 0;
      Term _v_90 = 0;
      Term _v_91 = 0;
      u32 _v_92 = 0;
      u32 _v_93 = 0;
      u32 _v_94 = 0;
      u32 _v_95 = 0;
      u32 _v_96 = 0;
      u32 _v_97 = 0;
      Term _v_98 = 0;
      u32 _v_99 = 0;
      Term _v_100 = 0;
      Term _v_101 = 0;
      Term _v_102 = 0;
      u32 _v_103 = 0;
      u32 _v_104 = 0;
      u32 _v_105 = 0;
      u32 _v_106 = 0;
      u32 _v_107 = 0;
      u32 _v_108 = 0;
      u32 _v_109 = 0;
      u32 _v_110 = 0;
      u32 _v_111 = 0;
      u32 _v_112 = 0;
      u32 _v_113 = 0;
      Term _v_114 = 0;
      Term _v_115 = 0;
      Term _v_116 = 0;
      u32 _v_117 = 0;
      u32 _v_118 = 0;
      u32 _v_119 = 0;
      Term _o_0[25];
      if (spin_37(e, _o_0, _outcome_1, _outcome_2, _outcome_3, _outcome_4, _outcome_4 == h9 ? q9 : blk_loc(e.mem, _outcome_4), _outcome_5, _outcome_6, _outcome_7, _outcome_7 == h12 ? q12 : blk_loc(e.mem, _outcome_7), _outcome_8, _outcome_8 == h13 ? q13 : blk_loc(e.mem, _outcome_8), _outcome_9, _outcome_10, _outcome_11, _outcome_12, _outcome_13, _outcome_14, _outcome_15, _outcome_16, _outcome_17, _outcome_18, _outcome_19, _outcome_20, _outcome_20 == h25 ? q25 : blk_loc(e.mem, _outcome_20), _outcome_21, _outcome_21 == h26 ? q26 : blk_loc(e.mem, _outcome_21), _outcome_22, _outcome_22 == h27 ? q27 : blk_loc(e.mem, _outcome_22), _outcome_23, _outcome_24) == 0) {
        return 0;
      }
      _v_95 = _o_0[0];
      _v_96 = _o_0[1];
      _v_97 = _o_0[2];
      _v_98 = _o_0[3];
      _v_99 = _o_0[4];
      _v_100 = _o_0[5];
      _v_101 = _o_0[6];
      _v_102 = _o_0[7];
      _v_103 = _o_0[8];
      _v_104 = _o_0[9];
      _v_105 = _o_0[10];
      _v_106 = _o_0[11];
      _v_107 = _o_0[12];
      _v_108 = _o_0[13];
      _v_109 = _o_0[14];
      _v_110 = _o_0[15];
      _v_111 = _o_0[16];
      _v_112 = _o_0[17];
      _v_113 = _o_0[18];
      _v_114 = _o_0[19];
      _v_115 = _o_0[20];
      _v_116 = _o_0[21];
      _v_117 = _o_0[22];
      _v_118 = _o_0[23];
      _v_119 = _o_0[24];
      _v_70 = _v_95;
      _v_71 = _v_96;
      _v_72 = _v_97;
      _v_73 = _v_98;
      _v_74 = _v_99;
      _v_75 = _v_100;
      _v_76 = _v_101;
      _v_77 = _v_102;
      _v_78 = _v_103;
      _v_79 = _v_104;
      _v_80 = _v_105;
      _v_81 = _v_106;
      _v_82 = _v_107;
      _v_83 = _v_108;
      _v_84 = _v_109;
      _v_85 = _v_110;
      _v_86 = _v_111;
      _v_87 = _v_112;
      _v_88 = _v_113;
      _v_89 = _v_114;
      _v_90 = _v_115;
      _v_91 = _v_116;
      _v_92 = _v_117;
      _v_93 = _v_118;
      _v_94 = _v_119;
      u32 _v_120 = 0;
      u32 _v_121 = 0;
      u32 _v_122 = 0;
      Term _v_123 = 0;
      Term _v_124 = 0;
      u32 _v_125 = 0;
      u32 _v_126 = 0;
      u32 _v_127 = 0;
      u32 _v_128 = 0;
      Term _v_129 = 0;
      Term _v_130 = 0;
      Term _v_131 = 0;
      Term _v_132 = 0;
      Term _v_133 = 0;
      Term _v_134 = 0;
      u32 _v_135 = 0;
      u32 _v_136 = 0;
      u32 _v_137 = 0;
      u32 _v_138 = 0;
      u32 _v_139 = 0;
      u32 _v_140 = 0;
      u32 _v_141 = 0;
      u32 _v_142 = 0;
      u32 _v_143 = 0;
      u32 _v_144 = 0;
      Term _v_145 = 0;
      Term _v_146 = 0;
      Term _v_147 = 0;
      Term _v_148 = 0;
      u32 _v_149 = 0;
      u32 _v_150 = 0;
      Term _v_151 = 0;
      u32 _v_152 = 0;
      u32 _v_153 = 0;
      u32 _v_154 = 0;
      Term _o_1[35];
      if (spin_38(e, _o_1, _registry_0, _registry_1, _registry_2, _registry_2 == h2 ? q2 : blk_loc(e.mem, _registry_2), _registry_3, _registry_3 == h3 ? q3 : blk_loc(e.mem, _registry_3), _registry_4, _v_70, _v_71, _v_72, _v_73, _v_73 == h30 ? q30 : _v_73 == h27 ? q27 : _v_73 == h26 ? q26 : _v_73 == h25 ? q25 : _v_73 == h13 ? q13 : _v_73 == h12 ? q12 : _v_73 == h9 ? q9 : _v_73 == h3 ? q3 : _v_73 == h2 ? q2 : blk_loc(e.mem, _v_73), _v_74, _v_75, _v_76, _v_76 == h30 ? q30 : _v_76 == h27 ? q27 : _v_76 == h26 ? q26 : _v_76 == h25 ? q25 : _v_76 == h13 ? q13 : _v_76 == h12 ? q12 : _v_76 == h9 ? q9 : _v_76 == h3 ? q3 : _v_76 == h2 ? q2 : blk_loc(e.mem, _v_76), _v_77, _v_77 == h30 ? q30 : _v_77 == h27 ? q27 : _v_77 == h26 ? q26 : _v_77 == h25 ? q25 : _v_77 == h13 ? q13 : _v_77 == h12 ? q12 : _v_77 == h9 ? q9 : _v_77 == h3 ? q3 : _v_77 == h2 ? q2 : blk_loc(e.mem, _v_77), _v_78, _v_79, _v_80, _v_81, _v_82, _v_83, _v_84, _v_85, _v_86, _v_87, _v_88, _v_89, _v_89 == h30 ? q30 : _v_89 == h27 ? q27 : _v_89 == h26 ? q26 : _v_89 == h25 ? q25 : _v_89 == h13 ? q13 : _v_89 == h12 ? q12 : _v_89 == h9 ? q9 : _v_89 == h3 ? q3 : _v_89 == h2 ? q2 : blk_loc(e.mem, _v_89), _v_90, _v_90 == h30 ? q30 : _v_90 == h27 ? q27 : _v_90 == h26 ? q26 : _v_90 == h25 ? q25 : _v_90 == h13 ? q13 : _v_90 == h12 ? q12 : _v_90 == h9 ? q9 : _v_90 == h3 ? q3 : _v_90 == h2 ? q2 : blk_loc(e.mem, _v_90), _v_91, _v_91 == h30 ? q30 : _v_91 == h27 ? q27 : _v_91 == h26 ? q26 : _v_91 == h25 ? q25 : _v_91 == h13 ? q13 : _v_91 == h12 ? q12 : _v_91 == h9 ? q9 : _v_91 == h3 ? q3 : _v_91 == h2 ? q2 : blk_loc(e.mem, _v_91), _v_92, _v_93, _v_94) == 0) {
        return 0;
      }
      _v_120 = _o_1[0];
      _v_121 = _o_1[1];
      _v_122 = _o_1[2];
      _v_123 = _o_1[3];
      _v_124 = _o_1[4];
      _v_125 = _o_1[5];
      _v_126 = _o_1[6];
      _v_127 = _o_1[7];
      _v_128 = _o_1[8];
      _v_129 = _o_1[9];
      _v_130 = _o_1[10];
      _v_131 = _o_1[11];
      _v_132 = _o_1[12];
      _v_133 = _o_1[13];
      _v_134 = _o_1[14];
      _v_135 = _o_1[15];
      _v_136 = _o_1[16];
      _v_137 = _o_1[17];
      _v_138 = _o_1[18];
      _v_139 = _o_1[19];
      _v_140 = _o_1[20];
      _v_141 = _o_1[21];
      _v_142 = _o_1[22];
      _v_143 = _o_1[23];
      _v_144 = _o_1[24];
      _v_145 = _o_1[25];
      _v_146 = _o_1[26];
      _v_147 = _o_1[27];
      _v_148 = _o_1[28];
      _v_149 = _o_1[29];
      _v_150 = _o_1[30];
      _v_151 = _o_1[31];
      _v_152 = _o_1[32];
      _v_153 = _o_1[33];
      _v_154 = _o_1[34];
      _v_35 = _v_120;
      _v_36 = _v_121;
      _v_37 = _v_122;
      _v_38 = _v_123;
      _v_39 = _v_124;
      _v_40 = _v_125;
      _v_41 = _v_126;
      _v_42 = _v_127;
      _v_43 = _v_128;
      _v_44 = _v_129;
      _v_45 = _v_130;
      _v_46 = _v_131;
      _v_47 = _v_132;
      _v_48 = _v_133;
      _v_49 = _v_134;
      _v_50 = _v_135;
      _v_51 = _v_136;
      _v_52 = _v_137;
      _v_53 = _v_138;
      _v_54 = _v_139;
      _v_55 = _v_140;
      _v_56 = _v_141;
      _v_57 = _v_142;
      _v_58 = _v_143;
      _v_59 = _v_144;
      _v_60 = _v_145;
      _v_61 = _v_146;
      _v_62 = _v_147;
      _v_63 = _v_148;
      _v_64 = _v_149;
      _v_65 = _v_150;
      _v_66 = _v_151;
      _v_67 = _v_152;
      _v_68 = _v_153;
      _v_69 = _v_154;
    }
  break;
  }
  o[0] = _v_35;
  o[1] = _v_36;
  o[2] = _v_37;
  o[3] = _v_38;
  o[4] = _v_39;
  o[5] = _v_40;
  o[6] = _v_41;
  o[7] = _v_42;
  o[8] = _v_43;
  o[9] = _v_44;
  o[10] = _v_45;
  o[11] = _v_46;
  o[12] = _v_47;
  o[13] = _v_48;
  o[14] = _v_49;
  o[15] = _v_50;
  o[16] = _v_51;
  o[17] = _v_52;
  o[18] = _v_53;
  o[19] = _v_54;
  o[20] = _v_55;
  o[21] = _v_56;
  o[22] = _v_57;
  o[23] = _v_58;
  o[24] = _v_59;
  o[25] = _v_60;
  o[26] = _v_61;
  o[27] = _v_62;
  o[28] = _v_63;
  o[29] = _v_64;
  o[30] = _v_65;
  o[31] = _v_66;
  o[32] = _v_67;
  o[33] = _v_68;
  o[34] = _v_69;
  return 1;
}

INLINE Term spin_42(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_2 = 0;
  u32 _available_0 = r0;
  u32 _clock_0 = r1;
  WL_SPIN
    if (_available_0 == 0) {
      _v_2 = _clock_0;
    } else {
      _v_2 = U32_BIN(_clock_0, +, 1ull);
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_43(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, Term r4, u64 q4, u32 r5, Term r6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, u32 r19, Term r20, u64 q20, Term r21, u64 q21, Term r22, u64 q22, u32 r23, u32 r24, Term r25, u64 q25, Term r26, u64 q26) {
  u32 wpoll = 0;
  Term h4 = r4;
  Term h7 = r7;
  Term h8 = r8;
  Term h20 = r20;
  Term h21 = r21;
  Term h22 = r22;
  Term h25 = r25;
  Term h26 = r26;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  Term _v_45 = 0;
  Term _v_46 = 0;
  Term _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  u32 _v_51 = 0;
  u32 _available_0 = r0;
  u32 _world_24 = r1;
  u32 _world_25 = r2;
  u32 _world_26 = r3;
  Term _world_27 = r4;
  u32 _world_28 = r5;
  Term _world_29 = r6;
  Term _world_30 = r7;
  Term _world_31 = r8;
  u32 _world_32 = r9;
  u32 _world_33 = r10;
  u32 _world_34 = r11;
  u32 _world_35 = r12;
  u32 _world_36 = r13;
  u32 _world_37 = r14;
  u32 _world_38 = r15;
  u32 _world_39 = r16;
  u32 _world_40 = r17;
  u32 _world_41 = r18;
  u32 _world_42 = r19;
  Term _world_43 = r20;
  Term _world_44 = r21;
  Term _world_45 = r22;
  u32 _world_46 = r23;
  u32 _world_47 = r24;
  Term _name_1 = r25;
  Term _access_1 = r26;
  WL_SPIN
    if (_available_0 == 0) {
      term_sink(e, _name_1);
      term_sink(e, _access_1);
      _v_26 = _world_24;
      _v_27 = _world_25;
      _v_28 = _world_26;
      _v_29 = _world_27;
      _v_30 = _world_28;
      _v_31 = _world_29;
      _v_32 = _world_30;
      _v_33 = _world_31;
      _v_34 = _world_32;
      _v_35 = _world_33;
      _v_36 = _world_34;
      _v_37 = _world_35;
      _v_38 = _world_36;
      _v_39 = _world_37;
      _v_40 = _world_38;
      _v_41 = _world_39;
      _v_42 = _world_40;
      _v_43 = _world_41;
      _v_44 = _world_42;
      _v_45 = _world_43;
      _v_46 = _world_44;
      _v_47 = _world_45;
      _v_48 = _world_46;
      _v_49 = _world_47;
      _v_50 = 1;
      _v_51 = 3;
    } else {
      u64 _nd_0 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_0 + 0] = rfc_seal(e, _world_46);
      e.mem[_nd_0 + 1] = rfc_seal(e, _name_1);
      e.mem[_nd_0 + 2] = rfc_seal(e, _access_1);
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID________________BENDVY_SRC_ECS_WORLD_REGISTRATIONMETA, _nd_0));
      e.mem[_nd_1 + 1] = rfc_seal(e, _world_45);
      _v_26 = _world_24;
      _v_27 = _world_25;
      _v_28 = _world_26;
      _v_29 = _world_27;
      _v_30 = _world_28;
      _v_31 = _world_29;
      _v_32 = _world_30;
      _v_33 = _world_31;
      _v_34 = _world_32;
      _v_35 = _world_33;
      _v_36 = _world_34;
      _v_37 = _world_35;
      _v_38 = _world_36;
      _v_39 = _world_37;
      _v_40 = _world_38;
      _v_41 = _world_39;
      _v_42 = _world_40;
      _v_43 = _world_41;
      _v_44 = _world_42;
      _v_45 = _world_43;
      _v_46 = _world_44;
      _v_47 = term_ctr(CID_CON, _nd_1);
      _v_48 = U32_BIN(_world_46, +, 1ull);
      _v_49 = _world_47;
      _v_50 = 0;
      _v_51 = _world_46;
    }
  break;
  }
  o[0] = _v_26;
  o[1] = _v_27;
  o[2] = _v_28;
  o[3] = _v_29;
  o[4] = _v_30;
  o[5] = _v_31;
  o[6] = _v_32;
  o[7] = _v_33;
  o[8] = _v_34;
  o[9] = _v_35;
  o[10] = _v_36;
  o[11] = _v_37;
  o[12] = _v_38;
  o[13] = _v_39;
  o[14] = _v_40;
  o[15] = _v_41;
  o[16] = _v_42;
  o[17] = _v_43;
  o[18] = _v_44;
  o[19] = _v_45;
  o[20] = _v_46;
  o[21] = _v_47;
  o[22] = _v_48;
  o[23] = _v_49;
  o[24] = _v_50;
  o[25] = _v_51;
  return 1;
}

INLINE Term spin_44(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23, u32 r24, u32 r25, u32 r26, Term r27, u64 q27, Term r28, u64 q28) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  Term h27 = r27;
  Term h28 = r28;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  Term _v_34 = 0;
  u32 _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  Term _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  Term _v_50 = 0;
  Term _v_51 = 0;
  Term _v_52 = 0;
  u32 _v_53 = 0;
  u32 _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  Term _v_57 = 0;
  Term _v_58 = 0;
  u32 _v_59 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  Term _world_6 = r6;
  Term _world_7 = r7;
  u32 _world_8 = r8;
  u32 _world_9 = r9;
  u32 _world_10 = r10;
  u32 _world_11 = r11;
  u32 _world_12 = r12;
  u32 _world_13 = r13;
  u32 _world_14 = r14;
  u32 _world_15 = r15;
  u32 _world_16 = r16;
  u32 _world_17 = r17;
  u32 _world_18 = r18;
  Term _world_19 = r19;
  Term _world_20 = r20;
  Term _world_21 = r21;
  u32 _world_22 = r22;
  u32 _world_23 = r23;
  u32 _result_0 = r24;
  u32 _result_1 = r25;
  u32 _namespace_1 = r26;
  Term _name_1 = r27;
  Term _access_1 = r28;
  WL_SPIN
    if (_result_0 == 1) {
      term_sink(e, _name_1);
      term_sink(e, _access_1);
      _v_30 = 1;
      _v_31 = _world_0;
      _v_32 = _world_1;
      _v_33 = _world_2;
      _v_34 = _world_3;
      _v_35 = _world_4;
      _v_36 = _world_5;
      _v_37 = _world_6;
      _v_38 = _world_7;
      _v_39 = _world_8;
      _v_40 = _world_9;
      _v_41 = _world_10;
      _v_42 = _world_11;
      _v_43 = _world_12;
      _v_44 = _world_13;
      _v_45 = _world_14;
      _v_46 = _world_15;
      _v_47 = _world_16;
      _v_48 = _world_17;
      _v_49 = _world_18;
      _v_50 = _world_19;
      _v_51 = _world_20;
      _v_52 = _world_21;
      _v_53 = _world_22;
      _v_54 = _world_23;
      _v_55 = 0;
      _v_56 = 0;
      _v_57 = 0;
      _v_58 = 0;
      _v_59 = 0;
    } else {
      _v_30 = 0;
      _v_31 = _world_0;
      _v_32 = _world_1;
      _v_33 = _world_2;
      _v_34 = _world_3;
      _v_35 = _world_4;
      _v_36 = _world_5;
      _v_37 = _world_6;
      _v_38 = _world_7;
      _v_39 = _world_8;
      _v_40 = _world_9;
      _v_41 = _world_10;
      _v_42 = _world_11;
      _v_43 = _world_12;
      _v_44 = _world_13;
      _v_45 = _world_14;
      _v_46 = _world_15;
      _v_47 = _world_16;
      _v_48 = _world_17;
      _v_49 = _world_18;
      _v_50 = _world_19;
      _v_51 = _world_20;
      _v_52 = _world_21;
      _v_53 = _world_22;
      _v_54 = _world_23;
      _v_55 = _namespace_1;
      _v_56 = _result_1;
      _v_57 = _name_1;
      _v_58 = _access_1;
      _v_59 = 0ull;
    }
  break;
  }
  o[0] = _v_30;
  o[1] = _v_31;
  o[2] = _v_32;
  o[3] = _v_33;
  o[4] = _v_34;
  o[5] = _v_35;
  o[6] = _v_36;
  o[7] = _v_37;
  o[8] = _v_38;
  o[9] = _v_39;
  o[10] = _v_40;
  o[11] = _v_41;
  o[12] = _v_42;
  o[13] = _v_43;
  o[14] = _v_44;
  o[15] = _v_45;
  o[16] = _v_46;
  o[17] = _v_47;
  o[18] = _v_48;
  o[19] = _v_49;
  o[20] = _v_50;
  o[21] = _v_51;
  o[22] = _v_52;
  o[23] = _v_53;
  o[24] = _v_54;
  o[25] = _v_55;
  o[26] = _v_56;
  o[27] = _v_57;
  o[28] = _v_58;
  o[29] = _v_59;
  return 1;
}

INLINE Term spin_45(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_4 = 0;
  Term _v_5 = 0;
  u32 _value_1 = r0;
  WL_SPIN
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _o_0[2];
    if (spin_39(e, _o_0, _value_1) == 0) {
      return 0;
    }
    _v_6 = _o_0[0];
    _v_7 = _o_0[1];
    _v_4 = _v_6;
    _v_5 = _v_7;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  return 1;
}

INLINE Term spin_46(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_2 = 0;
  Term _v_3 = 0;
  Term _head_0 = r0;
  Term _pair_0 = r1;
  Term _pair_1 = r2;
  WL_SPIN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _head_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _pair_0);
    _v_2 = term_ctr(CID_CON, _nd_0);
    _v_3 = nat_chk(e, _pair_1 + 1);
  break;
  }
  o[0] = _v_2;
  o[1] = _v_3;
  return 1;
}

INLINE Term spin_47(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9, Term r10, u64 q10, Term r11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, u32 r16, u32 r17, u32 r18, u32 r19, u32 r20, u32 r21, u32 r22, u32 r23, u32 r24, Term r25, u64 q25, Term r26, u64 q26, Term r27, u64 q27, Term r28, u64 q28, u32 r29, u32 r30, Term r31, u64 q31, u32 r32, u32 r33, u32 r34) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h9 = r9;
  Term h10 = r10;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  Term h25 = r25;
  Term h26 = r26;
  Term h27 = r27;
  Term h28 = r28;
  Term h31 = r31;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _v_38 = 0;
  Term _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  Term _v_44 = 0;
  Term _v_45 = 0;
  Term _v_46 = 0;
  Term _v_47 = 0;
  Term _v_48 = 0;
  Term _v_49 = 0;
  u32 _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  u32 _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  Term _v_60 = 0;
  Term _v_61 = 0;
  Term _v_62 = 0;
  Term _v_63 = 0;
  u32 _v_64 = 0;
  u32 _v_65 = 0;
  Term _v_66 = 0;
  u32 _v_67 = 0;
  u32 _v_68 = 0;
  u32 _v_69 = 0;
  u32 _result_0 = r0;
  u32 _result_1 = r1;
  u32 _result_2 = r2;
  Term _result_3 = r3;
  Term _result_4 = r4;
  u32 _result_5 = r5;
  u32 _result_6 = r6;
  u32 _result_7 = r7;
  u32 _result_8 = r8;
  Term _result_9 = r9;
  Term _result_10 = r10;
  Term _result_11 = r11;
  Term _result_12 = r12;
  Term _result_13 = r13;
  Term _result_14 = r14;
  u32 _result_15 = r15;
  u32 _result_16 = r16;
  u32 _result_17 = r17;
  u32 _result_18 = r18;
  u32 _result_19 = r19;
  u32 _result_20 = r20;
  u32 _result_21 = r21;
  u32 _result_22 = r22;
  u32 _result_23 = r23;
  u32 _result_24 = r24;
  Term _result_25 = r25;
  Term _result_26 = r26;
  Term _result_27 = r27;
  Term _result_28 = r28;
  u32 _result_29 = r29;
  u32 _result_30 = r30;
  Term _result_31 = r31;
  u32 _result_32 = r32;
  u32 _result_33 = r33;
  u32 _result_34 = r34;
  WL_SPIN
    if (_result_0 == 1) {
      _v_35 = 1;
      _v_36 = _result_1;
      _v_37 = _result_2;
      _v_38 = _result_3;
      _v_39 = _result_4;
      _v_40 = _result_5;
      _v_41 = _result_6;
      _v_42 = _result_7;
      _v_43 = _result_8;
      _v_44 = _result_9;
      _v_45 = _result_10;
      _v_46 = _result_11;
      _v_47 = _result_12;
      _v_48 = _result_13;
      _v_49 = _result_14;
      _v_50 = _result_15;
      _v_51 = _result_16;
      _v_52 = _result_17;
      _v_53 = _result_18;
      _v_54 = _result_19;
      _v_55 = _result_20;
      _v_56 = _result_21;
      _v_57 = _result_22;
      _v_58 = _result_23;
      _v_59 = _result_24;
      _v_60 = _result_25;
      _v_61 = _result_26;
      _v_62 = _result_27;
      _v_63 = _result_28;
      _v_64 = _result_29;
      _v_65 = _result_30;
      _v_66 = _result_31;
      _v_67 = _result_32;
      _v_68 = _result_33;
      _v_69 = _result_34;
    } else {
      u32 _v_70 = 0;
      u32 _v_71 = 0;
      u32 _v_72 = 0;
      Term _v_73 = 0;
      Term _v_74 = 0;
      u32 _v_75 = 0;
      u32 _v_76 = 0;
      u32 _v_77 = 0;
      u32 _v_78 = 0;
      Term _v_79 = 0;
      Term _v_80 = 0;
      Term _v_81 = 0;
      Term _v_82 = 0;
      Term _v_83 = 0;
      Term _v_84 = 0;
      u32 _v_85 = 0;
      u32 _v_86 = 0;
      u32 _v_87 = 0;
      u32 _v_88 = 0;
      u32 _v_89 = 0;
      u32 _v_90 = 0;
      u32 _v_91 = 0;
      u32 _v_92 = 0;
      u32 _v_93 = 0;
      u32 _v_94 = 0;
      Term _v_95 = 0;
      Term _v_96 = 0;
      Term _v_97 = 0;
      Term _v_98 = 0;
      u32 _v_99 = 0;
      u32 _v_100 = 0;
      Term _v_101 = 0;
      u32 _v_102 = 0;
      u32 _v_103 = 0;
      u32 _v_104 = 0;
      Term _o_0[35];
      if (spin_41(e, _o_0, _result_1, _result_2, _result_3, _result_3 == h3 ? q3 : blk_loc(e.mem, _result_3), _result_4, _result_4 == h4 ? q4 : blk_loc(e.mem, _result_4), _result_5, _result_6, _result_7, _result_8, _result_9, _result_10, _result_10 == h10 ? q10 : blk_loc(e.mem, _result_10), _result_11, _result_12, _result_13, _result_13 == h13 ? q13 : blk_loc(e.mem, _result_13), _result_14, _result_14 == h14 ? q14 : blk_loc(e.mem, _result_14), _result_15, _result_16, _result_17, _result_18, _result_19, _result_20, _result_21, _result_22, _result_23, _result_24, _result_25, _result_26, _result_26 == h26 ? q26 : blk_loc(e.mem, _result_26), _result_27, _result_27 == h27 ? q27 : blk_loc(e.mem, _result_27), _result_28, _result_28 == h28 ? q28 : blk_loc(e.mem, _result_28), _result_29, _result_30, _result_31, _result_31 == h31 ? q31 : blk_loc(e.mem, _result_31)) == 0) {
        return 0;
      }
      _v_70 = _o_0[0];
      _v_71 = _o_0[1];
      _v_72 = _o_0[2];
      _v_73 = _o_0[3];
      _v_74 = _o_0[4];
      _v_75 = _o_0[5];
      _v_76 = _o_0[6];
      _v_77 = _o_0[7];
      _v_78 = _o_0[8];
      _v_79 = _o_0[9];
      _v_80 = _o_0[10];
      _v_81 = _o_0[11];
      _v_82 = _o_0[12];
      _v_83 = _o_0[13];
      _v_84 = _o_0[14];
      _v_85 = _o_0[15];
      _v_86 = _o_0[16];
      _v_87 = _o_0[17];
      _v_88 = _o_0[18];
      _v_89 = _o_0[19];
      _v_90 = _o_0[20];
      _v_91 = _o_0[21];
      _v_92 = _o_0[22];
      _v_93 = _o_0[23];
      _v_94 = _o_0[24];
      _v_95 = _o_0[25];
      _v_96 = _o_0[26];
      _v_97 = _o_0[27];
      _v_98 = _o_0[28];
      _v_99 = _o_0[29];
      _v_100 = _o_0[30];
      _v_101 = _o_0[31];
      _v_102 = _o_0[32];
      _v_103 = _o_0[33];
      _v_104 = _o_0[34];
      _v_35 = _v_70;
      _v_36 = _v_71;
      _v_37 = _v_72;
      _v_38 = _v_73;
      _v_39 = _v_74;
      _v_40 = _v_75;
      _v_41 = _v_76;
      _v_42 = _v_77;
      _v_43 = _v_78;
      _v_44 = _v_79;
      _v_45 = _v_80;
      _v_46 = _v_81;
      _v_47 = _v_82;
      _v_48 = _v_83;
      _v_49 = _v_84;
      _v_50 = _v_85;
      _v_51 = _v_86;
      _v_52 = _v_87;
      _v_53 = _v_88;
      _v_54 = _v_89;
      _v_55 = _v_90;
      _v_56 = _v_91;
      _v_57 = _v_92;
      _v_58 = _v_93;
      _v_59 = _v_94;
      _v_60 = _v_95;
      _v_61 = _v_96;
      _v_62 = _v_97;
      _v_63 = _v_98;
      _v_64 = _v_99;
      _v_65 = _v_100;
      _v_66 = _v_101;
      _v_67 = _v_102;
      _v_68 = _v_103;
      _v_69 = _v_104;
    }
  break;
  }
  o[0] = _v_35;
  o[1] = _v_36;
  o[2] = _v_37;
  o[3] = _v_38;
  o[4] = _v_39;
  o[5] = _v_40;
  o[6] = _v_41;
  o[7] = _v_42;
  o[8] = _v_43;
  o[9] = _v_44;
  o[10] = _v_45;
  o[11] = _v_46;
  o[12] = _v_47;
  o[13] = _v_48;
  o[14] = _v_49;
  o[15] = _v_50;
  o[16] = _v_51;
  o[17] = _v_52;
  o[18] = _v_53;
  o[19] = _v_54;
  o[20] = _v_55;
  o[21] = _v_56;
  o[22] = _v_57;
  o[23] = _v_58;
  o[24] = _v_59;
  o[25] = _v_60;
  o[26] = _v_61;
  o[27] = _v_62;
  o[28] = _v_63;
  o[29] = _v_64;
  o[30] = _v_65;
  o[31] = _v_66;
  o[32] = _v_67;
  o[33] = _v_68;
  o[34] = _v_69;
  return 1;
}

INLINE Term spin_48(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9, u32 r10, Term r11, Term r12, u64 q12, Term r13, u64 q13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, u32 r19, u32 r20, u32 r21, u32 r22, u32 r23, u32 r24, Term r25, u64 q25, Term r26, u64 q26, Term r27, u64 q27, u32 r28, u32 r29, Term r30, u64 q30) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h9 = r9;
  Term h12 = r12;
  Term h13 = r13;
  Term h25 = r25;
  Term h26 = r26;
  Term h27 = r27;
  Term h30 = r30;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  Term _v_34 = 0;
  u32 _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  Term _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  Term _v_50 = 0;
  Term _v_51 = 0;
  Term _v_52 = 0;
  u32 _v_53 = 0;
  u32 _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  Term _v_58 = 0;
  Term _v_59 = 0;
  u32 _v_60 = 0;
  Term _v_61 = 0;
  u32 _registry_0 = r0;
  u32 _registry_1 = r1;
  Term _registry_2 = r2;
  Term _registry_3 = r3;
  u32 _registry_4 = r4;
  u32 _result_35 = r5;
  u32 _result_36 = r6;
  u32 _result_37 = r7;
  u32 _result_38 = r8;
  Term _result_39 = r9;
  u32 _result_40 = r10;
  Term _result_41 = r11;
  Term _result_42 = r12;
  Term _result_43 = r13;
  u32 _result_44 = r14;
  u32 _result_45 = r15;
  u32 _result_46 = r16;
  u32 _result_47 = r17;
  u32 _result_48 = r18;
  u32 _result_49 = r19;
  u32 _result_50 = r20;
  u32 _result_51 = r21;
  u32 _result_52 = r22;
  u32 _result_53 = r23;
  u32 _result_54 = r24;
  Term _result_55 = r25;
  Term _result_56 = r26;
  Term _result_57 = r27;
  u32 _result_58 = r28;
  u32 _result_59 = r29;
  Term _result_60 = r30;
  WL_SPIN
    if (_result_35 == 0) {
      _v_31 = _result_36;
      _v_32 = _result_37;
      _v_33 = _result_38;
      _v_34 = _result_39;
      _v_35 = _result_40;
      _v_36 = _result_41;
      _v_37 = _result_42;
      _v_38 = _result_43;
      _v_39 = _result_44;
      _v_40 = _result_45;
      _v_41 = _result_46;
      _v_42 = _result_47;
      _v_43 = _result_48;
      _v_44 = _result_49;
      _v_45 = _result_50;
      _v_46 = _result_51;
      _v_47 = _result_52;
      _v_48 = _result_53;
      _v_49 = _result_54;
      _v_50 = _result_55;
      _v_51 = _result_56;
      _v_52 = _result_57;
      _v_53 = _result_58;
      _v_54 = _result_59;
      _v_55 = 1;
      _v_56 = _registry_0;
      _v_57 = _registry_1;
      _v_58 = _registry_2;
      _v_59 = _registry_3;
      _v_60 = _registry_4;
      _v_61 = term_ctr(CID_SCON, STAT_OFF + 154);
    } else {
      _v_31 = _result_36;
      _v_32 = _result_37;
      _v_33 = _result_38;
      _v_34 = _result_39;
      _v_35 = _result_40;
      _v_36 = _result_41;
      _v_37 = _result_42;
      _v_38 = _result_43;
      _v_39 = _result_44;
      _v_40 = _result_45;
      _v_41 = _result_46;
      _v_42 = _result_47;
      _v_43 = _result_48;
      _v_44 = _result_49;
      _v_45 = _result_50;
      _v_46 = _result_51;
      _v_47 = _result_52;
      _v_48 = _result_53;
      _v_49 = _result_54;
      _v_50 = _result_55;
      _v_51 = _result_56;
      _v_52 = _result_57;
      _v_53 = _result_58;
      _v_54 = _result_59;
      _v_55 = 1;
      _v_56 = _registry_0;
      _v_57 = _registry_1;
      _v_58 = _registry_2;
      _v_59 = _registry_3;
      _v_60 = _registry_4;
      _v_61 = _result_60;
    }
  break;
  }
  o[0] = _v_31;
  o[1] = _v_32;
  o[2] = _v_33;
  o[3] = _v_34;
  o[4] = _v_35;
  o[5] = _v_36;
  o[6] = _v_37;
  o[7] = _v_38;
  o[8] = _v_39;
  o[9] = _v_40;
  o[10] = _v_41;
  o[11] = _v_42;
  o[12] = _v_43;
  o[13] = _v_44;
  o[14] = _v_45;
  o[15] = _v_46;
  o[16] = _v_47;
  o[17] = _v_48;
  o[18] = _v_49;
  o[19] = _v_50;
  o[20] = _v_51;
  o[21] = _v_52;
  o[22] = _v_53;
  o[23] = _v_54;
  o[24] = _v_55;
  o[25] = _v_56;
  o[26] = _v_57;
  o[27] = _v_58;
  o[28] = _v_59;
  o[29] = _v_60;
  o[30] = _v_61;
  return 1;
}

INLINE Term spin_49(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  u32 _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  Term _v_53 = 0;
  u32 _v_54 = 0;
  Term _v_55 = 0;
  Term _v_56 = 0;
  Term _v_57 = 0;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  u32 _v_60 = 0;
  u32 _v_61 = 0;
  u32 _v_62 = 0;
  u32 _v_63 = 0;
  u32 _v_64 = 0;
  u32 _v_65 = 0;
  u32 _v_66 = 0;
  u32 _v_67 = 0;
  u32 _v_68 = 0;
  Term _v_69 = 0;
  Term _v_70 = 0;
  Term _v_71 = 0;
  u32 _v_72 = 0;
  u32 _v_73 = 0;
  u32 _v_74 = 0;
  u32 _world_24 = r0;
  u32 _world_25 = r1;
  u32 _world_26 = r2;
  Term _world_27 = r3;
  u32 _world_28 = r4;
  Term _world_29 = r5;
  Term _world_30 = r6;
  Term _world_31 = r7;
  u32 _world_32 = r8;
  u32 _world_33 = r9;
  u32 _world_34 = r10;
  u32 _world_35 = r11;
  u32 _world_36 = r12;
  u32 _world_37 = r13;
  u32 _world_38 = r14;
  u32 _world_39 = r15;
  u32 _world_40 = r16;
  u32 _world_41 = r17;
  u32 _world_42 = r18;
  Term _world_43 = r19;
  Term _world_44 = r20;
  Term _world_45 = r21;
  u32 _world_46 = r22;
  u32 _world_47 = r23;
  WL_SPIN
    u32 _v_75 = 0;
    u32 _v_76 = 0;
    Term _o_0[1];
    if (spin_42(e, _o_0, U32_BIN(_world_47, <, 4294967295ull), _world_47) == 0) {
      return 0;
    }
    _v_76 = _o_0[0];
    _v_75 = _v_76;
    u32 _v_77 = 0;
    u32 _v_78 = 0;
    Term _o_1[1];
    if (spin_42(e, _o_1, U32_BIN(_world_47, <, 4294967295ull), _world_47) == 0) {
      return 0;
    }
    _v_78 = _o_1[0];
    _v_77 = _v_78;
    _v_50 = _world_24;
    _v_51 = _world_25;
    _v_52 = _world_26;
    _v_53 = _world_27;
    _v_54 = _world_28;
    _v_55 = _world_29;
    _v_56 = _world_30;
    _v_57 = _world_31;
    _v_58 = _world_32;
    _v_59 = _world_33;
    _v_60 = _world_34;
    _v_61 = _world_35;
    _v_62 = _world_36;
    _v_63 = _world_37;
    _v_64 = _world_38;
    _v_65 = _world_39;
    _v_66 = _world_40;
    _v_67 = _world_41;
    _v_68 = _world_42;
    _v_69 = _world_43;
    _v_70 = _world_44;
    _v_71 = _world_45;
    _v_72 = _world_46;
    _v_73 = _v_75;
    _v_74 = _v_77;
  break;
  }
  o[0] = _v_50;
  o[1] = _v_51;
  o[2] = _v_52;
  o[3] = _v_53;
  o[4] = _v_54;
  o[5] = _v_55;
  o[6] = _v_56;
  o[7] = _v_57;
  o[8] = _v_58;
  o[9] = _v_59;
  o[10] = _v_60;
  o[11] = _v_61;
  o[12] = _v_62;
  o[13] = _v_63;
  o[14] = _v_64;
  o[15] = _v_65;
  o[16] = _v_66;
  o[17] = _v_67;
  o[18] = _v_68;
  o[19] = _v_69;
  o[20] = _v_70;
  o[21] = _v_71;
  o[22] = _v_72;
  o[23] = _v_73;
  o[24] = _v_74;
  return 1;
}

INLINE Term spin_50(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23, u32 r24) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  u32 _v_103 = 0;
  u32 _v_104 = 0;
  u32 _v_105 = 0;
  Term _v_106 = 0;
  u32 _v_107 = 0;
  Term _v_108 = 0;
  Term _v_109 = 0;
  Term _v_110 = 0;
  u32 _v_111 = 0;
  u32 _v_112 = 0;
  u32 _v_113 = 0;
  u32 _v_114 = 0;
  u32 _v_115 = 0;
  u32 _v_116 = 0;
  u32 _v_117 = 0;
  u32 _v_118 = 0;
  u32 _v_119 = 0;
  u32 _v_120 = 0;
  u32 _v_121 = 0;
  Term _v_122 = 0;
  Term _v_123 = 0;
  Term _v_124 = 0;
  u32 _v_125 = 0;
  u32 _v_126 = 0;
  u32 _pair_0 = r0;
  u32 _pair_1 = r1;
  u32 _pair_2 = r2;
  Term _pair_3 = r3;
  u32 _pair_4 = r4;
  Term _pair_5 = r5;
  Term _pair_6 = r6;
  Term _pair_7 = r7;
  u32 _pair_8 = r8;
  u32 _pair_9 = r9;
  u32 _pair_10 = r10;
  u32 _pair_11 = r11;
  u32 _pair_12 = r12;
  u32 _pair_13 = r13;
  u32 _pair_14 = r14;
  u32 _pair_15 = r15;
  u32 _pair_16 = r16;
  u32 _pair_17 = r17;
  u32 _pair_18 = r18;
  Term _pair_19 = r19;
  Term _pair_20 = r20;
  Term _pair_21 = r21;
  u32 _pair_22 = r22;
  u32 _pair_23 = r23;
  u32 _pair_24 = r24;
  WL_SPIN
    _v_103 = _pair_0;
    _v_104 = _pair_1;
    _v_105 = _pair_2;
    _v_106 = _pair_3;
    _v_107 = _pair_4;
    _v_108 = _pair_5;
    _v_109 = _pair_6;
    _v_110 = _pair_7;
    _v_111 = _pair_8;
    _v_112 = _pair_9;
    _v_113 = _pair_10;
    _v_114 = _pair_11;
    _v_115 = _pair_12;
    _v_116 = _pair_13;
    _v_117 = _pair_14;
    _v_118 = _pair_15;
    _v_119 = _pair_16;
    _v_120 = _pair_17;
    _v_121 = _pair_18;
    _v_122 = _pair_19;
    _v_123 = _pair_20;
    _v_124 = _pair_21;
    _v_125 = _pair_22;
    _v_126 = _pair_23;
  break;
  }
  o[0] = _v_103;
  o[1] = _v_104;
  o[2] = _v_105;
  o[3] = _v_106;
  o[4] = _v_107;
  o[5] = _v_108;
  o[6] = _v_109;
  o[7] = _v_110;
  o[8] = _v_111;
  o[9] = _v_112;
  o[10] = _v_113;
  o[11] = _v_114;
  o[12] = _v_115;
  o[13] = _v_116;
  o[14] = _v_117;
  o[15] = _v_118;
  o[16] = _v_119;
  o[17] = _v_120;
  o[18] = _v_121;
  o[19] = _v_122;
  o[20] = _v_123;
  o[21] = _v_124;
  o[22] = _v_125;
  o[23] = _v_126;
  return 1;
}

INLINE Term spin_51(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23, Term r24, u64 q24, Term r25, u64 q25) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  Term h24 = r24;
  Term h25 = r25;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  u32 _v_54 = 0;
  Term _v_55 = 0;
  u32 _v_56 = 0;
  Term _v_57 = 0;
  Term _v_58 = 0;
  Term _v_59 = 0;
  u32 _v_60 = 0;
  u32 _v_61 = 0;
  u32 _v_62 = 0;
  u32 _v_63 = 0;
  u32 _v_64 = 0;
  u32 _v_65 = 0;
  u32 _v_66 = 0;
  u32 _v_67 = 0;
  u32 _v_68 = 0;
  u32 _v_69 = 0;
  u32 _v_70 = 0;
  Term _v_71 = 0;
  Term _v_72 = 0;
  Term _v_73 = 0;
  u32 _v_74 = 0;
  u32 _v_75 = 0;
  u32 _v_76 = 0;
  u32 _v_77 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  Term _world_6 = r6;
  Term _world_7 = r7;
  u32 _world_8 = r8;
  u32 _world_9 = r9;
  u32 _world_10 = r10;
  u32 _world_11 = r11;
  u32 _world_12 = r12;
  u32 _world_13 = r13;
  u32 _world_14 = r14;
  u32 _world_15 = r15;
  u32 _world_16 = r16;
  u32 _world_17 = r17;
  u32 _world_18 = r18;
  Term _world_19 = r19;
  Term _world_20 = r20;
  Term _world_21 = r21;
  u32 _world_22 = r22;
  u32 _world_23 = r23;
  Term _name_1 = r24;
  Term _access_1 = r25;
  WL_SPIN
    u32 _v_78 = 0;
    u32 _v_79 = 0;
    u32 _v_80 = 0;
    Term _v_81 = 0;
    u32 _v_82 = 0;
    Term _v_83 = 0;
    Term _v_84 = 0;
    Term _v_85 = 0;
    u32 _v_86 = 0;
    u32 _v_87 = 0;
    u32 _v_88 = 0;
    u32 _v_89 = 0;
    u32 _v_90 = 0;
    u32 _v_91 = 0;
    u32 _v_92 = 0;
    u32 _v_93 = 0;
    u32 _v_94 = 0;
    u32 _v_95 = 0;
    u32 _v_96 = 0;
    Term _v_97 = 0;
    Term _v_98 = 0;
    Term _v_99 = 0;
    u32 _v_100 = 0;
    u32 _v_101 = 0;
    u32 _v_102 = 0;
    u32 _v_103 = 0;
    Term _o_0[26];
    if (spin_43(e, _o_0, U32_BIN(_world_22, <, 4294967295ull), _world_0, _world_1, _world_2, _world_3, _world_3 == h3 ? q3 : blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_6 == h6 ? q6 : blk_loc(e.mem, _world_6), _world_7, _world_7 == h7 ? q7 : blk_loc(e.mem, _world_7), _world_8, _world_9, _world_10, _world_11, _world_12, _world_13, _world_14, _world_15, _world_16, _world_17, _world_18, _world_19, _world_19 == h19 ? q19 : blk_loc(e.mem, _world_19), _world_20, _world_20 == h20 ? q20 : blk_loc(e.mem, _world_20), _world_21, _world_21 == h21 ? q21 : blk_loc(e.mem, _world_21), _world_22, _world_23, _name_1, _name_1 == h24 ? q24 : blk_loc(e.mem, _name_1), _access_1, _access_1 == h25 ? q25 : blk_loc(e.mem, _access_1)) == 0) {
      return 0;
    }
    _v_78 = _o_0[0];
    _v_79 = _o_0[1];
    _v_80 = _o_0[2];
    _v_81 = _o_0[3];
    _v_82 = _o_0[4];
    _v_83 = _o_0[5];
    _v_84 = _o_0[6];
    _v_85 = _o_0[7];
    _v_86 = _o_0[8];
    _v_87 = _o_0[9];
    _v_88 = _o_0[10];
    _v_89 = _o_0[11];
    _v_90 = _o_0[12];
    _v_91 = _o_0[13];
    _v_92 = _o_0[14];
    _v_93 = _o_0[15];
    _v_94 = _o_0[16];
    _v_95 = _o_0[17];
    _v_96 = _o_0[18];
    _v_97 = _o_0[19];
    _v_98 = _o_0[20];
    _v_99 = _o_0[21];
    _v_100 = _o_0[22];
    _v_101 = _o_0[23];
    _v_102 = _o_0[24];
    _v_103 = _o_0[25];
    _v_52 = _v_78;
    _v_53 = _v_79;
    _v_54 = _v_80;
    _v_55 = _v_81;
    _v_56 = _v_82;
    _v_57 = _v_83;
    _v_58 = _v_84;
    _v_59 = _v_85;
    _v_60 = _v_86;
    _v_61 = _v_87;
    _v_62 = _v_88;
    _v_63 = _v_89;
    _v_64 = _v_90;
    _v_65 = _v_91;
    _v_66 = _v_92;
    _v_67 = _v_93;
    _v_68 = _v_94;
    _v_69 = _v_95;
    _v_70 = _v_96;
    _v_71 = _v_97;
    _v_72 = _v_98;
    _v_73 = _v_99;
    _v_74 = _v_100;
    _v_75 = _v_101;
    _v_76 = _v_102;
    _v_77 = _v_103;
  break;
  }
  o[0] = _v_52;
  o[1] = _v_53;
  o[2] = _v_54;
  o[3] = _v_55;
  o[4] = _v_56;
  o[5] = _v_57;
  o[6] = _v_58;
  o[7] = _v_59;
  o[8] = _v_60;
  o[9] = _v_61;
  o[10] = _v_62;
  o[11] = _v_63;
  o[12] = _v_64;
  o[13] = _v_65;
  o[14] = _v_66;
  o[15] = _v_67;
  o[16] = _v_68;
  o[17] = _v_69;
  o[18] = _v_70;
  o[19] = _v_71;
  o[20] = _v_72;
  o[21] = _v_73;
  o[22] = _v_74;
  o[23] = _v_75;
  o[24] = _v_76;
  o[25] = _v_77;
  return 1;
}

INLINE Term spin_52(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23, u32 r24, u32 r25, u32 r26, Term r27, u64 q27, Term r28, u64 q28) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  Term h27 = r27;
  Term h28 = r28;
  u32 _v_134 = 0;
  u32 _v_135 = 0;
  u32 _v_136 = 0;
  u32 _v_137 = 0;
  Term _v_138 = 0;
  u32 _v_139 = 0;
  Term _v_140 = 0;
  Term _v_141 = 0;
  Term _v_142 = 0;
  u32 _v_143 = 0;
  u32 _v_144 = 0;
  u32 _v_145 = 0;
  u32 _v_146 = 0;
  u32 _v_147 = 0;
  u32 _v_148 = 0;
  u32 _v_149 = 0;
  u32 _v_150 = 0;
  u32 _v_151 = 0;
  u32 _v_152 = 0;
  u32 _v_153 = 0;
  Term _v_154 = 0;
  Term _v_155 = 0;
  Term _v_156 = 0;
  u32 _v_157 = 0;
  u32 _v_158 = 0;
  u32 _v_159 = 0;
  u32 _v_160 = 0;
  Term _v_161 = 0;
  Term _v_162 = 0;
  u32 _v_163 = 0;
  u32 _registered_0 = r0;
  u32 _registered_1 = r1;
  u32 _registered_2 = r2;
  Term _registered_3 = r3;
  u32 _registered_4 = r4;
  Term _registered_5 = r5;
  Term _registered_6 = r6;
  Term _registered_7 = r7;
  u32 _registered_8 = r8;
  u32 _registered_9 = r9;
  u32 _registered_10 = r10;
  u32 _registered_11 = r11;
  u32 _registered_12 = r12;
  u32 _registered_13 = r13;
  u32 _registered_14 = r14;
  u32 _registered_15 = r15;
  u32 _registered_16 = r16;
  u32 _registered_17 = r17;
  u32 _registered_18 = r18;
  Term _registered_19 = r19;
  Term _registered_20 = r20;
  Term _registered_21 = r21;
  u32 _registered_22 = r22;
  u32 _registered_23 = r23;
  u32 _registered_24 = r24;
  u32 _registered_25 = r25;
  u32 _namespace_0 = r26;
  Term _name_2 = r27;
  Term _access_2 = r28;
  WL_SPIN
    u32 _v_164 = 0;
    u32 _v_165 = 0;
    u32 _v_166 = 0;
    u32 _v_167 = 0;
    Term _v_168 = 0;
    u32 _v_169 = 0;
    Term _v_170 = 0;
    Term _v_171 = 0;
    Term _v_172 = 0;
    u32 _v_173 = 0;
    u32 _v_174 = 0;
    u32 _v_175 = 0;
    u32 _v_176 = 0;
    u32 _v_177 = 0;
    u32 _v_178 = 0;
    u32 _v_179 = 0;
    u32 _v_180 = 0;
    u32 _v_181 = 0;
    u32 _v_182 = 0;
    u32 _v_183 = 0;
    Term _v_184 = 0;
    Term _v_185 = 0;
    Term _v_186 = 0;
    u32 _v_187 = 0;
    u32 _v_188 = 0;
    u32 _v_189 = 0;
    u32 _v_190 = 0;
    Term _v_191 = 0;
    Term _v_192 = 0;
    u32 _v_193 = 0;
    Term _o_2[30];
    if (spin_44(e, _o_2, _registered_0, _registered_1, _registered_2, _registered_3, _registered_3 == h3 ? q3 : blk_loc(e.mem, _registered_3), _registered_4, _registered_5, _registered_6, _registered_6 == h6 ? q6 : blk_loc(e.mem, _registered_6), _registered_7, _registered_7 == h7 ? q7 : blk_loc(e.mem, _registered_7), _registered_8, _registered_9, _registered_10, _registered_11, _registered_12, _registered_13, _registered_14, _registered_15, _registered_16, _registered_17, _registered_18, _registered_19, _registered_19 == h19 ? q19 : blk_loc(e.mem, _registered_19), _registered_20, _registered_20 == h20 ? q20 : blk_loc(e.mem, _registered_20), _registered_21, _registered_21 == h21 ? q21 : blk_loc(e.mem, _registered_21), _registered_22, _registered_23, _registered_24, _registered_25, _namespace_0, _name_2, _name_2 == h27 ? q27 : blk_loc(e.mem, _name_2), _access_2, _access_2 == h28 ? q28 : blk_loc(e.mem, _access_2)) == 0) {
      return 0;
    }
    _v_164 = _o_2[0];
    _v_165 = _o_2[1];
    _v_166 = _o_2[2];
    _v_167 = _o_2[3];
    _v_168 = _o_2[4];
    _v_169 = _o_2[5];
    _v_170 = _o_2[6];
    _v_171 = _o_2[7];
    _v_172 = _o_2[8];
    _v_173 = _o_2[9];
    _v_174 = _o_2[10];
    _v_175 = _o_2[11];
    _v_176 = _o_2[12];
    _v_177 = _o_2[13];
    _v_178 = _o_2[14];
    _v_179 = _o_2[15];
    _v_180 = _o_2[16];
    _v_181 = _o_2[17];
    _v_182 = _o_2[18];
    _v_183 = _o_2[19];
    _v_184 = _o_2[20];
    _v_185 = _o_2[21];
    _v_186 = _o_2[22];
    _v_187 = _o_2[23];
    _v_188 = _o_2[24];
    _v_189 = _o_2[25];
    _v_190 = _o_2[26];
    _v_191 = _o_2[27];
    _v_192 = _o_2[28];
    _v_193 = _o_2[29];
    _v_134 = _v_164;
    _v_135 = _v_165;
    _v_136 = _v_166;
    _v_137 = _v_167;
    _v_138 = _v_168;
    _v_139 = _v_169;
    _v_140 = _v_170;
    _v_141 = _v_171;
    _v_142 = _v_172;
    _v_143 = _v_173;
    _v_144 = _v_174;
    _v_145 = _v_175;
    _v_146 = _v_176;
    _v_147 = _v_177;
    _v_148 = _v_178;
    _v_149 = _v_179;
    _v_150 = _v_180;
    _v_151 = _v_181;
    _v_152 = _v_182;
    _v_153 = _v_183;
    _v_154 = _v_184;
    _v_155 = _v_185;
    _v_156 = _v_186;
    _v_157 = _v_187;
    _v_158 = _v_188;
    _v_159 = _v_189;
    _v_160 = _v_190;
    _v_161 = _v_191;
    _v_162 = _v_192;
    _v_163 = _v_193;
  break;
  }
  o[0] = _v_134;
  o[1] = _v_135;
  o[2] = _v_136;
  o[3] = _v_137;
  o[4] = _v_138;
  o[5] = _v_139;
  o[6] = _v_140;
  o[7] = _v_141;
  o[8] = _v_142;
  o[9] = _v_143;
  o[10] = _v_144;
  o[11] = _v_145;
  o[12] = _v_146;
  o[13] = _v_147;
  o[14] = _v_148;
  o[15] = _v_149;
  o[16] = _v_150;
  o[17] = _v_151;
  o[18] = _v_152;
  o[19] = _v_153;
  o[20] = _v_154;
  o[21] = _v_155;
  o[22] = _v_156;
  o[23] = _v_157;
  o[24] = _v_158;
  o[25] = _v_159;
  o[26] = _v_160;
  o[27] = _v_161;
  o[28] = _v_162;
  o[29] = _v_163;
  return 1;
}

INLINE Term spin_53(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9, Term r10, u64 q10, Term r11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, u32 r16, u32 r17, u32 r18, u32 r19, u32 r20, u32 r21, u32 r22, u32 r23, u32 r24, Term r25, u64 q25, Term r26, u64 q26, Term r27, u64 q27, Term r28, u64 q28, u32 r29, u32 r30, Term r31, u64 q31, u32 r32, u32 r33, u32 r34) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h9 = r9;
  Term h10 = r10;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  Term h25 = r25;
  Term h26 = r26;
  Term h27 = r27;
  Term h28 = r28;
  Term h31 = r31;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  Term _v_34 = 0;
  u32 _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  Term _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  Term _v_50 = 0;
  Term _v_51 = 0;
  Term _v_52 = 0;
  u32 _v_53 = 0;
  u32 _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  Term _v_58 = 0;
  Term _v_59 = 0;
  u32 _v_60 = 0;
  Term _v_61 = 0;
  u32 _result_0 = r0;
  u32 _result_1 = r1;
  u32 _result_2 = r2;
  Term _result_3 = r3;
  Term _result_4 = r4;
  u32 _result_5 = r5;
  u32 _result_6 = r6;
  u32 _result_7 = r7;
  u32 _result_8 = r8;
  Term _result_9 = r9;
  Term _result_10 = r10;
  Term _result_11 = r11;
  Term _result_12 = r12;
  Term _result_13 = r13;
  Term _result_14 = r14;
  u32 _result_15 = r15;
  u32 _result_16 = r16;
  u32 _result_17 = r17;
  u32 _result_18 = r18;
  u32 _result_19 = r19;
  u32 _result_20 = r20;
  u32 _result_21 = r21;
  u32 _result_22 = r22;
  u32 _result_23 = r23;
  u32 _result_24 = r24;
  Term _result_25 = r25;
  Term _result_26 = r26;
  Term _result_27 = r27;
  Term _result_28 = r28;
  u32 _result_29 = r29;
  u32 _result_30 = r30;
  Term _result_31 = r31;
  u32 _result_32 = r32;
  u32 _result_33 = r33;
  u32 _result_34 = r34;
  WL_SPIN
    if (_result_0 == 0) {
      u32 _v_62 = 0;
      u32 _v_63 = 0;
      u32 _v_64 = 0;
      Term _v_65 = 0;
      u32 _v_66 = 0;
      Term _v_67 = 0;
      Term _v_68 = 0;
      Term _v_69 = 0;
      u32 _v_70 = 0;
      u32 _v_71 = 0;
      u32 _v_72 = 0;
      u32 _v_73 = 0;
      u32 _v_74 = 0;
      u32 _v_75 = 0;
      u32 _v_76 = 0;
      u32 _v_77 = 0;
      u32 _v_78 = 0;
      u32 _v_79 = 0;
      u32 _v_80 = 0;
      Term _v_81 = 0;
      Term _v_82 = 0;
      Term _v_83 = 0;
      u32 _v_84 = 0;
      u32 _v_85 = 0;
      u32 _v_86 = 0;
      u32 _v_87 = 0;
      u32 _v_88 = 0;
      Term _v_89 = 0;
      Term _v_90 = 0;
      u32 _v_91 = 0;
      Term _v_92 = 0;
      Term _o_0[31];
      if (spin_48(e, _o_0, _result_1, _result_2, _result_3, _result_3 == h3 ? q3 : blk_loc(e.mem, _result_3), _result_4, _result_4 == h4 ? q4 : blk_loc(e.mem, _result_4), _result_5, _result_6, _result_7, _result_8, _result_9, _result_10, _result_10 == h10 ? q10 : blk_loc(e.mem, _result_10), _result_11, _result_12, _result_13, _result_13 == h13 ? q13 : blk_loc(e.mem, _result_13), _result_14, _result_14 == h14 ? q14 : blk_loc(e.mem, _result_14), _result_15, _result_16, _result_17, _result_18, _result_19, _result_20, _result_21, _result_22, _result_23, _result_24, _result_25, _result_26, _result_26 == h26 ? q26 : blk_loc(e.mem, _result_26), _result_27, _result_27 == h27 ? q27 : blk_loc(e.mem, _result_27), _result_28, _result_28 == h28 ? q28 : blk_loc(e.mem, _result_28), _result_29, _result_30, _result_31, _result_31 == h31 ? q31 : blk_loc(e.mem, _result_31)) == 0) {
        return 0;
      }
      _v_62 = _o_0[0];
      _v_63 = _o_0[1];
      _v_64 = _o_0[2];
      _v_65 = _o_0[3];
      _v_66 = _o_0[4];
      _v_67 = _o_0[5];
      _v_68 = _o_0[6];
      _v_69 = _o_0[7];
      _v_70 = _o_0[8];
      _v_71 = _o_0[9];
      _v_72 = _o_0[10];
      _v_73 = _o_0[11];
      _v_74 = _o_0[12];
      _v_75 = _o_0[13];
      _v_76 = _o_0[14];
      _v_77 = _o_0[15];
      _v_78 = _o_0[16];
      _v_79 = _o_0[17];
      _v_80 = _o_0[18];
      _v_81 = _o_0[19];
      _v_82 = _o_0[20];
      _v_83 = _o_0[21];
      _v_84 = _o_0[22];
      _v_85 = _o_0[23];
      _v_86 = _o_0[24];
      _v_87 = _o_0[25];
      _v_88 = _o_0[26];
      _v_89 = _o_0[27];
      _v_90 = _o_0[28];
      _v_91 = _o_0[29];
      _v_92 = _o_0[30];
      _v_31 = _v_62;
      _v_32 = _v_63;
      _v_33 = _v_64;
      _v_34 = _v_65;
      _v_35 = _v_66;
      _v_36 = _v_67;
      _v_37 = _v_68;
      _v_38 = _v_69;
      _v_39 = _v_70;
      _v_40 = _v_71;
      _v_41 = _v_72;
      _v_42 = _v_73;
      _v_43 = _v_74;
      _v_44 = _v_75;
      _v_45 = _v_76;
      _v_46 = _v_77;
      _v_47 = _v_78;
      _v_48 = _v_79;
      _v_49 = _v_80;
      _v_50 = _v_81;
      _v_51 = _v_82;
      _v_52 = _v_83;
      _v_53 = _v_84;
      _v_54 = _v_85;
      _v_55 = _v_86;
      _v_56 = _v_87;
      _v_57 = _v_88;
      _v_58 = _v_89;
      _v_59 = _v_90;
      _v_60 = _v_91;
      _v_61 = _v_92;
    } else {
      _v_31 = _result_6;
      _v_32 = _result_7;
      _v_33 = _result_8;
      _v_34 = _result_9;
      _v_35 = _result_10;
      _v_36 = _result_11;
      _v_37 = _result_12;
      _v_38 = _result_13;
      _v_39 = _result_14;
      _v_40 = _result_15;
      _v_41 = _result_16;
      _v_42 = _result_17;
      _v_43 = _result_18;
      _v_44 = _result_19;
      _v_45 = _result_20;
      _v_46 = _result_21;
      _v_47 = _result_22;
      _v_48 = _result_23;
      _v_49 = _result_24;
      _v_50 = _result_25;
      _v_51 = _result_26;
      _v_52 = _result_27;
      _v_53 = _result_28;
      _v_54 = _result_29;
      _v_55 = 1;
      _v_56 = _result_1;
      _v_57 = _result_2;
      _v_58 = _result_3;
      _v_59 = _result_4;
      _v_60 = _result_5;
      _v_61 = term_ctr(CID_SCON, STAT_OFF + 380);
    }
  break;
  }
  o[0] = _v_31;
  o[1] = _v_32;
  o[2] = _v_33;
  o[3] = _v_34;
  o[4] = _v_35;
  o[5] = _v_36;
  o[6] = _v_37;
  o[7] = _v_38;
  o[8] = _v_39;
  o[9] = _v_40;
  o[10] = _v_41;
  o[11] = _v_42;
  o[12] = _v_43;
  o[13] = _v_44;
  o[14] = _v_45;
  o[15] = _v_46;
  o[16] = _v_47;
  o[17] = _v_48;
  o[18] = _v_49;
  o[19] = _v_50;
  o[20] = _v_51;
  o[21] = _v_52;
  o[22] = _v_53;
  o[23] = _v_54;
  o[24] = _v_55;
  o[25] = _v_56;
  o[26] = _v_57;
  o[27] = _v_58;
  o[28] = _v_59;
  o[29] = _v_60;
  o[30] = _v_61;
  return 1;
}

INLINE Term spin_54(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  u32 _v_34 = 0;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  Term _v_43 = 0;
  Term _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _world_24 = r0;
  u32 _world_25 = r1;
  u32 _world_26 = r2;
  Term _world_27 = r3;
  u32 _world_28 = r4;
  Term _world_29 = r5;
  Term _world_30 = r6;
  Term _world_31 = r7;
  u32 _world_32 = r8;
  u32 _world_33 = r9;
  u32 _world_34 = r10;
  u32 _world_35 = r11;
  u32 _world_36 = r12;
  u32 _world_37 = r13;
  u32 _world_38 = r14;
  u32 _world_39 = r15;
  u32 _world_40 = r16;
  u32 _world_41 = r17;
  u32 _world_42 = r18;
  Term _world_43 = r19;
  Term _world_44 = r20;
  Term _world_45 = r21;
  u32 _world_46 = r22;
  u32 _world_47 = r23;
  WL_SPIN
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    u32 _v_50 = 0;
    Term _v_51 = 0;
    u32 _v_52 = 0;
    Term _v_53 = 0;
    Term _v_54 = 0;
    Term _v_55 = 0;
    u32 _v_56 = 0;
    u32 _v_57 = 0;
    u32 _v_58 = 0;
    u32 _v_59 = 0;
    u32 _v_60 = 0;
    u32 _v_61 = 0;
    u32 _v_62 = 0;
    u32 _v_63 = 0;
    u32 _v_64 = 0;
    u32 _v_65 = 0;
    u32 _v_66 = 0;
    Term _v_67 = 0;
    Term _v_68 = 0;
    Term _v_69 = 0;
    u32 _v_70 = 0;
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    u32 _v_73 = 0;
    u32 _v_74 = 0;
    u32 _v_75 = 0;
    Term _v_76 = 0;
    u32 _v_77 = 0;
    Term _v_78 = 0;
    Term _v_79 = 0;
    Term _v_80 = 0;
    u32 _v_81 = 0;
    u32 _v_82 = 0;
    u32 _v_83 = 0;
    u32 _v_84 = 0;
    u32 _v_85 = 0;
    u32 _v_86 = 0;
    u32 _v_87 = 0;
    u32 _v_88 = 0;
    u32 _v_89 = 0;
    u32 _v_90 = 0;
    u32 _v_91 = 0;
    Term _v_92 = 0;
    Term _v_93 = 0;
    Term _v_94 = 0;
    u32 _v_95 = 0;
    u32 _v_96 = 0;
    u32 _v_97 = 0;
    Term _o_0[25];
    if (spin_49(e, _o_0, _world_24, _world_25, _world_26, _world_27, _world_27 == h3 ? q3 : blk_loc(e.mem, _world_27), _world_28, _world_29, _world_30, _world_30 == h6 ? q6 : blk_loc(e.mem, _world_30), _world_31, _world_31 == h7 ? q7 : blk_loc(e.mem, _world_31), _world_32, _world_33, _world_34, _world_35, _world_36, _world_37, _world_38, _world_39, _world_40, _world_41, _world_42, _world_43, _world_43 == h19 ? q19 : blk_loc(e.mem, _world_43), _world_44, _world_44 == h20 ? q20 : blk_loc(e.mem, _world_44), _world_45, _world_45 == h21 ? q21 : blk_loc(e.mem, _world_45), _world_46, _world_47) == 0) {
      return 0;
    }
    _v_73 = _o_0[0];
    _v_74 = _o_0[1];
    _v_75 = _o_0[2];
    _v_76 = _o_0[3];
    _v_77 = _o_0[4];
    _v_78 = _o_0[5];
    _v_79 = _o_0[6];
    _v_80 = _o_0[7];
    _v_81 = _o_0[8];
    _v_82 = _o_0[9];
    _v_83 = _o_0[10];
    _v_84 = _o_0[11];
    _v_85 = _o_0[12];
    _v_86 = _o_0[13];
    _v_87 = _o_0[14];
    _v_88 = _o_0[15];
    _v_89 = _o_0[16];
    _v_90 = _o_0[17];
    _v_91 = _o_0[18];
    _v_92 = _o_0[19];
    _v_93 = _o_0[20];
    _v_94 = _o_0[21];
    _v_95 = _o_0[22];
    _v_96 = _o_0[23];
    _v_97 = _o_0[24];
    _v_48 = _v_73;
    _v_49 = _v_74;
    _v_50 = _v_75;
    _v_51 = _v_76;
    _v_52 = _v_77;
    _v_53 = _v_78;
    _v_54 = _v_79;
    _v_55 = _v_80;
    _v_56 = _v_81;
    _v_57 = _v_82;
    _v_58 = _v_83;
    _v_59 = _v_84;
    _v_60 = _v_85;
    _v_61 = _v_86;
    _v_62 = _v_87;
    _v_63 = _v_88;
    _v_64 = _v_89;
    _v_65 = _v_90;
    _v_66 = _v_91;
    _v_67 = _v_92;
    _v_68 = _v_93;
    _v_69 = _v_94;
    _v_70 = _v_95;
    _v_71 = _v_96;
    _v_72 = _v_97;
    u32 _v_98 = 0;
    u32 _v_99 = 0;
    u32 _v_100 = 0;
    Term _v_101 = 0;
    u32 _v_102 = 0;
    Term _v_103 = 0;
    Term _v_104 = 0;
    Term _v_105 = 0;
    u32 _v_106 = 0;
    u32 _v_107 = 0;
    u32 _v_108 = 0;
    u32 _v_109 = 0;
    u32 _v_110 = 0;
    u32 _v_111 = 0;
    u32 _v_112 = 0;
    u32 _v_113 = 0;
    u32 _v_114 = 0;
    u32 _v_115 = 0;
    u32 _v_116 = 0;
    Term _v_117 = 0;
    Term _v_118 = 0;
    Term _v_119 = 0;
    u32 _v_120 = 0;
    u32 _v_121 = 0;
    Term _o_1[24];
    if (spin_50(e, _o_1, _v_48, _v_49, _v_50, _v_51, _v_51 == h21 ? q21 : _v_51 == h20 ? q20 : _v_51 == h19 ? q19 : _v_51 == h7 ? q7 : _v_51 == h6 ? q6 : _v_51 == h3 ? q3 : blk_loc(e.mem, _v_51), _v_52, _v_53, _v_54, _v_54 == h21 ? q21 : _v_54 == h20 ? q20 : _v_54 == h19 ? q19 : _v_54 == h7 ? q7 : _v_54 == h6 ? q6 : _v_54 == h3 ? q3 : blk_loc(e.mem, _v_54), _v_55, _v_55 == h21 ? q21 : _v_55 == h20 ? q20 : _v_55 == h19 ? q19 : _v_55 == h7 ? q7 : _v_55 == h6 ? q6 : _v_55 == h3 ? q3 : blk_loc(e.mem, _v_55), _v_56, _v_57, _v_58, _v_59, _v_60, _v_61, _v_62, _v_63, _v_64, _v_65, _v_66, _v_67, _v_67 == h21 ? q21 : _v_67 == h20 ? q20 : _v_67 == h19 ? q19 : _v_67 == h7 ? q7 : _v_67 == h6 ? q6 : _v_67 == h3 ? q3 : blk_loc(e.mem, _v_67), _v_68, _v_68 == h21 ? q21 : _v_68 == h20 ? q20 : _v_68 == h19 ? q19 : _v_68 == h7 ? q7 : _v_68 == h6 ? q6 : _v_68 == h3 ? q3 : blk_loc(e.mem, _v_68), _v_69, _v_69 == h21 ? q21 : _v_69 == h20 ? q20 : _v_69 == h19 ? q19 : _v_69 == h7 ? q7 : _v_69 == h6 ? q6 : _v_69 == h3 ? q3 : blk_loc(e.mem, _v_69), _v_70, _v_71, _v_72) == 0) {
      return 0;
    }
    _v_98 = _o_1[0];
    _v_99 = _o_1[1];
    _v_100 = _o_1[2];
    _v_101 = _o_1[3];
    _v_102 = _o_1[4];
    _v_103 = _o_1[5];
    _v_104 = _o_1[6];
    _v_105 = _o_1[7];
    _v_106 = _o_1[8];
    _v_107 = _o_1[9];
    _v_108 = _o_1[10];
    _v_109 = _o_1[11];
    _v_110 = _o_1[12];
    _v_111 = _o_1[13];
    _v_112 = _o_1[14];
    _v_113 = _o_1[15];
    _v_114 = _o_1[16];
    _v_115 = _o_1[17];
    _v_116 = _o_1[18];
    _v_117 = _o_1[19];
    _v_118 = _o_1[20];
    _v_119 = _o_1[21];
    _v_120 = _o_1[22];
    _v_121 = _o_1[23];
    _v_24 = _v_98;
    _v_25 = _v_99;
    _v_26 = _v_100;
    _v_27 = _v_101;
    _v_28 = _v_102;
    _v_29 = _v_103;
    _v_30 = _v_104;
    _v_31 = _v_105;
    _v_32 = _v_106;
    _v_33 = _v_107;
    _v_34 = _v_108;
    _v_35 = _v_109;
    _v_36 = _v_110;
    _v_37 = _v_111;
    _v_38 = _v_112;
    _v_39 = _v_113;
    _v_40 = _v_114;
    _v_41 = _v_115;
    _v_42 = _v_116;
    _v_43 = _v_117;
    _v_44 = _v_118;
    _v_45 = _v_119;
    _v_46 = _v_120;
    _v_47 = _v_121;
  break;
  }
  o[0] = _v_24;
  o[1] = _v_25;
  o[2] = _v_26;
  o[3] = _v_27;
  o[4] = _v_28;
  o[5] = _v_29;
  o[6] = _v_30;
  o[7] = _v_31;
  o[8] = _v_32;
  o[9] = _v_33;
  o[10] = _v_34;
  o[11] = _v_35;
  o[12] = _v_36;
  o[13] = _v_37;
  o[14] = _v_38;
  o[15] = _v_39;
  o[16] = _v_40;
  o[17] = _v_41;
  o[18] = _v_42;
  o[19] = _v_43;
  o[20] = _v_44;
  o[21] = _v_45;
  o[22] = _v_46;
  o[23] = _v_47;
  return 1;
}

INLINE Term spin_55(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23, u32 r24, Term r25, u64 q25, Term r26, u64 q26) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  Term h25 = r25;
  Term h26 = r26;
  u32 _v_80 = 0;
  u32 _v_81 = 0;
  u32 _v_82 = 0;
  u32 _v_83 = 0;
  Term _v_84 = 0;
  u32 _v_85 = 0;
  Term _v_86 = 0;
  Term _v_87 = 0;
  Term _v_88 = 0;
  u32 _v_89 = 0;
  u32 _v_90 = 0;
  u32 _v_91 = 0;
  u32 _v_92 = 0;
  u32 _v_93 = 0;
  u32 _v_94 = 0;
  u32 _v_95 = 0;
  u32 _v_96 = 0;
  u32 _v_97 = 0;
  u32 _v_98 = 0;
  u32 _v_99 = 0;
  Term _v_100 = 0;
  Term _v_101 = 0;
  Term _v_102 = 0;
  u32 _v_103 = 0;
  u32 _v_104 = 0;
  u32 _v_105 = 0;
  u32 _v_106 = 0;
  Term _v_107 = 0;
  Term _v_108 = 0;
  u32 _v_109 = 0;
  u32 _named_0 = r0;
  u32 _named_1 = r1;
  u32 _named_2 = r2;
  Term _named_3 = r3;
  u32 _named_4 = r4;
  Term _named_5 = r5;
  Term _named_6 = r6;
  Term _named_7 = r7;
  u32 _named_8 = r8;
  u32 _named_9 = r9;
  u32 _named_10 = r10;
  u32 _named_11 = r11;
  u32 _named_12 = r12;
  u32 _named_13 = r13;
  u32 _named_14 = r14;
  u32 _named_15 = r15;
  u32 _named_16 = r16;
  u32 _named_17 = r17;
  u32 _named_18 = r18;
  Term _named_19 = r19;
  Term _named_20 = r20;
  Term _named_21 = r21;
  u32 _named_22 = r22;
  u32 _named_23 = r23;
  u32 _named_24 = r24;
  Term _name_1 = r25;
  Term _access_1 = r26;
  WL_SPIN
    u32 _v_110 = 0;
    u32 _v_111 = 0;
    u32 _v_112 = 0;
    Term _v_113 = 0;
    u32 _v_114 = 0;
    Term _v_115 = 0;
    Term _v_116 = 0;
    Term _v_117 = 0;
    u32 _v_118 = 0;
    u32 _v_119 = 0;
    u32 _v_120 = 0;
    u32 _v_121 = 0;
    u32 _v_122 = 0;
    u32 _v_123 = 0;
    u32 _v_124 = 0;
    u32 _v_125 = 0;
    u32 _v_126 = 0;
    u32 _v_127 = 0;
    u32 _v_128 = 0;
    Term _v_129 = 0;
    Term _v_130 = 0;
    Term _v_131 = 0;
    u32 _v_132 = 0;
    u32 _v_133 = 0;
    u32 _v_134 = 0;
    u32 _v_135 = 0;
    _name_1 = term_keep(e, _name_1, 1);
    _access_1 = term_keep(e, _access_1, 1);
    u32 _v_136 = 0;
    u32 _v_137 = 0;
    u32 _v_138 = 0;
    Term _v_139 = 0;
    u32 _v_140 = 0;
    Term _v_141 = 0;
    Term _v_142 = 0;
    Term _v_143 = 0;
    u32 _v_144 = 0;
    u32 _v_145 = 0;
    u32 _v_146 = 0;
    u32 _v_147 = 0;
    u32 _v_148 = 0;
    u32 _v_149 = 0;
    u32 _v_150 = 0;
    u32 _v_151 = 0;
    u32 _v_152 = 0;
    u32 _v_153 = 0;
    u32 _v_154 = 0;
    Term _v_155 = 0;
    Term _v_156 = 0;
    Term _v_157 = 0;
    u32 _v_158 = 0;
    u32 _v_159 = 0;
    u32 _v_160 = 0;
    u32 _v_161 = 0;
    Term _o_1[26];
    if (spin_51(e, _o_1, _named_0, _named_1, _named_2, _named_3, _named_3 == h3 ? q3 : blk_loc(e.mem, _named_3), _named_4, _named_5, _named_6, _named_6 == h6 ? q6 : blk_loc(e.mem, _named_6), _named_7, _named_7 == h7 ? q7 : blk_loc(e.mem, _named_7), _named_8, _named_9, _named_10, _named_11, _named_12, _named_13, _named_14, _named_15, _named_16, _named_17, _named_18, _named_19, _named_19 == h19 ? q19 : blk_loc(e.mem, _named_19), _named_20, _named_20 == h20 ? q20 : blk_loc(e.mem, _named_20), _named_21, _named_21 == h21 ? q21 : blk_loc(e.mem, _named_21), _named_22, _named_23, _name_1, _name_1 == h25 ? q25 : blk_loc(e.mem, _name_1), _access_1, _access_1 == h26 ? q26 : blk_loc(e.mem, _access_1)) == 0) {
      return 0;
    }
    _v_136 = _o_1[0];
    _v_137 = _o_1[1];
    _v_138 = _o_1[2];
    _v_139 = _o_1[3];
    _v_140 = _o_1[4];
    _v_141 = _o_1[5];
    _v_142 = _o_1[6];
    _v_143 = _o_1[7];
    _v_144 = _o_1[8];
    _v_145 = _o_1[9];
    _v_146 = _o_1[10];
    _v_147 = _o_1[11];
    _v_148 = _o_1[12];
    _v_149 = _o_1[13];
    _v_150 = _o_1[14];
    _v_151 = _o_1[15];
    _v_152 = _o_1[16];
    _v_153 = _o_1[17];
    _v_154 = _o_1[18];
    _v_155 = _o_1[19];
    _v_156 = _o_1[20];
    _v_157 = _o_1[21];
    _v_158 = _o_1[22];
    _v_159 = _o_1[23];
    _v_160 = _o_1[24];
    _v_161 = _o_1[25];
    _v_110 = _v_136;
    _v_111 = _v_137;
    _v_112 = _v_138;
    _v_113 = _v_139;
    _v_114 = _v_140;
    _v_115 = _v_141;
    _v_116 = _v_142;
    _v_117 = _v_143;
    _v_118 = _v_144;
    _v_119 = _v_145;
    _v_120 = _v_146;
    _v_121 = _v_147;
    _v_122 = _v_148;
    _v_123 = _v_149;
    _v_124 = _v_150;
    _v_125 = _v_151;
    _v_126 = _v_152;
    _v_127 = _v_153;
    _v_128 = _v_154;
    _v_129 = _v_155;
    _v_130 = _v_156;
    _v_131 = _v_157;
    _v_132 = _v_158;
    _v_133 = _v_159;
    _v_134 = _v_160;
    _v_135 = _v_161;
    u32 _v_162 = 0;
    u32 _v_163 = 0;
    u32 _v_164 = 0;
    u32 _v_165 = 0;
    Term _v_166 = 0;
    u32 _v_167 = 0;
    Term _v_168 = 0;
    Term _v_169 = 0;
    Term _v_170 = 0;
    u32 _v_171 = 0;
    u32 _v_172 = 0;
    u32 _v_173 = 0;
    u32 _v_174 = 0;
    u32 _v_175 = 0;
    u32 _v_176 = 0;
    u32 _v_177 = 0;
    u32 _v_178 = 0;
    u32 _v_179 = 0;
    u32 _v_180 = 0;
    u32 _v_181 = 0;
    Term _v_182 = 0;
    Term _v_183 = 0;
    Term _v_184 = 0;
    u32 _v_185 = 0;
    u32 _v_186 = 0;
    u32 _v_187 = 0;
    u32 _v_188 = 0;
    Term _v_189 = 0;
    Term _v_190 = 0;
    u32 _v_191 = 0;
    Term _o_2[30];
    if (spin_52(e, _o_2, _v_110, _v_111, _v_112, _v_113, _v_113 == h26 ? q26 : _v_113 == h25 ? q25 : _v_113 == h21 ? q21 : _v_113 == h20 ? q20 : _v_113 == h19 ? q19 : _v_113 == h7 ? q7 : _v_113 == h6 ? q6 : _v_113 == h3 ? q3 : blk_loc(e.mem, _v_113), _v_114, _v_115, _v_116, _v_116 == h26 ? q26 : _v_116 == h25 ? q25 : _v_116 == h21 ? q21 : _v_116 == h20 ? q20 : _v_116 == h19 ? q19 : _v_116 == h7 ? q7 : _v_116 == h6 ? q6 : _v_116 == h3 ? q3 : blk_loc(e.mem, _v_116), _v_117, _v_117 == h26 ? q26 : _v_117 == h25 ? q25 : _v_117 == h21 ? q21 : _v_117 == h20 ? q20 : _v_117 == h19 ? q19 : _v_117 == h7 ? q7 : _v_117 == h6 ? q6 : _v_117 == h3 ? q3 : blk_loc(e.mem, _v_117), _v_118, _v_119, _v_120, _v_121, _v_122, _v_123, _v_124, _v_125, _v_126, _v_127, _v_128, _v_129, _v_129 == h26 ? q26 : _v_129 == h25 ? q25 : _v_129 == h21 ? q21 : _v_129 == h20 ? q20 : _v_129 == h19 ? q19 : _v_129 == h7 ? q7 : _v_129 == h6 ? q6 : _v_129 == h3 ? q3 : blk_loc(e.mem, _v_129), _v_130, _v_130 == h26 ? q26 : _v_130 == h25 ? q25 : _v_130 == h21 ? q21 : _v_130 == h20 ? q20 : _v_130 == h19 ? q19 : _v_130 == h7 ? q7 : _v_130 == h6 ? q6 : _v_130 == h3 ? q3 : blk_loc(e.mem, _v_130), _v_131, _v_131 == h26 ? q26 : _v_131 == h25 ? q25 : _v_131 == h21 ? q21 : _v_131 == h20 ? q20 : _v_131 == h19 ? q19 : _v_131 == h7 ? q7 : _v_131 == h6 ? q6 : _v_131 == h3 ? q3 : blk_loc(e.mem, _v_131), _v_132, _v_133, _v_134, _v_135, _named_24, _name_1, _name_1 == h25 ? q25 : blk_loc(e.mem, _name_1), _access_1, _access_1 == h26 ? q26 : blk_loc(e.mem, _access_1)) == 0) {
      return 0;
    }
    _v_162 = _o_2[0];
    _v_163 = _o_2[1];
    _v_164 = _o_2[2];
    _v_165 = _o_2[3];
    _v_166 = _o_2[4];
    _v_167 = _o_2[5];
    _v_168 = _o_2[6];
    _v_169 = _o_2[7];
    _v_170 = _o_2[8];
    _v_171 = _o_2[9];
    _v_172 = _o_2[10];
    _v_173 = _o_2[11];
    _v_174 = _o_2[12];
    _v_175 = _o_2[13];
    _v_176 = _o_2[14];
    _v_177 = _o_2[15];
    _v_178 = _o_2[16];
    _v_179 = _o_2[17];
    _v_180 = _o_2[18];
    _v_181 = _o_2[19];
    _v_182 = _o_2[20];
    _v_183 = _o_2[21];
    _v_184 = _o_2[22];
    _v_185 = _o_2[23];
    _v_186 = _o_2[24];
    _v_187 = _o_2[25];
    _v_188 = _o_2[26];
    _v_189 = _o_2[27];
    _v_190 = _o_2[28];
    _v_191 = _o_2[29];
    _v_80 = _v_162;
    _v_81 = _v_163;
    _v_82 = _v_164;
    _v_83 = _v_165;
    _v_84 = _v_166;
    _v_85 = _v_167;
    _v_86 = _v_168;
    _v_87 = _v_169;
    _v_88 = _v_170;
    _v_89 = _v_171;
    _v_90 = _v_172;
    _v_91 = _v_173;
    _v_92 = _v_174;
    _v_93 = _v_175;
    _v_94 = _v_176;
    _v_95 = _v_177;
    _v_96 = _v_178;
    _v_97 = _v_179;
    _v_98 = _v_180;
    _v_99 = _v_181;
    _v_100 = _v_182;
    _v_101 = _v_183;
    _v_102 = _v_184;
    _v_103 = _v_185;
    _v_104 = _v_186;
    _v_105 = _v_187;
    _v_106 = _v_188;
    _v_107 = _v_189;
    _v_108 = _v_190;
    _v_109 = _v_191;
  break;
  }
  o[0] = _v_80;
  o[1] = _v_81;
  o[2] = _v_82;
  o[3] = _v_83;
  o[4] = _v_84;
  o[5] = _v_85;
  o[6] = _v_86;
  o[7] = _v_87;
  o[8] = _v_88;
  o[9] = _v_89;
  o[10] = _v_90;
  o[11] = _v_91;
  o[12] = _v_92;
  o[13] = _v_93;
  o[14] = _v_94;
  o[15] = _v_95;
  o[16] = _v_96;
  o[17] = _v_97;
  o[18] = _v_98;
  o[19] = _v_99;
  o[20] = _v_100;
  o[21] = _v_101;
  o[22] = _v_102;
  o[23] = _v_103;
  o[24] = _v_104;
  o[25] = _v_105;
  o[26] = _v_106;
  o[27] = _v_107;
  o[28] = _v_108;
  o[29] = _v_109;
  return 1;
}

INLINE Term spin_56(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23, u32 r24, u32 r25, u32 r26, Term r27, u64 q27, Term r28, u64 q28, u32 r29, Term r30, u64 q30) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  Term h27 = r27;
  Term h28 = r28;
  Term h30 = r30;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  Term _v_34 = 0;
  u32 _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  Term _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  Term _v_50 = 0;
  Term _v_51 = 0;
  Term _v_52 = 0;
  u32 _v_53 = 0;
  u32 _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  Term _v_58 = 0;
  Term _v_59 = 0;
  u32 _v_60 = 0;
  Term _v_61 = 0;
  u32 _app_31 = r0;
  u32 _app_32 = r1;
  u32 _app_33 = r2;
  Term _app_34 = r3;
  u32 _app_35 = r4;
  Term _app_36 = r5;
  Term _app_37 = r6;
  Term _app_38 = r7;
  u32 _app_39 = r8;
  u32 _app_40 = r9;
  u32 _app_41 = r10;
  u32 _app_42 = r11;
  u32 _app_43 = r12;
  u32 _app_44 = r13;
  u32 _app_45 = r14;
  u32 _app_46 = r15;
  u32 _app_47 = r16;
  u32 _app_48 = r17;
  u32 _app_49 = r18;
  Term _app_50 = r19;
  Term _app_51 = r20;
  Term _app_52 = r21;
  u32 _app_53 = r22;
  u32 _app_54 = r23;
  u32 _app_55 = r24;
  u32 _app_56 = r25;
  u32 _app_57 = r26;
  Term _app_58 = r27;
  Term _app_59 = r28;
  u32 _app_60 = r29;
  Term _app_61 = r30;
  WL_SPIN
    u32 _v_62 = 0;
    u32 _v_63 = 0;
    u32 _v_64 = 0;
    Term _v_65 = 0;
    u32 _v_66 = 0;
    Term _v_67 = 0;
    Term _v_68 = 0;
    Term _v_69 = 0;
    u32 _v_70 = 0;
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    u32 _v_73 = 0;
    u32 _v_74 = 0;
    u32 _v_75 = 0;
    u32 _v_76 = 0;
    u32 _v_77 = 0;
    u32 _v_78 = 0;
    u32 _v_79 = 0;
    u32 _v_80 = 0;
    Term _v_81 = 0;
    Term _v_82 = 0;
    Term _v_83 = 0;
    u32 _v_84 = 0;
    u32 _v_85 = 0;
    u32 _v_86 = 0;
    u32 _v_87 = 0;
    u32 _v_88 = 0;
    Term _v_89 = 0;
    u32 _v_90 = 0;
    Term _v_91 = 0;
    Term _v_92 = 0;
    Term _v_93 = 0;
    u32 _v_94 = 0;
    u32 _v_95 = 0;
    u32 _v_96 = 0;
    u32 _v_97 = 0;
    u32 _v_98 = 0;
    u32 _v_99 = 0;
    u32 _v_100 = 0;
    u32 _v_101 = 0;
    u32 _v_102 = 0;
    u32 _v_103 = 0;
    u32 _v_104 = 0;
    Term _v_105 = 0;
    Term _v_106 = 0;
    Term _v_107 = 0;
    u32 _v_108 = 0;
    u32 _v_109 = 0;
    Term _o_0[24];
    if (spin_14(e, _o_0, _app_31, _app_32, _app_33, _app_34, _app_34 == h3 ? q3 : blk_loc(e.mem, _app_34), _app_35, _app_36, _app_37, _app_37 == h6 ? q6 : blk_loc(e.mem, _app_37), _app_38, _app_38 == h7 ? q7 : blk_loc(e.mem, _app_38), _app_39, _app_40, _app_41, _app_42, _app_43, _app_44, _app_45, _app_46, _app_47, _app_48, _app_49, _app_50, _app_50 == h19 ? q19 : blk_loc(e.mem, _app_50), _app_51, _app_51 == h20 ? q20 : blk_loc(e.mem, _app_51), _app_52, _app_52 == h21 ? q21 : blk_loc(e.mem, _app_52), _app_53, _app_54, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0) == 0) {
      return 0;
    }
    _v_86 = _o_0[0];
    _v_87 = _o_0[1];
    _v_88 = _o_0[2];
    _v_89 = _o_0[3];
    _v_90 = _o_0[4];
    _v_91 = _o_0[5];
    _v_92 = _o_0[6];
    _v_93 = _o_0[7];
    _v_94 = _o_0[8];
    _v_95 = _o_0[9];
    _v_96 = _o_0[10];
    _v_97 = _o_0[11];
    _v_98 = _o_0[12];
    _v_99 = _o_0[13];
    _v_100 = _o_0[14];
    _v_101 = _o_0[15];
    _v_102 = _o_0[16];
    _v_103 = _o_0[17];
    _v_104 = _o_0[18];
    _v_105 = _o_0[19];
    _v_106 = _o_0[20];
    _v_107 = _o_0[21];
    _v_108 = _o_0[22];
    _v_109 = _o_0[23];
    _v_62 = _v_86;
    _v_63 = _v_87;
    _v_64 = _v_88;
    _v_65 = _v_89;
    _v_66 = _v_90;
    _v_67 = _v_91;
    _v_68 = _v_92;
    _v_69 = _v_93;
    _v_70 = _v_94;
    _v_71 = _v_95;
    _v_72 = _v_96;
    _v_73 = _v_97;
    _v_74 = _v_98;
    _v_75 = _v_99;
    _v_76 = _v_100;
    _v_77 = _v_101;
    _v_78 = _v_102;
    _v_79 = _v_103;
    _v_80 = _v_104;
    _v_81 = _v_105;
    _v_82 = _v_106;
    _v_83 = _v_107;
    _v_84 = _v_108;
    _v_85 = _v_109;
    _v_31 = _v_62;
    _v_32 = _v_63;
    _v_33 = _v_64;
    _v_34 = _v_65;
    _v_35 = _v_66;
    _v_36 = _v_67;
    _v_37 = _v_68;
    _v_38 = _v_69;
    _v_39 = _v_70;
    _v_40 = _v_71;
    _v_41 = _v_72;
    _v_42 = _v_73;
    _v_43 = _v_74;
    _v_44 = _v_75;
    _v_45 = _v_76;
    _v_46 = _v_77;
    _v_47 = _v_78;
    _v_48 = _v_79;
    _v_49 = _v_80;
    _v_50 = _v_81;
    _v_51 = _v_82;
    _v_52 = _v_83;
    _v_53 = _v_84;
    _v_54 = _v_85;
    _v_55 = _app_55;
    _v_56 = _app_56;
    _v_57 = _app_57;
    _v_58 = _app_58;
    _v_59 = _app_59;
    _v_60 = _app_60;
    _v_61 = _app_61;
  break;
  }
  o[0] = _v_31;
  o[1] = _v_32;
  o[2] = _v_33;
  o[3] = _v_34;
  o[4] = _v_35;
  o[5] = _v_36;
  o[6] = _v_37;
  o[7] = _v_38;
  o[8] = _v_39;
  o[9] = _v_40;
  o[10] = _v_41;
  o[11] = _v_42;
  o[12] = _v_43;
  o[13] = _v_44;
  o[14] = _v_45;
  o[15] = _v_46;
  o[16] = _v_47;
  o[17] = _v_48;
  o[18] = _v_49;
  o[19] = _v_50;
  o[20] = _v_51;
  o[21] = _v_52;
  o[22] = _v_53;
  o[23] = _v_54;
  o[24] = _v_55;
  o[25] = _v_56;
  o[26] = _v_57;
  o[27] = _v_58;
  o[28] = _v_59;
  o[29] = _v_60;
  o[30] = _v_61;
  return 1;
}

INLINE Term spin_57(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13) {
  u32 wpoll = 0;
  Term h2 = r2;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  Term _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  Term _v_47 = 0;
  Term _v_48 = 0;
  Term _v_49 = 0;
  u32 _v_50 = 0;
  u32 _v_51 = 0;
  u32 _available_0 = r0;
  u32 _namespace_0 = r1;
  Term _resource_12 = r2;
  u32 _resource_13 = r3;
  u32 _resource_14 = r4;
  u32 _resource_15 = r5;
  u32 _resource_16 = r6;
  u32 _resource_17 = r7;
  u32 _resource_18 = r8;
  u32 _resource_19 = r9;
  u32 _resource_20 = r10;
  u32 _resource_21 = r11;
  u32 _resource_22 = r12;
  u32 _resource_23 = r13;
  WL_SPIN
    if (_available_0 == 0) {
      _v_26 = 1;
      _v_27 = _namespace_0;
      _v_28 = _resource_12;
      _v_29 = _resource_13;
      _v_30 = _resource_14;
      _v_31 = _resource_15;
      _v_32 = _resource_16;
      _v_33 = _resource_17;
      _v_34 = _resource_18;
      _v_35 = _resource_19;
      _v_36 = _resource_20;
      _v_37 = _resource_21;
      _v_38 = _resource_22;
      _v_39 = _resource_23;
      _v_40 = 0;
      _v_41 = 0;
      _v_42 = 0;
      _v_43 = 0;
      _v_44 = 0;
      _v_45 = 0;
      _v_46 = 0;
      _v_47 = 0;
      _v_48 = 0;
      _v_49 = 0;
      _v_50 = 0;
      _v_51 = 0;
    } else {
      Term _fv_0[1];
      _fv_0[0] = 0;
      Term _fv_1[1];
      _fv_1[0] = 13ull;
      Term _fv_2[1];
      _fv_2[0] = 29ull;
      Term _fv_3[1];
      _fv_3[0] = blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1), blk_new(e, 0, 0, 0, 1, _fv_2));
      Term _fv_4[1];
      _fv_4[0] = 47ull;
      Term _fv_5[1];
      _fv_5[0] = blk_new(e, 0, 0, 0, 1, _fv_4);
      _v_26 = 0;
      _v_27 = U32_BIN(_namespace_0, +, 1ull);
      _v_28 = _namespace_0;
      _v_29 = 1ull;
      _v_30 = 0ull;
      _v_31 = blk_new(e, 0, 0, 0, 1, _fv_0);
      _v_32 = 1ull;
      _v_33 = 0;
      _v_34 = blk_node(e, blk_new(e, 1, 0, 0, 1, _fv_3), blk_new(e, 1, 0, 0, 1, _fv_5));
      _v_35 = _resource_12;
      _v_36 = _resource_13;
      _v_37 = _resource_14;
      _v_38 = _resource_15;
      _v_39 = _resource_16;
      _v_40 = _resource_17;
      _v_41 = _resource_18;
      _v_42 = _resource_19;
      _v_43 = _resource_20;
      _v_44 = _resource_21;
      _v_45 = _resource_22;
      _v_46 = _resource_23;
      _v_47 = term_pak(CID_NIL, 0);
      _v_48 = term_pak(CID_NIL, 0);
      _v_49 = term_pak(CID_NIL, 0);
      _v_50 = 1ull;
      _v_51 = 0ull;
    }
  break;
  }
  o[0] = _v_26;
  o[1] = _v_27;
  o[2] = _v_28;
  o[3] = _v_29;
  o[4] = _v_30;
  o[5] = _v_31;
  o[6] = _v_32;
  o[7] = _v_33;
  o[8] = _v_34;
  o[9] = _v_35;
  o[10] = _v_36;
  o[11] = _v_37;
  o[12] = _v_38;
  o[13] = _v_39;
  o[14] = _v_40;
  o[15] = _v_41;
  o[16] = _v_42;
  o[17] = _v_43;
  o[18] = _v_44;
  o[19] = _v_45;
  o[20] = _v_46;
  o[21] = _v_47;
  o[22] = _v_48;
  o[23] = _v_49;
  o[24] = _v_50;
  o[25] = _v_51;
  return 1;
}

INLINE Term spin_58(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  u32 _v_109 = 0;
  u32 _v_110 = 0;
  u32 _v_111 = 0;
  Term _v_112 = 0;
  u32 _v_113 = 0;
  Term _v_114 = 0;
  Term _v_115 = 0;
  Term _v_116 = 0;
  u32 _v_117 = 0;
  u32 _v_118 = 0;
  u32 _v_119 = 0;
  u32 _v_120 = 0;
  u32 _v_121 = 0;
  u32 _v_122 = 0;
  u32 _v_123 = 0;
  u32 _v_124 = 0;
  u32 _v_125 = 0;
  u32 _v_126 = 0;
  u32 _v_127 = 0;
  Term _v_128 = 0;
  Term _v_129 = 0;
  Term _v_130 = 0;
  u32 _v_131 = 0;
  u32 _v_132 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  Term _world_6 = r6;
  Term _world_7 = r7;
  u32 _world_8 = r8;
  u32 _world_9 = r9;
  u32 _world_10 = r10;
  u32 _world_11 = r11;
  u32 _world_12 = r12;
  u32 _world_13 = r13;
  u32 _world_14 = r14;
  u32 _world_15 = r15;
  u32 _world_16 = r16;
  u32 _world_17 = r17;
  u32 _world_18 = r18;
  Term _world_19 = r19;
  Term _world_20 = r20;
  Term _world_21 = r21;
  u32 _world_22 = r22;
  u32 _world_23 = r23;
  WL_SPIN
    term_sink(e, _world_19);
    term_sink(e, _world_20);
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, term_clo(FID_CONSUMER_EXPANDED_SEED_0_C366, 0));
    e.mem[_nd_2 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    _v_109 = _world_0;
    _v_110 = _world_1;
    _v_111 = _world_2;
    _v_112 = _world_3;
    _v_113 = _world_4;
    _v_114 = _world_5;
    _v_115 = _world_6;
    _v_116 = _world_7;
    _v_117 = _world_8;
    _v_118 = _world_9;
    _v_119 = _world_10;
    _v_120 = _world_11;
    _v_121 = _world_12;
    _v_122 = _world_13;
    _v_123 = _world_14;
    _v_124 = _world_15;
    _v_125 = _world_16;
    _v_126 = _world_17;
    _v_127 = _world_18;
    _v_128 = term_ctr(CID_CON, STAT_OFF + 454);
    _v_129 = term_ctr(CID_CON, _nd_2);
    _v_130 = _world_21;
    _v_131 = _world_22;
    _v_132 = 17ull;
  break;
  }
  o[0] = _v_109;
  o[1] = _v_110;
  o[2] = _v_111;
  o[3] = _v_112;
  o[4] = _v_113;
  o[5] = _v_114;
  o[6] = _v_115;
  o[7] = _v_116;
  o[8] = _v_117;
  o[9] = _v_118;
  o[10] = _v_119;
  o[11] = _v_120;
  o[12] = _v_121;
  o[13] = _v_122;
  o[14] = _v_123;
  o[15] = _v_124;
  o[16] = _v_125;
  o[17] = _v_126;
  o[18] = _v_127;
  o[19] = _v_128;
  o[20] = _v_129;
  o[21] = _v_130;
  o[22] = _v_131;
  o[23] = _v_132;
  return 1;
}

INLINE Term spin_59(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21, u32 r22, u32 r23, Term r24, u64 q24, Term r25, u64 q25) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  Term h24 = r24;
  Term h25 = r25;
  u32 _v_187 = 0;
  u32 _v_188 = 0;
  u32 _v_189 = 0;
  u32 _v_190 = 0;
  Term _v_191 = 0;
  u32 _v_192 = 0;
  Term _v_193 = 0;
  Term _v_194 = 0;
  Term _v_195 = 0;
  u32 _v_196 = 0;
  u32 _v_197 = 0;
  u32 _v_198 = 0;
  u32 _v_199 = 0;
  u32 _v_200 = 0;
  u32 _v_201 = 0;
  u32 _v_202 = 0;
  u32 _v_203 = 0;
  u32 _v_204 = 0;
  u32 _v_205 = 0;
  u32 _v_206 = 0;
  Term _v_207 = 0;
  Term _v_208 = 0;
  Term _v_209 = 0;
  u32 _v_210 = 0;
  u32 _v_211 = 0;
  u32 _v_212 = 0;
  u32 _v_213 = 0;
  Term _v_214 = 0;
  Term _v_215 = 0;
  u32 _v_216 = 0;
  u32 _world_24 = r0;
  u32 _world_25 = r1;
  u32 _world_26 = r2;
  Term _world_27 = r3;
  u32 _world_28 = r4;
  Term _world_29 = r5;
  Term _world_30 = r6;
  Term _world_31 = r7;
  u32 _world_32 = r8;
  u32 _world_33 = r9;
  u32 _world_34 = r10;
  u32 _world_35 = r11;
  u32 _world_36 = r12;
  u32 _world_37 = r13;
  u32 _world_38 = r14;
  u32 _world_39 = r15;
  u32 _world_40 = r16;
  u32 _world_41 = r17;
  u32 _world_42 = r18;
  Term _world_43 = r19;
  Term _world_44 = r20;
  Term _world_45 = r21;
  u32 _world_46 = r22;
  u32 _world_47 = r23;
  Term _name_0 = r24;
  Term _access_0 = r25;
  WL_SPIN
    u32 _v_217 = 0;
    u32 _v_218 = 0;
    u32 _v_219 = 0;
    Term _v_220 = 0;
    u32 _v_221 = 0;
    Term _v_222 = 0;
    Term _v_223 = 0;
    Term _v_224 = 0;
    u32 _v_225 = 0;
    u32 _v_226 = 0;
    u32 _v_227 = 0;
    u32 _v_228 = 0;
    u32 _v_229 = 0;
    u32 _v_230 = 0;
    u32 _v_231 = 0;
    u32 _v_232 = 0;
    u32 _v_233 = 0;
    u32 _v_234 = 0;
    u32 _v_235 = 0;
    Term _v_236 = 0;
    Term _v_237 = 0;
    Term _v_238 = 0;
    u32 _v_239 = 0;
    u32 _v_240 = 0;
    u32 _v_241 = 0;
    u32 _v_242 = 0;
    u32 _v_243 = 0;
    u32 _v_244 = 0;
    Term _v_245 = 0;
    u32 _v_246 = 0;
    Term _v_247 = 0;
    Term _v_248 = 0;
    Term _v_249 = 0;
    u32 _v_250 = 0;
    u32 _v_251 = 0;
    u32 _v_252 = 0;
    u32 _v_253 = 0;
    u32 _v_254 = 0;
    u32 _v_255 = 0;
    u32 _v_256 = 0;
    u32 _v_257 = 0;
    u32 _v_258 = 0;
    u32 _v_259 = 0;
    u32 _v_260 = 0;
    Term _v_261 = 0;
    Term _v_262 = 0;
    Term _v_263 = 0;
    u32 _v_264 = 0;
    u32 _v_265 = 0;
    u32 _v_266 = 0;
    Term _o_2[25];
    if (spin_40(e, _o_2, _world_24, _world_25, _world_26, _world_27, _world_27 == h3 ? q3 : blk_loc(e.mem, _world_27), _world_28, _world_29, _world_30, _world_30 == h6 ? q6 : blk_loc(e.mem, _world_30), _world_31, _world_31 == h7 ? q7 : blk_loc(e.mem, _world_31), _world_32, _world_33, _world_34, _world_35, _world_36, _world_37, _world_38, _world_39, _world_40, _world_41, _world_42, _world_43, _world_43 == h19 ? q19 : blk_loc(e.mem, _world_43), _world_44, _world_44 == h20 ? q20 : blk_loc(e.mem, _world_44), _world_45, _world_45 == h21 ? q21 : blk_loc(e.mem, _world_45), _world_46, _world_47) == 0) {
      return 0;
    }
    _v_242 = _o_2[0];
    _v_243 = _o_2[1];
    _v_244 = _o_2[2];
    _v_245 = _o_2[3];
    _v_246 = _o_2[4];
    _v_247 = _o_2[5];
    _v_248 = _o_2[6];
    _v_249 = _o_2[7];
    _v_250 = _o_2[8];
    _v_251 = _o_2[9];
    _v_252 = _o_2[10];
    _v_253 = _o_2[11];
    _v_254 = _o_2[12];
    _v_255 = _o_2[13];
    _v_256 = _o_2[14];
    _v_257 = _o_2[15];
    _v_258 = _o_2[16];
    _v_259 = _o_2[17];
    _v_260 = _o_2[18];
    _v_261 = _o_2[19];
    _v_262 = _o_2[20];
    _v_263 = _o_2[21];
    _v_264 = _o_2[22];
    _v_265 = _o_2[23];
    _v_266 = _o_2[24];
    _v_217 = _v_242;
    _v_218 = _v_243;
    _v_219 = _v_244;
    _v_220 = _v_245;
    _v_221 = _v_246;
    _v_222 = _v_247;
    _v_223 = _v_248;
    _v_224 = _v_249;
    _v_225 = _v_250;
    _v_226 = _v_251;
    _v_227 = _v_252;
    _v_228 = _v_253;
    _v_229 = _v_254;
    _v_230 = _v_255;
    _v_231 = _v_256;
    _v_232 = _v_257;
    _v_233 = _v_258;
    _v_234 = _v_259;
    _v_235 = _v_260;
    _v_236 = _v_261;
    _v_237 = _v_262;
    _v_238 = _v_263;
    _v_239 = _v_264;
    _v_240 = _v_265;
    _v_241 = _v_266;
    u32 _v_267 = 0;
    u32 _v_268 = 0;
    u32 _v_269 = 0;
    u32 _v_270 = 0;
    Term _v_271 = 0;
    u32 _v_272 = 0;
    Term _v_273 = 0;
    Term _v_274 = 0;
    Term _v_275 = 0;
    u32 _v_276 = 0;
    u32 _v_277 = 0;
    u32 _v_278 = 0;
    u32 _v_279 = 0;
    u32 _v_280 = 0;
    u32 _v_281 = 0;
    u32 _v_282 = 0;
    u32 _v_283 = 0;
    u32 _v_284 = 0;
    u32 _v_285 = 0;
    u32 _v_286 = 0;
    Term _v_287 = 0;
    Term _v_288 = 0;
    Term _v_289 = 0;
    u32 _v_290 = 0;
    u32 _v_291 = 0;
    u32 _v_292 = 0;
    u32 _v_293 = 0;
    Term _v_294 = 0;
    Term _v_295 = 0;
    u32 _v_296 = 0;
    Term _o_3[30];
    if (spin_55(e, _o_3, _v_217, _v_218, _v_219, _v_220, _v_220 == h25 ? q25 : _v_220 == h24 ? q24 : _v_220 == h21 ? q21 : _v_220 == h20 ? q20 : _v_220 == h19 ? q19 : _v_220 == h7 ? q7 : _v_220 == h6 ? q6 : _v_220 == h3 ? q3 : blk_loc(e.mem, _v_220), _v_221, _v_222, _v_223, _v_223 == h25 ? q25 : _v_223 == h24 ? q24 : _v_223 == h21 ? q21 : _v_223 == h20 ? q20 : _v_223 == h19 ? q19 : _v_223 == h7 ? q7 : _v_223 == h6 ? q6 : _v_223 == h3 ? q3 : blk_loc(e.mem, _v_223), _v_224, _v_224 == h25 ? q25 : _v_224 == h24 ? q24 : _v_224 == h21 ? q21 : _v_224 == h20 ? q20 : _v_224 == h19 ? q19 : _v_224 == h7 ? q7 : _v_224 == h6 ? q6 : _v_224 == h3 ? q3 : blk_loc(e.mem, _v_224), _v_225, _v_226, _v_227, _v_228, _v_229, _v_230, _v_231, _v_232, _v_233, _v_234, _v_235, _v_236, _v_236 == h25 ? q25 : _v_236 == h24 ? q24 : _v_236 == h21 ? q21 : _v_236 == h20 ? q20 : _v_236 == h19 ? q19 : _v_236 == h7 ? q7 : _v_236 == h6 ? q6 : _v_236 == h3 ? q3 : blk_loc(e.mem, _v_236), _v_237, _v_237 == h25 ? q25 : _v_237 == h24 ? q24 : _v_237 == h21 ? q21 : _v_237 == h20 ? q20 : _v_237 == h19 ? q19 : _v_237 == h7 ? q7 : _v_237 == h6 ? q6 : _v_237 == h3 ? q3 : blk_loc(e.mem, _v_237), _v_238, _v_238 == h25 ? q25 : _v_238 == h24 ? q24 : _v_238 == h21 ? q21 : _v_238 == h20 ? q20 : _v_238 == h19 ? q19 : _v_238 == h7 ? q7 : _v_238 == h6 ? q6 : _v_238 == h3 ? q3 : blk_loc(e.mem, _v_238), _v_239, _v_240, _v_241, _name_0, _name_0 == h24 ? q24 : blk_loc(e.mem, _name_0), _access_0, _access_0 == h25 ? q25 : blk_loc(e.mem, _access_0)) == 0) {
      return 0;
    }
    _v_267 = _o_3[0];
    _v_268 = _o_3[1];
    _v_269 = _o_3[2];
    _v_270 = _o_3[3];
    _v_271 = _o_3[4];
    _v_272 = _o_3[5];
    _v_273 = _o_3[6];
    _v_274 = _o_3[7];
    _v_275 = _o_3[8];
    _v_276 = _o_3[9];
    _v_277 = _o_3[10];
    _v_278 = _o_3[11];
    _v_279 = _o_3[12];
    _v_280 = _o_3[13];
    _v_281 = _o_3[14];
    _v_282 = _o_3[15];
    _v_283 = _o_3[16];
    _v_284 = _o_3[17];
    _v_285 = _o_3[18];
    _v_286 = _o_3[19];
    _v_287 = _o_3[20];
    _v_288 = _o_3[21];
    _v_289 = _o_3[22];
    _v_290 = _o_3[23];
    _v_291 = _o_3[24];
    _v_292 = _o_3[25];
    _v_293 = _o_3[26];
    _v_294 = _o_3[27];
    _v_295 = _o_3[28];
    _v_296 = _o_3[29];
    _v_187 = _v_267;
    _v_188 = _v_268;
    _v_189 = _v_269;
    _v_190 = _v_270;
    _v_191 = _v_271;
    _v_192 = _v_272;
    _v_193 = _v_273;
    _v_194 = _v_274;
    _v_195 = _v_275;
    _v_196 = _v_276;
    _v_197 = _v_277;
    _v_198 = _v_278;
    _v_199 = _v_279;
    _v_200 = _v_280;
    _v_201 = _v_281;
    _v_202 = _v_282;
    _v_203 = _v_283;
    _v_204 = _v_284;
    _v_205 = _v_285;
    _v_206 = _v_286;
    _v_207 = _v_287;
    _v_208 = _v_288;
    _v_209 = _v_289;
    _v_210 = _v_290;
    _v_211 = _v_291;
    _v_212 = _v_292;
    _v_213 = _v_293;
    _v_214 = _v_294;
    _v_215 = _v_295;
    _v_216 = _v_296;
  break;
  }
  o[0] = _v_187;
  o[1] = _v_188;
  o[2] = _v_189;
  o[3] = _v_190;
  o[4] = _v_191;
  o[5] = _v_192;
  o[6] = _v_193;
  o[7] = _v_194;
  o[8] = _v_195;
  o[9] = _v_196;
  o[10] = _v_197;
  o[11] = _v_198;
  o[12] = _v_199;
  o[13] = _v_200;
  o[14] = _v_201;
  o[15] = _v_202;
  o[16] = _v_203;
  o[17] = _v_204;
  o[18] = _v_205;
  o[19] = _v_206;
  o[20] = _v_207;
  o[21] = _v_208;
  o[22] = _v_209;
  o[23] = _v_210;
  o[24] = _v_211;
  o[25] = _v_212;
  o[26] = _v_213;
  o[27] = _v_214;
  o[28] = _v_215;
  o[29] = _v_216;
  return 1;
}

INLINE Term spin_60(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, Term r4, u64 q4, u32 r5, Term r6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, u32 r19, Term r20, u64 q20, Term r21, u64 q21, Term r22, u64 q22, u32 r23, u32 r24, u32 r25, u32 r26, Term r27, u64 q27, Term r28, u64 q28, u32 r29) {
  u32 wpoll = 0;
  Term h4 = r4;
  Term h7 = r7;
  Term h8 = r8;
  Term h20 = r20;
  Term h21 = r21;
  Term h22 = r22;
  Term h27 = r27;
  Term h28 = r28;
  u32 _v_328 = 0;
  u32 _v_329 = 0;
  u32 _v_330 = 0;
  Term _v_331 = 0;
  u32 _v_332 = 0;
  Term _v_333 = 0;
  Term _v_334 = 0;
  Term _v_335 = 0;
  u32 _v_336 = 0;
  u32 _v_337 = 0;
  u32 _v_338 = 0;
  u32 _v_339 = 0;
  u32 _v_340 = 0;
  u32 _v_341 = 0;
  u32 _v_342 = 0;
  u32 _v_343 = 0;
  u32 _v_344 = 0;
  u32 _v_345 = 0;
  u32 _v_346 = 0;
  Term _v_347 = 0;
  Term _v_348 = 0;
  Term _v_349 = 0;
  u32 _v_350 = 0;
  u32 _v_351 = 0;
  u32 _v_352 = 0;
  u32 _v_353 = 0;
  u32 _v_354 = 0;
  Term _v_355 = 0;
  Term _v_356 = 0;
  u32 _v_357 = 0;
  Term _v_358 = 0;
  u32 _result_26 = r0;
  u32 _result_27 = r1;
  u32 _result_28 = r2;
  u32 _result_29 = r3;
  Term _result_30 = r4;
  u32 _result_31 = r5;
  Term _result_32 = r6;
  Term _result_33 = r7;
  Term _result_34 = r8;
  u32 _result_35 = r9;
  u32 _result_36 = r10;
  u32 _result_37 = r11;
  u32 _result_38 = r12;
  u32 _result_39 = r13;
  u32 _result_40 = r14;
  u32 _result_41 = r15;
  u32 _result_42 = r16;
  u32 _result_43 = r17;
  u32 _result_44 = r18;
  u32 _result_45 = r19;
  Term _result_46 = r20;
  Term _result_47 = r21;
  Term _result_48 = r22;
  u32 _result_49 = r23;
  u32 _result_50 = r24;
  u32 _result_51 = r25;
  u32 _result_52 = r26;
  Term _result_53 = r27;
  Term _result_54 = r28;
  u32 _result_55 = r29;
  WL_SPIN
    if (_result_26 == 0) {
      _v_328 = _result_27;
      _v_329 = _result_28;
      _v_330 = _result_29;
      _v_331 = _result_30;
      _v_332 = _result_31;
      _v_333 = _result_32;
      _v_334 = _result_33;
      _v_335 = _result_34;
      _v_336 = _result_35;
      _v_337 = _result_36;
      _v_338 = _result_37;
      _v_339 = _result_38;
      _v_340 = _result_39;
      _v_341 = _result_40;
      _v_342 = _result_41;
      _v_343 = _result_42;
      _v_344 = _result_43;
      _v_345 = _result_44;
      _v_346 = _result_45;
      _v_347 = _result_46;
      _v_348 = _result_47;
      _v_349 = _result_48;
      _v_350 = _result_49;
      _v_351 = _result_50;
      _v_352 = 1;
      _v_353 = _result_51;
      _v_354 = _result_52;
      _v_355 = _result_53;
      _v_356 = _result_54;
      _v_357 = _result_55;
      _v_358 = term_ctr(CID_SCON, STAT_OFF + 154);
    } else {
      _v_328 = _result_27;
      _v_329 = _result_28;
      _v_330 = _result_29;
      _v_331 = _result_30;
      _v_332 = _result_31;
      _v_333 = _result_32;
      _v_334 = _result_33;
      _v_335 = _result_34;
      _v_336 = _result_35;
      _v_337 = _result_36;
      _v_338 = _result_37;
      _v_339 = _result_38;
      _v_340 = _result_39;
      _v_341 = _result_40;
      _v_342 = _result_41;
      _v_343 = _result_42;
      _v_344 = _result_43;
      _v_345 = _result_44;
      _v_346 = _result_45;
      _v_347 = _result_46;
      _v_348 = _result_47;
      _v_349 = _result_48;
      _v_350 = _result_49;
      _v_351 = _result_50;
      _v_352 = 0;
      _v_353 = 0;
      _v_354 = 0;
      _v_355 = 0;
      _v_356 = 0;
      _v_357 = 0;
      _v_358 = term_ctr(CID_SCON, STAT_OFF + 490);
    }
  break;
  }
  o[0] = _v_328;
  o[1] = _v_329;
  o[2] = _v_330;
  o[3] = _v_331;
  o[4] = _v_332;
  o[5] = _v_333;
  o[6] = _v_334;
  o[7] = _v_335;
  o[8] = _v_336;
  o[9] = _v_337;
  o[10] = _v_338;
  o[11] = _v_339;
  o[12] = _v_340;
  o[13] = _v_341;
  o[14] = _v_342;
  o[15] = _v_343;
  o[16] = _v_344;
  o[17] = _v_345;
  o[18] = _v_346;
  o[19] = _v_347;
  o[20] = _v_348;
  o[21] = _v_349;
  o[22] = _v_350;
  o[23] = _v_351;
  o[24] = _v_352;
  o[25] = _v_353;
  o[26] = _v_354;
  o[27] = _v_355;
  o[28] = _v_356;
  o[29] = _v_357;
  o[30] = _v_358;
  return 1;
}

FAR Term spin_61(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, u32 r3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12, u32 r13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, u32 r19, u32 r20, Term r21, u64 q21, Term r22, u64 q22, Term r23, u64 q23, u32 r24, u32 r25) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h5 = r5;
  Term h8 = r8;
  Term h9 = r9;
  Term h21 = r21;
  Term h22 = r22;
  Term h23 = r23;
  u32 _v_84 = 0;
  u32 _v_85 = 0;
  u32 _v_86 = 0;
  u32 _v_87 = 0;
  Term _v_88 = 0;
  u32 _v_89 = 0;
  Term _v_90 = 0;
  Term _v_91 = 0;
  Term _v_92 = 0;
  u32 _v_93 = 0;
  u32 _v_94 = 0;
  u32 _v_95 = 0;
  u32 _v_96 = 0;
  u32 _v_97 = 0;
  u32 _v_98 = 0;
  u32 _v_99 = 0;
  u32 _v_100 = 0;
  u32 _v_101 = 0;
  u32 _v_102 = 0;
  u32 _v_103 = 0;
  Term _v_104 = 0;
  Term _v_105 = 0;
  Term _v_106 = 0;
  u32 _v_107 = 0;
  u32 _v_108 = 0;
  u32 _v_109 = 0;
  u32 _v_110 = 0;
  u32 _v_111 = 0;
  Term _v_112 = 0;
  Term _v_113 = 0;
  u32 _v_114 = 0;
  Term _v_115 = 0;
  u32 _result_0 = r0;
  u32 _result_1 = r1;
  Term _result_2 = r2;
  u32 _result_3 = r3;
  u32 _result_4 = r4;
  Term _result_5 = r5;
  u32 _result_6 = r6;
  Term _result_7 = r7;
  Term _result_8 = r8;
  Term _result_9 = r9;
  u32 _result_10 = r10;
  u32 _result_11 = r11;
  u32 _result_12 = r12;
  u32 _result_13 = r13;
  u32 _result_14 = r14;
  u32 _result_15 = r15;
  u32 _result_16 = r16;
  u32 _result_17 = r17;
  u32 _result_18 = r18;
  u32 _result_19 = r19;
  u32 _result_20 = r20;
  Term _result_21 = r21;
  Term _result_22 = r22;
  Term _result_23 = r23;
  u32 _result_24 = r24;
  u32 _result_25 = r25;
  WL_SPIN
    if (_result_0 == 0) {
      u32 _v_116 = 0;
      u32 _v_117 = 0;
      u32 _v_118 = 0;
      Term _v_119 = 0;
      u32 _v_120 = 0;
      Term _v_121 = 0;
      Term _v_122 = 0;
      Term _v_123 = 0;
      u32 _v_124 = 0;
      u32 _v_125 = 0;
      u32 _v_126 = 0;
      u32 _v_127 = 0;
      u32 _v_128 = 0;
      u32 _v_129 = 0;
      u32 _v_130 = 0;
      u32 _v_131 = 0;
      u32 _v_132 = 0;
      u32 _v_133 = 0;
      u32 _v_134 = 0;
      Term _v_135 = 0;
      Term _v_136 = 0;
      Term _v_137 = 0;
      u32 _v_138 = 0;
      u32 _v_139 = 0;
      u32 _v_140 = 0;
      u32 _v_141 = 0;
      u32 _v_142 = 0;
      Term _v_143 = 0;
      Term _v_144 = 0;
      u32 _v_145 = 0;
      Term _v_146 = 0;
      u32 _v_147 = 0;
      u32 _v_148 = 0;
      u32 _v_149 = 0;
      u32 _v_150 = 0;
      Term _v_151 = 0;
      u32 _v_152 = 0;
      Term _v_153 = 0;
      Term _v_154 = 0;
      Term _v_155 = 0;
      u32 _v_156 = 0;
      u32 _v_157 = 0;
      u32 _v_158 = 0;
      u32 _v_159 = 0;
      u32 _v_160 = 0;
      u32 _v_161 = 0;
      u32 _v_162 = 0;
      u32 _v_163 = 0;
      u32 _v_164 = 0;
      u32 _v_165 = 0;
      u32 _v_166 = 0;
      Term _v_167 = 0;
      Term _v_168 = 0;
      Term _v_169 = 0;
      u32 _v_170 = 0;
      u32 _v_171 = 0;
      u32 _v_172 = 0;
      u32 _v_173 = 0;
      Term _v_174 = 0;
      Term _v_175 = 0;
      u32 _v_176 = 0;
      u32 _v_177 = 0;
      u32 _v_178 = 0;
      u32 _v_179 = 0;
      Term _v_180 = 0;
      u32 _v_181 = 0;
      Term _v_182 = 0;
      Term _v_183 = 0;
      Term _v_184 = 0;
      u32 _v_185 = 0;
      u32 _v_186 = 0;
      u32 _v_187 = 0;
      u32 _v_188 = 0;
      u32 _v_189 = 0;
      u32 _v_190 = 0;
      u32 _v_191 = 0;
      u32 _v_192 = 0;
      u32 _v_193 = 0;
      u32 _v_194 = 0;
      u32 _v_195 = 0;
      Term _v_196 = 0;
      Term _v_197 = 0;
      Term _v_198 = 0;
      u32 _v_199 = 0;
      u32 _v_200 = 0;
      u32 _v_201 = 0;
      u32 _v_202 = 0;
      u32 _v_203 = 0;
      Term _v_204 = 0;
      u32 _v_205 = 0;
      Term _v_206 = 0;
      Term _v_207 = 0;
      Term _v_208 = 0;
      u32 _v_209 = 0;
      u32 _v_210 = 0;
      u32 _v_211 = 0;
      u32 _v_212 = 0;
      u32 _v_213 = 0;
      u32 _v_214 = 0;
      u32 _v_215 = 0;
      u32 _v_216 = 0;
      u32 _v_217 = 0;
      u32 _v_218 = 0;
      u32 _v_219 = 0;
      Term _v_220 = 0;
      Term _v_221 = 0;
      Term _v_222 = 0;
      u32 _v_223 = 0;
      u32 _v_224 = 0;
      Term _o_1[24];
      if (spin_58(e, _o_1, _result_2, _result_3, _result_4, _result_5, _result_5 == h5 ? q5 : blk_loc(e.mem, _result_5), _result_6, _result_7, _result_8, _result_8 == h8 ? q8 : blk_loc(e.mem, _result_8), _result_9, _result_9 == h9 ? q9 : blk_loc(e.mem, _result_9), _result_10, _result_11, _result_12, _result_13, _result_14, _result_15, _result_16, _result_17, _result_18, _result_19, _result_20, _result_21, _result_21 == h21 ? q21 : blk_loc(e.mem, _result_21), _result_22, _result_22 == h22 ? q22 : blk_loc(e.mem, _result_22), _result_23, _result_23 == h23 ? q23 : blk_loc(e.mem, _result_23), _result_24, _result_25) == 0) {
        return 0;
      }
      _v_201 = _o_1[0];
      _v_202 = _o_1[1];
      _v_203 = _o_1[2];
      _v_204 = _o_1[3];
      _v_205 = _o_1[4];
      _v_206 = _o_1[5];
      _v_207 = _o_1[6];
      _v_208 = _o_1[7];
      _v_209 = _o_1[8];
      _v_210 = _o_1[9];
      _v_211 = _o_1[10];
      _v_212 = _o_1[11];
      _v_213 = _o_1[12];
      _v_214 = _o_1[13];
      _v_215 = _o_1[14];
      _v_216 = _o_1[15];
      _v_217 = _o_1[16];
      _v_218 = _o_1[17];
      _v_219 = _o_1[18];
      _v_220 = _o_1[19];
      _v_221 = _o_1[20];
      _v_222 = _o_1[21];
      _v_223 = _o_1[22];
      _v_224 = _o_1[23];
      _v_177 = _v_201;
      _v_178 = _v_202;
      _v_179 = _v_203;
      _v_180 = _v_204;
      _v_181 = _v_205;
      _v_182 = _v_206;
      _v_183 = _v_207;
      _v_184 = _v_208;
      _v_185 = _v_209;
      _v_186 = _v_210;
      _v_187 = _v_211;
      _v_188 = _v_212;
      _v_189 = _v_213;
      _v_190 = _v_214;
      _v_191 = _v_215;
      _v_192 = _v_216;
      _v_193 = _v_217;
      _v_194 = _v_218;
      _v_195 = _v_219;
      _v_196 = _v_220;
      _v_197 = _v_221;
      _v_198 = _v_222;
      _v_199 = _v_223;
      _v_200 = _v_224;
      u32 _v_225 = 0;
      u32 _v_226 = 0;
      u32 _v_227 = 0;
      u32 _v_228 = 0;
      Term _v_229 = 0;
      u32 _v_230 = 0;
      Term _v_231 = 0;
      Term _v_232 = 0;
      Term _v_233 = 0;
      u32 _v_234 = 0;
      u32 _v_235 = 0;
      u32 _v_236 = 0;
      u32 _v_237 = 0;
      u32 _v_238 = 0;
      u32 _v_239 = 0;
      u32 _v_240 = 0;
      u32 _v_241 = 0;
      u32 _v_242 = 0;
      u32 _v_243 = 0;
      u32 _v_244 = 0;
      Term _v_245 = 0;
      Term _v_246 = 0;
      Term _v_247 = 0;
      u32 _v_248 = 0;
      u32 _v_249 = 0;
      u32 _v_250 = 0;
      u32 _v_251 = 0;
      Term _v_252 = 0;
      Term _v_253 = 0;
      u32 _v_254 = 0;
      Term _o_2[30];
      Term _a_1 = term_ctr(CID_SCON, STAT_OFF + 510);
      Term _a_2 = term_ctr(CID_CON, STAT_OFF + 528);
      if (spin_59(e, _o_2, _v_177, _v_178, _v_179, _v_180, _v_180 == h23 ? q23 : _v_180 == h22 ? q22 : _v_180 == h21 ? q21 : _v_180 == h9 ? q9 : _v_180 == h8 ? q8 : _v_180 == h5 ? q5 : _v_180 == h2 ? q2 : blk_loc(e.mem, _v_180), _v_181, _v_182, _v_183, _v_183 == h23 ? q23 : _v_183 == h22 ? q22 : _v_183 == h21 ? q21 : _v_183 == h9 ? q9 : _v_183 == h8 ? q8 : _v_183 == h5 ? q5 : _v_183 == h2 ? q2 : blk_loc(e.mem, _v_183), _v_184, _v_184 == h23 ? q23 : _v_184 == h22 ? q22 : _v_184 == h21 ? q21 : _v_184 == h9 ? q9 : _v_184 == h8 ? q8 : _v_184 == h5 ? q5 : _v_184 == h2 ? q2 : blk_loc(e.mem, _v_184), _v_185, _v_186, _v_187, _v_188, _v_189, _v_190, _v_191, _v_192, _v_193, _v_194, _v_195, _v_196, _v_196 == h23 ? q23 : _v_196 == h22 ? q22 : _v_196 == h21 ? q21 : _v_196 == h9 ? q9 : _v_196 == h8 ? q8 : _v_196 == h5 ? q5 : _v_196 == h2 ? q2 : blk_loc(e.mem, _v_196), _v_197, _v_197 == h23 ? q23 : _v_197 == h22 ? q22 : _v_197 == h21 ? q21 : _v_197 == h9 ? q9 : _v_197 == h8 ? q8 : _v_197 == h5 ? q5 : _v_197 == h2 ? q2 : blk_loc(e.mem, _v_197), _v_198, _v_198 == h23 ? q23 : _v_198 == h22 ? q22 : _v_198 == h21 ? q21 : _v_198 == h9 ? q9 : _v_198 == h8 ? q8 : _v_198 == h5 ? q5 : _v_198 == h2 ? q2 : blk_loc(e.mem, _v_198), _v_199, _v_200, _a_1, _a_1 == h23 ? q23 : _a_1 == h22 ? q22 : _a_1 == h21 ? q21 : _a_1 == h9 ? q9 : _a_1 == h8 ? q8 : _a_1 == h5 ? q5 : _a_1 == h2 ? q2 : blk_loc(e.mem, _a_1), _a_2, _a_2 == h23 ? q23 : _a_2 == h22 ? q22 : _a_2 == h21 ? q21 : _a_2 == h9 ? q9 : _a_2 == h8 ? q8 : _a_2 == h5 ? q5 : _a_2 == h2 ? q2 : blk_loc(e.mem, _a_2)) == 0) {
        return 0;
      }
      _v_225 = _o_2[0];
      _v_226 = _o_2[1];
      _v_227 = _o_2[2];
      _v_228 = _o_2[3];
      _v_229 = _o_2[4];
      _v_230 = _o_2[5];
      _v_231 = _o_2[6];
      _v_232 = _o_2[7];
      _v_233 = _o_2[8];
      _v_234 = _o_2[9];
      _v_235 = _o_2[10];
      _v_236 = _o_2[11];
      _v_237 = _o_2[12];
      _v_238 = _o_2[13];
      _v_239 = _o_2[14];
      _v_240 = _o_2[15];
      _v_241 = _o_2[16];
      _v_242 = _o_2[17];
      _v_243 = _o_2[18];
      _v_244 = _o_2[19];
      _v_245 = _o_2[20];
      _v_246 = _o_2[21];
      _v_247 = _o_2[22];
      _v_248 = _o_2[23];
      _v_249 = _o_2[24];
      _v_250 = _o_2[25];
      _v_251 = _o_2[26];
      _v_252 = _o_2[27];
      _v_253 = _o_2[28];
      _v_254 = _o_2[29];
      _v_147 = _v_225;
      _v_148 = _v_226;
      _v_149 = _v_227;
      _v_150 = _v_228;
      _v_151 = _v_229;
      _v_152 = _v_230;
      _v_153 = _v_231;
      _v_154 = _v_232;
      _v_155 = _v_233;
      _v_156 = _v_234;
      _v_157 = _v_235;
      _v_158 = _v_236;
      _v_159 = _v_237;
      _v_160 = _v_238;
      _v_161 = _v_239;
      _v_162 = _v_240;
      _v_163 = _v_241;
      _v_164 = _v_242;
      _v_165 = _v_243;
      _v_166 = _v_244;
      _v_167 = _v_245;
      _v_168 = _v_246;
      _v_169 = _v_247;
      _v_170 = _v_248;
      _v_171 = _v_249;
      _v_172 = _v_250;
      _v_173 = _v_251;
      _v_174 = _v_252;
      _v_175 = _v_253;
      _v_176 = _v_254;
      u32 _v_255 = 0;
      u32 _v_256 = 0;
      u32 _v_257 = 0;
      Term _v_258 = 0;
      u32 _v_259 = 0;
      Term _v_260 = 0;
      Term _v_261 = 0;
      Term _v_262 = 0;
      u32 _v_263 = 0;
      u32 _v_264 = 0;
      u32 _v_265 = 0;
      u32 _v_266 = 0;
      u32 _v_267 = 0;
      u32 _v_268 = 0;
      u32 _v_269 = 0;
      u32 _v_270 = 0;
      u32 _v_271 = 0;
      u32 _v_272 = 0;
      u32 _v_273 = 0;
      Term _v_274 = 0;
      Term _v_275 = 0;
      Term _v_276 = 0;
      u32 _v_277 = 0;
      u32 _v_278 = 0;
      u32 _v_279 = 0;
      u32 _v_280 = 0;
      u32 _v_281 = 0;
      Term _v_282 = 0;
      Term _v_283 = 0;
      u32 _v_284 = 0;
      Term _v_285 = 0;
      Term _o_3[31];
      if (spin_60(e, _o_3, _v_147, _v_148, _v_149, _v_150, _v_151, _v_151 == h23 ? q23 : _v_151 == h22 ? q22 : _v_151 == h21 ? q21 : _v_151 == h9 ? q9 : _v_151 == h8 ? q8 : _v_151 == h5 ? q5 : _v_151 == h2 ? q2 : blk_loc(e.mem, _v_151), _v_152, _v_153, _v_154, _v_154 == h23 ? q23 : _v_154 == h22 ? q22 : _v_154 == h21 ? q21 : _v_154 == h9 ? q9 : _v_154 == h8 ? q8 : _v_154 == h5 ? q5 : _v_154 == h2 ? q2 : blk_loc(e.mem, _v_154), _v_155, _v_155 == h23 ? q23 : _v_155 == h22 ? q22 : _v_155 == h21 ? q21 : _v_155 == h9 ? q9 : _v_155 == h8 ? q8 : _v_155 == h5 ? q5 : _v_155 == h2 ? q2 : blk_loc(e.mem, _v_155), _v_156, _v_157, _v_158, _v_159, _v_160, _v_161, _v_162, _v_163, _v_164, _v_165, _v_166, _v_167, _v_167 == h23 ? q23 : _v_167 == h22 ? q22 : _v_167 == h21 ? q21 : _v_167 == h9 ? q9 : _v_167 == h8 ? q8 : _v_167 == h5 ? q5 : _v_167 == h2 ? q2 : blk_loc(e.mem, _v_167), _v_168, _v_168 == h23 ? q23 : _v_168 == h22 ? q22 : _v_168 == h21 ? q21 : _v_168 == h9 ? q9 : _v_168 == h8 ? q8 : _v_168 == h5 ? q5 : _v_168 == h2 ? q2 : blk_loc(e.mem, _v_168), _v_169, _v_169 == h23 ? q23 : _v_169 == h22 ? q22 : _v_169 == h21 ? q21 : _v_169 == h9 ? q9 : _v_169 == h8 ? q8 : _v_169 == h5 ? q5 : _v_169 == h2 ? q2 : blk_loc(e.mem, _v_169), _v_170, _v_171, _v_172, _v_173, _v_174, _v_174 == h23 ? q23 : _v_174 == h22 ? q22 : _v_174 == h21 ? q21 : _v_174 == h9 ? q9 : _v_174 == h8 ? q8 : _v_174 == h5 ? q5 : _v_174 == h2 ? q2 : blk_loc(e.mem, _v_174), _v_175, _v_175 == h23 ? q23 : _v_175 == h22 ? q22 : _v_175 == h21 ? q21 : _v_175 == h9 ? q9 : _v_175 == h8 ? q8 : _v_175 == h5 ? q5 : _v_175 == h2 ? q2 : blk_loc(e.mem, _v_175), _v_176) == 0) {
        return 0;
      }
      _v_255 = _o_3[0];
      _v_256 = _o_3[1];
      _v_257 = _o_3[2];
      _v_258 = _o_3[3];
      _v_259 = _o_3[4];
      _v_260 = _o_3[5];
      _v_261 = _o_3[6];
      _v_262 = _o_3[7];
      _v_263 = _o_3[8];
      _v_264 = _o_3[9];
      _v_265 = _o_3[10];
      _v_266 = _o_3[11];
      _v_267 = _o_3[12];
      _v_268 = _o_3[13];
      _v_269 = _o_3[14];
      _v_270 = _o_3[15];
      _v_271 = _o_3[16];
      _v_272 = _o_3[17];
      _v_273 = _o_3[18];
      _v_274 = _o_3[19];
      _v_275 = _o_3[20];
      _v_276 = _o_3[21];
      _v_277 = _o_3[22];
      _v_278 = _o_3[23];
      _v_279 = _o_3[24];
      _v_280 = _o_3[25];
      _v_281 = _o_3[26];
      _v_282 = _o_3[27];
      _v_283 = _o_3[28];
      _v_284 = _o_3[29];
      _v_285 = _o_3[30];
      _v_116 = _v_255;
      _v_117 = _v_256;
      _v_118 = _v_257;
      _v_119 = _v_258;
      _v_120 = _v_259;
      _v_121 = _v_260;
      _v_122 = _v_261;
      _v_123 = _v_262;
      _v_124 = _v_263;
      _v_125 = _v_264;
      _v_126 = _v_265;
      _v_127 = _v_266;
      _v_128 = _v_267;
      _v_129 = _v_268;
      _v_130 = _v_269;
      _v_131 = _v_270;
      _v_132 = _v_271;
      _v_133 = _v_272;
      _v_134 = _v_273;
      _v_135 = _v_274;
      _v_136 = _v_275;
      _v_137 = _v_276;
      _v_138 = _v_277;
      _v_139 = _v_278;
      _v_140 = _v_279;
      _v_141 = _v_280;
      _v_142 = _v_281;
      _v_143 = _v_282;
      _v_144 = _v_283;
      _v_145 = _v_284;
      _v_146 = _v_285;
      _v_84 = 1;
      _v_85 = _v_116;
      _v_86 = _v_117;
      _v_87 = _v_118;
      _v_88 = _v_119;
      _v_89 = _v_120;
      _v_90 = _v_121;
      _v_91 = _v_122;
      _v_92 = _v_123;
      _v_93 = _v_124;
      _v_94 = _v_125;
      _v_95 = _v_126;
      _v_96 = _v_127;
      _v_97 = _v_128;
      _v_98 = _v_129;
      _v_99 = _v_130;
      _v_100 = _v_131;
      _v_101 = _v_132;
      _v_102 = _v_133;
      _v_103 = _v_134;
      _v_104 = _v_135;
      _v_105 = _v_136;
      _v_106 = _v_137;
      _v_107 = _v_138;
      _v_108 = _v_139;
      _v_109 = _v_140;
      _v_110 = _v_141;
      _v_111 = _v_142;
      _v_112 = _v_143;
      _v_113 = _v_144;
      _v_114 = _v_145;
      _v_115 = _v_146;
    } else {
      term_sink(e, _result_2);
      _v_84 = 0;
      _v_85 = 0;
      _v_86 = 0;
      _v_87 = 0;
      _v_88 = 0;
      _v_89 = 0;
      _v_90 = 0;
      _v_91 = 0;
      _v_92 = 0;
      _v_93 = 0;
      _v_94 = 0;
      _v_95 = 0;
      _v_96 = 0;
      _v_97 = 0;
      _v_98 = 0;
      _v_99 = 0;
      _v_100 = 0;
      _v_101 = 0;
      _v_102 = 0;
      _v_103 = 0;
      _v_104 = 0;
      _v_105 = 0;
      _v_106 = 0;
      _v_107 = 0;
      _v_108 = 0;
      _v_109 = 0;
      _v_110 = 0;
      _v_111 = 0;
      _v_112 = 0;
      _v_113 = 0;
      _v_114 = 0;
      _v_115 = 0;
    }
  break;
  }
  o[0] = _v_84;
  o[1] = _v_85;
  o[2] = _v_86;
  o[3] = _v_87;
  o[4] = _v_88;
  o[5] = _v_89;
  o[6] = _v_90;
  o[7] = _v_91;
  o[8] = _v_92;
  o[9] = _v_93;
  o[10] = _v_94;
  o[11] = _v_95;
  o[12] = _v_96;
  o[13] = _v_97;
  o[14] = _v_98;
  o[15] = _v_99;
  o[16] = _v_100;
  o[17] = _v_101;
  o[18] = _v_102;
  o[19] = _v_103;
  o[20] = _v_104;
  o[21] = _v_105;
  o[22] = _v_106;
  o[23] = _v_107;
  o[24] = _v_108;
  o[25] = _v_109;
  o[26] = _v_110;
  o[27] = _v_111;
  o[28] = _v_112;
  o[29] = _v_113;
  o[30] = _v_114;
  o[31] = _v_115;
  return 1;
}

// Work
// ====

// A host self-jump is a tail call: as a loop, clang hoisted constants into
// symreg's entry (3.05 s against 2.51 s).
#if !DEVICE
#undef  WL_SPIN
#undef  WL_SPUN
#undef  WL_AGAIN
#define WL_SPIN
#define WL_SPUN
#define WL_AGAIN(F) __attribute__((musttail)) return WL_##F(WL_ALL)

typedef Term (PRESERVE(preserve_none) *WlFn)(WL_SIG);
#define WL_X(F) WL_FN WL_##F(WL_SIG);
WL_TABLE WL_X(FID_ENTER)
#undef WL_X
#define WL_X(F) WL_##F,
static const WlFn wl_tab[] = { WL_TABLE };
#undef WL_X
#endif

static Term work_loop(Env e, DEV Term* sp, Term t, u32 seq) {
  WL_BANK
  u32 rn = 0;
  r0 = t;
#if DEVICE
  u32 fid   = FID_ENTER;
  u32 wpoll = 0;
  for (;;) {
  if (err_spun(e.mem, &wpoll)) {
    return 0;
  }
  switch (fid) {
#else
  return WL_FID_ENTER(WL_ALL);
}
#endif

// Segments
// ========

// A task enters through its words: a continuation's results ride r0..
// and its parameters the stack; any other segment's parameters ride r0..

#if !DEVICE
  WL_CASE(FID_LIST_APPEND)
  {
    Term _xs_0 = r0;
    Term _ys_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = _ys_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_LIST_APPEND_K15;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_APPEND_K15, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_LIST_APPEND_K15, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _ys_0;
      _xs_0 = r0;
      _ys_0 = r1;
      WL_AGAIN(FID_LIST_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_APPEND_K15)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_CON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_ACCESS_EQUAL)
  {
    Term _xs_0 = r0;
    Term _ys_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_xs_0) == CID_NIL) {
      if (term_aux(_ys_0) == CID_NIL) {
        r0 = 1;
        WL_RETN(1);
      } else {
        u64 _sp_0 = term_peek(e.mem, _ys_0);
        Term _f_0 = e.mem[_sp_0 + 0];
        Term _f_1 = e.mem[_sp_0 + 1];
        r0 = 0;
        WL_RETN(1);
      }
    } else {
      u64 _sp_1 = term_peek(e.mem, _xs_0);
      Term _f_2 = e.mem[_sp_1 + 0];
      Term _f_3 = e.mem[_sp_1 + 1];
      if (term_aux(_ys_0) == CID_NIL) {
        r0 = 0;
        WL_RETN(1);
      } else {
        u64 _sp_2 = term_peek(e.mem, _ys_0);
        Term _f_4 = e.mem[_sp_2 + 0];
        Term _f_5 = e.mem[_sp_2 + 1];
        if (seq) {
          WL_ROOM(3);
          STK(0) = _f_2;
          STK(1) = _f_4;
          STK(2) = FID________________BENDVY_SRC_ECS_WORLD_ACCESS_EQUAL_K20;
          WL_PUSHN(3);
        } else {
          u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_ACCESS_EQUAL_K20, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _f_2;
          e.mem[_t_0 + 1] = _f_4;
          WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_WORLD_ACCESS_EQUAL_K20, _t_0);
          WL_IDX = 2;
        }
        r0 = _f_3;
        r1 = _f_5;
        _xs_0 = r0;
        _ys_0 = r1;
        WL_AGAIN(FID________________BENDVY_SRC_ECS_WORLD_ACCESS_EQUAL);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_ACCESS_EQUAL_K20)
  {
    WL_POPN(2);
    Term _f_6 = STK(0);
    Term _f_7 = STK(1);
    u32 _h_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _o_3[1];
    if (spin_11(e, _o_3, _f_6, blk_loc(e.mem, _f_6), _f_7, blk_loc(e.mem, _f_7)) == 0) {
      return 0;
    }
    _v_1 = _o_3[0];
    _v_0 = _v_1;
    u32 _v_9 = 0;
    Term _o_4[1];
    if (spin_10(e, _o_4, _v_0, _h_0) == 0) {
      return 0;
    }
    _v_9 = _o_4[0];
    r0 = _v_9;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_TRANSACTION_ROLLBACK_0)
  {
    Term _undo_0 = r0;
    u32 _world_0 = r1;
    u32 _world_1 = r2;
    u32 _world_2 = r3;
    Term _world_3 = r4;
    u32 _world_4 = r5;
    Term _world_5 = r6;
    Term _world_6 = r7;
    Term _world_7 = r8;
    u32 _world_8 = r9;
    u32 _world_9 = r10;
    u32 _world_10 = r11;
    u32 _world_11 = r12;
    u32 _world_12 = r13;
    u32 _world_13 = r14;
    u32 _world_14 = r15;
    u32 _world_15 = r16;
    u32 _world_16 = r17;
    u32 _world_17 = r18;
    u32 _world_18 = r19;
    Term _world_19 = r20;
    Term _world_20 = r21;
    Term _world_21 = r22;
    u32 _world_22 = r23;
    u32 _world_23 = r24;
    WL_OPEN
    if (term_aux(_undo_0) == CID_NIL) {
      r0 = _world_0;
      r1 = _world_1;
      r2 = _world_2;
      r3 = _world_3;
      r4 = _world_4;
      r5 = _world_5;
      r6 = _world_6;
      r7 = _world_7;
      r8 = _world_8;
      r9 = _world_9;
      r10 = _world_10;
      r11 = _world_11;
      r12 = _world_12;
      r13 = _world_13;
      r14 = _world_14;
      r15 = _world_15;
      r16 = _world_16;
      r17 = _world_17;
      r18 = _world_18;
      r19 = _world_19;
      r20 = _world_20;
      r21 = _world_21;
      r22 = _world_22;
      r23 = _world_23;
      WL_RETN(24);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _undo_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = heap_alloc(e, cls_fit(12));
      e.mem[_nd_0 + 0] = rfc_seal(e, _world_7);
      e.mem[_nd_0 + 1] = rfc_seal(e, _world_8);
      e.mem[_nd_0 + 2] = rfc_seal(e, _world_9);
      e.mem[_nd_0 + 3] = rfc_seal(e, _world_10);
      e.mem[_nd_0 + 4] = rfc_seal(e, _world_11);
      e.mem[_nd_0 + 5] = rfc_seal(e, _world_12);
      e.mem[_nd_0 + 6] = rfc_seal(e, _world_13);
      e.mem[_nd_0 + 7] = rfc_seal(e, _world_14);
      e.mem[_nd_0 + 8] = rfc_seal(e, _world_15);
      e.mem[_nd_0 + 9] = rfc_seal(e, _world_16);
      e.mem[_nd_0 + 10] = rfc_seal(e, _world_17);
      e.mem[_nd_0 + 11] = rfc_seal(e, _world_18);
      u64 _nd_1 = heap_alloc(e, cls_fit(13));
      e.mem[_nd_1 + 0] = rfc_seal(e, _world_0);
      e.mem[_nd_1 + 1] = rfc_seal(e, _world_1);
      e.mem[_nd_1 + 2] = rfc_seal(e, _world_2);
      e.mem[_nd_1 + 3] = rfc_seal(e, _world_3);
      e.mem[_nd_1 + 4] = rfc_seal(e, _world_4);
      e.mem[_nd_1 + 5] = rfc_seal(e, _world_5);
      e.mem[_nd_1 + 6] = rfc_seal(e, _world_6);
      e.mem[_nd_1 + 7] = rfc_seal(e, term_ctr(CID_CONSUMER_EXPANDED_RESOURCES, _nd_0));
      e.mem[_nd_1 + 8] = rfc_seal(e, _world_19);
      e.mem[_nd_1 + 9] = rfc_seal(e, _world_20);
      e.mem[_nd_1 + 10] = rfc_seal(e, _world_21);
      e.mem[_nd_1 + 11] = rfc_seal(e, _world_22);
      e.mem[_nd_1 + 12] = rfc_seal(e, _world_23);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID________________BENDVY_SRC_ECS_TRANSACTION_ROLLBACK_0_K27;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_TRANSACTION_ROLLBACK_0_K27, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_TRANSACTION_ROLLBACK_0_K27, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_0;
        e.mem[_t_1 + 1] = term_ctr(CID________________BENDVY_SRC_ECS_WORLD_WORLD, _nd_1);
        return term_tsk(FID_CLO_APPLY, _t_1);
      }
      r0 = _f_0;
      r1 = term_ctr(CID________________BENDVY_SRC_ECS_WORLD_WORLD, _nd_1);
      WL_JMP(FID_CLO_APPLY);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_TRANSACTION_ROLLBACK_0_K27)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    Term _fb_1[13];
    u64 _sp_1 = ctr_take(e, _h_0, 13, _fb_1);
    u32 _f_3 = _fb_1[0];
    u32 _f_4 = _fb_1[1];
    u32 _f_5 = _fb_1[2];
    Term _f_6 = _fb_1[3];
    u32 _f_7 = _fb_1[4];
    Term _f_8 = _fb_1[5];
    Term _f_9 = _fb_1[6];
    Term _f_10 = _fb_1[7];
    Term _f_11 = _fb_1[8];
    Term _f_12 = _fb_1[9];
    Term _f_13 = _fb_1[10];
    u32 _f_14 = _fb_1[11];
    u32 _f_15 = _fb_1[12];
    spare_free(e, cls_fit(13), _sp_1);
    Term _fb_2[12];
    u64 _sp_2 = ctr_take(e, _f_10, 12, _fb_2);
    Term _f_16 = _fb_2[0];
    u32 _f_17 = _fb_2[1];
    u32 _f_18 = _fb_2[2];
    u32 _f_19 = _fb_2[3];
    u32 _f_20 = _fb_2[4];
    u32 _f_21 = _fb_2[5];
    u32 _f_22 = _fb_2[6];
    u32 _f_23 = _fb_2[7];
    u32 _f_24 = _fb_2[8];
    u32 _f_25 = _fb_2[9];
    u32 _f_26 = _fb_2[10];
    u32 _f_27 = _fb_2[11];
    spare_free(e, cls_fit(12), _sp_2);
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_TRANSACTION_ROLLBACK_0)) {
      u64 _t_2 = task_node(e, FID________________BENDVY_SRC_ECS_TRANSACTION_ROLLBACK_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_2;
      e.mem[_t_2 + 1] = _f_3;
      e.mem[_t_2 + 2] = _f_4;
      e.mem[_t_2 + 3] = _f_5;
      e.mem[_t_2 + 4] = _f_6;
      e.mem[_t_2 + 5] = _f_7;
      e.mem[_t_2 + 6] = _f_8;
      e.mem[_t_2 + 7] = _f_9;
      e.mem[_t_2 + 8] = _f_16;
      e.mem[_t_2 + 9] = _f_17;
      e.mem[_t_2 + 10] = _f_18;
      e.mem[_t_2 + 11] = _f_19;
      e.mem[_t_2 + 12] = _f_20;
      e.mem[_t_2 + 13] = _f_21;
      e.mem[_t_2 + 14] = _f_22;
      e.mem[_t_2 + 15] = _f_23;
      e.mem[_t_2 + 16] = _f_24;
      e.mem[_t_2 + 17] = _f_25;
      e.mem[_t_2 + 18] = _f_26;
      e.mem[_t_2 + 19] = _f_27;
      e.mem[_t_2 + 20] = _f_11;
      e.mem[_t_2 + 21] = _f_12;
      e.mem[_t_2 + 22] = _f_13;
      e.mem[_t_2 + 23] = _f_14;
      e.mem[_t_2 + 24] = _f_15;
      return term_tsk(FID________________BENDVY_SRC_ECS_TRANSACTION_ROLLBACK_0, _t_2);
    }
    r0 = _f_2;
    r1 = _f_3;
    r2 = _f_4;
    r3 = _f_5;
    r4 = _f_6;
    r5 = _f_7;
    r6 = _f_8;
    r7 = _f_9;
    r8 = _f_16;
    r9 = _f_17;
    r10 = _f_18;
    r11 = _f_19;
    r12 = _f_20;
    r13 = _f_21;
    r14 = _f_22;
    r15 = _f_23;
    r16 = _f_24;
    r17 = _f_25;
    r18 = _f_26;
    r19 = _f_27;
    r20 = _f_11;
    r21 = _f_12;
    r22 = _f_13;
    r23 = _f_14;
    r24 = _f_15;
    WL_JMP(FID________________BENDVY_SRC_ECS_TRANSACTION_ROLLBACK_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_PUBLISH_0)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    u32 _world_2 = r2;
    Term _world_3 = r3;
    u32 _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    u32 _world_9 = r9;
    u32 _world_10 = r10;
    u32 _world_11 = r11;
    u32 _world_12 = r12;
    u32 _world_13 = r13;
    u32 _world_14 = r14;
    u32 _world_15 = r15;
    u32 _world_16 = r16;
    u32 _world_17 = r17;
    u32 _world_18 = r18;
    Term _world_19 = r19;
    Term _world_20 = r20;
    Term _world_21 = r21;
    u32 _world_22 = r22;
    u32 _world_23 = r23;
    Term _events_0 = r24;
    WL_OPEN
    if (seq) {
      WL_ROOM(24);
      STK(0) = _world_0;
      STK(1) = _world_1;
      STK(2) = _world_2;
      STK(3) = _world_3;
      STK(4) = _world_4;
      STK(5) = _world_5;
      STK(6) = _world_6;
      STK(7) = _world_7;
      STK(8) = _world_8;
      STK(9) = _world_9;
      STK(10) = _world_10;
      STK(11) = _world_11;
      STK(12) = _world_12;
      STK(13) = _world_13;
      STK(14) = _world_14;
      STK(15) = _world_15;
      STK(16) = _world_16;
      STK(17) = _world_17;
      STK(18) = _world_18;
      STK(19) = _world_20;
      STK(20) = _world_21;
      STK(21) = _world_22;
      STK(22) = _world_23;
      STK(23) = FID_CONSUMER_EXPANDED_PUBLISH_0_K29;
      WL_PUSHN(24);
    } else {
      u64 _t_0 = task_node(e, FID_CONSUMER_EXPANDED_PUBLISH_0_K29, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _world_0;
      e.mem[_t_0 + 1] = _world_1;
      e.mem[_t_0 + 2] = _world_2;
      e.mem[_t_0 + 3] = _world_3;
      e.mem[_t_0 + 4] = _world_4;
      e.mem[_t_0 + 5] = _world_5;
      e.mem[_t_0 + 6] = _world_6;
      e.mem[_t_0 + 7] = _world_7;
      e.mem[_t_0 + 8] = _world_8;
      e.mem[_t_0 + 9] = _world_9;
      e.mem[_t_0 + 10] = _world_10;
      e.mem[_t_0 + 11] = _world_11;
      e.mem[_t_0 + 12] = _world_12;
      e.mem[_t_0 + 13] = _world_13;
      e.mem[_t_0 + 14] = _world_14;
      e.mem[_t_0 + 15] = _world_15;
      e.mem[_t_0 + 16] = _world_16;
      e.mem[_t_0 + 17] = _world_17;
      e.mem[_t_0 + 18] = _world_18;
      e.mem[_t_0 + 19] = _world_20;
      e.mem[_t_0 + 20] = _world_21;
      e.mem[_t_0 + 21] = _world_22;
      e.mem[_t_0 + 22] = _world_23;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_PUBLISH_0_K29, _t_0);
      WL_IDX = 23;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_1 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_19;
      e.mem[_t_1 + 1] = _events_0;
      return term_tsk(FID_LIST_APPEND, _t_1);
    }
    r0 = _world_19;
    r1 = _events_0;
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_PUBLISH_0_K29)
  {
    WL_POPN(23);
    u32 _world_24 = STK(0);
    u32 _world_25 = STK(1);
    u32 _world_26 = STK(2);
    Term _world_27 = STK(3);
    u32 _world_28 = STK(4);
    Term _world_29 = STK(5);
    Term _world_30 = STK(6);
    Term _world_31 = STK(7);
    u32 _world_32 = STK(8);
    u32 _world_33 = STK(9);
    u32 _world_34 = STK(10);
    u32 _world_35 = STK(11);
    u32 _world_36 = STK(12);
    u32 _world_37 = STK(13);
    u32 _world_38 = STK(14);
    u32 _world_39 = STK(15);
    u32 _world_40 = STK(16);
    u32 _world_41 = STK(17);
    u32 _world_42 = STK(18);
    Term _world_43 = STK(19);
    Term _world_44 = STK(20);
    u32 _world_45 = STK(21);
    u32 _world_46 = STK(22);
    Term _h_0 = r0;
    WL_OPEN
    r0 = _world_24;
    r1 = _world_25;
    r2 = _world_26;
    r3 = _world_27;
    r4 = _world_28;
    r5 = _world_29;
    r6 = _world_30;
    r7 = _world_31;
    r8 = _world_32;
    r9 = _world_33;
    r10 = _world_34;
    r11 = _world_35;
    r12 = _world_36;
    r13 = _world_37;
    r14 = _world_38;
    r15 = _world_39;
    r16 = _world_40;
    r17 = _world_41;
    r18 = _world_42;
    r19 = _h_0;
    r20 = _world_43;
    r21 = _world_44;
    r22 = _world_45;
    r23 = _world_46;
    WL_RETN(24);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_MACHINE_RESET_TAKEN_0_C35)
  {
    u32 _pair_35 = r0;
    u32 _pair_36 = r1;
    u32 _pair_37 = r2;
    u32 _pair_38 = r3;
    u32 _pair_39 = r4;
    u32 _pair_40 = r5;
    u32 _pair_41 = r6;
    u32 _pair_42 = r7;
    u32 _pair_43 = r8;
    u32 _pair_44 = r9;
    u32 _pair_45 = r10;
    Term _x_0 = r11;
    WL_OPEN
    Term _fb_0[13];
    u64 _sp_0 = ctr_take(e, _x_0, 13, _fb_0);
    u32 _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    u32 _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    u32 _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    Term _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    Term _f_8 = _fb_0[8];
    Term _f_9 = _fb_0[9];
    Term _f_10 = _fb_0[10];
    u32 _f_11 = _fb_0[11];
    u32 _f_12 = _fb_0[12];
    spare_free(e, cls_fit(13), _sp_0);
    Term _fb_1[12];
    u64 _sp_1 = ctr_take(e, _f_7, 12, _fb_1);
    Term _f_13 = _fb_1[0];
    u32 _f_14 = _fb_1[1];
    u32 _f_15 = _fb_1[2];
    u32 _f_16 = _fb_1[3];
    u32 _f_17 = _fb_1[4];
    u32 _f_18 = _fb_1[5];
    u32 _f_19 = _fb_1[6];
    u32 _f_20 = _fb_1[7];
    u32 _f_21 = _fb_1[8];
    u32 _f_22 = _fb_1[9];
    u32 _f_23 = _fb_1[10];
    u32 _f_24 = _fb_1[11];
    spare_free(e, cls_fit(12), _sp_1);
    u32 _v_264 = 0;
    u32 _v_265 = 0;
    u32 _v_266 = 0;
    Term _v_267 = 0;
    u32 _v_268 = 0;
    Term _v_269 = 0;
    Term _v_270 = 0;
    Term _v_271 = 0;
    u32 _v_272 = 0;
    u32 _v_273 = 0;
    u32 _v_274 = 0;
    u32 _v_275 = 0;
    u32 _v_276 = 0;
    u32 _v_277 = 0;
    u32 _v_278 = 0;
    u32 _v_279 = 0;
    u32 _v_280 = 0;
    u32 _v_281 = 0;
    u32 _v_282 = 0;
    Term _v_283 = 0;
    Term _v_284 = 0;
    Term _v_285 = 0;
    u32 _v_286 = 0;
    u32 _v_287 = 0;
    Term _o_4[24];
    if (spin_14(e, _o_4, _f_0, _f_1, _f_2, _f_3, blk_loc(e.mem, _f_3), _f_4, _f_5, _f_6, blk_loc(e.mem, _f_6), _f_13, blk_loc(e.mem, _f_13), _f_14, _f_15, _f_16, _f_17, _f_18, _f_19, _f_20, _f_21, _f_22, _f_23, _f_24, _f_8, blk_loc(e.mem, _f_8), _f_9, blk_loc(e.mem, _f_9), _f_10, blk_loc(e.mem, _f_10), _f_11, _f_12, _pair_35, _pair_36, _pair_37, _pair_38, _pair_39, _pair_40, _pair_41, _pair_42, _pair_43, _pair_44, _pair_45) == 0) {
      return 0;
    }
    _v_264 = _o_4[0];
    _v_265 = _o_4[1];
    _v_266 = _o_4[2];
    _v_267 = _o_4[3];
    _v_268 = _o_4[4];
    _v_269 = _o_4[5];
    _v_270 = _o_4[6];
    _v_271 = _o_4[7];
    _v_272 = _o_4[8];
    _v_273 = _o_4[9];
    _v_274 = _o_4[10];
    _v_275 = _o_4[11];
    _v_276 = _o_4[12];
    _v_277 = _o_4[13];
    _v_278 = _o_4[14];
    _v_279 = _o_4[15];
    _v_280 = _o_4[16];
    _v_281 = _o_4[17];
    _v_282 = _o_4[18];
    _v_283 = _o_4[19];
    _v_284 = _o_4[20];
    _v_285 = _o_4[21];
    _v_286 = _o_4[22];
    _v_287 = _o_4[23];
    u64 _nd_1 = heap_alloc(e, cls_fit(12));
    e.mem[_nd_1 + 0] = rfc_seal(e, _v_271);
    e.mem[_nd_1 + 1] = rfc_seal(e, _v_272);
    e.mem[_nd_1 + 2] = rfc_seal(e, _v_273);
    e.mem[_nd_1 + 3] = rfc_seal(e, _v_274);
    e.mem[_nd_1 + 4] = rfc_seal(e, _v_275);
    e.mem[_nd_1 + 5] = rfc_seal(e, _v_276);
    e.mem[_nd_1 + 6] = rfc_seal(e, _v_277);
    e.mem[_nd_1 + 7] = rfc_seal(e, _v_278);
    e.mem[_nd_1 + 8] = rfc_seal(e, _v_279);
    e.mem[_nd_1 + 9] = rfc_seal(e, _v_280);
    e.mem[_nd_1 + 10] = rfc_seal(e, _v_281);
    e.mem[_nd_1 + 11] = rfc_seal(e, _v_282);
    u64 _nd_2 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_2 + 0] = rfc_seal(e, _v_264);
    e.mem[_nd_2 + 1] = rfc_seal(e, _v_265);
    e.mem[_nd_2 + 2] = rfc_seal(e, _v_266);
    e.mem[_nd_2 + 3] = rfc_seal(e, _v_267);
    e.mem[_nd_2 + 4] = rfc_seal(e, _v_268);
    e.mem[_nd_2 + 5] = rfc_seal(e, _v_269);
    e.mem[_nd_2 + 6] = rfc_seal(e, _v_270);
    e.mem[_nd_2 + 7] = rfc_seal(e, term_ctr(CID_CONSUMER_EXPANDED_RESOURCES, _nd_1));
    e.mem[_nd_2 + 8] = rfc_seal(e, _v_283);
    e.mem[_nd_2 + 9] = rfc_seal(e, _v_284);
    e.mem[_nd_2 + 10] = rfc_seal(e, _v_285);
    e.mem[_nd_2 + 11] = rfc_seal(e, _v_286);
    e.mem[_nd_2 + 12] = rfc_seal(e, _v_287);
    r0 = term_ctr(CID________________BENDVY_SRC_ECS_WORLD_WORLD, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_QUEUE_WRITE_TAKEN_0_C37)
  {
    u32 _pair_35 = r0;
    u32 _pair_36 = r1;
    u32 _pair_37 = r2;
    u32 _pair_38 = r3;
    u32 _pair_39 = r4;
    u32 _pair_40 = r5;
    u32 _pair_41 = r6;
    u32 _pair_42 = r7;
    u32 _pair_43 = r8;
    u32 _pair_44 = r9;
    u32 _pair_45 = r10;
    Term _x_0 = r11;
    WL_OPEN
    Term _fb_0[13];
    u64 _sp_0 = ctr_take(e, _x_0, 13, _fb_0);
    u32 _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    u32 _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    u32 _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    Term _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    Term _f_8 = _fb_0[8];
    Term _f_9 = _fb_0[9];
    Term _f_10 = _fb_0[10];
    u32 _f_11 = _fb_0[11];
    u32 _f_12 = _fb_0[12];
    spare_free(e, cls_fit(13), _sp_0);
    Term _fb_1[12];
    u64 _sp_1 = ctr_take(e, _f_7, 12, _fb_1);
    Term _f_13 = _fb_1[0];
    u32 _f_14 = _fb_1[1];
    u32 _f_15 = _fb_1[2];
    u32 _f_16 = _fb_1[3];
    u32 _f_17 = _fb_1[4];
    u32 _f_18 = _fb_1[5];
    u32 _f_19 = _fb_1[6];
    u32 _f_20 = _fb_1[7];
    u32 _f_21 = _fb_1[8];
    u32 _f_22 = _fb_1[9];
    u32 _f_23 = _fb_1[10];
    u32 _f_24 = _fb_1[11];
    spare_free(e, cls_fit(12), _sp_1);
    u32 _v_194 = 0;
    u32 _v_195 = 0;
    u32 _v_196 = 0;
    Term _v_197 = 0;
    u32 _v_198 = 0;
    Term _v_199 = 0;
    Term _v_200 = 0;
    Term _v_201 = 0;
    u32 _v_202 = 0;
    u32 _v_203 = 0;
    u32 _v_204 = 0;
    u32 _v_205 = 0;
    u32 _v_206 = 0;
    u32 _v_207 = 0;
    u32 _v_208 = 0;
    u32 _v_209 = 0;
    u32 _v_210 = 0;
    u32 _v_211 = 0;
    u32 _v_212 = 0;
    Term _v_213 = 0;
    Term _v_214 = 0;
    Term _v_215 = 0;
    u32 _v_216 = 0;
    u32 _v_217 = 0;
    Term _o_3[24];
    if (spin_14(e, _o_3, _f_0, _f_1, _f_2, _f_3, blk_loc(e.mem, _f_3), _f_4, _f_5, _f_6, blk_loc(e.mem, _f_6), _f_13, blk_loc(e.mem, _f_13), _f_14, _f_15, _f_16, _f_17, _f_18, _f_19, _f_20, _f_21, _f_22, _f_23, _f_24, _f_8, blk_loc(e.mem, _f_8), _f_9, blk_loc(e.mem, _f_9), _f_10, blk_loc(e.mem, _f_10), _f_11, _f_12, _pair_35, _pair_36, _pair_37, _pair_38, _pair_39, _pair_40, _pair_41, _pair_42, _pair_43, _pair_44, _pair_45) == 0) {
      return 0;
    }
    _v_194 = _o_3[0];
    _v_195 = _o_3[1];
    _v_196 = _o_3[2];
    _v_197 = _o_3[3];
    _v_198 = _o_3[4];
    _v_199 = _o_3[5];
    _v_200 = _o_3[6];
    _v_201 = _o_3[7];
    _v_202 = _o_3[8];
    _v_203 = _o_3[9];
    _v_204 = _o_3[10];
    _v_205 = _o_3[11];
    _v_206 = _o_3[12];
    _v_207 = _o_3[13];
    _v_208 = _o_3[14];
    _v_209 = _o_3[15];
    _v_210 = _o_3[16];
    _v_211 = _o_3[17];
    _v_212 = _o_3[18];
    _v_213 = _o_3[19];
    _v_214 = _o_3[20];
    _v_215 = _o_3[21];
    _v_216 = _o_3[22];
    _v_217 = _o_3[23];
    u64 _nd_1 = heap_alloc(e, cls_fit(12));
    e.mem[_nd_1 + 0] = rfc_seal(e, _v_201);
    e.mem[_nd_1 + 1] = rfc_seal(e, _v_202);
    e.mem[_nd_1 + 2] = rfc_seal(e, _v_203);
    e.mem[_nd_1 + 3] = rfc_seal(e, _v_204);
    e.mem[_nd_1 + 4] = rfc_seal(e, _v_205);
    e.mem[_nd_1 + 5] = rfc_seal(e, _v_206);
    e.mem[_nd_1 + 6] = rfc_seal(e, _v_207);
    e.mem[_nd_1 + 7] = rfc_seal(e, _v_208);
    e.mem[_nd_1 + 8] = rfc_seal(e, _v_209);
    e.mem[_nd_1 + 9] = rfc_seal(e, _v_210);
    e.mem[_nd_1 + 10] = rfc_seal(e, _v_211);
    e.mem[_nd_1 + 11] = rfc_seal(e, _v_212);
    u64 _nd_2 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_2 + 0] = rfc_seal(e, _v_194);
    e.mem[_nd_2 + 1] = rfc_seal(e, _v_195);
    e.mem[_nd_2 + 2] = rfc_seal(e, _v_196);
    e.mem[_nd_2 + 3] = rfc_seal(e, _v_197);
    e.mem[_nd_2 + 4] = rfc_seal(e, _v_198);
    e.mem[_nd_2 + 5] = rfc_seal(e, _v_199);
    e.mem[_nd_2 + 6] = rfc_seal(e, _v_200);
    e.mem[_nd_2 + 7] = rfc_seal(e, term_ctr(CID_CONSUMER_EXPANDED_RESOURCES, _nd_1));
    e.mem[_nd_2 + 8] = rfc_seal(e, _v_213);
    e.mem[_nd_2 + 9] = rfc_seal(e, _v_214);
    e.mem[_nd_2 + 10] = rfc_seal(e, _v_215);
    e.mem[_nd_2 + 11] = rfc_seal(e, _v_216);
    e.mem[_nd_2 + 12] = rfc_seal(e, _v_217);
    r0 = term_ctr(CID________________BENDVY_SRC_ECS_WORLD_WORLD, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_TRANSACTION_FINISH_0)
  {
    u32 _tx_0 = r0;
    u32 _tx_1 = r1;
    u32 _tx_2 = r2;
    Term _tx_3 = r3;
    u32 _tx_4 = r4;
    Term _tx_5 = r5;
    Term _tx_6 = r6;
    Term _tx_7 = r7;
    u32 _tx_8 = r8;
    u32 _tx_9 = r9;
    u32 _tx_10 = r10;
    u32 _tx_11 = r11;
    u32 _tx_12 = r12;
    u32 _tx_13 = r13;
    u32 _tx_14 = r14;
    u32 _tx_15 = r15;
    u32 _tx_16 = r16;
    u32 _tx_17 = r17;
    u32 _tx_18 = r18;
    Term _tx_19 = r19;
    Term _tx_20 = r20;
    Term _tx_21 = r21;
    u32 _tx_22 = r22;
    u32 _tx_23 = r23;
    Term _tx_24 = r24;
    Term _tx_25 = r25;
    Term _tx_26 = r26;
    u32 _outcome_0 = r27;
    Term _outcome_1 = r28;
    WL_OPEN
    if (_outcome_0 == 0) {
      term_sink(e, _tx_24);
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      u32 _v_2 = 0;
      Term _v_3 = 0;
      u32 _v_4 = 0;
      Term _v_5 = 0;
      Term _v_6 = 0;
      Term _v_7 = 0;
      u32 _v_8 = 0;
      u32 _v_9 = 0;
      u32 _v_10 = 0;
      u32 _v_11 = 0;
      u32 _v_12 = 0;
      u32 _v_13 = 0;
      u32 _v_14 = 0;
      u32 _v_15 = 0;
      u32 _v_16 = 0;
      u32 _v_17 = 0;
      u32 _v_18 = 0;
      Term _v_19 = 0;
      Term _v_20 = 0;
      Term _v_21 = 0;
      u32 _v_22 = 0;
      u32 _v_23 = 0;
      Term _v_24 = 0;
      Term _v_25 = 0;
      Term _o_0[1];
      if (spin_24(e, _o_0, _tx_25, blk_loc(e.mem, _tx_25)) == 0) {
        return 0;
      }
      _v_25 = _o_0[0];
      _v_24 = _v_25;
      u32 _v_26 = 0;
      u32 _v_27 = 0;
      u32 _v_28 = 0;
      Term _v_29 = 0;
      u32 _v_30 = 0;
      Term _v_31 = 0;
      Term _v_32 = 0;
      Term _v_33 = 0;
      u32 _v_34 = 0;
      u32 _v_35 = 0;
      u32 _v_36 = 0;
      u32 _v_37 = 0;
      u32 _v_38 = 0;
      u32 _v_39 = 0;
      u32 _v_40 = 0;
      u32 _v_41 = 0;
      u32 _v_42 = 0;
      u32 _v_43 = 0;
      u32 _v_44 = 0;
      Term _v_45 = 0;
      Term _v_46 = 0;
      Term _v_47 = 0;
      u32 _v_48 = 0;
      u32 _v_49 = 0;
      Term _o_1[24];
      if (spin_25(e, _o_1, _tx_0, _tx_1, _tx_2, _tx_3, blk_loc(e.mem, _tx_3), _tx_4, _tx_5, _tx_6, blk_loc(e.mem, _tx_6), _tx_7, blk_loc(e.mem, _tx_7), _tx_8, _tx_9, _tx_10, _tx_11, _tx_12, _tx_13, _tx_14, _tx_15, _tx_16, _tx_17, _tx_18, _tx_19, blk_loc(e.mem, _tx_19), _tx_20, blk_loc(e.mem, _tx_20), _tx_21, blk_loc(e.mem, _tx_21), _tx_22, _tx_23, _v_24, blk_loc(e.mem, _v_24)) == 0) {
        return 0;
      }
      _v_26 = _o_1[0];
      _v_27 = _o_1[1];
      _v_28 = _o_1[2];
      _v_29 = _o_1[3];
      _v_30 = _o_1[4];
      _v_31 = _o_1[5];
      _v_32 = _o_1[6];
      _v_33 = _o_1[7];
      _v_34 = _o_1[8];
      _v_35 = _o_1[9];
      _v_36 = _o_1[10];
      _v_37 = _o_1[11];
      _v_38 = _o_1[12];
      _v_39 = _o_1[13];
      _v_40 = _o_1[14];
      _v_41 = _o_1[15];
      _v_42 = _o_1[16];
      _v_43 = _o_1[17];
      _v_44 = _o_1[18];
      _v_45 = _o_1[19];
      _v_46 = _o_1[20];
      _v_47 = _o_1[21];
      _v_48 = _o_1[22];
      _v_49 = _o_1[23];
      _v_0 = _v_26;
      _v_1 = _v_27;
      _v_2 = _v_28;
      _v_3 = _v_29;
      _v_4 = _v_30;
      _v_5 = _v_31;
      _v_6 = _v_32;
      _v_7 = _v_33;
      _v_8 = _v_34;
      _v_9 = _v_35;
      _v_10 = _v_36;
      _v_11 = _v_37;
      _v_12 = _v_38;
      _v_13 = _v_39;
      _v_14 = _v_40;
      _v_15 = _v_41;
      _v_16 = _v_42;
      _v_17 = _v_43;
      _v_18 = _v_44;
      _v_19 = _v_45;
      _v_20 = _v_46;
      _v_21 = _v_47;
      _v_22 = _v_48;
      _v_23 = _v_49;
      Term _v_50 = 0;
      Term _v_51 = 0;
      Term _o_2[1];
      if (spin_24(e, _o_2, _tx_26, blk_loc(e.mem, _tx_26)) == 0) {
        return 0;
      }
      _v_51 = _o_2[0];
      _v_50 = _v_51;
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID________________BENDVY_SRC_ECS_TRANSACTION_FINISH_0_K44;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_TRANSACTION_FINISH_0_K44, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_TRANSACTION_FINISH_0_K44, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_PUBLISH_0)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_EXPANDED_PUBLISH_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _v_0;
        e.mem[_t_1 + 1] = _v_1;
        e.mem[_t_1 + 2] = _v_2;
        e.mem[_t_1 + 3] = _v_3;
        e.mem[_t_1 + 4] = _v_4;
        e.mem[_t_1 + 5] = _v_5;
        e.mem[_t_1 + 6] = _v_6;
        e.mem[_t_1 + 7] = _v_7;
        e.mem[_t_1 + 8] = _v_8;
        e.mem[_t_1 + 9] = _v_9;
        e.mem[_t_1 + 10] = _v_10;
        e.mem[_t_1 + 11] = _v_11;
        e.mem[_t_1 + 12] = _v_12;
        e.mem[_t_1 + 13] = _v_13;
        e.mem[_t_1 + 14] = _v_14;
        e.mem[_t_1 + 15] = _v_15;
        e.mem[_t_1 + 16] = _v_16;
        e.mem[_t_1 + 17] = _v_17;
        e.mem[_t_1 + 18] = _v_18;
        e.mem[_t_1 + 19] = _v_19;
        e.mem[_t_1 + 20] = _v_20;
        e.mem[_t_1 + 21] = _v_21;
        e.mem[_t_1 + 22] = _v_22;
        e.mem[_t_1 + 23] = _v_23;
        e.mem[_t_1 + 24] = _v_50;
        return term_tsk(FID_CONSUMER_EXPANDED_PUBLISH_0, _t_1);
      }
      r0 = _v_0;
      r1 = _v_1;
      r2 = _v_2;
      r3 = _v_3;
      r4 = _v_4;
      r5 = _v_5;
      r6 = _v_6;
      r7 = _v_7;
      r8 = _v_8;
      r9 = _v_9;
      r10 = _v_10;
      r11 = _v_11;
      r12 = _v_12;
      r13 = _v_13;
      r14 = _v_14;
      r15 = _v_15;
      r16 = _v_16;
      r17 = _v_17;
      r18 = _v_18;
      r19 = _v_19;
      r20 = _v_20;
      r21 = _v_21;
      r22 = _v_22;
      r23 = _v_23;
      r24 = _v_50;
      WL_JMP(FID_CONSUMER_EXPANDED_PUBLISH_0);
    } else {
      term_sink(e, _tx_25);
      term_sink(e, _tx_26);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _outcome_1;
        STK(1) = FID________________BENDVY_SRC_ECS_TRANSACTION_FINISH_0_K45;
        WL_PUSHN(2);
      } else {
        u64 _t_2 = task_node(e, FID________________BENDVY_SRC_ECS_TRANSACTION_FINISH_0_K45, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _outcome_1;
        WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_TRANSACTION_FINISH_0_K45, _t_2);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_TRANSACTION_ROLLBACK_0)) {
        u64 _t_3 = task_node(e, FID________________BENDVY_SRC_ECS_TRANSACTION_ROLLBACK_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _tx_24;
        e.mem[_t_3 + 1] = _tx_0;
        e.mem[_t_3 + 2] = _tx_1;
        e.mem[_t_3 + 3] = _tx_2;
        e.mem[_t_3 + 4] = _tx_3;
        e.mem[_t_3 + 5] = _tx_4;
        e.mem[_t_3 + 6] = _tx_5;
        e.mem[_t_3 + 7] = _tx_6;
        e.mem[_t_3 + 8] = _tx_7;
        e.mem[_t_3 + 9] = _tx_8;
        e.mem[_t_3 + 10] = _tx_9;
        e.mem[_t_3 + 11] = _tx_10;
        e.mem[_t_3 + 12] = _tx_11;
        e.mem[_t_3 + 13] = _tx_12;
        e.mem[_t_3 + 14] = _tx_13;
        e.mem[_t_3 + 15] = _tx_14;
        e.mem[_t_3 + 16] = _tx_15;
        e.mem[_t_3 + 17] = _tx_16;
        e.mem[_t_3 + 18] = _tx_17;
        e.mem[_t_3 + 19] = _tx_18;
        e.mem[_t_3 + 20] = _tx_19;
        e.mem[_t_3 + 21] = _tx_20;
        e.mem[_t_3 + 22] = _tx_21;
        e.mem[_t_3 + 23] = _tx_22;
        e.mem[_t_3 + 24] = _tx_23;
        return term_tsk(FID________________BENDVY_SRC_ECS_TRANSACTION_ROLLBACK_0, _t_3);
      }
      r0 = _tx_24;
      r1 = _tx_0;
      r2 = _tx_1;
      r3 = _tx_2;
      r4 = _tx_3;
      r5 = _tx_4;
      r6 = _tx_5;
      r7 = _tx_6;
      r8 = _tx_7;
      r9 = _tx_8;
      r10 = _tx_9;
      r11 = _tx_10;
      r12 = _tx_11;
      r13 = _tx_12;
      r14 = _tx_13;
      r15 = _tx_14;
      r16 = _tx_15;
      r17 = _tx_16;
      r18 = _tx_17;
      r19 = _tx_18;
      r20 = _tx_19;
      r21 = _tx_20;
      r22 = _tx_21;
      r23 = _tx_22;
      r24 = _tx_23;
      WL_JMP(FID________________BENDVY_SRC_ECS_TRANSACTION_ROLLBACK_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_TRANSACTION_FINISH_0_K44)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    u32 _h_12 = r12;
    u32 _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    Term _h_19 = r19;
    Term _h_20 = r20;
    Term _h_21 = r21;
    u32 _h_22 = r22;
    u32 _h_23 = r23;
    WL_OPEN
    r0 = _h_0;
    r1 = _h_1;
    r2 = _h_2;
    r3 = _h_3;
    r4 = _h_4;
    r5 = _h_5;
    r6 = _h_6;
    r7 = _h_7;
    r8 = _h_8;
    r9 = _h_9;
    r10 = _h_10;
    r11 = _h_11;
    r12 = _h_12;
    r13 = _h_13;
    r14 = _h_14;
    r15 = _h_15;
    r16 = _h_16;
    r17 = _h_17;
    r18 = _h_18;
    r19 = _h_19;
    r20 = _h_20;
    r21 = _h_21;
    r22 = _h_22;
    r23 = _h_23;
    r24 = 0;
    r25 = 0;
    WL_RETN(26);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_TRANSACTION_FINISH_0_K45)
  {
    WL_POPN(1);
    Term _outcome_2 = STK(0);
    u32 _h_24 = r0;
    u32 _h_25 = r1;
    u32 _h_26 = r2;
    Term _h_27 = r3;
    u32 _h_28 = r4;
    Term _h_29 = r5;
    Term _h_30 = r6;
    Term _h_31 = r7;
    u32 _h_32 = r8;
    u32 _h_33 = r9;
    u32 _h_34 = r10;
    u32 _h_35 = r11;
    u32 _h_36 = r12;
    u32 _h_37 = r13;
    u32 _h_38 = r14;
    u32 _h_39 = r15;
    u32 _h_40 = r16;
    u32 _h_41 = r17;
    u32 _h_42 = r18;
    Term _h_43 = r19;
    Term _h_44 = r20;
    Term _h_45 = r21;
    u32 _h_46 = r22;
    u32 _h_47 = r23;
    WL_OPEN
    r0 = _h_24;
    r1 = _h_25;
    r2 = _h_26;
    r3 = _h_27;
    r4 = _h_28;
    r5 = _h_29;
    r6 = _h_30;
    r7 = _h_31;
    r8 = _h_32;
    r9 = _h_33;
    r10 = _h_34;
    r11 = _h_35;
    r12 = _h_36;
    r13 = _h_37;
    r14 = _h_38;
    r15 = _h_39;
    r16 = _h_40;
    r17 = _h_41;
    r18 = _h_42;
    r19 = _h_43;
    r20 = _h_44;
    r21 = _h_45;
    r22 = _h_46;
    r23 = _h_47;
    r24 = 1;
    r25 = _outcome_2;
    WL_RETN(26);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_META_MATCHES)
  {
    u32 _meta_0 = r0;
    Term _meta_1 = r1;
    Term _meta_2 = r2;
    u32 _id_0 = r3;
    Term _name_0 = r4;
    Term _access_0 = r5;
    WL_OPEN
    u32 _s_0 = U32_BIN(_meta_0, ==, _id_0);
    if (_s_0 == 0) {
      r0 = 0;
      WL_RETN(1);
    } else {
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      Term _o_0[1];
      if (spin_11(e, _o_0, _meta_1, blk_loc(e.mem, _meta_1), _name_0, blk_loc(e.mem, _name_0)) == 0) {
        return 0;
      }
      _v_1 = _o_0[0];
      _v_0 = _v_1;
      if (_v_0 == 0) {
        r0 = 0;
        WL_RETN(1);
      } else {
        if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_WORLD_ACCESS_EQUAL)) {
          u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_ACCESS_EQUAL, WL_CONT, WL_IDX, 0);
          e.mem[_t_0 + 0] = _meta_2;
          e.mem[_t_0 + 1] = _access_0;
          return term_tsk(FID________________BENDVY_SRC_ECS_WORLD_ACCESS_EQUAL, _t_0);
        }
        r0 = _meta_2;
        r1 = _access_0;
        WL_JMP(FID________________BENDVY_SRC_ECS_WORLD_ACCESS_EQUAL);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_WALK)
  {
    Term _registrations_0 = r0;
    u32 _id_0 = r1;
    Term _name_0 = r2;
    Term _access_0 = r3;
    u32 _found_0 = r4;
    WL_OPEN
    if (term_aux(_registrations_0) == CID_NIL) {
      if (_found_0 == 1) {
        r0 = 1;
        WL_RETN(1);
      } else {
        r0 = 0;
        WL_RETN(1);
      }
    } else {
      u64 _sp_0 = term_peek(e.mem, _registrations_0);
      Term _f_0 = e.mem[_sp_0 + 0];
      Term _f_1 = e.mem[_sp_0 + 1];
      u64 _sp_1 = term_peek(e.mem, _f_0);
      u32 _f_2 = e.mem[_sp_1 + 0];
      Term _f_3 = e.mem[_sp_1 + 1];
      Term _f_4 = e.mem[_sp_1 + 2];
      if (_found_0 == 1) {
        r0 = 1;
        WL_RETN(1);
      } else {
        if (seq) {
          WL_ROOM(5);
          STK(0) = _f_1;
          STK(1) = _id_0;
          STK(2) = _name_0;
          STK(3) = _access_0;
          STK(4) = FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_WALK_K55;
          WL_PUSHN(5);
        } else {
          u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_WALK_K55, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _f_1;
          e.mem[_t_0 + 1] = _id_0;
          e.mem[_t_0 + 2] = _name_0;
          e.mem[_t_0 + 3] = _access_0;
          WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_WALK_K55, _t_0);
          WL_IDX = 4;
        }
        if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_META_MATCHES)) {
          u64 _t_1 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_META_MATCHES, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _f_2;
          e.mem[_t_1 + 1] = _f_3;
          e.mem[_t_1 + 2] = _f_4;
          e.mem[_t_1 + 3] = _id_0;
          e.mem[_t_1 + 4] = _name_0;
          e.mem[_t_1 + 5] = _access_0;
          return term_tsk(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_META_MATCHES, _t_1);
        }
        r0 = _f_2;
        r1 = _f_3;
        r2 = _f_4;
        r3 = _id_0;
        r4 = _name_0;
        r5 = _access_0;
        WL_JMP(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_META_MATCHES);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_WALK_K55)
  {
    WL_POPN(4);
    Term _f_5 = STK(0);
    u32 _id_1 = STK(1);
    Term _name_1 = STK(2);
    Term _access_1 = STK(3);
    u32 _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_WALK)) {
      u64 _t_2 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_WALK, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_5;
      e.mem[_t_2 + 1] = _id_1;
      e.mem[_t_2 + 2] = _name_1;
      e.mem[_t_2 + 3] = _access_1;
      e.mem[_t_2 + 4] = _h_0;
      return term_tsk(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_WALK, _t_2);
    }
    r0 = _f_5;
    r1 = _id_1;
    r2 = _name_1;
    r3 = _access_1;
    r4 = _h_0;
    WL_JMP(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_WALK);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_RUNNER_0)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    u32 _world_2 = r2;
    Term _world_3 = r3;
    u32 _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    u32 _world_9 = r9;
    u32 _world_10 = r10;
    u32 _world_11 = r11;
    u32 _world_12 = r12;
    u32 _world_13 = r13;
    u32 _world_14 = r14;
    u32 _world_15 = r15;
    u32 _world_16 = r16;
    u32 _world_17 = r17;
    u32 _world_18 = r18;
    Term _world_19 = r19;
    Term _world_20 = r20;
    Term _world_21 = r21;
    u32 _world_22 = r22;
    u32 _world_23 = r23;
    u32 _request_0 = r24;
    u32 _request_1 = r25;
    u32 _request_2 = r26;
    u32 _request_3 = r27;
    u32 _request_4 = r28;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    Term _v_26 = 0;
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    Term _v_30 = 0;
    u32 _v_31 = 0;
    Term _v_32 = 0;
    Term _v_33 = 0;
    Term _v_34 = 0;
    u32 _v_35 = 0;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    u32 _v_38 = 0;
    u32 _v_39 = 0;
    u32 _v_40 = 0;
    u32 _v_41 = 0;
    u32 _v_42 = 0;
    u32 _v_43 = 0;
    u32 _v_44 = 0;
    u32 _v_45 = 0;
    Term _v_46 = 0;
    Term _v_47 = 0;
    Term _v_48 = 0;
    u32 _v_49 = 0;
    u32 _v_50 = 0;
    Term _v_51 = 0;
    Term _v_52 = 0;
    Term _v_53 = 0;
    u32 _v_54 = 0;
    u32 _v_55 = 0;
    u32 _v_56 = 0;
    Term _v_57 = 0;
    u32 _v_58 = 0;
    Term _v_59 = 0;
    Term _v_60 = 0;
    Term _v_61 = 0;
    u32 _v_62 = 0;
    u32 _v_63 = 0;
    u32 _v_64 = 0;
    u32 _v_65 = 0;
    u32 _v_66 = 0;
    u32 _v_67 = 0;
    u32 _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    Term _v_73 = 0;
    Term _v_74 = 0;
    Term _v_75 = 0;
    u32 _v_76 = 0;
    u32 _v_77 = 0;
    Term _v_78 = 0;
    Term _v_79 = 0;
    Term _v_80 = 0;
    Term _o_0[27];
    if (spin_30(e, _o_0, _world_0, _world_1, _world_2, _world_3, blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, blk_loc(e.mem, _world_6), _world_7, blk_loc(e.mem, _world_7), _world_8, _world_9, _world_10, _world_11, _world_12, _world_13, _world_14, _world_15, _world_16, _world_17, _world_18, _world_19, blk_loc(e.mem, _world_19), _world_20, blk_loc(e.mem, _world_20), _world_21, blk_loc(e.mem, _world_21), _world_22, _world_23) == 0) {
      return 0;
    }
    _v_54 = _o_0[0];
    _v_55 = _o_0[1];
    _v_56 = _o_0[2];
    _v_57 = _o_0[3];
    _v_58 = _o_0[4];
    _v_59 = _o_0[5];
    _v_60 = _o_0[6];
    _v_61 = _o_0[7];
    _v_62 = _o_0[8];
    _v_63 = _o_0[9];
    _v_64 = _o_0[10];
    _v_65 = _o_0[11];
    _v_66 = _o_0[12];
    _v_67 = _o_0[13];
    _v_68 = _o_0[14];
    _v_69 = _o_0[15];
    _v_70 = _o_0[16];
    _v_71 = _o_0[17];
    _v_72 = _o_0[18];
    _v_73 = _o_0[19];
    _v_74 = _o_0[20];
    _v_75 = _o_0[21];
    _v_76 = _o_0[22];
    _v_77 = _o_0[23];
    _v_78 = _o_0[24];
    _v_79 = _o_0[25];
    _v_80 = _o_0[26];
    _v_27 = _v_54;
    _v_28 = _v_55;
    _v_29 = _v_56;
    _v_30 = _v_57;
    _v_31 = _v_58;
    _v_32 = _v_59;
    _v_33 = _v_60;
    _v_34 = _v_61;
    _v_35 = _v_62;
    _v_36 = _v_63;
    _v_37 = _v_64;
    _v_38 = _v_65;
    _v_39 = _v_66;
    _v_40 = _v_67;
    _v_41 = _v_68;
    _v_42 = _v_69;
    _v_43 = _v_70;
    _v_44 = _v_71;
    _v_45 = _v_72;
    _v_46 = _v_73;
    _v_47 = _v_74;
    _v_48 = _v_75;
    _v_49 = _v_76;
    _v_50 = _v_77;
    _v_51 = _v_78;
    _v_52 = _v_79;
    _v_53 = _v_80;
    u32 _v_108 = 0;
    u32 _v_109 = 0;
    u32 _v_110 = 0;
    Term _v_111 = 0;
    u32 _v_112 = 0;
    Term _v_113 = 0;
    Term _v_114 = 0;
    Term _v_115 = 0;
    u32 _v_116 = 0;
    u32 _v_117 = 0;
    u32 _v_118 = 0;
    u32 _v_119 = 0;
    u32 _v_120 = 0;
    u32 _v_121 = 0;
    u32 _v_122 = 0;
    u32 _v_123 = 0;
    u32 _v_124 = 0;
    u32 _v_125 = 0;
    u32 _v_126 = 0;
    Term _v_127 = 0;
    Term _v_128 = 0;
    Term _v_129 = 0;
    u32 _v_130 = 0;
    u32 _v_131 = 0;
    Term _v_132 = 0;
    Term _v_133 = 0;
    Term _v_134 = 0;
    Term _o_2[27];
    Term _a_0 = term_ctr(CID_SCON, STAT_OFF + 6);
    if (spin_31(e, _o_2, _a_0, blk_loc(e.mem, _a_0), _v_27, _v_28, _v_29, _v_30, blk_loc(e.mem, _v_30), _v_31, _v_32, _v_33, blk_loc(e.mem, _v_33), _v_34, blk_loc(e.mem, _v_34), _v_35, _v_36, _v_37, _v_38, _v_39, _v_40, _v_41, _v_42, _v_43, _v_44, _v_45, _v_46, blk_loc(e.mem, _v_46), _v_47, blk_loc(e.mem, _v_47), _v_48, blk_loc(e.mem, _v_48), _v_49, _v_50, _v_51, blk_loc(e.mem, _v_51), _v_52, blk_loc(e.mem, _v_52), _v_53, blk_loc(e.mem, _v_53), _request_0, _request_1, _request_2, _request_3) == 0) {
      return 0;
    }
    _v_108 = _o_2[0];
    _v_109 = _o_2[1];
    _v_110 = _o_2[2];
    _v_111 = _o_2[3];
    _v_112 = _o_2[4];
    _v_113 = _o_2[5];
    _v_114 = _o_2[6];
    _v_115 = _o_2[7];
    _v_116 = _o_2[8];
    _v_117 = _o_2[9];
    _v_118 = _o_2[10];
    _v_119 = _o_2[11];
    _v_120 = _o_2[12];
    _v_121 = _o_2[13];
    _v_122 = _o_2[14];
    _v_123 = _o_2[15];
    _v_124 = _o_2[16];
    _v_125 = _o_2[17];
    _v_126 = _o_2[18];
    _v_127 = _o_2[19];
    _v_128 = _o_2[20];
    _v_129 = _o_2[21];
    _v_130 = _o_2[22];
    _v_131 = _o_2[23];
    _v_132 = _o_2[24];
    _v_133 = _o_2[25];
    _v_134 = _o_2[26];
    _v_0 = _v_108;
    _v_1 = _v_109;
    _v_2 = _v_110;
    _v_3 = _v_111;
    _v_4 = _v_112;
    _v_5 = _v_113;
    _v_6 = _v_114;
    _v_7 = _v_115;
    _v_8 = _v_116;
    _v_9 = _v_117;
    _v_10 = _v_118;
    _v_11 = _v_119;
    _v_12 = _v_120;
    _v_13 = _v_121;
    _v_14 = _v_122;
    _v_15 = _v_123;
    _v_16 = _v_124;
    _v_17 = _v_125;
    _v_18 = _v_126;
    _v_19 = _v_127;
    _v_20 = _v_128;
    _v_21 = _v_129;
    _v_22 = _v_130;
    _v_23 = _v_131;
    _v_24 = _v_132;
    _v_25 = _v_133;
    _v_26 = _v_134;
    if (_request_4 == 0) {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_CONSUMER_EXPANDED_RUNNER_0_K57;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_CONSUMER_EXPANDED_RUNNER_0_K57, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_RUNNER_0_K57, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_TRANSACTION_FINISH_0)) {
        u64 _t_1 = task_node(e, FID________________BENDVY_SRC_ECS_TRANSACTION_FINISH_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _v_0;
        e.mem[_t_1 + 1] = _v_1;
        e.mem[_t_1 + 2] = _v_2;
        e.mem[_t_1 + 3] = _v_3;
        e.mem[_t_1 + 4] = _v_4;
        e.mem[_t_1 + 5] = _v_5;
        e.mem[_t_1 + 6] = _v_6;
        e.mem[_t_1 + 7] = _v_7;
        e.mem[_t_1 + 8] = _v_8;
        e.mem[_t_1 + 9] = _v_9;
        e.mem[_t_1 + 10] = _v_10;
        e.mem[_t_1 + 11] = _v_11;
        e.mem[_t_1 + 12] = _v_12;
        e.mem[_t_1 + 13] = _v_13;
        e.mem[_t_1 + 14] = _v_14;
        e.mem[_t_1 + 15] = _v_15;
        e.mem[_t_1 + 16] = _v_16;
        e.mem[_t_1 + 17] = _v_17;
        e.mem[_t_1 + 18] = _v_18;
        e.mem[_t_1 + 19] = _v_19;
        e.mem[_t_1 + 20] = _v_20;
        e.mem[_t_1 + 21] = _v_21;
        e.mem[_t_1 + 22] = _v_22;
        e.mem[_t_1 + 23] = _v_23;
        e.mem[_t_1 + 24] = _v_24;
        e.mem[_t_1 + 25] = _v_25;
        e.mem[_t_1 + 26] = _v_26;
        e.mem[_t_1 + 27] = 0;
        e.mem[_t_1 + 28] = 0;
        return term_tsk(FID________________BENDVY_SRC_ECS_TRANSACTION_FINISH_0, _t_1);
      }
      r0 = _v_0;
      r1 = _v_1;
      r2 = _v_2;
      r3 = _v_3;
      r4 = _v_4;
      r5 = _v_5;
      r6 = _v_6;
      r7 = _v_7;
      r8 = _v_8;
      r9 = _v_9;
      r10 = _v_10;
      r11 = _v_11;
      r12 = _v_12;
      r13 = _v_13;
      r14 = _v_14;
      r15 = _v_15;
      r16 = _v_16;
      r17 = _v_17;
      r18 = _v_18;
      r19 = _v_19;
      r20 = _v_20;
      r21 = _v_21;
      r22 = _v_22;
      r23 = _v_23;
      r24 = _v_24;
      r25 = _v_25;
      r26 = _v_26;
      r27 = 0;
      r28 = 0;
      WL_JMP(FID________________BENDVY_SRC_ECS_TRANSACTION_FINISH_0);
    } else {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_CONSUMER_EXPANDED_RUNNER_0_K58;
        WL_PUSHN(1);
      } else {
        u64 _t_2 = task_node(e, FID_CONSUMER_EXPANDED_RUNNER_0_K58, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_RUNNER_0_K58, _t_2);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_TRANSACTION_FINISH_0)) {
        u64 _t_3 = task_node(e, FID________________BENDVY_SRC_ECS_TRANSACTION_FINISH_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _v_0;
        e.mem[_t_3 + 1] = _v_1;
        e.mem[_t_3 + 2] = _v_2;
        e.mem[_t_3 + 3] = _v_3;
        e.mem[_t_3 + 4] = _v_4;
        e.mem[_t_3 + 5] = _v_5;
        e.mem[_t_3 + 6] = _v_6;
        e.mem[_t_3 + 7] = _v_7;
        e.mem[_t_3 + 8] = _v_8;
        e.mem[_t_3 + 9] = _v_9;
        e.mem[_t_3 + 10] = _v_10;
        e.mem[_t_3 + 11] = _v_11;
        e.mem[_t_3 + 12] = _v_12;
        e.mem[_t_3 + 13] = _v_13;
        e.mem[_t_3 + 14] = _v_14;
        e.mem[_t_3 + 15] = _v_15;
        e.mem[_t_3 + 16] = _v_16;
        e.mem[_t_3 + 17] = _v_17;
        e.mem[_t_3 + 18] = _v_18;
        e.mem[_t_3 + 19] = _v_19;
        e.mem[_t_3 + 20] = _v_20;
        e.mem[_t_3 + 21] = _v_21;
        e.mem[_t_3 + 22] = _v_22;
        e.mem[_t_3 + 23] = _v_23;
        e.mem[_t_3 + 24] = _v_24;
        e.mem[_t_3 + 25] = _v_25;
        e.mem[_t_3 + 26] = _v_26;
        e.mem[_t_3 + 27] = 1;
        e.mem[_t_3 + 28] = term_ctr(CID_SCON, STAT_OFF + 22);
        return term_tsk(FID________________BENDVY_SRC_ECS_TRANSACTION_FINISH_0, _t_3);
      }
      r0 = _v_0;
      r1 = _v_1;
      r2 = _v_2;
      r3 = _v_3;
      r4 = _v_4;
      r5 = _v_5;
      r6 = _v_6;
      r7 = _v_7;
      r8 = _v_8;
      r9 = _v_9;
      r10 = _v_10;
      r11 = _v_11;
      r12 = _v_12;
      r13 = _v_13;
      r14 = _v_14;
      r15 = _v_15;
      r16 = _v_16;
      r17 = _v_17;
      r18 = _v_18;
      r19 = _v_19;
      r20 = _v_20;
      r21 = _v_21;
      r22 = _v_22;
      r23 = _v_23;
      r24 = _v_24;
      r25 = _v_25;
      r26 = _v_26;
      r27 = 1;
      r28 = term_ctr(CID_SCON, STAT_OFF + 22);
      WL_JMP(FID________________BENDVY_SRC_ECS_TRANSACTION_FINISH_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_RUNNER_0_K57)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    u32 _h_12 = r12;
    u32 _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    Term _h_19 = r19;
    Term _h_20 = r20;
    Term _h_21 = r21;
    u32 _h_22 = r22;
    u32 _h_23 = r23;
    u32 _h_24 = r24;
    Term _h_25 = r25;
    WL_OPEN
    u32 _v_189 = 0;
    u32 _v_190 = 0;
    u32 _v_191 = 0;
    u32 _v_192 = 0;
    Term _v_193 = 0;
    u32 _v_194 = 0;
    Term _v_195 = 0;
    Term _v_196 = 0;
    Term _v_197 = 0;
    u32 _v_198 = 0;
    u32 _v_199 = 0;
    u32 _v_200 = 0;
    u32 _v_201 = 0;
    u32 _v_202 = 0;
    u32 _v_203 = 0;
    u32 _v_204 = 0;
    u32 _v_205 = 0;
    u32 _v_206 = 0;
    u32 _v_207 = 0;
    u32 _v_208 = 0;
    Term _v_209 = 0;
    Term _v_210 = 0;
    Term _v_211 = 0;
    u32 _v_212 = 0;
    u32 _v_213 = 0;
    Term _v_214 = 0;
    Term _o_3[26];
    if (spin_29(e, _o_3, _h_0, _h_1, _h_2, _h_3, blk_loc(e.mem, _h_3), _h_4, _h_5, _h_6, blk_loc(e.mem, _h_6), _h_7, blk_loc(e.mem, _h_7), _h_8, _h_9, _h_10, _h_11, _h_12, _h_13, _h_14, _h_15, _h_16, _h_17, _h_18, _h_19, blk_loc(e.mem, _h_19), _h_20, blk_loc(e.mem, _h_20), _h_21, blk_loc(e.mem, _h_21), _h_22, _h_23, _h_24, _h_25, blk_loc(e.mem, _h_25)) == 0) {
      return 0;
    }
    _v_189 = _o_3[0];
    _v_190 = _o_3[1];
    _v_191 = _o_3[2];
    _v_192 = _o_3[3];
    _v_193 = _o_3[4];
    _v_194 = _o_3[5];
    _v_195 = _o_3[6];
    _v_196 = _o_3[7];
    _v_197 = _o_3[8];
    _v_198 = _o_3[9];
    _v_199 = _o_3[10];
    _v_200 = _o_3[11];
    _v_201 = _o_3[12];
    _v_202 = _o_3[13];
    _v_203 = _o_3[14];
    _v_204 = _o_3[15];
    _v_205 = _o_3[16];
    _v_206 = _o_3[17];
    _v_207 = _o_3[18];
    _v_208 = _o_3[19];
    _v_209 = _o_3[20];
    _v_210 = _o_3[21];
    _v_211 = _o_3[22];
    _v_212 = _o_3[23];
    _v_213 = _o_3[24];
    _v_214 = _o_3[25];
    r0 = _v_189;
    r1 = _v_190;
    r2 = _v_191;
    r3 = _v_192;
    r4 = _v_193;
    r5 = _v_194;
    r6 = _v_195;
    r7 = _v_196;
    r8 = _v_197;
    r9 = _v_198;
    r10 = _v_199;
    r11 = _v_200;
    r12 = _v_201;
    r13 = _v_202;
    r14 = _v_203;
    r15 = _v_204;
    r16 = _v_205;
    r17 = _v_206;
    r18 = _v_207;
    r19 = _v_208;
    r20 = _v_209;
    r21 = _v_210;
    r22 = _v_211;
    r23 = _v_212;
    r24 = _v_213;
    r25 = _v_214;
    WL_RETN(26);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_RUNNER_0_K58)
  {
    u32 _h_26 = r0;
    u32 _h_27 = r1;
    u32 _h_28 = r2;
    Term _h_29 = r3;
    u32 _h_30 = r4;
    Term _h_31 = r5;
    Term _h_32 = r6;
    Term _h_33 = r7;
    u32 _h_34 = r8;
    u32 _h_35 = r9;
    u32 _h_36 = r10;
    u32 _h_37 = r11;
    u32 _h_38 = r12;
    u32 _h_39 = r13;
    u32 _h_40 = r14;
    u32 _h_41 = r15;
    u32 _h_42 = r16;
    u32 _h_43 = r17;
    u32 _h_44 = r18;
    Term _h_45 = r19;
    Term _h_46 = r20;
    Term _h_47 = r21;
    u32 _h_48 = r22;
    u32 _h_49 = r23;
    u32 _h_50 = r24;
    Term _h_51 = r25;
    WL_OPEN
    u32 _v_215 = 0;
    u32 _v_216 = 0;
    u32 _v_217 = 0;
    u32 _v_218 = 0;
    Term _v_219 = 0;
    u32 _v_220 = 0;
    Term _v_221 = 0;
    Term _v_222 = 0;
    Term _v_223 = 0;
    u32 _v_224 = 0;
    u32 _v_225 = 0;
    u32 _v_226 = 0;
    u32 _v_227 = 0;
    u32 _v_228 = 0;
    u32 _v_229 = 0;
    u32 _v_230 = 0;
    u32 _v_231 = 0;
    u32 _v_232 = 0;
    u32 _v_233 = 0;
    u32 _v_234 = 0;
    Term _v_235 = 0;
    Term _v_236 = 0;
    Term _v_237 = 0;
    u32 _v_238 = 0;
    u32 _v_239 = 0;
    Term _v_240 = 0;
    Term _o_4[26];
    if (spin_29(e, _o_4, _h_26, _h_27, _h_28, _h_29, blk_loc(e.mem, _h_29), _h_30, _h_31, _h_32, blk_loc(e.mem, _h_32), _h_33, blk_loc(e.mem, _h_33), _h_34, _h_35, _h_36, _h_37, _h_38, _h_39, _h_40, _h_41, _h_42, _h_43, _h_44, _h_45, blk_loc(e.mem, _h_45), _h_46, blk_loc(e.mem, _h_46), _h_47, blk_loc(e.mem, _h_47), _h_48, _h_49, _h_50, _h_51, blk_loc(e.mem, _h_51)) == 0) {
      return 0;
    }
    _v_215 = _o_4[0];
    _v_216 = _o_4[1];
    _v_217 = _o_4[2];
    _v_218 = _o_4[3];
    _v_219 = _o_4[4];
    _v_220 = _o_4[5];
    _v_221 = _o_4[6];
    _v_222 = _o_4[7];
    _v_223 = _o_4[8];
    _v_224 = _o_4[9];
    _v_225 = _o_4[10];
    _v_226 = _o_4[11];
    _v_227 = _o_4[12];
    _v_228 = _o_4[13];
    _v_229 = _o_4[14];
    _v_230 = _o_4[15];
    _v_231 = _o_4[16];
    _v_232 = _o_4[17];
    _v_233 = _o_4[18];
    _v_234 = _o_4[19];
    _v_235 = _o_4[20];
    _v_236 = _o_4[21];
    _v_237 = _o_4[22];
    _v_238 = _o_4[23];
    _v_239 = _o_4[24];
    _v_240 = _o_4[25];
    r0 = _v_215;
    r1 = _v_216;
    r2 = _v_217;
    r3 = _v_218;
    r4 = _v_219;
    r5 = _v_220;
    r6 = _v_221;
    r7 = _v_222;
    r8 = _v_223;
    r9 = _v_224;
    r10 = _v_225;
    r11 = _v_226;
    r12 = _v_227;
    r13 = _v_228;
    r14 = _v_229;
    r15 = _v_230;
    r16 = _v_231;
    r17 = _v_232;
    r18 = _v_233;
    r19 = _v_234;
    r20 = _v_235;
    r21 = _v_236;
    r22 = _v_237;
    r23 = _v_238;
    r24 = _v_239;
    r25 = _v_240;
    WL_RETN(26);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES)
  {
    Term _registrations_0 = r0;
    u32 _id_0 = r1;
    Term _name_0 = r2;
    Term _access_0 = r3;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_WALK)) {
      u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_WALK, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _registrations_0;
      e.mem[_t_0 + 1] = _id_0;
      e.mem[_t_0 + 2] = _name_0;
      e.mem[_t_0 + 3] = _access_0;
      e.mem[_t_0 + 4] = 0;
      return term_tsk(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_WALK, _t_0);
    }
    r0 = _registrations_0;
    r1 = _id_0;
    r2 = _name_0;
    r3 = _access_0;
    r4 = 0;
    WL_JMP(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_WALK);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_MATCHES_0)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    u32 _world_2 = r2;
    Term _world_3 = r3;
    u32 _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    u32 _world_9 = r9;
    u32 _world_10 = r10;
    u32 _world_11 = r11;
    u32 _world_12 = r12;
    u32 _world_13 = r13;
    u32 _world_14 = r14;
    u32 _world_15 = r15;
    u32 _world_16 = r16;
    u32 _world_17 = r17;
    u32 _world_18 = r18;
    Term _world_19 = r19;
    Term _world_20 = r20;
    Term _world_21 = r21;
    u32 _world_22 = r22;
    u32 _world_23 = r23;
    u32 _id_0 = r24;
    Term _name_0 = r25;
    Term _access_0 = r26;
    WL_OPEN
    if (seq) {
      WL_ROOM(25);
      STK(0) = _world_0;
      STK(1) = _world_1;
      STK(2) = _world_2;
      STK(3) = _world_3;
      STK(4) = _world_4;
      STK(5) = _world_5;
      STK(6) = _world_6;
      STK(7) = _world_7;
      STK(8) = _world_8;
      STK(9) = _world_9;
      STK(10) = _world_10;
      STK(11) = _world_11;
      STK(12) = _world_12;
      STK(13) = _world_13;
      STK(14) = _world_14;
      STK(15) = _world_15;
      STK(16) = _world_16;
      STK(17) = _world_17;
      STK(18) = _world_18;
      STK(19) = _world_19;
      STK(20) = _world_20;
      STK(21) = _world_21;
      STK(22) = _world_22;
      STK(23) = _world_23;
      STK(24) = FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_MATCHES_0_K64;
      WL_PUSHN(25);
    } else {
      u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_MATCHES_0_K64, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _world_0;
      e.mem[_t_0 + 1] = _world_1;
      e.mem[_t_0 + 2] = _world_2;
      e.mem[_t_0 + 3] = _world_3;
      e.mem[_t_0 + 4] = _world_4;
      e.mem[_t_0 + 5] = _world_5;
      e.mem[_t_0 + 6] = _world_6;
      e.mem[_t_0 + 7] = _world_7;
      e.mem[_t_0 + 8] = _world_8;
      e.mem[_t_0 + 9] = _world_9;
      e.mem[_t_0 + 10] = _world_10;
      e.mem[_t_0 + 11] = _world_11;
      e.mem[_t_0 + 12] = _world_12;
      e.mem[_t_0 + 13] = _world_13;
      e.mem[_t_0 + 14] = _world_14;
      e.mem[_t_0 + 15] = _world_15;
      e.mem[_t_0 + 16] = _world_16;
      e.mem[_t_0 + 17] = _world_17;
      e.mem[_t_0 + 18] = _world_18;
      e.mem[_t_0 + 19] = _world_19;
      e.mem[_t_0 + 20] = _world_20;
      e.mem[_t_0 + 21] = _world_21;
      e.mem[_t_0 + 22] = _world_22;
      e.mem[_t_0 + 23] = _world_23;
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_MATCHES_0_K64, _t_0);
      WL_IDX = 24;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES)) {
      u64 _t_1 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_21;
      e.mem[_t_1 + 1] = _id_0;
      e.mem[_t_1 + 2] = _name_0;
      e.mem[_t_1 + 3] = _access_0;
      return term_tsk(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES, _t_1);
    }
    r0 = _world_21;
    r1 = _id_0;
    r2 = _name_0;
    r3 = _access_0;
    WL_JMP(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_MATCHES_0_K64)
  {
    WL_POPN(24);
    u32 _world_24 = STK(0);
    u32 _world_25 = STK(1);
    u32 _world_26 = STK(2);
    Term _world_27 = STK(3);
    u32 _world_28 = STK(4);
    Term _world_29 = STK(5);
    Term _world_30 = STK(6);
    Term _world_31 = STK(7);
    u32 _world_32 = STK(8);
    u32 _world_33 = STK(9);
    u32 _world_34 = STK(10);
    u32 _world_35 = STK(11);
    u32 _world_36 = STK(12);
    u32 _world_37 = STK(13);
    u32 _world_38 = STK(14);
    u32 _world_39 = STK(15);
    u32 _world_40 = STK(16);
    u32 _world_41 = STK(17);
    u32 _world_42 = STK(18);
    Term _world_43 = STK(19);
    Term _world_44 = STK(20);
    Term _world_45 = STK(21);
    u32 _world_46 = STK(22);
    u32 _world_47 = STK(23);
    u32 _h_0 = r0;
    WL_OPEN
    r0 = _world_24;
    r1 = _world_25;
    r2 = _world_26;
    r3 = _world_27;
    r4 = _world_28;
    r5 = _world_29;
    r6 = _world_30;
    r7 = _world_31;
    r8 = _world_32;
    r9 = _world_33;
    r10 = _world_34;
    r11 = _world_35;
    r12 = _world_36;
    r13 = _world_37;
    r14 = _world_38;
    r15 = _world_39;
    r16 = _world_40;
    r17 = _world_41;
    r18 = _world_42;
    r19 = _world_43;
    r20 = _world_44;
    r21 = _world_45;
    r22 = _world_46;
    r23 = _world_47;
    r24 = _h_0;
    WL_RETN(25);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_1)
  {
    Term _xs_0 = r0;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 70);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[3];
      u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      spare_free(e, cls_fit(3), _sp_1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_LIST_SHOW_GO_1_K98;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_GO_1_K98, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_LIST_SHOW_GO_1_K98, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_REGISTRATION)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_EXPANDED_REGISTRATION, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_2;
        e.mem[_t_1 + 1] = _f_3;
        e.mem[_t_1 + 2] = _f_4;
        return term_tsk(FID_CONSUMER_EXPANDED_REGISTRATION, _t_1);
      }
      r0 = _f_2;
      r1 = _f_3;
      r2 = _f_4;
      WL_JMP(FID_CONSUMER_EXPANDED_REGISTRATION);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_1_K98)
  {
    WL_POPN(1);
    Term _f_5 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_LIST_SHOW_GO_1_K99;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_LIST_SHOW_GO_1_K99, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_LIST_SHOW_GO_1_K99, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_GO_1)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_GO_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_5;
      return term_tsk(FID_LIST_SHOW_GO_1, _t_3);
    }
    r0 = _f_5;
    WL_JMP(FID_LIST_SHOW_GO_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_1_K99)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_GO_1_K100;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_LIST_SHOW_GO_1_K100, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_GO_1_K100, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_1_K100)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 74);
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 74);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_REGISTRATION)
  {
    u32 _meta_0 = r0;
    Term _meta_1 = r1;
    Term _meta_2 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _meta_1;
      STK(1) = _meta_2;
      STK(2) = FID_CONSUMER_EXPANDED_REGISTRATION_K102;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID_CONSUMER_EXPANDED_REGISTRATION_K102, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _meta_1;
      e.mem[_t_0 + 1] = _meta_2;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_REGISTRATION_K102, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _meta_0;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _meta_0;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_REGISTRATION_K102)
  {
    WL_POPN(2);
    Term _meta_3 = STK(0);
    Term _meta_4 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _meta_3;
      STK(1) = _h_0;
      STK(2) = FID_CONSUMER_EXPANDED_REGISTRATION_K103;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_EXPANDED_REGISTRATION_K103, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _meta_3;
      e.mem[_t_2 + 1] = _h_0;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_REGISTRATION_K103, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_0)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _meta_4;
      return term_tsk(FID_LIST_SHOW_0, _t_3);
    }
    r0 = _meta_4;
    WL_JMP(FID_LIST_SHOW_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_REGISTRATION_K103)
  {
    WL_POPN(2);
    Term _meta_5 = STK(0);
    Term _h_2 = STK(1);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _meta_5;
      STK(1) = _h_2;
      STK(2) = FID_CONSUMER_EXPANDED_REGISTRATION_K104;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_CONSUMER_EXPANDED_REGISTRATION_K104, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _meta_5;
      e.mem[_t_4 + 1] = _h_2;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_REGISTRATION_K104, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 76);
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 76);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_REGISTRATION_K104)
  {
    WL_POPN(2);
    Term _meta_6 = STK(0);
    Term _h_4 = STK(1);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_4;
      STK(1) = FID_CONSUMER_EXPANDED_REGISTRATION_K105;
      WL_PUSHN(2);
    } else {
      u64 _t_6 = task_node(e, FID_CONSUMER_EXPANDED_REGISTRATION_K105, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_4;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_REGISTRATION_K105, _t_6);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _meta_6;
      e.mem[_t_7 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _meta_6;
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_REGISTRATION_K105)
  {
    WL_POPN(1);
    Term _h_6 = STK(0);
    Term _h_5 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_6;
      STK(1) = FID_CONSUMER_EXPANDED_REGISTRATION_K106;
      WL_PUSHN(2);
    } else {
      u64 _t_8 = task_node(e, FID_CONSUMER_EXPANDED_REGISTRATION_K106, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_6;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_REGISTRATION_K106, _t_8);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = term_ctr(CID_SCON, STAT_OFF + 76);
      e.mem[_t_9 + 1] = _h_5;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 76);
    r1 = _h_5;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_REGISTRATION_K106)
  {
    WL_POPN(1);
    Term _h_8 = STK(0);
    Term _h_7 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_10 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = _h_8;
      e.mem[_t_10 + 1] = _h_7;
      return term_tsk(FID_STRING_APPEND, _t_10);
    }
    r0 = _h_8;
    r1 = _h_7;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_PREVIOUS)
  {
    u32 _prior_0 = r0;
    u32 _prior_1 = r1;
    u32 _prior_2 = r2;
    WL_OPEN
    if (_prior_0 == 0) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 82);
      WL_RETN(1);
    } else {
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_SHOW_VALUE)) {
        u64 _t_0 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_VALUE, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = _prior_1;
        e.mem[_t_0 + 1] = _prior_2;
        return term_tsk(FID_CONSUMER_EXPANDED_SHOW_VALUE, _t_0);
      }
      r0 = _prior_1;
      r1 = _prior_2;
      WL_JMP(FID_CONSUMER_EXPANDED_SHOW_VALUE);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_PENDING)
  {
    u32 _pending_0 = r0;
    u32 _pending_1 = r1;
    u32 _pending_2 = r2;
    u32 _pending_3 = r3;
    WL_OPEN
    if (_pending_0 == 0) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 82);
      WL_RETN(1);
    } else {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _pending_3;
        STK(1) = FID_CONSUMER_EXPANDED_SHOW_PENDING_K110;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_PENDING_K110, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _pending_3;
        WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_PENDING_K110, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_SHOW_VALUE)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_VALUE, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _pending_1;
        e.mem[_t_1 + 1] = _pending_2;
        return term_tsk(FID_CONSUMER_EXPANDED_SHOW_VALUE, _t_1);
      }
      r0 = _pending_1;
      r1 = _pending_2;
      WL_JMP(FID_CONSUMER_EXPANDED_SHOW_VALUE);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_PENDING_K110)
  {
    WL_POPN(1);
    u32 _pending_4 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_35(e, _o_0, _pending_4) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_CONSUMER_EXPANDED_SHOW_PENDING_K111;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_PENDING_K111, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_PENDING_K111, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 94);
      e.mem[_t_3 + 1] = _v_0;
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 94);
    r1 = _v_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_PENDING_K111)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_4 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_4 + 0] = _h_2;
      e.mem[_t_4 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_4);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_VALUE)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _value_0;
      STK(1) = FID_CONSUMER_EXPANDED_SHOW_VALUE_K113;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_VALUE_K113, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_0;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_VALUE_K113, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _value_1;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _value_1;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_VALUE_K113)
  {
    WL_POPN(1);
    u32 _value_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _value_2;
      STK(1) = FID_CONSUMER_EXPANDED_SHOW_VALUE_K114;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_VALUE_K114, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _value_2;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_VALUE_K114, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 76);
      e.mem[_t_3 + 1] = _h_0;
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 76);
    r1 = _h_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_VALUE_K114)
  {
    WL_POPN(1);
    u32 _value_3 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_36(e, _o_0, _value_3) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_4 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_4 + 0] = _v_0;
      e.mem[_t_4 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_4);
    }
    r0 = _v_0;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NAT_SHOW_FIN)
  {
    Term _g_0 = r0;
    Term _acc_0 = r1;
    u32 _dq_0 = r2;
    Term _dq_1 = r3;
    WL_OPEN
    WL_SPIN
    if (_dq_1 == 0) {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _dq_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = term_ctr(CID_SCON, _nd_0);
      WL_RETN(1);
    } else {
      Term _p_0 = (_dq_1 - 1);
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _dq_0);
      e.mem[_nd_1 + 1] = rfc_seal(e, _acc_0);
      if (_g_0 == 0) {
        Term _n_0 = nat_chk(e, _p_0 + 1);
        Term _acc_1 = term_ctr(CID_SCON, _nd_1);
        r0 = _acc_1;
        WL_RETN(1);
      } else {
        Term _g_1 = (_g_0 - 1);
        Term _n_1 = nat_chk(e, _p_0 + 1);
        Term _acc_2 = term_ctr(CID_SCON, _nd_1);
        u32 _v_0 = 0;
        Term _v_1 = 0;
        Term _a_0 = 10ull;
        Term _a_1 = (_a_0 == 0 ? 0 : _n_1 / _a_0);
        Term _a_2 = (_a_0 == 0 ? _n_1 : _n_1 % _a_0);
        u32 _v_2 = 0;
        Term _v_3 = 0;
        Term _o_0[2];
        if (spin_33(e, _o_0, _a_1, _a_2) == 0) {
          return 0;
        }
        _v_2 = _o_0[0];
        _v_3 = _o_0[1];
        _v_0 = _v_2;
        _v_1 = _v_3;
        r0 = _g_1;
        r1 = _acc_2;
        r2 = _v_0;
        r3 = _v_1;
        _g_0 = r0;
        _acc_0 = r1;
        _dq_0 = r2;
        _dq_1 = r3;
        WL_AGAIN(FID_NAT_SHOW_FIN);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW_GO)
  {
    Term _f_0 = r0;
    u32 _n_0 = r1;
    Term _acc_0 = r2;
    WL_OPEN
    WL_SPIN
    if (_f_0 == 0) {
      r0 = _acc_0;
      WL_RETN(1);
    } else {
      Term _g_0 = (_f_0 - 1);
      u32 _s_0 = U32_BIN(_n_0, ==, 0);
      if (_s_0 == 1) {
        r0 = _acc_0;
        WL_RETN(1);
      } else {
        Term _a_0 = 10ull;
        Term _a_1 = 10ull;
        u64 _nd_0 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, U32_BIN(48ull, +, ((u32)(_a_1) == 0 ? _n_0 : U32_BIN(_n_0, -, U32_QUO((u32)(_n_0), (u32)(_a_1)) * _a_1))));
        e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
        r0 = _g_0;
        r1 = ((u32)(_a_0) == 0 ? 0 : (u64)U32_QUO((u32)(_n_0), (u32)(_a_0)));
        r2 = term_ctr(CID_SCON, _nd_0);
        _f_0 = r0;
        _n_0 = r1;
        _acc_0 = r2;
        WL_AGAIN(FID_U32_SHOW_GO);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_NUMBER)
  {
    u32 _value_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _value_0;
      STK(1) = FID_CONSUMER_EXPANDED_NUMBER_K132;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_CONSUMER_EXPANDED_NUMBER_K132, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_0;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_NUMBER_K132, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _value_0;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _value_0;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_NUMBER_K132)
  {
    WL_POPN(1);
    u32 _value_1 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    r0 = _value_1;
    r1 = _h_0;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_PAYLOAD)
  {
    Term _value_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_TREE_0)) {
      u64 _t_0 = task_node(e, FID_CONSUMER_EXPANDED_TREE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _value_0;
      return term_tsk(FID_CONSUMER_EXPANDED_TREE_0, _t_0);
    }
    r0 = _value_0;
    WL_JMP(FID_CONSUMER_EXPANDED_TREE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_1)
  {
    Term _xs_0 = r0;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 98);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[3];
      u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      spare_free(e, cls_fit(3), _sp_1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_LIST_SHOW_1_K156;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_1_K156, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_LIST_SHOW_1_K156, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_REGISTRATION)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_EXPANDED_REGISTRATION, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_2;
        e.mem[_t_1 + 1] = _f_3;
        e.mem[_t_1 + 2] = _f_4;
        return term_tsk(FID_CONSUMER_EXPANDED_REGISTRATION, _t_1);
      }
      r0 = _f_2;
      r1 = _f_3;
      r2 = _f_4;
      WL_JMP(FID_CONSUMER_EXPANDED_REGISTRATION);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_1_K156)
  {
    WL_POPN(1);
    Term _f_5 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_LIST_SHOW_1_K157;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_LIST_SHOW_1_K157, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_LIST_SHOW_1_K157, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_GO_1)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_GO_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_5;
      return term_tsk(FID_LIST_SHOW_GO_1, _t_3);
    }
    r0 = _f_5;
    WL_JMP(FID_LIST_SHOW_GO_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_1_K157)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_1_K158;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_LIST_SHOW_1_K158, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_1_K158, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_1_K158)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 100);
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 100);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_SLOT_0)
  {
    u32 _slot_0 = r0;
    u32 _slot_1 = r1;
    u32 _slot_2 = r2;
    u32 _slot_3 = r3;
    u32 _slot_4 = r4;
    u32 _slot_5 = r5;
    u32 _slot_6 = r6;
    u32 _slot_7 = r7;
    u32 _slot_8 = r8;
    u32 _slot_9 = r9;
    u32 _slot_10 = r10;
    WL_OPEN
    if (_slot_0 == 0) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 114);
      WL_RETN(1);
    } else {
      if (seq) {
        WL_ROOM(9);
        STK(0) = _slot_3;
        STK(1) = _slot_4;
        STK(2) = _slot_5;
        STK(3) = _slot_6;
        STK(4) = _slot_7;
        STK(5) = _slot_8;
        STK(6) = _slot_9;
        STK(7) = _slot_10;
        STK(8) = FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K160;
        WL_PUSHN(9);
      } else {
        u64 _t_0 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K160, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _slot_3;
        e.mem[_t_0 + 1] = _slot_4;
        e.mem[_t_0 + 2] = _slot_5;
        e.mem[_t_0 + 3] = _slot_6;
        e.mem[_t_0 + 4] = _slot_7;
        e.mem[_t_0 + 5] = _slot_8;
        e.mem[_t_0 + 6] = _slot_9;
        e.mem[_t_0 + 7] = _slot_10;
        WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K160, _t_0);
        WL_IDX = 8;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_SHOW_VALUE)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_VALUE, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _slot_1;
        e.mem[_t_1 + 1] = _slot_2;
        return term_tsk(FID_CONSUMER_EXPANDED_SHOW_VALUE, _t_1);
      }
      r0 = _slot_1;
      r1 = _slot_2;
      WL_JMP(FID_CONSUMER_EXPANDED_SHOW_VALUE);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K160)
  {
    WL_POPN(8);
    u32 _slot_11 = STK(0);
    u32 _slot_12 = STK(1);
    u32 _slot_13 = STK(2);
    u32 _slot_14 = STK(3);
    u32 _slot_15 = STK(4);
    u32 _slot_16 = STK(5);
    u32 _slot_17 = STK(6);
    u32 _slot_18 = STK(7);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _slot_15;
      STK(1) = _slot_16;
      STK(2) = _slot_17;
      STK(3) = _slot_18;
      STK(4) = _h_0;
      STK(5) = FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K161;
      WL_PUSHN(6);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K161, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _slot_15;
      e.mem[_t_2 + 1] = _slot_16;
      e.mem[_t_2 + 2] = _slot_17;
      e.mem[_t_2 + 3] = _slot_18;
      e.mem[_t_2 + 4] = _h_0;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K161, _t_2);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_SHOW_PENDING)) {
      u64 _t_3 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_PENDING, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _slot_11;
      e.mem[_t_3 + 1] = _slot_12;
      e.mem[_t_3 + 2] = _slot_13;
      e.mem[_t_3 + 3] = _slot_14;
      return term_tsk(FID_CONSUMER_EXPANDED_SHOW_PENDING, _t_3);
    }
    r0 = _slot_11;
    r1 = _slot_12;
    r2 = _slot_13;
    r3 = _slot_14;
    WL_JMP(FID_CONSUMER_EXPANDED_SHOW_PENDING);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K161)
  {
    WL_POPN(5);
    u32 _slot_19 = STK(0);
    u32 _slot_20 = STK(1);
    u32 _slot_21 = STK(2);
    u32 _slot_22 = STK(3);
    Term _h_2 = STK(4);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _slot_22;
      STK(1) = _h_2;
      STK(2) = _h_1;
      STK(3) = FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K162;
      WL_PUSHN(4);
    } else {
      u64 _t_4 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K162, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _slot_22;
      e.mem[_t_4 + 1] = _h_2;
      e.mem[_t_4 + 2] = _h_1;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K162, _t_4);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_PREVIOUS)) {
      u64 _t_5 = task_node(e, FID_CONSUMER_EXPANDED_PREVIOUS, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _slot_19;
      e.mem[_t_5 + 1] = _slot_20;
      e.mem[_t_5 + 2] = _slot_21;
      return term_tsk(FID_CONSUMER_EXPANDED_PREVIOUS, _t_5);
    }
    r0 = _slot_19;
    r1 = _slot_20;
    r2 = _slot_21;
    WL_JMP(FID_CONSUMER_EXPANDED_PREVIOUS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K162)
  {
    WL_POPN(3);
    u32 _slot_23 = STK(0);
    Term _h_4 = STK(1);
    Term _h_5 = STK(2);
    Term _h_3 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_35(e, _o_0, _slot_23) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_4;
      STK(1) = _h_5;
      STK(2) = _h_3;
      STK(3) = FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K163;
      WL_PUSHN(4);
    } else {
      u64 _t_6 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K163, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_4;
      e.mem[_t_6 + 1] = _h_5;
      e.mem[_t_6 + 2] = _h_3;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K163, _t_6);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 130);
      e.mem[_t_7 + 1] = _v_0;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 130);
    r1 = _v_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K163)
  {
    WL_POPN(3);
    Term _h_7 = STK(0);
    Term _h_8 = STK(1);
    Term _h_9 = STK(2);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_7;
      STK(1) = _h_8;
      STK(2) = FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K164;
      WL_PUSHN(3);
    } else {
      u64 _t_8 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K164, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_7;
      e.mem[_t_8 + 1] = _h_8;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K164, _t_8);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_9;
      e.mem[_t_9 + 1] = _h_6;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _h_9;
    r1 = _h_6;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K164)
  {
    WL_POPN(2);
    Term _h_11 = STK(0);
    Term _h_12 = STK(1);
    Term _h_10 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_11;
      STK(1) = _h_12;
      STK(2) = FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K165;
      WL_PUSHN(3);
    } else {
      u64 _t_10 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K165, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_11;
      e.mem[_t_10 + 1] = _h_12;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K165, _t_10);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 148);
      e.mem[_t_11 + 1] = _h_10;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 148);
    r1 = _h_10;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K165)
  {
    WL_POPN(2);
    Term _h_14 = STK(0);
    Term _h_15 = STK(1);
    Term _h_13 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_14;
      STK(1) = FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K166;
      WL_PUSHN(2);
    } else {
      u64 _t_12 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K166, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _h_14;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K166, _t_12);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _h_15;
      e.mem[_t_13 + 1] = _h_13;
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = _h_15;
    r1 = _h_13;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K166)
  {
    WL_POPN(1);
    Term _h_17 = STK(0);
    Term _h_16 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_17;
      STK(1) = FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K167;
      WL_PUSHN(2);
    } else {
      u64 _t_14 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K167, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _h_17;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K167, _t_14);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_15 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = term_ctr(CID_SCON, STAT_OFF + 150);
      e.mem[_t_15 + 1] = _h_16;
      return term_tsk(FID_STRING_APPEND, _t_15);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 150);
    r1 = _h_16;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_SLOT_0_K167)
  {
    WL_POPN(1);
    Term _h_19 = STK(0);
    Term _h_18 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_16 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_16 + 0] = _h_19;
      e.mem[_t_16 + 1] = _h_18;
      return term_tsk(FID_STRING_APPEND, _t_16);
    }
    r0 = _h_19;
    r1 = _h_18;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NAT_SHOW)
  {
    Term _n_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    Term _a_0 = 10ull;
    Term _a_1 = (_a_0 == 0 ? 0 : _n_0 / _a_0);
    Term _a_2 = (_a_0 == 0 ? _n_0 : _n_0 % _a_0);
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _o_0[2];
    if (spin_33(e, _o_0, _a_1, _a_2) == 0) {
      return 0;
    }
    _v_2 = _o_0[0];
    _v_3 = _o_0[1];
    _v_0 = _v_2;
    _v_1 = _v_3;
    if (!DEVICE && !seq && fid_nofk(FID_NAT_SHOW_FIN)) {
      u64 _t_0 = task_node(e, FID_NAT_SHOW_FIN, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _n_0;
      e.mem[_t_0 + 1] = term_pak(CID_SNIL, 0);
      e.mem[_t_0 + 2] = _v_0;
      e.mem[_t_0 + 3] = _v_1;
      return term_tsk(FID_NAT_SHOW_FIN, _t_0);
    }
    r0 = _n_0;
    r1 = term_pak(CID_SNIL, 0);
    r2 = _v_0;
    r3 = _v_1;
    WL_JMP(FID_NAT_SHOW_FIN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_0)
  {
    Term _xs_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 70);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_LIST_SHOW_GO_0_K170;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_GO_0_K170, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_LIST_SHOW_GO_0_K170, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      _xs_0 = r0;
      WL_AGAIN(FID_LIST_SHOW_GO_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_0_K170)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_GO_0_K171;
      WL_PUSHN(1);
    } else {
      u64 _t_1 = task_node(e, FID_LIST_SHOW_GO_0_K171, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_GO_0_K171, _t_1);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_2 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_2;
      e.mem[_t_2 + 1] = _h_0;
      return term_tsk(FID_STRING_APPEND, _t_2);
    }
    r0 = _f_2;
    r1 = _h_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_0_K171)
  {
    Term _h_1 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 74);
      e.mem[_t_3 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 74);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_SYSTEM_RUN_0)
  {
    u32 _registry_0 = r0;
    u32 _registry_1 = r1;
    Term _registry_2 = r2;
    Term _registry_3 = r3;
    u32 _registry_4 = r4;
    u32 _world_0 = r5;
    u32 _world_1 = r6;
    u32 _world_2 = r7;
    Term _world_3 = r8;
    u32 _world_4 = r9;
    Term _world_5 = r10;
    Term _world_6 = r11;
    Term _world_7 = r12;
    u32 _world_8 = r13;
    u32 _world_9 = r14;
    u32 _world_10 = r15;
    u32 _world_11 = r16;
    u32 _world_12 = r17;
    u32 _world_13 = r18;
    u32 _world_14 = r19;
    u32 _world_15 = r20;
    u32 _world_16 = r21;
    u32 _world_17 = r22;
    u32 _world_18 = r23;
    Term _world_19 = r24;
    Term _world_20 = r25;
    Term _world_21 = r26;
    u32 _world_22 = r27;
    u32 _world_23 = r28;
    u32 _args_0 = r29;
    u32 _args_1 = r30;
    u32 _args_2 = r31;
    u32 _args_3 = r32;
    u32 _args_4 = r33;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    Term _v_28 = 0;
    u32 _v_29 = 0;
    Term _v_30 = 0;
    Term _v_31 = 0;
    Term _v_32 = 0;
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    u32 _v_38 = 0;
    u32 _v_39 = 0;
    u32 _v_40 = 0;
    u32 _v_41 = 0;
    u32 _v_42 = 0;
    u32 _v_43 = 0;
    Term _v_44 = 0;
    Term _v_45 = 0;
    Term _v_46 = 0;
    u32 _v_47 = 0;
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    Term _o_0[25];
    if (spin_40(e, _o_0, _world_0, _world_1, _world_2, _world_3, blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, blk_loc(e.mem, _world_6), _world_7, blk_loc(e.mem, _world_7), _world_8, _world_9, _world_10, _world_11, _world_12, _world_13, _world_14, _world_15, _world_16, _world_17, _world_18, _world_19, blk_loc(e.mem, _world_19), _world_20, blk_loc(e.mem, _world_20), _world_21, blk_loc(e.mem, _world_21), _world_22, _world_23) == 0) {
      return 0;
    }
    _v_25 = _o_0[0];
    _v_26 = _o_0[1];
    _v_27 = _o_0[2];
    _v_28 = _o_0[3];
    _v_29 = _o_0[4];
    _v_30 = _o_0[5];
    _v_31 = _o_0[6];
    _v_32 = _o_0[7];
    _v_33 = _o_0[8];
    _v_34 = _o_0[9];
    _v_35 = _o_0[10];
    _v_36 = _o_0[11];
    _v_37 = _o_0[12];
    _v_38 = _o_0[13];
    _v_39 = _o_0[14];
    _v_40 = _o_0[15];
    _v_41 = _o_0[16];
    _v_42 = _o_0[17];
    _v_43 = _o_0[18];
    _v_44 = _o_0[19];
    _v_45 = _o_0[20];
    _v_46 = _o_0[21];
    _v_47 = _o_0[22];
    _v_48 = _o_0[23];
    _v_49 = _o_0[24];
    _v_0 = _v_25;
    _v_1 = _v_26;
    _v_2 = _v_27;
    _v_3 = _v_28;
    _v_4 = _v_29;
    _v_5 = _v_30;
    _v_6 = _v_31;
    _v_7 = _v_32;
    _v_8 = _v_33;
    _v_9 = _v_34;
    _v_10 = _v_35;
    _v_11 = _v_36;
    _v_12 = _v_37;
    _v_13 = _v_38;
    _v_14 = _v_39;
    _v_15 = _v_40;
    _v_16 = _v_41;
    _v_17 = _v_42;
    _v_18 = _v_43;
    _v_19 = _v_44;
    _v_20 = _v_45;
    _v_21 = _v_46;
    _v_22 = _v_47;
    _v_23 = _v_48;
    _v_24 = _v_49;
    u32 _s_0 = U32_BIN(_registry_0, ==, _v_24);
    if (_s_0 == 0) {
      r0 = 1;
      r1 = _registry_0;
      r2 = _registry_1;
      r3 = _registry_2;
      r4 = _registry_3;
      r5 = _registry_4;
      r6 = _v_0;
      r7 = _v_1;
      r8 = _v_2;
      r9 = _v_3;
      r10 = _v_4;
      r11 = _v_5;
      r12 = _v_6;
      r13 = _v_7;
      r14 = _v_8;
      r15 = _v_9;
      r16 = _v_10;
      r17 = _v_11;
      r18 = _v_12;
      r19 = _v_13;
      r20 = _v_14;
      r21 = _v_15;
      r22 = _v_16;
      r23 = _v_17;
      r24 = _v_18;
      r25 = _v_19;
      r26 = _v_20;
      r27 = _v_21;
      r28 = _v_22;
      r29 = _v_23;
      r30 = _args_0;
      r31 = _args_1;
      r32 = _args_2;
      r33 = _args_3;
      r34 = _args_4;
      WL_RETN(35);
    } else {
      if (seq) {
        WL_ROOM(11);
        STK(0) = _registry_0;
        STK(1) = _registry_1;
        STK(2) = _registry_2;
        STK(3) = _registry_3;
        STK(4) = _registry_4;
        STK(5) = _args_0;
        STK(6) = _args_1;
        STK(7) = _args_2;
        STK(8) = _args_3;
        STK(9) = _args_4;
        STK(10) = FID________________BENDVY_SRC_ECS_SYSTEM_RUN_0_K174;
        WL_PUSHN(11);
      } else {
        u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_SYSTEM_RUN_0_K174, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _registry_0;
        e.mem[_t_0 + 1] = _registry_1;
        e.mem[_t_0 + 2] = _registry_2;
        e.mem[_t_0 + 3] = _registry_3;
        e.mem[_t_0 + 4] = _registry_4;
        e.mem[_t_0 + 5] = _args_0;
        e.mem[_t_0 + 6] = _args_1;
        e.mem[_t_0 + 7] = _args_2;
        e.mem[_t_0 + 8] = _args_3;
        e.mem[_t_0 + 9] = _args_4;
        WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_SYSTEM_RUN_0_K174, _t_0);
        WL_IDX = 10;
      }
      if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_MATCHES_0)) {
        u64 _t_1 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_MATCHES_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _v_0;
        e.mem[_t_1 + 1] = _v_1;
        e.mem[_t_1 + 2] = _v_2;
        e.mem[_t_1 + 3] = _v_3;
        e.mem[_t_1 + 4] = _v_4;
        e.mem[_t_1 + 5] = _v_5;
        e.mem[_t_1 + 6] = _v_6;
        e.mem[_t_1 + 7] = _v_7;
        e.mem[_t_1 + 8] = _v_8;
        e.mem[_t_1 + 9] = _v_9;
        e.mem[_t_1 + 10] = _v_10;
        e.mem[_t_1 + 11] = _v_11;
        e.mem[_t_1 + 12] = _v_12;
        e.mem[_t_1 + 13] = _v_13;
        e.mem[_t_1 + 14] = _v_14;
        e.mem[_t_1 + 15] = _v_15;
        e.mem[_t_1 + 16] = _v_16;
        e.mem[_t_1 + 17] = _v_17;
        e.mem[_t_1 + 18] = _v_18;
        e.mem[_t_1 + 19] = _v_19;
        e.mem[_t_1 + 20] = _v_20;
        e.mem[_t_1 + 21] = _v_21;
        e.mem[_t_1 + 22] = _v_22;
        e.mem[_t_1 + 23] = _v_23;
        e.mem[_t_1 + 24] = _registry_1;
        e.mem[_t_1 + 25] = _registry_2;
        e.mem[_t_1 + 26] = _registry_3;
        return term_tsk(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_MATCHES_0, _t_1);
      }
      r0 = _v_0;
      r1 = _v_1;
      r2 = _v_2;
      r3 = _v_3;
      r4 = _v_4;
      r5 = _v_5;
      r6 = _v_6;
      r7 = _v_7;
      r8 = _v_8;
      r9 = _v_9;
      r10 = _v_10;
      r11 = _v_11;
      r12 = _v_12;
      r13 = _v_13;
      r14 = _v_14;
      r15 = _v_15;
      r16 = _v_16;
      r17 = _v_17;
      r18 = _v_18;
      r19 = _v_19;
      r20 = _v_20;
      r21 = _v_21;
      r22 = _v_22;
      r23 = _v_23;
      r24 = _registry_1;
      r25 = _registry_2;
      r26 = _registry_3;
      WL_JMP(FID________________BENDVY_SRC_ECS_WORLD_REGISTRATION_MATCHES_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_SYSTEM_RUN_0_K174)
  {
    WL_POPN(10);
    u32 _registry_5 = STK(0);
    u32 _registry_6 = STK(1);
    Term _registry_7 = STK(2);
    Term _registry_8 = STK(3);
    u32 _registry_9 = STK(4);
    u32 _args_5 = STK(5);
    u32 _args_6 = STK(6);
    u32 _args_7 = STK(7);
    u32 _args_8 = STK(8);
    u32 _args_9 = STK(9);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    u32 _h_12 = r12;
    u32 _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    Term _h_19 = r19;
    Term _h_20 = r20;
    Term _h_21 = r21;
    u32 _h_22 = r22;
    u32 _h_23 = r23;
    u32 _h_24 = r24;
    WL_OPEN
    if (_h_24 == 0) {
      r0 = 1;
      r1 = _registry_5;
      r2 = _registry_6;
      r3 = _registry_7;
      r4 = _registry_8;
      r5 = _registry_9;
      r6 = _h_0;
      r7 = _h_1;
      r8 = _h_2;
      r9 = _h_3;
      r10 = _h_4;
      r11 = _h_5;
      r12 = _h_6;
      r13 = _h_7;
      r14 = _h_8;
      r15 = _h_9;
      r16 = _h_10;
      r17 = _h_11;
      r18 = _h_12;
      r19 = _h_13;
      r20 = _h_14;
      r21 = _h_15;
      r22 = _h_16;
      r23 = _h_17;
      r24 = _h_18;
      r25 = _h_19;
      r26 = _h_20;
      r27 = _h_21;
      r28 = _h_22;
      r29 = _h_23;
      r30 = _args_5;
      r31 = _args_6;
      r32 = _args_7;
      r33 = _args_8;
      r34 = _args_9;
      WL_RETN(35);
    } else {
      if (seq) {
        WL_ROOM(6);
        STK(0) = _registry_5;
        STK(1) = _registry_6;
        STK(2) = _registry_7;
        STK(3) = _registry_8;
        STK(4) = _registry_9;
        STK(5) = FID________________BENDVY_SRC_ECS_SYSTEM_RUN_0_K175;
        WL_PUSHN(6);
      } else {
        u64 _t_2 = task_node(e, FID________________BENDVY_SRC_ECS_SYSTEM_RUN_0_K175, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _registry_5;
        e.mem[_t_2 + 1] = _registry_6;
        e.mem[_t_2 + 2] = _registry_7;
        e.mem[_t_2 + 3] = _registry_8;
        e.mem[_t_2 + 4] = _registry_9;
        WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_SYSTEM_RUN_0_K175, _t_2);
        WL_IDX = 5;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_RUNNER_0)) {
        u64 _t_3 = task_node(e, FID_CONSUMER_EXPANDED_RUNNER_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _h_0;
        e.mem[_t_3 + 1] = _h_1;
        e.mem[_t_3 + 2] = _h_2;
        e.mem[_t_3 + 3] = _h_3;
        e.mem[_t_3 + 4] = _h_4;
        e.mem[_t_3 + 5] = _h_5;
        e.mem[_t_3 + 6] = _h_6;
        e.mem[_t_3 + 7] = _h_7;
        e.mem[_t_3 + 8] = _h_8;
        e.mem[_t_3 + 9] = _h_9;
        e.mem[_t_3 + 10] = _h_10;
        e.mem[_t_3 + 11] = _h_11;
        e.mem[_t_3 + 12] = _h_12;
        e.mem[_t_3 + 13] = _h_13;
        e.mem[_t_3 + 14] = _h_14;
        e.mem[_t_3 + 15] = _h_15;
        e.mem[_t_3 + 16] = _h_16;
        e.mem[_t_3 + 17] = _h_17;
        e.mem[_t_3 + 18] = _h_18;
        e.mem[_t_3 + 19] = _h_19;
        e.mem[_t_3 + 20] = _h_20;
        e.mem[_t_3 + 21] = _h_21;
        e.mem[_t_3 + 22] = _h_22;
        e.mem[_t_3 + 23] = _h_23;
        e.mem[_t_3 + 24] = _args_5;
        e.mem[_t_3 + 25] = _args_6;
        e.mem[_t_3 + 26] = _args_7;
        e.mem[_t_3 + 27] = _args_8;
        e.mem[_t_3 + 28] = _args_9;
        return term_tsk(FID_CONSUMER_EXPANDED_RUNNER_0, _t_3);
      }
      r0 = _h_0;
      r1 = _h_1;
      r2 = _h_2;
      r3 = _h_3;
      r4 = _h_4;
      r5 = _h_5;
      r6 = _h_6;
      r7 = _h_7;
      r8 = _h_8;
      r9 = _h_9;
      r10 = _h_10;
      r11 = _h_11;
      r12 = _h_12;
      r13 = _h_13;
      r14 = _h_14;
      r15 = _h_15;
      r16 = _h_16;
      r17 = _h_17;
      r18 = _h_18;
      r19 = _h_19;
      r20 = _h_20;
      r21 = _h_21;
      r22 = _h_22;
      r23 = _h_23;
      r24 = _args_5;
      r25 = _args_6;
      r26 = _args_7;
      r27 = _args_8;
      r28 = _args_9;
      WL_JMP(FID_CONSUMER_EXPANDED_RUNNER_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_SYSTEM_RUN_0_K175)
  {
    WL_POPN(5);
    u32 _registry_10 = STK(0);
    u32 _registry_11 = STK(1);
    Term _registry_12 = STK(2);
    Term _registry_13 = STK(3);
    u32 _registry_14 = STK(4);
    u32 _h_25 = r0;
    u32 _h_26 = r1;
    u32 _h_27 = r2;
    u32 _h_28 = r3;
    Term _h_29 = r4;
    u32 _h_30 = r5;
    Term _h_31 = r6;
    Term _h_32 = r7;
    Term _h_33 = r8;
    u32 _h_34 = r9;
    u32 _h_35 = r10;
    u32 _h_36 = r11;
    u32 _h_37 = r12;
    u32 _h_38 = r13;
    u32 _h_39 = r14;
    u32 _h_40 = r15;
    u32 _h_41 = r16;
    u32 _h_42 = r17;
    u32 _h_43 = r18;
    u32 _h_44 = r19;
    Term _h_45 = r20;
    Term _h_46 = r21;
    Term _h_47 = r22;
    u32 _h_48 = r23;
    u32 _h_49 = r24;
    Term _h_50 = r25;
    WL_OPEN
    u32 _v_75 = 0;
    u32 _v_76 = 0;
    u32 _v_77 = 0;
    Term _v_78 = 0;
    Term _v_79 = 0;
    u32 _v_80 = 0;
    u32 _v_81 = 0;
    u32 _v_82 = 0;
    u32 _v_83 = 0;
    Term _v_84 = 0;
    Term _v_85 = 0;
    Term _v_86 = 0;
    Term _v_87 = 0;
    Term _v_88 = 0;
    Term _v_89 = 0;
    u32 _v_90 = 0;
    u32 _v_91 = 0;
    u32 _v_92 = 0;
    u32 _v_93 = 0;
    u32 _v_94 = 0;
    u32 _v_95 = 0;
    u32 _v_96 = 0;
    u32 _v_97 = 0;
    u32 _v_98 = 0;
    u32 _v_99 = 0;
    Term _v_100 = 0;
    Term _v_101 = 0;
    Term _v_102 = 0;
    Term _v_103 = 0;
    u32 _v_104 = 0;
    u32 _v_105 = 0;
    Term _v_106 = 0;
    u32 _v_107 = 0;
    u32 _v_108 = 0;
    u32 _v_109 = 0;
    Term _o_1[35];
    if (spin_32(e, _o_1, _registry_10, _registry_11, _registry_12, blk_loc(e.mem, _registry_12), _registry_13, blk_loc(e.mem, _registry_13), _registry_14, _h_25, _h_26, _h_27, _h_28, _h_29, blk_loc(e.mem, _h_29), _h_30, _h_31, _h_32, blk_loc(e.mem, _h_32), _h_33, blk_loc(e.mem, _h_33), _h_34, _h_35, _h_36, _h_37, _h_38, _h_39, _h_40, _h_41, _h_42, _h_43, _h_44, _h_45, blk_loc(e.mem, _h_45), _h_46, blk_loc(e.mem, _h_46), _h_47, blk_loc(e.mem, _h_47), _h_48, _h_49, _h_50, blk_loc(e.mem, _h_50)) == 0) {
      return 0;
    }
    _v_75 = _o_1[0];
    _v_76 = _o_1[1];
    _v_77 = _o_1[2];
    _v_78 = _o_1[3];
    _v_79 = _o_1[4];
    _v_80 = _o_1[5];
    _v_81 = _o_1[6];
    _v_82 = _o_1[7];
    _v_83 = _o_1[8];
    _v_84 = _o_1[9];
    _v_85 = _o_1[10];
    _v_86 = _o_1[11];
    _v_87 = _o_1[12];
    _v_88 = _o_1[13];
    _v_89 = _o_1[14];
    _v_90 = _o_1[15];
    _v_91 = _o_1[16];
    _v_92 = _o_1[17];
    _v_93 = _o_1[18];
    _v_94 = _o_1[19];
    _v_95 = _o_1[20];
    _v_96 = _o_1[21];
    _v_97 = _o_1[22];
    _v_98 = _o_1[23];
    _v_99 = _o_1[24];
    _v_100 = _o_1[25];
    _v_101 = _o_1[26];
    _v_102 = _o_1[27];
    _v_103 = _o_1[28];
    _v_104 = _o_1[29];
    _v_105 = _o_1[30];
    _v_106 = _o_1[31];
    _v_107 = _o_1[32];
    _v_108 = _o_1[33];
    _v_109 = _o_1[34];
    r0 = _v_75;
    r1 = _v_76;
    r2 = _v_77;
    r3 = _v_78;
    r4 = _v_79;
    r5 = _v_80;
    r6 = _v_81;
    r7 = _v_82;
    r8 = _v_83;
    r9 = _v_84;
    r10 = _v_85;
    r11 = _v_86;
    r12 = _v_87;
    r13 = _v_88;
    r14 = _v_89;
    r15 = _v_90;
    r16 = _v_91;
    r17 = _v_92;
    r18 = _v_93;
    r19 = _v_94;
    r20 = _v_95;
    r21 = _v_96;
    r22 = _v_97;
    r23 = _v_98;
    r24 = _v_99;
    r25 = _v_100;
    r26 = _v_101;
    r27 = _v_102;
    r28 = _v_103;
    r29 = _v_104;
    r30 = _v_105;
    r31 = _v_106;
    r32 = _v_107;
    r33 = _v_108;
    r34 = _v_109;
    WL_RETN(35);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_0)
  {
    Term _value_0 = r0;
    WL_OPEN
    WL_SPIN
    if (blk_cls(_value_0) == 0) {
      u32 _c_0 = blk_read(e.mem, 0, blk_loc(e.mem, _value_0), 0 + 0);
      blk_free(e, _value_0);
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_CONSUMER_EXPANDED_TREE_0_K184;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_CONSUMER_EXPANDED_TREE_0_K184, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_0_K184, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_NUMBER)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_EXPANDED_NUMBER, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _c_0;
        return term_tsk(FID_CONSUMER_EXPANDED_NUMBER, _t_1);
      }
      r0 = _c_0;
      WL_JMP(FID_CONSUMER_EXPANDED_NUMBER);
    } else {
      Term _h_6 = blk_half(e, _value_0, 0);
      Term _h_7 = blk_half(e, _value_0, 1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _h_6;
        STK(1) = FID_CONSUMER_EXPANDED_TREE_0_K187;
        WL_PUSHN(2);
      } else {
        u64 _t_6 = task_node(e, FID_CONSUMER_EXPANDED_TREE_0_K187, WL_CONT, WL_IDX, 1);
        e.mem[_t_6 + 0] = _h_6;
        WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_0_K187, _t_6);
        WL_IDX = 1;
      }
      r0 = _h_7;
      _value_0 = r0;
      WL_AGAIN(FID_CONSUMER_EXPANDED_TREE_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_0_K184)
  {
    u32 _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_CONSUMER_EXPANDED_TREE_0_K185;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_EXPANDED_TREE_0_K185, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_0_K185, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_1;
      e.mem[_t_3 + 1] = term_ctr(CID_SCON, STAT_OFF + 50);
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _h_1;
    r1 = term_ctr(CID_SCON, STAT_OFF + 50);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_0_K185)
  {
    WL_POPN(1);
    u32 _h_3 = STK(0);
    Term _h_2 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_3;
      STK(1) = FID_CONSUMER_EXPANDED_TREE_0_K186;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_CONSUMER_EXPANDED_TREE_0_K186, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_3;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_0_K186, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 96);
      e.mem[_t_5 + 1] = _h_2;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 96);
    r1 = _h_2;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_0_K186)
  {
    WL_POPN(1);
    u32 _h_5 = STK(0);
    Term _h_4 = r0;
    WL_OPEN
    Term _fv_0[1];
    _fv_0[0] = _h_5;
    r0 = blk_new(e, 0, 0, 0, 1, _fv_0);
    r1 = _h_4;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_0_K187)
  {
    WL_POPN(1);
    Term _h_10 = STK(0);
    Term _h_8 = r0;
    Term _h_9 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_8;
      STK(1) = _h_9;
      STK(2) = FID_CONSUMER_EXPANDED_TREE_0_K188;
      WL_PUSHN(3);
    } else {
      u64 _t_7 = task_node(e, FID_CONSUMER_EXPANDED_TREE_0_K188, WL_CONT, WL_IDX, 1);
      e.mem[_t_7 + 0] = _h_8;
      e.mem[_t_7 + 1] = _h_9;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_0_K188, _t_7);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_TREE_0)) {
      u64 _t_8 = task_node(e, FID_CONSUMER_EXPANDED_TREE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _h_10;
      return term_tsk(FID_CONSUMER_EXPANDED_TREE_0, _t_8);
    }
    r0 = _h_10;
    WL_JMP(FID_CONSUMER_EXPANDED_TREE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_0_K188)
  {
    WL_POPN(2);
    Term _h_13 = STK(0);
    Term _h_14 = STK(1);
    Term _h_11 = r0;
    Term _h_12 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_11;
      STK(1) = _h_12;
      STK(2) = _h_13;
      STK(3) = FID_CONSUMER_EXPANDED_TREE_0_K189;
      WL_PUSHN(4);
    } else {
      u64 _t_9 = task_node(e, FID_CONSUMER_EXPANDED_TREE_0_K189, WL_CONT, WL_IDX, 1);
      e.mem[_t_9 + 0] = _h_11;
      e.mem[_t_9 + 1] = _h_12;
      e.mem[_t_9 + 2] = _h_13;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_0_K189, _t_9);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_10 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = _h_14;
      e.mem[_t_10 + 1] = term_ctr(CID_SCON, STAT_OFF + 50);
      return term_tsk(FID_STRING_APPEND, _t_10);
    }
    r0 = _h_14;
    r1 = term_ctr(CID_SCON, STAT_OFF + 50);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_0_K189)
  {
    WL_POPN(3);
    Term _h_16 = STK(0);
    Term _h_17 = STK(1);
    Term _h_18 = STK(2);
    Term _h_15 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_16;
      STK(1) = _h_17;
      STK(2) = _h_18;
      STK(3) = FID_CONSUMER_EXPANDED_TREE_0_K190;
      WL_PUSHN(4);
    } else {
      u64 _t_11 = task_node(e, FID_CONSUMER_EXPANDED_TREE_0_K190, WL_CONT, WL_IDX, 1);
      e.mem[_t_11 + 0] = _h_16;
      e.mem[_t_11 + 1] = _h_17;
      e.mem[_t_11 + 2] = _h_18;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_0_K190, _t_11);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_12 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = term_ctr(CID_SCON, STAT_OFF + 52);
      e.mem[_t_12 + 1] = _h_15;
      return term_tsk(FID_STRING_APPEND, _t_12);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 52);
    r1 = _h_15;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_0_K190)
  {
    WL_POPN(3);
    Term _h_20 = STK(0);
    Term _h_21 = STK(1);
    Term _h_22 = STK(2);
    Term _h_19 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_20;
      STK(1) = _h_22;
      STK(2) = FID_CONSUMER_EXPANDED_TREE_0_K191;
      WL_PUSHN(3);
    } else {
      u64 _t_13 = task_node(e, FID_CONSUMER_EXPANDED_TREE_0_K191, WL_CONT, WL_IDX, 1);
      e.mem[_t_13 + 0] = _h_20;
      e.mem[_t_13 + 1] = _h_22;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_0_K191, _t_13);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_14 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_14 + 0] = _h_21;
      e.mem[_t_14 + 1] = _h_19;
      return term_tsk(FID_STRING_APPEND, _t_14);
    }
    r0 = _h_21;
    r1 = _h_19;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_0_K191)
  {
    WL_POPN(2);
    Term _h_24 = STK(0);
    Term _h_25 = STK(1);
    Term _h_23 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_24;
      STK(1) = _h_25;
      STK(2) = FID_CONSUMER_EXPANDED_TREE_0_K192;
      WL_PUSHN(3);
    } else {
      u64 _t_15 = task_node(e, FID_CONSUMER_EXPANDED_TREE_0_K192, WL_CONT, WL_IDX, 1);
      e.mem[_t_15 + 0] = _h_24;
      e.mem[_t_15 + 1] = _h_25;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_0_K192, _t_15);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_16 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_16 + 0] = term_ctr(CID_SCON, STAT_OFF + 56);
      e.mem[_t_16 + 1] = _h_23;
      return term_tsk(FID_STRING_APPEND, _t_16);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 56);
    r1 = _h_23;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_0_K192)
  {
    WL_POPN(2);
    Term _h_27 = STK(0);
    Term _h_28 = STK(1);
    Term _h_26 = r0;
    WL_OPEN
    r0 = blk_node(e, _h_27, _h_28);
    r1 = _h_26;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_2)
  {
    Term _value_0 = r0;
    WL_OPEN
    WL_SPIN
    if (blk_cls(_value_0) == 0) {
      Term _c_0 = blk_shr(_value_0) ? blk_keep(e, blk_loc(e.mem, _value_0) + 0 + 0) : e.mem[blk_loc(e.mem, _value_0) + 0 + 0];
      blk_free(e, _value_0);
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_CONSUMER_EXPANDED_TREE_2_K194;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_CONSUMER_EXPANDED_TREE_2_K194, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_2_K194, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_PAYLOAD)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_EXPANDED_PAYLOAD, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _c_0;
        return term_tsk(FID_CONSUMER_EXPANDED_PAYLOAD, _t_1);
      }
      r0 = _c_0;
      WL_JMP(FID_CONSUMER_EXPANDED_PAYLOAD);
    } else {
      Term _h_6 = blk_half(e, _value_0, 0);
      Term _h_7 = blk_half(e, _value_0, 1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _h_6;
        STK(1) = FID_CONSUMER_EXPANDED_TREE_2_K197;
        WL_PUSHN(2);
      } else {
        u64 _t_6 = task_node(e, FID_CONSUMER_EXPANDED_TREE_2_K197, WL_CONT, WL_IDX, 1);
        e.mem[_t_6 + 0] = _h_6;
        WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_2_K197, _t_6);
        WL_IDX = 1;
      }
      r0 = _h_7;
      _value_0 = r0;
      WL_AGAIN(FID_CONSUMER_EXPANDED_TREE_2);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_2_K194)
  {
    Term _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_CONSUMER_EXPANDED_TREE_2_K195;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_EXPANDED_TREE_2_K195, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_2_K195, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_1;
      e.mem[_t_3 + 1] = term_ctr(CID_SCON, STAT_OFF + 50);
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _h_1;
    r1 = term_ctr(CID_SCON, STAT_OFF + 50);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_2_K195)
  {
    WL_POPN(1);
    Term _h_3 = STK(0);
    Term _h_2 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_3;
      STK(1) = FID_CONSUMER_EXPANDED_TREE_2_K196;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_CONSUMER_EXPANDED_TREE_2_K196, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_3;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_2_K196, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 96);
      e.mem[_t_5 + 1] = _h_2;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 96);
    r1 = _h_2;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_2_K196)
  {
    WL_POPN(1);
    Term _h_5 = STK(0);
    Term _h_4 = r0;
    WL_OPEN
    Term _fv_0[1];
    _fv_0[0] = _h_5;
    r0 = blk_new(e, 1, 0, 0, 1, _fv_0);
    r1 = _h_4;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_2_K197)
  {
    WL_POPN(1);
    Term _h_10 = STK(0);
    Term _h_8 = r0;
    Term _h_9 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_8;
      STK(1) = _h_9;
      STK(2) = FID_CONSUMER_EXPANDED_TREE_2_K198;
      WL_PUSHN(3);
    } else {
      u64 _t_7 = task_node(e, FID_CONSUMER_EXPANDED_TREE_2_K198, WL_CONT, WL_IDX, 1);
      e.mem[_t_7 + 0] = _h_8;
      e.mem[_t_7 + 1] = _h_9;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_2_K198, _t_7);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_TREE_2)) {
      u64 _t_8 = task_node(e, FID_CONSUMER_EXPANDED_TREE_2, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _h_10;
      return term_tsk(FID_CONSUMER_EXPANDED_TREE_2, _t_8);
    }
    r0 = _h_10;
    WL_JMP(FID_CONSUMER_EXPANDED_TREE_2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_2_K198)
  {
    WL_POPN(2);
    Term _h_13 = STK(0);
    Term _h_14 = STK(1);
    Term _h_11 = r0;
    Term _h_12 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_11;
      STK(1) = _h_12;
      STK(2) = _h_13;
      STK(3) = FID_CONSUMER_EXPANDED_TREE_2_K199;
      WL_PUSHN(4);
    } else {
      u64 _t_9 = task_node(e, FID_CONSUMER_EXPANDED_TREE_2_K199, WL_CONT, WL_IDX, 1);
      e.mem[_t_9 + 0] = _h_11;
      e.mem[_t_9 + 1] = _h_12;
      e.mem[_t_9 + 2] = _h_13;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_2_K199, _t_9);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_10 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = _h_14;
      e.mem[_t_10 + 1] = term_ctr(CID_SCON, STAT_OFF + 50);
      return term_tsk(FID_STRING_APPEND, _t_10);
    }
    r0 = _h_14;
    r1 = term_ctr(CID_SCON, STAT_OFF + 50);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_2_K199)
  {
    WL_POPN(3);
    Term _h_16 = STK(0);
    Term _h_17 = STK(1);
    Term _h_18 = STK(2);
    Term _h_15 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_16;
      STK(1) = _h_17;
      STK(2) = _h_18;
      STK(3) = FID_CONSUMER_EXPANDED_TREE_2_K200;
      WL_PUSHN(4);
    } else {
      u64 _t_11 = task_node(e, FID_CONSUMER_EXPANDED_TREE_2_K200, WL_CONT, WL_IDX, 1);
      e.mem[_t_11 + 0] = _h_16;
      e.mem[_t_11 + 1] = _h_17;
      e.mem[_t_11 + 2] = _h_18;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_2_K200, _t_11);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_12 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = term_ctr(CID_SCON, STAT_OFF + 52);
      e.mem[_t_12 + 1] = _h_15;
      return term_tsk(FID_STRING_APPEND, _t_12);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 52);
    r1 = _h_15;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_2_K200)
  {
    WL_POPN(3);
    Term _h_20 = STK(0);
    Term _h_21 = STK(1);
    Term _h_22 = STK(2);
    Term _h_19 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_20;
      STK(1) = _h_22;
      STK(2) = FID_CONSUMER_EXPANDED_TREE_2_K201;
      WL_PUSHN(3);
    } else {
      u64 _t_13 = task_node(e, FID_CONSUMER_EXPANDED_TREE_2_K201, WL_CONT, WL_IDX, 1);
      e.mem[_t_13 + 0] = _h_20;
      e.mem[_t_13 + 1] = _h_22;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_2_K201, _t_13);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_14 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_14 + 0] = _h_21;
      e.mem[_t_14 + 1] = _h_19;
      return term_tsk(FID_STRING_APPEND, _t_14);
    }
    r0 = _h_21;
    r1 = _h_19;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_2_K201)
  {
    WL_POPN(2);
    Term _h_24 = STK(0);
    Term _h_25 = STK(1);
    Term _h_23 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_24;
      STK(1) = _h_25;
      STK(2) = FID_CONSUMER_EXPANDED_TREE_2_K202;
      WL_PUSHN(3);
    } else {
      u64 _t_15 = task_node(e, FID_CONSUMER_EXPANDED_TREE_2_K202, WL_CONT, WL_IDX, 1);
      e.mem[_t_15 + 0] = _h_24;
      e.mem[_t_15 + 1] = _h_25;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_2_K202, _t_15);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_16 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_16 + 0] = term_ctr(CID_SCON, STAT_OFF + 56);
      e.mem[_t_16 + 1] = _h_23;
      return term_tsk(FID_STRING_APPEND, _t_16);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 56);
    r1 = _h_23;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_2_K202)
  {
    WL_POPN(2);
    Term _h_27 = STK(0);
    Term _h_28 = STK(1);
    Term _h_26 = r0;
    WL_OPEN
    r0 = blk_node(e, _h_27, _h_28);
    r1 = _h_26;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_1)
  {
    Term _value_0 = r0;
    WL_OPEN
    WL_SPIN
    if (blk_cls(_value_0) == 0) {
      u32 _c_0 = blk_read(e.mem, 0, blk_loc(e.mem, _value_0), 0 + 0);
      blk_free(e, _value_0);
      u32 _v_0 = 0;
      Term _v_1 = 0;
      u32 _v_2 = 0;
      Term _v_3 = 0;
      Term _o_1[2];
      if (spin_45(e, _o_1, _c_0) == 0) {
        return 0;
      }
      _v_2 = _o_1[0];
      _v_3 = _o_1[1];
      _v_0 = _v_2;
      _v_1 = _v_3;
      if (seq) {
        WL_ROOM(2);
        STK(0) = _v_0;
        STK(1) = FID_CONSUMER_EXPANDED_TREE_1_K204;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_CONSUMER_EXPANDED_TREE_1_K204, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _v_0;
        WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_1_K204, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
        u64 _t_1 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _v_1;
        e.mem[_t_1 + 1] = term_ctr(CID_SCON, STAT_OFF + 50);
        return term_tsk(FID_STRING_APPEND, _t_1);
      }
      r0 = _v_1;
      r1 = term_ctr(CID_SCON, STAT_OFF + 50);
      WL_JMP(FID_STRING_APPEND);
    } else {
      Term _h_2 = blk_half(e, _value_0, 0);
      Term _h_3 = blk_half(e, _value_0, 1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _h_2;
        STK(1) = FID_CONSUMER_EXPANDED_TREE_1_K206;
        WL_PUSHN(2);
      } else {
        u64 _t_4 = task_node(e, FID_CONSUMER_EXPANDED_TREE_1_K206, WL_CONT, WL_IDX, 1);
        e.mem[_t_4 + 0] = _h_2;
        WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_1_K206, _t_4);
        WL_IDX = 1;
      }
      r0 = _h_3;
      _value_0 = r0;
      WL_AGAIN(FID_CONSUMER_EXPANDED_TREE_1);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_1_K204)
  {
    WL_POPN(1);
    u32 _v_8 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _v_8;
      STK(1) = FID_CONSUMER_EXPANDED_TREE_1_K205;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_EXPANDED_TREE_1_K205, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _v_8;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_1_K205, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 96);
      e.mem[_t_3 + 1] = _h_0;
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 96);
    r1 = _h_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_1_K205)
  {
    WL_POPN(1);
    u32 _v_9 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    Term _fv_0[1];
    _fv_0[0] = _v_9;
    r0 = blk_new(e, 0, 0, 0, 1, _fv_0);
    r1 = _h_1;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_1_K206)
  {
    WL_POPN(1);
    Term _h_6 = STK(0);
    Term _h_4 = r0;
    Term _h_5 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_4;
      STK(1) = _h_5;
      STK(2) = FID_CONSUMER_EXPANDED_TREE_1_K207;
      WL_PUSHN(3);
    } else {
      u64 _t_5 = task_node(e, FID_CONSUMER_EXPANDED_TREE_1_K207, WL_CONT, WL_IDX, 1);
      e.mem[_t_5 + 0] = _h_4;
      e.mem[_t_5 + 1] = _h_5;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_1_K207, _t_5);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_TREE_1)) {
      u64 _t_6 = task_node(e, FID_CONSUMER_EXPANDED_TREE_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _h_6;
      return term_tsk(FID_CONSUMER_EXPANDED_TREE_1, _t_6);
    }
    r0 = _h_6;
    WL_JMP(FID_CONSUMER_EXPANDED_TREE_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_1_K207)
  {
    WL_POPN(2);
    Term _h_9 = STK(0);
    Term _h_10 = STK(1);
    Term _h_7 = r0;
    Term _h_8 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_7;
      STK(1) = _h_8;
      STK(2) = _h_9;
      STK(3) = FID_CONSUMER_EXPANDED_TREE_1_K208;
      WL_PUSHN(4);
    } else {
      u64 _t_7 = task_node(e, FID_CONSUMER_EXPANDED_TREE_1_K208, WL_CONT, WL_IDX, 1);
      e.mem[_t_7 + 0] = _h_7;
      e.mem[_t_7 + 1] = _h_8;
      e.mem[_t_7 + 2] = _h_9;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_1_K208, _t_7);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_8 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _h_10;
      e.mem[_t_8 + 1] = term_ctr(CID_SCON, STAT_OFF + 50);
      return term_tsk(FID_STRING_APPEND, _t_8);
    }
    r0 = _h_10;
    r1 = term_ctr(CID_SCON, STAT_OFF + 50);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_1_K208)
  {
    WL_POPN(3);
    Term _h_12 = STK(0);
    Term _h_13 = STK(1);
    Term _h_14 = STK(2);
    Term _h_11 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_12;
      STK(1) = _h_13;
      STK(2) = _h_14;
      STK(3) = FID_CONSUMER_EXPANDED_TREE_1_K209;
      WL_PUSHN(4);
    } else {
      u64 _t_9 = task_node(e, FID_CONSUMER_EXPANDED_TREE_1_K209, WL_CONT, WL_IDX, 1);
      e.mem[_t_9 + 0] = _h_12;
      e.mem[_t_9 + 1] = _h_13;
      e.mem[_t_9 + 2] = _h_14;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_1_K209, _t_9);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_10 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = term_ctr(CID_SCON, STAT_OFF + 52);
      e.mem[_t_10 + 1] = _h_11;
      return term_tsk(FID_STRING_APPEND, _t_10);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 52);
    r1 = _h_11;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_1_K209)
  {
    WL_POPN(3);
    Term _h_16 = STK(0);
    Term _h_17 = STK(1);
    Term _h_18 = STK(2);
    Term _h_15 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_16;
      STK(1) = _h_18;
      STK(2) = FID_CONSUMER_EXPANDED_TREE_1_K210;
      WL_PUSHN(3);
    } else {
      u64 _t_11 = task_node(e, FID_CONSUMER_EXPANDED_TREE_1_K210, WL_CONT, WL_IDX, 1);
      e.mem[_t_11 + 0] = _h_16;
      e.mem[_t_11 + 1] = _h_18;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_1_K210, _t_11);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_12 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = _h_17;
      e.mem[_t_12 + 1] = _h_15;
      return term_tsk(FID_STRING_APPEND, _t_12);
    }
    r0 = _h_17;
    r1 = _h_15;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_1_K210)
  {
    WL_POPN(2);
    Term _h_20 = STK(0);
    Term _h_21 = STK(1);
    Term _h_19 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_20;
      STK(1) = _h_21;
      STK(2) = FID_CONSUMER_EXPANDED_TREE_1_K211;
      WL_PUSHN(3);
    } else {
      u64 _t_13 = task_node(e, FID_CONSUMER_EXPANDED_TREE_1_K211, WL_CONT, WL_IDX, 1);
      e.mem[_t_13 + 0] = _h_20;
      e.mem[_t_13 + 1] = _h_21;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_TREE_1_K211, _t_13);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_14 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_14 + 0] = term_ctr(CID_SCON, STAT_OFF + 56);
      e.mem[_t_14 + 1] = _h_19;
      return term_tsk(FID_STRING_APPEND, _t_14);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 56);
    r1 = _h_19;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_TREE_1_K211)
  {
    WL_POPN(2);
    Term _h_23 = STK(0);
    Term _h_24 = STK(1);
    Term _h_22 = r0;
    WL_OPEN
    r0 = blk_node(e, _h_23, _h_24);
    r1 = _h_22;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_COMMANDS_0)
  {
    Term _items_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_items_0) == CID_NIL) {
      r0 = term_pak(CID_NIL, 0);
      r1 = 0;
      WL_RETN(2);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _items_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_CONSUMER_EXPANDED_COMMANDS_0_K213;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_CONSUMER_EXPANDED_COMMANDS_0_K213, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_COMMANDS_0_K213, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      _items_0 = r0;
      WL_AGAIN(FID_CONSUMER_EXPANDED_COMMANDS_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_COMMANDS_0_K213)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[2];
    if (spin_46(e, _o_0, _f_2, blk_loc(e.mem, _f_2), _h_0, blk_loc(e.mem, _h_0), _h_1) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    r0 = _v_0;
    r1 = _v_1;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_0)
  {
    Term _xs_0 = r0;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 98);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_LIST_SHOW_0_K254;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_0_K254, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_LIST_SHOW_0_K254, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_GO_0)) {
        u64 _t_1 = task_node(e, FID_LIST_SHOW_GO_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_1;
        return term_tsk(FID_LIST_SHOW_GO_0, _t_1);
      }
      r0 = _f_1;
      WL_JMP(FID_LIST_SHOW_GO_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_0_K254)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_0_K255;
      WL_PUSHN(1);
    } else {
      u64 _t_2 = task_node(e, FID_LIST_SHOW_0_K255, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_0_K255, _t_2);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_2;
      e.mem[_t_3 + 1] = _h_0;
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _f_2;
    r1 = _h_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_0_K255)
  {
    Term _h_1 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_4 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_4 + 0] = term_ctr(CID_SCON, STAT_OFF + 100);
      e.mem[_t_4 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_4);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 100);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW)
  {
    u32 _a_0 = r0;
    WL_OPEN
    u32 _s_0 = U32_BIN(_a_0, ==, 0);
    if (_s_0 == 1) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 152);
      WL_RETN(1);
    } else {
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW_GO)) {
        u64 _t_0 = task_node(e, FID_U32_SHOW_GO, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = 10ull;
        e.mem[_t_0 + 1] = _a_0;
        e.mem[_t_0 + 2] = term_pak(CID_SNIL, 0);
        return term_tsk(FID_U32_SHOW_GO, _t_0);
      }
      r0 = 10ull;
      r1 = _a_0;
      r2 = term_pak(CID_SNIL, 0);
      WL_JMP(FID_U32_SHOW_GO);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_SYSTEM_RUN_TRACKED_0)
  {
    u32 _registry_0 = r0;
    u32 _registry_1 = r1;
    Term _registry_2 = r2;
    Term _registry_3 = r3;
    u32 _registry_4 = r4;
    u32 _world_0 = r5;
    u32 _world_1 = r6;
    u32 _world_2 = r7;
    Term _world_3 = r8;
    u32 _world_4 = r9;
    Term _world_5 = r10;
    Term _world_6 = r11;
    Term _world_7 = r12;
    u32 _world_8 = r13;
    u32 _world_9 = r14;
    u32 _world_10 = r15;
    u32 _world_11 = r16;
    u32 _world_12 = r17;
    u32 _world_13 = r18;
    u32 _world_14 = r19;
    u32 _world_15 = r20;
    u32 _world_16 = r21;
    u32 _world_17 = r22;
    u32 _world_18 = r23;
    Term _world_19 = r24;
    Term _world_20 = r25;
    Term _world_21 = r26;
    u32 _world_22 = r27;
    u32 _world_23 = r28;
    u32 _args_0 = r29;
    u32 _args_1 = r30;
    u32 _args_2 = r31;
    u32 _args_3 = r32;
    u32 _args_4 = r33;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID________________BENDVY_SRC_ECS_SYSTEM_RUN_TRACKED_0_K258;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_SYSTEM_RUN_TRACKED_0_K258, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_SYSTEM_RUN_TRACKED_0_K258, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_SYSTEM_RUN_0)) {
      u64 _t_1 = task_node(e, FID________________BENDVY_SRC_ECS_SYSTEM_RUN_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _registry_0;
      e.mem[_t_1 + 1] = _registry_1;
      e.mem[_t_1 + 2] = _registry_2;
      e.mem[_t_1 + 3] = _registry_3;
      e.mem[_t_1 + 4] = _registry_4;
      e.mem[_t_1 + 5] = _world_0;
      e.mem[_t_1 + 6] = _world_1;
      e.mem[_t_1 + 7] = _world_2;
      e.mem[_t_1 + 8] = _world_3;
      e.mem[_t_1 + 9] = _world_4;
      e.mem[_t_1 + 10] = _world_5;
      e.mem[_t_1 + 11] = _world_6;
      e.mem[_t_1 + 12] = _world_7;
      e.mem[_t_1 + 13] = _world_8;
      e.mem[_t_1 + 14] = _world_9;
      e.mem[_t_1 + 15] = _world_10;
      e.mem[_t_1 + 16] = _world_11;
      e.mem[_t_1 + 17] = _world_12;
      e.mem[_t_1 + 18] = _world_13;
      e.mem[_t_1 + 19] = _world_14;
      e.mem[_t_1 + 20] = _world_15;
      e.mem[_t_1 + 21] = _world_16;
      e.mem[_t_1 + 22] = _world_17;
      e.mem[_t_1 + 23] = _world_18;
      e.mem[_t_1 + 24] = _world_19;
      e.mem[_t_1 + 25] = _world_20;
      e.mem[_t_1 + 26] = _world_21;
      e.mem[_t_1 + 27] = _world_22;
      e.mem[_t_1 + 28] = _world_23;
      e.mem[_t_1 + 29] = _args_0;
      e.mem[_t_1 + 30] = _args_1;
      e.mem[_t_1 + 31] = _args_2;
      e.mem[_t_1 + 32] = _args_3;
      e.mem[_t_1 + 33] = _args_4;
      return term_tsk(FID________________BENDVY_SRC_ECS_SYSTEM_RUN_0, _t_1);
    }
    r0 = _registry_0;
    r1 = _registry_1;
    r2 = _registry_2;
    r3 = _registry_3;
    r4 = _registry_4;
    r5 = _world_0;
    r6 = _world_1;
    r7 = _world_2;
    r8 = _world_3;
    r9 = _world_4;
    r10 = _world_5;
    r11 = _world_6;
    r12 = _world_7;
    r13 = _world_8;
    r14 = _world_9;
    r15 = _world_10;
    r16 = _world_11;
    r17 = _world_12;
    r18 = _world_13;
    r19 = _world_14;
    r20 = _world_15;
    r21 = _world_16;
    r22 = _world_17;
    r23 = _world_18;
    r24 = _world_19;
    r25 = _world_20;
    r26 = _world_21;
    r27 = _world_22;
    r28 = _world_23;
    r29 = _args_0;
    r30 = _args_1;
    r31 = _args_2;
    r32 = _args_3;
    r33 = _args_4;
    WL_JMP(FID________________BENDVY_SRC_ECS_SYSTEM_RUN_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_SYSTEM_RUN_TRACKED_0_K258)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    u32 _h_5 = r5;
    u32 _h_6 = r6;
    u32 _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    Term _h_10 = r10;
    Term _h_11 = r11;
    Term _h_12 = r12;
    Term _h_13 = r13;
    Term _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    u32 _h_19 = r19;
    u32 _h_20 = r20;
    u32 _h_21 = r21;
    u32 _h_22 = r22;
    u32 _h_23 = r23;
    u32 _h_24 = r24;
    Term _h_25 = r25;
    Term _h_26 = r26;
    Term _h_27 = r27;
    Term _h_28 = r28;
    u32 _h_29 = r29;
    u32 _h_30 = r30;
    Term _h_31 = r31;
    u32 _h_32 = r32;
    u32 _h_33 = r33;
    u32 _h_34 = r34;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    u32 _v_7 = 0;
    u32 _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    u32 _v_19 = 0;
    u32 _v_20 = 0;
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    Term _v_25 = 0;
    Term _v_26 = 0;
    Term _v_27 = 0;
    Term _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    Term _v_31 = 0;
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    Term _o_1[35];
    if (spin_47(e, _o_1, _h_0, _h_1, _h_2, _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, _h_6, _h_7, _h_8, _h_9, blk_loc(e.mem, _h_9), _h_10, blk_loc(e.mem, _h_10), _h_11, _h_12, blk_loc(e.mem, _h_12), _h_13, blk_loc(e.mem, _h_13), _h_14, blk_loc(e.mem, _h_14), _h_15, _h_16, _h_17, _h_18, _h_19, _h_20, _h_21, _h_22, _h_23, _h_24, _h_25, blk_loc(e.mem, _h_25), _h_26, blk_loc(e.mem, _h_26), _h_27, blk_loc(e.mem, _h_27), _h_28, blk_loc(e.mem, _h_28), _h_29, _h_30, _h_31, blk_loc(e.mem, _h_31), _h_32, _h_33, _h_34) == 0) {
      return 0;
    }
    _v_0 = _o_1[0];
    _v_1 = _o_1[1];
    _v_2 = _o_1[2];
    _v_3 = _o_1[3];
    _v_4 = _o_1[4];
    _v_5 = _o_1[5];
    _v_6 = _o_1[6];
    _v_7 = _o_1[7];
    _v_8 = _o_1[8];
    _v_9 = _o_1[9];
    _v_10 = _o_1[10];
    _v_11 = _o_1[11];
    _v_12 = _o_1[12];
    _v_13 = _o_1[13];
    _v_14 = _o_1[14];
    _v_15 = _o_1[15];
    _v_16 = _o_1[16];
    _v_17 = _o_1[17];
    _v_18 = _o_1[18];
    _v_19 = _o_1[19];
    _v_20 = _o_1[20];
    _v_21 = _o_1[21];
    _v_22 = _o_1[22];
    _v_23 = _o_1[23];
    _v_24 = _o_1[24];
    _v_25 = _o_1[25];
    _v_26 = _o_1[26];
    _v_27 = _o_1[27];
    _v_28 = _o_1[28];
    _v_29 = _o_1[29];
    _v_30 = _o_1[30];
    _v_31 = _o_1[31];
    _v_32 = _o_1[32];
    _v_33 = _o_1[33];
    _v_34 = _o_1[34];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = _v_16;
    r17 = _v_17;
    r18 = _v_18;
    r19 = _v_19;
    r20 = _v_20;
    r21 = _v_21;
    r22 = _v_22;
    r23 = _v_23;
    r24 = _v_24;
    r25 = _v_25;
    r26 = _v_26;
    r27 = _v_27;
    r28 = _v_28;
    r29 = _v_29;
    r30 = _v_30;
    r31 = _v_31;
    r32 = _v_32;
    r33 = _v_33;
    r34 = _v_34;
    WL_RETN(35);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    u32 _world_2 = r2;
    Term _world_3 = r3;
    u32 _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    u32 _world_9 = r9;
    u32 _world_10 = r10;
    u32 _world_11 = r11;
    u32 _world_12 = r12;
    u32 _world_13 = r13;
    u32 _world_14 = r14;
    u32 _world_15 = r15;
    u32 _world_16 = r16;
    u32 _world_17 = r17;
    u32 _world_18 = r18;
    Term _world_19 = r19;
    Term _world_20 = r20;
    Term _world_21 = r21;
    u32 _world_22 = r22;
    u32 _world_23 = r23;
    WL_OPEN
    if (seq) {
      WL_ROOM(24);
      STK(0) = _world_0;
      STK(1) = _world_1;
      STK(2) = _world_2;
      STK(3) = _world_3;
      STK(4) = _world_4;
      STK(5) = _world_5;
      STK(6) = _world_6;
      STK(7) = _world_7;
      STK(8) = _world_8;
      STK(9) = _world_9;
      STK(10) = _world_10;
      STK(11) = _world_11;
      STK(12) = _world_12;
      STK(13) = _world_13;
      STK(14) = _world_14;
      STK(15) = _world_15;
      STK(16) = _world_16;
      STK(17) = _world_17;
      STK(18) = _world_18;
      STK(19) = _world_19;
      STK(20) = _world_21;
      STK(21) = _world_22;
      STK(22) = _world_23;
      STK(23) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K265;
      WL_PUSHN(24);
    } else {
      u64 _t_0 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K265, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _world_0;
      e.mem[_t_0 + 1] = _world_1;
      e.mem[_t_0 + 2] = _world_2;
      e.mem[_t_0 + 3] = _world_3;
      e.mem[_t_0 + 4] = _world_4;
      e.mem[_t_0 + 5] = _world_5;
      e.mem[_t_0 + 6] = _world_6;
      e.mem[_t_0 + 7] = _world_7;
      e.mem[_t_0 + 8] = _world_8;
      e.mem[_t_0 + 9] = _world_9;
      e.mem[_t_0 + 10] = _world_10;
      e.mem[_t_0 + 11] = _world_11;
      e.mem[_t_0 + 12] = _world_12;
      e.mem[_t_0 + 13] = _world_13;
      e.mem[_t_0 + 14] = _world_14;
      e.mem[_t_0 + 15] = _world_15;
      e.mem[_t_0 + 16] = _world_16;
      e.mem[_t_0 + 17] = _world_17;
      e.mem[_t_0 + 18] = _world_18;
      e.mem[_t_0 + 19] = _world_19;
      e.mem[_t_0 + 20] = _world_21;
      e.mem[_t_0 + 21] = _world_22;
      e.mem[_t_0 + 22] = _world_23;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K265, _t_0);
      WL_IDX = 23;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_COMMANDS_0)) {
      u64 _t_1 = task_node(e, FID_CONSUMER_EXPANDED_COMMANDS_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_20;
      return term_tsk(FID_CONSUMER_EXPANDED_COMMANDS_0, _t_1);
    }
    r0 = _world_20;
    WL_JMP(FID_CONSUMER_EXPANDED_COMMANDS_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K265)
  {
    WL_POPN(23);
    u32 _world_24 = STK(0);
    u32 _world_25 = STK(1);
    u32 _world_26 = STK(2);
    Term _world_27 = STK(3);
    u32 _world_28 = STK(4);
    Term _world_29 = STK(5);
    Term _world_30 = STK(6);
    Term _world_31 = STK(7);
    u32 _world_32 = STK(8);
    u32 _world_33 = STK(9);
    u32 _world_34 = STK(10);
    u32 _world_35 = STK(11);
    u32 _world_36 = STK(12);
    u32 _world_37 = STK(13);
    u32 _world_38 = STK(14);
    u32 _world_39 = STK(15);
    u32 _world_40 = STK(16);
    u32 _world_41 = STK(17);
    u32 _world_42 = STK(18);
    Term _world_43 = STK(19);
    Term _world_44 = STK(20);
    u32 _world_45 = STK(21);
    u32 _world_46 = STK(22);
    Term _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(25);
      STK(0) = _world_24;
      STK(1) = _world_25;
      STK(2) = _world_26;
      STK(3) = _world_28;
      STK(4) = _world_29;
      STK(5) = _world_30;
      STK(6) = _world_31;
      STK(7) = _world_32;
      STK(8) = _world_33;
      STK(9) = _world_34;
      STK(10) = _world_35;
      STK(11) = _world_36;
      STK(12) = _world_37;
      STK(13) = _world_38;
      STK(14) = _world_39;
      STK(15) = _world_40;
      STK(16) = _world_41;
      STK(17) = _world_42;
      STK(18) = _world_43;
      STK(19) = _world_44;
      STK(20) = _world_45;
      STK(21) = _world_46;
      STK(22) = _h_0;
      STK(23) = _h_1;
      STK(24) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K266;
      WL_PUSHN(25);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K266, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _world_24;
      e.mem[_t_2 + 1] = _world_25;
      e.mem[_t_2 + 2] = _world_26;
      e.mem[_t_2 + 3] = _world_28;
      e.mem[_t_2 + 4] = _world_29;
      e.mem[_t_2 + 5] = _world_30;
      e.mem[_t_2 + 6] = _world_31;
      e.mem[_t_2 + 7] = _world_32;
      e.mem[_t_2 + 8] = _world_33;
      e.mem[_t_2 + 9] = _world_34;
      e.mem[_t_2 + 10] = _world_35;
      e.mem[_t_2 + 11] = _world_36;
      e.mem[_t_2 + 12] = _world_37;
      e.mem[_t_2 + 13] = _world_38;
      e.mem[_t_2 + 14] = _world_39;
      e.mem[_t_2 + 15] = _world_40;
      e.mem[_t_2 + 16] = _world_41;
      e.mem[_t_2 + 17] = _world_42;
      e.mem[_t_2 + 18] = _world_43;
      e.mem[_t_2 + 19] = _world_44;
      e.mem[_t_2 + 20] = _world_45;
      e.mem[_t_2 + 21] = _world_46;
      e.mem[_t_2 + 22] = _h_0;
      e.mem[_t_2 + 23] = _h_1;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K266, _t_2);
      WL_IDX = 24;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_TREE_1)) {
      u64 _t_3 = task_node(e, FID_CONSUMER_EXPANDED_TREE_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _world_27;
      return term_tsk(FID_CONSUMER_EXPANDED_TREE_1, _t_3);
    }
    r0 = _world_27;
    WL_JMP(FID_CONSUMER_EXPANDED_TREE_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K266)
  {
    WL_POPN(24);
    u32 _world_47 = STK(0);
    u32 _world_48 = STK(1);
    u32 _world_49 = STK(2);
    u32 _world_50 = STK(3);
    Term _world_51 = STK(4);
    Term _world_52 = STK(5);
    Term _world_53 = STK(6);
    u32 _world_54 = STK(7);
    u32 _world_55 = STK(8);
    u32 _world_56 = STK(9);
    u32 _world_57 = STK(10);
    u32 _world_58 = STK(11);
    u32 _world_59 = STK(12);
    u32 _world_60 = STK(13);
    u32 _world_61 = STK(14);
    u32 _world_62 = STK(15);
    u32 _world_63 = STK(16);
    u32 _world_64 = STK(17);
    Term _world_65 = STK(18);
    Term _world_66 = STK(19);
    u32 _world_67 = STK(20);
    u32 _world_68 = STK(21);
    Term _h_4 = STK(22);
    Term _h_5 = STK(23);
    Term _h_2 = r0;
    Term _h_3 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(26);
      STK(0) = _world_47;
      STK(1) = _world_48;
      STK(2) = _world_49;
      STK(3) = _world_50;
      STK(4) = _world_51;
      STK(5) = _world_53;
      STK(6) = _world_54;
      STK(7) = _world_55;
      STK(8) = _world_56;
      STK(9) = _world_57;
      STK(10) = _world_58;
      STK(11) = _world_59;
      STK(12) = _world_60;
      STK(13) = _world_61;
      STK(14) = _world_62;
      STK(15) = _world_63;
      STK(16) = _world_64;
      STK(17) = _world_65;
      STK(18) = _world_66;
      STK(19) = _world_67;
      STK(20) = _world_68;
      STK(21) = _h_4;
      STK(22) = _h_5;
      STK(23) = _h_2;
      STK(24) = _h_3;
      STK(25) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K267;
      WL_PUSHN(26);
    } else {
      u64 _t_4 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K267, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _world_47;
      e.mem[_t_4 + 1] = _world_48;
      e.mem[_t_4 + 2] = _world_49;
      e.mem[_t_4 + 3] = _world_50;
      e.mem[_t_4 + 4] = _world_51;
      e.mem[_t_4 + 5] = _world_53;
      e.mem[_t_4 + 6] = _world_54;
      e.mem[_t_4 + 7] = _world_55;
      e.mem[_t_4 + 8] = _world_56;
      e.mem[_t_4 + 9] = _world_57;
      e.mem[_t_4 + 10] = _world_58;
      e.mem[_t_4 + 11] = _world_59;
      e.mem[_t_4 + 12] = _world_60;
      e.mem[_t_4 + 13] = _world_61;
      e.mem[_t_4 + 14] = _world_62;
      e.mem[_t_4 + 15] = _world_63;
      e.mem[_t_4 + 16] = _world_64;
      e.mem[_t_4 + 17] = _world_65;
      e.mem[_t_4 + 18] = _world_66;
      e.mem[_t_4 + 19] = _world_67;
      e.mem[_t_4 + 20] = _world_68;
      e.mem[_t_4 + 21] = _h_4;
      e.mem[_t_4 + 22] = _h_5;
      e.mem[_t_4 + 23] = _h_2;
      e.mem[_t_4 + 24] = _h_3;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K267, _t_4);
      WL_IDX = 25;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_TREE_2)) {
      u64 _t_5 = task_node(e, FID_CONSUMER_EXPANDED_TREE_2, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _world_52;
      return term_tsk(FID_CONSUMER_EXPANDED_TREE_2, _t_5);
    }
    r0 = _world_52;
    WL_JMP(FID_CONSUMER_EXPANDED_TREE_2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K267)
  {
    WL_POPN(25);
    u32 _world_69 = STK(0);
    u32 _world_70 = STK(1);
    u32 _world_71 = STK(2);
    u32 _world_72 = STK(3);
    Term _world_73 = STK(4);
    Term _world_74 = STK(5);
    u32 _world_75 = STK(6);
    u32 _world_76 = STK(7);
    u32 _world_77 = STK(8);
    u32 _world_78 = STK(9);
    u32 _world_79 = STK(10);
    u32 _world_80 = STK(11);
    u32 _world_81 = STK(12);
    u32 _world_82 = STK(13);
    u32 _world_83 = STK(14);
    u32 _world_84 = STK(15);
    u32 _world_85 = STK(16);
    Term _world_86 = STK(17);
    Term _world_87 = STK(18);
    u32 _world_88 = STK(19);
    u32 _world_89 = STK(20);
    Term _h_8 = STK(21);
    Term _h_9 = STK(22);
    Term _h_10 = STK(23);
    Term _h_11 = STK(24);
    Term _h_6 = r0;
    Term _h_7 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(27);
      STK(0) = _world_69;
      STK(1) = _world_70;
      STK(2) = _world_71;
      STK(3) = _world_72;
      STK(4) = _world_73;
      STK(5) = _world_75;
      STK(6) = _world_76;
      STK(7) = _world_77;
      STK(8) = _world_78;
      STK(9) = _world_79;
      STK(10) = _world_80;
      STK(11) = _world_81;
      STK(12) = _world_82;
      STK(13) = _world_83;
      STK(14) = _world_84;
      STK(15) = _world_85;
      STK(16) = _world_86;
      STK(17) = _world_87;
      STK(18) = _world_88;
      STK(19) = _world_89;
      STK(20) = _h_8;
      STK(21) = _h_9;
      STK(22) = _h_10;
      STK(23) = _h_11;
      STK(24) = _h_6;
      STK(25) = _h_7;
      STK(26) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K268;
      WL_PUSHN(27);
    } else {
      u64 _t_6 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K268, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _world_69;
      e.mem[_t_6 + 1] = _world_70;
      e.mem[_t_6 + 2] = _world_71;
      e.mem[_t_6 + 3] = _world_72;
      e.mem[_t_6 + 4] = _world_73;
      e.mem[_t_6 + 5] = _world_75;
      e.mem[_t_6 + 6] = _world_76;
      e.mem[_t_6 + 7] = _world_77;
      e.mem[_t_6 + 8] = _world_78;
      e.mem[_t_6 + 9] = _world_79;
      e.mem[_t_6 + 10] = _world_80;
      e.mem[_t_6 + 11] = _world_81;
      e.mem[_t_6 + 12] = _world_82;
      e.mem[_t_6 + 13] = _world_83;
      e.mem[_t_6 + 14] = _world_84;
      e.mem[_t_6 + 15] = _world_85;
      e.mem[_t_6 + 16] = _world_86;
      e.mem[_t_6 + 17] = _world_87;
      e.mem[_t_6 + 18] = _world_88;
      e.mem[_t_6 + 19] = _world_89;
      e.mem[_t_6 + 20] = _h_8;
      e.mem[_t_6 + 21] = _h_9;
      e.mem[_t_6 + 22] = _h_10;
      e.mem[_t_6 + 23] = _h_11;
      e.mem[_t_6 + 24] = _h_6;
      e.mem[_t_6 + 25] = _h_7;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K268, _t_6);
      WL_IDX = 26;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_TREE_0)) {
      u64 _t_7 = task_node(e, FID_CONSUMER_EXPANDED_TREE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _world_74;
      return term_tsk(FID_CONSUMER_EXPANDED_TREE_0, _t_7);
    }
    r0 = _world_74;
    WL_JMP(FID_CONSUMER_EXPANDED_TREE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K268)
  {
    WL_POPN(26);
    u32 _world_90 = STK(0);
    u32 _world_91 = STK(1);
    u32 _world_92 = STK(2);
    u32 _world_93 = STK(3);
    Term _world_94 = STK(4);
    u32 _world_95 = STK(5);
    u32 _world_96 = STK(6);
    u32 _world_97 = STK(7);
    u32 _world_98 = STK(8);
    u32 _world_99 = STK(9);
    u32 _world_100 = STK(10);
    u32 _world_101 = STK(11);
    u32 _world_102 = STK(12);
    u32 _world_103 = STK(13);
    u32 _world_104 = STK(14);
    u32 _world_105 = STK(15);
    Term _world_106 = STK(16);
    Term _world_107 = STK(17);
    u32 _world_108 = STK(18);
    u32 _world_109 = STK(19);
    Term _h_14 = STK(20);
    Term _h_15 = STK(21);
    Term _h_16 = STK(22);
    Term _h_17 = STK(23);
    Term _h_18 = STK(24);
    Term _h_19 = STK(25);
    Term _h_12 = r0;
    Term _h_13 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(29);
      STK(0) = _world_90;
      STK(1) = _world_91;
      STK(2) = _world_92;
      STK(3) = _world_93;
      STK(4) = _world_94;
      STK(5) = _world_95;
      STK(6) = _world_96;
      STK(7) = _world_97;
      STK(8) = _world_98;
      STK(9) = _world_99;
      STK(10) = _world_100;
      STK(11) = _world_101;
      STK(12) = _world_102;
      STK(13) = _world_103;
      STK(14) = _world_104;
      STK(15) = _world_105;
      STK(16) = _world_106;
      STK(17) = _h_14;
      STK(18) = _h_15;
      STK(19) = _world_107;
      STK(20) = _world_108;
      STK(21) = _world_109;
      STK(22) = _h_16;
      STK(23) = _h_17;
      STK(24) = _h_18;
      STK(25) = _h_19;
      STK(26) = _h_12;
      STK(27) = _h_13;
      STK(28) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K269;
      WL_PUSHN(29);
    } else {
      u64 _t_8 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K269, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _world_90;
      e.mem[_t_8 + 1] = _world_91;
      e.mem[_t_8 + 2] = _world_92;
      e.mem[_t_8 + 3] = _world_93;
      e.mem[_t_8 + 4] = _world_94;
      e.mem[_t_8 + 5] = _world_95;
      e.mem[_t_8 + 6] = _world_96;
      e.mem[_t_8 + 7] = _world_97;
      e.mem[_t_8 + 8] = _world_98;
      e.mem[_t_8 + 9] = _world_99;
      e.mem[_t_8 + 10] = _world_100;
      e.mem[_t_8 + 11] = _world_101;
      e.mem[_t_8 + 12] = _world_102;
      e.mem[_t_8 + 13] = _world_103;
      e.mem[_t_8 + 14] = _world_104;
      e.mem[_t_8 + 15] = _world_105;
      e.mem[_t_8 + 16] = _world_106;
      e.mem[_t_8 + 17] = _h_14;
      e.mem[_t_8 + 18] = _h_15;
      e.mem[_t_8 + 19] = _world_107;
      e.mem[_t_8 + 20] = _world_108;
      e.mem[_t_8 + 21] = _world_109;
      e.mem[_t_8 + 22] = _h_16;
      e.mem[_t_8 + 23] = _h_17;
      e.mem[_t_8 + 24] = _h_18;
      e.mem[_t_8 + 25] = _h_19;
      e.mem[_t_8 + 26] = _h_12;
      e.mem[_t_8 + 27] = _h_13;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K269, _t_8);
      WL_IDX = 28;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_9 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _world_90;
      return term_tsk(FID_U32_SHOW, _t_9);
    }
    r0 = _world_90;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K269)
  {
    WL_POPN(28);
    u32 _world_110 = STK(0);
    u32 _world_111 = STK(1);
    u32 _world_112 = STK(2);
    u32 _world_113 = STK(3);
    Term _world_114 = STK(4);
    u32 _world_115 = STK(5);
    u32 _world_116 = STK(6);
    u32 _world_117 = STK(7);
    u32 _world_118 = STK(8);
    u32 _world_119 = STK(9);
    u32 _world_120 = STK(10);
    u32 _world_121 = STK(11);
    u32 _world_122 = STK(12);
    u32 _world_123 = STK(13);
    u32 _world_124 = STK(14);
    u32 _world_125 = STK(15);
    Term _world_126 = STK(16);
    Term _h_21 = STK(17);
    Term _h_22 = STK(18);
    Term _world_127 = STK(19);
    u32 _world_128 = STK(20);
    u32 _world_129 = STK(21);
    Term _h_23 = STK(22);
    Term _h_24 = STK(23);
    Term _h_25 = STK(24);
    Term _h_26 = STK(25);
    Term _h_27 = STK(26);
    Term _h_28 = STK(27);
    Term _h_20 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(30);
      STK(0) = _world_110;
      STK(1) = _world_111;
      STK(2) = _world_112;
      STK(3) = _world_113;
      STK(4) = _world_114;
      STK(5) = _world_115;
      STK(6) = _world_116;
      STK(7) = _world_117;
      STK(8) = _world_118;
      STK(9) = _world_119;
      STK(10) = _world_120;
      STK(11) = _world_121;
      STK(12) = _world_122;
      STK(13) = _world_123;
      STK(14) = _world_124;
      STK(15) = _world_125;
      STK(16) = _world_126;
      STK(17) = _h_21;
      STK(18) = _h_22;
      STK(19) = _world_127;
      STK(20) = _world_128;
      STK(21) = _world_129;
      STK(22) = _h_23;
      STK(23) = _h_24;
      STK(24) = _h_25;
      STK(25) = _h_26;
      STK(26) = _h_27;
      STK(27) = _h_28;
      STK(28) = _h_20;
      STK(29) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K270;
      WL_PUSHN(30);
    } else {
      u64 _t_10 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K270, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _world_110;
      e.mem[_t_10 + 1] = _world_111;
      e.mem[_t_10 + 2] = _world_112;
      e.mem[_t_10 + 3] = _world_113;
      e.mem[_t_10 + 4] = _world_114;
      e.mem[_t_10 + 5] = _world_115;
      e.mem[_t_10 + 6] = _world_116;
      e.mem[_t_10 + 7] = _world_117;
      e.mem[_t_10 + 8] = _world_118;
      e.mem[_t_10 + 9] = _world_119;
      e.mem[_t_10 + 10] = _world_120;
      e.mem[_t_10 + 11] = _world_121;
      e.mem[_t_10 + 12] = _world_122;
      e.mem[_t_10 + 13] = _world_123;
      e.mem[_t_10 + 14] = _world_124;
      e.mem[_t_10 + 15] = _world_125;
      e.mem[_t_10 + 16] = _world_126;
      e.mem[_t_10 + 17] = _h_21;
      e.mem[_t_10 + 18] = _h_22;
      e.mem[_t_10 + 19] = _world_127;
      e.mem[_t_10 + 20] = _world_128;
      e.mem[_t_10 + 21] = _world_129;
      e.mem[_t_10 + 22] = _h_23;
      e.mem[_t_10 + 23] = _h_24;
      e.mem[_t_10 + 24] = _h_25;
      e.mem[_t_10 + 25] = _h_26;
      e.mem[_t_10 + 26] = _h_27;
      e.mem[_t_10 + 27] = _h_28;
      e.mem[_t_10 + 28] = _h_20;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K270, _t_10);
      WL_IDX = 29;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_11 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _world_111;
      return term_tsk(FID_U32_SHOW, _t_11);
    }
    r0 = _world_111;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K270)
  {
    WL_POPN(29);
    u32 _world_130 = STK(0);
    u32 _world_131 = STK(1);
    u32 _world_132 = STK(2);
    u32 _world_133 = STK(3);
    Term _world_134 = STK(4);
    u32 _world_135 = STK(5);
    u32 _world_136 = STK(6);
    u32 _world_137 = STK(7);
    u32 _world_138 = STK(8);
    u32 _world_139 = STK(9);
    u32 _world_140 = STK(10);
    u32 _world_141 = STK(11);
    u32 _world_142 = STK(12);
    u32 _world_143 = STK(13);
    u32 _world_144 = STK(14);
    u32 _world_145 = STK(15);
    Term _world_146 = STK(16);
    Term _h_30 = STK(17);
    Term _h_31 = STK(18);
    Term _world_147 = STK(19);
    u32 _world_148 = STK(20);
    u32 _world_149 = STK(21);
    Term _h_32 = STK(22);
    Term _h_33 = STK(23);
    Term _h_34 = STK(24);
    Term _h_35 = STK(25);
    Term _h_36 = STK(26);
    Term _h_37 = STK(27);
    Term _h_38 = STK(28);
    Term _h_29 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(31);
      STK(0) = _world_130;
      STK(1) = _world_131;
      STK(2) = _world_132;
      STK(3) = _world_133;
      STK(4) = _world_134;
      STK(5) = _world_135;
      STK(6) = _world_136;
      STK(7) = _world_137;
      STK(8) = _world_138;
      STK(9) = _world_139;
      STK(10) = _world_140;
      STK(11) = _world_141;
      STK(12) = _world_142;
      STK(13) = _world_143;
      STK(14) = _world_144;
      STK(15) = _world_145;
      STK(16) = _world_146;
      STK(17) = _h_30;
      STK(18) = _h_31;
      STK(19) = _world_147;
      STK(20) = _world_148;
      STK(21) = _world_149;
      STK(22) = _h_32;
      STK(23) = _h_33;
      STK(24) = _h_34;
      STK(25) = _h_35;
      STK(26) = _h_36;
      STK(27) = _h_37;
      STK(28) = _h_38;
      STK(29) = _h_29;
      STK(30) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K271;
      WL_PUSHN(31);
    } else {
      u64 _t_12 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K271, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _world_130;
      e.mem[_t_12 + 1] = _world_131;
      e.mem[_t_12 + 2] = _world_132;
      e.mem[_t_12 + 3] = _world_133;
      e.mem[_t_12 + 4] = _world_134;
      e.mem[_t_12 + 5] = _world_135;
      e.mem[_t_12 + 6] = _world_136;
      e.mem[_t_12 + 7] = _world_137;
      e.mem[_t_12 + 8] = _world_138;
      e.mem[_t_12 + 9] = _world_139;
      e.mem[_t_12 + 10] = _world_140;
      e.mem[_t_12 + 11] = _world_141;
      e.mem[_t_12 + 12] = _world_142;
      e.mem[_t_12 + 13] = _world_143;
      e.mem[_t_12 + 14] = _world_144;
      e.mem[_t_12 + 15] = _world_145;
      e.mem[_t_12 + 16] = _world_146;
      e.mem[_t_12 + 17] = _h_30;
      e.mem[_t_12 + 18] = _h_31;
      e.mem[_t_12 + 19] = _world_147;
      e.mem[_t_12 + 20] = _world_148;
      e.mem[_t_12 + 21] = _world_149;
      e.mem[_t_12 + 22] = _h_32;
      e.mem[_t_12 + 23] = _h_33;
      e.mem[_t_12 + 24] = _h_34;
      e.mem[_t_12 + 25] = _h_35;
      e.mem[_t_12 + 26] = _h_36;
      e.mem[_t_12 + 27] = _h_37;
      e.mem[_t_12 + 28] = _h_38;
      e.mem[_t_12 + 29] = _h_29;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K271, _t_12);
      WL_IDX = 30;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_13 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _world_132;
      return term_tsk(FID_U32_SHOW, _t_13);
    }
    r0 = _world_132;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K271)
  {
    WL_POPN(30);
    u32 _world_150 = STK(0);
    u32 _world_151 = STK(1);
    u32 _world_152 = STK(2);
    u32 _world_153 = STK(3);
    Term _world_154 = STK(4);
    u32 _world_155 = STK(5);
    u32 _world_156 = STK(6);
    u32 _world_157 = STK(7);
    u32 _world_158 = STK(8);
    u32 _world_159 = STK(9);
    u32 _world_160 = STK(10);
    u32 _world_161 = STK(11);
    u32 _world_162 = STK(12);
    u32 _world_163 = STK(13);
    u32 _world_164 = STK(14);
    u32 _world_165 = STK(15);
    Term _world_166 = STK(16);
    Term _h_40 = STK(17);
    Term _h_41 = STK(18);
    Term _world_167 = STK(19);
    u32 _world_168 = STK(20);
    u32 _world_169 = STK(21);
    Term _h_42 = STK(22);
    Term _h_43 = STK(23);
    Term _h_44 = STK(24);
    Term _h_45 = STK(25);
    Term _h_46 = STK(26);
    Term _h_47 = STK(27);
    Term _h_48 = STK(28);
    Term _h_49 = STK(29);
    Term _h_39 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(32);
      STK(0) = _world_150;
      STK(1) = _world_151;
      STK(2) = _world_152;
      STK(3) = _world_153;
      STK(4) = _world_154;
      STK(5) = _world_155;
      STK(6) = _world_156;
      STK(7) = _world_157;
      STK(8) = _world_158;
      STK(9) = _world_159;
      STK(10) = _world_160;
      STK(11) = _world_161;
      STK(12) = _world_162;
      STK(13) = _world_163;
      STK(14) = _world_164;
      STK(15) = _world_165;
      STK(16) = _world_166;
      STK(17) = _h_40;
      STK(18) = _h_41;
      STK(19) = _world_167;
      STK(20) = _world_168;
      STK(21) = _world_169;
      STK(22) = _h_42;
      STK(23) = _h_43;
      STK(24) = _h_44;
      STK(25) = _h_45;
      STK(26) = _h_46;
      STK(27) = _h_47;
      STK(28) = _h_48;
      STK(29) = _h_49;
      STK(30) = _h_39;
      STK(31) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K272;
      WL_PUSHN(32);
    } else {
      u64 _t_14 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K272, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _world_150;
      e.mem[_t_14 + 1] = _world_151;
      e.mem[_t_14 + 2] = _world_152;
      e.mem[_t_14 + 3] = _world_153;
      e.mem[_t_14 + 4] = _world_154;
      e.mem[_t_14 + 5] = _world_155;
      e.mem[_t_14 + 6] = _world_156;
      e.mem[_t_14 + 7] = _world_157;
      e.mem[_t_14 + 8] = _world_158;
      e.mem[_t_14 + 9] = _world_159;
      e.mem[_t_14 + 10] = _world_160;
      e.mem[_t_14 + 11] = _world_161;
      e.mem[_t_14 + 12] = _world_162;
      e.mem[_t_14 + 13] = _world_163;
      e.mem[_t_14 + 14] = _world_164;
      e.mem[_t_14 + 15] = _world_165;
      e.mem[_t_14 + 16] = _world_166;
      e.mem[_t_14 + 17] = _h_40;
      e.mem[_t_14 + 18] = _h_41;
      e.mem[_t_14 + 19] = _world_167;
      e.mem[_t_14 + 20] = _world_168;
      e.mem[_t_14 + 21] = _world_169;
      e.mem[_t_14 + 22] = _h_42;
      e.mem[_t_14 + 23] = _h_43;
      e.mem[_t_14 + 24] = _h_44;
      e.mem[_t_14 + 25] = _h_45;
      e.mem[_t_14 + 26] = _h_46;
      e.mem[_t_14 + 27] = _h_47;
      e.mem[_t_14 + 28] = _h_48;
      e.mem[_t_14 + 29] = _h_49;
      e.mem[_t_14 + 30] = _h_39;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K272, _t_14);
      WL_IDX = 31;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_15 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _world_153;
      return term_tsk(FID_U32_SHOW, _t_15);
    }
    r0 = _world_153;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K272)
  {
    WL_POPN(31);
    u32 _world_170 = STK(0);
    u32 _world_171 = STK(1);
    u32 _world_172 = STK(2);
    u32 _world_173 = STK(3);
    Term _world_174 = STK(4);
    u32 _world_175 = STK(5);
    u32 _world_176 = STK(6);
    u32 _world_177 = STK(7);
    u32 _world_178 = STK(8);
    u32 _world_179 = STK(9);
    u32 _world_180 = STK(10);
    u32 _world_181 = STK(11);
    u32 _world_182 = STK(12);
    u32 _world_183 = STK(13);
    u32 _world_184 = STK(14);
    u32 _world_185 = STK(15);
    Term _world_186 = STK(16);
    Term _h_51 = STK(17);
    Term _h_52 = STK(18);
    Term _world_187 = STK(19);
    u32 _world_188 = STK(20);
    u32 _world_189 = STK(21);
    Term _h_53 = STK(22);
    Term _h_54 = STK(23);
    Term _h_55 = STK(24);
    Term _h_56 = STK(25);
    Term _h_57 = STK(26);
    Term _h_58 = STK(27);
    Term _h_59 = STK(28);
    Term _h_60 = STK(29);
    Term _h_61 = STK(30);
    Term _h_50 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(33);
      STK(0) = _world_170;
      STK(1) = _world_171;
      STK(2) = _world_172;
      STK(3) = _world_173;
      STK(4) = _world_174;
      STK(5) = _world_175;
      STK(6) = _world_176;
      STK(7) = _world_177;
      STK(8) = _world_178;
      STK(9) = _world_179;
      STK(10) = _world_180;
      STK(11) = _world_181;
      STK(12) = _world_182;
      STK(13) = _world_183;
      STK(14) = _world_184;
      STK(15) = _world_185;
      STK(16) = _world_186;
      STK(17) = _h_51;
      STK(18) = _h_52;
      STK(19) = _world_187;
      STK(20) = _world_188;
      STK(21) = _world_189;
      STK(22) = _h_53;
      STK(23) = _h_54;
      STK(24) = _h_55;
      STK(25) = _h_56;
      STK(26) = _h_57;
      STK(27) = _h_58;
      STK(28) = _h_59;
      STK(29) = _h_60;
      STK(30) = _h_61;
      STK(31) = _h_50;
      STK(32) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K273;
      WL_PUSHN(33);
    } else {
      u64 _t_16 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K273, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _world_170;
      e.mem[_t_16 + 1] = _world_171;
      e.mem[_t_16 + 2] = _world_172;
      e.mem[_t_16 + 3] = _world_173;
      e.mem[_t_16 + 4] = _world_174;
      e.mem[_t_16 + 5] = _world_175;
      e.mem[_t_16 + 6] = _world_176;
      e.mem[_t_16 + 7] = _world_177;
      e.mem[_t_16 + 8] = _world_178;
      e.mem[_t_16 + 9] = _world_179;
      e.mem[_t_16 + 10] = _world_180;
      e.mem[_t_16 + 11] = _world_181;
      e.mem[_t_16 + 12] = _world_182;
      e.mem[_t_16 + 13] = _world_183;
      e.mem[_t_16 + 14] = _world_184;
      e.mem[_t_16 + 15] = _world_185;
      e.mem[_t_16 + 16] = _world_186;
      e.mem[_t_16 + 17] = _h_51;
      e.mem[_t_16 + 18] = _h_52;
      e.mem[_t_16 + 19] = _world_187;
      e.mem[_t_16 + 20] = _world_188;
      e.mem[_t_16 + 21] = _world_189;
      e.mem[_t_16 + 22] = _h_53;
      e.mem[_t_16 + 23] = _h_54;
      e.mem[_t_16 + 24] = _h_55;
      e.mem[_t_16 + 25] = _h_56;
      e.mem[_t_16 + 26] = _h_57;
      e.mem[_t_16 + 27] = _h_58;
      e.mem[_t_16 + 28] = _h_59;
      e.mem[_t_16 + 29] = _h_60;
      e.mem[_t_16 + 30] = _h_61;
      e.mem[_t_16 + 31] = _h_50;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K273, _t_16);
      WL_IDX = 32;
    }
    if (!DEVICE && !seq && fid_nofk(FID_NAT_SHOW)) {
      u64 _t_17 = task_node(e, FID_NAT_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _world_174;
      return term_tsk(FID_NAT_SHOW, _t_17);
    }
    r0 = _world_174;
    WL_JMP(FID_NAT_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K273)
  {
    WL_POPN(32);
    u32 _world_190 = STK(0);
    u32 _world_191 = STK(1);
    u32 _world_192 = STK(2);
    u32 _world_193 = STK(3);
    Term _world_194 = STK(4);
    u32 _world_195 = STK(5);
    u32 _world_196 = STK(6);
    u32 _world_197 = STK(7);
    u32 _world_198 = STK(8);
    u32 _world_199 = STK(9);
    u32 _world_200 = STK(10);
    u32 _world_201 = STK(11);
    u32 _world_202 = STK(12);
    u32 _world_203 = STK(13);
    u32 _world_204 = STK(14);
    u32 _world_205 = STK(15);
    Term _world_206 = STK(16);
    Term _h_63 = STK(17);
    Term _h_64 = STK(18);
    Term _world_207 = STK(19);
    u32 _world_208 = STK(20);
    u32 _world_209 = STK(21);
    Term _h_65 = STK(22);
    Term _h_66 = STK(23);
    Term _h_67 = STK(24);
    Term _h_68 = STK(25);
    Term _h_69 = STK(26);
    Term _h_70 = STK(27);
    Term _h_71 = STK(28);
    Term _h_72 = STK(29);
    Term _h_73 = STK(30);
    Term _h_74 = STK(31);
    Term _h_62 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(34);
      STK(0) = _world_190;
      STK(1) = _world_191;
      STK(2) = _world_192;
      STK(3) = _world_193;
      STK(4) = _world_194;
      STK(5) = _world_195;
      STK(6) = _world_196;
      STK(7) = _world_197;
      STK(8) = _world_198;
      STK(9) = _world_199;
      STK(10) = _world_200;
      STK(11) = _world_201;
      STK(12) = _world_202;
      STK(13) = _world_203;
      STK(14) = _world_204;
      STK(15) = _world_205;
      STK(16) = _world_206;
      STK(17) = _h_63;
      STK(18) = _h_64;
      STK(19) = _world_207;
      STK(20) = _world_208;
      STK(21) = _world_209;
      STK(22) = _h_65;
      STK(23) = _h_66;
      STK(24) = _h_67;
      STK(25) = _h_68;
      STK(26) = _h_69;
      STK(27) = _h_70;
      STK(28) = _h_71;
      STK(29) = _h_72;
      STK(30) = _h_73;
      STK(31) = _h_74;
      STK(32) = _h_62;
      STK(33) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K274;
      WL_PUSHN(34);
    } else {
      u64 _t_18 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K274, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _world_190;
      e.mem[_t_18 + 1] = _world_191;
      e.mem[_t_18 + 2] = _world_192;
      e.mem[_t_18 + 3] = _world_193;
      e.mem[_t_18 + 4] = _world_194;
      e.mem[_t_18 + 5] = _world_195;
      e.mem[_t_18 + 6] = _world_196;
      e.mem[_t_18 + 7] = _world_197;
      e.mem[_t_18 + 8] = _world_198;
      e.mem[_t_18 + 9] = _world_199;
      e.mem[_t_18 + 10] = _world_200;
      e.mem[_t_18 + 11] = _world_201;
      e.mem[_t_18 + 12] = _world_202;
      e.mem[_t_18 + 13] = _world_203;
      e.mem[_t_18 + 14] = _world_204;
      e.mem[_t_18 + 15] = _world_205;
      e.mem[_t_18 + 16] = _world_206;
      e.mem[_t_18 + 17] = _h_63;
      e.mem[_t_18 + 18] = _h_64;
      e.mem[_t_18 + 19] = _world_207;
      e.mem[_t_18 + 20] = _world_208;
      e.mem[_t_18 + 21] = _world_209;
      e.mem[_t_18 + 22] = _h_65;
      e.mem[_t_18 + 23] = _h_66;
      e.mem[_t_18 + 24] = _h_67;
      e.mem[_t_18 + 25] = _h_68;
      e.mem[_t_18 + 26] = _h_69;
      e.mem[_t_18 + 27] = _h_70;
      e.mem[_t_18 + 28] = _h_71;
      e.mem[_t_18 + 29] = _h_72;
      e.mem[_t_18 + 30] = _h_73;
      e.mem[_t_18 + 31] = _h_74;
      e.mem[_t_18 + 32] = _h_62;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K274, _t_18);
      WL_IDX = 33;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_SHOW_SLOT_0)) {
      u64 _t_19 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_SLOT_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _world_195;
      e.mem[_t_19 + 1] = _world_196;
      e.mem[_t_19 + 2] = _world_197;
      e.mem[_t_19 + 3] = _world_198;
      e.mem[_t_19 + 4] = _world_199;
      e.mem[_t_19 + 5] = _world_200;
      e.mem[_t_19 + 6] = _world_201;
      e.mem[_t_19 + 7] = _world_202;
      e.mem[_t_19 + 8] = _world_203;
      e.mem[_t_19 + 9] = _world_204;
      e.mem[_t_19 + 10] = _world_205;
      return term_tsk(FID_CONSUMER_EXPANDED_SHOW_SLOT_0, _t_19);
    }
    r0 = _world_195;
    r1 = _world_196;
    r2 = _world_197;
    r3 = _world_198;
    r4 = _world_199;
    r5 = _world_200;
    r6 = _world_201;
    r7 = _world_202;
    r8 = _world_203;
    r9 = _world_204;
    r10 = _world_205;
    WL_JMP(FID_CONSUMER_EXPANDED_SHOW_SLOT_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K274)
  {
    WL_POPN(33);
    u32 _world_210 = STK(0);
    u32 _world_211 = STK(1);
    u32 _world_212 = STK(2);
    u32 _world_213 = STK(3);
    Term _world_214 = STK(4);
    u32 _world_215 = STK(5);
    u32 _world_216 = STK(6);
    u32 _world_217 = STK(7);
    u32 _world_218 = STK(8);
    u32 _world_219 = STK(9);
    u32 _world_220 = STK(10);
    u32 _world_221 = STK(11);
    u32 _world_222 = STK(12);
    u32 _world_223 = STK(13);
    u32 _world_224 = STK(14);
    u32 _world_225 = STK(15);
    Term _world_226 = STK(16);
    Term _h_76 = STK(17);
    Term _h_77 = STK(18);
    Term _world_227 = STK(19);
    u32 _world_228 = STK(20);
    u32 _world_229 = STK(21);
    Term _h_78 = STK(22);
    Term _h_79 = STK(23);
    Term _h_80 = STK(24);
    Term _h_81 = STK(25);
    Term _h_82 = STK(26);
    Term _h_83 = STK(27);
    Term _h_84 = STK(28);
    Term _h_85 = STK(29);
    Term _h_86 = STK(30);
    Term _h_87 = STK(31);
    Term _h_88 = STK(32);
    Term _h_75 = r0;
    WL_OPEN
    _world_226 = term_keep(e, _world_226, 1);
    if (seq) {
      WL_ROOM(35);
      STK(0) = _world_210;
      STK(1) = _world_211;
      STK(2) = _world_212;
      STK(3) = _world_213;
      STK(4) = _world_214;
      STK(5) = _world_215;
      STK(6) = _world_216;
      STK(7) = _world_217;
      STK(8) = _world_218;
      STK(9) = _world_219;
      STK(10) = _world_220;
      STK(11) = _world_221;
      STK(12) = _world_222;
      STK(13) = _world_223;
      STK(14) = _world_224;
      STK(15) = _world_225;
      STK(16) = _world_226;
      STK(17) = _h_76;
      STK(18) = _h_77;
      STK(19) = _world_227;
      STK(20) = _world_228;
      STK(21) = _world_229;
      STK(22) = _h_78;
      STK(23) = _h_79;
      STK(24) = _h_80;
      STK(25) = _h_81;
      STK(26) = _h_82;
      STK(27) = _h_83;
      STK(28) = _h_84;
      STK(29) = _h_85;
      STK(30) = _h_86;
      STK(31) = _h_87;
      STK(32) = _h_88;
      STK(33) = _h_75;
      STK(34) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K275;
      WL_PUSHN(35);
    } else {
      u64 _t_20 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K275, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _world_210;
      e.mem[_t_20 + 1] = _world_211;
      e.mem[_t_20 + 2] = _world_212;
      e.mem[_t_20 + 3] = _world_213;
      e.mem[_t_20 + 4] = _world_214;
      e.mem[_t_20 + 5] = _world_215;
      e.mem[_t_20 + 6] = _world_216;
      e.mem[_t_20 + 7] = _world_217;
      e.mem[_t_20 + 8] = _world_218;
      e.mem[_t_20 + 9] = _world_219;
      e.mem[_t_20 + 10] = _world_220;
      e.mem[_t_20 + 11] = _world_221;
      e.mem[_t_20 + 12] = _world_222;
      e.mem[_t_20 + 13] = _world_223;
      e.mem[_t_20 + 14] = _world_224;
      e.mem[_t_20 + 15] = _world_225;
      e.mem[_t_20 + 16] = _world_226;
      e.mem[_t_20 + 17] = _h_76;
      e.mem[_t_20 + 18] = _h_77;
      e.mem[_t_20 + 19] = _world_227;
      e.mem[_t_20 + 20] = _world_228;
      e.mem[_t_20 + 21] = _world_229;
      e.mem[_t_20 + 22] = _h_78;
      e.mem[_t_20 + 23] = _h_79;
      e.mem[_t_20 + 24] = _h_80;
      e.mem[_t_20 + 25] = _h_81;
      e.mem[_t_20 + 26] = _h_82;
      e.mem[_t_20 + 27] = _h_83;
      e.mem[_t_20 + 28] = _h_84;
      e.mem[_t_20 + 29] = _h_85;
      e.mem[_t_20 + 30] = _h_86;
      e.mem[_t_20 + 31] = _h_87;
      e.mem[_t_20 + 32] = _h_88;
      e.mem[_t_20 + 33] = _h_75;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K275, _t_20);
      WL_IDX = 34;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_0)) {
      u64 _t_21 = task_node(e, FID_LIST_SHOW_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = _world_226;
      return term_tsk(FID_LIST_SHOW_0, _t_21);
    }
    r0 = _world_226;
    WL_JMP(FID_LIST_SHOW_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K275)
  {
    WL_POPN(34);
    u32 _world_230 = STK(0);
    u32 _world_231 = STK(1);
    u32 _world_232 = STK(2);
    u32 _world_233 = STK(3);
    Term _world_234 = STK(4);
    u32 _world_235 = STK(5);
    u32 _world_236 = STK(6);
    u32 _world_237 = STK(7);
    u32 _world_238 = STK(8);
    u32 _world_239 = STK(9);
    u32 _world_240 = STK(10);
    u32 _world_241 = STK(11);
    u32 _world_242 = STK(12);
    u32 _world_243 = STK(13);
    u32 _world_244 = STK(14);
    u32 _world_245 = STK(15);
    Term _world_246 = STK(16);
    Term _h_90 = STK(17);
    Term _h_91 = STK(18);
    Term _world_247 = STK(19);
    u32 _world_248 = STK(20);
    u32 _world_249 = STK(21);
    Term _h_92 = STK(22);
    Term _h_93 = STK(23);
    Term _h_94 = STK(24);
    Term _h_95 = STK(25);
    Term _h_96 = STK(26);
    Term _h_97 = STK(27);
    Term _h_98 = STK(28);
    Term _h_99 = STK(29);
    Term _h_100 = STK(30);
    Term _h_101 = STK(31);
    Term _h_102 = STK(32);
    Term _h_103 = STK(33);
    Term _h_89 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(35);
      STK(0) = _world_230;
      STK(1) = _world_231;
      STK(2) = _world_232;
      STK(3) = _world_233;
      STK(4) = _world_234;
      STK(5) = _world_235;
      STK(6) = _world_236;
      STK(7) = _world_237;
      STK(8) = _world_238;
      STK(9) = _world_239;
      STK(10) = _world_240;
      STK(11) = _world_241;
      STK(12) = _world_242;
      STK(13) = _world_243;
      STK(14) = _world_244;
      STK(15) = _world_245;
      STK(16) = _world_246;
      STK(17) = _h_90;
      STK(18) = _world_247;
      STK(19) = _world_248;
      STK(20) = _world_249;
      STK(21) = _h_92;
      STK(22) = _h_93;
      STK(23) = _h_94;
      STK(24) = _h_95;
      STK(25) = _h_96;
      STK(26) = _h_97;
      STK(27) = _h_98;
      STK(28) = _h_99;
      STK(29) = _h_100;
      STK(30) = _h_101;
      STK(31) = _h_102;
      STK(32) = _h_103;
      STK(33) = _h_89;
      STK(34) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K276;
      WL_PUSHN(35);
    } else {
      u64 _t_22 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K276, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _world_230;
      e.mem[_t_22 + 1] = _world_231;
      e.mem[_t_22 + 2] = _world_232;
      e.mem[_t_22 + 3] = _world_233;
      e.mem[_t_22 + 4] = _world_234;
      e.mem[_t_22 + 5] = _world_235;
      e.mem[_t_22 + 6] = _world_236;
      e.mem[_t_22 + 7] = _world_237;
      e.mem[_t_22 + 8] = _world_238;
      e.mem[_t_22 + 9] = _world_239;
      e.mem[_t_22 + 10] = _world_240;
      e.mem[_t_22 + 11] = _world_241;
      e.mem[_t_22 + 12] = _world_242;
      e.mem[_t_22 + 13] = _world_243;
      e.mem[_t_22 + 14] = _world_244;
      e.mem[_t_22 + 15] = _world_245;
      e.mem[_t_22 + 16] = _world_246;
      e.mem[_t_22 + 17] = _h_90;
      e.mem[_t_22 + 18] = _world_247;
      e.mem[_t_22 + 19] = _world_248;
      e.mem[_t_22 + 20] = _world_249;
      e.mem[_t_22 + 21] = _h_92;
      e.mem[_t_22 + 22] = _h_93;
      e.mem[_t_22 + 23] = _h_94;
      e.mem[_t_22 + 24] = _h_95;
      e.mem[_t_22 + 25] = _h_96;
      e.mem[_t_22 + 26] = _h_97;
      e.mem[_t_22 + 27] = _h_98;
      e.mem[_t_22 + 28] = _h_99;
      e.mem[_t_22 + 29] = _h_100;
      e.mem[_t_22 + 30] = _h_101;
      e.mem[_t_22 + 31] = _h_102;
      e.mem[_t_22 + 32] = _h_103;
      e.mem[_t_22 + 33] = _h_89;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K276, _t_22);
      WL_IDX = 34;
    }
    if (!DEVICE && !seq && fid_nofk(FID_NAT_SHOW)) {
      u64 _t_23 = task_node(e, FID_NAT_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = _h_91;
      return term_tsk(FID_NAT_SHOW, _t_23);
    }
    r0 = _h_91;
    WL_JMP(FID_NAT_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K276)
  {
    WL_POPN(34);
    u32 _world_250 = STK(0);
    u32 _world_251 = STK(1);
    u32 _world_252 = STK(2);
    u32 _world_253 = STK(3);
    Term _world_254 = STK(4);
    u32 _world_255 = STK(5);
    u32 _world_256 = STK(6);
    u32 _world_257 = STK(7);
    u32 _world_258 = STK(8);
    u32 _world_259 = STK(9);
    u32 _world_260 = STK(10);
    u32 _world_261 = STK(11);
    u32 _world_262 = STK(12);
    u32 _world_263 = STK(13);
    u32 _world_264 = STK(14);
    u32 _world_265 = STK(15);
    Term _world_266 = STK(16);
    Term _h_105 = STK(17);
    Term _world_267 = STK(18);
    u32 _world_268 = STK(19);
    u32 _world_269 = STK(20);
    Term _h_106 = STK(21);
    Term _h_107 = STK(22);
    Term _h_108 = STK(23);
    Term _h_109 = STK(24);
    Term _h_110 = STK(25);
    Term _h_111 = STK(26);
    Term _h_112 = STK(27);
    Term _h_113 = STK(28);
    Term _h_114 = STK(29);
    Term _h_115 = STK(30);
    Term _h_116 = STK(31);
    Term _h_117 = STK(32);
    Term _h_118 = STK(33);
    Term _h_104 = r0;
    WL_OPEN
    _world_267 = term_keep(e, _world_267, 1);
    if (seq) {
      WL_ROOM(36);
      STK(0) = _world_250;
      STK(1) = _world_251;
      STK(2) = _world_252;
      STK(3) = _world_253;
      STK(4) = _world_254;
      STK(5) = _world_255;
      STK(6) = _world_256;
      STK(7) = _world_257;
      STK(8) = _world_258;
      STK(9) = _world_259;
      STK(10) = _world_260;
      STK(11) = _world_261;
      STK(12) = _world_262;
      STK(13) = _world_263;
      STK(14) = _world_264;
      STK(15) = _world_265;
      STK(16) = _world_266;
      STK(17) = _h_105;
      STK(18) = _world_267;
      STK(19) = _world_268;
      STK(20) = _world_269;
      STK(21) = _h_106;
      STK(22) = _h_107;
      STK(23) = _h_108;
      STK(24) = _h_109;
      STK(25) = _h_110;
      STK(26) = _h_111;
      STK(27) = _h_112;
      STK(28) = _h_113;
      STK(29) = _h_114;
      STK(30) = _h_115;
      STK(31) = _h_116;
      STK(32) = _h_117;
      STK(33) = _h_118;
      STK(34) = _h_104;
      STK(35) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K277;
      WL_PUSHN(36);
    } else {
      u64 _t_24 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K277, WL_CONT, WL_IDX, 1);
      e.mem[_t_24 + 0] = _world_250;
      e.mem[_t_24 + 1] = _world_251;
      e.mem[_t_24 + 2] = _world_252;
      e.mem[_t_24 + 3] = _world_253;
      e.mem[_t_24 + 4] = _world_254;
      e.mem[_t_24 + 5] = _world_255;
      e.mem[_t_24 + 6] = _world_256;
      e.mem[_t_24 + 7] = _world_257;
      e.mem[_t_24 + 8] = _world_258;
      e.mem[_t_24 + 9] = _world_259;
      e.mem[_t_24 + 10] = _world_260;
      e.mem[_t_24 + 11] = _world_261;
      e.mem[_t_24 + 12] = _world_262;
      e.mem[_t_24 + 13] = _world_263;
      e.mem[_t_24 + 14] = _world_264;
      e.mem[_t_24 + 15] = _world_265;
      e.mem[_t_24 + 16] = _world_266;
      e.mem[_t_24 + 17] = _h_105;
      e.mem[_t_24 + 18] = _world_267;
      e.mem[_t_24 + 19] = _world_268;
      e.mem[_t_24 + 20] = _world_269;
      e.mem[_t_24 + 21] = _h_106;
      e.mem[_t_24 + 22] = _h_107;
      e.mem[_t_24 + 23] = _h_108;
      e.mem[_t_24 + 24] = _h_109;
      e.mem[_t_24 + 25] = _h_110;
      e.mem[_t_24 + 26] = _h_111;
      e.mem[_t_24 + 27] = _h_112;
      e.mem[_t_24 + 28] = _h_113;
      e.mem[_t_24 + 29] = _h_114;
      e.mem[_t_24 + 30] = _h_115;
      e.mem[_t_24 + 31] = _h_116;
      e.mem[_t_24 + 32] = _h_117;
      e.mem[_t_24 + 33] = _h_118;
      e.mem[_t_24 + 34] = _h_104;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K277, _t_24);
      WL_IDX = 35;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_1)) {
      u64 _t_25 = task_node(e, FID_LIST_SHOW_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = _world_267;
      return term_tsk(FID_LIST_SHOW_1, _t_25);
    }
    r0 = _world_267;
    WL_JMP(FID_LIST_SHOW_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K277)
  {
    WL_POPN(35);
    u32 _world_270 = STK(0);
    u32 _world_271 = STK(1);
    u32 _world_272 = STK(2);
    u32 _world_273 = STK(3);
    Term _world_274 = STK(4);
    u32 _world_275 = STK(5);
    u32 _world_276 = STK(6);
    u32 _world_277 = STK(7);
    u32 _world_278 = STK(8);
    u32 _world_279 = STK(9);
    u32 _world_280 = STK(10);
    u32 _world_281 = STK(11);
    u32 _world_282 = STK(12);
    u32 _world_283 = STK(13);
    u32 _world_284 = STK(14);
    u32 _world_285 = STK(15);
    Term _world_286 = STK(16);
    Term _h_120 = STK(17);
    Term _world_287 = STK(18);
    u32 _world_288 = STK(19);
    u32 _world_289 = STK(20);
    Term _h_121 = STK(21);
    Term _h_122 = STK(22);
    Term _h_123 = STK(23);
    Term _h_124 = STK(24);
    Term _h_125 = STK(25);
    Term _h_126 = STK(26);
    Term _h_127 = STK(27);
    Term _h_128 = STK(28);
    Term _h_129 = STK(29);
    Term _h_130 = STK(30);
    Term _h_131 = STK(31);
    Term _h_132 = STK(32);
    Term _h_133 = STK(33);
    Term _h_134 = STK(34);
    Term _h_119 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(37);
      STK(0) = _world_270;
      STK(1) = _world_271;
      STK(2) = _world_272;
      STK(3) = _world_273;
      STK(4) = _world_274;
      STK(5) = _world_275;
      STK(6) = _world_276;
      STK(7) = _world_277;
      STK(8) = _world_278;
      STK(9) = _world_279;
      STK(10) = _world_280;
      STK(11) = _world_281;
      STK(12) = _world_282;
      STK(13) = _world_283;
      STK(14) = _world_284;
      STK(15) = _world_285;
      STK(16) = _world_286;
      STK(17) = _h_120;
      STK(18) = _world_287;
      STK(19) = _world_288;
      STK(20) = _world_289;
      STK(21) = _h_121;
      STK(22) = _h_122;
      STK(23) = _h_123;
      STK(24) = _h_124;
      STK(25) = _h_125;
      STK(26) = _h_126;
      STK(27) = _h_127;
      STK(28) = _h_128;
      STK(29) = _h_129;
      STK(30) = _h_130;
      STK(31) = _h_131;
      STK(32) = _h_132;
      STK(33) = _h_133;
      STK(34) = _h_134;
      STK(35) = _h_119;
      STK(36) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K278;
      WL_PUSHN(37);
    } else {
      u64 _t_26 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K278, WL_CONT, WL_IDX, 1);
      e.mem[_t_26 + 0] = _world_270;
      e.mem[_t_26 + 1] = _world_271;
      e.mem[_t_26 + 2] = _world_272;
      e.mem[_t_26 + 3] = _world_273;
      e.mem[_t_26 + 4] = _world_274;
      e.mem[_t_26 + 5] = _world_275;
      e.mem[_t_26 + 6] = _world_276;
      e.mem[_t_26 + 7] = _world_277;
      e.mem[_t_26 + 8] = _world_278;
      e.mem[_t_26 + 9] = _world_279;
      e.mem[_t_26 + 10] = _world_280;
      e.mem[_t_26 + 11] = _world_281;
      e.mem[_t_26 + 12] = _world_282;
      e.mem[_t_26 + 13] = _world_283;
      e.mem[_t_26 + 14] = _world_284;
      e.mem[_t_26 + 15] = _world_285;
      e.mem[_t_26 + 16] = _world_286;
      e.mem[_t_26 + 17] = _h_120;
      e.mem[_t_26 + 18] = _world_287;
      e.mem[_t_26 + 19] = _world_288;
      e.mem[_t_26 + 20] = _world_289;
      e.mem[_t_26 + 21] = _h_121;
      e.mem[_t_26 + 22] = _h_122;
      e.mem[_t_26 + 23] = _h_123;
      e.mem[_t_26 + 24] = _h_124;
      e.mem[_t_26 + 25] = _h_125;
      e.mem[_t_26 + 26] = _h_126;
      e.mem[_t_26 + 27] = _h_127;
      e.mem[_t_26 + 28] = _h_128;
      e.mem[_t_26 + 29] = _h_129;
      e.mem[_t_26 + 30] = _h_130;
      e.mem[_t_26 + 31] = _h_131;
      e.mem[_t_26 + 32] = _h_132;
      e.mem[_t_26 + 33] = _h_133;
      e.mem[_t_26 + 34] = _h_134;
      e.mem[_t_26 + 35] = _h_119;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K278, _t_26);
      WL_IDX = 36;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_27 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_27 + 0] = _world_288;
      return term_tsk(FID_U32_SHOW, _t_27);
    }
    r0 = _world_288;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K278)
  {
    WL_POPN(36);
    u32 _world_290 = STK(0);
    u32 _world_291 = STK(1);
    u32 _world_292 = STK(2);
    u32 _world_293 = STK(3);
    Term _world_294 = STK(4);
    u32 _world_295 = STK(5);
    u32 _world_296 = STK(6);
    u32 _world_297 = STK(7);
    u32 _world_298 = STK(8);
    u32 _world_299 = STK(9);
    u32 _world_300 = STK(10);
    u32 _world_301 = STK(11);
    u32 _world_302 = STK(12);
    u32 _world_303 = STK(13);
    u32 _world_304 = STK(14);
    u32 _world_305 = STK(15);
    Term _world_306 = STK(16);
    Term _h_136 = STK(17);
    Term _world_307 = STK(18);
    u32 _world_308 = STK(19);
    u32 _world_309 = STK(20);
    Term _h_137 = STK(21);
    Term _h_138 = STK(22);
    Term _h_139 = STK(23);
    Term _h_140 = STK(24);
    Term _h_141 = STK(25);
    Term _h_142 = STK(26);
    Term _h_143 = STK(27);
    Term _h_144 = STK(28);
    Term _h_145 = STK(29);
    Term _h_146 = STK(30);
    Term _h_147 = STK(31);
    Term _h_148 = STK(32);
    Term _h_149 = STK(33);
    Term _h_150 = STK(34);
    Term _h_151 = STK(35);
    Term _h_135 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(38);
      STK(0) = _world_290;
      STK(1) = _world_291;
      STK(2) = _world_292;
      STK(3) = _world_293;
      STK(4) = _world_294;
      STK(5) = _world_295;
      STK(6) = _world_296;
      STK(7) = _world_297;
      STK(8) = _world_298;
      STK(9) = _world_299;
      STK(10) = _world_300;
      STK(11) = _world_301;
      STK(12) = _world_302;
      STK(13) = _world_303;
      STK(14) = _world_304;
      STK(15) = _world_305;
      STK(16) = _world_306;
      STK(17) = _h_136;
      STK(18) = _world_307;
      STK(19) = _world_308;
      STK(20) = _world_309;
      STK(21) = _h_137;
      STK(22) = _h_138;
      STK(23) = _h_139;
      STK(24) = _h_140;
      STK(25) = _h_141;
      STK(26) = _h_142;
      STK(27) = _h_143;
      STK(28) = _h_144;
      STK(29) = _h_145;
      STK(30) = _h_146;
      STK(31) = _h_147;
      STK(32) = _h_148;
      STK(33) = _h_149;
      STK(34) = _h_150;
      STK(35) = _h_151;
      STK(36) = _h_135;
      STK(37) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K279;
      WL_PUSHN(38);
    } else {
      u64 _t_28 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K279, WL_CONT, WL_IDX, 1);
      e.mem[_t_28 + 0] = _world_290;
      e.mem[_t_28 + 1] = _world_291;
      e.mem[_t_28 + 2] = _world_292;
      e.mem[_t_28 + 3] = _world_293;
      e.mem[_t_28 + 4] = _world_294;
      e.mem[_t_28 + 5] = _world_295;
      e.mem[_t_28 + 6] = _world_296;
      e.mem[_t_28 + 7] = _world_297;
      e.mem[_t_28 + 8] = _world_298;
      e.mem[_t_28 + 9] = _world_299;
      e.mem[_t_28 + 10] = _world_300;
      e.mem[_t_28 + 11] = _world_301;
      e.mem[_t_28 + 12] = _world_302;
      e.mem[_t_28 + 13] = _world_303;
      e.mem[_t_28 + 14] = _world_304;
      e.mem[_t_28 + 15] = _world_305;
      e.mem[_t_28 + 16] = _world_306;
      e.mem[_t_28 + 17] = _h_136;
      e.mem[_t_28 + 18] = _world_307;
      e.mem[_t_28 + 19] = _world_308;
      e.mem[_t_28 + 20] = _world_309;
      e.mem[_t_28 + 21] = _h_137;
      e.mem[_t_28 + 22] = _h_138;
      e.mem[_t_28 + 23] = _h_139;
      e.mem[_t_28 + 24] = _h_140;
      e.mem[_t_28 + 25] = _h_141;
      e.mem[_t_28 + 26] = _h_142;
      e.mem[_t_28 + 27] = _h_143;
      e.mem[_t_28 + 28] = _h_144;
      e.mem[_t_28 + 29] = _h_145;
      e.mem[_t_28 + 30] = _h_146;
      e.mem[_t_28 + 31] = _h_147;
      e.mem[_t_28 + 32] = _h_148;
      e.mem[_t_28 + 33] = _h_149;
      e.mem[_t_28 + 34] = _h_150;
      e.mem[_t_28 + 35] = _h_151;
      e.mem[_t_28 + 36] = _h_135;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K279, _t_28);
      WL_IDX = 37;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_29 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_29 + 0] = _world_309;
      return term_tsk(FID_U32_SHOW, _t_29);
    }
    r0 = _world_309;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K279)
  {
    WL_POPN(37);
    u32 _world_310 = STK(0);
    u32 _world_311 = STK(1);
    u32 _world_312 = STK(2);
    u32 _world_313 = STK(3);
    Term _world_314 = STK(4);
    u32 _world_315 = STK(5);
    u32 _world_316 = STK(6);
    u32 _world_317 = STK(7);
    u32 _world_318 = STK(8);
    u32 _world_319 = STK(9);
    u32 _world_320 = STK(10);
    u32 _world_321 = STK(11);
    u32 _world_322 = STK(12);
    u32 _world_323 = STK(13);
    u32 _world_324 = STK(14);
    u32 _world_325 = STK(15);
    Term _world_326 = STK(16);
    Term _h_153 = STK(17);
    Term _world_327 = STK(18);
    u32 _world_328 = STK(19);
    u32 _world_329 = STK(20);
    Term _h_154 = STK(21);
    Term _h_155 = STK(22);
    Term _h_156 = STK(23);
    Term _h_157 = STK(24);
    Term _h_158 = STK(25);
    Term _h_159 = STK(26);
    Term _h_160 = STK(27);
    Term _h_161 = STK(28);
    Term _h_162 = STK(29);
    Term _h_163 = STK(30);
    Term _h_164 = STK(31);
    Term _h_165 = STK(32);
    Term _h_166 = STK(33);
    Term _h_167 = STK(34);
    Term _h_168 = STK(35);
    Term _h_169 = STK(36);
    Term _h_152 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(38);
      STK(0) = _world_310;
      STK(1) = _world_311;
      STK(2) = _world_312;
      STK(3) = _world_313;
      STK(4) = _world_314;
      STK(5) = _world_315;
      STK(6) = _world_316;
      STK(7) = _world_317;
      STK(8) = _world_318;
      STK(9) = _world_319;
      STK(10) = _world_320;
      STK(11) = _world_321;
      STK(12) = _world_322;
      STK(13) = _world_323;
      STK(14) = _world_324;
      STK(15) = _world_325;
      STK(16) = _world_326;
      STK(17) = _h_153;
      STK(18) = _world_327;
      STK(19) = _world_328;
      STK(20) = _world_329;
      STK(21) = _h_154;
      STK(22) = _h_155;
      STK(23) = _h_156;
      STK(24) = _h_157;
      STK(25) = _h_158;
      STK(26) = _h_159;
      STK(27) = _h_160;
      STK(28) = _h_161;
      STK(29) = _h_162;
      STK(30) = _h_163;
      STK(31) = _h_164;
      STK(32) = _h_165;
      STK(33) = _h_166;
      STK(34) = _h_167;
      STK(35) = _h_168;
      STK(36) = _h_169;
      STK(37) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K280;
      WL_PUSHN(38);
    } else {
      u64 _t_30 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K280, WL_CONT, WL_IDX, 1);
      e.mem[_t_30 + 0] = _world_310;
      e.mem[_t_30 + 1] = _world_311;
      e.mem[_t_30 + 2] = _world_312;
      e.mem[_t_30 + 3] = _world_313;
      e.mem[_t_30 + 4] = _world_314;
      e.mem[_t_30 + 5] = _world_315;
      e.mem[_t_30 + 6] = _world_316;
      e.mem[_t_30 + 7] = _world_317;
      e.mem[_t_30 + 8] = _world_318;
      e.mem[_t_30 + 9] = _world_319;
      e.mem[_t_30 + 10] = _world_320;
      e.mem[_t_30 + 11] = _world_321;
      e.mem[_t_30 + 12] = _world_322;
      e.mem[_t_30 + 13] = _world_323;
      e.mem[_t_30 + 14] = _world_324;
      e.mem[_t_30 + 15] = _world_325;
      e.mem[_t_30 + 16] = _world_326;
      e.mem[_t_30 + 17] = _h_153;
      e.mem[_t_30 + 18] = _world_327;
      e.mem[_t_30 + 19] = _world_328;
      e.mem[_t_30 + 20] = _world_329;
      e.mem[_t_30 + 21] = _h_154;
      e.mem[_t_30 + 22] = _h_155;
      e.mem[_t_30 + 23] = _h_156;
      e.mem[_t_30 + 24] = _h_157;
      e.mem[_t_30 + 25] = _h_158;
      e.mem[_t_30 + 26] = _h_159;
      e.mem[_t_30 + 27] = _h_160;
      e.mem[_t_30 + 28] = _h_161;
      e.mem[_t_30 + 29] = _h_162;
      e.mem[_t_30 + 30] = _h_163;
      e.mem[_t_30 + 31] = _h_164;
      e.mem[_t_30 + 32] = _h_165;
      e.mem[_t_30 + 33] = _h_166;
      e.mem[_t_30 + 34] = _h_167;
      e.mem[_t_30 + 35] = _h_168;
      e.mem[_t_30 + 36] = _h_169;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K280, _t_30);
      WL_IDX = 37;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_31 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_31 + 0] = term_ctr(CID_SCON, STAT_OFF + 166);
      e.mem[_t_31 + 1] = _h_152;
      return term_tsk(FID_STRING_APPEND, _t_31);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 166);
    r1 = _h_152;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K280)
  {
    WL_POPN(37);
    u32 _world_330 = STK(0);
    u32 _world_331 = STK(1);
    u32 _world_332 = STK(2);
    u32 _world_333 = STK(3);
    Term _world_334 = STK(4);
    u32 _world_335 = STK(5);
    u32 _world_336 = STK(6);
    u32 _world_337 = STK(7);
    u32 _world_338 = STK(8);
    u32 _world_339 = STK(9);
    u32 _world_340 = STK(10);
    u32 _world_341 = STK(11);
    u32 _world_342 = STK(12);
    u32 _world_343 = STK(13);
    u32 _world_344 = STK(14);
    u32 _world_345 = STK(15);
    Term _world_346 = STK(16);
    Term _h_171 = STK(17);
    Term _world_347 = STK(18);
    u32 _world_348 = STK(19);
    u32 _world_349 = STK(20);
    Term _h_172 = STK(21);
    Term _h_173 = STK(22);
    Term _h_174 = STK(23);
    Term _h_175 = STK(24);
    Term _h_176 = STK(25);
    Term _h_177 = STK(26);
    Term _h_178 = STK(27);
    Term _h_179 = STK(28);
    Term _h_180 = STK(29);
    Term _h_181 = STK(30);
    Term _h_182 = STK(31);
    Term _h_183 = STK(32);
    Term _h_184 = STK(33);
    Term _h_185 = STK(34);
    Term _h_186 = STK(35);
    Term _h_187 = STK(36);
    Term _h_170 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(37);
      STK(0) = _world_330;
      STK(1) = _world_331;
      STK(2) = _world_332;
      STK(3) = _world_333;
      STK(4) = _world_334;
      STK(5) = _world_335;
      STK(6) = _world_336;
      STK(7) = _world_337;
      STK(8) = _world_338;
      STK(9) = _world_339;
      STK(10) = _world_340;
      STK(11) = _world_341;
      STK(12) = _world_342;
      STK(13) = _world_343;
      STK(14) = _world_344;
      STK(15) = _world_345;
      STK(16) = _world_346;
      STK(17) = _h_171;
      STK(18) = _world_347;
      STK(19) = _world_348;
      STK(20) = _world_349;
      STK(21) = _h_172;
      STK(22) = _h_173;
      STK(23) = _h_174;
      STK(24) = _h_175;
      STK(25) = _h_176;
      STK(26) = _h_177;
      STK(27) = _h_178;
      STK(28) = _h_179;
      STK(29) = _h_180;
      STK(30) = _h_181;
      STK(31) = _h_182;
      STK(32) = _h_183;
      STK(33) = _h_184;
      STK(34) = _h_185;
      STK(35) = _h_186;
      STK(36) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K281;
      WL_PUSHN(37);
    } else {
      u64 _t_32 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K281, WL_CONT, WL_IDX, 1);
      e.mem[_t_32 + 0] = _world_330;
      e.mem[_t_32 + 1] = _world_331;
      e.mem[_t_32 + 2] = _world_332;
      e.mem[_t_32 + 3] = _world_333;
      e.mem[_t_32 + 4] = _world_334;
      e.mem[_t_32 + 5] = _world_335;
      e.mem[_t_32 + 6] = _world_336;
      e.mem[_t_32 + 7] = _world_337;
      e.mem[_t_32 + 8] = _world_338;
      e.mem[_t_32 + 9] = _world_339;
      e.mem[_t_32 + 10] = _world_340;
      e.mem[_t_32 + 11] = _world_341;
      e.mem[_t_32 + 12] = _world_342;
      e.mem[_t_32 + 13] = _world_343;
      e.mem[_t_32 + 14] = _world_344;
      e.mem[_t_32 + 15] = _world_345;
      e.mem[_t_32 + 16] = _world_346;
      e.mem[_t_32 + 17] = _h_171;
      e.mem[_t_32 + 18] = _world_347;
      e.mem[_t_32 + 19] = _world_348;
      e.mem[_t_32 + 20] = _world_349;
      e.mem[_t_32 + 21] = _h_172;
      e.mem[_t_32 + 22] = _h_173;
      e.mem[_t_32 + 23] = _h_174;
      e.mem[_t_32 + 24] = _h_175;
      e.mem[_t_32 + 25] = _h_176;
      e.mem[_t_32 + 26] = _h_177;
      e.mem[_t_32 + 27] = _h_178;
      e.mem[_t_32 + 28] = _h_179;
      e.mem[_t_32 + 29] = _h_180;
      e.mem[_t_32 + 30] = _h_181;
      e.mem[_t_32 + 31] = _h_182;
      e.mem[_t_32 + 32] = _h_183;
      e.mem[_t_32 + 33] = _h_184;
      e.mem[_t_32 + 34] = _h_185;
      e.mem[_t_32 + 35] = _h_186;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K281, _t_32);
      WL_IDX = 36;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_33 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_33 + 0] = _h_187;
      e.mem[_t_33 + 1] = _h_170;
      return term_tsk(FID_STRING_APPEND, _t_33);
    }
    r0 = _h_187;
    r1 = _h_170;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K281)
  {
    WL_POPN(36);
    u32 _world_350 = STK(0);
    u32 _world_351 = STK(1);
    u32 _world_352 = STK(2);
    u32 _world_353 = STK(3);
    Term _world_354 = STK(4);
    u32 _world_355 = STK(5);
    u32 _world_356 = STK(6);
    u32 _world_357 = STK(7);
    u32 _world_358 = STK(8);
    u32 _world_359 = STK(9);
    u32 _world_360 = STK(10);
    u32 _world_361 = STK(11);
    u32 _world_362 = STK(12);
    u32 _world_363 = STK(13);
    u32 _world_364 = STK(14);
    u32 _world_365 = STK(15);
    Term _world_366 = STK(16);
    Term _h_189 = STK(17);
    Term _world_367 = STK(18);
    u32 _world_368 = STK(19);
    u32 _world_369 = STK(20);
    Term _h_190 = STK(21);
    Term _h_191 = STK(22);
    Term _h_192 = STK(23);
    Term _h_193 = STK(24);
    Term _h_194 = STK(25);
    Term _h_195 = STK(26);
    Term _h_196 = STK(27);
    Term _h_197 = STK(28);
    Term _h_198 = STK(29);
    Term _h_199 = STK(30);
    Term _h_200 = STK(31);
    Term _h_201 = STK(32);
    Term _h_202 = STK(33);
    Term _h_203 = STK(34);
    Term _h_204 = STK(35);
    Term _h_188 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(37);
      STK(0) = _world_350;
      STK(1) = _world_351;
      STK(2) = _world_352;
      STK(3) = _world_353;
      STK(4) = _world_354;
      STK(5) = _world_355;
      STK(6) = _world_356;
      STK(7) = _world_357;
      STK(8) = _world_358;
      STK(9) = _world_359;
      STK(10) = _world_360;
      STK(11) = _world_361;
      STK(12) = _world_362;
      STK(13) = _world_363;
      STK(14) = _world_364;
      STK(15) = _world_365;
      STK(16) = _world_366;
      STK(17) = _h_189;
      STK(18) = _world_367;
      STK(19) = _world_368;
      STK(20) = _world_369;
      STK(21) = _h_190;
      STK(22) = _h_191;
      STK(23) = _h_192;
      STK(24) = _h_193;
      STK(25) = _h_194;
      STK(26) = _h_195;
      STK(27) = _h_196;
      STK(28) = _h_197;
      STK(29) = _h_198;
      STK(30) = _h_199;
      STK(31) = _h_200;
      STK(32) = _h_201;
      STK(33) = _h_202;
      STK(34) = _h_203;
      STK(35) = _h_204;
      STK(36) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K282;
      WL_PUSHN(37);
    } else {
      u64 _t_34 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K282, WL_CONT, WL_IDX, 1);
      e.mem[_t_34 + 0] = _world_350;
      e.mem[_t_34 + 1] = _world_351;
      e.mem[_t_34 + 2] = _world_352;
      e.mem[_t_34 + 3] = _world_353;
      e.mem[_t_34 + 4] = _world_354;
      e.mem[_t_34 + 5] = _world_355;
      e.mem[_t_34 + 6] = _world_356;
      e.mem[_t_34 + 7] = _world_357;
      e.mem[_t_34 + 8] = _world_358;
      e.mem[_t_34 + 9] = _world_359;
      e.mem[_t_34 + 10] = _world_360;
      e.mem[_t_34 + 11] = _world_361;
      e.mem[_t_34 + 12] = _world_362;
      e.mem[_t_34 + 13] = _world_363;
      e.mem[_t_34 + 14] = _world_364;
      e.mem[_t_34 + 15] = _world_365;
      e.mem[_t_34 + 16] = _world_366;
      e.mem[_t_34 + 17] = _h_189;
      e.mem[_t_34 + 18] = _world_367;
      e.mem[_t_34 + 19] = _world_368;
      e.mem[_t_34 + 20] = _world_369;
      e.mem[_t_34 + 21] = _h_190;
      e.mem[_t_34 + 22] = _h_191;
      e.mem[_t_34 + 23] = _h_192;
      e.mem[_t_34 + 24] = _h_193;
      e.mem[_t_34 + 25] = _h_194;
      e.mem[_t_34 + 26] = _h_195;
      e.mem[_t_34 + 27] = _h_196;
      e.mem[_t_34 + 28] = _h_197;
      e.mem[_t_34 + 29] = _h_198;
      e.mem[_t_34 + 30] = _h_199;
      e.mem[_t_34 + 31] = _h_200;
      e.mem[_t_34 + 32] = _h_201;
      e.mem[_t_34 + 33] = _h_202;
      e.mem[_t_34 + 34] = _h_203;
      e.mem[_t_34 + 35] = _h_204;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K282, _t_34);
      WL_IDX = 36;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_35 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_35 + 0] = term_ctr(CID_SCON, STAT_OFF + 188);
      e.mem[_t_35 + 1] = _h_188;
      return term_tsk(FID_STRING_APPEND, _t_35);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 188);
    r1 = _h_188;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K282)
  {
    WL_POPN(36);
    u32 _world_370 = STK(0);
    u32 _world_371 = STK(1);
    u32 _world_372 = STK(2);
    u32 _world_373 = STK(3);
    Term _world_374 = STK(4);
    u32 _world_375 = STK(5);
    u32 _world_376 = STK(6);
    u32 _world_377 = STK(7);
    u32 _world_378 = STK(8);
    u32 _world_379 = STK(9);
    u32 _world_380 = STK(10);
    u32 _world_381 = STK(11);
    u32 _world_382 = STK(12);
    u32 _world_383 = STK(13);
    u32 _world_384 = STK(14);
    u32 _world_385 = STK(15);
    Term _world_386 = STK(16);
    Term _h_206 = STK(17);
    Term _world_387 = STK(18);
    u32 _world_388 = STK(19);
    u32 _world_389 = STK(20);
    Term _h_207 = STK(21);
    Term _h_208 = STK(22);
    Term _h_209 = STK(23);
    Term _h_210 = STK(24);
    Term _h_211 = STK(25);
    Term _h_212 = STK(26);
    Term _h_213 = STK(27);
    Term _h_214 = STK(28);
    Term _h_215 = STK(29);
    Term _h_216 = STK(30);
    Term _h_217 = STK(31);
    Term _h_218 = STK(32);
    Term _h_219 = STK(33);
    Term _h_220 = STK(34);
    Term _h_221 = STK(35);
    Term _h_205 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(36);
      STK(0) = _world_370;
      STK(1) = _world_371;
      STK(2) = _world_372;
      STK(3) = _world_373;
      STK(4) = _world_374;
      STK(5) = _world_375;
      STK(6) = _world_376;
      STK(7) = _world_377;
      STK(8) = _world_378;
      STK(9) = _world_379;
      STK(10) = _world_380;
      STK(11) = _world_381;
      STK(12) = _world_382;
      STK(13) = _world_383;
      STK(14) = _world_384;
      STK(15) = _world_385;
      STK(16) = _world_386;
      STK(17) = _h_206;
      STK(18) = _world_387;
      STK(19) = _world_388;
      STK(20) = _world_389;
      STK(21) = _h_207;
      STK(22) = _h_208;
      STK(23) = _h_209;
      STK(24) = _h_210;
      STK(25) = _h_211;
      STK(26) = _h_212;
      STK(27) = _h_213;
      STK(28) = _h_214;
      STK(29) = _h_215;
      STK(30) = _h_216;
      STK(31) = _h_217;
      STK(32) = _h_218;
      STK(33) = _h_219;
      STK(34) = _h_220;
      STK(35) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K283;
      WL_PUSHN(36);
    } else {
      u64 _t_36 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K283, WL_CONT, WL_IDX, 1);
      e.mem[_t_36 + 0] = _world_370;
      e.mem[_t_36 + 1] = _world_371;
      e.mem[_t_36 + 2] = _world_372;
      e.mem[_t_36 + 3] = _world_373;
      e.mem[_t_36 + 4] = _world_374;
      e.mem[_t_36 + 5] = _world_375;
      e.mem[_t_36 + 6] = _world_376;
      e.mem[_t_36 + 7] = _world_377;
      e.mem[_t_36 + 8] = _world_378;
      e.mem[_t_36 + 9] = _world_379;
      e.mem[_t_36 + 10] = _world_380;
      e.mem[_t_36 + 11] = _world_381;
      e.mem[_t_36 + 12] = _world_382;
      e.mem[_t_36 + 13] = _world_383;
      e.mem[_t_36 + 14] = _world_384;
      e.mem[_t_36 + 15] = _world_385;
      e.mem[_t_36 + 16] = _world_386;
      e.mem[_t_36 + 17] = _h_206;
      e.mem[_t_36 + 18] = _world_387;
      e.mem[_t_36 + 19] = _world_388;
      e.mem[_t_36 + 20] = _world_389;
      e.mem[_t_36 + 21] = _h_207;
      e.mem[_t_36 + 22] = _h_208;
      e.mem[_t_36 + 23] = _h_209;
      e.mem[_t_36 + 24] = _h_210;
      e.mem[_t_36 + 25] = _h_211;
      e.mem[_t_36 + 26] = _h_212;
      e.mem[_t_36 + 27] = _h_213;
      e.mem[_t_36 + 28] = _h_214;
      e.mem[_t_36 + 29] = _h_215;
      e.mem[_t_36 + 30] = _h_216;
      e.mem[_t_36 + 31] = _h_217;
      e.mem[_t_36 + 32] = _h_218;
      e.mem[_t_36 + 33] = _h_219;
      e.mem[_t_36 + 34] = _h_220;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K283, _t_36);
      WL_IDX = 35;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_37 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_37 + 0] = _h_221;
      e.mem[_t_37 + 1] = _h_205;
      return term_tsk(FID_STRING_APPEND, _t_37);
    }
    r0 = _h_221;
    r1 = _h_205;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K283)
  {
    WL_POPN(35);
    u32 _world_390 = STK(0);
    u32 _world_391 = STK(1);
    u32 _world_392 = STK(2);
    u32 _world_393 = STK(3);
    Term _world_394 = STK(4);
    u32 _world_395 = STK(5);
    u32 _world_396 = STK(6);
    u32 _world_397 = STK(7);
    u32 _world_398 = STK(8);
    u32 _world_399 = STK(9);
    u32 _world_400 = STK(10);
    u32 _world_401 = STK(11);
    u32 _world_402 = STK(12);
    u32 _world_403 = STK(13);
    u32 _world_404 = STK(14);
    u32 _world_405 = STK(15);
    Term _world_406 = STK(16);
    Term _h_223 = STK(17);
    Term _world_407 = STK(18);
    u32 _world_408 = STK(19);
    u32 _world_409 = STK(20);
    Term _h_224 = STK(21);
    Term _h_225 = STK(22);
    Term _h_226 = STK(23);
    Term _h_227 = STK(24);
    Term _h_228 = STK(25);
    Term _h_229 = STK(26);
    Term _h_230 = STK(27);
    Term _h_231 = STK(28);
    Term _h_232 = STK(29);
    Term _h_233 = STK(30);
    Term _h_234 = STK(31);
    Term _h_235 = STK(32);
    Term _h_236 = STK(33);
    Term _h_237 = STK(34);
    Term _h_222 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(36);
      STK(0) = _world_390;
      STK(1) = _world_391;
      STK(2) = _world_392;
      STK(3) = _world_393;
      STK(4) = _world_394;
      STK(5) = _world_395;
      STK(6) = _world_396;
      STK(7) = _world_397;
      STK(8) = _world_398;
      STK(9) = _world_399;
      STK(10) = _world_400;
      STK(11) = _world_401;
      STK(12) = _world_402;
      STK(13) = _world_403;
      STK(14) = _world_404;
      STK(15) = _world_405;
      STK(16) = _world_406;
      STK(17) = _h_223;
      STK(18) = _world_407;
      STK(19) = _world_408;
      STK(20) = _world_409;
      STK(21) = _h_224;
      STK(22) = _h_225;
      STK(23) = _h_226;
      STK(24) = _h_227;
      STK(25) = _h_228;
      STK(26) = _h_229;
      STK(27) = _h_230;
      STK(28) = _h_231;
      STK(29) = _h_232;
      STK(30) = _h_233;
      STK(31) = _h_234;
      STK(32) = _h_235;
      STK(33) = _h_236;
      STK(34) = _h_237;
      STK(35) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K284;
      WL_PUSHN(36);
    } else {
      u64 _t_38 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K284, WL_CONT, WL_IDX, 1);
      e.mem[_t_38 + 0] = _world_390;
      e.mem[_t_38 + 1] = _world_391;
      e.mem[_t_38 + 2] = _world_392;
      e.mem[_t_38 + 3] = _world_393;
      e.mem[_t_38 + 4] = _world_394;
      e.mem[_t_38 + 5] = _world_395;
      e.mem[_t_38 + 6] = _world_396;
      e.mem[_t_38 + 7] = _world_397;
      e.mem[_t_38 + 8] = _world_398;
      e.mem[_t_38 + 9] = _world_399;
      e.mem[_t_38 + 10] = _world_400;
      e.mem[_t_38 + 11] = _world_401;
      e.mem[_t_38 + 12] = _world_402;
      e.mem[_t_38 + 13] = _world_403;
      e.mem[_t_38 + 14] = _world_404;
      e.mem[_t_38 + 15] = _world_405;
      e.mem[_t_38 + 16] = _world_406;
      e.mem[_t_38 + 17] = _h_223;
      e.mem[_t_38 + 18] = _world_407;
      e.mem[_t_38 + 19] = _world_408;
      e.mem[_t_38 + 20] = _world_409;
      e.mem[_t_38 + 21] = _h_224;
      e.mem[_t_38 + 22] = _h_225;
      e.mem[_t_38 + 23] = _h_226;
      e.mem[_t_38 + 24] = _h_227;
      e.mem[_t_38 + 25] = _h_228;
      e.mem[_t_38 + 26] = _h_229;
      e.mem[_t_38 + 27] = _h_230;
      e.mem[_t_38 + 28] = _h_231;
      e.mem[_t_38 + 29] = _h_232;
      e.mem[_t_38 + 30] = _h_233;
      e.mem[_t_38 + 31] = _h_234;
      e.mem[_t_38 + 32] = _h_235;
      e.mem[_t_38 + 33] = _h_236;
      e.mem[_t_38 + 34] = _h_237;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K284, _t_38);
      WL_IDX = 35;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_39 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_39 + 0] = term_ctr(CID_SCON, STAT_OFF + 214);
      e.mem[_t_39 + 1] = _h_222;
      return term_tsk(FID_STRING_APPEND, _t_39);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 214);
    r1 = _h_222;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K284)
  {
    WL_POPN(35);
    u32 _world_410 = STK(0);
    u32 _world_411 = STK(1);
    u32 _world_412 = STK(2);
    u32 _world_413 = STK(3);
    Term _world_414 = STK(4);
    u32 _world_415 = STK(5);
    u32 _world_416 = STK(6);
    u32 _world_417 = STK(7);
    u32 _world_418 = STK(8);
    u32 _world_419 = STK(9);
    u32 _world_420 = STK(10);
    u32 _world_421 = STK(11);
    u32 _world_422 = STK(12);
    u32 _world_423 = STK(13);
    u32 _world_424 = STK(14);
    u32 _world_425 = STK(15);
    Term _world_426 = STK(16);
    Term _h_239 = STK(17);
    Term _world_427 = STK(18);
    u32 _world_428 = STK(19);
    u32 _world_429 = STK(20);
    Term _h_240 = STK(21);
    Term _h_241 = STK(22);
    Term _h_242 = STK(23);
    Term _h_243 = STK(24);
    Term _h_244 = STK(25);
    Term _h_245 = STK(26);
    Term _h_246 = STK(27);
    Term _h_247 = STK(28);
    Term _h_248 = STK(29);
    Term _h_249 = STK(30);
    Term _h_250 = STK(31);
    Term _h_251 = STK(32);
    Term _h_252 = STK(33);
    Term _h_253 = STK(34);
    Term _h_238 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(35);
      STK(0) = _world_410;
      STK(1) = _world_411;
      STK(2) = _world_412;
      STK(3) = _world_413;
      STK(4) = _world_414;
      STK(5) = _world_415;
      STK(6) = _world_416;
      STK(7) = _world_417;
      STK(8) = _world_418;
      STK(9) = _world_419;
      STK(10) = _world_420;
      STK(11) = _world_421;
      STK(12) = _world_422;
      STK(13) = _world_423;
      STK(14) = _world_424;
      STK(15) = _world_425;
      STK(16) = _world_426;
      STK(17) = _h_239;
      STK(18) = _world_427;
      STK(19) = _world_428;
      STK(20) = _world_429;
      STK(21) = _h_240;
      STK(22) = _h_241;
      STK(23) = _h_242;
      STK(24) = _h_243;
      STK(25) = _h_244;
      STK(26) = _h_245;
      STK(27) = _h_246;
      STK(28) = _h_247;
      STK(29) = _h_248;
      STK(30) = _h_249;
      STK(31) = _h_250;
      STK(32) = _h_251;
      STK(33) = _h_252;
      STK(34) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K285;
      WL_PUSHN(35);
    } else {
      u64 _t_40 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K285, WL_CONT, WL_IDX, 1);
      e.mem[_t_40 + 0] = _world_410;
      e.mem[_t_40 + 1] = _world_411;
      e.mem[_t_40 + 2] = _world_412;
      e.mem[_t_40 + 3] = _world_413;
      e.mem[_t_40 + 4] = _world_414;
      e.mem[_t_40 + 5] = _world_415;
      e.mem[_t_40 + 6] = _world_416;
      e.mem[_t_40 + 7] = _world_417;
      e.mem[_t_40 + 8] = _world_418;
      e.mem[_t_40 + 9] = _world_419;
      e.mem[_t_40 + 10] = _world_420;
      e.mem[_t_40 + 11] = _world_421;
      e.mem[_t_40 + 12] = _world_422;
      e.mem[_t_40 + 13] = _world_423;
      e.mem[_t_40 + 14] = _world_424;
      e.mem[_t_40 + 15] = _world_425;
      e.mem[_t_40 + 16] = _world_426;
      e.mem[_t_40 + 17] = _h_239;
      e.mem[_t_40 + 18] = _world_427;
      e.mem[_t_40 + 19] = _world_428;
      e.mem[_t_40 + 20] = _world_429;
      e.mem[_t_40 + 21] = _h_240;
      e.mem[_t_40 + 22] = _h_241;
      e.mem[_t_40 + 23] = _h_242;
      e.mem[_t_40 + 24] = _h_243;
      e.mem[_t_40 + 25] = _h_244;
      e.mem[_t_40 + 26] = _h_245;
      e.mem[_t_40 + 27] = _h_246;
      e.mem[_t_40 + 28] = _h_247;
      e.mem[_t_40 + 29] = _h_248;
      e.mem[_t_40 + 30] = _h_249;
      e.mem[_t_40 + 31] = _h_250;
      e.mem[_t_40 + 32] = _h_251;
      e.mem[_t_40 + 33] = _h_252;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K285, _t_40);
      WL_IDX = 34;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_41 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_41 + 0] = _h_253;
      e.mem[_t_41 + 1] = _h_238;
      return term_tsk(FID_STRING_APPEND, _t_41);
    }
    r0 = _h_253;
    r1 = _h_238;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K285)
  {
    WL_POPN(34);
    u32 _world_430 = STK(0);
    u32 _world_431 = STK(1);
    u32 _world_432 = STK(2);
    u32 _world_433 = STK(3);
    Term _world_434 = STK(4);
    u32 _world_435 = STK(5);
    u32 _world_436 = STK(6);
    u32 _world_437 = STK(7);
    u32 _world_438 = STK(8);
    u32 _world_439 = STK(9);
    u32 _world_440 = STK(10);
    u32 _world_441 = STK(11);
    u32 _world_442 = STK(12);
    u32 _world_443 = STK(13);
    u32 _world_444 = STK(14);
    u32 _world_445 = STK(15);
    Term _world_446 = STK(16);
    Term _h_255 = STK(17);
    Term _world_447 = STK(18);
    u32 _world_448 = STK(19);
    u32 _world_449 = STK(20);
    Term _h_256 = STK(21);
    Term _h_257 = STK(22);
    Term _h_258 = STK(23);
    Term _h_259 = STK(24);
    Term _h_260 = STK(25);
    Term _h_261 = STK(26);
    Term _h_262 = STK(27);
    Term _h_263 = STK(28);
    Term _h_264 = STK(29);
    Term _h_265 = STK(30);
    Term _h_266 = STK(31);
    Term _h_267 = STK(32);
    Term _h_268 = STK(33);
    Term _h_254 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(35);
      STK(0) = _world_430;
      STK(1) = _world_431;
      STK(2) = _world_432;
      STK(3) = _world_433;
      STK(4) = _world_434;
      STK(5) = _world_435;
      STK(6) = _world_436;
      STK(7) = _world_437;
      STK(8) = _world_438;
      STK(9) = _world_439;
      STK(10) = _world_440;
      STK(11) = _world_441;
      STK(12) = _world_442;
      STK(13) = _world_443;
      STK(14) = _world_444;
      STK(15) = _world_445;
      STK(16) = _world_446;
      STK(17) = _h_255;
      STK(18) = _world_447;
      STK(19) = _world_448;
      STK(20) = _world_449;
      STK(21) = _h_256;
      STK(22) = _h_257;
      STK(23) = _h_258;
      STK(24) = _h_259;
      STK(25) = _h_260;
      STK(26) = _h_261;
      STK(27) = _h_262;
      STK(28) = _h_263;
      STK(29) = _h_264;
      STK(30) = _h_265;
      STK(31) = _h_266;
      STK(32) = _h_267;
      STK(33) = _h_268;
      STK(34) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K286;
      WL_PUSHN(35);
    } else {
      u64 _t_42 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K286, WL_CONT, WL_IDX, 1);
      e.mem[_t_42 + 0] = _world_430;
      e.mem[_t_42 + 1] = _world_431;
      e.mem[_t_42 + 2] = _world_432;
      e.mem[_t_42 + 3] = _world_433;
      e.mem[_t_42 + 4] = _world_434;
      e.mem[_t_42 + 5] = _world_435;
      e.mem[_t_42 + 6] = _world_436;
      e.mem[_t_42 + 7] = _world_437;
      e.mem[_t_42 + 8] = _world_438;
      e.mem[_t_42 + 9] = _world_439;
      e.mem[_t_42 + 10] = _world_440;
      e.mem[_t_42 + 11] = _world_441;
      e.mem[_t_42 + 12] = _world_442;
      e.mem[_t_42 + 13] = _world_443;
      e.mem[_t_42 + 14] = _world_444;
      e.mem[_t_42 + 15] = _world_445;
      e.mem[_t_42 + 16] = _world_446;
      e.mem[_t_42 + 17] = _h_255;
      e.mem[_t_42 + 18] = _world_447;
      e.mem[_t_42 + 19] = _world_448;
      e.mem[_t_42 + 20] = _world_449;
      e.mem[_t_42 + 21] = _h_256;
      e.mem[_t_42 + 22] = _h_257;
      e.mem[_t_42 + 23] = _h_258;
      e.mem[_t_42 + 24] = _h_259;
      e.mem[_t_42 + 25] = _h_260;
      e.mem[_t_42 + 26] = _h_261;
      e.mem[_t_42 + 27] = _h_262;
      e.mem[_t_42 + 28] = _h_263;
      e.mem[_t_42 + 29] = _h_264;
      e.mem[_t_42 + 30] = _h_265;
      e.mem[_t_42 + 31] = _h_266;
      e.mem[_t_42 + 32] = _h_267;
      e.mem[_t_42 + 33] = _h_268;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K286, _t_42);
      WL_IDX = 34;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_43 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_43 + 0] = term_ctr(CID_SCON, STAT_OFF + 230);
      e.mem[_t_43 + 1] = _h_254;
      return term_tsk(FID_STRING_APPEND, _t_43);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 230);
    r1 = _h_254;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K286)
  {
    WL_POPN(34);
    u32 _world_450 = STK(0);
    u32 _world_451 = STK(1);
    u32 _world_452 = STK(2);
    u32 _world_453 = STK(3);
    Term _world_454 = STK(4);
    u32 _world_455 = STK(5);
    u32 _world_456 = STK(6);
    u32 _world_457 = STK(7);
    u32 _world_458 = STK(8);
    u32 _world_459 = STK(9);
    u32 _world_460 = STK(10);
    u32 _world_461 = STK(11);
    u32 _world_462 = STK(12);
    u32 _world_463 = STK(13);
    u32 _world_464 = STK(14);
    u32 _world_465 = STK(15);
    Term _world_466 = STK(16);
    Term _h_270 = STK(17);
    Term _world_467 = STK(18);
    u32 _world_468 = STK(19);
    u32 _world_469 = STK(20);
    Term _h_271 = STK(21);
    Term _h_272 = STK(22);
    Term _h_273 = STK(23);
    Term _h_274 = STK(24);
    Term _h_275 = STK(25);
    Term _h_276 = STK(26);
    Term _h_277 = STK(27);
    Term _h_278 = STK(28);
    Term _h_279 = STK(29);
    Term _h_280 = STK(30);
    Term _h_281 = STK(31);
    Term _h_282 = STK(32);
    Term _h_283 = STK(33);
    Term _h_269 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(34);
      STK(0) = _world_450;
      STK(1) = _world_451;
      STK(2) = _world_452;
      STK(3) = _world_453;
      STK(4) = _world_454;
      STK(5) = _world_455;
      STK(6) = _world_456;
      STK(7) = _world_457;
      STK(8) = _world_458;
      STK(9) = _world_459;
      STK(10) = _world_460;
      STK(11) = _world_461;
      STK(12) = _world_462;
      STK(13) = _world_463;
      STK(14) = _world_464;
      STK(15) = _world_465;
      STK(16) = _world_466;
      STK(17) = _h_270;
      STK(18) = _world_467;
      STK(19) = _world_468;
      STK(20) = _world_469;
      STK(21) = _h_271;
      STK(22) = _h_272;
      STK(23) = _h_273;
      STK(24) = _h_274;
      STK(25) = _h_275;
      STK(26) = _h_276;
      STK(27) = _h_277;
      STK(28) = _h_278;
      STK(29) = _h_279;
      STK(30) = _h_280;
      STK(31) = _h_281;
      STK(32) = _h_282;
      STK(33) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K287;
      WL_PUSHN(34);
    } else {
      u64 _t_44 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K287, WL_CONT, WL_IDX, 1);
      e.mem[_t_44 + 0] = _world_450;
      e.mem[_t_44 + 1] = _world_451;
      e.mem[_t_44 + 2] = _world_452;
      e.mem[_t_44 + 3] = _world_453;
      e.mem[_t_44 + 4] = _world_454;
      e.mem[_t_44 + 5] = _world_455;
      e.mem[_t_44 + 6] = _world_456;
      e.mem[_t_44 + 7] = _world_457;
      e.mem[_t_44 + 8] = _world_458;
      e.mem[_t_44 + 9] = _world_459;
      e.mem[_t_44 + 10] = _world_460;
      e.mem[_t_44 + 11] = _world_461;
      e.mem[_t_44 + 12] = _world_462;
      e.mem[_t_44 + 13] = _world_463;
      e.mem[_t_44 + 14] = _world_464;
      e.mem[_t_44 + 15] = _world_465;
      e.mem[_t_44 + 16] = _world_466;
      e.mem[_t_44 + 17] = _h_270;
      e.mem[_t_44 + 18] = _world_467;
      e.mem[_t_44 + 19] = _world_468;
      e.mem[_t_44 + 20] = _world_469;
      e.mem[_t_44 + 21] = _h_271;
      e.mem[_t_44 + 22] = _h_272;
      e.mem[_t_44 + 23] = _h_273;
      e.mem[_t_44 + 24] = _h_274;
      e.mem[_t_44 + 25] = _h_275;
      e.mem[_t_44 + 26] = _h_276;
      e.mem[_t_44 + 27] = _h_277;
      e.mem[_t_44 + 28] = _h_278;
      e.mem[_t_44 + 29] = _h_279;
      e.mem[_t_44 + 30] = _h_280;
      e.mem[_t_44 + 31] = _h_281;
      e.mem[_t_44 + 32] = _h_282;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K287, _t_44);
      WL_IDX = 33;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_45 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_45 + 0] = _h_283;
      e.mem[_t_45 + 1] = _h_269;
      return term_tsk(FID_STRING_APPEND, _t_45);
    }
    r0 = _h_283;
    r1 = _h_269;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K287)
  {
    WL_POPN(33);
    u32 _world_470 = STK(0);
    u32 _world_471 = STK(1);
    u32 _world_472 = STK(2);
    u32 _world_473 = STK(3);
    Term _world_474 = STK(4);
    u32 _world_475 = STK(5);
    u32 _world_476 = STK(6);
    u32 _world_477 = STK(7);
    u32 _world_478 = STK(8);
    u32 _world_479 = STK(9);
    u32 _world_480 = STK(10);
    u32 _world_481 = STK(11);
    u32 _world_482 = STK(12);
    u32 _world_483 = STK(13);
    u32 _world_484 = STK(14);
    u32 _world_485 = STK(15);
    Term _world_486 = STK(16);
    Term _h_285 = STK(17);
    Term _world_487 = STK(18);
    u32 _world_488 = STK(19);
    u32 _world_489 = STK(20);
    Term _h_286 = STK(21);
    Term _h_287 = STK(22);
    Term _h_288 = STK(23);
    Term _h_289 = STK(24);
    Term _h_290 = STK(25);
    Term _h_291 = STK(26);
    Term _h_292 = STK(27);
    Term _h_293 = STK(28);
    Term _h_294 = STK(29);
    Term _h_295 = STK(30);
    Term _h_296 = STK(31);
    Term _h_297 = STK(32);
    Term _h_284 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(34);
      STK(0) = _world_470;
      STK(1) = _world_471;
      STK(2) = _world_472;
      STK(3) = _world_473;
      STK(4) = _world_474;
      STK(5) = _world_475;
      STK(6) = _world_476;
      STK(7) = _world_477;
      STK(8) = _world_478;
      STK(9) = _world_479;
      STK(10) = _world_480;
      STK(11) = _world_481;
      STK(12) = _world_482;
      STK(13) = _world_483;
      STK(14) = _world_484;
      STK(15) = _world_485;
      STK(16) = _world_486;
      STK(17) = _h_285;
      STK(18) = _world_487;
      STK(19) = _world_488;
      STK(20) = _world_489;
      STK(21) = _h_286;
      STK(22) = _h_287;
      STK(23) = _h_288;
      STK(24) = _h_289;
      STK(25) = _h_290;
      STK(26) = _h_291;
      STK(27) = _h_292;
      STK(28) = _h_293;
      STK(29) = _h_294;
      STK(30) = _h_295;
      STK(31) = _h_296;
      STK(32) = _h_297;
      STK(33) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K288;
      WL_PUSHN(34);
    } else {
      u64 _t_46 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K288, WL_CONT, WL_IDX, 1);
      e.mem[_t_46 + 0] = _world_470;
      e.mem[_t_46 + 1] = _world_471;
      e.mem[_t_46 + 2] = _world_472;
      e.mem[_t_46 + 3] = _world_473;
      e.mem[_t_46 + 4] = _world_474;
      e.mem[_t_46 + 5] = _world_475;
      e.mem[_t_46 + 6] = _world_476;
      e.mem[_t_46 + 7] = _world_477;
      e.mem[_t_46 + 8] = _world_478;
      e.mem[_t_46 + 9] = _world_479;
      e.mem[_t_46 + 10] = _world_480;
      e.mem[_t_46 + 11] = _world_481;
      e.mem[_t_46 + 12] = _world_482;
      e.mem[_t_46 + 13] = _world_483;
      e.mem[_t_46 + 14] = _world_484;
      e.mem[_t_46 + 15] = _world_485;
      e.mem[_t_46 + 16] = _world_486;
      e.mem[_t_46 + 17] = _h_285;
      e.mem[_t_46 + 18] = _world_487;
      e.mem[_t_46 + 19] = _world_488;
      e.mem[_t_46 + 20] = _world_489;
      e.mem[_t_46 + 21] = _h_286;
      e.mem[_t_46 + 22] = _h_287;
      e.mem[_t_46 + 23] = _h_288;
      e.mem[_t_46 + 24] = _h_289;
      e.mem[_t_46 + 25] = _h_290;
      e.mem[_t_46 + 26] = _h_291;
      e.mem[_t_46 + 27] = _h_292;
      e.mem[_t_46 + 28] = _h_293;
      e.mem[_t_46 + 29] = _h_294;
      e.mem[_t_46 + 30] = _h_295;
      e.mem[_t_46 + 31] = _h_296;
      e.mem[_t_46 + 32] = _h_297;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K288, _t_46);
      WL_IDX = 33;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_47 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_47 + 0] = term_ctr(CID_SCON, STAT_OFF + 242);
      e.mem[_t_47 + 1] = _h_284;
      return term_tsk(FID_STRING_APPEND, _t_47);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 242);
    r1 = _h_284;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K288)
  {
    WL_POPN(33);
    u32 _world_490 = STK(0);
    u32 _world_491 = STK(1);
    u32 _world_492 = STK(2);
    u32 _world_493 = STK(3);
    Term _world_494 = STK(4);
    u32 _world_495 = STK(5);
    u32 _world_496 = STK(6);
    u32 _world_497 = STK(7);
    u32 _world_498 = STK(8);
    u32 _world_499 = STK(9);
    u32 _world_500 = STK(10);
    u32 _world_501 = STK(11);
    u32 _world_502 = STK(12);
    u32 _world_503 = STK(13);
    u32 _world_504 = STK(14);
    u32 _world_505 = STK(15);
    Term _world_506 = STK(16);
    Term _h_299 = STK(17);
    Term _world_507 = STK(18);
    u32 _world_508 = STK(19);
    u32 _world_509 = STK(20);
    Term _h_300 = STK(21);
    Term _h_301 = STK(22);
    Term _h_302 = STK(23);
    Term _h_303 = STK(24);
    Term _h_304 = STK(25);
    Term _h_305 = STK(26);
    Term _h_306 = STK(27);
    Term _h_307 = STK(28);
    Term _h_308 = STK(29);
    Term _h_309 = STK(30);
    Term _h_310 = STK(31);
    Term _h_311 = STK(32);
    Term _h_298 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(33);
      STK(0) = _world_490;
      STK(1) = _world_491;
      STK(2) = _world_492;
      STK(3) = _world_493;
      STK(4) = _world_494;
      STK(5) = _world_495;
      STK(6) = _world_496;
      STK(7) = _world_497;
      STK(8) = _world_498;
      STK(9) = _world_499;
      STK(10) = _world_500;
      STK(11) = _world_501;
      STK(12) = _world_502;
      STK(13) = _world_503;
      STK(14) = _world_504;
      STK(15) = _world_505;
      STK(16) = _world_506;
      STK(17) = _h_299;
      STK(18) = _world_507;
      STK(19) = _world_508;
      STK(20) = _world_509;
      STK(21) = _h_300;
      STK(22) = _h_301;
      STK(23) = _h_302;
      STK(24) = _h_303;
      STK(25) = _h_304;
      STK(26) = _h_305;
      STK(27) = _h_306;
      STK(28) = _h_307;
      STK(29) = _h_308;
      STK(30) = _h_309;
      STK(31) = _h_310;
      STK(32) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K289;
      WL_PUSHN(33);
    } else {
      u64 _t_48 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K289, WL_CONT, WL_IDX, 1);
      e.mem[_t_48 + 0] = _world_490;
      e.mem[_t_48 + 1] = _world_491;
      e.mem[_t_48 + 2] = _world_492;
      e.mem[_t_48 + 3] = _world_493;
      e.mem[_t_48 + 4] = _world_494;
      e.mem[_t_48 + 5] = _world_495;
      e.mem[_t_48 + 6] = _world_496;
      e.mem[_t_48 + 7] = _world_497;
      e.mem[_t_48 + 8] = _world_498;
      e.mem[_t_48 + 9] = _world_499;
      e.mem[_t_48 + 10] = _world_500;
      e.mem[_t_48 + 11] = _world_501;
      e.mem[_t_48 + 12] = _world_502;
      e.mem[_t_48 + 13] = _world_503;
      e.mem[_t_48 + 14] = _world_504;
      e.mem[_t_48 + 15] = _world_505;
      e.mem[_t_48 + 16] = _world_506;
      e.mem[_t_48 + 17] = _h_299;
      e.mem[_t_48 + 18] = _world_507;
      e.mem[_t_48 + 19] = _world_508;
      e.mem[_t_48 + 20] = _world_509;
      e.mem[_t_48 + 21] = _h_300;
      e.mem[_t_48 + 22] = _h_301;
      e.mem[_t_48 + 23] = _h_302;
      e.mem[_t_48 + 24] = _h_303;
      e.mem[_t_48 + 25] = _h_304;
      e.mem[_t_48 + 26] = _h_305;
      e.mem[_t_48 + 27] = _h_306;
      e.mem[_t_48 + 28] = _h_307;
      e.mem[_t_48 + 29] = _h_308;
      e.mem[_t_48 + 30] = _h_309;
      e.mem[_t_48 + 31] = _h_310;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K289, _t_48);
      WL_IDX = 32;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_49 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_49 + 0] = _h_311;
      e.mem[_t_49 + 1] = _h_298;
      return term_tsk(FID_STRING_APPEND, _t_49);
    }
    r0 = _h_311;
    r1 = _h_298;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K289)
  {
    WL_POPN(32);
    u32 _world_510 = STK(0);
    u32 _world_511 = STK(1);
    u32 _world_512 = STK(2);
    u32 _world_513 = STK(3);
    Term _world_514 = STK(4);
    u32 _world_515 = STK(5);
    u32 _world_516 = STK(6);
    u32 _world_517 = STK(7);
    u32 _world_518 = STK(8);
    u32 _world_519 = STK(9);
    u32 _world_520 = STK(10);
    u32 _world_521 = STK(11);
    u32 _world_522 = STK(12);
    u32 _world_523 = STK(13);
    u32 _world_524 = STK(14);
    u32 _world_525 = STK(15);
    Term _world_526 = STK(16);
    Term _h_313 = STK(17);
    Term _world_527 = STK(18);
    u32 _world_528 = STK(19);
    u32 _world_529 = STK(20);
    Term _h_314 = STK(21);
    Term _h_315 = STK(22);
    Term _h_316 = STK(23);
    Term _h_317 = STK(24);
    Term _h_318 = STK(25);
    Term _h_319 = STK(26);
    Term _h_320 = STK(27);
    Term _h_321 = STK(28);
    Term _h_322 = STK(29);
    Term _h_323 = STK(30);
    Term _h_324 = STK(31);
    Term _h_312 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(33);
      STK(0) = _world_510;
      STK(1) = _world_511;
      STK(2) = _world_512;
      STK(3) = _world_513;
      STK(4) = _world_514;
      STK(5) = _world_515;
      STK(6) = _world_516;
      STK(7) = _world_517;
      STK(8) = _world_518;
      STK(9) = _world_519;
      STK(10) = _world_520;
      STK(11) = _world_521;
      STK(12) = _world_522;
      STK(13) = _world_523;
      STK(14) = _world_524;
      STK(15) = _world_525;
      STK(16) = _world_526;
      STK(17) = _h_313;
      STK(18) = _world_527;
      STK(19) = _world_528;
      STK(20) = _world_529;
      STK(21) = _h_314;
      STK(22) = _h_315;
      STK(23) = _h_316;
      STK(24) = _h_317;
      STK(25) = _h_318;
      STK(26) = _h_319;
      STK(27) = _h_320;
      STK(28) = _h_321;
      STK(29) = _h_322;
      STK(30) = _h_323;
      STK(31) = _h_324;
      STK(32) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K290;
      WL_PUSHN(33);
    } else {
      u64 _t_50 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K290, WL_CONT, WL_IDX, 1);
      e.mem[_t_50 + 0] = _world_510;
      e.mem[_t_50 + 1] = _world_511;
      e.mem[_t_50 + 2] = _world_512;
      e.mem[_t_50 + 3] = _world_513;
      e.mem[_t_50 + 4] = _world_514;
      e.mem[_t_50 + 5] = _world_515;
      e.mem[_t_50 + 6] = _world_516;
      e.mem[_t_50 + 7] = _world_517;
      e.mem[_t_50 + 8] = _world_518;
      e.mem[_t_50 + 9] = _world_519;
      e.mem[_t_50 + 10] = _world_520;
      e.mem[_t_50 + 11] = _world_521;
      e.mem[_t_50 + 12] = _world_522;
      e.mem[_t_50 + 13] = _world_523;
      e.mem[_t_50 + 14] = _world_524;
      e.mem[_t_50 + 15] = _world_525;
      e.mem[_t_50 + 16] = _world_526;
      e.mem[_t_50 + 17] = _h_313;
      e.mem[_t_50 + 18] = _world_527;
      e.mem[_t_50 + 19] = _world_528;
      e.mem[_t_50 + 20] = _world_529;
      e.mem[_t_50 + 21] = _h_314;
      e.mem[_t_50 + 22] = _h_315;
      e.mem[_t_50 + 23] = _h_316;
      e.mem[_t_50 + 24] = _h_317;
      e.mem[_t_50 + 25] = _h_318;
      e.mem[_t_50 + 26] = _h_319;
      e.mem[_t_50 + 27] = _h_320;
      e.mem[_t_50 + 28] = _h_321;
      e.mem[_t_50 + 29] = _h_322;
      e.mem[_t_50 + 30] = _h_323;
      e.mem[_t_50 + 31] = _h_324;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K290, _t_50);
      WL_IDX = 32;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_51 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_51 + 0] = term_ctr(CID_SCON, STAT_OFF + 252);
      e.mem[_t_51 + 1] = _h_312;
      return term_tsk(FID_STRING_APPEND, _t_51);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 252);
    r1 = _h_312;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K290)
  {
    WL_POPN(32);
    u32 _world_530 = STK(0);
    u32 _world_531 = STK(1);
    u32 _world_532 = STK(2);
    u32 _world_533 = STK(3);
    Term _world_534 = STK(4);
    u32 _world_535 = STK(5);
    u32 _world_536 = STK(6);
    u32 _world_537 = STK(7);
    u32 _world_538 = STK(8);
    u32 _world_539 = STK(9);
    u32 _world_540 = STK(10);
    u32 _world_541 = STK(11);
    u32 _world_542 = STK(12);
    u32 _world_543 = STK(13);
    u32 _world_544 = STK(14);
    u32 _world_545 = STK(15);
    Term _world_546 = STK(16);
    Term _h_326 = STK(17);
    Term _world_547 = STK(18);
    u32 _world_548 = STK(19);
    u32 _world_549 = STK(20);
    Term _h_327 = STK(21);
    Term _h_328 = STK(22);
    Term _h_329 = STK(23);
    Term _h_330 = STK(24);
    Term _h_331 = STK(25);
    Term _h_332 = STK(26);
    Term _h_333 = STK(27);
    Term _h_334 = STK(28);
    Term _h_335 = STK(29);
    Term _h_336 = STK(30);
    Term _h_337 = STK(31);
    Term _h_325 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(32);
      STK(0) = _world_530;
      STK(1) = _world_531;
      STK(2) = _world_532;
      STK(3) = _world_533;
      STK(4) = _world_534;
      STK(5) = _world_535;
      STK(6) = _world_536;
      STK(7) = _world_537;
      STK(8) = _world_538;
      STK(9) = _world_539;
      STK(10) = _world_540;
      STK(11) = _world_541;
      STK(12) = _world_542;
      STK(13) = _world_543;
      STK(14) = _world_544;
      STK(15) = _world_545;
      STK(16) = _world_546;
      STK(17) = _h_326;
      STK(18) = _world_547;
      STK(19) = _world_548;
      STK(20) = _world_549;
      STK(21) = _h_327;
      STK(22) = _h_328;
      STK(23) = _h_329;
      STK(24) = _h_330;
      STK(25) = _h_331;
      STK(26) = _h_333;
      STK(27) = _h_334;
      STK(28) = _h_335;
      STK(29) = _h_336;
      STK(30) = _h_337;
      STK(31) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K291;
      WL_PUSHN(32);
    } else {
      u64 _t_52 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K291, WL_CONT, WL_IDX, 1);
      e.mem[_t_52 + 0] = _world_530;
      e.mem[_t_52 + 1] = _world_531;
      e.mem[_t_52 + 2] = _world_532;
      e.mem[_t_52 + 3] = _world_533;
      e.mem[_t_52 + 4] = _world_534;
      e.mem[_t_52 + 5] = _world_535;
      e.mem[_t_52 + 6] = _world_536;
      e.mem[_t_52 + 7] = _world_537;
      e.mem[_t_52 + 8] = _world_538;
      e.mem[_t_52 + 9] = _world_539;
      e.mem[_t_52 + 10] = _world_540;
      e.mem[_t_52 + 11] = _world_541;
      e.mem[_t_52 + 12] = _world_542;
      e.mem[_t_52 + 13] = _world_543;
      e.mem[_t_52 + 14] = _world_544;
      e.mem[_t_52 + 15] = _world_545;
      e.mem[_t_52 + 16] = _world_546;
      e.mem[_t_52 + 17] = _h_326;
      e.mem[_t_52 + 18] = _world_547;
      e.mem[_t_52 + 19] = _world_548;
      e.mem[_t_52 + 20] = _world_549;
      e.mem[_t_52 + 21] = _h_327;
      e.mem[_t_52 + 22] = _h_328;
      e.mem[_t_52 + 23] = _h_329;
      e.mem[_t_52 + 24] = _h_330;
      e.mem[_t_52 + 25] = _h_331;
      e.mem[_t_52 + 26] = _h_333;
      e.mem[_t_52 + 27] = _h_334;
      e.mem[_t_52 + 28] = _h_335;
      e.mem[_t_52 + 29] = _h_336;
      e.mem[_t_52 + 30] = _h_337;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K291, _t_52);
      WL_IDX = 31;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_53 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_53 + 0] = _h_332;
      e.mem[_t_53 + 1] = _h_325;
      return term_tsk(FID_STRING_APPEND, _t_53);
    }
    r0 = _h_332;
    r1 = _h_325;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K291)
  {
    WL_POPN(31);
    u32 _world_550 = STK(0);
    u32 _world_551 = STK(1);
    u32 _world_552 = STK(2);
    u32 _world_553 = STK(3);
    Term _world_554 = STK(4);
    u32 _world_555 = STK(5);
    u32 _world_556 = STK(6);
    u32 _world_557 = STK(7);
    u32 _world_558 = STK(8);
    u32 _world_559 = STK(9);
    u32 _world_560 = STK(10);
    u32 _world_561 = STK(11);
    u32 _world_562 = STK(12);
    u32 _world_563 = STK(13);
    u32 _world_564 = STK(14);
    u32 _world_565 = STK(15);
    Term _world_566 = STK(16);
    Term _h_339 = STK(17);
    Term _world_567 = STK(18);
    u32 _world_568 = STK(19);
    u32 _world_569 = STK(20);
    Term _h_340 = STK(21);
    Term _h_341 = STK(22);
    Term _h_342 = STK(23);
    Term _h_343 = STK(24);
    Term _h_344 = STK(25);
    Term _h_345 = STK(26);
    Term _h_346 = STK(27);
    Term _h_347 = STK(28);
    Term _h_348 = STK(29);
    Term _h_349 = STK(30);
    Term _h_338 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(32);
      STK(0) = _world_550;
      STK(1) = _world_551;
      STK(2) = _world_552;
      STK(3) = _world_553;
      STK(4) = _world_554;
      STK(5) = _world_555;
      STK(6) = _world_556;
      STK(7) = _world_557;
      STK(8) = _world_558;
      STK(9) = _world_559;
      STK(10) = _world_560;
      STK(11) = _world_561;
      STK(12) = _world_562;
      STK(13) = _world_563;
      STK(14) = _world_564;
      STK(15) = _world_565;
      STK(16) = _world_566;
      STK(17) = _h_339;
      STK(18) = _world_567;
      STK(19) = _world_568;
      STK(20) = _world_569;
      STK(21) = _h_340;
      STK(22) = _h_341;
      STK(23) = _h_342;
      STK(24) = _h_343;
      STK(25) = _h_344;
      STK(26) = _h_345;
      STK(27) = _h_346;
      STK(28) = _h_347;
      STK(29) = _h_348;
      STK(30) = _h_349;
      STK(31) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K292;
      WL_PUSHN(32);
    } else {
      u64 _t_54 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K292, WL_CONT, WL_IDX, 1);
      e.mem[_t_54 + 0] = _world_550;
      e.mem[_t_54 + 1] = _world_551;
      e.mem[_t_54 + 2] = _world_552;
      e.mem[_t_54 + 3] = _world_553;
      e.mem[_t_54 + 4] = _world_554;
      e.mem[_t_54 + 5] = _world_555;
      e.mem[_t_54 + 6] = _world_556;
      e.mem[_t_54 + 7] = _world_557;
      e.mem[_t_54 + 8] = _world_558;
      e.mem[_t_54 + 9] = _world_559;
      e.mem[_t_54 + 10] = _world_560;
      e.mem[_t_54 + 11] = _world_561;
      e.mem[_t_54 + 12] = _world_562;
      e.mem[_t_54 + 13] = _world_563;
      e.mem[_t_54 + 14] = _world_564;
      e.mem[_t_54 + 15] = _world_565;
      e.mem[_t_54 + 16] = _world_566;
      e.mem[_t_54 + 17] = _h_339;
      e.mem[_t_54 + 18] = _world_567;
      e.mem[_t_54 + 19] = _world_568;
      e.mem[_t_54 + 20] = _world_569;
      e.mem[_t_54 + 21] = _h_340;
      e.mem[_t_54 + 22] = _h_341;
      e.mem[_t_54 + 23] = _h_342;
      e.mem[_t_54 + 24] = _h_343;
      e.mem[_t_54 + 25] = _h_344;
      e.mem[_t_54 + 26] = _h_345;
      e.mem[_t_54 + 27] = _h_346;
      e.mem[_t_54 + 28] = _h_347;
      e.mem[_t_54 + 29] = _h_348;
      e.mem[_t_54 + 30] = _h_349;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K292, _t_54);
      WL_IDX = 31;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_55 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_55 + 0] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_55 + 1] = _h_338;
      return term_tsk(FID_STRING_APPEND, _t_55);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 270);
    r1 = _h_338;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K292)
  {
    WL_POPN(31);
    u32 _world_570 = STK(0);
    u32 _world_571 = STK(1);
    u32 _world_572 = STK(2);
    u32 _world_573 = STK(3);
    Term _world_574 = STK(4);
    u32 _world_575 = STK(5);
    u32 _world_576 = STK(6);
    u32 _world_577 = STK(7);
    u32 _world_578 = STK(8);
    u32 _world_579 = STK(9);
    u32 _world_580 = STK(10);
    u32 _world_581 = STK(11);
    u32 _world_582 = STK(12);
    u32 _world_583 = STK(13);
    u32 _world_584 = STK(14);
    u32 _world_585 = STK(15);
    Term _world_586 = STK(16);
    Term _h_351 = STK(17);
    Term _world_587 = STK(18);
    u32 _world_588 = STK(19);
    u32 _world_589 = STK(20);
    Term _h_352 = STK(21);
    Term _h_353 = STK(22);
    Term _h_354 = STK(23);
    Term _h_355 = STK(24);
    Term _h_356 = STK(25);
    Term _h_357 = STK(26);
    Term _h_358 = STK(27);
    Term _h_359 = STK(28);
    Term _h_360 = STK(29);
    Term _h_361 = STK(30);
    Term _h_350 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(31);
      STK(0) = _world_570;
      STK(1) = _world_571;
      STK(2) = _world_572;
      STK(3) = _world_573;
      STK(4) = _world_574;
      STK(5) = _world_575;
      STK(6) = _world_576;
      STK(7) = _world_577;
      STK(8) = _world_578;
      STK(9) = _world_579;
      STK(10) = _world_580;
      STK(11) = _world_581;
      STK(12) = _world_582;
      STK(13) = _world_583;
      STK(14) = _world_584;
      STK(15) = _world_585;
      STK(16) = _world_586;
      STK(17) = _h_351;
      STK(18) = _world_587;
      STK(19) = _world_588;
      STK(20) = _world_589;
      STK(21) = _h_352;
      STK(22) = _h_353;
      STK(23) = _h_354;
      STK(24) = _h_356;
      STK(25) = _h_357;
      STK(26) = _h_358;
      STK(27) = _h_359;
      STK(28) = _h_360;
      STK(29) = _h_361;
      STK(30) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K293;
      WL_PUSHN(31);
    } else {
      u64 _t_56 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K293, WL_CONT, WL_IDX, 1);
      e.mem[_t_56 + 0] = _world_570;
      e.mem[_t_56 + 1] = _world_571;
      e.mem[_t_56 + 2] = _world_572;
      e.mem[_t_56 + 3] = _world_573;
      e.mem[_t_56 + 4] = _world_574;
      e.mem[_t_56 + 5] = _world_575;
      e.mem[_t_56 + 6] = _world_576;
      e.mem[_t_56 + 7] = _world_577;
      e.mem[_t_56 + 8] = _world_578;
      e.mem[_t_56 + 9] = _world_579;
      e.mem[_t_56 + 10] = _world_580;
      e.mem[_t_56 + 11] = _world_581;
      e.mem[_t_56 + 12] = _world_582;
      e.mem[_t_56 + 13] = _world_583;
      e.mem[_t_56 + 14] = _world_584;
      e.mem[_t_56 + 15] = _world_585;
      e.mem[_t_56 + 16] = _world_586;
      e.mem[_t_56 + 17] = _h_351;
      e.mem[_t_56 + 18] = _world_587;
      e.mem[_t_56 + 19] = _world_588;
      e.mem[_t_56 + 20] = _world_589;
      e.mem[_t_56 + 21] = _h_352;
      e.mem[_t_56 + 22] = _h_353;
      e.mem[_t_56 + 23] = _h_354;
      e.mem[_t_56 + 24] = _h_356;
      e.mem[_t_56 + 25] = _h_357;
      e.mem[_t_56 + 26] = _h_358;
      e.mem[_t_56 + 27] = _h_359;
      e.mem[_t_56 + 28] = _h_360;
      e.mem[_t_56 + 29] = _h_361;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K293, _t_56);
      WL_IDX = 30;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_57 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_57 + 0] = _h_355;
      e.mem[_t_57 + 1] = _h_350;
      return term_tsk(FID_STRING_APPEND, _t_57);
    }
    r0 = _h_355;
    r1 = _h_350;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K293)
  {
    WL_POPN(30);
    u32 _world_590 = STK(0);
    u32 _world_591 = STK(1);
    u32 _world_592 = STK(2);
    u32 _world_593 = STK(3);
    Term _world_594 = STK(4);
    u32 _world_595 = STK(5);
    u32 _world_596 = STK(6);
    u32 _world_597 = STK(7);
    u32 _world_598 = STK(8);
    u32 _world_599 = STK(9);
    u32 _world_600 = STK(10);
    u32 _world_601 = STK(11);
    u32 _world_602 = STK(12);
    u32 _world_603 = STK(13);
    u32 _world_604 = STK(14);
    u32 _world_605 = STK(15);
    Term _world_606 = STK(16);
    Term _h_363 = STK(17);
    Term _world_607 = STK(18);
    u32 _world_608 = STK(19);
    u32 _world_609 = STK(20);
    Term _h_364 = STK(21);
    Term _h_365 = STK(22);
    Term _h_366 = STK(23);
    Term _h_367 = STK(24);
    Term _h_368 = STK(25);
    Term _h_369 = STK(26);
    Term _h_370 = STK(27);
    Term _h_371 = STK(28);
    Term _h_372 = STK(29);
    Term _h_362 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(31);
      STK(0) = _world_590;
      STK(1) = _world_591;
      STK(2) = _world_592;
      STK(3) = _world_593;
      STK(4) = _world_594;
      STK(5) = _world_595;
      STK(6) = _world_596;
      STK(7) = _world_597;
      STK(8) = _world_598;
      STK(9) = _world_599;
      STK(10) = _world_600;
      STK(11) = _world_601;
      STK(12) = _world_602;
      STK(13) = _world_603;
      STK(14) = _world_604;
      STK(15) = _world_605;
      STK(16) = _world_606;
      STK(17) = _h_363;
      STK(18) = _world_607;
      STK(19) = _world_608;
      STK(20) = _world_609;
      STK(21) = _h_364;
      STK(22) = _h_365;
      STK(23) = _h_366;
      STK(24) = _h_367;
      STK(25) = _h_368;
      STK(26) = _h_369;
      STK(27) = _h_370;
      STK(28) = _h_371;
      STK(29) = _h_372;
      STK(30) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K294;
      WL_PUSHN(31);
    } else {
      u64 _t_58 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K294, WL_CONT, WL_IDX, 1);
      e.mem[_t_58 + 0] = _world_590;
      e.mem[_t_58 + 1] = _world_591;
      e.mem[_t_58 + 2] = _world_592;
      e.mem[_t_58 + 3] = _world_593;
      e.mem[_t_58 + 4] = _world_594;
      e.mem[_t_58 + 5] = _world_595;
      e.mem[_t_58 + 6] = _world_596;
      e.mem[_t_58 + 7] = _world_597;
      e.mem[_t_58 + 8] = _world_598;
      e.mem[_t_58 + 9] = _world_599;
      e.mem[_t_58 + 10] = _world_600;
      e.mem[_t_58 + 11] = _world_601;
      e.mem[_t_58 + 12] = _world_602;
      e.mem[_t_58 + 13] = _world_603;
      e.mem[_t_58 + 14] = _world_604;
      e.mem[_t_58 + 15] = _world_605;
      e.mem[_t_58 + 16] = _world_606;
      e.mem[_t_58 + 17] = _h_363;
      e.mem[_t_58 + 18] = _world_607;
      e.mem[_t_58 + 19] = _world_608;
      e.mem[_t_58 + 20] = _world_609;
      e.mem[_t_58 + 21] = _h_364;
      e.mem[_t_58 + 22] = _h_365;
      e.mem[_t_58 + 23] = _h_366;
      e.mem[_t_58 + 24] = _h_367;
      e.mem[_t_58 + 25] = _h_368;
      e.mem[_t_58 + 26] = _h_369;
      e.mem[_t_58 + 27] = _h_370;
      e.mem[_t_58 + 28] = _h_371;
      e.mem[_t_58 + 29] = _h_372;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K294, _t_58);
      WL_IDX = 30;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_59 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_59 + 0] = term_ctr(CID_SCON, STAT_OFF + 284);
      e.mem[_t_59 + 1] = _h_362;
      return term_tsk(FID_STRING_APPEND, _t_59);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 284);
    r1 = _h_362;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K294)
  {
    WL_POPN(30);
    u32 _world_610 = STK(0);
    u32 _world_611 = STK(1);
    u32 _world_612 = STK(2);
    u32 _world_613 = STK(3);
    Term _world_614 = STK(4);
    u32 _world_615 = STK(5);
    u32 _world_616 = STK(6);
    u32 _world_617 = STK(7);
    u32 _world_618 = STK(8);
    u32 _world_619 = STK(9);
    u32 _world_620 = STK(10);
    u32 _world_621 = STK(11);
    u32 _world_622 = STK(12);
    u32 _world_623 = STK(13);
    u32 _world_624 = STK(14);
    u32 _world_625 = STK(15);
    Term _world_626 = STK(16);
    Term _h_374 = STK(17);
    Term _world_627 = STK(18);
    u32 _world_628 = STK(19);
    u32 _world_629 = STK(20);
    Term _h_375 = STK(21);
    Term _h_376 = STK(22);
    Term _h_377 = STK(23);
    Term _h_378 = STK(24);
    Term _h_379 = STK(25);
    Term _h_380 = STK(26);
    Term _h_381 = STK(27);
    Term _h_382 = STK(28);
    Term _h_383 = STK(29);
    Term _h_373 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(30);
      STK(0) = _world_610;
      STK(1) = _world_611;
      STK(2) = _world_612;
      STK(3) = _world_613;
      STK(4) = _world_614;
      STK(5) = _world_615;
      STK(6) = _world_616;
      STK(7) = _world_617;
      STK(8) = _world_618;
      STK(9) = _world_619;
      STK(10) = _world_620;
      STK(11) = _world_621;
      STK(12) = _world_622;
      STK(13) = _world_623;
      STK(14) = _world_624;
      STK(15) = _world_625;
      STK(16) = _world_626;
      STK(17) = _h_374;
      STK(18) = _world_627;
      STK(19) = _world_628;
      STK(20) = _world_629;
      STK(21) = _h_375;
      STK(22) = _h_377;
      STK(23) = _h_378;
      STK(24) = _h_379;
      STK(25) = _h_380;
      STK(26) = _h_381;
      STK(27) = _h_382;
      STK(28) = _h_383;
      STK(29) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K295;
      WL_PUSHN(30);
    } else {
      u64 _t_60 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K295, WL_CONT, WL_IDX, 1);
      e.mem[_t_60 + 0] = _world_610;
      e.mem[_t_60 + 1] = _world_611;
      e.mem[_t_60 + 2] = _world_612;
      e.mem[_t_60 + 3] = _world_613;
      e.mem[_t_60 + 4] = _world_614;
      e.mem[_t_60 + 5] = _world_615;
      e.mem[_t_60 + 6] = _world_616;
      e.mem[_t_60 + 7] = _world_617;
      e.mem[_t_60 + 8] = _world_618;
      e.mem[_t_60 + 9] = _world_619;
      e.mem[_t_60 + 10] = _world_620;
      e.mem[_t_60 + 11] = _world_621;
      e.mem[_t_60 + 12] = _world_622;
      e.mem[_t_60 + 13] = _world_623;
      e.mem[_t_60 + 14] = _world_624;
      e.mem[_t_60 + 15] = _world_625;
      e.mem[_t_60 + 16] = _world_626;
      e.mem[_t_60 + 17] = _h_374;
      e.mem[_t_60 + 18] = _world_627;
      e.mem[_t_60 + 19] = _world_628;
      e.mem[_t_60 + 20] = _world_629;
      e.mem[_t_60 + 21] = _h_375;
      e.mem[_t_60 + 22] = _h_377;
      e.mem[_t_60 + 23] = _h_378;
      e.mem[_t_60 + 24] = _h_379;
      e.mem[_t_60 + 25] = _h_380;
      e.mem[_t_60 + 26] = _h_381;
      e.mem[_t_60 + 27] = _h_382;
      e.mem[_t_60 + 28] = _h_383;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K295, _t_60);
      WL_IDX = 29;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_61 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_61 + 0] = _h_376;
      e.mem[_t_61 + 1] = _h_373;
      return term_tsk(FID_STRING_APPEND, _t_61);
    }
    r0 = _h_376;
    r1 = _h_373;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K295)
  {
    WL_POPN(29);
    u32 _world_630 = STK(0);
    u32 _world_631 = STK(1);
    u32 _world_632 = STK(2);
    u32 _world_633 = STK(3);
    Term _world_634 = STK(4);
    u32 _world_635 = STK(5);
    u32 _world_636 = STK(6);
    u32 _world_637 = STK(7);
    u32 _world_638 = STK(8);
    u32 _world_639 = STK(9);
    u32 _world_640 = STK(10);
    u32 _world_641 = STK(11);
    u32 _world_642 = STK(12);
    u32 _world_643 = STK(13);
    u32 _world_644 = STK(14);
    u32 _world_645 = STK(15);
    Term _world_646 = STK(16);
    Term _h_385 = STK(17);
    Term _world_647 = STK(18);
    u32 _world_648 = STK(19);
    u32 _world_649 = STK(20);
    Term _h_386 = STK(21);
    Term _h_387 = STK(22);
    Term _h_388 = STK(23);
    Term _h_389 = STK(24);
    Term _h_390 = STK(25);
    Term _h_391 = STK(26);
    Term _h_392 = STK(27);
    Term _h_393 = STK(28);
    Term _h_384 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(30);
      STK(0) = _world_630;
      STK(1) = _world_631;
      STK(2) = _world_632;
      STK(3) = _world_633;
      STK(4) = _world_634;
      STK(5) = _world_635;
      STK(6) = _world_636;
      STK(7) = _world_637;
      STK(8) = _world_638;
      STK(9) = _world_639;
      STK(10) = _world_640;
      STK(11) = _world_641;
      STK(12) = _world_642;
      STK(13) = _world_643;
      STK(14) = _world_644;
      STK(15) = _world_645;
      STK(16) = _world_646;
      STK(17) = _h_385;
      STK(18) = _world_647;
      STK(19) = _world_648;
      STK(20) = _world_649;
      STK(21) = _h_386;
      STK(22) = _h_387;
      STK(23) = _h_388;
      STK(24) = _h_389;
      STK(25) = _h_390;
      STK(26) = _h_391;
      STK(27) = _h_392;
      STK(28) = _h_393;
      STK(29) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K296;
      WL_PUSHN(30);
    } else {
      u64 _t_62 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K296, WL_CONT, WL_IDX, 1);
      e.mem[_t_62 + 0] = _world_630;
      e.mem[_t_62 + 1] = _world_631;
      e.mem[_t_62 + 2] = _world_632;
      e.mem[_t_62 + 3] = _world_633;
      e.mem[_t_62 + 4] = _world_634;
      e.mem[_t_62 + 5] = _world_635;
      e.mem[_t_62 + 6] = _world_636;
      e.mem[_t_62 + 7] = _world_637;
      e.mem[_t_62 + 8] = _world_638;
      e.mem[_t_62 + 9] = _world_639;
      e.mem[_t_62 + 10] = _world_640;
      e.mem[_t_62 + 11] = _world_641;
      e.mem[_t_62 + 12] = _world_642;
      e.mem[_t_62 + 13] = _world_643;
      e.mem[_t_62 + 14] = _world_644;
      e.mem[_t_62 + 15] = _world_645;
      e.mem[_t_62 + 16] = _world_646;
      e.mem[_t_62 + 17] = _h_385;
      e.mem[_t_62 + 18] = _world_647;
      e.mem[_t_62 + 19] = _world_648;
      e.mem[_t_62 + 20] = _world_649;
      e.mem[_t_62 + 21] = _h_386;
      e.mem[_t_62 + 22] = _h_387;
      e.mem[_t_62 + 23] = _h_388;
      e.mem[_t_62 + 24] = _h_389;
      e.mem[_t_62 + 25] = _h_390;
      e.mem[_t_62 + 26] = _h_391;
      e.mem[_t_62 + 27] = _h_392;
      e.mem[_t_62 + 28] = _h_393;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K296, _t_62);
      WL_IDX = 29;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_63 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_63 + 0] = term_ctr(CID_SCON, STAT_OFF + 292);
      e.mem[_t_63 + 1] = _h_384;
      return term_tsk(FID_STRING_APPEND, _t_63);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 292);
    r1 = _h_384;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K296)
  {
    WL_POPN(29);
    u32 _world_650 = STK(0);
    u32 _world_651 = STK(1);
    u32 _world_652 = STK(2);
    u32 _world_653 = STK(3);
    Term _world_654 = STK(4);
    u32 _world_655 = STK(5);
    u32 _world_656 = STK(6);
    u32 _world_657 = STK(7);
    u32 _world_658 = STK(8);
    u32 _world_659 = STK(9);
    u32 _world_660 = STK(10);
    u32 _world_661 = STK(11);
    u32 _world_662 = STK(12);
    u32 _world_663 = STK(13);
    u32 _world_664 = STK(14);
    u32 _world_665 = STK(15);
    Term _world_666 = STK(16);
    Term _h_395 = STK(17);
    Term _world_667 = STK(18);
    u32 _world_668 = STK(19);
    u32 _world_669 = STK(20);
    Term _h_396 = STK(21);
    Term _h_397 = STK(22);
    Term _h_398 = STK(23);
    Term _h_399 = STK(24);
    Term _h_400 = STK(25);
    Term _h_401 = STK(26);
    Term _h_402 = STK(27);
    Term _h_403 = STK(28);
    Term _h_394 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(29);
      STK(0) = _world_650;
      STK(1) = _world_651;
      STK(2) = _world_652;
      STK(3) = _world_653;
      STK(4) = _world_654;
      STK(5) = _world_655;
      STK(6) = _world_656;
      STK(7) = _world_657;
      STK(8) = _world_658;
      STK(9) = _world_659;
      STK(10) = _world_660;
      STK(11) = _world_661;
      STK(12) = _world_662;
      STK(13) = _world_663;
      STK(14) = _world_664;
      STK(15) = _world_665;
      STK(16) = _world_666;
      STK(17) = _h_395;
      STK(18) = _world_667;
      STK(19) = _world_668;
      STK(20) = _world_669;
      STK(21) = _h_396;
      STK(22) = _h_397;
      STK(23) = _h_398;
      STK(24) = _h_399;
      STK(25) = _h_400;
      STK(26) = _h_401;
      STK(27) = _h_402;
      STK(28) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K297;
      WL_PUSHN(29);
    } else {
      u64 _t_64 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K297, WL_CONT, WL_IDX, 1);
      e.mem[_t_64 + 0] = _world_650;
      e.mem[_t_64 + 1] = _world_651;
      e.mem[_t_64 + 2] = _world_652;
      e.mem[_t_64 + 3] = _world_653;
      e.mem[_t_64 + 4] = _world_654;
      e.mem[_t_64 + 5] = _world_655;
      e.mem[_t_64 + 6] = _world_656;
      e.mem[_t_64 + 7] = _world_657;
      e.mem[_t_64 + 8] = _world_658;
      e.mem[_t_64 + 9] = _world_659;
      e.mem[_t_64 + 10] = _world_660;
      e.mem[_t_64 + 11] = _world_661;
      e.mem[_t_64 + 12] = _world_662;
      e.mem[_t_64 + 13] = _world_663;
      e.mem[_t_64 + 14] = _world_664;
      e.mem[_t_64 + 15] = _world_665;
      e.mem[_t_64 + 16] = _world_666;
      e.mem[_t_64 + 17] = _h_395;
      e.mem[_t_64 + 18] = _world_667;
      e.mem[_t_64 + 19] = _world_668;
      e.mem[_t_64 + 20] = _world_669;
      e.mem[_t_64 + 21] = _h_396;
      e.mem[_t_64 + 22] = _h_397;
      e.mem[_t_64 + 23] = _h_398;
      e.mem[_t_64 + 24] = _h_399;
      e.mem[_t_64 + 25] = _h_400;
      e.mem[_t_64 + 26] = _h_401;
      e.mem[_t_64 + 27] = _h_402;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K297, _t_64);
      WL_IDX = 28;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_65 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_65 + 0] = _h_403;
      e.mem[_t_65 + 1] = _h_394;
      return term_tsk(FID_STRING_APPEND, _t_65);
    }
    r0 = _h_403;
    r1 = _h_394;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K297)
  {
    WL_POPN(28);
    u32 _world_670 = STK(0);
    u32 _world_671 = STK(1);
    u32 _world_672 = STK(2);
    u32 _world_673 = STK(3);
    Term _world_674 = STK(4);
    u32 _world_675 = STK(5);
    u32 _world_676 = STK(6);
    u32 _world_677 = STK(7);
    u32 _world_678 = STK(8);
    u32 _world_679 = STK(9);
    u32 _world_680 = STK(10);
    u32 _world_681 = STK(11);
    u32 _world_682 = STK(12);
    u32 _world_683 = STK(13);
    u32 _world_684 = STK(14);
    u32 _world_685 = STK(15);
    Term _world_686 = STK(16);
    Term _h_405 = STK(17);
    Term _world_687 = STK(18);
    u32 _world_688 = STK(19);
    u32 _world_689 = STK(20);
    Term _h_406 = STK(21);
    Term _h_407 = STK(22);
    Term _h_408 = STK(23);
    Term _h_409 = STK(24);
    Term _h_410 = STK(25);
    Term _h_411 = STK(26);
    Term _h_412 = STK(27);
    Term _h_404 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(29);
      STK(0) = _world_670;
      STK(1) = _world_671;
      STK(2) = _world_672;
      STK(3) = _world_673;
      STK(4) = _world_674;
      STK(5) = _world_675;
      STK(6) = _world_676;
      STK(7) = _world_677;
      STK(8) = _world_678;
      STK(9) = _world_679;
      STK(10) = _world_680;
      STK(11) = _world_681;
      STK(12) = _world_682;
      STK(13) = _world_683;
      STK(14) = _world_684;
      STK(15) = _world_685;
      STK(16) = _world_686;
      STK(17) = _h_405;
      STK(18) = _world_687;
      STK(19) = _world_688;
      STK(20) = _world_689;
      STK(21) = _h_406;
      STK(22) = _h_407;
      STK(23) = _h_408;
      STK(24) = _h_409;
      STK(25) = _h_410;
      STK(26) = _h_411;
      STK(27) = _h_412;
      STK(28) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K298;
      WL_PUSHN(29);
    } else {
      u64 _t_66 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K298, WL_CONT, WL_IDX, 1);
      e.mem[_t_66 + 0] = _world_670;
      e.mem[_t_66 + 1] = _world_671;
      e.mem[_t_66 + 2] = _world_672;
      e.mem[_t_66 + 3] = _world_673;
      e.mem[_t_66 + 4] = _world_674;
      e.mem[_t_66 + 5] = _world_675;
      e.mem[_t_66 + 6] = _world_676;
      e.mem[_t_66 + 7] = _world_677;
      e.mem[_t_66 + 8] = _world_678;
      e.mem[_t_66 + 9] = _world_679;
      e.mem[_t_66 + 10] = _world_680;
      e.mem[_t_66 + 11] = _world_681;
      e.mem[_t_66 + 12] = _world_682;
      e.mem[_t_66 + 13] = _world_683;
      e.mem[_t_66 + 14] = _world_684;
      e.mem[_t_66 + 15] = _world_685;
      e.mem[_t_66 + 16] = _world_686;
      e.mem[_t_66 + 17] = _h_405;
      e.mem[_t_66 + 18] = _world_687;
      e.mem[_t_66 + 19] = _world_688;
      e.mem[_t_66 + 20] = _world_689;
      e.mem[_t_66 + 21] = _h_406;
      e.mem[_t_66 + 22] = _h_407;
      e.mem[_t_66 + 23] = _h_408;
      e.mem[_t_66 + 24] = _h_409;
      e.mem[_t_66 + 25] = _h_410;
      e.mem[_t_66 + 26] = _h_411;
      e.mem[_t_66 + 27] = _h_412;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K298, _t_66);
      WL_IDX = 28;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_67 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_67 + 0] = term_ctr(CID_SCON, STAT_OFF + 304);
      e.mem[_t_67 + 1] = _h_404;
      return term_tsk(FID_STRING_APPEND, _t_67);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 304);
    r1 = _h_404;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K298)
  {
    WL_POPN(28);
    u32 _world_690 = STK(0);
    u32 _world_691 = STK(1);
    u32 _world_692 = STK(2);
    u32 _world_693 = STK(3);
    Term _world_694 = STK(4);
    u32 _world_695 = STK(5);
    u32 _world_696 = STK(6);
    u32 _world_697 = STK(7);
    u32 _world_698 = STK(8);
    u32 _world_699 = STK(9);
    u32 _world_700 = STK(10);
    u32 _world_701 = STK(11);
    u32 _world_702 = STK(12);
    u32 _world_703 = STK(13);
    u32 _world_704 = STK(14);
    u32 _world_705 = STK(15);
    Term _world_706 = STK(16);
    Term _h_414 = STK(17);
    Term _world_707 = STK(18);
    u32 _world_708 = STK(19);
    u32 _world_709 = STK(20);
    Term _h_415 = STK(21);
    Term _h_416 = STK(22);
    Term _h_417 = STK(23);
    Term _h_418 = STK(24);
    Term _h_419 = STK(25);
    Term _h_420 = STK(26);
    Term _h_421 = STK(27);
    Term _h_413 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(28);
      STK(0) = _world_690;
      STK(1) = _world_691;
      STK(2) = _world_692;
      STK(3) = _world_693;
      STK(4) = _world_694;
      STK(5) = _world_695;
      STK(6) = _world_696;
      STK(7) = _world_697;
      STK(8) = _world_698;
      STK(9) = _world_699;
      STK(10) = _world_700;
      STK(11) = _world_701;
      STK(12) = _world_702;
      STK(13) = _world_703;
      STK(14) = _world_704;
      STK(15) = _world_705;
      STK(16) = _world_706;
      STK(17) = _h_414;
      STK(18) = _world_707;
      STK(19) = _world_708;
      STK(20) = _world_709;
      STK(21) = _h_415;
      STK(22) = _h_416;
      STK(23) = _h_417;
      STK(24) = _h_418;
      STK(25) = _h_419;
      STK(26) = _h_420;
      STK(27) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K299;
      WL_PUSHN(28);
    } else {
      u64 _t_68 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K299, WL_CONT, WL_IDX, 1);
      e.mem[_t_68 + 0] = _world_690;
      e.mem[_t_68 + 1] = _world_691;
      e.mem[_t_68 + 2] = _world_692;
      e.mem[_t_68 + 3] = _world_693;
      e.mem[_t_68 + 4] = _world_694;
      e.mem[_t_68 + 5] = _world_695;
      e.mem[_t_68 + 6] = _world_696;
      e.mem[_t_68 + 7] = _world_697;
      e.mem[_t_68 + 8] = _world_698;
      e.mem[_t_68 + 9] = _world_699;
      e.mem[_t_68 + 10] = _world_700;
      e.mem[_t_68 + 11] = _world_701;
      e.mem[_t_68 + 12] = _world_702;
      e.mem[_t_68 + 13] = _world_703;
      e.mem[_t_68 + 14] = _world_704;
      e.mem[_t_68 + 15] = _world_705;
      e.mem[_t_68 + 16] = _world_706;
      e.mem[_t_68 + 17] = _h_414;
      e.mem[_t_68 + 18] = _world_707;
      e.mem[_t_68 + 19] = _world_708;
      e.mem[_t_68 + 20] = _world_709;
      e.mem[_t_68 + 21] = _h_415;
      e.mem[_t_68 + 22] = _h_416;
      e.mem[_t_68 + 23] = _h_417;
      e.mem[_t_68 + 24] = _h_418;
      e.mem[_t_68 + 25] = _h_419;
      e.mem[_t_68 + 26] = _h_420;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K299, _t_68);
      WL_IDX = 27;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_69 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_69 + 0] = _h_421;
      e.mem[_t_69 + 1] = _h_413;
      return term_tsk(FID_STRING_APPEND, _t_69);
    }
    r0 = _h_421;
    r1 = _h_413;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K299)
  {
    WL_POPN(27);
    u32 _world_710 = STK(0);
    u32 _world_711 = STK(1);
    u32 _world_712 = STK(2);
    u32 _world_713 = STK(3);
    Term _world_714 = STK(4);
    u32 _world_715 = STK(5);
    u32 _world_716 = STK(6);
    u32 _world_717 = STK(7);
    u32 _world_718 = STK(8);
    u32 _world_719 = STK(9);
    u32 _world_720 = STK(10);
    u32 _world_721 = STK(11);
    u32 _world_722 = STK(12);
    u32 _world_723 = STK(13);
    u32 _world_724 = STK(14);
    u32 _world_725 = STK(15);
    Term _world_726 = STK(16);
    Term _h_423 = STK(17);
    Term _world_727 = STK(18);
    u32 _world_728 = STK(19);
    u32 _world_729 = STK(20);
    Term _h_424 = STK(21);
    Term _h_425 = STK(22);
    Term _h_426 = STK(23);
    Term _h_427 = STK(24);
    Term _h_428 = STK(25);
    Term _h_429 = STK(26);
    Term _h_422 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(28);
      STK(0) = _world_710;
      STK(1) = _world_711;
      STK(2) = _world_712;
      STK(3) = _world_713;
      STK(4) = _world_714;
      STK(5) = _world_715;
      STK(6) = _world_716;
      STK(7) = _world_717;
      STK(8) = _world_718;
      STK(9) = _world_719;
      STK(10) = _world_720;
      STK(11) = _world_721;
      STK(12) = _world_722;
      STK(13) = _world_723;
      STK(14) = _world_724;
      STK(15) = _world_725;
      STK(16) = _world_726;
      STK(17) = _h_423;
      STK(18) = _world_727;
      STK(19) = _world_728;
      STK(20) = _world_729;
      STK(21) = _h_424;
      STK(22) = _h_425;
      STK(23) = _h_426;
      STK(24) = _h_427;
      STK(25) = _h_428;
      STK(26) = _h_429;
      STK(27) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K300;
      WL_PUSHN(28);
    } else {
      u64 _t_70 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K300, WL_CONT, WL_IDX, 1);
      e.mem[_t_70 + 0] = _world_710;
      e.mem[_t_70 + 1] = _world_711;
      e.mem[_t_70 + 2] = _world_712;
      e.mem[_t_70 + 3] = _world_713;
      e.mem[_t_70 + 4] = _world_714;
      e.mem[_t_70 + 5] = _world_715;
      e.mem[_t_70 + 6] = _world_716;
      e.mem[_t_70 + 7] = _world_717;
      e.mem[_t_70 + 8] = _world_718;
      e.mem[_t_70 + 9] = _world_719;
      e.mem[_t_70 + 10] = _world_720;
      e.mem[_t_70 + 11] = _world_721;
      e.mem[_t_70 + 12] = _world_722;
      e.mem[_t_70 + 13] = _world_723;
      e.mem[_t_70 + 14] = _world_724;
      e.mem[_t_70 + 15] = _world_725;
      e.mem[_t_70 + 16] = _world_726;
      e.mem[_t_70 + 17] = _h_423;
      e.mem[_t_70 + 18] = _world_727;
      e.mem[_t_70 + 19] = _world_728;
      e.mem[_t_70 + 20] = _world_729;
      e.mem[_t_70 + 21] = _h_424;
      e.mem[_t_70 + 22] = _h_425;
      e.mem[_t_70 + 23] = _h_426;
      e.mem[_t_70 + 24] = _h_427;
      e.mem[_t_70 + 25] = _h_428;
      e.mem[_t_70 + 26] = _h_429;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K300, _t_70);
      WL_IDX = 27;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_71 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_71 + 0] = term_ctr(CID_SCON, STAT_OFF + 322);
      e.mem[_t_71 + 1] = _h_422;
      return term_tsk(FID_STRING_APPEND, _t_71);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 322);
    r1 = _h_422;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K300)
  {
    WL_POPN(27);
    u32 _world_730 = STK(0);
    u32 _world_731 = STK(1);
    u32 _world_732 = STK(2);
    u32 _world_733 = STK(3);
    Term _world_734 = STK(4);
    u32 _world_735 = STK(5);
    u32 _world_736 = STK(6);
    u32 _world_737 = STK(7);
    u32 _world_738 = STK(8);
    u32 _world_739 = STK(9);
    u32 _world_740 = STK(10);
    u32 _world_741 = STK(11);
    u32 _world_742 = STK(12);
    u32 _world_743 = STK(13);
    u32 _world_744 = STK(14);
    u32 _world_745 = STK(15);
    Term _world_746 = STK(16);
    Term _h_431 = STK(17);
    Term _world_747 = STK(18);
    u32 _world_748 = STK(19);
    u32 _world_749 = STK(20);
    Term _h_432 = STK(21);
    Term _h_433 = STK(22);
    Term _h_434 = STK(23);
    Term _h_435 = STK(24);
    Term _h_436 = STK(25);
    Term _h_437 = STK(26);
    Term _h_430 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(27);
      STK(0) = _world_730;
      STK(1) = _world_731;
      STK(2) = _world_732;
      STK(3) = _world_733;
      STK(4) = _world_734;
      STK(5) = _world_735;
      STK(6) = _world_736;
      STK(7) = _world_737;
      STK(8) = _world_738;
      STK(9) = _world_739;
      STK(10) = _world_740;
      STK(11) = _world_741;
      STK(12) = _world_742;
      STK(13) = _world_743;
      STK(14) = _world_744;
      STK(15) = _world_745;
      STK(16) = _world_746;
      STK(17) = _h_431;
      STK(18) = _world_747;
      STK(19) = _world_748;
      STK(20) = _world_749;
      STK(21) = _h_432;
      STK(22) = _h_433;
      STK(23) = _h_434;
      STK(24) = _h_435;
      STK(25) = _h_436;
      STK(26) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K301;
      WL_PUSHN(27);
    } else {
      u64 _t_72 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K301, WL_CONT, WL_IDX, 1);
      e.mem[_t_72 + 0] = _world_730;
      e.mem[_t_72 + 1] = _world_731;
      e.mem[_t_72 + 2] = _world_732;
      e.mem[_t_72 + 3] = _world_733;
      e.mem[_t_72 + 4] = _world_734;
      e.mem[_t_72 + 5] = _world_735;
      e.mem[_t_72 + 6] = _world_736;
      e.mem[_t_72 + 7] = _world_737;
      e.mem[_t_72 + 8] = _world_738;
      e.mem[_t_72 + 9] = _world_739;
      e.mem[_t_72 + 10] = _world_740;
      e.mem[_t_72 + 11] = _world_741;
      e.mem[_t_72 + 12] = _world_742;
      e.mem[_t_72 + 13] = _world_743;
      e.mem[_t_72 + 14] = _world_744;
      e.mem[_t_72 + 15] = _world_745;
      e.mem[_t_72 + 16] = _world_746;
      e.mem[_t_72 + 17] = _h_431;
      e.mem[_t_72 + 18] = _world_747;
      e.mem[_t_72 + 19] = _world_748;
      e.mem[_t_72 + 20] = _world_749;
      e.mem[_t_72 + 21] = _h_432;
      e.mem[_t_72 + 22] = _h_433;
      e.mem[_t_72 + 23] = _h_434;
      e.mem[_t_72 + 24] = _h_435;
      e.mem[_t_72 + 25] = _h_436;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K301, _t_72);
      WL_IDX = 26;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_73 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_73 + 0] = _h_437;
      e.mem[_t_73 + 1] = _h_430;
      return term_tsk(FID_STRING_APPEND, _t_73);
    }
    r0 = _h_437;
    r1 = _h_430;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K301)
  {
    WL_POPN(26);
    u32 _world_750 = STK(0);
    u32 _world_751 = STK(1);
    u32 _world_752 = STK(2);
    u32 _world_753 = STK(3);
    Term _world_754 = STK(4);
    u32 _world_755 = STK(5);
    u32 _world_756 = STK(6);
    u32 _world_757 = STK(7);
    u32 _world_758 = STK(8);
    u32 _world_759 = STK(9);
    u32 _world_760 = STK(10);
    u32 _world_761 = STK(11);
    u32 _world_762 = STK(12);
    u32 _world_763 = STK(13);
    u32 _world_764 = STK(14);
    u32 _world_765 = STK(15);
    Term _world_766 = STK(16);
    Term _h_439 = STK(17);
    Term _world_767 = STK(18);
    u32 _world_768 = STK(19);
    u32 _world_769 = STK(20);
    Term _h_440 = STK(21);
    Term _h_441 = STK(22);
    Term _h_442 = STK(23);
    Term _h_443 = STK(24);
    Term _h_444 = STK(25);
    Term _h_438 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(27);
      STK(0) = _world_750;
      STK(1) = _world_751;
      STK(2) = _world_752;
      STK(3) = _world_753;
      STK(4) = _world_754;
      STK(5) = _world_755;
      STK(6) = _world_756;
      STK(7) = _world_757;
      STK(8) = _world_758;
      STK(9) = _world_759;
      STK(10) = _world_760;
      STK(11) = _world_761;
      STK(12) = _world_762;
      STK(13) = _world_763;
      STK(14) = _world_764;
      STK(15) = _world_765;
      STK(16) = _world_766;
      STK(17) = _h_439;
      STK(18) = _world_767;
      STK(19) = _world_768;
      STK(20) = _world_769;
      STK(21) = _h_440;
      STK(22) = _h_441;
      STK(23) = _h_442;
      STK(24) = _h_443;
      STK(25) = _h_444;
      STK(26) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K302;
      WL_PUSHN(27);
    } else {
      u64 _t_74 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K302, WL_CONT, WL_IDX, 1);
      e.mem[_t_74 + 0] = _world_750;
      e.mem[_t_74 + 1] = _world_751;
      e.mem[_t_74 + 2] = _world_752;
      e.mem[_t_74 + 3] = _world_753;
      e.mem[_t_74 + 4] = _world_754;
      e.mem[_t_74 + 5] = _world_755;
      e.mem[_t_74 + 6] = _world_756;
      e.mem[_t_74 + 7] = _world_757;
      e.mem[_t_74 + 8] = _world_758;
      e.mem[_t_74 + 9] = _world_759;
      e.mem[_t_74 + 10] = _world_760;
      e.mem[_t_74 + 11] = _world_761;
      e.mem[_t_74 + 12] = _world_762;
      e.mem[_t_74 + 13] = _world_763;
      e.mem[_t_74 + 14] = _world_764;
      e.mem[_t_74 + 15] = _world_765;
      e.mem[_t_74 + 16] = _world_766;
      e.mem[_t_74 + 17] = _h_439;
      e.mem[_t_74 + 18] = _world_767;
      e.mem[_t_74 + 19] = _world_768;
      e.mem[_t_74 + 20] = _world_769;
      e.mem[_t_74 + 21] = _h_440;
      e.mem[_t_74 + 22] = _h_441;
      e.mem[_t_74 + 23] = _h_442;
      e.mem[_t_74 + 24] = _h_443;
      e.mem[_t_74 + 25] = _h_444;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K302, _t_74);
      WL_IDX = 26;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_75 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_75 + 0] = term_ctr(CID_SCON, STAT_OFF + 330);
      e.mem[_t_75 + 1] = _h_438;
      return term_tsk(FID_STRING_APPEND, _t_75);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 330);
    r1 = _h_438;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K302)
  {
    WL_POPN(26);
    u32 _world_770 = STK(0);
    u32 _world_771 = STK(1);
    u32 _world_772 = STK(2);
    u32 _world_773 = STK(3);
    Term _world_774 = STK(4);
    u32 _world_775 = STK(5);
    u32 _world_776 = STK(6);
    u32 _world_777 = STK(7);
    u32 _world_778 = STK(8);
    u32 _world_779 = STK(9);
    u32 _world_780 = STK(10);
    u32 _world_781 = STK(11);
    u32 _world_782 = STK(12);
    u32 _world_783 = STK(13);
    u32 _world_784 = STK(14);
    u32 _world_785 = STK(15);
    Term _world_786 = STK(16);
    Term _h_446 = STK(17);
    Term _world_787 = STK(18);
    u32 _world_788 = STK(19);
    u32 _world_789 = STK(20);
    Term _h_447 = STK(21);
    Term _h_448 = STK(22);
    Term _h_449 = STK(23);
    Term _h_450 = STK(24);
    Term _h_451 = STK(25);
    Term _h_445 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(26);
      STK(0) = _world_770;
      STK(1) = _world_771;
      STK(2) = _world_772;
      STK(3) = _world_773;
      STK(4) = _world_774;
      STK(5) = _world_775;
      STK(6) = _world_776;
      STK(7) = _world_777;
      STK(8) = _world_778;
      STK(9) = _world_779;
      STK(10) = _world_780;
      STK(11) = _world_781;
      STK(12) = _world_782;
      STK(13) = _world_783;
      STK(14) = _world_784;
      STK(15) = _world_785;
      STK(16) = _world_786;
      STK(17) = _h_446;
      STK(18) = _world_787;
      STK(19) = _world_788;
      STK(20) = _world_789;
      STK(21) = _h_447;
      STK(22) = _h_448;
      STK(23) = _h_449;
      STK(24) = _h_450;
      STK(25) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K303;
      WL_PUSHN(26);
    } else {
      u64 _t_76 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K303, WL_CONT, WL_IDX, 1);
      e.mem[_t_76 + 0] = _world_770;
      e.mem[_t_76 + 1] = _world_771;
      e.mem[_t_76 + 2] = _world_772;
      e.mem[_t_76 + 3] = _world_773;
      e.mem[_t_76 + 4] = _world_774;
      e.mem[_t_76 + 5] = _world_775;
      e.mem[_t_76 + 6] = _world_776;
      e.mem[_t_76 + 7] = _world_777;
      e.mem[_t_76 + 8] = _world_778;
      e.mem[_t_76 + 9] = _world_779;
      e.mem[_t_76 + 10] = _world_780;
      e.mem[_t_76 + 11] = _world_781;
      e.mem[_t_76 + 12] = _world_782;
      e.mem[_t_76 + 13] = _world_783;
      e.mem[_t_76 + 14] = _world_784;
      e.mem[_t_76 + 15] = _world_785;
      e.mem[_t_76 + 16] = _world_786;
      e.mem[_t_76 + 17] = _h_446;
      e.mem[_t_76 + 18] = _world_787;
      e.mem[_t_76 + 19] = _world_788;
      e.mem[_t_76 + 20] = _world_789;
      e.mem[_t_76 + 21] = _h_447;
      e.mem[_t_76 + 22] = _h_448;
      e.mem[_t_76 + 23] = _h_449;
      e.mem[_t_76 + 24] = _h_450;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K303, _t_76);
      WL_IDX = 25;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_77 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_77 + 0] = _h_451;
      e.mem[_t_77 + 1] = _h_445;
      return term_tsk(FID_STRING_APPEND, _t_77);
    }
    r0 = _h_451;
    r1 = _h_445;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K303)
  {
    WL_POPN(25);
    u32 _world_790 = STK(0);
    u32 _world_791 = STK(1);
    u32 _world_792 = STK(2);
    u32 _world_793 = STK(3);
    Term _world_794 = STK(4);
    u32 _world_795 = STK(5);
    u32 _world_796 = STK(6);
    u32 _world_797 = STK(7);
    u32 _world_798 = STK(8);
    u32 _world_799 = STK(9);
    u32 _world_800 = STK(10);
    u32 _world_801 = STK(11);
    u32 _world_802 = STK(12);
    u32 _world_803 = STK(13);
    u32 _world_804 = STK(14);
    u32 _world_805 = STK(15);
    Term _world_806 = STK(16);
    Term _h_453 = STK(17);
    Term _world_807 = STK(18);
    u32 _world_808 = STK(19);
    u32 _world_809 = STK(20);
    Term _h_454 = STK(21);
    Term _h_455 = STK(22);
    Term _h_456 = STK(23);
    Term _h_457 = STK(24);
    Term _h_452 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(26);
      STK(0) = _world_790;
      STK(1) = _world_791;
      STK(2) = _world_792;
      STK(3) = _world_793;
      STK(4) = _world_794;
      STK(5) = _world_795;
      STK(6) = _world_796;
      STK(7) = _world_797;
      STK(8) = _world_798;
      STK(9) = _world_799;
      STK(10) = _world_800;
      STK(11) = _world_801;
      STK(12) = _world_802;
      STK(13) = _world_803;
      STK(14) = _world_804;
      STK(15) = _world_805;
      STK(16) = _world_806;
      STK(17) = _h_453;
      STK(18) = _world_807;
      STK(19) = _world_808;
      STK(20) = _world_809;
      STK(21) = _h_454;
      STK(22) = _h_455;
      STK(23) = _h_456;
      STK(24) = _h_457;
      STK(25) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K304;
      WL_PUSHN(26);
    } else {
      u64 _t_78 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K304, WL_CONT, WL_IDX, 1);
      e.mem[_t_78 + 0] = _world_790;
      e.mem[_t_78 + 1] = _world_791;
      e.mem[_t_78 + 2] = _world_792;
      e.mem[_t_78 + 3] = _world_793;
      e.mem[_t_78 + 4] = _world_794;
      e.mem[_t_78 + 5] = _world_795;
      e.mem[_t_78 + 6] = _world_796;
      e.mem[_t_78 + 7] = _world_797;
      e.mem[_t_78 + 8] = _world_798;
      e.mem[_t_78 + 9] = _world_799;
      e.mem[_t_78 + 10] = _world_800;
      e.mem[_t_78 + 11] = _world_801;
      e.mem[_t_78 + 12] = _world_802;
      e.mem[_t_78 + 13] = _world_803;
      e.mem[_t_78 + 14] = _world_804;
      e.mem[_t_78 + 15] = _world_805;
      e.mem[_t_78 + 16] = _world_806;
      e.mem[_t_78 + 17] = _h_453;
      e.mem[_t_78 + 18] = _world_807;
      e.mem[_t_78 + 19] = _world_808;
      e.mem[_t_78 + 20] = _world_809;
      e.mem[_t_78 + 21] = _h_454;
      e.mem[_t_78 + 22] = _h_455;
      e.mem[_t_78 + 23] = _h_456;
      e.mem[_t_78 + 24] = _h_457;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K304, _t_78);
      WL_IDX = 25;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_79 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_79 + 0] = term_ctr(CID_SCON, STAT_OFF + 338);
      e.mem[_t_79 + 1] = _h_452;
      return term_tsk(FID_STRING_APPEND, _t_79);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 338);
    r1 = _h_452;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K304)
  {
    WL_POPN(25);
    u32 _world_810 = STK(0);
    u32 _world_811 = STK(1);
    u32 _world_812 = STK(2);
    u32 _world_813 = STK(3);
    Term _world_814 = STK(4);
    u32 _world_815 = STK(5);
    u32 _world_816 = STK(6);
    u32 _world_817 = STK(7);
    u32 _world_818 = STK(8);
    u32 _world_819 = STK(9);
    u32 _world_820 = STK(10);
    u32 _world_821 = STK(11);
    u32 _world_822 = STK(12);
    u32 _world_823 = STK(13);
    u32 _world_824 = STK(14);
    u32 _world_825 = STK(15);
    Term _world_826 = STK(16);
    Term _h_459 = STK(17);
    Term _world_827 = STK(18);
    u32 _world_828 = STK(19);
    u32 _world_829 = STK(20);
    Term _h_460 = STK(21);
    Term _h_461 = STK(22);
    Term _h_462 = STK(23);
    Term _h_463 = STK(24);
    Term _h_458 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(25);
      STK(0) = _world_810;
      STK(1) = _world_811;
      STK(2) = _world_812;
      STK(3) = _world_813;
      STK(4) = _world_814;
      STK(5) = _world_815;
      STK(6) = _world_816;
      STK(7) = _world_817;
      STK(8) = _world_818;
      STK(9) = _world_819;
      STK(10) = _world_820;
      STK(11) = _world_821;
      STK(12) = _world_822;
      STK(13) = _world_823;
      STK(14) = _world_824;
      STK(15) = _world_825;
      STK(16) = _world_826;
      STK(17) = _h_459;
      STK(18) = _world_827;
      STK(19) = _world_828;
      STK(20) = _world_829;
      STK(21) = _h_460;
      STK(22) = _h_461;
      STK(23) = _h_462;
      STK(24) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K305;
      WL_PUSHN(25);
    } else {
      u64 _t_80 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K305, WL_CONT, WL_IDX, 1);
      e.mem[_t_80 + 0] = _world_810;
      e.mem[_t_80 + 1] = _world_811;
      e.mem[_t_80 + 2] = _world_812;
      e.mem[_t_80 + 3] = _world_813;
      e.mem[_t_80 + 4] = _world_814;
      e.mem[_t_80 + 5] = _world_815;
      e.mem[_t_80 + 6] = _world_816;
      e.mem[_t_80 + 7] = _world_817;
      e.mem[_t_80 + 8] = _world_818;
      e.mem[_t_80 + 9] = _world_819;
      e.mem[_t_80 + 10] = _world_820;
      e.mem[_t_80 + 11] = _world_821;
      e.mem[_t_80 + 12] = _world_822;
      e.mem[_t_80 + 13] = _world_823;
      e.mem[_t_80 + 14] = _world_824;
      e.mem[_t_80 + 15] = _world_825;
      e.mem[_t_80 + 16] = _world_826;
      e.mem[_t_80 + 17] = _h_459;
      e.mem[_t_80 + 18] = _world_827;
      e.mem[_t_80 + 19] = _world_828;
      e.mem[_t_80 + 20] = _world_829;
      e.mem[_t_80 + 21] = _h_460;
      e.mem[_t_80 + 22] = _h_461;
      e.mem[_t_80 + 23] = _h_462;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K305, _t_80);
      WL_IDX = 24;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_81 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_81 + 0] = _h_463;
      e.mem[_t_81 + 1] = _h_458;
      return term_tsk(FID_STRING_APPEND, _t_81);
    }
    r0 = _h_463;
    r1 = _h_458;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K305)
  {
    WL_POPN(24);
    u32 _world_830 = STK(0);
    u32 _world_831 = STK(1);
    u32 _world_832 = STK(2);
    u32 _world_833 = STK(3);
    Term _world_834 = STK(4);
    u32 _world_835 = STK(5);
    u32 _world_836 = STK(6);
    u32 _world_837 = STK(7);
    u32 _world_838 = STK(8);
    u32 _world_839 = STK(9);
    u32 _world_840 = STK(10);
    u32 _world_841 = STK(11);
    u32 _world_842 = STK(12);
    u32 _world_843 = STK(13);
    u32 _world_844 = STK(14);
    u32 _world_845 = STK(15);
    Term _world_846 = STK(16);
    Term _h_465 = STK(17);
    Term _world_847 = STK(18);
    u32 _world_848 = STK(19);
    u32 _world_849 = STK(20);
    Term _h_466 = STK(21);
    Term _h_467 = STK(22);
    Term _h_468 = STK(23);
    Term _h_464 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(25);
      STK(0) = _world_830;
      STK(1) = _world_831;
      STK(2) = _world_832;
      STK(3) = _world_833;
      STK(4) = _world_834;
      STK(5) = _world_835;
      STK(6) = _world_836;
      STK(7) = _world_837;
      STK(8) = _world_838;
      STK(9) = _world_839;
      STK(10) = _world_840;
      STK(11) = _world_841;
      STK(12) = _world_842;
      STK(13) = _world_843;
      STK(14) = _world_844;
      STK(15) = _world_845;
      STK(16) = _world_846;
      STK(17) = _h_465;
      STK(18) = _world_847;
      STK(19) = _world_848;
      STK(20) = _world_849;
      STK(21) = _h_466;
      STK(22) = _h_467;
      STK(23) = _h_468;
      STK(24) = FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K306;
      WL_PUSHN(25);
    } else {
      u64 _t_82 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K306, WL_CONT, WL_IDX, 1);
      e.mem[_t_82 + 0] = _world_830;
      e.mem[_t_82 + 1] = _world_831;
      e.mem[_t_82 + 2] = _world_832;
      e.mem[_t_82 + 3] = _world_833;
      e.mem[_t_82 + 4] = _world_834;
      e.mem[_t_82 + 5] = _world_835;
      e.mem[_t_82 + 6] = _world_836;
      e.mem[_t_82 + 7] = _world_837;
      e.mem[_t_82 + 8] = _world_838;
      e.mem[_t_82 + 9] = _world_839;
      e.mem[_t_82 + 10] = _world_840;
      e.mem[_t_82 + 11] = _world_841;
      e.mem[_t_82 + 12] = _world_842;
      e.mem[_t_82 + 13] = _world_843;
      e.mem[_t_82 + 14] = _world_844;
      e.mem[_t_82 + 15] = _world_845;
      e.mem[_t_82 + 16] = _world_846;
      e.mem[_t_82 + 17] = _h_465;
      e.mem[_t_82 + 18] = _world_847;
      e.mem[_t_82 + 19] = _world_848;
      e.mem[_t_82 + 20] = _world_849;
      e.mem[_t_82 + 21] = _h_466;
      e.mem[_t_82 + 22] = _h_467;
      e.mem[_t_82 + 23] = _h_468;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K306, _t_82);
      WL_IDX = 24;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_83 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_83 + 0] = term_ctr(CID_SCON, STAT_OFF + 190);
      e.mem[_t_83 + 1] = _h_464;
      return term_tsk(FID_STRING_APPEND, _t_83);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 190);
    r1 = _h_464;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SHOW_WORLD_0_K306)
  {
    WL_POPN(24);
    u32 _world_850 = STK(0);
    u32 _world_851 = STK(1);
    u32 _world_852 = STK(2);
    u32 _world_853 = STK(3);
    Term _world_854 = STK(4);
    u32 _world_855 = STK(5);
    u32 _world_856 = STK(6);
    u32 _world_857 = STK(7);
    u32 _world_858 = STK(8);
    u32 _world_859 = STK(9);
    u32 _world_860 = STK(10);
    u32 _world_861 = STK(11);
    u32 _world_862 = STK(12);
    u32 _world_863 = STK(13);
    u32 _world_864 = STK(14);
    u32 _world_865 = STK(15);
    Term _world_866 = STK(16);
    Term _h_470 = STK(17);
    Term _world_867 = STK(18);
    u32 _world_868 = STK(19);
    u32 _world_869 = STK(20);
    Term _h_471 = STK(21);
    Term _h_472 = STK(22);
    Term _h_473 = STK(23);
    Term _h_469 = r0;
    WL_OPEN
    r0 = _world_850;
    r1 = _world_851;
    r2 = _world_852;
    r3 = _h_471;
    r4 = _world_853;
    r5 = _world_854;
    r6 = _h_472;
    r7 = _h_473;
    r8 = _world_855;
    r9 = _world_856;
    r10 = _world_857;
    r11 = _world_858;
    r12 = _world_859;
    r13 = _world_860;
    r14 = _world_861;
    r15 = _world_862;
    r16 = _world_863;
    r17 = _world_864;
    r18 = _world_865;
    r19 = _world_866;
    r20 = _h_470;
    r21 = _world_867;
    r22 = _world_868;
    r23 = _world_869;
    r24 = _h_469;
    WL_RETN(25);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_a_0) == CID_SNIL) {
      r0 = _b_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _a_0, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_STRING_APPEND_K327;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_STRING_APPEND_K327, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_STRING_APPEND_K327, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _b_0;
      _a_0 = r0;
      _b_0 = r1;
      WL_AGAIN(FID_STRING_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND_K327)
  {
    WL_POPN(1);
    u32 _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_SCON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_OBSERVE_0)
  {
    u32 _app_0 = r0;
    u32 _app_1 = r1;
    u32 _app_2 = r2;
    Term _app_3 = r3;
    u32 _app_4 = r4;
    Term _app_5 = r5;
    Term _app_6 = r6;
    Term _app_7 = r7;
    u32 _app_8 = r8;
    u32 _app_9 = r9;
    u32 _app_10 = r10;
    u32 _app_11 = r11;
    u32 _app_12 = r12;
    u32 _app_13 = r13;
    u32 _app_14 = r14;
    u32 _app_15 = r15;
    u32 _app_16 = r16;
    u32 _app_17 = r17;
    u32 _app_18 = r18;
    Term _app_19 = r19;
    Term _app_20 = r20;
    Term _app_21 = r21;
    u32 _app_22 = r22;
    u32 _app_23 = r23;
    u32 _app_24 = r24;
    u32 _app_25 = r25;
    u32 _app_26 = r26;
    Term _app_27 = r27;
    Term _app_28 = r28;
    u32 _app_29 = r29;
    Term _app_30 = r30;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _app_24;
      STK(1) = _app_25;
      STK(2) = _app_26;
      STK(3) = _app_27;
      STK(4) = _app_28;
      STK(5) = _app_29;
      STK(6) = _app_30;
      STK(7) = FID_CONSUMER_EXPANDED_OBSERVE_0_K337;
      WL_PUSHN(8);
    } else {
      u64 _t_0 = task_node(e, FID_CONSUMER_EXPANDED_OBSERVE_0_K337, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _app_24;
      e.mem[_t_0 + 1] = _app_25;
      e.mem[_t_0 + 2] = _app_26;
      e.mem[_t_0 + 3] = _app_27;
      e.mem[_t_0 + 4] = _app_28;
      e.mem[_t_0 + 5] = _app_29;
      e.mem[_t_0 + 6] = _app_30;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_OBSERVE_0_K337, _t_0);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0)) {
      u64 _t_1 = task_node(e, FID_CONSUMER_EXPANDED_SHOW_WORLD_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _app_0;
      e.mem[_t_1 + 1] = _app_1;
      e.mem[_t_1 + 2] = _app_2;
      e.mem[_t_1 + 3] = _app_3;
      e.mem[_t_1 + 4] = _app_4;
      e.mem[_t_1 + 5] = _app_5;
      e.mem[_t_1 + 6] = _app_6;
      e.mem[_t_1 + 7] = _app_7;
      e.mem[_t_1 + 8] = _app_8;
      e.mem[_t_1 + 9] = _app_9;
      e.mem[_t_1 + 10] = _app_10;
      e.mem[_t_1 + 11] = _app_11;
      e.mem[_t_1 + 12] = _app_12;
      e.mem[_t_1 + 13] = _app_13;
      e.mem[_t_1 + 14] = _app_14;
      e.mem[_t_1 + 15] = _app_15;
      e.mem[_t_1 + 16] = _app_16;
      e.mem[_t_1 + 17] = _app_17;
      e.mem[_t_1 + 18] = _app_18;
      e.mem[_t_1 + 19] = _app_19;
      e.mem[_t_1 + 20] = _app_20;
      e.mem[_t_1 + 21] = _app_21;
      e.mem[_t_1 + 22] = _app_22;
      e.mem[_t_1 + 23] = _app_23;
      return term_tsk(FID_CONSUMER_EXPANDED_SHOW_WORLD_0, _t_1);
    }
    r0 = _app_0;
    r1 = _app_1;
    r2 = _app_2;
    r3 = _app_3;
    r4 = _app_4;
    r5 = _app_5;
    r6 = _app_6;
    r7 = _app_7;
    r8 = _app_8;
    r9 = _app_9;
    r10 = _app_10;
    r11 = _app_11;
    r12 = _app_12;
    r13 = _app_13;
    r14 = _app_14;
    r15 = _app_15;
    r16 = _app_16;
    r17 = _app_17;
    r18 = _app_18;
    r19 = _app_19;
    r20 = _app_20;
    r21 = _app_21;
    r22 = _app_22;
    r23 = _app_23;
    WL_JMP(FID_CONSUMER_EXPANDED_SHOW_WORLD_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_OBSERVE_0_K337)
  {
    WL_POPN(7);
    u32 _app_31 = STK(0);
    u32 _app_32 = STK(1);
    u32 _app_33 = STK(2);
    Term _app_34 = STK(3);
    Term _app_35 = STK(4);
    u32 _app_36 = STK(5);
    Term _app_37 = STK(6);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    u32 _h_12 = r12;
    u32 _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    Term _h_19 = r19;
    Term _h_20 = r20;
    Term _h_21 = r21;
    u32 _h_22 = r22;
    u32 _h_23 = r23;
    Term _h_24 = r24;
    WL_OPEN
    if (_app_31 == 0) {
      _app_37 = term_keep(e, _app_37, 1);
      if (seq) {
        WL_ROOM(27);
        STK(0) = _app_37;
        STK(1) = _h_0;
        STK(2) = _h_1;
        STK(3) = _h_2;
        STK(4) = _h_3;
        STK(5) = _h_4;
        STK(6) = _h_5;
        STK(7) = _h_6;
        STK(8) = _h_7;
        STK(9) = _h_8;
        STK(10) = _h_9;
        STK(11) = _h_10;
        STK(12) = _h_11;
        STK(13) = _h_12;
        STK(14) = _h_13;
        STK(15) = _h_14;
        STK(16) = _h_15;
        STK(17) = _h_16;
        STK(18) = _h_17;
        STK(19) = _h_18;
        STK(20) = _h_19;
        STK(21) = _h_20;
        STK(22) = _h_21;
        STK(23) = _h_22;
        STK(24) = _h_23;
        STK(25) = _h_24;
        STK(26) = FID_CONSUMER_EXPANDED_OBSERVE_0_K338;
        WL_PUSHN(27);
      } else {
        u64 _t_2 = task_node(e, FID_CONSUMER_EXPANDED_OBSERVE_0_K338, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _app_37;
        e.mem[_t_2 + 1] = _h_0;
        e.mem[_t_2 + 2] = _h_1;
        e.mem[_t_2 + 3] = _h_2;
        e.mem[_t_2 + 4] = _h_3;
        e.mem[_t_2 + 5] = _h_4;
        e.mem[_t_2 + 6] = _h_5;
        e.mem[_t_2 + 7] = _h_6;
        e.mem[_t_2 + 8] = _h_7;
        e.mem[_t_2 + 9] = _h_8;
        e.mem[_t_2 + 10] = _h_9;
        e.mem[_t_2 + 11] = _h_10;
        e.mem[_t_2 + 12] = _h_11;
        e.mem[_t_2 + 13] = _h_12;
        e.mem[_t_2 + 14] = _h_13;
        e.mem[_t_2 + 15] = _h_14;
        e.mem[_t_2 + 16] = _h_15;
        e.mem[_t_2 + 17] = _h_16;
        e.mem[_t_2 + 18] = _h_17;
        e.mem[_t_2 + 19] = _h_18;
        e.mem[_t_2 + 20] = _h_19;
        e.mem[_t_2 + 21] = _h_20;
        e.mem[_t_2 + 22] = _h_21;
        e.mem[_t_2 + 23] = _h_22;
        e.mem[_t_2 + 24] = _h_23;
        e.mem[_t_2 + 25] = _h_24;
        WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_OBSERVE_0_K338, _t_2);
        WL_IDX = 26;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
        u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 418);
        e.mem[_t_3 + 1] = _app_37;
        return term_tsk(FID_STRING_APPEND, _t_3);
      }
      r0 = term_ctr(CID_SCON, STAT_OFF + 418);
      r1 = _app_37;
      WL_JMP(FID_STRING_APPEND);
    } else {
      if (seq) {
        WL_ROOM(32);
        STK(0) = _app_37;
        STK(1) = _h_0;
        STK(2) = _h_1;
        STK(3) = _h_2;
        STK(4) = _h_3;
        STK(5) = _h_4;
        STK(6) = _h_5;
        STK(7) = _h_6;
        STK(8) = _h_7;
        STK(9) = _h_8;
        STK(10) = _h_9;
        STK(11) = _h_10;
        STK(12) = _h_11;
        STK(13) = _h_12;
        STK(14) = _h_13;
        STK(15) = _h_14;
        STK(16) = _h_15;
        STK(17) = _h_16;
        STK(18) = _h_17;
        STK(19) = _h_18;
        STK(20) = _h_19;
        STK(21) = _h_20;
        STK(22) = _h_21;
        STK(23) = _h_22;
        STK(24) = _h_23;
        STK(25) = _h_24;
        STK(26) = _app_32;
        STK(27) = _app_33;
        STK(28) = _app_34;
        STK(29) = _app_35;
        STK(30) = _app_36;
        STK(31) = FID_CONSUMER_EXPANDED_OBSERVE_0_K340;
        WL_PUSHN(32);
      } else {
        u64 _t_6 = task_node(e, FID_CONSUMER_EXPANDED_OBSERVE_0_K340, WL_CONT, WL_IDX, 1);
        e.mem[_t_6 + 0] = _app_37;
        e.mem[_t_6 + 1] = _h_0;
        e.mem[_t_6 + 2] = _h_1;
        e.mem[_t_6 + 3] = _h_2;
        e.mem[_t_6 + 4] = _h_3;
        e.mem[_t_6 + 5] = _h_4;
        e.mem[_t_6 + 6] = _h_5;
        e.mem[_t_6 + 7] = _h_6;
        e.mem[_t_6 + 8] = _h_7;
        e.mem[_t_6 + 9] = _h_8;
        e.mem[_t_6 + 10] = _h_9;
        e.mem[_t_6 + 11] = _h_10;
        e.mem[_t_6 + 12] = _h_11;
        e.mem[_t_6 + 13] = _h_12;
        e.mem[_t_6 + 14] = _h_13;
        e.mem[_t_6 + 15] = _h_14;
        e.mem[_t_6 + 16] = _h_15;
        e.mem[_t_6 + 17] = _h_16;
        e.mem[_t_6 + 18] = _h_17;
        e.mem[_t_6 + 19] = _h_18;
        e.mem[_t_6 + 20] = _h_19;
        e.mem[_t_6 + 21] = _h_20;
        e.mem[_t_6 + 22] = _h_21;
        e.mem[_t_6 + 23] = _h_22;
        e.mem[_t_6 + 24] = _h_23;
        e.mem[_t_6 + 25] = _h_24;
        e.mem[_t_6 + 26] = _app_32;
        e.mem[_t_6 + 27] = _app_33;
        e.mem[_t_6 + 28] = _app_34;
        e.mem[_t_6 + 29] = _app_35;
        e.mem[_t_6 + 30] = _app_36;
        WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_OBSERVE_0_K340, _t_6);
        WL_IDX = 31;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_7 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_7 + 0] = _app_32;
        return term_tsk(FID_U32_SHOW, _t_7);
      }
      r0 = _app_32;
      WL_JMP(FID_U32_SHOW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_OBSERVE_0_K338)
  {
    WL_POPN(26);
    Term _app_38 = STK(0);
    u32 _h_26 = STK(1);
    u32 _h_27 = STK(2);
    u32 _h_28 = STK(3);
    Term _h_29 = STK(4);
    u32 _h_30 = STK(5);
    Term _h_31 = STK(6);
    Term _h_32 = STK(7);
    Term _h_33 = STK(8);
    u32 _h_34 = STK(9);
    u32 _h_35 = STK(10);
    u32 _h_36 = STK(11);
    u32 _h_37 = STK(12);
    u32 _h_38 = STK(13);
    u32 _h_39 = STK(14);
    u32 _h_40 = STK(15);
    u32 _h_41 = STK(16);
    u32 _h_42 = STK(17);
    u32 _h_43 = STK(18);
    u32 _h_44 = STK(19);
    Term _h_45 = STK(20);
    Term _h_46 = STK(21);
    Term _h_47 = STK(22);
    u32 _h_48 = STK(23);
    u32 _h_49 = STK(24);
    Term _h_50 = STK(25);
    Term _h_25 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(26);
      STK(0) = _app_38;
      STK(1) = _h_26;
      STK(2) = _h_27;
      STK(3) = _h_28;
      STK(4) = _h_29;
      STK(5) = _h_30;
      STK(6) = _h_31;
      STK(7) = _h_32;
      STK(8) = _h_33;
      STK(9) = _h_34;
      STK(10) = _h_35;
      STK(11) = _h_36;
      STK(12) = _h_37;
      STK(13) = _h_38;
      STK(14) = _h_39;
      STK(15) = _h_40;
      STK(16) = _h_41;
      STK(17) = _h_42;
      STK(18) = _h_43;
      STK(19) = _h_44;
      STK(20) = _h_45;
      STK(21) = _h_46;
      STK(22) = _h_47;
      STK(23) = _h_48;
      STK(24) = _h_49;
      STK(25) = FID_CONSUMER_EXPANDED_OBSERVE_0_K339;
      WL_PUSHN(26);
    } else {
      u64 _t_4 = task_node(e, FID_CONSUMER_EXPANDED_OBSERVE_0_K339, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _app_38;
      e.mem[_t_4 + 1] = _h_26;
      e.mem[_t_4 + 2] = _h_27;
      e.mem[_t_4 + 3] = _h_28;
      e.mem[_t_4 + 4] = _h_29;
      e.mem[_t_4 + 5] = _h_30;
      e.mem[_t_4 + 6] = _h_31;
      e.mem[_t_4 + 7] = _h_32;
      e.mem[_t_4 + 8] = _h_33;
      e.mem[_t_4 + 9] = _h_34;
      e.mem[_t_4 + 10] = _h_35;
      e.mem[_t_4 + 11] = _h_36;
      e.mem[_t_4 + 12] = _h_37;
      e.mem[_t_4 + 13] = _h_38;
      e.mem[_t_4 + 14] = _h_39;
      e.mem[_t_4 + 15] = _h_40;
      e.mem[_t_4 + 16] = _h_41;
      e.mem[_t_4 + 17] = _h_42;
      e.mem[_t_4 + 18] = _h_43;
      e.mem[_t_4 + 19] = _h_44;
      e.mem[_t_4 + 20] = _h_45;
      e.mem[_t_4 + 21] = _h_46;
      e.mem[_t_4 + 22] = _h_47;
      e.mem[_t_4 + 23] = _h_48;
      e.mem[_t_4 + 24] = _h_49;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_OBSERVE_0_K339, _t_4);
      WL_IDX = 25;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_50;
      e.mem[_t_5 + 1] = _h_25;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_50;
    r1 = _h_25;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_OBSERVE_0_K339)
  {
    WL_POPN(25);
    Term _app_39 = STK(0);
    u32 _h_52 = STK(1);
    u32 _h_53 = STK(2);
    u32 _h_54 = STK(3);
    Term _h_55 = STK(4);
    u32 _h_56 = STK(5);
    Term _h_57 = STK(6);
    Term _h_58 = STK(7);
    Term _h_59 = STK(8);
    u32 _h_60 = STK(9);
    u32 _h_61 = STK(10);
    u32 _h_62 = STK(11);
    u32 _h_63 = STK(12);
    u32 _h_64 = STK(13);
    u32 _h_65 = STK(14);
    u32 _h_66 = STK(15);
    u32 _h_67 = STK(16);
    u32 _h_68 = STK(17);
    u32 _h_69 = STK(18);
    u32 _h_70 = STK(19);
    Term _h_71 = STK(20);
    Term _h_72 = STK(21);
    Term _h_73 = STK(22);
    u32 _h_74 = STK(23);
    u32 _h_75 = STK(24);
    Term _h_51 = r0;
    WL_OPEN
    r0 = _h_52;
    r1 = _h_53;
    r2 = _h_54;
    r3 = _h_55;
    r4 = _h_56;
    r5 = _h_57;
    r6 = _h_58;
    r7 = _h_59;
    r8 = _h_60;
    r9 = _h_61;
    r10 = _h_62;
    r11 = _h_63;
    r12 = _h_64;
    r13 = _h_65;
    r14 = _h_66;
    r15 = _h_67;
    r16 = _h_68;
    r17 = _h_69;
    r18 = _h_70;
    r19 = _h_71;
    r20 = _h_72;
    r21 = _h_73;
    r22 = _h_74;
    r23 = _h_75;
    r24 = 0;
    r25 = 0;
    r26 = 0;
    r27 = 0;
    r28 = 0;
    r29 = 0;
    r30 = _app_39;
    r31 = _h_51;
    WL_RETN(32);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_OBSERVE_0_K340)
  {
    WL_POPN(31);
    Term _app_40 = STK(0);
    u32 _h_77 = STK(1);
    u32 _h_78 = STK(2);
    u32 _h_79 = STK(3);
    Term _h_80 = STK(4);
    u32 _h_81 = STK(5);
    Term _h_82 = STK(6);
    Term _h_83 = STK(7);
    Term _h_84 = STK(8);
    u32 _h_85 = STK(9);
    u32 _h_86 = STK(10);
    u32 _h_87 = STK(11);
    u32 _h_88 = STK(12);
    u32 _h_89 = STK(13);
    u32 _h_90 = STK(14);
    u32 _h_91 = STK(15);
    u32 _h_92 = STK(16);
    u32 _h_93 = STK(17);
    u32 _h_94 = STK(18);
    u32 _h_95 = STK(19);
    Term _h_96 = STK(20);
    Term _h_97 = STK(21);
    Term _h_98 = STK(22);
    u32 _h_99 = STK(23);
    u32 _h_100 = STK(24);
    Term _h_101 = STK(25);
    u32 _app_41 = STK(26);
    u32 _app_42 = STK(27);
    Term _app_43 = STK(28);
    Term _app_44 = STK(29);
    u32 _app_45 = STK(30);
    Term _h_76 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(33);
      STK(0) = _app_40;
      STK(1) = _h_77;
      STK(2) = _h_78;
      STK(3) = _h_79;
      STK(4) = _h_80;
      STK(5) = _h_81;
      STK(6) = _h_82;
      STK(7) = _h_83;
      STK(8) = _h_84;
      STK(9) = _h_85;
      STK(10) = _h_86;
      STK(11) = _h_87;
      STK(12) = _h_88;
      STK(13) = _h_89;
      STK(14) = _h_90;
      STK(15) = _h_91;
      STK(16) = _h_92;
      STK(17) = _h_93;
      STK(18) = _h_94;
      STK(19) = _h_95;
      STK(20) = _h_96;
      STK(21) = _h_97;
      STK(22) = _h_98;
      STK(23) = _h_99;
      STK(24) = _h_100;
      STK(25) = _h_101;
      STK(26) = _app_41;
      STK(27) = _app_42;
      STK(28) = _app_43;
      STK(29) = _app_44;
      STK(30) = _app_45;
      STK(31) = _h_76;
      STK(32) = FID_CONSUMER_EXPANDED_OBSERVE_0_K341;
      WL_PUSHN(33);
    } else {
      u64 _t_8 = task_node(e, FID_CONSUMER_EXPANDED_OBSERVE_0_K341, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _app_40;
      e.mem[_t_8 + 1] = _h_77;
      e.mem[_t_8 + 2] = _h_78;
      e.mem[_t_8 + 3] = _h_79;
      e.mem[_t_8 + 4] = _h_80;
      e.mem[_t_8 + 5] = _h_81;
      e.mem[_t_8 + 6] = _h_82;
      e.mem[_t_8 + 7] = _h_83;
      e.mem[_t_8 + 8] = _h_84;
      e.mem[_t_8 + 9] = _h_85;
      e.mem[_t_8 + 10] = _h_86;
      e.mem[_t_8 + 11] = _h_87;
      e.mem[_t_8 + 12] = _h_88;
      e.mem[_t_8 + 13] = _h_89;
      e.mem[_t_8 + 14] = _h_90;
      e.mem[_t_8 + 15] = _h_91;
      e.mem[_t_8 + 16] = _h_92;
      e.mem[_t_8 + 17] = _h_93;
      e.mem[_t_8 + 18] = _h_94;
      e.mem[_t_8 + 19] = _h_95;
      e.mem[_t_8 + 20] = _h_96;
      e.mem[_t_8 + 21] = _h_97;
      e.mem[_t_8 + 22] = _h_98;
      e.mem[_t_8 + 23] = _h_99;
      e.mem[_t_8 + 24] = _h_100;
      e.mem[_t_8 + 25] = _h_101;
      e.mem[_t_8 + 26] = _app_41;
      e.mem[_t_8 + 27] = _app_42;
      e.mem[_t_8 + 28] = _app_43;
      e.mem[_t_8 + 29] = _app_44;
      e.mem[_t_8 + 30] = _app_45;
      e.mem[_t_8 + 31] = _h_76;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_OBSERVE_0_K341, _t_8);
      WL_IDX = 32;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_9 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _app_42;
      return term_tsk(FID_U32_SHOW, _t_9);
    }
    r0 = _app_42;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_OBSERVE_0_K341)
  {
    WL_POPN(32);
    Term _app_46 = STK(0);
    u32 _h_103 = STK(1);
    u32 _h_104 = STK(2);
    u32 _h_105 = STK(3);
    Term _h_106 = STK(4);
    u32 _h_107 = STK(5);
    Term _h_108 = STK(6);
    Term _h_109 = STK(7);
    Term _h_110 = STK(8);
    u32 _h_111 = STK(9);
    u32 _h_112 = STK(10);
    u32 _h_113 = STK(11);
    u32 _h_114 = STK(12);
    u32 _h_115 = STK(13);
    u32 _h_116 = STK(14);
    u32 _h_117 = STK(15);
    u32 _h_118 = STK(16);
    u32 _h_119 = STK(17);
    u32 _h_120 = STK(18);
    u32 _h_121 = STK(19);
    Term _h_122 = STK(20);
    Term _h_123 = STK(21);
    Term _h_124 = STK(22);
    u32 _h_125 = STK(23);
    u32 _h_126 = STK(24);
    Term _h_127 = STK(25);
    u32 _app_47 = STK(26);
    u32 _app_48 = STK(27);
    Term _app_49 = STK(28);
    Term _app_50 = STK(29);
    u32 _app_51 = STK(30);
    Term _h_128 = STK(31);
    Term _h_102 = r0;
    WL_OPEN
    _app_50 = term_keep(e, _app_50, 1);
    if (seq) {
      WL_ROOM(34);
      STK(0) = _app_46;
      STK(1) = _h_103;
      STK(2) = _h_104;
      STK(3) = _h_105;
      STK(4) = _h_106;
      STK(5) = _h_107;
      STK(6) = _h_108;
      STK(7) = _h_109;
      STK(8) = _h_110;
      STK(9) = _h_111;
      STK(10) = _h_112;
      STK(11) = _h_113;
      STK(12) = _h_114;
      STK(13) = _h_115;
      STK(14) = _h_116;
      STK(15) = _h_117;
      STK(16) = _h_118;
      STK(17) = _h_119;
      STK(18) = _h_120;
      STK(19) = _h_121;
      STK(20) = _h_122;
      STK(21) = _h_123;
      STK(22) = _h_124;
      STK(23) = _h_125;
      STK(24) = _h_126;
      STK(25) = _h_127;
      STK(26) = _app_47;
      STK(27) = _app_48;
      STK(28) = _app_49;
      STK(29) = _app_50;
      STK(30) = _app_51;
      STK(31) = _h_128;
      STK(32) = _h_102;
      STK(33) = FID_CONSUMER_EXPANDED_OBSERVE_0_K342;
      WL_PUSHN(34);
    } else {
      u64 _t_10 = task_node(e, FID_CONSUMER_EXPANDED_OBSERVE_0_K342, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _app_46;
      e.mem[_t_10 + 1] = _h_103;
      e.mem[_t_10 + 2] = _h_104;
      e.mem[_t_10 + 3] = _h_105;
      e.mem[_t_10 + 4] = _h_106;
      e.mem[_t_10 + 5] = _h_107;
      e.mem[_t_10 + 6] = _h_108;
      e.mem[_t_10 + 7] = _h_109;
      e.mem[_t_10 + 8] = _h_110;
      e.mem[_t_10 + 9] = _h_111;
      e.mem[_t_10 + 10] = _h_112;
      e.mem[_t_10 + 11] = _h_113;
      e.mem[_t_10 + 12] = _h_114;
      e.mem[_t_10 + 13] = _h_115;
      e.mem[_t_10 + 14] = _h_116;
      e.mem[_t_10 + 15] = _h_117;
      e.mem[_t_10 + 16] = _h_118;
      e.mem[_t_10 + 17] = _h_119;
      e.mem[_t_10 + 18] = _h_120;
      e.mem[_t_10 + 19] = _h_121;
      e.mem[_t_10 + 20] = _h_122;
      e.mem[_t_10 + 21] = _h_123;
      e.mem[_t_10 + 22] = _h_124;
      e.mem[_t_10 + 23] = _h_125;
      e.mem[_t_10 + 24] = _h_126;
      e.mem[_t_10 + 25] = _h_127;
      e.mem[_t_10 + 26] = _app_47;
      e.mem[_t_10 + 27] = _app_48;
      e.mem[_t_10 + 28] = _app_49;
      e.mem[_t_10 + 29] = _app_50;
      e.mem[_t_10 + 30] = _app_51;
      e.mem[_t_10 + 31] = _h_128;
      e.mem[_t_10 + 32] = _h_102;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_OBSERVE_0_K342, _t_10);
      WL_IDX = 33;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_0)) {
      u64 _t_11 = task_node(e, FID_LIST_SHOW_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _app_50;
      return term_tsk(FID_LIST_SHOW_0, _t_11);
    }
    r0 = _app_50;
    WL_JMP(FID_LIST_SHOW_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_OBSERVE_0_K342)
  {
    WL_POPN(33);
    Term _app_52 = STK(0);
    u32 _h_130 = STK(1);
    u32 _h_131 = STK(2);
    u32 _h_132 = STK(3);
    Term _h_133 = STK(4);
    u32 _h_134 = STK(5);
    Term _h_135 = STK(6);
    Term _h_136 = STK(7);
    Term _h_137 = STK(8);
    u32 _h_138 = STK(9);
    u32 _h_139 = STK(10);
    u32 _h_140 = STK(11);
    u32 _h_141 = STK(12);
    u32 _h_142 = STK(13);
    u32 _h_143 = STK(14);
    u32 _h_144 = STK(15);
    u32 _h_145 = STK(16);
    u32 _h_146 = STK(17);
    u32 _h_147 = STK(18);
    u32 _h_148 = STK(19);
    Term _h_149 = STK(20);
    Term _h_150 = STK(21);
    Term _h_151 = STK(22);
    u32 _h_152 = STK(23);
    u32 _h_153 = STK(24);
    Term _h_154 = STK(25);
    u32 _app_53 = STK(26);
    u32 _app_54 = STK(27);
    Term _app_55 = STK(28);
    Term _app_56 = STK(29);
    u32 _app_57 = STK(30);
    Term _h_155 = STK(31);
    Term _h_156 = STK(32);
    Term _h_129 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(35);
      STK(0) = _app_52;
      STK(1) = _h_130;
      STK(2) = _h_131;
      STK(3) = _h_132;
      STK(4) = _h_133;
      STK(5) = _h_134;
      STK(6) = _h_135;
      STK(7) = _h_136;
      STK(8) = _h_137;
      STK(9) = _h_138;
      STK(10) = _h_139;
      STK(11) = _h_140;
      STK(12) = _h_141;
      STK(13) = _h_142;
      STK(14) = _h_143;
      STK(15) = _h_144;
      STK(16) = _h_145;
      STK(17) = _h_146;
      STK(18) = _h_147;
      STK(19) = _h_148;
      STK(20) = _h_149;
      STK(21) = _h_150;
      STK(22) = _h_151;
      STK(23) = _h_152;
      STK(24) = _h_153;
      STK(25) = _h_154;
      STK(26) = _app_53;
      STK(27) = _app_54;
      STK(28) = _app_55;
      STK(29) = _app_56;
      STK(30) = _app_57;
      STK(31) = _h_155;
      STK(32) = _h_156;
      STK(33) = _h_129;
      STK(34) = FID_CONSUMER_EXPANDED_OBSERVE_0_K343;
      WL_PUSHN(35);
    } else {
      u64 _t_12 = task_node(e, FID_CONSUMER_EXPANDED_OBSERVE_0_K343, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _app_52;
      e.mem[_t_12 + 1] = _h_130;
      e.mem[_t_12 + 2] = _h_131;
      e.mem[_t_12 + 3] = _h_132;
      e.mem[_t_12 + 4] = _h_133;
      e.mem[_t_12 + 5] = _h_134;
      e.mem[_t_12 + 6] = _h_135;
      e.mem[_t_12 + 7] = _h_136;
      e.mem[_t_12 + 8] = _h_137;
      e.mem[_t_12 + 9] = _h_138;
      e.mem[_t_12 + 10] = _h_139;
      e.mem[_t_12 + 11] = _h_140;
      e.mem[_t_12 + 12] = _h_141;
      e.mem[_t_12 + 13] = _h_142;
      e.mem[_t_12 + 14] = _h_143;
      e.mem[_t_12 + 15] = _h_144;
      e.mem[_t_12 + 16] = _h_145;
      e.mem[_t_12 + 17] = _h_146;
      e.mem[_t_12 + 18] = _h_147;
      e.mem[_t_12 + 19] = _h_148;
      e.mem[_t_12 + 20] = _h_149;
      e.mem[_t_12 + 21] = _h_150;
      e.mem[_t_12 + 22] = _h_151;
      e.mem[_t_12 + 23] = _h_152;
      e.mem[_t_12 + 24] = _h_153;
      e.mem[_t_12 + 25] = _h_154;
      e.mem[_t_12 + 26] = _app_53;
      e.mem[_t_12 + 27] = _app_54;
      e.mem[_t_12 + 28] = _app_55;
      e.mem[_t_12 + 29] = _app_56;
      e.mem[_t_12 + 30] = _app_57;
      e.mem[_t_12 + 31] = _h_155;
      e.mem[_t_12 + 32] = _h_156;
      e.mem[_t_12 + 33] = _h_129;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_OBSERVE_0_K343, _t_12);
      WL_IDX = 34;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_13 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _app_57;
      return term_tsk(FID_U32_SHOW, _t_13);
    }
    r0 = _app_57;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_OBSERVE_0_K343)
  {
    WL_POPN(34);
    Term _app_58 = STK(0);
    u32 _h_158 = STK(1);
    u32 _h_159 = STK(2);
    u32 _h_160 = STK(3);
    Term _h_161 = STK(4);
    u32 _h_162 = STK(5);
    Term _h_163 = STK(6);
    Term _h_164 = STK(7);
    Term _h_165 = STK(8);
    u32 _h_166 = STK(9);
    u32 _h_167 = STK(10);
    u32 _h_168 = STK(11);
    u32 _h_169 = STK(12);
    u32 _h_170 = STK(13);
    u32 _h_171 = STK(14);
    u32 _h_172 = STK(15);
    u32 _h_173 = STK(16);
    u32 _h_174 = STK(17);
    u32 _h_175 = STK(18);
    u32 _h_176 = STK(19);
    Term _h_177 = STK(20);
    Term _h_178 = STK(21);
    Term _h_179 = STK(22);
    u32 _h_180 = STK(23);
    u32 _h_181 = STK(24);
    Term _h_182 = STK(25);
    u32 _app_59 = STK(26);
    u32 _app_60 = STK(27);
    Term _app_61 = STK(28);
    Term _app_62 = STK(29);
    u32 _app_63 = STK(30);
    Term _h_183 = STK(31);
    Term _h_184 = STK(32);
    Term _h_185 = STK(33);
    Term _h_157 = r0;
    WL_OPEN
    _app_58 = term_keep(e, _app_58, 1);
    if (seq) {
      WL_ROOM(36);
      STK(0) = _app_58;
      STK(1) = _h_158;
      STK(2) = _h_159;
      STK(3) = _h_160;
      STK(4) = _h_161;
      STK(5) = _h_162;
      STK(6) = _h_163;
      STK(7) = _h_164;
      STK(8) = _h_165;
      STK(9) = _h_166;
      STK(10) = _h_167;
      STK(11) = _h_168;
      STK(12) = _h_169;
      STK(13) = _h_170;
      STK(14) = _h_171;
      STK(15) = _h_172;
      STK(16) = _h_173;
      STK(17) = _h_174;
      STK(18) = _h_175;
      STK(19) = _h_176;
      STK(20) = _h_177;
      STK(21) = _h_178;
      STK(22) = _h_179;
      STK(23) = _h_180;
      STK(24) = _h_181;
      STK(25) = _h_182;
      STK(26) = _app_59;
      STK(27) = _app_60;
      STK(28) = _app_61;
      STK(29) = _app_62;
      STK(30) = _app_63;
      STK(31) = _h_183;
      STK(32) = _h_184;
      STK(33) = _h_185;
      STK(34) = _h_157;
      STK(35) = FID_CONSUMER_EXPANDED_OBSERVE_0_K344;
      WL_PUSHN(36);
    } else {
      u64 _t_14 = task_node(e, FID_CONSUMER_EXPANDED_OBSERVE_0_K344, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _app_58;
      e.mem[_t_14 + 1] = _h_158;
      e.mem[_t_14 + 2] = _h_159;
      e.mem[_t_14 + 3] = _h_160;
      e.mem[_t_14 + 4] = _h_161;
      e.mem[_t_14 + 5] = _h_162;
      e.mem[_t_14 + 6] = _h_163;
      e.mem[_t_14 + 7] = _h_164;
      e.mem[_t_14 + 8] = _h_165;
      e.mem[_t_14 + 9] = _h_166;
      e.mem[_t_14 + 10] = _h_167;
      e.mem[_t_14 + 11] = _h_168;
      e.mem[_t_14 + 12] = _h_169;
      e.mem[_t_14 + 13] = _h_170;
      e.mem[_t_14 + 14] = _h_171;
      e.mem[_t_14 + 15] = _h_172;
      e.mem[_t_14 + 16] = _h_173;
      e.mem[_t_14 + 17] = _h_174;
      e.mem[_t_14 + 18] = _h_175;
      e.mem[_t_14 + 19] = _h_176;
      e.mem[_t_14 + 20] = _h_177;
      e.mem[_t_14 + 21] = _h_178;
      e.mem[_t_14 + 22] = _h_179;
      e.mem[_t_14 + 23] = _h_180;
      e.mem[_t_14 + 24] = _h_181;
      e.mem[_t_14 + 25] = _h_182;
      e.mem[_t_14 + 26] = _app_59;
      e.mem[_t_14 + 27] = _app_60;
      e.mem[_t_14 + 28] = _app_61;
      e.mem[_t_14 + 29] = _app_62;
      e.mem[_t_14 + 30] = _app_63;
      e.mem[_t_14 + 31] = _h_183;
      e.mem[_t_14 + 32] = _h_184;
      e.mem[_t_14 + 33] = _h_185;
      e.mem[_t_14 + 34] = _h_157;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_OBSERVE_0_K344, _t_14);
      WL_IDX = 35;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_15 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = term_ctr(CID_SCON, STAT_OFF + 390);
      e.mem[_t_15 + 1] = _app_58;
      return term_tsk(FID_STRING_APPEND, _t_15);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 390);
    r1 = _app_58;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_OBSERVE_0_K344)
  {
    WL_POPN(35);
    Term _app_64 = STK(0);
    u32 _h_187 = STK(1);
    u32 _h_188 = STK(2);
    u32 _h_189 = STK(3);
    Term _h_190 = STK(4);
    u32 _h_191 = STK(5);
    Term _h_192 = STK(6);
    Term _h_193 = STK(7);
    Term _h_194 = STK(8);
    u32 _h_195 = STK(9);
    u32 _h_196 = STK(10);
    u32 _h_197 = STK(11);
    u32 _h_198 = STK(12);
    u32 _h_199 = STK(13);
    u32 _h_200 = STK(14);
    u32 _h_201 = STK(15);
    u32 _h_202 = STK(16);
    u32 _h_203 = STK(17);
    u32 _h_204 = STK(18);
    u32 _h_205 = STK(19);
    Term _h_206 = STK(20);
    Term _h_207 = STK(21);
    Term _h_208 = STK(22);
    u32 _h_209 = STK(23);
    u32 _h_210 = STK(24);
    Term _h_211 = STK(25);
    u32 _app_65 = STK(26);
    u32 _app_66 = STK(27);
    Term _app_67 = STK(28);
    Term _app_68 = STK(29);
    u32 _app_69 = STK(30);
    Term _h_212 = STK(31);
    Term _h_213 = STK(32);
    Term _h_214 = STK(33);
    Term _h_215 = STK(34);
    Term _h_186 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(35);
      STK(0) = _app_64;
      STK(1) = _h_187;
      STK(2) = _h_188;
      STK(3) = _h_189;
      STK(4) = _h_190;
      STK(5) = _h_191;
      STK(6) = _h_192;
      STK(7) = _h_193;
      STK(8) = _h_194;
      STK(9) = _h_195;
      STK(10) = _h_196;
      STK(11) = _h_197;
      STK(12) = _h_198;
      STK(13) = _h_199;
      STK(14) = _h_200;
      STK(15) = _h_201;
      STK(16) = _h_202;
      STK(17) = _h_203;
      STK(18) = _h_204;
      STK(19) = _h_205;
      STK(20) = _h_206;
      STK(21) = _h_207;
      STK(22) = _h_208;
      STK(23) = _h_209;
      STK(24) = _h_210;
      STK(25) = _h_211;
      STK(26) = _app_65;
      STK(27) = _app_66;
      STK(28) = _app_67;
      STK(29) = _app_68;
      STK(30) = _app_69;
      STK(31) = _h_212;
      STK(32) = _h_213;
      STK(33) = _h_214;
      STK(34) = FID_CONSUMER_EXPANDED_OBSERVE_0_K345;
      WL_PUSHN(35);
    } else {
      u64 _t_16 = task_node(e, FID_CONSUMER_EXPANDED_OBSERVE_0_K345, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _app_64;
      e.mem[_t_16 + 1] = _h_187;
      e.mem[_t_16 + 2] = _h_188;
      e.mem[_t_16 + 3] = _h_189;
      e.mem[_t_16 + 4] = _h_190;
      e.mem[_t_16 + 5] = _h_191;
      e.mem[_t_16 + 6] = _h_192;
      e.mem[_t_16 + 7] = _h_193;
      e.mem[_t_16 + 8] = _h_194;
      e.mem[_t_16 + 9] = _h_195;
      e.mem[_t_16 + 10] = _h_196;
      e.mem[_t_16 + 11] = _h_197;
      e.mem[_t_16 + 12] = _h_198;
      e.mem[_t_16 + 13] = _h_199;
      e.mem[_t_16 + 14] = _h_200;
      e.mem[_t_16 + 15] = _h_201;
      e.mem[_t_16 + 16] = _h_202;
      e.mem[_t_16 + 17] = _h_203;
      e.mem[_t_16 + 18] = _h_204;
      e.mem[_t_16 + 19] = _h_205;
      e.mem[_t_16 + 20] = _h_206;
      e.mem[_t_16 + 21] = _h_207;
      e.mem[_t_16 + 22] = _h_208;
      e.mem[_t_16 + 23] = _h_209;
      e.mem[_t_16 + 24] = _h_210;
      e.mem[_t_16 + 25] = _h_211;
      e.mem[_t_16 + 26] = _app_65;
      e.mem[_t_16 + 27] = _app_66;
      e.mem[_t_16 + 28] = _app_67;
      e.mem[_t_16 + 29] = _app_68;
      e.mem[_t_16 + 30] = _app_69;
      e.mem[_t_16 + 31] = _h_212;
      e.mem[_t_16 + 32] = _h_213;
      e.mem[_t_16 + 33] = _h_214;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_OBSERVE_0_K345, _t_16);
      WL_IDX = 34;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_17 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _h_215;
      e.mem[_t_17 + 1] = _h_186;
      return term_tsk(FID_STRING_APPEND, _t_17);
    }
    r0 = _h_215;
    r1 = _h_186;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_OBSERVE_0_K345)
  {
    WL_POPN(34);
    Term _app_70 = STK(0);
    u32 _h_217 = STK(1);
    u32 _h_218 = STK(2);
    u32 _h_219 = STK(3);
    Term _h_220 = STK(4);
    u32 _h_221 = STK(5);
    Term _h_222 = STK(6);
    Term _h_223 = STK(7);
    Term _h_224 = STK(8);
    u32 _h_225 = STK(9);
    u32 _h_226 = STK(10);
    u32 _h_227 = STK(11);
    u32 _h_228 = STK(12);
    u32 _h_229 = STK(13);
    u32 _h_230 = STK(14);
    u32 _h_231 = STK(15);
    u32 _h_232 = STK(16);
    u32 _h_233 = STK(17);
    u32 _h_234 = STK(18);
    u32 _h_235 = STK(19);
    Term _h_236 = STK(20);
    Term _h_237 = STK(21);
    Term _h_238 = STK(22);
    u32 _h_239 = STK(23);
    u32 _h_240 = STK(24);
    Term _h_241 = STK(25);
    u32 _app_71 = STK(26);
    u32 _app_72 = STK(27);
    Term _app_73 = STK(28);
    Term _app_74 = STK(29);
    u32 _app_75 = STK(30);
    Term _h_242 = STK(31);
    Term _h_243 = STK(32);
    Term _h_244 = STK(33);
    Term _h_216 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(35);
      STK(0) = _app_70;
      STK(1) = _h_217;
      STK(2) = _h_218;
      STK(3) = _h_219;
      STK(4) = _h_220;
      STK(5) = _h_221;
      STK(6) = _h_222;
      STK(7) = _h_223;
      STK(8) = _h_224;
      STK(9) = _h_225;
      STK(10) = _h_226;
      STK(11) = _h_227;
      STK(12) = _h_228;
      STK(13) = _h_229;
      STK(14) = _h_230;
      STK(15) = _h_231;
      STK(16) = _h_232;
      STK(17) = _h_233;
      STK(18) = _h_234;
      STK(19) = _h_235;
      STK(20) = _h_236;
      STK(21) = _h_237;
      STK(22) = _h_238;
      STK(23) = _h_239;
      STK(24) = _h_240;
      STK(25) = _h_241;
      STK(26) = _app_71;
      STK(27) = _app_72;
      STK(28) = _app_73;
      STK(29) = _app_74;
      STK(30) = _app_75;
      STK(31) = _h_242;
      STK(32) = _h_243;
      STK(33) = _h_244;
      STK(34) = FID_CONSUMER_EXPANDED_OBSERVE_0_K346;
      WL_PUSHN(35);
    } else {
      u64 _t_18 = task_node(e, FID_CONSUMER_EXPANDED_OBSERVE_0_K346, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _app_70;
      e.mem[_t_18 + 1] = _h_217;
      e.mem[_t_18 + 2] = _h_218;
      e.mem[_t_18 + 3] = _h_219;
      e.mem[_t_18 + 4] = _h_220;
      e.mem[_t_18 + 5] = _h_221;
      e.mem[_t_18 + 6] = _h_222;
      e.mem[_t_18 + 7] = _h_223;
      e.mem[_t_18 + 8] = _h_224;
      e.mem[_t_18 + 9] = _h_225;
      e.mem[_t_18 + 10] = _h_226;
      e.mem[_t_18 + 11] = _h_227;
      e.mem[_t_18 + 12] = _h_228;
      e.mem[_t_18 + 13] = _h_229;
      e.mem[_t_18 + 14] = _h_230;
      e.mem[_t_18 + 15] = _h_231;
      e.mem[_t_18 + 16] = _h_232;
      e.mem[_t_18 + 17] = _h_233;
      e.mem[_t_18 + 18] = _h_234;
      e.mem[_t_18 + 19] = _h_235;
      e.mem[_t_18 + 20] = _h_236;
      e.mem[_t_18 + 21] = _h_237;
      e.mem[_t_18 + 22] = _h_238;
      e.mem[_t_18 + 23] = _h_239;
      e.mem[_t_18 + 24] = _h_240;
      e.mem[_t_18 + 25] = _h_241;
      e.mem[_t_18 + 26] = _app_71;
      e.mem[_t_18 + 27] = _app_72;
      e.mem[_t_18 + 28] = _app_73;
      e.mem[_t_18 + 29] = _app_74;
      e.mem[_t_18 + 30] = _app_75;
      e.mem[_t_18 + 31] = _h_242;
      e.mem[_t_18 + 32] = _h_243;
      e.mem[_t_18 + 33] = _h_244;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_OBSERVE_0_K346, _t_18);
      WL_IDX = 34;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_19 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = term_ctr(CID_SCON, STAT_OFF + 432);
      e.mem[_t_19 + 1] = _h_216;
      return term_tsk(FID_STRING_APPEND, _t_19);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 432);
    r1 = _h_216;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_OBSERVE_0_K346)
  {
    WL_POPN(34);
    Term _app_76 = STK(0);
    u32 _h_246 = STK(1);
    u32 _h_247 = STK(2);
    u32 _h_248 = STK(3);
    Term _h_249 = STK(4);
    u32 _h_250 = STK(5);
    Term _h_251 = STK(6);
    Term _h_252 = STK(7);
    Term _h_253 = STK(8);
    u32 _h_254 = STK(9);
    u32 _h_255 = STK(10);
    u32 _h_256 = STK(11);
    u32 _h_257 = STK(12);
    u32 _h_258 = STK(13);
    u32 _h_259 = STK(14);
    u32 _h_260 = STK(15);
    u32 _h_261 = STK(16);
    u32 _h_262 = STK(17);
    u32 _h_263 = STK(18);
    u32 _h_264 = STK(19);
    Term _h_265 = STK(20);
    Term _h_266 = STK(21);
    Term _h_267 = STK(22);
    u32 _h_268 = STK(23);
    u32 _h_269 = STK(24);
    Term _h_270 = STK(25);
    u32 _app_77 = STK(26);
    u32 _app_78 = STK(27);
    Term _app_79 = STK(28);
    Term _app_80 = STK(29);
    u32 _app_81 = STK(30);
    Term _h_271 = STK(31);
    Term _h_272 = STK(32);
    Term _h_273 = STK(33);
    Term _h_245 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(34);
      STK(0) = _app_76;
      STK(1) = _h_246;
      STK(2) = _h_247;
      STK(3) = _h_248;
      STK(4) = _h_249;
      STK(5) = _h_250;
      STK(6) = _h_251;
      STK(7) = _h_252;
      STK(8) = _h_253;
      STK(9) = _h_254;
      STK(10) = _h_255;
      STK(11) = _h_256;
      STK(12) = _h_257;
      STK(13) = _h_258;
      STK(14) = _h_259;
      STK(15) = _h_260;
      STK(16) = _h_261;
      STK(17) = _h_262;
      STK(18) = _h_263;
      STK(19) = _h_264;
      STK(20) = _h_265;
      STK(21) = _h_266;
      STK(22) = _h_267;
      STK(23) = _h_268;
      STK(24) = _h_269;
      STK(25) = _h_270;
      STK(26) = _app_77;
      STK(27) = _app_78;
      STK(28) = _app_79;
      STK(29) = _app_80;
      STK(30) = _app_81;
      STK(31) = _h_271;
      STK(32) = _h_272;
      STK(33) = FID_CONSUMER_EXPANDED_OBSERVE_0_K347;
      WL_PUSHN(34);
    } else {
      u64 _t_20 = task_node(e, FID_CONSUMER_EXPANDED_OBSERVE_0_K347, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _app_76;
      e.mem[_t_20 + 1] = _h_246;
      e.mem[_t_20 + 2] = _h_247;
      e.mem[_t_20 + 3] = _h_248;
      e.mem[_t_20 + 4] = _h_249;
      e.mem[_t_20 + 5] = _h_250;
      e.mem[_t_20 + 6] = _h_251;
      e.mem[_t_20 + 7] = _h_252;
      e.mem[_t_20 + 8] = _h_253;
      e.mem[_t_20 + 9] = _h_254;
      e.mem[_t_20 + 10] = _h_255;
      e.mem[_t_20 + 11] = _h_256;
      e.mem[_t_20 + 12] = _h_257;
      e.mem[_t_20 + 13] = _h_258;
      e.mem[_t_20 + 14] = _h_259;
      e.mem[_t_20 + 15] = _h_260;
      e.mem[_t_20 + 16] = _h_261;
      e.mem[_t_20 + 17] = _h_262;
      e.mem[_t_20 + 18] = _h_263;
      e.mem[_t_20 + 19] = _h_264;
      e.mem[_t_20 + 20] = _h_265;
      e.mem[_t_20 + 21] = _h_266;
      e.mem[_t_20 + 22] = _h_267;
      e.mem[_t_20 + 23] = _h_268;
      e.mem[_t_20 + 24] = _h_269;
      e.mem[_t_20 + 25] = _h_270;
      e.mem[_t_20 + 26] = _app_77;
      e.mem[_t_20 + 27] = _app_78;
      e.mem[_t_20 + 28] = _app_79;
      e.mem[_t_20 + 29] = _app_80;
      e.mem[_t_20 + 30] = _app_81;
      e.mem[_t_20 + 31] = _h_271;
      e.mem[_t_20 + 32] = _h_272;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_OBSERVE_0_K347, _t_20);
      WL_IDX = 33;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_21 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = _h_273;
      e.mem[_t_21 + 1] = _h_245;
      return term_tsk(FID_STRING_APPEND, _t_21);
    }
    r0 = _h_273;
    r1 = _h_245;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_OBSERVE_0_K347)
  {
    WL_POPN(33);
    Term _app_82 = STK(0);
    u32 _h_275 = STK(1);
    u32 _h_276 = STK(2);
    u32 _h_277 = STK(3);
    Term _h_278 = STK(4);
    u32 _h_279 = STK(5);
    Term _h_280 = STK(6);
    Term _h_281 = STK(7);
    Term _h_282 = STK(8);
    u32 _h_283 = STK(9);
    u32 _h_284 = STK(10);
    u32 _h_285 = STK(11);
    u32 _h_286 = STK(12);
    u32 _h_287 = STK(13);
    u32 _h_288 = STK(14);
    u32 _h_289 = STK(15);
    u32 _h_290 = STK(16);
    u32 _h_291 = STK(17);
    u32 _h_292 = STK(18);
    u32 _h_293 = STK(19);
    Term _h_294 = STK(20);
    Term _h_295 = STK(21);
    Term _h_296 = STK(22);
    u32 _h_297 = STK(23);
    u32 _h_298 = STK(24);
    Term _h_299 = STK(25);
    u32 _app_83 = STK(26);
    u32 _app_84 = STK(27);
    Term _app_85 = STK(28);
    Term _app_86 = STK(29);
    u32 _app_87 = STK(30);
    Term _h_300 = STK(31);
    Term _h_301 = STK(32);
    Term _h_274 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(34);
      STK(0) = _app_82;
      STK(1) = _h_275;
      STK(2) = _h_276;
      STK(3) = _h_277;
      STK(4) = _h_278;
      STK(5) = _h_279;
      STK(6) = _h_280;
      STK(7) = _h_281;
      STK(8) = _h_282;
      STK(9) = _h_283;
      STK(10) = _h_284;
      STK(11) = _h_285;
      STK(12) = _h_286;
      STK(13) = _h_287;
      STK(14) = _h_288;
      STK(15) = _h_289;
      STK(16) = _h_290;
      STK(17) = _h_291;
      STK(18) = _h_292;
      STK(19) = _h_293;
      STK(20) = _h_294;
      STK(21) = _h_295;
      STK(22) = _h_296;
      STK(23) = _h_297;
      STK(24) = _h_298;
      STK(25) = _h_299;
      STK(26) = _app_83;
      STK(27) = _app_84;
      STK(28) = _app_85;
      STK(29) = _app_86;
      STK(30) = _app_87;
      STK(31) = _h_300;
      STK(32) = _h_301;
      STK(33) = FID_CONSUMER_EXPANDED_OBSERVE_0_K348;
      WL_PUSHN(34);
    } else {
      u64 _t_22 = task_node(e, FID_CONSUMER_EXPANDED_OBSERVE_0_K348, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _app_82;
      e.mem[_t_22 + 1] = _h_275;
      e.mem[_t_22 + 2] = _h_276;
      e.mem[_t_22 + 3] = _h_277;
      e.mem[_t_22 + 4] = _h_278;
      e.mem[_t_22 + 5] = _h_279;
      e.mem[_t_22 + 6] = _h_280;
      e.mem[_t_22 + 7] = _h_281;
      e.mem[_t_22 + 8] = _h_282;
      e.mem[_t_22 + 9] = _h_283;
      e.mem[_t_22 + 10] = _h_284;
      e.mem[_t_22 + 11] = _h_285;
      e.mem[_t_22 + 12] = _h_286;
      e.mem[_t_22 + 13] = _h_287;
      e.mem[_t_22 + 14] = _h_288;
      e.mem[_t_22 + 15] = _h_289;
      e.mem[_t_22 + 16] = _h_290;
      e.mem[_t_22 + 17] = _h_291;
      e.mem[_t_22 + 18] = _h_292;
      e.mem[_t_22 + 19] = _h_293;
      e.mem[_t_22 + 20] = _h_294;
      e.mem[_t_22 + 21] = _h_295;
      e.mem[_t_22 + 22] = _h_296;
      e.mem[_t_22 + 23] = _h_297;
      e.mem[_t_22 + 24] = _h_298;
      e.mem[_t_22 + 25] = _h_299;
      e.mem[_t_22 + 26] = _app_83;
      e.mem[_t_22 + 27] = _app_84;
      e.mem[_t_22 + 28] = _app_85;
      e.mem[_t_22 + 29] = _app_86;
      e.mem[_t_22 + 30] = _app_87;
      e.mem[_t_22 + 31] = _h_300;
      e.mem[_t_22 + 32] = _h_301;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_OBSERVE_0_K348, _t_22);
      WL_IDX = 33;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_23 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = term_ctr(CID_SCON, STAT_OFF + 76);
      e.mem[_t_23 + 1] = _h_274;
      return term_tsk(FID_STRING_APPEND, _t_23);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 76);
    r1 = _h_274;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_OBSERVE_0_K348)
  {
    WL_POPN(33);
    Term _app_88 = STK(0);
    u32 _h_303 = STK(1);
    u32 _h_304 = STK(2);
    u32 _h_305 = STK(3);
    Term _h_306 = STK(4);
    u32 _h_307 = STK(5);
    Term _h_308 = STK(6);
    Term _h_309 = STK(7);
    Term _h_310 = STK(8);
    u32 _h_311 = STK(9);
    u32 _h_312 = STK(10);
    u32 _h_313 = STK(11);
    u32 _h_314 = STK(12);
    u32 _h_315 = STK(13);
    u32 _h_316 = STK(14);
    u32 _h_317 = STK(15);
    u32 _h_318 = STK(16);
    u32 _h_319 = STK(17);
    u32 _h_320 = STK(18);
    u32 _h_321 = STK(19);
    Term _h_322 = STK(20);
    Term _h_323 = STK(21);
    Term _h_324 = STK(22);
    u32 _h_325 = STK(23);
    u32 _h_326 = STK(24);
    Term _h_327 = STK(25);
    u32 _app_89 = STK(26);
    u32 _app_90 = STK(27);
    Term _app_91 = STK(28);
    Term _app_92 = STK(29);
    u32 _app_93 = STK(30);
    Term _h_328 = STK(31);
    Term _h_329 = STK(32);
    Term _h_302 = r0;
    WL_OPEN
    _app_91 = term_keep(e, _app_91, 1);
    if (seq) {
      WL_ROOM(34);
      STK(0) = _app_88;
      STK(1) = _h_303;
      STK(2) = _h_304;
      STK(3) = _h_305;
      STK(4) = _h_306;
      STK(5) = _h_307;
      STK(6) = _h_308;
      STK(7) = _h_309;
      STK(8) = _h_310;
      STK(9) = _h_311;
      STK(10) = _h_312;
      STK(11) = _h_313;
      STK(12) = _h_314;
      STK(13) = _h_315;
      STK(14) = _h_316;
      STK(15) = _h_317;
      STK(16) = _h_318;
      STK(17) = _h_319;
      STK(18) = _h_320;
      STK(19) = _h_321;
      STK(20) = _h_322;
      STK(21) = _h_323;
      STK(22) = _h_324;
      STK(23) = _h_325;
      STK(24) = _h_326;
      STK(25) = _h_327;
      STK(26) = _app_89;
      STK(27) = _app_90;
      STK(28) = _app_91;
      STK(29) = _app_92;
      STK(30) = _app_93;
      STK(31) = _h_328;
      STK(32) = _h_329;
      STK(33) = FID_CONSUMER_EXPANDED_OBSERVE_0_K349;
      WL_PUSHN(34);
    } else {
      u64 _t_24 = task_node(e, FID_CONSUMER_EXPANDED_OBSERVE_0_K349, WL_CONT, WL_IDX, 1);
      e.mem[_t_24 + 0] = _app_88;
      e.mem[_t_24 + 1] = _h_303;
      e.mem[_t_24 + 2] = _h_304;
      e.mem[_t_24 + 3] = _h_305;
      e.mem[_t_24 + 4] = _h_306;
      e.mem[_t_24 + 5] = _h_307;
      e.mem[_t_24 + 6] = _h_308;
      e.mem[_t_24 + 7] = _h_309;
      e.mem[_t_24 + 8] = _h_310;
      e.mem[_t_24 + 9] = _h_311;
      e.mem[_t_24 + 10] = _h_312;
      e.mem[_t_24 + 11] = _h_313;
      e.mem[_t_24 + 12] = _h_314;
      e.mem[_t_24 + 13] = _h_315;
      e.mem[_t_24 + 14] = _h_316;
      e.mem[_t_24 + 15] = _h_317;
      e.mem[_t_24 + 16] = _h_318;
      e.mem[_t_24 + 17] = _h_319;
      e.mem[_t_24 + 18] = _h_320;
      e.mem[_t_24 + 19] = _h_321;
      e.mem[_t_24 + 20] = _h_322;
      e.mem[_t_24 + 21] = _h_323;
      e.mem[_t_24 + 22] = _h_324;
      e.mem[_t_24 + 23] = _h_325;
      e.mem[_t_24 + 24] = _h_326;
      e.mem[_t_24 + 25] = _h_327;
      e.mem[_t_24 + 26] = _app_89;
      e.mem[_t_24 + 27] = _app_90;
      e.mem[_t_24 + 28] = _app_91;
      e.mem[_t_24 + 29] = _app_92;
      e.mem[_t_24 + 30] = _app_93;
      e.mem[_t_24 + 31] = _h_328;
      e.mem[_t_24 + 32] = _h_329;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_OBSERVE_0_K349, _t_24);
      WL_IDX = 33;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_25 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = _app_91;
      e.mem[_t_25 + 1] = _h_302;
      return term_tsk(FID_STRING_APPEND, _t_25);
    }
    r0 = _app_91;
    r1 = _h_302;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_OBSERVE_0_K349)
  {
    WL_POPN(33);
    Term _app_94 = STK(0);
    u32 _h_331 = STK(1);
    u32 _h_332 = STK(2);
    u32 _h_333 = STK(3);
    Term _h_334 = STK(4);
    u32 _h_335 = STK(5);
    Term _h_336 = STK(6);
    Term _h_337 = STK(7);
    Term _h_338 = STK(8);
    u32 _h_339 = STK(9);
    u32 _h_340 = STK(10);
    u32 _h_341 = STK(11);
    u32 _h_342 = STK(12);
    u32 _h_343 = STK(13);
    u32 _h_344 = STK(14);
    u32 _h_345 = STK(15);
    u32 _h_346 = STK(16);
    u32 _h_347 = STK(17);
    u32 _h_348 = STK(18);
    u32 _h_349 = STK(19);
    Term _h_350 = STK(20);
    Term _h_351 = STK(21);
    Term _h_352 = STK(22);
    u32 _h_353 = STK(23);
    u32 _h_354 = STK(24);
    Term _h_355 = STK(25);
    u32 _app_95 = STK(26);
    u32 _app_96 = STK(27);
    Term _app_97 = STK(28);
    Term _app_98 = STK(29);
    u32 _app_99 = STK(30);
    Term _h_356 = STK(31);
    Term _h_357 = STK(32);
    Term _h_330 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(34);
      STK(0) = _app_94;
      STK(1) = _h_331;
      STK(2) = _h_332;
      STK(3) = _h_333;
      STK(4) = _h_334;
      STK(5) = _h_335;
      STK(6) = _h_336;
      STK(7) = _h_337;
      STK(8) = _h_338;
      STK(9) = _h_339;
      STK(10) = _h_340;
      STK(11) = _h_341;
      STK(12) = _h_342;
      STK(13) = _h_343;
      STK(14) = _h_344;
      STK(15) = _h_345;
      STK(16) = _h_346;
      STK(17) = _h_347;
      STK(18) = _h_348;
      STK(19) = _h_349;
      STK(20) = _h_350;
      STK(21) = _h_351;
      STK(22) = _h_352;
      STK(23) = _h_353;
      STK(24) = _h_354;
      STK(25) = _h_355;
      STK(26) = _app_95;
      STK(27) = _app_96;
      STK(28) = _app_97;
      STK(29) = _app_98;
      STK(30) = _app_99;
      STK(31) = _h_356;
      STK(32) = _h_357;
      STK(33) = FID_CONSUMER_EXPANDED_OBSERVE_0_K350;
      WL_PUSHN(34);
    } else {
      u64 _t_26 = task_node(e, FID_CONSUMER_EXPANDED_OBSERVE_0_K350, WL_CONT, WL_IDX, 1);
      e.mem[_t_26 + 0] = _app_94;
      e.mem[_t_26 + 1] = _h_331;
      e.mem[_t_26 + 2] = _h_332;
      e.mem[_t_26 + 3] = _h_333;
      e.mem[_t_26 + 4] = _h_334;
      e.mem[_t_26 + 5] = _h_335;
      e.mem[_t_26 + 6] = _h_336;
      e.mem[_t_26 + 7] = _h_337;
      e.mem[_t_26 + 8] = _h_338;
      e.mem[_t_26 + 9] = _h_339;
      e.mem[_t_26 + 10] = _h_340;
      e.mem[_t_26 + 11] = _h_341;
      e.mem[_t_26 + 12] = _h_342;
      e.mem[_t_26 + 13] = _h_343;
      e.mem[_t_26 + 14] = _h_344;
      e.mem[_t_26 + 15] = _h_345;
      e.mem[_t_26 + 16] = _h_346;
      e.mem[_t_26 + 17] = _h_347;
      e.mem[_t_26 + 18] = _h_348;
      e.mem[_t_26 + 19] = _h_349;
      e.mem[_t_26 + 20] = _h_350;
      e.mem[_t_26 + 21] = _h_351;
      e.mem[_t_26 + 22] = _h_352;
      e.mem[_t_26 + 23] = _h_353;
      e.mem[_t_26 + 24] = _h_354;
      e.mem[_t_26 + 25] = _h_355;
      e.mem[_t_26 + 26] = _app_95;
      e.mem[_t_26 + 27] = _app_96;
      e.mem[_t_26 + 28] = _app_97;
      e.mem[_t_26 + 29] = _app_98;
      e.mem[_t_26 + 30] = _app_99;
      e.mem[_t_26 + 31] = _h_356;
      e.mem[_t_26 + 32] = _h_357;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_OBSERVE_0_K350, _t_26);
      WL_IDX = 33;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_27 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_27 + 0] = term_ctr(CID_SCON, STAT_OFF + 76);
      e.mem[_t_27 + 1] = _h_330;
      return term_tsk(FID_STRING_APPEND, _t_27);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 76);
    r1 = _h_330;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_OBSERVE_0_K350)
  {
    WL_POPN(33);
    Term _app_100 = STK(0);
    u32 _h_359 = STK(1);
    u32 _h_360 = STK(2);
    u32 _h_361 = STK(3);
    Term _h_362 = STK(4);
    u32 _h_363 = STK(5);
    Term _h_364 = STK(6);
    Term _h_365 = STK(7);
    Term _h_366 = STK(8);
    u32 _h_367 = STK(9);
    u32 _h_368 = STK(10);
    u32 _h_369 = STK(11);
    u32 _h_370 = STK(12);
    u32 _h_371 = STK(13);
    u32 _h_372 = STK(14);
    u32 _h_373 = STK(15);
    u32 _h_374 = STK(16);
    u32 _h_375 = STK(17);
    u32 _h_376 = STK(18);
    u32 _h_377 = STK(19);
    Term _h_378 = STK(20);
    Term _h_379 = STK(21);
    Term _h_380 = STK(22);
    u32 _h_381 = STK(23);
    u32 _h_382 = STK(24);
    Term _h_383 = STK(25);
    u32 _app_101 = STK(26);
    u32 _app_102 = STK(27);
    Term _app_103 = STK(28);
    Term _app_104 = STK(29);
    u32 _app_105 = STK(30);
    Term _h_384 = STK(31);
    Term _h_385 = STK(32);
    Term _h_358 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(33);
      STK(0) = _app_100;
      STK(1) = _h_359;
      STK(2) = _h_360;
      STK(3) = _h_361;
      STK(4) = _h_362;
      STK(5) = _h_363;
      STK(6) = _h_364;
      STK(7) = _h_365;
      STK(8) = _h_366;
      STK(9) = _h_367;
      STK(10) = _h_368;
      STK(11) = _h_369;
      STK(12) = _h_370;
      STK(13) = _h_371;
      STK(14) = _h_372;
      STK(15) = _h_373;
      STK(16) = _h_374;
      STK(17) = _h_375;
      STK(18) = _h_376;
      STK(19) = _h_377;
      STK(20) = _h_378;
      STK(21) = _h_379;
      STK(22) = _h_380;
      STK(23) = _h_381;
      STK(24) = _h_382;
      STK(25) = _h_383;
      STK(26) = _app_101;
      STK(27) = _app_102;
      STK(28) = _app_103;
      STK(29) = _app_104;
      STK(30) = _app_105;
      STK(31) = _h_384;
      STK(32) = FID_CONSUMER_EXPANDED_OBSERVE_0_K351;
      WL_PUSHN(33);
    } else {
      u64 _t_28 = task_node(e, FID_CONSUMER_EXPANDED_OBSERVE_0_K351, WL_CONT, WL_IDX, 1);
      e.mem[_t_28 + 0] = _app_100;
      e.mem[_t_28 + 1] = _h_359;
      e.mem[_t_28 + 2] = _h_360;
      e.mem[_t_28 + 3] = _h_361;
      e.mem[_t_28 + 4] = _h_362;
      e.mem[_t_28 + 5] = _h_363;
      e.mem[_t_28 + 6] = _h_364;
      e.mem[_t_28 + 7] = _h_365;
      e.mem[_t_28 + 8] = _h_366;
      e.mem[_t_28 + 9] = _h_367;
      e.mem[_t_28 + 10] = _h_368;
      e.mem[_t_28 + 11] = _h_369;
      e.mem[_t_28 + 12] = _h_370;
      e.mem[_t_28 + 13] = _h_371;
      e.mem[_t_28 + 14] = _h_372;
      e.mem[_t_28 + 15] = _h_373;
      e.mem[_t_28 + 16] = _h_374;
      e.mem[_t_28 + 17] = _h_375;
      e.mem[_t_28 + 18] = _h_376;
      e.mem[_t_28 + 19] = _h_377;
      e.mem[_t_28 + 20] = _h_378;
      e.mem[_t_28 + 21] = _h_379;
      e.mem[_t_28 + 22] = _h_380;
      e.mem[_t_28 + 23] = _h_381;
      e.mem[_t_28 + 24] = _h_382;
      e.mem[_t_28 + 25] = _h_383;
      e.mem[_t_28 + 26] = _app_101;
      e.mem[_t_28 + 27] = _app_102;
      e.mem[_t_28 + 28] = _app_103;
      e.mem[_t_28 + 29] = _app_104;
      e.mem[_t_28 + 30] = _app_105;
      e.mem[_t_28 + 31] = _h_384;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_OBSERVE_0_K351, _t_28);
      WL_IDX = 32;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_29 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_29 + 0] = _h_385;
      e.mem[_t_29 + 1] = _h_358;
      return term_tsk(FID_STRING_APPEND, _t_29);
    }
    r0 = _h_385;
    r1 = _h_358;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_OBSERVE_0_K351)
  {
    WL_POPN(32);
    Term _app_106 = STK(0);
    u32 _h_387 = STK(1);
    u32 _h_388 = STK(2);
    u32 _h_389 = STK(3);
    Term _h_390 = STK(4);
    u32 _h_391 = STK(5);
    Term _h_392 = STK(6);
    Term _h_393 = STK(7);
    Term _h_394 = STK(8);
    u32 _h_395 = STK(9);
    u32 _h_396 = STK(10);
    u32 _h_397 = STK(11);
    u32 _h_398 = STK(12);
    u32 _h_399 = STK(13);
    u32 _h_400 = STK(14);
    u32 _h_401 = STK(15);
    u32 _h_402 = STK(16);
    u32 _h_403 = STK(17);
    u32 _h_404 = STK(18);
    u32 _h_405 = STK(19);
    Term _h_406 = STK(20);
    Term _h_407 = STK(21);
    Term _h_408 = STK(22);
    u32 _h_409 = STK(23);
    u32 _h_410 = STK(24);
    Term _h_411 = STK(25);
    u32 _app_107 = STK(26);
    u32 _app_108 = STK(27);
    Term _app_109 = STK(28);
    Term _app_110 = STK(29);
    u32 _app_111 = STK(30);
    Term _h_412 = STK(31);
    Term _h_386 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(33);
      STK(0) = _app_106;
      STK(1) = _h_387;
      STK(2) = _h_388;
      STK(3) = _h_389;
      STK(4) = _h_390;
      STK(5) = _h_391;
      STK(6) = _h_392;
      STK(7) = _h_393;
      STK(8) = _h_394;
      STK(9) = _h_395;
      STK(10) = _h_396;
      STK(11) = _h_397;
      STK(12) = _h_398;
      STK(13) = _h_399;
      STK(14) = _h_400;
      STK(15) = _h_401;
      STK(16) = _h_402;
      STK(17) = _h_403;
      STK(18) = _h_404;
      STK(19) = _h_405;
      STK(20) = _h_406;
      STK(21) = _h_407;
      STK(22) = _h_408;
      STK(23) = _h_409;
      STK(24) = _h_410;
      STK(25) = _h_411;
      STK(26) = _app_107;
      STK(27) = _app_108;
      STK(28) = _app_109;
      STK(29) = _app_110;
      STK(30) = _app_111;
      STK(31) = _h_412;
      STK(32) = FID_CONSUMER_EXPANDED_OBSERVE_0_K352;
      WL_PUSHN(33);
    } else {
      u64 _t_30 = task_node(e, FID_CONSUMER_EXPANDED_OBSERVE_0_K352, WL_CONT, WL_IDX, 1);
      e.mem[_t_30 + 0] = _app_106;
      e.mem[_t_30 + 1] = _h_387;
      e.mem[_t_30 + 2] = _h_388;
      e.mem[_t_30 + 3] = _h_389;
      e.mem[_t_30 + 4] = _h_390;
      e.mem[_t_30 + 5] = _h_391;
      e.mem[_t_30 + 6] = _h_392;
      e.mem[_t_30 + 7] = _h_393;
      e.mem[_t_30 + 8] = _h_394;
      e.mem[_t_30 + 9] = _h_395;
      e.mem[_t_30 + 10] = _h_396;
      e.mem[_t_30 + 11] = _h_397;
      e.mem[_t_30 + 12] = _h_398;
      e.mem[_t_30 + 13] = _h_399;
      e.mem[_t_30 + 14] = _h_400;
      e.mem[_t_30 + 15] = _h_401;
      e.mem[_t_30 + 16] = _h_402;
      e.mem[_t_30 + 17] = _h_403;
      e.mem[_t_30 + 18] = _h_404;
      e.mem[_t_30 + 19] = _h_405;
      e.mem[_t_30 + 20] = _h_406;
      e.mem[_t_30 + 21] = _h_407;
      e.mem[_t_30 + 22] = _h_408;
      e.mem[_t_30 + 23] = _h_409;
      e.mem[_t_30 + 24] = _h_410;
      e.mem[_t_30 + 25] = _h_411;
      e.mem[_t_30 + 26] = _app_107;
      e.mem[_t_30 + 27] = _app_108;
      e.mem[_t_30 + 28] = _app_109;
      e.mem[_t_30 + 29] = _app_110;
      e.mem[_t_30 + 30] = _app_111;
      e.mem[_t_30 + 31] = _h_412;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_OBSERVE_0_K352, _t_30);
      WL_IDX = 32;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_31 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_31 + 0] = term_ctr(CID_SCON, STAT_OFF + 76);
      e.mem[_t_31 + 1] = _h_386;
      return term_tsk(FID_STRING_APPEND, _t_31);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 76);
    r1 = _h_386;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_OBSERVE_0_K352)
  {
    WL_POPN(32);
    Term _app_112 = STK(0);
    u32 _h_414 = STK(1);
    u32 _h_415 = STK(2);
    u32 _h_416 = STK(3);
    Term _h_417 = STK(4);
    u32 _h_418 = STK(5);
    Term _h_419 = STK(6);
    Term _h_420 = STK(7);
    Term _h_421 = STK(8);
    u32 _h_422 = STK(9);
    u32 _h_423 = STK(10);
    u32 _h_424 = STK(11);
    u32 _h_425 = STK(12);
    u32 _h_426 = STK(13);
    u32 _h_427 = STK(14);
    u32 _h_428 = STK(15);
    u32 _h_429 = STK(16);
    u32 _h_430 = STK(17);
    u32 _h_431 = STK(18);
    u32 _h_432 = STK(19);
    Term _h_433 = STK(20);
    Term _h_434 = STK(21);
    Term _h_435 = STK(22);
    u32 _h_436 = STK(23);
    u32 _h_437 = STK(24);
    Term _h_438 = STK(25);
    u32 _app_113 = STK(26);
    u32 _app_114 = STK(27);
    Term _app_115 = STK(28);
    Term _app_116 = STK(29);
    u32 _app_117 = STK(30);
    Term _h_439 = STK(31);
    Term _h_413 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(32);
      STK(0) = _app_112;
      STK(1) = _h_414;
      STK(2) = _h_415;
      STK(3) = _h_416;
      STK(4) = _h_417;
      STK(5) = _h_418;
      STK(6) = _h_419;
      STK(7) = _h_420;
      STK(8) = _h_421;
      STK(9) = _h_422;
      STK(10) = _h_423;
      STK(11) = _h_424;
      STK(12) = _h_425;
      STK(13) = _h_426;
      STK(14) = _h_427;
      STK(15) = _h_428;
      STK(16) = _h_429;
      STK(17) = _h_430;
      STK(18) = _h_431;
      STK(19) = _h_432;
      STK(20) = _h_433;
      STK(21) = _h_434;
      STK(22) = _h_435;
      STK(23) = _h_436;
      STK(24) = _h_437;
      STK(25) = _h_438;
      STK(26) = _app_113;
      STK(27) = _app_114;
      STK(28) = _app_115;
      STK(29) = _app_116;
      STK(30) = _app_117;
      STK(31) = FID_CONSUMER_EXPANDED_OBSERVE_0_K353;
      WL_PUSHN(32);
    } else {
      u64 _t_32 = task_node(e, FID_CONSUMER_EXPANDED_OBSERVE_0_K353, WL_CONT, WL_IDX, 1);
      e.mem[_t_32 + 0] = _app_112;
      e.mem[_t_32 + 1] = _h_414;
      e.mem[_t_32 + 2] = _h_415;
      e.mem[_t_32 + 3] = _h_416;
      e.mem[_t_32 + 4] = _h_417;
      e.mem[_t_32 + 5] = _h_418;
      e.mem[_t_32 + 6] = _h_419;
      e.mem[_t_32 + 7] = _h_420;
      e.mem[_t_32 + 8] = _h_421;
      e.mem[_t_32 + 9] = _h_422;
      e.mem[_t_32 + 10] = _h_423;
      e.mem[_t_32 + 11] = _h_424;
      e.mem[_t_32 + 12] = _h_425;
      e.mem[_t_32 + 13] = _h_426;
      e.mem[_t_32 + 14] = _h_427;
      e.mem[_t_32 + 15] = _h_428;
      e.mem[_t_32 + 16] = _h_429;
      e.mem[_t_32 + 17] = _h_430;
      e.mem[_t_32 + 18] = _h_431;
      e.mem[_t_32 + 19] = _h_432;
      e.mem[_t_32 + 20] = _h_433;
      e.mem[_t_32 + 21] = _h_434;
      e.mem[_t_32 + 22] = _h_435;
      e.mem[_t_32 + 23] = _h_436;
      e.mem[_t_32 + 24] = _h_437;
      e.mem[_t_32 + 25] = _h_438;
      e.mem[_t_32 + 26] = _app_113;
      e.mem[_t_32 + 27] = _app_114;
      e.mem[_t_32 + 28] = _app_115;
      e.mem[_t_32 + 29] = _app_116;
      e.mem[_t_32 + 30] = _app_117;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_OBSERVE_0_K353, _t_32);
      WL_IDX = 31;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_33 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_33 + 0] = _h_439;
      e.mem[_t_33 + 1] = _h_413;
      return term_tsk(FID_STRING_APPEND, _t_33);
    }
    r0 = _h_439;
    r1 = _h_413;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_OBSERVE_0_K353)
  {
    WL_POPN(31);
    Term _app_118 = STK(0);
    u32 _h_441 = STK(1);
    u32 _h_442 = STK(2);
    u32 _h_443 = STK(3);
    Term _h_444 = STK(4);
    u32 _h_445 = STK(5);
    Term _h_446 = STK(6);
    Term _h_447 = STK(7);
    Term _h_448 = STK(8);
    u32 _h_449 = STK(9);
    u32 _h_450 = STK(10);
    u32 _h_451 = STK(11);
    u32 _h_452 = STK(12);
    u32 _h_453 = STK(13);
    u32 _h_454 = STK(14);
    u32 _h_455 = STK(15);
    u32 _h_456 = STK(16);
    u32 _h_457 = STK(17);
    u32 _h_458 = STK(18);
    u32 _h_459 = STK(19);
    Term _h_460 = STK(20);
    Term _h_461 = STK(21);
    Term _h_462 = STK(22);
    u32 _h_463 = STK(23);
    u32 _h_464 = STK(24);
    Term _h_465 = STK(25);
    u32 _app_119 = STK(26);
    u32 _app_120 = STK(27);
    Term _app_121 = STK(28);
    Term _app_122 = STK(29);
    u32 _app_123 = STK(30);
    Term _h_440 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(32);
      STK(0) = _app_118;
      STK(1) = _h_441;
      STK(2) = _h_442;
      STK(3) = _h_443;
      STK(4) = _h_444;
      STK(5) = _h_445;
      STK(6) = _h_446;
      STK(7) = _h_447;
      STK(8) = _h_448;
      STK(9) = _h_449;
      STK(10) = _h_450;
      STK(11) = _h_451;
      STK(12) = _h_452;
      STK(13) = _h_453;
      STK(14) = _h_454;
      STK(15) = _h_455;
      STK(16) = _h_456;
      STK(17) = _h_457;
      STK(18) = _h_458;
      STK(19) = _h_459;
      STK(20) = _h_460;
      STK(21) = _h_461;
      STK(22) = _h_462;
      STK(23) = _h_463;
      STK(24) = _h_464;
      STK(25) = _h_465;
      STK(26) = _app_119;
      STK(27) = _app_120;
      STK(28) = _app_121;
      STK(29) = _app_122;
      STK(30) = _app_123;
      STK(31) = FID_CONSUMER_EXPANDED_OBSERVE_0_K354;
      WL_PUSHN(32);
    } else {
      u64 _t_34 = task_node(e, FID_CONSUMER_EXPANDED_OBSERVE_0_K354, WL_CONT, WL_IDX, 1);
      e.mem[_t_34 + 0] = _app_118;
      e.mem[_t_34 + 1] = _h_441;
      e.mem[_t_34 + 2] = _h_442;
      e.mem[_t_34 + 3] = _h_443;
      e.mem[_t_34 + 4] = _h_444;
      e.mem[_t_34 + 5] = _h_445;
      e.mem[_t_34 + 6] = _h_446;
      e.mem[_t_34 + 7] = _h_447;
      e.mem[_t_34 + 8] = _h_448;
      e.mem[_t_34 + 9] = _h_449;
      e.mem[_t_34 + 10] = _h_450;
      e.mem[_t_34 + 11] = _h_451;
      e.mem[_t_34 + 12] = _h_452;
      e.mem[_t_34 + 13] = _h_453;
      e.mem[_t_34 + 14] = _h_454;
      e.mem[_t_34 + 15] = _h_455;
      e.mem[_t_34 + 16] = _h_456;
      e.mem[_t_34 + 17] = _h_457;
      e.mem[_t_34 + 18] = _h_458;
      e.mem[_t_34 + 19] = _h_459;
      e.mem[_t_34 + 20] = _h_460;
      e.mem[_t_34 + 21] = _h_461;
      e.mem[_t_34 + 22] = _h_462;
      e.mem[_t_34 + 23] = _h_463;
      e.mem[_t_34 + 24] = _h_464;
      e.mem[_t_34 + 25] = _h_465;
      e.mem[_t_34 + 26] = _app_119;
      e.mem[_t_34 + 27] = _app_120;
      e.mem[_t_34 + 28] = _app_121;
      e.mem[_t_34 + 29] = _app_122;
      e.mem[_t_34 + 30] = _app_123;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_OBSERVE_0_K354, _t_34);
      WL_IDX = 31;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_35 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_35 + 0] = term_ctr(CID_SCON, STAT_OFF + 448);
      e.mem[_t_35 + 1] = _h_440;
      return term_tsk(FID_STRING_APPEND, _t_35);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 448);
    r1 = _h_440;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_OBSERVE_0_K354)
  {
    WL_POPN(31);
    Term _app_124 = STK(0);
    u32 _h_467 = STK(1);
    u32 _h_468 = STK(2);
    u32 _h_469 = STK(3);
    Term _h_470 = STK(4);
    u32 _h_471 = STK(5);
    Term _h_472 = STK(6);
    Term _h_473 = STK(7);
    Term _h_474 = STK(8);
    u32 _h_475 = STK(9);
    u32 _h_476 = STK(10);
    u32 _h_477 = STK(11);
    u32 _h_478 = STK(12);
    u32 _h_479 = STK(13);
    u32 _h_480 = STK(14);
    u32 _h_481 = STK(15);
    u32 _h_482 = STK(16);
    u32 _h_483 = STK(17);
    u32 _h_484 = STK(18);
    u32 _h_485 = STK(19);
    Term _h_486 = STK(20);
    Term _h_487 = STK(21);
    Term _h_488 = STK(22);
    u32 _h_489 = STK(23);
    u32 _h_490 = STK(24);
    Term _h_491 = STK(25);
    u32 _app_125 = STK(26);
    u32 _app_126 = STK(27);
    Term _app_127 = STK(28);
    Term _app_128 = STK(29);
    u32 _app_129 = STK(30);
    Term _h_466 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(31);
      STK(0) = _app_124;
      STK(1) = _h_467;
      STK(2) = _h_468;
      STK(3) = _h_469;
      STK(4) = _h_470;
      STK(5) = _h_471;
      STK(6) = _h_472;
      STK(7) = _h_473;
      STK(8) = _h_474;
      STK(9) = _h_475;
      STK(10) = _h_476;
      STK(11) = _h_477;
      STK(12) = _h_478;
      STK(13) = _h_479;
      STK(14) = _h_480;
      STK(15) = _h_481;
      STK(16) = _h_482;
      STK(17) = _h_483;
      STK(18) = _h_484;
      STK(19) = _h_485;
      STK(20) = _h_486;
      STK(21) = _h_487;
      STK(22) = _h_488;
      STK(23) = _h_489;
      STK(24) = _h_490;
      STK(25) = _app_125;
      STK(26) = _app_126;
      STK(27) = _app_127;
      STK(28) = _app_128;
      STK(29) = _app_129;
      STK(30) = FID_CONSUMER_EXPANDED_OBSERVE_0_K355;
      WL_PUSHN(31);
    } else {
      u64 _t_36 = task_node(e, FID_CONSUMER_EXPANDED_OBSERVE_0_K355, WL_CONT, WL_IDX, 1);
      e.mem[_t_36 + 0] = _app_124;
      e.mem[_t_36 + 1] = _h_467;
      e.mem[_t_36 + 2] = _h_468;
      e.mem[_t_36 + 3] = _h_469;
      e.mem[_t_36 + 4] = _h_470;
      e.mem[_t_36 + 5] = _h_471;
      e.mem[_t_36 + 6] = _h_472;
      e.mem[_t_36 + 7] = _h_473;
      e.mem[_t_36 + 8] = _h_474;
      e.mem[_t_36 + 9] = _h_475;
      e.mem[_t_36 + 10] = _h_476;
      e.mem[_t_36 + 11] = _h_477;
      e.mem[_t_36 + 12] = _h_478;
      e.mem[_t_36 + 13] = _h_479;
      e.mem[_t_36 + 14] = _h_480;
      e.mem[_t_36 + 15] = _h_481;
      e.mem[_t_36 + 16] = _h_482;
      e.mem[_t_36 + 17] = _h_483;
      e.mem[_t_36 + 18] = _h_484;
      e.mem[_t_36 + 19] = _h_485;
      e.mem[_t_36 + 20] = _h_486;
      e.mem[_t_36 + 21] = _h_487;
      e.mem[_t_36 + 22] = _h_488;
      e.mem[_t_36 + 23] = _h_489;
      e.mem[_t_36 + 24] = _h_490;
      e.mem[_t_36 + 25] = _app_125;
      e.mem[_t_36 + 26] = _app_126;
      e.mem[_t_36 + 27] = _app_127;
      e.mem[_t_36 + 28] = _app_128;
      e.mem[_t_36 + 29] = _app_129;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_OBSERVE_0_K355, _t_36);
      WL_IDX = 30;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_37 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_37 + 0] = _h_491;
      e.mem[_t_37 + 1] = _h_466;
      return term_tsk(FID_STRING_APPEND, _t_37);
    }
    r0 = _h_491;
    r1 = _h_466;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_OBSERVE_0_K355)
  {
    WL_POPN(30);
    Term _app_130 = STK(0);
    u32 _h_493 = STK(1);
    u32 _h_494 = STK(2);
    u32 _h_495 = STK(3);
    Term _h_496 = STK(4);
    u32 _h_497 = STK(5);
    Term _h_498 = STK(6);
    Term _h_499 = STK(7);
    Term _h_500 = STK(8);
    u32 _h_501 = STK(9);
    u32 _h_502 = STK(10);
    u32 _h_503 = STK(11);
    u32 _h_504 = STK(12);
    u32 _h_505 = STK(13);
    u32 _h_506 = STK(14);
    u32 _h_507 = STK(15);
    u32 _h_508 = STK(16);
    u32 _h_509 = STK(17);
    u32 _h_510 = STK(18);
    u32 _h_511 = STK(19);
    Term _h_512 = STK(20);
    Term _h_513 = STK(21);
    Term _h_514 = STK(22);
    u32 _h_515 = STK(23);
    u32 _h_516 = STK(24);
    u32 _app_131 = STK(25);
    u32 _app_132 = STK(26);
    Term _app_133 = STK(27);
    Term _app_134 = STK(28);
    u32 _app_135 = STK(29);
    Term _h_492 = r0;
    WL_OPEN
    r0 = _h_493;
    r1 = _h_494;
    r2 = _h_495;
    r3 = _h_496;
    r4 = _h_497;
    r5 = _h_498;
    r6 = _h_499;
    r7 = _h_500;
    r8 = _h_501;
    r9 = _h_502;
    r10 = _h_503;
    r11 = _h_504;
    r12 = _h_505;
    r13 = _h_506;
    r14 = _h_507;
    r15 = _h_508;
    r16 = _h_509;
    r17 = _h_510;
    r18 = _h_511;
    r19 = _h_512;
    r20 = _h_513;
    r21 = _h_514;
    r22 = _h_515;
    r23 = _h_516;
    r24 = 1;
    r25 = _app_131;
    r26 = _app_132;
    r27 = _app_133;
    r28 = _app_134;
    r29 = _app_135;
    r30 = _app_130;
    r31 = _h_492;
    WL_RETN(32);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_ACTION_0)
  {
    u32 _app_0 = r0;
    u32 _app_1 = r1;
    u32 _app_2 = r2;
    Term _app_3 = r3;
    u32 _app_4 = r4;
    Term _app_5 = r5;
    Term _app_6 = r6;
    Term _app_7 = r7;
    u32 _app_8 = r8;
    u32 _app_9 = r9;
    u32 _app_10 = r10;
    u32 _app_11 = r11;
    u32 _app_12 = r12;
    u32 _app_13 = r13;
    u32 _app_14 = r14;
    u32 _app_15 = r15;
    u32 _app_16 = r16;
    u32 _app_17 = r17;
    u32 _app_18 = r18;
    Term _app_19 = r19;
    Term _app_20 = r20;
    Term _app_21 = r21;
    u32 _app_22 = r22;
    u32 _app_23 = r23;
    u32 _app_24 = r24;
    u32 _app_25 = r25;
    u32 _app_26 = r26;
    Term _app_27 = r27;
    Term _app_28 = r28;
    u32 _app_29 = r29;
    Term _app_30 = r30;
    u32 _request_0 = r31;
    u32 _request_1 = r32;
    u32 _request_2 = r33;
    u32 _request_3 = r34;
    u32 _request_4 = r35;
    u32 _request_5 = r36;
    WL_OPEN
    if (_request_0 == 0) {
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      u32 _v_2 = 0;
      Term _v_3 = 0;
      u32 _v_4 = 0;
      Term _v_5 = 0;
      Term _v_6 = 0;
      Term _v_7 = 0;
      u32 _v_8 = 0;
      u32 _v_9 = 0;
      u32 _v_10 = 0;
      u32 _v_11 = 0;
      u32 _v_12 = 0;
      u32 _v_13 = 0;
      u32 _v_14 = 0;
      u32 _v_15 = 0;
      u32 _v_16 = 0;
      u32 _v_17 = 0;
      u32 _v_18 = 0;
      Term _v_19 = 0;
      Term _v_20 = 0;
      Term _v_21 = 0;
      u32 _v_22 = 0;
      u32 _v_23 = 0;
      u32 _v_24 = 0;
      u32 _v_25 = 0;
      u32 _v_26 = 0;
      Term _v_27 = 0;
      Term _v_28 = 0;
      u32 _v_29 = 0;
      Term _v_30 = 0;
      Term _o_1[31];
      if (spin_56(e, _o_1, _app_0, _app_1, _app_2, _app_3, blk_loc(e.mem, _app_3), _app_4, _app_5, _app_6, blk_loc(e.mem, _app_6), _app_7, blk_loc(e.mem, _app_7), _app_8, _app_9, _app_10, _app_11, _app_12, _app_13, _app_14, _app_15, _app_16, _app_17, _app_18, _app_19, blk_loc(e.mem, _app_19), _app_20, blk_loc(e.mem, _app_20), _app_21, blk_loc(e.mem, _app_21), _app_22, _app_23, _app_24, _app_25, _app_26, _app_27, blk_loc(e.mem, _app_27), _app_28, blk_loc(e.mem, _app_28), _app_29, _app_30, blk_loc(e.mem, _app_30)) == 0) {
        return 0;
      }
      _v_0 = _o_1[0];
      _v_1 = _o_1[1];
      _v_2 = _o_1[2];
      _v_3 = _o_1[3];
      _v_4 = _o_1[4];
      _v_5 = _o_1[5];
      _v_6 = _o_1[6];
      _v_7 = _o_1[7];
      _v_8 = _o_1[8];
      _v_9 = _o_1[9];
      _v_10 = _o_1[10];
      _v_11 = _o_1[11];
      _v_12 = _o_1[12];
      _v_13 = _o_1[13];
      _v_14 = _o_1[14];
      _v_15 = _o_1[15];
      _v_16 = _o_1[16];
      _v_17 = _o_1[17];
      _v_18 = _o_1[18];
      _v_19 = _o_1[19];
      _v_20 = _o_1[20];
      _v_21 = _o_1[21];
      _v_22 = _o_1[22];
      _v_23 = _o_1[23];
      _v_24 = _o_1[24];
      _v_25 = _o_1[25];
      _v_26 = _o_1[26];
      _v_27 = _o_1[27];
      _v_28 = _o_1[28];
      _v_29 = _o_1[29];
      _v_30 = _o_1[30];
      r0 = _v_0;
      r1 = _v_1;
      r2 = _v_2;
      r3 = _v_3;
      r4 = _v_4;
      r5 = _v_5;
      r6 = _v_6;
      r7 = _v_7;
      r8 = _v_8;
      r9 = _v_9;
      r10 = _v_10;
      r11 = _v_11;
      r12 = _v_12;
      r13 = _v_13;
      r14 = _v_14;
      r15 = _v_15;
      r16 = _v_16;
      r17 = _v_17;
      r18 = _v_18;
      r19 = _v_19;
      r20 = _v_20;
      r21 = _v_21;
      r22 = _v_22;
      r23 = _v_23;
      r24 = _v_24;
      r25 = _v_25;
      r26 = _v_26;
      r27 = _v_27;
      r28 = _v_28;
      r29 = _v_29;
      r30 = _v_30;
      WL_RETN(31);
    } else {
      if (_app_24 == 0) {
        r0 = _app_0;
        r1 = _app_1;
        r2 = _app_2;
        r3 = _app_3;
        r4 = _app_4;
        r5 = _app_5;
        r6 = _app_6;
        r7 = _app_7;
        r8 = _app_8;
        r9 = _app_9;
        r10 = _app_10;
        r11 = _app_11;
        r12 = _app_12;
        r13 = _app_13;
        r14 = _app_14;
        r15 = _app_15;
        r16 = _app_16;
        r17 = _app_17;
        r18 = _app_18;
        r19 = _app_19;
        r20 = _app_20;
        r21 = _app_21;
        r22 = _app_22;
        r23 = _app_23;
        r24 = 0;
        r25 = 0;
        r26 = 0;
        r27 = 0;
        r28 = 0;
        r29 = 0;
        r30 = _app_30;
        WL_RETN(31);
      } else {
        term_sink(e, _app_30);
        if (seq) {
          WL_ROOM(1);
          STK(0) = FID_CONSUMER_EXPANDED_ACTION_0_K362;
          WL_PUSHN(1);
        } else {
          u64 _t_0 = task_node(e, FID_CONSUMER_EXPANDED_ACTION_0_K362, WL_CONT, WL_IDX, 1);
          WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_ACTION_0_K362, _t_0);
          WL_IDX = 0;
        }
        if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_SYSTEM_RUN_TRACKED_0)) {
          u64 _t_1 = task_node(e, FID________________BENDVY_SRC_ECS_SYSTEM_RUN_TRACKED_0, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _app_25;
          e.mem[_t_1 + 1] = _app_26;
          e.mem[_t_1 + 2] = _app_27;
          e.mem[_t_1 + 3] = _app_28;
          e.mem[_t_1 + 4] = _app_29;
          e.mem[_t_1 + 5] = _app_0;
          e.mem[_t_1 + 6] = _app_1;
          e.mem[_t_1 + 7] = _app_2;
          e.mem[_t_1 + 8] = _app_3;
          e.mem[_t_1 + 9] = _app_4;
          e.mem[_t_1 + 10] = _app_5;
          e.mem[_t_1 + 11] = _app_6;
          e.mem[_t_1 + 12] = _app_7;
          e.mem[_t_1 + 13] = _app_8;
          e.mem[_t_1 + 14] = _app_9;
          e.mem[_t_1 + 15] = _app_10;
          e.mem[_t_1 + 16] = _app_11;
          e.mem[_t_1 + 17] = _app_12;
          e.mem[_t_1 + 18] = _app_13;
          e.mem[_t_1 + 19] = _app_14;
          e.mem[_t_1 + 20] = _app_15;
          e.mem[_t_1 + 21] = _app_16;
          e.mem[_t_1 + 22] = _app_17;
          e.mem[_t_1 + 23] = _app_18;
          e.mem[_t_1 + 24] = _app_19;
          e.mem[_t_1 + 25] = _app_20;
          e.mem[_t_1 + 26] = _app_21;
          e.mem[_t_1 + 27] = _app_22;
          e.mem[_t_1 + 28] = _app_23;
          e.mem[_t_1 + 29] = _request_1;
          e.mem[_t_1 + 30] = _request_2;
          e.mem[_t_1 + 31] = _request_3;
          e.mem[_t_1 + 32] = _request_4;
          e.mem[_t_1 + 33] = _request_5;
          return term_tsk(FID________________BENDVY_SRC_ECS_SYSTEM_RUN_TRACKED_0, _t_1);
        }
        r0 = _app_25;
        r1 = _app_26;
        r2 = _app_27;
        r3 = _app_28;
        r4 = _app_29;
        r5 = _app_0;
        r6 = _app_1;
        r7 = _app_2;
        r8 = _app_3;
        r9 = _app_4;
        r10 = _app_5;
        r11 = _app_6;
        r12 = _app_7;
        r13 = _app_8;
        r14 = _app_9;
        r15 = _app_10;
        r16 = _app_11;
        r17 = _app_12;
        r18 = _app_13;
        r19 = _app_14;
        r20 = _app_15;
        r21 = _app_16;
        r22 = _app_17;
        r23 = _app_18;
        r24 = _app_19;
        r25 = _app_20;
        r26 = _app_21;
        r27 = _app_22;
        r28 = _app_23;
        r29 = _request_1;
        r30 = _request_2;
        r31 = _request_3;
        r32 = _request_4;
        r33 = _request_5;
        WL_JMP(FID________________BENDVY_SRC_ECS_SYSTEM_RUN_TRACKED_0);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_ACTION_0_K362)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    u32 _h_5 = r5;
    u32 _h_6 = r6;
    u32 _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    Term _h_10 = r10;
    Term _h_11 = r11;
    Term _h_12 = r12;
    Term _h_13 = r13;
    Term _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    u32 _h_19 = r19;
    u32 _h_20 = r20;
    u32 _h_21 = r21;
    u32 _h_22 = r22;
    u32 _h_23 = r23;
    u32 _h_24 = r24;
    Term _h_25 = r25;
    Term _h_26 = r26;
    Term _h_27 = r27;
    Term _h_28 = r28;
    u32 _h_29 = r29;
    u32 _h_30 = r30;
    Term _h_31 = r31;
    u32 _h_32 = r32;
    u32 _h_33 = r33;
    u32 _h_34 = r34;
    WL_OPEN
    u32 _v_110 = 0;
    u32 _v_111 = 0;
    u32 _v_112 = 0;
    Term _v_113 = 0;
    u32 _v_114 = 0;
    Term _v_115 = 0;
    Term _v_116 = 0;
    Term _v_117 = 0;
    u32 _v_118 = 0;
    u32 _v_119 = 0;
    u32 _v_120 = 0;
    u32 _v_121 = 0;
    u32 _v_122 = 0;
    u32 _v_123 = 0;
    u32 _v_124 = 0;
    u32 _v_125 = 0;
    u32 _v_126 = 0;
    u32 _v_127 = 0;
    u32 _v_128 = 0;
    Term _v_129 = 0;
    Term _v_130 = 0;
    Term _v_131 = 0;
    u32 _v_132 = 0;
    u32 _v_133 = 0;
    u32 _v_134 = 0;
    u32 _v_135 = 0;
    u32 _v_136 = 0;
    Term _v_137 = 0;
    Term _v_138 = 0;
    u32 _v_139 = 0;
    Term _v_140 = 0;
    Term _o_2[31];
    if (spin_53(e, _o_2, _h_0, _h_1, _h_2, _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, _h_6, _h_7, _h_8, _h_9, blk_loc(e.mem, _h_9), _h_10, blk_loc(e.mem, _h_10), _h_11, _h_12, blk_loc(e.mem, _h_12), _h_13, blk_loc(e.mem, _h_13), _h_14, blk_loc(e.mem, _h_14), _h_15, _h_16, _h_17, _h_18, _h_19, _h_20, _h_21, _h_22, _h_23, _h_24, _h_25, blk_loc(e.mem, _h_25), _h_26, blk_loc(e.mem, _h_26), _h_27, blk_loc(e.mem, _h_27), _h_28, blk_loc(e.mem, _h_28), _h_29, _h_30, _h_31, blk_loc(e.mem, _h_31), _h_32, _h_33, _h_34) == 0) {
      return 0;
    }
    _v_110 = _o_2[0];
    _v_111 = _o_2[1];
    _v_112 = _o_2[2];
    _v_113 = _o_2[3];
    _v_114 = _o_2[4];
    _v_115 = _o_2[5];
    _v_116 = _o_2[6];
    _v_117 = _o_2[7];
    _v_118 = _o_2[8];
    _v_119 = _o_2[9];
    _v_120 = _o_2[10];
    _v_121 = _o_2[11];
    _v_122 = _o_2[12];
    _v_123 = _o_2[13];
    _v_124 = _o_2[14];
    _v_125 = _o_2[15];
    _v_126 = _o_2[16];
    _v_127 = _o_2[17];
    _v_128 = _o_2[18];
    _v_129 = _o_2[19];
    _v_130 = _o_2[20];
    _v_131 = _o_2[21];
    _v_132 = _o_2[22];
    _v_133 = _o_2[23];
    _v_134 = _o_2[24];
    _v_135 = _o_2[25];
    _v_136 = _o_2[26];
    _v_137 = _o_2[27];
    _v_138 = _o_2[28];
    _v_139 = _o_2[29];
    _v_140 = _o_2[30];
    r0 = _v_110;
    r1 = _v_111;
    r2 = _v_112;
    r3 = _v_113;
    r4 = _v_114;
    r5 = _v_115;
    r6 = _v_116;
    r7 = _v_117;
    r8 = _v_118;
    r9 = _v_119;
    r10 = _v_120;
    r11 = _v_121;
    r12 = _v_122;
    r13 = _v_123;
    r14 = _v_124;
    r15 = _v_125;
    r16 = _v_126;
    r17 = _v_127;
    r18 = _v_128;
    r19 = _v_129;
    r20 = _v_130;
    r21 = _v_131;
    r22 = _v_132;
    r23 = _v_133;
    r24 = _v_134;
    r25 = _v_135;
    r26 = _v_136;
    r27 = _v_137;
    r28 = _v_138;
    r29 = _v_139;
    r30 = _v_140;
    WL_RETN(31);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_SEED_0_C366)
  {
    Term _x_0 = r0;
    WL_OPEN
    Term _fb_0[13];
    u64 _sp_0 = ctr_take(e, _x_0, 13, _fb_0);
    u32 _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    u32 _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    u32 _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    Term _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    Term _f_8 = _fb_0[8];
    Term _f_9 = _fb_0[9];
    Term _f_10 = _fb_0[10];
    u32 _f_11 = _fb_0[11];
    u32 _f_12 = _fb_0[12];
    spare_free(e, cls_fit(13), _sp_0);
    Term _fb_1[12];
    u64 _sp_1 = ctr_take(e, _f_7, 12, _fb_1);
    Term _f_13 = _fb_1[0];
    u32 _f_14 = _fb_1[1];
    u32 _f_15 = _fb_1[2];
    u32 _f_16 = _fb_1[3];
    u32 _f_17 = _fb_1[4];
    u32 _f_18 = _fb_1[5];
    u32 _f_19 = _fb_1[6];
    u32 _f_20 = _fb_1[7];
    u32 _f_21 = _fb_1[8];
    u32 _f_22 = _fb_1[9];
    u32 _f_23 = _fb_1[10];
    u32 _f_24 = _fb_1[11];
    spare_free(e, cls_fit(12), _sp_1);
    u32 _v_133 = 0;
    u32 _v_134 = 0;
    u32 _v_135 = 0;
    Term _v_136 = 0;
    u32 _v_137 = 0;
    Term _v_138 = 0;
    Term _v_139 = 0;
    Term _v_140 = 0;
    u32 _v_141 = 0;
    u32 _v_142 = 0;
    u32 _v_143 = 0;
    u32 _v_144 = 0;
    u32 _v_145 = 0;
    u32 _v_146 = 0;
    u32 _v_147 = 0;
    u32 _v_148 = 0;
    u32 _v_149 = 0;
    u32 _v_150 = 0;
    u32 _v_151 = 0;
    Term _v_152 = 0;
    Term _v_153 = 0;
    Term _v_154 = 0;
    u32 _v_155 = 0;
    u32 _v_156 = 0;
    Term _o_0[24];
    if (spin_54(e, _o_0, _f_0, _f_1, _f_2, _f_3, blk_loc(e.mem, _f_3), _f_4, _f_5, _f_6, blk_loc(e.mem, _f_6), _f_13, blk_loc(e.mem, _f_13), _f_14, _f_15, _f_16, _f_17, _f_18, _f_19, _f_20, _f_21, _f_22, _f_23, _f_24, _f_8, blk_loc(e.mem, _f_8), _f_9, blk_loc(e.mem, _f_9), _f_10, blk_loc(e.mem, _f_10), _f_11, _f_12) == 0) {
      return 0;
    }
    _v_133 = _o_0[0];
    _v_134 = _o_0[1];
    _v_135 = _o_0[2];
    _v_136 = _o_0[3];
    _v_137 = _o_0[4];
    _v_138 = _o_0[5];
    _v_139 = _o_0[6];
    _v_140 = _o_0[7];
    _v_141 = _o_0[8];
    _v_142 = _o_0[9];
    _v_143 = _o_0[10];
    _v_144 = _o_0[11];
    _v_145 = _o_0[12];
    _v_146 = _o_0[13];
    _v_147 = _o_0[14];
    _v_148 = _o_0[15];
    _v_149 = _o_0[16];
    _v_150 = _o_0[17];
    _v_151 = _o_0[18];
    _v_152 = _o_0[19];
    _v_153 = _o_0[20];
    _v_154 = _o_0[21];
    _v_155 = _o_0[22];
    _v_156 = _o_0[23];
    u64 _nd_0 = heap_alloc(e, cls_fit(12));
    e.mem[_nd_0 + 0] = rfc_seal(e, _v_140);
    e.mem[_nd_0 + 1] = rfc_seal(e, _v_141);
    e.mem[_nd_0 + 2] = rfc_seal(e, _v_142);
    e.mem[_nd_0 + 3] = rfc_seal(e, _v_143);
    e.mem[_nd_0 + 4] = rfc_seal(e, _v_144);
    e.mem[_nd_0 + 5] = rfc_seal(e, _v_145);
    e.mem[_nd_0 + 6] = rfc_seal(e, _v_146);
    e.mem[_nd_0 + 7] = rfc_seal(e, _v_147);
    e.mem[_nd_0 + 8] = rfc_seal(e, _v_148);
    e.mem[_nd_0 + 9] = rfc_seal(e, _v_149);
    e.mem[_nd_0 + 10] = rfc_seal(e, _v_150);
    e.mem[_nd_0 + 11] = rfc_seal(e, _v_151);
    u64 _nd_1 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_1 + 0] = rfc_seal(e, _v_133);
    e.mem[_nd_1 + 1] = rfc_seal(e, _v_134);
    e.mem[_nd_1 + 2] = rfc_seal(e, _v_135);
    e.mem[_nd_1 + 3] = rfc_seal(e, _v_136);
    e.mem[_nd_1 + 4] = rfc_seal(e, _v_137);
    e.mem[_nd_1 + 5] = rfc_seal(e, _v_138);
    e.mem[_nd_1 + 6] = rfc_seal(e, _v_139);
    e.mem[_nd_1 + 7] = rfc_seal(e, term_ctr(CID_CONSUMER_EXPANDED_RESOURCES, _nd_0));
    e.mem[_nd_1 + 8] = rfc_seal(e, _v_152);
    e.mem[_nd_1 + 9] = rfc_seal(e, _v_153);
    e.mem[_nd_1 + 10] = rfc_seal(e, _v_154);
    e.mem[_nd_1 + 11] = rfc_seal(e, _v_155);
    e.mem[_nd_1 + 12] = rfc_seal(e, _v_156);
    r0 = term_ctr(CID________________BENDVY_SRC_ECS_WORLD_WORLD, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_CHECKPOINT_0)
  {
    u32 _app_0 = r0;
    u32 _app_1 = r1;
    u32 _app_2 = r2;
    Term _app_3 = r3;
    u32 _app_4 = r4;
    Term _app_5 = r5;
    Term _app_6 = r6;
    Term _app_7 = r7;
    u32 _app_8 = r8;
    u32 _app_9 = r9;
    u32 _app_10 = r10;
    u32 _app_11 = r11;
    u32 _app_12 = r12;
    u32 _app_13 = r13;
    u32 _app_14 = r14;
    u32 _app_15 = r15;
    u32 _app_16 = r16;
    u32 _app_17 = r17;
    u32 _app_18 = r18;
    Term _app_19 = r19;
    Term _app_20 = r20;
    Term _app_21 = r21;
    u32 _app_22 = r22;
    u32 _app_23 = r23;
    u32 _app_24 = r24;
    u32 _app_25 = r25;
    u32 _app_26 = r26;
    Term _app_27 = r27;
    Term _app_28 = r28;
    u32 _app_29 = r29;
    Term _app_30 = r30;
    Term _label_0 = r31;
    Term _prior_0 = r32;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _label_0;
      STK(1) = _prior_0;
      STK(2) = FID_CONSUMER_EXPANDED_CHECKPOINT_0_K368;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID_CONSUMER_EXPANDED_CHECKPOINT_0_K368, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _label_0;
      e.mem[_t_0 + 1] = _prior_0;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_CHECKPOINT_0_K368, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_OBSERVE_0)) {
      u64 _t_1 = task_node(e, FID_CONSUMER_EXPANDED_OBSERVE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _app_0;
      e.mem[_t_1 + 1] = _app_1;
      e.mem[_t_1 + 2] = _app_2;
      e.mem[_t_1 + 3] = _app_3;
      e.mem[_t_1 + 4] = _app_4;
      e.mem[_t_1 + 5] = _app_5;
      e.mem[_t_1 + 6] = _app_6;
      e.mem[_t_1 + 7] = _app_7;
      e.mem[_t_1 + 8] = _app_8;
      e.mem[_t_1 + 9] = _app_9;
      e.mem[_t_1 + 10] = _app_10;
      e.mem[_t_1 + 11] = _app_11;
      e.mem[_t_1 + 12] = _app_12;
      e.mem[_t_1 + 13] = _app_13;
      e.mem[_t_1 + 14] = _app_14;
      e.mem[_t_1 + 15] = _app_15;
      e.mem[_t_1 + 16] = _app_16;
      e.mem[_t_1 + 17] = _app_17;
      e.mem[_t_1 + 18] = _app_18;
      e.mem[_t_1 + 19] = _app_19;
      e.mem[_t_1 + 20] = _app_20;
      e.mem[_t_1 + 21] = _app_21;
      e.mem[_t_1 + 22] = _app_22;
      e.mem[_t_1 + 23] = _app_23;
      e.mem[_t_1 + 24] = _app_24;
      e.mem[_t_1 + 25] = _app_25;
      e.mem[_t_1 + 26] = _app_26;
      e.mem[_t_1 + 27] = _app_27;
      e.mem[_t_1 + 28] = _app_28;
      e.mem[_t_1 + 29] = _app_29;
      e.mem[_t_1 + 30] = _app_30;
      return term_tsk(FID_CONSUMER_EXPANDED_OBSERVE_0, _t_1);
    }
    r0 = _app_0;
    r1 = _app_1;
    r2 = _app_2;
    r3 = _app_3;
    r4 = _app_4;
    r5 = _app_5;
    r6 = _app_6;
    r7 = _app_7;
    r8 = _app_8;
    r9 = _app_9;
    r10 = _app_10;
    r11 = _app_11;
    r12 = _app_12;
    r13 = _app_13;
    r14 = _app_14;
    r15 = _app_15;
    r16 = _app_16;
    r17 = _app_17;
    r18 = _app_18;
    r19 = _app_19;
    r20 = _app_20;
    r21 = _app_21;
    r22 = _app_22;
    r23 = _app_23;
    r24 = _app_24;
    r25 = _app_25;
    r26 = _app_26;
    r27 = _app_27;
    r28 = _app_28;
    r29 = _app_29;
    r30 = _app_30;
    WL_JMP(FID_CONSUMER_EXPANDED_OBSERVE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_CHECKPOINT_0_K368)
  {
    WL_POPN(2);
    Term _label_1 = STK(0);
    Term _prior_1 = STK(1);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    u32 _h_12 = r12;
    u32 _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    Term _h_19 = r19;
    Term _h_20 = r20;
    Term _h_21 = r21;
    u32 _h_22 = r22;
    u32 _h_23 = r23;
    u32 _h_24 = r24;
    u32 _h_25 = r25;
    u32 _h_26 = r26;
    Term _h_27 = r27;
    Term _h_28 = r28;
    u32 _h_29 = r29;
    Term _h_30 = r30;
    Term _h_31 = r31;
    WL_OPEN
    if (seq) {
      WL_ROOM(34);
      STK(0) = _label_1;
      STK(1) = _prior_1;
      STK(2) = _h_0;
      STK(3) = _h_1;
      STK(4) = _h_2;
      STK(5) = _h_3;
      STK(6) = _h_4;
      STK(7) = _h_5;
      STK(8) = _h_6;
      STK(9) = _h_7;
      STK(10) = _h_8;
      STK(11) = _h_9;
      STK(12) = _h_10;
      STK(13) = _h_11;
      STK(14) = _h_12;
      STK(15) = _h_13;
      STK(16) = _h_14;
      STK(17) = _h_15;
      STK(18) = _h_16;
      STK(19) = _h_17;
      STK(20) = _h_18;
      STK(21) = _h_19;
      STK(22) = _h_20;
      STK(23) = _h_21;
      STK(24) = _h_22;
      STK(25) = _h_23;
      STK(26) = _h_24;
      STK(27) = _h_25;
      STK(28) = _h_26;
      STK(29) = _h_27;
      STK(30) = _h_28;
      STK(31) = _h_29;
      STK(32) = _h_30;
      STK(33) = FID_CONSUMER_EXPANDED_CHECKPOINT_0_K369;
      WL_PUSHN(34);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_EXPANDED_CHECKPOINT_0_K369, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _label_1;
      e.mem[_t_2 + 1] = _prior_1;
      e.mem[_t_2 + 2] = _h_0;
      e.mem[_t_2 + 3] = _h_1;
      e.mem[_t_2 + 4] = _h_2;
      e.mem[_t_2 + 5] = _h_3;
      e.mem[_t_2 + 6] = _h_4;
      e.mem[_t_2 + 7] = _h_5;
      e.mem[_t_2 + 8] = _h_6;
      e.mem[_t_2 + 9] = _h_7;
      e.mem[_t_2 + 10] = _h_8;
      e.mem[_t_2 + 11] = _h_9;
      e.mem[_t_2 + 12] = _h_10;
      e.mem[_t_2 + 13] = _h_11;
      e.mem[_t_2 + 14] = _h_12;
      e.mem[_t_2 + 15] = _h_13;
      e.mem[_t_2 + 16] = _h_14;
      e.mem[_t_2 + 17] = _h_15;
      e.mem[_t_2 + 18] = _h_16;
      e.mem[_t_2 + 19] = _h_17;
      e.mem[_t_2 + 20] = _h_18;
      e.mem[_t_2 + 21] = _h_19;
      e.mem[_t_2 + 22] = _h_20;
      e.mem[_t_2 + 23] = _h_21;
      e.mem[_t_2 + 24] = _h_22;
      e.mem[_t_2 + 25] = _h_23;
      e.mem[_t_2 + 26] = _h_24;
      e.mem[_t_2 + 27] = _h_25;
      e.mem[_t_2 + 28] = _h_26;
      e.mem[_t_2 + 29] = _h_27;
      e.mem[_t_2 + 30] = _h_28;
      e.mem[_t_2 + 31] = _h_29;
      e.mem[_t_2 + 32] = _h_30;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_CHECKPOINT_0_K369, _t_2);
      WL_IDX = 33;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_31;
      e.mem[_t_3 + 1] = term_ctr(CID_SCON, STAT_OFF + 492);
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _h_31;
    r1 = term_ctr(CID_SCON, STAT_OFF + 492);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_CHECKPOINT_0_K369)
  {
    WL_POPN(33);
    Term _label_2 = STK(0);
    Term _prior_2 = STK(1);
    u32 _h_33 = STK(2);
    u32 _h_34 = STK(3);
    u32 _h_35 = STK(4);
    Term _h_36 = STK(5);
    u32 _h_37 = STK(6);
    Term _h_38 = STK(7);
    Term _h_39 = STK(8);
    Term _h_40 = STK(9);
    u32 _h_41 = STK(10);
    u32 _h_42 = STK(11);
    u32 _h_43 = STK(12);
    u32 _h_44 = STK(13);
    u32 _h_45 = STK(14);
    u32 _h_46 = STK(15);
    u32 _h_47 = STK(16);
    u32 _h_48 = STK(17);
    u32 _h_49 = STK(18);
    u32 _h_50 = STK(19);
    u32 _h_51 = STK(20);
    Term _h_52 = STK(21);
    Term _h_53 = STK(22);
    Term _h_54 = STK(23);
    u32 _h_55 = STK(24);
    u32 _h_56 = STK(25);
    u32 _h_57 = STK(26);
    u32 _h_58 = STK(27);
    u32 _h_59 = STK(28);
    Term _h_60 = STK(29);
    Term _h_61 = STK(30);
    u32 _h_62 = STK(31);
    Term _h_63 = STK(32);
    Term _h_32 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(34);
      STK(0) = _label_2;
      STK(1) = _prior_2;
      STK(2) = _h_33;
      STK(3) = _h_34;
      STK(4) = _h_35;
      STK(5) = _h_36;
      STK(6) = _h_37;
      STK(7) = _h_38;
      STK(8) = _h_39;
      STK(9) = _h_40;
      STK(10) = _h_41;
      STK(11) = _h_42;
      STK(12) = _h_43;
      STK(13) = _h_44;
      STK(14) = _h_45;
      STK(15) = _h_46;
      STK(16) = _h_47;
      STK(17) = _h_48;
      STK(18) = _h_49;
      STK(19) = _h_50;
      STK(20) = _h_51;
      STK(21) = _h_52;
      STK(22) = _h_53;
      STK(23) = _h_54;
      STK(24) = _h_55;
      STK(25) = _h_56;
      STK(26) = _h_57;
      STK(27) = _h_58;
      STK(28) = _h_59;
      STK(29) = _h_60;
      STK(30) = _h_61;
      STK(31) = _h_62;
      STK(32) = _h_63;
      STK(33) = FID_CONSUMER_EXPANDED_CHECKPOINT_0_K370;
      WL_PUSHN(34);
    } else {
      u64 _t_4 = task_node(e, FID_CONSUMER_EXPANDED_CHECKPOINT_0_K370, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _label_2;
      e.mem[_t_4 + 1] = _prior_2;
      e.mem[_t_4 + 2] = _h_33;
      e.mem[_t_4 + 3] = _h_34;
      e.mem[_t_4 + 4] = _h_35;
      e.mem[_t_4 + 5] = _h_36;
      e.mem[_t_4 + 6] = _h_37;
      e.mem[_t_4 + 7] = _h_38;
      e.mem[_t_4 + 8] = _h_39;
      e.mem[_t_4 + 9] = _h_40;
      e.mem[_t_4 + 10] = _h_41;
      e.mem[_t_4 + 11] = _h_42;
      e.mem[_t_4 + 12] = _h_43;
      e.mem[_t_4 + 13] = _h_44;
      e.mem[_t_4 + 14] = _h_45;
      e.mem[_t_4 + 15] = _h_46;
      e.mem[_t_4 + 16] = _h_47;
      e.mem[_t_4 + 17] = _h_48;
      e.mem[_t_4 + 18] = _h_49;
      e.mem[_t_4 + 19] = _h_50;
      e.mem[_t_4 + 20] = _h_51;
      e.mem[_t_4 + 21] = _h_52;
      e.mem[_t_4 + 22] = _h_53;
      e.mem[_t_4 + 23] = _h_54;
      e.mem[_t_4 + 24] = _h_55;
      e.mem[_t_4 + 25] = _h_56;
      e.mem[_t_4 + 26] = _h_57;
      e.mem[_t_4 + 27] = _h_58;
      e.mem[_t_4 + 28] = _h_59;
      e.mem[_t_4 + 29] = _h_60;
      e.mem[_t_4 + 30] = _h_61;
      e.mem[_t_4 + 31] = _h_62;
      e.mem[_t_4 + 32] = _h_63;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_CHECKPOINT_0_K370, _t_4);
      WL_IDX = 33;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 76);
      e.mem[_t_5 + 1] = _h_32;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 76);
    r1 = _h_32;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_CHECKPOINT_0_K370)
  {
    WL_POPN(33);
    Term _label_3 = STK(0);
    Term _prior_3 = STK(1);
    u32 _h_65 = STK(2);
    u32 _h_66 = STK(3);
    u32 _h_67 = STK(4);
    Term _h_68 = STK(5);
    u32 _h_69 = STK(6);
    Term _h_70 = STK(7);
    Term _h_71 = STK(8);
    Term _h_72 = STK(9);
    u32 _h_73 = STK(10);
    u32 _h_74 = STK(11);
    u32 _h_75 = STK(12);
    u32 _h_76 = STK(13);
    u32 _h_77 = STK(14);
    u32 _h_78 = STK(15);
    u32 _h_79 = STK(16);
    u32 _h_80 = STK(17);
    u32 _h_81 = STK(18);
    u32 _h_82 = STK(19);
    u32 _h_83 = STK(20);
    Term _h_84 = STK(21);
    Term _h_85 = STK(22);
    Term _h_86 = STK(23);
    u32 _h_87 = STK(24);
    u32 _h_88 = STK(25);
    u32 _h_89 = STK(26);
    u32 _h_90 = STK(27);
    u32 _h_91 = STK(28);
    Term _h_92 = STK(29);
    Term _h_93 = STK(30);
    u32 _h_94 = STK(31);
    Term _h_95 = STK(32);
    Term _h_64 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(33);
      STK(0) = _prior_3;
      STK(1) = _h_65;
      STK(2) = _h_66;
      STK(3) = _h_67;
      STK(4) = _h_68;
      STK(5) = _h_69;
      STK(6) = _h_70;
      STK(7) = _h_71;
      STK(8) = _h_72;
      STK(9) = _h_73;
      STK(10) = _h_74;
      STK(11) = _h_75;
      STK(12) = _h_76;
      STK(13) = _h_77;
      STK(14) = _h_78;
      STK(15) = _h_79;
      STK(16) = _h_80;
      STK(17) = _h_81;
      STK(18) = _h_82;
      STK(19) = _h_83;
      STK(20) = _h_84;
      STK(21) = _h_85;
      STK(22) = _h_86;
      STK(23) = _h_87;
      STK(24) = _h_88;
      STK(25) = _h_89;
      STK(26) = _h_90;
      STK(27) = _h_91;
      STK(28) = _h_92;
      STK(29) = _h_93;
      STK(30) = _h_94;
      STK(31) = _h_95;
      STK(32) = FID_CONSUMER_EXPANDED_CHECKPOINT_0_K371;
      WL_PUSHN(33);
    } else {
      u64 _t_6 = task_node(e, FID_CONSUMER_EXPANDED_CHECKPOINT_0_K371, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _prior_3;
      e.mem[_t_6 + 1] = _h_65;
      e.mem[_t_6 + 2] = _h_66;
      e.mem[_t_6 + 3] = _h_67;
      e.mem[_t_6 + 4] = _h_68;
      e.mem[_t_6 + 5] = _h_69;
      e.mem[_t_6 + 6] = _h_70;
      e.mem[_t_6 + 7] = _h_71;
      e.mem[_t_6 + 8] = _h_72;
      e.mem[_t_6 + 9] = _h_73;
      e.mem[_t_6 + 10] = _h_74;
      e.mem[_t_6 + 11] = _h_75;
      e.mem[_t_6 + 12] = _h_76;
      e.mem[_t_6 + 13] = _h_77;
      e.mem[_t_6 + 14] = _h_78;
      e.mem[_t_6 + 15] = _h_79;
      e.mem[_t_6 + 16] = _h_80;
      e.mem[_t_6 + 17] = _h_81;
      e.mem[_t_6 + 18] = _h_82;
      e.mem[_t_6 + 19] = _h_83;
      e.mem[_t_6 + 20] = _h_84;
      e.mem[_t_6 + 21] = _h_85;
      e.mem[_t_6 + 22] = _h_86;
      e.mem[_t_6 + 23] = _h_87;
      e.mem[_t_6 + 24] = _h_88;
      e.mem[_t_6 + 25] = _h_89;
      e.mem[_t_6 + 26] = _h_90;
      e.mem[_t_6 + 27] = _h_91;
      e.mem[_t_6 + 28] = _h_92;
      e.mem[_t_6 + 29] = _h_93;
      e.mem[_t_6 + 30] = _h_94;
      e.mem[_t_6 + 31] = _h_95;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_CHECKPOINT_0_K371, _t_6);
      WL_IDX = 32;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _label_3;
      e.mem[_t_7 + 1] = _h_64;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _label_3;
    r1 = _h_64;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_CHECKPOINT_0_K371)
  {
    WL_POPN(32);
    Term _prior_4 = STK(0);
    u32 _h_97 = STK(1);
    u32 _h_98 = STK(2);
    u32 _h_99 = STK(3);
    Term _h_100 = STK(4);
    u32 _h_101 = STK(5);
    Term _h_102 = STK(6);
    Term _h_103 = STK(7);
    Term _h_104 = STK(8);
    u32 _h_105 = STK(9);
    u32 _h_106 = STK(10);
    u32 _h_107 = STK(11);
    u32 _h_108 = STK(12);
    u32 _h_109 = STK(13);
    u32 _h_110 = STK(14);
    u32 _h_111 = STK(15);
    u32 _h_112 = STK(16);
    u32 _h_113 = STK(17);
    u32 _h_114 = STK(18);
    u32 _h_115 = STK(19);
    Term _h_116 = STK(20);
    Term _h_117 = STK(21);
    Term _h_118 = STK(22);
    u32 _h_119 = STK(23);
    u32 _h_120 = STK(24);
    u32 _h_121 = STK(25);
    u32 _h_122 = STK(26);
    u32 _h_123 = STK(27);
    Term _h_124 = STK(28);
    Term _h_125 = STK(29);
    u32 _h_126 = STK(30);
    Term _h_127 = STK(31);
    Term _h_96 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(32);
      STK(0) = _h_97;
      STK(1) = _h_98;
      STK(2) = _h_99;
      STK(3) = _h_100;
      STK(4) = _h_101;
      STK(5) = _h_102;
      STK(6) = _h_103;
      STK(7) = _h_104;
      STK(8) = _h_105;
      STK(9) = _h_106;
      STK(10) = _h_107;
      STK(11) = _h_108;
      STK(12) = _h_109;
      STK(13) = _h_110;
      STK(14) = _h_111;
      STK(15) = _h_112;
      STK(16) = _h_113;
      STK(17) = _h_114;
      STK(18) = _h_115;
      STK(19) = _h_116;
      STK(20) = _h_117;
      STK(21) = _h_118;
      STK(22) = _h_119;
      STK(23) = _h_120;
      STK(24) = _h_121;
      STK(25) = _h_122;
      STK(26) = _h_123;
      STK(27) = _h_124;
      STK(28) = _h_125;
      STK(29) = _h_126;
      STK(30) = _h_127;
      STK(31) = FID_CONSUMER_EXPANDED_CHECKPOINT_0_K372;
      WL_PUSHN(32);
    } else {
      u64 _t_8 = task_node(e, FID_CONSUMER_EXPANDED_CHECKPOINT_0_K372, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_97;
      e.mem[_t_8 + 1] = _h_98;
      e.mem[_t_8 + 2] = _h_99;
      e.mem[_t_8 + 3] = _h_100;
      e.mem[_t_8 + 4] = _h_101;
      e.mem[_t_8 + 5] = _h_102;
      e.mem[_t_8 + 6] = _h_103;
      e.mem[_t_8 + 7] = _h_104;
      e.mem[_t_8 + 8] = _h_105;
      e.mem[_t_8 + 9] = _h_106;
      e.mem[_t_8 + 10] = _h_107;
      e.mem[_t_8 + 11] = _h_108;
      e.mem[_t_8 + 12] = _h_109;
      e.mem[_t_8 + 13] = _h_110;
      e.mem[_t_8 + 14] = _h_111;
      e.mem[_t_8 + 15] = _h_112;
      e.mem[_t_8 + 16] = _h_113;
      e.mem[_t_8 + 17] = _h_114;
      e.mem[_t_8 + 18] = _h_115;
      e.mem[_t_8 + 19] = _h_116;
      e.mem[_t_8 + 20] = _h_117;
      e.mem[_t_8 + 21] = _h_118;
      e.mem[_t_8 + 22] = _h_119;
      e.mem[_t_8 + 23] = _h_120;
      e.mem[_t_8 + 24] = _h_121;
      e.mem[_t_8 + 25] = _h_122;
      e.mem[_t_8 + 26] = _h_123;
      e.mem[_t_8 + 27] = _h_124;
      e.mem[_t_8 + 28] = _h_125;
      e.mem[_t_8 + 29] = _h_126;
      e.mem[_t_8 + 30] = _h_127;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_CHECKPOINT_0_K372, _t_8);
      WL_IDX = 31;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _prior_4;
      e.mem[_t_9 + 1] = _h_96;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _prior_4;
    r1 = _h_96;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_CHECKPOINT_0_K372)
  {
    WL_POPN(31);
    u32 _h_129 = STK(0);
    u32 _h_130 = STK(1);
    u32 _h_131 = STK(2);
    Term _h_132 = STK(3);
    u32 _h_133 = STK(4);
    Term _h_134 = STK(5);
    Term _h_135 = STK(6);
    Term _h_136 = STK(7);
    u32 _h_137 = STK(8);
    u32 _h_138 = STK(9);
    u32 _h_139 = STK(10);
    u32 _h_140 = STK(11);
    u32 _h_141 = STK(12);
    u32 _h_142 = STK(13);
    u32 _h_143 = STK(14);
    u32 _h_144 = STK(15);
    u32 _h_145 = STK(16);
    u32 _h_146 = STK(17);
    u32 _h_147 = STK(18);
    Term _h_148 = STK(19);
    Term _h_149 = STK(20);
    Term _h_150 = STK(21);
    u32 _h_151 = STK(22);
    u32 _h_152 = STK(23);
    u32 _h_153 = STK(24);
    u32 _h_154 = STK(25);
    u32 _h_155 = STK(26);
    Term _h_156 = STK(27);
    Term _h_157 = STK(28);
    u32 _h_158 = STK(29);
    Term _h_159 = STK(30);
    Term _h_128 = r0;
    WL_OPEN
    r0 = _h_129;
    r1 = _h_130;
    r2 = _h_131;
    r3 = _h_132;
    r4 = _h_133;
    r5 = _h_134;
    r6 = _h_135;
    r7 = _h_136;
    r8 = _h_137;
    r9 = _h_138;
    r10 = _h_139;
    r11 = _h_140;
    r12 = _h_141;
    r13 = _h_142;
    r14 = _h_143;
    r15 = _h_144;
    r16 = _h_145;
    r17 = _h_146;
    r18 = _h_147;
    r19 = _h_148;
    r20 = _h_149;
    r21 = _h_150;
    r22 = _h_151;
    r23 = _h_152;
    r24 = _h_153;
    r25 = _h_154;
    r26 = _h_155;
    r27 = _h_156;
    r28 = _h_157;
    r29 = _h_158;
    r30 = _h_159;
    r31 = _h_128;
    WL_RETN(32);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_STEPS_0)
  {
    Term _remaining_0 = r0;
    u32 _pair_0 = r1;
    u32 _pair_1 = r2;
    u32 _pair_2 = r3;
    Term _pair_3 = r4;
    u32 _pair_4 = r5;
    Term _pair_5 = r6;
    Term _pair_6 = r7;
    Term _pair_7 = r8;
    u32 _pair_8 = r9;
    u32 _pair_9 = r10;
    u32 _pair_10 = r11;
    u32 _pair_11 = r12;
    u32 _pair_12 = r13;
    u32 _pair_13 = r14;
    u32 _pair_14 = r15;
    u32 _pair_15 = r16;
    u32 _pair_16 = r17;
    u32 _pair_17 = r18;
    u32 _pair_18 = r19;
    Term _pair_19 = r20;
    Term _pair_20 = r21;
    Term _pair_21 = r22;
    u32 _pair_22 = r23;
    u32 _pair_23 = r24;
    u32 _pair_24 = r25;
    u32 _pair_25 = r26;
    u32 _pair_26 = r27;
    Term _pair_27 = r28;
    Term _pair_28 = r29;
    u32 _pair_29 = r30;
    Term _pair_30 = r31;
    Term _pair_31 = r32;
    WL_OPEN
    if (term_aux(_remaining_0) == CID_NIL) {
      term_sink(e, _pair_3);
      term_sink(e, _pair_6);
      term_sink(e, _pair_7);
      term_sink(e, _pair_19);
      term_sink(e, _pair_20);
      term_sink(e, _pair_21);
      term_sink(e, _pair_27);
      term_sink(e, _pair_28);
      term_sink(e, _pair_30);
      r0 = _pair_31;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _remaining_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[7];
      u64 _sp_1 = ctr_take(e, _f_0, 7, _fb_1);
      Term _f_2 = _fb_1[0];
      u32 _f_3 = _fb_1[1];
      u32 _f_4 = _fb_1[2];
      u32 _f_5 = _fb_1[3];
      u32 _f_6 = _fb_1[4];
      u32 _f_7 = _fb_1[5];
      u32 _f_8 = _fb_1[6];
      spare_free(e, cls_fit(7), _sp_1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(4);
        STK(0) = _f_2;
        STK(1) = _f_1;
        STK(2) = _pair_31;
        STK(3) = FID_CONSUMER_EXPANDED_STEPS_0_K374;
        WL_PUSHN(4);
      } else {
        u64 _t_0 = task_node(e, FID_CONSUMER_EXPANDED_STEPS_0_K374, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_2;
        e.mem[_t_0 + 1] = _f_1;
        e.mem[_t_0 + 2] = _pair_31;
        WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_STEPS_0_K374, _t_0);
        WL_IDX = 3;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_ACTION_0)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_EXPANDED_ACTION_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _pair_0;
        e.mem[_t_1 + 1] = _pair_1;
        e.mem[_t_1 + 2] = _pair_2;
        e.mem[_t_1 + 3] = _pair_3;
        e.mem[_t_1 + 4] = _pair_4;
        e.mem[_t_1 + 5] = _pair_5;
        e.mem[_t_1 + 6] = _pair_6;
        e.mem[_t_1 + 7] = _pair_7;
        e.mem[_t_1 + 8] = _pair_8;
        e.mem[_t_1 + 9] = _pair_9;
        e.mem[_t_1 + 10] = _pair_10;
        e.mem[_t_1 + 11] = _pair_11;
        e.mem[_t_1 + 12] = _pair_12;
        e.mem[_t_1 + 13] = _pair_13;
        e.mem[_t_1 + 14] = _pair_14;
        e.mem[_t_1 + 15] = _pair_15;
        e.mem[_t_1 + 16] = _pair_16;
        e.mem[_t_1 + 17] = _pair_17;
        e.mem[_t_1 + 18] = _pair_18;
        e.mem[_t_1 + 19] = _pair_19;
        e.mem[_t_1 + 20] = _pair_20;
        e.mem[_t_1 + 21] = _pair_21;
        e.mem[_t_1 + 22] = _pair_22;
        e.mem[_t_1 + 23] = _pair_23;
        e.mem[_t_1 + 24] = _pair_24;
        e.mem[_t_1 + 25] = _pair_25;
        e.mem[_t_1 + 26] = _pair_26;
        e.mem[_t_1 + 27] = _pair_27;
        e.mem[_t_1 + 28] = _pair_28;
        e.mem[_t_1 + 29] = _pair_29;
        e.mem[_t_1 + 30] = _pair_30;
        e.mem[_t_1 + 31] = _f_3;
        e.mem[_t_1 + 32] = _f_4;
        e.mem[_t_1 + 33] = _f_5;
        e.mem[_t_1 + 34] = _f_6;
        e.mem[_t_1 + 35] = _f_7;
        e.mem[_t_1 + 36] = _f_8;
        return term_tsk(FID_CONSUMER_EXPANDED_ACTION_0, _t_1);
      }
      r0 = _pair_0;
      r1 = _pair_1;
      r2 = _pair_2;
      r3 = _pair_3;
      r4 = _pair_4;
      r5 = _pair_5;
      r6 = _pair_6;
      r7 = _pair_7;
      r8 = _pair_8;
      r9 = _pair_9;
      r10 = _pair_10;
      r11 = _pair_11;
      r12 = _pair_12;
      r13 = _pair_13;
      r14 = _pair_14;
      r15 = _pair_15;
      r16 = _pair_16;
      r17 = _pair_17;
      r18 = _pair_18;
      r19 = _pair_19;
      r20 = _pair_20;
      r21 = _pair_21;
      r22 = _pair_22;
      r23 = _pair_23;
      r24 = _pair_24;
      r25 = _pair_25;
      r26 = _pair_26;
      r27 = _pair_27;
      r28 = _pair_28;
      r29 = _pair_29;
      r30 = _pair_30;
      r31 = _f_3;
      r32 = _f_4;
      r33 = _f_5;
      r34 = _f_6;
      r35 = _f_7;
      r36 = _f_8;
      WL_JMP(FID_CONSUMER_EXPANDED_ACTION_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_STEPS_0_K374)
  {
    WL_POPN(3);
    Term _f_9 = STK(0);
    Term _f_10 = STK(1);
    Term _pair_32 = STK(2);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    u32 _h_12 = r12;
    u32 _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    Term _h_19 = r19;
    Term _h_20 = r20;
    Term _h_21 = r21;
    u32 _h_22 = r22;
    u32 _h_23 = r23;
    u32 _h_24 = r24;
    u32 _h_25 = r25;
    u32 _h_26 = r26;
    Term _h_27 = r27;
    Term _h_28 = r28;
    u32 _h_29 = r29;
    Term _h_30 = r30;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _f_10;
      STK(1) = FID_CONSUMER_EXPANDED_STEPS_0_K375;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_EXPANDED_STEPS_0_K375, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _f_10;
      WL_CONT = term_tsk(FID_CONSUMER_EXPANDED_STEPS_0_K375, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_CHECKPOINT_0)) {
      u64 _t_3 = task_node(e, FID_CONSUMER_EXPANDED_CHECKPOINT_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = _h_1;
      e.mem[_t_3 + 2] = _h_2;
      e.mem[_t_3 + 3] = _h_3;
      e.mem[_t_3 + 4] = _h_4;
      e.mem[_t_3 + 5] = _h_5;
      e.mem[_t_3 + 6] = _h_6;
      e.mem[_t_3 + 7] = _h_7;
      e.mem[_t_3 + 8] = _h_8;
      e.mem[_t_3 + 9] = _h_9;
      e.mem[_t_3 + 10] = _h_10;
      e.mem[_t_3 + 11] = _h_11;
      e.mem[_t_3 + 12] = _h_12;
      e.mem[_t_3 + 13] = _h_13;
      e.mem[_t_3 + 14] = _h_14;
      e.mem[_t_3 + 15] = _h_15;
      e.mem[_t_3 + 16] = _h_16;
      e.mem[_t_3 + 17] = _h_17;
      e.mem[_t_3 + 18] = _h_18;
      e.mem[_t_3 + 19] = _h_19;
      e.mem[_t_3 + 20] = _h_20;
      e.mem[_t_3 + 21] = _h_21;
      e.mem[_t_3 + 22] = _h_22;
      e.mem[_t_3 + 23] = _h_23;
      e.mem[_t_3 + 24] = _h_24;
      e.mem[_t_3 + 25] = _h_25;
      e.mem[_t_3 + 26] = _h_26;
      e.mem[_t_3 + 27] = _h_27;
      e.mem[_t_3 + 28] = _h_28;
      e.mem[_t_3 + 29] = _h_29;
      e.mem[_t_3 + 30] = _h_30;
      e.mem[_t_3 + 31] = _f_9;
      e.mem[_t_3 + 32] = _pair_32;
      return term_tsk(FID_CONSUMER_EXPANDED_CHECKPOINT_0, _t_3);
    }
    r0 = _h_0;
    r1 = _h_1;
    r2 = _h_2;
    r3 = _h_3;
    r4 = _h_4;
    r5 = _h_5;
    r6 = _h_6;
    r7 = _h_7;
    r8 = _h_8;
    r9 = _h_9;
    r10 = _h_10;
    r11 = _h_11;
    r12 = _h_12;
    r13 = _h_13;
    r14 = _h_14;
    r15 = _h_15;
    r16 = _h_16;
    r17 = _h_17;
    r18 = _h_18;
    r19 = _h_19;
    r20 = _h_20;
    r21 = _h_21;
    r22 = _h_22;
    r23 = _h_23;
    r24 = _h_24;
    r25 = _h_25;
    r26 = _h_26;
    r27 = _h_27;
    r28 = _h_28;
    r29 = _h_29;
    r30 = _h_30;
    r31 = _f_9;
    r32 = _pair_32;
    WL_JMP(FID_CONSUMER_EXPANDED_CHECKPOINT_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_EXPANDED_STEPS_0_K375)
  {
    WL_POPN(1);
    Term _f_11 = STK(0);
    u32 _h_31 = r0;
    u32 _h_32 = r1;
    u32 _h_33 = r2;
    Term _h_34 = r3;
    u32 _h_35 = r4;
    Term _h_36 = r5;
    Term _h_37 = r6;
    Term _h_38 = r7;
    u32 _h_39 = r8;
    u32 _h_40 = r9;
    u32 _h_41 = r10;
    u32 _h_42 = r11;
    u32 _h_43 = r12;
    u32 _h_44 = r13;
    u32 _h_45 = r14;
    u32 _h_46 = r15;
    u32 _h_47 = r16;
    u32 _h_48 = r17;
    u32 _h_49 = r18;
    Term _h_50 = r19;
    Term _h_51 = r20;
    Term _h_52 = r21;
    u32 _h_53 = r22;
    u32 _h_54 = r23;
    u32 _h_55 = r24;
    u32 _h_56 = r25;
    u32 _h_57 = r26;
    Term _h_58 = r27;
    Term _h_59 = r28;
    u32 _h_60 = r29;
    Term _h_61 = r30;
    Term _h_62 = r31;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_STEPS_0)) {
      u64 _t_4 = task_node(e, FID_CONSUMER_EXPANDED_STEPS_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_4 + 0] = _f_11;
      e.mem[_t_4 + 1] = _h_31;
      e.mem[_t_4 + 2] = _h_32;
      e.mem[_t_4 + 3] = _h_33;
      e.mem[_t_4 + 4] = _h_34;
      e.mem[_t_4 + 5] = _h_35;
      e.mem[_t_4 + 6] = _h_36;
      e.mem[_t_4 + 7] = _h_37;
      e.mem[_t_4 + 8] = _h_38;
      e.mem[_t_4 + 9] = _h_39;
      e.mem[_t_4 + 10] = _h_40;
      e.mem[_t_4 + 11] = _h_41;
      e.mem[_t_4 + 12] = _h_42;
      e.mem[_t_4 + 13] = _h_43;
      e.mem[_t_4 + 14] = _h_44;
      e.mem[_t_4 + 15] = _h_45;
      e.mem[_t_4 + 16] = _h_46;
      e.mem[_t_4 + 17] = _h_47;
      e.mem[_t_4 + 18] = _h_48;
      e.mem[_t_4 + 19] = _h_49;
      e.mem[_t_4 + 20] = _h_50;
      e.mem[_t_4 + 21] = _h_51;
      e.mem[_t_4 + 22] = _h_52;
      e.mem[_t_4 + 23] = _h_53;
      e.mem[_t_4 + 24] = _h_54;
      e.mem[_t_4 + 25] = _h_55;
      e.mem[_t_4 + 26] = _h_56;
      e.mem[_t_4 + 27] = _h_57;
      e.mem[_t_4 + 28] = _h_58;
      e.mem[_t_4 + 29] = _h_59;
      e.mem[_t_4 + 30] = _h_60;
      e.mem[_t_4 + 31] = _h_61;
      e.mem[_t_4 + 32] = _h_62;
      return term_tsk(FID_CONSUMER_EXPANDED_STEPS_0, _t_4);
    }
    r0 = _f_11;
    r1 = _h_31;
    r2 = _h_32;
    r3 = _h_33;
    r4 = _h_34;
    r5 = _h_35;
    r6 = _h_36;
    r7 = _h_37;
    r8 = _h_38;
    r9 = _h_39;
    r10 = _h_40;
    r11 = _h_41;
    r12 = _h_42;
    r13 = _h_43;
    r14 = _h_44;
    r15 = _h_45;
    r16 = _h_46;
    r17 = _h_47;
    r18 = _h_48;
    r19 = _h_49;
    r20 = _h_50;
    r21 = _h_51;
    r22 = _h_52;
    r23 = _h_53;
    r24 = _h_54;
    r25 = _h_55;
    r26 = _h_56;
    r27 = _h_57;
    r28 = _h_58;
    r29 = _h_59;
    r30 = _h_60;
    r31 = _h_61;
    r32 = _h_62;
    WL_JMP(FID_CONSUMER_EXPANDED_STEPS_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN)
  {
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    Term _v_4 = 0;
    u32 _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    u32 _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    Term _v_28 = 0;
    Term _v_29 = 0;
    u32 _v_30 = 0;
    Term _v_31 = 0;
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    Term _v_34 = 0;
    u32 _v_35 = 0;
    u32 _v_36 = 0;
    Term _v_37 = 0;
    u32 _v_38 = 0;
    Term _v_39 = 0;
    Term _v_40 = 0;
    Term _v_41 = 0;
    u32 _v_42 = 0;
    u32 _v_43 = 0;
    u32 _v_44 = 0;
    u32 _v_45 = 0;
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    u32 _v_50 = 0;
    u32 _v_51 = 0;
    u32 _v_52 = 0;
    Term _v_53 = 0;
    Term _v_54 = 0;
    Term _v_55 = 0;
    u32 _v_56 = 0;
    u32 _v_57 = 0;
    Term _fv_0[1];
    _fv_0[0] = 31ull;
    Term _fv_1[1];
    _fv_1[0] = 37ull;
    u32 _v_58 = 0;
    u32 _v_59 = 0;
    Term _v_60 = 0;
    u32 _v_61 = 0;
    u32 _v_62 = 0;
    Term _v_63 = 0;
    u32 _v_64 = 0;
    Term _v_65 = 0;
    Term _v_66 = 0;
    Term _v_67 = 0;
    u32 _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    u32 _v_73 = 0;
    u32 _v_74 = 0;
    u32 _v_75 = 0;
    u32 _v_76 = 0;
    u32 _v_77 = 0;
    u32 _v_78 = 0;
    Term _v_79 = 0;
    Term _v_80 = 0;
    Term _v_81 = 0;
    u32 _v_82 = 0;
    u32 _v_83 = 0;
    Term _o_0[26];
    Term _a_0 = blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_0), blk_new(e, 0, 0, 0, 1, _fv_1));
    if (spin_57(e, _o_0, U32_BIN(1ull, <, 4294967295ull), 1ull, _a_0, blk_loc(e.mem, _a_0), 1, 0, 10ull, 0, 0, 0, 0, 1, 2, 90ull, 1) == 0) {
      return 0;
    }
    _v_58 = _o_0[0];
    _v_59 = _o_0[1];
    _v_60 = _o_0[2];
    _v_61 = _o_0[3];
    _v_62 = _o_0[4];
    _v_63 = _o_0[5];
    _v_64 = _o_0[6];
    _v_65 = _o_0[7];
    _v_66 = _o_0[8];
    _v_67 = _o_0[9];
    _v_68 = _o_0[10];
    _v_69 = _o_0[11];
    _v_70 = _o_0[12];
    _v_71 = _o_0[13];
    _v_72 = _o_0[14];
    _v_73 = _o_0[15];
    _v_74 = _o_0[16];
    _v_75 = _o_0[17];
    _v_76 = _o_0[18];
    _v_77 = _o_0[19];
    _v_78 = _o_0[20];
    _v_79 = _o_0[21];
    _v_80 = _o_0[22];
    _v_81 = _o_0[23];
    _v_82 = _o_0[24];
    _v_83 = _o_0[25];
    _v_32 = _v_58;
    _v_33 = _v_59;
    _v_34 = _v_60;
    _v_35 = _v_61;
    _v_36 = _v_62;
    _v_37 = _v_63;
    _v_38 = _v_64;
    _v_39 = _v_65;
    _v_40 = _v_66;
    _v_41 = _v_67;
    _v_42 = _v_68;
    _v_43 = _v_69;
    _v_44 = _v_70;
    _v_45 = _v_71;
    _v_46 = _v_72;
    _v_47 = _v_73;
    _v_48 = _v_74;
    _v_49 = _v_75;
    _v_50 = _v_76;
    _v_51 = _v_77;
    _v_52 = _v_78;
    _v_53 = _v_79;
    _v_54 = _v_80;
    _v_55 = _v_81;
    _v_56 = _v_82;
    _v_57 = _v_83;
    u32 _v_84 = 0;
    u32 _v_85 = 0;
    u32 _v_86 = 0;
    u32 _v_87 = 0;
    Term _v_88 = 0;
    u32 _v_89 = 0;
    Term _v_90 = 0;
    Term _v_91 = 0;
    Term _v_92 = 0;
    u32 _v_93 = 0;
    u32 _v_94 = 0;
    u32 _v_95 = 0;
    u32 _v_96 = 0;
    u32 _v_97 = 0;
    u32 _v_98 = 0;
    u32 _v_99 = 0;
    u32 _v_100 = 0;
    u32 _v_101 = 0;
    u32 _v_102 = 0;
    u32 _v_103 = 0;
    Term _v_104 = 0;
    Term _v_105 = 0;
    Term _v_106 = 0;
    u32 _v_107 = 0;
    u32 _v_108 = 0;
    u32 _v_109 = 0;
    u32 _v_110 = 0;
    u32 _v_111 = 0;
    Term _v_112 = 0;
    Term _v_113 = 0;
    u32 _v_114 = 0;
    Term _v_115 = 0;
    Term _o_1[32];
    if (spin_61(e, _o_1, _v_32, _v_33, _v_34, blk_loc(e.mem, _v_34), _v_35, _v_36, _v_37, blk_loc(e.mem, _v_37), _v_38, _v_39, _v_40, blk_loc(e.mem, _v_40), _v_41, blk_loc(e.mem, _v_41), _v_42, _v_43, _v_44, _v_45, _v_46, _v_47, _v_48, _v_49, _v_50, _v_51, _v_52, _v_53, blk_loc(e.mem, _v_53), _v_54, blk_loc(e.mem, _v_54), _v_55, blk_loc(e.mem, _v_55), _v_56, _v_57) == 0) {
      return 0;
    }
    _v_84 = _o_1[0];
    _v_85 = _o_1[1];
    _v_86 = _o_1[2];
    _v_87 = _o_1[3];
    _v_88 = _o_1[4];
    _v_89 = _o_1[5];
    _v_90 = _o_1[6];
    _v_91 = _o_1[7];
    _v_92 = _o_1[8];
    _v_93 = _o_1[9];
    _v_94 = _o_1[10];
    _v_95 = _o_1[11];
    _v_96 = _o_1[12];
    _v_97 = _o_1[13];
    _v_98 = _o_1[14];
    _v_99 = _o_1[15];
    _v_100 = _o_1[16];
    _v_101 = _o_1[17];
    _v_102 = _o_1[18];
    _v_103 = _o_1[19];
    _v_104 = _o_1[20];
    _v_105 = _o_1[21];
    _v_106 = _o_1[22];
    _v_107 = _o_1[23];
    _v_108 = _o_1[24];
    _v_109 = _o_1[25];
    _v_110 = _o_1[26];
    _v_111 = _o_1[27];
    _v_112 = _o_1[28];
    _v_113 = _o_1[29];
    _v_114 = _o_1[30];
    _v_115 = _o_1[31];
    _v_0 = _v_84;
    _v_1 = _v_85;
    _v_2 = _v_86;
    _v_3 = _v_87;
    _v_4 = _v_88;
    _v_5 = _v_89;
    _v_6 = _v_90;
    _v_7 = _v_91;
    _v_8 = _v_92;
    _v_9 = _v_93;
    _v_10 = _v_94;
    _v_11 = _v_95;
    _v_12 = _v_96;
    _v_13 = _v_97;
    _v_14 = _v_98;
    _v_15 = _v_99;
    _v_16 = _v_100;
    _v_17 = _v_101;
    _v_18 = _v_102;
    _v_19 = _v_103;
    _v_20 = _v_104;
    _v_21 = _v_105;
    _v_22 = _v_106;
    _v_23 = _v_107;
    _v_24 = _v_108;
    _v_25 = _v_109;
    _v_26 = _v_110;
    _v_27 = _v_111;
    _v_28 = _v_112;
    _v_29 = _v_113;
    _v_30 = _v_114;
    _v_31 = _v_115;
    if (_v_0 == 0) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 544);
      WL_RETN(1);
    } else {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_MAIN_K380;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_MAIN_K380, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_MAIN_K380, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_CHECKPOINT_0)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_EXPANDED_CHECKPOINT_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _v_1;
        e.mem[_t_1 + 1] = _v_2;
        e.mem[_t_1 + 2] = _v_3;
        e.mem[_t_1 + 3] = _v_4;
        e.mem[_t_1 + 4] = _v_5;
        e.mem[_t_1 + 5] = _v_6;
        e.mem[_t_1 + 6] = _v_7;
        e.mem[_t_1 + 7] = _v_8;
        e.mem[_t_1 + 8] = _v_9;
        e.mem[_t_1 + 9] = _v_10;
        e.mem[_t_1 + 10] = _v_11;
        e.mem[_t_1 + 11] = _v_12;
        e.mem[_t_1 + 12] = _v_13;
        e.mem[_t_1 + 13] = _v_14;
        e.mem[_t_1 + 14] = _v_15;
        e.mem[_t_1 + 15] = _v_16;
        e.mem[_t_1 + 16] = _v_17;
        e.mem[_t_1 + 17] = _v_18;
        e.mem[_t_1 + 18] = _v_19;
        e.mem[_t_1 + 19] = _v_20;
        e.mem[_t_1 + 20] = _v_21;
        e.mem[_t_1 + 21] = _v_22;
        e.mem[_t_1 + 22] = _v_23;
        e.mem[_t_1 + 23] = _v_24;
        e.mem[_t_1 + 24] = _v_25;
        e.mem[_t_1 + 25] = _v_26;
        e.mem[_t_1 + 26] = _v_27;
        e.mem[_t_1 + 27] = _v_28;
        e.mem[_t_1 + 28] = _v_29;
        e.mem[_t_1 + 29] = _v_30;
        e.mem[_t_1 + 30] = _v_31;
        e.mem[_t_1 + 31] = term_ctr(CID_SCON, STAT_OFF + 558);
        e.mem[_t_1 + 32] = term_pak(CID_SNIL, 0);
        return term_tsk(FID_CONSUMER_EXPANDED_CHECKPOINT_0, _t_1);
      }
      r0 = _v_1;
      r1 = _v_2;
      r2 = _v_3;
      r3 = _v_4;
      r4 = _v_5;
      r5 = _v_6;
      r6 = _v_7;
      r7 = _v_8;
      r8 = _v_9;
      r9 = _v_10;
      r10 = _v_11;
      r11 = _v_12;
      r12 = _v_13;
      r13 = _v_14;
      r14 = _v_15;
      r15 = _v_16;
      r16 = _v_17;
      r17 = _v_18;
      r18 = _v_19;
      r19 = _v_20;
      r20 = _v_21;
      r21 = _v_22;
      r22 = _v_23;
      r23 = _v_24;
      r24 = _v_25;
      r25 = _v_26;
      r26 = _v_27;
      r27 = _v_28;
      r28 = _v_29;
      r29 = _v_30;
      r30 = _v_31;
      r31 = term_ctr(CID_SCON, STAT_OFF + 558);
      r32 = term_pak(CID_SNIL, 0);
      WL_JMP(FID_CONSUMER_EXPANDED_CHECKPOINT_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K380)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    u32 _h_12 = r12;
    u32 _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    Term _h_19 = r19;
    Term _h_20 = r20;
    Term _h_21 = r21;
    u32 _h_22 = r22;
    u32 _h_23 = r23;
    u32 _h_24 = r24;
    u32 _h_25 = r25;
    u32 _h_26 = r26;
    Term _h_27 = r27;
    Term _h_28 = r28;
    u32 _h_29 = r29;
    Term _h_30 = r30;
    Term _h_31 = r31;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_EXPANDED_STEPS_0)) {
      u64 _t_2 = task_node(e, FID_CONSUMER_EXPANDED_STEPS_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = term_ctr(CID_CON, STAT_OFF + 831);
      e.mem[_t_2 + 1] = _h_0;
      e.mem[_t_2 + 2] = _h_1;
      e.mem[_t_2 + 3] = _h_2;
      e.mem[_t_2 + 4] = _h_3;
      e.mem[_t_2 + 5] = _h_4;
      e.mem[_t_2 + 6] = _h_5;
      e.mem[_t_2 + 7] = _h_6;
      e.mem[_t_2 + 8] = _h_7;
      e.mem[_t_2 + 9] = _h_8;
      e.mem[_t_2 + 10] = _h_9;
      e.mem[_t_2 + 11] = _h_10;
      e.mem[_t_2 + 12] = _h_11;
      e.mem[_t_2 + 13] = _h_12;
      e.mem[_t_2 + 14] = _h_13;
      e.mem[_t_2 + 15] = _h_14;
      e.mem[_t_2 + 16] = _h_15;
      e.mem[_t_2 + 17] = _h_16;
      e.mem[_t_2 + 18] = _h_17;
      e.mem[_t_2 + 19] = _h_18;
      e.mem[_t_2 + 20] = _h_19;
      e.mem[_t_2 + 21] = _h_20;
      e.mem[_t_2 + 22] = _h_21;
      e.mem[_t_2 + 23] = _h_22;
      e.mem[_t_2 + 24] = _h_23;
      e.mem[_t_2 + 25] = _h_24;
      e.mem[_t_2 + 26] = _h_25;
      e.mem[_t_2 + 27] = _h_26;
      e.mem[_t_2 + 28] = _h_27;
      e.mem[_t_2 + 29] = _h_28;
      e.mem[_t_2 + 30] = _h_29;
      e.mem[_t_2 + 31] = _h_30;
      e.mem[_t_2 + 32] = _h_31;
      return term_tsk(FID_CONSUMER_EXPANDED_STEPS_0, _t_2);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 831);
    r1 = _h_0;
    r2 = _h_1;
    r3 = _h_2;
    r4 = _h_3;
    r5 = _h_4;
    r6 = _h_5;
    r7 = _h_6;
    r8 = _h_7;
    r9 = _h_8;
    r10 = _h_9;
    r11 = _h_10;
    r12 = _h_11;
    r13 = _h_12;
    r14 = _h_13;
    r15 = _h_14;
    r16 = _h_15;
    r17 = _h_16;
    r18 = _h_17;
    r19 = _h_18;
    r20 = _h_19;
    r21 = _h_20;
    r22 = _h_21;
    r23 = _h_22;
    r24 = _h_23;
    r25 = _h_24;
    r26 = _h_25;
    r27 = _h_26;
    r28 = _h_27;
    r29 = _h_28;
    r30 = _h_29;
    r31 = _h_30;
    r32 = _h_31;
    WL_JMP(FID_CONSUMER_EXPANDED_STEPS_0);
  }}
#endif

  WL_CASE(FID_ENTER)
  {
    Term t = r0;
    WL_OPEN
    u32 f   = (u32)term_aux(t);
    u64 a   = term_loc(t);
    u32 war = fid_arity(f);
    WL_FRAME(t)
    seq |= fid_nofk(f) << 1;
    u32 rw = fid_resw(f);
    if (rw) {
      WL_LOAD(a + war - rw, rw)
      WL_ARGS(a, war - rw + 1)
    } else {
      WL_LOAD(a, war)
    }
    heap_free(e, cls_fit(war + 2), a);
    WL_DYN(f);
  }}

  WL_CASE(FID_IO_EMIT)
  {
    Term x = r0;
    WL_OPEN
    u64 l = heap_alloc(e, 0);
    e.mem[l] = x;
    r0 = term_ctr(CID_EMIT, l);
    WL_RETN(1);
  }}

  WL_CASE(FID_CLO_APPLY)
  {
    Term fun = r0;
    Term arg = r1;
    WL_OPEN
    u32 f    = (u32)term_aux(fun);
    u32 war  = fid_arity(f) - 1;
    u64 a    = term_loc(fun);
    WL_LOAD(a, war)
    spare_free(e, cls_fit(war), a);
    WL_LAST(arg)
    WL_DYN(f);
  }}

  WL_CASE(FID_EXIT)
  {
    u32  n = rn;
    Term rv[WL_RESW];
    WL_SAVE(rv)
    WL_OPEN
    if (err_seen(e.mem)) {
      return 0;
    }
    sp -= 2 * LANE_STEP;
    Term cont = STK(0);
    u32  idx  = (u32)STK(1);
    u32  wf   = (u32)term_aux(cont);
    if (cont != TERM_HOLE && fid_resw(wf)) {
      u64 wa = term_loc(cont);
      u32 wn = fid_arity(wf);
      WL_FRAME(cont)
      seq = (seq & 1) | fid_nofk(wf) << 1;
      WL_ARGS(wa, wn - n + 1)
      heap_free(e, cls_fit(wn + 2), wa);
      WL_TAKE(rv)
      WL_DYN(wf);
    }
    return task_deliver(e.mem, cont, idx, rv, n);
  }}

#if DEVICE
  default: {
    err_post(e.mem, ERR_FIDS);
    return 0;
  }
  }
  }
}
#endif

// Monk
// ====

// One turn on a ring: its head task below put0 runs (a growing
// lane skips a fork-free one). The host grows a row ring by
// ring and drains a ring; a device lane does both.
INLINE u32 monk_step(Env e, DEV Term* stk, u32 rg, u32 put0, u32 base, u32 stride,
  TG u32* cur) {
  DEV u64* H   = e.mem;
  bool     seq = stride == 0;
  DEV u32* get = ring_get(H, rg);
  if (*get == put0) {
    return 0;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, rg, *get);
  u32      hi = a32_load_acq(lo + 1);
  Term     t  = (((u64)hi << 32) | a32_load(lo)) & ~RFC_BIT;
  if ((hi >> 31) != ring_lap(*get) || (!seq && fid_nofk((u32)term_aux(t)))) {
    return 0;
  }
  a32_store(get, *get + 1);
  u32 spin = 0;
  for (;;) {
    Term r = work_loop(e, stk, t, seq);
    if (r == 0) {
      return 2;
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      if (err_spun(H, &spin)) {
        return 2;
      }
      if (stride != 0 && fid_nofk((u32)term_aux(r))) {
        ring_push(H, ring_pick(base, stride, cur), r);
        return 2;
      }
      t      = r;
      seq    = false;
      stride = 0;
      continue;
    }
    task_deal(H, r, base, stride, cur);
    return 1;
  }
}

// Dev
// ===

// One kernel: pass 0 grows the frontier, pass 1 drains each lane's ring,
// pass 2 packs the banks: in one group, each bank's [top, wr) slides onto
// rd, CUBE_T entries a step (loads, barrier, stores: rd <= top), off the
// host's pages. A grow pass ends when its group is full or nothing grew,
// so a spine of forks unrolls whole. TG_HOLD words of threadgroup memory
// hold one group per Apple core (bitonic 1.35x without).

#if DEVICE

INLINE void dev_cut(Env e) {
  if (err_seen(e.mem)) {
    return;
  }
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    u64 gen = (u64)KEEP(c) << c;
    while (ALC_LEN(e, c) >= gen) {
      u64 head = ALC_AT(e, c);
      u64 tail = head;
      for (u32 i = 1; i < KEEP(c); i += 1) {
        tail = e.mem[tail];
      }
      ALC_AT(e, c)    = e.mem[tail];
      ALC_LEN(e, c)  -= gen;
      e.mem[tail]     = 0;
      bank_push(e.mem, c, head);
    }
  }
}

INLINE void bank_pack(DEV u64* H, u32 lane) {
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    DEV Bank* b  = bank_at(H, c);
    u32       rd = b->rd;
    u32       n  = b->wr - b->top;
    for (u32 i = 0; i < n; i += CUBE_T) {
      Term v = i + lane < n ? H[b->off + b->top + i + lane] : 0;
      BAR();
      if (i + lane < n) {
        H[b->off + rd + i + lane] = v;
      }
    }
    BAR();
    if (lane == 0) {
      b->rd = b->wr = b->top = rd + n;
    }
  }
}

#ifdef __METAL_VERSION__
kernel void bend_dev(DEV u64* H [[buffer(0)]], constant u32& pass [[buffer(1)]],
  TG u32* vote [[threadgroup(0)]],
  u32 grids [[threadgroups_per_grid]],
  u32 row [[threadgroup_position_in_grid]],
  u32 lane [[thread_position_in_threadgroup]]) {
#else
extern "C" __global__ void bend_dev(DEV u64* H, u32 pass) {
  extern __shared__ u32 vote[];
  u32 grids = gridDim.x;
  u32 row   = blockIdx.x;
  u32 lane  = threadIdx.x;
#endif
  if (pass == 2) {
    bank_pack(H, lane);
    return;
  }
  u32  stride = grids == 1 ? CUBE_G : 1;
  u32  me     = row * CUBE_T + stride * lane;
  u32 rg     = pass ? ring_flip(me) : me;
  Env  e      = { H, H + ALC_OFF + me };
  DEV Term*  stk    = (DEV Term*)(H + STAK_OFF + me);
  if (lane == 0) {
    for (u32 i = 0; i < 3; i += 1) {
      a32_store(vote + i, 0);
    }
  }
  BAR();
  u32 put0      = a32_load(ring_put(H, rg));
  u32 seen_has  = 0;
  u32 seen_grew = 0;
  for (;;) {
    if (pass) {
      if (*ring_get(H, rg) == put0 || err_seen(H)) {
        break;
      }
    } else {
      put0 = a32_load(ring_put(H, rg));
      u32 has = put0 != a32_load(ring_get(H, rg));
      if (lane == 0 && (err_seen(H) || root_done(H))) {
        has = CUBE_T;
      }
      a32_add(vote + 2, has);
      BAR();
      has = a32_load(vote + 2);
      if (has - seen_has >= CUBE_T) {
        break;
      }
      seen_has = has;
    }
    u32 ran = monk_step(e, stk, rg, put0, row * CUBE_T, pass ? 0 : stride,
      vote);
    if (!pass) {
      if (ran == 1) {
        a32_add(vote + 1, 1);
      }
      BARD();
      u32 grew = a32_load(vote + 1);
      if (grew == seen_grew) {
        break;
      }
      seen_grew = grew;
    }
  }
  dev_cut(e);
}

#endif

// Window
// ======

// Linux's window fill (the Mac's is window_msl): an Image is a quadtree over
// 2^k x 2^k (Qua splits tl, tr, bl, br; Pix is 0xRRGGBB).
#if defined(__linux__) || defined(BEND_RTC)

INLINE u32 window_pix(DEV u64* H, Term t, u32 k, u32 x, u32 y) {
  for (u32 i = k; term_tag(t) == TAG_CTR;) {
    u32 j = 0;
    if (i > 0) {
      i -= 1;
      j = ((y >> i) & 1) * 2 + ((x >> i) & 1);
    }
    t = H[term_peek(H, t) + j];
  }
  return (u32)term_loc(t) & 0xFFFFFF;
}

#ifdef BEND_RTC
extern "C" __global__ void window_dev(DEV u64* H, Term root, u32 w, u32 h,
  u32 k, u32* out) {
  u32 x = blockIdx.x * blockDim.x + threadIdx.x;
  u32 y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x < w && y < h) {
    out[y * w + x] = window_pix(H, root, k, x, y);
  }
}
#endif

#endif

#if !DEVICE

// Row
// ===

static u32 row_grow(Env e, DEV Term* stk, u32 base, u32 stride, u32 want) {
  u64* H = e.mem;
  u32 cur = 0;
  for (;;) {
    u32 put0[CUBE_T];
    u32 has = 0;
    for (u32 i = 0; i < CUBE_T; i += 1) {
      put0[i] = *ring_put(H, base + i * stride);
      has += put0[i] != *ring_get(H, base + i * stride);
    }
    if (root_done(H) || has >= want) {
      return cur;
    }
    u32 grew = 0;
    u32 ran  = 0;
    for (u32 i = 0; i < CUBE_T && ran != 2; i += 1) {
      ran   = monk_step(e, stk, base + i * stride, put0[i], base, stride,
        &cur);
      grew += ran == 1;
    }
    if (grew == 0) {
      return cur;
    }
  }
}

// Pool
// ====

static void* pool_try(void* at, u64 bytes) {
  return mmap(at, bytes, PROT_READ | PROT_WRITE,
    MAP_PRIVATE | MAP_ANON | MAP_NORESERVE, -1, 0);
}

static void* pool_mmap(u64 bytes) {
  void* p = pool_try(NULL, bytes);
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static Term* pool_stack(void) {
  u64   len = 1ull << 31;
  char* p   = pool_mmap(len + 16384 + SIGSTKSZ);
  if (mprotect(p + len, 16384, PROT_NONE) != 0) {
    err_fail("stack guard failed");
  }
  stack_t ss = { .ss_sp = p + len + 16384, .ss_size = SIGSTKSZ };
  sigaltstack(&ss, NULL);
  struct sigaction sa = { .sa_handler = err_trap, .sa_flags = SA_ONSTACK };
  sigaction(SIGSEGV, &sa, NULL);
  sigaction(SIGBUS, &sa, NULL);
  return (Term*)p;
}

// A wait yields a while before it sleeps, so a turn that ends (or follows)
// within microseconds never pays a condvar wake.

#define POOL_WAIT(c, cv) \
  for (u32 s = 0; s < 128 && (c); s += 1) { \
    sched_yield(); \
  } \
  pthread_mutex_lock(&pool_lock); \
  while (c) { \
    pthread_cond_wait(&cv, &pool_lock); \
  } \
  pthread_mutex_unlock(&pool_lock);

static u32 pool_step(u32 rows) {
  u32 per = rows * CUBE_T / (32 * pool_size);
  return CUBE_T >> (31 - CLZ(per < LINE ? per | 1 : LINE));
}

static u32 pool_rows(Env e, DEV Term* stk) {
  u32 n = 0;
  for (;;) {
    u32 c    = a32_add(&pool_row, 1);
    u32 r    = c & 32767;
    u32 rows = c >> 15 & 255;
    u32 step = c >> 23 & 1 ? 1 : pool_step(rows);
    if (r >= rows * step) {
      if (n != 0 && a32_sub_rel(&pool_done, n) == n) {
        pthread_mutex_lock(&pool_lock);
        pthread_cond_signal(&pool_join);
        pthread_mutex_unlock(&pool_lock);
      }
      return c >> 24;
    }
    a32_acq(&pool_row);
    if (c >> 23 & 1) {
      row_grow(e, stk, r * CUBE_T, 1, CUBE_T);
    } else {
      u32 row = r / step * CUBE_T;
      for (u32 rg = row + r % step; rg < row + CUBE_T; rg += step) {
        u32 put0 = a32_load(ring_put(e.mem, rg));
        while (*ring_get(e.mem, rg) != put0 && !err_seen(e.mem)) {
          monk_step(e, stk, rg, put0, rg, 0, NULL);
        }
      }
    }
    n += 1;
  }
}

static void* pool_work(void* arg) {
  Term* stk  = pool_stack();
  u32   seen = 0;
  for (;;) {
    POOL_WAIT(a32_load(&pool_row) >> 24 == seen, pool_wake)
    seen = pool_rows((Env){ CORPUS, ALC[(uintptr_t)arg] }, stk);
  }
}

OUTLINE void pool_open(void) {
  static bool up;
  if (up) {
    return;
  }
  up = true;
  for (u32 w = 1; w < pool_size; w += 1) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, pool_work, (void*)(uintptr_t)w)) {
      err_fail("pthread_create");
    }
  }
}

static int cpu_read(const char* path, long* a, long* b) {
  FILE* f = fopen(path, "r");
  if (f == NULL) {
    return 0;
  }
  int n = fscanf(f, "%ld %ld", a, b);
  fclose(f);
  return n;
}

static long cpu_count(void) {
  long n = sysconf(_SC_NPROCESSORS_ONLN);
#ifdef __linux__
  cpu_set_t set;
  if (sched_getaffinity(0, sizeof set, &set) == 0) {
    n = CPU_COUNT(&set);
  }
  long q = 0;
  long p = 0;
  if (cpu_read("/sys/fs/cgroup/cpu.max", &q, &p) != 2) {
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_quota_us", &q, &p);
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_period_us", &p, &p);
  }
  if (q > 0 && p > 0 && (q + p - 1) / p < n) {
    n = (q + p - 1) / p;
  }
#endif
  return n;
}

OUTLINE void pool_turn(bool grow, u32 rows) {
  static u32 turn;
  u32 n = rows < CUBE_G ? rows : CUBE_G;
  turn += 1;
  a32_store(&pool_done, grow ? n : n * pool_step(n));
  pthread_mutex_lock(&pool_lock);
  a32_store_rel(&pool_row, turn << 24 | grow << 23 | n << 15);
  pthread_cond_broadcast(&pool_wake);
  pthread_mutex_unlock(&pool_lock);
  pool_rows((Env){ CORPUS, ALC[0] }, io_stk);
  POOL_WAIT(a32_load_acq(&pool_done) != 0, pool_join)
}

// Gpu
// ===

// gpu_make compiles the device program into <binary>.gpu
// (--gpu-build): Metal's binary archive, or CUDA's cubin behind a
// hash of the text. A launch loads it, else notes and compiles. CUDA
// shapes the bag by the device: a group of 128 lanes per 64 KB of
// L2, a power of two in 16..128 (Apple keeps the tuned 128). CUDA
// runs one stream: the default 8 cost about half of the startup.

static const char* gpu_path(void) {
  static char path[4096];
  u32 n = sizeof path - 8;
#ifdef __APPLE__
  _NSGetExecutablePath(path, &n);
#else
  path[readlink("/proc/self/exe", path, n)] = 0;
#endif
  return strcat(path, ".gpu");
}

static void gpu_note(const char* path) {
  fprintf(stderr, "bend: compiling the GPU program (%s is missing or"
    " stale)\n", path);
}

#if !BEND_CUDA
#define gpu_map pool_mmap
#endif

#if BEND_METAL || BEND_CUDA

static void gpu_kernel(u32 pass, u32 groups);

static void gpu_run(u32 f) {
  if (f < CUBE_T) {
    gpu_kernel(0, 1);
  }
  if (f < LANES) {
    gpu_kernel(0, CUBE_G);
  }
  gpu_kernel(1, CUBE_G);
  gpu_kernel(2, 1);
}

#endif

#if BEND_CUDA

static u64 gpu_hash(void) {
  u64 key = 14695981039346656037ull ^ CUBE_LOG;
  for (const char* p = BEND_SRC; *p != 0; p += 1) {
    key = (key ^ (u8)*p) * 1099511628211ull;
  }
  return key;
}

#endif

#if BEND_METAL

static void gpu_fail(NSError* err) {
  err_fail([[err localizedDescription] UTF8String]);
}

static bool gpu_probe(void) {
  return (gpu_dev = MTLCreateSystemDefaultDevice()) != nil;
}

static MTLComputePipelineDescriptor* gpu_desc(void) {
  NSError* err = nil;
  MTLCompileOptions* opts = [MTLCompileOptions new];
  opts.mathMode = MTLMathModeSafe;
  opts.preprocessorMacros = @{ @"CUBE_LOG": @(CUBE_LOG) };
  id<MTLLibrary> lib = [gpu_dev newLibraryWithSource:@(BEND_SRC) options:opts
    error:&err];
  if (!lib) {
    gpu_fail(err);
  }
  MTLComputePipelineDescriptor* d = [MTLComputePipelineDescriptor new];
  d.computeFunction = [lib newFunctionWithName:@"bend_dev"];
  return d;
}

static bool gpu_make(const char* path) {
  NSError* err = nil;
  id<MTLBinaryArchive> ar = [gpu_dev
    newBinaryArchiveWithDescriptor:[MTLBinaryArchiveDescriptor new] error:&err];
  if (![ar addComputePipelineFunctionsWithDescriptor:gpu_desc() error:&err]) {
    gpu_fail(err);
  }
  return [ar serializeToURL:[NSURL fileURLWithPath:@(path)] error:&err];
}

static id<MTLComputePipelineState> gpu_pipe(MTLComputePipelineDescriptor* d,
  id<MTLBinaryArchive> ar) {
  NSError* err = nil;
  d.binaryArchives = ar ? @[ar] : @[];
  id<MTLComputePipelineState> pso = [gpu_dev
    newComputePipelineStateWithDescriptor:d
    options:ar ? MTLPipelineOptionFailOnBinaryArchiveMiss : 0 reflection:nil
    error:&err];
  if (!pso && !ar) {
    gpu_fail(err);
  }
  return pso;
}

static u64 gpu_span(void) {
  u64 span = [gpu_dev recommendedMaxWorkingSetSize];
  u64 most = [gpu_dev maxBufferLength];
  span = span < most ? span : most;
  return span < (2ull << 30) ? span : 2ull << 30;
}

static void gpu_load(u64 bytes) {
  gpu_buf = [gpu_dev newBufferWithBytesNoCopy:CORPUS length:bytes
    options:MTLResourceStorageModeShared
      | MTLResourceHazardTrackingModeUntracked deallocator:nil];
  u64 most = [gpu_dev maxBufferLength];
  if (!gpu_buf && bytes > most) {
    char msg[96];
    snprintf(msg, sizeof msg, "--gpu %lluMB is over the device's %lluMB",
      (unsigned long long)(bytes >> 20), (unsigned long long)(most >> 20));
    err_fail(msg);
  }
  if (!gpu_buf) {
    err_fail("the GPU span is more than the device has");
  }
  @autoreleasepool {
    gpu_que = [gpu_dev newCommandQueue];
    const char* path = gpu_path();
    MTLBinaryArchiveDescriptor* ad = [MTLBinaryArchiveDescriptor new];
    ad.url = [NSURL fileURLWithPath:@(path)];
    MTLComputePipelineDescriptor* d = gpu_desc();
    id<MTLBinaryArchive> ar = [gpu_dev newBinaryArchiveWithDescriptor:ad
      error:nil];
    gpu_pso = ar ? gpu_pipe(d, ar) : nil;
    if (!gpu_pso) {
      gpu_note(path);
      gpu_pso = gpu_pipe(d, nil);
    }
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  [gpu_enc setComputePipelineState:gpu_pso];
  [gpu_enc setBuffer:gpu_buf offset:0 atIndex:0];
  [gpu_enc setBytes:&pass length:sizeof pass atIndex:1];
  [gpu_enc setThreadgroupMemoryLength:TG_HOLD * 8 atIndex:0];
  [gpu_enc dispatchThreadgroups:MTLSizeMake(groups, 1, 1)
    threadsPerThreadgroup:MTLSizeMake(CUBE_T, 1, 1)];
  [gpu_enc memoryBarrierWithScope:MTLBarrierScopeBuffers];
}

static void gpu_pass(u32 f) {
  @autoreleasepool {
    id<MTLCommandBuffer> cb = [gpu_que commandBuffer];
    gpu_enc = [cb computeCommandEncoder];
    gpu_run(f);
    [gpu_enc endEncoding];
    [cb commit];
    [cb waitUntilCompleted];
    if ([cb error]) {
      gpu_fail([cb error]);
    }
  }
}

#elif BEND_CUDA

static void gpu_shape(int units) {
  CUBE_LOG = 31 - CLZ(units < 16 ? 16 : units > 128 ? 128 : units);
}

static bool gpu_probe(void) {
  int       managed = 0;
  CUcontext ctx;
  setenv("CUDA_DEVICE_MAX_CONNECTIONS", "1", 0);
  if (cuInit(0) == CUDA_SUCCESS && cuDeviceGet(&gpu_dev, 0) == CUDA_SUCCESS) {
    cuDeviceGetAttribute(&managed,
      CU_DEVICE_ATTRIBUTE_CONCURRENT_MANAGED_ACCESS, gpu_dev);
  }
  int l2 = 1 << 23;
  cuDeviceGetAttribute(&l2, CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE, gpu_dev);
  gpu_shape(l2 >> 16);
  return managed != 0
    && cuDevicePrimaryCtxRetain(&ctx, gpu_dev) == CUDA_SUCCESS
    && cuCtxSetCurrent(ctx) == CUDA_SUCCESS;
}

static u64* gpu_map(u64 bytes) {
  CUdeviceptr p = 0;
  if (cuMemAllocManaged(&p, bytes, CU_MEM_ATTACH_GLOBAL) != CUDA_SUCCESS) {
    err_fail("corpus reservation failed");
  }
#if CUDA_VERSION >= 13000
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION,
    (CUmemLocation){ CU_MEM_LOCATION_TYPE_DEVICE, gpu_dev });
#else
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION, gpu_dev);
#endif
  return (u64*)(uintptr_t)p;
}

static bool gpu_make(const char* path) {
  int cc[2] = {0, 0};
  cuDeviceGetAttribute(cc,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR, gpu_dev);
  cuDeviceGetAttribute(cc + 1,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR, gpu_dev);
  char arch[40];
  char bag[24];
  snprintf(arch, sizeof arch, "--gpu-architecture=sm_%d%d", cc[0], cc[1]);
  snprintf(bag, sizeof bag, "-DCUBE_LOG=%u", CUBE_LOG);
  const char* opts[] = { arch, bag, "--fmad=false", "-default-device" };
  nvrtcProgram prog;
  if (nvrtcCreateProgram(&prog, BEND_SRC, "bend.cu", 0, NULL, NULL)
    != NVRTC_SUCCESS) {
    err_fail("cannot compile the CUDA library");
  }
  if (nvrtcCompileProgram(prog, 4, opts) != NVRTC_SUCCESS) {
    size_t n = 0;
    nvrtcGetProgramLogSize(prog, &n);
    char* log = calloc(n + 1, 1);
    if (log != NULL && nvrtcGetProgramLog(prog, log) == NVRTC_SUCCESS) {
      fprintf(stderr, "%s\n", log);
    }
    err_fail("cannot compile the CUDA library");
  }
  size_t len = 0;
  nvrtcGetCUBINSize(prog, &len);
  char* bin = malloc(len);
  if (bin == NULL || nvrtcGetCUBIN(prog, bin) != NVRTC_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  nvrtcDestroyProgram(&prog);
  u64   key = gpu_hash();
  FILE* out = path == NULL ? NULL : fopen(path, "wb");
  bool  ok  = out != NULL && fwrite(&key, 8, 1, out) == 1
    && fwrite(bin, 1, len, out) == len && fclose(out) == 0;
  if (cuModuleLoadData(&gpu_lib, bin) != CUDA_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  free(bin);
  return path == NULL || ok;
}

static u64 gpu_span(void) {
  size_t span = 0;
  cuDeviceTotalMem(&span, gpu_dev);
  return span;
}

static void gpu_load(u64 bytes) {
  const char* path = gpu_path();
  int         fd   = open(path, O_RDONLY);
  struct stat st   = { 0 };
  u64         key  = 0;
  char*       bin  = fd < 0 || fstat(fd, &st) != 0 || st.st_size <= 8 ? NULL
    : mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
  if (bin != NULL && bin != MAP_FAILED) {
    memcpy(&key, bin, 8);
  }
  if (key != gpu_hash()
    || cuModuleLoadData(&gpu_lib, bin + 8) != CUDA_SUCCESS) {
    gpu_note(path);
    gpu_make(path);
  }
  if (cuModuleGetFunction(&gpu_pso, gpu_lib, "bend_dev") != CUDA_SUCCESS) {
    err_fail("cannot load the GPU program");
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  void* args[] = { &CORPUS, &pass };
  if (cuLaunchKernel(gpu_pso, groups, 1, 1, CUBE_T, 1, 1, TG_HOLD * 8, NULL,
    args, NULL) != CUDA_SUCCESS) {
    err_fail("device launch failed");
  }
}

static void gpu_pass(u32 f) {
  gpu_run(f);
  if (cuCtxSynchronize() != CUDA_SUCCESS) {
    err_fail("device fault");
  }
}

#else

#define gpu_probe() false
#define gpu_make(p) true
#define gpu_span()  0
#define gpu_load(b)
#define gpu_pass(f)

#endif

// Cube
// ====

// The host's column grows to the rows that give a LINE of tasks a thread,
// no more: every task a grow starts early is live at once (tree-matmul's
// 2048 at 16 threads start 384 rounds: 15 MB -> 68 MB), and pool_step
// splits the few rows finely instead. A turn visits only the rows below
// its bound: a drain deals task g to ring_flip(g), whose row is at most g,
// a row grows into itself, and a column grow's cur tasks land in rows 0
// to cur - 1, so those rows hold every task.

// Between turns, each ring's pending tasks move back to slot 0.

static void ring_rewind(u64* H, u32 rows) {
  Term keep[RING_LEN];
  for (u32 r = 0; r < (rows < CUBE_G ? rows : CUBE_G) * CUBE_T; r += 1) {
    u32 g = *ring_get(H, r);
    u32 n = *ring_put(H, r) - g;
    if (g == 0 || n > RING_LEN) {
      continue;
    }
    for (u32 i = 0; i < n; i += 1) {
      keep[i] = *ring_slot(H, r, g + i) & ~RFC_BIT;
    }
    for (u32 i = n; i < g + n && i < RING_LEN; i += 1) {
      ((u32*)ring_slot(H, r, i))[1] = 0;
    }
    *ring_get(H, r) = *ring_put(H, r) = 0;
    for (u32 i = 0; i < n; i += 1) {
      ring_push(H, r, keep[i]);
    }
  }
}

static void cube_run(u64* H, bool gpu) {
  for (;;) {
    u32 f = a32_exch(a32_at(H, H_CURSOR), 0);
    if (root_done(H)) {
      return;
    }
    if (f == 0) {
      err_fail("frontier drained without a result");
    }
    if (gpu) {
      gpu_pass(f);
    } else {
      u32 rows = f;
      u32 want = (pool_size - 1) / (CUBE_T / LINE) + 1;
      if (f < want) {
        u32 cur = row_grow((Env){ H, ALC[0] }, io_stk, 0, CUBE_G, want);
        rows = cur > f ? cur : f;
      }
      if (f < CUBE) {
        pool_turn(true, rows);
      }
      f = a32_load(a32_at(H, H_CURSOR));
      pool_turn(false, f > rows ? f : rows);
      f = a32_load(a32_at(H, H_CURSOR));
      ring_rewind(H, f > rows ? f : rows);
    }
    u32 ec = a32_load(a32_at(H, H_ERROR_CODE));
    if (ec != 0) {
      err_post(H, ec);
    }
  }
}

// Corpus
// ======

// The cores map 8 GiB at a high base and double it in place, so one
// base holds every location; the banks move up past the pages. The GPU maps
// its whole span at once, and never grows it.

static u64 corpus_size;

static void* corpus_map(u64 size) {
  u64   hint = 1ull << 45;
  void* p    = pool_try((void*)hint, size);
  while (p != (void*)hint && hint > size) {
    if (p != MAP_FAILED) {
      munmap(p, size);
    }
    hint /= 2;
    p     = pool_try((void*)hint, size);
  }
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static void corpus_lay(u64* H, u64 size) {
  u64 span = size / 8;
  u64 cap  = span > HEAP_OFF ? (span - HEAP_OFF) / (PAGE_LEN + 10) : 0;
  if (cap <= CUBE) {
    err_fail("the GPU span is under the rings, stacks and a page per lane");
  }
  cap = cap < ~0u ? cap : ~0u - 1;
  u64 at = HEAP_OFF + (cap << PAGE_BITS);
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    Bank* b = bank_at(H, c);
    memcpy(H + at, H + b->off, b->wr * sizeof(u64));
    b->off  = at;
    at     += 2 * (cap >> ((c < NCLS ? NCLS : c) - PAGE_BITS));
  }
  corpus_size = size;
  a32_store_rel(a32_at(H, H_CAP), (u32)cap);
}

static bool corpus_grow(u64* H, u64 need) {
  bool ok = true;
  LOCK(bank_lock);
  while (ok && need > a32_load(a32_at(H, H_CAP))) {
    u64   more = corpus_size;
    char* at   = (char*)H + more;
    void* got  = io_gpu || more >= 1ull << 43 ? MAP_FAILED
      : pool_try(at, more);
    ok = got == at;
    if (ok) {
      corpus_lay(H, more * 2);
    } else if (got != MAP_FAILED) {
      munmap(got, more);
    }
  }
  UNLOCK(bank_lock);
  return ok;
}

static u64* corpus_setup(bool gpu, long threads, u64 bytes) {
  io_gpu     = gpu;
  KEEP_WORDS = gpu ? CHUNK : CAP_WORDS;
  u64 dflt   = gpu ? gpu_span() : 1ull << 33;
  u64 size   = (gpu && bytes != 0 ? bytes : dflt) & ~16383ull;
  CORPUS     = gpu ? gpu_map(size) : corpus_map(size);
  u64* H     = CORPUS;
#if BEND_CUDA
  if (gpu) {
    cuMemsetD8((CUdeviceptr)(uintptr_t)H, 0, STAK_OFF * 8);
    cuCtxSynchronize();
  }
#endif
  corpus_lay(H, size);
  memcpy(H + STAT_OFF, STAT_IMG, STAT_LEN * sizeof(u64));
  a32_store(a32_at(H, H_BUMP), 1);
  if (gpu) {
    gpu_load(size);
  }
  pool_size = threads < 1 ? 1 : threads < CUBE_T ? threads : CUBE_T;
  return H;
}

OUTLINE Term corpus_eval(u64* H, Term t) {
  Env  e = { H, ALC[0] };
  Term rv[WL_RESW];
  for (;;) {
    Term r = work_loop(e, io_stk, t, !BANGS && pool_size == 1);
    if (r == 0) {
      if (root_done(H)) {
        break;
      }
      err_fail("solo delivery lost");
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      t = r;
      if (io_gpu && fid_bangs((u32)term_aux(t))) {
        u64  tl   = task_tail(t);
        Term cont = H[tl];
        u32  idx  = (u32)(H[tl + 1] >> 32) & 0xFFFF;
        H[tl]     = TERM_HOLE;
        a32_store(a32_at(H, H_CURSOR), 1);
        ring_push(H, 0, t);
        cube_run(H, true);
        Term p = task_deliver(H, cont, idx, rv, root_take(H, rv));
        if (root_done(H)) {
          break;
        }
        if (p == 0) {
          err_fail("seam delivery lost");
        }
        t = p;
      }
      continue;
    }
    task_deal(H, r, 0, 0, NULL);
    pool_open();
    cube_run(H, false);
    break;
  }
  root_take(H, rv);
  return rv[0];
}

// Io
// ==

// Base's opaque, linear handles pack host fds or pointers into aux and loc:
// no forging, copying, reuse or host wrapper. A request's cont applied to
// its item is the next request. A parked request keeps its fd, deadline and
// readiness in word, time and evts; the loop then calls pack: a value
// resumes, IO_PARK parks again. The edge is UTF-8, decoded as WHATWG does: a
// broken sequence yields one U+FFFD and its breaking byte is read again as a
// lead. inet_aton reads a leading zero as octal, so io_sys_addr refuses it.
// macOS poll misses FIFO EOF, so io_wait selects, its sets sized to the
// highest fd (_DARWIN_UNLIMITED_SELECT allows fds past FD_SETSIZE).

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define IO_READ 1
#define IO_TIME 2
#define IO_PARK TERM_HOLE

#define io_hand(v)   term_make(TAG_PAK, (u64)(v) >> 40, (u64)(v) & LOC_MASK)
#define io_hand_v(t) (((u64)term_aux(t) << 40) | term_loc(t))

struct IoWork;
typedef void (*IoCall)(struct IoWork* w);
typedef Term (*IoPack)(Env e, struct IoWork* w);

typedef struct IoWork {
  intptr_t       hand;
  intptr_t       made;
  u32            word;
  u64            size;
  char*          data;
  char*          text;
  u32            code;
  IoCall         call;
  IoPack         pack;
  Term           cont;
  Term           item;
  u64            time;
  short          evts;
  struct IoWork* next;
} IoWork;

typedef Term (*Effect)(Env e, Term* f, IoWork* w);

typedef struct {
  Effect run;
  u32    ask;
} IoEff;

static IoEff io_eff_rows[1 << 16];
static u32   io_live;

static u64 io_tick(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}

OUTLINE void* io_mem(void* mem) {
  if (mem == NULL) {
    err_fail("host allocation failed");
  }
  return mem;
}

static int io_sys_addr(const char* host, u32 port, struct sockaddr_in* at) {
  memset(at, 0, sizeof(*at));
  at->sin_family = AF_INET;
  at->sin_port   = htons((uint16_t)port);
  for (const char* p = host; *p != 0; p += 1) {
    if ((p == host || p[-1] == '.') && *p == '0'
      && p[1] >= '0' && p[1] <= '9') {
      return -1;
    }
  }
  return port > 65535 || inet_pton(AF_INET, host, &at->sin_addr) != 1
    ? -1 : 0;
}

static int    io_argc;
static char** io_argv;

static void io_eff(u32 cid, Effect run, u32 need) {
  if (io_eff_rows[cid].run != NULL) {
    err_fail("two effects register one request");
  }
  io_eff_rows[cid] = (IoEff){ run, need };
}

static u64 io_sys_end(IoWork* w, ssize_t n) {
  w->code = n < 0 ? (u32)errno : 0;
  return n < 0 ? 0 : (u64)n;
}

static IoWork* io_runs;
static IoWork* io_park;
static IoWork* io_jobs;

static void io_push(IoWork** q, IoWork* a) {
  IoWork* l = *q != NULL ? *q : a;
  a->next = l->next;
  l->next = a;
  *q      = a;
}

static IoWork* io_pop(IoWork** q) {
  IoWork* a  = (*q)->next;
  (*q)->next = a->next;
  *q         = a != *q ? *q : NULL;
  return a;
}

static void io_spawn(Term m) {
  IoWork* a = io_mem(calloc(1, sizeof(IoWork)));
  a->cont  = m;
  a->item  = term_clo(FID_IO_EMIT, 0);
  io_push(&io_runs, a);
  io_live += 1;
}

// io_park stays in deadline order (time 0, none, sorts last; ties keep
// their park order), so io_wait wakes due timers in the order they expire.
static void io_park_add(IoWork* w) {
  IoWork* p = io_park;
  if (p == NULL || p->time - 1 <= w->time - 1) {
    io_push(&io_park, w);
    return;
  }
  while (p->next->time - 1 <= w->time - 1) {
    p = p->next;
  }
  io_push(&p, w);
}

static Term io_wait_on(IoWork* w, int fd, short evts, u64 time, IoPack more) {
  w->word = (u32)fd;
  w->pack = more;
  w->time = time;
  w->evts = evts;
  io_park_add(w);
  return IO_PARK;
}

OUTLINE void io_out(FILE* h, const char* data, u64 len) {
  if (fwrite(data, 1, len, h) != len) {
    err_fail("a short write on a standard stream");
  }
}

OUTLINE void io_sync(void) {
  if (fflush(stdout) != 0) {
    err_fail("a short write on a standard stream");
  }
}

static u64 io_utf8(char* buf, u64 c) {
  u64 k = c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
  for (u64 i = k; i > 1; i -= 1) {
    buf[i - 1] = (char)(0x80 | (c & 0x3F));
    c >>= 6;
  }
  buf[0] = (char)(k == 1 ? c : (0xF00 >> k) | c);
  return k;
}

// io_cbuf writes a String (cons SCon) as UTF-8, or a List (cons Con) as
// its bytes, with no UTF-8: NULL if a value is past 255.
OUTLINE char* io_cbuf(Env e, Term s, u64* len, u64 cons) {
  u64   cap = 64;
  u64   n   = 0;
  u64   bad = 0;
  char* buf = io_mem(malloc(cap));
  while (term_aux(s) == cons) {
    Term fb[2];
    spare_free(e, cls_fit(2), ctr_take(e, s, 2, fb));
    if (n + 5 > cap) {
      cap *= 2;
      buf = io_mem(realloc(buf, cap));
    }
    if (cons == CID_SCON) {
      n += io_utf8(buf + n, fb[0]);
    } else {
      bad |= fb[0] > 255;
      buf[n++] = (char)fb[0];
    }
    s = fb[1];
  }
  buf[n] = 0;
  *len = n;
  if (bad) {
    free(buf);
    return NULL;
  }
  return buf;
}

#define io_cstr(e, s, len) io_cbuf(e, s, len, CID_SCON)

OUTLINE void io_errs(Env e, Term s) {
  u64   n    = 0;
  char* text = io_cstr(e, s, &n);
  io_sync();
  io_out(stderr, text, n);
  io_out(stderr, "\n", 1);
  free(text);
}

#define io_nul(s, n) (strlen(s) != (n))

#define io_seal(e, t, cid) (cid_hot(cid) ? rfc_seal(e, t) : (t))

static Term io_node(Env e, u64 cid, Term a, Term b) {
  u64 l = heap_alloc(e, 1);
  e.mem[l]     = io_seal(e, a, cid);
  e.mem[l + 1] = io_seal(e, b, cid);
  return term_ctr(cid, l);
}

static Term io_str(Env e, const char* p, u64 n) {
  Term s    = term_pak(CID_SNIL, 0);
  u64  hole = 0;
  u64  c = 0, need = 0, lo = 0x80, hi = 0xBF;
  for (u64 i = 0; i < n || need > 0; i += 1) {
    u64 b = i < n ? (uint8_t)p[i] : 0x100;
    if (need > 0 && (b < lo || b > hi)) {
      need = 0;
      c    = 0xFFFD;
      i   -= 1;
    } else if (need > 0) {
      lo = 0x80;
      hi = 0xBF;
      c  = (c << 6) | (b & 0x3F);
      if (--need > 0) {
        continue;
      }
    } else if (b < 0x80) {
      c = b;
    } else if (b < 0xC2 || b > 0xF4) {
      c = 0xFFFD;
    } else {
      need = b < 0xE0 ? 1 : b < 0xF0 ? 2 : 3;
      lo   = b == 0xE0 ? 0xA0 : b == 0xF0 ? 0x90 : 0x80;
      hi   = b == 0xED ? 0x9F : b == 0xF4 ? 0x8F : 0xBF;
      c    = b & (0x3F >> need);
      continue;
    }
    u64  l = heap_alloc(e, 1);
    Term t = term_ctr(CID_SCON, l);
    e.mem[l] = c;
    if (hole == 0) {
      s = t;
    } else {
      e.mem[hole] = io_seal(e, t, CID_SCON);
    }
    hole = l + 1;
  }
  if (hole != 0) {
    e.mem[hole] = io_seal(e, term_pak(CID_SNIL, 0), CID_SCON);
  }
  return s;
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8.
#ifdef CID_CON

static Term io_list(Env e, const char* p, u64 n) {
  Term xs = term_pak(CID_NIL, 0);
  for (u64 i = n; i > 0; i -= 1) {
    xs = io_node(e, CID_CON, (uint8_t)p[i - 1], xs);
  }
  return xs;
}

#endif

#define io_tup(e, a, b) io_node(e, CID_TUPLE, a, b)
#define io_done(e, v)   io_box(e, CID_DONE, v)
#define io_res(e, w, v) ((w)->code ? io_fail(e, (w)->code, NULL) \
  : io_done(e, v))

static Term io_box(Env e, u64 cid, Term v) {
  u64 l = heap_alloc(e, 0);
  e.mem[l] = io_seal(e, v, cid);
  return term_ctr(cid, l);
}

static Term io_fail(Env e, u32 code, const char* text) {
  const char* s = text != NULL ? text : strerror((int)code);
  Term t = io_tup(e, code, io_str(e, s, strlen(s)));
  return io_box(e, CID_FAIL, t);
}

static pthread_mutex_t io_gate = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  io_bell = PTHREAD_COND_INITIALIZER;
static u32             io_busy;
static u32             io_size;
static int             io_wake_fd[2];

static void io_take(Env e) {
  IoWork* acts[64];
  ssize_t n;
  while ((n = read(io_wake_fd[0], acts, sizeof acts)) > 0) {
    for (u32 i = 0; i < (u32)n / sizeof(IoWork*); i += 1) {
      IoWork* a = acts[i];
      a->item   = a->pack(e, a);
      io_push(&io_runs, a);
      io_busy -= 1;
    }
  }
}

static void* io_help(void* arg) {
  for (;;) {
    pthread_mutex_lock(&io_gate);
    while (io_jobs == NULL) {
      pthread_cond_wait(&io_bell, &io_gate);
    }
    IoWork* a = io_pop(&io_jobs);
    pthread_mutex_unlock(&io_gate);
    a->call(a);
    while (write(io_wake_fd[1], &a, sizeof a) != sizeof a) {
    }
  }
}

static Term io_work(IoWork* w, IoCall call, IoPack pack) {
  w->call  = call;
  w->pack  = pack;
  io_busy += 1;
  if (io_busy > io_size && io_size < IO_HELP) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, io_help, NULL)) {
      err_fail("pthread_create");
    }
    pthread_detach(tid);
    io_size += 1;
  }
  pthread_mutex_lock(&io_gate);
  io_push(&io_jobs, w);
  pthread_cond_signal(&io_bell);
  pthread_mutex_unlock(&io_gate);
  return IO_PARK;
}

static Term io_exec(Env e, IoWork* w) {
  Term fs[256];
  u32  c = (u32)term_aux(w->cont);
  u32  n = cid_arity(c);
  spare_free(e, cls_fit(n), ctr_take(e, w->cont, n, fs));
  w->cont = fs[n - 1];
  return io_eff_rows[c].run(e, fs, w);
}

static bool io_bit(u8* set, int fd, bool put) {
  u8* at = set + fd / 8;
  *at |= put << fd % 8;
  return *at >> fd % 8 & 1;
}

static void io_wait(Env e, bool block) {
  int top  = io_wake_fd[0];
  u64 soon = io_park != NULL ? io_park->next->time : 0;
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0 && (int)a->word > top) {
      top = (int)a->word;
    }
  }
  u64 len = (u64)top / 64 * 8 + 8;
  u8* set[2] = { io_mem(calloc(2, len)), NULL };
  set[1] = set[0] + len;
  io_bit(set[0], io_wake_fd[0], true);
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0) {
      io_bit(set[a->evts == POLLOUT], (int)a->word, true);
    }
  }
  u64 tick = io_tick();
  u64 ms = soon > tick && block ? (soon - tick) / 1000000 + 1 : 0;
  struct timeval tv = { ms / 1000, ms % 1000 * 1000 };
  io_sync();
  if (select(top + 1, (fd_set*)set[0], (fd_set*)set[1], NULL,
    soon == 0 && block ? NULL : &tv) < 0) {
    if (errno != EINTR) {
      err_fail("the poller failed");
    }
    memset(set[0], 0, 2 * len);
  }
  if (io_bit(set[0], io_wake_fd[0], false)) {
    io_take(e);
  }
  u64     now  = io_tick();
  IoWork* todo = io_park;
  io_park = NULL;
  while (todo != NULL) {
    IoWork* a   = io_pop(&todo);
    bool    due = (a->evts != 0
        && io_bit(set[a->evts == POLLOUT], (int)a->word, false))
      || (a->time != 0 && a->time <= now);
    if (!due) {
      io_park_add(a);
      continue;
    }
    Term x = a->pack(e, a);
    if (x != IO_PARK) {
      a->item = x;
      io_push(&io_runs, a);
    }
  }
  free(set[0]);
}

static int f32_text(char* buf, f32 v) {
  int n = 0;
  int p = 0;
  if (v != v) {
    return sprintf(buf, "nan");
  }
  for (; p < 9; p += 1) {
    n = snprintf(buf, 40, "%.*e", p, (double)v);
    if (strtof(buf, NULL) == v) {
      break;
    }
  }
  char* ep = strchr(buf, 'e');
  if (ep == NULL) {
    return n;
  }
  int ex = atoi(ep + 1);
  if (ex >= 21 || ex <= -7) {
    n = (int)(ep - buf) + sprintf(ep, "e%c%d", ex < 0 ? '-' : '+', abs(ex));
  } else if (ex <= p) {
    n = snprintf(buf, 40, "%.*f", p - ex, (double)v);
  } else {
    int s = *buf == '-';
    memmove(buf + s + 1, buf + s + 2, p);
    memset(buf + s + 1 + p, '0', ex - p);
    n = s + 1 + ex;
  }
  return n;
}

static Term f32_show(Env e, Term x) {
  char buf[40];
  return io_str(e, buf, f32_text(buf, f32_unbox(x)));
}

static Term f32_read(Env e, Term s) {
  u64 n = 0;
  char* text = io_cstr(e, s, &n);
  char* end;
  f32 v = strtof(text, &end);
  Term out = n > 0 && (u64)(end - text) == n && strpbrk(text, "xX(") == NULL
    ? io_box(e, CID_SOME, f32_rewrap(v)) : term_pak(CID_NONE, 0);
  free(text);
  return out;
}


// Show
// ====

// show_val prints a pure main's value as term_show spells it: d
// is a SHOW_DESC node (see show_main), w its words, and chain the
// bracket of the [a, b] or (a, b) the value continues, or 0. Con
// or Nil spell a list, Tuple a tuple, and their tails continue
// it. show_chr escapes as char_show does; show_f32 prints the
// shortest text that reads back, with a point before an e.

#if MAIN_PURE

static void show_val(Env e, u32 d, const Term* w, char chain);

static void show_chr(u64 c, char q) {
  char b[4];
  int  k = c == 10 ? 'n' : c == 9 ? 't' : c == 13 ? 'r' : c == 0 ? '0'
    : c == 92 || c == (u64)q ? (int)c : 0;
  if (k != 0) {
    printf("\\%c", k);
  } else if (c < 32 || c == 127 || (c >= 0xD800 && c <= 0xDFFF)
    || c > 0x10FFFF) {
    printf("\\u{%llx}", (unsigned long long)c);
  } else {
    fwrite(b, 1, io_utf8(b, c), stdout);
  }
}

static void show_f32(u32 x) {
  char  buf[40];
  int   n  = f32_text(buf, f32_unbox(x));
  char* ep = memchr(buf, 'e', n);
  int   m  = ep == NULL ? n : (int)(ep - buf);
  buf[n] = 0;
  if (strpbrk(buf, ".ni") == NULL) {
    printf("%.*s.0%s", m, buf, buf + m);
  } else {
    fputs(buf, stdout);
  }
}

static void show_val(Env e, u32 d, const Term* w, char chain) {
  const u32* D = SHOW_DESC;
  Term one;
  char zs[4];
  u32  zn = 0;
  for (bool tail = true; tail;) switch (tail = false, D[d]) {
    case 0:
      printf("%u", (u32)w[0]);
      break;
    case 1:
      show_f32((u32)w[0]);
      break;
    case 2:
      printf("%llun", (unsigned long long)w[0]);
      break;
    case 3:
      putchar('\'');
      show_chr(D[d + 1] != 0 ? term_loc(w[0]) : w[0], '\'');
      putchar('\'');
      break;
    case 4:
      putchar('"');
      for (Term s = w[0]; term_aux(s) == CID_SCON;) {
        u64 l = term_peek(e.mem, s);
        show_chr(e.mem[l], '"');
        s = e.mem[l + 1];
      }
      putchar('"');
      break;
    case 5:
      fputs("{==}", stdout);
      break;
    case 6:
      putchar('[');
      for (u32 i = 0, g = D[d + 2]; i < 1u << (blk_cls(w[0]) - g); i += 1) {
        Term v[1u << g];
        for (u32 j = 0; j < 1u << g; j += 1) {
          v[j] = blk_read(e.mem, term_tag(w[0]) == TAG_ARR,
            term_peek(e.mem, w[0]), (i << g) + j);
        }
        fputs(i > 0 ? ", " : "", stdout);
        show_val(e, D[d + 1], v, 0);
      }
      putchar(']');
      break;
    default: {
      Term t   = w[0];
      bool box = D[d + 1] != 0;
      u32  key = box ? (u32)term_aux(t) : D[d + 2] > 1 ? (u32)t : 0;
      u32  a   = d + 3;
      for (u32 i = 0; box ? D[a + 1] != key : i != key; i += 1) {
        a += 4 + 2 * D[a + 2];
      }
      if (box) {
        one = term_loc(t);
        w   = term_tag(t) == TAG_PAK ? &one : e.mem + term_peek(e.mem, t);
      }
      char o = "{[("[D[a + 3]];
      if (o == '{') {
        printf("%s{", SHOW_NAMES[D[a]]);
      } else if (chain != o) {
        putchar(o);
      }
      if (o == '{' || chain != o) {
        zs[zn++] = "}])"[D[a + 3]];
      }
      for (u32 j = 0; j < D[a + 2]; j += 1) {
        if (o == '[' ? j == 0 && chain == o : j > 0) {
          fputs(", ", stdout);
        }
        if (j == 1 && o != '{') {
          tail  = true;
          chain = o;
          d     = D[a + 5 + 2 * j];
          w     = w + D[a + 4 + 2 * j];
        } else {
          show_val(e, D[a + 5 + 2 * j], w + D[a + 4 + 2 * j], 0);
        }
      }
    }
  }
  while (zn > 0) {
    putchar(zs[--zn]);
  }
}

#endif

// Run
// ===

static void io_step(Env e, IoWork* a) {
  for (;;) {
    u64  ap  = task_node(e, FID_CLO_APPLY, TERM_HOLE, 0, 0);
    e.mem[ap]     = a->cont;
    e.mem[ap + 1] = a->item;
    Term req = corpus_eval(e.mem, term_tsk(FID_CLO_APPLY, ap));
    u32  c   = (u32)term_aux(req);
    u64  at  = term_peek(e.mem, req);
    if (c == CID_EMIT) {
      term_drop(e, req);
      free(a);
      io_live -= 1;
      return;
    }
    if (c == CID_HALT) {
      io_errs(e, e.mem[at + 1]);
      exit((int)(u32)e.mem[at]);
    }
    if (io_eff_rows[c].run == NULL) {
      err_fail("an alien request");
    }
    u32 need = io_eff_rows[c].ask;
    u32 word = (u32)(need & IO_READ ? io_hand_v(e.mem[at]) : e.mem[at]);
    a->cont  = req;
    if (need != 0) {
      io_wait_on(a, (int)word, need & IO_READ ? POLLIN : 0,
        need & IO_TIME ? io_tick() + (u64)word * 1000000ull : 0, io_exec);
      return;
    }
    Term x = io_exec(e, a);
    if (x == IO_PARK) {
      return;
    }
    a->item = x;
  }
}

OUTLINE void io_loop(u64* H) {
  Env e = { H, ALC[0] };
  io_stk = pool_stack();
  signal(SIGPIPE, SIG_IGN);
  if (pipe(io_wake_fd) | fcntl(io_wake_fd[0], F_SETFL, O_NONBLOCK)) {
    err_fail("the event loop failed to open");
  }
  Term m = corpus_eval(H, term_tsk(MAIN_FID, task_node(e, MAIN_FID,
    TERM_HOLE, 0, 0)));
#if MAIN_PURE
  show_val(e, 0, H + H_ROOT_WORD, 0);
  putchar('\n');
  return;
#endif
  io_spawn(m);
  u64 look = 0;
  for (u32 n = 0;; n += 1) {
    if (io_runs == NULL) {
      if (io_live == 0) {
        return;
      }
      if (io_park == NULL && io_busy == 0) {
        io_sync();
        err_fail("deadlock: every computation waits on a channel");
      }
      io_wait(e, true);
      continue;
    }
    if ((n & 63) == 0 && io_busy != 0) {
      io_take(e);
    }
    // A busy loop still checks due timers, and fds periodically.
    if ((n & 63) == 0 && io_park != NULL) {
      u64 now = io_tick();
      if (now >= look || io_park->next->time - 1 < now) {
        look = now + 10000000;
        io_wait(e, false);
      }
    }
    io_step(e, io_pop(&io_runs));
  }
}

// Requests
// ========



// Main
// ====

int main(int argc, char** argv) {
  long thr = 0;
  int  gpu = -1;
  u64  mem = 0;
  io_argv = argv;
  io_argc = 1;
  for (int i = 1; i < argc; i += 1) {
    const char* a = argv[i];
    const char* v = i + 1 < argc ? argv[i + 1] : NULL;
    if (strcmp(a, "--") == 0) {
      while (i + 1 < argc) {
        io_argv[io_argc++] = argv[++i];
      }
    } else if (strcmp(a, "--bend-help") == 0) {
      printf(CLI_HELP, argv[0]);
      return 0;
    } else if (strcmp(a, "--gpu-build") == 0) {
      if (gpu_probe() && !gpu_make(gpu_path())) {
        fprintf(stderr, "bend: cannot write %s\n", gpu_path());
        return 1;
      }
      return 0;
    } else if (strcmp(a, "--threads") == 0) {
      char* end = NULL;
      thr = v != NULL ? strtol(v, &end, 10) : 0;
      if (thr < 1 || *end != '\0') {
        err_fail("expected a thread count of 1 or more after --threads");
      }
      i += 1;
    } else if (strcmp(a, "--gpu") == 0) {
      char*  end = NULL;
      double n   = v != NULL ? strtod(v, &end) : 0;
      u64    mul = end == NULL ? 0 : strcmp(end, "GB") == 0 ? 1ull << 30
        : strcmp(end, "MB") == 0 ? 1ull << 20 : 0;
      if (v != NULL && strcmp(v, "off") == 0) {
        gpu = 0;
      } else if (v != NULL && (strcmp(v, "on") == 0 || (mul != 0 && n > 0))) {
        gpu = 1;
        mem = (u64)(n * (double)mul);
      } else {
        err_fail("expected on, off or a size like 4GB after --gpu");
      }
      i += 1;
    } else {
      io_argv[io_argc++] = argv[i];
    }
  }
  bool dev = gpu != 0 && BANGS != 0 && gpu_probe();
  if (gpu == 1 && BANGS != 0 && !dev) {
    err_fail("--gpu on, but this binary found no usable GPU (a CUDA GPU needs"
      " concurrent managed access, which WSL2's lack)");
  }
  io_loop(corpus_setup(dev, thr > 0 ? thr : cpu_count(), mem));
  io_sync();
  return 0;
}

#endif
