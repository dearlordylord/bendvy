function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $main$() {
  return $consumer$045order$058main_trace$1260$(($consumer$045order$058create$1260$()));
}

function $consumer$045order$058main_trace$1260$(_result_0) {
  if (_result_0.$ === "None") {
    return "installation-refused";
  } else {
    const _app_0 = _result_0["value"];
    return $consumer$045order$058first$1260$(($consumer$045order$058checkpoint$1260$(_app_0, "initial", "")));
  }
}

function $consumer$045order$058create$1260$() {
  return $consumer$045order$058created$1260$(($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058create$1260$()));
}

function $consumer$045order$058first$1260$(_pair_0) {
  const _app_0 = _pair_0["fst"];
  const _prior_0 = _pair_0["snd"];
  return $consumer$045order$058second$1260$(($consumer$045order$058checkpoint$1260$(($consumer$045order$058run$1260$(_app_0)), "marker1", _prior_0)));
}

function $consumer$045order$058checkpoint$1260$(_app_0, _label_0, _prior_0) {
  return $consumer$045order$058checkpoint_observed$1260$(_label_0, _prior_0, ($consumer$045order$058observe$1260$(_app_0)));
}

function $consumer$045order$058created$1260$(_result_0) {
  if (_result_0.$ === "None") {
    return {$: "None"};
  } else {
    const _t_0 = _result_0["value"];
    const _owners_0 = _t_0["owners"];
    const _world_0 = _t_0["world"];
    return $consumer$045order$058named$1260$(_owners_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)));
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058create$1260$() {
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058created$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$()), {$: "../marker-phases-v1/apply-retention-v1/consumer.Resources", "owned": array_node([31], [37]), "slot": {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": {$: "../marker-phases-v1/apply-retention-v1/consumer.Value", "tag": {$: "../marker-phases-v1/apply-retention-v1/consumer.Boot"}, "representation": 10}, "pending": {$: "../../../../../../bendvy/src/ecs/machine.Queued", "value": {$: "../marker-phases-v1/apply-retention-v1/consumer.Value", "tag": {$: "../marker-phases-v1/apply-retention-v1/consumer.Play"}, "representation": 20}, "skipSame": false}, "previous": {$: "Some", "value": {$: "../marker-phases-v1/apply-retention-v1/consumer.Value", "tag": {$: "../marker-phases-v1/apply-retention-v1/consumer.Pause"}, "representation": 90}}, "changed": false}, "level": {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": {$: "../marker-phases-v1/apply-retention-v1/consumer.Value", "tag": {$: "../marker-phases-v1/apply-retention-v1/consumer.Boot"}, "representation": 90}, "pending": {$: "../../../../../../bendvy/src/ecs/machine.Queued", "value": {$: "../marker-phases-v1/apply-retention-v1/consumer.Value", "tag": {$: "../marker-phases-v1/apply-retention-v1/consumer.Pause"}, "representation": 30}, "skipSame": false}, "previous": {$: "Some", "value": {$: "../marker-phases-v1/apply-retention-v1/consumer.Value", "tag": {$: "../marker-phases-v1/apply-retention-v1/consumer.Play"}, "representation": 70}}, "changed": false}})));
}

function $consumer$045order$058second$1260$(_pair_0) {
  const _app_0 = _pair_0["fst"];
  const _prior_0 = _pair_0["snd"];
  return $consumer$045order$058final$1260$(($consumer$045order$058checkpoint$1260$(($consumer$045order$058run$1260$(_app_0)), "marker2", _prior_0)));
}

function $consumer$045order$058run$1260$(_app_0) {
  const _schedule_0 = _app_0["schedule"];
  const _world_0 = _app_0["world"];
  return $consumer$045order$058returned$1260$(run_loop($installer$045order$058run$1260$(_schedule_0, _world_0)));
}

function $consumer$045order$058checkpoint_observed$1260$(_label_0, _prior_0, _pair_0) {
  const _app_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  const _x_0 = (_text_0 + "\n");
  const _x_1 = (":" + _x_0);
  const _x_2 = (_label_0 + _x_1);
  return {$: "Tuple", "fst": _app_0, "snd": (_prior_0 + _x_2)};
}

function $consumer$045order$058observe$1260$(_app_0) {
  const _t_0 = _app_0["schedule"];
  const _namespace_0 = _t_0["namespace"];
  const _name_0 = _t_0["name"];
  const _steps_0 = _t_0["steps"];
  const _owners_0 = _t_0["owners"];
  const _world_0 = _app_0["world"];
  const _observations_0 = _app_0["observations"];
  const _status_0 = _app_0["status"];
  return $consumer$045order$058observed$1260$(_namespace_0, _name_0, _steps_0, _observations_0, _status_0, ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058observe$1260$({$: "../marker-phases-v1/apply-retention-v1/consumer.Application", "owners": _owners_0, "world": _world_0})));
}

function $consumer$045order$058named$1260$(_owners_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _namespace_0 = _pair_0["snd"];
  return $consumer$045order$058installed$1260$(_world_0, ($installer$045order$058install$1260$(($installer$045order$058declare$1260$("ordinary-machine-marker")), _namespace_0, _owners_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058created$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/world.Created") {
    const _world_0 = _result_0["world"];
    return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058registered$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1260$(($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058seed$1260$(_world_0)), "phases", {$: "Con", "head": "Flow.next", "tail": {$: "Con", "head": "Level.next", "tail": {$: "Nil"}}})));
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$() {
  return {$: "../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": 1};
}

function $consumer$045order$058final$1260$(_pair_0) {
  const _text_0 = _pair_0["snd"];
  return _text_0;
}

function $consumer$045order$058returned$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/schedule.Finished") {
    const _schedule_0 = _result_0["schedule"];
    const _world_0 = _result_0["world"];
    const _observations_0 = _result_0["observations"];
    return {$: "consumer-order.InstalledApplication", "schedule": _schedule_0, "world": _world_0, "observations": _observations_0, "status": "finished"};
  } else if (_result_0.$ === "../../../../../../bendvy/src/ecs/schedule.Failed") {
    const _schedule_1 = _result_0["schedule"];
    const _world_1 = _result_0["world"];
    const _error_0 = _result_0["error"];
    const _observations_1 = _result_0["observations"];
    return {$: "consumer-order.InstalledApplication", "schedule": _schedule_1, "world": _world_1, "observations": _observations_1, "status": ("failed:" + _error_0)};
  } else {
    const _schedule_2 = _result_0["schedule"];
    const _world_2 = _result_0["world"];
    return {$: "consumer-order.InstalledApplication", "schedule": _schedule_2, "world": _world_2, "observations": {$: "Nil"}, "status": "rejected"};
  }
}

function $installer$045order$058run$1260$(_schedule_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run$1260$(_schedule_0, _world_0);
}

function $consumer$045order$058observed$1260$(_namespace_0, _name_0, _steps_0, _observations_0, _status_0, _pair_0) {
  const _t_0 = _pair_0["fst"];
  const _owners_0 = _t_0["owners"];
  const _world_0 = _t_0["world"];
  const _text_0 = _pair_0["snd"];
  const _x_0 = ($List$show$1262$(_observations_0));
  const _x_1 = ("/scheduleStatus=" + _status_0);
  const _x_2 = (_x_0 + _x_1);
  const _x_3 = ($List$show$1261$(_steps_0));
  const _x_4 = ("/observations=" + _x_2);
  const _x_5 = (_x_3 + _x_4);
  const _x_6 = (":" + _x_5);
  const _x_7 = (_name_0 + _x_6);
  const _x_8 = ($U32$show$(_namespace_0));
  const _x_9 = (":" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ("/schedule=" + _x_10);
  return {$: "Tuple", "fst": {$: "consumer-order.InstalledApplication", "schedule": {$: "../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}, "world": _world_0, "observations": _observations_0, "status": _status_0}, "snd": (_text_0 + _x_11)};
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058observe$1260$(_app_0) {
  const _owners_0 = _app_0["owners"];
  const _world_0 = _app_0["world"];
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058observed$1260$(_owners_0, ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058show_world$1260$(_world_0)));
}

function $consumer$045order$058installed$1260$(_world_0, _built_0) {
  if (_built_0.$ === "../../../../../../bendvy/src/ecs/schedule.Invalid") {
    return {$: "None"};
  } else {
    const _schedule_0 = _built_0["schedule"];
    return {$: "Some", "value": {$: "consumer-order.InstalledApplication", "schedule": _schedule_0, "world": _world_0, "observations": {$: "Nil"}, "status": "ready"}};
  }
}

function $installer$045order$058install$1260$(_declaration_0, _namespace_0, _owners_0) {
  const _name_0 = _declaration_0["name"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build$1260$(_namespace_0, _name_0, ($installer$045order$058steps$()), {$: "Con", "head": 1, "tail": {$: "Con", "head": 2, "tail": {$: "Con", "head": 3, "tail": {$: "Con", "head": 4, "tail": {$: "Nil"}}}}}, _owners_0);
}

function $installer$045order$058declare$1260$(_name_0) {
  return {$: "installer-order.Declaration", "name": _name_0};
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058registered$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "Some", "value": {$: "../marker-phases-v1/apply-retention-v1/consumer.Application", "owners": {$: "../marker-phases-v1/apply-retention-v1/consumer.Owners", "registry": _registry_0, "flow": {$: "../../../../../../bendvy/src/ecs/machine.Unscheduled"}, "level": {$: "../../../../../../bendvy/src/ecs/machine.Unscheduled"}, "owned": array_node([43], [59]), "status": "ok"}, "world": _world_0}};
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058seed$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": {$: "Con", "head": "seed", "tail": {$: "Nil"}}, "pending": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058barrier$1260$(_x_0);
}), "tail": {$: "Nil"}}, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": 17};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../../../bendvy/src/ecs/world.CreateRejected", "factory": {$: "../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/world.Created", "factory": {$: "../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": array_node([array_node([13], [29])], [[47]]), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run$1260$(_schedule_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_namespace$1260$(_schedule_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $List$show$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$045order$058step$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$045order$058observation$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058observed$1260$(_owners_0, _pair_0) {
  const _registry_0 = _owners_0["registry"];
  const _flow_0 = _owners_0["flow"];
  const _level_0 = _owners_0["level"];
  const _owned_0 = _owners_0["owned"];
  const _status_0 = _owners_0["status"];
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058owners_view$1260$(_registry_0, _flow_0, _level_0, _status_0, ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1260$(_owned_0)), _pair_0);
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058show_world$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _slot_0 = _t_0["slot"];
  const _level_0 = _t_0["level"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058world_view$1260$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _slot_0, _level_0, _events_0, ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058commands$1260$(_pending_0)), _registrations_0, _nextSystem_0, _clock_0, ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1261$(_live_0)), ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1262$(_store_0)), ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1260$(_owned_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build$1260$(_namespace_0, _name_0, _steps_0, _catalog_0, _owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build_checked$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058valid$(_steps_0, _catalog_0, {$: "Nil"})), _namespace_0, _name_0, _steps_0, _owners_0);
}

function $installer$045order$058steps$() {
  return {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.Barrier"}, "tail": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.Phase", "name": "exit"}, "tail": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.System", "id": 2, "condition": 0}, "tail": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.Phase", "name": "apply"}, "tail": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.System", "id": 1, "condition": 0}, "tail": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.Phase", "name": "transition"}, "tail": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.System", "id": 3, "condition": 0}, "tail": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.Phase", "name": "enter"}, "tail": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.System", "id": 4, "condition": 0}, "tail": {$: "Nil"}}}}}}}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1260$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058barrier$1260$(_world_0) {
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058barrier_result$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_namespace$1260$(_schedule_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_actual$1260$(_schedule_0, _world_0, _actual_0);
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $consumer$045order$058step$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/schedule.Barrier") {
    return "barrier";
  } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/schedule.Phase") {
    const _name_0 = _value_0["name"];
    return ("phase:" + _name_0);
  } else {
    const _id_0 = _value_0["id"];
    const _condition_0 = _value_0["condition"];
    const _x_0 = ($U32$show$(_condition_0));
    const _x_1 = ($U32$show$(_id_0));
    const _x_2 = (":condition=" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    return ("system:" + _x_3);
  }
}

function $List$show$go$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$045order$058step$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $consumer$045order$058observation$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/schedule.Applied") {
    return "applied";
  } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/schedule.Entered") {
    const _name_0 = _value_0["name"];
    return ("entered:" + _name_0);
  } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/schedule.Ran") {
    const _id_0 = _value_0["id"];
    const _x_0 = ($U32$show$(_id_0));
    return ("ran:" + _x_0);
  } else {
    const _id_1 = _value_0["id"];
    const _x_1 = ($U32$show$(_id_1));
    return ("skipped:" + _x_1);
  }
}

function $List$show$go$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$045order$058observation$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058owners_view$1260$(_registry_0, _flow_0, _level_0, _status_0, _owned_0, _pair_0) {
  const _ns_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  const _owned_1 = _owned_0["fst"];
  const _a_0 = _owned_0["snd"];
  const _world_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  const _x_0 = ("/status=" + _status_0);
  const _x_1 = (_a_0 + _x_0);
  const _x_2 = ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058snapshot$(_level_0));
  const _x_3 = ("/owners=" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058snapshot$(_flow_0));
  const _x_6 = ("," + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($U32$show$(_cursor_0));
  const _x_9 = ("/cohort=" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($List$show$1260$(_access_0));
  const _x_12 = (":cursor=" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = (":" + _x_13);
  const _x_15 = (_name_0 + _x_14);
  const _x_16 = ($U32$show$(_id_0));
  const _x_17 = (":" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = ($U32$show$(_ns_0));
  const _x_20 = (":" + _x_18);
  const _x_21 = (_x_19 + _x_20);
  const _x_22 = ("/registry=" + _x_21);
  return {$: "Tuple", "fst": {$: "../marker-phases-v1/apply-retention-v1/consumer.Application", "owners": {$: "../marker-phases-v1/apply-retention-v1/consumer.Owners", "registry": {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "flow": _flow_0, "level": _level_0, "owned": _owned_1, "status": _status_0}, "world": _world_0}, "snd": (_text_0 + _x_22)};
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1260$(_value_0) {
  if (_value_0.length === 1) {
    const _value_1 = _value_0[0];
    return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058leaf$1260$(($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058number$(_value_1)));
  } else {
    const _a_0 = _value_0.slice(0, _value_0.length >> 1);
    const _b_0 = _value_0.slice(_value_0.length >> 1);
    return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_left$1260$(($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1260$(_b_0)), ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1260$(_a_0)));
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058world_view$1260$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _slot_0, _level_0, _events_0, _pending_0, _registrations_0, _nextSystem_0, _clock_0, _live_0, _store_0, _owned_0) {
  const _pending_1 = _pending_0["fst"];
  const _count_0 = _pending_0["snd"];
  const _live_1 = _live_0["fst"];
  const _a_0 = _live_0["snd"];
  const _store_1 = _store_0["fst"];
  const _b_0 = _store_0["snd"];
  const _owned_1 = _owned_0["fst"];
  const _c_0 = _owned_0["snd"];
  const _x_0 = ($U32$show$(_clock_0));
  const _x_1 = ($U32$show$(_nextSystem_0));
  const _x_2 = ("/clock=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($List$show$1263$(_registrations_0));
  const _x_5 = ("/nextSystem=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($Nat$show$(_count_0));
  const _x_8 = ("/registrations=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($List$show$1260$(_events_0));
  const _x_11 = ("/pending=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058show_slot$1261$(_level_0));
  const _x_14 = ("/events=" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058show_slot$1260$(_slot_0));
  const _x_17 = ("/level=" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = ("/slot=" + _x_18);
  const _x_20 = (_c_0 + _x_19);
  const _x_21 = ("/resource=" + _x_20);
  const _x_22 = (_b_0 + _x_21);
  const _x_23 = ("/components=" + _x_22);
  const _x_24 = (_a_0 + _x_23);
  const _x_25 = ($Nat$show$(_depth_0));
  const _x_26 = ("/live=" + _x_24);
  const _x_27 = (_x_25 + _x_26);
  const _x_28 = ($U32$show$(_capacity_0));
  const _x_29 = ("/depth=" + _x_27);
  const _x_30 = (_x_28 + _x_29);
  const _x_31 = ($U32$show$(_high_0));
  const _x_32 = ("/capacity=" + _x_30);
  const _x_33 = (_x_31 + _x_32);
  const _x_34 = ($U32$show$(_next_0));
  const _x_35 = ("/high=" + _x_33);
  const _x_36 = (_x_34 + _x_35);
  const _x_37 = ($U32$show$(_ns_0));
  const _x_38 = ("/next=" + _x_36);
  const _x_39 = (_x_37 + _x_38);
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_1, "capacity": _capacity_0, "depth": _depth_0, "store": _store_1, "resource": {$: "../marker-phases-v1/apply-retention-v1/consumer.Resources", "owned": _owned_1, "slot": _slot_0, "level": _level_0}, "events": _events_0, "pending": _pending_1, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ("ns=" + _x_39)};
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058commands$1260$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _head_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058commands_join$1260$(_head_0, ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058commands$1260$(_rest_0)));
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1261$(_value_0) {
  if (_value_0.length === 1) {
    const _value_1 = _value_0[0];
    return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058leaf$1261$(($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058boolean$(_value_1)));
  } else {
    const _a_0 = _value_0.slice(0, _value_0.length >> 1);
    const _b_0 = _value_0.slice(_value_0.length >> 1);
    return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_left$1261$(($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1261$(_b_0)), ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1261$(_a_0)));
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1262$(_value_0) {
  if (_value_0.length === 1) {
    const _value_1 = _value_0[0];
    return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058leaf$1262$(($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058payload$(_value_1)));
  } else {
    const _a_0 = _value_0.slice(0, _value_0.length >> 1);
    const _b_0 = _value_0.slice(_value_0.length >> 1);
    return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_left$1262$(($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1262$(_b_0)), ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1262$(_a_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build_checked$1260$(_allowed_0, _namespace_0, _name_0, _steps_0, _owners_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/schedule.Invalid", "owners": _owners_0};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/schedule.Built", "schedule": {$: "../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058valid$($0, $1, $2) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _catalog_0 = $1;
      const _seen_0 = $2;
      if (_steps_0.$ === "Nil") {
        return true;
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../../../../../../bendvy/src/ecs/schedule.Phase") {
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _catalog_0;
          $2 = _seen_0;
          continue;
        } else if (_t_0.$ === "../../../../../../bendvy/src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _catalog_0;
          $2 = _seen_0;
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _rest_2 = _steps_0["tail"];
          return $Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058contains$(_catalog_0, _id_0)), ($Bool$and$(($Bool$not$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058contains$(_seen_0, _id_0)))), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058valid$(_rest_2, _catalog_0, {$: "Con", "head": _id_0, "tail": _seen_0})))));
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1260$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058barrier_result$1260$(_pair_0) {
  const _world_0 = _pair_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_actual$1260$(_schedule_0, _world_0, _actual_0) {
  const _namespace_0 = _schedule_0["namespace"];
  const _name_0 = _schedule_0["name"];
  const _steps_0 = _schedule_0["steps"];
  const _owners_0 = _schedule_0["owners"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_checked$1260$((_namespace_0 === _actual_0), {$: "../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}, _world_0);
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $List$show$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1260$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return ("[" + _x_1);
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058snapshot$(_value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/machine.Unscheduled") {
    return "none";
  } else {
    const _value_1 = _value_0["value"];
    const _skip_0 = _value_0["skipSame"];
    const _x_0 = ($Bool$show$(_skip_0));
    const _x_1 = ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058show_value$(_value_1));
    const _x_2 = (":skip=" + _x_0);
    return (_x_1 + _x_2);
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058leaf$1260$(_pair_0) {
  const _value_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": [_value_0], "snd": ("L(" + _x_0)};
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058number$(_value_0) {
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058number_value$(_value_0);
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_left$1260$(_b_0, _pair_0) {
  const _a_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_right$1260$(_a_0, _text_0, _b_0);
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058show_slot$1260$(_slot_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _prior_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    const _x_0 = ($Bool$show$(_changed_0));
    const _x_1 = ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058previous$(_prior_0));
    const _x_2 = ("/changed=" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058show_pending$(_pending_0));
    const _x_5 = ("/previous=" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    const _x_7 = ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058show_value$(_current_0));
    const _x_8 = ("/" + _x_6);
    return (_x_7 + _x_8);
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058show_slot$1261$(_slot_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _prior_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    const _x_0 = ($Bool$show$(_changed_0));
    const _x_1 = ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058previous$(_prior_0));
    const _x_2 = ("/changed=" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058show_pending$(_pending_0));
    const _x_5 = ("/previous=" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    const _x_7 = ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058show_value$(_current_0));
    const _x_8 = ("/" + _x_6);
    return (_x_7 + _x_8);
  }
}

function $List$show$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058registration$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058commands_join$1260$(_head_0, _pair_0) {
  const _tail_0 = _pair_0["fst"];
  const _count_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_0, "tail": _tail_0}, "snd": nat_chk(_count_0 + 1)};
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058leaf$1261$(_pair_0) {
  const _value_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": [_value_0], "snd": ("L(" + _x_0)};
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058boolean$(_value_0) {
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058boolean_value$(_value_0);
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_left$1261$(_b_0, _pair_0) {
  const _a_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_right$1261$(_a_0, _text_0, _b_0);
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058leaf$1262$(_pair_0) {
  const _value_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": [_value_0], "snd": ("L(" + _x_0)};
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058payload$(_value_0) {
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1260$(_value_0);
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_left$1262$(_b_0, _pair_0) {
  const _a_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_right$1262$(_a_0, _text_0, _b_0);
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058contains$(_ids_0, _id_0) {
  if (_ids_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    const _x_0 = (_head_0 === _id_0);
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058contains$(_rest_0, _id_0));
    return (_x_0 || _x_1);
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/world.RegistrationRejected") {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../../../bendvy/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/world.RegistrationRejected", "error": {$: "../../../../../../bendvy/src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../../../bendvy/src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058run_checked$1260$(_allowed_0, _schedule_0, _world_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/schedule.Rejected", "schedule": _schedule_0, "world": _world_0};
  } else {
    const _namespace_0 = _schedule_0["namespace"];
    const _name_0 = _schedule_0["name"];
    const _steps_0 = _schedule_0["steps"];
    const _owners_0 = _schedule_0["owners"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058execute$1260$(_steps_0, _owners_0, _world_0, _namespace_0, _name_0, _steps_0, {$: "Nil"});
  }
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $List$show$go$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1260$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return (", " + _x_1);
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058show_value$(_value_0) {
  const _kind_0 = _value_0["tag"];
  const _representation_0 = _value_0["representation"];
  const _x_0 = ($U32$show$(_representation_0));
  const _x_1 = ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tag$(_kind_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $Bool$show$(_b_0) {
  if (!_b_0) {
    return "False";
  } else {
    return "True";
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058number_value$(_value_0) {
  return {$: "Tuple", "fst": _value_0, "snd": ($U32$show$(_value_0))};
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_right$1260$(_a_0, _text_0, _pair_0) {
  const _b_0 = _pair_0["fst"];
  const _other_0 = _pair_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("N(" + _x_2)};
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058show_pending$(_pending_0) {
  if (_pending_0.$ === "../../../../../../bendvy/src/ecs/machine.NoPending") {
    return "none";
  } else {
    const _value_0 = _pending_0["value"];
    const _skip_0 = _pending_0["skipSame"];
    const _x_0 = ($Bool$show$(_skip_0));
    const _x_1 = ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058show_value$(_value_0));
    const _x_2 = (":skip=" + _x_0);
    return (_x_1 + _x_2);
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058previous$(_prior_0) {
  if (_prior_0.$ === "None") {
    return "none";
  } else {
    const _prior_1 = _prior_0["value"];
    return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058show_value$(_prior_1);
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058registration$(_meta_0) {
  const _id_0 = _meta_0["id"];
  const _name_0 = _meta_0["name"];
  const _access_0 = _meta_0["access"];
  const _x_0 = ($List$show$1260$(_access_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_name_0 + _x_1);
  const _x_3 = ($U32$show$(_id_0));
  const _x_4 = (":" + _x_2);
  return (_x_3 + _x_4);
}

function $List$show$go$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058registration$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058boolean_value$(_value_0) {
  return {$: "Tuple", "fst": _value_0, "snd": ($Bool$show$(_value_0))};
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_right$1261$(_a_0, _text_0, _pair_0) {
  const _b_0 = _pair_0["fst"];
  const _other_0 = _pair_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("N(" + _x_2)};
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_right$1262$(_a_0, _text_0, _pair_0) {
  const _b_0 = _pair_0["fst"];
  const _other_0 = _pair_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("N(" + _x_2)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058execute$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _owners_0 = $1;
      const _world_0 = $2;
      const _namespace_0 = $3;
      const _name_0 = $4;
      const _all_0 = $5;
      const _observations_0 = $6;
      if (_steps_0.$ === "Nil") {
        return {$: "../../../../../../bendvy/src/ecs/schedule.Finished", "schedule": {$: "../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "observations": _observations_0};
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../../../../../../bendvy/src/ecs/schedule.Phase") {
          const _phase_0 = _t_0["name"];
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _owners_0;
          $2 = _world_0;
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.Entered", "name": _phase_0}, "tail": {$: "Nil"}}));
          continue;
        } else if (_t_0.$ === "../../../../../../bendvy/src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _owners_0;
          $2 = run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058barrier$1260$(_world_0));
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.Applied"}, "tail": {$: "Nil"}}));
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _slot_0 = _t_0["condition"];
          const _rest_2 = _steps_0["tail"];
          return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_condition$1260$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058execute$1260$(_rest_2, _x_0, _x_1, _namespace_0, _name_0, _all_0, _x_2);
});
});
}), ($installer$045order$058condition$1260$(_world_0, _slot_0)), _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
        }
      }
    }
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tag$(_tag_0) {
  if (_tag_0.$ === "../marker-phases-v1/apply-retention-v1/consumer.Boot") {
    return "Boot";
  } else if (_tag_0.$ === "../marker-phases-v1/apply-retention-v1/consumer.Play") {
    return "Play";
  } else {
    return "Pause";
  }
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058barrier$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1260$(_pending_0, {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_condition$1260$(_next_0, _checked_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058conditioned$1260$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $installer$045order$058condition$1260$(_world_0, __0) {
  return {$: "Tuple", "fst": _world_0, "snd": true};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1260$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1260$(_rest_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058conditioned$1260$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (!_allowed_0) {
    return run_tail(_next_0(_owners_0)(_world_0), ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.Skipped", "id": _id_0}, "tail": {$: "Nil"}})));
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_dispatch$1260$(_next_0, ($installer$045order$058dispatch$1260$(_owners_0, _world_0, _id_0)), _namespace_0, _name_0, _all_0, _observations_0, _id_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_dispatch$1260$(_next_0, _result_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _owners_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_outcome$1260$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $installer$045order$058dispatch$1260$(_owners_0, _world_0, _id_0) {
  if (_id_0 == 1) {
    return $consumer$045order$058group$1260$(1, _owners_0, _world_0);
  } else if ((_id_0 & 3) == 1) {
    return $consumer$045order$058group$1260$(4, _owners_0, _world_0);
  } else if (_id_0 == 3) {
    return $consumer$045order$058group$1260$(3, _owners_0, _world_0);
  } else if ((_id_0 & 3) == 3) {
    return $consumer$045order$058group$1260$(4, _owners_0, _world_0);
  } else if (_id_0 == 2) {
    return $consumer$045order$058group$1260$(2, _owners_0, _world_0);
  } else {
    return $consumer$045order$058group$1260$(4, _owners_0, _world_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_outcome$1260$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/schedule.Failed", "schedule": {$: "../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "error": _error_0, "observations": ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}}))};
  } else {
    const _world_1 = _outcome_0["world"];
    return run_tail(_next_0(_owners_0)(_world_1), ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}})));
  }
}

function $consumer$045order$058group$1260$(_phase_0, _owners_0, _world_0) {
  return $consumer$045order$058selected_group$1260$(_phase_0, ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058marker$1260$()), _owners_0, _world_0);
}

function $consumer$045order$058selected_group$1260$(_phase_0, _marker_0, _owners_0, _world_0) {
  if (_phase_0 == 1) {
    const _apply_0 = _marker_0["apply"];
    return $consumer$045order$058success$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058run_owned_marker$1260$(_apply_0, _owners_0, _world_0)));
  } else if ((_phase_0 & 3) == 1) {
    const _enter_0 = _marker_0["enter"];
    return $consumer$045order$058success$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058run_owned_marker$1260$(_enter_0, _owners_0, _world_0)));
  } else if (_phase_0 == 3) {
    const _transition_0 = _marker_0["transition"];
    return $consumer$045order$058success$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058run_owned_marker$1260$(_transition_0, _owners_0, _world_0)));
  } else if ((_phase_0 & 3) == 3) {
    const _enter_1 = _marker_0["enter"];
    return $consumer$045order$058success$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058run_owned_marker$1260$(_enter_1, _owners_0, _world_0)));
  } else if (_phase_0 == 2) {
    const _exit_0 = _marker_0["exit"];
    return $consumer$045order$058success$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058run_owned_marker$1260$(_exit_0, _owners_0, _world_0)));
  } else {
    const _enter_2 = _marker_0["enter"];
    return $consumer$045order$058success$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058run_owned_marker$1260$(_enter_2, _owners_0, _world_0)));
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058marker$1260$() {
  return {$: "../marker-phases-v1/apply-retention-v1/phases.PhasedMarker", "apply": {$: "../../../../../../bendvy/src/ecs/machine.OwnedMarker", "steps": {$: "Con", "head": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058capture$1260$(_x_0, _x_1);
});
}), "tail": {$: "Con", "head": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058apply_flow$1260$(_x_2, _x_3);
});
}), "tail": {$: "Con", "head": run_clo((_x_4) => {
  return run_clo((_x_5) => {
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058hook$1260$({$: "../marker-phases-v1/apply-retention-v1/consumer.Request", "label": "applyQueueLevel", "action": {$: "../marker-phases-v1/apply-retention-v1/consumer.QueueLevel", "input": {$: "../../../../../../bendvy/src/ecs/machine.Set", "value": {$: "../marker-phases-v1/apply-retention-v1/consumer.Value", "tag": {$: "../marker-phases-v1/apply-retention-v1/consumer.Boot"}, "representation": 40}, "skipSame": false}}}, _x_4, _x_5);
});
}), "tail": {$: "Con", "head": run_clo((_x_6) => {
  return run_clo((_x_7) => {
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058apply_level$1260$(_x_6, _x_7);
});
}), "tail": {$: "Nil"}}}}}}, "exit": {$: "../../../../../../bendvy/src/ecs/machine.OwnedMarker", "steps": {$: "Con", "head": run_clo((_x_8) => {
  return run_clo((_x_9) => {
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058hook$1260$({$: "../marker-phases-v1/apply-retention-v1/consumer.Request", "label": "exitFlow", "action": {$: "../marker-phases-v1/apply-retention-v1/consumer.Idle"}}, _x_8, _x_9);
});
}), "tail": {$: "Con", "head": run_clo((_x_10) => {
  return run_clo((_x_11) => {
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058hook$1260$({$: "../marker-phases-v1/apply-retention-v1/consumer.Request", "label": "exitLevel", "action": {$: "../marker-phases-v1/apply-retention-v1/consumer.Idle"}}, _x_10, _x_11);
});
}), "tail": {$: "Nil"}}}}, "transition": {$: "../../../../../../bendvy/src/ecs/machine.OwnedMarker", "steps": {$: "Con", "head": run_clo((_x_12) => {
  return run_clo((_x_13) => {
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058hook$1260$({$: "../marker-phases-v1/apply-retention-v1/consumer.Request", "label": "transitionFlow", "action": {$: "../marker-phases-v1/apply-retention-v1/consumer.QueueFlow", "input": {$: "../../../../../../bendvy/src/ecs/machine.Set", "value": {$: "../marker-phases-v1/apply-retention-v1/consumer.Value", "tag": {$: "../marker-phases-v1/apply-retention-v1/consumer.Pause"}, "representation": 50}, "skipSame": false}}}, _x_12, _x_13);
});
}), "tail": {$: "Con", "head": run_clo((_x_14) => {
  return run_clo((_x_15) => {
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058hook$1260$({$: "../marker-phases-v1/apply-retention-v1/consumer.Request", "label": "transitionLevel", "action": {$: "../marker-phases-v1/apply-retention-v1/consumer.Idle"}}, _x_14, _x_15);
});
}), "tail": {$: "Nil"}}}}, "enter": {$: "../../../../../../bendvy/src/ecs/machine.OwnedMarker", "steps": {$: "Con", "head": run_clo((_x_16) => {
  return run_clo((_x_17) => {
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058hook$1260$({$: "../marker-phases-v1/apply-retention-v1/consumer.Request", "label": "enterFlow", "action": {$: "../marker-phases-v1/apply-retention-v1/consumer.Idle"}}, _x_16, _x_17);
});
}), "tail": {$: "Con", "head": run_clo((_x_18) => {
  return run_clo((_x_19) => {
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058hook$1260$({$: "../marker-phases-v1/apply-retention-v1/consumer.Request", "label": "enterLevel", "action": {$: "../marker-phases-v1/apply-retention-v1/consumer.Idle"}}, _x_18, _x_19);
});
}), "tail": {$: "Nil"}}}}};
}

function $consumer$045order$058success$1260$(_pair_0) {
  const _owners_0 = _pair_0["fst"];
  const _world_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": _owners_0, "snd": {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058run_owned_marker$1260$(_marker_0, _owners_0, _world_0) {
  const _steps_0 = _marker_0["steps"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058owned_marker_steps$1260$(_steps_0, _owners_0, _world_0);
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058capture$1260$(_owners_0, _world_0) {
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058captured$1260$(_owners_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1260$(_world_0)));
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058apply_flow$1260$(_owners_0, _world_0) {
  const _registry_0 = _owners_0["registry"];
  const _flow_0 = _owners_0["flow"];
  const _level_0 = _owners_0["level"];
  const _owned_0 = _owners_0["owned"];
  const _status_0 = _owners_0["status"];
  return {$: "Tuple", "fst": {$: "../marker-phases-v1/apply-retention-v1/consumer.Owners", "registry": _registry_0, "flow": _flow_0, "level": _level_0, "owned": _owned_0, "status": _status_0}, "snd": ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058apply_pair$1260$("applyFlow", _flow_0, ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058take$1260$(_world_0))))};
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058hook$1260$(_request_0, _owners_0, _world_0) {
  const _registry_0 = _owners_0["registry"];
  const _flow_0 = _owners_0["flow"];
  const _level_0 = _owners_0["level"];
  const _owned_0 = _owners_0["owned"];
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058returned$1260$(_flow_0, _level_0, _owned_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _request_0)));
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058apply_level$1260$(_owners_0, _world_0) {
  const _registry_0 = _owners_0["registry"];
  const _flow_0 = _owners_0["flow"];
  const _level_0 = _owners_0["level"];
  const _owned_0 = _owners_0["owned"];
  const _status_0 = _owners_0["status"];
  return {$: "Tuple", "fst": {$: "../marker-phases-v1/apply-retention-v1/consumer.Owners", "registry": _registry_0, "flow": _flow_0, "level": _level_0, "owned": _owned_0, "status": _status_0}, "snd": ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058apply_pair$1261$("applyLevel", _level_0, ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058take_level$1260$(_world_0))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058owned_marker_steps$1260$(_steps_0, _owners_0, _world_0) {
  if (_steps_0.$ === "Nil") {
    return {$: "Tuple", "fst": _owners_0, "snd": _world_0};
  } else {
    const _step_0 = _steps_0["head"];
    const _rest_0 = _steps_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058marker_next$1260$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058owned_marker_steps$1260$(_rest_0, _x_0, _x_1);
});
}), _step_0(_owners_0)(_world_0));
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058captured$1260$(_owners_0, _observed_0) {
  const _registry_0 = _owners_0["registry"];
  const _owned_0 = _owners_0["owned"];
  const _status_0 = _owners_0["status"];
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _flow_0 = _t_0["fst"];
  const _level_0 = _t_0["snd"];
  return {$: "Tuple", "fst": {$: "../marker-phases-v1/apply-retention-v1/consumer.Owners", "registry": _registry_0, "flow": _flow_0, "level": _level_0, "owned": _owned_0, "status": _status_0}, "snd": _world_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1260$(($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058capture_resource$1260$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058apply_pair$1260$(_label_0, _captured_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058applied_world$1260$(_label_0, _world_0, ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047cohort$058apply$1260$(_slot_0, _captured_0)));
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058take$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1260$(_world_0);
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058returned$1260$(_flow_0, _level_0, _owned_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _result_1 = _result_0["outcome"];
    return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058outcome$1260$(_registry_0, _flow_0, _level_0, _owned_0, _result_1);
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    return {$: "Tuple", "fst": {$: "../marker-phases-v1/apply-retention-v1/consumer.Owners", "registry": _registry_1, "flow": _flow_0, "level": _level_0, "owned": _owned_0, "status": "registration-rejected"}, "snd": _world_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0)));
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058apply_pair$1261$(_label_0, _captured_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058applied_world$1261$(_label_0, _world_0, ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047cohort$058apply$1261$(_slot_0, _captured_0)));
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058take_level$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1261$(_world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058marker_next$1260$(_next_0, _pair_0) {
  const _owners_0 = _pair_0["fst"];
  const _world_0 = _pair_0["snd"];
  return run_tail(_next_0(_owners_0), _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058capture_resource$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["slot"];
  const _level_0 = _resources_0["level"];
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058capture_slots$1260$(_owned_0, ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047cohort$058take_slot$1260$(_flow_0)), ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047cohort$058take_slot$1261$(_level_0)));
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058applied_world$1260$(_label_0, _world_0, _applied_0) {
  const _slot_0 = _applied_0["slot"];
  const _t_0 = _applied_0["event"];
  if (_t_0.$ === "None") {
    return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058put$1260$(_world_0, _slot_0);
  } else {
    const _t_1 = _t_0["value"];
    const _from_0 = _t_1["from"];
    const _to_0 = _t_1["to"];
    const _x_0 = ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058show_value$(_to_0));
    const _x_1 = ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058show_value$(_from_0));
    const _x_2 = ("->" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = (":" + _x_3);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058put$1260$(_world_0, _slot_0)), {$: "Con", "head": (_label_0 + _x_4), "tail": {$: "Nil"}});
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047cohort$058apply$1260$(_slot_0, _captured_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    if (_captured_0.$ === "../../../../../../bendvy/src/ecs/machine.Unscheduled") {
      return {$: "../../../../../../bendvy/src/ecs/machine.Applied", "slot": {$: "../../../../../../bendvy/src/ecs/machine.Missing"}, "event": {$: "None"}};
    } else {
      return {$: "../../../../../../bendvy/src/ecs/machine.Applied", "slot": {$: "../../../../../../bendvy/src/ecs/machine.Missing"}, "event": {$: "None"}};
    }
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    if (_captured_0.$ === "../../../../../../bendvy/src/ecs/machine.Unscheduled") {
      return {$: "../../../../../../bendvy/src/ecs/machine.Applied", "slot": {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": _pending_0, "previous": _previous_0, "changed": _changed_0}, "event": {$: "None"}};
    } else {
      const _value_0 = _captured_0["value"];
      const _skipSame_0 = _captured_0["skipSame"];
      return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047cohort$058restored$1260$(_pending_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058apply_present$1260$(_current_0, _value_0, _previous_0, _changed_0, _skipSame_0)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take_join$1260$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058take_resource$1260$(_resources_0)), _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058outcome$1260$(_registry_0, _flow_0, _level_0, _owned_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.Succeeded") {
    const _world_0 = _result_0["world"];
    return {$: "Tuple", "fst": {$: "../marker-phases-v1/apply-retention-v1/consumer.Owners", "registry": _registry_0, "flow": _flow_0, "level": _level_0, "owned": _owned_0, "status": "ok"}, "snd": _world_0};
  } else {
    const _world_1 = _result_0["world"];
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": {$: "../marker-phases-v1/apply-retention-v1/consumer.Owners", "registry": _registry_0, "flow": _flow_0, "level": _level_0, "owned": _owned_0, "status": _error_0}, "snd": _world_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1260$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1260$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058applied_world$1261$(_label_0, _world_0, _applied_0) {
  const _slot_0 = _applied_0["slot"];
  const _t_0 = _applied_0["event"];
  if (_t_0.$ === "None") {
    return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058put_level$1260$(_world_0, _slot_0);
  } else {
    const _t_1 = _t_0["value"];
    const _from_0 = _t_1["from"];
    const _to_0 = _t_1["to"];
    const _x_0 = ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058show_value$(_to_0));
    const _x_1 = ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058show_value$(_from_0));
    const _x_2 = ("->" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = (":" + _x_3);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058put_level$1260$(_world_0, _slot_0)), {$: "Con", "head": (_label_0 + _x_4), "tail": {$: "Nil"}});
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047cohort$058apply$1261$(_slot_0, _captured_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    if (_captured_0.$ === "../../../../../../bendvy/src/ecs/machine.Unscheduled") {
      return {$: "../../../../../../bendvy/src/ecs/machine.Applied", "slot": {$: "../../../../../../bendvy/src/ecs/machine.Missing"}, "event": {$: "None"}};
    } else {
      return {$: "../../../../../../bendvy/src/ecs/machine.Applied", "slot": {$: "../../../../../../bendvy/src/ecs/machine.Missing"}, "event": {$: "None"}};
    }
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    if (_captured_0.$ === "../../../../../../bendvy/src/ecs/machine.Unscheduled") {
      return {$: "../../../../../../bendvy/src/ecs/machine.Applied", "slot": {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": _pending_0, "previous": _previous_0, "changed": _changed_0}, "event": {$: "None"}};
    } else {
      const _value_0 = _captured_0["value"];
      const _skipSame_0 = _captured_0["skipSame"];
      return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047cohort$058restored$1261$(_pending_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058apply_present$1261$(_current_0, _value_0, _previous_0, _changed_0, _skipSame_0)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1261$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take_join$1261$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058take_level_resource$1260$(_resources_0)), _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058capture_slots$1260$(_owned_0, _flow_0, _level_0) {
  const _flow_1 = _flow_0["fst"];
  const _capturedFlow_0 = _flow_0["snd"];
  const _level_1 = _level_0["fst"];
  const _capturedLevel_0 = _level_0["snd"];
  return {$: "Tuple", "fst": {$: "../marker-phases-v1/apply-retention-v1/consumer.Resources", "owned": _owned_0, "slot": _flow_1, "level": _level_1}, "snd": {$: "Tuple", "fst": _capturedFlow_0, "snd": _capturedLevel_0}};
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047cohort$058take_slot$1260$(_slot_0) {
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset$1260$(_slot_0)), "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058snapshot$1260$(_slot_0))};
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047cohort$058take_slot$1261$(_slot_0) {
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset$1261$(_slot_0)), "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058snapshot$1261$(_slot_0))};
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058put$1260$(_world_0, _slot_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1260$(_world_0, _slot_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047cohort$058restored$1260$(_pending_0, _applied_0) {
  const _t_0 = _applied_0["slot"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    const _event_0 = _applied_0["event"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Applied", "slot": {$: "../../../../../../bendvy/src/ecs/machine.Missing"}, "event": _event_0};
  } else {
    const _current_0 = _t_0["current"];
    const _previous_0 = _t_0["previous"];
    const _changed_0 = _t_0["changed"];
    const _event_1 = _applied_0["event"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Applied", "slot": {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": _pending_0, "previous": _previous_0, "changed": _changed_0}, "event": _event_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058apply_present$1260$(_current_0, _value_0, _previous_0, _changed_0, _skipSame_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058apply_decision$1260$(_current_0, _value_0, _previous_0, _changed_0, ($Bool$and$(_skipSame_0, ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058same$(_current_0, _value_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take_join$1260$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _split_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _resources_0 = _split_0["fst"];
  const _slot_0 = _split_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _slot_0};
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058take_resource$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _slot_0 = _resources_0["slot"];
  const _level_0 = _resources_0["level"];
  return {$: "Tuple", "fst": {$: "../marker-phases-v1/apply-retention-v1/consumer.Resources", "owned": _owned_0, "slot": _slot_0, "level": _level_0}, "snd": _slot_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1260$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058put_level$1260$(_world_0, _slot_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1261$(_world_0, _slot_0);
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047cohort$058restored$1261$(_pending_0, _applied_0) {
  const _t_0 = _applied_0["slot"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    const _event_0 = _applied_0["event"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Applied", "slot": {$: "../../../../../../bendvy/src/ecs/machine.Missing"}, "event": _event_0};
  } else {
    const _current_0 = _t_0["current"];
    const _previous_0 = _t_0["previous"];
    const _changed_0 = _t_0["changed"];
    const _event_1 = _applied_0["event"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Applied", "slot": {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": _pending_0, "previous": _previous_0, "changed": _changed_0}, "event": _event_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058apply_present$1261$(_current_0, _value_0, _previous_0, _changed_0, _skipSame_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058apply_decision$1261$(_current_0, _value_0, _previous_0, _changed_0, ($Bool$and$(_skipSame_0, ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058same$(_current_0, _value_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take_join$1261$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _split_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _resources_0 = _split_0["fst"];
  const _slot_0 = _split_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _slot_0};
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058take_level_resource$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["slot"];
  const _level_0 = _resources_0["level"];
  return {$: "Tuple", "fst": {$: "../marker-phases-v1/apply-retention-v1/consumer.Resources", "owned": _owned_0, "slot": _flow_0, "level": _level_0}, "snd": _level_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset$1260$(_slot_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../../../bendvy/src/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058snapshot$1260$(_slot_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Unscheduled"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058snapshot_pending$1260$(_pending_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset$1261$(_slot_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../../../bendvy/src/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058snapshot$1261$(_slot_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Unscheduled"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058snapshot_pending$1260$(_pending_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1260$(_world_0, _slot_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058put_resource$1260$(_resources_0, _slot_0)), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058apply_decision$1260$(_current_0, _value_0, _previous_0, _changed_0, _skip_0) {
  if (_skip_0) {
    return {$: "../../../../../../bendvy/src/ecs/machine.Applied", "slot": {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../../../bendvy/src/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0}, "event": {$: "None"}};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/machine.Applied", "slot": {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _value_0, "pending": {$: "../../../../../../bendvy/src/ecs/machine.NoPending"}, "previous": {$: "Some", "value": _current_0}, "changed": true}, "event": {$: "Some", "value": {$: "../../../../../../bendvy/src/ecs/machine.Transition", "from": _current_0, "to": _value_0}}};
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058same$(_a_0, _b_0) {
  const _a_1 = _a_0["tag"];
  const _b_1 = _b_0["tag"];
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tag_same$(_a_1, _b_1);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1260$({$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1261$(_world_0, _slot_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058put_level_resource$1260$(_resources_0, _slot_0)), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058apply_decision$1261$(_current_0, _value_0, _previous_0, _changed_0, _skip_0) {
  if (_skip_0) {
    return {$: "../../../../../../bendvy/src/ecs/machine.Applied", "slot": {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../../../bendvy/src/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0}, "event": {$: "None"}};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/machine.Applied", "slot": {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _value_0, "pending": {$: "../../../../../../bendvy/src/ecs/machine.NoPending"}, "previous": {$: "Some", "value": _current_0}, "changed": true}, "event": {$: "Some", "value": {$: "../../../../../../bendvy/src/ecs/machine.Transition", "from": _current_0, "to": _value_0}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058snapshot_pending$1260$(_pending_0) {
  if (_pending_0.$ === "../../../../../../bendvy/src/ecs/machine.NoPending") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Unscheduled"};
  } else {
    const _value_0 = _pending_0["value"];
    const _skipSame_0 = _pending_0["skipSame"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Scheduled", "value": _value_0, "skipSame": _skipSame_0};
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058put_resource$1260$(_resources_0, _slot_0) {
  const _owned_0 = _resources_0["owned"];
  const _level_0 = _resources_0["level"];
  return {$: "../marker-phases-v1/apply-retention-v1/consumer.Resources", "owned": _owned_0, "slot": _slot_0, "level": _level_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tag_same$(_a_0, _b_0) {
  if (_a_0.$ === "../marker-phases-v1/apply-retention-v1/consumer.Boot") {
    if (_b_0.$ === "../marker-phases-v1/apply-retention-v1/consumer.Boot") {
      return true;
    } else {
      return false;
    }
  } else if (_a_0.$ === "../marker-phases-v1/apply-retention-v1/consumer.Play") {
    if (_b_0.$ === "../marker-phases-v1/apply-retention-v1/consumer.Play") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_b_0.$ === "../marker-phases-v1/apply-retention-v1/consumer.Pause") {
      return true;
    } else {
      return false;
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1260$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": {$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1260$({$: "../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058put_level_resource$1260$(_resources_0, _slot_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["slot"];
  return {$: "../marker-phases-v1/apply-retention-v1/consumer.Resources", "owned": _owned_0, "slot": _flow_0, "level": _slot_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1260$(_registry_0, ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058runner$1260$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058runner$1260$(_world_0, _request_0) {
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058invoked$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1260$(_request_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1260$(_world_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058invoked$1260$(_pair_0) {
  const _frame_0 = _pair_0["fst"];
  const _event_0 = _pair_0["snd"];
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058emit$1260$(_frame_0, _event_0)), false);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1260$(_args_0, _ctx_0) {
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058body$1260$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058finish$1260$(_frame_0, _fail_0) {
  if (!_fail_0) {
    return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058completed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1260$(_frame_0, {$: "../../../../../../bendvy/src/ecs/transaction.Success"})));
  } else {
    return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058completed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1260$(_frame_0, {$: "../../../../../../bendvy/src/ecs/transaction.Failure", "error": "rollback"})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058emit$1260$(_tx_0, _event_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": {$: "Con", "head": _event_0, "tail": _events_0}};
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058body$1260$(_request_0, _owner_0) {
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058body_flow$1260$(_request_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_get$1261$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_access$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058completed$1260$(_result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    return {$: "../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058body_flow$1260$(_request_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _flow_0 = _observed_0["snd"];
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058body_level$1260$(_request_0, _flow_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_get$1260$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_get$1261$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_read_field$1261$(($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058flow_cap$1260$({$: "../marker-phases-v1/apply-retention-v1/consumer.Ops", "flow": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058write$1260$()), "level": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058write$1261$())})))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058body_level$1260$(_request_0, _flow_0, _observed_0) {
  const _label_0 = _request_0["label"];
  const _action_0 = _request_0["action"];
  const _owner_0 = _observed_0["fst"];
  const _level_0 = _observed_0["snd"];
  const _x_0 = ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058current$1261$(_level_0));
  const _x_1 = ($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058current$1260$(_flow_0));
  const _x_2 = (",Level=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = (":Flow=" + _x_3);
  return {$: "Tuple", "fst": run_loop($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058act$1260$(_owner_0, _action_0)), "snd": (_label_0 + _x_4)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_get$1260$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_read_field$1260$(($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058level_cap$1260$({$: "../marker-phases-v1/apply-retention-v1/consumer.Ops", "flow": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058write$1260$()), "level": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058write$1261$())})))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_read_field$1261$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058flow_cap$1260$(_ops_0) {
  const _flow_0 = _ops_0["flow"];
  return _flow_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058write$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.ValueWrite", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058get$1260$(_x_0);
}), "set": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058set$1260$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058write$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.ValueWrite", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058get$1261$(_x_0);
}), "set": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058set$1261$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058enqueue$1260$(_world_0, _commands_0) {
  return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058enqueue_go$1260$(_commands_0, _world_0);
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058publish$1260$(_world_0, _events_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _prior_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($List$append$(_prior_0, _events_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058act$1260$(_owner_0, _action_0) {
  if (_action_0.$ === "../marker-phases-v1/apply-retention-v1/consumer.Idle") {
    return _owner_0;
  } else if (_action_0.$ === "../marker-phases-v1/apply-retention-v1/consumer.QueueFlow") {
    const _input_0 = _action_0["input"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1260$(_owner_0, _input_0);
  } else {
    const _input_1 = _action_0["input"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1261$(_owner_0, _input_1);
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058current$1260$(_view_0) {
  if (_view_0.$ === "../../../../../../bendvy/src/ecs/machine.Unavailable") {
    return "missing";
  } else {
    const _value_0 = _view_0["value"];
    return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058show_value$(_value_0);
  }
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058current$1261$(_view_0) {
  if (_view_0.$ === "../../../../../../bendvy/src/ecs/machine.Unavailable") {
    return "missing";
  } else {
    const _value_0 = _view_0["value"];
    return $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058show_value$(_value_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_read_field$1260$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058level_cap$1260$(_ops_0) {
  const _level_0 = _ops_0["level"];
  return _level_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058get$1260$(_frame_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058current$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read$1260$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058set$1260$(_frame_0, _input_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058next_declared$1260$({$: "../../../../../../bendvy/src/ecs/machine.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058name$1260$(($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058flow_declaration$1260$())))}, _frame_0, _input_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058get$1261$(_frame_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058current$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read$1261$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058set$1261$(_frame_0, _input_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058next_declared$1261$({$: "../../../../../../bendvy/src/ecs/machine.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058name$1261$(($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058level_declaration$1260$())))}, _frame_0, _input_0);
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058enqueue_go$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1260$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_field$1260$(($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058flow_cap$1260$({$: "../marker-phases-v1/apply-retention-v1/consumer.Ops", "flow": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058write$1260$()), "level": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058write$1261$())}))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1261$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_field$1261$(($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058level_cap$1260$({$: "../marker-phases-v1/apply-retention-v1/consumer.Ops", "flow": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058write$1260$()), "level": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058write$1261$())}))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058current$1260$(_pair_0) {
  const _frame_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058current_view$1260$(_slot_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read$1260$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read_taken$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1260$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058next_declared$1260$(__0, _tx_0, _request_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058next$1260$(_tx_0, _request_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058name$1260$(_declaration_0) {
  const _name_0 = _declaration_0["name"];
  return _name_0;
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058flow_declaration$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-machine-declaration.Declaration", "name": "Flow"};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045operations$058current$1261$(_pair_0) {
  const _frame_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058current_view$1261$(_slot_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read$1261$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read_taken$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1261$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058next_declared$1261$(__0, _tx_0, _request_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058next$1261$(_tx_0, _request_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058name$1261$(_declaration_0) {
  const _name_0 = _declaration_0["name"];
  return _name_0;
}

function $$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058level_declaration$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/ordinary-machine-declaration.Declaration", "name": "Level"};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_field$1260$(_cap_0) {
  const _set_0 = _cap_0["set"];
  return _set_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_field$1261$(_cap_0) {
  const _set_0 = _cap_0["set"];
  return _set_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058current_view$1260$(_slot_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Unavailable"};
  } else {
    const _current_0 = _slot_0["current"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Current", "value": _current_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read_taken$1260$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _slot_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058next$1260$(_tx_0, _request_0) {
  if (_request_0.$ === "../../../../../../bendvy/src/ecs/machine.Set") {
    const _value_0 = _request_0["value"];
    const _skipSame_0 = _request_0["skipSame"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058write$1260$(_tx_0, _value_0, _skipSame_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_tx$1260$(_tx_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058current_view$1261$(_slot_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Unavailable"};
  } else {
    const _current_0 = _slot_0["current"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Current", "value": _current_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read_taken$1261$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _slot_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058next$1261$(_tx_0, _request_0) {
  if (_request_0.$ === "../../../../../../bendvy/src/ecs/machine.Set") {
    const _value_0 = _request_0["value"];
    const _skipSame_0 = _request_0["skipSame"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058write$1261$(_tx_0, _value_0, _skipSame_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_tx$1261$(_tx_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058write$1260$(_tx_0, _value_0, _skipSame_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058write_taken$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1260$(_world_0)), _undo_0, _commands_0, _events_0, _value_0, _skipSame_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_tx$1260$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_taken$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1260$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058write$1261$(_tx_0, _value_0, _skipSame_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058write_taken$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1261$(_world_0)), _undo_0, _commands_0, _events_0, _value_0, _skipSame_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_tx$1261$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_taken$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1261$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058write_taken$1260$(_pair_0, _undo_0, _commands_0, _events_0, _value_0, _skipSame_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1260$(_world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058queue$1260$(_old_0, _value_0, _skipSame_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1260$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_taken$1260$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1260$(_world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset$1260$(_old_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1260$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058write_taken$1261$(_pair_0, _undo_0, _commands_0, _events_0, _value_0, _skipSame_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1261$(_world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058queue$1261$(_old_0, _value_0, _skipSame_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1261$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_taken$1261$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1261$(_world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset$1261$(_old_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1261$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058queue$1260$(_slot_0, _value_0, _skipSame_0) {
  if (!_skipSame_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058queue$1260$(_slot_0, _value_0, false);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058conditional$1260$(_slot_0, _value_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058queue$1261$(_slot_0, _value_0, _skipSame_0) {
  if (!_skipSame_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058queue$1261$(_slot_0, _value_0, false);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058conditional$1261$(_slot_0, _value_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058queue$1260$(_slot_0, _value_0, _skipSame_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../../../bendvy/src/ecs/machine.Queued", "value": _value_0, "skipSame": _skipSame_0}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058conditional$1260$(_slot_0, _value_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058conditional_pending$1260$(_pending_0, _value_0)), "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058queue$1261$(_slot_0, _value_0, _skipSame_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../../../bendvy/src/ecs/machine.Queued", "value": _value_0, "skipSame": _skipSame_0}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058conditional$1261$(_slot_0, _value_0) {
  if (_slot_0.$ === "../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../bendvy/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058conditional_pending$1260$(_pending_0, _value_0)), "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058conditional_pending$1260$(_pending_0, _value_0) {
  if (_pending_0.$ === "../../../../../../bendvy/src/ecs/machine.Queued") {
    const _prior_0 = _pending_0["value"];
    const _t_0 = _pending_0["skipSame"];
    if (!_t_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058forced_pending$1260$(($$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058same$(_prior_0, _value_0)), _prior_0, _value_0);
    } else {
      return {$: "../../../../../../bendvy/src/ecs/machine.Queued", "value": _value_0, "skipSame": true};
    }
  } else {
    return {$: "../../../../../../bendvy/src/ecs/machine.Queued", "value": _value_0, "skipSame": true};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045queue$058forced_pending$1260$(_same_0, _prior_0, _value_0) {
  if (_same_0) {
    return {$: "../../../../../../bendvy/src/ecs/machine.Queued", "value": _prior_0, "skipSame": false};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/machine.Queued", "value": _value_0, "skipSame": true};
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, [[4],[]]);