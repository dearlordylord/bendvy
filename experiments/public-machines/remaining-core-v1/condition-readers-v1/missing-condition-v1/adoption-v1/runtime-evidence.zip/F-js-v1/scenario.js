function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $main$() {
  return $fail$045false$045consumer$058main_trace$1260$(($fail$045false$045consumer$058create$1260$()));
}

function $fail$045false$045consumer$058main_trace$1260$(_result_0) {
  if (_result_0.$ === "None") {
    return "fixture-rejected";
  } else {
    const _app_0 = _result_0["value"];
    return $fail$045false$045consumer$058first$1260$(($fail$045false$045consumer$058checkpoint$1260$(_app_0, "initial", "")));
  }
}

function $fail$045false$045consumer$058create$1260$() {
  return $fail$045false$045consumer$058created$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$()), ($$$$047$$$047provider$058initial_resources$1260$()))));
}

function $fail$045false$045consumer$058first$1260$(_pair_0) {
  const _app_0 = _pair_0["fst"];
  const _prior_0 = _pair_0["snd"];
  return $fail$045false$045consumer$058missing_checkpoint$1260$(($fail$045false$045consumer$058checkpoint$1260$(($fail$045false$045consumer$058run$1260$(_app_0)), "readers-register", _prior_0)));
}

function $fail$045false$045consumer$058checkpoint$1260$(_app_0, _label_0, _prior_0) {
  return $fail$045false$045consumer$058checkpoint_join$1260$(_label_0, _prior_0, ($fail$045false$045consumer$058observe$1260$(_app_0)));
}

function $fail$045false$045consumer$058created$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/world.CreateRejected") {
    return {$: "None"};
  } else {
    const _world_0 = _result_0["world"];
    return $fail$045false$045consumer$058seeded$1260$(($$$$047$$$047context$058runner$1260$(_world_0, {$: "../../gameplay.Seed"})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$() {
  return {$: "../../../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": 1};
}

function $$$$047$$$047provider$058initial_resources$1260$() {
  return {$: "../../provider.Resources", "owned": array_node([30], [130]), "flow": {$: "../../../../../../../../bendvy/src/ecs/machine.Present", "current": {$: "../../provider.Boot"}, "pending": {$: "../../../../../../../../bendvy/src/ecs/machine.NoPending"}, "previous": {$: "None"}, "changed": false}, "level": {$: "../../../../../../../../bendvy/src/ecs/machine.Present", "current": {$: "../../provider.Low"}, "pending": {$: "../../../../../../../../bendvy/src/ecs/machine.NoPending"}, "previous": {$: "None"}, "changed": false}, "flowStream": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058empty$1260$()), "levelStream": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058empty$1261$()), "frame": 0, "tick": 0, "trace": {$: "Nil"}};
}

function $fail$045false$045consumer$058missing_checkpoint$1260$(_pair_0) {
  const _app_0 = _pair_0["fst"];
  const _prior_0 = _pair_0["snd"];
  return $fail$045false$045consumer$058failed_checkpoint$1260$(($fail$045false$045consumer$058checkpoint$1260$(($fail$045false$045consumer$058missing$1260$(_app_0)), "missing-fixture", _prior_0)));
}

function $fail$045false$045consumer$058run$1260$(_app_0) {
  const _owners_0 = _app_0["owners"];
  const _world_0 = _app_0["world"];
  return $fail$045false$045consumer$058named$1260$(_owners_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(($$$$047$$$047provider$058frame$1260$(_world_0)))));
}

function $fail$045false$045consumer$058checkpoint_join$1260$(_label_0, _prior_0, _pair_0) {
  const _app_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  const _x_0 = (_text_0 + "\n");
  const _x_1 = (":" + _x_0);
  const _x_2 = (_label_0 + _x_1);
  return {$: "Tuple", "fst": _app_0, "snd": (_prior_0 + _x_2)};
}

function $fail$045false$045consumer$058observe$1260$(_app_0) {
  const _t_0 = _app_0["owners"];
  const _fast_0 = _t_0["fast"];
  const _slow_0 = _t_0["slow"];
  const _owned_0 = _t_0["owned"];
  const _deliveries_0 = _t_0["deliveries"];
  const _world_0 = _app_0["world"];
  const _observations_0 = _app_0["observations"];
  const _status_0 = _app_0["status"];
  return $fail$045false$045consumer$058owners_join$1260$(_deliveries_0, _observations_0, _status_0, ($fail$045false$045consumer$058instance$1260$(_fast_0)), ($fail$045false$045consumer$058instance$1260$(_slow_0)), ($$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1260$(_owned_0)), ($$$$047$$$047full$045observe$058world$1260$(_world_0)));
}

function $fail$045false$045consumer$058seeded$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/system.Succeeded") {
    const _world_0 = _result_0["world"];
    return $fail$045false$045consumer$058populated$1260$(_world_0);
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047context$058runner$1260$(_world_0, _operation_0) {
  return $$$$047$$$047context$058finish$1260$(($$$$047$$$047gameplay$058body$1260$(_operation_0, {$: "../../context.Frame", "tx": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1260$(($$$$047$$$047provider$058pulse$1260$(_world_0)))), "error": {$: "None"}})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/world.CreateRejected", "factory": {$: "../../../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/world.Created", "factory": {$: "../../../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($$$$047$$$047provider$058empty_store$1260$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058empty$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/machine-stream.Stream", "batches": {$: "Nil"}, "positions": {$: "Nil"}, "droppedThrough": 0, "frameStart": 0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058empty$1261$() {
  return {$: "../../../../../../../../bendvy/src/ecs/machine-stream.Stream", "batches": {$: "Nil"}, "positions": {$: "Nil"}, "droppedThrough": 0, "frameStart": 0};
}

function $fail$045false$045consumer$058failed_checkpoint$1260$(_pair_0) {
  const _app_0 = _pair_0["fst"];
  const _prior_0 = _pair_0["snd"];
  return $fail$045false$045consumer$058final$1260$(($fail$045false$045consumer$058checkpoint$1260$(($fail$045false$045consumer$058run$1260$(_app_0)), "missing-condition", _prior_0)));
}

function $fail$045false$045consumer$058missing$1260$(_app_0) {
  const _owners_0 = _app_0["owners"];
  const _world_0 = _app_0["world"];
  const _observations_0 = _app_0["observations"];
  const _status_0 = _app_0["status"];
  return {$: "fail-false-consumer.ReaderApplication", "owners": _owners_0, "world": ($$$$047$$$047provider$058map_resources$1260$(run_clo((_x_0) => {
  return $fail$045false$045consumer$058remove_flow$1260$(_x_0);
}), _world_0)), "observations": _observations_0, "status": _status_0};
}

function $fail$045false$045consumer$058named$1260$(_owners_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _namespace_0 = _pair_0["snd"];
  return $fail$045false$045consumer$058built$1260$(_world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build$1260$(_namespace_0, "ordinary-readers", {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/schedule.Phase", "name": "condition-preflight"}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/schedule.System", "id": 1, "condition": 1}, "tail": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/schedule.System", "id": 2, "condition": 2}, "tail": {$: "Nil"}}}}, {$: "Con", "head": 1, "tail": {$: "Con", "head": 2, "tail": {$: "Nil"}}}, _owners_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047$$$047provider$058frame$1260$(_world_0) {
  return $$$$047$$$047provider$058map_resources$1260$(run_clo((_x_0) => {
  return $$$$047$$$047provider$058frame_resources$1260$(_x_0);
}), _world_0);
}

function $fail$045false$045consumer$058owners_join$1260$(_deliveries_0, _observations_0, _status_0, _pairFast_0, _pairSlow_0, _pairOwned_0, _pairWorld_0) {
  const _fast_0 = _pairFast_0["fst"];
  const _a_0 = _pairFast_0["snd"];
  const _slow_0 = _pairSlow_0["fst"];
  const _b_0 = _pairSlow_0["snd"];
  const _owned_0 = _pairOwned_0["fst"];
  const _c_0 = _pairOwned_0["snd"];
  const _world_0 = _pairWorld_0["fst"];
  const _text_0 = _pairWorld_0["snd"];
  const _x_0 = ($List$show$1266$(_observations_0));
  const _x_1 = ("/status=" + _status_0);
  const _x_2 = (_x_0 + _x_1);
  const _x_3 = ($List$show$1265$(_deliveries_0));
  const _x_4 = ("/observations=" + _x_2);
  const _x_5 = (_x_3 + _x_4);
  const _x_6 = ("/deliveries=" + _x_5);
  const _x_7 = (_c_0 + _x_6);
  const _x_8 = ("/owners=" + _x_7);
  const _x_9 = (_b_0 + _x_8);
  const _x_10 = ("/slow=" + _x_9);
  const _x_11 = (_a_0 + _x_10);
  const _x_12 = ("/fast=" + _x_11);
  return {$: "Tuple", "fst": {$: "fail-false-consumer.ReaderApplication", "owners": {$: "fail-false-consumer.ReaderOwners", "fast": _fast_0, "slow": _slow_0, "owned": _owned_0, "deliveries": _deliveries_0}, "world": _world_0, "observations": _observations_0, "status": _status_0}, "snd": (_text_0 + _x_12)};
}

function $fail$045false$045consumer$058instance$1260$(_value_0) {
  const _t_0 = _value_0["registry"];
  const _ns_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _name_0 = _t_0["name"];
  const _access_0 = _t_0["access"];
  const _cursor_0 = _t_0["cursor"];
  const _t_1 = _value_0["flow"];
  const _fn_0 = _t_1["namespace"];
  const _fi_0 = _t_1["id"];
  const _t_2 = _value_0["level"];
  const _ln_0 = _t_2["namespace"];
  const _li_0 = _t_2["id"];
  const _x_0 = ($U32$show$(_li_0));
  const _x_1 = ($U32$show$(_ln_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_fi_0));
  const _x_5 = (":level=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($U32$show$(_fn_0));
  const _x_8 = (":" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($U32$show$(_cursor_0));
  const _x_11 = (":flow=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($List$show$1265$(_access_0));
  const _x_14 = (":cursor=" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = (":" + _x_15);
  const _x_17 = (_name_0 + _x_16);
  const _x_18 = ($U32$show$(_id_0));
  const _x_19 = (":" + _x_17);
  const _x_20 = (_x_18 + _x_19);
  const _x_21 = ($U32$show$(_ns_0));
  const _x_22 = (":" + _x_20);
  return {$: "Tuple", "fst": {$: "../../readers.Instance", "registry": {$: "../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "flow": {$: "../../../../../../../../bendvy/src/ecs/machine-stream.Reader", "namespace": _fn_0, "id": _fi_0}, "level": {$: "../../../../../../../../bendvy/src/ecs/machine-stream.Reader", "namespace": _ln_0, "id": _li_0}}, "snd": (_x_21 + _x_22)};
}

function $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1260$(_value_0) {
  if (_value_0.length === 1) {
    const _value_1 = _value_0[0];
    return $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058leaf$1260$(($$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058number$(_value_1)));
  } else {
    const _a_0 = _value_0.slice(0, _value_0.length >> 1);
    const _b_0 = _value_0.slice(_value_0.length >> 1);
    return $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_left$1260$(($$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1260$(_b_0)), ($$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1260$(_a_0)));
  }
}

function $$$$047$$$047full$045observe$058world$1260$(_world_0) {
  return $$$$047$$$047full$045observe$058old_observed$1260$(($$$$047$$$047full$045observe$058physical$1260$(_world_0)));
}

function $fail$045false$045consumer$058populated$1260$(_world_0) {
  return $fail$045false$045consumer$058fast_provisioned$1260$(($$$$047$$$047readers$058provision$1260$(($$$$047$$$047provider$058map_resources$1260$(run_clo((_x_0) => {
  return $fail$045false$045consumer$058fixture_resource$1260$(_x_0);
}), _world_0)), "fast")));
}

function $$$$047$$$047context$058finish$1260$(_pair_0) {
  const _t_0 = _pair_0["fst"];
  const _tx_0 = _t_0["tx"];
  const _error_0 = _t_0["error"];
  const _outcome_0 = _pair_0["snd"];
  return $$$$047$$$047context$058returned$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, ($$$$047$$$047context$058effective$(_outcome_0, _error_0)))));
}

function $$$$047$$$047gameplay$058body$1260$(_operation_0, _ctx_0) {
  if (_operation_0.$ === "../../gameplay.Seed") {
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058send$1260$(_ctx_0, {$: "../../gameplay.SeedCells", "owner": array_node([10], [99])})), "snd": {$: "../../../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else if (_operation_0.$ === "../../gameplay.Queue") {
    const _ctx_1 = run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1260$(_ctx_0, {$: "../../../../../../../../bendvy/src/ecs/machine.Set", "value": {$: "../../provider.Middle"}, "skipSame": false}));
    const _ctx_2 = run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1261$(_ctx_1, {$: "../../../../../../../../bendvy/src/ecs/machine.Set", "value": {$: "../../provider.Play"}, "skipSame": false}));
    const _ctx_3 = run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1262$(_ctx_2, {$: "../../../../../../../../bendvy/src/ecs/machine.Set", "value": {$: "../../provider.Pause"}, "skipSame": false}));
    return $$$$047$$$047gameplay$058queue_current$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1263$(_ctx_3)));
  } else if (_operation_0.$ === "../../gameplay.OldPending") {
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1261$(_ctx_0, {$: "../../../../../../../../bendvy/src/ecs/machine.Set", "value": {$: "../../provider.Boot"}, "skipSame": false})), "snd": {$: "../../../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else if (_operation_0.$ === "../../gameplay.FailingPublisher") {
    const _error_0 = _operation_0["error"];
    const _ctx_4 = run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058send$1261$(_ctx_0, array_node([88], [188])));
    const _ctx_5 = run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058send$1262$(_ctx_4, array_node([77], [177])));
    const _ctx_6 = run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1261$(_ctx_5, {$: "../../../../../../../../bendvy/src/ecs/machine.Set", "value": {$: "../../provider.Play"}, "skipSame": false}));
    const _ctx_7 = run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1260$(_ctx_6, {$: "../../../../../../../../bendvy/src/ecs/machine.Set", "value": {$: "../../provider.High"}, "skipSame": false}));
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058send$1260$(_ctx_7, {$: "../../gameplay.Empty"})), "snd": {$: "../../../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_0}};
  } else if (_operation_0.$ === "../../gameplay.Reset") {
    const _ctx_8 = run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1261$(_ctx_0, {$: "../../../../../../../../bendvy/src/ecs/machine.Set", "value": {$: "../../provider.Play"}, "skipSame": false}));
    return $$$$047$$$047gameplay$058reset_observed$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_get$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1262$(_ctx_8, {$: "../../../../../../../../bendvy/src/ecs/machine.Reset"})))));
  } else if (_operation_0.$ === "../../gameplay.MarkerQueues") {
    const _ctx_9 = run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1260$(_ctx_0, {$: "../../../../../../../../bendvy/src/ecs/machine.Set", "value": {$: "../../provider.Middle"}, "skipSame": false}));
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1261$(_ctx_9, {$: "../../../../../../../../bendvy/src/ecs/machine.Set", "value": {$: "../../provider.Pause"}, "skipSame": false})), "snd": {$: "../../../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else if (_operation_0.$ === "../../gameplay.SameSet") {
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1261$(_ctx_0, {$: "../../../../../../../../bendvy/src/ecs/machine.Set", "value": {$: "../../provider.Pause"}, "skipSame": false})), "snd": {$: "../../../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else if (_operation_0.$ === "../../gameplay.SameSkip") {
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1261$(_ctx_0, {$: "../../../../../../../../bendvy/src/ecs/machine.Set", "value": {$: "../../provider.Pause"}, "skipSame": true})), "snd": {$: "../../../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else if (_operation_0.$ === "../../gameplay.OverwriteSkip") {
    const _ctx_10 = run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1261$(_ctx_0, {$: "../../../../../../../../bendvy/src/ecs/machine.Set", "value": {$: "../../provider.Pause"}, "skipSame": true}));
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1262$(_ctx_10, {$: "../../../../../../../../bendvy/src/ecs/machine.Set", "value": {$: "../../provider.Pause"}, "skipSame": false})), "snd": {$: "../../../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else if (_operation_0.$ === "../../gameplay.PauseRequest") {
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1261$(_ctx_0, {$: "../../../../../../../../bendvy/src/ecs/machine.Set", "value": {$: "../../provider.Pause"}, "skipSame": false})), "snd": {$: "../../../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else if (_operation_0.$ === "../../gameplay.PlayRequest") {
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1261$(_ctx_0, {$: "../../../../../../../../bendvy/src/ecs/machine.Set", "value": {$: "../../provider.Play"}, "skipSame": false})), "snd": {$: "../../../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/transaction.Success"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047$$$047provider$058pulse$1260$(_world_0) {
  return $$$$047$$$047provider$058map_resources$1260$(run_clo((_x_0) => {
  return $$$$047$$$047provider$058pulse_resources$1260$(_x_0);
}), _world_0);
}

function $$$$047$$$047provider$058empty_store$1260$(__0) {
  return {$: "../../provider.Store", "cells": {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}}};
}

function $fail$045false$045consumer$058final$1260$(_pair_0) {
  const _text_0 = _pair_0["snd"];
  return _text_0;
}

function $$$$047$$$047provider$058map_resources$1260$(_effect_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _effect_0(_resources_0), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $fail$045false$045consumer$058remove_flow$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "../../provider.Resources", "owned": _owned_0, "flow": {$: "../../../../../../../../bendvy/src/ecs/machine.Missing"}, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0};
}

function $fail$045false$045consumer$058built$1260$(_world_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/schedule.Invalid") {
    const _owners_0 = _result_0["owners"];
    return {$: "fail-false-consumer.ReaderApplication", "owners": _owners_0, "world": _world_0, "observations": {$: "Nil"}, "status": "invalid"};
  } else {
    const _schedule_0 = _result_0["schedule"];
    return $fail$045false$045consumer$058scheduled$1260$(run_loop($fail$045false$058run_with_skip$1260$(_schedule_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build$1260$(_namespace_0, _name_0, _steps_0, _catalog_0, _owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build_checked$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058valid$(_steps_0, _catalog_0, {$: "Nil"})), _namespace_0, _name_0, _steps_0, _owners_0);
}

function $$$$047$$$047provider$058frame_resources$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "../../provider.Resources", "owned": _owned_0, "flow": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058clear_changed$1260$(_flow_0)), "level": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058clear_changed$1261$(_level_0)), "flowStream": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058frame$1260$(_flowStream_0, _tick_0)), "levelStream": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058frame$1261$(_levelStream_0, _tick_0)), "frame": nat_chk(_frame_0 + 1), "tick": _tick_0, "trace": _trace_0};
}

function $List$show$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1265$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return ("[" + _x_1);
  }
}

function $List$show$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($fail$045false$045consumer$058observation$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058leaf$1260$(_pair_0) {
  const _value_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": [_value_0], "snd": ("L(" + _x_0)};
}

function $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058number$(_value_0) {
  return $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058number_value$(_value_0);
}

function $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_left$1260$(_b_0, _pair_0) {
  const _a_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  return $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_right$1260$(_a_0, _text_0, _b_0);
}

function $$$$047$$$047full$045observe$058old_observed$1260$(_pair_0) {
  const _world_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  return $$$$047$$$047full$045observe$058joined$1260$(_text_0, ($$$$047$$$047observe$058world$1260$(_world_0)));
}

function $$$$047$$$047full$045observe$058physical$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _payload_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047full$045observe$058physical_join$1260$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _events_0, _pending_0, _registrations_0, _nextSystem_0, _clock_0, ($$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1261$(_live_0)), ($$$$047$$$047full$045observe$058store$1260$(_payload_0)), ($$$$047$$$047full$045observe$058resource$1260$(_resources_0)));
}

function $fail$045false$045consumer$058fast_provisioned$1260$(_result_0) {
  if (_result_0.$ === "../../readers.ProvisionFailed") {
    return {$: "None"};
  } else {
    const _world_0 = _result_0["world"];
    const _fast_0 = _result_0["instance"];
    return $fail$045false$045consumer$058slow_provisioned$1260$(_fast_0, ($$$$047$$$047readers$058provision$1260$(_world_0, "slow")));
  }
}

function $$$$047$$$047readers$058provision$1260$(_world_0, _name_0) {
  return $$$$047$$$047readers$058registered$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1260$(_world_0, _name_0, {$: "Con", "head": "transition.Flow.read", "tail": {$: "Con", "head": "transition.Level.read", "tail": {$: "Nil"}}})));
}

function $fail$045false$045consumer$058fixture_resource$1260$(_resource_0) {
  const _owned_0 = _resource_0["owned"];
  const _level_0 = _resource_0["level"];
  const _levelStream_0 = _resource_0["levelStream"];
  const _trace_0 = _resource_0["trace"];
  return {$: "../../provider.Resources", "owned": _owned_0, "flow": {$: "../../../../../../../../bendvy/src/ecs/machine.Present", "current": {$: "../../provider.Play"}, "pending": {$: "../../../../../../../../bendvy/src/ecs/machine.Queued", "value": {$: "../../provider.Boot"}, "skipSame": false}, "previous": {$: "Some", "value": {$: "../../provider.Boot"}}, "changed": true}, "level": _level_0, "flowStream": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058publish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058empty$1260$()), 1, {$: "../../../../../../../../bendvy/src/ecs/machine.Transition", "from": {$: "../../provider.Boot"}, "to": {$: "../../provider.Play"}})), "levelStream": _levelStream_0, "frame": 0, "tick": 1, "trace": _trace_0};
}

function $$$$047$$$047context$058returned$1260$(_result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/transaction.Success") {
    return {$: "../../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0);
}

function $$$$047$$$047context$058effective$(_outcome_0, _error_0) {
  if (_error_0.$ === "None") {
    return _outcome_0;
  } else {
    const _error_1 = _error_0["value"];
    return {$: "../../../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058send$1260$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058send_field$1260$(($$$$047$$$047gameplay$058spawn$1260$(($$$$047$$$047context$058work$1260$())))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1260$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_field$1260$(($$$$047$$$047gameplay$058level$1260$(($$$$047$$$047context$058work$1260$())))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1261$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_field$1261$(($$$$047$$$047gameplay$058flow$1260$(($$$$047$$$047context$058work$1260$())))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_set$1262$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_field$1261$(($$$$047$$$047gameplay$058alias$1260$(($$$$047$$$047context$058work$1260$())))))(_ctx_0), _value_0);
}

function $$$$047$$$047gameplay$058queue_current$1260$(_pair_0) {
  const _ctx_0 = _pair_0["fst"];
  const _current_0 = _pair_0["snd"];
  return $$$$047$$$047gameplay$058queue_observed$1260$(_current_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_get$1260$(_ctx_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1263$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1263$(($$$$047$$$047gameplay$058read_flow$1260$(($$$$047$$$047context$058work$1260$()))))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058send$1261$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058send_field$1261$(($$$$047$$$047gameplay$058cells$1260$(($$$$047$$$047context$058work$1260$())))))(_ctx_0), _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058send$1262$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058send_field$1261$(($$$$047$$$047gameplay$058owned$1260$(($$$$047$$$047context$058work$1260$())))))(_ctx_0), _value_0);
}

function $$$$047$$$047gameplay$058reset_observed$1260$(_pair_0) {
  const _ctx_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/machine.NoNext") {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/transaction.Failure", "error": "ResetObservationMismatch"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_get$1260$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_read_field$1260$(($$$$047$$$047gameplay$058alias$1260$(($$$$047$$$047context$058work$1260$()))))), _ctx_0);
}

function $$$$047$$$047provider$058pulse_resources$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": nat_chk(_tick_0 + 1), "trace": _trace_0};
}

function $fail$045false$045consumer$058scheduled$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/schedule.Finished") {
    const _t_0 = _result_0["schedule"];
    const _owners_0 = _t_0["owners"];
    const _world_0 = _result_0["world"];
    const _observations_0 = _result_0["observations"];
    return {$: "fail-false-consumer.ReaderApplication", "owners": _owners_0, "world": _world_0, "observations": _observations_0, "status": "finished"};
  } else if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/schedule.Failed") {
    const _t_1 = _result_0["schedule"];
    const _owners_1 = _t_1["owners"];
    const _world_1 = _result_0["world"];
    const _error_0 = _result_0["error"];
    const _observations_1 = _result_0["observations"];
    return {$: "fail-false-consumer.ReaderApplication", "owners": _owners_1, "world": _world_1, "observations": _observations_1, "status": _error_0};
  } else {
    const _t_2 = _result_0["schedule"];
    const _owners_2 = _t_2["owners"];
    const _world_2 = _result_0["world"];
    return {$: "fail-false-consumer.ReaderApplication", "owners": _owners_2, "world": _world_2, "observations": {$: "Nil"}, "status": "rejected"};
  }
}

function $fail$045false$058run_with_skip$1260$(_schedule_0, _world_0) {
  return $fail$045false$058run_namespace_skip$1260$(_schedule_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058build_checked$1260$(_allowed_0, _namespace_0, _name_0, _steps_0, _owners_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/schedule.Invalid", "owners": _owners_0};
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/schedule.Built", "schedule": {$: "../../../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058valid$($0, $1, $2) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _catalog_0 = $1;
      const _seen_0 = $2;
      if (_steps_0.$ === "Nil") {
        return true;
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/schedule.Phase") {
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _catalog_0;
          $2 = _seen_0;
          continue;
        } else if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _catalog_0;
          $2 = _seen_0;
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _rest_2 = _steps_0["tail"];
          return $Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058contains$(_catalog_0, _id_0)), ($Bool$and$(($Bool$not$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058contains$(_seen_0, _id_0)))), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058valid$(_rest_2, _catalog_0, {$: "Con", "head": _id_0, "tail": _seen_0})))));
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058clear_changed$1260$(_slot_0) {
  if (_slot_0.$ === "../../../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../../../bendvy/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    return {$: "../../../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": _pending_0, "previous": _previous_0, "changed": false};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058clear_changed$1261$(_slot_0) {
  if (_slot_0.$ === "../../../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../../../bendvy/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _pending_0 = _slot_0["pending"];
    const _previous_0 = _slot_0["previous"];
    return {$: "../../../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": _pending_0, "previous": _previous_0, "changed": false};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058frame$1260$(_stream_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058trimmed$1260$(_tick_0, _positions_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058trim_capacity$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_window$1260$(_batches_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058hold_boundary$(_positions_0, _frameStart_0)), _dropped_0)), 65536)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058frame$1261$(_stream_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058trimmed$1261$(_tick_0, _positions_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058trim_capacity$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_window$1261$(_batches_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058hold_boundary$(_positions_0, _frameStart_0)), _dropped_0)), 65536)));
}

function $List$show$go$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1265$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return (", " + _x_1);
  }
}

function $fail$045false$045consumer$058observation$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/schedule.Ran") {
    const _id_0 = _value_0["id"];
    const _x_0 = ($U32$show$(_id_0));
    return ("ran:" + _x_0);
  } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/schedule.Skipped") {
    const _id_1 = _value_0["id"];
    const _x_1 = ($U32$show$(_id_1));
    return ("skipped:" + _x_1);
  } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/schedule.Applied") {
    return "applied";
  } else {
    const _name_0 = _value_0["name"];
    return ("entered:" + _name_0);
  }
}

function $List$show$go$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($fail$045false$045consumer$058observation$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058number_value$(_value_0) {
  return {$: "Tuple", "fst": _value_0, "snd": ($U32$show$(_value_0))};
}

function $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_right$1260$(_a_0, _text_0, _pair_0) {
  const _b_0 = _pair_0["fst"];
  const _other_0 = _pair_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("N(" + _x_2)};
}

function $$$$047$$$047full$045observe$058joined$1260$(_prior_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  const _x_0 = ("/physical=" + _prior_0);
  return {$: "Tuple", "fst": _world_0, "snd": (_text_0 + _x_0)};
}

function $$$$047$$$047observe$058world$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047observe$058world_join$1260$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, ($$$$047$$$047observe$058live_view$(_live_0)), ($$$$047$$$047observe$058store_view$1260$(_store_0)), ($$$$047$$$047observe$058resources_view$1260$(_resources_0)), _events_0, ($$$$047$$$047observe$058queue_view$1260$(_commands_0)), _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047$$$047full$045observe$058physical_join$1260$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _events_0, _pending_0, _registrations_0, _nextSystem_0, _clock_0, _pairLive_0, _pairStore_0, _pairResource_0) {
  const _live_0 = _pairLive_0["fst"];
  const _a_0 = _pairLive_0["snd"];
  const _store_0 = _pairStore_0["fst"];
  const _b_0 = _pairStore_0["snd"];
  const _resource_0 = _pairResource_0["fst"];
  const _c_0 = _pairResource_0["snd"];
  const _x_0 = ($List$show$12615$(_events_0));
  const _x_1 = ("/bus=" + _x_0);
  const _x_2 = (_c_0 + _x_1);
  const _x_3 = ("/owned=" + _x_2);
  const _x_4 = (_b_0 + _x_3);
  const _x_5 = ("/cells=" + _x_4);
  const _x_6 = (_a_0 + _x_5);
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ("live=" + _x_6)};
}

function $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1261$(_value_0) {
  if (_value_0.length === 1) {
    const _value_1 = _value_0[0];
    return $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058leaf$1261$(($$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058boolean$(_value_1)));
  } else {
    const _a_0 = _value_0.slice(0, _value_0.length >> 1);
    const _b_0 = _value_0.slice(_value_0.length >> 1);
    return $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_left$1261$(($$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1261$(_b_0)), ($$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1261$(_a_0)));
  }
}

function $$$$047$$$047full$045observe$058store$1260$(_store_0) {
  const _t_0 = _store_0["cells"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _t_0["values"];
    const _stamps_0 = _t_0["stamps"];
    return $$$$047$$$047full$045observe$058column_join$1260$(_stamps_0, ($$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1262$(_values_0)));
  } else {
    return {$: "Tuple", "fst": {$: "../../provider.Store", "cells": _t_0}, "snd": "unsupported-column-fixture"};
  }
}

function $$$$047$$$047full$045observe$058resource$1260$(_resource_0) {
  const _owned_0 = _resource_0["owned"];
  const _flow_0 = _resource_0["flow"];
  const _level_0 = _resource_0["level"];
  const _flowStream_0 = _resource_0["flowStream"];
  const _levelStream_0 = _resource_0["levelStream"];
  const _frame_0 = _resource_0["frame"];
  const _tick_0 = _resource_0["tick"];
  const _trace_0 = _resource_0["trace"];
  return $$$$047$$$047full$045observe$058resource_join$1260$(_flow_0, _level_0, _flowStream_0, _levelStream_0, _frame_0, _tick_0, _trace_0, ($$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1260$(_owned_0)));
}

function $fail$045false$045consumer$058slow_provisioned$1260$(_fast_0, _result_0) {
  if (_result_0.$ === "../../readers.ProvisionFailed") {
    return {$: "None"};
  } else {
    const _world_0 = _result_0["world"];
    const _slow_0 = _result_0["instance"];
    return {$: "Some", "value": {$: "fail-false-consumer.ReaderApplication", "owners": {$: "fail-false-consumer.ReaderOwners", "fast": _fast_0, "slow": _slow_0, "owned": array_node([43], [59]), "deliveries": {$: "Nil"}}, "world": _world_0, "observations": {$: "Nil"}, "status": "ready"}};
  }
}

function $$$$047$$$047readers$058registered$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return $$$$047$$$047readers$058registered_identity$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058identity$1260$(_registry_0)));
  } else {
    const _world_1 = _result_0["world"];
    return {$: "../../readers.ProvisionFailed", "world": _world_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058publish$1260$(_stream_0, _tick_0, _event_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return {$: "../../../../../../../../bendvy/src/ecs/machine-stream.Stream", "batches": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1262$(_batches_0, {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": {$: "Con", "head": _event_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}})), "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058send_field$1260$(_cap_0) {
  const _send_0 = _cap_0["send"];
  return _send_0;
}

function $$$$047$$$047gameplay$058spawn$1260$(_caps_0) {
  const _cap_0 = _caps_0["spawn"];
  return _cap_0;
}

function $$$$047$$$047context$058work$1260$() {
  return {$: "../../gameplay.Work", "readFlow": {$: "../../../../../../../../bendvy/src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047context$058flow_current$1260$(_x_0);
})}, "flow": {$: "../../../../../../../../bendvy/src/ecs/capabilities.ValueWrite", "get": run_clo((_x_1) => {
  return $$$$047$$$047context$058flow_pending$1260$(_x_1);
}), "set": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047context$058flow_next$1260$(_x_2, _x_3);
});
})}, "alias": {$: "../../../../../../../../bendvy/src/ecs/capabilities.ValueWrite", "get": run_clo((_x_4) => {
  return $$$$047$$$047context$058flow_pending$1260$(_x_4);
}), "set": run_clo((_x_5) => {
  return run_clo((_x_6) => {
  return $$$$047$$$047context$058flow_next$1260$(_x_5, _x_6);
});
})}, "level": {$: "../../../../../../../../bendvy/src/ecs/capabilities.ValueWrite", "get": run_clo((_x_7) => {
  return $$$$047$$$047context$058level_pending$1260$(_x_7);
}), "set": run_clo((_x_8) => {
  return run_clo((_x_9) => {
  return $$$$047$$$047context$058level_next$1260$(_x_8, _x_9);
});
})}, "cells": {$: "../../../../../../../../bendvy/src/ecs/capabilities.Send", "send": run_clo((_x_10) => {
  return run_clo((_x_11) => {
  return $$$$047$$$047context$058cells_write$1260$(_x_10, _x_11);
});
})}, "owned": {$: "../../../../../../../../bendvy/src/ecs/capabilities.Send", "send": run_clo((_x_12) => {
  return run_clo((_x_13) => {
  return $$$$047$$$047context$058owned_write$1260$(_x_12, _x_13);
});
})}, "spawn": {$: "../../../../../../../../bendvy/src/ecs/capabilities.Send", "send": run_clo((_x_14) => {
  return run_clo((_x_15) => {
  return $$$$047$$$047context$058spawn$1260$(_x_14, _x_15);
});
})}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_field$1260$(_cap_0) {
  const _set_0 = _cap_0["set"];
  return _set_0;
}

function $$$$047$$$047gameplay$058level$1260$(_caps_0) {
  const _cap_0 = _caps_0["level"];
  return _cap_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_field$1261$(_cap_0) {
  const _set_0 = _cap_0["set"];
  return _set_0;
}

function $$$$047$$$047gameplay$058flow$1260$(_caps_0) {
  const _cap_0 = _caps_0["flow"];
  return _cap_0;
}

function $$$$047$$$047gameplay$058alias$1260$(_caps_0) {
  const _cap_0 = _caps_0["alias"];
  return _cap_0;
}

function $$$$047$$$047gameplay$058queue_observed$1260$(_current_0, _pair_0) {
  if (_current_0.$ === "../../../../../../../../bendvy/src/ecs/machine.Current") {
    const _t_0 = _current_0["value"];
    if (_t_0.$ === "../../provider.Boot") {
      const _ctx_0 = _pair_0["fst"];
      const _t_1 = _pair_0["snd"];
      if (_t_1.$ === "../../../../../../../../bendvy/src/ecs/machine.Next") {
        const _t_2 = _t_1["value"];
        if (_t_2.$ === "../../provider.Pause") {
          return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058send$1260$(_ctx_0, {$: "../../gameplay.Empty"})), "snd": {$: "../../../../../../../../bendvy/src/ecs/transaction.Success"}};
        } else {
          return {$: "Tuple", "fst": _ctx_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/transaction.Failure", "error": "AliasObservationMismatch"}};
        }
      } else {
        return {$: "Tuple", "fst": _ctx_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/transaction.Failure", "error": "AliasObservationMismatch"}};
      }
    } else {
      const _ctx_1 = _pair_0["fst"];
      return {$: "Tuple", "fst": _ctx_1, "snd": {$: "../../../../../../../../bendvy/src/ecs/transaction.Failure", "error": "AliasObservationMismatch"}};
    }
  } else {
    const _ctx_2 = _pair_0["fst"];
    return {$: "Tuple", "fst": _ctx_2, "snd": {$: "../../../../../../../../bendvy/src/ecs/transaction.Failure", "error": "AliasObservationMismatch"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1263$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047gameplay$058read_flow$1260$(_caps_0) {
  const _cap_0 = _caps_0["readFlow"];
  return _cap_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058send_field$1261$(_cap_0) {
  const _send_0 = _cap_0["send"];
  return _send_0;
}

function $$$$047$$$047gameplay$058cells$1260$(_caps_0) {
  const _cap_0 = _caps_0["cells"];
  return _cap_0;
}

function $$$$047$$$047gameplay$058owned$1260$(_caps_0) {
  const _cap_0 = _caps_0["owned"];
  return _cap_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_write_read_field$1260$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $fail$045false$058run_namespace_skip$1260$(_schedule_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $fail$045false$058run_actual_skip$1260$(_schedule_0, _world_0, _actual_0);
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058contains$(_ids_0, _id_0) {
  if (_ids_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    const _x_0 = (_head_0 === _id_0);
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058contains$(_rest_0, _id_0));
    return (_x_0 || _x_1);
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058trimmed$1260$(_frameStart_0, _positions_0, _result_0) {
  const _batches_0 = _result_0["batches"];
  const _dropped_0 = _result_0["dropped"];
  return {$: "../../../../../../../../bendvy/src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058trim_capacity$1260$(_trimmed_0, _capacity_0) {
  const _batches_0 = _trimmed_0["batches"];
  const _dropped_0 = _trimmed_0["dropped"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058at_capacity$1260$(_batches_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_window$1260$(_batches_0, _boundary_0, _dropped_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Trimmed", "batches": {$: "Nil"}, "dropped": _dropped_0};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_checked$1260$(($Nat$is_le$(_tick_0, _boundary_0)), _tick_0, _items_0, _rest_0, _dropped_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_window$1260$(_rest_0, _boundary_0, _x_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058hold_boundary$($0, $1) {
  for (;;) {
    {
      const _positions_0 = $0;
      const _boundary_0 = $1;
      if (_positions_0.$ === "Nil") {
        return _boundary_0;
      } else {
        const _t_0 = _positions_0["head"];
        const _cursor_0 = _t_0["cursor"];
        const _rest_0 = _positions_0["tail"];
        $0 = _rest_0;
        $1 = (_boundary_0 < _cursor_0 ? _boundary_0 : _cursor_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058trimmed$1261$(_frameStart_0, _positions_0, _result_0) {
  const _batches_0 = _result_0["batches"];
  const _dropped_0 = _result_0["dropped"];
  return {$: "../../../../../../../../bendvy/src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058trim_capacity$1261$(_trimmed_0, _capacity_0) {
  const _batches_0 = _trimmed_0["batches"];
  const _dropped_0 = _trimmed_0["dropped"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058at_capacity$1261$(_batches_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_window$1261$(_batches_0, _boundary_0, _dropped_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Trimmed", "batches": {$: "Nil"}, "dropped": _dropped_0};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_checked$1261$(($Nat$is_le$(_tick_0, _boundary_0)), _tick_0, _items_0, _rest_0, _dropped_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_window$1261$(_rest_0, _boundary_0, _x_0);
}));
  }
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047observe$058world_join$1260$(_ns_0, _next_0, _high_0, _capacity_0, _depth_0, _pairLive_0, _pairStore_0, _pairResources_0, _events_0, _pairCommands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _live_0 = _pairLive_0["fst"];
  const _liveValues_0 = _pairLive_0["snd"];
  const _store_0 = _pairStore_0["fst"];
  const _cells_0 = _pairStore_0["snd"];
  const _resources_0 = _pairResources_0["fst"];
  const _resourceText_0 = _pairResources_0["snd"];
  const _commands_0 = _pairCommands_0["fst"];
  const _commandCount_0 = _pairCommands_0["snd"];
  const _x_0 = ($Nat$show$(($List$length$(_events_0))));
  const _x_1 = ($U32$show$(_clock_0));
  const _x_2 = (";busEvents=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_nextSystem_0));
  const _x_5 = (";componentClock=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($List$show$1268$(_registrations_0));
  const _x_8 = (";nextSystem=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($Nat$show$(_commandCount_0));
  const _x_11 = (";registrations=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = (";queue=" + _x_12);
  const _x_14 = (_resourceText_0 + _x_13);
  const _x_15 = (";" + _x_14);
  const _x_16 = (_cells_0 + _x_15);
  const _x_17 = ($List$show$1267$(_liveValues_0));
  const _x_18 = (";cells=" + _x_16);
  const _x_19 = (_x_17 + _x_18);
  const _x_20 = ($Nat$show$(_depth_0));
  const _x_21 = (";live=" + _x_19);
  const _x_22 = (_x_20 + _x_21);
  const _x_23 = ($U32$show$(_capacity_0));
  const _x_24 = (";depth=" + _x_22);
  const _x_25 = (_x_23 + _x_24);
  const _x_26 = ($U32$show$(_high_0));
  const _x_27 = (";capacity=" + _x_25);
  const _x_28 = (_x_26 + _x_27);
  const _x_29 = ($U32$show$(_next_0));
  const _x_30 = (";high=" + _x_28);
  const _x_31 = (_x_29 + _x_30);
  const _x_32 = ($U32$show$(_ns_0));
  const _x_33 = (";next=" + _x_31);
  const _x_34 = (_x_32 + _x_33);
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": ("ns=" + _x_34)};
}

function $$$$047$$$047observe$058live_view$(_live_0) {
  if (_live_0.length === 1) {
    const _value_0 = _live_0[0];
    return {$: "Tuple", "fst": [_value_0], "snd": {$: "Con", "head": _value_0, "tail": {$: "Nil"}}};
  } else {
    const _left_0 = _live_0.slice(0, _live_0.length >> 1);
    const _right_0 = _live_0.slice(_live_0.length >> 1);
    return $$$$047$$$047observe$058live_join$(($$$$047$$$047observe$058live_view$(_left_0)), ($$$$047$$$047observe$058live_view$(_right_0)));
  }
}

function $$$$047$$$047observe$058store_view$1260$(_store_0) {
  const _column_0 = _store_0["cells"];
  return $$$$047$$$047observe$058store_join$1260$(($$$$047$$$047observe$058column_view$1260$(_column_0)));
}

function $$$$047$$$047observe$058resources_view$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return $$$$047$$$047observe$058resources_join$1260$(($$$$047$$$047observe$058owner_view$(_owned_0)), _flow_0, _level_0, _flowStream_0, _levelStream_0, _frame_0, _tick_0, _trace_0);
}

function $$$$047$$$047observe$058queue_view$1260$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047observe$058queue_join$1260$(_command_0, ($$$$047$$$047observe$058queue_view$1260$(_rest_0)));
  }
}

function $List$show$12615$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$12615$(_t_0));
    const _x_1 = ("Unit" + _x_0);
    return ("[" + _x_1);
  }
}

function $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058leaf$1261$(_pair_0) {
  const _value_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": [_value_0], "snd": ("L(" + _x_0)};
}

function $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058boolean$(_value_0) {
  return $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058boolean_value$(_value_0);
}

function $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_left$1261$(_b_0, _pair_0) {
  const _a_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  return $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_right$1261$(_a_0, _text_0, _b_0);
}

function $$$$047$$$047full$045observe$058column_join$1260$(_stamps_0, _pair_0) {
  const _values_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  const _x_0 = ($List$show$1269$(_stamps_0));
  const _x_1 = (":stamps=" + _x_0);
  return {$: "Tuple", "fst": {$: "../../provider.Store", "cells": {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}}, "snd": (_text_0 + _x_1)};
}

function $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1262$(_value_0) {
  if (_value_0.length === 1) {
    const _value_1 = _value_0[0];
    return $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058leaf$1262$(($$$$047$$$047full$045observe$058cell$(_value_1)));
  } else {
    const _a_0 = _value_0.slice(0, _value_0.length >> 1);
    const _b_0 = _value_0.slice(_value_0.length >> 1);
    return $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_left$1262$(($$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1262$(_b_0)), ($$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1262$(_a_0)));
  }
}

function $$$$047$$$047full$045observe$058resource_join$1260$(_flow_0, _level_0, _flowStream_0, _levelStream_0, _frame_0, _tick_0, _trace_0, _pair_0) {
  const _owned_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "snd": _text_0};
}

function $$$$047$$$047readers$058registered_identity$1260$(_named_0, _pair_0) {
  const _actual_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  const _registry_0 = _pair_0["fst"];
  const _id_0 = _pair_0["snd"];
  return {$: "../../readers.Provisioned", "world": _actual_0, "instance": {$: "../../readers.Instance", "registry": _registry_0, "flow": {$: "../../../../../../../../bendvy/src/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": _id_0}, "level": {$: "../../../../../../../../bendvy/src/ecs/machine-stream.Reader", "namespace": _namespace_0, "id": _id_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058identity$1260$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _id_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1260$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1262$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1262$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../../../bendvy/src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047context$058flow_current$1260$(_frame_0) {
  return $$$$047$$$047context$058flow_current_pair$1260$(($$$$047$$$047context$058flow_read$1260$(_frame_0)));
}

function $$$$047$$$047context$058flow_pending$1260$(_frame_0) {
  return $$$$047$$$047context$058flow_pending_pair$1260$(($$$$047$$$047context$058flow_read$1260$(_frame_0)));
}

function $$$$047$$$047context$058flow_next$1260$(_frame_0, _request_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return {$: "../../context.Frame", "tx": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058next_declared$1260$({$: "../../../../../../../../bendvy/src/ecs/machine.Family", "name": "Flow"}, _tx_0, _request_0)), "error": _error_0};
}

function $$$$047$$$047context$058level_pending$1260$(_frame_0) {
  return $$$$047$$$047context$058level_pending_pair$1260$(($$$$047$$$047context$058level_read$1260$(_frame_0)));
}

function $$$$047$$$047context$058level_next$1260$(_frame_0, _request_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return {$: "../../context.Frame", "tx": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058next_declared$1261$({$: "../../../../../../../../bendvy/src/ecs/machine.Family", "name": "Level"}, _tx_0, _request_0)), "error": _error_0};
}

function $$$$047$$$047context$058cells_write$1260$(_frame_0, _incoming_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return $$$$047$$$047context$058cells_result$1260$(($$$$047$$$047provider$058cells_set$1260$(_tx_0, _incoming_0)), _error_0);
}

function $$$$047$$$047context$058owned_write$1260$(_frame_0, _incoming_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return {$: "../../context.Frame", "tx": ($$$$047$$$047context$058owned_tx$1260$(_tx_0, _incoming_0)), "error": _error_0};
}

function $$$$047$$$047context$058spawn$1260$(_frame_0, _payload_0) {
  if (_payload_0.$ === "../../gameplay.Empty") {
    return $$$$047$$$047context$058spawn_empty$1260$(_frame_0);
  } else {
    const _owner_0 = _payload_0["owner"];
    return $$$$047$$$047context$058spawn_seed$1260$(_frame_0, _owner_0);
  }
}

function $fail$045false$058run_actual_skip$1260$(_schedule_0, _world_0, _actual_0) {
  const _namespace_0 = _schedule_0["namespace"];
  const _name_0 = _schedule_0["name"];
  const _steps_0 = _schedule_0["steps"];
  const _owners_0 = _schedule_0["owners"];
  return $fail$045false$058run_checked_skip$1260$((_namespace_0 === _actual_0), {$: "../../../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058at_capacity$1260$(_batches_0, _capacity_0, _dropped_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Trimmed", "batches": {$: "Nil"}, "dropped": _dropped_0};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size$1260$({$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}));
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058capacity_checked$1260$((_capacity_0 < _x_0), _tick_0, _items_0, _rest_0, _dropped_0, run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058at_capacity$1260$(_rest_0, _capacity_0, _x_1);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_checked$1260$(_remove_0, _tick_0, _items_0, _rest_0, _dropped_0, _ih_0) {
  if (!_remove_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Trimmed", "batches": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0));
  }
}

function $Nat$is_le$(_a_0, _b_0) {
  return $Cmp$is_le$(cmp_new(_a_0, _b_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058at_capacity$1261$(_batches_0, _capacity_0, _dropped_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Trimmed", "batches": {$: "Nil"}, "dropped": _dropped_0};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size$1261$({$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}));
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058capacity_checked$1261$((_capacity_0 < _x_0), _tick_0, _items_0, _rest_0, _dropped_0, run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058at_capacity$1261$(_rest_0, _capacity_0, _x_1);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058past_checked$1261$(_remove_0, _tick_0, _items_0, _rest_0, _dropped_0, _ih_0) {
  if (!_remove_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Trimmed", "batches": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0));
  }
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $List$show$1267$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047observe$058bool$(_h_0));
    const _x_1 = ($List$show$go$1267$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1268$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047observe$058registration$(_h_0));
    const _x_1 = ($List$show$go$1268$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$length$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = _xs_0["tail"];
    return nat_chk(($List$length$(_t_0)) + 1);
  }
}

function $$$$047$$$047observe$058live_join$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ($List$append$(_a_0, _b_0))};
}

function $$$$047$$$047observe$058store_join$1260$(_pair_0) {
  const _column_0 = _pair_0["fst"];
  const _view_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../provider.Store", "cells": _column_0}, "snd": _view_0};
}

function $$$$047$$$047observe$058column_view$1260$(_column_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047observe$058column_join$1260$(($$$$047$$$047observe$058cells_view$(_values_0)), _stamps_0);
  } else {
    return {$: "Tuple", "fst": _column_0, "snd": "UNSUPPORTED_COLUMN_ROUTE"};
  }
}

function $$$$047$$$047observe$058resources_join$1260$(_pair_0, _a_0, _b_0, _flowStream_0, _levelStream_0, _frame_0, _tick_0, _trace_0) {
  const _owned_0 = _pair_0["fst"];
  const _view_0 = _pair_0["snd"];
  const _x_0 = ($List$show$1261$(_trace_0));
  const _x_1 = ($Nat$show$(_tick_0));
  const _x_2 = (";hooks=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($Nat$show$(_frame_0));
  const _x_5 = (";tick=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($$$$047$$$047observe$058stream$1261$(_levelStream_0));
  const _x_8 = (";frame=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($$$$047$$$047observe$058stream$1260$(_flowStream_0));
  const _x_11 = (";levelStream=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($$$$047$$$047observe$058slot$1261$(_b_0));
  const _x_14 = (";flowStream=" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($$$$047$$$047observe$058slot$1260$(_a_0));
  const _x_17 = (";level=" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = (";flow=" + _x_18);
  const _x_20 = (_view_0 + _x_19);
  return {$: "Tuple", "fst": {$: "../../provider.Resources", "owned": _owned_0, "flow": _a_0, "level": _b_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "snd": ("owned=" + _x_20)};
}

function $$$$047$$$047observe$058owner_view$(_owner_0) {
  return $$$$047$$$047observe$058owner_view_join$(($$$$047$$$047provider$058array_view$(_owner_0)));
}

function $$$$047$$$047observe$058queue_join$1260$(_command_0, _pair_0) {
  const _rest_0 = _pair_0["fst"];
  const _count_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _rest_0}, "snd": nat_chk(_count_0 + 1)};
}

function $List$show$go$12615$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$12615$(_t_0));
    const _x_1 = ("Unit" + _x_0);
    return (", " + _x_1);
  }
}

function $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058boolean_value$(_value_0) {
  return {$: "Tuple", "fst": _value_0, "snd": ($Bool$show$(_value_0))};
}

function $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_right$1261$(_a_0, _text_0, _pair_0) {
  const _b_0 = _pair_0["fst"];
  const _other_0 = _pair_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("N(" + _x_2)};
}

function $List$show$1269$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047observe$058entry$(_h_0));
    const _x_1 = ($List$show$go$1269$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058leaf$1262$(_pair_0) {
  const _value_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": [_value_0], "snd": ("L(" + _x_0)};
}

function $$$$047$$$047full$045observe$058cell$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": "none"};
  } else {
    const _owner_0 = _value_0["value"];
    return $$$$047$$$047full$045observe$058cell_join$(($$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree$1260$(_owner_0)));
  }
}

function $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_left$1262$(_b_0, _pair_0) {
  const _a_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  return $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_right$1262$(_a_0, _text_0, _b_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1260$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1262$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1260$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue_list$1260$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1260$(_world_0, _events_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(_world_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047context$058flow_current_pair$1260$(_pair_0) {
  const _frame_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058current_view$1260$(_slot_0))};
}

function $$$$047$$$047context$058flow_read$1260$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return $$$$047$$$047context$058flow_read_pair$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read$1260$(_tx_0)), _error_0);
}

function $$$$047$$$047context$058flow_pending_pair$1260$(_pair_0) {
  const _frame_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058next_view$1260$(_slot_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058next_declared$1260$(__0, _tx_0, _request_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058next$1260$(_tx_0, _request_0);
}

function $$$$047$$$047context$058level_pending_pair$1260$(_pair_0) {
  const _frame_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058next_view$1261$(_slot_0))};
}

function $$$$047$$$047context$058level_read$1260$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return $$$$047$$$047context$058level_read_pair$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read$1261$(_tx_0)), _error_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058next_declared$1261$(__0, _tx_0, _request_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058next$1261$(_tx_0, _request_0);
}

function $$$$047$$$047context$058cells_result$1260$(_result_0, _error_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/component.Written") {
    const _tx_0 = _result_0["tx"];
    return {$: "../../context.Frame", "tx": _tx_0, "error": _error_0};
  } else if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/component.WriteRejected") {
    const _tx_1 = _result_0["tx"];
    return {$: "../../context.Frame", "tx": _tx_1, "error": ($$$$047$$$047context$058first_error$(_error_0, "ComponentWriteRejected"))};
  } else {
    const _tx_2 = _result_0["tx"];
    return {$: "../../context.Frame", "tx": _tx_2, "error": ($$$$047$$$047context$058first_error$(_error_0, "ComponentWriteFailure"))};
  }
}

function $$$$047$$$047provider$058cells_set$1260$(_tx_0, _owner_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047provider$058cells_set_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _owner_0);
}

function $$$$047$$$047context$058owned_tx$1260$(_tx_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047context$058owned_written$1260$(($$$$047$$$047context$058owned_replace$1260$(_world_0, _incoming_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047context$058spawn_empty$1260$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return $$$$047$$$047context$058spawned$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_spawn$1260$(_tx_0, {$: "Unit"})), _error_0);
}

function $$$$047$$$047context$058spawn_seed$1260$(_frame_0, _owner_0) {
  const _tx_0 = _frame_0["tx"];
  const _error_0 = _frame_0["error"];
  return $$$$047$$$047context$058spawned$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_spawn$1261$(_tx_0, _owner_0)), _error_0);
}

function $fail$045false$058run_checked_skip$1260$(_allowed_0, _schedule_0, _world_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/schedule.Rejected", "schedule": _schedule_0, "world": _world_0};
  } else {
    const _namespace_0 = _schedule_0["namespace"];
    const _name_0 = _schedule_0["name"];
    const _steps_0 = _schedule_0["steps"];
    const _owners_0 = _schedule_0["owners"];
    return $fail$045false$058execute_skip$1260$(_steps_0, _owners_0, _world_0, _namespace_0, _name_0, _steps_0, {$: "Nil"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058capacity_checked$1260$(_overflow_0, _tick_0, _items_0, _rest_0, _dropped_0, _ih_0) {
  if (!_overflow_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Trimmed", "batches": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size$1260$(_batches_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size_loop$1260$(_batches_0, 0);
}

function $Cmp$is_le$(_c_0) {
  if (_c_0.$ === "GT") {
    return false;
  } else {
    return true;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058capacity_checked$1261$(_overflow_0, _tick_0, _items_0, _rest_0, _dropped_0, _ih_0) {
  if (!_overflow_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Trimmed", "batches": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size$1261$(_batches_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size_loop$1261$(_batches_0, 0);
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $$$$047$$$047observe$058bool$(_value_0) {
  if (_value_0) {
    return "true";
  } else {
    return "false";
  }
}

function $List$show$go$1267$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047observe$058bool$(_h_0));
    const _x_1 = ($List$show$go$1267$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047observe$058registration$(_value_0) {
  const _id_0 = _value_0["id"];
  const _name_0 = _value_0["name"];
  const _access_0 = _value_0["access"];
  const _x_0 = ($List$show$1261$(_access_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_name_0 + _x_1);
  const _x_3 = ($U32$show$(_id_0));
  const _x_4 = (":" + _x_2);
  return (_x_3 + _x_4);
}

function $List$show$go$1268$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047observe$058registration$(_h_0));
    const _x_1 = ($List$show$go$1268$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $$$$047$$$047observe$058column_join$1260$(_pair_0, _stamps_0) {
  const _values_0 = _pair_0["fst"];
  const _views_0 = _pair_0["snd"];
  const _x_0 = ($List$show$1269$(_stamps_0));
  const _x_1 = ($List$show$1261$(_views_0));
  const _x_2 = (":stamps=" + _x_0);
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": (_x_1 + _x_2)};
}

function $$$$047$$$047observe$058cells_view$(_values_0) {
  if (_values_0.length === 1) {
    const _owner_0 = _values_0[0];
    return $$$$047$$$047observe$058cells_leaf$(($$$$047$$$047observe$058cell_view$(_owner_0)));
  } else {
    const _left_0 = _values_0.slice(0, _values_0.length >> 1);
    const _right_0 = _values_0.slice(_values_0.length >> 1);
    return $$$$047$$$047observe$058cells_join$(($$$$047$$$047observe$058cells_view$(_left_0)), ($$$$047$$$047observe$058cells_view$(_right_0)));
  }
}

function $$$$047$$$047observe$058slot$1260$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _last_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($$$$047$$$047observe$058bool$(_changed_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($$$$047$$$047observe$058previous$1260$(_last_0));
    const _x_3 = (",changed=" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($$$$047$$$047observe$058pending$1260$(_next_0));
    const _x_6 = (",previous=" + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($$$$047$$$047observe$058flow$(_current_0));
    const _x_9 = ("(pending=" + _x_7);
    return (_x_8 + _x_9);
  }
}

function $$$$047$$$047observe$058slot$1261$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/machine.Missing") {
    return "missing";
  } else {
    const _current_0 = _value_0["current"];
    const _next_0 = _value_0["pending"];
    const _last_0 = _value_0["previous"];
    const _changed_0 = _value_0["changed"];
    const _x_0 = ($$$$047$$$047observe$058bool$(_changed_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($$$$047$$$047observe$058previous$1261$(_last_0));
    const _x_3 = (",changed=" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = ($$$$047$$$047observe$058pending$1261$(_next_0));
    const _x_6 = (",previous=" + _x_4);
    const _x_7 = (_x_5 + _x_6);
    const _x_8 = ($$$$047$$$047observe$058level$(_current_0));
    const _x_9 = ("(pending=" + _x_7);
    return (_x_8 + _x_9);
  }
}

function $$$$047$$$047observe$058stream$1260$(_value_0) {
  const _batches_0 = _value_0["batches"];
  const _positions_0 = _value_0["positions"];
  const _dropped_0 = _value_0["droppedThrough"];
  const _frameStart_0 = _value_0["frameStart"];
  const _x_0 = ($Nat$show$(_frameStart_0));
  const _x_1 = ($Nat$show$(_dropped_0));
  const _x_2 = (",frameStart=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($List$show$12612$(_positions_0));
  const _x_5 = (",dropped=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($List$show$12610$(_batches_0));
  const _x_8 = (",positions=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  return ("batches=" + _x_9);
}

function $$$$047$$$047observe$058stream$1261$(_value_0) {
  const _batches_0 = _value_0["batches"];
  const _positions_0 = _value_0["positions"];
  const _dropped_0 = _value_0["droppedThrough"];
  const _frameStart_0 = _value_0["frameStart"];
  const _x_0 = ($Nat$show$(_frameStart_0));
  const _x_1 = ($Nat$show$(_dropped_0));
  const _x_2 = (",frameStart=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($List$show$12612$(_positions_0));
  const _x_5 = (",dropped=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($List$show$12613$(_batches_0));
  const _x_8 = (",positions=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  return ("batches=" + _x_9);
}

function $List$show$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047observe$058text$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047observe$058owner_view_join$(_pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _values_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": ($List$show$1260$(_values_0))};
}

function $$$$047$$$047provider$058array_view$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return {$: "Tuple", "fst": [_value_0], "snd": {$: "Con", "head": _value_0, "tail": {$: "Nil"}}};
  } else {
    const _left_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _right_0 = _owner_0.slice(_owner_0.length >> 1);
    return $$$$047$$$047provider$058array_join$(($$$$047$$$047provider$058array_view$(_left_0)), ($$$$047$$$047provider$058array_view$(_right_0)));
  }
}

function $Bool$show$(_b_0) {
  if (!_b_0) {
    return "False";
  } else {
    return "True";
  }
}

function $$$$047$$$047observe$058entry$(_value_0) {
  const _id_0 = _value_0["id"];
  const _t_0 = _value_0["stamp"];
  const _added_0 = _t_0["added"];
  const _changed_0 = _t_0["changed"];
  const _x_0 = ($U32$show$(_changed_0));
  const _x_1 = ($U32$show$(_added_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_id_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$1269$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047observe$058entry$(_h_0));
    const _x_1 = ($List$show$go$1269$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047full$045observe$058cell_join$(_pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": _owner_0}, "snd": ("some:" + _text_0)};
}

function $$$$047$$$047$$$047marker$045phases$045v1$047apply$045retention$045v1$047consumer$058tree_right$1262$(_a_0, _text_0, _pair_0) {
  const _b_0 = _pair_0["fst"];
  const _other_0 = _pair_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("N(" + _x_2)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/world.RegistrationRejected") {
    return {$: "../../../../../../../../bendvy/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../../../../../bendvy/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.RegistrationRejected", "error": {$: "../../../../../../../../bendvy/src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue_list$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058current_view$1260$(_slot_0) {
  if (_slot_0.$ === "../../../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../../../bendvy/src/ecs/machine.Unavailable"};
  } else {
    const _current_0 = _slot_0["current"];
    return {$: "../../../../../../../../bendvy/src/ecs/machine.Current", "value": _current_0};
  }
}

function $$$$047$$$047context$058flow_read_pair$1260$(_pair_0, _error_0) {
  const _tx_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../context.Frame", "tx": _tx_0, "error": _error_0}, "snd": _slot_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read$1260$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read_taken$1260$(($$$$047$$$047provider$058flow_take$1260$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058next_view$1260$(_slot_0) {
  if (_slot_0.$ === "../../../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../../../bendvy/src/ecs/machine.NoNext"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058pending_view$1260$(_pending_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058next$1260$(_tx_0, _request_0) {
  if (_request_0.$ === "../../../../../../../../bendvy/src/ecs/machine.Set") {
    const _value_0 = _request_0["value"];
    const _skipSame_0 = _request_0["skipSame"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058write$1260$(_tx_0, _value_0, _skipSame_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_tx$1260$(_tx_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058next_view$1261$(_slot_0) {
  if (_slot_0.$ === "../../../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../../../bendvy/src/ecs/machine.NoNext"};
  } else {
    const _pending_0 = _slot_0["pending"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058pending_view$1261$(_pending_0);
  }
}

function $$$$047$$$047context$058level_read_pair$1260$(_pair_0, _error_0) {
  const _tx_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../context.Frame", "tx": _tx_0, "error": _error_0}, "snd": _slot_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read$1261$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read_taken$1261$(($$$$047$$$047provider$058level_take$1260$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058next$1261$(_tx_0, _request_0) {
  if (_request_0.$ === "../../../../../../../../bendvy/src/ecs/machine.Set") {
    const _value_0 = _request_0["value"];
    const _skipSame_0 = _request_0["skipSame"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058write$1261$(_tx_0, _value_0, _skipSame_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_tx$1261$(_tx_0);
  }
}

function $$$$047$$$047context$058first_error$(_old_0, _next_0) {
  if (_old_0.$ === "None") {
    return {$: "Some", "value": _next_0};
  } else {
    return _old_0;
  }
}

function $$$$047$$$047provider$058cells_set_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _owner_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _bus_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_set$1260$({$: "../../../../../../../../bendvy/src/ecs/component.Family", "name": "cells"}, {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _bus_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _ns_0, "id": 1}, _owner_0);
}

function $$$$047$$$047context$058owned_written$1260$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047context$058owned_restore$1260$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047context$058owned_replace$1260$(_world_0, _incoming_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _old_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _flowStream_0 = _t_0["flowStream"];
  const _levelStream_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _trace_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../../provider.Resources", "owned": _incoming_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _old_0};
}

function $$$$047$$$047context$058spawned$1260$(_result_0, _error_0) {
  const _tx_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/world.Reserved") {
    return {$: "../../context.Frame", "tx": _tx_0, "error": _error_0};
  } else {
    return {$: "../../context.Frame", "tx": _tx_0, "error": ($$$$047$$$047context$058first_error$(_error_0, "SpawnRejected"))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_spawn$1260$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_join$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1260$(_world_0)), _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_spawn$1261$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_join$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1260$(_world_0)), _undo_0, _commands_0, _events_0, _payload_0);
}

function $fail$045false$058execute_skip$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _owners_0 = $1;
      const _world_0 = $2;
      const _namespace_0 = $3;
      const _name_0 = $4;
      const _all_0 = $5;
      const _observations_0 = $6;
      if (_steps_0.$ === "Nil") {
        return {$: "../../../../../../../../bendvy/src/ecs/schedule.Finished", "schedule": {$: "../../../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "observations": _observations_0};
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/schedule.Phase") {
          const _phase_0 = _t_0["name"];
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _owners_0;
          $2 = _world_0;
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/schedule.Entered", "name": _phase_0}, "tail": {$: "Nil"}}));
          continue;
        } else if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _owners_0;
          $2 = run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058barrier$1260$(_world_0));
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/schedule.Applied"}, "tail": {$: "Nil"}}));
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _slot_0 = _t_0["condition"];
          const _rest_2 = _steps_0["tail"];
          return $fail$045false$058after_condition$1260$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $fail$045false$058execute_skip$1260$(_rest_2, _x_0, _x_1, _namespace_0, _name_0, _all_0, _x_2);
});
});
}), ($fail$045false$045consumer$058condition$1260$(_world_0, _slot_0)), _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size_loop$1260$($0, $1) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _acc_0 = $1;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1260$(_items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058size_loop$1261$($0, $1) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _acc_0 = $1;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1261$(_items_0, _acc_0));
        continue;
      }
    }
  }
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047observe$058cells_leaf$(_pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _text_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": [_owner_0], "snd": {$: "Con", "head": _text_0, "tail": {$: "Nil"}}};
}

function $$$$047$$$047observe$058cell_view$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": "none"};
  } else {
    const _owner_0 = _value_0["value"];
    return $$$$047$$$047observe$058cell_view_join$(($$$$047$$$047observe$058owner_view$(_owner_0)));
  }
}

function $$$$047$$$047observe$058cells_join$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ($List$append$(_a_0, _b_0))};
}

function $$$$047$$$047observe$058flow$(_value_0) {
  if (_value_0.$ === "../../provider.Boot") {
    return "Boot";
  } else if (_value_0.$ === "../../provider.Play") {
    return "Play";
  } else {
    return "Pause";
  }
}

function $$$$047$$$047observe$058pending$1260$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/machine.NoPending") {
    return "none";
  } else {
    const _value_1 = _value_0["value"];
    const _skip_0 = _value_0["skipSame"];
    const _x_0 = ($$$$047$$$047observe$058bool$(_skip_0));
    const _x_1 = ($$$$047$$$047observe$058flow$(_value_1));
    const _x_2 = (":" + _x_0);
    return (_x_1 + _x_2);
  }
}

function $$$$047$$$047observe$058previous$1260$(_value_0) {
  if (_value_0.$ === "None") {
    return "none";
  } else {
    const _value_1 = _value_0["value"];
    return $$$$047$$$047observe$058flow$(_value_1);
  }
}

function $$$$047$$$047observe$058level$(_value_0) {
  if (_value_0.$ === "../../provider.Low") {
    return "0";
  } else if (_value_0.$ === "../../provider.Middle") {
    return "1";
  } else {
    return "2";
  }
}

function $$$$047$$$047observe$058pending$1261$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/machine.NoPending") {
    return "none";
  } else {
    const _value_1 = _value_0["value"];
    const _skip_0 = _value_0["skipSame"];
    const _x_0 = ($$$$047$$$047observe$058bool$(_skip_0));
    const _x_1 = ($$$$047$$$047observe$058level$(_value_1));
    const _x_2 = (":" + _x_0);
    return (_x_1 + _x_2);
  }
}

function $$$$047$$$047observe$058previous$1261$(_value_0) {
  if (_value_0.$ === "None") {
    return "none";
  } else {
    const _value_1 = _value_0["value"];
    return $$$$047$$$047observe$058level$(_value_1);
  }
}

function $List$show$12610$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047observe$058batch$1260$(_h_0));
    const _x_1 = ($List$show$go$12611$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12612$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047observe$058position$(_h_0));
    const _x_1 = ($List$show$go$12612$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12613$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047observe$058batch$1261$(_h_0));
    const _x_1 = ($List$show$go$12614$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047observe$058text$(_value_0) {
  return _value_0;
}

function $List$show$go$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047observe$058text$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $List$show$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047provider$058array_join$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ($List$append$(_a_0, _b_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read_taken$1260$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _slot_0};
}

function $$$$047$$$047provider$058flow_take$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1261$(_world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058pending_view$1260$(_pending_0) {
  if (_pending_0.$ === "../../../../../../../../bendvy/src/ecs/machine.NoPending") {
    return {$: "../../../../../../../../bendvy/src/ecs/machine.NoNext"};
  } else {
    const _value_0 = _pending_0["value"];
    return {$: "../../../../../../../../bendvy/src/ecs/machine.Next", "value": _value_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058write$1260$(_tx_0, _value_0, _skipSame_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058write_taken$1260$(($$$$047$$$047provider$058flow_take$1260$(_world_0)), _undo_0, _commands_0, _events_0, _value_0, _skipSame_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_tx$1260$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_taken$1260$(($$$$047$$$047provider$058flow_take$1260$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058pending_view$1261$(_pending_0) {
  if (_pending_0.$ === "../../../../../../../../bendvy/src/ecs/machine.NoPending") {
    return {$: "../../../../../../../../bendvy/src/ecs/machine.NoNext"};
  } else {
    const _value_0 = _pending_0["value"];
    return {$: "../../../../../../../../bendvy/src/ecs/machine.Next", "value": _value_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058read_taken$1261$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _slot_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _slot_0};
}

function $$$$047$$$047provider$058level_take$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1262$(_world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058write$1261$(_tx_0, _value_0, _skipSame_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058write_taken$1261$(($$$$047$$$047provider$058level_take$1260$(_world_0)), _undo_0, _commands_0, _events_0, _value_0, _skipSame_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_tx$1261$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_taken$1261$(($$$$047$$$047provider$058level_take$1260$(_world_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_set$1260$(_family_0, _tx_0, _handle_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_set_fused$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_allowed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0)));
}

function $$$$047$$$047context$058owned_restore$1260$(_world_0, _old_0) {
  return $$$$047$$$047context$058owned_restored$1260$(($$$$047$$$047context$058owned_replace$1260$(_world_0, _old_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_join$1260$(_reserved_0, _undo_0, _commands_0, _events_0, _payload_0) {
  const _world_0 = _reserved_0["fst"];
  const _reservation_0 = _reserved_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_reserved$1260$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_available$1260$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_join$1261$(_reserved_0, _undo_0, _commands_0, _events_0, _payload_0) {
  const _world_0 = _reserved_0["fst"];
  const _reservation_0 = _reserved_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_reserved$1261$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058barrier$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1260$(_pending_0, {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $fail$045false$058after_condition$1260$(_next_0, _checked_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (_t_0.$ === "Fail") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058conditioned_skip$1260$(_next_0, false, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
  } else {
    const _allowed_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058conditioned_skip$1260$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
  }
}

function $fail$045false$045consumer$058condition$1260$(_world_0, _id_0) {
  return $fail$045false$045consumer$058checked$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058run$1260$(_id_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058count_loop$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $$$$047$$$047observe$058cell_view_join$(_value_0) {
  const _owner_0 = _value_0["fst"];
  const _text_0 = _value_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": _owner_0}, "snd": _text_0};
}

function $$$$047$$$047observe$058batch$1260$(_value_0) {
  const _tick_0 = _value_0["tick"];
  const _values_0 = _value_0["values"];
  const _x_0 = ($List$show$12611$(_values_0));
  const _x_1 = ($Nat$show$(_tick_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$12611$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047observe$058batch$1260$(_h_0));
    const _x_1 = ($List$show$go$12611$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047observe$058position$(_value_0) {
  const _id_0 = _value_0["id"];
  const _cursor_0 = _value_0["cursor"];
  const _registered_0 = _value_0["registeredAt"];
  const _x_0 = ($Nat$show$(_registered_0));
  const _x_1 = ($Nat$show$(_cursor_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_id_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$12612$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047observe$058position$(_h_0));
    const _x_1 = ($List$show$go$12612$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047observe$058batch$1261$(_value_0) {
  const _tick_0 = _value_0["tick"];
  const _values_0 = _value_0["values"];
  const _x_0 = ($List$show$12614$(_values_0));
  const _x_1 = ($Nat$show$(_tick_0));
  const _x_2 = (":" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$12614$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047observe$058batch$1261$(_h_0));
    const _x_1 = ($List$show$go$12614$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $List$show$go$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1261$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take_join$1260$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, ($$$$047$$$047provider$058flow_take_resource$1260$(_resources_0)), _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058write_taken$1260$(_pair_0, _undo_0, _commands_0, _events_0, _value_0, _skipSame_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": ($$$$047$$$047provider$058flow_put$1260$(_world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058queue$1260$(_old_0, _value_0, _skipSame_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047provider$058flow_put$1260$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_taken$1260$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": ($$$$047$$$047provider$058flow_put$1260$(_world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset$1260$(_old_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047provider$058flow_put$1260$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1262$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take_join$1261$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, ($$$$047$$$047provider$058level_take_resource$1260$(_resources_0)), _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058write_taken$1261$(_pair_0, _undo_0, _commands_0, _events_0, _value_0, _skipSame_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": ($$$$047$$$047provider$058level_put$1260$(_world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058queue$1261$(_old_0, _value_0, _skipSame_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047provider$058level_put$1260$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset_taken$1261$(_pair_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _pair_0["fst"];
  const _old_0 = _pair_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": ($$$$047$$$047provider$058level_put$1260$(_world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset$1261$(_old_0)))), "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047provider$058level_put$1260$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_set_fused$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _observed_0) {
  const _result_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_written$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": {$: "Some", "value": _incoming_0}, "error": {$: "../../../../../../../../bendvy/src/ecs/world.MissingEntity"}}, "snd": {$: "../../../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_world$1260$(_id_0, _incoming_0, _world_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1260$(_handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047context$058owned_restored$1260$(_pair_0) {
  const _world_0 = _pair_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_reserved$1260$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0) {
  if (_reservation_0.$ === "../../../../../../../../bendvy/src/ecs/world.ReservationRejected") {
    const _error_0 = _reservation_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.ReservationRejected", "error": _error_0}};
  } else {
    const _handle_0 = _reservation_0["handle"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_apply$1260$(_x_0, _handle_0, _payload_0);
}), "tail": _commands_0}, "events": _events_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.Reserved", "handle": _handle_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_available$1260$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.ReservationRejected", "error": {$: "../../../../../../../../bendvy/src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1260$({$: "../../../../../../../../bendvy/src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_reserved$1261$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0) {
  if (_reservation_0.$ === "../../../../../../../../bendvy/src/ecs/world.ReservationRejected") {
    const _error_0 = _reservation_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.ReservationRejected", "error": _error_0}};
  } else {
    const _handle_0 = _reservation_0["handle"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_apply$1261$(_x_0, _handle_0, _payload_0);
}), "tail": _commands_0}, "events": _events_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.Reserved", "handle": _handle_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1260$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1260$(_rest_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058conditioned_skip$1260$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (!_allowed_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_skip$1260$(_next_0, ($fail$045false$045consumer$058skip$1260$(_owners_0, _world_0, _id_0)), ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/schedule.Skipped", "id": _id_0}, "tail": {$: "Nil"}})));
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_dispatch$1260$(_next_0, ($fail$045false$045consumer$058dispatch$1260$(_owners_0, _world_0, _id_0)), _namespace_0, _name_0, _all_0, _observations_0, _id_0);
  }
}

function $fail$045false$045consumer$058checked$1260$(_result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["result"];
  if (_t_0.$ === "Done") {
    const _allowed_0 = _t_0["value"];
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Done", "value": _allowed_0}};
  } else {
    const _t_1 = _t_0["error"];
    const _names_0 = _t_1["resources"];
    const _x_0 = ($List$show$1265$(_names_0));
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Fail", "error": ("ConditionMissing:" + _x_0)}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058run$1260$(_args_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058ready$1260$(_args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058required_field$1260$(($fail$045false$045consumer$058condition_plan$1260$())))(_world_0));
}

function $List$show$12611$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047observe$058transition$1260$(_h_0));
    const _x_1 = ($List$show$go$12610$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12614$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047observe$058transition$1261$(_h_0));
    const _x_1 = ($List$show$go$12613$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take_join$1260$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _split_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _resources_0 = _split_0["fst"];
  const _slot_0 = _split_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _slot_0};
}

function $$$$047$$$047provider$058flow_take_resource$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "Tuple", "fst": {$: "../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "snd": _flow_0};
}

function $$$$047$$$047provider$058flow_put$1260$(_world_0, _slot_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1260$(_world_0, _slot_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058queue$1260$(_slot_0, _value_0, _skipSame_0) {
  if (_slot_0.$ === "../../../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../../../bendvy/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../../../../../bendvy/src/ecs/machine.Queued", "value": _value_0, "skipSame": _skipSame_0}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset$1260$(_slot_0) {
  if (_slot_0.$ === "../../../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../../../bendvy/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../../../../../bendvy/src/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take_join$1261$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, _split_0, _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0) {
  const _resources_0 = _split_0["fst"];
  const _slot_0 = _split_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": _slot_0};
}

function $$$$047$$$047provider$058level_take_resource$1260$(_resources_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "Tuple", "fst": {$: "../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "snd": _level_0};
}

function $$$$047$$$047provider$058level_put$1260$(_world_0, _slot_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1261$(_world_0, _slot_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058queue$1261$(_slot_0, _value_0, _skipSame_0) {
  if (_slot_0.$ === "../../../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../../../bendvy/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../../../../../bendvy/src/ecs/machine.Queued", "value": _value_0, "skipSame": _skipSame_0}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058reset$1261$(_slot_0) {
  if (_slot_0.$ === "../../../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "../../../../../../../../bendvy/src/ecs/machine.Missing"};
  } else {
    const _current_0 = _slot_0["current"];
    const _previous_0 = _slot_0["previous"];
    const _changed_0 = _slot_0["changed"];
    return {$: "../../../../../../../../bendvy/src/ecs/machine.Present", "current": _current_0, "pending": {$: "../../../../../../../../bendvy/src/ecs/machine.NoPending"}, "previous": _previous_0, "changed": _changed_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_written$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../../../../../../../bendvy/src/ecs/component.Written", "tx": {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp$1260$(_handle_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore$1260$(_family_0, _handle_0, _previous_0, _x_0)));
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["incoming"];
    if (_t_0.$ === "Some") {
      const _incoming_0 = _t_0["value"];
      const _error_0 = _result_0["error"];
      return {$: "../../../../../../../../bendvy/src/ecs/component.WriteRejected", "tx": {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "incoming": _incoming_0, "error": _error_0};
    } else {
      const _error_1 = _result_0["error"];
      return {$: "../../../../../../../../bendvy/src/ecs/component.WriteFailure", "tx": {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "error": _error_1};
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_world$1260$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_replaced$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_store$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))), (_clock_0 < 4294967295), ($$$$047$$$047provider$058store_take$1260$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1260$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_apply$1260$(_world_0, _handle_0, _payload_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawned$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1260$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.Reserved", "handle": {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "../../../../../../../../bendvy/src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_apply$1261$(_world_0, _handle_0, _payload_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawned$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_skip$1260$(_next_0, _returned_0, _observations_0) {
  const _owners_0 = _returned_0["fst"];
  const _world_0 = _returned_0["snd"];
  return run_tail(_next_0(_owners_0)(_world_0), _observations_0);
}

function $fail$045false$045consumer$058skip$1260$(_owners_0, _world_0, _id_0) {
  const _fast_0 = _owners_0["fast"];
  const _slow_0 = _owners_0["slow"];
  const _owned_0 = _owners_0["owned"];
  const _prior_0 = _owners_0["deliveries"];
  if (_id_0 == 1) {
    return $fail$045false$045consumer$058skip_returned$1260$(_slow_0, _owned_0, _prior_0, 1, ($$$$047$$$047readers$058skip$1260$(_fast_0, _world_0)));
  } else {
    return $fail$045false$045consumer$058skip_returned$1260$(_fast_0, _owned_0, _prior_0, 2, ($$$$047$$$047readers$058skip$1260$(_slow_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_dispatch$1260$(_next_0, _result_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _owners_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_outcome$1260$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $fail$045false$045consumer$058dispatch$1260$(_owners_0, _world_0, _id_0) {
  const _fast_0 = _owners_0["fast"];
  const _slow_0 = _owners_0["slow"];
  const _owned_0 = _owners_0["owned"];
  const _prior_0 = _owners_0["deliveries"];
  if (_id_0 == 1) {
    return $fail$045false$045consumer$058reader_returned$1260$(_slow_0, _owned_0, _prior_0, 1, ($$$$047$$$047readers$058invoke$1260$(_fast_0, _world_0, false)));
  } else {
    return $fail$045false$045consumer$058reader_returned$1260$(_fast_0, _owned_0, _prior_0, 2, ($$$$047$$$047readers$058invoke$1260$(_slow_0, _world_0, false)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058ready$1260$(_args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058completed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1260$(_args_0, {$: "../../../../../../../../bendvy/src/ecs/check.Frame", "world": _world_0})));
  } else {
    const _name_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    return {$: "../../../../../../../../bendvy/src/ecs/check.Checked", "world": _world_0, "result": {$: "Fail", "error": {$: "../../../../../../../../bendvy/src/ecs/check.MissingRuntimeRequirements", "resources": {$: "Con", "head": _name_0, "tail": _rest_0}}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058required_field$1260$(_plan_0) {
  const _required_0 = _plan_0["required"];
  return _required_0;
}

function $fail$045false$045consumer$058condition_plan$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/check.Plan", "required": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058required$1260$(_x_0);
}), "caps": {$: "fail-false-consumer.ConditionWork", "flow": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058condition$1260$())}};
}

function $$$$047$$$047observe$058transition$1260$(_value_0) {
  const _from_0 = _value_0["from"];
  const _to_0 = _value_0["to"];
  const _x_0 = ($$$$047$$$047observe$058flow$(_to_0));
  const _x_1 = ($$$$047$$$047observe$058flow$(_from_0));
  const _x_2 = (">" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$12610$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047observe$058transition$1260$(_h_0));
    const _x_1 = ($List$show$go$12610$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047observe$058transition$1261$(_value_0) {
  const _from_0 = _value_0["from"];
  const _to_0 = _value_0["to"];
  const _x_0 = ($$$$047$$$047observe$058level$(_to_0));
  const _x_1 = ($$$$047$$$047observe$058level$(_from_0));
  const _x_2 = (">" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$12613$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047observe$058transition$1261$(_h_0));
    const _x_1 = ($List$show$go$12613$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1260$(_world_0, _slot_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": ($$$$047$$$047provider$058flow_put_resource$1260$(_resources_0, _slot_0)), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058put$1261$(_world_0, _slot_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": ($$$$047$$$047provider$058level_put_resource$1260$(_resources_0, _slot_0)), "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp$1260$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_done$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_world$1260$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore$1260$(_family_0, _handle_0, _incoming_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_allowed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_replaced$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _t_1 = _t_0["fst"];
  if (_t_1.$ === "../../../../../../../../bendvy/src/ecs/component.Swapped") {
    const _previous_0 = _t_1["previous"];
    const _stamp_0 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0}, "snd": _stamp_0};
  } else {
    const _incoming_0 = _t_1["incoming"];
    const _stamp_1 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../../../bendvy/src/ecs/world.CapacityExceeded"}}, "snd": _stamp_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_store$1260$(_id_0, _incoming_0, _tick_0, _allowed_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_column$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_tick$(_clock_0, _allowed_0) {
  if (!_allowed_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047$$$047provider$058store_take$1260$(_store_0) {
  const _column_0 = _store_0["cells"];
  return {$: "Tuple", "fst": {$: "Unit"}, "snd": _column_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1260$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawned$1260$(_activated_0, _handle_0, _payload_0) {
  const _world_0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/world.Accepted") {
    return $$$$047$$$047context$058populate_empty$1260$(_world_0, _handle_0, _payload_0);
  } else {
    return _world_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1260$(true, _handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawned$1261$(_activated_0, _handle_0, _payload_0) {
  const _world_0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/world.Accepted") {
    return $$$$047$$$047provider$058populate_cells$1260$(_world_0, _handle_0, _payload_0);
  } else {
    return _world_0;
  }
}

function $fail$045false$045consumer$058skip_returned$1260$(_other_0, _owned_0, _prior_0, _id_0, _pair_0) {
  if (_id_0 == 1) {
    const _instance_0 = _pair_0["fst"];
    const _world_0 = _pair_0["snd"];
    return {$: "Tuple", "fst": {$: "fail-false-consumer.ReaderOwners", "fast": _instance_0, "slow": _other_0, "owned": _owned_0, "deliveries": _prior_0}, "snd": _world_0};
  } else {
    const _instance_1 = _pair_0["fst"];
    const _world_1 = _pair_0["snd"];
    return {$: "Tuple", "fst": {$: "fail-false-consumer.ReaderOwners", "fast": _other_0, "slow": _instance_1, "owned": _owned_0, "deliveries": _prior_0}, "snd": _world_1};
  }
}

function $$$$047$$$047readers$058skip$1260$(_instance_0, _world_0) {
  const _registry_0 = _instance_0["registry"];
  const _t_0 = _instance_0["flow"];
  const _a_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _t_1 = _instance_0["level"];
  const _b_0 = _t_1["namespace"];
  const _jd_0 = _t_1["id"];
  return {$: "Tuple", "fst": {$: "../../readers.Instance", "registry": _registry_0, "flow": {$: "../../../../../../../../bendvy/src/ecs/machine-stream.Reader", "namespace": _a_0, "id": _id_0}, "level": {$: "../../../../../../../../bendvy/src/ecs/machine-stream.Reader", "namespace": _b_0, "id": _jd_0}}, "snd": ($$$$047$$$047readers$058skipped_world$1260$(_world_0, _id_0, _jd_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047schedule$058after_outcome$1260$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (_outcome_0.$ === "../../../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/schedule.Failed", "schedule": {$: "../../../../../../../../bendvy/src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "error": _error_0, "observations": ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}}))};
  } else {
    const _world_1 = _outcome_0["world"];
    return run_tail(_next_0(_owners_0)(_world_1), ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}})));
  }
}

function $fail$045false$045consumer$058reader_returned$1260$(_other_0, _owned_0, _prior_0, _id_0, _result_0) {
  if (_id_0 == 1) {
    const _instance_0 = _result_0["instance"];
    const _world_0 = _result_0["world"];
    const _values_0 = _result_0["delivery"];
    const _status_0 = _result_0["status"];
    const _x_0 = ($fail$045false$045consumer$058report$(_values_0));
    const _x_1 = (":" + _status_0);
    const _x_2 = (_x_0 + _x_1);
    return {$: "Tuple", "fst": {$: "fail-false-consumer.ReaderOwners", "fast": _instance_0, "slow": _other_0, "owned": _owned_0, "deliveries": ($List$append$(_prior_0, {$: "Con", "head": ("fast:" + _x_2), "tail": {$: "Nil"}}))}, "snd": ($fail$045false$045consumer$058reader_outcome$1260$(_status_0, _world_0))};
  } else {
    const _instance_1 = _result_0["instance"];
    const _world_1 = _result_0["world"];
    const _values_1 = _result_0["delivery"];
    const _status_1 = _result_0["status"];
    const _x_3 = ($fail$045false$045consumer$058report$(_values_1));
    const _x_4 = (":" + _status_1);
    const _x_5 = (_x_3 + _x_4);
    return {$: "Tuple", "fst": {$: "fail-false-consumer.ReaderOwners", "fast": _other_0, "slow": _instance_1, "owned": _owned_0, "deliveries": ($List$append$(_prior_0, {$: "Con", "head": ("slow:" + _x_5), "tail": {$: "Nil"}}))}, "snd": ($fail$045false$045consumer$058reader_outcome$1260$(_status_1, _world_1))};
  }
}

function $$$$047$$$047readers$058invoke$1260$(_instance_0, _world_0, _fails_0) {
  const _registry_0 = _instance_0["registry"];
  const _t_0 = _instance_0["flow"];
  const _a_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _t_1 = _instance_0["level"];
  const _b_0 = _t_1["namespace"];
  const _jd_0 = _t_1["id"];
  return $$$$047$$$047readers$058returned$1260$({$: "../../../../../../../../bendvy/src/ecs/machine-stream.Reader", "namespace": _a_0, "id": _id_0}, {$: "../../../../../../../../bendvy/src/ecs/machine-stream.Reader", "namespace": _b_0, "id": _jd_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, {$: "../../readers.Input", "flowNamespace": _a_0, "flowId": _id_0, "levelNamespace": _b_0, "levelId": _jd_0, "fails": _fails_0})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058completed$1260$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _value_0 = _result_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/check.Checked", "world": _world_0, "result": {$: "Done", "value": _value_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke$1260$(_args_0, _ctx_0) {
  return $fail$045false$045consumer$058condition_body$1260$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058required$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058availability$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058name$1260$(($fail$045false$045consumer$058flow_declaration$1260$()))), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058condition$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045machine$045projection$058check_provide$1260$();
}

function $$$$047$$$047provider$058flow_put_resource$1260$(_resources_0, _flow_0) {
  const _owned_0 = _resources_0["owned"];
  const _level_0 = _resources_0["level"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0};
}

function $$$$047$$$047provider$058level_put_resource$1260$(_resources_0, _level_0) {
  const _owned_0 = _resources_0["owned"];
  const _flow_0 = _resources_0["flow"];
  const _flowStream_0 = _resources_0["flowStream"];
  const _levelStream_0 = _resources_0["levelStream"];
  const _frame_0 = _resources_0["frame"];
  const _tick_0 = _resources_0["tick"];
  const _trace_0 = _resources_0["trace"];
  return {$: "../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": _trace_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_done$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_world$1260$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_store$1260$(_id_0, _stamp_0, ($$$$047$$$047provider$058store_take$1260$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return _world_0;
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_observed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_world$1260$(_id_0, _incoming_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_column$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, _observed_0) {
  if (!_allowed_0) {
    const _column_0 = _observed_0["fst"];
    const _stamp_0 = _observed_0["snd"];
    return {$: "Tuple", "fst": ($$$$047$$$047provider$058store_put$1260$(_rest_0, _column_0)), "snd": {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/component.SwapRejected", "incoming": {$: "Some", "value": _incoming_0}}, "snd": _stamp_0}};
  } else {
    const _column_1 = _observed_0["fst"];
    const _stamp_1 = _observed_0["snd"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_store_join$1260$(_stamp_1, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, true, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1260$(_column_1, _id_0)), _id_0, {$: "Some", "value": _incoming_0})))));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1260$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047$$$047context$058populate_empty$1260$(_world_0, __0, __1) {
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1260$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047provider$058populate_cells$1260$(_world_0, _handle_0, _owner_0) {
  return $$$$047$$$047provider$058populated$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace$1260$({$: "../../../../../../../../bendvy/src/ecs/component.Family", "name": "cells"}, _world_0, _handle_0, {$: "Some", "value": _owner_0})));
}

function $$$$047$$$047readers$058skipped_world$1260$(_world_0, _flowId_0, _levelId_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _flowStream_0 = _t_0["flowStream"];
  const _levelStream_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _trace_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058skip$1260$(_flowStream_0, _flowId_0, _tick_0)), "levelStream": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058skip$1261$(_levelStream_0, _levelId_0, _tick_0)), "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $fail$045false$045consumer$058report$(_value_0) {
  if (_value_0.$ === "None") {
    return "none";
  } else {
    const _value_1 = _value_0["value"];
    return $fail$045false$045consumer$058delivery$(_value_1);
  }
}

function $fail$045false$045consumer$058reader_outcome$1260$(_status_0, _world_0) {
  return $fail$045false$045consumer$058reader_allowed$1260$(($String$eq$(_status_0, "ok")), _status_0, _world_0);
}

function $$$$047$$$047readers$058returned$1260$(_flow_0, _level_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _t_0 = _result_0["outcome"];
    if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/system.Succeeded") {
      const _world_0 = _t_0["world"];
      const _delivery_0 = _t_0["output"];
      return {$: "../../readers.Returned", "instance": {$: "../../readers.Instance", "registry": _registry_0, "flow": _flow_0, "level": _level_0}, "world": _world_0, "delivery": {$: "Some", "value": _delivery_0}, "status": "ok"};
    } else {
      const _world_1 = _t_0["world"];
      const _t_1 = _t_0["error"];
      const _error_0 = _t_1["message"];
      const _delivery_1 = _t_1["delivery"];
      return {$: "../../readers.Returned", "instance": {$: "../../readers.Instance", "registry": _registry_0, "flow": _flow_0, "level": _level_0}, "world": _world_1, "delivery": _delivery_1, "status": _error_0};
    }
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_2 = _result_0["world"];
    return {$: "../../readers.Returned", "instance": {$: "../../readers.Instance", "registry": _registry_1, "flow": _flow_0, "level": _level_0}, "world": _world_2, "delivery": {$: "None"}, "status": "reader-registration-rejected"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1260$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $fail$045false$045consumer$058condition_body$1260$(_id_0, _owner_0) {
  return $fail$045false$045consumer$058condition_read$1260$(_id_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1262$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058availability$1260$(_name_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/machine.Missing") {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": _name_0, "tail": {$: "Nil"}}};
  } else {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Nil"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045machine$045declaration$058name$1260$(_declaration_0) {
  const _name_0 = _declaration_0["name"];
  return _name_0;
}

function $fail$045false$045consumer$058flow_declaration$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-machine-declaration.Declaration", "name": "Flow"};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resources_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take_join$1260$(_ns_0, _next_0, _high_0, _live_0, _capacity_0, _depth_0, _store_0, ($$$$047$$$047provider$058flow_take_resource$1260$(_resources_0)), _events_0, _commands_0, _registrations_0, _nextSystem_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045machine$045projection$058check_provide$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045machine$045projection$058check_current$1260$(_x_0);
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_store$1260$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047provider$058store_put$1260$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_observed$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_world$1260$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_store$1260$(_id_0, _incoming_0, ($$$$047$$$047provider$058store_take$1260$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047provider$058store_put$1260$(__0, _column_0) {
  return {$: "../../provider.Store", "cells": _column_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_store_join$1260$(_stamp_0, _result_0) {
  const _store_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _store_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": _stamp_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058mark_swapped$1260$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($$$$047$$$047provider$058store_put$1260$(_rest_0, _column_1)), "snd": {$: "../../../../../../../../bendvy/src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1260$(_column_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058choose$((_key_0 === _id_0), _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../../../bendvy/src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../../../bendvy/src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.Rejected", "error": {$: "../../../../../../../../bendvy/src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.Accepted"}};
  }
}

function $$$$047$$$047provider$058populated$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return $$$$047$$$047provider$058populate_error$1260$(_world_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace$1260$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_allowed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058skip$1260$(_stream_0, _id_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return {$: "../../../../../../../../bendvy/src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _tick_0, false)), "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058skip$1261$(_stream_0, _id_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return {$: "../../../../../../../../bendvy/src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _tick_0, false)), "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $fail$045false$045consumer$058delivery$(_value_0) {
  const _flow_0 = _value_0["flow"];
  const _level_0 = _value_0["level"];
  const _flowLagged_0 = _value_0["flowLagged"];
  const _levelLagged_0 = _value_0["levelLagged"];
  const _x_0 = ($$$$047$$$047observe$058bool$(_levelLagged_0));
  const _x_1 = ($$$$047$$$047observe$058bool$(_flowLagged_0));
  const _x_2 = ("," + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($List$show$1264$(_level_0));
  const _x_5 = ("/lagged=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($List$show$1263$(_flow_0));
  const _x_8 = ("/level=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  return ("flow=" + _x_9);
}

function $fail$045false$045consumer$058reader_allowed$1260$(_allowed_0, _status_0, _world_0) {
  if (_allowed_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}};
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _status_0};
  }
}

function $String$eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(($String$order$(_a_0, _b_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $fail$045false$045consumer$058condition_read$1260$(_id_0, _pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _view_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": ($fail$045false$045consumer$058condition_view$1260$(_view_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1262$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1262$(($fail$045false$045consumer$058condition_cap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058caps_field$1260$(($fail$045false$045consumer$058condition_plan$1260$()))))))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045machine$045projection$058check_current$1260$(_ctx_0) {
  const _world_0 = _ctx_0["world"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045machine$045projection$058check_projected$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045world$058take$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_store$1260$(_id_0, _incoming_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_swap$1260$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058mark_swapped$1260$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047provider$058store_put$1260$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../../../../../../bendvy/src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1260$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058choose$(_found_0, _stamp_0, _other_0) {
  if (_found_0) {
    return _stamp_0;
  } else {
    return _other_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)), (_id_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047$$$047provider$058populate_error$1260$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _flowStream_0 = _t_0["flowStream"];
  const _levelStream_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _trace_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": _flowStream_0, "levelStream": _levelStream_0, "frame": _frame_0, "tick": _tick_0, "trace": ($List$append$(_trace_0, {$: "Con", "head": "POPULATE_REJECTED", "tail": {$: "Nil"}}))}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../../../bendvy/src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _cursor_0, _dispose_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _positions_0["head"];
    const _actual_0 = _t_0["id"];
    const _old_0 = _t_0["cursor"];
    const _registered_0 = _t_0["registeredAt"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update_checked$((_actual_0 === _id_0), _dispose_0, _actual_0, _old_0, _registered_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update$(_rest_0, _id_0, _cursor_0, _dispose_0)), _cursor_0);
  }
}

function $List$show$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047observe$058transition$1260$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047observe$058transition$1261$(_h_0));
    const _x_1 = ($List$show$go$1264$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $Cmp$is_eq$(_c_0) {
  if (_c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $String$order$(_a_0, _b_0) {
  return $Pair$snd$(($String$cmp$(_a_0, _b_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $fail$045false$045consumer$058condition_view$1260$(_view_0, _id_0) {
  if (_id_0 == 1) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058is_current$1260$(_view_0, {$: "../../provider.Play"});
  } else {
    return $Bool$not$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058is_current$1260$(_view_0, {$: "../../provider.Play"})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1262$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $fail$045false$045consumer$058condition_cap$1260$(_caps_0) {
  const _cap_0 = _caps_0["flow"];
  return _cap_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047check$058caps_field$1260$(_plan_0) {
  const _caps_0 = _plan_0["caps"];
  return _caps_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047inspector$045machine$045projection$058check_projected$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _slot_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/check.Frame", "world": _world_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058current_view$1260$(_slot_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_entries_0, _id_0, _stamp_0) {
  return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/lifecycle.Entry", "id": _id_0, "stamp": _stamp_0}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_swap$1260$(_rest_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": ($$$$047$$$047provider$058store_put$1260$(_rest_0, _column_0)), "snd": {$: "Unit"}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": ($$$$047$$$047provider$058store_put$1260$(_rest_0, _column_1)), "snd": {$: "Unit"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swapped$1260$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1260$({$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../../../bendvy/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1260$({$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../../../bendvy/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058grow$1260$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/column.Indexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0, _fits_0) {
  if (!_isnormal_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_exceptional_0, _id_0))};
  } else {
    if (!_fits_0) {
      return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
    } else {
      const _x_0 = ((_id_0 - 1) >>> 0);
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, {$: "Tuple", fst: _added_0, snd: _added_0[_x_0 % _added_0.length]});
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0) {
  return $Bool$and$((_id_0 > 0), (_id_0 <= 131072));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock$1260$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_checked$1260$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1260$(_incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update_checked$(_found_0, _dispose_0, _id_0, _old_0, _registered_0, _rest_0, _cursor_0) {
  if (!_found_0) {
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Position", "id": _id_0, "cursor": _old_0, "registeredAt": _registered_0}, "tail": _rest_0};
  } else {
    if (!_dispose_0) {
      return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Position", "id": _id_0, "cursor": _cursor_0, "registeredAt": _registered_0}, "tail": _rest_0};
    } else {
      return _rest_0;
    }
  }
}

function $List$show$go$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047observe$058transition$1260$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $List$show$go$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047$$$047observe$058transition$1261$(_h_0));
    const _x_1 = ($List$show$go$1264$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $Pair$snd$(_p_0) {
  const _b_0 = _p_0["snd"];
  return _b_0;
}

function $String$cmp$(_a_0, _b_0) {
  if (_a_0 === "") {
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": ""}, "snd": {$: "EQ"}};
    } else {
      const _h_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": (_h_0 + _t_0)}, "snd": {$: "LT"}};
    }
  } else {
    const _h_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
    const _t_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h_1 + _t_1), "snd": ""}, "snd": {$: "GT"}};
    } else {
      const _h2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return $String$cmp$fin$(_t_1, _t2_0, ($Char$cmp$(_h_1, _h2_0)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1260$({$: "../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$058is_current$1260$(_view_0, _value_0) {
  if (_view_0.$ === "../../../../../../../../bendvy/src/ecs/machine.Unavailable") {
    return false;
  } else {
    const _current_0 = _view_0["value"];
    return $$$$047$$$047provider$058flow_same$(_current_0, _value_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058keep$((_key_0 === _id_0), {$: "../../../../../../../../bendvy/src/ecs/lifecycle.Entry", "id": _key_0, "stamp": _stamp_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058clear$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0) {
  if (!_incoming_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swapped$1260$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1260$(_column_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_state$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../../../../../../bendvy/src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_state$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $U32$log2$(_n_0) {
  return $U32$log2$go$(5, _n_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1260$(_column_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_grow$1260$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _observed_0) {
  const _added_0 = _observed_0["fst"];
  const _first_0 = _observed_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, {$: "Tuple", fst: _changed_0, snd: _changed_0[_x_0 % _changed_0.length]});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_checked$1260$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../../../bendvy/src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_advanced$1260$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $String$cmp$fin$(_t1_0, _t2_0, _hc_0) {
  const _t_0 = _hc_0["fst"];
  const _h1b_0 = _t_0["fst"];
  const _h2b_0 = _t_0["snd"];
  const _t_1 = _hc_0["snd"];
  if (_t_1.$ === "LT") {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "LT"}};
  } else if (_t_1.$ === "EQ") {
    return $String$cmp$rec$(_h1b_0, _h2b_0, ($String$cmp$(_t1_0, _t2_0)));
  } else {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "GT"}};
  }
}

function $Char$cmp$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _a_0, "snd": _b_0}, "snd": cmp_new(_x_0, _x_1)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047$$$047provider$058flow_same$(_a_0, _b_0) {
  if (_a_0.$ === "../../provider.Boot") {
    if (_b_0.$ === "../../provider.Boot") {
      return true;
    } else {
      return false;
    }
  } else if (_a_0.$ === "../../provider.Play") {
    if (_b_0.$ === "../../provider.Play") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_b_0.$ === "../../provider.Pause") {
      return true;
    } else {
      return false;
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058keep$(_equal_0, _entry_0, _rest_0) {
  if (_equal_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _entry_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0) {
  if (!_isnormal_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_exceptional_0, _id_0, _stamp_0))};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058write_grow$(17, _id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, (_id_0 <= _capacity_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0) {
  if (!_wasPresent_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": _tick_0, "changed": _tick_0};
  } else {
    const _added_0 = _stamp_0["added"];
    return {$: "../../../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": _added_0, "changed": _tick_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1260$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1260$(_rest_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1260$(_rest_0)));
  }
}

function $U32$log2$go$($0, $1, $2) {
  for (;;) {
    {
      const _k_0 = $0;
      const _n_0 = $1;
      const _b_0 = $2;
      if (_k_0 === 0) {
        return _b_0;
      } else {
        const _p_0 = (_k_0 - 1);
        const _x_0 = (_p_0 >= 32 ? 0 : (1 << _p_0) >>> 0);
        const _s_0 = _x_0;
        const _x_1 = (_s_0 >= 32 ? 0 : (_n_0 >>> _s_0) >>> 0);
        const _x_2 = ($Bool$to_u32$((_x_1 !== 0)));
        const _t_0 = nat_chk(_s_0 * _x_2);
        $0 = _p_0;
        $1 = (_t_0 >= 32 ? 0 : (_n_0 >>> _t_0) >>> 0);
        $2 = nat_chk(_b_0 + _t_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, _column_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, _observed_0) {
  const _changed_0 = _observed_0["fst"];
  const _last_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": _first_0, "changed": _last_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_advanced$1260$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replaced$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_world$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $String$cmp$rec$(_h1b_0, _h2b_0, _rr_0) {
  const _t_0 = _rr_0["fst"];
  const _t1b_0 = _t_0["fst"];
  const _t2b_0 = _t_0["snd"];
  const _r_0 = _rr_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1b_0), "snd": (_h2b_0 + _t2b_0)}, "snd": _r_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1260$(_registry_0, ($$$$047$$$047readers$058runner$1260$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058write_grow$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _id_0 = $1;
      const _stamp_0 = $2;
      const _added_0 = $3;
      const _changed_0 = $4;
      const _capacity_0 = $5;
      const _depth_0 = $6;
      const _exceptional_0 = $7;
      const _fits_0 = $8;
      if (_fuel_0 === 0) {
        if (_fits_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          return {$: "../../../../../../../../bendvy/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_fits_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          const _next_0 = ((_capacity_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _stamp_0;
          $3 = array_node(_added_0, array_new(_depth_0, 0));
          $4 = array_node(_changed_0, array_new(_depth_0, 0));
          $5 = _next_0;
          $6 = nat_chk(_depth_0 + 1);
          $7 = _exceptional_0;
          $8 = (_id_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $Bool$to_u32$(_b_0) {
  if (!_b_0) {
    return 0;
  } else {
    return 1;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replaced$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../../../../../../bendvy/src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../../../bendvy/src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_world$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_store$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($$$$047$$$047provider$058store_take$1260$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047$$$047readers$058runner$1260$(_world_0, _input_0) {
  return $$$$047$$$047readers$058namespace_checked$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _input_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0) {
  const _first_0 = _stamp_0["added"];
  const _last_0 = _stamp_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = ((_id_0 - 1) >>> 0);
  return {$: "../../../../../../../../bendvy/src/ecs/indexed-lifecycle.Metadata", "added": (_added_0[_x_0 % _added_0.length] = _first_0, _added_0), "changed": (_changed_0[_x_1 % _changed_0.length] = _last_0, _changed_0), "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$($0, $1) {
  for (;;) {
    {
      const _rows_0 = $0;
      const _values_0 = $1;
      if (_rows_0.$ === "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
        return _values_0;
      } else {
        const _id_0 = _rows_0["id"];
        const _owner_0 = _rows_0["owner"];
        const _rest_0 = _rows_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        const _x_1 = {$: "Some", "value": _owner_0};
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _x_1, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1260$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../../../../../../bendvy/src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1262$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_store$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047readers$058namespace_checked$1260$(_pair_0, _input_0) {
  const _world_0 = _pair_0["fst"];
  const _actual_0 = _pair_0["snd"];
  const _a_0 = _input_0["flowNamespace"];
  const _id_0 = _input_0["flowId"];
  const _b_0 = _input_0["levelNamespace"];
  const _jd_0 = _input_0["levelId"];
  const _fails_0 = _input_0["fails"];
  return $$$$047$$$047readers$058prepare_checked$1260$(($Bool$and$((_actual_0 === _a_0), (_actual_0 === _b_0))), _world_0, _id_0, _jd_0, _fails_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $$$$047$$$047readers$058prepare_checked$1260$(_allowed_0, _world_0, _flowId_0, _levelId_0, _fails_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": {$: "../../readers.Failure", "message": "ReaderNamespaceRejected", "delivery": {$: "None"}}};
  } else {
    return $$$$047$$$047readers$058prepare$1260$(_world_0, _flowId_0, _levelId_0, _fails_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_access$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047readers$058prepare$1260$(_world_0, _flowId_0, _levelId_0, _fails_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _flowStream_0 = _t_0["flowStream"];
  const _levelStream_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _trace_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047readers$058prepared$1260$({$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058activate$1260$(_flowStream_0, _flowId_0, _tick_0)), "levelStream": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058activate$1261$(_levelStream_0, _levelId_0, _tick_0)), "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, _flowStream_0, _levelStream_0, _flowId_0, _levelId_0, _tick_0, _fails_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $$$$047$$$047readers$058prepared$1260$(_world_0, _flowStream_0, _levelStream_0, _flowId_0, _levelId_0, _tick_0, _fails_0) {
  return $$$$047$$$047readers$058finish$1260$(_flowId_0, _levelId_0, ($$$$047$$$047readers$058body$1260$(_fails_0, {$: "../../readers.Frame", "base": {$: "../../context.Frame", "tx": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1260$(($$$$047$$$047provider$058pulse$1260$(_world_0)))), "error": {$: "None"}}, "flow": ($$$$047$$$047readers$058view$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058observe$1260$(_flowStream_0, _flowId_0, _tick_0)))), "level": ($$$$047$$$047readers$058view$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058observe$1261$(_levelStream_0, _levelId_0, _tick_0))))})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058activate$1260$(_stream_0, _id_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return {$: "../../../../../../../../bendvy/src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _tick_0)), "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058activate$1261$(_stream_0, _id_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  return {$: "../../../../../../../../bendvy/src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _tick_0)), "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047readers$058finish$1260$(_flowId_0, _levelId_0, _pair_0) {
  const _t_0 = _pair_0["fst"];
  const _base_0 = _t_0["base"];
  const _t_1 = _pair_0["snd"];
  const _delivery_0 = _t_1["delivery"];
  const _outcome_0 = _t_1["outcome"];
  return $$$$047$$$047readers$058finished$1260$(_flowId_0, _levelId_0, _delivery_0, ($$$$047$$$047context$058finish$1260$({$: "Tuple", "fst": _base_0, "snd": _outcome_0})));
}

function $$$$047$$$047readers$058body$1260$(_fails_0, _ctx_0) {
  return $$$$047$$$047readers$058level_read$1260$(_fails_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1261$(_ctx_0)));
}

function $$$$047$$$047readers$058view$1260$(_reading_0) {
  const _values_0 = _reading_0["values"];
  const _lagged_0 = _reading_0["lagged"];
  return {$: "../../readers.View", "values": _values_0, "lagged": _lagged_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058observe$1260$(_stream_0, _id_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058observe_position$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _batches_0, _dropped_0, _id_0, _tick_0);
}

function $$$$047$$$047readers$058view$1261$(_reading_0) {
  const _values_0 = _reading_0["values"];
  const _lagged_0 = _reading_0["lagged"];
  return {$: "../../readers.View", "values": _values_0, "lagged": _lagged_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058observe$1261$(_stream_0, _id_0, _tick_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058observe_position$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _batches_0, _dropped_0, _id_0, _tick_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _registered_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058activation$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _positions_0, _id_0, _registered_0);
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

function $$$$047$$$047readers$058finished$1260$(_flowId_0, _levelId_0, _delivery_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/system.Succeeded") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../../../../../bendvy/src/ecs/system.Succeeded", "world": ($$$$047$$$047readers$058stream_completed$1260$(_world_0, _flowId_0, _levelId_0)), "output": _delivery_0};
  } else {
    const _world_1 = _result_0["world"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_1, "error": {$: "../../readers.Failure", "message": _error_0, "delivery": {$: "Some", "value": _delivery_0}}};
  }
}

function $$$$047$$$047readers$058level_read$1260$(_fails_0, _pair_0) {
  const _ctx_0 = _pair_0["fst"];
  const _flow_0 = _pair_0["snd"];
  return $$$$047$$$047readers$058completed$1260$(_fails_0, _flow_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1260$(_ctx_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1261$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1261$(($$$$047$$$047readers$058flow_cap$1260$(($$$$047$$$047readers$058work$1260$()))))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058observe_position$1260$(_position_0, _batches_0, _dropped_0, _id_0, _tick_0) {
  if (_position_0.$ === "None") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reading$1260$({$: "../../../../../../../../bendvy/src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _tick_0}, _batches_0, _dropped_0);
  } else {
    const _position_1 = _position_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reading$1260$(_position_1, _batches_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _position_0 = _positions_0["head"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058observe_position$1261$(_position_0, _batches_0, _dropped_0, _id_0, _tick_0) {
  if (_position_0.$ === "None") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reading$1261$({$: "../../../../../../../../bendvy/src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _tick_0}, _batches_0, _dropped_0);
  } else {
    const _position_1 = _position_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reading$1261$(_position_1, _batches_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058activation$(_position_0, _positions_0, _id_0, _registered_0) {
  if (_position_0.$ === "None") {
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _registered_0}, "tail": _positions_0};
  } else {
    return _positions_0;
  }
}

function $$$$047$$$047readers$058stream_completed$1260$(_world_0, _flowId_0, _levelId_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _owned_0 = _t_0["owned"];
  const _flow_0 = _t_0["flow"];
  const _level_0 = _t_0["level"];
  const _flowStream_0 = _t_0["flowStream"];
  const _levelStream_0 = _t_0["levelStream"];
  const _frame_0 = _t_0["frame"];
  const _tick_0 = _t_0["tick"];
  const _trace_0 = _t_0["trace"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../../provider.Resources", "owned": _owned_0, "flow": _flow_0, "level": _level_0, "flowStream": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058complete$1260$(_flowStream_0, _flowId_0, _tick_0, true)), "levelStream": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058complete$1261$(_levelStream_0, _levelId_0, _tick_0, true)), "frame": _frame_0, "tick": _tick_0, "trace": _trace_0}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0};
}

function $$$$047$$$047readers$058completed$1260$(_fails_0, _flow_0, _pair_0) {
  if (!_fails_0) {
    const _a_0 = _flow_0["values"];
    const _al_0 = _flow_0["lagged"];
    const _ctx_0 = _pair_0["fst"];
    const _t_0 = _pair_0["snd"];
    const _b_0 = _t_0["values"];
    const _bl_0 = _t_0["lagged"];
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "../../readers.Completion", "delivery": {$: "../../readers.Delivery", "flow": _a_0, "level": _b_0, "flowLagged": _al_0, "levelLagged": _bl_0}, "outcome": {$: "../../../../../../../../bendvy/src/ecs/transaction.Success"}}};
  } else {
    const _a_1 = _flow_0["values"];
    const _al_1 = _flow_0["lagged"];
    const _ctx_1 = _pair_0["fst"];
    const _t_1 = _pair_0["snd"];
    const _b_1 = _t_1["values"];
    const _bl_1 = _t_1["lagged"];
    return {$: "Tuple", "fst": _ctx_1, "snd": {$: "../../readers.Completion", "delivery": {$: "../../readers.Delivery", "flow": _a_1, "level": _b_1, "flowLagged": _al_1, "levelLagged": _bl_1}, "outcome": {$: "../../../../../../../../bendvy/src/ecs/transaction.Failure", "error": "reader-failed"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read$1260$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1260$(($$$$047$$$047readers$058level_cap$1260$(($$$$047$$$047readers$058work$1260$()))))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1261$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047readers$058flow_cap$1260$(_caps_0) {
  const _cap_0 = _caps_0["flow"];
  return _cap_0;
}

function $$$$047$$$047readers$058work$1260$() {
  return {$: "../../readers.Work", "flow": {$: "../../../../../../../../bendvy/src/ecs/capabilities.ValueRead", "get": run_clo((_x_0) => {
  return $$$$047$$$047readers$058read_flow$1260$(_x_0);
})}, "level": {$: "../../../../../../../../bendvy/src/ecs/capabilities.ValueRead", "get": run_clo((_x_1) => {
  return $$$$047$$$047readers$058read_level$1260$(_x_1);
})}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reading$1260$(_position_0, _batches_0, _dropped_0) {
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Reading", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, _fallback_0) {
  const _actual_0 = _position_0["id"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058choose_position$((_actual_0 === _id_0), {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Position", "id": _actual_0, "cursor": _cursor_0, "registeredAt": _registered_0}, _fallback_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058reading$1261$(_position_0, _batches_0, _dropped_0) {
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../../../../../../../../bendvy/src/ecs/event-runtime.Reading", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since$1261$(_batches_0, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058complete$1260$(_stream_0, _id_0, _tick_0, _success_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  if (_success_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _tick_0, false)), "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047machine$045stream$058complete$1261$(_stream_0, _id_0, _tick_0, _success_0) {
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _dropped_0 = _stream_0["droppedThrough"];
  const _frameStart_0 = _stream_0["frameStart"];
  if (_success_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _tick_0, false)), "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/machine-stream.Stream", "batches": _batches_0, "positions": _positions_0, "droppedThrough": _dropped_0, "frameStart": _frameStart_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058value_read_field$1260$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047readers$058level_cap$1260$(_caps_0) {
  const _cap_0 = _caps_0["level"];
  return _cap_0;
}

function $$$$047$$$047readers$058read_flow$1260$(_frame_0) {
  const _base_0 = _frame_0["base"];
  const _flow_0 = _frame_0["flow"];
  const _level_0 = _frame_0["level"];
  return {$: "Tuple", "fst": {$: "../../readers.Frame", "base": _base_0, "flow": _flow_0, "level": _level_0}, "snd": _flow_0};
}

function $$$$047$$$047readers$058read_level$1260$(_frame_0) {
  const _base_0 = _frame_0["base"];
  const _flow_0 = _frame_0["flow"];
  const _level_0 = _frame_0["level"];
  return {$: "Tuple", "fst": {$: "../../readers.Frame", "base": _base_0, "flow": _flow_0, "level": _level_0}, "snd": _level_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since_checked$1260$((_cursor_0 < _tick_0), _items_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since$1260$(_rest_0, _cursor_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058choose_position$(_found_0, _position_0, _fallback_0) {
  if (!_found_0) {
    return _fallback_0;
  } else {
    return {$: "Some", "value": _position_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since$1261$(_batches_0, _cursor_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since_checked$1261$((_cursor_0 < _tick_0), _items_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since$1261$(_rest_0, _cursor_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since_checked$1260$(_visible_0, _items_0, _rest_0) {
  if (!_visible_0) {
    return _rest_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1260$(_items_0, _rest_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058since_checked$1261$(_visible_0, _items_0, _rest_0) {
  if (!_visible_0) {
    return _rest_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1261$(_items_0, _rest_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1260$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1260$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append$1261$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1261$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047event$045runtime$058append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, [[4],[]]);