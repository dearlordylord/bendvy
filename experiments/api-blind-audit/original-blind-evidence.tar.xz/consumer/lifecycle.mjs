function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $$$$047library$047storage$058metadata_empty$(_depth_0) {
  const _x_0 = {$: "None"};
  return {$: "../library/storage.MetadataColumns", "live": array_new(_depth_0, false), "flags": array_new(_depth_0, _x_0), "added": array_new(_depth_0, 0), "changed": array_new(_depth_0, 0)};
}

function $$$$047library$047storage$058metadata_grow$(_columns_0, _depth_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  const _x_0 = {$: "None"};
  return {$: "../library/storage.MetadataColumns", "live": array_node(_live_0, array_new(_depth_0, false)), "flags": array_node(_flags_0, array_new(_depth_0, _x_0)), "added": array_node(_added_0, array_new(_depth_0, 0)), "changed": array_node(_changed_0, array_new(_depth_0, 0))};
}

function $$$$047library$047storage$058metadata_get_changed$(_live_0, _flags_0, _added_0, _l_0, _f_0, _a_0, _result_0) {
  const _changed_0 = _result_0["fst"];
  const _c_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../library/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "snd": {$: "../library/storage.Metadata", "live": _l_0, "flag": _f_0, "added": _a_0, "changed": _c_0}};
}

function $$$$047library$047storage$058metadata_get_added$(_live_0, _flags_0, _changed_0, _index_0, _l_0, _f_0, _result_0) {
  const _added_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return $$$$047library$047storage$058metadata_get_changed$(_live_0, _flags_0, _added_0, _l_0, _f_0, _a_0, {$: "Tuple", fst: _changed_0, snd: _changed_0[_index_0 % _changed_0.length]});
}

function $$$$047library$047storage$058metadata_get_flags$(_live_0, _added_0, _changed_0, _index_0, _l_0, _result_0) {
  const _flags_0 = _result_0["fst"];
  const _f_0 = _result_0["snd"];
  return $$$$047library$047storage$058metadata_get_added$(_live_0, _flags_0, _changed_0, _index_0, _l_0, _f_0, {$: "Tuple", fst: _added_0, snd: _added_0[_index_0 % _added_0.length]});
}

function $$$$047library$047storage$058metadata_get_live$(_flags_0, _added_0, _changed_0, _index_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _l_0 = _result_0["snd"];
  return $$$$047library$047storage$058metadata_get_flags$(_live_0, _added_0, _changed_0, _index_0, _l_0, {$: "Tuple", fst: _flags_0, snd: _flags_0[_index_0 % _flags_0.length]});
}

function $$$$047library$047storage$058metadata_get$(_columns_0, _index_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  return $$$$047library$047storage$058metadata_get_live$(_flags_0, _added_0, _changed_0, _index_0, {$: "Tuple", fst: _live_0, snd: _live_0[_index_0 % _live_0.length]});
}

function $$$$047library$047storage$058metadata_membership_flags$(_live_0, _added_0, _changed_0, _value_0, _result_0) {
  const _flags_0 = _result_0["fst"];
  const _flag_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../library/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "snd": {$: "../library/storage.Membership", "live": _value_0, "flag": _flag_0}};
}

function $$$$047library$047storage$058metadata_membership_live$(_flags_0, _added_0, _changed_0, _index_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $$$$047library$047storage$058metadata_membership_flags$(_live_0, _added_0, _changed_0, _value_0, {$: "Tuple", fst: _flags_0, snd: _flags_0[_index_0 % _flags_0.length]});
}

function $$$$047library$047storage$058metadata_membership$(_columns_0, _index_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  return $$$$047library$047storage$058metadata_membership_live$(_flags_0, _added_0, _changed_0, _index_0, {$: "Tuple", fst: _live_0, snd: _live_0[_index_0 % _live_0.length]});
}

function $$$$047library$047storage$058metadata_live_done$(_flags_0, _added_0, _changed_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../library/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "snd": _value_0};
}

function $$$$047library$047storage$058metadata_live$(_columns_0, _index_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  return $$$$047library$047storage$058metadata_live_done$(_flags_0, _added_0, _changed_0, {$: "Tuple", fst: _live_0, snd: _live_0[_index_0 % _live_0.length]});
}

function $$$$047library$047storage$058metadata_mark$(_columns_0, _index_0, _tick_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  return {$: "../library/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": (_changed_0[_index_0 % _changed_0.length] = _tick_0, _changed_0)};
}

function $$$$047library$047storage$058metadata_set$(_columns_0, _index_0, _meta_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  const _l_0 = _meta_0["live"];
  const _f_0 = _meta_0["flag"];
  const _a_0 = _meta_0["added"];
  const _c_0 = _meta_0["changed"];
  return {$: "../library/storage.MetadataColumns", "live": (_live_0[_index_0 % _live_0.length] = _l_0, _live_0), "flags": (_flags_0[_index_0 % _flags_0.length] = _f_0, _flags_0), "added": (_added_0[_index_0 % _added_0.length] = _a_0, _added_0), "changed": (_changed_0[_index_0 % _changed_0.length] = _c_0, _changed_0)};
}

function $$$$047library$047storage$058slots_empty$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _d_0 = (_depth_0 - 1);
    return array_node(($$$$047library$047storage$058slots_empty$(_d_0)), ($$$$047library$047storage$058slots_empty$(_d_0)));
  }
}

function $$$$047library$047storage$058rows_empty$() {
  return {$: "../library/storage.Rows", "main": [{$: "None"}], "aux": [{$: "None"}], "metadata": ($$$$047library$047storage$058metadata_empty$(0)), "capacity": 1, "depth": 0, "high_water": 0};
}

function $$$$047library$047storage$058rows_high_water$(_rows_0) {
  const _m_0 = _rows_0["main"];
  const _a_0 = _rows_0["aux"];
  const _f_0 = _rows_0["metadata"];
  const _c_0 = _rows_0["capacity"];
  const _d_0 = _rows_0["depth"];
  const _h_0 = _rows_0["high_water"];
  return {$: "Tuple", "fst": {$: "../library/storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, "snd": _h_0};
}

function $$$$047library$047storage$058rows_can_place$(_rows_0, _id_0) {
  return {$: "Tuple", "fst": _rows_0, "snd": ($Bool$and$((0 < _id_0), (_id_0 <= 131072)))};
}

function $$$$047library$047storage$058grow_decide$(_needed_0, _rows_0, _recurse_0) {
  if (!_needed_0) {
    return _rows_0;
  } else {
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    return run_tail(_recurse_0, {$: "../library/storage.Rows", "main": array_node(_m_0, ($$$$047library$047storage$058slots_empty$(_d_0))), "aux": array_node(_a_0, ($$$$047library$047storage$058slots_empty$(_d_0))), "metadata": ($$$$047library$047storage$058metadata_grow$(_f_0, _d_0)), "capacity": ((_c_0 + _c_0) >>> 0), "depth": nat_chk(_d_0 + 1), "high_water": _h_0});
  }
}

function $$$$047library$047storage$058grow$(_fuel_0, _id_0, _rows_0) {
  if (_fuel_0 === 0) {
    return _rows_0;
  } else {
    const _n_0 = (_fuel_0 - 1);
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    return $$$$047library$047storage$058grow_decide$(($Bool$and$((_c_0 < _id_0), (_c_0 <= 65536))), {$: "../library/storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, run_clo((_x_0) => {
  return $$$$047library$047storage$058grow$(_n_0, _id_0, _x_0);
}));
  }
}

function $$$$047library$047storage$058extract_row$(_id_0, _main_0, _value_0, _aux_0, _av_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0) {
  const _flag_0 = _meta_0["flag"];
  const _added_0 = _meta_0["added"];
  const _changed_0 = _meta_0["changed"];
  return {$: "Tuple", "fst": {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "Some", "value": {$: "../library/storage.Row", "id": _id_0, "main": _value_0, "aux": _av_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}}};
}

function $$$$047library$047storage$058extract_aux$(_id_0, _main_0, _value_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _av_0 = _result_0["snd"];
  return $$$$047library$047storage$058extract_row$(_id_0, _main_0, _value_0, _aux_0, _av_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0);
}

function $$$$047library$047storage$058extract_main$(_id_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _mv_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "None"};
  return $$$$047library$047storage$058extract_aux$(_id_0, _main_0, _mv_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, array_rmw(_aux_0, _x_0, () => _x_1));
}

function $$$$047library$047storage$058extract_meta$(_id_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _t_1 = _t_0["live"];
  if (!_t_1) {
    return {$: "Tuple", "fst": {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "None"}};
  } else {
    const _flag_1 = _t_0["flag"];
    const _added_1 = _t_0["added"];
    const _changed_1 = _t_0["changed"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047library$047storage$058extract_main$(_id_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, {$: "../library/storage.Metadata", "live": true, "flag": _flag_1, "added": _added_1, "changed": _changed_1}, array_rmw(_main_0, _x_0, () => _x_1));
  }
}

function $$$$047library$047storage$058extract_checked$(_valid_0, _id_0, _rows_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _rows_0, "snd": {$: "None"}};
  } else {
    const _main_0 = _rows_0["main"];
    const _aux_0 = _rows_0["aux"];
    const _metadata_0 = _rows_0["metadata"];
    const _capacity_0 = _rows_0["capacity"];
    const _depth_0 = _rows_0["depth"];
    const _high_0 = _rows_0["high_water"];
    return $$$$047library$047storage$058extract_meta$(_id_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, ($$$$047library$047storage$058metadata_get$(_metadata_0, ((_id_0 - 1) >>> 0))));
  }
}

function $$$$047library$047storage$058rows_extract$(_rows_0, _id_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _metadata_0 = _rows_0["metadata"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $$$$047library$047storage$058extract_checked$(($Bool$and$((0 < _id_0), ($Bool$and$((_id_0 <= _capacity_0), (_id_0 <= _high_0))))), _id_0, {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0});
}

function $$$$047library$047storage$058rows_restore$(_rows_0, _row_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _metadata_0 = _rows_0["metadata"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  const _id_0 = _row_0["id"];
  const _m_0 = _row_0["main"];
  const _a_0 = _row_0["aux"];
  const _f_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = ((_id_0 - 1) >>> 0);
  return {$: "../library/storage.Rows", "main": (_main_0[_x_0 % _main_0.length] = _m_0, _main_0), "aux": (_aux_0[_x_1 % _aux_0.length] = _a_0, _aux_0), "metadata": ($$$$047library$047storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "../library/storage.Metadata", "live": true, "flag": _f_0, "added": _added_0, "changed": _changed_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0};
}

function $$$$047library$047storage$058remove_done$(_id_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _m_0 = _t_0["main"];
  const _a_0 = _t_0["aux"];
  const _f_0 = _t_0["metadata"];
  const _c_0 = _t_0["capacity"];
  const _d_0 = _t_0["depth"];
  const _h_0 = _t_0["high_water"];
  const _t_1 = _result_0["snd"];
  if (_t_1.$ === "None") {
    return {$: "Tuple", "fst": {$: "../library/storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, "snd": {$: "None"}};
  } else {
    const _row_0 = _t_1["value"];
    return {$: "Tuple", "fst": {$: "../library/storage.Rows", "main": _m_0, "aux": _a_0, "metadata": ($$$$047library$047storage$058metadata_set$(_f_0, ((_id_0 - 1) >>> 0), {$: "../library/storage.Metadata", "live": false, "flag": {$: "None"}, "added": 0, "changed": 0})), "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, "snd": {$: "Some", "value": _row_0}};
  }
}

function $$$$047library$047storage$058rows_remove$(_rows_0, _id_0) {
  return $$$$047library$047storage$058remove_done$(_id_0, ($$$$047library$047storage$058rows_extract$(_rows_0, _id_0)));
}

function $$$$047library$047storage$058place_status$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _live_0, _row_0) {
  if (_live_0) {
    return {$: "../library/storage.Rejected", "rows": {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "row": _row_0};
  } else {
    const _id_0 = _row_0["id"];
    const _m_0 = _row_0["main"];
    const _a_0 = _row_0["aux"];
    const _f_0 = _row_0["flag"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = ((_id_0 - 1) >>> 0);
    return {$: "../library/storage.Placed", "rows": {$: "../library/storage.Rows", "main": (_main_0[_x_0 % _main_0.length] = _m_0, _main_0), "aux": (_aux_0[_x_1 % _aux_0.length] = _a_0, _aux_0), "metadata": ($$$$047library$047storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "../library/storage.Metadata", "live": true, "flag": _f_0, "added": _added_0, "changed": _changed_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": ($U32$max$(_high_0, _id_0))}};
  }
}

function $$$$047library$047storage$058place_metadata$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _row_0, _meta_0) {
  return $$$$047library$047storage$058place_status$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, _row_0);
}

function $$$$047library$047storage$058place_meta$(_main_0, _aux_0, _capacity_0, _depth_0, _high_0, _row_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _meta_0 = _result_0["snd"];
  return $$$$047library$047storage$058place_metadata$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _row_0, _meta_0);
}

function $$$$047library$047storage$058place_capacity$(_valid_0, _rows_0, _row_0) {
  if (!_valid_0) {
    return {$: "../library/storage.Rejected", "rows": _rows_0, "row": _row_0};
  } else {
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    const _id_0 = _row_0["id"];
    const _main_0 = _row_0["main"];
    const _aux_0 = _row_0["aux"];
    const _flag_0 = _row_0["flag"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    return $$$$047library$047storage$058place_meta$(_m_0, _a_0, _c_0, _d_0, _h_0, {$: "../library/storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}, ($$$$047library$047storage$058metadata_live$(_f_0, ((_id_0 - 1) >>> 0))));
  }
}

function $$$$047library$047storage$058place_grown$(_rows_0, _row_0) {
  const _m_0 = _rows_0["main"];
  const _a_0 = _rows_0["aux"];
  const _f_0 = _rows_0["metadata"];
  const _c_0 = _rows_0["capacity"];
  const _d_0 = _rows_0["depth"];
  const _h_0 = _rows_0["high_water"];
  const _id_0 = _row_0["id"];
  const _main_0 = _row_0["main"];
  const _aux_0 = _row_0["aux"];
  const _flag_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  return $$$$047library$047storage$058place_capacity$(($Bool$and$((0 < _id_0), (_id_0 <= _c_0))), {$: "../library/storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, {$: "../library/storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0});
}

function $$$$047library$047storage$058place_checked$(_valid_0, _rows_0, _row_0) {
  if (!_valid_0) {
    return {$: "../library/storage.Rejected", "rows": _rows_0, "row": _row_0};
  } else {
    const _id_0 = _row_0["id"];
    const _m_0 = _row_0["main"];
    const _a_0 = _row_0["aux"];
    const _f_0 = _row_0["flag"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    return $$$$047library$047storage$058place_grown$(run_loop($$$$047library$047storage$058grow$(17, _id_0, _rows_0)), {$: "../library/storage.Row", "id": _id_0, "main": _m_0, "aux": _a_0, "flag": _f_0, "added": _added_0, "changed": _changed_0});
  }
}

function $$$$047library$047storage$058rows_place$(_rows_0, _row_0) {
  const _id_0 = _row_0["id"];
  const _m_0 = _row_0["main"];
  const _a_0 = _row_0["aux"];
  const _f_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  return $$$$047library$047storage$058place_checked$(($Bool$and$((0 < _id_0), (_id_0 <= 131072))), _rows_0, {$: "../library/storage.Row", "id": _id_0, "main": _m_0, "aux": _a_0, "flag": _f_0, "added": _added_0, "changed": _changed_0});
}

function $$$$047library$047storage$058take_main_done$(_aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "../library/storage.NoMain"}};
  } else {
    const _value_0 = _t_0["value"];
    return {$: "Tuple", "fst": {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "../library/storage.Taken", "main": _value_0}};
  }
}

function $$$$047library$047storage$058take_meta$(_id_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0) {
  if (!_meta_0) {
    return {$: "Tuple", "fst": {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "../library/storage.NoEntity"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047library$047storage$058take_main_done$(_aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, array_rmw(_main_0, _x_0, () => _x_1));
  }
}

function $$$$047library$047storage$058take_meta_done$(_id_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _meta_0 = _result_0["snd"];
  return $$$$047library$047storage$058take_meta$(_id_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0);
}

function $$$$047library$047storage$058prototype_take_live$(_id_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $$$$047library$047storage$058take_meta$(_id_0, _main_0, _aux_0, {$: "../library/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, _capacity_0, _depth_0, _high_0, _value_0);
}

function $$$$047library$047storage$058prototype_take_columns$(_id_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0) {
  const _live_0 = _metadata_0["live"];
  const _flags_0 = _metadata_0["flags"];
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return $$$$047library$047storage$058prototype_take_live$(_id_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, {$: "Tuple", fst: _live_0, snd: _live_0[_x_0 % _live_0.length]});
}

function $$$$047library$047storage$058take_checked$(_valid_0, _id_0, _rows_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _rows_0, "snd": {$: "../library/storage.NoEntity"}};
  } else {
    const _main_0 = _rows_0["main"];
    const _aux_0 = _rows_0["aux"];
    const _metadata_0 = _rows_0["metadata"];
    const _capacity_0 = _rows_0["capacity"];
    const _depth_0 = _rows_0["depth"];
    const _high_0 = _rows_0["high_water"];
    return $$$$047library$047storage$058prototype_take_columns$(_id_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0);
  }
}

function $$$$047library$047storage$058take_rows$(_rows_0, _target_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _metadata_0 = _rows_0["metadata"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $$$$047library$047storage$058take_checked$(($Bool$and$((0 < _target_0), ($Bool$and$((_target_0 <= _capacity_0), (_target_0 <= _high_0))))), _target_0, {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0});
}

function $$$$047library$047storage$058put_meta$(_id_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _value_0, _meta_0) {
  if (!_meta_0) {
    return {$: "Tuple", "fst": {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "Some", "value": _value_0}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _value_0};
    return {$: "Tuple", "fst": {$: "../library/storage.Rows", "main": (_main_0[_x_0 % _main_0.length] = _x_1, _main_0), "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "None"}};
  }
}

function $$$$047library$047storage$058put_meta_done$(_id_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, _value_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _meta_0 = _result_0["snd"];
  return $$$$047library$047storage$058put_meta$(_id_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _value_0, _meta_0);
}

function $$$$047library$047storage$058put_checked$(_valid_0, _id_0, _rows_0, _value_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _rows_0, "snd": {$: "Some", "value": _value_0}};
  } else {
    const _main_0 = _rows_0["main"];
    const _aux_0 = _rows_0["aux"];
    const _metadata_0 = _rows_0["metadata"];
    const _capacity_0 = _rows_0["capacity"];
    const _depth_0 = _rows_0["depth"];
    const _high_0 = _rows_0["high_water"];
    return $$$$047library$047storage$058put_meta_done$(_id_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, _value_0, ($$$$047library$047storage$058metadata_live$(_metadata_0, ((_id_0 - 1) >>> 0))));
  }
}

function $$$$047library$047storage$058put_rows$(_rows_0, _target_0, _main_0) {
  const _m_0 = _rows_0["main"];
  const _a_0 = _rows_0["aux"];
  const _f_0 = _rows_0["metadata"];
  const _c_0 = _rows_0["capacity"];
  const _d_0 = _rows_0["depth"];
  const _h_0 = _rows_0["high_water"];
  return $$$$047library$047storage$058put_checked$(($Bool$and$((0 < _target_0), ($Bool$and$((_target_0 <= _c_0), (_target_0 <= _h_0))))), _target_0, {$: "../library/storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, _main_0);
}

function $$$$047library$047storage$058put_finish$(_result_0) {
  const _rows_0 = _result_0["fst"];
  return _rows_0;
}

function $$$$047library$047storage$058hook_return$(_namespace_0, _next_0, _rows_0, _pending_0, _ledger_0, _mode_0, _target_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _observation_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../library/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": ($$$$047library$047storage$058put_finish$(($$$$047library$047storage$058put_rows$(_rows_0, _target_0, _main_0)))), "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "../library/types.Found", "value": _observation_0}};
}

function $$$$047library$047storage$058hook_taken$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, _target_0, _transform_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../library/storage.NoEntity") {
    return {$: "Tuple", "fst": {$: "../library/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "../library/types.Missing"}};
  } else if (_t_0.$ === "../library/storage.NoMain") {
    return {$: "Tuple", "fst": {$: "../library/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "../library/types.Mismatch"}};
  } else {
    const _main_0 = _t_0["main"];
    return $$$$047library$047storage$058hook_return$(_namespace_0, _next_0, _rows_0, _pending_0, _ledger_0, _mode_0, _target_0, _transform_0(_main_0));
  }
}

function $$$$047library$047storage$058fuse_return$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _result_0) {
  const _value_0 = _result_0["fst"];
  const _observation_0 = _result_0["snd"];
  const _x_0 = {$: "Some", "value": _value_0};
  return {$: "Tuple", "fst": {$: "../library/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "../library/storage.Rows", "main": (_main_0[_index_0 % _main_0.length] = _x_0, _main_0), "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "../library/types.Found", "value": _observation_0}};
}

function $$$$047library$047storage$058fuse_taken$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../library/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "../library/types.Mismatch"}};
  } else {
    const _value_0 = _t_0["value"];
    return $$$$047library$047storage$058fuse_return$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0(_value_0));
  }
}

function $$$$047library$047storage$058fuse_live$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0, _meta_0) {
  if (!_meta_0) {
    return {$: "Tuple", "fst": {$: "../library/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "../library/types.Missing"}};
  } else {
    const _x_0 = {$: "None"};
    return $$$$047library$047storage$058fuse_taken$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, array_rmw(_main_0, _index_0, () => _x_0));
  }
}

function $$$$047library$047storage$058fuse_meta$(_namespace_0, _next_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _meta_0 = _result_0["snd"];
  return $$$$047library$047storage$058fuse_live$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0, _meta_0);
}

function $$$$047library$047storage$058prototype_fuse_live_result$(_namespace_0, _next_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $$$$047library$047storage$058fuse_live$(_namespace_0, _next_0, _aux_0, {$: "../library/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0, _value_0);
}

function $$$$047library$047storage$058prototype_fuse_columns$(_namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0) {
  const _live_0 = _metadata_0["live"];
  const _flags_0 = _metadata_0["flags"];
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  return $$$$047library$047storage$058prototype_fuse_live_result$(_namespace_0, _next_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, {$: "Tuple", fst: _live_0, snd: _live_0[_index_0 % _live_0.length]});
}

function $$$$047library$047storage$058fuse_bounds$(_valid_0, _world_0, _target_0, _transform_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../library/types.Missing"}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _t_0 = _world_0["rows"];
    const _main_0 = _t_0["main"];
    const _aux_0 = _t_0["aux"];
    const _metadata_0 = _t_0["metadata"];
    const _capacity_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _high_0 = _t_0["high_water"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return $$$$047library$047storage$058prototype_fuse_columns$(_namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, ((_target_0 - 1) >>> 0), _transform_0);
  }
}

function $$$$047library$047storage$058hook_checked$(_valid_0, _world_0, _target_0, _transform_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../library/types.Missing"}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _t_0 = _world_0["rows"];
    const _main_0 = _t_0["main"];
    const _aux_0 = _t_0["aux"];
    const _metadata_0 = _t_0["metadata"];
    const _capacity_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _high_0 = _t_0["high_water"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return $$$$047library$047storage$058fuse_bounds$(($Bool$and$((0 < _target_0), ($Bool$and$((_target_0 <= _capacity_0), (_target_0 <= _high_0))))), {$: "../library/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, _target_0, _transform_0);
  }
}

function $$$$047library$047storage$058with_main$(_world_0, _handle_0, _transform_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  const _foreign_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047library$047storage$058hook_checked$((_namespace_0 === _foreign_0), {$: "../library/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, _id_0, _transform_0);
}

function $$$$047library$047storage$058ledger_return$(_namespace_0, _next_0, _rows_0, _pending_0, _mode_0, _result_0) {
  const _ledger_0 = _result_0["fst"];
  const _observation_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../library/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": {$: "Some", "value": _ledger_0}, "mode": _mode_0}, "snd": {$: "Some", "value": _observation_0}};
}

function $$$$047library$047storage$058with_ledger$(_world_0, _transform_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _t_0 = _world_0["ledger"];
  if (_t_0.$ === "None") {
    const _mode_0 = _world_0["mode"];
    return {$: "Tuple", "fst": {$: "../library/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": {$: "None"}, "mode": _mode_0}, "snd": {$: "None"}};
  } else {
    const _ledger_0 = _t_0["value"];
    const _mode_1 = _world_0["mode"];
    return $$$$047library$047storage$058ledger_return$(_namespace_0, _next_0, _rows_0, _pending_0, _mode_1, _transform_0(_ledger_0));
  }
}

function $$$$047library$047storage$058publish$(_world_0, _staged_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return {$: "../library/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": ($List$reverse$go$(($List$reverse$(_staged_0)), _pending_0)), "ledger": _ledger_0, "mode": _mode_0};
}

function $$$$047library$047storage$058mark_meta$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0) {
  if (!_meta_0) {
    return {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0};
  } else {
    return {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": ($$$$047library$047storage$058metadata_mark$(_metadata_0, ((_id_0 - 1) >>> 0), _tick_0)), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0};
  }
}

function $$$$047library$047storage$058mark_meta_done$(_id_0, _tick_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _meta_0 = _result_0["snd"];
  return $$$$047library$047storage$058mark_meta$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0);
}

function $$$$047library$047storage$058mark_rows_checked$(_valid_0, _id_0, _tick_0, _rows_0) {
  if (!_valid_0) {
    return _rows_0;
  } else {
    const _main_0 = _rows_0["main"];
    const _aux_0 = _rows_0["aux"];
    const _metadata_0 = _rows_0["metadata"];
    const _capacity_0 = _rows_0["capacity"];
    const _depth_0 = _rows_0["depth"];
    const _high_0 = _rows_0["high_water"];
    return $$$$047library$047storage$058mark_meta_done$(_id_0, _tick_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, ($$$$047library$047storage$058metadata_live$(_metadata_0, ((_id_0 - 1) >>> 0))));
  }
}

function $$$$047library$047storage$058mark_rows$(_rows_0, _target_0, _tick_0) {
  const _m_0 = _rows_0["main"];
  const _a_0 = _rows_0["aux"];
  const _f_0 = _rows_0["metadata"];
  const _c_0 = _rows_0["capacity"];
  const _d_0 = _rows_0["depth"];
  const _h_0 = _rows_0["high_water"];
  return $$$$047library$047storage$058mark_rows_checked$(($Bool$and$((0 < _target_0), ($Bool$and$((_target_0 <= _c_0), (_target_0 <= _h_0))))), _target_0, _tick_0, {$: "../library/storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0});
}

function $$$$047library$047storage$058mark_checked$(_valid_0, _world_0, _target_0, _tick_0) {
  if (!_valid_0) {
    return _world_0;
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _rows_0 = _world_0["rows"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return {$: "../library/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": ($$$$047library$047storage$058mark_rows$(_rows_0, _target_0, _tick_0)), "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0};
  }
}

function $$$$047library$047storage$058prototype_mark_world_meta$(_namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _id_0, _tick_0, _meta_0) {
  if (!_meta_0) {
    return {$: "../library/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0};
  } else {
    return {$: "../library/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": ($$$$047library$047storage$058metadata_mark$(_metadata_0, ((_id_0 - 1) >>> 0), _tick_0)), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0};
  }
}

function $$$$047library$047storage$058prototype_mark_world_result$(_namespace_0, _next_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _id_0, _tick_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _meta_0 = _result_0["snd"];
  return $$$$047library$047storage$058prototype_mark_world_meta$(_namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _id_0, _tick_0, _meta_0);
}

function $$$$047library$047storage$058prototype_mark_open_live$(_namespace_0, _next_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _tick_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return {$: "../library/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": {$: "../library/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0};
  } else {
    return {$: "../library/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": {$: "../library/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": (_changed_0[_index_0 % _changed_0.length] = _tick_0, _changed_0)}, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0};
  }
}

function $$$$047library$047storage$058prototype_mark_open_columns$(_namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _tick_0) {
  const _live_0 = _metadata_0["live"];
  const _flags_0 = _metadata_0["flags"];
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  return $$$$047library$047storage$058prototype_mark_open_live$(_namespace_0, _next_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _tick_0, {$: "Tuple", fst: _live_0, snd: _live_0[_index_0 % _live_0.length]});
}

function $$$$047library$047storage$058prototype_mark_world_checked$(_valid_0, _namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _id_0, _tick_0) {
  if (!_valid_0) {
    return {$: "../library/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0};
  } else {
    return $$$$047library$047storage$058prototype_mark_open_columns$(_namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, ((_id_0 - 1) >>> 0), _tick_0);
  }
}

function $$$$047library$047storage$058mark_main$(_world_0, _handle_0, _tick_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _t_0 = _world_0["rows"];
  const _main_0 = _t_0["main"];
  const _aux_0 = _t_0["aux"];
  const _metadata_0 = _t_0["metadata"];
  const _capacity_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _high_0 = _t_0["high_water"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  const _foreign_0 = _handle_0["namespace"];
  const _target_0 = _handle_0["id"];
  return $$$$047library$047storage$058prototype_mark_world_checked$(($Bool$and$((_namespace_0 === _foreign_0), ($Bool$and$((0 < _target_0), ($Bool$and$((_target_0 <= _capacity_0), (_target_0 <= _high_0))))))), _namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _target_0, _tick_0);
}

function $$$$047library$047storage$058replace_main_effect$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _insert_0, _old_0) {
  if (!_insert_0) {
    if (_old_0.$ === "None") {
      return {$: "Tuple", "fst": {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "../library/storage.NoMainChange"}};
    } else {
      return {$: "Tuple", "fst": {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": ($$$$047library$047storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "../library/storage.Metadata", "live": true, "flag": _flag_0, "added": 0, "changed": 0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "../library/storage.RemovedMain"}};
    }
  } else {
    if (_old_0.$ === "None") {
      return {$: "Tuple", "fst": {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": ($$$$047library$047storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "../library/storage.Metadata", "live": true, "flag": _flag_0, "added": _tick_0, "changed": _tick_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "../library/storage.AddedMain"}};
    } else {
      return {$: "Tuple", "fst": {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": ($$$$047library$047storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "../library/storage.Metadata", "live": true, "flag": _flag_0, "added": _added_0, "changed": _tick_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "../library/storage.ChangedMain"}};
    }
  }
}

function $$$$047library$047storage$058replace_main_done$(_id_0, _tick_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _insert_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return $$$$047library$047storage$058replace_main_effect$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _insert_0, _old_0);
}

function $$$$047library$047storage$058replace_main_slot$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _replacement_0) {
  if (_replacement_0.$ === "None") {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047library$047storage$058replace_main_done$(_id_0, _tick_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, false, array_rmw(_main_0, _x_0, () => _x_1));
  } else {
    const _value_0 = _replacement_0["value"];
    const _x_2 = ((_id_0 - 1) >>> 0);
    const _x_3 = {$: "Some", "value": _value_0};
    return $$$$047library$047storage$058replace_main_done$(_id_0, _tick_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, true, array_rmw(_main_0, _x_2, () => _x_3));
  }
}

function $$$$047library$047storage$058replace_main_meta$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _replacement_0, _meta_0) {
  const _t_0 = _meta_0["live"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../library/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "../library/storage.MissingMainTarget"}};
  } else {
    const __3 = _meta_0["flag"];
    const __4 = _meta_0["added"];
    const __5 = _meta_0["changed"];
    return $$$$047library$047storage$058replace_main_slot$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, __3, __4, __5, _replacement_0);
  }
}

function $$$$047library$047storage$058replace_main_meta_done$(_id_0, _tick_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, _replacement_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _meta_0 = _result_0["snd"];
  return $$$$047library$047storage$058replace_main_meta$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _replacement_0, _meta_0);
}

function $$$$047library$047storage$058replace_main_checked$(_valid_0, _id_0, _tick_0, _rows_0, _replacement_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _rows_0, "snd": {$: "../library/storage.MissingMainTarget"}};
  } else {
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    return $$$$047library$047storage$058replace_main_meta_done$(_id_0, _tick_0, _m_0, _a_0, _c_0, _d_0, _h_0, _replacement_0, ($$$$047library$047storage$058metadata_get$(_f_0, ((_id_0 - 1) >>> 0))));
  }
}

function $$$$047library$047storage$058rows_replace_main$(_rows_0, _id_0, _replacement_0, _tick_0) {
  const _m_0 = _rows_0["main"];
  const _a_0 = _rows_0["aux"];
  const _f_0 = _rows_0["metadata"];
  const _c_0 = _rows_0["capacity"];
  const _d_0 = _rows_0["depth"];
  const _h_0 = _rows_0["high_water"];
  return $$$$047library$047storage$058replace_main_checked$(($Bool$and$((0 < _id_0), ($Bool$and$((_id_0 <= _c_0), (_id_0 <= _h_0))))), _id_0, _tick_0, {$: "../library/storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, _replacement_0);
}

function $$$$047library$047identity$058factory$() {
  return {$: "../library/storage.Factory", "next": 1};
}

function $$$$047library$047identity$058reserve_checked$(_available_0, _namespace_0, _next_0, _rows_0, _pending_0, _ledger_0, _mode_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": {$: "../library/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "None"}};
  } else {
    return {$: "Tuple", "fst": {$: "../library/storage.World", "namespace": _namespace_0, "next": ((_next_0 + 1) >>> 0), "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "Some", "value": {$: "../library/storage.Handle", "namespace": _namespace_0, "id": _next_0}}};
  }
}

function $$$$047library$047identity$058reserve_id$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $$$$047library$047identity$058reserve_checked$((_next_0 < 4294967295), _namespace_0, _next_0, _rows_0, _pending_0, _ledger_0, _mode_0);
}

function $$$$047library$047commands$058reserved$(_bundle_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "../library/types.ReserveRejected", "world": _world_0, "payload": _bundle_0};
  } else {
    const _t_1 = _t_0["value"];
    const _namespace_0 = _t_1["namespace"];
    const _id_0 = _t_1["id"];
    return {$: "../library/types.Reserved", "world": ($$$$047library$047storage$058publish$(_world_0, {$: "Con", "head": {$: "../library/storage.Spawn", "id": _id_0, "bundle": _bundle_0}, "tail": {$: "Nil"}})), "handle": {$: "../library/storage.Handle", "namespace": _namespace_0, "id": _id_0}};
  }
}

function $$$$047library$047commands$058reserve$(_world_0, _bundle_0) {
  return $$$$047library$047commands$058reserved$(_bundle_0, ($$$$047library$047identity$058reserve_id$(_world_0)));
}

function $$$$047library$047commands$058queue_checked$(_valid_0, _world_0, _target_0, _payload_0, _build_0) {
  if (!_valid_0) {
    return {$: "../library/types.CommandMissing", "world": _world_0, "payload": _payload_0};
  } else {
    return {$: "../library/types.CommandQueued", "world": ($$$$047library$047storage$058publish$(_world_0, {$: "Con", "head": _build_0(_target_0)(_payload_0), "tail": {$: "Nil"}}))};
  }
}

function $$$$047library$047commands$058queue_owned$(_world_0, _handle_0, _payload_0, _build_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  const _foreign_0 = _handle_0["namespace"];
  const _target_0 = _handle_0["id"];
  return $$$$047library$047commands$058queue_checked$((_namespace_0 === _foreign_0), {$: "../library/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, _target_0, _payload_0, _build_0);
}

function $$$$047library$047commands$058build_main$(_id_0, _main_0) {
  return {$: "../library/storage.InsertMain", "id": _id_0, "main": _main_0};
}

function $$$$047library$047commands$058build_flag$(_id_0, _flag_0) {
  return {$: "../library/storage.InsertFlag", "id": _id_0, "flag": _flag_0};
}

function $$$$047library$047commands$058build_remove_main$(_id_0, _unit_0) {
  return {$: "../library/storage.RemoveMain", "id": _id_0};
}

function $$$$047library$047commands$058build_remove_flag$(_id_0, _unit_0) {
  return {$: "../library/storage.RemoveFlag", "id": _id_0};
}

function $$$$047library$047commands$058build_despawn$(_id_0, _unit_0) {
  return {$: "../library/storage.Despawn", "id": _id_0};
}

function $$$$047library$047commands$058insert_main$(_world_0, _handle_0, _main_0) {
  return $$$$047library$047commands$058queue_owned$(_world_0, _handle_0, _main_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047library$047commands$058build_main$(_x_0, _x_1);
});
}));
}

function $$$$047library$047commands$058insert_flag$(_world_0, _handle_0, _flag_0) {
  return $$$$047library$047commands$058queue_owned$(_world_0, _handle_0, _flag_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047library$047commands$058build_flag$(_x_0, _x_1);
});
}));
}

function $$$$047library$047commands$058remove_main$(_world_0, _handle_0) {
  return $$$$047library$047commands$058queue_owned$(_world_0, _handle_0, {$: "Unit"}, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047library$047commands$058build_remove_main$(_x_0, _x_1);
});
}));
}

function $$$$047library$047commands$058remove_flag$(_world_0, _handle_0) {
  return $$$$047library$047commands$058queue_owned$(_world_0, _handle_0, {$: "Unit"}, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047library$047commands$058build_remove_flag$(_x_0, _x_1);
});
}));
}

function $$$$047library$047commands$058despawn$(_world_0, _handle_0) {
  return $$$$047library$047commands$058queue_owned$(_world_0, _handle_0, {$: "Unit"}, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047library$047commands$058build_despawn$(_x_0, _x_1);
});
}));
}

function $$$$047library$047commands$058edit_row$(_namespace_0, _tick_0, _command_0, _row_0) {
  if (_command_0.$ === "../library/storage.InsertFlag") {
    const _flag_0 = _command_0["flag"];
    const _id_0 = _row_0["id"];
    const _main_0 = _row_0["main"];
    const _aux_0 = _row_0["aux"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    return {$: "../library/commands.RowEdit", "row": {$: "Some", "value": {$: "../library/storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": {$: "Some", "value": _flag_0}, "added": _added_0, "changed": _changed_0}}, "changes": {$: "Nil"}};
  } else if (_command_0.$ === "../library/storage.RemoveFlag") {
    const _id_1 = _row_0["id"];
    const _main_1 = _row_0["main"];
    const _aux_1 = _row_0["aux"];
    const _added_1 = _row_0["added"];
    const _changed_1 = _row_0["changed"];
    return {$: "../library/commands.RowEdit", "row": {$: "Some", "value": {$: "../library/storage.Row", "id": _id_1, "main": _main_1, "aux": _aux_1, "flag": {$: "None"}, "added": _added_1, "changed": _changed_1}}, "changes": {$: "Nil"}};
  } else if (_command_0.$ === "../library/storage.InsertMain") {
    return {$: "../library/commands.RowEdit", "row": {$: "Some", "value": _row_0}, "changes": {$: "Nil"}};
  } else if (_command_0.$ === "../library/storage.RemoveMain") {
    return {$: "../library/commands.RowEdit", "row": {$: "Some", "value": _row_0}, "changes": {$: "Nil"}};
  } else if (_command_0.$ === "../library/storage.Despawn") {
    const _id_2 = _row_0["id"];
    const _t_0 = _row_0["main"];
    if (_t_0.$ === "Some") {
      return {$: "../library/commands.RowEdit", "row": {$: "None"}, "changes": {$: "Con", "head": {$: "../library/storage.MainRemoved", "handle": {$: "../library/storage.Handle", "namespace": _namespace_0, "id": _id_2}}, "tail": {$: "Con", "head": {$: "../library/storage.Despawned", "handle": {$: "../library/storage.Handle", "namespace": _namespace_0, "id": _id_2}}, "tail": {$: "Nil"}}}};
    } else {
      return {$: "../library/commands.RowEdit", "row": {$: "None"}, "changes": {$: "Con", "head": {$: "../library/storage.Despawned", "handle": {$: "../library/storage.Handle", "namespace": _namespace_0, "id": _id_2}}, "tail": {$: "Nil"}}};
    }
  } else {
    return {$: "../library/commands.RowEdit", "row": {$: "Some", "value": _row_0}, "changes": {$: "Nil"}};
  }
}

function $$$$047library$047commands$058bounded_spawn$(_id_0, _bundle_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _valid_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _rows_0, "snd": {$: "Tuple", "fst": {$: "../library/storage.Spawn", "id": _id_0, "bundle": _bundle_0}, "snd": _valid_0}};
}

function $$$$047library$047commands$058command_bound$(_rows_0, _command_0) {
  if (_command_0.$ === "../library/storage.Spawn") {
    const _id_0 = _command_0["id"];
    const _bundle_0 = _command_0["bundle"];
    return $$$$047library$047commands$058bounded_spawn$(_id_0, _bundle_0, ($$$$047library$047storage$058rows_can_place$(_rows_0, _id_0)));
  } else {
    return {$: "Tuple", "fst": _rows_0, "snd": {$: "Tuple", "fst": _command_0, "snd": true}};
  }
}

function $$$$047library$047commands$058preflight_step$(_reverse_0, _valid_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _command_0 = _t_0["fst"];
  const _bounded_0 = _t_0["snd"];
  return {$: "../library/commands.Preflight", "rows": _rows_0, "commands": {$: "Con", "head": _command_0, "tail": _reverse_0}, "valid": ($Bool$and$(_valid_0, _bounded_0))};
}

function $$$$047library$047commands$058preflight_go$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _state_0 = $1;
      if (_commands_0.$ === "Nil") {
        const _rows_0 = _state_0["rows"];
        const _reverse_0 = _state_0["commands"];
        const _valid_0 = _state_0["valid"];
        return {$: "../library/commands.Preflight", "rows": _rows_0, "commands": ($List$reverse$(_reverse_0)), "valid": _valid_0};
      } else {
        const _command_0 = _commands_0["head"];
        const _tail_0 = _commands_0["tail"];
        const _rows_1 = _state_0["rows"];
        const _reverse_1 = _state_0["commands"];
        const _valid_1 = _state_0["valid"];
        $0 = _tail_0;
        $1 = ($$$$047library$047commands$058preflight_step$(_reverse_1, _valid_1, ($$$$047library$047commands$058command_bound$(_rows_1, _command_0))));
        continue;
      }
    }
  }
}

function $$$$047library$047commands$058preflight$(_commands_0, _rows_0) {
  return $$$$047library$047commands$058preflight_go$(_commands_0, {$: "../library/commands.Preflight", "rows": _rows_0, "commands": {$: "Nil"}, "valid": true});
}

function $$$$047library$047commands$058removed$(_changes_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  return {$: "../library/commands.Stepped", "rows": _rows_0, "changes": _changes_0};
}

function $$$$047library$047commands$058edited$(_rows_0, _id_0, _result_0) {
  const _t_0 = _result_0["row"];
  if (_t_0.$ === "Some") {
    const _row_0 = _t_0["value"];
    const _changes_0 = _result_0["changes"];
    return {$: "../library/commands.Stepped", "rows": ($$$$047library$047storage$058rows_restore$(_rows_0, _row_0)), "changes": _changes_0};
  } else {
    const _changes_1 = _result_0["changes"];
    return $$$$047library$047commands$058removed$(_changes_1, ($$$$047library$047storage$058rows_remove$(_rows_0, _id_0)));
  }
}

function $$$$047library$047commands$058extracted$(_namespace_0, _tick_0, _id_0, _command_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "../library/commands.Stepped", "rows": _rows_0, "changes": {$: "Nil"}};
  } else {
    const _row_0 = _t_0["value"];
    return $$$$047library$047commands$058edited$(_rows_0, _id_0, ($$$$047library$047commands$058edit_row$(_namespace_0, _tick_0, _command_0, _row_0)));
  }
}

function $$$$047library$047commands$058placed$(_changes_0, _result_0) {
  if (_result_0.$ === "../library/storage.Placed") {
    const _rows_0 = _result_0["rows"];
    return {$: "../library/commands.Stepped", "rows": _rows_0, "changes": _changes_0};
  } else {
    const _rows_1 = _result_0["rows"];
    const _row_0 = _result_0["row"];
    return {$: "../library/commands.PlacementFault", "rows": _rows_1, "row": _row_0};
  }
}

function $$$$047library$047commands$058spawn$(_namespace_0, _tick_0, _id_0, _rows_0, _bundle_0) {
  const _t_0 = _bundle_0["main"];
  if (_t_0.$ === "None") {
    const _aux_0 = _bundle_0["aux"];
    const _flag_0 = _bundle_0["flag"];
    return $$$$047library$047commands$058placed$({$: "Nil"}, ($$$$047library$047storage$058rows_place$(_rows_0, {$: "../library/storage.Row", "id": _id_0, "main": {$: "None"}, "aux": _aux_0, "flag": _flag_0, "added": 0, "changed": 0})));
  } else {
    const _main_0 = _t_0["value"];
    const _aux_1 = _bundle_0["aux"];
    const _flag_1 = _bundle_0["flag"];
    return $$$$047library$047commands$058placed$({$: "Con", "head": {$: "../library/storage.MainAdded", "handle": {$: "../library/storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Con", "head": {$: "../library/storage.MainChanged", "handle": {$: "../library/storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Nil"}}}, ($$$$047library$047storage$058rows_place$(_rows_0, {$: "../library/storage.Row", "id": _id_0, "main": {$: "Some", "value": _main_0}, "aux": _aux_1, "flag": _flag_1, "added": _tick_0, "changed": _tick_0})));
  }
}

function $$$$047library$047commands$058targeted$(_command_0) {
  if (_command_0.$ === "../library/storage.Spawn") {
    const _id_0 = _command_0["id"];
    const _bundle_0 = _command_0["bundle"];
    return {$: "Tuple", "fst": {$: "../library/storage.Spawn", "id": _id_0, "bundle": _bundle_0}, "snd": _id_0};
  } else if (_command_0.$ === "../library/storage.InsertMain") {
    const _id_1 = _command_0["id"];
    const _main_0 = _command_0["main"];
    return {$: "Tuple", "fst": {$: "../library/storage.InsertMain", "id": _id_1, "main": _main_0}, "snd": _id_1};
  } else if (_command_0.$ === "../library/storage.InsertFlag") {
    const _id_2 = _command_0["id"];
    const _flag_0 = _command_0["flag"];
    return {$: "Tuple", "fst": {$: "../library/storage.InsertFlag", "id": _id_2, "flag": _flag_0}, "snd": _id_2};
  } else if (_command_0.$ === "../library/storage.RemoveMain") {
    const _id_3 = _command_0["id"];
    return {$: "Tuple", "fst": {$: "../library/storage.RemoveMain", "id": _id_3}, "snd": _id_3};
  } else if (_command_0.$ === "../library/storage.RemoveFlag") {
    const _id_4 = _command_0["id"];
    return {$: "Tuple", "fst": {$: "../library/storage.RemoveFlag", "id": _id_4}, "snd": _id_4};
  } else {
    const _id_5 = _command_0["id"];
    return {$: "Tuple", "fst": {$: "../library/storage.Despawn", "id": _id_5}, "snd": _id_5};
  }
}

function $$$$047library$047commands$058edit_target$(_namespace_0, _tick_0, _rows_0, _result_0) {
  const _command_0 = _result_0["fst"];
  const _id_0 = _result_0["snd"];
  return $$$$047library$047commands$058extracted$(_namespace_0, _tick_0, _id_0, _command_0, ($$$$047library$047storage$058rows_extract$(_rows_0, _id_0)));
}

function $$$$047library$047commands$058main_effect$(_namespace_0, _id_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../library/storage.AddedMain") {
    return {$: "../library/commands.Stepped", "rows": _rows_0, "changes": {$: "Con", "head": {$: "../library/storage.MainAdded", "handle": {$: "../library/storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Con", "head": {$: "../library/storage.MainChanged", "handle": {$: "../library/storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Nil"}}}};
  } else if (_t_0.$ === "../library/storage.ChangedMain") {
    return {$: "../library/commands.Stepped", "rows": _rows_0, "changes": {$: "Con", "head": {$: "../library/storage.MainChanged", "handle": {$: "../library/storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Nil"}}};
  } else if (_t_0.$ === "../library/storage.RemovedMain") {
    return {$: "../library/commands.Stepped", "rows": _rows_0, "changes": {$: "Con", "head": {$: "../library/storage.MainRemoved", "handle": {$: "../library/storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Nil"}}};
  } else if (_t_0.$ === "../library/storage.MissingMainTarget") {
    return {$: "../library/commands.Stepped", "rows": _rows_0, "changes": {$: "Nil"}};
  } else {
    return {$: "../library/commands.Stepped", "rows": _rows_0, "changes": {$: "Nil"}};
  }
}

function $$$$047library$047commands$058step$(_namespace_0, _tick_0, _rows_0, _command_0) {
  if (_command_0.$ === "../library/storage.Spawn") {
    const _id_0 = _command_0["id"];
    const _bundle_0 = _command_0["bundle"];
    return $$$$047library$047commands$058spawn$(_namespace_0, _tick_0, _id_0, _rows_0, _bundle_0);
  } else if (_command_0.$ === "../library/storage.InsertMain") {
    const _id_1 = _command_0["id"];
    const _main_0 = _command_0["main"];
    return $$$$047library$047commands$058main_effect$(_namespace_0, _id_1, ($$$$047library$047storage$058rows_replace_main$(_rows_0, _id_1, {$: "Some", "value": _main_0}, _tick_0)));
  } else if (_command_0.$ === "../library/storage.RemoveMain") {
    const _id_2 = _command_0["id"];
    return $$$$047library$047commands$058main_effect$(_namespace_0, _id_2, ($$$$047library$047storage$058rows_replace_main$(_rows_0, _id_2, {$: "None"}, _tick_0)));
  } else {
    return $$$$047library$047commands$058edit_target$(_namespace_0, _tick_0, _rows_0, ($$$$047library$047commands$058targeted$(_command_0)));
  }
}

function $$$$047library$047commands$058state_step$(_reverseChanges_0, _result_0) {
  if (_result_0.$ === "../library/commands.Stepped") {
    const _rows_0 = _result_0["rows"];
    const _changes_0 = _result_0["changes"];
    return {$: "../library/commands.Running", "rows": _rows_0, "reverseChanges": ($List$reverse$go$(_changes_0, _reverseChanges_0))};
  } else {
    const _rows_1 = _result_0["rows"];
    const _row_0 = _result_0["row"];
    return {$: "../library/commands.Faulted", "rows": _rows_1, "row": _row_0, "reverseRemaining": {$: "Nil"}, "changes": ($List$reverse$(_reverseChanges_0))};
  }
}

function $$$$047library$047commands$058state_command$(_namespace_0, _tick_0, _command_0, _state_0) {
  if (_state_0.$ === "../library/commands.Running") {
    const _rows_0 = _state_0["rows"];
    const _changes_0 = _state_0["reverseChanges"];
    return $$$$047library$047commands$058state_step$(_changes_0, ($$$$047library$047commands$058step$(_namespace_0, _tick_0, _rows_0, _command_0)));
  } else {
    const _rows_1 = _state_0["rows"];
    const _row_0 = _state_0["row"];
    const _remaining_0 = _state_0["reverseRemaining"];
    const _changes_1 = _state_0["changes"];
    return {$: "../library/commands.Faulted", "rows": _rows_1, "row": _row_0, "reverseRemaining": {$: "Con", "head": _command_0, "tail": _remaining_0}, "changes": _changes_1};
  }
}

function $$$$047library$047commands$058state_finish$(_state_0) {
  if (_state_0.$ === "../library/commands.Running") {
    const _rows_0 = _state_0["rows"];
    const _changes_0 = _state_0["reverseChanges"];
    return {$: "../library/commands.Completed", "rows": _rows_0, "changes": ($List$reverse$(_changes_0))};
  } else {
    const _rows_1 = _state_0["rows"];
    const _row_0 = _state_0["row"];
    const _remaining_0 = _state_0["reverseRemaining"];
    const _changes_1 = _state_0["changes"];
    return {$: "../library/commands.BatchFault", "rows": _rows_1, "row": _row_0, "remaining": ($List$reverse$(_remaining_0)), "changes": _changes_1};
  }
}

function $$$$047library$047commands$058batch$($0, $1, $2, $3) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _namespace_0 = $1;
      const _tick_0 = $2;
      const _state_0 = $3;
      if (_commands_0.$ === "Nil") {
        return $$$$047library$047commands$058state_finish$(_state_0);
      } else {
        const _command_0 = _commands_0["head"];
        const _tail_0 = _commands_0["tail"];
        $0 = _tail_0;
        $1 = _namespace_0;
        $2 = _tick_0;
        $3 = ($$$$047library$047commands$058state_command$(_namespace_0, _tick_0, _command_0, _state_0));
        continue;
      }
    }
  }
}

function $$$$047library$047commands$058batch_world$(_namespace_0, _next_0, _ledger_0, _mode_0, _result_0) {
  if (_result_0.$ === "../library/commands.Completed") {
    const _rows_0 = _result_0["rows"];
    const _changes_0 = _result_0["changes"];
    return {$: "../library/commands.Applied", "world": {$: "../library/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": {$: "Nil"}, "ledger": _ledger_0, "mode": _mode_0}, "changes": _changes_0};
  } else {
    const _rows_1 = _result_0["rows"];
    const _row_0 = _result_0["row"];
    const _remaining_0 = _result_0["remaining"];
    const _changes_1 = _result_0["changes"];
    return {$: "../library/commands.InvariantFault", "world": {$: "../library/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_1, "pending": ($List$reverse$(_remaining_0)), "ledger": _ledger_0, "mode": _mode_0}, "row": _row_0, "changes": _changes_1};
  }
}

function $$$$047library$047commands$058preflight_world$(_namespace_0, _next_0, _ledger_0, _mode_0, _tick_0, _result_0) {
  const _rows_0 = _result_0["rows"];
  const _pending_0 = _result_0["commands"];
  const _t_0 = _result_0["valid"];
  if (!_t_0) {
    return {$: "../library/commands.CapacityRejected", "world": {$: "../library/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}};
  } else {
    return $$$$047library$047commands$058batch_world$(_namespace_0, _next_0, _ledger_0, _mode_0, ($$$$047library$047commands$058batch$(($List$reverse$(_pending_0)), _namespace_0, _tick_0, {$: "../library/commands.Running", "rows": _rows_0, "reverseChanges": {$: "Nil"}})));
  }
}

function $$$$047library$047commands$058apply_checked$(_world_0, _tick_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $$$$047library$047commands$058preflight_world$(_namespace_0, _next_0, _ledger_0, _mode_0, _tick_0, ($$$$047library$047commands$058preflight$(_pending_0, _rows_0)));
}

function $World$() {
  return null;
}

function $stats$(_unit_0) {
  return {$: "Stats", "hits": 0};
}

function $finish$(_result_0) {
  if (_result_0.$ === "../library/commands.Applied") {
    const _changes_0 = _result_0["changes"];
    const _x_0 = ($List$length$(_changes_0));
    return {$: "Con", "head": (_x_0 >>> 0), "tail": {$: "Nil"}};
  } else {
    return {$: "Con", "head": 999, "tail": {$: "Nil"}};
  }
}

function $gone$(_result_0) {
  if (_result_0.$ === "../library/types.CommandQueued") {
    const _world_0 = _result_0["world"];
    return $finish$(($$$$047library$047commands$058apply_checked$(_world_0, 2)));
  } else {
    return {$: "Con", "head": 996, "tail": {$: "Nil"}};
  }
}

function $inserted$(_handle_0, _result_0) {
  if (_result_0.$ === "../library/types.CommandQueued") {
    const _world_0 = _result_0["world"];
    return $gone$(($$$$047library$047commands$058despawn$(_world_0, _handle_0)));
  } else {
    return {$: "Con", "head": 995, "tail": {$: "Nil"}};
  }
}

function $removed$(_handle_0, _result_0) {
  if (_result_0.$ === "../library/types.CommandQueued") {
    const _world_0 = _result_0["world"];
    return $inserted$(_handle_0, ($$$$047library$047commands$058insert_main$(_world_0, _handle_0, {$: "Position", "x": 7})));
  } else {
    return {$: "Con", "head": 994, "tail": {$: "Nil"}};
  }
}

function $seeded$(_handle_0, _result_0) {
  if (_result_0.$ === "../library/commands.Applied") {
    const _world_0 = _result_0["world"];
    return $removed$(_handle_0, ($$$$047library$047commands$058remove_main$(_world_0, _handle_0)));
  } else {
    return {$: "Con", "head": 993, "tail": {$: "Nil"}};
  }
}

function $reserved$(_result_0) {
  if (_result_0.$ === "../library/types.Reserved") {
    const _world_0 = _result_0["world"];
    const _handle_0 = _result_0["handle"];
    return $seeded$(_handle_0, ($$$$047library$047commands$058apply_checked$(_world_0, 1)));
  } else {
    return {$: "Con", "head": 998, "tail": {$: "Nil"}};
  }
}

function $created$(_result_0) {
  if (_result_0.$ === "../library/types.Created") {
    const _world_0 = _result_0["world"];
    return $reserved$(($$$$047library$047commands$058reserve$(_world_0, {$: "../library/storage.Bundle", "main": {$: "Some", "value": {$: "Position", "x": 3}}, "aux": {$: "Some", "value": {$: "Velocity", "dx": 2}}, "flag": {$: "Some", "value": {$: "Tag"}}})));
  } else {
    return {$: "Con", "head": 997, "tail": {$: "Nil"}};
  }
}

function $main$() {
  return $created$(($$$$047library$047identity$058create$1260$(($$$$047library$047identity$058factory$()), {$: "Playing"})));
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $U32$max$(_a_0, _b_0) {
  return $Bool$pick$((_a_0 < _b_0), _b_0, _a_0);
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $List$length$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = _xs_0["tail"];
    return nat_chk(($List$length$(_t_0)) + 1);
  }
}

function $$$$047library$047identity$058create$1260$(_factory_0, _mode_0) {
  const _namespace_0 = _factory_0["next"];
  return $$$$047library$047identity$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _mode_0);
}

function $Bool$pick$(_c_0, _a_0, _b_0) {
  if (!_c_0) {
    return _b_0;
  } else {
    return _a_0;
  }
}

function $$$$047library$047identity$058create_checked$1260$(_available_0, _namespace_0, _mode_0) {
  if (!_available_0) {
    return {$: "../library/types.CreateRejected", "factory": {$: "../library/storage.Factory", "next": _namespace_0}};
  } else {
    return {$: "../library/types.Created", "factory": {$: "../library/storage.Factory", "next": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../library/storage.World", "namespace": _namespace_0, "next": 1, "rows": ($$$$047library$047storage$058rows_empty$()), "pending": {$: "Nil"}, "ledger": {$: "Some", "value": ($stats$({$: "Unit"}))}, "mode": _mode_0}};
  }
}

function $0m0(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/storage.Rows": at = at[key] = {...v, "depth": BigInt(v["depth"])}; return top[0];
      default: throw "bend: ../library/storage.Rows has no tag " + v?.$ + " (its tags: ../library/storage.Rows); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m1(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/storage.Rows": at = at[key] = {...v, "depth": nat_host(v["depth"])}; return top[0];
      default: throw "bend: ../library/storage.Rows has no tag " + v?.$ + " (its tags: ../library/storage.Rows); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m2(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/storage.Rows": at = at[key] = {...v, "depth": BigInt(v["depth"])}; return top[0];
      default: throw "bend: ../library/storage.Rows has no tag " + v?.$ + " (its tags: ../library/storage.Rows); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m3(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m0(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m4(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m0(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m5(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/storage.Rows": at = at[key] = {...v, "depth": nat_host(v["depth"])}; return top[0];
      default: throw "bend: ../library/storage.Rows has no tag " + v?.$ + " (its tags: ../library/storage.Rows); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m6(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/storage.Rows": at = at[key] = {...v, "depth": BigInt(v["depth"])}; return top[0];
      default: throw "bend: ../library/storage.Rows has no tag " + v?.$ + " (its tags: ../library/storage.Rows); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m7(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m0(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m8(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m1(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m9(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m2(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m10(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/storage.Placed": at = at[key] = {...v, "rows": $0m0(v["rows"])}; return top[0];
      case "../library/storage.Rejected": at = at[key] = {...v, "rows": $0m0(v["rows"])}; return top[0];
      default: throw "bend: ../library/storage.Placement has no tag " + v?.$ + " (its tags: ../library/storage.Placed, ../library/storage.Rejected); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m11(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m0(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m12(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m0(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m13(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m1(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m14(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m2(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m16(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/storage.World": at = at[key] = {...v, "rows": $0m0(v["rows"])}; return top[0];
      default: throw "bend: ../library/storage.World has no tag " + v?.$ + " (its tags: ../library/storage.World); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m15(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m16(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m17(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m5(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m18(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m6(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m19(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/storage.World": at = at[key] = {...v, "rows": $0m5(v["rows"])}; return top[0];
      default: throw "bend: ../library/storage.World has no tag " + v?.$ + " (its tags: ../library/storage.World); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m20(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/storage.World": at = at[key] = {...v, "rows": $0m6(v["rows"])}; return top[0];
      default: throw "bend: ../library/storage.World has no tag " + v?.$ + " (its tags: ../library/storage.World); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m21(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m16(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m22(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m0(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m23(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m16(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m24(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/storage.World": at = at[key] = {...v, "rows": $0m5(v["rows"])}; return top[0];
      default: throw "bend: ../library/storage.World has no tag " + v?.$ + " (its tags: ../library/storage.World); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m25(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/storage.World": at = at[key] = {...v, "rows": $0m6(v["rows"])}; return top[0];
      default: throw "bend: ../library/storage.World has no tag " + v?.$ + " (its tags: ../library/storage.World); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m26(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m24(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m27(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m25(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m28(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/types.Reserved": at = at[key] = {...v, "world": $0m16(v["world"])}; return top[0];
      case "../library/types.ReserveRejected": at = at[key] = {...v, "world": $0m16(v["world"])}; return top[0];
      default: throw "bend: ../library/types.Reservation has no tag " + v?.$ + " (its tags: ../library/types.Reserved, ../library/types.ReserveRejected); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m29(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/types.CommandQueued": at = at[key] = {...v, "world": $0m16(v["world"])}; return top[0];
      case "../library/types.CommandMissing": at = at[key] = {...v, "world": $0m16(v["world"])}; return top[0];
      default: throw "bend: ../library/types.CommandResult has no tag " + v?.$ + " (its tags: ../library/types.CommandQueued, ../library/types.CommandMissing); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m30(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/types.CommandQueued": at = at[key] = {...v, "world": $0m16(v["world"])}; return top[0];
      case "../library/types.CommandMissing": at = at[key] = {...v, "world": $0m16(v["world"])}; return top[0];
      default: throw "bend: ../library/types.CommandResult has no tag " + v?.$ + " (its tags: ../library/types.CommandQueued, ../library/types.CommandMissing); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m31(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m1(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m32(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m2(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m33(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m0(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m34(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m1(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m35(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m2(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m36(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/commands.Preflight": at = at[key] = {...v, "rows": $0m0(v["rows"])}; return top[0];
      default: throw "bend: ../library/commands.Preflight has no tag " + v?.$ + " (its tags: ../library/commands.Preflight); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m37(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/commands.Preflight": at = at[key] = {...v, "rows": $0m1(v["rows"])}; return top[0];
      default: throw "bend: ../library/commands.Preflight has no tag " + v?.$ + " (its tags: ../library/commands.Preflight); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m38(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/commands.Preflight": at = at[key] = {...v, "rows": $0m2(v["rows"])}; return top[0];
      default: throw "bend: ../library/commands.Preflight has no tag " + v?.$ + " (its tags: ../library/commands.Preflight); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m39(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m5(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m40(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m6(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m41(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/commands.Stepped": at = at[key] = {...v, "rows": $0m0(v["rows"])}; return top[0];
      case "../library/commands.PlacementFault": at = at[key] = {...v, "rows": $0m0(v["rows"])}; return top[0];
      default: throw "bend: ../library/commands.StepResult has no tag " + v?.$ + " (its tags: ../library/commands.Stepped, ../library/commands.PlacementFault); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m42(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/storage.Placed": at = at[key] = {...v, "rows": $0m5(v["rows"])}; return top[0];
      case "../library/storage.Rejected": at = at[key] = {...v, "rows": $0m5(v["rows"])}; return top[0];
      default: throw "bend: ../library/storage.Placement has no tag " + v?.$ + " (its tags: ../library/storage.Placed, ../library/storage.Rejected); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m43(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/storage.Placed": at = at[key] = {...v, "rows": $0m6(v["rows"])}; return top[0];
      case "../library/storage.Rejected": at = at[key] = {...v, "rows": $0m6(v["rows"])}; return top[0];
      default: throw "bend: ../library/storage.Placement has no tag " + v?.$ + " (its tags: ../library/storage.Placed, ../library/storage.Rejected); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m44(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m5(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m45(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m6(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m46(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/commands.Stepped": at = at[key] = {...v, "rows": $0m5(v["rows"])}; return top[0];
      case "../library/commands.PlacementFault": at = at[key] = {...v, "rows": $0m5(v["rows"])}; return top[0];
      default: throw "bend: ../library/commands.StepResult has no tag " + v?.$ + " (its tags: ../library/commands.Stepped, ../library/commands.PlacementFault); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m47(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/commands.Stepped": at = at[key] = {...v, "rows": $0m6(v["rows"])}; return top[0];
      case "../library/commands.PlacementFault": at = at[key] = {...v, "rows": $0m6(v["rows"])}; return top[0];
      default: throw "bend: ../library/commands.StepResult has no tag " + v?.$ + " (its tags: ../library/commands.Stepped, ../library/commands.PlacementFault); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m48(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/commands.Running": at = at[key] = {...v, "rows": $0m0(v["rows"])}; return top[0];
      case "../library/commands.Faulted": at = at[key] = {...v, "rows": $0m0(v["rows"])}; return top[0];
      default: throw "bend: ../library/commands.BatchState has no tag " + v?.$ + " (its tags: ../library/commands.Running, ../library/commands.Faulted); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m49(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/commands.Running": at = at[key] = {...v, "rows": $0m5(v["rows"])}; return top[0];
      case "../library/commands.Faulted": at = at[key] = {...v, "rows": $0m5(v["rows"])}; return top[0];
      default: throw "bend: ../library/commands.BatchState has no tag " + v?.$ + " (its tags: ../library/commands.Running, ../library/commands.Faulted); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m50(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/commands.Running": at = at[key] = {...v, "rows": $0m6(v["rows"])}; return top[0];
      case "../library/commands.Faulted": at = at[key] = {...v, "rows": $0m6(v["rows"])}; return top[0];
      default: throw "bend: ../library/commands.BatchState has no tag " + v?.$ + " (its tags: ../library/commands.Running, ../library/commands.Faulted); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m51(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/commands.Completed": at = at[key] = {...v, "rows": $0m0(v["rows"])}; return top[0];
      case "../library/commands.BatchFault": at = at[key] = {...v, "rows": $0m0(v["rows"])}; return top[0];
      default: throw "bend: ../library/commands.BatchResult has no tag " + v?.$ + " (its tags: ../library/commands.Completed, ../library/commands.BatchFault); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m52(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/commands.Completed": at = at[key] = {...v, "rows": $0m5(v["rows"])}; return top[0];
      case "../library/commands.BatchFault": at = at[key] = {...v, "rows": $0m5(v["rows"])}; return top[0];
      default: throw "bend: ../library/commands.BatchResult has no tag " + v?.$ + " (its tags: ../library/commands.Completed, ../library/commands.BatchFault); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m53(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/commands.Completed": at = at[key] = {...v, "rows": $0m6(v["rows"])}; return top[0];
      case "../library/commands.BatchFault": at = at[key] = {...v, "rows": $0m6(v["rows"])}; return top[0];
      default: throw "bend: ../library/commands.BatchResult has no tag " + v?.$ + " (its tags: ../library/commands.Completed, ../library/commands.BatchFault); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m54(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/commands.Applied": at = at[key] = {...v, "world": $0m16(v["world"])}; return top[0];
      case "../library/commands.CapacityRejected": at = at[key] = {...v, "world": $0m16(v["world"])}; return top[0];
      case "../library/commands.InvariantFault": at = at[key] = {...v, "world": $0m16(v["world"])}; return top[0];
      default: throw "bend: ../library/commands.CheckedApply has no tag " + v?.$ + " (its tags: ../library/commands.Applied, ../library/commands.CapacityRejected, ../library/commands.InvariantFault); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m55(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/commands.Preflight": at = at[key] = {...v, "rows": $0m5(v["rows"])}; return top[0];
      default: throw "bend: ../library/commands.Preflight has no tag " + v?.$ + " (its tags: ../library/commands.Preflight); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m56(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/commands.Preflight": at = at[key] = {...v, "rows": $0m6(v["rows"])}; return top[0];
      default: throw "bend: ../library/commands.Preflight has no tag " + v?.$ + " (its tags: ../library/commands.Preflight); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m59(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/storage.Rows": at = at[key] = {...v, "depth": nat_host(v["depth"])}; return top[0];
      default: throw "bend: ../library/storage.Rows has no tag " + v?.$ + " (its tags: ../library/storage.Rows); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m58(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/storage.World": at = at[key] = {...v, "rows": $0m59(v["rows"])}; return top[0];
      default: throw "bend: ../library/storage.World has no tag " + v?.$ + " (its tags: ../library/storage.World); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m57(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/commands.Applied": at = at[key] = {...v, "world": $0m58(v["world"])}; return top[0];
      case "../library/commands.CapacityRejected": at = at[key] = {...v, "world": $0m58(v["world"])}; return top[0];
      case "../library/commands.InvariantFault": at = at[key] = {...v, "world": $0m58(v["world"])}; return top[0];
      default: throw "bend: ../library/commands.CheckedApply has no tag " + v?.$ + " (its tags: ../library/commands.Applied, ../library/commands.CapacityRejected, ../library/commands.InvariantFault); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m62(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/storage.Rows": at = at[key] = {...v, "depth": BigInt(v["depth"])}; return top[0];
      default: throw "bend: ../library/storage.Rows has no tag " + v?.$ + " (its tags: ../library/storage.Rows); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m61(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/storage.World": at = at[key] = {...v, "rows": $0m62(v["rows"])}; return top[0];
      default: throw "bend: ../library/storage.World has no tag " + v?.$ + " (its tags: ../library/storage.World); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m60(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/commands.Applied": at = at[key] = {...v, "world": $0m61(v["world"])}; return top[0];
      case "../library/commands.CapacityRejected": at = at[key] = {...v, "world": $0m61(v["world"])}; return top[0];
      case "../library/commands.InvariantFault": at = at[key] = {...v, "world": $0m61(v["world"])}; return top[0];
      default: throw "bend: ../library/commands.CheckedApply has no tag " + v?.$ + " (its tags: ../library/commands.Applied, ../library/commands.CapacityRejected, ../library/commands.InvariantFault); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m63(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/types.CommandQueued": at = at[key] = {...v, "world": $0m58(v["world"])}; return top[0];
      case "../library/types.CommandMissing": at = at[key] = {...v, "world": $0m58(v["world"])}; return top[0];
      default: throw "bend: ../library/types.CommandResult has no tag " + v?.$ + " (its tags: ../library/types.CommandQueued, ../library/types.CommandMissing); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m64(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/types.CommandQueued": at = at[key] = {...v, "world": $0m61(v["world"])}; return top[0];
      case "../library/types.CommandMissing": at = at[key] = {...v, "world": $0m61(v["world"])}; return top[0];
      default: throw "bend: ../library/types.CommandResult has no tag " + v?.$ + " (its tags: ../library/types.CommandQueued, ../library/types.CommandMissing); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m65(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/types.CommandQueued": at = at[key] = {...v, "world": $0m58(v["world"])}; return top[0];
      case "../library/types.CommandMissing": at = at[key] = {...v, "world": $0m58(v["world"])}; return top[0];
      default: throw "bend: ../library/types.CommandResult has no tag " + v?.$ + " (its tags: ../library/types.CommandQueued, ../library/types.CommandMissing); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m66(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/types.CommandQueued": at = at[key] = {...v, "world": $0m61(v["world"])}; return top[0];
      case "../library/types.CommandMissing": at = at[key] = {...v, "world": $0m61(v["world"])}; return top[0];
      default: throw "bend: ../library/types.CommandResult has no tag " + v?.$ + " (its tags: ../library/types.CommandQueued, ../library/types.CommandMissing); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m67(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/types.Reserved": at = at[key] = {...v, "world": $0m58(v["world"])}; return top[0];
      case "../library/types.ReserveRejected": at = at[key] = {...v, "world": $0m58(v["world"])}; return top[0];
      default: throw "bend: ../library/types.Reservation has no tag " + v?.$ + " (its tags: ../library/types.Reserved, ../library/types.ReserveRejected); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m68(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/types.Reserved": at = at[key] = {...v, "world": $0m61(v["world"])}; return top[0];
      case "../library/types.ReserveRejected": at = at[key] = {...v, "world": $0m61(v["world"])}; return top[0];
      default: throw "bend: ../library/types.Reservation has no tag " + v?.$ + " (its tags: ../library/types.Reserved, ../library/types.ReserveRejected); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m69(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/types.Created": at = at[key] = {...v, "world": $0m58(v["world"])}; return top[0];
      case "../library/types.CreateRejected": at[key] = v; return top[0];
      default: throw "bend: ../library/types.Creation has no tag " + v?.$ + " (its tags: ../library/types.Created, ../library/types.CreateRejected); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m70(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../library/types.Created": at = at[key] = {...v, "world": $0m61(v["world"])}; return top[0];
      case "../library/types.CreateRejected": at[key] = v; return top[0];
      default: throw "bend: ../library/types.Creation has no tag " + v?.$ + " (its tags: ../library/types.Created, ../library/types.CreateRejected); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}
export default {
  "../library/storage.metadata_empty": run_lib((a0) => { const r = (run_loop($$$$047library$047storage$058metadata_empty$(nat_host(a0)))); BigInt(a0); return r; }, 1),
  "../library/storage.metadata_grow": run_lib((a0, a1) => { const r = (run_loop($$$$047library$047storage$058metadata_grow$((a0), nat_host(a1)))); (a0); BigInt(a1); return r; }, 2),
  "../library/storage.metadata_get_changed": run_lib((a0, a1, a2, a3, a4, a5, a6) => { const r = (run_loop($$$$047library$047storage$058metadata_get_changed$((a0), (a1), (a2), (a3), (a4), (a5), (a6)))); (a0); (a1); (a2); (a3); (a4); (a5); (a6); return r; }, 7),
  "../library/storage.metadata_get_added": run_lib((a0, a1, a2, a3, a4, a5, a6) => { const r = (run_loop($$$$047library$047storage$058metadata_get_added$((a0), (a1), (a2), (a3), (a4), (a5), (a6)))); (a0); (a1); (a2); (a3); (a4); (a5); (a6); return r; }, 7),
  "../library/storage.metadata_get_flags": run_lib((a0, a1, a2, a3, a4, a5) => { const r = (run_loop($$$$047library$047storage$058metadata_get_flags$((a0), (a1), (a2), (a3), (a4), (a5)))); (a0); (a1); (a2); (a3); (a4); (a5); return r; }, 6),
  "../library/storage.metadata_get_live": run_lib((a0, a1, a2, a3, a4) => { const r = (run_loop($$$$047library$047storage$058metadata_get_live$((a0), (a1), (a2), (a3), (a4)))); (a0); (a1); (a2); (a3); (a4); return r; }, 5),
  "../library/storage.metadata_get": run_lib((a0, a1) => { const r = (run_loop($$$$047library$047storage$058metadata_get$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../library/storage.metadata_membership_flags": run_lib((a0, a1, a2, a3, a4) => { const r = (run_loop($$$$047library$047storage$058metadata_membership_flags$((a0), (a1), (a2), (a3), (a4)))); (a0); (a1); (a2); (a3); (a4); return r; }, 5),
  "../library/storage.metadata_membership_live": run_lib((a0, a1, a2, a3, a4) => { const r = (run_loop($$$$047library$047storage$058metadata_membership_live$((a0), (a1), (a2), (a3), (a4)))); (a0); (a1); (a2); (a3); (a4); return r; }, 5),
  "../library/storage.metadata_membership": run_lib((a0, a1) => { const r = (run_loop($$$$047library$047storage$058metadata_membership$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../library/storage.metadata_live_done": run_lib((a0, a1, a2, a3) => { const r = (run_loop($$$$047library$047storage$058metadata_live_done$((a0), (a1), (a2), (a3)))); (a0); (a1); (a2); (a3); return r; }, 4),
  "../library/storage.metadata_live": run_lib((a0, a1) => { const r = (run_loop($$$$047library$047storage$058metadata_live$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../library/storage.metadata_mark": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047library$047storage$058metadata_mark$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../library/storage.metadata_set": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047library$047storage$058metadata_set$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../library/storage.slots_empty": run_lib((a0) => { const r = (run_loop($$$$047library$047storage$058slots_empty$(nat_host(a0)))); BigInt(a0); return r; }, 1),
  "../library/storage.rows_empty": run_lib(() => { const r = $0m0(run_loop($$$$047library$047storage$058rows_empty$()));  return r; }, 0),
  "../library/storage.rows_high_water": run_lib((a0) => { const r = $0m3(run_loop($$$$047library$047storage$058rows_high_water$($0m1(a0)))); $0m2(a0); return r; }, 1),
  "../library/storage.rows_can_place": run_lib((a0, a1) => { const r = $0m4(run_loop($$$$047library$047storage$058rows_can_place$($0m1(a0), (a1)))); $0m2(a0); (a1); return r; }, 2),
  "../library/storage.grow_decide": run_lib((a0, a1, a2) => { const r = $0m0(run_loop($$$$047library$047storage$058grow_decide$((a0), $0m1(a1), ((f) => (x) => $0m1(f($0m2(x))))(a2)))); (a0); $0m2(a1); ((f) => (x) => $0m2(f($0m1(x))))(a2); return r; }, 3),
  "../library/storage.grow": run_lib((a0, a1, a2) => { const r = $0m0(run_loop($$$$047library$047storage$058grow$(nat_host(a0), (a1), $0m5(a2)))); BigInt(a0); (a1); $0m6(a2); return r; }, 3),
  "../library/storage.extract_row": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9) => { const r = $0m7(run_loop($$$$047library$047storage$058extract_row$((a0), (a1), (a2), (a3), (a4), (a5), (a6), nat_host(a7), (a8), (a9)))); (a0); (a1); (a2); (a3); (a4); (a5); (a6); BigInt(a7); (a8); (a9); return r; }, 10),
  "../library/storage.extract_aux": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8) => { const r = $0m7(run_loop($$$$047library$047storage$058extract_aux$((a0), (a1), (a2), (a3), (a4), nat_host(a5), (a6), (a7), (a8)))); (a0); (a1); (a2); (a3); (a4); BigInt(a5); (a6); (a7); (a8); return r; }, 9),
  "../library/storage.extract_main": run_lib((a0, a1, a2, a3, a4, a5, a6, a7) => { const r = $0m7(run_loop($$$$047library$047storage$058extract_main$((a0), (a1), (a2), (a3), nat_host(a4), (a5), (a6), (a7)))); (a0); (a1); (a2); (a3); BigInt(a4); (a5); (a6); (a7); return r; }, 8),
  "../library/storage.extract_meta": run_lib((a0, a1, a2, a3, a4, a5, a6) => { const r = $0m7(run_loop($$$$047library$047storage$058extract_meta$((a0), (a1), (a2), (a3), nat_host(a4), (a5), (a6)))); (a0); (a1); (a2); (a3); BigInt(a4); (a5); (a6); return r; }, 7),
  "../library/storage.extract_checked": run_lib((a0, a1, a2) => { const r = $0m7(run_loop($$$$047library$047storage$058extract_checked$((a0), (a1), $0m1(a2)))); (a0); (a1); $0m2(a2); return r; }, 3),
  "../library/storage.rows_extract": run_lib((a0, a1) => { const r = $0m7(run_loop($$$$047library$047storage$058rows_extract$($0m1(a0), (a1)))); $0m2(a0); (a1); return r; }, 2),
  "../library/storage.rows_restore": run_lib((a0, a1) => { const r = $0m0(run_loop($$$$047library$047storage$058rows_restore$($0m1(a0), (a1)))); $0m2(a0); (a1); return r; }, 2),
  "../library/storage.remove_done": run_lib((a0, a1) => { const r = $0m7(run_loop($$$$047library$047storage$058remove_done$((a0), $0m8(a1)))); (a0); $0m9(a1); return r; }, 2),
  "../library/storage.rows_remove": run_lib((a0, a1) => { const r = $0m7(run_loop($$$$047library$047storage$058rows_remove$($0m1(a0), (a1)))); $0m2(a0); (a1); return r; }, 2),
  "../library/storage.place_status": run_lib((a0, a1, a2, a3, a4, a5, a6, a7) => { const r = $0m10(run_loop($$$$047library$047storage$058place_status$((a0), (a1), (a2), (a3), nat_host(a4), (a5), (a6), (a7)))); (a0); (a1); (a2); (a3); BigInt(a4); (a5); (a6); (a7); return r; }, 8),
  "../library/storage.place_metadata": run_lib((a0, a1, a2, a3, a4, a5, a6, a7) => { const r = $0m10(run_loop($$$$047library$047storage$058place_metadata$((a0), (a1), (a2), (a3), nat_host(a4), (a5), (a6), (a7)))); (a0); (a1); (a2); (a3); BigInt(a4); (a5); (a6); (a7); return r; }, 8),
  "../library/storage.place_meta": run_lib((a0, a1, a2, a3, a4, a5, a6) => { const r = $0m10(run_loop($$$$047library$047storage$058place_meta$((a0), (a1), (a2), nat_host(a3), (a4), (a5), (a6)))); (a0); (a1); (a2); BigInt(a3); (a4); (a5); (a6); return r; }, 7),
  "../library/storage.place_capacity": run_lib((a0, a1, a2) => { const r = $0m10(run_loop($$$$047library$047storage$058place_capacity$((a0), $0m1(a1), (a2)))); (a0); $0m2(a1); (a2); return r; }, 3),
  "../library/storage.place_grown": run_lib((a0, a1) => { const r = $0m10(run_loop($$$$047library$047storage$058place_grown$($0m1(a0), (a1)))); $0m2(a0); (a1); return r; }, 2),
  "../library/storage.place_checked": run_lib((a0, a1, a2) => { const r = $0m10(run_loop($$$$047library$047storage$058place_checked$((a0), $0m1(a1), (a2)))); (a0); $0m2(a1); (a2); return r; }, 3),
  "../library/storage.rows_place": run_lib((a0, a1) => { const r = $0m10(run_loop($$$$047library$047storage$058rows_place$($0m1(a0), (a1)))); $0m2(a0); (a1); return r; }, 2),
  "../library/storage.take_main_done": run_lib((a0, a1, a2, a3, a4, a5) => { const r = $0m11(run_loop($$$$047library$047storage$058take_main_done$((a0), (a1), (a2), nat_host(a3), (a4), (a5)))); (a0); (a1); (a2); BigInt(a3); (a4); (a5); return r; }, 6),
  "../library/storage.take_meta": run_lib((a0, a1, a2, a3, a4, a5, a6, a7) => { const r = $0m11(run_loop($$$$047library$047storage$058take_meta$((a0), (a1), (a2), (a3), (a4), nat_host(a5), (a6), (a7)))); (a0); (a1); (a2); (a3); (a4); BigInt(a5); (a6); (a7); return r; }, 8),
  "../library/storage.take_meta_done": run_lib((a0, a1, a2, a3, a4, a5, a6) => { const r = $0m11(run_loop($$$$047library$047storage$058take_meta_done$((a0), (a1), (a2), (a3), nat_host(a4), (a5), (a6)))); (a0); (a1); (a2); (a3); BigInt(a4); (a5); (a6); return r; }, 7),
  "../library/storage.prototype_take_live": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9) => { const r = $0m11(run_loop($$$$047library$047storage$058prototype_take_live$((a0), (a1), (a2), (a3), (a4), (a5), (a6), nat_host(a7), (a8), (a9)))); (a0); (a1); (a2); (a3); (a4); (a5); (a6); BigInt(a7); (a8); (a9); return r; }, 10),
  "../library/storage.prototype_take_columns": run_lib((a0, a1, a2, a3, a4, a5, a6) => { const r = $0m11(run_loop($$$$047library$047storage$058prototype_take_columns$((a0), (a1), (a2), (a3), (a4), nat_host(a5), (a6)))); (a0); (a1); (a2); (a3); (a4); BigInt(a5); (a6); return r; }, 7),
  "../library/storage.take_checked": run_lib((a0, a1, a2) => { const r = $0m11(run_loop($$$$047library$047storage$058take_checked$((a0), (a1), $0m1(a2)))); (a0); (a1); $0m2(a2); return r; }, 3),
  "../library/storage.take_rows": run_lib((a0, a1) => { const r = $0m11(run_loop($$$$047library$047storage$058take_rows$($0m1(a0), (a1)))); $0m2(a0); (a1); return r; }, 2),
  "../library/storage.put_meta": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8) => { const r = $0m12(run_loop($$$$047library$047storage$058put_meta$((a0), (a1), (a2), (a3), (a4), nat_host(a5), (a6), (a7), (a8)))); (a0); (a1); (a2); (a3); (a4); BigInt(a5); (a6); (a7); (a8); return r; }, 9),
  "../library/storage.put_meta_done": run_lib((a0, a1, a2, a3, a4, a5, a6, a7) => { const r = $0m12(run_loop($$$$047library$047storage$058put_meta_done$((a0), (a1), (a2), (a3), nat_host(a4), (a5), (a6), (a7)))); (a0); (a1); (a2); (a3); BigInt(a4); (a5); (a6); (a7); return r; }, 8),
  "../library/storage.put_checked": run_lib((a0, a1, a2, a3) => { const r = $0m12(run_loop($$$$047library$047storage$058put_checked$((a0), (a1), $0m1(a2), (a3)))); (a0); (a1); $0m2(a2); (a3); return r; }, 4),
  "../library/storage.put_rows": run_lib((a0, a1, a2) => { const r = $0m12(run_loop($$$$047library$047storage$058put_rows$($0m1(a0), (a1), (a2)))); $0m2(a0); (a1); (a2); return r; }, 3),
  "../library/storage.put_finish": run_lib((a0) => { const r = $0m0(run_loop($$$$047library$047storage$058put_finish$($0m13(a0)))); $0m14(a0); return r; }, 1),
  "../library/storage.hook_return": run_lib((a0, a1, a2, a3, a4, a5, a6, a7) => { const r = $0m15(run_loop($$$$047library$047storage$058hook_return$((a0), (a1), $0m5(a2), (a3), (a4), (a5), (a6), (a7)))); (a0); (a1); $0m6(a2); (a3); (a4); (a5); (a6); (a7); return r; }, 8),
  "../library/storage.hook_taken": run_lib((a0, a1, a2, a3, a4, a5, a6, a7) => { const r = $0m15(run_loop($$$$047library$047storage$058hook_taken$((a0), (a1), (a2), (a3), (a4), (a5), (a6), $0m17(a7)))); (a0); (a1); (a2); (a3); (a4); (a5); (a6); $0m18(a7); return r; }, 8),
  "../library/storage.fuse_return": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12) => { const r = $0m15(run_loop($$$$047library$047storage$058fuse_return$((a0), (a1), (a2), (a3), (a4), nat_host(a5), (a6), (a7), (a8), (a9), (a10), (a11), (a12)))); (a0); (a1); (a2); (a3); (a4); BigInt(a5); (a6); (a7); (a8); (a9); (a10); (a11); (a12); return r; }, 13),
  "../library/storage.fuse_taken": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12) => { const r = $0m15(run_loop($$$$047library$047storage$058fuse_taken$((a0), (a1), (a2), (a3), (a4), nat_host(a5), (a6), (a7), (a8), (a9), (a10), (a11), (a12)))); (a0); (a1); (a2); (a3); (a4); BigInt(a5); (a6); (a7); (a8); (a9); (a10); (a11); (a12); return r; }, 13),
  "../library/storage.fuse_live": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13) => { const r = $0m15(run_loop($$$$047library$047storage$058fuse_live$((a0), (a1), (a2), (a3), (a4), nat_host(a5), (a6), (a7), (a8), (a9), (a10), (a11), (a12), (a13)))); (a0); (a1); (a2); (a3); (a4); BigInt(a5); (a6); (a7); (a8); (a9); (a10); (a11); (a12); (a13); return r; }, 14),
  "../library/storage.fuse_meta": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12) => { const r = $0m15(run_loop($$$$047library$047storage$058fuse_meta$((a0), (a1), (a2), (a3), (a4), nat_host(a5), (a6), (a7), (a8), (a9), (a10), (a11), (a12)))); (a0); (a1); (a2); (a3); (a4); BigInt(a5); (a6); (a7); (a8); (a9); (a10); (a11); (a12); return r; }, 13),
  "../library/storage.prototype_fuse_live_result": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15) => { const r = $0m15(run_loop($$$$047library$047storage$058prototype_fuse_live_result$((a0), (a1), (a2), (a3), (a4), (a5), (a6), (a7), nat_host(a8), (a9), (a10), (a11), (a12), (a13), (a14), (a15)))); (a0); (a1); (a2); (a3); (a4); (a5); (a6); (a7); BigInt(a8); (a9); (a10); (a11); (a12); (a13); (a14); (a15); return r; }, 16),
  "../library/storage.prototype_fuse_columns": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12) => { const r = $0m15(run_loop($$$$047library$047storage$058prototype_fuse_columns$((a0), (a1), (a2), (a3), (a4), (a5), nat_host(a6), (a7), (a8), (a9), (a10), (a11), (a12)))); (a0); (a1); (a2); (a3); (a4); (a5); BigInt(a6); (a7); (a8); (a9); (a10); (a11); (a12); return r; }, 13),
  "../library/storage.fuse_bounds": run_lib((a0, a1, a2, a3) => { const r = $0m15(run_loop($$$$047library$047storage$058fuse_bounds$((a0), $0m19(a1), (a2), (a3)))); (a0); $0m20(a1); (a2); (a3); return r; }, 4),
  "../library/storage.hook_checked": run_lib((a0, a1, a2, a3) => { const r = $0m15(run_loop($$$$047library$047storage$058hook_checked$((a0), $0m19(a1), (a2), (a3)))); (a0); $0m20(a1); (a2); (a3); return r; }, 4),
  "../library/storage.with_main": run_lib((a0, a1, a2) => { const r = $0m15(run_loop($$$$047library$047storage$058with_main$($0m19(a0), (a1), (a2)))); $0m20(a0); (a1); (a2); return r; }, 3),
  "../library/storage.ledger_return": run_lib((a0, a1, a2, a3, a4, a5) => { const r = $0m21(run_loop($$$$047library$047storage$058ledger_return$((a0), (a1), $0m5(a2), (a3), (a4), (a5)))); (a0); (a1); $0m6(a2); (a3); (a4); (a5); return r; }, 6),
  "../library/storage.with_ledger": run_lib((a0, a1) => { const r = $0m21(run_loop($$$$047library$047storage$058with_ledger$($0m19(a0), (a1)))); $0m20(a0); (a1); return r; }, 2),
  "../library/storage.publish": run_lib((a0, a1) => { const r = $0m16(run_loop($$$$047library$047storage$058publish$($0m19(a0), (a1)))); $0m20(a0); (a1); return r; }, 2),
  "../library/storage.mark_meta": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8) => { const r = $0m0(run_loop($$$$047library$047storage$058mark_meta$((a0), (a1), (a2), (a3), (a4), (a5), nat_host(a6), (a7), (a8)))); (a0); (a1); (a2); (a3); (a4); (a5); BigInt(a6); (a7); (a8); return r; }, 9),
  "../library/storage.mark_meta_done": run_lib((a0, a1, a2, a3, a4, a5, a6, a7) => { const r = $0m0(run_loop($$$$047library$047storage$058mark_meta_done$((a0), (a1), (a2), (a3), (a4), nat_host(a5), (a6), (a7)))); (a0); (a1); (a2); (a3); (a4); BigInt(a5); (a6); (a7); return r; }, 8),
  "../library/storage.mark_rows_checked": run_lib((a0, a1, a2, a3) => { const r = $0m0(run_loop($$$$047library$047storage$058mark_rows_checked$((a0), (a1), (a2), $0m1(a3)))); (a0); (a1); (a2); $0m2(a3); return r; }, 4),
  "../library/storage.mark_rows": run_lib((a0, a1, a2) => { const r = $0m0(run_loop($$$$047library$047storage$058mark_rows$($0m1(a0), (a1), (a2)))); $0m2(a0); (a1); (a2); return r; }, 3),
  "../library/storage.mark_checked": run_lib((a0, a1, a2, a3) => { const r = $0m16(run_loop($$$$047library$047storage$058mark_checked$((a0), $0m19(a1), (a2), (a3)))); (a0); $0m20(a1); (a2); (a3); return r; }, 4),
  "../library/storage.prototype_mark_world_meta": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13) => { const r = $0m16(run_loop($$$$047library$047storage$058prototype_mark_world_meta$((a0), (a1), (a2), (a3), (a4), (a5), nat_host(a6), (a7), (a8), (a9), (a10), (a11), (a12), (a13)))); (a0); (a1); (a2); (a3); (a4); (a5); BigInt(a6); (a7); (a8); (a9); (a10); (a11); (a12); (a13); return r; }, 14),
  "../library/storage.prototype_mark_world_result": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12) => { const r = $0m16(run_loop($$$$047library$047storage$058prototype_mark_world_result$((a0), (a1), (a2), (a3), (a4), nat_host(a5), (a6), (a7), (a8), (a9), (a10), (a11), (a12)))); (a0); (a1); (a2); (a3); (a4); BigInt(a5); (a6); (a7); (a8); (a9); (a10); (a11); (a12); return r; }, 13),
  "../library/storage.prototype_mark_open_live": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15) => { const r = $0m16(run_loop($$$$047library$047storage$058prototype_mark_open_live$((a0), (a1), (a2), (a3), (a4), (a5), (a6), (a7), nat_host(a8), (a9), (a10), (a11), (a12), (a13), (a14), (a15)))); (a0); (a1); (a2); (a3); (a4); (a5); (a6); (a7); BigInt(a8); (a9); (a10); (a11); (a12); (a13); (a14); (a15); return r; }, 16),
  "../library/storage.prototype_mark_open_columns": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12) => { const r = $0m16(run_loop($$$$047library$047storage$058prototype_mark_open_columns$((a0), (a1), (a2), (a3), (a4), (a5), nat_host(a6), (a7), (a8), (a9), (a10), (a11), (a12)))); (a0); (a1); (a2); (a3); (a4); (a5); BigInt(a6); (a7); (a8); (a9); (a10); (a11); (a12); return r; }, 13),
  "../library/storage.prototype_mark_world_checked": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13) => { const r = $0m16(run_loop($$$$047library$047storage$058prototype_mark_world_checked$((a0), (a1), (a2), (a3), (a4), (a5), (a6), nat_host(a7), (a8), (a9), (a10), (a11), (a12), (a13)))); (a0); (a1); (a2); (a3); (a4); (a5); (a6); BigInt(a7); (a8); (a9); (a10); (a11); (a12); (a13); return r; }, 14),
  "../library/storage.mark_main": run_lib((a0, a1, a2) => { const r = $0m16(run_loop($$$$047library$047storage$058mark_main$($0m19(a0), (a1), (a2)))); $0m20(a0); (a1); (a2); return r; }, 3),
  "../library/storage.replace_main_effect": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12) => { const r = $0m22(run_loop($$$$047library$047storage$058replace_main_effect$((a0), (a1), (a2), (a3), (a4), (a5), nat_host(a6), (a7), (a8), (a9), (a10), (a11), (a12)))); (a0); (a1); (a2); (a3); (a4); (a5); BigInt(a6); (a7); (a8); (a9); (a10); (a11); (a12); return r; }, 13),
  "../library/storage.replace_main_done": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11) => { const r = $0m22(run_loop($$$$047library$047storage$058replace_main_done$((a0), (a1), (a2), (a3), (a4), nat_host(a5), (a6), (a7), (a8), (a9), (a10), (a11)))); (a0); (a1); (a2); (a3); (a4); BigInt(a5); (a6); (a7); (a8); (a9); (a10); (a11); return r; }, 12),
  "../library/storage.replace_main_slot": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11) => { const r = $0m22(run_loop($$$$047library$047storage$058replace_main_slot$((a0), (a1), (a2), (a3), (a4), (a5), nat_host(a6), (a7), (a8), (a9), (a10), (a11)))); (a0); (a1); (a2); (a3); (a4); (a5); BigInt(a6); (a7); (a8); (a9); (a10); (a11); return r; }, 12),
  "../library/storage.replace_main_meta": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9) => { const r = $0m22(run_loop($$$$047library$047storage$058replace_main_meta$((a0), (a1), (a2), (a3), (a4), (a5), nat_host(a6), (a7), (a8), (a9)))); (a0); (a1); (a2); (a3); (a4); (a5); BigInt(a6); (a7); (a8); (a9); return r; }, 10),
  "../library/storage.replace_main_meta_done": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8) => { const r = $0m22(run_loop($$$$047library$047storage$058replace_main_meta_done$((a0), (a1), (a2), (a3), (a4), nat_host(a5), (a6), (a7), (a8)))); (a0); (a1); (a2); (a3); (a4); BigInt(a5); (a6); (a7); (a8); return r; }, 9),
  "../library/storage.replace_main_checked": run_lib((a0, a1, a2, a3, a4) => { const r = $0m22(run_loop($$$$047library$047storage$058replace_main_checked$((a0), (a1), (a2), $0m1(a3), (a4)))); (a0); (a1); (a2); $0m2(a3); (a4); return r; }, 5),
  "../library/storage.rows_replace_main": run_lib((a0, a1, a2, a3) => { const r = $0m22(run_loop($$$$047library$047storage$058rows_replace_main$($0m1(a0), (a1), (a2), (a3)))); $0m2(a0); (a1); (a2); (a3); return r; }, 4),
  "../library/identity.factory": run_lib(() => { const r = (run_loop($$$$047library$047identity$058factory$()));  return r; }, 0),
  "../library/identity.reserve_checked": run_lib((a0, a1, a2, a3, a4, a5, a6) => { const r = $0m23(run_loop($$$$047library$047identity$058reserve_checked$((a0), (a1), (a2), $0m5(a3), (a4), (a5), (a6)))); (a0); (a1); (a2); $0m6(a3); (a4); (a5); (a6); return r; }, 7),
  "../library/identity.reserve_id": run_lib((a0) => { const r = $0m23(run_loop($$$$047library$047identity$058reserve_id$($0m24(a0)))); $0m25(a0); return r; }, 1),
  "../library/commands.reserved": run_lib((a0, a1) => { const r = $0m28(run_loop($$$$047library$047commands$058reserved$((a0), $0m26(a1)))); (a0); $0m27(a1); return r; }, 2),
  "../library/commands.reserve": run_lib((a0, a1) => { const r = $0m28(run_loop($$$$047library$047commands$058reserve$($0m24(a0), (a1)))); $0m25(a0); (a1); return r; }, 2),
  "../library/commands.queue_checked": run_lib((a0, a1, a2, a3, a4) => { const r = $0m29(run_loop($$$$047library$047commands$058queue_checked$((a0), $0m24(a1), (a2), (a3), (a4)))); (a0); $0m25(a1); (a2); (a3); (a4); return r; }, 5),
  "../library/commands.queue_owned": run_lib((a0, a1, a2, a3) => { const r = $0m29(run_loop($$$$047library$047commands$058queue_owned$($0m24(a0), (a1), (a2), (a3)))); $0m25(a0); (a1); (a2); (a3); return r; }, 4),
  "../library/commands.build_main": run_lib((a0, a1) => { const r = (run_loop($$$$047library$047commands$058build_main$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../library/commands.build_flag": run_lib((a0, a1) => { const r = (run_loop($$$$047library$047commands$058build_flag$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../library/commands.build_remove_main": run_lib((a0, a1) => { const r = (run_loop($$$$047library$047commands$058build_remove_main$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../library/commands.build_remove_flag": run_lib((a0, a1) => { const r = (run_loop($$$$047library$047commands$058build_remove_flag$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../library/commands.build_despawn": run_lib((a0, a1) => { const r = (run_loop($$$$047library$047commands$058build_despawn$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../library/commands.insert_main": run_lib((a0, a1, a2) => { const r = $0m29(run_loop($$$$047library$047commands$058insert_main$($0m24(a0), (a1), (a2)))); $0m25(a0); (a1); (a2); return r; }, 3),
  "../library/commands.insert_flag": run_lib((a0, a1, a2) => { const r = $0m29(run_loop($$$$047library$047commands$058insert_flag$($0m24(a0), (a1), (a2)))); $0m25(a0); (a1); (a2); return r; }, 3),
  "../library/commands.remove_main": run_lib((a0, a1) => { const r = $0m30(run_loop($$$$047library$047commands$058remove_main$($0m24(a0), (a1)))); $0m25(a0); (a1); return r; }, 2),
  "../library/commands.remove_flag": run_lib((a0, a1) => { const r = $0m30(run_loop($$$$047library$047commands$058remove_flag$($0m24(a0), (a1)))); $0m25(a0); (a1); return r; }, 2),
  "../library/commands.despawn": run_lib((a0, a1) => { const r = $0m30(run_loop($$$$047library$047commands$058despawn$($0m24(a0), (a1)))); $0m25(a0); (a1); return r; }, 2),
  "../library/commands.edit_row": run_lib((a0, a1, a2, a3) => { const r = (run_loop($$$$047library$047commands$058edit_row$((a0), (a1), (a2), (a3)))); (a0); (a1); (a2); (a3); return r; }, 4),
  "../library/commands.bounded_spawn": run_lib((a0, a1, a2) => { const r = $0m33(run_loop($$$$047library$047commands$058bounded_spawn$((a0), (a1), $0m31(a2)))); (a0); (a1); $0m32(a2); return r; }, 3),
  "../library/commands.command_bound": run_lib((a0, a1) => { const r = $0m33(run_loop($$$$047library$047commands$058command_bound$($0m1(a0), (a1)))); $0m2(a0); (a1); return r; }, 2),
  "../library/commands.preflight_step": run_lib((a0, a1, a2) => { const r = $0m36(run_loop($$$$047library$047commands$058preflight_step$((a0), (a1), $0m34(a2)))); (a0); (a1); $0m35(a2); return r; }, 3),
  "../library/commands.preflight_go": run_lib((a0, a1) => { const r = $0m36(run_loop($$$$047library$047commands$058preflight_go$((a0), $0m37(a1)))); (a0); $0m38(a1); return r; }, 2),
  "../library/commands.preflight": run_lib((a0, a1) => { const r = $0m36(run_loop($$$$047library$047commands$058preflight$((a0), $0m1(a1)))); (a0); $0m2(a1); return r; }, 2),
  "../library/commands.removed": run_lib((a0, a1) => { const r = $0m41(run_loop($$$$047library$047commands$058removed$((a0), $0m39(a1)))); (a0); $0m40(a1); return r; }, 2),
  "../library/commands.edited": run_lib((a0, a1, a2) => { const r = $0m41(run_loop($$$$047library$047commands$058edited$($0m5(a0), (a1), (a2)))); $0m6(a0); (a1); (a2); return r; }, 3),
  "../library/commands.extracted": run_lib((a0, a1, a2, a3, a4) => { const r = $0m41(run_loop($$$$047library$047commands$058extracted$((a0), (a1), (a2), (a3), $0m39(a4)))); (a0); (a1); (a2); (a3); $0m40(a4); return r; }, 5),
  "../library/commands.placed": run_lib((a0, a1) => { const r = $0m41(run_loop($$$$047library$047commands$058placed$((a0), $0m42(a1)))); (a0); $0m43(a1); return r; }, 2),
  "../library/commands.spawn": run_lib((a0, a1, a2, a3, a4) => { const r = $0m41(run_loop($$$$047library$047commands$058spawn$((a0), (a1), (a2), $0m5(a3), (a4)))); (a0); (a1); (a2); $0m6(a3); (a4); return r; }, 5),
  "../library/commands.targeted": run_lib((a0) => { const r = (run_loop($$$$047library$047commands$058targeted$((a0)))); (a0); return r; }, 1),
  "../library/commands.edit_target": run_lib((a0, a1, a2, a3) => { const r = $0m41(run_loop($$$$047library$047commands$058edit_target$((a0), (a1), $0m5(a2), (a3)))); (a0); (a1); $0m6(a2); (a3); return r; }, 4),
  "../library/commands.main_effect": run_lib((a0, a1, a2) => { const r = $0m41(run_loop($$$$047library$047commands$058main_effect$((a0), (a1), $0m44(a2)))); (a0); (a1); $0m45(a2); return r; }, 3),
  "../library/commands.step": run_lib((a0, a1, a2, a3) => { const r = $0m41(run_loop($$$$047library$047commands$058step$((a0), (a1), $0m5(a2), (a3)))); (a0); (a1); $0m6(a2); (a3); return r; }, 4),
  "../library/commands.state_step": run_lib((a0, a1) => { const r = $0m48(run_loop($$$$047library$047commands$058state_step$((a0), $0m46(a1)))); (a0); $0m47(a1); return r; }, 2),
  "../library/commands.state_command": run_lib((a0, a1, a2, a3) => { const r = $0m48(run_loop($$$$047library$047commands$058state_command$((a0), (a1), (a2), $0m49(a3)))); (a0); (a1); (a2); $0m50(a3); return r; }, 4),
  "../library/commands.state_finish": run_lib((a0) => { const r = $0m51(run_loop($$$$047library$047commands$058state_finish$($0m49(a0)))); $0m50(a0); return r; }, 1),
  "../library/commands.batch": run_lib((a0, a1, a2, a3) => { const r = $0m51(run_loop($$$$047library$047commands$058batch$((a0), (a1), (a2), $0m49(a3)))); (a0); (a1); (a2); $0m50(a3); return r; }, 4),
  "../library/commands.batch_world": run_lib((a0, a1, a2, a3, a4) => { const r = $0m54(run_loop($$$$047library$047commands$058batch_world$((a0), (a1), (a2), (a3), $0m52(a4)))); (a0); (a1); (a2); (a3); $0m53(a4); return r; }, 5),
  "../library/commands.preflight_world": run_lib((a0, a1, a2, a3, a4, a5) => { const r = $0m54(run_loop($$$$047library$047commands$058preflight_world$((a0), (a1), (a2), (a3), (a4), $0m55(a5)))); (a0); (a1); (a2); (a3); (a4); $0m56(a5); return r; }, 6),
  "../library/commands.apply_checked": run_lib((a0, a1) => { const r = $0m54(run_loop($$$$047library$047commands$058apply_checked$($0m24(a0), (a1)))); $0m25(a0); (a1); return r; }, 2),
  "World": run_lib(() => { const r = (run_loop($World$()));  return r; }, 0),
  "stats": run_lib((a0) => { const r = (run_loop($stats$((a0)))); (a0); return r; }, 1),
  "finish": run_lib((a0) => { const r = (run_loop($finish$($0m57(a0)))); $0m60(a0); return r; }, 1),
  "gone": run_lib((a0) => { const r = (run_loop($gone$($0m63(a0)))); $0m64(a0); return r; }, 1),
  "inserted": run_lib((a0, a1) => { const r = (run_loop($inserted$((a0), $0m65(a1)))); (a0); $0m66(a1); return r; }, 2),
  "removed": run_lib((a0, a1) => { const r = (run_loop($removed$((a0), $0m63(a1)))); (a0); $0m64(a1); return r; }, 2),
  "seeded": run_lib((a0, a1) => { const r = (run_loop($seeded$((a0), $0m57(a1)))); (a0); $0m60(a1); return r; }, 2),
  "reserved": run_lib((a0) => { const r = (run_loop($reserved$($0m67(a0)))); $0m68(a0); return r; }, 1),
  "created": run_lib((a0) => { const r = (run_loop($created$($0m69(a0)))); $0m70(a0); return r; }, 1),
  "main": run_lib(() => { const r = (run_loop($main$()));  return r; }, 0),
};
