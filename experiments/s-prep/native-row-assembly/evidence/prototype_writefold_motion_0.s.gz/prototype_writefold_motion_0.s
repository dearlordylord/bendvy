WL_FID____BENDVY_WRITE_ROW_FOLD_V2_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_WRITEFOLD_MOTION_0: // @WL_FID____BENDVY_WRITE_ROW_FOLD_V2_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_WRITEFOLD_MOTION_0
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #176
	.cfi_def_cfa_offset 176
	stp	x29, x30, [sp, #160]            // 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	ldp	x16, x17, [x29, #72]
	stp	x11, x13, [x29, #-48]           // 16-byte Folded Spill
	stp	x25, x7, [x29, #-64]            // 16-byte Folded Spill
	mov	x11, x5
	ldr	x19, [x29, #16]
	ldp	x5, x8, [x29, #88]
	stp	x16, x17, [x29, #-24]           // 16-byte Folded Spill
	ldp	x16, x17, [x29, #56]
	ldp	x25, x2, [x29, #24]
	stur	x17, [x29, #-32]                // 8-byte Folded Spill
	ldp	x18, x17, [x29, #40]
	tbnz	x28, #63, .LBB78_14
// %bb.1:
	tbnz	x0, #63, .LBB78_15
.LBB78_2:
	tbnz	x1, #63, .LBB78_16
.LBB78_3:
	tbnz	x3, #63, .LBB78_17
.LBB78_4:
	tbnz	x4, #63, .LBB78_18
.LBB78_5:
	tbnz	x11, #63, .LBB78_19
.LBB78_6:
	ldur	x13, [x29, #-48]                // 8-byte Folded Reload
	tbnz	x13, #63, .LBB78_20
.LBB78_7:
	ldur	x13, [x29, #-40]                // 8-byte Folded Reload
	tbnz	x13, #63, .LBB78_21
.LBB78_8:
	ldur	x24, [x29, #-32]                // 8-byte Folded Reload
	tbnz	x24, #63, .LBB78_22
.LBB78_9:
	ldur	x24, [x29, #-24]                // 8-byte Folded Reload
	tbnz	x24, #63, .LBB78_23
.LBB78_10:
	ldur	x24, [x29, #-16]                // 8-byte Folded Reload
	tbnz	x24, #63, .LBB78_24
.LBB78_11:
	tbnz	x5, #63, .LBB78_25
.LBB78_12:
	mov	w26, w26
	mov	w27, w27
	mov	w6, w6
	mov	w10, w10
	mov	w12, w12
	mov	w14, w14
	mov	w9, w9
	mov	w15, w15
	mov	w30, w19
	mov	w7, w25
	mov	w2, w2
	mov	w24, w18
	mov	w13, w17
	mov	w25, w16
	mov	w19, w8
	cbz	w23, .LBB78_26
// %bb.13:
	mov	w8, #58                         // =0x3a
	str	x8, [x22], #8
	ldur	x8, [x29, #-16]                 // 8-byte Folded Reload
	stp	x5, x19, [x29, #88]
	mov	x5, x11
	str	x8, [x29, #80]
	ldur	x8, [x29, #-24]                 // 8-byte Folded Reload
	stp	x24, x13, [x29, #40]
	ldp	x11, x13, [x29, #-48]           // 16-byte Folded Reload
	str	x8, [x29, #72]
	ldur	x8, [x29, #-32]                 // 8-byte Folded Reload
	stp	x7, x2, [x29, #24]
	stp	x25, x8, [x29, #56]
	ldp	x25, x7, [x29, #-64]            // 16-byte Folded Reload
	str	x30, [x29, #16]
	.cfi_def_cfa wsp, 176
	ldp	x29, x30, [sp, #160]            // 16-byte Folded Reload
	add	sp, sp, #176
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	WL_FID____BENDVY_WRITE_ROW_FOLD_V2_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_WRITEFOLD_MOTION_LOOP_0
.LBB78_14:
	.cfi_restore_state
	.cfi_remember_state
	and	x24, x28, #0xffffffffff
	ldr	xzr, [x20, x24, lsl #3]
	tbz	x0, #63, .LBB78_2
.LBB78_15:
	and	x24, x0, #0xffffffffff
	ldr	xzr, [x20, x24, lsl #3]
	tbz	x1, #63, .LBB78_3
.LBB78_16:
	and	x24, x1, #0xffffffffff
	ldr	xzr, [x20, x24, lsl #3]
	tbz	x3, #63, .LBB78_4
.LBB78_17:
	and	x24, x3, #0xffffffffff
	ldr	xzr, [x20, x24, lsl #3]
	tbz	x4, #63, .LBB78_5
.LBB78_18:
	and	x24, x4, #0xffffffffff
	ldr	xzr, [x20, x24, lsl #3]
	tbz	x11, #63, .LBB78_6
.LBB78_19:
	and	x24, x11, #0xffffffffff
	ldr	xzr, [x20, x24, lsl #3]
	ldur	x13, [x29, #-48]                // 8-byte Folded Reload
	tbz	x13, #63, .LBB78_7
.LBB78_20:
	ldur	x13, [x29, #-48]                // 8-byte Folded Reload
	and	x24, x13, #0xffffffffff
	ldr	xzr, [x20, x24, lsl #3]
	ldur	x13, [x29, #-40]                // 8-byte Folded Reload
	tbz	x13, #63, .LBB78_8
.LBB78_21:
	ldur	x13, [x29, #-40]                // 8-byte Folded Reload
	and	x24, x13, #0xffffffffff
	ldr	xzr, [x20, x24, lsl #3]
	ldur	x24, [x29, #-32]                // 8-byte Folded Reload
	tbz	x24, #63, .LBB78_9
.LBB78_22:
	ldur	x24, [x29, #-32]                // 8-byte Folded Reload
	and	x24, x24, #0xffffffffff
	ldr	xzr, [x20, x24, lsl #3]
	ldur	x24, [x29, #-24]                // 8-byte Folded Reload
	tbz	x24, #63, .LBB78_10
.LBB78_23:
	ldur	x24, [x29, #-24]                // 8-byte Folded Reload
	and	x24, x24, #0xffffffffff
	ldr	xzr, [x20, x24, lsl #3]
	ldur	x24, [x29, #-16]                // 8-byte Folded Reload
	tbz	x24, #63, .LBB78_11
.LBB78_24:
	ldur	x24, [x29, #-16]                // 8-byte Folded Reload
	and	x24, x24, #0xffffffffff
	ldr	xzr, [x20, x24, lsl #3]
	tbz	x5, #63, .LBB78_12
.LBB78_25:
	and	x24, x5, #0xffffffffff
	ldr	xzr, [x20, x24, lsl #3]
	b	.LBB78_12
.LBB78_26:
	stp	x2, x7, [sp, #72]               // 16-byte Folded Spill
	ldp	x2, x23, [x22, #-24]
	ldr	x8, [x21, #40]
	stur	x30, [x29, #-72]                // 8-byte Folded Spill
	cbz	x8, .LBB78_31
// %bb.27:
	ldr	x16, [x20, x8, lsl #3]
	ldr	x17, [x21, #296]
	str	x16, [x21, #40]
	sub	x16, x17, #32
	str	x16, [x21, #296]
.LBB78_28:
	movi	v0.2d, #0xffffffffffffffff
	mov	w17, #1                         // =0x1
	mov	x18, #63771674411008            // =0x3a0000000000
	add	x16, x20, x8, lsl #3
	orr	x17, x17, x23, lsl #32
	movk	x18, #1280, lsl #48
	orr	x23, x8, x18
	stp	x2, x17, [x16, #224]
	stp	q0, q0, [x16]
	stp	q0, q0, [x16, #32]
	stp	q0, q0, [x16, #64]
	stp	q0, q0, [x16, #96]
	stp	q0, q0, [x16, #128]
	stp	q0, q0, [x16, #160]
	stp	q0, q0, [x16, #192]
	stp	x23, xzr, [x22, #-24]
	ldr	x8, [x21, #40]
	cbz	x8, .LBB78_32
// %bb.29:
	ldr	x16, [x20, x8, lsl #3]
	ldr	x17, [x21, #296]
	mov	x18, x14
	mov	x2, x12
	mov	x30, x26
	str	x16, [x21, #40]
	sub	x16, x17, #32
	str	x16, [x21, #296]
.LBB78_30:
	ldp	x17, x12, [x29, #-64]           // 16-byte Folded Reload
	add	x16, x20, x8, lsl #3
	stp	x11, x6, [x16, #64]
	stp	x12, x10, [x16, #80]
	ldp	x10, x11, [x29, #-48]           // 16-byte Folded Reload
	stp	x9, x15, [x16, #128]
	str	xzr, [x16, #240]
	stp	x11, x18, [x16, #112]
	ldp	x9, x11, [sp, #72]              // 16-byte Folded Reload
	stp	x10, x2, [x16, #96]
	ldur	x10, [x29, #-72]                // 8-byte Folded Reload
	stp	x17, x30, [x16]
	stp	x10, x11, [x16, #144]
	stp	x9, x24, [x16, #160]
	ldp	x10, x9, [x29, #-32]            // 16-byte Folded Reload
	stp	x27, x28, [x16, #16]
	stp	x0, x1, [x16, #32]
	stp	x10, x9, [x16, #192]
	ldur	x9, [x29, #-16]                 // 8-byte Folded Reload
	stp	x3, x4, [x16, #48]
	stp	x9, x5, [x16, #208]
	mov	x9, #53876069761024             // =0x310000000000
	movk	x9, #1280, lsl #48
	stp	x13, x25, [x16, #176]
	orr	x0, x8, x9
	stp	x19, x23, [x16, #224]
	.cfi_def_cfa wsp, 176
	ldp	x29, x30, [sp, #160]            // 16-byte Folded Reload
	add	sp, sp, #176
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB78_31:
	.cfi_restore_state
	stp	x1, x0, [sp, #56]               // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	stp	x2, x3, [sp, #8]                // 16-byte Folded Spill
	mov	w2, #5                          // =0x5
	stp	x11, x28, [sp, #24]             // 16-byte Folded Spill
	mov	x28, x5
	stp	x6, x4, [sp, #40]               // 16-byte Folded Spill
	bl	heap_alloc_miss
	ldp	x2, x3, [sp, #8]                // 16-byte Folded Reload
	mov	x5, x28
	ldp	x28, x6, [sp, #32]              // 16-byte Folded Reload
	mov	x8, x0
	ldp	x4, x1, [sp, #48]               // 16-byte Folded Reload
	ldr	x11, [sp, #24]                  // 8-byte Folded Reload
	ldr	x0, [sp, #64]                   // 8-byte Folded Reload
	b	.LBB78_28
.LBB78_32:
	stp	x1, x0, [sp, #56]               // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	mov	w2, #5                          // =0x5
	stp	x28, x6, [sp, #32]              // 16-byte Folded Spill
	mov	x22, x3
	str	x4, [sp, #48]                   // 8-byte Folded Spill
	mov	x28, x5
	bl	heap_alloc_miss
	mov	x5, x28
	ldp	x28, x6, [sp, #32]              // 16-byte Folded Reload
	ldp	x4, x1, [sp, #48]               // 16-byte Folded Reload
	mov	x8, x0
	ldr	x0, [sp, #64]                   // 8-byte Folded Reload
	mov	x30, x26
	mov	x2, x12
	mov	x18, x14
	mov	x3, x22
	b	.LBB78_30
.Lfunc_end78:
