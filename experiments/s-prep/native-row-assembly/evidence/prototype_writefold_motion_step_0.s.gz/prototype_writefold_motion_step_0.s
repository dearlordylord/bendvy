WL_FID____BENDVY_WRITE_ROW_FOLD_V2_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_WRITEFOLD_MOTION_STEP_0: // @WL_FID____BENDVY_WRITE_ROW_FOLD_V2_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_WRITEFOLD_MOTION_STEP_0
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	sub	sp, sp, #592
	ldr	x8, [x29, #72]
	mov	x18, x9
	mov	x16, x10
	ldp	x30, x17, [x29, #96]
	cmp	w27, w25
	stp	x8, x6, [x29, #-176]            // 16-byte Folded Spill
	ldr	x8, [x29, #48]
	ldp	x9, x2, [x29, #80]
	stp	x14, x8, [x29, #-192]           // 16-byte Folded Spill
	ldp	x10, x8, [x29, #32]
	ldp	x24, x6, [x29, #16]
	stur	x8, [x29, #-200]                // 8-byte Folded Spill
	b.ne	.LBB65_14
// %bb.1:
	sub	w8, w26, #1
	cmp	w8, w7
	b.hs	.LBB65_14
// %bb.2:
	cmp	w26, w11
	b.hi	.LBB65_14
// %bb.3:
	mov	w19, w13
	cmp	x19, #1
	b.ne	.LBB65_16
// %bb.4:
	and	x19, x3, #0xffffffffff
	mov	x13, x19
	tbnz	x3, #63, .LBB65_23
// %bb.5:
	str	x19, [sp, #296]                 // 8-byte Folded Spill
	and	x19, x4, #0xffffffffff
	str	x19, [sp, #328]                 // 8-byte Folded Spill
	ldur	x19, [x29, #-168]               // 8-byte Folded Reload
	tbnz	x4, #63, .LBB65_24
.LBB65_6:
	and	x14, x5, #0xffffffffff
	tbnz	x5, #63, .LBB65_25
.LBB65_7:
	stp	x12, x16, [x29, #-224]          // 16-byte Folded Spill
	and	x12, x19, #0xffffffffff
	stp	x17, x28, [x29, #-240]          // 16-byte Folded Spill
	tbnz	x19, #63, .LBB65_26
.LBB65_8:
	lsr	x16, x3, #40
	mov	w17, #-1                        // =0xffffffff
	add	x13, x20, x13, lsl #3
	str	x12, [sp, #256]                 // 8-byte Folded Spill
	lsl	w16, w17, w16
	bic	w16, w8, w16
	ldr	w13, [x13, w16, uxtw #2]
	cbz	w13, .LBB65_27
// %bb.9:
	and	x12, x0, #0xffffffffff
	stur	x2, [x29, #-248]                // 8-byte Folded Spill
	mov	x13, x12
	tbz	x0, #63, .LBB65_11
// %bb.10:
	ldr	x13, [x20, x12, lsl #3]
	lsr	x13, x13, #24
.LBB65_11:
	ubfx	x16, x0, #40, #5
	mov	x17, #-1                        // =0xffffffffffffffff
	lsl	x13, x13, #3
	sub	w16, w16, #1
	add	x13, x20, x13
	lsl	x16, x17, x16
	bic	w8, w8, w16
	lsl	w8, w8, #1
	ubfiz	x8, x8, #3, #32
	add	x8, x13, x8
	ldr	w13, [x8]
	ldr	x2, [x8, #8]
	stp	xzr, xzr, [x8]
	cbz	w13, .LBB65_34
// %bb.12:
	and	x8, x2, #0xffffffffff
	str	x16, [sp, #232]                 // 8-byte Folded Spill
	add	x16, x20, x8, lsl #3
	stur	x12, [x29, #-256]               // 8-byte Folded Spill
	str	x14, [sp, #176]                 // 8-byte Folded Spill
	stp	x7, x0, [sp, #304]              // 16-byte Folded Spill
	stp	x3, x4, [sp, #280]              // 16-byte Folded Spill
	str	x1, [sp, #320]                  // 8-byte Folded Spill
	stur	x9, [x29, #-208]                // 8-byte Folded Spill
	str	x24, [sp, #248]                 // 8-byte Folded Spill
	tbnz	x2, #63, .LBB65_37
// %bb.13:
	ldp	x24, x2, [x16]
	mov	x13, x8
	mov	w12, #34047                     // =0x84ff
	movk	w12, #784, lsl #16
	cmp	x8, x12
	b.hi	.LBB65_41
	b	.LBB65_43
.LBB65_14:
	stur	x9, [x29, #-208]                // 8-byte Folded Spill
	mov	x9, x30
	cbz	w23, .LBB65_18
// %bb.15:
	mov	w8, w17
	mov	x19, x24
	mov	x24, x16
	mov	w16, #48                        // =0x30
	mov	x14, x12
	mov	w17, w7
	stp	x8, x16, [x22], #16
	mov	w7, w11
	stp	x2, x9, [x29, #72]
	ldur	x9, [x29, #-208]                // 8-byte Folded Reload
	mov	w11, w13
	mov	w13, w18
	mov	w18, w15
	ldp	x15, x12, [x29, #-184]          // 16-byte Folded Reload
	str	x9, [x29, #64]
	mov	w9, w26
	stp	x9, x12, [x29, #48]
	mov	w12, w25
	mov	w9, w19
	mov	w19, w15
	mov	w8, w27
	mov	w16, w28
	stp	x19, x12, [x29, #32]
	ldur	x12, [x29, #-200]               // 8-byte Folded Reload
	mov	x28, x1
	mov	x1, x4
	ldur	x4, [x29, #-168]                // 8-byte Folded Reload
	mov	w15, w6
	mov	w12, w12
	mov	w19, w10
	mov	x25, x8
	stp	x19, x12, [x29, #16]
	mov	x26, x16
	mov	x27, x0
	mov	x0, x3
	mov	x3, x5
	mov	x5, x17
	mov	x6, x24
	mov	x10, x14
	ldur	x12, [x29, #-192]               // 8-byte Folded Reload
	mov	x14, x18
	add	sp, sp, #592
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	WL_FID____BENDVY_WRITE_ROW_FOLD_V2_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0
.LBB65_16:
	.cfi_restore_state
	.cfi_remember_state
	cbz	w23, .LBB65_29
// %bb.17:
	mov	w8, w17
	mov	w13, #47                        // =0x2f
	mov	w17, w7
	stp	x8, x13, [x22], #16
	mov	w8, w27
	mov	x27, x10
	mov	x10, x12
	mov	w7, w11
	ldp	x12, x11, [x29, #-184]          // 16-byte Folded Reload
	str	x9, [x29, #64]
	mov	w9, w26
	mov	x14, x6
	mov	x6, x16
	mov	w16, w28
	mov	w13, w18
	mov	w18, w15
	stp	x9, x11, [x29, #48]
	mov	w11, w25
	mov	w12, w12
	stp	x12, x11, [x29, #32]
	ldp	x11, x12, [x29, #-200]          // 16-byte Folded Reload
	mov	w9, w24
	mov	w24, w27
	mov	x28, x1
	mov	x1, x4
	ldur	x4, [x29, #-168]                // 8-byte Folded Reload
	stp	x2, x30, [x29, #72]
	mov	w11, w11
	mov	w15, w14
	mov	x25, x8
	stp	x24, x11, [x29, #16]
	mov	x26, x16
	mov	x27, x0
	mov	x0, x3
	mov	x3, x5
	mov	x5, x17
	mov	x11, x19
	mov	x14, x18
	add	sp, sp, #592
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	WL_FID____BENDVY_WRITE_ROW_FOLD_V2_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0
.LBB65_18:
	.cfi_restore_state
	.cfi_remember_state
	ldp	x19, x23, [x22, #-24]
	mov	x14, x10
	ldr	x8, [x21, #40]
	mov	x10, x17
	stp	x25, x26, [x29, #-224]          // 16-byte Folded Spill
	mov	x25, x18
	mov	x26, x16
	cbz	x8, .LBB65_122
// %bb.19:
	ldr	x16, [x20, x8, lsl #3]
	ldr	x17, [x21, #296]
	str	x16, [x21, #40]
	sub	x16, x17, #32
	str	x16, [x21, #296]
.LBB65_20:
	mov	w17, #1                         // =0x1
	add	x16, x20, x8, lsl #3
	movi	v0.2d, #0xffffffffffffffff
	orr	x18, x17, x23, lsl #32
	stp	x19, x18, [x16, #232]
	mov	x19, #52776558133248            // =0x300000000000
	mov	w18, w10
	movk	x19, #1280, lsl #48
	stur	q0, [x16, #216]
	orr	x19, x8, x19
	stur	q0, [x16, #200]
	stur	q0, [x16, #184]
	stur	q0, [x16, #168]
	stur	q0, [x16, #152]
	stur	q0, [x16, #136]
	stur	q0, [x16, #120]
	stur	q0, [x16, #104]
	stur	q0, [x16, #88]
	stur	q0, [x16, #72]
	stur	q0, [x16, #56]
	stur	q0, [x16, #40]
	stur	q0, [x16, #24]
	stur	q0, [x16, #8]
	str	x18, [x16]
	stp	x19, x17, [x22, #-24]
	ldr	x8, [x21, #40]
	cbz	x8, .LBB65_123
// %bb.21:
	ldr	x16, [x20, x8, lsl #3]
	ldr	x17, [x21, #296]
	mov	x23, x14
	str	x16, [x21, #40]
	sub	x16, x17, #32
	str	x16, [x21, #296]
	ldur	x21, [x29, #-184]               // 8-byte Folded Reload
.LBB65_22:
	add	x16, x20, x8, lsl #3
	mov	x17, #4294967296                // =0x100000000
	mov	w18, w27
	ldur	x10, [x29, #-168]               // 8-byte Folded Reload
	mov	x30, x9
	mov	x9, x25
	stp	x19, x17, [x16, #216]
	mov	w17, w28
	mov	w19, w13
	stp	x18, x17, [x16]
	mov	w17, w7
	stp	x17, x26, [x16, #64]
	ldp	x25, x26, [x29, #-224]          // 16-byte Folded Reload
	stp	x5, x10, [x16, #48]
	mov	w10, w11
	stp	x0, x1, [x16, #16]
	stp	x3, x4, [x16, #32]
	stp	x10, x12, [x16, #80]
	b	.LBB65_121
.LBB65_23:
	ldr	x13, [x20, x19, lsl #3]
	lsr	x13, x13, #24
	str	x19, [sp, #296]                 // 8-byte Folded Spill
	and	x19, x4, #0xffffffffff
	str	x19, [sp, #328]                 // 8-byte Folded Spill
	ldur	x19, [x29, #-168]               // 8-byte Folded Reload
	tbz	x4, #63, .LBB65_6
.LBB65_24:
	ldr	x14, [sp, #328]                 // 8-byte Folded Reload
	ldr	xzr, [x20, x14, lsl #3]
	and	x14, x5, #0xffffffffff
	tbz	x5, #63, .LBB65_7
.LBB65_25:
	ldr	xzr, [x20, x14, lsl #3]
	stp	x12, x16, [x29, #-224]          // 16-byte Folded Spill
	and	x12, x19, #0xffffffffff
	stp	x17, x28, [x29, #-240]          // 16-byte Folded Spill
	tbz	x19, #63, .LBB65_8
.LBB65_26:
	ldr	xzr, [x20, x12, lsl #3]
	b	.LBB65_8
.LBB65_27:
	cbz	w23, .LBB65_110
// %bb.28:
	ldur	x8, [x29, #-240]                // 8-byte Folded Reload
	mov	w13, #45                        // =0x2d
	mov	w8, w8
	stp	x8, x13, [x22]
	ldur	x13, [x29, #-232]               // 8-byte Folded Reload
	mov	w8, w27
	stp	x2, x30, [x29, #72]
	mov	w17, w13
	b	.LBB65_36
.LBB65_29:
	ldp	x13, x23, [x22, #-24]
	ldr	x8, [x21, #40]
	stp	x15, x10, [x29, #-232]          // 16-byte Folded Spill
	mov	x10, x17
	stp	x16, x9, [x29, #-216]           // 16-byte Folded Spill
	mov	x9, x18
	cbz	x8, .LBB65_130
// %bb.30:
	ldr	x16, [x20, x8, lsl #3]
	ldr	x17, [x21, #296]
	str	x16, [x21, #40]
	sub	x16, x17, #32
	str	x16, [x21, #296]
.LBB65_31:
	mov	w17, #1                         // =0x1
	add	x16, x20, x8, lsl #3
	movi	v0.2d, #0xffffffffffffffff
	orr	x18, x17, x23, lsl #32
	stp	x13, x18, [x16, #232]
	mov	x18, #51677046505472            // =0x2f0000000000
	mov	w13, w10
	movk	x18, #1280, lsl #48
	str	x13, [x16]
	orr	x13, x8, x18
	stur	q0, [x16, #216]
	stur	q0, [x16, #200]
	stur	q0, [x16, #184]
	stur	q0, [x16, #168]
	stur	q0, [x16, #152]
	stur	q0, [x16, #136]
	stur	q0, [x16, #120]
	stur	q0, [x16, #104]
	stur	q0, [x16, #88]
	stur	q0, [x16, #72]
	stur	q0, [x16, #56]
	stur	q0, [x16, #40]
	stur	q0, [x16, #24]
	stur	q0, [x16, #8]
	stp	x13, x17, [x22, #-24]
	ldr	x8, [x21, #40]
	cbz	x8, .LBB65_131
// %bb.32:
	ldr	x16, [x20, x8, lsl #3]
	ldr	x17, [x21, #296]
	ldur	x23, [x29, #-224]               // 8-byte Folded Reload
	str	x16, [x21, #40]
	sub	x16, x17, #32
	str	x16, [x21, #296]
	ldur	x21, [x29, #-184]               // 8-byte Folded Reload
.LBB65_33:
	add	x16, x20, x8, lsl #3
	ldur	x10, [x29, #-168]               // 8-byte Folded Reload
	mov	x17, #4294967296                // =0x100000000
	ldur	x15, [x29, #-232]               // 8-byte Folded Reload
	stp	x13, x17, [x16, #216]
	mov	w13, w27
	mov	w17, w28
	stp	x5, x10, [x16, #48]
	ldur	x10, [x29, #-216]               // 8-byte Folded Reload
	stp	x13, x17, [x16]
	mov	w13, w7
	stp	x13, x10, [x16, #64]
	mov	w10, w11
	stp	x0, x1, [x16, #16]
	stp	x3, x4, [x16, #32]
	stp	x10, x12, [x16, #80]
	b	.LBB65_121
.LBB65_34:
	ldp	x8, x16, [x29, #-240]           // 16-byte Folded Reload
	cbz	w23, .LBB65_115
// %bb.35:
	mov	w8, w8
	mov	w13, #46                        // =0x2e
	mov	w17, w16
	stp	x8, x13, [x22]
	ldur	x13, [x29, #-248]               // 8-byte Folded Reload
	mov	w8, w27
	stp	x13, x30, [x29, #72]
.LBB65_36:
	mov	w16, w7
	mov	w7, w11
	str	x9, [x29, #64]
	ldp	x12, x11, [x29, #-184]          // 16-byte Folded Reload
	mov	w9, w26
	mov	w13, w18
	mov	w18, w15
	mov	w15, w6
	mov	w19, w10
	ldp	x10, x6, [x29, #-224]           // 16-byte Folded Reload
	stp	x9, x11, [x29, #48]
	mov	w11, w25
	mov	w12, w12
	stp	x12, x11, [x29, #32]
	ldp	x11, x12, [x29, #-200]          // 16-byte Folded Reload
	mov	x28, x1
	mov	x1, x4
	ldur	x4, [x29, #-168]                // 8-byte Folded Reload
	mov	w9, w24
	mov	w11, w11
	add	x22, x22, #16
	mov	x25, x8
	stp	x19, x11, [x29, #16]
	mov	x26, x17
	mov	x27, x0
	mov	x0, x3
	mov	x3, x5
	mov	x5, x16
	mov	w11, #1                         // =0x1
	mov	x14, x18
	add	sp, sp, #592
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	WL_FID____BENDVY_WRITE_ROW_FOLD_V2_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0
.LBB65_37:
	.cfi_restore_state
	.cfi_remember_state
	ldr	w13, [x16, #4]
	ldr	w17, [x16]
	mov	x28, x26
	mov	x26, x25
	mov	x25, x11
	mov	x11, x27
	mov	x27, x18
	and	x18, x17, #0xffffff
	cmp	x18, #1
	b.ne	.LBB65_135
// %bb.38:
	orr	x13, x17, x13, lsl #32
	ldar	wzr, [x16]
	ldr	x16, [x21]
	lsr	x13, x13, #24
	add	x17, x20, x13, lsl #3
	ldp	x24, x2, [x17]
	str	x16, [x20, x8, lsl #3]
	ldr	x16, [x21, #256]
	str	x8, [x21]
	add	x8, x16, #1
	adrp	x16, .L_MergedGlobals
	str	x8, [x21, #256]
	ldrb	w16, [x16, :lo12:.L_MergedGlobals]
	cmp	w16, #1
	b.ne	.LBB65_140
// %bb.39:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB65_140
.LBB65_40:
	mov	x18, x27
	mov	x27, x11
	mov	x11, x25
	mov	x25, x26
	mov	x26, x28
	mov	w12, #34047                     // =0x84ff
	movk	w12, #784, lsl #16
	cmp	x13, x12
	b.ls	.LBB65_43
.LBB65_41:
	ldr	x8, [x21, #8]
	adrp	x16, .L_MergedGlobals
	str	x8, [x20, x13, lsl #3]
	ldr	x8, [x21, #264]
	str	x13, [x21, #8]
	add	x8, x8, #2
	str	x8, [x21, #264]
	ldrb	w16, [x16, :lo12:.L_MergedGlobals]
	cmp	w16, #1
	b.ne	.LBB65_132
// %bb.42:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB65_132
.LBB65_43:
	and	x8, x24, #0xffffffffff
	add	x16, x20, x8, lsl #3
	tbnz	x24, #63, .LBB65_45
// %bb.44:
	ldp	x13, x14, [x16]
	mov	x19, x8
	str	x14, [sp, #208]                 // 8-byte Folded Spill
	cmp	x8, x12
	b.hi	.LBB65_49
	b	.LBB65_51
.LBB65_45:
	str	x2, [sp, #240]                  // 8-byte Folded Spill
	mov	x28, x26
	mov	x26, x25
	ldr	w13, [x16, #4]
	ldr	w17, [x16]
	mov	x25, x11
	mov	x11, x27
	mov	x27, x18
	and	x18, x17, #0xffffff
	cmp	x18, #1
	b.ne	.LBB65_136
// %bb.46:
	orr	x13, x17, x13, lsl #32
	ldar	wzr, [x16]
	ldr	x16, [x21]
	lsr	x19, x13, #24
	add	x17, x20, x19, lsl #3
	ldp	x13, x14, [x17]
	str	x16, [x20, x8, lsl #3]
	ldr	x16, [x21, #256]
	str	x8, [x21]
	add	x8, x16, #1
	adrp	x16, .L_MergedGlobals
	str	x14, [sp, #208]                 // 8-byte Folded Spill
	str	x8, [x21, #256]
	ldrb	w16, [x16, :lo12:.L_MergedGlobals]
	cmp	w16, #1
	b.ne	.LBB65_141
// %bb.47:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB65_141
.LBB65_48:
	ldr	x2, [sp, #240]                  // 8-byte Folded Reload
	mov	x18, x27
	mov	x27, x11
	mov	x11, x25
	mov	x25, x26
	mov	x26, x28
	cmp	x19, x12
	b.ls	.LBB65_51
.LBB65_49:
	ldr	x8, [x21, #8]
	adrp	x16, .L_MergedGlobals
	str	x8, [x20, x19, lsl #3]
	ldr	x8, [x21, #264]
	str	x19, [x21, #8]
	add	x8, x8, #2
	str	x8, [x21, #264]
	ldrb	w16, [x16, :lo12:.L_MergedGlobals]
	cmp	w16, #1
	b.ne	.LBB65_133
// %bb.50:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB65_133
.LBB65_51:
	and	x8, x2, #0xffffffffff
	str	x5, [sp, #272]                  // 8-byte Folded Spill
	add	x16, x20, x8, lsl #3
	tbnz	x2, #63, .LBB65_53
// %bb.52:
	ldp	x2, x14, [x16]
	mov	x24, x8
	str	x14, [sp, #200]                 // 8-byte Folded Spill
	ldp	x14, x19, [x16, #16]
	str	x14, [sp, #192]                 // 8-byte Folded Spill
	ldr	x14, [x16, #32]
	str	x14, [sp, #184]                 // 8-byte Folded Spill
	mov	x28, x26
	cmp	x8, x12
	b.hi	.LBB65_59
	b	.LBB65_61
.LBB65_53:
	mov	x28, x26
	mov	x26, x25
	mov	x25, x11
	mov	x11, x27
	mov	x27, x18
	ldr	w18, [x16, #4]
	ldr	w19, [x16]
	and	x17, x19, #0xffffff
	cmp	x17, #1
	b.ne	.LBB65_55
// %bb.54:
	ldar	wzr, [x16]
.LBB65_55:
	orr	x18, x19, x18, lsl #32
	cmp	x17, #1
	lsr	x24, x18, #24
	add	x18, x20, x24, lsl #3
	ldp	x14, x0, [x18]
	ldp	x1, x19, [x18, #16]
	ldr	x18, [x18, #32]
	str	x18, [sp, #184]                 // 8-byte Folded Spill
	stp	x1, x0, [sp, #192]              // 16-byte Folded Spill
	b.ne	.LBB65_137
// %bb.56:
	ldr	x17, [x21]
	str	x17, [x16]
	ldr	x16, [x21, #256]
	str	x8, [x21]
	add	x8, x16, #1
	adrp	x16, .L_MergedGlobals
	str	x8, [x21, #256]
	ldrb	w16, [x16, :lo12:.L_MergedGlobals]
	cmp	w16, #1
	b.ne	.LBB65_142
// %bb.57:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB65_142
.LBB65_58:
	mov	x18, x27
	mov	x27, x11
	mov	x11, x25
	mov	x25, x26
	mov	x2, x14
	cmp	x24, x12
	b.ls	.LBB65_61
.LBB65_59:
	ldr	x8, [x21, #24]
	adrp	x16, .L_MergedGlobals
	str	x8, [x20, x24, lsl #3]
	ldr	x8, [x21, #280]
	str	x24, [x21, #24]
	add	x8, x8, #8
	str	x8, [x21, #280]
	ldrb	w16, [x16, :lo12:.L_MergedGlobals]
	cmp	w16, #1
	b.ne	.LBB65_134
// %bb.60:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB65_134
.LBB65_61:
	ldur	x12, [x29, #-192]               // 8-byte Folded Reload
	mov	x26, x25
	and	x8, x13, #0xffffffffff
	mov	x25, x11
	tbnz	x13, #63, .LBB65_95
// %bb.62:
	and	x16, x12, #0xffffffffff
	tbnz	x12, #63, .LBB65_96
.LBB65_63:
	ldur	x14, [x29, #-176]               // 8-byte Folded Reload
	and	x17, x14, #0xffffffffff
	tbnz	x14, #63, .LBB65_97
.LBB65_64:
	mov	x14, x18
	and	x18, x30, #0xffffffffff
	tbz	x30, #63, .LBB65_66
.LBB65_65:
	ldr	x18, [x20, x18, lsl #3]
	lsr	x18, x18, #24
.LBB65_66:
	mov	x24, x10
	cmp	x13, x30
	mov	x4, x18
	str	x25, [sp, #240]                 // 8-byte Folded Spill
	b.eq	.LBB65_69
// %bb.67:
	ldur	x10, [x29, #-176]               // 8-byte Folded Reload
	mov	x4, x17
	cmp	x13, x10
	b.eq	.LBB65_69
// %bb.68:
	cmp	x13, x12
	csel	x4, x16, x8, eq
.LBB65_69:
	ldur	x11, [x29, #-176]               // 8-byte Folded Reload
	str	w19, [sp, #168]
	mov	x0, x20
	str	w2, [sp, #144]
	mov	x1, x21
	mov	x3, x13
	cmp	x12, x11
	str	wzr, [sp, #136]
	ldr	x5, [sp, #208]                  // 8-byte Folded Reload
	csel	x8, x17, x16, eq
	ldp	x16, x7, [sp, #192]             // 16-byte Folded Reload
	stp	x30, x18, [sp, #120]
	cmp	x12, x30
                                        // kill: def $w5 killed $w5 killed $x5
	str	w28, [sp, #96]
	csel	x8, x18, x8, eq
	cmp	x11, x30
	str	w16, [sp, #160]
	csel	x10, x18, x17, eq
	str	w7, [sp, #152]
                                        // kill: def $w7 killed $w7 killed $x7
	str	w26, [sp, #88]
	ldur	x9, [x29, #-200]                // 8-byte Folded Reload
	str	w6, [sp, #64]
	mov	x6, x2
	sub	x2, x29, #160
	str	w24, [sp, #72]
                                        // kill: def $w6 killed $w6 killed $x6
	str	w9, [sp, #80]
	ldr	x9, [sp, #248]                  // 8-byte Folded Reload
	str	w15, [sp, #48]
	str	w9, [sp, #56]
	ldr	x9, [sp, #184]                  // 8-byte Folded Reload
	str	w14, [sp, #40]
	str	w9, [sp, #16]
	str	w19, [sp, #8]
	str	w16, [sp]
	stp	x11, x10, [sp, #104]
	stp	x12, x8, [sp, #24]
	bl	spin_52
	ldur	w8, [x29, #-96]
	ldp	q1, q2, [x29, #-144]
	ldp	x24, x19, [x29, #-40]
	ldur	x13, [x29, #-160]
	stur	x8, [x29, #-176]                // 8-byte Folded Spill
	ldur	w8, [x29, #-88]
	ldur	w15, [x29, #-152]
	ldur	w2, [x29, #-112]
	ldur	x30, [x29, #-104]
	ldur	w0, [x29, #-64]
	stur	x8, [x29, #-192]                // 8-byte Folded Spill
	ldur	w8, [x29, #-80]
	ldur	w7, [x29, #-56]
	ldur	w25, [x29, #-48]
	ldp	x28, x26, [x29, #-24]
	stur	x8, [x29, #-200]                // 8-byte Folded Spill
	ldur	w8, [x29, #-72]
	str	x8, [sp, #248]                  // 8-byte Folded Spill
	tbz	x13, #63, .LBB65_71
// %bb.70:
	and	x8, x13, #0xffffffffff
	ldr	xzr, [x20, x8, lsl #3]
.LBB65_71:
	ldp	x3, x8, [sp, #272]              // 16-byte Folded Reload
	ldur	x10, [x29, #-224]               // 8-byte Folded Reload
	ldp	x1, x18, [sp, #288]             // 16-byte Folded Reload
	ldur	x4, [x29, #-168]                // 8-byte Folded Reload
	ldur	x5, [x29, #-208]                // 8-byte Folded Reload
	ldp	x11, x9, [sp, #312]             // 16-byte Folded Reload
	ldp	x17, x14, [x29, #-256]          // 16-byte Folded Reload
	tbnz	x30, #63, .LBB65_98
// %bb.72:
	ldur	x6, [x29, #-216]                // 8-byte Folded Reload
	ldr	x16, [sp, #304]                 // 8-byte Folded Reload
	tbnz	x19, #63, .LBB65_99
.LBB65_73:
	tbnz	x28, #63, .LBB65_100
.LBB65_74:
	tbnz	x11, #63, .LBB65_101
.LBB65_75:
	tbnz	x9, #63, .LBB65_102
.LBB65_76:
	tbnz	x8, #63, .LBB65_103
.LBB65_77:
	tbnz	x1, #63, .LBB65_104
.LBB65_78:
	tbnz	x3, #63, .LBB65_105
.LBB65_79:
	tbnz	x4, #63, .LBB65_106
.LBB65_80:
	tbnz	x10, #63, .LBB65_107
.LBB65_81:
	tbnz	x5, #63, .LBB65_108
.LBB65_82:
	ldr	x12, [sp, #232]                 // 8-byte Folded Reload
	str	x28, [sp, #296]                 // 8-byte Folded Spill
	str	x19, [sp, #328]                 // 8-byte Folded Spill
	mvn	w12, w12
	tbnz	x14, #63, .LBB65_109
.LBB65_83:
	sub	w14, w24, #1
	stur	x17, [x29, #-256]               // 8-byte Folded Spill
	and	w12, w14, w12
	ldr	x14, [x21, #8]
	lsl	w28, w12, #1
	add	x12, x20, w28, uxtw #3
	add	x19, x12, x17, lsl #3
	ldr	x12, [x19, #8]
	cbz	x14, .LBB65_124
// %bb.84:
	ldr	x17, [x20, x14, lsl #3]
	ldr	x18, [x21, #264]
	str	x17, [x21, #8]
	sub	x17, x18, #2
	str	x17, [x21, #264]
	lsr	x17, x13, #56
	cmp	x17, #2
	b.eq	.LBB65_125
.LBB65_85:
	add	x17, x20, x14, lsl #3
	stp	x13, x15, [x17]
	ldr	x15, [x21, #24]
	cbz	x15, .LBB65_126
.LBB65_86:
	ldr	x13, [x20, x15, lsl #3]
	ldr	x17, [x21, #280]
	str	x13, [x21, #24]
	sub	x13, x17, #8
	str	x13, [x21, #280]
.LBB65_87:
	movi	v0.2d, #0x000000ffffffff
	add	x13, x20, x15, lsl #3
	str	x2, [x13, #32]
	and	v1.16b, v1.16b, v0.16b
	and	v0.16b, v2.16b, v0.16b
	stp	q1, q0, [x13]
	ldr	x13, [x21, #8]
	cbz	x13, .LBB65_127
// %bb.88:
	ldr	x17, [x20, x13, lsl #3]
	ldr	x18, [x21, #264]
	str	x17, [x21, #8]
	sub	x17, x18, #2
	str	x17, [x21, #264]
	mov	x17, #35184372088832            // =0x200000000000
	movk	x17, #512, lsl #48
	orr	x2, x14, x17
	lsr	x14, x2, #56
	cmp	x14, #2
	b.eq	.LBB65_128
.LBB65_89:
	mov	x14, #36283883716608            // =0x210000000000
	movk	x14, #512, lsl #48
	orr	x14, x15, x14
	add	x15, x20, x13, lsl #3
	lsr	x17, x14, #56
	str	x2, [x15]
	cmp	x17, #2
	mov	w17, w24
	str	x17, [sp, #256]                 // 8-byte Folded Spill
	b.eq	.LBB65_129
.LBB65_90:
	mov	w18, #34047                     // =0x84ff
	str	x14, [x15, #8]
	mov	w14, #1                         // =0x1
	orr	w15, w28, #0x1
	movk	w18, #784, lsl #16
	ldr	x24, [sp, #240]                 // 8-byte Folded Reload
	add	x15, x20, w15, uxtw #3
	and	x17, x12, #0xffffffff00
	add	x18, x18, #1
	mov	x28, #34084860461056            // =0x1f0000000000
	str	x14, [x19]
	ldur	x14, [x29, #-256]               // 8-byte Folded Reload
	movk	x28, #512, lsl #48
	cmp	x17, x18
	orr	x13, x13, x28
	str	x13, [x15, x14, lsl #3]
	b.lo	.LBB65_94
// %bb.91:
	cmn	x12, #1
	b.eq	.LBB65_94
// %bb.92:
	and	x13, x12, #0x7e00000000000000
	cbz	x13, .LBB65_94
// %bb.93:
	mov	x28, x0
	mov	x0, x20
	mov	x1, x21
	mov	x2, x12
	mov	x19, x30
	mov	x24, x26
	mov	x26, x25
	mov	x25, x7
	bl	term_drop
	ldp	x6, x5, [x29, #-216]            // 16-byte Folded Reload
	mov	x7, x25
	ldp	x16, x11, [sp, #304]            // 16-byte Folded Reload
	mov	x25, x26
	ldp	x8, x1, [sp, #280]              // 16-byte Folded Reload
	mov	x26, x24
	ldr	x24, [sp, #240]                 // 8-byte Folded Reload
	ldr	x9, [sp, #320]                  // 8-byte Folded Reload
	mov	x0, x28
	ldr	x3, [sp, #272]                  // 8-byte Folded Reload
	ldur	x4, [x29, #-168]                // 8-byte Folded Reload
	mov	x30, x19
	ldur	x10, [x29, #-224]               // 8-byte Folded Reload
.LBB65_94:
	ldr	w12, [x22, #-8]!
	adrp	x13, wl_tab
	add	x13, x13, :lo12:wl_tab
	mov	x28, x9
	ldr	x2, [x13, x12, lsl #3]
	ldr	x13, [sp, #296]                 // 8-byte Folded Reload
	ldur	x12, [x29, #-248]               // 8-byte Folded Reload
	str	x5, [x29, #64]
	ldp	x9, x14, [x29, #-200]           // 16-byte Folded Reload
	stp	x12, x13, [x29, #72]
	mov	w5, w16
	ldr	x12, [sp, #328]                 // 8-byte Folded Reload
	str	x12, [x29, #56]
	ldr	x12, [sp, #256]                 // 8-byte Folded Reload
	stp	x0, x7, [x29, #16]
	mov	w7, w24
	mov	w24, #28                        // =0x1c
	mov	x0, x8
	stp	x25, x12, [x29, #40]
	ldp	x13, x12, [x29, #-240]          // 16-byte Folded Reload
	mov	w25, w27
	mov	x27, x11
	mov	w11, #1                         // =0x1
	add	w17, w26, w13
	mov	w26, w12
	ldp	x12, x13, [x29, #-184]          // 16-byte Folded Reload
	mov	w12, w12
	str	x12, [x29, #32]
	mov	x12, x30
	ldr	x15, [sp, #248]                 // 8-byte Folded Reload
	str	x17, [x29, #88]
	add	sp, sp, #592
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	br	x2
.LBB65_95:
	.cfi_restore_state
	.cfi_remember_state
	ldr	x8, [x20, x8, lsl #3]
	lsr	x8, x8, #24
	and	x16, x12, #0xffffffffff
	tbz	x12, #63, .LBB65_63
.LBB65_96:
	ldr	x16, [x20, x16, lsl #3]
	lsr	x16, x16, #24
	ldur	x14, [x29, #-176]               // 8-byte Folded Reload
	and	x17, x14, #0xffffffffff
	tbz	x14, #63, .LBB65_64
.LBB65_97:
	ldr	x17, [x20, x17, lsl #3]
	mov	x14, x18
	lsr	x17, x17, #24
	and	x18, x30, #0xffffffffff
	tbz	x30, #63, .LBB65_66
	b	.LBB65_65
.LBB65_98:
	and	x12, x30, #0xffffffffff
	ldr	xzr, [x20, x12, lsl #3]
	ldur	x6, [x29, #-216]                // 8-byte Folded Reload
	ldr	x16, [sp, #304]                 // 8-byte Folded Reload
	tbz	x19, #63, .LBB65_73
.LBB65_99:
	and	x12, x19, #0xffffffffff
	ldr	xzr, [x20, x12, lsl #3]
	tbz	x28, #63, .LBB65_74
.LBB65_100:
	and	x12, x28, #0xffffffffff
	ldr	xzr, [x20, x12, lsl #3]
	tbz	x11, #63, .LBB65_75
.LBB65_101:
	ldr	x12, [x20, x17, lsl #3]
	lsr	x17, x12, #24
	tbz	x9, #63, .LBB65_76
.LBB65_102:
	and	x12, x9, #0xffffffffff
	ldr	xzr, [x20, x12, lsl #3]
	tbz	x8, #63, .LBB65_77
.LBB65_103:
	ldr	xzr, [x20, x18, lsl #3]
	tbz	x1, #63, .LBB65_78
.LBB65_104:
	ldr	x12, [sp, #328]                 // 8-byte Folded Reload
	ldr	xzr, [x20, x12, lsl #3]
	tbz	x3, #63, .LBB65_79
.LBB65_105:
	ldr	x12, [sp, #176]                 // 8-byte Folded Reload
	ldr	xzr, [x20, x12, lsl #3]
	tbz	x4, #63, .LBB65_80
.LBB65_106:
	ldr	x12, [sp, #256]                 // 8-byte Folded Reload
	ldr	xzr, [x20, x12, lsl #3]
	tbz	x10, #63, .LBB65_81
.LBB65_107:
	and	x12, x10, #0xffffffffff
	ldr	xzr, [x20, x12, lsl #3]
	tbz	x5, #63, .LBB65_82
.LBB65_108:
	and	x12, x5, #0xffffffffff
	ldr	xzr, [x20, x12, lsl #3]
	ldr	x12, [sp, #232]                 // 8-byte Folded Reload
	str	x28, [sp, #296]                 // 8-byte Folded Spill
	str	x19, [sp, #328]                 // 8-byte Folded Spill
	mvn	w12, w12
	tbz	x14, #63, .LBB65_83
.LBB65_109:
	and	x14, x14, #0xffffffffff
	ldr	xzr, [x20, x14, lsl #3]
	b	.LBB65_83
.LBB65_110:
	ldp	x13, x19, [x22, #-24]
	mov	x28, x18
	ldr	x8, [x21, #40]
	mov	x23, x10
	stur	x9, [x29, #-208]                // 8-byte Folded Spill
	cbz	x8, .LBB65_138
// %bb.111:
	ldr	x16, [x20, x8, lsl #3]
	ldr	x17, [x21, #296]
	str	x16, [x21, #40]
	sub	x16, x17, #32
	str	x16, [x21, #296]
.LBB65_112:
	mov	w17, #1                         // =0x1
	add	x16, x20, x8, lsl #3
	movi	v0.2d, #0xffffffffffffffff
	orr	x18, x17, x19, lsl #32
	ldur	x10, [x29, #-240]               // 8-byte Folded Reload
	stp	x13, x18, [x16, #232]
	mov	x18, #49478023249920            // =0x2d0000000000
	mov	w13, w10
	movk	x18, #1280, lsl #48
	str	x13, [x16]
	orr	x13, x8, x18
	stur	q0, [x16, #216]
	stur	q0, [x16, #200]
	stur	q0, [x16, #184]
	stur	q0, [x16, #168]
	stur	q0, [x16, #152]
	stur	q0, [x16, #136]
	stur	q0, [x16, #120]
	stur	q0, [x16, #104]
	stur	q0, [x16, #88]
	stur	q0, [x16, #72]
	stur	q0, [x16, #56]
	stur	q0, [x16, #40]
	stur	q0, [x16, #24]
	stur	q0, [x16, #8]
	stp	x13, x17, [x22, #-24]
	ldr	x8, [x21, #40]
	cbz	x8, .LBB65_139
// %bb.113:
	ldr	x16, [x20, x8, lsl #3]
	ldr	x17, [x21, #296]
	str	x16, [x21, #40]
	sub	x16, x17, #32
	str	x16, [x21, #296]
	ldur	x21, [x29, #-184]               // 8-byte Folded Reload
.LBB65_114:
	add	x16, x20, x8, lsl #3
	mov	x17, #4294967296                // =0x100000000
	ldur	x10, [x29, #-216]               // 8-byte Folded Reload
	ldur	x9, [x29, #-168]                // 8-byte Folded Reload
	mov	w19, #1                         // =0x1
	stp	x13, x17, [x16, #216]
	ldur	x17, [x29, #-232]               // 8-byte Folded Reload
	mov	w13, w27
	stp	x0, x1, [x16, #16]
	mov	w17, w17
	stp	x3, x4, [x16, #32]
	stp	x13, x17, [x16]
	mov	w13, w7
	stp	x13, x10, [x16, #64]
	mov	w10, w11
	str	x10, [x16, #80]
	ldur	x10, [x29, #-224]               // 8-byte Folded Reload
	stp	x5, x9, [x16, #48]
	mov	x9, x28
	b	.LBB65_120
.LBB65_115:
	ldp	x13, x19, [x22, #-24]
	mov	x23, x10
	ldr	x8, [x21, #40]
	ldur	x2, [x29, #-248]                // 8-byte Folded Reload
	mov	x28, x11
	mov	x12, x18
	stur	x9, [x29, #-208]                // 8-byte Folded Spill
	cbz	x8, .LBB65_143
// %bb.116:
	ldr	x16, [x20, x8, lsl #3]
	ldr	x17, [x21, #296]
	str	x16, [x21, #40]
	sub	x16, x17, #32
	str	x16, [x21, #296]
.LBB65_117:
	mov	w17, #1                         // =0x1
	add	x16, x20, x8, lsl #3
	movi	v0.2d, #0xffffffffffffffff
	orr	x18, x17, x19, lsl #32
	ldur	x10, [x29, #-240]               // 8-byte Folded Reload
	stp	x13, x18, [x16, #232]
	mov	x18, #50577534877696            // =0x2e0000000000
	mov	w13, w10
	movk	x18, #1280, lsl #48
	str	x13, [x16]
	orr	x13, x8, x18
	stur	q0, [x16, #216]
	stur	q0, [x16, #200]
	stur	q0, [x16, #184]
	stur	q0, [x16, #168]
	stur	q0, [x16, #152]
	stur	q0, [x16, #136]
	stur	q0, [x16, #120]
	stur	q0, [x16, #104]
	stur	q0, [x16, #88]
	stur	q0, [x16, #72]
	stur	q0, [x16, #56]
	stur	q0, [x16, #40]
	stur	q0, [x16, #24]
	stur	q0, [x16, #8]
	stp	x13, x17, [x22, #-24]
	ldr	x8, [x21, #40]
	cbz	x8, .LBB65_144
// %bb.118:
	ldr	x16, [x20, x8, lsl #3]
	ldr	x17, [x21, #296]
	str	x16, [x21, #40]
	sub	x16, x17, #32
	str	x16, [x21, #296]
	ldur	x21, [x29, #-184]               // 8-byte Folded Reload
.LBB65_119:
	add	x16, x20, x8, lsl #3
	mov	x17, #4294967296                // =0x100000000
	ldur	x10, [x29, #-216]               // 8-byte Folded Reload
	ldur	x9, [x29, #-168]                // 8-byte Folded Reload
	mov	w19, #1                         // =0x1
	stp	x13, x17, [x16, #216]
	ldur	x17, [x29, #-232]               // 8-byte Folded Reload
	mov	w13, w27
	stp	x0, x1, [x16, #16]
	mov	w17, w17
	stp	x3, x4, [x16, #32]
	stp	x13, x17, [x16]
	mov	w13, w7
	stp	x13, x10, [x16, #64]
	mov	w10, w28
	str	x10, [x16, #80]
	ldur	x10, [x29, #-224]               // 8-byte Folded Reload
	stp	x5, x9, [x16, #48]
	mov	x9, x12
.LBB65_120:
	str	x10, [x16, #88]
.LBB65_121:
	ldur	x10, [x29, #-192]               // 8-byte Folded Reload
	mov	w9, w9
	ldur	x11, [x29, #-176]               // 8-byte Folded Reload
	stp	x2, x30, [x16, #200]
	stp	x19, x10, [x16, #96]
	mov	w10, w15
	stp	x9, x10, [x16, #112]
	mov	w9, w24
	mov	w10, w6
	stp	x9, x10, [x16, #128]
	ldur	x10, [x29, #-200]               // 8-byte Folded Reload
	mov	w9, w23
	mov	w10, w10
	stp	x9, x10, [x16, #144]
	mov	w9, w21
	mov	w10, w25
	stp	x9, x10, [x16, #160]
	mov	w9, w26
	ldur	x10, [x29, #-208]               // 8-byte Folded Reload
	str	x9, [x16, #176]
	mov	x9, #35184372088832             // =0x200000000000
	movk	x9, #1280, lsl #48
	stp	x11, x10, [x16, #184]
	orr	x0, x8, x9
	add	sp, sp, #592
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB65_122:
	.cfi_restore_state
	stp	x0, x1, [sp, #312]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	stur	x2, [x29, #-248]                // 8-byte Folded Spill
	mov	w2, #5                          // =0x5
	str	x24, [sp, #248]                 // 8-byte Folded Spill
	mov	x24, x5
	stp	x3, x4, [sp, #280]              // 16-byte Folded Spill
	str	x7, [sp, #304]                  // 8-byte Folded Spill
	stur	x6, [x29, #-232]                // 8-byte Folded Spill
	bl	heap_alloc_miss
	ldp	x3, x4, [sp, #280]              // 16-byte Folded Reload
	mov	x8, x0
	ldp	x7, x0, [sp, #304]              // 16-byte Folded Reload
	mov	x5, x24
	ldur	x6, [x29, #-232]                // 8-byte Folded Reload
	ldur	x2, [x29, #-248]                // 8-byte Folded Reload
	ldr	x1, [sp, #320]                  // 8-byte Folded Reload
	ldr	x24, [sp, #248]                 // 8-byte Folded Reload
	b	.LBB65_20
.LBB65_123:
	stp	x0, x1, [sp, #312]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	stur	x2, [x29, #-248]                // 8-byte Folded Spill
	mov	w2, #5                          // =0x5
	mov	x23, x14
	str	x5, [sp, #272]                  // 8-byte Folded Spill
	mov	x21, x3
	str	x4, [sp, #288]                  // 8-byte Folded Spill
	str	x7, [sp, #304]                  // 8-byte Folded Spill
	str	x24, [sp, #248]                 // 8-byte Folded Spill
	mov	x24, x6
	bl	heap_alloc_miss
	mov	x8, x0
	ldp	x7, x0, [sp, #304]              // 16-byte Folded Reload
	mov	x6, x24
	ldr	x24, [sp, #248]                 // 8-byte Folded Reload
	ldur	x2, [x29, #-248]                // 8-byte Folded Reload
	ldr	x1, [sp, #320]                  // 8-byte Folded Reload
	mov	x3, x21
	ldr	x4, [sp, #288]                  // 8-byte Folded Reload
	ldur	x21, [x29, #-184]               // 8-byte Folded Reload
	ldr	x5, [sp, #272]                  // 8-byte Folded Reload
	b	.LBB65_22
.LBB65_124:
	str	x0, [sp, #232]                  // 8-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	str	x2, [sp, #200]                  // 8-byte Folded Spill
	mov	w2, #1                          // =0x1
	mov	x9, x6
	mov	x11, x30
	mov	x14, x7
	str	q2, [sp, #256]                  // 16-byte Folded Spill
	str	q1, [sp, #208]                  // 16-byte Folded Spill
	bl	heap_alloc_miss
	mov	x30, x11
	ldp	x16, x11, [sp, #304]            // 16-byte Folded Reload
	ldp	x8, x1, [sp, #280]              // 16-byte Folded Reload
	mov	x7, x14
	ldr	q1, [sp, #208]                  // 16-byte Folded Reload
	ldr	q2, [sp, #256]                  // 16-byte Folded Reload
	mov	x6, x9
	ldr	x2, [sp, #200]                  // 8-byte Folded Reload
	ldur	x5, [x29, #-208]                // 8-byte Folded Reload
	mov	x14, x0
	ldr	x9, [sp, #320]                  // 8-byte Folded Reload
	ldr	x3, [sp, #272]                  // 8-byte Folded Reload
	ldur	x4, [x29, #-168]                // 8-byte Folded Reload
	ldr	x0, [sp, #232]                  // 8-byte Folded Reload
	lsr	x17, x13, #56
	cmp	x17, #2
	b.ne	.LBB65_85
.LBB65_125:
	str	x0, [sp, #232]                  // 8-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	str	x2, [sp, #200]                  // 8-byte Folded Spill
	mov	x2, x13
	mov	w3, #1                          // =0x1
	mov	x9, x6
	mov	x11, x30
	mov	x13, x7
	str	q2, [sp, #256]                  // 16-byte Folded Spill
	str	q1, [sp, #208]                  // 16-byte Folded Spill
	bl	rfc_wrap
	mov	x30, x11
	ldp	x16, x11, [sp, #304]            // 16-byte Folded Reload
	ldp	x8, x1, [sp, #280]              // 16-byte Folded Reload
	mov	x7, x13
	ldr	q1, [sp, #208]                  // 16-byte Folded Reload
	ldr	q2, [sp, #256]                  // 16-byte Folded Reload
	mov	x6, x9
	ldr	x2, [sp, #200]                  // 8-byte Folded Reload
	ldur	x5, [x29, #-208]                // 8-byte Folded Reload
	mov	x13, x0
	ldr	x9, [sp, #320]                  // 8-byte Folded Reload
	ldr	x3, [sp, #272]                  // 8-byte Folded Reload
	ldur	x4, [x29, #-168]                // 8-byte Folded Reload
	ldr	x0, [sp, #232]                  // 8-byte Folded Reload
	add	x17, x20, x14, lsl #3
	stp	x13, x15, [x17]
	ldr	x15, [x21, #24]
	cbnz	x15, .LBB65_86
.LBB65_126:
	str	x0, [sp, #232]                  // 8-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	mov	x13, x2
	mov	w2, #3                          // =0x3
	mov	x9, x6
	mov	x11, x30
	mov	x15, x7
	str	q2, [sp, #256]                  // 16-byte Folded Spill
	str	q1, [sp, #208]                  // 16-byte Folded Spill
	bl	heap_alloc_miss
	mov	x30, x11
	ldp	x16, x11, [sp, #304]            // 16-byte Folded Reload
	ldp	x8, x1, [sp, #280]              // 16-byte Folded Reload
	mov	x7, x15
	ldr	q1, [sp, #208]                  // 16-byte Folded Reload
	ldr	q2, [sp, #256]                  // 16-byte Folded Reload
	mov	x6, x9
	ldur	x5, [x29, #-208]                // 8-byte Folded Reload
	ldr	x9, [sp, #320]                  // 8-byte Folded Reload
	mov	x15, x0
	ldr	x3, [sp, #272]                  // 8-byte Folded Reload
	ldur	x4, [x29, #-168]                // 8-byte Folded Reload
	mov	x2, x13
	ldr	x0, [sp, #232]                  // 8-byte Folded Reload
	b	.LBB65_87
.LBB65_127:
	str	x0, [sp, #232]                  // 8-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	mov	w2, #1                          // =0x1
	mov	x9, x6
	mov	x11, x30
	mov	x13, x7
	bl	heap_alloc_miss
	mov	x30, x11
	ldp	x16, x11, [sp, #304]            // 16-byte Folded Reload
	ldp	x8, x1, [sp, #280]              // 16-byte Folded Reload
	mov	x7, x13
	ldur	x5, [x29, #-208]                // 8-byte Folded Reload
	mov	x6, x9
	ldr	x9, [sp, #320]                  // 8-byte Folded Reload
	ldr	x3, [sp, #272]                  // 8-byte Folded Reload
	ldur	x4, [x29, #-168]                // 8-byte Folded Reload
	mov	x13, x0
	ldr	x0, [sp, #232]                  // 8-byte Folded Reload
	mov	x17, #35184372088832            // =0x200000000000
	movk	x17, #512, lsl #48
	orr	x2, x14, x17
	lsr	x14, x2, #56
	cmp	x14, #2
	b.ne	.LBB65_89
.LBB65_128:
	str	x0, [sp, #232]                  // 8-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	mov	w3, #1                          // =0x1
	mov	x9, x6
	mov	x11, x30
	mov	x14, x26
	mov	x26, x25
	mov	x25, x7
	bl	rfc_wrap
	mov	x30, x11
	ldp	x16, x11, [sp, #304]            // 16-byte Folded Reload
	ldp	x8, x1, [sp, #280]              // 16-byte Folded Reload
	mov	x6, x9
	ldur	x5, [x29, #-208]                // 8-byte Folded Reload
	ldr	x9, [sp, #320]                  // 8-byte Folded Reload
	mov	x2, x0
	ldr	x3, [sp, #272]                  // 8-byte Folded Reload
	ldur	x4, [x29, #-168]                // 8-byte Folded Reload
	mov	x7, x25
	ldr	x0, [sp, #232]                  // 8-byte Folded Reload
	mov	x25, x26
	mov	x26, x14
	b	.LBB65_89
.LBB65_129:
	str	x0, [sp, #232]                  // 8-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	mov	x2, x14
	mov	w3, #1                          // =0x1
	mov	x9, x6
	mov	x11, x30
	mov	x14, x7
	bl	rfc_wrap
	mov	x30, x11
	ldp	x16, x11, [sp, #304]            // 16-byte Folded Reload
	ldp	x8, x1, [sp, #280]              // 16-byte Folded Reload
	mov	x7, x14
	ldur	x5, [x29, #-208]                // 8-byte Folded Reload
	mov	x6, x9
	ldr	x9, [sp, #320]                  // 8-byte Folded Reload
	ldr	x3, [sp, #272]                  // 8-byte Folded Reload
	ldur	x4, [x29, #-168]                // 8-byte Folded Reload
	mov	x14, x0
	ldr	x0, [sp, #232]                  // 8-byte Folded Reload
	b	.LBB65_90
.LBB65_130:
	stp	x0, x1, [sp, #312]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	stur	x2, [x29, #-248]                // 8-byte Folded Spill
	mov	w2, #5                          // =0x5
	mov	x14, x6
	str	x24, [sp, #248]                 // 8-byte Folded Spill
	mov	x24, x5
	stp	x3, x4, [sp, #280]              // 16-byte Folded Spill
	str	x7, [sp, #304]                  // 8-byte Folded Spill
	stur	x30, [x29, #-240]               // 8-byte Folded Spill
	bl	heap_alloc_miss
	ldp	x2, x30, [x29, #-248]           // 16-byte Folded Reload
	mov	x8, x0
	ldp	x3, x4, [sp, #280]              // 16-byte Folded Reload
	mov	x5, x24
	ldp	x7, x0, [sp, #304]              // 16-byte Folded Reload
	mov	x6, x14
	ldr	x1, [sp, #320]                  // 8-byte Folded Reload
	ldr	x24, [sp, #248]                 // 8-byte Folded Reload
	b	.LBB65_31
.LBB65_131:
	ldur	x23, [x29, #-224]               // 8-byte Folded Reload
	stp	x0, x1, [sp, #312]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	stur	x2, [x29, #-248]                // 8-byte Folded Spill
	mov	w2, #5                          // =0x5
	str	x5, [sp, #272]                  // 8-byte Folded Spill
	mov	x21, x3
	mov	x14, x6
	str	x24, [sp, #248]                 // 8-byte Folded Spill
	mov	x24, x4
	str	x7, [sp, #304]                  // 8-byte Folded Spill
	stur	x30, [x29, #-240]               // 8-byte Folded Spill
	bl	heap_alloc_miss
	ldp	x2, x30, [x29, #-248]           // 16-byte Folded Reload
	mov	x8, x0
	ldp	x7, x0, [sp, #304]              // 16-byte Folded Reload
	mov	x3, x21
	ldr	x1, [sp, #320]                  // 8-byte Folded Reload
	mov	x4, x24
	ldr	x24, [sp, #248]                 // 8-byte Folded Reload
	ldur	x21, [x29, #-184]               // 8-byte Folded Reload
	ldr	x5, [sp, #272]                  // 8-byte Folded Reload
	mov	x6, x14
	b	.LBB65_33
.LBB65_132:
	mov	x0, x20
	mov	x1, x21
	mov	x12, x2
	mov	w2, #1                          // =0x1
	mov	x13, x5
	mov	x9, x30
	mov	x14, x6
	mov	x28, x26
	mov	x26, x25
	mov	x25, x11
	mov	x11, x27
	mov	x27, x18
	bl	heap_hand
	mov	x2, x12
	mov	w12, #34047                     // =0x84ff
	mov	x18, x27
	mov	x27, x11
	mov	x11, x25
	mov	x25, x26
	mov	x26, x28
	mov	x6, x14
	mov	x30, x9
	movk	w12, #784, lsl #16
	mov	x5, x13
	b	.LBB65_43
.LBB65_133:
	mov	x0, x20
	mov	x1, x21
	mov	x12, x2
	mov	w2, #1                          // =0x1
	mov	x19, x5
	mov	x9, x30
	mov	x14, x6
	mov	x28, x26
	mov	x26, x25
	mov	x25, x11
	mov	x11, x27
	mov	x27, x18
	bl	heap_hand
	mov	x2, x12
	mov	w12, #34047                     // =0x84ff
	mov	x18, x27
	mov	x27, x11
	mov	x11, x25
	mov	x25, x26
	mov	x26, x28
	mov	x6, x14
	mov	x30, x9
	movk	w12, #784, lsl #16
	mov	x5, x19
	b	.LBB65_51
.LBB65_134:
	mov	x0, x20
	mov	x1, x21
	mov	x12, x2
	mov	w2, #3                          // =0x3
	mov	x9, x30
	mov	x14, x6
	mov	x26, x25
	mov	x25, x11
	mov	x11, x27
	mov	x27, x18
	bl	heap_hand
	mov	x2, x12
	mov	x18, x27
	mov	x27, x11
	mov	x11, x25
	mov	x25, x26
	mov	x6, x14
	mov	x30, x9
	b	.LBB65_61
.LBB65_135:
	orr	x8, x17, x13, lsl #32
	mov	x0, x20
	mov	x1, x21
	mov	w4, #2                          // =0x2
	mov	x9, x30
	mov	x14, x6
	lsr	x8, x8, #24
	add	x13, x20, x8, lsl #3
	mov	x3, x8
	ldp	x24, x12, [x13]
	mov	x13, x5
	bl	span_fade
	mov	x2, x12
	mov	w12, #34047                     // =0x84ff
	mov	x6, x14
	mov	x30, x9
	mov	x5, x13
	mov	x18, x27
	mov	x27, x11
	mov	x11, x25
	mov	x25, x26
	mov	x26, x28
	movk	w12, #784, lsl #16
	b	.LBB65_43
.LBB65_136:
	orr	x8, x17, x13, lsl #32
	mov	x0, x20
	mov	x1, x21
	mov	x2, x24
	mov	w4, #2                          // =0x2
	mov	x19, x5
	lsr	x8, x8, #24
	mov	x9, x30
	mov	x14, x6
	add	x16, x20, x8, lsl #3
	mov	x3, x8
	ldp	x13, x12, [x16]
	str	x12, [sp, #208]                 // 8-byte Folded Spill
	bl	span_fade
	mov	w12, #34047                     // =0x84ff
	ldr	x2, [sp, #240]                  // 8-byte Folded Reload
	mov	x6, x14
	mov	x30, x9
	movk	w12, #784, lsl #16
	mov	x5, x19
	mov	x18, x27
	mov	x27, x11
	mov	x11, x25
	mov	x25, x26
	mov	x26, x28
	b	.LBB65_51
.LBB65_137:
	mov	x0, x20
	mov	x1, x21
	mov	x3, x24
	mov	w4, #5                          // =0x5
	mov	x9, x30
	mov	x12, x6
	bl	span_fade
	mov	x6, x12
	mov	x30, x9
	mov	x18, x27
	mov	x27, x11
	mov	x11, x25
	mov	x25, x26
	mov	x2, x14
	b	.LBB65_61
.LBB65_138:
	stp	x0, x1, [sp, #312]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	stur	x2, [x29, #-248]                // 8-byte Folded Spill
	mov	w2, #5                          // =0x5
	mov	x10, x5
	str	x4, [sp, #288]                  // 8-byte Folded Spill
	mov	x9, x30
	mov	x14, x6
	str	x24, [sp, #248]                 // 8-byte Folded Spill
	mov	x24, x3
	str	x7, [sp, #304]                  // 8-byte Folded Spill
	bl	heap_alloc_miss
	mov	x8, x0
	ldp	x7, x0, [sp, #304]              // 16-byte Folded Reload
	ldur	x2, [x29, #-248]                // 8-byte Folded Reload
	ldr	x1, [sp, #320]                  // 8-byte Folded Reload
	mov	x3, x24
	ldr	x24, [sp, #248]                 // 8-byte Folded Reload
	ldr	x4, [sp, #288]                  // 8-byte Folded Reload
	mov	x6, x14
	mov	x30, x9
	mov	x5, x10
	b	.LBB65_112
.LBB65_139:
	stp	x0, x1, [sp, #312]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	stur	x2, [x29, #-248]                // 8-byte Folded Spill
	mov	w2, #5                          // =0x5
	mov	x19, x5
	str	x4, [sp, #288]                  // 8-byte Folded Spill
	mov	x10, x3
	mov	x9, x30
	str	x24, [sp, #248]                 // 8-byte Folded Spill
	mov	x24, x7
	mov	x14, x6
	bl	heap_alloc_miss
	mov	x8, x0
	ldp	x0, x1, [sp, #312]              // 16-byte Folded Reload
	ldur	x2, [x29, #-248]                // 8-byte Folded Reload
	mov	x7, x24
	ldr	x24, [sp, #248]                 // 8-byte Folded Reload
	ldur	x21, [x29, #-184]               // 8-byte Folded Reload
	ldr	x4, [sp, #288]                  // 8-byte Folded Reload
	mov	x6, x14
	mov	x30, x9
	mov	x3, x10
	mov	x5, x19
	b	.LBB65_114
.LBB65_140:
	mov	x0, x20
	mov	x1, x21
	mov	x12, x2
	mov	w2, wzr
	mov	x19, x5
	mov	x9, x30
	mov	x14, x6
	bl	heap_hand
	mov	x2, x12
	mov	x6, x14
	mov	x30, x9
	mov	x5, x19
	b	.LBB65_40
.LBB65_141:
	mov	x0, x20
	mov	x1, x21
	mov	w2, wzr
	mov	x24, x5
	mov	x9, x30
	mov	x14, x6
	bl	heap_hand
	mov	w12, #34047                     // =0x84ff
	mov	x6, x14
	mov	x30, x9
	movk	w12, #784, lsl #16
	mov	x5, x24
	b	.LBB65_48
.LBB65_142:
	mov	x0, x20
	mov	x1, x21
	mov	w2, wzr
	mov	x9, x30
	mov	x12, x6
	bl	heap_hand
	mov	x6, x12
	mov	w12, #34047                     // =0x84ff
	mov	x30, x9
	movk	w12, #784, lsl #16
	b	.LBB65_58
.LBB65_143:
	stp	x0, x1, [sp, #312]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	mov	w2, #5                          // =0x5
	mov	x11, x5
	str	x4, [sp, #288]                  // 8-byte Folded Spill
	str	x24, [sp, #248]                 // 8-byte Folded Spill
	mov	x24, x3
	mov	x9, x30
	str	x7, [sp, #304]                  // 8-byte Folded Spill
	mov	x14, x6
	bl	heap_alloc_miss
	mov	x8, x0
	ldp	x7, x0, [sp, #304]              // 16-byte Folded Reload
	ldur	x2, [x29, #-248]                // 8-byte Folded Reload
	ldr	x1, [sp, #320]                  // 8-byte Folded Reload
	mov	x3, x24
	ldr	x24, [sp, #248]                 // 8-byte Folded Reload
	ldr	x4, [sp, #288]                  // 8-byte Folded Reload
	mov	x6, x14
	mov	x30, x9
	mov	x5, x11
	b	.LBB65_117
.LBB65_144:
	stp	x0, x1, [sp, #312]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	mov	w2, #5                          // =0x5
	mov	x19, x5
	str	x4, [sp, #288]                  // 8-byte Folded Spill
	mov	x10, x3
	str	x24, [sp, #248]                 // 8-byte Folded Spill
	mov	x24, x7
	mov	x9, x30
	mov	x14, x6
	bl	heap_alloc_miss
	mov	x8, x0
	ldp	x0, x1, [sp, #312]              // 16-byte Folded Reload
	ldur	x2, [x29, #-248]                // 8-byte Folded Reload
	mov	x7, x24
	ldr	x24, [sp, #248]                 // 8-byte Folded Reload
	ldur	x21, [x29, #-184]               // 8-byte Folded Reload
	ldr	x4, [sp, #288]                  // 8-byte Folded Reload
	mov	x6, x14
	mov	x30, x9
	mov	x3, x10
	mov	x5, x19
	b	.LBB65_119
.Lfunc_end65:
