WL_FID____BENDVY_QUERY_FROZEN_PROVIDER_NATIVE_V3_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_MOTION_ROW_0: // @WL_FID____BENDVY_QUERY_FROZEN_PROVIDER_NATIVE_V3_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_MOTION_ROW_0
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	sub	sp, sp, #688
	mov	x2, x14
	ldp	x24, x14, [x29, #40]
	stur	x15, [x29, #-208]               // 8-byte Folded Spill
	ldp	x18, x15, [x29, #72]
	stur	x12, [x29, #-192]               // 8-byte Folded Spill
	ldr	x17, [x29, #16]
	ldp	x16, x30, [x29, #56]
	cmp	w25, w24
	ldp	x8, x12, [x29, #24]
	stur	x8, [x29, #-200]                // 8-byte Folded Spill
	b.ne	.LBB71_9
// %bb.1:
	mov	w11, w11
	cmp	x11, #1
	b.ne	.LBB71_11
// %bb.2:
	and	x8, x27, #0xffffffffff
	tbnz	x27, #63, .LBB71_17
// %bb.3:
	tbnz	x28, #63, .LBB71_18
.LBB71_4:
	and	x11, x0, #0xffffffffff
	stur	x10, [x29, #-232]               // 8-byte Folded Spill
	tbnz	x0, #63, .LBB71_19
.LBB71_5:
	mov	x19, x13
	tbnz	x1, #63, .LBB71_20
.LBB71_6:
	tbnz	x3, #63, .LBB71_21
.LBB71_7:
	tbnz	x4, #63, .LBB71_22
.LBB71_8:
	cmp	w14, w7
	b.ls	.LBB71_23
	b	.LBB71_36
.LBB71_9:
	cbz	w23, .LBB71_14
// %bb.10:
	mov	w25, w25
	stp	x18, x15, [x29, #72]
	mov	w26, w26
	mov	w5, w5
	mov	w7, w7
	mov	w11, w11
	b	.LBB71_13
.LBB71_11:
	cbz	w23, .LBB71_38
// %bb.12:
	mov	w25, w25
	mov	w26, w26
	mov	w5, w5
	mov	w7, w7
	stp	x18, x15, [x29, #72]
.LBB71_13:
	stp	x16, x30, [x29, #56]
	mov	w8, w14
	mov	w16, w24
	stp	x16, x8, [x29, #40]
	ldp	x15, x16, [x29, #-208]          // 16-byte Folded Reload
	mov	w8, w12
	mov	w13, w13
	mov	w14, w2
	mov	w9, w9
	mov	w16, w16
	mov	w15, w15
	stp	x16, x8, [x29, #24]
	mov	w8, w17
	ldur	x12, [x29, #-192]               // 8-byte Folded Reload
	str	x8, [x29, #16]
	add	sp, sp, #688
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	WL_FID____BENDVY_QUERY_FROZEN_PROVIDER_NATIVE_V3_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_1
.LBB71_14:
	.cfi_restore_state
	.cfi_remember_state
	stp	x15, x16, [x29, #-224]          // 16-byte Folded Spill
	mov	x15, x14
	mov	x19, x13
	ldp	x14, x13, [x22, #-24]
	ldr	x8, [x21, #40]
	mov	x23, x17
	cbz	x8, .LBB71_92
// %bb.15:
	ldr	x16, [x20, x8, lsl #3]
	ldr	x17, [x21, #296]
	mov	x22, x20
	str	x16, [x21, #40]
	sub	x16, x17, #32
	str	x16, [x21, #296]
.LBB71_16:
	add	x16, x22, x8, lsl #3
	lsl	x13, x13, #32
	mov	w11, w11
	b	.LBB71_41
.LBB71_17:
	ldr	x8, [x20, x8, lsl #3]
	lsr	x8, x8, #24
	tbz	x28, #63, .LBB71_4
.LBB71_18:
	and	x11, x28, #0xffffffffff
	ldr	xzr, [x20, x11, lsl #3]
	and	x11, x0, #0xffffffffff
	stur	x10, [x29, #-232]               // 8-byte Folded Spill
	tbz	x0, #63, .LBB71_5
.LBB71_19:
	ldr	x11, [x20, x11, lsl #3]
	lsr	x11, x11, #24
	mov	x19, x13
	tbz	x1, #63, .LBB71_6
.LBB71_20:
	and	x13, x1, #0xffffffffff
	ldr	xzr, [x20, x13, lsl #3]
	tbz	x3, #63, .LBB71_7
.LBB71_21:
	and	x13, x3, #0xffffffffff
	ldr	xzr, [x20, x13, lsl #3]
	tbz	x4, #63, .LBB71_8
.LBB71_22:
	and	x13, x4, #0xffffffffff
	ldr	xzr, [x20, x13, lsl #3]
	cmp	w14, w7
	b.hi	.LBB71_36
.LBB71_23:
	sub	w13, w14, #1
	cmp	w13, w5
	b.hs	.LBB71_36
// %bb.24:
	lsr	x13, x0, #40
	stp	x14, x16, [x29, #-224]          // 16-byte Folded Spill
	mov	w14, #-1                        // =0xffffffff
	ldur	x10, [x29, #-224]               // 8-byte Folded Reload
	mov	w16, #2147483647                // =0x7fffffff
	add	x11, x20, x11, lsl #3
	lsl	w14, w14, w13
	add	w13, w10, w16
	bic	w14, w13, w14
	ldr	w11, [x11, w14, uxtw #2]
	ldp	x14, x16, [x29, #-224]          // 16-byte Folded Reload
	cbz	w11, .LBB71_36
// %bb.25:
	ubfx	x11, x27, #40, #5
	mov	x14, #-1                        // =0xffffffffffffffff
	stur	x2, [x29, #-240]                // 8-byte Folded Spill
	str	x18, [sp, #424]                 // 8-byte Folded Spill
	sub	w11, w11, #1
	stur	w23, [x29, #-256]               // 4-byte Folded Spill
	lsl	x11, x14, x11
	stur	x22, [x29, #-248]               // 8-byte Folded Spill
	bic	w11, w13, w11
	lsl	w11, w11, #1
	add	x11, x20, w11, uxtw #3
	add	x11, x11, x8, lsl #3
	ldr	x2, [x11, #8]
	ldr	w8, [x11]
	stp	xzr, xzr, [x11]
	tbz	x2, #63, .LBB71_33
// %bb.26:
	cmp	x2, x27
	b.eq	.LBB71_33
// %bb.27:
	cmp	x2, x28
	b.eq	.LBB71_33
// %bb.28:
	cmp	x2, x0
	b.eq	.LBB71_33
// %bb.29:
	cmp	x2, x1
	b.eq	.LBB71_33
// %bb.30:
	cmp	x2, x4
	b.eq	.LBB71_33
// %bb.31:
	cmp	x2, x3
	b.eq	.LBB71_33
// %bb.32:
	and	x11, x2, #0xffffffffff
	ldr	xzr, [x20, x11, lsl #3]
.LBB71_33:
	mov	w5, w5
	mov	w7, w7
	cbz	x8, .LBB71_42
// %bb.34:
	and	x8, x2, #0xffffffffff
	str	x17, [sp, #400]                 // 8-byte Folded Spill
	mov	w17, #34047                     // =0x84ff
	add	x13, x20, x8, lsl #3
	movk	w17, #784, lsl #16
	tbnz	x2, #63, .LBB71_47
// %bb.35:
	ldp	x24, x2, [x13]
	mov	x11, x8
	cmp	x8, x17
	b.hi	.LBB71_51
	b	.LBB71_53
.LBB71_36:
	mov	w5, w5
	mov	w7, w7
	cbz	w23, .LBB71_43
.LBB71_37:
	mov	w8, w14
	mov	w11, w24
	stp	x18, x15, [x29, #72]
	stp	x11, x8, [x29, #40]
	ldp	x10, x11, [x29, #-208]          // 16-byte Folded Reload
	mov	w8, w12
	mov	w25, w25
	mov	w26, w26
	stp	x16, x30, [x29, #56]
	mov	w13, w19
	mov	w14, w2
	mov	w15, w10
	mov	w11, w11
	ldur	x10, [x29, #-232]               // 8-byte Folded Reload
	mov	w9, w9
	stp	x11, x8, [x29, #24]
	mov	w8, w17
	mov	w11, #1                         // =0x1
	ldur	x12, [x29, #-192]               // 8-byte Folded Reload
	str	x8, [x29, #16]
	add	sp, sp, #688
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	WL_FID____BENDVY_QUERY_FROZEN_PROVIDER_NATIVE_V3_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_1
.LBB71_38:
	.cfi_restore_state
	.cfi_remember_state
	stp	x15, x16, [x29, #-224]          // 16-byte Folded Spill
	mov	x15, x14
	mov	x19, x13
	ldp	x14, x13, [x22, #-24]
	ldr	x8, [x21, #40]
	mov	x23, x17
	cbz	x8, .LBB71_93
// %bb.39:
	ldr	x16, [x20, x8, lsl #3]
	ldr	x17, [x21, #296]
	mov	x22, x20
	str	x16, [x21, #40]
	sub	x16, x17, #32
	str	x16, [x21, #296]
.LBB71_40:
	add	x16, x22, x8, lsl #3
	lsl	x13, x13, #32
.LBB71_41:
	stp	x14, x13, [x16, #216]
	mov	w14, w25
	mov	w13, w26
	stp	x14, x13, [x16]
	mov	w13, w5
	stp	x13, x6, [x16, #64]
	mov	w13, w7
	stp	x27, x28, [x16, #16]
	stp	x0, x1, [x16, #32]
	stp	x3, x4, [x16, #48]
	stp	x13, x10, [x16, #80]
	mov	x17, x23
	b	.LBB71_46
.LBB71_42:
	ldp	x22, x2, [x29, #-248]           // 16-byte Folded Reload
	ldur	w23, [x29, #-256]               // 4-byte Folded Reload
	ldr	x18, [sp, #424]                 // 8-byte Folded Reload
	ldur	x14, [x29, #-224]               // 8-byte Folded Reload
	cbnz	w23, .LBB71_37
.LBB71_43:
	ldp	x11, x13, [x22, #-24]
	stp	x15, x16, [x29, #-224]          // 16-byte Folded Spill
	ldr	x8, [x21, #40]
	mov	x15, x27
	mov	x27, x28
	mov	x23, x25
	mov	x25, x14
	cbz	x8, .LBB71_94
// %bb.44:
	ldr	x14, [x20, x8, lsl #3]
	ldr	x16, [x21, #296]
	mov	x28, x20
	str	x14, [x21, #40]
	sub	x14, x16, #32
	str	x14, [x21, #296]
.LBB71_45:
	add	x16, x28, x8, lsl #3
	lsl	x13, x13, #32
	stp	x11, x13, [x16, #216]
	mov	w11, w23
	mov	w13, w26
	stp	x11, x13, [x16]
	ldur	x13, [x29, #-232]               // 8-byte Folded Reload
	mov	w11, #1                         // =0x1
	stp	x15, x27, [x16, #16]
	mov	x15, x25
	stp	x0, x1, [x16, #32]
	stp	x3, x4, [x16, #48]
	stp	x5, x6, [x16, #64]
	stp	x7, x13, [x16, #80]
.LBB71_46:
	ldur	x10, [x29, #-192]               // 8-byte Folded Reload
	stp	x30, x18, [x16, #192]
	stp	x11, x10, [x16, #96]
	mov	w10, w19
	mov	w11, w2
	stp	x10, x11, [x16, #112]
	mov	w10, w9
	ldur	x9, [x29, #-208]                // 8-byte Folded Reload
	mov	w11, w9
	ldur	x9, [x29, #-200]                // 8-byte Folded Reload
	stp	x10, x11, [x16, #128]
	mov	w10, w17
	mov	w11, w9
	ldur	x9, [x29, #-216]                // 8-byte Folded Reload
	stp	x10, x11, [x16, #144]
	mov	w10, w12
	mov	w11, w24
	stp	x10, x11, [x16, #160]
	mov	w10, w15
	stp	x10, x9, [x16, #176]
	mov	x9, #42880953483264             // =0x270000000000
	movk	x9, #1280, lsl #48
	orr	x0, x8, x9
	ldur	x8, [x29, #-224]                // 8-byte Folded Reload
	str	x8, [x16, #208]
	add	sp, sp, #688
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB71_47:
	.cfi_restore_state
	.cfi_remember_state
	ldr	w11, [x13, #4]
	ldr	w14, [x13]
	and	x16, x14, #0xffffff
	cmp	x16, #1
	b.ne	.LBB71_299
// %bb.48:
	orr	x11, x14, x11, lsl #32
	ldar	wzr, [x13]
	ldr	x13, [x21]
	lsr	x11, x11, #24
	add	x14, x20, x11, lsl #3
	ldp	x24, x2, [x14]
	str	x13, [x20, x8, lsl #3]
	ldr	x13, [x21, #256]
	str	x8, [x21]
	add	x8, x13, #1
	adrp	x13, .L_MergedGlobals
	str	x8, [x21, #256]
	ldrb	w13, [x13, :lo12:.L_MergedGlobals]
	cmp	w13, #1
	b.ne	.LBB71_305
// %bb.49:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB71_305
// %bb.50:
	cmp	x11, x17
	b.ls	.LBB71_53
.LBB71_51:
	ldr	x8, [x21, #8]
	adrp	x13, .L_MergedGlobals
	str	x8, [x20, x11, lsl #3]
	ldr	x8, [x21, #264]
	str	x11, [x21, #8]
	add	x8, x8, #2
	str	x8, [x21, #264]
	ldrb	w13, [x13, :lo12:.L_MergedGlobals]
	cmp	w13, #1
	b.ne	.LBB71_294
// %bb.52:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB71_294
.LBB71_53:
	and	x8, x24, #0xffffffffff
	add	x13, x20, x8, lsl #3
	tbnz	x24, #63, .LBB71_55
// %bb.54:
	ldp	x22, x10, [x13]
	mov	x11, x8
	str	x10, [sp, #392]                 // 8-byte Folded Spill
	cmp	x8, x17
	b.hi	.LBB71_59
	b	.LBB71_61
.LBB71_55:
	ldr	w11, [x13, #4]
	ldr	w14, [x13]
	mov	x23, x2
	and	x16, x14, #0xffffff
	cmp	x16, #1
	b.ne	.LBB71_300
// %bb.56:
	orr	x11, x14, x11, lsl #32
	ldar	wzr, [x13]
	ldr	x13, [x21]
	lsr	x11, x11, #24
	add	x14, x20, x11, lsl #3
	ldp	x22, x10, [x14]
	str	x13, [x20, x8, lsl #3]
	ldr	x13, [x21, #256]
	str	x8, [x21]
	add	x8, x13, #1
	adrp	x13, .L_MergedGlobals
	str	x10, [sp, #392]                 // 8-byte Folded Spill
	str	x8, [x21, #256]
	ldrb	w13, [x13, :lo12:.L_MergedGlobals]
	cmp	w13, #1
	b.ne	.LBB71_306
// %bb.57:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB71_306
// %bb.58:
	mov	x2, x23
	cmp	x11, x17
	b.ls	.LBB71_61
.LBB71_59:
	ldr	x8, [x21, #8]
	adrp	x13, .L_MergedGlobals
	str	x8, [x20, x11, lsl #3]
	ldr	x8, [x21, #264]
	str	x11, [x21, #8]
	add	x8, x8, #2
	str	x8, [x21, #264]
	ldrb	w13, [x13, :lo12:.L_MergedGlobals]
	cmp	w13, #1
	b.ne	.LBB71_295
// %bb.60:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB71_295
.LBB71_61:
	and	x8, x2, #0xffffffffff
	add	x11, x20, x8, lsl #3
	tbnz	x2, #63, .LBB71_63
// %bb.62:
	ldr	x10, [x11]
	mov	x24, x8
	str	x10, [sp, #384]                 // 8-byte Folded Spill
	ldp	x8, x10, [x11, #8]
	stp	x10, x8, [sp, #368]             // 16-byte Folded Spill
	ldp	x8, x10, [x11, #24]
	stp	x10, x8, [sp, #352]             // 16-byte Folded Spill
	cmp	x24, x17
	b.hi	.LBB71_69
	b	.LBB71_71
.LBB71_63:
	ldr	w14, [x11, #4]
	ldr	w16, [x11]
	and	x13, x16, #0xffffff
	cmp	x13, #1
	b.ne	.LBB71_65
// %bb.64:
	ldar	wzr, [x11]
.LBB71_65:
	orr	x14, x16, x14, lsl #32
	cmp	x13, #1
	stp	x0, x1, [sp, #408]              // 16-byte Folded Spill
	lsr	x24, x14, #24
	add	x14, x20, x24, lsl #3
	ldr	x10, [x14]
	str	x10, [sp, #384]                 // 8-byte Folded Spill
	ldr	x10, [x14, #8]
	str	x10, [sp, #376]                 // 8-byte Folded Spill
	ldr	x10, [x14, #16]
	str	x10, [sp, #368]                 // 8-byte Folded Spill
	ldr	x10, [x14, #24]
	str	x10, [sp, #360]                 // 8-byte Folded Spill
	ldr	x10, [x14, #32]
	str	x10, [sp, #352]                 // 8-byte Folded Spill
	b.ne	.LBB71_301
// %bb.66:
	ldr	x13, [x21]
	str	x13, [x11]
	ldr	x11, [x21, #256]
	str	x8, [x21]
	add	x8, x11, #1
	adrp	x11, .L_MergedGlobals
	str	x8, [x21, #256]
	ldrb	w11, [x11, :lo12:.L_MergedGlobals]
	cmp	w11, #1
	b.ne	.LBB71_307
// %bb.67:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB71_307
// %bb.68:
	ldp	x0, x1, [sp, #408]              // 16-byte Folded Reload
	cmp	x24, x17
	b.ls	.LBB71_71
.LBB71_69:
	ldr	x8, [x21, #24]
	adrp	x11, .L_MergedGlobals
	str	x8, [x20, x24, lsl #3]
	ldr	x8, [x21, #280]
	str	x24, [x21, #24]
	add	x8, x8, #8
	str	x8, [x21, #280]
	ldrb	w11, [x11, :lo12:.L_MergedGlobals]
	cmp	w11, #1
	b.ne	.LBB71_296
// %bb.70:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB71_296
.LBB71_71:
	mov	x8, #42880953483264             // =0x270000000000
	mov	x13, #41781441855488            // =0x260000000000
	ldr	x11, [x21, #32]
	cmp	w12, #0
	movk	x8, #256, lsl #48
	movk	x13, #256, lsl #48
	csel	x23, x13, x8, eq
	cbz	x11, .LBB71_95
// %bb.72:
	ldr	x8, [x20, x11, lsl #3]
	ldr	x13, [x21, #288]
	str	x8, [x21, #32]
	sub	x8, x13, #16
	str	x8, [x21, #288]
.LBB71_73:
	lsr	x8, x27, #56
	add	x24, x20, x11, lsl #3
	mov	w13, w25
	mov	w14, w26
	cmp	x8, #2
	stp	x13, x14, [x24]
	b.eq	.LBB71_96
// %bb.74:
	lsr	x8, x28, #56
	str	x27, [x24, #16]
	cmp	x8, #2
	b.eq	.LBB71_97
.LBB71_75:
	lsr	x8, x0, #56
	str	x28, [x24, #24]
	cmp	x8, #2
	b.eq	.LBB71_98
.LBB71_76:
	lsr	x8, x1, #56
	str	x0, [x24, #32]
	cmp	x8, #2
	b.eq	.LBB71_99
.LBB71_77:
	lsr	x8, x3, #56
	str	x1, [x24, #40]
	cmp	x8, #2
	b.eq	.LBB71_100
.LBB71_78:
	lsr	x8, x4, #56
	str	x3, [x24, #48]
	cmp	x8, #2
	b.eq	.LBB71_101
.LBB71_79:
	lsr	x8, x6, #56
	stp	x4, x5, [x24, #56]
	cmp	x8, #2
	b.eq	.LBB71_102
.LBB71_80:
	ldur	x8, [x29, #-232]                // 8-byte Folded Reload
	stp	x6, x7, [x24, #72]
	lsr	x8, x8, #56
	cmp	x8, #2
	b.eq	.LBB71_103
.LBB71_81:
	ldur	x8, [x29, #-232]                // 8-byte Folded Reload
	stp	xzr, x23, [x24, #104]
	stp	x8, xzr, [x24, #88]
	ldr	x10, [x21]
	cbz	x10, .LBB71_104
.LBB71_82:
	ldr	x8, [x20, x10, lsl #3]
	ldr	x13, [x21, #256]
	str	x8, [x21]
	sub	x8, x13, #1
	str	x8, [x21, #256]
.LBB71_83:
	mov	x8, #65970697666560             // =0x3c0000000000
	ldur	x24, [x29, #-200]               // 8-byte Folded Reload
	mov	x27, x19
	movk	x8, #512, lsl #48
	orr	x2, x11, x8
	lsr	x8, x2, #56
	cmp	x8, #2
	b.eq	.LBB71_105
// %bb.84:
	str	x2, [x20, x10, lsl #3]
	tbnz	x10, #63, .LBB71_106
.LBB71_85:
	ldr	x14, [sp, #424]                 // 8-byte Folded Reload
	ldur	x19, [x29, #-240]               // 8-byte Folded Reload
	and	x23, x22, #0xffffffffff
	tbnz	x22, #63, .LBB71_107
.LBB71_86:
	ldur	x8, [x29, #-192]                // 8-byte Folded Reload
	and	x16, x8, #0xffffffffff
	tbnz	x8, #63, .LBB71_108
.LBB71_87:
	ldur	x11, [x29, #-216]               // 8-byte Folded Reload
	and	x8, x11, #0xffffffffff
	tbnz	x11, #63, .LBB71_109
.LBB71_88:
	and	x11, x30, #0xffffffffff
	tbnz	x30, #63, .LBB71_110
.LBB71_89:
	and	x17, x14, #0xffffffffff
	tbnz	x14, #63, .LBB71_111
.LBB71_90:
	and	x18, x15, #0xffffffffff
	tbnz	x15, #63, .LBB71_112
.LBB71_91:
	mov	x13, #207807697649664           // =0xbd0000000000
	cmp	x22, x15
	mov	x5, x18
	movk	x13, #512, lsl #48
	b.ne	.LBB71_113
	b	.LBB71_117
.LBB71_92:
	stp	x0, x1, [sp, #408]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	stp	x9, x2, [x29, #-248]            // 16-byte Folded Spill
	mov	w2, #5                          // =0x5
	mov	x22, x20
	mov	x9, x18
	str	x6, [sp, #320]                  // 8-byte Folded Spill
	mov	x21, x4
	str	x3, [sp, #344]                  // 8-byte Folded Spill
	mov	x20, x30
	str	x7, [sp, #424]                  // 8-byte Folded Spill
	stur	x5, [x29, #-256]                // 8-byte Folded Spill
	bl	heap_alloc_miss
	mov	x18, x9
	ldp	x9, x2, [x29, #-248]            // 16-byte Folded Reload
	ldp	x1, x7, [sp, #416]              // 16-byte Folded Reload
	mov	x8, x0
	ldur	x5, [x29, #-256]                // 8-byte Folded Reload
	ldr	x3, [sp, #344]                  // 8-byte Folded Reload
	mov	x30, x20
	ldr	x6, [sp, #320]                  // 8-byte Folded Reload
	ldr	x0, [sp, #408]                  // 8-byte Folded Reload
	mov	x4, x21
	b	.LBB71_16
.LBB71_93:
	stp	x0, x1, [sp, #408]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	stp	x9, x2, [x29, #-248]            // 16-byte Folded Spill
	mov	w2, #5                          // =0x5
	mov	x22, x20
	mov	x9, x18
	str	x6, [sp, #320]                  // 8-byte Folded Spill
	mov	x21, x4
	str	x3, [sp, #344]                  // 8-byte Folded Spill
	mov	x20, x30
	str	x7, [sp, #424]                  // 8-byte Folded Spill
	stur	x5, [x29, #-256]                // 8-byte Folded Spill
	bl	heap_alloc_miss
	mov	x18, x9
	ldp	x9, x2, [x29, #-248]            // 16-byte Folded Reload
	ldp	x1, x7, [sp, #416]              // 16-byte Folded Reload
	mov	x8, x0
	ldur	x5, [x29, #-256]                // 8-byte Folded Reload
	ldr	x3, [sp, #344]                  // 8-byte Folded Reload
	mov	x30, x20
	ldr	x6, [sp, #320]                  // 8-byte Folded Reload
	ldr	x0, [sp, #408]                  // 8-byte Folded Reload
	mov	x4, x21
	b	.LBB71_40
.LBB71_94:
	stp	x0, x1, [sp, #408]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	stp	x9, x2, [x29, #-248]            // 16-byte Folded Spill
	mov	w2, #5                          // =0x5
	mov	x28, x20
	mov	x9, x18
	str	x6, [sp, #320]                  // 8-byte Folded Spill
	mov	x21, x4
	str	x3, [sp, #344]                  // 8-byte Folded Spill
	mov	x14, x7
	mov	x22, x30
	str	x5, [sp, #304]                  // 8-byte Folded Spill
	mov	x20, x17
	bl	heap_alloc_miss
	mov	x18, x9
	ldp	x9, x2, [x29, #-248]            // 16-byte Folded Reload
	mov	x8, x0
	ldp	x0, x1, [sp, #408]              // 16-byte Folded Reload
	ldr	x5, [sp, #304]                  // 8-byte Folded Reload
	ldr	x3, [sp, #344]                  // 8-byte Folded Reload
	mov	x17, x20
	ldr	x6, [sp, #320]                  // 8-byte Folded Reload
	mov	x30, x22
	mov	x7, x14
	mov	x4, x21
	b	.LBB71_45
.LBB71_95:
	stp	x0, x1, [sp, #408]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	mov	w2, #4                          // =0x4
	mov	x14, x6
	mov	x13, x4
	mov	x24, x3
	mov	x11, x7
	str	x5, [sp, #304]                  // 8-byte Folded Spill
	mov	x12, x19
	mov	x19, x30
	bl	heap_alloc_miss
	mov	x7, x11
	mov	x11, x0
	ldr	x5, [sp, #304]                  // 8-byte Folded Reload
	ldp	x0, x1, [sp, #408]              // 16-byte Folded Reload
	mov	x30, x19
	mov	x19, x12
	mov	x3, x24
	mov	x4, x13
	mov	x6, x14
	b	.LBB71_73
.LBB71_96:
	stp	x0, x1, [sp, #408]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	mov	x2, x27
	str	x3, [sp, #344]                  // 8-byte Folded Spill
	mov	w3, #1                          // =0x1
	mov	x27, x6
	mov	x14, x4
	mov	x13, x7
	mov	x26, x5
	mov	x10, x19
	mov	x19, x30
	bl	rfc_wrap
	mov	x6, x27
	mov	x27, x0
	ldr	x3, [sp, #344]                  // 8-byte Folded Reload
	ldp	x0, x1, [sp, #408]              // 16-byte Folded Reload
	mov	x30, x19
	mov	x19, x10
	mov	x5, x26
	mov	x7, x13
	mov	x4, x14
	lsr	x8, x28, #56
	str	x27, [x24, #16]
	cmp	x8, #2
	b.ne	.LBB71_75
.LBB71_97:
	stp	x0, x1, [sp, #408]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	mov	x2, x28
	mov	x26, x3
	mov	w3, #1                          // =0x1
	mov	x27, x6
	mov	x13, x4
	mov	x28, x7
	mov	x14, x5
	mov	x10, x19
	mov	x19, x30
	bl	rfc_wrap
	mov	x7, x28
	mov	x28, x0
	mov	x30, x19
	ldp	x0, x1, [sp, #408]              // 16-byte Folded Reload
	mov	x19, x10
	mov	x5, x14
	mov	x3, x26
	mov	x4, x13
	mov	x6, x27
	lsr	x8, x0, #56
	str	x28, [x24, #24]
	cmp	x8, #2
	b.ne	.LBB71_76
.LBB71_98:
	mov	x2, x0
	mov	x0, x20
	str	x1, [sp, #416]                  // 8-byte Folded Spill
	mov	x1, x21
	mov	x14, x3
	mov	w3, #1                          // =0x1
	mov	x26, x6
	mov	x28, x4
	mov	x27, x7
	mov	x13, x5
	mov	x10, x19
	mov	x19, x30
	bl	rfc_wrap
	ldr	x1, [sp, #416]                  // 8-byte Folded Reload
	mov	x30, x19
	mov	x19, x10
	mov	x5, x13
	mov	x7, x27
	mov	x3, x14
	mov	x4, x28
	mov	x6, x26
	lsr	x8, x1, #56
	str	x0, [x24, #32]
	cmp	x8, #2
	b.ne	.LBB71_77
.LBB71_99:
	mov	x0, x20
	mov	x2, x1
	mov	x1, x21
	mov	x13, x3
	mov	w3, #1                          // =0x1
	mov	x14, x6
	mov	x27, x4
	mov	x26, x7
	mov	x28, x5
	mov	x10, x19
	mov	x19, x30
	bl	rfc_wrap
	mov	x30, x19
	mov	x19, x10
	mov	x5, x28
	mov	x7, x26
	mov	x3, x13
	mov	x4, x27
	mov	x6, x14
	lsr	x8, x13, #56
	str	x0, [x24, #40]
	cmp	x8, #2
	b.ne	.LBB71_78
.LBB71_100:
	mov	x0, x20
	mov	x1, x21
	mov	x2, x3
	mov	w3, #1                          // =0x1
	mov	x13, x6
	mov	x26, x4
	mov	x14, x7
	mov	x27, x5
	mov	x10, x19
	mov	x19, x30
	bl	rfc_wrap
	mov	x30, x19
	mov	x19, x10
	mov	x5, x27
	mov	x7, x14
	mov	x4, x26
	mov	x6, x13
	lsr	x8, x26, #56
	str	x0, [x24, #48]
	cmp	x8, #2
	b.ne	.LBB71_79
.LBB71_101:
	mov	x0, x20
	mov	x1, x21
	mov	x2, x4
	mov	w3, #1                          // =0x1
	mov	x13, x6
	mov	x26, x7
	mov	x14, x5
	mov	x10, x19
	mov	x19, x30
	bl	rfc_wrap
	mov	x30, x19
	mov	x19, x10
	mov	x7, x26
	mov	x6, x13
	lsr	x8, x13, #56
	stp	x0, x14, [x24, #56]
	cmp	x8, #2
	b.ne	.LBB71_80
.LBB71_102:
	mov	x0, x20
	mov	x1, x21
	mov	x2, x6
	mov	w3, #1                          // =0x1
	mov	x13, x7
	mov	x14, x30
	bl	rfc_wrap
	mov	x30, x14
	ldur	x8, [x29, #-232]                // 8-byte Folded Reload
	stp	x0, x13, [x24, #72]
	lsr	x8, x8, #56
	cmp	x8, #2
	b.ne	.LBB71_81
.LBB71_103:
	ldur	x2, [x29, #-232]                // 8-byte Folded Reload
	mov	x0, x20
	mov	x1, x21
	mov	w3, #1                          // =0x1
	mov	x10, x30
	bl	rfc_wrap
	mov	x30, x10
	stur	x0, [x29, #-232]                // 8-byte Folded Spill
	stp	xzr, x23, [x24, #104]
	stp	x0, xzr, [x24, #88]
	ldr	x10, [x21]
	cbnz	x10, .LBB71_82
.LBB71_104:
	mov	x0, x20
	mov	x1, x21
	mov	w2, wzr
	mov	x10, x30
	bl	heap_alloc_miss
	mov	x30, x10
	mov	x10, x0
	b	.LBB71_83
.LBB71_105:
	mov	x0, x20
	mov	x1, x21
	mov	w3, #1                          // =0x1
	mov	x11, x30
	bl	rfc_wrap
	mov	x30, x11
	str	x0, [x20, x10, lsl #3]
	tbz	x10, #63, .LBB71_85
.LBB71_106:
	and	x8, x10, #0xffffffffff
	ldr	xzr, [x20, x8, lsl #3]
	ldr	x14, [sp, #424]                 // 8-byte Folded Reload
	ldur	x19, [x29, #-240]               // 8-byte Folded Reload
	and	x23, x22, #0xffffffffff
	tbz	x22, #63, .LBB71_86
.LBB71_107:
	ldr	x8, [x20, x23, lsl #3]
	lsr	x23, x8, #24
	ldur	x8, [x29, #-192]                // 8-byte Folded Reload
	and	x16, x8, #0xffffffffff
	tbz	x8, #63, .LBB71_87
.LBB71_108:
	ldr	x8, [x20, x16, lsl #3]
	lsr	x16, x8, #24
	ldur	x11, [x29, #-216]               // 8-byte Folded Reload
	and	x8, x11, #0xffffffffff
	tbz	x11, #63, .LBB71_88
.LBB71_109:
	ldr	x8, [x20, x8, lsl #3]
	lsr	x8, x8, #24
	and	x11, x30, #0xffffffffff
	tbz	x30, #63, .LBB71_89
.LBB71_110:
	ldr	x11, [x20, x11, lsl #3]
	lsr	x11, x11, #24
	and	x17, x14, #0xffffffffff
	tbz	x14, #63, .LBB71_90
.LBB71_111:
	ldr	x13, [x20, x17, lsl #3]
	lsr	x17, x13, #24
	and	x18, x15, #0xffffffffff
	tbz	x15, #63, .LBB71_91
.LBB71_112:
	ldr	x13, [x20, x18, lsl #3]
	lsr	x18, x13, #24
	mov	x13, #207807697649664           // =0xbd0000000000
	cmp	x22, x15
	mov	x5, x18
	movk	x13, #512, lsl #48
	b.eq	.LBB71_117
.LBB71_113:
	cmp	x22, x14
	mov	x5, x17
	b.eq	.LBB71_117
// %bb.114:
	cmp	x22, x30
	mov	x5, x11
	b.eq	.LBB71_117
// %bb.115:
	ldur	x26, [x29, #-216]               // 8-byte Folded Reload
	mov	x5, x8
	cmp	x22, x26
	b.eq	.LBB71_117
// %bb.116:
	ldur	x12, [x29, #-192]               // 8-byte Folded Reload
	cmp	x22, x12
	csel	x5, x16, x23, eq
.LBB71_117:
	ldur	x12, [x29, #-192]               // 8-byte Folded Reload
	orr	x3, x10, x13
	mov	x10, x18
	cmp	x12, x15
	b.eq	.LBB71_121
// %bb.118:
	ldur	x10, [x29, #-192]               // 8-byte Folded Reload
	cmp	x10, x14
	mov	x10, x17
	b.eq	.LBB71_121
// %bb.119:
	ldur	x10, [x29, #-192]               // 8-byte Folded Reload
	cmp	x10, x30
	mov	x10, x11
	b.eq	.LBB71_121
// %bb.120:
	ldur	x10, [x29, #-216]               // 8-byte Folded Reload
	ldur	x12, [x29, #-192]               // 8-byte Folded Reload
	cmp	x12, x10
	csel	x10, x8, x16, eq
.LBB71_121:
	ldur	x16, [x29, #-216]               // 8-byte Folded Reload
	mov	x13, x18
	cmp	x16, x15
	b.eq	.LBB71_124
// %bb.122:
	cmp	x16, x14
	mov	x13, x17
	b.eq	.LBB71_124
// %bb.123:
	cmp	x16, x30
	csel	x13, x11, x8, eq
.LBB71_124:
	cmp	x30, x14
	ldp	x12, x7, [sp, #376]             // 16-byte Folded Reload
	csel	x8, x17, x11, eq
	cmp	x30, x15
	str	wzr, [sp, #176]
	csel	x8, x18, x8, eq
	cmp	x14, x15
	stp	x15, x18, [sp, #160]
	csel	x11, x18, x17, eq
	ldp	x23, x17, [sp, #360]            // 16-byte Folded Reload
	str	w12, [sp, #192]
	sub	x2, x29, #184
	mov	x0, x20
	str	w7, [sp, #184]
	mov	x1, x21
	mov	x4, x22
	str	w23, [sp, #208]
	ldr	x6, [sp, #392]                  // 8-byte Folded Reload
                                        // kill: def $w7 killed $w7 killed $x7
	str	w17, [sp, #200]
                                        // kill: def $w6 killed $w6 killed $x6
	stp	x16, x13, [sp, #112]
	ldur	x13, [x29, #-224]               // 8-byte Folded Reload
	str	w25, [sp, #96]
	str	w24, [sp, #88]
	str	w13, [sp, #104]
	ldr	x13, [sp, #400]                 // 8-byte Folded Reload
	str	w13, [sp, #80]
	ldur	x13, [x29, #-208]               // 8-byte Folded Reload
	str	w9, [sp, #64]
	str	w19, [sp, #56]
	str	w13, [sp, #72]
	str	w27, [sp, #48]
	str	x10, [sp, #40]
	ldur	x9, [x29, #-192]                // 8-byte Folded Reload
	str	w23, [sp, #16]
	str	w17, [sp, #8]
	str	x9, [sp, #32]
	ldr	x9, [sp, #352]                  // 8-byte Folded Reload
	str	w12, [sp]
	str	w9, [sp, #24]
	stp	x14, x11, [sp, #144]
	stp	x30, x8, [sp, #128]
	bl	spin_76
	ldur	w8, [x29, #-168]
	ldp	x12, x24, [x29, #-184]
	ldp	q1, q0, [x29, #-160]
	ldur	x10, [x29, #-120]
	str	x8, [sp, #408]                  // 8-byte Folded Spill
	ldur	w8, [x29, #-128]
	ldur	x23, [x29, #-24]
	ldur	w9, [x29, #-16]
	ldp	x25, x26, [x29, #-40]
	str	x8, [sp, #416]                  // 8-byte Folded Spill
	ldur	w8, [x29, #-112]
	stp	q1, q0, [sp, #304]              // 32-byte Folded Spill
	str	x8, [sp, #400]                  // 8-byte Folded Spill
	ldur	w8, [x29, #-104]
	str	x8, [sp, #392]                  // 8-byte Folded Spill
	ldur	w8, [x29, #-96]
	str	x8, [sp, #384]                  // 8-byte Folded Spill
	ldur	w8, [x29, #-88]
	str	x8, [sp, #376]                  // 8-byte Folded Spill
	ldur	w8, [x29, #-80]
	str	x8, [sp, #368]                  // 8-byte Folded Spill
	ldur	w8, [x29, #-72]
	str	x8, [sp, #360]                  // 8-byte Folded Spill
	ldur	w8, [x29, #-64]
	str	x8, [sp, #352]                  // 8-byte Folded Spill
	ldp	x8, x11, [x29, #-56]
	stur	x8, [x29, #-208]                // 8-byte Folded Spill
	and	x8, x12, #0xffffffffff
	mov	x14, x8
	str	x9, [sp, #344]                  // 8-byte Folded Spill
	tbnz	x12, #63, .LBB71_135
// %bb.125:
	mov	w1, #34047                      // =0x84ff
	and	x15, x24, #0xffffffffff
	movk	w1, #784, lsl #16
	tbnz	x24, #63, .LBB71_136
.LBB71_126:
	and	x19, x10, #0xffffffffff
	tbnz	x10, #63, .LBB71_137
.LBB71_127:
	and	x13, x11, #0xffffffffff
	stp	x10, x11, [x29, #-200]          // 16-byte Folded Spill
	tbnz	x11, #63, .LBB71_138
.LBB71_128:
	and	x9, x25, #0xffffffffff
	tbnz	x25, #63, .LBB71_139
.LBB71_129:
	and	x10, x26, #0xffffffffff
	stp	x13, x9, [sp, #232]             // 16-byte Folded Spill
	tbnz	x26, #63, .LBB71_140
.LBB71_130:
	str	x10, [sp, #248]                 // 8-byte Folded Spill
	and	x22, x23, #0xffffffffff
	tbz	x23, #63, .LBB71_132
.LBB71_131:
	ldr	x9, [x20, x22, lsl #3]
	lsr	x22, x9, #24
.LBB71_132:
	and	x9, x12, #0xffff0000000000
	mov	x10, #207807697649664           // =0xbd0000000000
	cmp	x9, x10
	b.ne	.LBB71_134
// %bb.133:
	mov	x9, x12
	b	.LBB71_155
.LBB71_134:
	adrp	x11, .L_MergedGlobals
	mov	x9, x12
	b	.LBB71_144
.LBB71_135:
	ldr	x9, [x20, x8, lsl #3]
	lsr	x14, x9, #24
	mov	w1, #34047                      // =0x84ff
	and	x15, x24, #0xffffffffff
	movk	w1, #784, lsl #16
	tbz	x24, #63, .LBB71_126
.LBB71_136:
	ldr	x9, [x20, x15, lsl #3]
	lsr	x15, x9, #24
	and	x19, x10, #0xffffffffff
	tbz	x10, #63, .LBB71_127
.LBB71_137:
	ldr	x9, [x20, x19, lsl #3]
	lsr	x19, x9, #24
	and	x13, x11, #0xffffffffff
	stp	x10, x11, [x29, #-200]          // 16-byte Folded Spill
	tbz	x11, #63, .LBB71_128
.LBB71_138:
	ldr	x9, [x20, x13, lsl #3]
	lsr	x13, x9, #24
	and	x9, x25, #0xffffffffff
	tbz	x25, #63, .LBB71_129
.LBB71_139:
	ldr	x9, [x20, x9, lsl #3]
	lsr	x9, x9, #24
	and	x10, x26, #0xffffffffff
	stp	x13, x9, [sp, #232]             // 16-byte Folded Spill
	tbz	x26, #63, .LBB71_130
.LBB71_140:
	ldr	x9, [x20, x10, lsl #3]
	lsr	x9, x9, #24
	str	x9, [sp, #248]                  // 8-byte Folded Spill
	and	x22, x23, #0xffffffffff
	tbz	x23, #63, .LBB71_132
	b	.LBB71_131
.LBB71_141:                             //   in Loop: Header=BB71_144 Depth=1
	orr	x8, x17, x13, lsl #32
	mov	x0, x20
	mov	x1, x21
	mov	x2, x9
	mov	w4, #1                          // =0x1
	lsr	x3, x8, #24
	ldr	x13, [x20, x3, lsl #3]
	bl	span_fade
	mov	w1, #34047                      // =0x84ff
	mov	x9, x13
.LBB71_142:                             //   in Loop: Header=BB71_144 Depth=1
	movk	w1, #784, lsl #16
.LBB71_143:                             //   in Loop: Header=BB71_144 Depth=1
	and	x8, x9, #0xffff0000000000
	cmp	x8, x10
	b.eq	.LBB71_154
.LBB71_144:                             // =>This Inner Loop Header: Depth=1
	and	x8, x9, #0xffffffffff
	add	x16, x20, x8, lsl #3
	tbnz	x9, #63, .LBB71_146
// %bb.145:                             //   in Loop: Header=BB71_144 Depth=1
	ldr	x9, [x16]
	mov	x13, x8
	cmp	x8, x1
	b.ls	.LBB71_143
	b	.LBB71_150
.LBB71_146:                             //   in Loop: Header=BB71_144 Depth=1
	ldr	w13, [x16, #4]
	ldr	w17, [x16]
	and	x18, x17, #0xffffff
	cmp	x18, #1
	b.ne	.LBB71_141
// %bb.147:                             //   in Loop: Header=BB71_144 Depth=1
	orr	x9, x17, x13, lsl #32
	ldar	wzr, [x16]
	ldr	x16, [x21]
	lsr	x13, x9, #24
	ldr	x9, [x20, x13, lsl #3]
	str	x16, [x20, x8, lsl #3]
	ldr	x16, [x21, #256]
	str	x8, [x21]
	add	x8, x16, #1
	str	x8, [x21, #256]
	ldrb	w16, [x11, :lo12:.L_MergedGlobals]
	cmp	w16, #1
	b.ne	.LBB71_153
// %bb.148:                             //   in Loop: Header=BB71_144 Depth=1
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB71_153
// %bb.149:                             //   in Loop: Header=BB71_144 Depth=1
	cmp	x13, x1
	b.ls	.LBB71_143
.LBB71_150:                             //   in Loop: Header=BB71_144 Depth=1
	ldr	x8, [x21]
	str	x8, [x20, x13, lsl #3]
	ldr	x8, [x21, #256]
	str	x13, [x21]
	add	x8, x8, #1
	str	x8, [x21, #256]
	ldrb	w13, [x11, :lo12:.L_MergedGlobals]
	cmp	w13, #1
	b.ne	.LBB71_152
// %bb.151:                             //   in Loop: Header=BB71_144 Depth=1
	cmp	x8, #8, lsl #12                 // =32768
	b.lo	.LBB71_143
.LBB71_152:                             //   in Loop: Header=BB71_144 Depth=1
	mov	x0, x20
	mov	x1, x21
	mov	w2, wzr
	bl	heap_hand
	mov	w1, #34047                      // =0x84ff
	b	.LBB71_142
.LBB71_153:                             //   in Loop: Header=BB71_144 Depth=1
	mov	x0, x20
	mov	x1, x21
	mov	w2, wzr
	bl	heap_hand
	mov	w1, #34047                      // =0x84ff
	movk	w1, #784, lsl #16
	cmp	x13, x1
	b.ls	.LBB71_143
	b	.LBB71_150
.LBB71_154:
	and	x8, x9, #0xffffffffff
.LBB71_155:
	add	x10, x20, x8, lsl #3
	tbnz	x9, #63, .LBB71_157
// %bb.156:
	ldr	x10, [x10]
	mov	x9, x8
	cmp	x8, x1
	b.hi	.LBB71_161
	b	.LBB71_163
.LBB71_157:
	ldr	w11, [x10, #4]
	ldr	w13, [x10]
	and	x16, x13, #0xffffff
	cmp	x16, #1
	b.ne	.LBB71_302
// %bb.158:
	orr	x9, x13, x11, lsl #32
	ldar	wzr, [x10]
	ldr	x11, [x21]
	lsr	x9, x9, #24
	ldr	x10, [x20, x9, lsl #3]
	str	x11, [x20, x8, lsl #3]
	ldr	x11, [x21, #256]
	str	x8, [x21]
	add	x8, x11, #1
	adrp	x11, .L_MergedGlobals
	str	x8, [x21, #256]
	ldrb	w11, [x11, :lo12:.L_MergedGlobals]
	cmp	w11, #1
	b.ne	.LBB71_308
// %bb.159:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB71_308
// %bb.160:
	cmp	x9, x1
	b.ls	.LBB71_163
.LBB71_161:
	ldr	x8, [x21]
	str	x8, [x20, x9, lsl #3]
	ldr	x8, [x21, #256]
	str	x9, [x21]
	adrp	x9, .L_MergedGlobals
	add	x8, x8, #1
	str	x8, [x21, #256]
	ldrb	w9, [x9, :lo12:.L_MergedGlobals]
	cmp	w9, #1
	b.ne	.LBB71_297
// %bb.162:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB71_297
.LBB71_163:
	and	x8, x10, #0xffffffffff
	str	x19, [sp, #224]                 // 8-byte Folded Spill
	add	x16, x20, x8, lsl #3
	tbnz	x10, #63, .LBB71_165
// %bb.164:
	ldr	w9, [x16]
	ldr	x10, [x16, #72]
	mov	x11, x8
	ldp	x27, x28, [x16, #16]
	ldr	x19, [x16, #88]
	str	x9, [sp, #296]                  // 8-byte Folded Spill
	ldr	w9, [x16, #8]
	ldr	w13, [x16, #96]
	ldp	x0, x18, [x16, #32]
	str	x9, [sp, #288]                  // 8-byte Folded Spill
	ldr	w9, [x16, #64]
	ldp	x3, x4, [x16, #48]
	str	x9, [sp, #280]                  // 8-byte Folded Spill
	ldr	w9, [x16, #80]
	stp	x9, x10, [sp, #264]             // 16-byte Folded Spill
	ldp	x9, x10, [x16, #104]
	str	x10, [sp, #256]                 // 8-byte Folded Spill
	cmp	x8, x1
	b.hi	.LBB71_171
	b	.LBB71_173
.LBB71_165:
	str	x22, [sp, #424]                 // 8-byte Folded Spill
	mov	x22, x15
	mov	x15, x14
	ldr	w11, [x16, #4]
	ldr	w13, [x16]
	and	x9, x13, #0xffffff
	cmp	x9, #1
	b.ne	.LBB71_167
// %bb.166:
	ldar	wzr, [x16]
.LBB71_167:
	orr	x11, x13, x11, lsl #32
	cmp	x9, #1
	lsr	x11, x11, #24
	add	x17, x20, x11, lsl #3
	ldr	w13, [x17]
	ldr	x14, [x17, #72]
	ldr	x19, [x17, #88]
	ldp	x27, x28, [x17, #16]
	str	x13, [sp, #296]                 // 8-byte Folded Spill
	ldr	w13, [x17, #8]
	ldp	x0, x18, [x17, #32]
	str	x13, [sp, #288]                 // 8-byte Folded Spill
	ldr	w13, [x17, #64]
	ldp	x3, x4, [x17, #48]
	str	x13, [sp, #280]                 // 8-byte Folded Spill
	ldr	w13, [x17, #80]
	stp	x13, x14, [sp, #264]            // 16-byte Folded Spill
	ldp	x9, x14, [x17, #104]
	ldr	w13, [x17, #96]
	str	x14, [sp, #256]                 // 8-byte Folded Spill
	b.ne	.LBB71_304
// %bb.168:
	ldr	x10, [x21]
	mov	x14, x15
	str	x10, [x16]
	ldr	x10, [x21, #256]
	str	x8, [x21]
	add	x8, x10, #1
	adrp	x10, .L_MergedGlobals
	str	x8, [x21, #256]
	ldrb	w10, [x10, :lo12:.L_MergedGlobals]
	cmp	w10, #1
	b.ne	.LBB71_309
// %bb.169:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB71_309
// %bb.170:
	mov	x15, x22
	ldr	x22, [sp, #424]                 // 8-byte Folded Reload
	cmp	x11, x1
	b.ls	.LBB71_173
.LBB71_171:
	ldr	x8, [x21, #32]
	adrp	x10, .L_MergedGlobals
	str	x8, [x20, x11, lsl #3]
	ldr	x8, [x21, #288]
	str	x11, [x21, #32]
	add	x8, x8, #16
	str	x8, [x21, #288]
	ldrb	w10, [x10, :lo12:.L_MergedGlobals]
	cmp	w10, #1
	b.ne	.LBB71_298
// %bb.172:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB71_298
.LBB71_173:
	str	x27, [sp, #424]                 // 8-byte Folded Spill
	stp	x3, x0, [x29, #-224]            // 16-byte Folded Spill
	stp	x4, x18, [x29, #-240]           // 16-byte Folded Spill
	cbz	w13, .LBB71_176
// %bb.174:
	and	x8, x9, #0xffffffffff
	add	x10, x20, x8, lsl #3
	tbnz	x9, #63, .LBB71_177
// %bb.175:
	ldp	x11, x10, [x10]
	mov	x9, x8
	cmp	x8, x1
	b.hi	.LBB71_181
	b	.LBB71_183
.LBB71_176:
	mov	x9, xzr
	b	.LBB71_200
.LBB71_177:
	ldr	w11, [x10, #4]
	ldr	w13, [x10]
	and	x16, x13, #0xffffff
	cmp	x16, #1
	b.ne	.LBB71_313
// %bb.178:
	orr	x9, x13, x11, lsl #32
	ldar	wzr, [x10]
	ldr	x16, [x21]
	lsr	x9, x9, #24
	add	x13, x20, x9, lsl #3
	ldp	x11, x10, [x13]
	str	x16, [x20, x8, lsl #3]
	ldr	x13, [x21, #256]
	str	x8, [x21]
	add	x8, x13, #1
	adrp	x13, .L_MergedGlobals
	str	x8, [x21, #256]
	ldrb	w13, [x13, :lo12:.L_MergedGlobals]
	cmp	w13, #1
	b.ne	.LBB71_318
// %bb.179:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB71_318
// %bb.180:
	cmp	x9, x1
	b.ls	.LBB71_183
.LBB71_181:
	ldr	x8, [x21, #8]
	adrp	x13, .L_MergedGlobals
	str	x8, [x20, x9, lsl #3]
	ldr	x8, [x21, #264]
	str	x9, [x21, #8]
	add	x8, x8, #2
	str	x8, [x21, #264]
	ldrb	w13, [x13, :lo12:.L_MergedGlobals]
	cmp	w13, #1
	b.ne	.LBB71_310
// %bb.182:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB71_310
.LBB71_183:
	and	x8, x11, #0xffffffffff
	add	x9, x20, x8, lsl #3
	tbnz	x11, #63, .LBB71_185
// %bb.184:
	ldr	x9, [x9]
	mov	x11, x8
	cmp	x8, x1
	b.hi	.LBB71_189
	b	.LBB71_191
.LBB71_185:
	ldr	w13, [x9, #4]
	ldr	w16, [x9]
	and	x17, x16, #0xffffff
	cmp	x17, #1
	b.ne	.LBB71_315
// %bb.186:
	orr	x11, x16, x13, lsl #32
	ldar	wzr, [x9]
	ldr	x13, [x21]
	lsr	x11, x11, #24
	ldr	x9, [x20, x11, lsl #3]
	str	x13, [x20, x8, lsl #3]
	ldr	x13, [x21, #256]
	str	x8, [x21]
	add	x8, x13, #1
	adrp	x13, .L_MergedGlobals
	str	x8, [x21, #256]
	ldrb	w13, [x13, :lo12:.L_MergedGlobals]
	cmp	w13, #1
	b.ne	.LBB71_319
// %bb.187:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB71_319
// %bb.188:
	cmp	x11, x1
	b.ls	.LBB71_191
.LBB71_189:
	ldr	x8, [x21, #8]
	adrp	x13, .L_MergedGlobals
	str	x8, [x20, x11, lsl #3]
	ldr	x8, [x21, #264]
	str	x11, [x21, #8]
	add	x8, x8, #2
	str	x8, [x21, #264]
	ldrb	w13, [x13, :lo12:.L_MergedGlobals]
	cmp	w13, #1
	b.ne	.LBB71_311
// %bb.190:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB71_311
.LBB71_191:
	and	x8, x10, #0xffffffffff
	tbnz	x10, #63, .LBB71_193
// %bb.192:
	mov	x10, x8
	b	.LBB71_197
.LBB71_193:
	add	x16, x20, x8, lsl #3
	ldr	w11, [x16, #4]
	ldr	w13, [x16]
	and	x17, x13, #0xffffff
	cmp	x17, #1
	b.ne	.LBB71_317
// %bb.194:
	ldar	wzr, [x16]
	ldr	x10, [x21]
	orr	x11, x13, x11, lsl #32
	str	x10, [x16]
	ldr	x10, [x21, #256]
	str	x8, [x21]
	add	x8, x10, #1
	adrp	x10, .L_MergedGlobals
	str	x8, [x21, #256]
	ldrb	w13, [x10, :lo12:.L_MergedGlobals]
	lsr	x10, x11, #24
	cmp	w13, #1
	b.ne	.LBB71_320
// %bb.195:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB71_320
.LBB71_196:
	ldp	x3, x0, [x29, #-224]            // 16-byte Folded Reload
	ldr	x27, [sp, #424]                 // 8-byte Folded Reload
	ldp	x4, x18, [x29, #-240]           // 16-byte Folded Reload
.LBB71_197:
	cmp	x10, x1
	b.ls	.LBB71_200
// %bb.198:
	ldr	x8, [x21, #24]
	adrp	x11, .L_MergedGlobals
	str	x8, [x20, x10, lsl #3]
	ldr	x8, [x21, #280]
	str	x10, [x21, #24]
	add	x8, x8, #8
	str	x8, [x21, #280]
	ldrb	w11, [x11, :lo12:.L_MergedGlobals]
	cmp	w11, #1
	b.ne	.LBB71_312
// %bb.199:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB71_312
.LBB71_200:
	cmp	x27, x23
	b.eq	.LBB71_209
// %bb.201:
	ldr	x22, [sp, #248]                 // 8-byte Folded Reload
	cmp	x27, x26
	b.eq	.LBB71_209
// %bb.202:
	ldr	x22, [sp, #240]                 // 8-byte Folded Reload
	cmp	x27, x25
	b.eq	.LBB71_209
// %bb.203:
	ldur	x8, [x29, #-192]                // 8-byte Folded Reload
	ldr	x22, [sp, #232]                 // 8-byte Folded Reload
	cmp	x27, x8
	b.eq	.LBB71_209
// %bb.204:
	ldur	x8, [x29, #-200]                // 8-byte Folded Reload
	ldr	x22, [sp, #224]                 // 8-byte Folded Reload
	cmp	x27, x8
	b.eq	.LBB71_209
// %bb.205:
	cmp	x27, x24
	mov	x22, x15
	b.eq	.LBB71_209
// %bb.206:
	cmp	x27, x12
	mov	x22, x14
	b.eq	.LBB71_209
// %bb.207:
	and	x22, x27, #0xffffffffff
	tbz	x27, #63, .LBB71_209
// %bb.208:
	ldr	x8, [x20, x22, lsl #3]
	lsr	x22, x8, #24
.LBB71_209:
	ldp	x10, x11, [x29, #-200]          // 16-byte Folded Reload
	tbz	x28, #63, .LBB71_218
// %bb.210:
	cmp	x28, x12
	b.eq	.LBB71_218
// %bb.211:
	cmp	x28, x24
	b.eq	.LBB71_218
// %bb.212:
	cmp	x28, x10
	b.eq	.LBB71_218
// %bb.213:
	cmp	x28, x11
	b.eq	.LBB71_218
// %bb.214:
	cmp	x28, x25
	b.eq	.LBB71_218
// %bb.215:
	cmp	x28, x23
	b.eq	.LBB71_218
// %bb.216:
	cmp	x28, x26
	b.eq	.LBB71_218
// %bb.217:
	and	x8, x28, #0xffffffffff
	ldr	xzr, [x20, x8, lsl #3]
.LBB71_218:
	tbz	x0, #63, .LBB71_227
// %bb.219:
	cmp	x0, x12
	b.eq	.LBB71_227
// %bb.220:
	cmp	x0, x24
	b.eq	.LBB71_227
// %bb.221:
	cmp	x0, x10
	b.eq	.LBB71_227
// %bb.222:
	cmp	x0, x11
	b.eq	.LBB71_227
// %bb.223:
	cmp	x0, x25
	b.eq	.LBB71_227
// %bb.224:
	cmp	x0, x23
	b.eq	.LBB71_227
// %bb.225:
	cmp	x0, x26
	b.eq	.LBB71_227
// %bb.226:
	and	x8, x0, #0xffffffffff
	ldr	xzr, [x20, x8, lsl #3]
.LBB71_227:
	tbz	x18, #63, .LBB71_236
// %bb.228:
	cmp	x18, x12
	b.eq	.LBB71_236
// %bb.229:
	cmp	x18, x24
	b.eq	.LBB71_236
// %bb.230:
	cmp	x18, x10
	b.eq	.LBB71_236
// %bb.231:
	cmp	x18, x11
	b.eq	.LBB71_236
// %bb.232:
	cmp	x18, x25
	b.eq	.LBB71_236
// %bb.233:
	cmp	x18, x23
	b.eq	.LBB71_236
// %bb.234:
	cmp	x18, x26
	b.eq	.LBB71_236
// %bb.235:
	and	x8, x18, #0xffffffffff
	ldr	xzr, [x20, x8, lsl #3]
.LBB71_236:
	tbz	x3, #63, .LBB71_245
// %bb.237:
	cmp	x3, x12
	b.eq	.LBB71_245
// %bb.238:
	cmp	x3, x24
	b.eq	.LBB71_245
// %bb.239:
	cmp	x3, x10
	b.eq	.LBB71_245
// %bb.240:
	cmp	x3, x11
	b.eq	.LBB71_245
// %bb.241:
	cmp	x3, x25
	b.eq	.LBB71_245
// %bb.242:
	cmp	x3, x23
	b.eq	.LBB71_245
// %bb.243:
	cmp	x3, x26
	b.eq	.LBB71_245
// %bb.244:
	and	x8, x3, #0xffffffffff
	ldr	xzr, [x20, x8, lsl #3]
.LBB71_245:
	tbz	x4, #63, .LBB71_254
// %bb.246:
	cmp	x4, x12
	b.eq	.LBB71_254
// %bb.247:
	cmp	x4, x24
	b.eq	.LBB71_254
// %bb.248:
	cmp	x4, x10
	b.eq	.LBB71_254
// %bb.249:
	cmp	x4, x11
	b.eq	.LBB71_254
// %bb.250:
	cmp	x4, x25
	b.eq	.LBB71_254
// %bb.251:
	cmp	x4, x23
	b.eq	.LBB71_254
// %bb.252:
	cmp	x4, x26
	b.eq	.LBB71_254
// %bb.253:
	and	x8, x4, #0xffffffffff
	ldr	xzr, [x20, x8, lsl #3]
.LBB71_254:
	tbz	x19, #63, .LBB71_263
// %bb.255:
	cmp	x19, x12
	b.eq	.LBB71_263
// %bb.256:
	cmp	x19, x24
	b.eq	.LBB71_263
// %bb.257:
	cmp	x19, x10
	b.eq	.LBB71_263
// %bb.258:
	cmp	x19, x11
	b.eq	.LBB71_263
// %bb.259:
	cmp	x19, x25
	b.eq	.LBB71_263
// %bb.260:
	cmp	x19, x23
	b.eq	.LBB71_263
// %bb.261:
	cmp	x19, x26
	b.eq	.LBB71_263
// %bb.262:
	and	x8, x19, #0xffffffffff
	ldr	xzr, [x20, x8, lsl #3]
.LBB71_263:
	tbz	x9, #63, .LBB71_272
// %bb.264:
	cmp	x9, x12
	b.eq	.LBB71_272
// %bb.265:
	cmp	x9, x24
	b.eq	.LBB71_272
// %bb.266:
	cmp	x9, x10
	b.eq	.LBB71_272
// %bb.267:
	cmp	x9, x11
	b.eq	.LBB71_272
// %bb.268:
	cmp	x9, x25
	b.eq	.LBB71_272
// %bb.269:
	cmp	x9, x23
	b.eq	.LBB71_272
// %bb.270:
	cmp	x9, x26
	b.eq	.LBB71_272
// %bb.271:
	and	x8, x9, #0xffffffffff
	ldr	xzr, [x20, x8, lsl #3]
.LBB71_272:
	and	x8, x9, #0xffffffff00
	add	x10, x1, #1
	cmp	x8, x10
	b.lo	.LBB71_276
// %bb.273:
	cmn	x9, #1
	b.eq	.LBB71_276
// %bb.274:
	and	x8, x9, #0x7e00000000000000
	cbz	x8, .LBB71_276
// %bb.275:
	mov	x0, x20
	mov	x1, x21
	mov	x2, x9
	bl	term_drop
	ldp	x4, x18, [x29, #-240]           // 16-byte Folded Reload
	mov	w1, #34047                      // =0x84ff
	ldp	x3, x0, [x29, #-224]            // 16-byte Folded Reload
	movk	w1, #784, lsl #16
	ldr	x27, [sp, #424]                 // 8-byte Folded Reload
.LBB71_276:
	ubfx	x8, x27, #40, #5
	mov	x9, #-1                         // =0xffffffffffffffff
	ldr	x10, [x21, #8]
	sub	w8, w8, #1
	lsl	x8, x9, x8
	ldur	x9, [x29, #-208]                // 8-byte Folded Reload
	sub	w9, w9, #1
	bic	w8, w9, w8
	lsl	w14, w8, #1
	add	x8, x20, w14, uxtw #3
	add	x13, x8, x22, lsl #3
	ldr	x9, [x13, #8]
	cbz	x10, .LBB71_288
// %bb.277:
	ldr	x8, [x20, x10, lsl #3]
	ldr	x11, [x21, #264]
	str	x8, [x21, #8]
	sub	x8, x11, #2
	str	x8, [x21, #264]
	lsr	x8, x24, #56
	ldr	x11, [sp, #408]                 // 8-byte Folded Reload
	cmp	x8, #2
	b.eq	.LBB71_289
.LBB71_278:
	add	x8, x20, x10, lsl #3
	stp	x24, x11, [x8]
	ldr	x12, [x21, #24]
	cbz	x12, .LBB71_290
.LBB71_279:
	ldr	x8, [x20, x12, lsl #3]
	ldr	x11, [x21, #280]
	str	x8, [x21, #24]
	sub	x8, x11, #8
	str	x8, [x21, #280]
.LBB71_280:
	movi	v0.2d, #0x000000ffffffff
	ldp	q1, q2, [sp, #304]              // 32-byte Folded Reload
	ldr	x11, [sp, #416]                 // 8-byte Folded Reload
	add	x8, x20, x12, lsl #3
	str	x11, [x8, #32]
	and	v1.16b, v1.16b, v0.16b
	and	v0.16b, v2.16b, v0.16b
	stp	q1, q0, [x8]
	ldr	x11, [x21, #8]
	cbz	x11, .LBB71_291
// %bb.281:
	ldr	x8, [x20, x11, lsl #3]
	ldr	x15, [x21, #264]
	str	x8, [x21, #8]
	sub	x8, x15, #2
	str	x8, [x21, #264]
	mov	x8, #35184372088832             // =0x200000000000
	movk	x8, #512, lsl #48
	orr	x2, x10, x8
	lsr	x8, x2, #56
	cmp	x8, #2
	b.eq	.LBB71_292
.LBB71_282:
	mov	x8, #36283883716608             // =0x210000000000
	add	x10, x20, x11, lsl #3
	movk	x8, #512, lsl #48
	orr	x8, x12, x8
	str	x2, [x10]
	lsr	x12, x8, #56
	cmp	x12, #2
	ldur	x12, [x29, #-208]               // 8-byte Folded Reload
	mov	w24, w12
	b.eq	.LBB71_293
.LBB71_283:
	str	x8, [x10, #8]
	orr	w10, w14, #0x1
	and	x12, x9, #0xffffffff00
	add	x10, x20, w10, uxtw #3
	add	x14, x1, #1
	mov	x15, #34084860461056            // =0x1f0000000000
	mov	w8, #1                          // =0x1
	movk	x15, #512, lsl #48
	cmp	x12, x14
	str	x8, [x13]
	orr	x8, x11, x15
	str	x8, [x10, x22, lsl #3]
	b.lo	.LBB71_287
// %bb.284:
	cmn	x9, #1
	b.eq	.LBB71_287
// %bb.285:
	and	x8, x9, #0x7e00000000000000
	cbz	x8, .LBB71_287
// %bb.286:
	mov	x0, x20
	mov	x1, x21
	mov	x2, x9
	bl	term_drop
	ldp	x4, x18, [x29, #-240]           // 16-byte Folded Reload
	ldr	x27, [sp, #424]                 // 8-byte Folded Reload
	ldp	x3, x0, [x29, #-224]            // 16-byte Folded Reload
.LBB71_287:
	ldur	x22, [x29, #-248]               // 8-byte Folded Reload
	adrp	x9, wl_tab
	add	x9, x9, :lo12:wl_tab
	mov	x1, x18
	mov	x10, x19
	ldr	w8, [x22, #-8]!
	mov	w11, #1                         // =0x1
	ldr	x2, [x9, x8, lsl #3]
	ldr	x8, [sp, #344]                  // 8-byte Folded Reload
	stp	x25, x26, [x29, #64]
	mov	x9, #41781441855488             // =0x260000000000
	stp	x23, x8, [x29, #80]
	ldp	x12, x8, [x29, #-200]           // 16-byte Folded Reload
	ldur	w23, [x29, #-256]               // 4-byte Folded Reload
	str	x8, [x29, #56]
	ldr	x8, [sp, #256]                  // 8-byte Folded Reload
	str	x24, [x29, #48]
	mov	w24, #28                        // =0x1c
	and	x8, x8, #0xffff0000000000
	cmp	x8, x9
	ldr	x8, [sp, #352]                  // 8-byte Folded Reload
	str	x8, [x29, #40]
	cset	w8, ne
	ldr	x9, [sp, #360]                  // 8-byte Folded Reload
	str	x9, [x29, #24]
	ldr	x9, [sp, #368]                  // 8-byte Folded Reload
	str	x9, [x29, #16]
	ldp	x26, x25, [sp, #288]            // 16-byte Folded Reload
	ldr	x7, [sp, #264]                  // 8-byte Folded Reload
	ldp	x6, x5, [sp, #272]              // 16-byte Folded Reload
	ldp	x14, x13, [sp, #392]            // 16-byte Folded Reload
	ldp	x15, x9, [sp, #376]             // 16-byte Folded Reload
	str	x8, [x29, #32]
	add	sp, sp, #688
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	br	x2
.LBB71_288:
	.cfi_restore_state
	mov	x0, x20
	mov	x1, x21
	mov	w2, #1                          // =0x1
	bl	heap_alloc_miss
	ldp	x4, x18, [x29, #-240]           // 16-byte Folded Reload
	mov	x10, x0
	ldp	x3, x0, [x29, #-224]            // 16-byte Folded Reload
	mov	w1, #34047                      // =0x84ff
	ldr	x27, [sp, #424]                 // 8-byte Folded Reload
	movk	w1, #784, lsl #16
	lsr	x8, x24, #56
	ldr	x11, [sp, #408]                 // 8-byte Folded Reload
	cmp	x8, #2
	b.ne	.LBB71_278
.LBB71_289:
	mov	x0, x20
	mov	x1, x21
	mov	x2, x24
	mov	w3, #1                          // =0x1
	bl	rfc_wrap
	ldp	x4, x18, [x29, #-240]           // 16-byte Folded Reload
	mov	x24, x0
	ldp	x3, x0, [x29, #-224]            // 16-byte Folded Reload
	mov	w1, #34047                      // =0x84ff
	ldr	x27, [sp, #424]                 // 8-byte Folded Reload
	movk	w1, #784, lsl #16
	add	x8, x20, x10, lsl #3
	stp	x24, x11, [x8]
	ldr	x12, [x21, #24]
	cbnz	x12, .LBB71_279
.LBB71_290:
	mov	x0, x20
	mov	x1, x21
	mov	w2, #3                          // =0x3
	bl	heap_alloc_miss
	ldp	x4, x18, [x29, #-240]           // 16-byte Folded Reload
	mov	x12, x0
	ldp	x3, x0, [x29, #-224]            // 16-byte Folded Reload
	mov	w1, #34047                      // =0x84ff
	ldr	x27, [sp, #424]                 // 8-byte Folded Reload
	movk	w1, #784, lsl #16
	b	.LBB71_280
.LBB71_291:
	mov	x0, x20
	mov	x1, x21
	mov	w2, #1                          // =0x1
	bl	heap_alloc_miss
	ldp	x4, x18, [x29, #-240]           // 16-byte Folded Reload
	mov	x11, x0
	ldp	x3, x0, [x29, #-224]            // 16-byte Folded Reload
	mov	w1, #34047                      // =0x84ff
	ldr	x27, [sp, #424]                 // 8-byte Folded Reload
	movk	w1, #784, lsl #16
	mov	x8, #35184372088832             // =0x200000000000
	movk	x8, #512, lsl #48
	orr	x2, x10, x8
	lsr	x8, x2, #56
	cmp	x8, #2
	b.ne	.LBB71_282
.LBB71_292:
	mov	x0, x20
	mov	x1, x21
	mov	w3, #1                          // =0x1
	bl	rfc_wrap
	ldp	x4, x18, [x29, #-240]           // 16-byte Folded Reload
	mov	x2, x0
	ldp	x3, x0, [x29, #-224]            // 16-byte Folded Reload
	mov	w1, #34047                      // =0x84ff
	ldr	x27, [sp, #424]                 // 8-byte Folded Reload
	movk	w1, #784, lsl #16
	b	.LBB71_282
.LBB71_293:
	mov	x0, x20
	mov	x1, x21
	mov	x2, x8
	mov	w3, #1                          // =0x1
	bl	rfc_wrap
	ldp	x4, x18, [x29, #-240]           // 16-byte Folded Reload
	mov	x8, x0
	ldp	x3, x0, [x29, #-224]            // 16-byte Folded Reload
	mov	w1, #34047                      // =0x84ff
	ldr	x27, [sp, #424]                 // 8-byte Folded Reload
	movk	w1, #784, lsl #16
	b	.LBB71_283
.LBB71_294:
	stp	x0, x1, [sp, #408]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	mov	x10, x2
	mov	w2, #1                          // =0x1
	mov	x14, x6
	mov	x11, x4
	str	x3, [sp, #344]                  // 8-byte Folded Spill
	mov	x13, x7
	str	x5, [sp, #304]                  // 8-byte Folded Spill
	mov	x23, x30
	bl	heap_hand
	ldp	x0, x1, [sp, #408]              // 16-byte Folded Reload
	mov	w17, #34047                     // =0x84ff
	ldr	x5, [sp, #304]                  // 8-byte Folded Reload
	ldr	x3, [sp, #344]                  // 8-byte Folded Reload
	mov	x2, x10
	mov	x30, x23
	movk	w17, #784, lsl #16
	mov	x7, x13
	mov	x4, x11
	mov	x6, x14
	b	.LBB71_53
.LBB71_295:
	stp	x0, x1, [sp, #408]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	mov	x10, x2
	mov	w2, #1                          // =0x1
	mov	x14, x6
	mov	x13, x4
	mov	x24, x3
	mov	x11, x7
	str	x5, [sp, #304]                  // 8-byte Folded Spill
	mov	x23, x30
	bl	heap_hand
	ldp	x0, x1, [sp, #408]              // 16-byte Folded Reload
	mov	w17, #34047                     // =0x84ff
	ldr	x5, [sp, #304]                  // 8-byte Folded Reload
	mov	x2, x10
	mov	x30, x23
	movk	w17, #784, lsl #16
	mov	x7, x11
	mov	x3, x24
	mov	x4, x13
	mov	x6, x14
	b	.LBB71_61
.LBB71_296:
	stp	x0, x1, [sp, #408]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	mov	w2, #3                          // =0x3
	mov	x14, x6
	mov	x13, x4
	mov	x24, x3
	mov	x11, x7
	str	x5, [sp, #304]                  // 8-byte Folded Spill
	mov	x23, x30
	bl	heap_hand
	ldp	x0, x1, [sp, #408]              // 16-byte Folded Reload
	mov	x30, x23
	ldr	x5, [sp, #304]                  // 8-byte Folded Reload
	mov	x7, x11
	mov	x3, x24
	mov	x4, x13
	mov	x6, x14
	b	.LBB71_71
.LBB71_297:
	mov	x0, x20
	mov	x1, x21
	mov	w2, wzr
	bl	heap_hand
	b	.LBB71_303
.LBB71_298:
	stur	x0, [x29, #-216]                // 8-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	mov	w2, #4                          // =0x4
	mov	x11, x18
	mov	x10, x3
	str	x22, [sp, #424]                 // 8-byte Folded Spill
	mov	x22, x15
	mov	x15, x14
	mov	x14, x4
	bl	heap_hand
	mov	x4, x14
	mov	x14, x15
	mov	x15, x22
	ldr	x22, [sp, #424]                 // 8-byte Folded Reload
	ldur	x0, [x29, #-216]                // 8-byte Folded Reload
	mov	w1, #34047                      // =0x84ff
	mov	x3, x10
	mov	x18, x11
	movk	w1, #784, lsl #16
	b	.LBB71_173
.LBB71_299:
	orr	x8, x14, x11, lsl #32
	stp	x0, x1, [sp, #408]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	str	x3, [sp, #344]                  // 8-byte Folded Spill
	mov	x13, x6
	lsr	x8, x8, #24
	str	x4, [sp, #392]                  // 8-byte Folded Spill
	mov	w4, #2                          // =0x2
	mov	x14, x5
	mov	x23, x30
	add	x11, x20, x8, lsl #3
	mov	x3, x8
	ldp	x24, x10, [x11]
	mov	x11, x7
	bl	span_fade
	ldp	x0, x1, [sp, #408]              // 16-byte Folded Reload
	mov	w17, #34047                     // =0x84ff
	ldr	x3, [sp, #344]                  // 8-byte Folded Reload
	ldr	x4, [sp, #392]                  // 8-byte Folded Reload
	mov	x2, x10
	mov	x30, x23
	movk	w17, #784, lsl #16
	mov	x5, x14
	mov	x7, x11
	mov	x6, x13
	b	.LBB71_53
.LBB71_300:
	orr	x8, x14, x11, lsl #32
	stp	x0, x1, [sp, #408]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	mov	x2, x24
	str	x3, [sp, #344]                  // 8-byte Folded Spill
	lsr	x8, x8, #24
	mov	x24, x4
	mov	w4, #2                          // =0x2
	mov	x14, x7
	mov	x13, x5
	add	x11, x20, x8, lsl #3
	mov	x3, x8
	ldp	x22, x10, [x11]
	mov	x11, x6
	str	x10, [sp, #392]                 // 8-byte Folded Spill
	mov	x10, x30
	bl	span_fade
	ldp	x0, x1, [sp, #408]              // 16-byte Folded Reload
	mov	w17, #34047                     // =0x84ff
	ldr	x3, [sp, #344]                  // 8-byte Folded Reload
	mov	x30, x10
	movk	w17, #784, lsl #16
	mov	x5, x13
	mov	x7, x14
	mov	x4, x24
	mov	x6, x11
	mov	x2, x23
	b	.LBB71_61
.LBB71_301:
	mov	x0, x20
	mov	x1, x21
	str	x3, [sp, #344]                  // 8-byte Folded Spill
	mov	x3, x24
	mov	x13, x4
	mov	w4, #5                          // =0x5
	mov	x14, x6
	mov	x11, x7
	mov	x24, x5
	mov	x23, x30
	bl	span_fade
	ldp	x0, x1, [sp, #408]              // 16-byte Folded Reload
	mov	x30, x23
	ldr	x3, [sp, #344]                  // 8-byte Folded Reload
	mov	x5, x24
	mov	x7, x11
	mov	x4, x13
	mov	x6, x14
	b	.LBB71_71
.LBB71_302:
	orr	x8, x13, x11, lsl #32
	mov	x0, x20
	mov	x1, x21
	mov	x2, x9
	mov	w4, #1                          // =0x1
	lsr	x3, x8, #24
	ldr	x10, [x20, x3, lsl #3]
	bl	span_fade
.LBB71_303:
	mov	w1, #34047                      // =0x84ff
	movk	w1, #784, lsl #16
	b	.LBB71_163
.LBB71_304:
	stp	x3, x0, [x29, #-224]            // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	mov	x2, x10
	mov	x3, x11
	mov	x11, x4
	mov	w4, #15                         // =0xf
	mov	x10, x18
	bl	span_fade
	ldp	x3, x0, [x29, #-224]            // 16-byte Folded Reload
	mov	w1, #34047                      // =0x84ff
	mov	x14, x15
	mov	x15, x22
	ldr	x22, [sp, #424]                 // 8-byte Folded Reload
	mov	x4, x11
	mov	x18, x10
	movk	w1, #784, lsl #16
	b	.LBB71_173
.LBB71_305:
	stp	x0, x1, [sp, #408]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	mov	x10, x2
	mov	w2, wzr
	str	x6, [sp, #320]                  // 8-byte Folded Spill
	mov	x13, x4
	str	x3, [sp, #344]                  // 8-byte Folded Spill
	mov	x14, x7
	str	x5, [sp, #304]                  // 8-byte Folded Spill
	mov	x23, x30
	bl	heap_hand
	ldp	x0, x1, [sp, #408]              // 16-byte Folded Reload
	mov	w17, #34047                     // =0x84ff
	ldr	x5, [sp, #304]                  // 8-byte Folded Reload
	ldr	x3, [sp, #344]                  // 8-byte Folded Reload
	mov	x2, x10
	ldr	x6, [sp, #320]                  // 8-byte Folded Reload
	mov	x30, x23
	movk	w17, #784, lsl #16
	mov	x7, x14
	mov	x4, x13
	cmp	x11, x17
	b.hi	.LBB71_51
	b	.LBB71_53
.LBB71_306:
	stp	x0, x1, [sp, #408]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	mov	w2, wzr
	mov	x24, x6
	mov	x13, x4
	str	x3, [sp, #344]                  // 8-byte Folded Spill
	mov	x14, x7
	mov	x10, x30
	str	x5, [sp, #304]                  // 8-byte Folded Spill
	bl	heap_hand
	ldp	x0, x1, [sp, #408]              // 16-byte Folded Reload
	mov	w17, #34047                     // =0x84ff
	ldr	x5, [sp, #304]                  // 8-byte Folded Reload
	ldr	x3, [sp, #344]                  // 8-byte Folded Reload
	mov	x30, x10
	movk	w17, #784, lsl #16
	mov	x7, x14
	mov	x4, x13
	mov	x6, x24
	mov	x2, x23
	cmp	x11, x17
	b.hi	.LBB71_59
	b	.LBB71_61
.LBB71_307:
	mov	x0, x20
	mov	x1, x21
	mov	w2, wzr
	str	x6, [sp, #320]                  // 8-byte Folded Spill
	mov	x11, x4
	mov	x13, x7
	str	x3, [sp, #344]                  // 8-byte Folded Spill
	mov	x14, x5
	mov	x23, x30
	bl	heap_hand
	mov	w17, #34047                     // =0x84ff
	ldr	x3, [sp, #344]                  // 8-byte Folded Reload
	ldr	x6, [sp, #320]                  // 8-byte Folded Reload
	mov	x30, x23
	movk	w17, #784, lsl #16
	mov	x5, x14
	mov	x7, x13
	mov	x4, x11
	ldp	x0, x1, [sp, #408]              // 16-byte Folded Reload
	cmp	x24, x17
	b.hi	.LBB71_69
	b	.LBB71_71
.LBB71_308:
	mov	x0, x20
	mov	x1, x21
	mov	w2, wzr
	bl	heap_hand
	mov	w1, #34047                      // =0x84ff
	movk	w1, #784, lsl #16
	cmp	x9, x1
	b.hi	.LBB71_161
	b	.LBB71_163
.LBB71_309:
	stur	x0, [x29, #-216]                // 8-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	mov	w2, wzr
	stp	x4, x18, [x29, #-240]           // 16-byte Folded Spill
	mov	x10, x3
	bl	heap_hand
	ldp	x4, x18, [x29, #-240]           // 16-byte Folded Reload
	mov	w1, #34047                      // =0x84ff
	ldur	x0, [x29, #-216]                // 8-byte Folded Reload
	mov	x3, x10
	movk	w1, #784, lsl #16
	mov	x15, x22
	ldr	x22, [sp, #424]                 // 8-byte Folded Reload
	cmp	x11, x1
	b.hi	.LBB71_171
	b	.LBB71_173
.LBB71_310:
	mov	x0, x20
	mov	x1, x21
	mov	w2, #1                          // =0x1
	bl	heap_hand
	b	.LBB71_314
.LBB71_311:
	mov	x0, x20
	mov	x1, x21
	mov	w2, #1                          // =0x1
	bl	heap_hand
	b	.LBB71_316
.LBB71_312:
	mov	x0, x20
	mov	x1, x21
	mov	w2, #3                          // =0x3
	bl	heap_hand
	ldp	x4, x18, [x29, #-240]           // 16-byte Folded Reload
	mov	w1, #34047                      // =0x84ff
	ldp	x3, x0, [x29, #-224]            // 16-byte Folded Reload
	movk	w1, #784, lsl #16
	ldr	x27, [sp, #424]                 // 8-byte Folded Reload
	b	.LBB71_200
.LBB71_313:
	orr	x8, x13, x11, lsl #32
	mov	x0, x20
	mov	x1, x21
	mov	x2, x9
	mov	w4, #2                          // =0x2
	lsr	x3, x8, #24
	add	x8, x20, x3, lsl #3
	ldp	x11, x10, [x8]
	bl	span_fade
.LBB71_314:
	ldp	x4, x18, [x29, #-240]           // 16-byte Folded Reload
	mov	w1, #34047                      // =0x84ff
	ldp	x3, x0, [x29, #-224]            // 16-byte Folded Reload
	movk	w1, #784, lsl #16
	ldr	x27, [sp, #424]                 // 8-byte Folded Reload
	b	.LBB71_183
.LBB71_315:
	orr	x8, x16, x13, lsl #32
	mov	x0, x20
	mov	x1, x21
	mov	x2, x11
	mov	w4, #2                          // =0x2
	lsr	x3, x8, #24
	ldr	x9, [x20, x3, lsl #3]
	bl	span_fade
.LBB71_316:
	ldp	x4, x18, [x29, #-240]           // 16-byte Folded Reload
	mov	w1, #34047                      // =0x84ff
	ldp	x3, x0, [x29, #-224]            // 16-byte Folded Reload
	movk	w1, #784, lsl #16
	ldr	x27, [sp, #424]                 // 8-byte Folded Reload
	b	.LBB71_191
.LBB71_317:
	orr	x8, x13, x11, lsl #32
	mov	x0, x20
	mov	x1, x21
	mov	x2, x10
	mov	w4, #5                          // =0x5
	lsr	x3, x8, #24
	bl	span_fade
	ldp	x3, x0, [x29, #-224]            // 16-byte Folded Reload
	mov	w1, #34047                      // =0x84ff
	ldp	x4, x18, [x29, #-240]           // 16-byte Folded Reload
	movk	w1, #784, lsl #16
	ldr	x27, [sp, #424]                 // 8-byte Folded Reload
	b	.LBB71_200
.LBB71_318:
	mov	x0, x20
	mov	x1, x21
	mov	w2, wzr
	bl	heap_hand
	ldp	x4, x18, [x29, #-240]           // 16-byte Folded Reload
	mov	w1, #34047                      // =0x84ff
	ldp	x3, x0, [x29, #-224]            // 16-byte Folded Reload
	movk	w1, #784, lsl #16
	ldr	x27, [sp, #424]                 // 8-byte Folded Reload
	cmp	x9, x1
	b.hi	.LBB71_181
	b	.LBB71_183
.LBB71_319:
	mov	x0, x20
	mov	x1, x21
	mov	w2, wzr
	bl	heap_hand
	ldp	x4, x18, [x29, #-240]           // 16-byte Folded Reload
	mov	w1, #34047                      // =0x84ff
	ldp	x3, x0, [x29, #-224]            // 16-byte Folded Reload
	movk	w1, #784, lsl #16
	ldr	x27, [sp, #424]                 // 8-byte Folded Reload
	cmp	x11, x1
	b.hi	.LBB71_189
	b	.LBB71_191
.LBB71_320:
	mov	x0, x20
	mov	x1, x21
	mov	w2, wzr
	bl	heap_hand
	mov	w1, #34047                      // =0x84ff
	movk	w1, #784, lsl #16
	b	.LBB71_196
.Lfunc_end71:
