WL_FID____BENDVY_WRITE_ROW_FOLD_V2_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_WRITEFOLD_MOTION_LOOP_0: // @WL_FID____BENDVY_WRITE_ROW_FOLD_V2_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_WRITEFOLD_MOTION_LOOP_0
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #224
	.cfi_def_cfa_offset 224
	stp	x29, x30, [sp, #208]            // 16-byte Folded Spill
	add	x29, sp, #208
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	mov	x30, x11
	ldp	x11, x8, [x29, #88]
	stp	x5, x13, [x29, #-24]            // 16-byte Folded Spill
	mov	x18, x12
	mov	x19, x7
	stp	x3, x8, [x29, #-40]             // 16-byte Folded Spill
	mov	x3, x1
	mov	x1, x0
	ldp	x5, x8, [x29, #72]
	mov	x0, x28
	ldp	x2, x12, [x29, #56]
	ldp	x13, x7, [x29, #40]
	mov	x24, x9
	ldp	x28, x16, [x29, #24]
	stur	x8, [x29, #-48]                 // 8-byte Folded Spill
	and	x8, x25, #0xffff0000000000
	mov	x9, #15393162788864             // =0xe0000000000
	ldr	x17, [x29, #16]
	cmp	x8, x9
	b.ne	.LBB70_2
// %bb.1:
	ldr	w8, [x22, #-8]!
	adrp	x9, wl_tab
	add	x9, x9, :lo12:wl_tab
	mov	x25, x2
	ldr	x2, [x9, x8, lsl #3]
	ldur	x8, [x29, #-48]                 // 8-byte Folded Reload
	stp	x12, x5, [x29, #56]
	mov	w5, w6
	mov	w9, w15
	mov	w15, w17
	stp	x8, x11, [x29, #72]
	ldur	x8, [x29, #-32]                 // 8-byte Folded Reload
	mov	x6, x19
	mov	w8, w8
	stp	x8, x11, [x29, #88]
	mov	w8, w25
	mov	w25, w26
	str	x8, [x29, #48]
	mov	w8, w7
	mov	w26, w27
	str	x8, [x29, #40]
	mov	w8, w13
	mov	x27, x0
	mov	x0, x3
	mov	x3, x4
	str	x8, [x29, #32]
	ldp	x4, x12, [x29, #-24]            // 16-byte Folded Reload
	mov	w7, w10
	mov	w8, w28
	mov	w10, w16
	mov	x28, x1
	ldur	x1, [x29, #-40]                 // 8-byte Folded Reload
	mov	w11, w18
	mov	w13, w14
	mov	w14, w24
	stp	x8, x10, [x29, #16]
	mov	w24, #28                        // =0x1c
	mov	x10, x30
	.cfi_def_cfa wsp, 224
	ldp	x29, x30, [sp, #208]            // 16-byte Folded Reload
	add	sp, sp, #224
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	br	x2
.LBB70_2:
	.cfi_restore_state
	.cfi_remember_state
	and	x8, x25, #0xffffffffff
	stp	x30, x13, [x29, #-96]           // 16-byte Folded Spill
	add	x13, x20, x8, lsl #3
	stur	w23, [x29, #-100]               // 4-byte Folded Spill
	stp	x16, x7, [x29, #-64]            // 16-byte Folded Spill
	stp	x28, x6, [x29, #-80]            // 16-byte Folded Spill
	tbnz	x25, #63, .LBB70_5
// %bb.3:
	ldp	x28, x7, [x13]
	mov	x9, x8
	mov	x30, x19
.LBB70_4:
	mov	x19, x24
	b	.LBB70_9
.LBB70_5:
	stp	x17, x12, [sp, #72]             // 16-byte Folded Spill
	mov	x12, x18
	mov	x23, x3
	str	x10, [sp, #88]                  // 8-byte Folded Spill
	mov	x10, x4
	mov	x30, x19
	ldr	w9, [x13, #4]
	ldr	w16, [x13]
	and	x17, x16, #0xffffff
	cmp	x17, #1
	b.ne	.LBB70_11
// %bb.6:
	orr	x9, x16, x9, lsl #32
	ldar	wzr, [x13]
	ldr	x13, [x21]
	mov	x19, x24
	lsr	x9, x9, #24
	add	x16, x20, x9, lsl #3
	ldp	x28, x7, [x16]
	str	x13, [x20, x8, lsl #3]
	ldr	x13, [x21, #256]
	str	x8, [x21]
	add	x8, x13, #1
	adrp	x13, .L_MergedGlobals
	str	x8, [x21, #256]
	ldrb	w13, [x13, :lo12:.L_MergedGlobals]
	cmp	w13, #1
	b.ne	.LBB70_12
// %bb.7:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB70_12
// %bb.8:
	mov	x4, x10
	mov	x18, x12
	ldr	x17, [sp, #72]                  // 8-byte Folded Reload
	ldp	x12, x10, [sp, #80]             // 16-byte Folded Reload
	mov	x3, x23
.LBB70_9:
	mov	x24, x15
	and	x8, x28, #0xffffffffff
	mov	w13, #34047                     // =0x84ff
	ldur	x6, [x29, #-56]                 // 8-byte Folded Reload
	add	x16, x20, x8, lsl #3
	movk	w13, #784, lsl #16
	tbnz	x28, #63, .LBB70_13
.LBB70_10:
	ldr	w25, [x16]
	ldr	w15, [x16, #8]
	mov	x28, x8
	str	x15, [sp, #96]                  // 8-byte Folded Spill
	cmp	x8, x13
	b.hi	.LBB70_17
	b	.LBB70_19
.LBB70_11:
	orr	x8, x16, x9, lsl #32
	stp	x0, x1, [sp, #24]               // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	str	x2, [sp, #96]                   // 8-byte Folded Spill
	mov	x2, x25
	lsr	x3, x8, #24
	mov	w4, #2                          // =0x2
	str	x14, [sp, #64]                  // 8-byte Folded Spill
	mov	x13, x30
	str	x5, [sp, #48]                   // 8-byte Folded Spill
	add	x8, x20, x3, lsl #3
	ldp	x28, x9, [x8]
	bl	span_fade
	ldp	x0, x1, [sp, #24]               // 16-byte Folded Reload
	mov	x4, x10
	ldp	x14, x17, [sp, #64]             // 16-byte Folded Reload
	mov	x18, x12
	ldp	x10, x2, [sp, #88]              // 16-byte Folded Reload
	mov	x7, x9
	ldr	x5, [sp, #48]                   // 8-byte Folded Reload
	ldr	x12, [sp, #80]                  // 8-byte Folded Reload
	mov	x30, x13
	mov	x9, xzr
	mov	x3, x23
	b	.LBB70_4
.LBB70_12:
	stp	x0, x1, [sp, #24]               // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	str	x2, [sp, #96]                   // 8-byte Folded Spill
	mov	w2, wzr
	mov	x13, x7
	stp	x15, x30, [sp, #8]              // 16-byte Folded Spill
	str	x14, [sp, #64]                  // 8-byte Folded Spill
	str	x5, [sp, #48]                   // 8-byte Folded Spill
	bl	heap_hand
	ldp	x0, x1, [sp, #24]               // 16-byte Folded Reload
	mov	x4, x10
	ldp	x14, x17, [sp, #64]             // 16-byte Folded Reload
	mov	x18, x12
	ldp	x24, x30, [sp, #8]              // 16-byte Folded Reload
	mov	x7, x13
	ldp	x10, x2, [sp, #88]              // 16-byte Folded Reload
	mov	x3, x23
	ldr	x5, [sp, #48]                   // 8-byte Folded Reload
	ldr	x12, [sp, #80]                  // 8-byte Folded Reload
	and	x8, x28, #0xffffffffff
	mov	w13, #34047                     // =0x84ff
	ldur	x6, [x29, #-56]                 // 8-byte Folded Reload
	add	x16, x20, x8, lsl #3
	movk	w13, #784, lsl #16
	tbz	x28, #63, .LBB70_10
.LBB70_13:
	stp	x17, x12, [sp, #72]             // 16-byte Folded Spill
	mov	x15, x3
	stp	x5, x18, [sp, #48]              // 16-byte Folded Spill
	str	x10, [sp, #88]                  // 8-byte Folded Spill
	mov	x10, x24
	mov	x24, x30
	str	x14, [sp, #64]                  // 8-byte Folded Spill
	str	x19, [sp, #40]                  // 8-byte Folded Spill
	mov	x19, x4
	ldr	w17, [x16, #4]
	ldr	w18, [x16]
	and	x25, x18, #0xffffff
	cmp	x25, #1
	b.ne	.LBB70_31
// %bb.14:
	orr	x17, x18, x17, lsl #32
	ldar	wzr, [x16]
	ldr	x16, [x21]
	lsr	x28, x17, #24
	add	x17, x20, x28, lsl #3
	ldr	w25, [x17]
	ldr	w12, [x17, #8]
	str	x16, [x20, x8, lsl #3]
	ldr	x16, [x21, #256]
	str	x8, [x21]
	str	x12, [sp, #96]                  // 8-byte Folded Spill
	add	x8, x16, #1
	adrp	x16, .L_MergedGlobals
	str	x8, [x21, #256]
	ldrb	w16, [x16, :lo12:.L_MergedGlobals]
	cmp	w16, #1
	b.ne	.LBB70_34
// %bb.15:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB70_34
.LBB70_16:
	mov	x30, x24
	mov	x24, x10
	mov	x4, x19
	ldp	x19, x5, [sp, #40]              // 16-byte Folded Reload
	ldr	x17, [sp, #72]                  // 8-byte Folded Reload
	ldp	x18, x14, [sp, #56]             // 16-byte Folded Reload
	ldur	x6, [x29, #-56]                 // 8-byte Folded Reload
	ldp	x12, x10, [sp, #80]             // 16-byte Folded Reload
	mov	x3, x15
	cmp	x28, x13
	b.ls	.LBB70_19
.LBB70_17:
	ldr	x8, [x21, #8]
	adrp	x16, .L_MergedGlobals
	str	x8, [x20, x28, lsl #3]
	ldr	x8, [x21, #264]
	str	x28, [x21, #8]
	add	x8, x8, #2
	str	x8, [x21, #264]
	ldrb	w16, [x16, :lo12:.L_MergedGlobals]
	cmp	w16, #1
	b.ne	.LBB70_30
// %bb.18:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB70_30
.LBB70_19:
	ldur	x28, [x29, #-64]                // 8-byte Folded Reload
	cmp	x9, x13
	b.ls	.LBB70_22
// %bb.20:
	ldr	x8, [x21, #8]
	adrp	x13, .L_MergedGlobals
	str	x8, [x20, x9, lsl #3]
	ldr	x8, [x21, #264]
	str	x9, [x21, #8]
	add	x8, x8, #2
	str	x8, [x21, #264]
	ldrb	w13, [x13, :lo12:.L_MergedGlobals]
	cmp	w13, #1
	b.ne	.LBB70_24
// %bb.21:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB70_24
.LBB70_22:
	ldur	w23, [x29, #-100]               // 4-byte Folded Reload
	cbz	w23, .LBB70_25
.LBB70_23:
	mov	w8, #50                         // =0x32
	mov	w16, w24
	mov	w13, w18
	stp	x7, x8, [x22], #16
	stp	x12, x5, [x29, #72]
	mov	x5, x4
	ldp	x8, x4, [x29, #-48]             // 16-byte Folded Reload
	stp	x8, x11, [x29, #88]
	ldur	x8, [x29, #-32]                 // 8-byte Folded Reload
	mov	w11, w10
	mov	w15, w19
	mov	x10, x30
	mov	w8, w8
	str	x8, [x29, #104]
	ldp	x12, x8, [x29, #-96]            // 16-byte Folded Reload
	mov	w8, w8
	str	x8, [x29, #48]
	mov	w8, w28
	mov	w28, w27
	str	x8, [x29, #40]
	ldp	x8, x9, [x29, #-80]             // 16-byte Folded Reload
	mov	w8, w8
	mov	w7, w9
	mov	w9, w14
	str	x8, [x29, #32]
	mov	w8, w17
	str	x8, [x29, #24]
	ldp	x6, x14, [x29, #-24]            // 16-byte Folded Reload
	mov	w8, w26
	ldr	x26, [sp, #96]                  // 8-byte Folded Reload
	mov	x27, x8
	str	x16, [x29, #16]
	.cfi_def_cfa wsp, 224
	ldp	x29, x30, [sp, #208]            // 16-byte Folded Reload
	add	sp, sp, #224
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	WL_FID____BENDVY_WRITE_ROW_FOLD_V2_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_WRITEFOLD_MOTION_STEP_0
.LBB70_24:
	.cfi_restore_state
	.cfi_remember_state
	stp	x0, x1, [sp, #24]               // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	mov	x28, x2
	mov	w2, #1                          // =0x1
	stp	x24, x30, [sp, #8]              // 16-byte Folded Spill
	stp	x5, x18, [sp, #48]              // 16-byte Folded Spill
	mov	x15, x19
	mov	x19, x4
	stp	x14, x17, [sp, #64]             // 16-byte Folded Spill
	mov	x24, x3
	mov	x9, x7
	bl	heap_hand
	mov	x2, x28
	ldp	x0, x1, [sp, #24]               // 16-byte Folded Reload
	ldp	x28, x6, [x29, #-64]            // 16-byte Folded Reload
	mov	x3, x24
	ldp	x14, x17, [sp, #64]             // 16-byte Folded Reload
	mov	x7, x9
	ldp	x5, x18, [sp, #48]              // 16-byte Folded Reload
	mov	x4, x19
	ldp	x24, x30, [sp, #8]              // 16-byte Folded Reload
	mov	x19, x15
	ldur	w23, [x29, #-100]               // 4-byte Folded Reload
	cbnz	w23, .LBB70_23
.LBB70_25:
	ldp	x9, x13, [x22, #-24]
	mov	x15, x0
	ldr	x0, [x21, #40]
	mov	x23, x17
	cbz	x0, .LBB70_32
// %bb.26:
	ldr	x8, [x20, x0, lsl #3]
	ldr	x16, [x21, #296]
	str	x8, [x21, #40]
	sub	x8, x16, #32
	str	x8, [x21, #296]
.LBB70_27:
	mov	w16, #1                         // =0x1
	add	x8, x20, x0, lsl #3
	movi	v0.2d, #0xffffffffffffffff
	orr	x13, x16, x13, lsl #32
	str	x7, [x8]
	stp	x9, x13, [x8, #232]
	mov	x9, #54975581388800             // =0x320000000000
	movk	x9, #1280, lsl #48
	stur	q0, [x8, #216]
	orr	x9, x0, x9
	stur	q0, [x8, #200]
	stur	q0, [x8, #184]
	stur	q0, [x8, #168]
	stur	q0, [x8, #152]
	stur	q0, [x8, #136]
	stur	q0, [x8, #120]
	stur	q0, [x8, #104]
	stur	q0, [x8, #88]
	stur	q0, [x8, #72]
	stur	q0, [x8, #56]
	stur	q0, [x8, #40]
	stur	q0, [x8, #24]
	stur	q0, [x8, #8]
	stp	x9, x16, [x22, #-24]
	ldr	x0, [x21, #40]
	cbz	x0, .LBB70_33
// %bb.28:
	ldr	x8, [x20, x0, lsl #3]
	ldr	x13, [x21, #296]
	ldur	x16, [x29, #-96]                // 8-byte Folded Reload
	str	x8, [x21, #40]
	sub	x8, x13, #32
	str	x8, [x21, #296]
.LBB70_29:
	add	x8, x20, x0, lsl #3
	mov	x13, #4294967296                // =0x100000000
	stp	x9, x13, [x8, #240]
	ldr	x9, [sp, #96]                   // 8-byte Folded Reload
	mov	w13, w27
	stp	x15, x1, [x8, #32]
	stp	x25, x9, [x8]
	mov	w9, w26
	stp	x9, x13, [x8, #16]
	ldur	x9, [x29, #-40]                 // 8-byte Folded Reload
	stp	x3, x9, [x8, #48]
	ldur	x9, [x29, #-24]                 // 8-byte Folded Reload
	stp	x4, x9, [x8, #64]
	ldur	x9, [x29, #-72]                 // 8-byte Folded Reload
	mov	w9, w9
	stp	x9, x30, [x8, #80]
	mov	w9, w10
	mov	w10, w19
	stp	x9, x16, [x8, #96]
	mov	w9, w18
	str	x9, [x8, #112]
	ldur	x9, [x29, #-16]                 // 8-byte Folded Reload
	str	x9, [x8, #120]
	mov	w9, w14
	stp	x9, x10, [x8, #128]
	mov	w9, w24
	mov	w10, w23
	stp	x9, x10, [x8, #144]
	ldur	x9, [x29, #-80]                 // 8-byte Folded Reload
	mov	w10, w28
	mov	w9, w9
	stp	x9, x10, [x8, #160]
	ldur	x9, [x29, #-88]                 // 8-byte Folded Reload
	mov	w10, w6
	mov	w9, w9
	stp	x9, x10, [x8, #176]
	mov	w9, w2
	stp	x9, x12, [x8, #192]
	ldur	x9, [x29, #-48]                 // 8-byte Folded Reload
	stp	x5, x9, [x8, #208]
	mov	x9, #48378511622144             // =0x2c0000000000
	movk	x9, #1280, lsl #48
	orr	x0, x0, x9
	ldur	x9, [x29, #-32]                 // 8-byte Folded Reload
	mov	w9, w9
	stp	x11, x9, [x8, #224]
	.cfi_def_cfa wsp, 224
	ldp	x29, x30, [sp, #208]            // 16-byte Folded Reload
	add	sp, sp, #224
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB70_30:
	.cfi_restore_state
	stp	x0, x1, [sp, #24]               // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	stp	x26, x24, [sp]                  // 16-byte Folded Spill
	mov	x26, x2
	mov	w2, #1                          // =0x1
	str	x30, [sp, #16]                  // 8-byte Folded Spill
	mov	x15, x19
	mov	x19, x4
	stp	x18, x14, [sp, #56]             // 16-byte Folded Spill
	mov	x24, x3
	stp	x12, x10, [sp, #80]             // 16-byte Folded Spill
	mov	x12, x5
	mov	x10, x7
	str	x17, [sp, #72]                  // 8-byte Folded Spill
	bl	heap_hand
	mov	x2, x26
	ldp	x0, x1, [sp, #24]               // 16-byte Folded Reload
	mov	x5, x12
	mov	x3, x24
	mov	x7, x10
	ldp	x17, x12, [sp, #72]             // 16-byte Folded Reload
	ldur	x6, [x29, #-56]                 // 8-byte Folded Reload
	ldp	x18, x14, [sp, #56]             // 16-byte Folded Reload
	ldr	x10, [sp, #88]                  // 8-byte Folded Reload
	ldp	x26, x24, [sp]                  // 16-byte Folded Reload
	mov	x4, x19
	ldr	x30, [sp, #16]                  // 8-byte Folded Reload
	mov	x19, x15
	b	.LBB70_19
.LBB70_31:
	orr	x8, x18, x17, lsl #32
	stp	x0, x1, [sp, #24]               // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	str	x26, [sp]                       // 8-byte Folded Spill
	mov	x26, x2
	lsr	x3, x8, #24
	mov	x2, x28
	mov	w4, #2                          // =0x2
	mov	x12, x7
	add	x8, x20, x3, lsl #3
	ldr	w25, [x8]
	ldr	w8, [x8, #8]
	str	x8, [sp, #96]                   // 8-byte Folded Spill
	bl	span_fade
	mov	x7, x12
	ldp	x0, x1, [sp, #24]               // 16-byte Folded Reload
	mov	x30, x24
	mov	x24, x10
	mov	x4, x19
	ldp	x19, x5, [sp, #40]              // 16-byte Folded Reload
	mov	x2, x26
	ldp	x18, x14, [sp, #56]             // 16-byte Folded Reload
	ldr	x26, [sp]                       // 8-byte Folded Reload
	ldp	x12, x10, [sp, #80]             // 16-byte Folded Reload
	ldr	x17, [sp, #72]                  // 8-byte Folded Reload
	ldur	x6, [x29, #-56]                 // 8-byte Folded Reload
	mov	x3, x15
	b	.LBB70_19
.LBB70_32:
	mov	x0, x20
	stp	x1, x19, [sp, #32]              // 16-byte Folded Spill
	mov	x1, x21
	stp	x26, x24, [sp]                  // 16-byte Folded Spill
	mov	x26, x2
	mov	w2, #5                          // =0x5
	str	x30, [sp, #16]                  // 8-byte Folded Spill
	mov	x19, x4
	stp	x18, x14, [sp, #56]             // 16-byte Folded Spill
	stp	x12, x10, [sp, #80]             // 16-byte Folded Spill
	mov	x12, x3
	mov	x10, x7
	str	x5, [sp, #48]                   // 8-byte Folded Spill
	bl	heap_alloc_miss
	mov	x7, x10
	mov	x2, x26
	mov	x3, x12
	ldp	x26, x24, [sp]                  // 16-byte Folded Reload
	mov	x4, x19
	ldp	x12, x10, [sp, #80]             // 16-byte Folded Reload
	ldur	x6, [x29, #-56]                 // 8-byte Folded Reload
	ldp	x19, x5, [sp, #40]              // 16-byte Folded Reload
	ldr	x1, [sp, #32]                   // 8-byte Folded Reload
	ldp	x18, x14, [sp, #56]             // 16-byte Folded Reload
	ldr	x30, [sp, #16]                  // 8-byte Folded Reload
	b	.LBB70_27
.LBB70_33:
	mov	x0, x20
	str	x1, [sp, #32]                   // 8-byte Folded Spill
	mov	x1, x21
	mov	x21, x2
	mov	w2, #5                          // =0x5
	str	x30, [sp, #16]                  // 8-byte Folded Spill
	mov	x28, x4
	stp	x18, x14, [sp, #56]             // 16-byte Folded Spill
	mov	x22, x5
	stp	x12, x10, [sp, #80]             // 16-byte Folded Spill
	mov	x10, x3
	bl	heap_alloc_miss
	mov	x3, x10
	ldp	x12, x10, [sp, #80]             // 16-byte Folded Reload
	ldp	x18, x14, [sp, #56]             // 16-byte Folded Reload
	mov	x4, x28
	ldp	x28, x6, [x29, #-64]            // 16-byte Folded Reload
	mov	x2, x21
	ldr	x1, [sp, #32]                   // 8-byte Folded Reload
	ldur	x16, [x29, #-96]                // 8-byte Folded Reload
	mov	x5, x22
	ldr	x30, [sp, #16]                  // 8-byte Folded Reload
	b	.LBB70_29
.LBB70_34:
	stp	x0, x1, [sp, #24]               // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	str	x26, [sp]                       // 8-byte Folded Spill
	mov	x26, x2
	mov	w2, wzr
	mov	x12, x7
	bl	heap_hand
	ldp	x0, x1, [sp, #24]               // 16-byte Folded Reload
	mov	x2, x26
	ldr	x26, [sp]                       // 8-byte Folded Reload
	mov	x7, x12
	b	.LBB70_16
.Lfunc_end70:
