WL_FID____BENDVY_ROW_OWNER_SPLIT_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_MOTION_ROW_0: // @WL_FID____BENDVY_ROW_OWNER_SPLIT_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_MOTION_ROW_0
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	sub	sp, sp, #576
	ldp	x18, x8, [x29, #72]
	ldr	x17, [x29, #16]
	ldp	x19, x16, [x29, #40]
	ldp	x24, x30, [x29, #56]
	stur	x8, [x29, #-176]                // 8-byte Folded Spill
	ldp	x8, x2, [x29, #24]
	cmp	w25, w19
	stur	x8, [x29, #-168]                // 8-byte Folded Spill
	b.ne	.LBB71_23
// %bb.1:
	mov	w11, w11
	cmp	x11, #1
	b.ne	.LBB71_25
// %bb.2:
	and	x11, x27, #0xffffffffff
	stur	x26, [x29, #-240]               // 8-byte Folded Spill
	mov	x8, x11
	tbnz	x27, #63, .LBB71_33
// %bb.3:
	mov	x26, x24
	stur	x11, [x29, #-256]               // 8-byte Folded Spill
	and	x11, x28, #0xffffffffff
	stur	x22, [x29, #-224]               // 8-byte Folded Spill
	stur	w23, [x29, #-216]               // 4-byte Folded Spill
	tbnz	x28, #63, .LBB71_34
.LBB71_4:
	mov	x24, x30
	stur	x10, [x29, #-208]               // 8-byte Folded Spill
	str	x11, [sp, #256]                 // 8-byte Folded Spill
	and	x11, x0, #0xffffffffff
	str	x11, [sp, #304]                 // 8-byte Folded Spill
	tbnz	x0, #63, .LBB71_35
.LBB71_5:
	and	x30, x1, #0xffffffffff
	str	x30, [sp, #288]                 // 8-byte Folded Spill
	tbnz	x1, #63, .LBB71_36
.LBB71_6:
	ldur	x10, [x29, #-208]               // 8-byte Folded Reload
	stur	x9, [x29, #-232]                // 8-byte Folded Spill
	and	x9, x3, #0xffffffffff
	mov	x30, x24
	tbnz	x3, #63, .LBB71_37
.LBB71_7:
	str	x9, [sp, #264]                  // 8-byte Folded Spill
	and	x9, x4, #0xffffffffff
	mov	x24, x26
	ldur	w23, [x29, #-216]               // 4-byte Folded Reload
	ldur	x22, [x29, #-224]               // 8-byte Folded Reload
	stur	x13, [x29, #-192]               // 8-byte Folded Spill
	tbz	x4, #63, .LBB71_9
// %bb.8:
	ldr	xzr, [x20, x9, lsl #3]
.LBB71_9:
	cmp	w16, w7
	str	x9, [sp, #248]                  // 8-byte Folded Spill
	stur	x16, [x29, #-200]               // 8-byte Folded Spill
	b.hi	.LBB71_31
// %bb.10:
	mov	x13, x16
	sub	w16, w13, #1
	cmp	w16, w5
	b.hs	.LBB71_31
// %bb.11:
	lsr	x16, x0, #40
	stur	x17, [x29, #-184]               // 8-byte Folded Spill
	mov	w17, #-1                        // =0xffffffff
	stur	x27, [x29, #-248]               // 8-byte Folded Spill
	add	x11, x20, x11, lsl #3
	stp	x18, x28, [sp, #272]            // 16-byte Folded Spill
	mov	w18, #2147483647                // =0x7fffffff
	lsl	w17, w17, w16
	add	w16, w13, w18
	ldr	x18, [sp, #272]                 // 8-byte Folded Reload
	ldur	x27, [x29, #-248]               // 8-byte Folded Reload
	bic	w17, w16, w17
	ldr	w11, [x11, w17, uxtw #2]
	ldur	x17, [x29, #-184]               // 8-byte Folded Reload
	cbz	w11, .LBB71_31
// %bb.12:
	ubfx	x11, x27, #40, #5
	mov	x17, #-1                        // =0xffffffffffffffff
	str	x2, [sp, #240]                  // 8-byte Folded Spill
	ldur	x27, [x29, #-248]               // 8-byte Folded Reload
	mov	x9, x12
	sub	w11, w11, #1
	lsl	x13, x17, x11
	bic	w11, w16, w13
	lsl	w11, w11, #1
	add	x11, x20, w11, uxtw #3
	add	x11, x11, x8, lsl #3
	ldr	x2, [x11, #8]
	ldr	w8, [x11]
	stp	xzr, xzr, [x11]
	tbz	x2, #63, .LBB71_20
// %bb.13:
	cmp	x2, x27
	b.eq	.LBB71_20
// %bb.14:
	cmp	x2, x28
	b.eq	.LBB71_20
// %bb.15:
	cmp	x2, x0
	b.eq	.LBB71_20
// %bb.16:
	cmp	x2, x1
	b.eq	.LBB71_20
// %bb.17:
	cmp	x2, x4
	b.eq	.LBB71_20
// %bb.18:
	cmp	x2, x3
	b.eq	.LBB71_20
// %bb.19:
	and	x11, x2, #0xffffffffff
	ldr	xzr, [x20, x11, lsl #3]
.LBB71_20:
	ldur	x17, [x29, #-184]               // 8-byte Folded Reload
	mov	w5, w5
	mov	w7, w7
	mov	x12, x9
	cbz	x8, .LBB71_42
// %bb.21:
	and	x8, x2, #0xffffffffff
	mov	x22, x13
	mov	w13, #34047                     // =0x84ff
	add	x16, x20, x8, lsl #3
	movk	w13, #784, lsl #16
	stp	x5, x4, [sp, #176]              // 16-byte Folded Spill
	stp	x7, x30, [sp, #192]             // 16-byte Folded Spill
	stp	x1, x3, [sp, #224]              // 16-byte Folded Spill
	stp	x6, x0, [sp, #208]              // 16-byte Folded Spill
	tbnz	x2, #63, .LBB71_47
// %bb.22:
	ldp	x11, x27, [x16]
	mov	x19, x8
	ldur	x26, [x29, #-240]               // 8-byte Folded Reload
	cmp	x8, x13
	b.hi	.LBB71_51
	b	.LBB71_53
.LBB71_23:
	cbz	w23, .LBB71_28
// %bb.24:
	ldur	x8, [x29, #-176]                // 8-byte Folded Reload
	mov	w25, w25
	mov	w26, w26
	mov	w5, w5
	mov	w7, w7
	mov	w11, w11
	b	.LBB71_27
.LBB71_25:
	cbz	w23, .LBB71_38
// %bb.26:
	ldur	x8, [x29, #-176]                // 8-byte Folded Reload
	mov	w25, w25
	mov	w26, w26
	mov	w5, w5
	mov	w7, w7
.LBB71_27:
	stp	x18, x8, [x29, #72]
	mov	w8, w16
	mov	w16, w19
	mov	w13, w13
	stp	x16, x8, [x29, #40]
	ldur	x16, [x29, #-168]               // 8-byte Folded Reload
	mov	w8, w2
	mov	w14, w14
	mov	w9, w9
	mov	w15, w15
	mov	w16, w16
	stp	x24, x30, [x29, #56]
	stp	x16, x8, [x29, #24]
	mov	w8, w17
	str	x8, [x29, #16]
	add	sp, sp, #576
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	WL_FID____BENDVY_ROW_OWNER_SPLIT_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_1
.LBB71_28:
	.cfi_restore_state
	.cfi_remember_state
	ldp	x23, x22, [x22, #-24]
	ldr	x8, [x21, #40]
	stp	x16, x13, [x29, #-200]          // 16-byte Folded Spill
	mov	x13, x24
	mov	x24, x9
	mov	x9, x18
	stur	x17, [x29, #-184]               // 8-byte Folded Spill
	cbz	x8, .LBB71_121
// %bb.29:
	ldr	x16, [x20, x8, lsl #3]
	ldr	x17, [x21, #296]
	str	x16, [x21, #40]
	sub	x16, x17, #32
	str	x16, [x21, #296]
.LBB71_30:
	add	x16, x20, x8, lsl #3
	lsl	x17, x22, #32
	mov	w18, w25
	mov	w11, w11
	b	.LBB71_41
.LBB71_31:
	mov	w5, w5
	mov	w7, w7
	ldur	x9, [x29, #-232]                // 8-byte Folded Reload
	cbz	w23, .LBB71_43
.LBB71_32:
	ldur	x8, [x29, #-176]                // 8-byte Folded Reload
	mov	x16, x15
	mov	w25, w25
	stp	x24, x30, [x29, #56]
	mov	w14, w14
	mov	w9, w9
	stp	x18, x8, [x29, #72]
	ldur	x8, [x29, #-240]                // 8-byte Folded Reload
	mov	w15, w16
	mov	w26, w8
	ldp	x8, x11, [x29, #-200]           // 16-byte Folded Reload
	mov	w13, w11
	mov	w8, w8
	mov	w11, w19
	stp	x11, x8, [x29, #40]
	ldur	x11, [x29, #-168]               // 8-byte Folded Reload
	mov	w8, w2
	mov	w11, w11
	stp	x11, x8, [x29, #24]
	mov	w8, w17
	mov	w11, #1                         // =0x1
	str	x8, [x29, #16]
	add	sp, sp, #576
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	WL_FID____BENDVY_ROW_OWNER_SPLIT_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_1
.LBB71_33:
	.cfi_restore_state
	.cfi_remember_state
	ldr	x8, [x20, x11, lsl #3]
	lsr	x8, x8, #24
	mov	x26, x24
	stur	x11, [x29, #-256]               // 8-byte Folded Spill
	and	x11, x28, #0xffffffffff
	stur	x22, [x29, #-224]               // 8-byte Folded Spill
	stur	w23, [x29, #-216]               // 4-byte Folded Spill
	tbz	x28, #63, .LBB71_4
.LBB71_34:
	ldr	xzr, [x20, x11, lsl #3]
	mov	x24, x30
	stur	x10, [x29, #-208]               // 8-byte Folded Spill
	str	x11, [sp, #256]                 // 8-byte Folded Spill
	and	x11, x0, #0xffffffffff
	str	x11, [sp, #304]                 // 8-byte Folded Spill
	tbz	x0, #63, .LBB71_5
.LBB71_35:
	ldr	x11, [sp, #304]                 // 8-byte Folded Reload
	ldr	x11, [x20, x11, lsl #3]
	lsr	x11, x11, #24
	and	x30, x1, #0xffffffffff
	str	x30, [sp, #288]                 // 8-byte Folded Spill
	tbz	x1, #63, .LBB71_6
.LBB71_36:
	ldr	x30, [sp, #288]                 // 8-byte Folded Reload
	ldr	xzr, [x20, x30, lsl #3]
	ldur	x10, [x29, #-208]               // 8-byte Folded Reload
	stur	x9, [x29, #-232]                // 8-byte Folded Spill
	and	x9, x3, #0xffffffffff
	mov	x30, x24
	tbz	x3, #63, .LBB71_7
.LBB71_37:
	ldr	xzr, [x20, x9, lsl #3]
	b	.LBB71_7
.LBB71_38:
	ldp	x23, x22, [x22, #-24]
	ldr	x8, [x21, #40]
	stp	x16, x13, [x29, #-200]          // 16-byte Folded Spill
	mov	x13, x24
	mov	x24, x9
	mov	x9, x18
	stur	x17, [x29, #-184]               // 8-byte Folded Spill
	cbz	x8, .LBB71_122
// %bb.39:
	ldr	x16, [x20, x8, lsl #3]
	ldr	x17, [x21, #296]
	str	x16, [x21, #40]
	sub	x16, x17, #32
	str	x16, [x21, #296]
.LBB71_40:
	add	x16, x20, x8, lsl #3
	lsl	x17, x22, #32
	mov	w18, w25
.LBB71_41:
	stp	x23, x17, [x16, #216]
	mov	w17, w26
	stp	x18, x17, [x16]
	mov	w17, w5
	stp	x17, x6, [x16, #64]
	mov	w17, w7
	stp	x27, x28, [x16, #16]
	stp	x0, x1, [x16, #32]
	stp	x3, x4, [x16, #48]
	stp	x17, x10, [x16, #80]
	ldur	x21, [x29, #-168]               // 8-byte Folded Reload
	mov	x18, x9
	mov	x9, x24
	mov	x24, x13
	b	.LBB71_46
.LBB71_42:
	ldr	x2, [sp, #240]                  // 8-byte Folded Reload
	ldur	x9, [x29, #-232]                // 8-byte Folded Reload
	cbnz	w23, .LBB71_32
.LBB71_43:
	ldp	x11, x23, [x22, #-24]
	mov	x13, x25
	ldr	x8, [x21, #40]
	stur	x17, [x29, #-184]               // 8-byte Folded Spill
	cbz	x8, .LBB71_123
// %bb.44:
	ldr	x16, [x20, x8, lsl #3]
	ldr	x17, [x21, #296]
	str	x16, [x21, #40]
	sub	x16, x17, #32
	str	x16, [x21, #296]
.LBB71_45:
	add	x16, x20, x8, lsl #3
	lsl	x17, x23, #32
	ldur	x21, [x29, #-168]               // 8-byte Folded Reload
	stp	x11, x17, [x16, #216]
	mov	w11, w13
	ldur	x13, [x29, #-240]               // 8-byte Folded Reload
	stp	x27, x28, [x16, #16]
	mov	w17, w13
	stp	x0, x1, [x16, #32]
	stp	x11, x17, [x16]
	mov	w11, #1                         // =0x1
	stp	x3, x4, [x16, #48]
	stp	x5, x6, [x16, #64]
	stp	x7, x10, [x16, #80]
.LBB71_46:
	ldur	x10, [x29, #-192]               // 8-byte Folded Reload
	stp	x11, x12, [x16, #96]
	mov	w11, w14
	mov	w9, w9
	stp	x30, x18, [x16, #192]
	mov	w10, w10
	stp	x10, x11, [x16, #112]
	mov	w10, w15
	stp	x9, x10, [x16, #128]
	ldur	x9, [x29, #-184]                // 8-byte Folded Reload
	mov	w10, w21
	mov	w9, w9
	stp	x9, x10, [x16, #144]
	mov	w9, w2
	mov	w10, w19
	stp	x9, x10, [x16, #160]
	ldur	x9, [x29, #-200]                // 8-byte Folded Reload
	mov	w9, w9
	stp	x9, x24, [x16, #176]
	mov	x9, #42880953483264             // =0x270000000000
	movk	x9, #1280, lsl #48
	orr	x0, x8, x9
	ldur	x8, [x29, #-176]                // 8-byte Folded Reload
	str	x8, [x16, #208]
	add	sp, sp, #576
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB71_47:
	.cfi_restore_state
	.cfi_remember_state
	ldr	w11, [x16, #4]
	ldr	w17, [x16]
	ldur	x26, [x29, #-240]               // 8-byte Folded Reload
	and	x18, x17, #0xffffff
	cmp	x18, #1
	b.ne	.LBB71_133
// %bb.48:
	orr	x11, x17, x11, lsl #32
	ldar	wzr, [x16]
	ldr	x16, [x21]
	lsr	x19, x11, #24
	add	x17, x20, x19, lsl #3
	ldp	x11, x27, [x17]
	str	x16, [x20, x8, lsl #3]
	ldr	x16, [x21, #256]
	str	x8, [x21]
	add	x8, x16, #1
	adrp	x16, .L_MergedGlobals
	str	x8, [x21, #256]
	ldrb	w16, [x16, :lo12:.L_MergedGlobals]
	cmp	w16, #1
	b.ne	.LBB71_139
// %bb.49:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB71_139
// %bb.50:
	mov	x12, x9
	cmp	x19, x13
	b.ls	.LBB71_53
.LBB71_51:
	ldr	x8, [x21, #8]
	adrp	x16, .L_MergedGlobals
	str	x8, [x20, x19, lsl #3]
	ldr	x8, [x21, #264]
	str	x19, [x21, #8]
	add	x8, x8, #2
	str	x8, [x21, #264]
	ldrb	w16, [x16, :lo12:.L_MergedGlobals]
	cmp	w16, #1
	b.ne	.LBB71_130
// %bb.52:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB71_130
.LBB71_53:
	and	x8, x11, #0xffffffffff
	add	x16, x20, x8, lsl #3
	tbnz	x11, #63, .LBB71_55
// %bb.54:
	ldp	x23, x28, [x16]
	mov	x11, x8
	cmp	x8, x13
	b.hi	.LBB71_59
	b	.LBB71_61
.LBB71_55:
	ldr	w17, [x16, #4]
	ldr	w18, [x16]
	and	x19, x18, #0xffffff
	cmp	x19, #1
	b.ne	.LBB71_135
// %bb.56:
	orr	x11, x18, x17, lsl #32
	ldar	wzr, [x16]
	ldr	x16, [x21]
	lsr	x11, x11, #24
	add	x17, x20, x11, lsl #3
	ldp	x23, x28, [x17]
	str	x16, [x20, x8, lsl #3]
	ldr	x16, [x21, #256]
	str	x8, [x21]
	add	x8, x16, #1
	adrp	x16, .L_MergedGlobals
	str	x8, [x21, #256]
	ldrb	w16, [x16, :lo12:.L_MergedGlobals]
	cmp	w16, #1
	b.ne	.LBB71_140
// %bb.57:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB71_140
// %bb.58:
	mov	x12, x9
	cmp	x11, x13
	b.ls	.LBB71_61
.LBB71_59:
	ldr	x8, [x21, #8]
	adrp	x16, .L_MergedGlobals
	str	x8, [x20, x11, lsl #3]
	ldr	x8, [x21, #264]
	str	x11, [x21, #8]
	add	x8, x8, #2
	str	x8, [x21, #264]
	ldrb	w16, [x16, :lo12:.L_MergedGlobals]
	cmp	w16, #1
	b.ne	.LBB71_131
// %bb.60:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB71_131
.LBB71_61:
	and	x8, x27, #0xffffffffff
	add	x16, x20, x8, lsl #3
	tbnz	x27, #63, .LBB71_63
// %bb.62:
	ldp	x27, x7, [x16]
	mov	x11, x8
	ldp	x5, x19, [x16, #16]
	ldr	x18, [x16, #32]
	cmp	x8, x13
	b.hi	.LBB71_69
	b	.LBB71_71
.LBB71_63:
	ldr	w11, [x16, #4]
	ldr	w18, [x16]
	mov	x2, x27
	and	x17, x18, #0xffffff
	cmp	x17, #1
	b.ne	.LBB71_65
// %bb.64:
	ldar	wzr, [x16]
.LBB71_65:
	orr	x11, x18, x11, lsl #32
	cmp	x17, #1
	lsr	x11, x11, #24
	add	x18, x20, x11, lsl #3
	ldp	x27, x7, [x18]
	ldp	x5, x19, [x18, #16]
	ldr	x18, [x18, #32]
	b.ne	.LBB71_137
// %bb.66:
	ldr	x17, [x21]
	str	x17, [x16]
	ldr	x16, [x21, #256]
	str	x8, [x21]
	add	x8, x16, #1
	adrp	x16, .L_MergedGlobals
	str	x8, [x21, #256]
	ldrb	w16, [x16, :lo12:.L_MergedGlobals]
	cmp	w16, #1
	b.ne	.LBB71_141
// %bb.67:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB71_141
// %bb.68:
	mov	x12, x9
	cmp	x11, x13
	b.ls	.LBB71_71
.LBB71_69:
	ldr	x8, [x21, #24]
	adrp	x16, .L_MergedGlobals
	str	x8, [x20, x11, lsl #3]
	ldr	x8, [x21, #280]
	str	x11, [x21, #24]
	add	x8, x8, #8
	str	x8, [x21, #280]
	ldrb	w16, [x16, :lo12:.L_MergedGlobals]
	cmp	w16, #1
	b.ne	.LBB71_132
// %bb.70:
	cmp	x8, #8, lsl #12                 // =32768
	b.hs	.LBB71_132
.LBB71_71:
	and	x8, x23, #0xffffffffff
	tbnz	x23, #63, .LBB71_76
// %bb.72:
	and	x11, x12, #0xffffffffff
	tbnz	x12, #63, .LBB71_77
.LBB71_73:
	ldur	x12, [x29, #-176]               // 8-byte Folded Reload
	and	x16, x24, #0xffffffffff
	tbnz	x24, #63, .LBB71_78
.LBB71_74:
	and	x17, x12, #0xffffffffff
	tbnz	x12, #63, .LBB71_79
.LBB71_75:
	cmp	x23, x12
	mov	x4, x17
	b.ne	.LBB71_80
	b	.LBB71_82
.LBB71_76:
	ldr	x8, [x20, x8, lsl #3]
	lsr	x8, x8, #24
	and	x11, x12, #0xffffffffff
	tbz	x12, #63, .LBB71_73
.LBB71_77:
	ldr	x11, [x20, x11, lsl #3]
	lsr	x11, x11, #24
	ldur	x12, [x29, #-176]               // 8-byte Folded Reload
	and	x16, x24, #0xffffffffff
	tbz	x24, #63, .LBB71_74
.LBB71_78:
	ldr	x16, [x20, x16, lsl #3]
	lsr	x16, x16, #24
	and	x17, x12, #0xffffffffff
	tbz	x12, #63, .LBB71_75
.LBB71_79:
	ldr	x17, [x20, x17, lsl #3]
	lsr	x17, x17, #24
	cmp	x23, x12
	mov	x4, x17
	b.eq	.LBB71_82
.LBB71_80:
	cmp	x23, x24
	mov	x4, x16
	b.eq	.LBB71_82
// %bb.81:
	cmp	x23, x9
	csel	x4, x11, x8, eq
.LBB71_82:
	cmp	x9, x24
	str	w19, [sp, #168]
	sub	x2, x29, #160
	str	w5, [sp, #160]
	csel	x8, x16, x11, eq
	cmp	x9, x12
	str	w7, [sp, #152]
	csel	x8, x17, x8, eq
	cmp	x24, x12
	str	w27, [sp, #144]
	csel	x10, x17, x16, eq
	mov	x0, x20
	str	wzr, [sp, #136]
	mov	x1, x21
	mov	x3, x23
	stp	x12, x17, [sp, #120]
	mov	w6, w27
                                        // kill: def $w7 killed $w7 killed $x7
	ldur	x11, [x29, #-200]               // 8-byte Folded Reload
	str	w25, [sp, #88]
	str	w11, [sp, #96]
	ldur	x11, [x29, #-168]               // 8-byte Folded Reload
	str	w11, [sp, #80]
	ldur	x11, [x29, #-184]               // 8-byte Folded Reload
	str	w15, [sp, #64]
	str	w11, [sp, #72]
	ldur	x11, [x29, #-232]               // 8-byte Folded Reload
	str	w14, [sp, #48]
	str	w11, [sp, #56]
	ldur	x11, [x29, #-192]               // 8-byte Folded Reload
	str	w5, [sp]
	mov	w5, w28
	str	w18, [sp, #16]
	str	w11, [sp, #40]
	str	w19, [sp, #8]
	stp	x24, x10, [sp, #104]
	stp	x9, x8, [sp, #24]
	bl	spin_76
	ldur	w8, [x29, #-72]
	ldp	q1, q2, [x29, #-144]
	ldp	x14, x27, [x29, #-40]
	ldur	x11, [x29, #-160]
	stur	x8, [x29, #-176]                // 8-byte Folded Spill
	ldur	w8, [x29, #-64]
	ldur	w23, [x29, #-152]
	ldur	w2, [x29, #-112]
	ldur	x12, [x29, #-104]
	ldur	w13, [x29, #-96]
	stur	x8, [x29, #-184]                // 8-byte Folded Spill
	ldur	w8, [x29, #-56]
	ldur	w30, [x29, #-88]
	ldur	w24, [x29, #-80]
	ldur	x15, [x29, #-24]
	stur	x8, [x29, #-192]                // 8-byte Folded Spill
	ldur	w8, [x29, #-48]
	stur	x8, [x29, #-200]                // 8-byte Folded Spill
	ldur	w8, [x29, #-16]
	stur	x8, [x29, #-240]                // 8-byte Folded Spill
	tbz	x11, #63, .LBB71_84
// %bb.83:
	and	x8, x11, #0xffffffffff
	ldr	xzr, [x20, x8, lsl #3]
.LBB71_84:
	ldp	x1, x3, [sp, #224]              // 16-byte Folded Reload
	ldur	x10, [x29, #-208]               // 8-byte Folded Reload
	ldp	x18, x28, [sp, #272]            // 16-byte Folded Reload
	ldr	x4, [sp, #184]                  // 8-byte Folded Reload
	ldr	x0, [sp, #216]                  // 8-byte Folded Reload
	ldr	x17, [sp, #200]                 // 8-byte Folded Reload
	ldr	x9, [sp, #264]                  // 8-byte Folded Reload
	tbnz	x12, #63, .LBB71_109
// %bb.85:
	ldr	x6, [sp, #208]                  // 8-byte Folded Reload
	ldr	x5, [sp, #176]                  // 8-byte Folded Reload
	ldr	x7, [sp, #192]                  // 8-byte Folded Reload
	tbnz	x27, #63, .LBB71_110
.LBB71_86:
	tbnz	x15, #63, .LBB71_111
.LBB71_87:
	ldur	x8, [x29, #-248]                // 8-byte Folded Reload
	tbnz	x8, #63, .LBB71_112
.LBB71_88:
	tbnz	x28, #63, .LBB71_113
.LBB71_89:
	tbnz	x0, #63, .LBB71_114
.LBB71_90:
	tbnz	x1, #63, .LBB71_115
.LBB71_91:
	tbnz	x3, #63, .LBB71_116
.LBB71_92:
	tbnz	x4, #63, .LBB71_117
.LBB71_93:
	tbnz	x10, #63, .LBB71_118
.LBB71_94:
	tbnz	x17, #63, .LBB71_119
.LBB71_95:
	mvn	w8, w22
	stur	x15, [x29, #-232]               // 8-byte Folded Spill
	tbnz	x18, #63, .LBB71_120
.LBB71_96:
	sub	w9, w14, #1
	ldr	x22, [x21, #8]
	and	w8, w9, w8
	ldur	x9, [x29, #-256]                // 8-byte Folded Reload
	lsl	w15, w8, #1
	add	x8, x20, w15, uxtw #3
	add	x19, x8, x9, lsl #3
	ldr	x9, [x19, #8]
	cbz	x22, .LBB71_124
// %bb.97:
	ldr	x8, [x20, x22, lsl #3]
	ldr	x16, [x21, #264]
	str	x8, [x21, #8]
	sub	x8, x16, #2
	str	x8, [x21, #264]
	lsr	x8, x11, #56
	cmp	x8, #2
	b.eq	.LBB71_125
.LBB71_98:
	add	x8, x20, x22, lsl #3
	stp	x11, x23, [x8]
	ldr	x23, [x21, #24]
	cbz	x23, .LBB71_126
.LBB71_99:
	ldr	x8, [x20, x23, lsl #3]
	ldr	x11, [x21, #280]
	str	x8, [x21, #24]
	sub	x8, x11, #8
	str	x8, [x21, #280]
.LBB71_100:
	movi	v0.2d, #0x000000ffffffff
	add	x8, x20, x23, lsl #3
	str	x2, [x8, #32]
	and	v1.16b, v1.16b, v0.16b
	and	v0.16b, v2.16b, v0.16b
	stp	q1, q0, [x8]
	ldr	x11, [x21, #8]
	cbz	x11, .LBB71_127
// %bb.101:
	ldr	x8, [x20, x11, lsl #3]
	ldr	x16, [x21, #264]
	str	x8, [x21, #8]
	sub	x8, x16, #2
	str	x8, [x21, #264]
.LBB71_102:
	mov	x8, #35184372088832             // =0x200000000000
	stur	x24, [x29, #-168]               // 8-byte Folded Spill
	movk	x8, #512, lsl #48
	orr	x2, x22, x8
	lsr	x8, x2, #56
	cmp	x8, #2
	b.eq	.LBB71_128
.LBB71_103:
	mov	x8, #36283883716608             // =0x210000000000
	add	x22, x20, x11, lsl #3
	mov	w24, w14
	movk	x8, #512, lsl #48
	orr	x8, x23, x8
	str	x2, [x22]
	lsr	x16, x8, #56
	cmp	x16, #2
	b.eq	.LBB71_129
.LBB71_104:
	orr	w14, w15, #0x1
	mov	x15, #34084860461056            // =0x1f0000000000
	str	x8, [x22, #8]
	add	x16, x20, w14, uxtw #3
	mov	w14, #34047                     // =0x84ff
	mov	w8, #1                          // =0x1
	movk	w14, #784, lsl #16
	movk	x15, #512, lsl #48
	and	x22, x9, #0xffffffff00
	add	x14, x14, #1
	str	x8, [x19]
	orr	x8, x11, x15
	ldur	x11, [x29, #-256]               // 8-byte Folded Reload
	cmp	x22, x14
	str	x8, [x16, x11, lsl #3]
	b.lo	.LBB71_108
// %bb.105:
	cmn	x9, #1
	b.eq	.LBB71_108
// %bb.106:
	and	x8, x9, #0x7e00000000000000
	cbz	x8, .LBB71_108
// %bb.107:
	mov	x0, x20
	mov	x1, x21
	mov	x2, x9
	mov	x19, x12
	mov	x22, x13
	mov	x23, x30
	bl	term_drop
	ldp	x7, x17, [sp, #192]             // 16-byte Folded Reload
	mov	x30, x23
	ldp	x5, x4, [sp, #176]              // 16-byte Folded Reload
	mov	x13, x22
	ldp	x18, x28, [sp, #272]            // 16-byte Folded Reload
	mov	x12, x19
	ldp	x0, x1, [sp, #216]              // 16-byte Folded Reload
	ldr	x3, [sp, #232]                  // 8-byte Folded Reload
	ldr	x6, [sp, #208]                  // 8-byte Folded Reload
	ldur	x10, [x29, #-208]               // 8-byte Folded Reload
.LBB71_108:
	ldur	x22, [x29, #-224]               // 8-byte Folded Reload
	adrp	x9, wl_tab
	add	x9, x9, :lo12:wl_tab
	ldur	w23, [x29, #-216]               // 4-byte Folded Reload
	mov	w25, w25
	mov	w26, w26
	ldr	w8, [x22, #-8]!
	mov	x14, x30
	ldr	x2, [x9, x8, lsl #3]
	ldp	x9, x8, [x29, #-240]            // 16-byte Folded Reload
	stp	x17, x18, [x29, #64]
	stp	x24, x27, [x29, #48]
	ldur	x27, [x29, #-248]               // 8-byte Folded Reload
	mov	w24, #28                        // =0x1c
	stp	x8, x9, [x29, #80]
	ldp	x8, x11, [x29, #-200]           // 16-byte Folded Reload
	ldp	x9, x15, [x29, #-184]           // 16-byte Folded Reload
	str	x8, [x29, #40]
	ldr	x8, [sp, #240]                  // 8-byte Folded Reload
	stp	x9, x11, [x29, #16]
	ldur	x9, [x29, #-168]                // 8-byte Folded Reload
	mov	w11, #1                         // =0x1
	mov	w8, w8
	str	x8, [x29, #32]
	add	sp, sp, #576
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	br	x2
.LBB71_109:
	.cfi_restore_state
	and	x8, x12, #0xffffffffff
	ldr	xzr, [x20, x8, lsl #3]
	ldr	x6, [sp, #208]                  // 8-byte Folded Reload
	ldr	x5, [sp, #176]                  // 8-byte Folded Reload
	ldr	x7, [sp, #192]                  // 8-byte Folded Reload
	tbz	x27, #63, .LBB71_86
.LBB71_110:
	and	x8, x27, #0xffffffffff
	ldr	xzr, [x20, x8, lsl #3]
	tbz	x15, #63, .LBB71_87
.LBB71_111:
	and	x8, x15, #0xffffffffff
	ldr	xzr, [x20, x8, lsl #3]
	ldur	x8, [x29, #-248]                // 8-byte Folded Reload
	tbz	x8, #63, .LBB71_88
.LBB71_112:
	ldur	x8, [x29, #-256]                // 8-byte Folded Reload
	ldr	x8, [x20, x8, lsl #3]
	lsr	x8, x8, #24
	stur	x8, [x29, #-256]                // 8-byte Folded Spill
	tbz	x28, #63, .LBB71_89
.LBB71_113:
	ldr	x8, [sp, #256]                  // 8-byte Folded Reload
	ldr	xzr, [x20, x8, lsl #3]
	tbz	x0, #63, .LBB71_90
.LBB71_114:
	ldr	x8, [sp, #304]                  // 8-byte Folded Reload
	ldr	xzr, [x20, x8, lsl #3]
	tbz	x1, #63, .LBB71_91
.LBB71_115:
	ldr	x8, [sp, #288]                  // 8-byte Folded Reload
	ldr	xzr, [x20, x8, lsl #3]
	tbz	x3, #63, .LBB71_92
.LBB71_116:
	ldr	xzr, [x20, x9, lsl #3]
	tbz	x4, #63, .LBB71_93
.LBB71_117:
	ldr	x8, [sp, #248]                  // 8-byte Folded Reload
	ldr	xzr, [x20, x8, lsl #3]
	tbz	x10, #63, .LBB71_94
.LBB71_118:
	and	x8, x10, #0xffffffffff
	ldr	xzr, [x20, x8, lsl #3]
	tbz	x17, #63, .LBB71_95
.LBB71_119:
	and	x8, x17, #0xffffffffff
	ldr	xzr, [x20, x8, lsl #3]
	mvn	w8, w22
	stur	x15, [x29, #-232]               // 8-byte Folded Spill
	tbz	x18, #63, .LBB71_96
.LBB71_120:
	and	x9, x18, #0xffffffffff
	ldr	xzr, [x20, x9, lsl #3]
	b	.LBB71_96
.LBB71_121:
	stp	x0, x1, [sp, #216]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	stp	x3, x2, [sp, #232]              // 16-byte Folded Spill
	mov	w2, #5                          // =0x5
	mov	x21, x4
	str	x6, [sp, #208]                  // 8-byte Folded Spill
	stp	x7, x5, [x29, #-224]            // 16-byte Folded Spill
	str	x30, [sp, #200]                 // 8-byte Folded Spill
	bl	heap_alloc_miss
	ldp	x30, x6, [sp, #200]             // 16-byte Folded Reload
	mov	x8, x0
	ldp	x3, x2, [sp, #232]              // 16-byte Folded Reload
	mov	x4, x21
	ldp	x7, x5, [x29, #-224]            // 16-byte Folded Reload
	ldp	x0, x1, [sp, #216]              // 16-byte Folded Reload
	b	.LBB71_30
.LBB71_122:
	stp	x0, x1, [sp, #216]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	stp	x3, x2, [sp, #232]              // 16-byte Folded Spill
	mov	w2, #5                          // =0x5
	mov	x21, x4
	str	x6, [sp, #208]                  // 8-byte Folded Spill
	stp	x7, x5, [x29, #-224]            // 16-byte Folded Spill
	str	x30, [sp, #200]                 // 8-byte Folded Spill
	bl	heap_alloc_miss
	ldp	x30, x6, [sp, #200]             // 16-byte Folded Reload
	mov	x8, x0
	ldp	x3, x2, [sp, #232]              // 16-byte Folded Reload
	mov	x4, x21
	ldp	x7, x5, [x29, #-224]            // 16-byte Folded Reload
	ldp	x0, x1, [sp, #216]              // 16-byte Folded Reload
	b	.LBB71_40
.LBB71_123:
	stp	x0, x1, [sp, #216]              // 16-byte Folded Spill
	mov	x0, x20
	mov	x1, x21
	stp	x3, x2, [sp, #232]              // 16-byte Folded Spill
	mov	w2, #5                          // =0x5
	mov	x21, x4
	str	x6, [sp, #208]                  // 8-byte Folded Spill
	mov	x24, x30
	mov	x9, x18
	mov	x25, x5
	str	x7, [sp, #192]                  // 8-byte Folded Spill
	bl	heap_alloc_miss
	ldp	x3, x2, [sp, #232]              // 16-byte Folded Reload
	mov	x8, x0
	ldp	x0, x1, [sp, #216]              // 16-byte Folded Reload
	mov	x18, x9
	ldur	x10, [x29, #-208]               // 8-byte Folded Reload
	ldr	x7, [sp, #192]                  // 8-byte Folded Reload
	mov	x5, x25
	ldur	x9, [x29, #-232]                // 8-byte Folded Reload
	ldr	x6, [sp, #208]                  // 8-byte Folded Reload
	mov	x30, x24
	mov	x24, x26
	mov	x4, x21
	b	.LBB71_45
.LBB71_124:
	mov	x0, x20
	mov	x1, x21
	mov	x28, x2
	mov	w2, #1                          // =0x1
	mov	x22, x30
	stp	q1, q2, [sp, #288]              // 32-byte Folded Spill
	bl	heap_alloc_miss
	ldp	q1, q2, [sp, #288]              // 32-byte Folded Reload
	mov	x2, x28
	mov	x30, x22
	ldp	x7, x17, [sp, #192]             // 16-byte Folded Reload
	ldp	x5, x4, [sp, #176]              // 16-byte Folded Reload
	mov	x22, x0
	ldp	x18, x28, [sp, #272]            // 16-byte Folded Reload
	ldp	x1, x3, [sp, #224]              // 16-byte Folded Reload
	ldp	x6, x0, [sp, #208]              // 16-byte Folded Reload
	lsr	x8, x11, #56
	cmp	x8, #2
	b.ne	.LBB71_98
.LBB71_125:
	mov	x0, x20
	mov	x1, x21
	mov	x28, x2
	mov	x2, x11
	mov	w3, #1                          // =0x1
	mov	x11, x30
	stp	q1, q2, [sp, #288]              // 32-byte Folded Spill
	bl	rfc_wrap
	ldp	q1, q2, [sp, #288]              // 32-byte Folded Reload
	mov	x2, x28
	mov	x30, x11
	ldp	x7, x17, [sp, #192]             // 16-byte Folded Reload
	ldp	x5, x4, [sp, #176]              // 16-byte Folded Reload
	mov	x11, x0
	ldp	x18, x28, [sp, #272]            // 16-byte Folded Reload
	ldp	x1, x3, [sp, #224]              // 16-byte Folded Reload
	ldp	x6, x0, [sp, #208]              // 16-byte Folded Reload
	add	x8, x20, x22, lsl #3
	stp	x11, x23, [x8]
	ldr	x23, [x21, #24]
	cbnz	x23, .LBB71_99
.LBB71_126:
	mov	x0, x20
	mov	x1, x21
	mov	x23, x2
	mov	w2, #3                          // =0x3
	mov	x11, x30
	stp	q1, q2, [sp, #288]              // 32-byte Folded Spill
	bl	heap_alloc_miss
	ldp	q1, q2, [sp, #288]              // 32-byte Folded Reload
	mov	x2, x23
	ldp	x7, x17, [sp, #192]             // 16-byte Folded Reload
	mov	x23, x0
	ldp	x5, x4, [sp, #176]              // 16-byte Folded Reload
	mov	x30, x11
	ldp	x18, x28, [sp, #272]            // 16-byte Folded Reload
	ldp	x1, x3, [sp, #224]              // 16-byte Folded Reload
	ldp	x6, x0, [sp, #208]              // 16-byte Folded Reload
	b	.LBB71_100
.LBB71_127:
	mov	x0, x20
	mov	x1, x21
	mov	w2, #1                          // =0x1
	mov	x11, x30
	bl	heap_alloc_miss
	mov	x30, x11
	ldp	x7, x17, [sp, #192]             // 16-byte Folded Reload
	ldp	x5, x4, [sp, #176]              // 16-byte Folded Reload
	mov	x11, x0
	ldp	x18, x28, [sp, #272]            // 16-byte Folded Reload
	ldp	x1, x3, [sp, #224]              // 16-byte Folded Reload
	ldp	x6, x0, [sp, #208]              // 16-byte Folded Reload
	b	.LBB71_102
.LBB71_128:
	mov	x0, x20
	mov	x1, x21
	mov	w3, #1                          // =0x1
	mov	x22, x30
	bl	rfc_wrap
	ldp	x7, x17, [sp, #192]             // 16-byte Folded Reload
	mov	x2, x0
	ldp	x5, x4, [sp, #176]              // 16-byte Folded Reload
	mov	x30, x22
	ldp	x18, x28, [sp, #272]            // 16-byte Folded Reload
	ldp	x1, x3, [sp, #224]              // 16-byte Folded Reload
	ldp	x6, x0, [sp, #208]              // 16-byte Folded Reload
	b	.LBB71_103
.LBB71_129:
	mov	x0, x20
	mov	x1, x21
	mov	x2, x8
	mov	w3, #1                          // =0x1
	mov	x14, x30
	bl	rfc_wrap
	ldp	x7, x17, [sp, #192]             // 16-byte Folded Reload
	mov	x8, x0
	ldp	x5, x4, [sp, #176]              // 16-byte Folded Reload
	mov	x30, x14
	ldp	x18, x28, [sp, #272]            // 16-byte Folded Reload
	ldp	x1, x3, [sp, #224]              // 16-byte Folded Reload
	ldp	x6, x0, [sp, #208]              // 16-byte Folded Reload
	b	.LBB71_104
.LBB71_130:
	mov	x0, x20
	mov	x1, x21
	mov	w2, #1                          // =0x1
	bl	heap_hand
	b	.LBB71_134
.LBB71_131:
	mov	x0, x20
	mov	x1, x21
	mov	w2, #1                          // =0x1
	bl	heap_hand
	b	.LBB71_136
.LBB71_132:
	mov	x0, x20
	mov	x1, x21
	mov	w2, #3                          // =0x3
	mov	x10, x7
	mov	x12, x5
	mov	x13, x18
	bl	heap_hand
	b	.LBB71_138
.LBB71_133:
	orr	x8, x17, x11, lsl #32
	mov	x0, x20
	mov	x1, x21
	mov	w4, #2                          // =0x2
	lsr	x8, x8, #24
	add	x16, x20, x8, lsl #3
	mov	x3, x8
	ldp	x11, x27, [x16]
	bl	span_fade
.LBB71_134:
	mov	x12, x9
	b	.LBB71_53
.LBB71_135:
	orr	x8, x18, x17, lsl #32
	mov	x0, x20
	mov	x1, x21
	mov	x2, x11
	mov	w4, #2                          // =0x2
	lsr	x8, x8, #24
	add	x16, x20, x8, lsl #3
	mov	x3, x8
	ldp	x23, x28, [x16]
	bl	span_fade
.LBB71_136:
	mov	x12, x9
	b	.LBB71_61
.LBB71_137:
	mov	x0, x20
	mov	x1, x21
	mov	x3, x11
	mov	w4, #5                          // =0x5
	mov	x10, x7
	mov	x12, x5
	mov	x13, x18
	bl	span_fade
.LBB71_138:
	mov	x18, x13
	mov	x5, x12
	mov	x7, x10
	mov	x12, x9
	b	.LBB71_71
.LBB71_139:
	mov	x0, x20
	mov	x1, x21
	mov	w2, wzr
	bl	heap_hand
	mov	x12, x9
	cmp	x19, x13
	b.hi	.LBB71_51
	b	.LBB71_53
.LBB71_140:
	mov	x0, x20
	mov	x1, x21
	mov	w2, wzr
	bl	heap_hand
	mov	x12, x9
	cmp	x11, x13
	b.hi	.LBB71_59
	b	.LBB71_61
.LBB71_141:
	mov	x0, x20
	mov	x1, x21
	mov	w2, wzr
	mov	x10, x7
	mov	x12, x5
	stur	x18, [x29, #-240]               // 8-byte Folded Spill
	bl	heap_hand
	ldur	x18, [x29, #-240]               // 8-byte Folded Reload
	mov	x5, x12
	mov	x7, x10
	mov	x12, x9
	cmp	x11, x13
	b.hi	.LBB71_69
	b	.LBB71_71
.Lfunc_end71:
