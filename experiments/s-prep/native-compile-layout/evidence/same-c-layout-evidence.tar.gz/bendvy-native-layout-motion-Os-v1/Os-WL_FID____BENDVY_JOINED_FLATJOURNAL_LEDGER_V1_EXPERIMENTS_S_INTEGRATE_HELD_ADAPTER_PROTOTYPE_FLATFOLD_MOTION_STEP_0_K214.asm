   1a17c:	d103c3ff 	sub	sp, sp, #0xf0
   1a180:	a90e7bfd 	stp	x29, x30, [sp, #224]
   1a184:	910383fd 	add	x29, sp, #0xe0
   1a188:	a941fbb3 	ldp	x19, x30, [x29, #24]
   1a18c:	f81f03ac 	stur	x12, [x29, #-16]
   1a190:	a944cbb0 	ldp	x16, x18, [x29, #72]
   1a194:	a9438ba8 	ldp	x8, x2, [x29, #56]
   1a198:	a93e2bb3 	stp	x19, x10, [x29, #-32]
   1a19c:	f9400bb3 	ldr	x19, [x29, #16]
   1a1a0:	a942c7b8 	ldp	x24, x17, [x29, #40]
   1a1a4:	f81d83b3 	stur	x19, [x29, #-40]
   1a1a8:	b85f82d3 	ldur	w19, [x22, #-8]
   1a1ac:	34000437 	cbz	w23, 1a230 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K214+0xb4>
   1a1b0:	aa1c03ea 	mov	x10, x28
   1a1b4:	aa0803fc 	mov	x28, x8
   1a1b8:	528007c8 	mov	w8, #0x3e                  	// #62
   1a1bc:	a93fa2d3 	stp	x19, x8, [x22, #-8]
   1a1c0:	2a1103e8 	mov	w8, w17
   1a1c4:	2a1903ec 	mov	w12, w25
   1a1c8:	a904cbb0 	stp	x16, x18, [x29, #72]
   1a1cc:	2a1803f0 	mov	w16, w24
   1a1d0:	aa0c03f9 	mov	x25, x12
   1a1d4:	a902a3b0 	stp	x16, x8, [x29, #40]
   1a1d8:	f85e03b0 	ldur	x16, [x29, #-32]
   1a1dc:	2a1e03e8 	mov	w8, w30
   1a1e0:	a9038bbc 	stp	x28, x2, [x29, #56]
   1a1e4:	aa0a03fc 	mov	x28, x10
   1a1e8:	2a1a03fa 	mov	w26, w26
   1a1ec:	2a1003f0 	mov	w16, w16
   1a1f0:	a97eb3aa 	ldp	x10, x12, [x29, #-24]
   1a1f4:	a901a3b0 	stp	x16, x8, [x29, #24]
   1a1f8:	f85d83a8 	ldur	x8, [x29, #-40]
   1a1fc:	2a0503e5 	mov	w5, w5
   1a200:	2a0703e7 	mov	w7, w7
   1a204:	2a0b03eb 	mov	w11, w11
   1a208:	2a0d03ed 	mov	w13, w13
   1a20c:	2a0803e8 	mov	w8, w8
   1a210:	2a0e03ee 	mov	w14, w14
   1a214:	2a0903e9 	mov	w9, w9
   1a218:	2a0f03ef 	mov	w15, w15
   1a21c:	910022d6 	add	x22, x22, #0x8
   1a220:	f9000ba8 	str	x8, [x29, #16]
   1a224:	a94e7bfd 	ldp	x29, x30, [sp, #224]
   1a228:	9103c3ff 	add	sp, sp, #0xf0
   1a22c:	17fff126 	b	166c4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0>
   1a230:	f81a03b4 	stur	x20, [x29, #-96]
   1a234:	f94016b7 	ldr	x23, [x21, #40]
   1a238:	a9009fe5 	stp	x5, x7, [sp, #8]
   1a23c:	f81a83bb 	stur	x27, [x29, #-88]
   1a240:	f9000feb 	str	x11, [sp, #24]
   1a244:	f81b03bc 	stur	x28, [x29, #-80]
   1a248:	a90207e0 	stp	x0, x1, [sp, #32]
   1a24c:	a9030fed 	stp	x13, x3, [sp, #48]
   1a250:	f81b83be 	stur	x30, [x29, #-72]
   1a254:	f90023e4 	str	x4, [sp, #64]
   1a258:	f81c03b8 	stur	x24, [x29, #-64]
   1a25c:	a97e62db 	ldp	x27, x24, [x22, #-32]
   1a260:	a904c7ee 	stp	x14, x17, [sp, #72]
   1a264:	a905c3e6 	stp	x6, x16, [sp, #88]
   1a268:	f9003be9 	str	x9, [sp, #112]
   1a26c:	f81983b2 	stur	x18, [x29, #-104]
   1a270:	a93cbfa8 	stp	x8, x15, [x29, #-56]
   1a274:	f90037e2 	str	x2, [sp, #104]
   1a278:	b4000ab7 	cbz	x23, 1a3cc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K214+0x250>
   1a27c:	f85a03b4 	ldur	x20, [x29, #-96]
   1a280:	f94096a9 	ldr	x9, [x21, #296]
   1a284:	f8777a88 	ldr	x8, [x20, x23, lsl #3]
   1a288:	f90016a8 	str	x8, [x21, #40]
   1a28c:	d1008128 	sub	x8, x9, #0x20
   1a290:	f90096a8 	str	x8, [x21, #296]
   1a294:	8b170e9c 	add	x28, x20, x23, lsl #3
   1a298:	52801fe1 	mov	w1, #0xff                  	// #255
   1a29c:	52801c02 	mov	w2, #0xe0                  	// #224
   1a2a0:	91002380 	add	x0, x28, #0x8
   1a2a4:	97ffa613 	bl	3af0 <memset@plt>
   1a2a8:	52800028 	mov	w8, #0x1                   	// #1
   1a2ac:	d2c7c009 	mov	x9, #0x3e0000000000        	// #68169720922112
   1a2b0:	f9000393 	str	x19, [x28]
   1a2b4:	aa18810a 	orr	x10, x8, x24, lsl #32
   1a2b8:	f2e0a009 	movk	x9, #0x500, lsl #48
   1a2bc:	aa0902e9 	orr	x9, x23, x9
   1a2c0:	a90eab9b 	stp	x27, x10, [x28, #232]
   1a2c4:	a93e22c9 	stp	x9, x8, [x22, #-32]
   1a2c8:	f94016a0 	ldr	x0, [x21, #40]
   1a2cc:	b40008e0 	cbz	x0, 1a3e8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K214+0x26c>
   1a2d0:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   1a2d4:	f94096aa 	ldr	x10, [x21, #296]
   1a2d8:	f90016a8 	str	x8, [x21, #40]
   1a2dc:	d1008148 	sub	x8, x10, #0x20
   1a2e0:	f90096a8 	str	x8, [x21, #296]
   1a2e4:	8b000e88 	add	x8, x20, x0, lsl #3
   1a2e8:	d2c0002a 	mov	x10, #0x100000000           	// #4294967296
   1a2ec:	2a1a03eb 	mov	w11, w26
   1a2f0:	f85f03ac 	ldur	x12, [x29, #-16]
   1a2f4:	a97cb7ae 	ldp	x14, x13, [x29, #-56]
   1a2f8:	f900710a 	str	x10, [x8, #224]
   1a2fc:	2a1903ea 	mov	w10, w25
   1a300:	f85e03b1 	ldur	x17, [x29, #-32]
   1a304:	a9002d0a 	stp	x10, x11, [x8]
   1a308:	a9422beb 	ldp	x11, x10, [sp, #32]
   1a30c:	a97bbfb0 	ldp	x16, x15, [x29, #-72]
   1a310:	f9006d09 	str	x9, [x8, #216]
   1a314:	a97acbb3 	ldp	x19, x18, [x29, #-88]
   1a318:	f85983a9 	ldur	x9, [x29, #-104]
   1a31c:	a902290b 	stp	x11, x10, [x8, #32]
   1a320:	a943abeb 	ldp	x11, x10, [sp, #56]
   1a324:	a9014913 	stp	x19, x18, [x8, #16]
   1a328:	a903290b 	stp	x11, x10, [x8, #48]
   1a32c:	f94007ea 	ldr	x10, [sp, #8]
   1a330:	f9402feb 	ldr	x11, [sp, #88]
   1a334:	2a0a03ea 	mov	w10, w10
   1a338:	f900210a 	str	x10, [x8, #64]
   1a33c:	f9400bea 	ldr	x10, [sp, #16]
   1a340:	2a0a03ea 	mov	w10, w10
   1a344:	a904a90b 	stp	x11, x10, [x8, #72]
   1a348:	f9400fea 	ldr	x10, [sp, #24]
   1a34c:	f85e83ab 	ldur	x11, [x29, #-24]
   1a350:	2a0a03ea 	mov	w10, w10
   1a354:	a905a90b 	stp	x11, x10, [x8, #88]
   1a358:	f9401bea 	ldr	x10, [sp, #48]
   1a35c:	f94027eb 	ldr	x11, [sp, #72]
   1a360:	2a0a03ea 	mov	w10, w10
   1a364:	2a0b03eb 	mov	w11, w11
   1a368:	a906a90c 	stp	x12, x10, [x8, #104]
   1a36c:	f9403bea 	ldr	x10, [sp, #112]
   1a370:	f9003d0b 	str	x11, [x8, #120]
   1a374:	2a0d03eb 	mov	w11, w13
   1a378:	2a0a03ea 	mov	w10, w10
   1a37c:	a9082d0a 	stp	x10, x11, [x8, #128]
   1a380:	f85d83aa 	ldur	x10, [x29, #-40]
   1a384:	2a1103eb 	mov	w11, w17
   1a388:	2a0a03ea 	mov	w10, w10
   1a38c:	a9092d0a 	stp	x10, x11, [x8, #144]
   1a390:	2a1003ea 	mov	w10, w16
   1a394:	2a0f03eb 	mov	w11, w15
   1a398:	a90a2d0a 	stp	x10, x11, [x8, #160]
   1a39c:	f9402bea 	ldr	x10, [sp, #80]
   1a3a0:	2a0a03ea 	mov	w10, w10
   1a3a4:	a90b390a 	stp	x10, x14, [x8, #176]
   1a3a8:	a9462fea 	ldp	x10, x11, [sp, #96]
   1a3ac:	a90c290b 	stp	x11, x10, [x8, #192]
   1a3b0:	d2c5400a 	mov	x10, #0x2a0000000000        	// #46179488366592
   1a3b4:	f2e0a00a 	movk	x10, #0x500, lsl #48
   1a3b8:	aa0a0000 	orr	x0, x0, x10
   1a3bc:	f9006909 	str	x9, [x8, #208]
   1a3c0:	a94e7bfd 	ldp	x29, x30, [sp, #224]
   1a3c4:	9103c3ff 	add	sp, sp, #0xf0
   1a3c8:	d65f03c0 	ret
   1a3cc:	f85a03b4 	ldur	x20, [x29, #-96]
   1a3d0:	aa1503e1 	mov	x1, x21
   1a3d4:	528000a2 	mov	w2, #0x5                   	// #5
   1a3d8:	aa1403e0 	mov	x0, x20
   1a3dc:	97ffa9e4 	bl	4b6c <heap_alloc_miss>
   1a3e0:	aa0003f7 	mov	x23, x0
   1a3e4:	17ffffac 	b	1a294 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K214+0x118>
   1a3e8:	aa1403e0 	mov	x0, x20
   1a3ec:	aa1503e1 	mov	x1, x21
   1a3f0:	528000a2 	mov	w2, #0x5                   	// #5
   1a3f4:	97ffa9de 	bl	4b6c <heap_alloc_miss>
   1a3f8:	17ffffbb 	b	1a2e4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K214+0x168>

