    59f4:	d101c3ff 	sub	sp, sp, #0x70
    59f8:	a9017bfd 	stp	x29, x30, [sp, #16]
    59fc:	a9026ffc 	stp	x28, x27, [sp, #32]
    5a00:	a90367fa 	stp	x26, x25, [sp, #48]
    5a04:	a9045ff8 	stp	x24, x23, [sp, #64]
    5a08:	a90557f6 	stp	x22, x21, [sp, #80]
    5a0c:	a9064ff4 	stp	x20, x19, [sp, #96]
    5a10:	910043fd 	add	x29, sp, #0x10
    5a14:	5290a00e 	mov	w14, #0x8500                	// #34048
    5a18:	aa0203f5 	mov	x21, x2
    5a1c:	aa0103f3 	mov	x19, x1
    5a20:	72a0620e 	movk	w14, #0x310, lsl #16
    5a24:	aa0003f4 	mov	x20, x0
    5a28:	aa1f03f7 	mov	x23, xzr
    5a2c:	aa1f03f8 	mov	x24, xzr
    5a30:	91040039 	add	x25, x1, #0x100
    5a34:	9100201a 	add	x26, x0, #0x8
    5a38:	d10005cf 	sub	x15, x14, #0x1
    5a3c:	f0000d56 	adrp	x22, 1b0000 <memcpy@GLIBC_2.17>
    5a40:	5280003b 	mov	w27, #0x1                   	// #1
    5a44:	d2c0201c 	mov	x28, #0x10000000000         	// #1099511627776
    5a48:	b6f804b5 	tbz	x21, #63, 5adc <term_drop+0xe8>
    5a4c:	92787ea8 	and	x8, x21, #0xffffffff00
    5a50:	eb0f011f 	cmp	x8, x15
    5a54:	54000449 	b.ls	5adc <term_drop+0xe8>  // b.plast
    5a58:	b10006bf 	cmn	x21, #0x1
    5a5c:	54000400 	b.eq	5adc <term_drop+0xe8>  // b.none
    5a60:	924716a8 	and	x8, x21, #0x7e00000000000000
    5a64:	b40003c8 	cbz	x8, 5adc <term_drop+0xe8>
    5a68:	92409ebc 	and	x28, x21, #0xffffffffff
    5a6c:	12800000 	mov	w0, #0xffffffff            	// #-1
    5a70:	f90007ef 	str	x15, [sp, #8]
    5a74:	8b1c0e96 	add	x22, x20, x28, lsl #3
    5a78:	aa1603e1 	mov	x1, x22
    5a7c:	94020fe9 	bl	89a20 <__aarch64_ldadd4_rel>
    5a80:	12005c08 	and	w8, w0, #0xffffff
    5a84:	7100051f 	cmp	w8, #0x1
    5a88:	54000561 	b.ne	5b34 <term_drop+0x140>  // b.any
    5a8c:	88dffedf 	ldar	wzr, [x22]
    5a90:	f9400268 	ldr	x8, [x19]
    5a94:	92585ab5 	and	x21, x21, #0x7fffff0000000000
    5a98:	f94002c9 	ldr	x9, [x22]
    5a9c:	f90002c8 	str	x8, [x22]
    5aa0:	f0000d56 	adrp	x22, 1b0000 <memcpy@GLIBC_2.17>
    5aa4:	f9408268 	ldr	x8, [x19, #256]
    5aa8:	394832ca 	ldrb	w10, [x22, #524]
    5aac:	b358fd35 	bfxil	x21, x9, #24, #40
    5ab0:	f900027c 	str	x28, [x19]
    5ab4:	91000508 	add	x8, x8, #0x1
    5ab8:	7100055f 	cmp	w10, #0x1
    5abc:	f9008268 	str	x8, [x19, #256]
    5ac0:	540009a1 	b.ne	5bf4 <term_drop+0x200>  // b.any
    5ac4:	f140211f 	cmp	x8, #0x8, lsl #12
    5ac8:	54000962 	b.cs	5bf4 <term_drop+0x200>  // b.hs, b.nlast
    5acc:	5290a00e 	mov	w14, #0x8500                	// #34048
    5ad0:	f94007ef 	ldr	x15, [sp, #8]
    5ad4:	d2c0201c 	mov	x28, #0x10000000000         	// #1099511627776
    5ad8:	72a0620e 	movk	w14, #0x310, lsl #16
    5adc:	92787ea8 	and	x8, x21, #0xffffffff00
    5ae0:	eb0e011f 	cmp	x8, x14
    5ae4:	54000923 	b.cc	5c08 <term_drop+0x214>  // b.lo, b.ul, b.last
    5ae8:	b10006bf 	cmn	x21, #0x1
    5aec:	540008e0 	b.eq	5c08 <term_drop+0x214>  // b.none
    5af0:	924716a8 	and	x8, x21, #0x7e00000000000000
    5af4:	b40008a8 	cbz	x8, 5c08 <term_drop+0x214>
    5af8:	d378faa9 	ubfx	x9, x21, #56, #7
    5afc:	f100113f 	cmp	x9, #0x4
    5b00:	54000261 	b.ne	5b4c <term_drop+0x158>  // b.any
    5b04:	d368b2a8 	ubfx	x8, x21, #40, #5
    5b08:	92481aa9 	and	x9, x21, #0x7f00000000000000
    5b0c:	d2e0c00b 	mov	x11, #0x600000000000000     	// #432345564227567616
    5b10:	7100050a 	subs	w10, w8, #0x1
    5b14:	1a8a33ea 	csel	w10, wzr, w10, cc	// cc = lo, ul, last
    5b18:	eb0b013f 	cmp	x9, x11
    5b1c:	1a8a0102 	csel	w2, w8, w10, eq	// eq = none
    5b20:	92409ea8 	and	x8, x21, #0xffffffffff
    5b24:	f8625a69 	ldr	x9, [x19, w2, uxtw #3]
    5b28:	f8287a89 	str	x9, [x20, x8, lsl #3]
    5b2c:	f8225a68 	str	x8, [x19, w2, uxtw #3]
    5b30:	14000060 	b	5cb0 <term_drop+0x2bc>
    5b34:	5290a00e 	mov	w14, #0x8500                	// #34048
    5b38:	f94007ef 	ldr	x15, [sp, #8]
    5b3c:	f0000d56 	adrp	x22, 1b0000 <memcpy@GLIBC_2.17>
    5b40:	72a0620e 	movk	w14, #0x310, lsl #16
    5b44:	d2c0201c 	mov	x28, #0x10000000000         	// #1099511627776
    5b48:	14000030 	b	5c08 <term_drop+0x214>
    5b4c:	f100193f 	cmp	x9, #0x6
    5b50:	54000120 	b.eq	5b74 <term_drop+0x180>  // b.none
    5b54:	d368dea8 	ubfx	x8, x21, #40, #16
    5b58:	f100093f 	cmp	x9, #0x2
    5b5c:	54000141 	b.ne	5b84 <term_drop+0x190>  // b.any
    5b60:	d37ff908 	lsl	x8, x8, #1
    5b64:	9000042a 	adrp	x10, 89000 <spin_348+0x1e6c>
    5b68:	9130514a 	add	x10, x10, #0xc14
    5b6c:	38686948 	ldrb	w8, [x10, x8]
    5b70:	1400000c 	b	5ba0 <term_drop+0x1ac>
    5b74:	d368b2a9 	ubfx	x9, x21, #40, #5
    5b78:	2a1f03e8 	mov	w8, wzr
    5b7c:	321a0129 	orr	w9, w9, #0x40
    5b80:	14000016 	b	5bd8 <term_drop+0x1e4>
    5b84:	8b080508 	add	x8, x8, x8, lsl #1
    5b88:	9000042a 	adrp	x10, 89000 <spin_348+0x1e6c>
    5b8c:	9136894a 	add	x10, x10, #0xda2
    5b90:	f1000d3f 	cmp	x9, #0x3
    5b94:	38686948 	ldrb	w8, [x10, x8]
    5b98:	1a9f17ea 	cset	w10, eq	// eq = none
    5b9c:	4b0a0108 	sub	w8, w8, w10
    5ba0:	7103e11f 	cmp	w8, #0xf8
    5ba4:	54000083 	b.cc	5bb4 <term_drop+0x1c0>  // b.lo, b.ul, b.last
    5ba8:	5103c109 	sub	w9, w8, #0xf0
    5bac:	321a0129 	orr	w9, w9, #0x40
    5bb0:	1400000a 	b	5bd8 <term_drop+0x1e4>
    5bb4:	1100090a 	add	w10, w8, #0x2
    5bb8:	f100153f 	cmp	x9, #0x5
    5bbc:	5280040b 	mov	w11, #0x20                  	// #32
    5bc0:	1a880149 	csel	w9, w10, w8, eq	// eq = none
    5bc4:	7100052a 	subs	w10, w9, #0x1
    5bc8:	5ac0114a 	clz	w10, w10
    5bcc:	7100053f 	cmp	w9, #0x1
    5bd0:	4b0a016a 	sub	w10, w11, w10
    5bd4:	1a9f8149 	csel	w9, w10, wzr, hi	// hi = pmore
    5bd8:	d3503d08 	lsl	x8, x8, #48
    5bdc:	92409eaa 	and	x10, x21, #0xffffffffff
    5be0:	f86a7a97 	ldr	x23, [x20, x10, lsl #3]
    5be4:	f82a7a98 	str	x24, [x20, x10, lsl #3]
    5be8:	aa09e108 	orr	x8, x8, x9, lsl #56
    5bec:	aa0a0118 	orr	x24, x8, x10
    5bf0:	14000006 	b	5c08 <term_drop+0x214>
    5bf4:	aa1403e0 	mov	x0, x20
    5bf8:	aa1303e1 	mov	x1, x19
    5bfc:	2a1f03e2 	mov	w2, wzr
    5c00:	97fffa18 	bl	4460 <heap_hand>
    5c04:	17ffffb2 	b	5acc <term_drop+0xd8>
    5c08:	b40006f8 	cbz	x24, 5ce4 <term_drop+0x2f0>
    5c0c:	d37eff08 	lsr	x8, x24, #62
    5c10:	d368bf09 	ubfx	x9, x24, #40, #8
    5c14:	d378ff02 	lsr	x2, x24, #56
    5c18:	92409f0a 	and	x10, x24, #0xffffffffff
    5c1c:	b4000108 	cbz	x8, 5c3c <term_drop+0x248>
    5c20:	1ac2236b 	lsl	w11, w27, w2
    5c24:	7100093f 	cmp	w9, #0x2
    5c28:	1200144d 	and	w13, w2, #0x3f
    5c2c:	540000c1 	b.ne	5c44 <term_drop+0x250>  // b.any
    5c30:	f86a7b4c 	ldr	x12, [x26, x10, lsl #3]
    5c34:	2a0d03e2 	mov	w2, w13
    5c38:	14000005 	b	5c4c <term_drop+0x258>
    5c3c:	d370df0b 	ubfx	x11, x24, #48, #8
    5c40:	14000002 	b	5c48 <term_drop+0x254>
    5c44:	2a0d03e2 	mov	w2, w13
    5c48:	2a0903ec 	mov	w12, w9
    5c4c:	6b0b019f 	cmp	w12, w11
    5c50:	54000282 	b.cs	5ca0 <term_drop+0x2ac>  // b.hs, b.nlast
    5c54:	aa1703f5 	mov	x21, x23
    5c58:	340000cc 	cbz	w12, 5c70 <term_drop+0x27c>
    5c5c:	8b0a0e8b 	add	x11, x20, x10, lsl #3
    5c60:	f86c5975 	ldr	x21, [x11, w12, uxtw #3]
    5c64:	b4000068 	cbz	x8, 5c70 <term_drop+0x27c>
    5c68:	1100058b 	add	w11, w12, #0x1
    5c6c:	f82a7b4b 	str	x11, [x26, x10, lsl #3]
    5c70:	7100053f 	cmp	w9, #0x1
    5c74:	fa408904 	ccmp	x8, #0x0, #0x4, hi	// hi = pmore
    5c78:	8b1c0308 	add	x8, x24, x28
    5c7c:	9a881318 	csel	x24, x24, x8, ne	// ne = any
    5c80:	b10006bf 	cmn	x21, #0x1
    5c84:	54fffc20 	b.eq	5c08 <term_drop+0x214>  // b.none
    5c88:	924716a8 	and	x8, x21, #0x7e00000000000000
    5c8c:	b4fffbe8 	cbz	x8, 5c08 <term_drop+0x214>
    5c90:	92787ea8 	and	x8, x21, #0xffffffff00
    5c94:	eb0e011f 	cmp	x8, x14
    5c98:	54fffb83 	b.cc	5c08 <term_drop+0x214>  // b.lo, b.ul, b.last
    5c9c:	17ffff6b 	b	5a48 <term_drop+0x54>
    5ca0:	f8625a68 	ldr	x8, [x19, w2, uxtw #3]
    5ca4:	f86a7a98 	ldr	x24, [x20, x10, lsl #3]
    5ca8:	f82a7a88 	str	x8, [x20, x10, lsl #3]
    5cac:	f8225a6a 	str	x10, [x19, w2, uxtw #3]
    5cb0:	394832c8 	ldrb	w8, [x22, #524]
    5cb4:	9ac22369 	lsl	x9, x27, x2
    5cb8:	f8625b2a 	ldr	x10, [x25, w2, uxtw #3]
    5cbc:	7100051f 	cmp	w8, #0x1
    5cc0:	8b090148 	add	x8, x10, x9
    5cc4:	f8225b28 	str	x8, [x25, w2, uxtw #3]
    5cc8:	54000061 	b.ne	5cd4 <term_drop+0x2e0>  // b.any
    5ccc:	f140211f 	cmp	x8, #0x8, lsl #12
    5cd0:	54fff9c3 	b.cc	5c08 <term_drop+0x214>  // b.lo, b.ul, b.last
    5cd4:	aa1403e0 	mov	x0, x20
    5cd8:	aa1303e1 	mov	x1, x19
    5cdc:	97fff9e1 	bl	4460 <heap_hand>
    5ce0:	17ffffca 	b	5c08 <term_drop+0x214>
    5ce4:	a9464ff4 	ldp	x20, x19, [sp, #96]
    5ce8:	a94557f6 	ldp	x22, x21, [sp, #80]
    5cec:	a9445ff8 	ldp	x24, x23, [sp, #64]
    5cf0:	a94367fa 	ldp	x26, x25, [sp, #48]
    5cf4:	a9426ffc 	ldp	x28, x27, [sp, #32]
    5cf8:	a9417bfd 	ldp	x29, x30, [sp, #16]
    5cfc:	9101c3ff 	add	sp, sp, #0x70
    5d00:	d65f03c0 	ret

