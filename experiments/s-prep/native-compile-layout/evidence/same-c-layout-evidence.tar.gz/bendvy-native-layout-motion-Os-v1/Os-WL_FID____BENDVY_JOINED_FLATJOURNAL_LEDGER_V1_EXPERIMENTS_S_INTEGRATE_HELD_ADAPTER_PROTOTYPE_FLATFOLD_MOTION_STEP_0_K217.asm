   1a87c:	d10243ff 	sub	sp, sp, #0x90
   1a880:	a9087bfd 	stp	x29, x30, [sp, #128]
   1a884:	910203fd 	add	x29, sp, #0x80
   1a888:	a93da7af 	stp	x15, x9, [x29, #-40]
   1a88c:	aa0e03e9 	mov	x9, x14
   1a890:	aa0503f3 	mov	x19, x5
   1a894:	a9453baf 	ldp	x15, x14, [x29, #80]
   1a898:	aa1603e8 	mov	x8, x22
   1a89c:	a94343be 	ldp	x30, x16, [x29, #48]
   1a8a0:	f81e83ac 	stur	x12, [x29, #-24]
   1a8a4:	a9414ba2 	ldp	x2, x18, [x29, #16]
   1a8a8:	aa0703ec 	mov	x12, x7
   1a8ac:	f81f03ae 	stur	x14, [x29, #-16]
   1a8b0:	a94417ae 	ldp	x14, x5, [x29, #64]
   1a8b4:	f81d03b0 	stur	x16, [x29, #-48]
   1a8b8:	aa0103e7 	mov	x7, x1
   1a8bc:	aa0003e1 	mov	x1, x0
   1a8c0:	a94243b1 	ldp	x17, x16, [x29, #32]
   1a8c4:	b85f8ed8 	ldr	w24, [x22, #-8]!
   1a8c8:	340003f7 	cbz	w23, 1a944 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K217+0xc8>
   1a8cc:	f85f03a8 	ldur	x8, [x29, #-16]
   1a8d0:	aa0103e0 	mov	x0, x1
   1a8d4:	aa0703e1 	mov	x1, x7
   1a8d8:	2a0c03e7 	mov	w7, w12
   1a8dc:	f85d03ac 	ldur	x12, [x29, #-48]
   1a8e0:	a904bfa5 	stp	x5, x15, [x29, #72]
   1a8e4:	2a0803e8 	mov	w8, w8
   1a8e8:	2a1903f9 	mov	w25, w25
   1a8ec:	2a1a03fa 	mov	w26, w26
   1a8f0:	a903bbac 	stp	x12, x14, [x29, #56]
   1a8f4:	2a1e03ec 	mov	w12, w30
   1a8f8:	2a0903ee 	mov	w14, w9
   1a8fc:	a905e3a8 	stp	x8, x24, [x29, #88]
   1a900:	2a1003e8 	mov	w8, w16
   1a904:	2a0203f0 	mov	w16, w2
   1a908:	a902b3a8 	stp	x8, x12, [x29, #40]
   1a90c:	a97da7a8 	ldp	x8, x9, [x29, #-40]
   1a910:	2a1103ec 	mov	w12, w17
   1a914:	2a1303e5 	mov	w5, w19
   1a918:	2a0b03eb 	mov	w11, w11
   1a91c:	2a0d03ed 	mov	w13, w13
   1a920:	2a0803ef 	mov	w15, w8
   1a924:	2a1203e8 	mov	w8, w18
   1a928:	2a0903e9 	mov	w9, w9
   1a92c:	a901b3a8 	stp	x8, x12, [x29, #24]
   1a930:	f85e83ac 	ldur	x12, [x29, #-24]
   1a934:	f9000bb0 	str	x16, [x29, #16]
   1a938:	a9487bfd 	ldp	x29, x30, [sp, #128]
   1a93c:	910243ff 	add	sp, sp, #0x90
   1a940:	17fff28c 	b	17370 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_FALLBACK>
   1a944:	a903c7f2 	stp	x18, x17, [sp, #56]
   1a948:	a97e5d12 	ldp	x18, x23, [x8, #-32]
   1a94c:	f94016a0 	ldr	x0, [x21, #40]
   1a950:	aa0203f6 	mov	x22, x2
   1a954:	f81c83b0 	stur	x16, [x29, #-56]
   1a958:	b40006c0 	cbz	x0, 1aa30 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K217+0x1b4>
   1a95c:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   1a960:	f94096b0 	ldr	x16, [x21, #296]
   1a964:	f90016a8 	str	x8, [x21, #40]
   1a968:	d1008208 	sub	x8, x16, #0x20
   1a96c:	f90096a8 	str	x8, [x21, #296]
   1a970:	8b000e88 	add	x8, x20, x0, lsl #3
   1a974:	2a0c03ec 	mov	w12, w12
   1a978:	d3607ef0 	lsl	x16, x23, #32
   1a97c:	2a1a03f1 	mov	w17, w26
   1a980:	a905290c 	stp	x12, x10, [x8, #80]
   1a984:	2a0b03ea 	mov	w10, w11
   1a988:	2a0d03eb 	mov	w11, w13
   1a98c:	f900310a 	str	x10, [x8, #96]
   1a990:	f85e83aa 	ldur	x10, [x29, #-24]
   1a994:	f9007910 	str	x16, [x8, #240]
   1a998:	2a1903f0 	mov	w16, w25
   1a99c:	f900350a 	str	x10, [x8, #104]
   1a9a0:	2a0903ea 	mov	w10, w9
   1a9a4:	a907290b 	stp	x11, x10, [x8, #112]
   1a9a8:	a97da7aa 	ldp	x10, x9, [x29, #-40]
   1a9ac:	a9004510 	stp	x16, x17, [x8]
   1a9b0:	2a1303f0 	mov	w16, w19
   1a9b4:	a901711b 	stp	x27, x28, [x8, #16]
   1a9b8:	2a0903e9 	mov	w9, w9
   1a9bc:	2a0a03ea 	mov	w10, w10
   1a9c0:	a9021d01 	stp	x1, x7, [x8, #32]
   1a9c4:	a9082909 	stp	x9, x10, [x8, #128]
   1a9c8:	f9401fea 	ldr	x10, [sp, #56]
   1a9cc:	2a1603e9 	mov	w9, w22
   1a9d0:	a9031103 	stp	x3, x4, [x8, #48]
   1a9d4:	2a0a03ea 	mov	w10, w10
   1a9d8:	a9041910 	stp	x16, x6, [x8, #64]
   1a9dc:	a9092909 	stp	x9, x10, [x8, #144]
   1a9e0:	f94023e9 	ldr	x9, [sp, #64]
   1a9e4:	f85c83aa 	ldur	x10, [x29, #-56]
   1a9e8:	a90cbd05 	stp	x5, x15, [x8, #200]
   1a9ec:	2a0903e9 	mov	w9, w9
   1a9f0:	2a0a03ea 	mov	w10, w10
   1a9f4:	a90a2909 	stp	x9, x10, [x8, #160]
   1a9f8:	2a1e03e9 	mov	w9, w30
   1a9fc:	f9005909 	str	x9, [x8, #176]
   1aa00:	f85d03a9 	ldur	x9, [x29, #-48]
   1aa04:	a90bb909 	stp	x9, x14, [x8, #184]
   1aa08:	f85f03a9 	ldur	x9, [x29, #-16]
   1aa0c:	2a0903e9 	mov	w9, w9
   1aa10:	a90de109 	stp	x9, x24, [x8, #216]
   1aa14:	d2c5e009 	mov	x9, #0x2f0000000000        	// #51677046505472
   1aa18:	f2e0a009 	movk	x9, #0x500, lsl #48
   1aa1c:	aa090000 	orr	x0, x0, x9
   1aa20:	f9007512 	str	x18, [x8, #232]
   1aa24:	a9487bfd 	ldp	x29, x30, [sp, #128]
   1aa28:	910243ff 	add	sp, sp, #0x90
   1aa2c:	d65f03c0 	ret
   1aa30:	aa1403e0 	mov	x0, x20
   1aa34:	a9001fe1 	stp	x1, x7, [sp]
   1aa38:	aa1503e1 	mov	x1, x21
   1aa3c:	528000a2 	mov	w2, #0x5                   	// #5
   1aa40:	a902bfea 	stp	x10, x15, [sp, #40]
   1aa44:	aa0503ea 	mov	x10, x5
   1aa48:	a901fbe6 	stp	x6, x30, [sp, #24]
   1aa4c:	aa0303ef 	mov	x15, x3
   1aa50:	aa1203f5 	mov	x21, x18
   1aa54:	f9000be4 	str	x4, [sp, #16]
   1aa58:	97ffa845 	bl	4b6c <heap_alloc_miss>
   1aa5c:	a9401fe1 	ldp	x1, x7, [sp]
   1aa60:	aa0a03e5 	mov	x5, x10
   1aa64:	a9411be4 	ldp	x4, x6, [sp, #16]
   1aa68:	aa0f03e3 	mov	x3, x15
   1aa6c:	a9422bfe 	ldp	x30, x10, [sp, #32]
   1aa70:	aa1503f2 	mov	x18, x21
   1aa74:	f9401bef 	ldr	x15, [sp, #48]
   1aa78:	17ffffbe 	b	1a970 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K217+0xf4>

