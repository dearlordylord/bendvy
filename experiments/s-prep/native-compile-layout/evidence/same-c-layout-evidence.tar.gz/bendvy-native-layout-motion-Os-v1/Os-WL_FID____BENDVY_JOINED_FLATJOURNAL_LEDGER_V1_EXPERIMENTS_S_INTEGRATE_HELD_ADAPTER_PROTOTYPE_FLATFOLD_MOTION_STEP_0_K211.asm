   19afc:	d10243ff 	sub	sp, sp, #0x90
   19b00:	a9087bfd 	stp	x29, x30, [sp, #128]
   19b04:	910203fd 	add	x29, sp, #0x80
   19b08:	a93da7af 	stp	x15, x9, [x29, #-40]
   19b0c:	aa0e03e9 	mov	x9, x14
   19b10:	aa0503f3 	mov	x19, x5
   19b14:	a9453baf 	ldp	x15, x14, [x29, #80]
   19b18:	aa1603e8 	mov	x8, x22
   19b1c:	a94343be 	ldp	x30, x16, [x29, #48]
   19b20:	f81e83ac 	stur	x12, [x29, #-24]
   19b24:	a9414ba2 	ldp	x2, x18, [x29, #16]
   19b28:	aa0703ec 	mov	x12, x7
   19b2c:	f81f03ae 	stur	x14, [x29, #-16]
   19b30:	a94417ae 	ldp	x14, x5, [x29, #64]
   19b34:	f81d03b0 	stur	x16, [x29, #-48]
   19b38:	aa0103e7 	mov	x7, x1
   19b3c:	aa0003e1 	mov	x1, x0
   19b40:	a94243b1 	ldp	x17, x16, [x29, #32]
   19b44:	b85f8ed8 	ldr	w24, [x22, #-8]!
   19b48:	340003f7 	cbz	w23, 19bc4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K211+0xc8>
   19b4c:	f85f03a8 	ldur	x8, [x29, #-16]
   19b50:	aa0103e0 	mov	x0, x1
   19b54:	aa0703e1 	mov	x1, x7
   19b58:	2a0c03e7 	mov	w7, w12
   19b5c:	f85d03ac 	ldur	x12, [x29, #-48]
   19b60:	a904bfa5 	stp	x5, x15, [x29, #72]
   19b64:	2a0803e8 	mov	w8, w8
   19b68:	2a1903f9 	mov	w25, w25
   19b6c:	2a1a03fa 	mov	w26, w26
   19b70:	a903bbac 	stp	x12, x14, [x29, #56]
   19b74:	2a1e03ec 	mov	w12, w30
   19b78:	2a0903ee 	mov	w14, w9
   19b7c:	a905e3a8 	stp	x8, x24, [x29, #88]
   19b80:	2a1003e8 	mov	w8, w16
   19b84:	2a0203f0 	mov	w16, w2
   19b88:	a902b3a8 	stp	x8, x12, [x29, #40]
   19b8c:	a97da7a8 	ldp	x8, x9, [x29, #-40]
   19b90:	2a1103ec 	mov	w12, w17
   19b94:	2a1303e5 	mov	w5, w19
   19b98:	2a0b03eb 	mov	w11, w11
   19b9c:	2a0d03ed 	mov	w13, w13
   19ba0:	2a0803ef 	mov	w15, w8
   19ba4:	2a1203e8 	mov	w8, w18
   19ba8:	2a0903e9 	mov	w9, w9
   19bac:	a901b3a8 	stp	x8, x12, [x29, #24]
   19bb0:	f85e83ac 	ldur	x12, [x29, #-24]
   19bb4:	f9000bb0 	str	x16, [x29, #16]
   19bb8:	a9487bfd 	ldp	x29, x30, [sp, #128]
   19bbc:	910243ff 	add	sp, sp, #0x90
   19bc0:	17fff5ec 	b	17370 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_FALLBACK>
   19bc4:	a903c7f2 	stp	x18, x17, [sp, #56]
   19bc8:	a97e5d12 	ldp	x18, x23, [x8, #-32]
   19bcc:	f94016a0 	ldr	x0, [x21, #40]
   19bd0:	aa0203f6 	mov	x22, x2
   19bd4:	f81c83b0 	stur	x16, [x29, #-56]
   19bd8:	b40006c0 	cbz	x0, 19cb0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K211+0x1b4>
   19bdc:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   19be0:	f94096b0 	ldr	x16, [x21, #296]
   19be4:	f90016a8 	str	x8, [x21, #40]
   19be8:	d1008208 	sub	x8, x16, #0x20
   19bec:	f90096a8 	str	x8, [x21, #296]
   19bf0:	8b000e88 	add	x8, x20, x0, lsl #3
   19bf4:	2a0c03ec 	mov	w12, w12
   19bf8:	d3607ef0 	lsl	x16, x23, #32
   19bfc:	2a1a03f1 	mov	w17, w26
   19c00:	a905290c 	stp	x12, x10, [x8, #80]
   19c04:	2a0b03ea 	mov	w10, w11
   19c08:	2a0d03eb 	mov	w11, w13
   19c0c:	f900310a 	str	x10, [x8, #96]
   19c10:	f85e83aa 	ldur	x10, [x29, #-24]
   19c14:	f9007910 	str	x16, [x8, #240]
   19c18:	2a1903f0 	mov	w16, w25
   19c1c:	f900350a 	str	x10, [x8, #104]
   19c20:	2a0903ea 	mov	w10, w9
   19c24:	a907290b 	stp	x11, x10, [x8, #112]
   19c28:	a97da7aa 	ldp	x10, x9, [x29, #-40]
   19c2c:	a9004510 	stp	x16, x17, [x8]
   19c30:	2a1303f0 	mov	w16, w19
   19c34:	a901711b 	stp	x27, x28, [x8, #16]
   19c38:	2a0903e9 	mov	w9, w9
   19c3c:	2a0a03ea 	mov	w10, w10
   19c40:	a9021d01 	stp	x1, x7, [x8, #32]
   19c44:	a9082909 	stp	x9, x10, [x8, #128]
   19c48:	f9401fea 	ldr	x10, [sp, #56]
   19c4c:	2a1603e9 	mov	w9, w22
   19c50:	a9031103 	stp	x3, x4, [x8, #48]
   19c54:	2a0a03ea 	mov	w10, w10
   19c58:	a9041910 	stp	x16, x6, [x8, #64]
   19c5c:	a9092909 	stp	x9, x10, [x8, #144]
   19c60:	f94023e9 	ldr	x9, [sp, #64]
   19c64:	f85c83aa 	ldur	x10, [x29, #-56]
   19c68:	a90cbd05 	stp	x5, x15, [x8, #200]
   19c6c:	2a0903e9 	mov	w9, w9
   19c70:	2a0a03ea 	mov	w10, w10
   19c74:	a90a2909 	stp	x9, x10, [x8, #160]
   19c78:	2a1e03e9 	mov	w9, w30
   19c7c:	f9005909 	str	x9, [x8, #176]
   19c80:	f85d03a9 	ldur	x9, [x29, #-48]
   19c84:	a90bb909 	stp	x9, x14, [x8, #184]
   19c88:	f85f03a9 	ldur	x9, [x29, #-16]
   19c8c:	2a0903e9 	mov	w9, w9
   19c90:	a90de109 	stp	x9, x24, [x8, #216]
   19c94:	d2c5e009 	mov	x9, #0x2f0000000000        	// #51677046505472
   19c98:	f2e0a009 	movk	x9, #0x500, lsl #48
   19c9c:	aa090000 	orr	x0, x0, x9
   19ca0:	f9007512 	str	x18, [x8, #232]
   19ca4:	a9487bfd 	ldp	x29, x30, [sp, #128]
   19ca8:	910243ff 	add	sp, sp, #0x90
   19cac:	d65f03c0 	ret
   19cb0:	aa1403e0 	mov	x0, x20
   19cb4:	a9001fe1 	stp	x1, x7, [sp]
   19cb8:	aa1503e1 	mov	x1, x21
   19cbc:	528000a2 	mov	w2, #0x5                   	// #5
   19cc0:	a902bfea 	stp	x10, x15, [sp, #40]
   19cc4:	aa0503ea 	mov	x10, x5
   19cc8:	a901fbe6 	stp	x6, x30, [sp, #24]
   19ccc:	aa0303ef 	mov	x15, x3
   19cd0:	aa1203f5 	mov	x21, x18
   19cd4:	f9000be4 	str	x4, [sp, #16]
   19cd8:	97ffaba5 	bl	4b6c <heap_alloc_miss>
   19cdc:	a9401fe1 	ldp	x1, x7, [sp]
   19ce0:	aa0a03e5 	mov	x5, x10
   19ce4:	a9411be4 	ldp	x4, x6, [sp, #16]
   19ce8:	aa0f03e3 	mov	x3, x15
   19cec:	a9422bfe 	ldp	x30, x10, [sp, #32]
   19cf0:	aa1503f2 	mov	x18, x21
   19cf4:	f9401bef 	ldr	x15, [sp, #48]
   19cf8:	17ffffbe 	b	19bf0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K211+0xf4>

