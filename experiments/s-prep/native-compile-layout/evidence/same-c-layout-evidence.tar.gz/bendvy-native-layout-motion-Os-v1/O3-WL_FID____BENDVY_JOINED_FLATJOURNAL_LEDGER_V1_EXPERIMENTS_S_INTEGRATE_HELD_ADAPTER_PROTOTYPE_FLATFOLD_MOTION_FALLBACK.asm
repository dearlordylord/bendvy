   18564:	d102c3ff 	sub	sp, sp, #0xb0
   18568:	a90a7bfd 	stp	x29, x30, [sp, #160]
   1856c:	910283fd 	add	x29, sp, #0xa0
   18570:	a93ebfaa 	stp	x10, x15, [x29, #-24]
   18574:	a9448bb0 	ldp	x16, x2, [x29, #72]
   18578:	a93da7ac 	stp	x12, x9, [x29, #-40]
   1857c:	f9400bb8 	ldr	x24, [x29, #16]
   18580:	a945a7af 	ldp	x15, x9, [x29, #88]
   18584:	a943c7be 	ldp	x30, x17, [x29, #56]
   18588:	a942b3b2 	ldp	x18, x12, [x29, #40]
   1858c:	a941cfaa 	ldp	x10, x19, [x29, #24]
   18590:	34000417 	cbz	w23, 18610 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_FALLBACK+0xac>
   18594:	2a0903e8 	mov	w8, w9
   18598:	52800609 	mov	w9, #0x30                  	// #48
   1859c:	2a1903f9 	mov	w25, w25
   185a0:	a88126c8 	stp	x8, x9, [x22], #16
   185a4:	2a0f03e8 	mov	w8, w15
   185a8:	a90523a2 	stp	x2, x8, [x29, #80]
   185ac:	2a0c03e8 	mov	w8, w12
   185b0:	f85d83ac 	ldur	x12, [x29, #-40]
   185b4:	a9037ba8 	stp	x8, x30, [x29, #48]
   185b8:	2a1203e8 	mov	w8, w18
   185bc:	2a1a03fa 	mov	w26, w26
   185c0:	f90017a8 	str	x8, [x29, #40]
   185c4:	2a1303e8 	mov	w8, w19
   185c8:	2a0503e5 	mov	w5, w5
   185cc:	f90013a8 	str	x8, [x29, #32]
   185d0:	2a0a03e8 	mov	w8, w10
   185d4:	2a0703e7 	mov	w7, w7
   185d8:	f9000fa8 	str	x8, [x29, #24]
   185dc:	a97e2ba8 	ldp	x8, x10, [x29, #-32]
   185e0:	a90443b1 	stp	x17, x16, [x29, #64]
   185e4:	2a0b03eb 	mov	w11, w11
   185e8:	2a0d03ed 	mov	w13, w13
   185ec:	2a0e03ee 	mov	w14, w14
   185f0:	2a0803e9 	mov	w9, w8
   185f4:	f85f03a8 	ldur	x8, [x29, #-16]
   185f8:	2a0803ef 	mov	w15, w8
   185fc:	2a1803e8 	mov	w8, w24
   18600:	f9000ba8 	str	x8, [x29, #16]
   18604:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   18608:	9102c3ff 	add	sp, sp, #0xb0
   1860c:	17fffab9 	b	170f0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_CONVERTED>
   18610:	f81d03b2 	stur	x18, [x29, #-48]
   18614:	f94016a8 	ldr	x8, [x21, #40]
   18618:	a904c7fe 	stp	x30, x17, [sp, #72]
   1861c:	f81c83af 	stur	x15, [x29, #-56]
   18620:	a97ebed7 	ldp	x23, x15, [x22, #-24]
   18624:	a93bb7b0 	stp	x16, x13, [x29, #-72]
   18628:	b4000ae8 	cbz	x8, 18784 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_FALLBACK+0x220>
   1862c:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   18630:	f94096b1 	ldr	x17, [x21, #296]
   18634:	f90016b0 	str	x16, [x21, #40]
   18638:	d1008230 	sub	x16, x17, #0x20
   1863c:	f90096b0 	str	x16, [x21, #296]
   18640:	52800031 	mov	w17, #0x1                   	// #1
   18644:	8b080e90 	add	x16, x20, x8, lsl #3
   18648:	6f07e7e0 	movi	v0.2d, #0xffffffffffffffff
   1864c:	aa0f822f 	orr	x15, x17, x15, lsl #32
   18650:	2a0903ed 	mov	w13, w9
   18654:	f85d03be 	ldur	x30, [x29, #-48]
   18658:	f900020d 	str	x13, [x16]
   1865c:	a90ebe17 	stp	x23, x15, [x16, #232]
   18660:	d2c6000f 	mov	x15, #0x300000000000        	// #52776558133248
   18664:	f2e0a00f 	movk	x15, #0x500, lsl #48
   18668:	3c8d8200 	stur	q0, [x16, #216]
   1866c:	aa0f010d 	orr	x13, x8, x15
   18670:	3c8c8200 	stur	q0, [x16, #200]
   18674:	3c8b8200 	stur	q0, [x16, #184]
   18678:	3c8a8200 	stur	q0, [x16, #168]
   1867c:	3c898200 	stur	q0, [x16, #152]
   18680:	3c888200 	stur	q0, [x16, #136]
   18684:	3c878200 	stur	q0, [x16, #120]
   18688:	3c868200 	stur	q0, [x16, #104]
   1868c:	3c858200 	stur	q0, [x16, #88]
   18690:	3c848200 	stur	q0, [x16, #72]
   18694:	3c838200 	stur	q0, [x16, #56]
   18698:	3c828200 	stur	q0, [x16, #40]
   1869c:	3c818200 	stur	q0, [x16, #24]
   186a0:	3c808200 	stur	q0, [x16, #8]
   186a4:	a93ec6cd 	stp	x13, x17, [x22, #-24]
   186a8:	f94016a8 	ldr	x8, [x21, #40]
   186ac:	b40008a8 	cbz	x8, 187c0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_FALLBACK+0x25c>
   186b0:	f8687a8f 	ldr	x15, [x20, x8, lsl #3]
   186b4:	f94096b0 	ldr	x16, [x21, #296]
   186b8:	aa0c03f1 	mov	x17, x12
   186bc:	f90016af 	str	x15, [x21, #40]
   186c0:	d100820f 	sub	x15, x16, #0x20
   186c4:	f90096af 	str	x15, [x21, #296]
   186c8:	8b080e90 	add	x16, x20, x8, lsl #3
   186cc:	d2c0002f 	mov	x15, #0x100000000           	// #4294967296
   186d0:	f85e83a9 	ldur	x9, [x29, #-24]
   186d4:	2a0b03eb 	mov	w11, w11
   186d8:	2a0e03ec 	mov	w12, w14
   186dc:	a90e3e0d 	stp	x13, x15, [x16, #224]
   186e0:	2a1903ed 	mov	w13, w25
   186e4:	2a1a03ef 	mov	w15, w26
   186e8:	a9003e0d 	stp	x13, x15, [x16]
   186ec:	2a0503ed 	mov	w13, w5
   186f0:	a9041a0d 	stp	x13, x6, [x16, #64]
   186f4:	2a0703ed 	mov	w13, w7
   186f8:	a905260d 	stp	x13, x9, [x16, #80]
   186fc:	f85d83a9 	ldur	x9, [x29, #-40]
   18700:	a901721b 	stp	x27, x28, [x16, #16]
   18704:	a906260b 	stp	x11, x9, [x16, #96]
   18708:	f85c03a9 	ldur	x9, [x29, #-64]
   1870c:	a9020600 	stp	x0, x1, [x16, #32]
   18710:	2a0903eb 	mov	w11, w9
   18714:	f85e03a9 	ldur	x9, [x29, #-32]
   18718:	a9031203 	stp	x3, x4, [x16, #48]
   1871c:	a907320b 	stp	x11, x12, [x16, #112]
   18720:	f85f03ac 	ldur	x12, [x29, #-16]
   18724:	2a0903eb 	mov	w11, w9
   18728:	2a1103e9 	mov	w9, w17
   1872c:	2a0c03ec 	mov	w12, w12
   18730:	f9005a09 	str	x9, [x16, #176]
   18734:	a908320b 	stp	x11, x12, [x16, #128]
   18738:	2a1803eb 	mov	w11, w24
   1873c:	2a0a03ec 	mov	w12, w10
   18740:	a909320b 	stp	x11, x12, [x16, #144]
   18744:	2a1303eb 	mov	w11, w19
   18748:	2a1e03ea 	mov	w10, w30
   1874c:	a90a2a0b 	stp	x11, x10, [x16, #160]
   18750:	a944a7ea 	ldp	x10, x9, [sp, #72]
   18754:	a90ba60a 	stp	x10, x9, [x16, #184]
   18758:	f85b83a9 	ldur	x9, [x29, #-72]
   1875c:	f85c83aa 	ldur	x10, [x29, #-56]
   18760:	a90c8a09 	stp	x9, x2, [x16, #200]
   18764:	d2c4a009 	mov	x9, #0x250000000000        	// #40681930227712
   18768:	2a0a03ea 	mov	w10, w10
   1876c:	f2e0a009 	movk	x9, #0x500, lsl #48
   18770:	aa090100 	orr	x0, x8, x9
   18774:	f9006e0a 	str	x10, [x16, #216]
   18778:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   1877c:	9102c3ff 	add	sp, sp, #0xb0
   18780:	d65f03c0 	ret
   18784:	a90383e1 	stp	x1, x0, [sp, #56]
   18788:	aa1403e0 	mov	x0, x20
   1878c:	aa1503e1 	mov	x1, x21
   18790:	a9018be3 	stp	x3, x2, [sp, #24]
   18794:	528000a2 	mov	w2, #0x5                   	// #5
   18798:	a9029be5 	stp	x5, x6, [sp, #40]
   1879c:	a9009fe4 	stp	x4, x7, [sp, #8]
   187a0:	97ffb1bc 	bl	4e90 <heap_alloc_miss>
   187a4:	a94217e2 	ldp	x2, x5, [sp, #32]
   187a8:	aa0003e8 	mov	x8, x0
   187ac:	a9410fe7 	ldp	x7, x3, [sp, #16]
   187b0:	f94007e4 	ldr	x4, [sp, #8]
   187b4:	a94307e6 	ldp	x6, x1, [sp, #48]
   187b8:	f94023e0 	ldr	x0, [sp, #64]
   187bc:	17ffffa1 	b	18640 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_FALLBACK+0xdc>
   187c0:	a90383e1 	stp	x1, x0, [sp, #56]
   187c4:	aa1403e0 	mov	x0, x20
   187c8:	aa1503e1 	mov	x1, x21
   187cc:	a90217e2 	stp	x2, x5, [sp, #32]
   187d0:	528000a2 	mov	w2, #0x5                   	// #5
   187d4:	aa0403f5 	mov	x21, x4
   187d8:	f9001be6 	str	x6, [sp, #48]
   187dc:	aa0303f7 	mov	x23, x3
   187e0:	aa0703f6 	mov	x22, x7
   187e4:	97ffb1ab 	bl	4e90 <heap_alloc_miss>
   187e8:	a94217e2 	ldp	x2, x5, [sp, #32]
   187ec:	aa0003e8 	mov	x8, x0
   187f0:	a94307e6 	ldp	x6, x1, [sp, #48]
   187f4:	aa0c03f1 	mov	x17, x12
   187f8:	f85d03be 	ldur	x30, [x29, #-48]
   187fc:	f94023e0 	ldr	x0, [sp, #64]
   18800:	aa1603e7 	mov	x7, x22
   18804:	aa1703e3 	mov	x3, x23
   18808:	aa1503e4 	mov	x4, x21
   1880c:	17ffffaf 	b	186c8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_FALLBACK+0x164>

