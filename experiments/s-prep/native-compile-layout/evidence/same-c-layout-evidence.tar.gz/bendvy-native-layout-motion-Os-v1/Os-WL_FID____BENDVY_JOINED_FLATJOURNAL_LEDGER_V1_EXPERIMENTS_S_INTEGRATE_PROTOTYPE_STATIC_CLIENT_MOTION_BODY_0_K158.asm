   16920:	d10443ff 	sub	sp, sp, #0x110
   16924:	a9107bfd 	stp	x29, x30, [sp, #256]
   16928:	910403fd 	add	x29, sp, #0x100
   1692c:	aa0a03f3 	mov	x19, x10
   16930:	a93e97b9 	stp	x25, x5, [x29, #-24]
   16934:	b9405ba8 	ldr	w8, [x29, #88]
   16938:	a944abbe 	ldp	x30, x10, [x29, #72]
   1693c:	f9400bb0 	ldr	x16, [x29, #16]
   16940:	a94397b9 	ldp	x25, x5, [x29, #56]
   16944:	a942e3a2 	ldp	x2, x24, [x29, #40]
   16948:	a941c7b2 	ldp	x18, x17, [x29, #24]
   1694c:	34000468 	cbz	w8, 169d8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K158+0xb8>
   16950:	b85f8ec8 	ldr	w8, [x22, #-8]!
   16954:	a93db3b3 	stp	x19, x12, [x29, #-40]
   16958:	90000cd3 	adrp	x19, 1ae000 <io_eff_rows+0xff0d0>
   1695c:	913f2273 	add	x19, x19, #0xfc8
   16960:	1280000c 	mov	w12, #0xffffffff            	// #-1
   16964:	f8687a68 	ldr	x8, [x19, x8, lsl #3]
   16968:	a90533aa 	stp	x10, x12, [x29, #80]
   1696c:	2a1a03fa 	mov	w26, w26
   16970:	a9047ba5 	stp	x5, x30, [x29, #64]
   16974:	2a0703e7 	mov	w7, w7
   16978:	2a0b03eb 	mov	w11, w11
   1697c:	f81d03a8 	stur	x8, [x29, #-48]
   16980:	2a1803e8 	mov	w8, w24
   16984:	2a0d03ed 	mov	w13, w13
   16988:	a90367a8 	stp	x8, x25, [x29, #48]
   1698c:	2a0203e8 	mov	w8, w2
   16990:	2a0e03ee 	mov	w14, w14
   16994:	f90017a8 	str	x8, [x29, #40]
   16998:	2a1103e8 	mov	w8, w17
   1699c:	2a0903e9 	mov	w9, w9
   169a0:	f90013a8 	str	x8, [x29, #32]
   169a4:	a97ea3aa 	ldp	x10, x8, [x29, #-24]
   169a8:	2a0f03ef 	mov	w15, w15
   169ac:	52800398 	mov	w24, #0x1c                  	// #28
   169b0:	2a0a03f9 	mov	w25, w10
   169b4:	a97db3aa 	ldp	x10, x12, [x29, #-40]
   169b8:	2a0803e5 	mov	w5, w8
   169bc:	2a1003e8 	mov	w8, w16
   169c0:	2a1203f0 	mov	w16, w18
   169c4:	a90143a8 	stp	x8, x16, [x29, #16]
   169c8:	f85d03a2 	ldur	x2, [x29, #-48]
   169cc:	a9507bfd 	ldp	x29, x30, [sp, #256]
   169d0:	910443ff 	add	sp, sp, #0x110
   169d4:	d61f0040 	br	x2
   169d8:	a93c17b9 	stp	x25, x5, [x29, #-64]
   169dc:	f85e83b9 	ldur	x25, [x29, #-24]
   169e0:	f81d03aa 	stur	x10, [x29, #-48]
   169e4:	a93aebb5 	stp	x21, x26, [x29, #-88]
   169e8:	a9466ba5 	ldp	x5, x26, [x29, #96]
   169ec:	f81b83b8 	stur	x24, [x29, #-72]
   169f0:	a9472bb8 	ldp	x24, x10, [x29, #112]
   169f4:	340005d7 	cbz	w23, 16aac <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K158+0x18c>
   169f8:	2a0503e8 	mov	w8, w5
   169fc:	aa1003f5 	mov	x21, x16
   16a00:	2a1a03f0 	mov	w16, w26
   16a04:	a90042c8 	stp	x8, x16, [x22]
   16a08:	2a1803e8 	mov	w8, w24
   16a0c:	2a0a03f0 	mov	w16, w10
   16a10:	a90142c8 	stp	x8, x16, [x22, #16]
   16a14:	52800588 	mov	w8, #0x2c                  	// #44
   16a18:	2a1903f9 	mov	w25, w25
   16a1c:	f90012c8 	str	x8, [x22, #32]
   16a20:	110004a8 	add	w8, w5, #0x1
   16a24:	2a0703e7 	mov	w7, w7
   16a28:	f9002fa8 	str	x8, [x29, #88]
   16a2c:	f85d03a8 	ldur	x8, [x29, #-48]
   16a30:	2a0b03eb 	mov	w11, w11
   16a34:	2a0d03ed 	mov	w13, w13
   16a38:	2a0e03ee 	mov	w14, w14
   16a3c:	2a0903e9 	mov	w9, w9
   16a40:	a904a3be 	stp	x30, x8, [x29, #72]
   16a44:	f85c83a8 	ldur	x8, [x29, #-56]
   16a48:	2a0f03ef 	mov	w15, w15
   16a4c:	9100a2d6 	add	x22, x22, #0x28
   16a50:	aa1303ea 	mov	x10, x19
   16a54:	f90023a8 	str	x8, [x29, #64]
   16a58:	f85c03a8 	ldur	x8, [x29, #-64]
   16a5c:	f9001fa8 	str	x8, [x29, #56]
   16a60:	f85b83a8 	ldur	x8, [x29, #-72]
   16a64:	2a0803e8 	mov	w8, w8
   16a68:	f9001ba8 	str	x8, [x29, #48]
   16a6c:	2a0203e8 	mov	w8, w2
   16a70:	f90017a8 	str	x8, [x29, #40]
   16a74:	2a1103e8 	mov	w8, w17
   16a78:	f90013a8 	str	x8, [x29, #32]
   16a7c:	2a1203e8 	mov	w8, w18
   16a80:	f9000fa8 	str	x8, [x29, #24]
   16a84:	f85b03a8 	ldur	x8, [x29, #-80]
   16a88:	2a0803fa 	mov	w26, w8
   16a8c:	f85f03a8 	ldur	x8, [x29, #-16]
   16a90:	2a0803e5 	mov	w5, w8
   16a94:	2a1503e8 	mov	w8, w21
   16a98:	f85a83b5 	ldur	x21, [x29, #-88]
   16a9c:	f9000ba8 	str	x8, [x29, #16]
   16aa0:	a9507bfd 	ldp	x29, x30, [sp, #256]
   16aa4:	910443ff 	add	sp, sp, #0x110
   16aa8:	17ffd286 	b	b4c0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_TRANSACTION_DISPATCH_ADAPTERS_MOTION_SET_MAIN0>
   16aac:	f81a03a5 	stur	x5, [x29, #-96]
   16ab0:	a9020bf1 	stp	x17, x2, [sp, #32]
   16ab4:	a9031ff2 	stp	x18, x7, [sp, #48]
   16ab8:	a90473f0 	stp	x16, x28, [sp, #64]
   16abc:	aa1e03fc 	mov	x28, x30
   16ac0:	a90537eb 	stp	x11, x13, [sp, #80]
   16ac4:	f9000ffb 	str	x27, [sp, #24]
   16ac8:	aa0a03fb 	mov	x27, x10
   16acc:	f90033e0 	str	x0, [sp, #96]
   16ad0:	a9070fe1 	stp	x1, x3, [sp, #112]
   16ad4:	f90043e9 	str	x9, [sp, #128]
   16ad8:	a97ea2c9 	ldp	x9, x8, [x22, #-24]
   16adc:	f85a83b5 	ldur	x21, [x29, #-88]
   16ae0:	f81883a4 	stur	x4, [x29, #-120]
   16ae4:	f81983a6 	stur	x6, [x29, #-104]
   16ae8:	f9401ab7 	ldr	x23, [x21, #48]
   16aec:	f81d83b3 	stur	x19, [x29, #-40]
   16af0:	a900a7e8 	stp	x8, x9, [sp, #8]
   16af4:	f81e03ac 	stur	x12, [x29, #-32]
   16af8:	f81903af 	stur	x15, [x29, #-112]
   16afc:	f90037ee 	str	x14, [sp, #104]
   16b00:	b4000c17 	cbz	x23, 16c80 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K158+0x360>
   16b04:	f8777a88 	ldr	x8, [x20, x23, lsl #3]
   16b08:	f9409aa9 	ldr	x9, [x21, #304]
   16b0c:	f9001aa8 	str	x8, [x21, #48]
   16b10:	d1010128 	sub	x8, x9, #0x40
   16b14:	f9009aa8 	str	x8, [x21, #304]
   16b18:	8b170e93 	add	x19, x20, x23, lsl #3
   16b1c:	52801fe1 	mov	w1, #0xff                  	// #255
   16b20:	52801b02 	mov	w2, #0xd8                  	// #216
   16b24:	91008260 	add	x0, x19, #0x20
   16b28:	97ffb3f2 	bl	3af0 <memset@plt>
   16b2c:	f85a03b1 	ldur	x17, [x29, #-96]
   16b30:	2a1a03ea 	mov	w10, w26
   16b34:	52800029 	mov	w9, #0x1                   	// #1
   16b38:	2a1103e8 	mov	w8, w17
   16b3c:	a9002a68 	stp	x8, x10, [x19]
   16b40:	f94007e8 	ldr	x8, [sp, #8]
   16b44:	d2c5800a 	mov	x10, #0x2c0000000000        	// #48378511622144
   16b48:	f2e0a00a 	movk	x10, #0x500, lsl #48
   16b4c:	aa088128 	orr	x8, x9, x8, lsl #32
   16b50:	f9400be9 	ldr	x9, [sp, #16]
   16b54:	a90fa269 	stp	x9, x8, [x19, #248]
   16b58:	2a1803e9 	mov	w9, w24
   16b5c:	2a1b03e8 	mov	w8, w27
   16b60:	a9012269 	stp	x9, x8, [x19, #16]
   16b64:	aa0a02e9 	orr	x9, x23, x10
   16b68:	52800088 	mov	w8, #0x4                   	// #4
   16b6c:	a93ea2c9 	stp	x9, x8, [x22, #-24]
   16b70:	f94016a0 	ldr	x0, [x21, #40]
   16b74:	b4000920 	cbz	x0, 16c98 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K158+0x378>
   16b78:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   16b7c:	f94096aa 	ldr	x10, [x21, #296]
   16b80:	f90016a8 	str	x8, [x21, #40]
   16b84:	d1008148 	sub	x8, x10, #0x20
   16b88:	f90096a8 	str	x8, [x21, #296]
   16b8c:	a97b3bb0 	ldp	x16, x14, [x29, #-80]
   16b90:	8b000e88 	add	x8, x20, x0, lsl #3
   16b94:	d2c0008a 	mov	x10, #0x400000000           	// #17179869184
   16b98:	f85f03af 	ldur	x15, [x29, #-16]
   16b9c:	f85e03ab 	ldur	x11, [x29, #-32]
   16ba0:	a90e2909 	stp	x9, x10, [x8, #224]
   16ba4:	2a1903e9 	mov	w9, w25
   16ba8:	f85903ac 	ldur	x12, [x29, #-112]
   16bac:	2a1003ea 	mov	w10, w16
   16bb0:	a9002909 	stp	x9, x10, [x8]
   16bb4:	f9400fea 	ldr	x10, [sp, #24]
   16bb8:	f94027e9 	ldr	x9, [sp, #72]
   16bbc:	a901250a 	stp	x10, x9, [x8, #16]
   16bc0:	a94637ea 	ldp	x10, x13, [sp, #96]
   16bc4:	f9403be9 	ldr	x9, [sp, #112]
   16bc8:	a902250a 	stp	x10, x9, [x8, #32]
   16bcc:	f9403fea 	ldr	x10, [sp, #120]
   16bd0:	f85883a9 	ldur	x9, [x29, #-120]
   16bd4:	a903250a 	stp	x10, x9, [x8, #48]
   16bd8:	2a0f03e9 	mov	w9, w15
   16bdc:	f85983aa 	ldur	x10, [x29, #-104]
   16be0:	f9002109 	str	x9, [x8, #64]
   16be4:	f9401fe9 	ldr	x9, [sp, #56]
   16be8:	2a0903e9 	mov	w9, w9
   16bec:	a904a50a 	stp	x10, x9, [x8, #72]
   16bf0:	f9402be9 	ldr	x9, [sp, #80]
   16bf4:	f85d83aa 	ldur	x10, [x29, #-40]
   16bf8:	2a0903e9 	mov	w9, w9
   16bfc:	a905a50a 	stp	x10, x9, [x8, #88]
   16c00:	f9402fe9 	ldr	x9, [sp, #88]
   16c04:	2a0d03ea 	mov	w10, w13
   16c08:	f9003d0a 	str	x10, [x8, #120]
   16c0c:	2a0c03ea 	mov	w10, w12
   16c10:	2a0903e9 	mov	w9, w9
   16c14:	a906a50b 	stp	x11, x9, [x8, #104]
   16c18:	f94043e9 	ldr	x9, [sp, #128]
   16c1c:	2a0903e9 	mov	w9, w9
   16c20:	a9082909 	stp	x9, x10, [x8, #128]
   16c24:	f94023e9 	ldr	x9, [sp, #64]
   16c28:	f9401bea 	ldr	x10, [sp, #48]
   16c2c:	2a0903e9 	mov	w9, w9
   16c30:	2a0a03ea 	mov	w10, w10
   16c34:	a9092909 	stp	x9, x10, [x8, #144]
   16c38:	a9422be9 	ldp	x9, x10, [sp, #32]
   16c3c:	2a0903e9 	mov	w9, w9
   16c40:	2a0a03ea 	mov	w10, w10
   16c44:	a90a2909 	stp	x9, x10, [x8, #160]
   16c48:	2a0e03e9 	mov	w9, w14
   16c4c:	f9005909 	str	x9, [x8, #176]
   16c50:	a97c27aa 	ldp	x10, x9, [x29, #-64]
   16c54:	a90ba50a 	stp	x10, x9, [x8, #184]
   16c58:	d2c16009 	mov	x9, #0xb0000000000         	// #12094627905536
   16c5c:	1100062a 	add	w10, w17, #0x1
   16c60:	f2e0a009 	movk	x9, #0x500, lsl #48
   16c64:	aa090000 	orr	x0, x0, x9
   16c68:	f85d03a9 	ldur	x9, [x29, #-48]
   16c6c:	a90ca51c 	stp	x28, x9, [x8, #200]
   16c70:	f9006d0a 	str	x10, [x8, #216]
   16c74:	a9507bfd 	ldp	x29, x30, [sp, #256]
   16c78:	910443ff 	add	sp, sp, #0x110
   16c7c:	d65f03c0 	ret
   16c80:	aa1403e0 	mov	x0, x20
   16c84:	aa1503e1 	mov	x1, x21
   16c88:	528000c2 	mov	w2, #0x6                   	// #6
   16c8c:	97ffb7b8 	bl	4b6c <heap_alloc_miss>
   16c90:	aa0003f7 	mov	x23, x0
   16c94:	17ffffa1 	b	16b18 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K158+0x1f8>
   16c98:	aa1403e0 	mov	x0, x20
   16c9c:	aa1503e1 	mov	x1, x21
   16ca0:	528000a2 	mov	w2, #0x5                   	// #5
   16ca4:	97ffb7b2 	bl	4b6c <heap_alloc_miss>
   16ca8:	f85a03b1 	ldur	x17, [x29, #-96]
   16cac:	17ffffb8 	b	16b8c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K158+0x26c>

