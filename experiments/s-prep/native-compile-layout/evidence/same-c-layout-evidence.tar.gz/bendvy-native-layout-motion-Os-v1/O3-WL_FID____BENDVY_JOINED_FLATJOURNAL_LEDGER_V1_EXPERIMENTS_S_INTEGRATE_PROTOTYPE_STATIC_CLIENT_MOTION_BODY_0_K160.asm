   18148:	d102c3ff 	sub	sp, sp, #0xb0
   1814c:	a90a7bfd 	stp	x29, x30, [sp, #160]
   18150:	910283fd 	add	x29, sp, #0xa0
   18154:	a93db3af 	stp	x15, x12, [x29, #-40]
   18158:	aa0b03f0 	mov	x16, x11
   1815c:	b9405ba8 	ldr	w8, [x29, #88]
   18160:	a93e9baa 	stp	x10, x6, [x29, #-24]
   18164:	a944cba2 	ldp	x2, x18, [x29, #72]
   18168:	a943fbaa 	ldp	x10, x30, [x29, #56]
   1816c:	7100051f 	cmp	w8, #0x1
   18170:	a942cfab 	ldp	x11, x19, [x29, #40]
   18174:	f9400bb8 	ldr	x24, [x29, #16]
   18178:	a941bfac 	ldp	x12, x15, [x29, #24]
   1817c:	54000681 	b.ne	1824c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K160+0x104>  // b.any
   18180:	aa1603e8 	mov	x8, x22
   18184:	a9043ff0 	stp	x16, x15, [sp, #64]
   18188:	f9002bea 	str	x10, [sp, #80]
   1818c:	a93bcbbe 	stp	x30, x18, [x29, #-72]
   18190:	f94033be 	ldr	x30, [x29, #96]
   18194:	a93ca7bc 	stp	x28, x9, [x29, #-56]
   18198:	b85f0d1c 	ldr	w28, [x8, #-16]!
   1819c:	b85f0110 	ldur	w16, [x8, #-16]
   181a0:	b85f8111 	ldur	w17, [x8, #-8]
   181a4:	b9400912 	ldr	w18, [x8, #8]
   181a8:	0b100230 	add	w16, w17, w16
   181ac:	0b120391 	add	w17, w28, w18
   181b0:	0b11021c 	add	w28, w16, w17
   181b4:	340008b7 	cbz	w23, 182c8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K160+0x180>
   181b8:	a97baba9 	ldp	x9, x10, [x29, #-72]
   181bc:	528005d0 	mov	w16, #0x2e                  	// #46
   181c0:	a93e42dc 	stp	x28, x16, [x22, #-32]
   181c4:	110007d0 	add	w16, w30, #0x1
   181c8:	f85c83bc 	ldur	x28, [x29, #-56]
   181cc:	2a1903f9 	mov	w25, w25
   181d0:	2a1a03fa 	mov	w26, w26
   181d4:	2a0503e5 	mov	w5, w5
   181d8:	a904aba2 	stp	x2, x10, [x29, #72]
   181dc:	2a0703e7 	mov	w7, w7
   181e0:	2a0d03ed 	mov	w13, w13
   181e4:	f90023a9 	str	x9, [x29, #64]
   181e8:	2a1303e9 	mov	w9, w19
   181ec:	2a0e03ee 	mov	w14, w14
   181f0:	f9402bea 	ldr	x10, [sp, #80]
   181f4:	aa0803f6 	mov	x22, x8
   181f8:	a9032ba9 	stp	x9, x10, [x29, #48]
   181fc:	2a0b03e9 	mov	w9, w11
   18200:	f90017a9 	str	x9, [x29, #40]
   18204:	f94027e9 	ldr	x9, [sp, #72]
   18208:	2a0903e9 	mov	w9, w9
   1820c:	f90013a9 	str	x9, [x29, #32]
   18210:	2a0c03e9 	mov	w9, w12
   18214:	f85e03ac 	ldur	x12, [x29, #-32]
   18218:	f9000fa9 	str	x9, [x29, #24]
   1821c:	2a1803e9 	mov	w9, w24
   18220:	f9000ba9 	str	x9, [x29, #16]
   18224:	f94023e9 	ldr	x9, [sp, #64]
   18228:	2a0903eb 	mov	w11, w9
   1822c:	a97d2ba9 	ldp	x9, x10, [x29, #-48]
   18230:	2a0a03ef 	mov	w15, w10
   18234:	a97e9baa 	ldp	x10, x6, [x29, #-24]
   18238:	2a0903e9 	mov	w9, w9
   1823c:	f9002fb0 	str	x16, [x29, #88]
   18240:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   18244:	9102c3ff 	add	sp, sp, #0xb0
   18248:	17ffc26b 	b	8bf4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_TRANSACTION_DISPATCH_ADAPTERS_MOTION_SET_LEDGER0>
   1824c:	b85d8ec8 	ldr	w8, [x22, #-40]!
   18250:	d0000cb1 	adrp	x17, 1ae000 <io_eff_rows+0xff118>
   18254:	913f2231 	add	x17, x17, #0xfc8
   18258:	12800006 	mov	w6, #0xffffffff            	// #-1
   1825c:	2a1903f9 	mov	w25, w25
   18260:	f8687a31 	ldr	x17, [x17, x8, lsl #3]
   18264:	2a1303e8 	mov	w8, w19
   18268:	a9051bb2 	stp	x18, x6, [x29, #80]
   1826c:	a9032ba8 	stp	x8, x10, [x29, #48]
   18270:	2a0b03e8 	mov	w8, w11
   18274:	2a1003eb 	mov	w11, w16
   18278:	f90017a8 	str	x8, [x29, #40]
   1827c:	2a0f03e8 	mov	w8, w15
   18280:	2a0c03f0 	mov	w16, w12
   18284:	f90013a8 	str	x8, [x29, #32]
   18288:	a97db3a8 	ldp	x8, x12, [x29, #-40]
   1828c:	2a1a03fa 	mov	w26, w26
   18290:	a97e9baa 	ldp	x10, x6, [x29, #-24]
   18294:	a9040bbe 	stp	x30, x2, [x29, #64]
   18298:	2a0803ef 	mov	w15, w8
   1829c:	2a1803e8 	mov	w8, w24
   182a0:	2a0503e5 	mov	w5, w5
   182a4:	2a0703e7 	mov	w7, w7
   182a8:	2a0d03ed 	mov	w13, w13
   182ac:	2a0e03ee 	mov	w14, w14
   182b0:	2a0903e9 	mov	w9, w9
   182b4:	a90143a8 	stp	x8, x16, [x29, #16]
   182b8:	52800398 	mov	w24, #0x1c                  	// #28
   182bc:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   182c0:	9102c3ff 	add	sp, sp, #0xb0
   182c4:	d61f0220 	br	x17
   182c8:	a97cdecf 	ldp	x15, x23, [x22, #-56]
   182cc:	aa1803ea 	mov	x10, x24
   182d0:	f94016a8 	ldr	x8, [x21, #40]
   182d4:	f9001ffe 	str	x30, [sp, #56]
   182d8:	b4000b88 	cbz	x8, 18448 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K160+0x300>
   182dc:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   182e0:	f94096b1 	ldr	x17, [x21, #296]
   182e4:	aa0c03fe 	mov	x30, x12
   182e8:	f90016b0 	str	x16, [x21, #40]
   182ec:	d1008230 	sub	x16, x17, #0x20
   182f0:	f90096b0 	str	x16, [x21, #296]
   182f4:	8b080e90 	add	x16, x20, x8, lsl #3
   182f8:	6f07e7e0 	movi	v0.2d, #0xffffffffffffffff
   182fc:	92800011 	mov	x17, #0xffffffffffffffff    	// #-1
   18300:	52800032 	mov	w18, #0x1                   	// #1
   18304:	aa1303f8 	mov	x24, x19
   18308:	aa0b03f3 	mov	x19, x11
   1830c:	a90dbe11 	stp	x17, x15, [x16, #216]
   18310:	d2c5c011 	mov	x17, #0x2e0000000000        	// #50577534877696
   18314:	aa178257 	orr	x23, x18, x23, lsl #32
   18318:	f2e0a011 	movk	x17, #0x500, lsl #48
   1831c:	f900021c 	str	x28, [x16]
   18320:	aa11011c 	orr	x28, x8, x17
   18324:	3c8c8200 	stur	q0, [x16, #200]
   18328:	3c8b8200 	stur	q0, [x16, #184]
   1832c:	3c8a8200 	stur	q0, [x16, #168]
   18330:	3c898200 	stur	q0, [x16, #152]
   18334:	3c888200 	stur	q0, [x16, #136]
   18338:	3c878200 	stur	q0, [x16, #120]
   1833c:	3c868200 	stur	q0, [x16, #104]
   18340:	3c858200 	stur	q0, [x16, #88]
   18344:	3c848200 	stur	q0, [x16, #72]
   18348:	3c838200 	stur	q0, [x16, #56]
   1834c:	3c828200 	stur	q0, [x16, #40]
   18350:	3c818200 	stur	q0, [x16, #24]
   18354:	3c808200 	stur	q0, [x16, #8]
   18358:	f9007617 	str	x23, [x16, #232]
   1835c:	a93ccadc 	stp	x28, x18, [x22, #-56]
   18360:	f94016a8 	ldr	x8, [x21, #40]
   18364:	b4000928 	cbz	x8, 18488 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K160+0x340>
   18368:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   1836c:	f94096b1 	ldr	x17, [x21, #296]
   18370:	f90016b0 	str	x16, [x21, #40]
   18374:	d1008230 	sub	x16, x17, #0x20
   18378:	f90096b0 	str	x16, [x21, #296]
   1837c:	8b080e90 	add	x16, x20, x8, lsl #3
   18380:	f85c83a9 	ldur	x9, [x29, #-56]
   18384:	d2c00031 	mov	x17, #0x100000000           	// #4294967296
   18388:	2a1903f2 	mov	w18, w25
   1838c:	f94023eb 	ldr	x11, [sp, #64]
   18390:	2a0e03ec 	mov	w12, w14
   18394:	a90e461c 	stp	x28, x17, [x16, #224]
   18398:	2a1a03f1 	mov	w17, w26
   1839c:	a901261b 	stp	x27, x9, [x16, #16]
   183a0:	f85f03a9 	ldur	x9, [x29, #-16]
   183a4:	2a0b03eb 	mov	w11, w11
   183a8:	a9004612 	stp	x18, x17, [x16]
   183ac:	2a0503f1 	mov	w17, w5
   183b0:	a9042611 	stp	x17, x9, [x16, #64]
   183b4:	f85e83a9 	ldur	x9, [x29, #-24]
   183b8:	2a0703f1 	mov	w17, w7
   183bc:	a9020600 	stp	x0, x1, [x16, #32]
   183c0:	a9052611 	stp	x17, x9, [x16, #80]
   183c4:	f85e03a9 	ldur	x9, [x29, #-32]
   183c8:	a9031203 	stp	x3, x4, [x16, #48]
   183cc:	a906260b 	stp	x11, x9, [x16, #96]
   183d0:	f85d03a9 	ldur	x9, [x29, #-48]
   183d4:	2a0d03eb 	mov	w11, w13
   183d8:	a907320b 	stp	x11, x12, [x16, #112]
   183dc:	2a1e03ec 	mov	w12, w30
   183e0:	2a0903eb 	mov	w11, w9
   183e4:	f85d83a9 	ldur	x9, [x29, #-40]
   183e8:	2a0903ef 	mov	w15, w9
   183ec:	f94027e9 	ldr	x9, [sp, #72]
   183f0:	a9083e0b 	stp	x11, x15, [x16, #128]
   183f4:	2a0a03eb 	mov	w11, w10
   183f8:	f9401fea 	ldr	x10, [sp, #56]
   183fc:	a909320b 	stp	x11, x12, [x16, #144]
   18400:	2a0903eb 	mov	w11, w9
   18404:	2a1303ec 	mov	w12, w19
   18408:	2a1803e9 	mov	w9, w24
   1840c:	a90a320b 	stp	x11, x12, [x16, #160]
   18410:	f9402beb 	ldr	x11, [sp, #80]
   18414:	f9005a09 	str	x9, [x16, #176]
   18418:	f85b83a9 	ldur	x9, [x29, #-72]
   1841c:	1100054a 	add	w10, w10, #0x1
   18420:	a90ba60b 	stp	x11, x9, [x16, #184]
   18424:	d2c08009 	mov	x9, #0x40000000000         	// #4398046511104
   18428:	f2e0a009 	movk	x9, #0x500, lsl #48
   1842c:	aa090100 	orr	x0, x8, x9
   18430:	f85c03a8 	ldur	x8, [x29, #-64]
   18434:	a90ca202 	stp	x2, x8, [x16, #200]
   18438:	f9006e0a 	str	x10, [x16, #216]
   1843c:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   18440:	9102c3ff 	add	sp, sp, #0xb0
   18444:	d65f03c0 	ret
   18448:	a90283e1 	stp	x1, x0, [sp, #40]
   1844c:	aa1403e0 	mov	x0, x20
   18450:	aa1503e1 	mov	x1, x21
   18454:	aa0203e9 	mov	x9, x2
   18458:	528000a2 	mov	w2, #0x5                   	// #5
   1845c:	a9009fe4 	stp	x4, x7, [sp, #8]
   18460:	a9018fe5 	stp	x5, x3, [sp, #24]
   18464:	97ffb28b 	bl	4e90 <heap_alloc_miss>
   18468:	a94117e7 	ldp	x7, x5, [sp, #16]
   1846c:	aa0003e8 	mov	x8, x0
   18470:	a94207e3 	ldp	x3, x1, [sp, #32]
   18474:	aa0c03fe 	mov	x30, x12
   18478:	f94007e4 	ldr	x4, [sp, #8]
   1847c:	f9401be0 	ldr	x0, [sp, #48]
   18480:	aa0903e2 	mov	x2, x9
   18484:	17ffff9c 	b	182f4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K160+0x1ac>
   18488:	a90283e1 	stp	x1, x0, [sp, #40]
   1848c:	aa1403e0 	mov	x0, x20
   18490:	aa1503e1 	mov	x1, x21
   18494:	aa0203e9 	mov	x9, x2
   18498:	528000a2 	mov	w2, #0x5                   	// #5
   1849c:	aa0403f6 	mov	x22, x4
   184a0:	f90013e3 	str	x3, [sp, #32]
   184a4:	aa0703f5 	mov	x21, x7
   184a8:	aa0503f7 	mov	x23, x5
   184ac:	97ffb279 	bl	4e90 <heap_alloc_miss>
   184b0:	a94207e3 	ldp	x3, x1, [sp, #32]
   184b4:	aa0003e8 	mov	x8, x0
   184b8:	f9401be0 	ldr	x0, [sp, #48]
   184bc:	aa0c03fe 	mov	x30, x12
   184c0:	aa0903e2 	mov	x2, x9
   184c4:	aa1703e5 	mov	x5, x23
   184c8:	aa1503e7 	mov	x7, x21
   184cc:	aa1603e4 	mov	x4, x22
   184d0:	17ffffab 	b	1837c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K160+0x234>

