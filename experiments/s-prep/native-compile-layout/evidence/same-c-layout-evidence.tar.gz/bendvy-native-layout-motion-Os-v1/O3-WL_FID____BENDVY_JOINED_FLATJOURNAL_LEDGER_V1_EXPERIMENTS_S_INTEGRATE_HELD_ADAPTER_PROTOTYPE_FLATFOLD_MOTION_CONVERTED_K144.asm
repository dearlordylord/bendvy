   17370:	d100c3ff 	sub	sp, sp, #0x30
   17374:	a9027bfd 	stp	x29, x30, [sp, #32]
   17378:	b94033e8 	ldr	w8, [sp, #48]
   1737c:	a90133e8 	stp	x8, x12, [sp, #16]
   17380:	aa0a03ec 	mov	x12, x10
   17384:	a946f7ea 	ldp	x10, x29, [sp, #104]
   17388:	f0000cb8 	adrp	x24, 1ae000 <io_eff_rows+0xff118>
   1738c:	913f2318 	add	x24, x24, #0xfc8
   17390:	b94053f0 	ldr	w16, [sp, #80]
   17394:	b85f0ec2 	ldr	w2, [x22, #-16]!
   17398:	b9404bf1 	ldr	w17, [sp, #72]
   1739c:	a945fbe8 	ldp	x8, x30, [sp, #88]
   173a0:	2a1903f9 	mov	w25, w25
   173a4:	f8627b02 	ldr	x2, [x24, x2, lsl #3]
   173a8:	b9400ad8 	ldr	w24, [x22, #8]
   173ac:	2a1a03fa 	mov	w26, w26
   173b0:	f90037ea 	str	x10, [sp, #104]
   173b4:	aa0c03ea 	mov	x10, x12
   173b8:	b94043f2 	ldr	w18, [sp, #64]
   173bc:	a905fbe8 	stp	x8, x30, [sp, #88]
   173c0:	a94133e8 	ldp	x8, x12, [sp, #16]
   173c4:	b9403bf3 	ldr	w19, [sp, #56]
   173c8:	2a0503e5 	mov	w5, w5
   173cc:	2a0703e7 	mov	w7, w7
   173d0:	a90763fd 	stp	x29, x24, [sp, #112]
   173d4:	a9427bfd 	ldp	x29, x30, [sp, #32]
   173d8:	a903cbf3 	stp	x19, x18, [sp, #56]
   173dc:	2a0b03eb 	mov	w11, w11
   173e0:	2a0d03ed 	mov	w13, w13
   173e4:	a904c3f1 	stp	x17, x16, [sp, #72]
   173e8:	2a0e03ee 	mov	w14, w14
   173ec:	2a0903e9 	mov	w9, w9
   173f0:	2a0f03ef 	mov	w15, w15
   173f4:	52800398 	mov	w24, #0x1c                  	// #28
   173f8:	f8030fe8 	str	x8, [sp, #48]!
   173fc:	d61f0040 	br	x2

