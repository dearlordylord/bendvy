   166c4:	d10383ff 	sub	sp, sp, #0xe0
   166c8:	a90d7bfd 	stp	x29, x30, [sp, #208]
   166cc:	910343fd 	add	x29, sp, #0xd0
   166d0:	a93e2bad 	stp	x13, x10, [x29, #-32]
   166d4:	a944cbb0 	ldp	x16, x18, [x29, #72]
   166d8:	a943b7a8 	ldp	x8, x13, [x29, #56]
   166dc:	f9400ba2 	ldr	x2, [x29, #16]
   166e0:	f81f03ac 	stur	x12, [x29, #-16]
   166e4:	a942c7be 	ldp	x30, x17, [x29, #40]
   166e8:	a941e3b3 	ldp	x19, x24, [x29, #24]
   166ec:	340003f7 	cbz	w23, 16768 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0+0xa4>
   166f0:	aa1b03ea 	mov	x10, x27
   166f4:	aa0803fb 	mov	x27, x8
   166f8:	52800568 	mov	w8, #0x2b                  	// #43
   166fc:	f80086c8 	str	x8, [x22], #8
   16700:	f85e03a8 	ldur	x8, [x29, #-32]
   16704:	2a1903ec 	mov	w12, w25
   16708:	a904cbb0 	stp	x16, x18, [x29, #72]
   1670c:	2a1e03f0 	mov	w16, w30
   16710:	a903b7bb 	stp	x27, x13, [x29, #56]
   16714:	2a0803ed 	mov	w13, w8
   16718:	2a1103e8 	mov	w8, w17
   1671c:	a902a3b0 	stp	x16, x8, [x29, #40]
   16720:	2a1803e8 	mov	w8, w24
   16724:	2a1303f0 	mov	w16, w19
   16728:	aa0c03f9 	mov	x25, x12
   1672c:	aa0a03fb 	mov	x27, x10
   16730:	a901a3b0 	stp	x16, x8, [x29, #24]
   16734:	a97eb3aa 	ldp	x10, x12, [x29, #-24]
   16738:	2a0203e8 	mov	w8, w2
   1673c:	2a1a03fa 	mov	w26, w26
   16740:	2a0503e5 	mov	w5, w5
   16744:	2a0703e7 	mov	w7, w7
   16748:	2a0b03eb 	mov	w11, w11
   1674c:	2a0e03ee 	mov	w14, w14
   16750:	2a0903e9 	mov	w9, w9
   16754:	2a0f03ef 	mov	w15, w15
   16758:	f9000ba8 	str	x8, [x29, #16]
   1675c:	a94d7bfd 	ldp	x29, x30, [sp, #208]
   16760:	910383ff 	add	sp, sp, #0xe0
   16764:	17fff016 	b	127bc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_TRANSACTION_DISPATCH_ADAPTERS_MOTION_READ_MAIN>
   16768:	a90017fb 	stp	x27, x5, [sp]
   1676c:	f9401ab7 	ldr	x23, [x21, #48]
   16770:	f9000be7 	str	x7, [sp, #16]
   16774:	f81b03bc 	stur	x28, [x29, #-80]
   16778:	a90183eb 	stp	x11, x0, [sp, #24]
   1677c:	a9028be1 	stp	x1, x2, [sp, #40]
   16780:	f9001fe3 	str	x3, [sp, #56]
   16784:	f81b83b3 	stur	x19, [x29, #-72]
   16788:	f90023e4 	str	x4, [sp, #64]
   1678c:	f81c03b8 	stur	x24, [x29, #-64]
   16790:	a97ee2dc 	ldp	x28, x24, [x22, #-24]
   16794:	a9049bee 	stp	x14, x6, [sp, #72]
   16798:	a905c3f1 	stp	x17, x16, [sp, #88]
   1679c:	a93a4ba9 	stp	x9, x18, [x29, #-96]
   167a0:	a93d3fa8 	stp	x8, x15, [x29, #-48]
   167a4:	f90037ed 	str	x13, [sp, #104]
   167a8:	f81c83be 	stur	x30, [x29, #-56]
   167ac:	b4000a57 	cbz	x23, 168f4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0+0x230>
   167b0:	f8777a88 	ldr	x8, [x20, x23, lsl #3]
   167b4:	f9409aa9 	ldr	x9, [x21, #304]
   167b8:	f9001aa8 	str	x8, [x21, #48]
   167bc:	d1010128 	sub	x8, x9, #0x40
   167c0:	f9009aa8 	str	x8, [x21, #304]
   167c4:	8b170e93 	add	x19, x20, x23, lsl #3
   167c8:	52801fe1 	mov	w1, #0xff                  	// #255
   167cc:	52802102 	mov	w2, #0x108                 	// #264
   167d0:	aa1303e0 	mov	x0, x19
   167d4:	97ffb4c7 	bl	3af0 <memset@plt>
   167d8:	52800028 	mov	w8, #0x1                   	// #1
   167dc:	d2c56009 	mov	x9, #0x2b0000000000        	// #47278999994368
   167e0:	aa188108 	orr	x8, x8, x24, lsl #32
   167e4:	f2e0a009 	movk	x9, #0x500, lsl #48
   167e8:	aa0902e9 	orr	x9, x23, x9
   167ec:	a910a27c 	stp	x28, x8, [x19, #264]
   167f0:	f94003f3 	ldr	x19, [sp]
   167f4:	a93efec9 	stp	x9, xzr, [x22, #-24]
   167f8:	f94016a0 	ldr	x0, [x21, #40]
   167fc:	b4000880 	cbz	x0, 1690c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0+0x248>
   16800:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   16804:	f94096aa 	ldr	x10, [x21, #296]
   16808:	f90016a8 	str	x8, [x21, #40]
   1680c:	d1008148 	sub	x8, x10, #0x20
   16810:	f90096a8 	str	x8, [x21, #296]
   16814:	8b000e88 	add	x8, x20, x0, lsl #3
   16818:	2a1903ea 	mov	w10, w25
   1681c:	2a1a03eb 	mov	w11, w26
   16820:	f85f03ac 	ldur	x12, [x29, #-16]
   16824:	a97d37ae 	ldp	x14, x13, [x29, #-48]
   16828:	a9002d0a 	stp	x10, x11, [x8]
   1682c:	a9422beb 	ldp	x11, x10, [sp, #32]
   16830:	a97b47b2 	ldp	x18, x17, [x29, #-80]
   16834:	f9006d09 	str	x9, [x8, #216]
   16838:	a97c3fb0 	ldp	x16, x15, [x29, #-64]
   1683c:	f85a83a9 	ldur	x9, [x29, #-88]
   16840:	a902290b 	stp	x11, x10, [x8, #32]
   16844:	a943abeb 	ldp	x11, x10, [sp, #56]
   16848:	f900711f 	str	xzr, [x8, #224]
   1684c:	a9014913 	stp	x19, x18, [x8, #16]
   16850:	a903290b 	stp	x11, x10, [x8, #48]
   16854:	f94007ea 	ldr	x10, [sp, #8]
   16858:	2a0a03ea 	mov	w10, w10
   1685c:	f900210a 	str	x10, [x8, #64]
   16860:	a944abeb 	ldp	x11, x10, [sp, #72]
   16864:	f900250a 	str	x10, [x8, #72]
   16868:	f9400bea 	ldr	x10, [sp, #16]
   1686c:	2a0b03eb 	mov	w11, w11
   16870:	2a0a03ea 	mov	w10, w10
   16874:	f900290a 	str	x10, [x8, #80]
   16878:	f85e83aa 	ldur	x10, [x29, #-24]
   1687c:	f9002d0a 	str	x10, [x8, #88]
   16880:	f9400fea 	ldr	x10, [sp, #24]
   16884:	2a0a03ea 	mov	w10, w10
   16888:	a906310a 	stp	x10, x12, [x8, #96]
   1688c:	f85e03aa 	ldur	x10, [x29, #-32]
   16890:	2a0a03ea 	mov	w10, w10
   16894:	a9072d0a 	stp	x10, x11, [x8, #112]
   16898:	f85a03aa 	ldur	x10, [x29, #-96]
   1689c:	2a0d03eb 	mov	w11, w13
   168a0:	2a0a03ea 	mov	w10, w10
   168a4:	a9082d0a 	stp	x10, x11, [x8, #128]
   168a8:	f9401bea 	ldr	x10, [sp, #48]
   168ac:	2a1103eb 	mov	w11, w17
   168b0:	2a0a03ea 	mov	w10, w10
   168b4:	a9092d0a 	stp	x10, x11, [x8, #144]
   168b8:	2a1003ea 	mov	w10, w16
   168bc:	2a0f03eb 	mov	w11, w15
   168c0:	a90a2d0a 	stp	x10, x11, [x8, #160]
   168c4:	f9402fea 	ldr	x10, [sp, #88]
   168c8:	2a0a03ea 	mov	w10, w10
   168cc:	a90b390a 	stp	x10, x14, [x8, #176]
   168d0:	a9462fea 	ldp	x10, x11, [sp, #96]
   168d4:	a90c290b 	stp	x11, x10, [x8, #192]
   168d8:	d2c3c00a 	mov	x10, #0x1e0000000000        	// #32985348833280
   168dc:	f2e0a00a 	movk	x10, #0x500, lsl #48
   168e0:	aa0a0000 	orr	x0, x0, x10
   168e4:	f9006909 	str	x9, [x8, #208]
   168e8:	a94d7bfd 	ldp	x29, x30, [sp, #208]
   168ec:	910383ff 	add	sp, sp, #0xe0
   168f0:	d65f03c0 	ret
   168f4:	aa1403e0 	mov	x0, x20
   168f8:	aa1503e1 	mov	x1, x21
   168fc:	528000c2 	mov	w2, #0x6                   	// #6
   16900:	97ffb89b 	bl	4b6c <heap_alloc_miss>
   16904:	aa0003f7 	mov	x23, x0
   16908:	17ffffaf 	b	167c4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0+0x100>
   1690c:	aa1403e0 	mov	x0, x20
   16910:	aa1503e1 	mov	x1, x21
   16914:	528000a2 	mov	w2, #0x5                   	// #5
   16918:	97ffb895 	bl	4b6c <heap_alloc_miss>
   1691c:	17ffffbe 	b	16814 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0+0x150>

