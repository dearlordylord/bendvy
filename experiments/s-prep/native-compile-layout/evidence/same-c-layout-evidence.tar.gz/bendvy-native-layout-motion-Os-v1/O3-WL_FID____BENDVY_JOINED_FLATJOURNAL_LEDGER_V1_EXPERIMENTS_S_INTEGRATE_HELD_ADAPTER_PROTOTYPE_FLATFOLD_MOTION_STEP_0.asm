   19648:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
   1964c:	910003fd 	mov	x29, sp
   19650:	d10943ff 	sub	sp, sp, #0x250
   19654:	f94027a8 	ldr	x8, [x29, #72]
   19658:	aa0903f2 	mov	x18, x9
   1965c:	aa0a03f0 	mov	x16, x10
   19660:	a94647be 	ldp	x30, x17, [x29, #96]
   19664:	6b19037f 	cmp	w27, w25
   19668:	a9351ba8 	stp	x8, x6, [x29, #-176]
   1966c:	f9401ba8 	ldr	x8, [x29, #48]
   19670:	a9450ba9 	ldp	x9, x2, [x29, #80]
   19674:	a93423ae 	stp	x14, x8, [x29, #-192]
   19678:	a94223aa 	ldp	x10, x8, [x29, #32]
   1967c:	a9411bb8 	ldp	x24, x6, [x29, #16]
   19680:	f81383a8 	stur	x8, [x29, #-200]
   19684:	540008a1 	b.ne	19798 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x150>  // b.any
   19688:	51000748 	sub	w8, w26, #0x1
   1968c:	6b07011f 	cmp	w8, w7
   19690:	54000842 	b.cs	19798 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x150>  // b.hs, b.nlast
   19694:	6b0b035f 	cmp	w26, w11
   19698:	54000808 	b.hi	19798 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x150>  // b.pmore
   1969c:	2a0d03f3 	mov	w19, w13
   196a0:	f100067f 	cmp	x19, #0x1
   196a4:	54000d81 	b.ne	19854 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x20c>  // b.any
   196a8:	92409c73 	and	x19, x3, #0xffffffffff
   196ac:	aa1303ed 	mov	x13, x19
   196b0:	b7f81b03 	tbnz	x3, #63, 19a10 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x3c8>
   196b4:	f90097f3 	str	x19, [sp, #296]
   196b8:	92409c93 	and	x19, x4, #0xffffffffff
   196bc:	f900a7f3 	str	x19, [sp, #328]
   196c0:	f85583b3 	ldur	x19, [x29, #-168]
   196c4:	b7f81b44 	tbnz	x4, #63, 19a2c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x3e4>
   196c8:	92409cae 	and	x14, x5, #0xffffffffff
   196cc:	b7f81b85 	tbnz	x5, #63, 19a3c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x3f4>
   196d0:	a93243ac 	stp	x12, x16, [x29, #-224]
   196d4:	92409e6c 	and	x12, x19, #0xffffffffff
   196d8:	a93173b1 	stp	x17, x28, [x29, #-240]
   196dc:	b7f81bb3 	tbnz	x19, #63, 19a50 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x408>
   196e0:	d368fc70 	lsr	x16, x3, #40
   196e4:	12800011 	mov	w17, #0xffffffff            	// #-1
   196e8:	8b0d0e8d 	add	x13, x20, x13, lsl #3
   196ec:	f90083ec 	str	x12, [sp, #256]
   196f0:	1ad02230 	lsl	w16, w17, w16
   196f4:	0a300110 	bic	w16, w8, w16
   196f8:	b87059ad 	ldr	w13, [x13, w16, uxtw #2]
   196fc:	34001aed 	cbz	w13, 19a58 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x410>
   19700:	92409c0c 	and	x12, x0, #0xffffffffff
   19704:	f81083a2 	stur	x2, [x29, #-248]
   19708:	aa0c03ed 	mov	x13, x12
   1970c:	b6f80060 	tbz	x0, #63, 19718 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xd0>
   19710:	f86c7a8d 	ldr	x13, [x20, x12, lsl #3]
   19714:	d358fdad 	lsr	x13, x13, #24
   19718:	d368b010 	ubfx	x16, x0, #40, #5
   1971c:	92800011 	mov	x17, #0xffffffffffffffff    	// #-1
   19720:	d37df1ad 	lsl	x13, x13, #3
   19724:	51000610 	sub	w16, w16, #0x1
   19728:	8b0d028d 	add	x13, x20, x13
   1972c:	9ad02230 	lsl	x16, x17, x16
   19730:	0a300108 	bic	w8, w8, w16
   19734:	531f7908 	lsl	w8, w8, #1
   19738:	d37d7d08 	ubfiz	x8, x8, #3, #32
   1973c:	8b0801a8 	add	x8, x13, x8
   19740:	b940010d 	ldr	w13, [x8]
   19744:	f9400502 	ldr	x2, [x8, #8]
   19748:	a9007d1f 	stp	xzr, xzr, [x8]
   1974c:	340021cd 	cbz	w13, 19b84 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x53c>
   19750:	92409c48 	and	x8, x2, #0xffffffffff
   19754:	f90073f0 	str	x16, [sp, #224]
   19758:	8b080e90 	add	x16, x20, x8, lsl #3
   1975c:	f81003ac 	stur	x12, [x29, #-256]
   19760:	f9005bee 	str	x14, [sp, #176]
   19764:	a91303e7 	stp	x7, x0, [sp, #304]
   19768:	a91193e3 	stp	x3, x4, [sp, #280]
   1976c:	f900a3e1 	str	x1, [sp, #320]
   19770:	f81303a9 	stur	x9, [x29, #-208]
   19774:	f9007bf8 	str	x24, [sp, #240]
   19778:	b7f825a2 	tbnz	x2, #63, 19c2c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x5e4>
   1977c:	a9400a18 	ldp	x24, x2, [x16]
   19780:	aa0803ed 	mov	x13, x8
   19784:	52909fec 	mov	w12, #0x84ff                	// #34047
   19788:	72a0620c 	movk	w12, #0x310, lsl #16
   1978c:	eb0c011f 	cmp	x8, x12
   19790:	54002968 	b.hi	19cbc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x674>  // b.pmore
   19794:	14000156 	b	19cec <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x6a4>
   19798:	f81303a9 	stur	x9, [x29, #-208]
   1979c:	aa1e03e9 	mov	x9, x30
   197a0:	34000af7 	cbz	w23, 198fc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x2b4>
   197a4:	2a1103e8 	mov	w8, w17
   197a8:	aa1803f3 	mov	x19, x24
   197ac:	aa1003f8 	mov	x24, x16
   197b0:	528007f0 	mov	w16, #0x3f                  	// #63
   197b4:	aa0c03ee 	mov	x14, x12
   197b8:	2a0703f1 	mov	w17, w7
   197bc:	a88142c8 	stp	x8, x16, [x22], #16
   197c0:	2a0b03e7 	mov	w7, w11
   197c4:	a904a7a2 	stp	x2, x9, [x29, #72]
   197c8:	f85303a9 	ldur	x9, [x29, #-208]
   197cc:	2a0d03eb 	mov	w11, w13
   197d0:	2a1203ed 	mov	w13, w18
   197d4:	2a0f03f2 	mov	w18, w15
   197d8:	a974b3af 	ldp	x15, x12, [x29, #-184]
   197dc:	f90023a9 	str	x9, [x29, #64]
   197e0:	2a1a03e9 	mov	w9, w26
   197e4:	a90333a9 	stp	x9, x12, [x29, #48]
   197e8:	2a1903ec 	mov	w12, w25
   197ec:	2a1303e9 	mov	w9, w19
   197f0:	2a0f03f3 	mov	w19, w15
   197f4:	2a1b03e8 	mov	w8, w27
   197f8:	2a1c03f0 	mov	w16, w28
   197fc:	a90233b3 	stp	x19, x12, [x29, #32]
   19800:	f85383ac 	ldur	x12, [x29, #-200]
   19804:	aa0103fc 	mov	x28, x1
   19808:	aa0403e1 	mov	x1, x4
   1980c:	f85583a4 	ldur	x4, [x29, #-168]
   19810:	2a0603ef 	mov	w15, w6
   19814:	2a0c03ec 	mov	w12, w12
   19818:	2a0a03f3 	mov	w19, w10
   1981c:	aa0803f9 	mov	x25, x8
   19820:	a90133b3 	stp	x19, x12, [x29, #16]
   19824:	aa1003fa 	mov	x26, x16
   19828:	aa0003fb 	mov	x27, x0
   1982c:	aa0303e0 	mov	x0, x3
   19830:	aa0503e3 	mov	x3, x5
   19834:	aa1103e5 	mov	x5, x17
   19838:	aa1803e6 	mov	x6, x24
   1983c:	aa0e03ea 	mov	x10, x14
   19840:	f85403ac 	ldur	x12, [x29, #-192]
   19844:	aa1203ee 	mov	x14, x18
   19848:	910943ff 	add	sp, sp, #0x250
   1984c:	a8c17bfd 	ldp	x29, x30, [sp], #16
   19850:	17fff6ec 	b	17400 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_TRANSACTION_PROTOTYPE_FLAT_UNPACK_0>
   19854:	34001177 	cbz	w23, 19a80 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x438>
   19858:	2a1103e8 	mov	w8, w17
   1985c:	528007ad 	mov	w13, #0x3d                  	// #61
   19860:	2a0703f1 	mov	w17, w7
   19864:	a88136c8 	stp	x8, x13, [x22], #16
   19868:	2a1b03e8 	mov	w8, w27
   1986c:	aa0a03fb 	mov	x27, x10
   19870:	aa0c03ea 	mov	x10, x12
   19874:	2a0b03e7 	mov	w7, w11
   19878:	a974afac 	ldp	x12, x11, [x29, #-184]
   1987c:	f90023a9 	str	x9, [x29, #64]
   19880:	2a1a03e9 	mov	w9, w26
   19884:	aa0603ee 	mov	x14, x6
   19888:	aa1003e6 	mov	x6, x16
   1988c:	2a1c03f0 	mov	w16, w28
   19890:	2a1203ed 	mov	w13, w18
   19894:	2a0f03f2 	mov	w18, w15
   19898:	a9032fa9 	stp	x9, x11, [x29, #48]
   1989c:	2a1903eb 	mov	w11, w25
   198a0:	2a0c03ec 	mov	w12, w12
   198a4:	a9022fac 	stp	x12, x11, [x29, #32]
   198a8:	a973b3ab 	ldp	x11, x12, [x29, #-200]
   198ac:	2a1803e9 	mov	w9, w24
   198b0:	2a1b03f8 	mov	w24, w27
   198b4:	aa0103fc 	mov	x28, x1
   198b8:	aa0403e1 	mov	x1, x4
   198bc:	f85583a4 	ldur	x4, [x29, #-168]
   198c0:	a904fba2 	stp	x2, x30, [x29, #72]
   198c4:	2a0b03eb 	mov	w11, w11
   198c8:	2a0e03ef 	mov	w15, w14
   198cc:	aa0803f9 	mov	x25, x8
   198d0:	a9012fb8 	stp	x24, x11, [x29, #16]
   198d4:	aa1003fa 	mov	x26, x16
   198d8:	aa0003fb 	mov	x27, x0
   198dc:	aa0303e0 	mov	x0, x3
   198e0:	aa0503e3 	mov	x3, x5
   198e4:	aa1103e5 	mov	x5, x17
   198e8:	aa1303eb 	mov	x11, x19
   198ec:	aa1203ee 	mov	x14, x18
   198f0:	910943ff 	add	sp, sp, #0x250
   198f4:	a8c17bfd 	ldp	x29, x30, [sp], #16
   198f8:	17fff6c2 	b	17400 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_TRANSACTION_PROTOTYPE_FLAT_UNPACK_0>
   198fc:	a97eded3 	ldp	x19, x23, [x22, #-24]
   19900:	aa0a03ee 	mov	x14, x10
   19904:	f94016a8 	ldr	x8, [x21, #40]
   19908:	aa1103ea 	mov	x10, x17
   1990c:	a9326bb9 	stp	x25, x26, [x29, #-224]
   19910:	aa0f03f9 	mov	x25, x15
   19914:	aa1003fa 	mov	x26, x16
   19918:	f81183b2 	stur	x18, [x29, #-232]
   1991c:	b4006828 	cbz	x8, 1a620 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xfd8>
   19920:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   19924:	f94096b1 	ldr	x17, [x21, #296]
   19928:	f90016b0 	str	x16, [x21, #40]
   1992c:	d1008230 	sub	x16, x17, #0x20
   19930:	f90096b0 	str	x16, [x21, #296]
   19934:	8b080e90 	add	x16, x20, x8, lsl #3
   19938:	6f07e7e0 	movi	v0.2d, #0xffffffffffffffff
   1993c:	92800011 	mov	x17, #0xffffffffffffffff    	// #-1
   19940:	52800032 	mov	w18, #0x1                   	// #1
   19944:	a90dce11 	stp	x17, x19, [x16, #216]
   19948:	d2c7e013 	mov	x19, #0x3f0000000000        	// #69269232549888
   1994c:	aa178257 	orr	x23, x18, x23, lsl #32
   19950:	f2e0a013 	movk	x19, #0x500, lsl #48
   19954:	2a0a03f1 	mov	w17, w10
   19958:	aa130113 	orr	x19, x8, x19
   1995c:	3c8c8200 	stur	q0, [x16, #200]
   19960:	3c8b8200 	stur	q0, [x16, #184]
   19964:	3c8a8200 	stur	q0, [x16, #168]
   19968:	3c898200 	stur	q0, [x16, #152]
   1996c:	3c888200 	stur	q0, [x16, #136]
   19970:	3c878200 	stur	q0, [x16, #120]
   19974:	3c868200 	stur	q0, [x16, #104]
   19978:	3c858200 	stur	q0, [x16, #88]
   1997c:	3c848200 	stur	q0, [x16, #72]
   19980:	3c838200 	stur	q0, [x16, #56]
   19984:	3c828200 	stur	q0, [x16, #40]
   19988:	3c818200 	stur	q0, [x16, #24]
   1998c:	3c808200 	stur	q0, [x16, #8]
   19990:	f9007617 	str	x23, [x16, #232]
   19994:	f9000211 	str	x17, [x16]
   19998:	a93ecad3 	stp	x19, x18, [x22, #-24]
   1999c:	f94016a8 	ldr	x8, [x21, #40]
   199a0:	b4006668 	cbz	x8, 1a66c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1024>
   199a4:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   199a8:	f94096b1 	ldr	x17, [x21, #296]
   199ac:	aa0e03ef 	mov	x15, x14
   199b0:	f85483b6 	ldur	x22, [x29, #-184]
   199b4:	f90016b0 	str	x16, [x21, #40]
   199b8:	d1008230 	sub	x16, x17, #0x20
   199bc:	f90096b0 	str	x16, [x21, #296]
   199c0:	8b080e90 	add	x16, x20, x8, lsl #3
   199c4:	f85583aa 	ldur	x10, [x29, #-168]
   199c8:	d2c00031 	mov	x17, #0x100000000           	// #4294967296
   199cc:	2a1b03f2 	mov	w18, w27
   199d0:	aa0903fe 	mov	x30, x9
   199d4:	a90dc613 	stp	x19, x17, [x16, #216]
   199d8:	2a1c03f1 	mov	w17, w28
   199dc:	2a0d03f3 	mov	w19, w13
   199e0:	a9032a05 	stp	x5, x10, [x16, #48]
   199e4:	2a0b03ea 	mov	w10, w11
   199e8:	a9004612 	stp	x18, x17, [x16]
   199ec:	2a0703f1 	mov	w17, w7
   199f0:	a905320a 	stp	x10, x12, [x16, #80]
   199f4:	aa1903ec 	mov	x12, x25
   199f8:	a971e7a9 	ldp	x9, x25, [x29, #-232]
   199fc:	a9046a11 	stp	x17, x26, [x16, #64]
   19a00:	f85283ba 	ldur	x26, [x29, #-216]
   19a04:	a9010600 	stp	x0, x1, [x16, #16]
   19a08:	a9021203 	stp	x3, x4, [x16, #32]
   19a0c:	140002ea 	b	1a5b4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xf6c>
   19a10:	f8737a8d 	ldr	x13, [x20, x19, lsl #3]
   19a14:	d358fdad 	lsr	x13, x13, #24
   19a18:	f90097f3 	str	x19, [sp, #296]
   19a1c:	92409c93 	and	x19, x4, #0xffffffffff
   19a20:	f900a7f3 	str	x19, [sp, #328]
   19a24:	f85583b3 	ldur	x19, [x29, #-168]
   19a28:	b6ffe504 	tbz	x4, #63, 196c8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x80>
   19a2c:	f940a7ee 	ldr	x14, [sp, #328]
   19a30:	f86e7a9f 	ldr	xzr, [x20, x14, lsl #3]
   19a34:	92409cae 	and	x14, x5, #0xffffffffff
   19a38:	b6ffe4c5 	tbz	x5, #63, 196d0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x88>
   19a3c:	f86e7a9f 	ldr	xzr, [x20, x14, lsl #3]
   19a40:	a93243ac 	stp	x12, x16, [x29, #-224]
   19a44:	92409e6c 	and	x12, x19, #0xffffffffff
   19a48:	a93173b1 	stp	x17, x28, [x29, #-240]
   19a4c:	b6ffe4b3 	tbz	x19, #63, 196e0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x98>
   19a50:	f86c7a9f 	ldr	xzr, [x20, x12, lsl #3]
   19a54:	17ffff23 	b	196e0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x98>
   19a58:	34004997 	cbz	w23, 1a388 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xd40>
   19a5c:	f85103a8 	ldur	x8, [x29, #-240]
   19a60:	5280072d 	mov	w13, #0x39                  	// #57
   19a64:	2a0803e8 	mov	w8, w8
   19a68:	a90036c8 	stp	x8, x13, [x22]
   19a6c:	f85183ad 	ldur	x13, [x29, #-232]
   19a70:	2a1b03e8 	mov	w8, w27
   19a74:	a904fba2 	stp	x2, x30, [x29, #72]
   19a78:	2a0d03f1 	mov	w17, w13
   19a7c:	1400004b 	b	19ba8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x560>
   19a80:	a97edecd 	ldp	x13, x23, [x22, #-24]
   19a84:	f94016a8 	ldr	x8, [x21, #40]
   19a88:	a931abaf 	stp	x15, x10, [x29, #-232]
   19a8c:	aa1103ea 	mov	x10, x17
   19a90:	aa1603ef 	mov	x15, x22
   19a94:	a932a7b0 	stp	x16, x9, [x29, #-216]
   19a98:	aa1203e9 	mov	x9, x18
   19a9c:	b40074c8 	cbz	x8, 1a934 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x12ec>
   19aa0:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   19aa4:	f94096b1 	ldr	x17, [x21, #296]
   19aa8:	f85483b6 	ldur	x22, [x29, #-184]
   19aac:	f90016b0 	str	x16, [x21, #40]
   19ab0:	d1008230 	sub	x16, x17, #0x20
   19ab4:	f90096b0 	str	x16, [x21, #296]
   19ab8:	8b080e90 	add	x16, x20, x8, lsl #3
   19abc:	6f07e7e0 	movi	v0.2d, #0xffffffffffffffff
   19ac0:	92800011 	mov	x17, #0xffffffffffffffff    	// #-1
   19ac4:	52800032 	mov	w18, #0x1                   	// #1
   19ac8:	a90db611 	stp	x17, x13, [x16, #216]
   19acc:	d2c7a011 	mov	x17, #0x3d0000000000        	// #67070209294336
   19ad0:	aa178257 	orr	x23, x18, x23, lsl #32
   19ad4:	2a0a03ed 	mov	w13, w10
   19ad8:	f2e0a011 	movk	x17, #0x500, lsl #48
   19adc:	f900020d 	str	x13, [x16]
   19ae0:	aa11010d 	orr	x13, x8, x17
   19ae4:	3c8c8200 	stur	q0, [x16, #200]
   19ae8:	3c8b8200 	stur	q0, [x16, #184]
   19aec:	3c8a8200 	stur	q0, [x16, #168]
   19af0:	3c898200 	stur	q0, [x16, #152]
   19af4:	3c888200 	stur	q0, [x16, #136]
   19af8:	3c878200 	stur	q0, [x16, #120]
   19afc:	3c868200 	stur	q0, [x16, #104]
   19b00:	3c858200 	stur	q0, [x16, #88]
   19b04:	3c848200 	stur	q0, [x16, #72]
   19b08:	3c838200 	stur	q0, [x16, #56]
   19b0c:	3c828200 	stur	q0, [x16, #40]
   19b10:	3c818200 	stur	q0, [x16, #24]
   19b14:	3c808200 	stur	q0, [x16, #8]
   19b18:	f9007617 	str	x23, [x16, #232]
   19b1c:	a93ec9ed 	stp	x13, x18, [x15, #-24]
   19b20:	f94016a8 	ldr	x8, [x21, #40]
   19b24:	b4007348 	cbz	x8, 1a98c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1344>
   19b28:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   19b2c:	f94096b1 	ldr	x17, [x21, #296]
   19b30:	f85203af 	ldur	x15, [x29, #-224]
   19b34:	f90016b0 	str	x16, [x21, #40]
   19b38:	d1008230 	sub	x16, x17, #0x20
   19b3c:	f90096b0 	str	x16, [x21, #296]
   19b40:	8b080e90 	add	x16, x20, x8, lsl #3
   19b44:	f85583aa 	ldur	x10, [x29, #-168]
   19b48:	d2c00031 	mov	x17, #0x100000000           	// #4294967296
   19b4c:	a90dc60d 	stp	x13, x17, [x16, #216]
   19b50:	2a1b03ed 	mov	w13, w27
   19b54:	2a1c03f1 	mov	w17, w28
   19b58:	a9032a05 	stp	x5, x10, [x16, #48]
   19b5c:	f85283aa 	ldur	x10, [x29, #-216]
   19b60:	a900460d 	stp	x13, x17, [x16]
   19b64:	2a0703ed 	mov	w13, w7
   19b68:	a9042a0d 	stp	x13, x10, [x16, #64]
   19b6c:	2a0b03ea 	mov	w10, w11
   19b70:	a905320a 	stp	x10, x12, [x16, #80]
   19b74:	f85183ac 	ldur	x12, [x29, #-232]
   19b78:	a9010600 	stp	x0, x1, [x16, #16]
   19b7c:	a9021203 	stp	x3, x4, [x16, #32]
   19b80:	1400028d 	b	1a5b4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xf6c>
   19b84:	a97143a8 	ldp	x8, x16, [x29, #-240]
   19b88:	34004897 	cbz	w23, 1a498 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xe50>
   19b8c:	2a0803e8 	mov	w8, w8
   19b90:	5280076d 	mov	w13, #0x3b                  	// #59
   19b94:	2a1003f1 	mov	w17, w16
   19b98:	a90036c8 	stp	x8, x13, [x22]
   19b9c:	f85083ad 	ldur	x13, [x29, #-248]
   19ba0:	2a1b03e8 	mov	w8, w27
   19ba4:	a904fbad 	stp	x13, x30, [x29, #72]
   19ba8:	2a0703f0 	mov	w16, w7
   19bac:	2a0b03e7 	mov	w7, w11
   19bb0:	f90023a9 	str	x9, [x29, #64]
   19bb4:	a974afac 	ldp	x12, x11, [x29, #-184]
   19bb8:	2a1a03e9 	mov	w9, w26
   19bbc:	2a1203ed 	mov	w13, w18
   19bc0:	2a0f03f2 	mov	w18, w15
   19bc4:	2a0603ef 	mov	w15, w6
   19bc8:	2a0a03f3 	mov	w19, w10
   19bcc:	a9721baa 	ldp	x10, x6, [x29, #-224]
   19bd0:	a9032fa9 	stp	x9, x11, [x29, #48]
   19bd4:	2a1903eb 	mov	w11, w25
   19bd8:	2a0c03ec 	mov	w12, w12
   19bdc:	a9022fac 	stp	x12, x11, [x29, #32]
   19be0:	a973b3ab 	ldp	x11, x12, [x29, #-200]
   19be4:	aa0103fc 	mov	x28, x1
   19be8:	aa0403e1 	mov	x1, x4
   19bec:	f85583a4 	ldur	x4, [x29, #-168]
   19bf0:	2a1803e9 	mov	w9, w24
   19bf4:	2a0b03eb 	mov	w11, w11
   19bf8:	910042d6 	add	x22, x22, #0x10
   19bfc:	aa0803f9 	mov	x25, x8
   19c00:	a9012fb3 	stp	x19, x11, [x29, #16]
   19c04:	aa1103fa 	mov	x26, x17
   19c08:	aa0003fb 	mov	x27, x0
   19c0c:	aa0303e0 	mov	x0, x3
   19c10:	aa0503e3 	mov	x3, x5
   19c14:	aa1003e5 	mov	x5, x16
   19c18:	5280002b 	mov	w11, #0x1                   	// #1
   19c1c:	aa1203ee 	mov	x14, x18
   19c20:	910943ff 	add	sp, sp, #0x250
   19c24:	a8c17bfd 	ldp	x29, x30, [sp], #16
   19c28:	17fff5f6 	b	17400 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_TRANSACTION_PROTOTYPE_FLAT_UNPACK_0>
   19c2c:	b940060d 	ldr	w13, [x16, #4]
   19c30:	b9400211 	ldr	w17, [x16]
   19c34:	aa1a03fc 	mov	x28, x26
   19c38:	aa1903fa 	mov	x26, x25
   19c3c:	aa0b03f9 	mov	x25, x11
   19c40:	aa1b03eb 	mov	x11, x27
   19c44:	aa1203fb 	mov	x27, x18
   19c48:	92405e32 	and	x18, x17, #0xffffff
   19c4c:	f100065f 	cmp	x18, #0x1
   19c50:	540075a1 	b.ne	1ab04 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x14bc>  // b.any
   19c54:	aa0d822d 	orr	x13, x17, x13, lsl #32
   19c58:	88dffe1f 	ldar	wzr, [x16]
   19c5c:	f94002b0 	ldr	x16, [x21]
   19c60:	d358fdad 	lsr	x13, x13, #24
   19c64:	8b0d0e91 	add	x17, x20, x13, lsl #3
   19c68:	a9400a38 	ldp	x24, x2, [x17]
   19c6c:	f8287a90 	str	x16, [x20, x8, lsl #3]
   19c70:	f94082b0 	ldr	x16, [x21, #256]
   19c74:	f90002a8 	str	x8, [x21]
   19c78:	91000608 	add	x8, x16, #0x1
   19c7c:	f0000d70 	adrp	x16, 1c8000 <ALC+0x17e00>
   19c80:	f90082a8 	str	x8, [x21, #256]
   19c84:	39540210 	ldrb	w16, [x16, #1280]
   19c88:	7100061f 	cmp	w16, #0x1
   19c8c:	54008221 	b.ne	1acd0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1688>  // b.any
   19c90:	f140211f 	cmp	x8, #0x8, lsl #12
   19c94:	540081e2 	b.cs	1acd0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1688>  // b.hs, b.nlast
   19c98:	aa1b03f2 	mov	x18, x27
   19c9c:	aa0b03fb 	mov	x27, x11
   19ca0:	aa1903eb 	mov	x11, x25
   19ca4:	aa1a03f9 	mov	x25, x26
   19ca8:	aa1c03fa 	mov	x26, x28
   19cac:	52909fec 	mov	w12, #0x84ff                	// #34047
   19cb0:	72a0620c 	movk	w12, #0x310, lsl #16
   19cb4:	eb0c01bf 	cmp	x13, x12
   19cb8:	540001a9 	b.ls	19cec <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x6a4>  // b.plast
   19cbc:	f94006a8 	ldr	x8, [x21, #8]
   19cc0:	f0000d70 	adrp	x16, 1c8000 <ALC+0x17e00>
   19cc4:	f82d7a88 	str	x8, [x20, x13, lsl #3]
   19cc8:	f94086a8 	ldr	x8, [x21, #264]
   19ccc:	f90006ad 	str	x13, [x21, #8]
   19cd0:	91000908 	add	x8, x8, #0x2
   19cd4:	f90086a8 	str	x8, [x21, #264]
   19cd8:	39540210 	ldrb	w16, [x16, #1280]
   19cdc:	7100061f 	cmp	w16, #0x1
   19ce0:	54006881 	b.ne	1a9f0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x13a8>  // b.any
   19ce4:	f140211f 	cmp	x8, #0x8, lsl #12
   19ce8:	54006842 	b.cs	1a9f0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x13a8>  // b.hs, b.nlast
   19cec:	92409f08 	and	x8, x24, #0xffffffffff
   19cf0:	8b080e90 	add	x16, x20, x8, lsl #3
   19cf4:	b7f800f8 	tbnz	x24, #63, 19d10 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x6c8>
   19cf8:	a9403a0d 	ldp	x13, x14, [x16]
   19cfc:	aa0803f3 	mov	x19, x8
   19d00:	f9006bee 	str	x14, [sp, #208]
   19d04:	eb0c011f 	cmp	x8, x12
   19d08:	540004e8 	b.hi	19da4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x75c>  // b.pmore
   19d0c:	14000032 	b	19dd4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x78c>
   19d10:	f90077e2 	str	x2, [sp, #232]
   19d14:	aa1a03fc 	mov	x28, x26
   19d18:	aa1903fa 	mov	x26, x25
   19d1c:	b940060d 	ldr	w13, [x16, #4]
   19d20:	b9400211 	ldr	w17, [x16]
   19d24:	aa0b03f9 	mov	x25, x11
   19d28:	aa1b03eb 	mov	x11, x27
   19d2c:	aa1203fb 	mov	x27, x18
   19d30:	92405e32 	and	x18, x17, #0xffffff
   19d34:	f100065f 	cmp	x18, #0x1
   19d38:	54007161 	b.ne	1ab64 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x151c>  // b.any
   19d3c:	aa0d822d 	orr	x13, x17, x13, lsl #32
   19d40:	88dffe1f 	ldar	wzr, [x16]
   19d44:	f94002b0 	ldr	x16, [x21]
   19d48:	d358fdb3 	lsr	x19, x13, #24
   19d4c:	8b130e91 	add	x17, x20, x19, lsl #3
   19d50:	a9403a2d 	ldp	x13, x14, [x17]
   19d54:	f8287a90 	str	x16, [x20, x8, lsl #3]
   19d58:	f94082b0 	ldr	x16, [x21, #256]
   19d5c:	f90002a8 	str	x8, [x21]
   19d60:	91000608 	add	x8, x16, #0x1
   19d64:	f0000d70 	adrp	x16, 1c8000 <ALC+0x17e00>
   19d68:	f9006bee 	str	x14, [sp, #208]
   19d6c:	f90082a8 	str	x8, [x21, #256]
   19d70:	39540210 	ldrb	w16, [x16, #1280]
   19d74:	7100061f 	cmp	w16, #0x1
   19d78:	54007c61 	b.ne	1ad04 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x16bc>  // b.any
   19d7c:	f140211f 	cmp	x8, #0x8, lsl #12
   19d80:	54007c22 	b.cs	1ad04 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x16bc>  // b.hs, b.nlast
   19d84:	f94077e2 	ldr	x2, [sp, #232]
   19d88:	aa1b03f2 	mov	x18, x27
   19d8c:	aa0b03fb 	mov	x27, x11
   19d90:	aa1903eb 	mov	x11, x25
   19d94:	aa1a03f9 	mov	x25, x26
   19d98:	aa1c03fa 	mov	x26, x28
   19d9c:	eb0c027f 	cmp	x19, x12
   19da0:	540001a9 	b.ls	19dd4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x78c>  // b.plast
   19da4:	f94006a8 	ldr	x8, [x21, #8]
   19da8:	f0000d70 	adrp	x16, 1c8000 <ALC+0x17e00>
   19dac:	f8337a88 	str	x8, [x20, x19, lsl #3]
   19db0:	f94086a8 	ldr	x8, [x21, #264]
   19db4:	f90006b3 	str	x19, [x21, #8]
   19db8:	91000908 	add	x8, x8, #0x2
   19dbc:	f90086a8 	str	x8, [x21, #264]
   19dc0:	39540210 	ldrb	w16, [x16, #1280]
   19dc4:	7100061f 	cmp	w16, #0x1
   19dc8:	54006461 	b.ne	1aa54 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x140c>  // b.any
   19dcc:	f140211f 	cmp	x8, #0x8, lsl #12
   19dd0:	54006422 	b.cs	1aa54 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x140c>  // b.hs, b.nlast
   19dd4:	92409c48 	and	x8, x2, #0xffffffffff
   19dd8:	f9007fe5 	str	x5, [sp, #248]
   19ddc:	8b080e90 	add	x16, x20, x8, lsl #3
   19de0:	b7f80182 	tbnz	x2, #63, 19e10 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x7c8>
   19de4:	a9403a02 	ldp	x2, x14, [x16]
   19de8:	aa0803f8 	mov	x24, x8
   19dec:	f90067ee 	str	x14, [sp, #200]
   19df0:	a9414e0e 	ldp	x14, x19, [x16, #16]
   19df4:	f90063ee 	str	x14, [sp, #192]
   19df8:	f940120e 	ldr	x14, [x16, #32]
   19dfc:	f9005fee 	str	x14, [sp, #184]
   19e00:	aa1a03fc 	mov	x28, x26
   19e04:	eb0c011f 	cmp	x8, x12
   19e08:	54000548 	b.hi	19eb0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x868>  // b.pmore
   19e0c:	14000035 	b	19ee0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x898>
   19e10:	aa1a03fc 	mov	x28, x26
   19e14:	aa1903fa 	mov	x26, x25
   19e18:	aa0b03f9 	mov	x25, x11
   19e1c:	aa1b03eb 	mov	x11, x27
   19e20:	aa1203fb 	mov	x27, x18
   19e24:	b9400612 	ldr	w18, [x16, #4]
   19e28:	b9400213 	ldr	w19, [x16]
   19e2c:	92405e71 	and	x17, x19, #0xffffff
   19e30:	f100063f 	cmp	x17, #0x1
   19e34:	54000041 	b.ne	19e3c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x7f4>  // b.any
   19e38:	88dffe1f 	ldar	wzr, [x16]
   19e3c:	aa128272 	orr	x18, x19, x18, lsl #32
   19e40:	f100063f 	cmp	x17, #0x1
   19e44:	d358fe58 	lsr	x24, x18, #24
   19e48:	8b180e92 	add	x18, x20, x24, lsl #3
   19e4c:	a940024e 	ldp	x14, x0, [x18]
   19e50:	a9414e41 	ldp	x1, x19, [x18, #16]
   19e54:	f9401252 	ldr	x18, [x18, #32]
   19e58:	f9005ff2 	str	x18, [sp, #184]
   19e5c:	a90c03e1 	stp	x1, x0, [sp, #192]
   19e60:	54006b61 	b.ne	1abcc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1584>  // b.any
   19e64:	f94002b1 	ldr	x17, [x21]
   19e68:	f9000211 	str	x17, [x16]
   19e6c:	f94082b0 	ldr	x16, [x21, #256]
   19e70:	f90002a8 	str	x8, [x21]
   19e74:	91000608 	add	x8, x16, #0x1
   19e78:	f0000d70 	adrp	x16, 1c8000 <ALC+0x17e00>
   19e7c:	f90082a8 	str	x8, [x21, #256]
   19e80:	39540210 	ldrb	w16, [x16, #1280]
   19e84:	7100061f 	cmp	w16, #0x1
   19e88:	54007581 	b.ne	1ad38 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x16f0>  // b.any
   19e8c:	f140211f 	cmp	x8, #0x8, lsl #12
   19e90:	54007542 	b.cs	1ad38 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x16f0>  // b.hs, b.nlast
   19e94:	aa1b03f2 	mov	x18, x27
   19e98:	aa0b03fb 	mov	x27, x11
   19e9c:	aa1903eb 	mov	x11, x25
   19ea0:	aa1a03f9 	mov	x25, x26
   19ea4:	aa0e03e2 	mov	x2, x14
   19ea8:	eb0c031f 	cmp	x24, x12
   19eac:	540001a9 	b.ls	19ee0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x898>  // b.plast
   19eb0:	f9400ea8 	ldr	x8, [x21, #24]
   19eb4:	f0000d70 	adrp	x16, 1c8000 <ALC+0x17e00>
   19eb8:	f8387a88 	str	x8, [x20, x24, lsl #3]
   19ebc:	f9408ea8 	ldr	x8, [x21, #280]
   19ec0:	f9000eb8 	str	x24, [x21, #24]
   19ec4:	91002108 	add	x8, x8, #0x8
   19ec8:	f9008ea8 	str	x8, [x21, #280]
   19ecc:	39540210 	ldrb	w16, [x16, #1280]
   19ed0:	7100061f 	cmp	w16, #0x1
   19ed4:	54005f21 	b.ne	1aab8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1470>  // b.any
   19ed8:	f140211f 	cmp	x8, #0x8, lsl #12
   19edc:	54005ee2 	b.cs	1aab8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1470>  // b.hs, b.nlast
   19ee0:	f85403ac 	ldur	x12, [x29, #-192]
   19ee4:	aa1903fa 	mov	x26, x25
   19ee8:	92409da8 	and	x8, x13, #0xffffffffff
   19eec:	aa0b03f9 	mov	x25, x11
   19ef0:	b7f81dcd 	tbnz	x13, #63, 1a2a8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xc60>
   19ef4:	92409d90 	and	x16, x12, #0xffffffffff
   19ef8:	b7f81e0c 	tbnz	x12, #63, 1a2b8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xc70>
   19efc:	f85503ae 	ldur	x14, [x29, #-176]
   19f00:	92409dd1 	and	x17, x14, #0xffffffffff
   19f04:	b7f81e4e 	tbnz	x14, #63, 1a2cc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xc84>
   19f08:	aa1203ee 	mov	x14, x18
   19f0c:	92409fd2 	and	x18, x30, #0xffffffffff
   19f10:	b6f8007e 	tbz	x30, #63, 19f1c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x8d4>
   19f14:	f8727a92 	ldr	x18, [x20, x18, lsl #3]
   19f18:	d358fe52 	lsr	x18, x18, #24
   19f1c:	aa0a03f8 	mov	x24, x10
   19f20:	eb1e01bf 	cmp	x13, x30
   19f24:	aa1203e4 	mov	x4, x18
   19f28:	f90077f9 	str	x25, [sp, #232]
   19f2c:	540000e0 	b.eq	19f48 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x900>  // b.none
   19f30:	f85503aa 	ldur	x10, [x29, #-176]
   19f34:	aa1103e4 	mov	x4, x17
   19f38:	eb0a01bf 	cmp	x13, x10
   19f3c:	54000060 	b.eq	19f48 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x900>  // b.none
   19f40:	eb0c01bf 	cmp	x13, x12
   19f44:	9a880204 	csel	x4, x16, x8, eq	// eq = none
   19f48:	f85503ab 	ldur	x11, [x29, #-176]
   19f4c:	b900abf3 	str	w19, [sp, #168]
   19f50:	aa1403e0 	mov	x0, x20
   19f54:	b90093e2 	str	w2, [sp, #144]
   19f58:	aa1503e1 	mov	x1, x21
   19f5c:	aa0d03e3 	mov	x3, x13
   19f60:	eb0b019f 	cmp	x12, x11
   19f64:	b9008bff 	str	wzr, [sp, #136]
   19f68:	f9406be5 	ldr	x5, [sp, #208]
   19f6c:	9a900228 	csel	x8, x17, x16, eq	// eq = none
   19f70:	a94c1ff0 	ldp	x16, x7, [sp, #192]
   19f74:	a907cbfe 	stp	x30, x18, [sp, #120]
   19f78:	eb1e019f 	cmp	x12, x30
   19f7c:	b90063fc 	str	w28, [sp, #96]
   19f80:	9a880248 	csel	x8, x18, x8, eq	// eq = none
   19f84:	eb1e017f 	cmp	x11, x30
   19f88:	b900a3f0 	str	w16, [sp, #160]
   19f8c:	9a91024a 	csel	x10, x18, x17, eq	// eq = none
   19f90:	b9009be7 	str	w7, [sp, #152]
   19f94:	b9005bfa 	str	w26, [sp, #88]
   19f98:	f85383a9 	ldur	x9, [x29, #-200]
   19f9c:	b90043e6 	str	w6, [sp, #64]
   19fa0:	aa0203e6 	mov	x6, x2
   19fa4:	d10283a2 	sub	x2, x29, #0xa0
   19fa8:	b9004bf8 	str	w24, [sp, #72]
   19fac:	b90053e9 	str	w9, [sp, #80]
   19fb0:	f9407be9 	ldr	x9, [sp, #240]
   19fb4:	b90033ef 	str	w15, [sp, #48]
   19fb8:	b9003be9 	str	w9, [sp, #56]
   19fbc:	f9405fe9 	ldr	x9, [sp, #184]
   19fc0:	b9002bee 	str	w14, [sp, #40]
   19fc4:	b90013e9 	str	w9, [sp, #16]
   19fc8:	b9000bf3 	str	w19, [sp, #8]
   19fcc:	b90003f0 	str	w16, [sp]
   19fd0:	a906abeb 	stp	x11, x10, [sp, #104]
   19fd4:	a901a3ec 	stp	x12, x8, [sp, #24]
   19fd8:	94019bf1 	bl	80f9c <spin_51>
   19fdc:	b85a03a8 	ldur	w8, [x29, #-96]
   19fe0:	ad7b8ba1 	ldp	q1, q2, [x29, #-144]
   19fe4:	a97dcfb8 	ldp	x24, x19, [x29, #-40]
   19fe8:	f85603ad 	ldur	x13, [x29, #-160]
   19fec:	f81503a8 	stur	x8, [x29, #-176]
   19ff0:	b85a83a8 	ldur	w8, [x29, #-88]
   19ff4:	b85683af 	ldur	w15, [x29, #-152]
   19ff8:	b85903a2 	ldur	w2, [x29, #-112]
   19ffc:	f85983be 	ldur	x30, [x29, #-104]
   1a000:	b85c03a0 	ldur	w0, [x29, #-64]
   1a004:	f81403a8 	stur	x8, [x29, #-192]
   1a008:	b85b03a8 	ldur	w8, [x29, #-80]
   1a00c:	b85c83a7 	ldur	w7, [x29, #-56]
   1a010:	b85d03b9 	ldur	w25, [x29, #-48]
   1a014:	a97eebbc 	ldp	x28, x26, [x29, #-24]
   1a018:	f81383a8 	stur	x8, [x29, #-200]
   1a01c:	b85b83a8 	ldur	w8, [x29, #-72]
   1a020:	f9007be8 	str	x8, [sp, #240]
   1a024:	b6f8006d 	tbz	x13, #63, 1a030 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x9e8>
   1a028:	92409da8 	and	x8, x13, #0xffffffffff
   1a02c:	f8687a9f 	ldr	xzr, [x20, x8, lsl #3]
   1a030:	a95187e8 	ldp	x8, x1, [sp, #280]
   1a034:	f85203aa 	ldur	x10, [x29, #-224]
   1a038:	a953a7eb 	ldp	x11, x9, [sp, #312]
   1a03c:	f85583a4 	ldur	x4, [x29, #-168]
   1a040:	f9407fe3 	ldr	x3, [sp, #248]
   1a044:	f85303a5 	ldur	x5, [x29, #-208]
   1a048:	f94097f2 	ldr	x18, [sp, #296]
   1a04c:	a9703bb1 	ldp	x17, x14, [x29, #-256]
   1a050:	b7f814be 	tbnz	x30, #63, 1a2e4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xc9c>
   1a054:	f85283a6 	ldur	x6, [x29, #-216]
   1a058:	f9409bf0 	ldr	x16, [sp, #304]
   1a05c:	b7f814f3 	tbnz	x19, #63, 1a2f8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xcb0>
   1a060:	b7f8153c 	tbnz	x28, #63, 1a304 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xcbc>
   1a064:	b7f8156b 	tbnz	x11, #63, 1a310 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xcc8>
   1a068:	b7f815a9 	tbnz	x9, #63, 1a31c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xcd4>
   1a06c:	b7f815e8 	tbnz	x8, #63, 1a328 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xce0>
   1a070:	b7f81601 	tbnz	x1, #63, 1a330 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xce8>
   1a074:	b7f81643 	tbnz	x3, #63, 1a33c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xcf4>
   1a078:	b7f81684 	tbnz	x4, #63, 1a348 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xd00>
   1a07c:	b7f816ca 	tbnz	x10, #63, 1a354 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xd0c>
   1a080:	b7f81705 	tbnz	x5, #63, 1a360 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xd18>
   1a084:	f94073ec 	ldr	x12, [sp, #224]
   1a088:	f90097fc 	str	x28, [sp, #296]
   1a08c:	f900a7f3 	str	x19, [sp, #328]
   1a090:	2a2c03ec 	mvn	w12, w12
   1a094:	b7f8174e 	tbnz	x14, #63, 1a37c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xd34>
   1a098:	5100070e 	sub	w14, w24, #0x1
   1a09c:	f81003b1 	stur	x17, [x29, #-256]
   1a0a0:	0a0c01cc 	and	w12, w14, w12
   1a0a4:	f94006ae 	ldr	x14, [x21, #8]
   1a0a8:	531f799c 	lsl	w28, w12, #1
   1a0ac:	8b3c4e8c 	add	x12, x20, w28, uxtw #3
   1a0b0:	8b110d93 	add	x19, x12, x17, lsl #3
   1a0b4:	f940066c 	ldr	x12, [x19, #8]
   1a0b8:	b40030ae 	cbz	x14, 1a6cc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1084>
   1a0bc:	f86e7a91 	ldr	x17, [x20, x14, lsl #3]
   1a0c0:	f94086b2 	ldr	x18, [x21, #264]
   1a0c4:	f90006b1 	str	x17, [x21, #8]
   1a0c8:	d1000a51 	sub	x17, x18, #0x2
   1a0cc:	f90086b1 	str	x17, [x21, #264]
   1a0d0:	d378fdb1 	lsr	x17, x13, #56
   1a0d4:	f1000a3f 	cmp	x17, #0x2
   1a0d8:	54003320 	b.eq	1a73c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x10f4>  // b.none
   1a0dc:	8b0e0e91 	add	x17, x20, x14, lsl #3
   1a0e0:	a9003e2d 	stp	x13, x15, [x17]
   1a0e4:	f9400eaf 	ldr	x15, [x21, #24]
   1a0e8:	b400366f 	cbz	x15, 1a7b4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x116c>
   1a0ec:	f86f7a8d 	ldr	x13, [x20, x15, lsl #3]
   1a0f0:	f9408eb1 	ldr	x17, [x21, #280]
   1a0f4:	f9000ead 	str	x13, [x21, #24]
   1a0f8:	d100222d 	sub	x13, x17, #0x8
   1a0fc:	f9008ead 	str	x13, [x21, #280]
   1a100:	6f00e5e0 	movi	v0.2d, #0xffffffff
   1a104:	8b0f0e8d 	add	x13, x20, x15, lsl #3
   1a108:	f90011a2 	str	x2, [x13, #32]
   1a10c:	4e201c21 	and	v1.16b, v1.16b, v0.16b
   1a110:	4e201c40 	and	v0.16b, v2.16b, v0.16b
   1a114:	ad0001a1 	stp	q1, q0, [x13]
   1a118:	f94006ad 	ldr	x13, [x21, #8]
   1a11c:	b400380d 	cbz	x13, 1a81c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x11d4>
   1a120:	f86d7a91 	ldr	x17, [x20, x13, lsl #3]
   1a124:	f94086b2 	ldr	x18, [x21, #264]
   1a128:	f90006b1 	str	x17, [x21, #8]
   1a12c:	d1000a51 	sub	x17, x18, #0x2
   1a130:	f90086b1 	str	x17, [x21, #264]
   1a134:	d2c40011 	mov	x17, #0x200000000000        	// #35184372088832
   1a138:	f2e04011 	movk	x17, #0x200, lsl #48
   1a13c:	aa1101c2 	orr	x2, x14, x17
   1a140:	d378fc4e 	lsr	x14, x2, #56
   1a144:	f10009df 	cmp	x14, #0x2
   1a148:	540039c0 	b.eq	1a880 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1238>  // b.none
   1a14c:	d2c4200e 	mov	x14, #0x210000000000        	// #36283883716608
   1a150:	f2e0400e 	movk	x14, #0x200, lsl #48
   1a154:	aa0e01ee 	orr	x14, x15, x14
   1a158:	8b0d0e8f 	add	x15, x20, x13, lsl #3
   1a15c:	d378fdd1 	lsr	x17, x14, #56
   1a160:	f90001e2 	str	x2, [x15]
   1a164:	f1000a3f 	cmp	x17, #0x2
   1a168:	2a1803f1 	mov	w17, w24
   1a16c:	f90083f1 	str	x17, [sp, #256]
   1a170:	54003b80 	b.eq	1a8e0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1298>  // b.none
   1a174:	52909ff2 	mov	w18, #0x84ff                	// #34047
   1a178:	f90005ee 	str	x14, [x15, #8]
   1a17c:	5280002e 	mov	w14, #0x1                   	// #1
   1a180:	3200038f 	orr	w15, w28, #0x1
   1a184:	72a06212 	movk	w18, #0x310, lsl #16
   1a188:	f94077f8 	ldr	x24, [sp, #232]
   1a18c:	8b2f4e8f 	add	x15, x20, w15, uxtw #3
   1a190:	92787d91 	and	x17, x12, #0xffffffff00
   1a194:	91000652 	add	x18, x18, #0x1
   1a198:	d2c3e01c 	mov	x28, #0x1f0000000000        	// #34084860461056
   1a19c:	f900026e 	str	x14, [x19]
   1a1a0:	f85003ae 	ldur	x14, [x29, #-256]
   1a1a4:	f2e0401c 	movk	x28, #0x200, lsl #48
   1a1a8:	eb12023f 	cmp	x17, x18
   1a1ac:	aa1c01ad 	orr	x13, x13, x28
   1a1b0:	f82e79ed 	str	x13, [x15, x14, lsl #3]
   1a1b4:	54000363 	b.cc	1a220 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xbd8>  // b.lo, b.ul, b.last
   1a1b8:	b100059f 	cmn	x12, #0x1
   1a1bc:	54000320 	b.eq	1a220 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xbd8>  // b.none
   1a1c0:	9247158d 	and	x13, x12, #0x7e00000000000000
   1a1c4:	b40002ed 	cbz	x13, 1a220 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xbd8>
   1a1c8:	aa0003fc 	mov	x28, x0
   1a1cc:	aa1403e0 	mov	x0, x20
   1a1d0:	aa1503e1 	mov	x1, x21
   1a1d4:	aa0c03e2 	mov	x2, x12
   1a1d8:	aa1e03f3 	mov	x19, x30
   1a1dc:	aa1a03f8 	mov	x24, x26
   1a1e0:	aa1903fa 	mov	x26, x25
   1a1e4:	aa0703f9 	mov	x25, x7
   1a1e8:	97ffaf8b 	bl	6014 <term_drop>
   1a1ec:	a97297a6 	ldp	x6, x5, [x29, #-216]
   1a1f0:	aa1903e7 	mov	x7, x25
   1a1f4:	a9532ff0 	ldp	x16, x11, [sp, #304]
   1a1f8:	aa1a03f9 	mov	x25, x26
   1a1fc:	a95187e8 	ldp	x8, x1, [sp, #280]
   1a200:	aa1803fa 	mov	x26, x24
   1a204:	f94077f8 	ldr	x24, [sp, #232]
   1a208:	f940a3e9 	ldr	x9, [sp, #320]
   1a20c:	aa1c03e0 	mov	x0, x28
   1a210:	f9407fe3 	ldr	x3, [sp, #248]
   1a214:	f85583a4 	ldur	x4, [x29, #-168]
   1a218:	aa1303fe 	mov	x30, x19
   1a21c:	f85203aa 	ldur	x10, [x29, #-224]
   1a220:	b85f8ecc 	ldr	w12, [x22, #-8]!
   1a224:	90000cad 	adrp	x13, 1ae000 <io_eff_rows+0xff118>
   1a228:	913f21ad 	add	x13, x13, #0xfc8
   1a22c:	aa0903fc 	mov	x28, x9
   1a230:	f86c79a2 	ldr	x2, [x13, x12, lsl #3]
   1a234:	f94097ed 	ldr	x13, [sp, #296]
   1a238:	f85083ac 	ldur	x12, [x29, #-248]
   1a23c:	f90023a5 	str	x5, [x29, #64]
   1a240:	a973bba9 	ldp	x9, x14, [x29, #-200]
   1a244:	a904b7ac 	stp	x12, x13, [x29, #72]
   1a248:	2a1003e5 	mov	w5, w16
   1a24c:	f940a7ec 	ldr	x12, [sp, #328]
   1a250:	f9001fac 	str	x12, [x29, #56]
   1a254:	f94083ec 	ldr	x12, [sp, #256]
   1a258:	a9011fa0 	stp	x0, x7, [x29, #16]
   1a25c:	2a1803e7 	mov	w7, w24
   1a260:	52800398 	mov	w24, #0x1c                  	// #28
   1a264:	aa0803e0 	mov	x0, x8
   1a268:	a902b3b9 	stp	x25, x12, [x29, #40]
   1a26c:	a97133ad 	ldp	x13, x12, [x29, #-240]
   1a270:	2a1b03f9 	mov	w25, w27
   1a274:	aa0b03fb 	mov	x27, x11
   1a278:	5280002b 	mov	w11, #0x1                   	// #1
   1a27c:	0b0d0351 	add	w17, w26, w13
   1a280:	2a0c03fa 	mov	w26, w12
   1a284:	a974b7ac 	ldp	x12, x13, [x29, #-184]
   1a288:	2a0c03ec 	mov	w12, w12
   1a28c:	f90013ac 	str	x12, [x29, #32]
   1a290:	aa1e03ec 	mov	x12, x30
   1a294:	f9407bef 	ldr	x15, [sp, #240]
   1a298:	f9002fb1 	str	x17, [x29, #88]
   1a29c:	910943ff 	add	sp, sp, #0x250
   1a2a0:	a8c17bfd 	ldp	x29, x30, [sp], #16
   1a2a4:	d61f0040 	br	x2
   1a2a8:	f8687a88 	ldr	x8, [x20, x8, lsl #3]
   1a2ac:	d358fd08 	lsr	x8, x8, #24
   1a2b0:	92409d90 	and	x16, x12, #0xffffffffff
   1a2b4:	b6ffe24c 	tbz	x12, #63, 19efc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x8b4>
   1a2b8:	f8707a90 	ldr	x16, [x20, x16, lsl #3]
   1a2bc:	d358fe10 	lsr	x16, x16, #24
   1a2c0:	f85503ae 	ldur	x14, [x29, #-176]
   1a2c4:	92409dd1 	and	x17, x14, #0xffffffffff
   1a2c8:	b6ffe20e 	tbz	x14, #63, 19f08 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x8c0>
   1a2cc:	f8717a91 	ldr	x17, [x20, x17, lsl #3]
   1a2d0:	aa1203ee 	mov	x14, x18
   1a2d4:	d358fe31 	lsr	x17, x17, #24
   1a2d8:	92409fd2 	and	x18, x30, #0xffffffffff
   1a2dc:	b6ffe21e 	tbz	x30, #63, 19f1c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x8d4>
   1a2e0:	17ffff0d 	b	19f14 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x8cc>
   1a2e4:	92409fcc 	and	x12, x30, #0xffffffffff
   1a2e8:	f86c7a9f 	ldr	xzr, [x20, x12, lsl #3]
   1a2ec:	f85283a6 	ldur	x6, [x29, #-216]
   1a2f0:	f9409bf0 	ldr	x16, [sp, #304]
   1a2f4:	b6ffeb73 	tbz	x19, #63, 1a060 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xa18>
   1a2f8:	92409e6c 	and	x12, x19, #0xffffffffff
   1a2fc:	f86c7a9f 	ldr	xzr, [x20, x12, lsl #3]
   1a300:	b6ffeb3c 	tbz	x28, #63, 1a064 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xa1c>
   1a304:	92409f8c 	and	x12, x28, #0xffffffffff
   1a308:	f86c7a9f 	ldr	xzr, [x20, x12, lsl #3]
   1a30c:	b6ffeaeb 	tbz	x11, #63, 1a068 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xa20>
   1a310:	f8717a8c 	ldr	x12, [x20, x17, lsl #3]
   1a314:	d358fd91 	lsr	x17, x12, #24
   1a318:	b6ffeaa9 	tbz	x9, #63, 1a06c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xa24>
   1a31c:	92409d2c 	and	x12, x9, #0xffffffffff
   1a320:	f86c7a9f 	ldr	xzr, [x20, x12, lsl #3]
   1a324:	b6ffea68 	tbz	x8, #63, 1a070 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xa28>
   1a328:	f8727a9f 	ldr	xzr, [x20, x18, lsl #3]
   1a32c:	b6ffea41 	tbz	x1, #63, 1a074 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xa2c>
   1a330:	f940a7ec 	ldr	x12, [sp, #328]
   1a334:	f86c7a9f 	ldr	xzr, [x20, x12, lsl #3]
   1a338:	b6ffea03 	tbz	x3, #63, 1a078 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xa30>
   1a33c:	f9405bec 	ldr	x12, [sp, #176]
   1a340:	f86c7a9f 	ldr	xzr, [x20, x12, lsl #3]
   1a344:	b6ffe9c4 	tbz	x4, #63, 1a07c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xa34>
   1a348:	f94083ec 	ldr	x12, [sp, #256]
   1a34c:	f86c7a9f 	ldr	xzr, [x20, x12, lsl #3]
   1a350:	b6ffe98a 	tbz	x10, #63, 1a080 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xa38>
   1a354:	92409d4c 	and	x12, x10, #0xffffffffff
   1a358:	f86c7a9f 	ldr	xzr, [x20, x12, lsl #3]
   1a35c:	b6ffe945 	tbz	x5, #63, 1a084 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xa3c>
   1a360:	92409cac 	and	x12, x5, #0xffffffffff
   1a364:	f86c7a9f 	ldr	xzr, [x20, x12, lsl #3]
   1a368:	f94073ec 	ldr	x12, [sp, #224]
   1a36c:	f90097fc 	str	x28, [sp, #296]
   1a370:	f900a7f3 	str	x19, [sp, #328]
   1a374:	2a2c03ec 	mvn	w12, w12
   1a378:	b6ffe90e 	tbz	x14, #63, 1a098 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xa50>
   1a37c:	92409dce 	and	x14, x14, #0xffffffffff
   1a380:	f86e7a9f 	ldr	xzr, [x20, x14, lsl #3]
   1a384:	17ffff45 	b	1a098 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xa50>
   1a388:	a97ececd 	ldp	x13, x19, [x22, #-24]
   1a38c:	aa1203fc 	mov	x28, x18
   1a390:	f94016a8 	ldr	x8, [x21, #40]
   1a394:	aa0a03f7 	mov	x23, x10
   1a398:	f81303a9 	stur	x9, [x29, #-208]
   1a39c:	b4004368 	cbz	x8, 1ac08 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x15c0>
   1a3a0:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   1a3a4:	f94096b1 	ldr	x17, [x21, #296]
   1a3a8:	f90016b0 	str	x16, [x21, #40]
   1a3ac:	d1008230 	sub	x16, x17, #0x20
   1a3b0:	f90096b0 	str	x16, [x21, #296]
   1a3b4:	8b080e90 	add	x16, x20, x8, lsl #3
   1a3b8:	6f07e7e0 	movi	v0.2d, #0xffffffffffffffff
   1a3bc:	92800011 	mov	x17, #0xffffffffffffffff    	// #-1
   1a3c0:	f85103aa 	ldur	x10, [x29, #-240]
   1a3c4:	52800032 	mov	w18, #0x1                   	// #1
   1a3c8:	aa0f03ec 	mov	x12, x15
   1a3cc:	a90db611 	stp	x17, x13, [x16, #216]
   1a3d0:	d2c72011 	mov	x17, #0x390000000000        	// #62672162783232
   1a3d4:	aa138253 	orr	x19, x18, x19, lsl #32
   1a3d8:	2a0a03ed 	mov	w13, w10
   1a3dc:	f2e0a011 	movk	x17, #0x500, lsl #48
   1a3e0:	f900020d 	str	x13, [x16]
   1a3e4:	aa11010d 	orr	x13, x8, x17
   1a3e8:	3c8c8200 	stur	q0, [x16, #200]
   1a3ec:	3c8b8200 	stur	q0, [x16, #184]
   1a3f0:	3c8a8200 	stur	q0, [x16, #168]
   1a3f4:	3c898200 	stur	q0, [x16, #152]
   1a3f8:	3c888200 	stur	q0, [x16, #136]
   1a3fc:	3c878200 	stur	q0, [x16, #120]
   1a400:	3c868200 	stur	q0, [x16, #104]
   1a404:	3c858200 	stur	q0, [x16, #88]
   1a408:	3c848200 	stur	q0, [x16, #72]
   1a40c:	3c838200 	stur	q0, [x16, #56]
   1a410:	3c828200 	stur	q0, [x16, #40]
   1a414:	3c818200 	stur	q0, [x16, #24]
   1a418:	3c808200 	stur	q0, [x16, #8]
   1a41c:	f9007613 	str	x19, [x16, #232]
   1a420:	a93ecacd 	stp	x13, x18, [x22, #-24]
   1a424:	f94016a8 	ldr	x8, [x21, #40]
   1a428:	b4004208 	cbz	x8, 1ac68 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1620>
   1a42c:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   1a430:	f94096b1 	ldr	x17, [x21, #296]
   1a434:	aa1703ef 	mov	x15, x23
   1a438:	f85483b6 	ldur	x22, [x29, #-184]
   1a43c:	f90016b0 	str	x16, [x21, #40]
   1a440:	d1008230 	sub	x16, x17, #0x20
   1a444:	f90096b0 	str	x16, [x21, #296]
   1a448:	8b080e90 	add	x16, x20, x8, lsl #3
   1a44c:	d2c00031 	mov	x17, #0x100000000           	// #4294967296
   1a450:	f85283aa 	ldur	x10, [x29, #-216]
   1a454:	f85583a9 	ldur	x9, [x29, #-168]
   1a458:	52800033 	mov	w19, #0x1                   	// #1
   1a45c:	a90dc60d 	stp	x13, x17, [x16, #216]
   1a460:	f85183b1 	ldur	x17, [x29, #-232]
   1a464:	2a1b03ed 	mov	w13, w27
   1a468:	a9010600 	stp	x0, x1, [x16, #16]
   1a46c:	2a1103f1 	mov	w17, w17
   1a470:	a9021203 	stp	x3, x4, [x16, #32]
   1a474:	a900460d 	stp	x13, x17, [x16]
   1a478:	2a0703ed 	mov	w13, w7
   1a47c:	a9042a0d 	stp	x13, x10, [x16, #64]
   1a480:	2a0b03ea 	mov	w10, w11
   1a484:	f9002a0a 	str	x10, [x16, #80]
   1a488:	f85203aa 	ldur	x10, [x29, #-224]
   1a48c:	a9032605 	stp	x5, x9, [x16, #48]
   1a490:	aa1c03e9 	mov	x9, x28
   1a494:	14000047 	b	1a5b0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xf68>
   1a498:	a97ececd 	ldp	x13, x19, [x22, #-24]
   1a49c:	aa0a03f7 	mov	x23, x10
   1a4a0:	f94016a8 	ldr	x8, [x21, #40]
   1a4a4:	f85083a2 	ldur	x2, [x29, #-248]
   1a4a8:	aa0b03fc 	mov	x28, x11
   1a4ac:	aa1203ec 	mov	x12, x18
   1a4b0:	f81303a9 	stur	x9, [x29, #-208]
   1a4b4:	b4004588 	cbz	x8, 1ad64 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x171c>
   1a4b8:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   1a4bc:	f94096b1 	ldr	x17, [x21, #296]
   1a4c0:	f90016b0 	str	x16, [x21, #40]
   1a4c4:	d1008230 	sub	x16, x17, #0x20
   1a4c8:	f90096b0 	str	x16, [x21, #296]
   1a4cc:	8b080e90 	add	x16, x20, x8, lsl #3
   1a4d0:	6f07e7e0 	movi	v0.2d, #0xffffffffffffffff
   1a4d4:	92800011 	mov	x17, #0xffffffffffffffff    	// #-1
   1a4d8:	f85103aa 	ldur	x10, [x29, #-240]
   1a4dc:	52800032 	mov	w18, #0x1                   	// #1
   1a4e0:	aa0f03eb 	mov	x11, x15
   1a4e4:	a90db611 	stp	x17, x13, [x16, #216]
   1a4e8:	d2c76011 	mov	x17, #0x3b0000000000        	// #64871186038784
   1a4ec:	aa138253 	orr	x19, x18, x19, lsl #32
   1a4f0:	2a0a03ed 	mov	w13, w10
   1a4f4:	f2e0a011 	movk	x17, #0x500, lsl #48
   1a4f8:	f900020d 	str	x13, [x16]
   1a4fc:	aa11010d 	orr	x13, x8, x17
   1a500:	3c8c8200 	stur	q0, [x16, #200]
   1a504:	3c8b8200 	stur	q0, [x16, #184]
   1a508:	3c8a8200 	stur	q0, [x16, #168]
   1a50c:	3c898200 	stur	q0, [x16, #152]
   1a510:	3c888200 	stur	q0, [x16, #136]
   1a514:	3c878200 	stur	q0, [x16, #120]
   1a518:	3c868200 	stur	q0, [x16, #104]
   1a51c:	3c858200 	stur	q0, [x16, #88]
   1a520:	3c848200 	stur	q0, [x16, #72]
   1a524:	3c838200 	stur	q0, [x16, #56]
   1a528:	3c828200 	stur	q0, [x16, #40]
   1a52c:	3c818200 	stur	q0, [x16, #24]
   1a530:	3c808200 	stur	q0, [x16, #8]
   1a534:	f9007613 	str	x19, [x16, #232]
   1a538:	a93ecacd 	stp	x13, x18, [x22, #-24]
   1a53c:	f94016a8 	ldr	x8, [x21, #40]
   1a540:	b4004408 	cbz	x8, 1adc0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1778>
   1a544:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   1a548:	f94096b1 	ldr	x17, [x21, #296]
   1a54c:	aa1703ef 	mov	x15, x23
   1a550:	f85483b6 	ldur	x22, [x29, #-184]
   1a554:	f90016b0 	str	x16, [x21, #40]
   1a558:	d1008230 	sub	x16, x17, #0x20
   1a55c:	f90096b0 	str	x16, [x21, #296]
   1a560:	8b080e90 	add	x16, x20, x8, lsl #3
   1a564:	d2c00031 	mov	x17, #0x100000000           	// #4294967296
   1a568:	f85283aa 	ldur	x10, [x29, #-216]
   1a56c:	f85583a9 	ldur	x9, [x29, #-168]
   1a570:	52800033 	mov	w19, #0x1                   	// #1
   1a574:	a90dc60d 	stp	x13, x17, [x16, #216]
   1a578:	f85183b1 	ldur	x17, [x29, #-232]
   1a57c:	2a1b03ed 	mov	w13, w27
   1a580:	a9010600 	stp	x0, x1, [x16, #16]
   1a584:	2a1103f1 	mov	w17, w17
   1a588:	a9021203 	stp	x3, x4, [x16, #32]
   1a58c:	a900460d 	stp	x13, x17, [x16]
   1a590:	2a0703ed 	mov	w13, w7
   1a594:	a9042a0d 	stp	x13, x10, [x16, #64]
   1a598:	2a1c03ea 	mov	w10, w28
   1a59c:	f9002a0a 	str	x10, [x16, #80]
   1a5a0:	f85203aa 	ldur	x10, [x29, #-224]
   1a5a4:	a9032605 	stp	x5, x9, [x16, #48]
   1a5a8:	aa0c03e9 	mov	x9, x12
   1a5ac:	aa0b03ec 	mov	x12, x11
   1a5b0:	f9002e0a 	str	x10, [x16, #88]
   1a5b4:	f85403aa 	ldur	x10, [x29, #-192]
   1a5b8:	2a0903e9 	mov	w9, w9
   1a5bc:	f85503ab 	ldur	x11, [x29, #-176]
   1a5c0:	a90cfa02 	stp	x2, x30, [x16, #200]
   1a5c4:	a9062a13 	stp	x19, x10, [x16, #96]
   1a5c8:	2a0c03ea 	mov	w10, w12
   1a5cc:	a9072a09 	stp	x9, x10, [x16, #112]
   1a5d0:	2a1803e9 	mov	w9, w24
   1a5d4:	2a0603ea 	mov	w10, w6
   1a5d8:	a9082a09 	stp	x9, x10, [x16, #128]
   1a5dc:	f85383aa 	ldur	x10, [x29, #-200]
   1a5e0:	2a0f03e9 	mov	w9, w15
   1a5e4:	2a0a03ea 	mov	w10, w10
   1a5e8:	a9092a09 	stp	x9, x10, [x16, #144]
   1a5ec:	2a1603e9 	mov	w9, w22
   1a5f0:	2a1903ea 	mov	w10, w25
   1a5f4:	a90a2a09 	stp	x9, x10, [x16, #160]
   1a5f8:	2a1a03e9 	mov	w9, w26
   1a5fc:	f85303aa 	ldur	x10, [x29, #-208]
   1a600:	f9005a09 	str	x9, [x16, #176]
   1a604:	d2c4e009 	mov	x9, #0x270000000000        	// #42880953483264
   1a608:	f2e0a009 	movk	x9, #0x500, lsl #48
   1a60c:	a90baa0b 	stp	x11, x10, [x16, #184]
   1a610:	aa090100 	orr	x0, x8, x9
   1a614:	910943ff 	add	sp, sp, #0x250
   1a618:	a8c17bfd 	ldp	x29, x30, [sp], #16
   1a61c:	d65f03c0 	ret
   1a620:	a91387e0 	stp	x0, x1, [sp, #312]
   1a624:	aa1403e0 	mov	x0, x20
   1a628:	aa1503e1 	mov	x1, x21
   1a62c:	f81083a2 	stur	x2, [x29, #-248]
   1a630:	528000a2 	mov	w2, #0x5                   	// #5
   1a634:	f9007bf8 	str	x24, [sp, #240]
   1a638:	aa0503f8 	mov	x24, x5
   1a63c:	a91193e3 	stp	x3, x4, [sp, #280]
   1a640:	f9009be7 	str	x7, [sp, #304]
   1a644:	f81103a6 	stur	x6, [x29, #-240]
   1a648:	97ffaa12 	bl	4e90 <heap_alloc_miss>
   1a64c:	a9709ba2 	ldp	x2, x6, [x29, #-248]
   1a650:	aa0003e8 	mov	x8, x0
   1a654:	a95193e3 	ldp	x3, x4, [sp, #280]
   1a658:	aa1803e5 	mov	x5, x24
   1a65c:	a95303e7 	ldp	x7, x0, [sp, #304]
   1a660:	f940a3e1 	ldr	x1, [sp, #320]
   1a664:	f9407bf8 	ldr	x24, [sp, #240]
   1a668:	17fffcb3 	b	19934 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x2ec>
   1a66c:	a91387e0 	stp	x0, x1, [sp, #312]
   1a670:	aa1403e0 	mov	x0, x20
   1a674:	aa1503e1 	mov	x1, x21
   1a678:	f81083a2 	stur	x2, [x29, #-248]
   1a67c:	528000a2 	mov	w2, #0x5                   	// #5
   1a680:	aa0e03ef 	mov	x15, x14
   1a684:	aa0503f7 	mov	x23, x5
   1a688:	f90093e4 	str	x4, [sp, #288]
   1a68c:	aa0303f5 	mov	x21, x3
   1a690:	f9009be7 	str	x7, [sp, #304]
   1a694:	f9007bf8 	str	x24, [sp, #240]
   1a698:	aa0603f8 	mov	x24, x6
   1a69c:	97ffa9fd 	bl	4e90 <heap_alloc_miss>
   1a6a0:	aa0003e8 	mov	x8, x0
   1a6a4:	a95303e7 	ldp	x7, x0, [sp, #304]
   1a6a8:	aa1803e6 	mov	x6, x24
   1a6ac:	f9407bf8 	ldr	x24, [sp, #240]
   1a6b0:	f85083a2 	ldur	x2, [x29, #-248]
   1a6b4:	f940a3e1 	ldr	x1, [sp, #320]
   1a6b8:	f94093e4 	ldr	x4, [sp, #288]
   1a6bc:	aa1503e3 	mov	x3, x21
   1a6c0:	f85483b6 	ldur	x22, [x29, #-184]
   1a6c4:	aa1703e5 	mov	x5, x23
   1a6c8:	17fffcbe 	b	199c0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x378>
   1a6cc:	f90073e0 	str	x0, [sp, #224]
   1a6d0:	aa1403e0 	mov	x0, x20
   1a6d4:	aa1503e1 	mov	x1, x21
   1a6d8:	f90067e2 	str	x2, [sp, #200]
   1a6dc:	52800022 	mov	w2, #0x1                   	// #1
   1a6e0:	aa0603e9 	mov	x9, x6
   1a6e4:	aa1e03eb 	mov	x11, x30
   1a6e8:	aa0703ee 	mov	x14, x7
   1a6ec:	3d8043e2 	str	q2, [sp, #256]
   1a6f0:	3d8037e1 	str	q1, [sp, #208]
   1a6f4:	97ffa9e7 	bl	4e90 <heap_alloc_miss>
   1a6f8:	aa0b03fe 	mov	x30, x11
   1a6fc:	a9532ff0 	ldp	x16, x11, [sp, #304]
   1a700:	a95187e8 	ldp	x8, x1, [sp, #280]
   1a704:	aa0e03e7 	mov	x7, x14
   1a708:	3dc037e1 	ldr	q1, [sp, #208]
   1a70c:	3dc043e2 	ldr	q2, [sp, #256]
   1a710:	aa0903e6 	mov	x6, x9
   1a714:	f94067e2 	ldr	x2, [sp, #200]
   1a718:	f85303a5 	ldur	x5, [x29, #-208]
   1a71c:	aa0003ee 	mov	x14, x0
   1a720:	f940a3e9 	ldr	x9, [sp, #320]
   1a724:	f9407fe3 	ldr	x3, [sp, #248]
   1a728:	f85583a4 	ldur	x4, [x29, #-168]
   1a72c:	f94073e0 	ldr	x0, [sp, #224]
   1a730:	d378fdb1 	lsr	x17, x13, #56
   1a734:	f1000a3f 	cmp	x17, #0x2
   1a738:	54ffcd21 	b.ne	1a0dc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xa94>  // b.any
   1a73c:	f90073e0 	str	x0, [sp, #224]
   1a740:	aa1403e0 	mov	x0, x20
   1a744:	aa1503e1 	mov	x1, x21
   1a748:	f90067e2 	str	x2, [sp, #200]
   1a74c:	aa0d03e2 	mov	x2, x13
   1a750:	52800023 	mov	w3, #0x1                   	// #1
   1a754:	aa0603e9 	mov	x9, x6
   1a758:	aa1e03eb 	mov	x11, x30
   1a75c:	aa0703ed 	mov	x13, x7
   1a760:	3d8043e2 	str	q2, [sp, #256]
   1a764:	3d8037e1 	str	q1, [sp, #208]
   1a768:	97ffaabd 	bl	525c <rfc_wrap>
   1a76c:	aa0b03fe 	mov	x30, x11
   1a770:	a9532ff0 	ldp	x16, x11, [sp, #304]
   1a774:	a95187e8 	ldp	x8, x1, [sp, #280]
   1a778:	aa0d03e7 	mov	x7, x13
   1a77c:	3dc037e1 	ldr	q1, [sp, #208]
   1a780:	3dc043e2 	ldr	q2, [sp, #256]
   1a784:	aa0903e6 	mov	x6, x9
   1a788:	f94067e2 	ldr	x2, [sp, #200]
   1a78c:	f85303a5 	ldur	x5, [x29, #-208]
   1a790:	aa0003ed 	mov	x13, x0
   1a794:	f940a3e9 	ldr	x9, [sp, #320]
   1a798:	f9407fe3 	ldr	x3, [sp, #248]
   1a79c:	f85583a4 	ldur	x4, [x29, #-168]
   1a7a0:	f94073e0 	ldr	x0, [sp, #224]
   1a7a4:	8b0e0e91 	add	x17, x20, x14, lsl #3
   1a7a8:	a9003e2d 	stp	x13, x15, [x17]
   1a7ac:	f9400eaf 	ldr	x15, [x21, #24]
   1a7b0:	b5ffc9ef 	cbnz	x15, 1a0ec <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xaa4>
   1a7b4:	f90073e0 	str	x0, [sp, #224]
   1a7b8:	aa1403e0 	mov	x0, x20
   1a7bc:	aa1503e1 	mov	x1, x21
   1a7c0:	aa0203ed 	mov	x13, x2
   1a7c4:	52800062 	mov	w2, #0x3                   	// #3
   1a7c8:	aa0603e9 	mov	x9, x6
   1a7cc:	aa1e03eb 	mov	x11, x30
   1a7d0:	aa0703ef 	mov	x15, x7
   1a7d4:	3d8043e2 	str	q2, [sp, #256]
   1a7d8:	3d8037e1 	str	q1, [sp, #208]
   1a7dc:	97ffa9ad 	bl	4e90 <heap_alloc_miss>
   1a7e0:	aa0b03fe 	mov	x30, x11
   1a7e4:	a9532ff0 	ldp	x16, x11, [sp, #304]
   1a7e8:	a95187e8 	ldp	x8, x1, [sp, #280]
   1a7ec:	aa0f03e7 	mov	x7, x15
   1a7f0:	3dc037e1 	ldr	q1, [sp, #208]
   1a7f4:	3dc043e2 	ldr	q2, [sp, #256]
   1a7f8:	aa0903e6 	mov	x6, x9
   1a7fc:	f85303a5 	ldur	x5, [x29, #-208]
   1a800:	f940a3e9 	ldr	x9, [sp, #320]
   1a804:	aa0003ef 	mov	x15, x0
   1a808:	f9407fe3 	ldr	x3, [sp, #248]
   1a80c:	f85583a4 	ldur	x4, [x29, #-168]
   1a810:	aa0d03e2 	mov	x2, x13
   1a814:	f94073e0 	ldr	x0, [sp, #224]
   1a818:	17fffe3a 	b	1a100 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xab8>
   1a81c:	f90073e0 	str	x0, [sp, #224]
   1a820:	aa1403e0 	mov	x0, x20
   1a824:	aa1503e1 	mov	x1, x21
   1a828:	52800022 	mov	w2, #0x1                   	// #1
   1a82c:	aa0603e9 	mov	x9, x6
   1a830:	aa1e03eb 	mov	x11, x30
   1a834:	aa0703ed 	mov	x13, x7
   1a838:	97ffa996 	bl	4e90 <heap_alloc_miss>
   1a83c:	aa0b03fe 	mov	x30, x11
   1a840:	a9532ff0 	ldp	x16, x11, [sp, #304]
   1a844:	a95187e8 	ldp	x8, x1, [sp, #280]
   1a848:	aa0d03e7 	mov	x7, x13
   1a84c:	f85303a5 	ldur	x5, [x29, #-208]
   1a850:	aa0903e6 	mov	x6, x9
   1a854:	f940a3e9 	ldr	x9, [sp, #320]
   1a858:	f9407fe3 	ldr	x3, [sp, #248]
   1a85c:	f85583a4 	ldur	x4, [x29, #-168]
   1a860:	aa0003ed 	mov	x13, x0
   1a864:	f94073e0 	ldr	x0, [sp, #224]
   1a868:	d2c40011 	mov	x17, #0x200000000000        	// #35184372088832
   1a86c:	f2e04011 	movk	x17, #0x200, lsl #48
   1a870:	aa1101c2 	orr	x2, x14, x17
   1a874:	d378fc4e 	lsr	x14, x2, #56
   1a878:	f10009df 	cmp	x14, #0x2
   1a87c:	54ffc681 	b.ne	1a14c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xb04>  // b.any
   1a880:	f90073e0 	str	x0, [sp, #224]
   1a884:	aa1403e0 	mov	x0, x20
   1a888:	aa1503e1 	mov	x1, x21
   1a88c:	52800023 	mov	w3, #0x1                   	// #1
   1a890:	aa0603e9 	mov	x9, x6
   1a894:	aa1e03eb 	mov	x11, x30
   1a898:	aa1a03ee 	mov	x14, x26
   1a89c:	aa1903fa 	mov	x26, x25
   1a8a0:	aa0703f9 	mov	x25, x7
   1a8a4:	97ffaa6e 	bl	525c <rfc_wrap>
   1a8a8:	aa0b03fe 	mov	x30, x11
   1a8ac:	a9532ff0 	ldp	x16, x11, [sp, #304]
   1a8b0:	a95187e8 	ldp	x8, x1, [sp, #280]
   1a8b4:	aa0903e6 	mov	x6, x9
   1a8b8:	f85303a5 	ldur	x5, [x29, #-208]
   1a8bc:	f940a3e9 	ldr	x9, [sp, #320]
   1a8c0:	aa0003e2 	mov	x2, x0
   1a8c4:	f9407fe3 	ldr	x3, [sp, #248]
   1a8c8:	f85583a4 	ldur	x4, [x29, #-168]
   1a8cc:	aa1903e7 	mov	x7, x25
   1a8d0:	f94073e0 	ldr	x0, [sp, #224]
   1a8d4:	aa1a03f9 	mov	x25, x26
   1a8d8:	aa0e03fa 	mov	x26, x14
   1a8dc:	17fffe1c 	b	1a14c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xb04>
   1a8e0:	f90073e0 	str	x0, [sp, #224]
   1a8e4:	aa1403e0 	mov	x0, x20
   1a8e8:	aa1503e1 	mov	x1, x21
   1a8ec:	aa0e03e2 	mov	x2, x14
   1a8f0:	52800023 	mov	w3, #0x1                   	// #1
   1a8f4:	aa0603e9 	mov	x9, x6
   1a8f8:	aa1e03eb 	mov	x11, x30
   1a8fc:	aa0703ee 	mov	x14, x7
   1a900:	97ffaa57 	bl	525c <rfc_wrap>
   1a904:	aa0b03fe 	mov	x30, x11
   1a908:	a9532ff0 	ldp	x16, x11, [sp, #304]
   1a90c:	a95187e8 	ldp	x8, x1, [sp, #280]
   1a910:	aa0e03e7 	mov	x7, x14
   1a914:	f85303a5 	ldur	x5, [x29, #-208]
   1a918:	aa0903e6 	mov	x6, x9
   1a91c:	f940a3e9 	ldr	x9, [sp, #320]
   1a920:	f9407fe3 	ldr	x3, [sp, #248]
   1a924:	f85583a4 	ldur	x4, [x29, #-168]
   1a928:	aa0003ee 	mov	x14, x0
   1a92c:	f94073e0 	ldr	x0, [sp, #224]
   1a930:	17fffe11 	b	1a174 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xb2c>
   1a934:	a91387e0 	stp	x0, x1, [sp, #312]
   1a938:	aa1403e0 	mov	x0, x20
   1a93c:	aa1503e1 	mov	x1, x21
   1a940:	f81083a2 	stur	x2, [x29, #-248]
   1a944:	528000a2 	mov	w2, #0x5                   	// #5
   1a948:	aa0603ee 	mov	x14, x6
   1a94c:	f9007bf8 	str	x24, [sp, #240]
   1a950:	aa0503f8 	mov	x24, x5
   1a954:	a91193e3 	stp	x3, x4, [sp, #280]
   1a958:	f9009be7 	str	x7, [sp, #304]
   1a95c:	f81103be 	stur	x30, [x29, #-240]
   1a960:	97ffa94c 	bl	4e90 <heap_alloc_miss>
   1a964:	a970fba2 	ldp	x2, x30, [x29, #-248]
   1a968:	aa0003e8 	mov	x8, x0
   1a96c:	a95193e3 	ldp	x3, x4, [sp, #280]
   1a970:	aa1803e5 	mov	x5, x24
   1a974:	a95303e7 	ldp	x7, x0, [sp, #304]
   1a978:	aa0e03e6 	mov	x6, x14
   1a97c:	f940a3e1 	ldr	x1, [sp, #320]
   1a980:	f9407bf8 	ldr	x24, [sp, #240]
   1a984:	f85483b6 	ldur	x22, [x29, #-184]
   1a988:	17fffc4c 	b	19ab8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x470>
   1a98c:	f85203af 	ldur	x15, [x29, #-224]
   1a990:	a91387e0 	stp	x0, x1, [sp, #312]
   1a994:	aa1403e0 	mov	x0, x20
   1a998:	aa1503e1 	mov	x1, x21
   1a99c:	f81083a2 	stur	x2, [x29, #-248]
   1a9a0:	528000a2 	mov	w2, #0x5                   	// #5
   1a9a4:	aa0503f7 	mov	x23, x5
   1a9a8:	f9007bf8 	str	x24, [sp, #240]
   1a9ac:	aa0403f8 	mov	x24, x4
   1a9b0:	aa0303f5 	mov	x21, x3
   1a9b4:	f9009be7 	str	x7, [sp, #304]
   1a9b8:	aa0603ee 	mov	x14, x6
   1a9bc:	f81103be 	stur	x30, [x29, #-240]
   1a9c0:	97ffa934 	bl	4e90 <heap_alloc_miss>
   1a9c4:	a970fba2 	ldp	x2, x30, [x29, #-248]
   1a9c8:	aa0003e8 	mov	x8, x0
   1a9cc:	a95303e7 	ldp	x7, x0, [sp, #304]
   1a9d0:	aa1803e4 	mov	x4, x24
   1a9d4:	f940a3e1 	ldr	x1, [sp, #320]
   1a9d8:	f9407bf8 	ldr	x24, [sp, #240]
   1a9dc:	aa0e03e6 	mov	x6, x14
   1a9e0:	f85483b6 	ldur	x22, [x29, #-184]
   1a9e4:	aa1503e3 	mov	x3, x21
   1a9e8:	aa1703e5 	mov	x5, x23
   1a9ec:	17fffc55 	b	19b40 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x4f8>
   1a9f0:	aa1403e0 	mov	x0, x20
   1a9f4:	aa1503e1 	mov	x1, x21
   1a9f8:	aa0203ec 	mov	x12, x2
   1a9fc:	52800022 	mov	w2, #0x1                   	// #1
   1aa00:	aa0503ed 	mov	x13, x5
   1aa04:	aa1e03e9 	mov	x9, x30
   1aa08:	aa0603ee 	mov	x14, x6
   1aa0c:	aa1a03fc 	mov	x28, x26
   1aa10:	aa1903fa 	mov	x26, x25
   1aa14:	aa0b03f9 	mov	x25, x11
   1aa18:	aa1b03eb 	mov	x11, x27
   1aa1c:	aa1203fb 	mov	x27, x18
   1aa20:	97ffa708 	bl	4640 <heap_hand>
   1aa24:	aa0c03e2 	mov	x2, x12
   1aa28:	52909fec 	mov	w12, #0x84ff                	// #34047
   1aa2c:	aa1b03f2 	mov	x18, x27
   1aa30:	aa0b03fb 	mov	x27, x11
   1aa34:	aa1903eb 	mov	x11, x25
   1aa38:	aa1a03f9 	mov	x25, x26
   1aa3c:	aa1c03fa 	mov	x26, x28
   1aa40:	aa0e03e6 	mov	x6, x14
   1aa44:	aa0903fe 	mov	x30, x9
   1aa48:	72a0620c 	movk	w12, #0x310, lsl #16
   1aa4c:	aa0d03e5 	mov	x5, x13
   1aa50:	17fffca7 	b	19cec <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x6a4>
   1aa54:	aa1403e0 	mov	x0, x20
   1aa58:	aa1503e1 	mov	x1, x21
   1aa5c:	aa0203ec 	mov	x12, x2
   1aa60:	52800022 	mov	w2, #0x1                   	// #1
   1aa64:	aa0503f3 	mov	x19, x5
   1aa68:	aa1e03e9 	mov	x9, x30
   1aa6c:	aa0603ee 	mov	x14, x6
   1aa70:	aa1a03fc 	mov	x28, x26
   1aa74:	aa1903fa 	mov	x26, x25
   1aa78:	aa0b03f9 	mov	x25, x11
   1aa7c:	aa1b03eb 	mov	x11, x27
   1aa80:	aa1203fb 	mov	x27, x18
   1aa84:	97ffa6ef 	bl	4640 <heap_hand>
   1aa88:	aa0c03e2 	mov	x2, x12
   1aa8c:	52909fec 	mov	w12, #0x84ff                	// #34047
   1aa90:	aa1b03f2 	mov	x18, x27
   1aa94:	aa0b03fb 	mov	x27, x11
   1aa98:	aa1903eb 	mov	x11, x25
   1aa9c:	aa1a03f9 	mov	x25, x26
   1aaa0:	aa1c03fa 	mov	x26, x28
   1aaa4:	aa0e03e6 	mov	x6, x14
   1aaa8:	aa0903fe 	mov	x30, x9
   1aaac:	72a0620c 	movk	w12, #0x310, lsl #16
   1aab0:	aa1303e5 	mov	x5, x19
   1aab4:	17fffcc8 	b	19dd4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x78c>
   1aab8:	aa1403e0 	mov	x0, x20
   1aabc:	aa1503e1 	mov	x1, x21
   1aac0:	aa0203ec 	mov	x12, x2
   1aac4:	52800062 	mov	w2, #0x3                   	// #3
   1aac8:	aa1e03e9 	mov	x9, x30
   1aacc:	aa0603ee 	mov	x14, x6
   1aad0:	aa1903fa 	mov	x26, x25
   1aad4:	aa0b03f9 	mov	x25, x11
   1aad8:	aa1b03eb 	mov	x11, x27
   1aadc:	aa1203fb 	mov	x27, x18
   1aae0:	97ffa6d8 	bl	4640 <heap_hand>
   1aae4:	aa0c03e2 	mov	x2, x12
   1aae8:	aa1b03f2 	mov	x18, x27
   1aaec:	aa0b03fb 	mov	x27, x11
   1aaf0:	aa1903eb 	mov	x11, x25
   1aaf4:	aa1a03f9 	mov	x25, x26
   1aaf8:	aa0e03e6 	mov	x6, x14
   1aafc:	aa0903fe 	mov	x30, x9
   1ab00:	17fffcf8 	b	19ee0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x898>
   1ab04:	aa0d8228 	orr	x8, x17, x13, lsl #32
   1ab08:	aa1403e0 	mov	x0, x20
   1ab0c:	aa1503e1 	mov	x1, x21
   1ab10:	52800044 	mov	w4, #0x2                   	// #2
   1ab14:	aa1e03e9 	mov	x9, x30
   1ab18:	aa0603ee 	mov	x14, x6
   1ab1c:	d358fd08 	lsr	x8, x8, #24
   1ab20:	8b080e8d 	add	x13, x20, x8, lsl #3
   1ab24:	aa0803e3 	mov	x3, x8
   1ab28:	a94031b8 	ldp	x24, x12, [x13]
   1ab2c:	aa0503ed 	mov	x13, x5
   1ab30:	97ffa6f7 	bl	470c <span_fade>
   1ab34:	aa0c03e2 	mov	x2, x12
   1ab38:	52909fec 	mov	w12, #0x84ff                	// #34047
   1ab3c:	aa0e03e6 	mov	x6, x14
   1ab40:	aa0903fe 	mov	x30, x9
   1ab44:	aa0d03e5 	mov	x5, x13
   1ab48:	aa1b03f2 	mov	x18, x27
   1ab4c:	aa0b03fb 	mov	x27, x11
   1ab50:	aa1903eb 	mov	x11, x25
   1ab54:	aa1a03f9 	mov	x25, x26
   1ab58:	aa1c03fa 	mov	x26, x28
   1ab5c:	72a0620c 	movk	w12, #0x310, lsl #16
   1ab60:	17fffc63 	b	19cec <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x6a4>
   1ab64:	aa0d8228 	orr	x8, x17, x13, lsl #32
   1ab68:	aa1403e0 	mov	x0, x20
   1ab6c:	aa1503e1 	mov	x1, x21
   1ab70:	aa1803e2 	mov	x2, x24
   1ab74:	52800044 	mov	w4, #0x2                   	// #2
   1ab78:	aa0503f3 	mov	x19, x5
   1ab7c:	d358fd08 	lsr	x8, x8, #24
   1ab80:	aa1e03e9 	mov	x9, x30
   1ab84:	aa0603ee 	mov	x14, x6
   1ab88:	8b080e90 	add	x16, x20, x8, lsl #3
   1ab8c:	aa0803e3 	mov	x3, x8
   1ab90:	a940320d 	ldp	x13, x12, [x16]
   1ab94:	f9006bec 	str	x12, [sp, #208]
   1ab98:	97ffa6dd 	bl	470c <span_fade>
   1ab9c:	52909fec 	mov	w12, #0x84ff                	// #34047
   1aba0:	f94077e2 	ldr	x2, [sp, #232]
   1aba4:	aa0e03e6 	mov	x6, x14
   1aba8:	aa0903fe 	mov	x30, x9
   1abac:	72a0620c 	movk	w12, #0x310, lsl #16
   1abb0:	aa1303e5 	mov	x5, x19
   1abb4:	aa1b03f2 	mov	x18, x27
   1abb8:	aa0b03fb 	mov	x27, x11
   1abbc:	aa1903eb 	mov	x11, x25
   1abc0:	aa1a03f9 	mov	x25, x26
   1abc4:	aa1c03fa 	mov	x26, x28
   1abc8:	17fffc83 	b	19dd4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x78c>
   1abcc:	aa1403e0 	mov	x0, x20
   1abd0:	aa1503e1 	mov	x1, x21
   1abd4:	aa1803e3 	mov	x3, x24
   1abd8:	528000a4 	mov	w4, #0x5                   	// #5
   1abdc:	aa1e03e9 	mov	x9, x30
   1abe0:	aa0603ec 	mov	x12, x6
   1abe4:	97ffa6ca 	bl	470c <span_fade>
   1abe8:	aa0c03e6 	mov	x6, x12
   1abec:	aa0903fe 	mov	x30, x9
   1abf0:	aa1b03f2 	mov	x18, x27
   1abf4:	aa0b03fb 	mov	x27, x11
   1abf8:	aa1903eb 	mov	x11, x25
   1abfc:	aa1a03f9 	mov	x25, x26
   1ac00:	aa0e03e2 	mov	x2, x14
   1ac04:	17fffcb7 	b	19ee0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x898>
   1ac08:	a91387e0 	stp	x0, x1, [sp, #312]
   1ac0c:	aa1403e0 	mov	x0, x20
   1ac10:	aa1503e1 	mov	x1, x21
   1ac14:	f81083a2 	stur	x2, [x29, #-248]
   1ac18:	528000a2 	mov	w2, #0x5                   	// #5
   1ac1c:	aa0503ea 	mov	x10, x5
   1ac20:	f90093e4 	str	x4, [sp, #288]
   1ac24:	aa1e03e9 	mov	x9, x30
   1ac28:	aa0603ee 	mov	x14, x6
   1ac2c:	f9007bf8 	str	x24, [sp, #240]
   1ac30:	aa0303f8 	mov	x24, x3
   1ac34:	f9009be7 	str	x7, [sp, #304]
   1ac38:	97ffa896 	bl	4e90 <heap_alloc_miss>
   1ac3c:	aa0003e8 	mov	x8, x0
   1ac40:	a95303e7 	ldp	x7, x0, [sp, #304]
   1ac44:	f85083a2 	ldur	x2, [x29, #-248]
   1ac48:	f940a3e1 	ldr	x1, [sp, #320]
   1ac4c:	aa1803e3 	mov	x3, x24
   1ac50:	f9407bf8 	ldr	x24, [sp, #240]
   1ac54:	f94093e4 	ldr	x4, [sp, #288]
   1ac58:	aa0e03e6 	mov	x6, x14
   1ac5c:	aa0903fe 	mov	x30, x9
   1ac60:	aa0a03e5 	mov	x5, x10
   1ac64:	17fffdd4 	b	1a3b4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xd6c>
   1ac68:	a91387e0 	stp	x0, x1, [sp, #312]
   1ac6c:	aa1403e0 	mov	x0, x20
   1ac70:	aa1503e1 	mov	x1, x21
   1ac74:	f81083a2 	stur	x2, [x29, #-248]
   1ac78:	528000a2 	mov	w2, #0x5                   	// #5
   1ac7c:	aa1703ef 	mov	x15, x23
   1ac80:	aa0503f3 	mov	x19, x5
   1ac84:	aa0403f7 	mov	x23, x4
   1ac88:	aa0303ea 	mov	x10, x3
   1ac8c:	f9007bf8 	str	x24, [sp, #240]
   1ac90:	aa0703f8 	mov	x24, x7
   1ac94:	aa1e03e9 	mov	x9, x30
   1ac98:	aa0603ee 	mov	x14, x6
   1ac9c:	97ffa87d 	bl	4e90 <heap_alloc_miss>
   1aca0:	aa0003e8 	mov	x8, x0
   1aca4:	a95387e0 	ldp	x0, x1, [sp, #312]
   1aca8:	f85083a2 	ldur	x2, [x29, #-248]
   1acac:	aa1803e7 	mov	x7, x24
   1acb0:	f9407bf8 	ldr	x24, [sp, #240]
   1acb4:	f85483b6 	ldur	x22, [x29, #-184]
   1acb8:	aa0e03e6 	mov	x6, x14
   1acbc:	aa0903fe 	mov	x30, x9
   1acc0:	aa0a03e3 	mov	x3, x10
   1acc4:	aa1703e4 	mov	x4, x23
   1acc8:	aa1303e5 	mov	x5, x19
   1accc:	17fffddf 	b	1a448 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xe00>
   1acd0:	aa1403e0 	mov	x0, x20
   1acd4:	aa1503e1 	mov	x1, x21
   1acd8:	aa0203ec 	mov	x12, x2
   1acdc:	2a1f03e2 	mov	w2, wzr
   1ace0:	aa0503f3 	mov	x19, x5
   1ace4:	aa1e03e9 	mov	x9, x30
   1ace8:	aa0603ee 	mov	x14, x6
   1acec:	97ffa655 	bl	4640 <heap_hand>
   1acf0:	aa0c03e2 	mov	x2, x12
   1acf4:	aa0e03e6 	mov	x6, x14
   1acf8:	aa0903fe 	mov	x30, x9
   1acfc:	aa1303e5 	mov	x5, x19
   1ad00:	17fffbe6 	b	19c98 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x650>
   1ad04:	aa1403e0 	mov	x0, x20
   1ad08:	aa1503e1 	mov	x1, x21
   1ad0c:	2a1f03e2 	mov	w2, wzr
   1ad10:	aa0503f8 	mov	x24, x5
   1ad14:	aa1e03e9 	mov	x9, x30
   1ad18:	aa0603ee 	mov	x14, x6
   1ad1c:	97ffa649 	bl	4640 <heap_hand>
   1ad20:	52909fec 	mov	w12, #0x84ff                	// #34047
   1ad24:	aa0e03e6 	mov	x6, x14
   1ad28:	aa0903fe 	mov	x30, x9
   1ad2c:	72a0620c 	movk	w12, #0x310, lsl #16
   1ad30:	aa1803e5 	mov	x5, x24
   1ad34:	17fffc14 	b	19d84 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x73c>
   1ad38:	aa1403e0 	mov	x0, x20
   1ad3c:	aa1503e1 	mov	x1, x21
   1ad40:	2a1f03e2 	mov	w2, wzr
   1ad44:	aa1e03e9 	mov	x9, x30
   1ad48:	aa0603ec 	mov	x12, x6
   1ad4c:	97ffa63d 	bl	4640 <heap_hand>
   1ad50:	aa0c03e6 	mov	x6, x12
   1ad54:	52909fec 	mov	w12, #0x84ff                	// #34047
   1ad58:	aa0903fe 	mov	x30, x9
   1ad5c:	72a0620c 	movk	w12, #0x310, lsl #16
   1ad60:	17fffc4d 	b	19e94 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x84c>
   1ad64:	a91387e0 	stp	x0, x1, [sp, #312]
   1ad68:	aa1403e0 	mov	x0, x20
   1ad6c:	aa1503e1 	mov	x1, x21
   1ad70:	528000a2 	mov	w2, #0x5                   	// #5
   1ad74:	aa0503eb 	mov	x11, x5
   1ad78:	f90093e4 	str	x4, [sp, #288]
   1ad7c:	f9007bf8 	str	x24, [sp, #240]
   1ad80:	aa0303f8 	mov	x24, x3
   1ad84:	aa1e03e9 	mov	x9, x30
   1ad88:	f9009be7 	str	x7, [sp, #304]
   1ad8c:	aa0603ee 	mov	x14, x6
   1ad90:	97ffa840 	bl	4e90 <heap_alloc_miss>
   1ad94:	aa0003e8 	mov	x8, x0
   1ad98:	a95303e7 	ldp	x7, x0, [sp, #304]
   1ad9c:	f85083a2 	ldur	x2, [x29, #-248]
   1ada0:	f940a3e1 	ldr	x1, [sp, #320]
   1ada4:	aa1803e3 	mov	x3, x24
   1ada8:	f9407bf8 	ldr	x24, [sp, #240]
   1adac:	f94093e4 	ldr	x4, [sp, #288]
   1adb0:	aa0e03e6 	mov	x6, x14
   1adb4:	aa0903fe 	mov	x30, x9
   1adb8:	aa0b03e5 	mov	x5, x11
   1adbc:	17fffdc4 	b	1a4cc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xe84>
   1adc0:	a91387e0 	stp	x0, x1, [sp, #312]
   1adc4:	aa1403e0 	mov	x0, x20
   1adc8:	aa1503e1 	mov	x1, x21
   1adcc:	528000a2 	mov	w2, #0x5                   	// #5
   1add0:	aa1703ef 	mov	x15, x23
   1add4:	aa0503f3 	mov	x19, x5
   1add8:	aa0403f7 	mov	x23, x4
   1addc:	aa0303ea 	mov	x10, x3
   1ade0:	f9007bf8 	str	x24, [sp, #240]
   1ade4:	aa0703f8 	mov	x24, x7
   1ade8:	aa1e03e9 	mov	x9, x30
   1adec:	aa0603ee 	mov	x14, x6
   1adf0:	97ffa828 	bl	4e90 <heap_alloc_miss>
   1adf4:	aa0003e8 	mov	x8, x0
   1adf8:	a95387e0 	ldp	x0, x1, [sp, #312]
   1adfc:	f85083a2 	ldur	x2, [x29, #-248]
   1ae00:	aa1803e7 	mov	x7, x24
   1ae04:	f9407bf8 	ldr	x24, [sp, #240]
   1ae08:	f85483b6 	ldur	x22, [x29, #-184]
   1ae0c:	aa0e03e6 	mov	x6, x14
   1ae10:	aa0903fe 	mov	x30, x9
   1ae14:	aa0a03e3 	mov	x3, x10
   1ae18:	aa1703e4 	mov	x4, x23
   1ae1c:	aa1303e5 	mov	x5, x19
   1ae20:	17fffdd0 	b	1a560 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xf18>

