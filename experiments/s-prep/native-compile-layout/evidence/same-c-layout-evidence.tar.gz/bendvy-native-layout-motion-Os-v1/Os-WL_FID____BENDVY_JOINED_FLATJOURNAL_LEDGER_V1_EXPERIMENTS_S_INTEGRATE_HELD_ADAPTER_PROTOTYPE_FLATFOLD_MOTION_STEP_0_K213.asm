   19f7c:	d10243ff 	sub	sp, sp, #0x90
   19f80:	a9087bfd 	stp	x29, x30, [sp, #128]
   19f84:	910203fd 	add	x29, sp, #0x80
   19f88:	a93da7af 	stp	x15, x9, [x29, #-40]
   19f8c:	aa0e03e9 	mov	x9, x14
   19f90:	aa0503f3 	mov	x19, x5
   19f94:	a9453baf 	ldp	x15, x14, [x29, #80]
   19f98:	aa1603e8 	mov	x8, x22
   19f9c:	a94343be 	ldp	x30, x16, [x29, #48]
   19fa0:	f81e83ac 	stur	x12, [x29, #-24]
   19fa4:	a9414ba2 	ldp	x2, x18, [x29, #16]
   19fa8:	aa0703ec 	mov	x12, x7
   19fac:	f81f03ae 	stur	x14, [x29, #-16]
   19fb0:	a94417ae 	ldp	x14, x5, [x29, #64]
   19fb4:	f81d03b0 	stur	x16, [x29, #-48]
   19fb8:	aa0103e7 	mov	x7, x1
   19fbc:	aa0003e1 	mov	x1, x0
   19fc0:	a94243b1 	ldp	x17, x16, [x29, #32]
   19fc4:	b85f8ed8 	ldr	w24, [x22, #-8]!
   19fc8:	340003f7 	cbz	w23, 1a044 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K213+0xc8>
   19fcc:	f85f03a8 	ldur	x8, [x29, #-16]
   19fd0:	aa0103e0 	mov	x0, x1
   19fd4:	aa0703e1 	mov	x1, x7
   19fd8:	2a0c03e7 	mov	w7, w12
   19fdc:	f85d03ac 	ldur	x12, [x29, #-48]
   19fe0:	a904bfa5 	stp	x5, x15, [x29, #72]
   19fe4:	2a0803e8 	mov	w8, w8
   19fe8:	2a1903f9 	mov	w25, w25
   19fec:	2a1a03fa 	mov	w26, w26
   19ff0:	a903bbac 	stp	x12, x14, [x29, #56]
   19ff4:	2a1e03ec 	mov	w12, w30
   19ff8:	2a0903ee 	mov	w14, w9
   19ffc:	a905e3a8 	stp	x8, x24, [x29, #88]
   1a000:	2a1003e8 	mov	w8, w16
   1a004:	2a0203f0 	mov	w16, w2
   1a008:	a902b3a8 	stp	x8, x12, [x29, #40]
   1a00c:	a97da7a8 	ldp	x8, x9, [x29, #-40]
   1a010:	2a1103ec 	mov	w12, w17
   1a014:	2a1303e5 	mov	w5, w19
   1a018:	2a0b03eb 	mov	w11, w11
   1a01c:	2a0d03ed 	mov	w13, w13
   1a020:	2a0803ef 	mov	w15, w8
   1a024:	2a1203e8 	mov	w8, w18
   1a028:	2a0903e9 	mov	w9, w9
   1a02c:	a901b3a8 	stp	x8, x12, [x29, #24]
   1a030:	f85e83ac 	ldur	x12, [x29, #-24]
   1a034:	f9000bb0 	str	x16, [x29, #16]
   1a038:	a9487bfd 	ldp	x29, x30, [sp, #128]
   1a03c:	910243ff 	add	sp, sp, #0x90
   1a040:	17fff4cc 	b	17370 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_FALLBACK>
   1a044:	a903c7f2 	stp	x18, x17, [sp, #56]
   1a048:	a97e5d12 	ldp	x18, x23, [x8, #-32]
   1a04c:	f94016a0 	ldr	x0, [x21, #40]
   1a050:	aa0203f6 	mov	x22, x2
   1a054:	f81c83b0 	stur	x16, [x29, #-56]
   1a058:	b40006c0 	cbz	x0, 1a130 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K213+0x1b4>
   1a05c:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   1a060:	f94096b0 	ldr	x16, [x21, #296]
   1a064:	f90016a8 	str	x8, [x21, #40]
   1a068:	d1008208 	sub	x8, x16, #0x20
   1a06c:	f90096a8 	str	x8, [x21, #296]
   1a070:	8b000e88 	add	x8, x20, x0, lsl #3
   1a074:	2a0c03ec 	mov	w12, w12
   1a078:	d3607ef0 	lsl	x16, x23, #32
   1a07c:	2a1a03f1 	mov	w17, w26
   1a080:	a905290c 	stp	x12, x10, [x8, #80]
   1a084:	2a0b03ea 	mov	w10, w11
   1a088:	2a0d03eb 	mov	w11, w13
   1a08c:	f900310a 	str	x10, [x8, #96]
   1a090:	f85e83aa 	ldur	x10, [x29, #-24]
   1a094:	f9007910 	str	x16, [x8, #240]
   1a098:	2a1903f0 	mov	w16, w25
   1a09c:	f900350a 	str	x10, [x8, #104]
   1a0a0:	2a0903ea 	mov	w10, w9
   1a0a4:	a907290b 	stp	x11, x10, [x8, #112]
   1a0a8:	a97da7aa 	ldp	x10, x9, [x29, #-40]
   1a0ac:	a9004510 	stp	x16, x17, [x8]
   1a0b0:	2a1303f0 	mov	w16, w19
   1a0b4:	a901711b 	stp	x27, x28, [x8, #16]
   1a0b8:	2a0903e9 	mov	w9, w9
   1a0bc:	2a0a03ea 	mov	w10, w10
   1a0c0:	a9021d01 	stp	x1, x7, [x8, #32]
   1a0c4:	a9082909 	stp	x9, x10, [x8, #128]
   1a0c8:	f9401fea 	ldr	x10, [sp, #56]
   1a0cc:	2a1603e9 	mov	w9, w22
   1a0d0:	a9031103 	stp	x3, x4, [x8, #48]
   1a0d4:	2a0a03ea 	mov	w10, w10
   1a0d8:	a9041910 	stp	x16, x6, [x8, #64]
   1a0dc:	a9092909 	stp	x9, x10, [x8, #144]
   1a0e0:	f94023e9 	ldr	x9, [sp, #64]
   1a0e4:	f85c83aa 	ldur	x10, [x29, #-56]
   1a0e8:	a90cbd05 	stp	x5, x15, [x8, #200]
   1a0ec:	2a0903e9 	mov	w9, w9
   1a0f0:	2a0a03ea 	mov	w10, w10
   1a0f4:	a90a2909 	stp	x9, x10, [x8, #160]
   1a0f8:	2a1e03e9 	mov	w9, w30
   1a0fc:	f9005909 	str	x9, [x8, #176]
   1a100:	f85d03a9 	ldur	x9, [x29, #-48]
   1a104:	a90bb909 	stp	x9, x14, [x8, #184]
   1a108:	f85f03a9 	ldur	x9, [x29, #-16]
   1a10c:	2a0903e9 	mov	w9, w9
   1a110:	a90de109 	stp	x9, x24, [x8, #216]
   1a114:	d2c5e009 	mov	x9, #0x2f0000000000        	// #51677046505472
   1a118:	f2e0a009 	movk	x9, #0x500, lsl #48
   1a11c:	aa090000 	orr	x0, x0, x9
   1a120:	f9007512 	str	x18, [x8, #232]
   1a124:	a9487bfd 	ldp	x29, x30, [sp, #128]
   1a128:	910243ff 	add	sp, sp, #0x90
   1a12c:	d65f03c0 	ret
   1a130:	aa1403e0 	mov	x0, x20
   1a134:	a9001fe1 	stp	x1, x7, [sp]
   1a138:	aa1503e1 	mov	x1, x21
   1a13c:	528000a2 	mov	w2, #0x5                   	// #5
   1a140:	a902bfea 	stp	x10, x15, [sp, #40]
   1a144:	aa0503ea 	mov	x10, x5
   1a148:	a901fbe6 	stp	x6, x30, [sp, #24]
   1a14c:	aa0303ef 	mov	x15, x3
   1a150:	aa1203f5 	mov	x21, x18
   1a154:	f9000be4 	str	x4, [sp, #16]
   1a158:	97ffaa85 	bl	4b6c <heap_alloc_miss>
   1a15c:	a9401fe1 	ldp	x1, x7, [sp]
   1a160:	aa0a03e5 	mov	x5, x10
   1a164:	a9411be4 	ldp	x4, x6, [sp, #16]
   1a168:	aa0f03e3 	mov	x3, x15
   1a16c:	a9422bfe 	ldp	x30, x10, [sp, #32]
   1a170:	aa1503f2 	mov	x18, x21
   1a174:	f9401bef 	ldr	x15, [sp, #48]
   1a178:	17ffffbe 	b	1a070 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K213+0xf4>

