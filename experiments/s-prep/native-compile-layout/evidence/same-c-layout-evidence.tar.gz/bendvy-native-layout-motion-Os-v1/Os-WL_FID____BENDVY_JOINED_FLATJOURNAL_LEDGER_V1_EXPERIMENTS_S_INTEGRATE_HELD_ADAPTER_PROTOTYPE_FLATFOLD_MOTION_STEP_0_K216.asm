   1a5fc:	d103c3ff 	sub	sp, sp, #0xf0
   1a600:	a90e7bfd 	stp	x29, x30, [sp, #224]
   1a604:	910383fd 	add	x29, sp, #0xe0
   1a608:	a941fbb3 	ldp	x19, x30, [x29, #24]
   1a60c:	f81f03ac 	stur	x12, [x29, #-16]
   1a610:	a944cbb0 	ldp	x16, x18, [x29, #72]
   1a614:	a9438ba8 	ldp	x8, x2, [x29, #56]
   1a618:	a93e2bb3 	stp	x19, x10, [x29, #-32]
   1a61c:	f9400bb3 	ldr	x19, [x29, #16]
   1a620:	a942c7b8 	ldp	x24, x17, [x29, #40]
   1a624:	f81d83b3 	stur	x19, [x29, #-40]
   1a628:	b85f82d3 	ldur	w19, [x22, #-8]
   1a62c:	34000437 	cbz	w23, 1a6b0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K216+0xb4>
   1a630:	aa1c03ea 	mov	x10, x28
   1a634:	aa0803fc 	mov	x28, x8
   1a638:	52800808 	mov	w8, #0x40                  	// #64
   1a63c:	a93fa2d3 	stp	x19, x8, [x22, #-8]
   1a640:	2a1103e8 	mov	w8, w17
   1a644:	2a1903ec 	mov	w12, w25
   1a648:	a904cbb0 	stp	x16, x18, [x29, #72]
   1a64c:	2a1803f0 	mov	w16, w24
   1a650:	aa0c03f9 	mov	x25, x12
   1a654:	a902a3b0 	stp	x16, x8, [x29, #40]
   1a658:	f85e03b0 	ldur	x16, [x29, #-32]
   1a65c:	2a1e03e8 	mov	w8, w30
   1a660:	a9038bbc 	stp	x28, x2, [x29, #56]
   1a664:	aa0a03fc 	mov	x28, x10
   1a668:	2a1a03fa 	mov	w26, w26
   1a66c:	2a1003f0 	mov	w16, w16
   1a670:	a97eb3aa 	ldp	x10, x12, [x29, #-24]
   1a674:	a901a3b0 	stp	x16, x8, [x29, #24]
   1a678:	f85d83a8 	ldur	x8, [x29, #-40]
   1a67c:	2a0503e5 	mov	w5, w5
   1a680:	2a0703e7 	mov	w7, w7
   1a684:	2a0b03eb 	mov	w11, w11
   1a688:	2a0d03ed 	mov	w13, w13
   1a68c:	2a0803e8 	mov	w8, w8
   1a690:	2a0e03ee 	mov	w14, w14
   1a694:	2a0903e9 	mov	w9, w9
   1a698:	2a0f03ef 	mov	w15, w15
   1a69c:	910022d6 	add	x22, x22, #0x8
   1a6a0:	f9000ba8 	str	x8, [x29, #16]
   1a6a4:	a94e7bfd 	ldp	x29, x30, [sp, #224]
   1a6a8:	9103c3ff 	add	sp, sp, #0xf0
   1a6ac:	17fff006 	b	166c4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0>
   1a6b0:	f81a03b4 	stur	x20, [x29, #-96]
   1a6b4:	f94016b7 	ldr	x23, [x21, #40]
   1a6b8:	a9009fe5 	stp	x5, x7, [sp, #8]
   1a6bc:	f81a83bb 	stur	x27, [x29, #-88]
   1a6c0:	f9000feb 	str	x11, [sp, #24]
   1a6c4:	f81b03bc 	stur	x28, [x29, #-80]
   1a6c8:	a90207e0 	stp	x0, x1, [sp, #32]
   1a6cc:	a9030fed 	stp	x13, x3, [sp, #48]
   1a6d0:	f81b83be 	stur	x30, [x29, #-72]
   1a6d4:	f90023e4 	str	x4, [sp, #64]
   1a6d8:	f81c03b8 	stur	x24, [x29, #-64]
   1a6dc:	a97e62db 	ldp	x27, x24, [x22, #-32]
   1a6e0:	a904c7ee 	stp	x14, x17, [sp, #72]
   1a6e4:	a905c3e6 	stp	x6, x16, [sp, #88]
   1a6e8:	f9003be9 	str	x9, [sp, #112]
   1a6ec:	f81983b2 	stur	x18, [x29, #-104]
   1a6f0:	a93cbfa8 	stp	x8, x15, [x29, #-56]
   1a6f4:	f90037e2 	str	x2, [sp, #104]
   1a6f8:	b4000ab7 	cbz	x23, 1a84c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K216+0x250>
   1a6fc:	f85a03b4 	ldur	x20, [x29, #-96]
   1a700:	f94096a9 	ldr	x9, [x21, #296]
   1a704:	f8777a88 	ldr	x8, [x20, x23, lsl #3]
   1a708:	f90016a8 	str	x8, [x21, #40]
   1a70c:	d1008128 	sub	x8, x9, #0x20
   1a710:	f90096a8 	str	x8, [x21, #296]
   1a714:	8b170e9c 	add	x28, x20, x23, lsl #3
   1a718:	52801fe1 	mov	w1, #0xff                  	// #255
   1a71c:	52801c02 	mov	w2, #0xe0                  	// #224
   1a720:	91002380 	add	x0, x28, #0x8
   1a724:	97ffa4f3 	bl	3af0 <memset@plt>
   1a728:	52800028 	mov	w8, #0x1                   	// #1
   1a72c:	d2c80009 	mov	x9, #0x400000000000        	// #70368744177664
   1a730:	f9000393 	str	x19, [x28]
   1a734:	aa18810a 	orr	x10, x8, x24, lsl #32
   1a738:	f2e0a009 	movk	x9, #0x500, lsl #48
   1a73c:	aa0902e9 	orr	x9, x23, x9
   1a740:	a90eab9b 	stp	x27, x10, [x28, #232]
   1a744:	a93e22c9 	stp	x9, x8, [x22, #-32]
   1a748:	f94016a0 	ldr	x0, [x21, #40]
   1a74c:	b40008e0 	cbz	x0, 1a868 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K216+0x26c>
   1a750:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   1a754:	f94096aa 	ldr	x10, [x21, #296]
   1a758:	f90016a8 	str	x8, [x21, #40]
   1a75c:	d1008148 	sub	x8, x10, #0x20
   1a760:	f90096a8 	str	x8, [x21, #296]
   1a764:	8b000e88 	add	x8, x20, x0, lsl #3
   1a768:	d2c0002a 	mov	x10, #0x100000000           	// #4294967296
   1a76c:	2a1a03eb 	mov	w11, w26
   1a770:	f85f03ac 	ldur	x12, [x29, #-16]
   1a774:	a97cb7ae 	ldp	x14, x13, [x29, #-56]
   1a778:	f900710a 	str	x10, [x8, #224]
   1a77c:	2a1903ea 	mov	w10, w25
   1a780:	f85e03b1 	ldur	x17, [x29, #-32]
   1a784:	a9002d0a 	stp	x10, x11, [x8]
   1a788:	a9422beb 	ldp	x11, x10, [sp, #32]
   1a78c:	a97bbfb0 	ldp	x16, x15, [x29, #-72]
   1a790:	f9006d09 	str	x9, [x8, #216]
   1a794:	a97acbb3 	ldp	x19, x18, [x29, #-88]
   1a798:	f85983a9 	ldur	x9, [x29, #-104]
   1a79c:	a902290b 	stp	x11, x10, [x8, #32]
   1a7a0:	a943abeb 	ldp	x11, x10, [sp, #56]
   1a7a4:	a9014913 	stp	x19, x18, [x8, #16]
   1a7a8:	a903290b 	stp	x11, x10, [x8, #48]
   1a7ac:	f94007ea 	ldr	x10, [sp, #8]
   1a7b0:	f9402feb 	ldr	x11, [sp, #88]
   1a7b4:	2a0a03ea 	mov	w10, w10
   1a7b8:	f900210a 	str	x10, [x8, #64]
   1a7bc:	f9400bea 	ldr	x10, [sp, #16]
   1a7c0:	2a0a03ea 	mov	w10, w10
   1a7c4:	a904a90b 	stp	x11, x10, [x8, #72]
   1a7c8:	f9400fea 	ldr	x10, [sp, #24]
   1a7cc:	f85e83ab 	ldur	x11, [x29, #-24]
   1a7d0:	2a0a03ea 	mov	w10, w10
   1a7d4:	a905a90b 	stp	x11, x10, [x8, #88]
   1a7d8:	f9401bea 	ldr	x10, [sp, #48]
   1a7dc:	f94027eb 	ldr	x11, [sp, #72]
   1a7e0:	2a0a03ea 	mov	w10, w10
   1a7e4:	2a0b03eb 	mov	w11, w11
   1a7e8:	a906a90c 	stp	x12, x10, [x8, #104]
   1a7ec:	f9403bea 	ldr	x10, [sp, #112]
   1a7f0:	f9003d0b 	str	x11, [x8, #120]
   1a7f4:	2a0d03eb 	mov	w11, w13
   1a7f8:	2a0a03ea 	mov	w10, w10
   1a7fc:	a9082d0a 	stp	x10, x11, [x8, #128]
   1a800:	f85d83aa 	ldur	x10, [x29, #-40]
   1a804:	2a1103eb 	mov	w11, w17
   1a808:	2a0a03ea 	mov	w10, w10
   1a80c:	a9092d0a 	stp	x10, x11, [x8, #144]
   1a810:	2a1003ea 	mov	w10, w16
   1a814:	2a0f03eb 	mov	w11, w15
   1a818:	a90a2d0a 	stp	x10, x11, [x8, #160]
   1a81c:	f9402bea 	ldr	x10, [sp, #80]
   1a820:	2a0a03ea 	mov	w10, w10
   1a824:	a90b390a 	stp	x10, x14, [x8, #176]
   1a828:	a9462fea 	ldp	x10, x11, [sp, #96]
   1a82c:	a90c290b 	stp	x11, x10, [x8, #192]
   1a830:	d2c5400a 	mov	x10, #0x2a0000000000        	// #46179488366592
   1a834:	f2e0a00a 	movk	x10, #0x500, lsl #48
   1a838:	aa0a0000 	orr	x0, x0, x10
   1a83c:	f9006909 	str	x9, [x8, #208]
   1a840:	a94e7bfd 	ldp	x29, x30, [sp, #224]
   1a844:	9103c3ff 	add	sp, sp, #0xf0
   1a848:	d65f03c0 	ret
   1a84c:	f85a03b4 	ldur	x20, [x29, #-96]
   1a850:	aa1503e1 	mov	x1, x21
   1a854:	528000a2 	mov	w2, #0x5                   	// #5
   1a858:	aa1403e0 	mov	x0, x20
   1a85c:	97ffa8c4 	bl	4b6c <heap_alloc_miss>
   1a860:	aa0003f7 	mov	x23, x0
   1a864:	17ffffac 	b	1a714 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K216+0x118>
   1a868:	aa1403e0 	mov	x0, x20
   1a86c:	aa1503e1 	mov	x1, x21
   1a870:	528000a2 	mov	w2, #0x5                   	// #5
   1a874:	97ffa8be 	bl	4b6c <heap_alloc_miss>
   1a878:	17ffffbb 	b	1a764 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K216+0x168>

