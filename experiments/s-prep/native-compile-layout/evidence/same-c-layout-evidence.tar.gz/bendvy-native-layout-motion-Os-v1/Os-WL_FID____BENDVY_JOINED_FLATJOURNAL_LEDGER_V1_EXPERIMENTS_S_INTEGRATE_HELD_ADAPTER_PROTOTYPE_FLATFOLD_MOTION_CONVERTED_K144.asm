   1616c:	d100c3ff 	sub	sp, sp, #0x30
   16170:	a9027bfd 	stp	x29, x30, [sp, #32]
   16174:	b94033e8 	ldr	w8, [sp, #48]
   16178:	f9000fec 	str	x12, [sp, #24]
   1617c:	aa0a03ec 	mov	x12, x10
   16180:	a946f7ea 	ldp	x10, x29, [sp, #104]
   16184:	90000cd8 	adrp	x24, 1ae000 <io_eff_rows+0xff0d0>
   16188:	913f2318 	add	x24, x24, #0xfc8
   1618c:	f9000be8 	str	x8, [sp, #16]
   16190:	b94053f0 	ldr	w16, [sp, #80]
   16194:	b85f0ec2 	ldr	w2, [x22, #-16]!
   16198:	b9404bf1 	ldr	w17, [sp, #72]
   1619c:	a945fbe8 	ldp	x8, x30, [sp, #88]
   161a0:	2a1903f9 	mov	w25, w25
   161a4:	f8627b02 	ldr	x2, [x24, x2, lsl #3]
   161a8:	b9400ad8 	ldr	w24, [x22, #8]
   161ac:	2a1a03fa 	mov	w26, w26
   161b0:	f90037ea 	str	x10, [sp, #104]
   161b4:	aa0c03ea 	mov	x10, x12
   161b8:	b94043f2 	ldr	w18, [sp, #64]
   161bc:	a905fbe8 	stp	x8, x30, [sp, #88]
   161c0:	a94133e8 	ldp	x8, x12, [sp, #16]
   161c4:	b9403bf3 	ldr	w19, [sp, #56]
   161c8:	2a0503e5 	mov	w5, w5
   161cc:	2a0703e7 	mov	w7, w7
   161d0:	a90763fd 	stp	x29, x24, [sp, #112]
   161d4:	a9427bfd 	ldp	x29, x30, [sp, #32]
   161d8:	a903cbf3 	stp	x19, x18, [sp, #56]
   161dc:	2a0b03eb 	mov	w11, w11
   161e0:	2a0d03ed 	mov	w13, w13
   161e4:	a904c3f1 	stp	x17, x16, [sp, #72]
   161e8:	2a0e03ee 	mov	w14, w14
   161ec:	2a0903e9 	mov	w9, w9
   161f0:	2a0f03ef 	mov	w15, w15
   161f4:	52800398 	mov	w24, #0x1c                  	// #28
   161f8:	f9001be8 	str	x8, [sp, #48]
   161fc:	9100c3ff 	add	sp, sp, #0x30
   16200:	d61f0040 	br	x2

