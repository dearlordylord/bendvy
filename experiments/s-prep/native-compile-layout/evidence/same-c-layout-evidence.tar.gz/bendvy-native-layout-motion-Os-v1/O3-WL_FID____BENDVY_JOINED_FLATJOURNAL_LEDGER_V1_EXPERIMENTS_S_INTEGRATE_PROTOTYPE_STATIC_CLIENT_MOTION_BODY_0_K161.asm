   184d4:	d100c3ff 	sub	sp, sp, #0x30
   184d8:	a9027bfd 	stp	x29, x30, [sp, #32]
   184dc:	b94033e8 	ldr	w8, [sp, #48]
   184e0:	a90133e8 	stp	x8, x12, [sp, #16]
   184e4:	aa0a03ec 	mov	x12, x10
   184e8:	a946f7ea 	ldp	x10, x29, [sp, #104]
   184ec:	d0000cb8 	adrp	x24, 1ae000 <io_eff_rows+0xff118>
   184f0:	913f2318 	add	x24, x24, #0xfc8
   184f4:	b94053f0 	ldr	w16, [sp, #80]
   184f8:	b85f0ec2 	ldr	w2, [x22, #-16]!
   184fc:	b9404bf1 	ldr	w17, [sp, #72]
   18500:	a945fbe8 	ldp	x8, x30, [sp, #88]
   18504:	2a1903f9 	mov	w25, w25
   18508:	f8627b02 	ldr	x2, [x24, x2, lsl #3]
   1850c:	b9400ad8 	ldr	w24, [x22, #8]
   18510:	2a1a03fa 	mov	w26, w26
   18514:	f90037ea 	str	x10, [sp, #104]
   18518:	aa0c03ea 	mov	x10, x12
   1851c:	b94043f2 	ldr	w18, [sp, #64]
   18520:	a905fbe8 	stp	x8, x30, [sp, #88]
   18524:	a94133e8 	ldp	x8, x12, [sp, #16]
   18528:	b9403bf3 	ldr	w19, [sp, #56]
   1852c:	2a0503e5 	mov	w5, w5
   18530:	2a0703e7 	mov	w7, w7
   18534:	a90763fd 	stp	x29, x24, [sp, #112]
   18538:	a9427bfd 	ldp	x29, x30, [sp, #32]
   1853c:	a903cbf3 	stp	x19, x18, [sp, #56]
   18540:	2a0b03eb 	mov	w11, w11
   18544:	2a0d03ed 	mov	w13, w13
   18548:	a904c3f1 	stp	x17, x16, [sp, #72]
   1854c:	2a0e03ee 	mov	w14, w14
   18550:	2a0903e9 	mov	w9, w9
   18554:	2a0f03ef 	mov	w15, w15
   18558:	52800398 	mov	w24, #0x1c                  	// #28
   1855c:	f8030fe8 	str	x8, [sp, #48]!
   18560:	d61f0040 	br	x2

