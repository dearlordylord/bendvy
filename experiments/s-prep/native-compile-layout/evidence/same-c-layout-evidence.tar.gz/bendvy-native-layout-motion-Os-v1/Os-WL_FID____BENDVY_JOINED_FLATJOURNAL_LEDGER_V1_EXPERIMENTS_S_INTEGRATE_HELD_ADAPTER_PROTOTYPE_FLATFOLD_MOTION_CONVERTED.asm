   15efc:	d10383ff 	sub	sp, sp, #0xe0
   15f00:	a90d7bfd 	stp	x29, x30, [sp, #208]
   15f04:	910343fd 	add	x29, sp, #0xd0
   15f08:	a94263a2 	ldp	x2, x24, [x29, #32]
   15f0c:	f81f03ac 	stur	x12, [x29, #-16]
   15f10:	a9454fbe 	ldp	x30, x19, [x29, #80]
   15f14:	a94447b0 	ldp	x16, x17, [x29, #64]
   15f18:	a93e2ba2 	stp	x2, x10, [x29, #-32]
   15f1c:	f9400fa2 	ldr	x2, [x29, #24]
   15f20:	a94323b2 	ldp	x18, x8, [x29, #48]
   15f24:	f81d83a2 	stur	x2, [x29, #-40]
   15f28:	f9400ba2 	ldr	x2, [x29, #16]
   15f2c:	34000437 	cbz	w23, 15fb0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_CONVERTED+0xb4>
   15f30:	aa1b03ea 	mov	x10, x27
   15f34:	aa0803fb 	mov	x27, x8
   15f38:	2a1303e8 	mov	w8, w19
   15f3c:	aa0b03f3 	mov	x19, x11
   15f40:	528004cb 	mov	w11, #0x26                  	// #38
   15f44:	2a1903ec 	mov	w12, w25
   15f48:	a8812ec8 	stp	x8, x11, [x22], #16
   15f4c:	2a1203e8 	mov	w8, w18
   15f50:	a903c3bb 	stp	x27, x16, [x29, #56]
   15f54:	2a1803f0 	mov	w16, w24
   15f58:	aa0c03f9 	mov	x25, x12
   15f5c:	a902a3b0 	stp	x16, x8, [x29, #40]
   15f60:	a97da3b0 	ldp	x16, x8, [x29, #-40]
   15f64:	aa0a03fb 	mov	x27, x10
   15f68:	a97eb3aa 	ldp	x10, x12, [x29, #-24]
   15f6c:	a904fbb1 	stp	x17, x30, [x29, #72]
   15f70:	2a1a03fa 	mov	w26, w26
   15f74:	2a0503e5 	mov	w5, w5
   15f78:	2a0803e8 	mov	w8, w8
   15f7c:	2a1003f0 	mov	w16, w16
   15f80:	2a0703e7 	mov	w7, w7
   15f84:	a901a3b0 	stp	x16, x8, [x29, #24]
   15f88:	2a0203e8 	mov	w8, w2
   15f8c:	2a1303eb 	mov	w11, w19
   15f90:	2a0d03ed 	mov	w13, w13
   15f94:	2a0e03ee 	mov	w14, w14
   15f98:	2a0903e9 	mov	w9, w9
   15f9c:	2a0f03ef 	mov	w15, w15
   15fa0:	f9000ba8 	str	x8, [x29, #16]
   15fa4:	a94d7bfd 	ldp	x29, x30, [sp, #208]
   15fa8:	910383ff 	add	sp, sp, #0xe0
   15fac:	14001fb8 	b	1de8c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_TRANSACTION_PROTOTYPE_FLAT_PACK_0>
   15fb0:	a9001fe5 	stp	x5, x7, [sp]
   15fb4:	f94016b7 	ldr	x23, [x21, #40]
   15fb8:	a93af3bb 	stp	x27, x28, [x29, #-88]
   15fbc:	a90183e2 	stp	x2, x0, [sp, #24]
   15fc0:	a902b7e1 	stp	x1, x13, [sp, #40]
   15fc4:	a90393e3 	stp	x3, x4, [sp, #56]
   15fc8:	a93bbbb8 	stp	x24, x14, [x29, #-72]
   15fcc:	a97ee2db 	ldp	x27, x24, [x22, #-24]
   15fd0:	a904c7f2 	stp	x18, x17, [sp, #72]
   15fd4:	a9059bf0 	stp	x16, x6, [sp, #88]
   15fd8:	f81a03a9 	stur	x9, [x29, #-96]
   15fdc:	f81d03af 	stur	x15, [x29, #-48]
   15fe0:	f90037fe 	str	x30, [sp, #104]
   15fe4:	f81c83a8 	stur	x8, [x29, #-56]
   15fe8:	f9000beb 	str	x11, [sp, #16]
   15fec:	b4000ab7 	cbz	x23, 16140 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_CONVERTED+0x244>
   15ff0:	f8777a88 	ldr	x8, [x20, x23, lsl #3]
   15ff4:	f94096a9 	ldr	x9, [x21, #296]
   15ff8:	f90016a8 	str	x8, [x21, #40]
   15ffc:	d1008128 	sub	x8, x9, #0x20
   16000:	f90096a8 	str	x8, [x21, #296]
   16004:	8b170e9c 	add	x28, x20, x23, lsl #3
   16008:	52801fe1 	mov	w1, #0xff                  	// #255
   1600c:	52801b02 	mov	w2, #0xd8                  	// #216
   16010:	91002380 	add	x0, x28, #0x8
   16014:	97ffb6b7 	bl	3af0 <memset@plt>
   16018:	2a1303e9 	mov	w9, w19
   1601c:	52800028 	mov	w8, #0x1                   	// #1
   16020:	f9000389 	str	x9, [x28]
   16024:	d2c4c009 	mov	x9, #0x260000000000        	// #41781441855488
   16028:	aa18810a 	orr	x10, x8, x24, lsl #32
   1602c:	f2e0a009 	movk	x9, #0x500, lsl #48
   16030:	aa0902e9 	orr	x9, x23, x9
   16034:	a90e2b9b 	stp	x27, x10, [x28, #224]
   16038:	a93ea2c9 	stp	x9, x8, [x22, #-24]
   1603c:	f94016a0 	ldr	x0, [x21, #40]
   16040:	b40008c0 	cbz	x0, 16158 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_CONVERTED+0x25c>
   16044:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   16048:	f94096aa 	ldr	x10, [x21, #296]
   1604c:	f90016a8 	str	x8, [x21, #40]
   16050:	d1008148 	sub	x8, x10, #0x20
   16054:	f90096a8 	str	x8, [x21, #296]
   16058:	8b000e88 	add	x8, x20, x0, lsl #3
   1605c:	d2c0002a 	mov	x10, #0x100000000           	// #4294967296
   16060:	2a1a03eb 	mov	w11, w26
   16064:	f85f03ac 	ldur	x12, [x29, #-16]
   16068:	a97bbfb0 	ldp	x16, x15, [x29, #-72]
   1606c:	f900710a 	str	x10, [x8, #224]
   16070:	2a1903ea 	mov	w10, w25
   16074:	f85e03b1 	ldur	x17, [x29, #-32]
   16078:	a9002d0a 	stp	x10, x11, [x8]
   1607c:	a9422beb 	ldp	x11, x10, [sp, #32]
   16080:	a97cb7ae 	ldp	x14, x13, [x29, #-56]
   16084:	f9006d09 	str	x9, [x8, #216]
   16088:	a97acbb3 	ldp	x19, x18, [x29, #-88]
   1608c:	f94037e9 	ldr	x9, [sp, #104]
   16090:	a902290b 	stp	x11, x10, [x8, #32]
   16094:	a943abeb 	ldp	x11, x10, [sp, #56]
   16098:	a9014913 	stp	x19, x18, [x8, #16]
   1609c:	a903290b 	stp	x11, x10, [x8, #48]
   160a0:	f94003ea 	ldr	x10, [sp]
   160a4:	f94033eb 	ldr	x11, [sp, #96]
   160a8:	2a0a03ea 	mov	w10, w10
   160ac:	f900210a 	str	x10, [x8, #64]
   160b0:	f94007ea 	ldr	x10, [sp, #8]
   160b4:	2a0a03ea 	mov	w10, w10
   160b8:	a904a90b 	stp	x11, x10, [x8, #72]
   160bc:	f9400bea 	ldr	x10, [sp, #16]
   160c0:	f85e83ab 	ldur	x11, [x29, #-24]
   160c4:	2a0a03ea 	mov	w10, w10
   160c8:	a905a90b 	stp	x11, x10, [x8, #88]
   160cc:	f9401bea 	ldr	x10, [sp, #48]
   160d0:	2a0f03eb 	mov	w11, w15
   160d4:	f9003d0b 	str	x11, [x8, #120]
   160d8:	2a0d03eb 	mov	w11, w13
   160dc:	2a0a03ea 	mov	w10, w10
   160e0:	a906a90c 	stp	x12, x10, [x8, #104]
   160e4:	f85a03aa 	ldur	x10, [x29, #-96]
   160e8:	2a0a03ea 	mov	w10, w10
   160ec:	a9082d0a 	stp	x10, x11, [x8, #128]
   160f0:	f9400fea 	ldr	x10, [sp, #24]
   160f4:	f85d83ab 	ldur	x11, [x29, #-40]
   160f8:	2a0a03ea 	mov	w10, w10
   160fc:	2a0b03eb 	mov	w11, w11
   16100:	a9092d0a 	stp	x10, x11, [x8, #144]
   16104:	2a1103ea 	mov	w10, w17
   16108:	2a1003eb 	mov	w11, w16
   1610c:	a90a2d0a 	stp	x10, x11, [x8, #160]
   16110:	f94027ea 	ldr	x10, [sp, #72]
   16114:	2a0a03ea 	mov	w10, w10
   16118:	a90b390a 	stp	x10, x14, [x8, #176]
   1611c:	a9452fea 	ldp	x10, x11, [sp, #80]
   16120:	a90c290b 	stp	x11, x10, [x8, #192]
   16124:	d2ca800a 	mov	x10, #0x540000000000        	// #92358976733184
   16128:	f2e0a00a 	movk	x10, #0x500, lsl #48
   1612c:	aa0a0000 	orr	x0, x0, x10
   16130:	f9006909 	str	x9, [x8, #208]
   16134:	a94d7bfd 	ldp	x29, x30, [sp, #208]
   16138:	910383ff 	add	sp, sp, #0xe0
   1613c:	d65f03c0 	ret
   16140:	aa1403e0 	mov	x0, x20
   16144:	aa1503e1 	mov	x1, x21
   16148:	528000a2 	mov	w2, #0x5                   	// #5
   1614c:	97ffba88 	bl	4b6c <heap_alloc_miss>
   16150:	aa0003f7 	mov	x23, x0
   16154:	17ffffac 	b	16004 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_CONVERTED+0x108>
   16158:	aa1403e0 	mov	x0, x20
   1615c:	aa1503e1 	mov	x1, x21
   16160:	528000a2 	mov	w2, #0x5                   	// #5
   16164:	97ffba82 	bl	4b6c <heap_alloc_miss>
   16168:	17ffffbc 	b	16058 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_CONVERTED+0x15c>

