   1a3fc:	d10243ff 	sub	sp, sp, #0x90
   1a400:	a9087bfd 	stp	x29, x30, [sp, #128]
   1a404:	910203fd 	add	x29, sp, #0x80
   1a408:	a93da7af 	stp	x15, x9, [x29, #-40]
   1a40c:	aa0e03e9 	mov	x9, x14
   1a410:	aa0503f3 	mov	x19, x5
   1a414:	a9453baf 	ldp	x15, x14, [x29, #80]
   1a418:	aa1603e8 	mov	x8, x22
   1a41c:	a94343be 	ldp	x30, x16, [x29, #48]
   1a420:	f81e83ac 	stur	x12, [x29, #-24]
   1a424:	a9414ba2 	ldp	x2, x18, [x29, #16]
   1a428:	aa0703ec 	mov	x12, x7
   1a42c:	f81f03ae 	stur	x14, [x29, #-16]
   1a430:	a94417ae 	ldp	x14, x5, [x29, #64]
   1a434:	f81d03b0 	stur	x16, [x29, #-48]
   1a438:	aa0103e7 	mov	x7, x1
   1a43c:	aa0003e1 	mov	x1, x0
   1a440:	a94243b1 	ldp	x17, x16, [x29, #32]
   1a444:	b85f8ed8 	ldr	w24, [x22, #-8]!
   1a448:	340003f7 	cbz	w23, 1a4c4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K215+0xc8>
   1a44c:	f85f03a8 	ldur	x8, [x29, #-16]
   1a450:	aa0103e0 	mov	x0, x1
   1a454:	aa0703e1 	mov	x1, x7
   1a458:	2a0c03e7 	mov	w7, w12
   1a45c:	f85d03ac 	ldur	x12, [x29, #-48]
   1a460:	a904bfa5 	stp	x5, x15, [x29, #72]
   1a464:	2a0803e8 	mov	w8, w8
   1a468:	2a1903f9 	mov	w25, w25
   1a46c:	2a1a03fa 	mov	w26, w26
   1a470:	a903bbac 	stp	x12, x14, [x29, #56]
   1a474:	2a1e03ec 	mov	w12, w30
   1a478:	2a0903ee 	mov	w14, w9
   1a47c:	a905e3a8 	stp	x8, x24, [x29, #88]
   1a480:	2a1003e8 	mov	w8, w16
   1a484:	2a0203f0 	mov	w16, w2
   1a488:	a902b3a8 	stp	x8, x12, [x29, #40]
   1a48c:	a97da7a8 	ldp	x8, x9, [x29, #-40]
   1a490:	2a1103ec 	mov	w12, w17
   1a494:	2a1303e5 	mov	w5, w19
   1a498:	2a0b03eb 	mov	w11, w11
   1a49c:	2a0d03ed 	mov	w13, w13
   1a4a0:	2a0803ef 	mov	w15, w8
   1a4a4:	2a1203e8 	mov	w8, w18
   1a4a8:	2a0903e9 	mov	w9, w9
   1a4ac:	a901b3a8 	stp	x8, x12, [x29, #24]
   1a4b0:	f85e83ac 	ldur	x12, [x29, #-24]
   1a4b4:	f9000bb0 	str	x16, [x29, #16]
   1a4b8:	a9487bfd 	ldp	x29, x30, [sp, #128]
   1a4bc:	910243ff 	add	sp, sp, #0x90
   1a4c0:	17fff3ac 	b	17370 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_FALLBACK>
   1a4c4:	a903c7f2 	stp	x18, x17, [sp, #56]
   1a4c8:	a97e5d12 	ldp	x18, x23, [x8, #-32]
   1a4cc:	f94016a0 	ldr	x0, [x21, #40]
   1a4d0:	aa0203f6 	mov	x22, x2
   1a4d4:	f81c83b0 	stur	x16, [x29, #-56]
   1a4d8:	b40006c0 	cbz	x0, 1a5b0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K215+0x1b4>
   1a4dc:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   1a4e0:	f94096b0 	ldr	x16, [x21, #296]
   1a4e4:	f90016a8 	str	x8, [x21, #40]
   1a4e8:	d1008208 	sub	x8, x16, #0x20
   1a4ec:	f90096a8 	str	x8, [x21, #296]
   1a4f0:	8b000e88 	add	x8, x20, x0, lsl #3
   1a4f4:	2a0c03ec 	mov	w12, w12
   1a4f8:	d3607ef0 	lsl	x16, x23, #32
   1a4fc:	2a1a03f1 	mov	w17, w26
   1a500:	a905290c 	stp	x12, x10, [x8, #80]
   1a504:	2a0b03ea 	mov	w10, w11
   1a508:	2a0d03eb 	mov	w11, w13
   1a50c:	f900310a 	str	x10, [x8, #96]
   1a510:	f85e83aa 	ldur	x10, [x29, #-24]
   1a514:	f9007910 	str	x16, [x8, #240]
   1a518:	2a1903f0 	mov	w16, w25
   1a51c:	f900350a 	str	x10, [x8, #104]
   1a520:	2a0903ea 	mov	w10, w9
   1a524:	a907290b 	stp	x11, x10, [x8, #112]
   1a528:	a97da7aa 	ldp	x10, x9, [x29, #-40]
   1a52c:	a9004510 	stp	x16, x17, [x8]
   1a530:	2a1303f0 	mov	w16, w19
   1a534:	a901711b 	stp	x27, x28, [x8, #16]
   1a538:	2a0903e9 	mov	w9, w9
   1a53c:	2a0a03ea 	mov	w10, w10
   1a540:	a9021d01 	stp	x1, x7, [x8, #32]
   1a544:	a9082909 	stp	x9, x10, [x8, #128]
   1a548:	f9401fea 	ldr	x10, [sp, #56]
   1a54c:	2a1603e9 	mov	w9, w22
   1a550:	a9031103 	stp	x3, x4, [x8, #48]
   1a554:	2a0a03ea 	mov	w10, w10
   1a558:	a9041910 	stp	x16, x6, [x8, #64]
   1a55c:	a9092909 	stp	x9, x10, [x8, #144]
   1a560:	f94023e9 	ldr	x9, [sp, #64]
   1a564:	f85c83aa 	ldur	x10, [x29, #-56]
   1a568:	a90cbd05 	stp	x5, x15, [x8, #200]
   1a56c:	2a0903e9 	mov	w9, w9
   1a570:	2a0a03ea 	mov	w10, w10
   1a574:	a90a2909 	stp	x9, x10, [x8, #160]
   1a578:	2a1e03e9 	mov	w9, w30
   1a57c:	f9005909 	str	x9, [x8, #176]
   1a580:	f85d03a9 	ldur	x9, [x29, #-48]
   1a584:	a90bb909 	stp	x9, x14, [x8, #184]
   1a588:	f85f03a9 	ldur	x9, [x29, #-16]
   1a58c:	2a0903e9 	mov	w9, w9
   1a590:	a90de109 	stp	x9, x24, [x8, #216]
   1a594:	d2c5e009 	mov	x9, #0x2f0000000000        	// #51677046505472
   1a598:	f2e0a009 	movk	x9, #0x500, lsl #48
   1a59c:	aa090000 	orr	x0, x0, x9
   1a5a0:	f9007512 	str	x18, [x8, #232]
   1a5a4:	a9487bfd 	ldp	x29, x30, [sp, #128]
   1a5a8:	910243ff 	add	sp, sp, #0x90
   1a5ac:	d65f03c0 	ret
   1a5b0:	aa1403e0 	mov	x0, x20
   1a5b4:	a9001fe1 	stp	x1, x7, [sp]
   1a5b8:	aa1503e1 	mov	x1, x21
   1a5bc:	528000a2 	mov	w2, #0x5                   	// #5
   1a5c0:	a902bfea 	stp	x10, x15, [sp, #40]
   1a5c4:	aa0503ea 	mov	x10, x5
   1a5c8:	a901fbe6 	stp	x6, x30, [sp, #24]
   1a5cc:	aa0303ef 	mov	x15, x3
   1a5d0:	aa1203f5 	mov	x21, x18
   1a5d4:	f9000be4 	str	x4, [sp, #16]
   1a5d8:	97ffa965 	bl	4b6c <heap_alloc_miss>
   1a5dc:	a9401fe1 	ldp	x1, x7, [sp]
   1a5e0:	aa0a03e5 	mov	x5, x10
   1a5e4:	a9411be4 	ldp	x4, x6, [sp, #16]
   1a5e8:	aa0f03e3 	mov	x3, x15
   1a5ec:	a9422bfe 	ldp	x30, x10, [sp, #32]
   1a5f0:	aa1503f2 	mov	x18, x21
   1a5f4:	f9401bef 	ldr	x15, [sp, #48]
   1a5f8:	17ffffbe 	b	1a4f0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K215+0xf4>

