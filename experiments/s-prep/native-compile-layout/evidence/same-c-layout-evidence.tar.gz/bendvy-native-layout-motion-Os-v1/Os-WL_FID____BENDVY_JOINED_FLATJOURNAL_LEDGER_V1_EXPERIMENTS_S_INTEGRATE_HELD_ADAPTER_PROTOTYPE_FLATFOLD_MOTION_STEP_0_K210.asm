   1987c:	d103c3ff 	sub	sp, sp, #0xf0
   19880:	a90e7bfd 	stp	x29, x30, [sp, #224]
   19884:	910383fd 	add	x29, sp, #0xe0
   19888:	a941fbb3 	ldp	x19, x30, [x29, #24]
   1988c:	f81f03ac 	stur	x12, [x29, #-16]
   19890:	a944cbb0 	ldp	x16, x18, [x29, #72]
   19894:	a9438ba8 	ldp	x8, x2, [x29, #56]
   19898:	a93e2bb3 	stp	x19, x10, [x29, #-32]
   1989c:	f9400bb3 	ldr	x19, [x29, #16]
   198a0:	a942c7b8 	ldp	x24, x17, [x29, #40]
   198a4:	f81d83b3 	stur	x19, [x29, #-40]
   198a8:	b85f82d3 	ldur	w19, [x22, #-8]
   198ac:	34000437 	cbz	w23, 19930 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K210+0xb4>
   198b0:	aa1c03ea 	mov	x10, x28
   198b4:	aa0803fc 	mov	x28, x8
   198b8:	52800748 	mov	w8, #0x3a                  	// #58
   198bc:	a93fa2d3 	stp	x19, x8, [x22, #-8]
   198c0:	2a1103e8 	mov	w8, w17
   198c4:	2a1903ec 	mov	w12, w25
   198c8:	a904cbb0 	stp	x16, x18, [x29, #72]
   198cc:	2a1803f0 	mov	w16, w24
   198d0:	aa0c03f9 	mov	x25, x12
   198d4:	a902a3b0 	stp	x16, x8, [x29, #40]
   198d8:	f85e03b0 	ldur	x16, [x29, #-32]
   198dc:	2a1e03e8 	mov	w8, w30
   198e0:	a9038bbc 	stp	x28, x2, [x29, #56]
   198e4:	aa0a03fc 	mov	x28, x10
   198e8:	2a1a03fa 	mov	w26, w26
   198ec:	2a1003f0 	mov	w16, w16
   198f0:	a97eb3aa 	ldp	x10, x12, [x29, #-24]
   198f4:	a901a3b0 	stp	x16, x8, [x29, #24]
   198f8:	f85d83a8 	ldur	x8, [x29, #-40]
   198fc:	2a0503e5 	mov	w5, w5
   19900:	2a0703e7 	mov	w7, w7
   19904:	2a0b03eb 	mov	w11, w11
   19908:	2a0d03ed 	mov	w13, w13
   1990c:	2a0803e8 	mov	w8, w8
   19910:	2a0e03ee 	mov	w14, w14
   19914:	2a0903e9 	mov	w9, w9
   19918:	2a0f03ef 	mov	w15, w15
   1991c:	910022d6 	add	x22, x22, #0x8
   19920:	f9000ba8 	str	x8, [x29, #16]
   19924:	a94e7bfd 	ldp	x29, x30, [sp, #224]
   19928:	9103c3ff 	add	sp, sp, #0xf0
   1992c:	17fff366 	b	166c4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0>
   19930:	f81a03b4 	stur	x20, [x29, #-96]
   19934:	f94016b7 	ldr	x23, [x21, #40]
   19938:	a9009fe5 	stp	x5, x7, [sp, #8]
   1993c:	f81a83bb 	stur	x27, [x29, #-88]
   19940:	f9000feb 	str	x11, [sp, #24]
   19944:	f81b03bc 	stur	x28, [x29, #-80]
   19948:	a90207e0 	stp	x0, x1, [sp, #32]
   1994c:	a9030fed 	stp	x13, x3, [sp, #48]
   19950:	f81b83be 	stur	x30, [x29, #-72]
   19954:	f90023e4 	str	x4, [sp, #64]
   19958:	f81c03b8 	stur	x24, [x29, #-64]
   1995c:	a97e62db 	ldp	x27, x24, [x22, #-32]
   19960:	a904c7ee 	stp	x14, x17, [sp, #72]
   19964:	a905c3e6 	stp	x6, x16, [sp, #88]
   19968:	f9003be9 	str	x9, [sp, #112]
   1996c:	f81983b2 	stur	x18, [x29, #-104]
   19970:	a93cbfa8 	stp	x8, x15, [x29, #-56]
   19974:	f90037e2 	str	x2, [sp, #104]
   19978:	b4000ab7 	cbz	x23, 19acc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K210+0x250>
   1997c:	f85a03b4 	ldur	x20, [x29, #-96]
   19980:	f94096a9 	ldr	x9, [x21, #296]
   19984:	f8777a88 	ldr	x8, [x20, x23, lsl #3]
   19988:	f90016a8 	str	x8, [x21, #40]
   1998c:	d1008128 	sub	x8, x9, #0x20
   19990:	f90096a8 	str	x8, [x21, #296]
   19994:	8b170e9c 	add	x28, x20, x23, lsl #3
   19998:	52801fe1 	mov	w1, #0xff                  	// #255
   1999c:	52801c02 	mov	w2, #0xe0                  	// #224
   199a0:	91002380 	add	x0, x28, #0x8
   199a4:	97ffa853 	bl	3af0 <memset@plt>
   199a8:	52800028 	mov	w8, #0x1                   	// #1
   199ac:	d2c74009 	mov	x9, #0x3a0000000000        	// #63771674411008
   199b0:	f9000393 	str	x19, [x28]
   199b4:	aa18810a 	orr	x10, x8, x24, lsl #32
   199b8:	f2e0a009 	movk	x9, #0x500, lsl #48
   199bc:	aa0902e9 	orr	x9, x23, x9
   199c0:	a90eab9b 	stp	x27, x10, [x28, #232]
   199c4:	a93e22c9 	stp	x9, x8, [x22, #-32]
   199c8:	f94016a0 	ldr	x0, [x21, #40]
   199cc:	b40008e0 	cbz	x0, 19ae8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K210+0x26c>
   199d0:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   199d4:	f94096aa 	ldr	x10, [x21, #296]
   199d8:	f90016a8 	str	x8, [x21, #40]
   199dc:	d1008148 	sub	x8, x10, #0x20
   199e0:	f90096a8 	str	x8, [x21, #296]
   199e4:	8b000e88 	add	x8, x20, x0, lsl #3
   199e8:	d2c0002a 	mov	x10, #0x100000000           	// #4294967296
   199ec:	2a1a03eb 	mov	w11, w26
   199f0:	f85f03ac 	ldur	x12, [x29, #-16]
   199f4:	a97cb7ae 	ldp	x14, x13, [x29, #-56]
   199f8:	f900710a 	str	x10, [x8, #224]
   199fc:	2a1903ea 	mov	w10, w25
   19a00:	f85e03b1 	ldur	x17, [x29, #-32]
   19a04:	a9002d0a 	stp	x10, x11, [x8]
   19a08:	a9422beb 	ldp	x11, x10, [sp, #32]
   19a0c:	a97bbfb0 	ldp	x16, x15, [x29, #-72]
   19a10:	f9006d09 	str	x9, [x8, #216]
   19a14:	a97acbb3 	ldp	x19, x18, [x29, #-88]
   19a18:	f85983a9 	ldur	x9, [x29, #-104]
   19a1c:	a902290b 	stp	x11, x10, [x8, #32]
   19a20:	a943abeb 	ldp	x11, x10, [sp, #56]
   19a24:	a9014913 	stp	x19, x18, [x8, #16]
   19a28:	a903290b 	stp	x11, x10, [x8, #48]
   19a2c:	f94007ea 	ldr	x10, [sp, #8]
   19a30:	f9402feb 	ldr	x11, [sp, #88]
   19a34:	2a0a03ea 	mov	w10, w10
   19a38:	f900210a 	str	x10, [x8, #64]
   19a3c:	f9400bea 	ldr	x10, [sp, #16]
   19a40:	2a0a03ea 	mov	w10, w10
   19a44:	a904a90b 	stp	x11, x10, [x8, #72]
   19a48:	f9400fea 	ldr	x10, [sp, #24]
   19a4c:	f85e83ab 	ldur	x11, [x29, #-24]
   19a50:	2a0a03ea 	mov	w10, w10
   19a54:	a905a90b 	stp	x11, x10, [x8, #88]
   19a58:	f9401bea 	ldr	x10, [sp, #48]
   19a5c:	f94027eb 	ldr	x11, [sp, #72]
   19a60:	2a0a03ea 	mov	w10, w10
   19a64:	2a0b03eb 	mov	w11, w11
   19a68:	a906a90c 	stp	x12, x10, [x8, #104]
   19a6c:	f9403bea 	ldr	x10, [sp, #112]
   19a70:	f9003d0b 	str	x11, [x8, #120]
   19a74:	2a0d03eb 	mov	w11, w13
   19a78:	2a0a03ea 	mov	w10, w10
   19a7c:	a9082d0a 	stp	x10, x11, [x8, #128]
   19a80:	f85d83aa 	ldur	x10, [x29, #-40]
   19a84:	2a1103eb 	mov	w11, w17
   19a88:	2a0a03ea 	mov	w10, w10
   19a8c:	a9092d0a 	stp	x10, x11, [x8, #144]
   19a90:	2a1003ea 	mov	w10, w16
   19a94:	2a0f03eb 	mov	w11, w15
   19a98:	a90a2d0a 	stp	x10, x11, [x8, #160]
   19a9c:	f9402bea 	ldr	x10, [sp, #80]
   19aa0:	2a0a03ea 	mov	w10, w10
   19aa4:	a90b390a 	stp	x10, x14, [x8, #176]
   19aa8:	a9462fea 	ldp	x10, x11, [sp, #96]
   19aac:	a90c290b 	stp	x11, x10, [x8, #192]
   19ab0:	d2c5400a 	mov	x10, #0x2a0000000000        	// #46179488366592
   19ab4:	f2e0a00a 	movk	x10, #0x500, lsl #48
   19ab8:	aa0a0000 	orr	x0, x0, x10
   19abc:	f9006909 	str	x9, [x8, #208]
   19ac0:	a94e7bfd 	ldp	x29, x30, [sp, #224]
   19ac4:	9103c3ff 	add	sp, sp, #0xf0
   19ac8:	d65f03c0 	ret
   19acc:	f85a03b4 	ldur	x20, [x29, #-96]
   19ad0:	aa1503e1 	mov	x1, x21
   19ad4:	528000a2 	mov	w2, #0x5                   	// #5
   19ad8:	aa1403e0 	mov	x0, x20
   19adc:	97ffac24 	bl	4b6c <heap_alloc_miss>
   19ae0:	aa0003f7 	mov	x23, x0
   19ae4:	17ffffac 	b	19994 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K210+0x118>
   19ae8:	aa1403e0 	mov	x0, x20
   19aec:	aa1503e1 	mov	x1, x21
   19af0:	528000a2 	mov	w2, #0x5                   	// #5
   19af4:	97ffac1e 	bl	4b6c <heap_alloc_miss>
   19af8:	17ffffbb 	b	199e4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K210+0x168>

