   1b704:	d102c3ff 	sub	sp, sp, #0xb0
   1b708:	a90a7bfd 	stp	x29, x30, [sp, #160]
   1b70c:	910283fd 	add	x29, sp, #0xa0
   1b710:	a93eb3af 	stp	x15, x12, [x29, #-24]
   1b714:	a943c7b0 	ldp	x16, x17, [x29, #56]
   1b718:	f81e03aa 	stur	x10, [x29, #-32]
   1b71c:	aa0603ea 	mov	x10, x6
   1b720:	f9400ba2 	ldr	x2, [x29, #16]
   1b724:	a9449bb2 	ldp	x18, x6, [x29, #72]
   1b728:	b85f82cc 	ldur	w12, [x22, #-8]
   1b72c:	a942fbb3 	ldp	x19, x30, [x29, #40]
   1b730:	a941bfb8 	ldp	x24, x15, [x29, #24]
   1b734:	340003b7 	cbz	w23, 1b7a8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K214+0xa4>
   1b738:	528007c8 	mov	w8, #0x3e                  	// #62
   1b73c:	2a1903f9 	mov	w25, w25
   1b740:	2a1a03fa 	mov	w26, w26
   1b744:	a93fa2cc 	stp	x12, x8, [x22, #-8]
   1b748:	2a1e03e8 	mov	w8, w30
   1b74c:	2a1303ec 	mov	w12, w19
   1b750:	a902a3ac 	stp	x12, x8, [x29, #40]
   1b754:	2a0f03e8 	mov	w8, w15
   1b758:	a9049bb2 	stp	x18, x6, [x29, #72]
   1b75c:	aa0a03e6 	mov	x6, x10
   1b760:	a97e33aa 	ldp	x10, x12, [x29, #-32]
   1b764:	2a0c03ef 	mov	w15, w12
   1b768:	2a1803ec 	mov	w12, w24
   1b76c:	2a0503e5 	mov	w5, w5
   1b770:	a901a3ac 	stp	x12, x8, [x29, #24]
   1b774:	2a0203e8 	mov	w8, w2
   1b778:	f85f03ac 	ldur	x12, [x29, #-16]
   1b77c:	2a0703e7 	mov	w7, w7
   1b780:	2a0b03eb 	mov	w11, w11
   1b784:	a903c7b0 	stp	x16, x17, [x29, #56]
   1b788:	2a0d03ed 	mov	w13, w13
   1b78c:	2a0e03ee 	mov	w14, w14
   1b790:	2a0903e9 	mov	w9, w9
   1b794:	910022d6 	add	x22, x22, #0x8
   1b798:	f9000ba8 	str	x8, [x29, #16]
   1b79c:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   1b7a0:	9102c3ff 	add	sp, sp, #0xb0
   1b7a4:	17fff03c 	b	17894 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0>
   1b7a8:	a93c4fa2 	stp	x2, x19, [x29, #-64]
   1b7ac:	f94016a8 	ldr	x8, [x21, #40]
   1b7b0:	a93d7baf 	stp	x15, x30, [x29, #-48]
   1b7b4:	a90447f2 	stp	x18, x17, [sp, #64]
   1b7b8:	f9002bf0 	str	x16, [sp, #80]
   1b7bc:	f81b83a9 	stur	x9, [x29, #-72]
   1b7c0:	a97e26d7 	ldp	x23, x9, [x22, #-32]
   1b7c4:	b4000a88 	cbz	x8, 1b914 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K214+0x210>
   1b7c8:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   1b7cc:	f94096b1 	ldr	x17, [x21, #296]
   1b7d0:	f90016b0 	str	x16, [x21, #40]
   1b7d4:	d1008230 	sub	x16, x17, #0x20
   1b7d8:	f90096b0 	str	x16, [x21, #296]
   1b7dc:	52800031 	mov	w17, #0x1                   	// #1
   1b7e0:	8b080e90 	add	x16, x20, x8, lsl #3
   1b7e4:	6f07e7e0 	movi	v0.2d, #0xffffffffffffffff
   1b7e8:	aa098229 	orr	x9, x17, x9, lsl #32
   1b7ec:	f900020c 	str	x12, [x16]
   1b7f0:	a90ea617 	stp	x23, x9, [x16, #232]
   1b7f4:	d2c7c009 	mov	x9, #0x3e0000000000        	// #68169720922112
   1b7f8:	f2e0a009 	movk	x9, #0x500, lsl #48
   1b7fc:	3c8d8200 	stur	q0, [x16, #216]
   1b800:	aa090117 	orr	x23, x8, x9
   1b804:	3c8c8200 	stur	q0, [x16, #200]
   1b808:	3c8b8200 	stur	q0, [x16, #184]
   1b80c:	3c8a8200 	stur	q0, [x16, #168]
   1b810:	3c898200 	stur	q0, [x16, #152]
   1b814:	3c888200 	stur	q0, [x16, #136]
   1b818:	3c878200 	stur	q0, [x16, #120]
   1b81c:	3c868200 	stur	q0, [x16, #104]
   1b820:	3c858200 	stur	q0, [x16, #88]
   1b824:	3c848200 	stur	q0, [x16, #72]
   1b828:	3c838200 	stur	q0, [x16, #56]
   1b82c:	3c828200 	stur	q0, [x16, #40]
   1b830:	3c818200 	stur	q0, [x16, #24]
   1b834:	3c808200 	stur	q0, [x16, #8]
   1b838:	a93e46d7 	stp	x23, x17, [x22, #-32]
   1b83c:	f94016a8 	ldr	x8, [x21, #40]
   1b840:	b40008a8 	cbz	x8, 1b954 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K214+0x250>
   1b844:	f8687a89 	ldr	x9, [x20, x8, lsl #3]
   1b848:	f94096ac 	ldr	x12, [x21, #296]
   1b84c:	f90016a9 	str	x9, [x21, #40]
   1b850:	d1008189 	sub	x9, x12, #0x20
   1b854:	f90096a9 	str	x9, [x21, #296]
   1b858:	8b080e90 	add	x16, x20, x8, lsl #3
   1b85c:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
   1b860:	2a1a03ec 	mov	w12, w26
   1b864:	a97c4bb5 	ldp	x21, x18, [x29, #-64]
   1b868:	f9007209 	str	x9, [x16, #224]
   1b86c:	2a1903e9 	mov	w9, w25
   1b870:	a9003209 	stp	x9, x12, [x16]
   1b874:	2a0503e9 	mov	w9, w5
   1b878:	a9042a09 	stp	x9, x10, [x16, #64]
   1b87c:	2a0703e9 	mov	w9, w7
   1b880:	f9002a09 	str	x9, [x16, #80]
   1b884:	a97e2ba9 	ldp	x9, x10, [x29, #-32]
   1b888:	a97d47af 	ldp	x15, x17, [x29, #-48]
   1b88c:	a901721b 	stp	x27, x28, [x16, #16]
   1b890:	a9020600 	stp	x0, x1, [x16, #32]
   1b894:	f9002e09 	str	x9, [x16, #88]
   1b898:	2a0b03e9 	mov	w9, w11
   1b89c:	2a0e03eb 	mov	w11, w14
   1b8a0:	f9003209 	str	x9, [x16, #96]
   1b8a4:	f85f03a9 	ldur	x9, [x29, #-16]
   1b8a8:	a9031203 	stp	x3, x4, [x16, #48]
   1b8ac:	f9003609 	str	x9, [x16, #104]
   1b8b0:	2a0d03e9 	mov	w9, w13
   1b8b4:	a9072e09 	stp	x9, x11, [x16, #112]
   1b8b8:	f85b83a9 	ldur	x9, [x29, #-72]
   1b8bc:	2a0a03eb 	mov	w11, w10
   1b8c0:	2a1203ea 	mov	w10, w18
   1b8c4:	2a0903e9 	mov	w9, w9
   1b8c8:	a9082e09 	stp	x9, x11, [x16, #128]
   1b8cc:	2a1503e9 	mov	w9, w21
   1b8d0:	2a1803eb 	mov	w11, w24
   1b8d4:	a9092e09 	stp	x9, x11, [x16, #144]
   1b8d8:	2a0f03e9 	mov	w9, w15
   1b8dc:	a90a2a09 	stp	x9, x10, [x16, #160]
   1b8e0:	2a1103e9 	mov	w9, w17
   1b8e4:	f9005a09 	str	x9, [x16, #176]
   1b8e8:	a944abe9 	ldp	x9, x10, [sp, #72]
   1b8ec:	a90ba60a 	stp	x10, x9, [x16, #184]
   1b8f0:	f94023e9 	ldr	x9, [sp, #64]
   1b8f4:	a90c9a09 	stp	x9, x6, [x16, #200]
   1b8f8:	d2c54009 	mov	x9, #0x2a0000000000        	// #46179488366592
   1b8fc:	f2e0a009 	movk	x9, #0x500, lsl #48
   1b900:	aa090100 	orr	x0, x8, x9
   1b904:	f9006e17 	str	x23, [x16, #216]
   1b908:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   1b90c:	9102c3ff 	add	sp, sp, #0xb0
   1b910:	d65f03c0 	ret
   1b914:	a90303e1 	stp	x1, x0, [sp, #48]
   1b918:	aa1403e0 	mov	x0, x20
   1b91c:	aa1503e1 	mov	x1, x21
   1b920:	528000a2 	mov	w2, #0x5                   	// #5
   1b924:	a9009be7 	stp	x7, x6, [sp, #8]
   1b928:	a9022be3 	stp	x3, x10, [sp, #32]
   1b92c:	f90003e4 	str	x4, [sp]
   1b930:	f9000fe5 	str	x5, [sp, #24]
   1b934:	97ffa557 	bl	4e90 <heap_alloc_miss>
   1b938:	a94117e6 	ldp	x6, x5, [sp, #16]
   1b93c:	aa0003e8 	mov	x8, x0
   1b940:	a9401fe4 	ldp	x4, x7, [sp]
   1b944:	f94013e3 	ldr	x3, [sp, #32]
   1b948:	a94287ea 	ldp	x10, x1, [sp, #40]
   1b94c:	f9401fe0 	ldr	x0, [sp, #56]
   1b950:	17ffffa3 	b	1b7dc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K214+0xd8>
   1b954:	a90303e1 	stp	x1, x0, [sp, #48]
   1b958:	aa1403e0 	mov	x0, x20
   1b95c:	aa1503e1 	mov	x1, x21
   1b960:	528000a2 	mov	w2, #0x5                   	// #5
   1b964:	a90117e6 	stp	x6, x5, [sp, #16]
   1b968:	aa0403e9 	mov	x9, x4
   1b96c:	a9022be3 	stp	x3, x10, [sp, #32]
   1b970:	aa0703f5 	mov	x21, x7
   1b974:	97ffa547 	bl	4e90 <heap_alloc_miss>
   1b978:	a94117e6 	ldp	x6, x5, [sp, #16]
   1b97c:	aa0003e8 	mov	x8, x0
   1b980:	a94287ea 	ldp	x10, x1, [sp, #40]
   1b984:	aa1503e7 	mov	x7, x21
   1b988:	f94013e3 	ldr	x3, [sp, #32]
   1b98c:	f9401fe0 	ldr	x0, [sp, #56]
   1b990:	aa0903e4 	mov	x4, x9
   1b994:	17ffffb1 	b	1b858 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K214+0x154>

