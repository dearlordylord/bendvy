    4f10:	f81b0fef 	str	x15, [sp, #-80]!
    4f14:	a90137ee 	stp	x14, x13, [sp, #16]
    4f18:	a9022fec 	stp	x12, x11, [sp, #32]
    4f1c:	a90327ea 	stp	x10, x9, [sp, #48]
    4f20:	a9047bfd 	stp	x29, x30, [sp, #64]
    4f24:	910103fd 	add	x29, sp, #0x40
    4f28:	d378f848 	ubfx	x8, x2, #56, #7
    4f2c:	f100151f 	cmp	x8, #0x5
    4f30:	540003c0 	b.eq	4fa8 <rfc_wrap+0x98>  // b.none
    4f34:	f1000d1f 	cmp	x8, #0x3
    4f38:	54000380 	b.eq	4fa8 <rfc_wrap+0x98>  // b.none
    4f3c:	f9400028 	ldr	x8, [x1]
    4f40:	2a0303ea 	mov	w10, w3
    4f44:	aa0203e9 	mov	x9, x2
    4f48:	aa0003eb 	mov	x11, x0
    4f4c:	b4000248 	cbz	x8, 4f94 <rfc_wrap+0x84>
    4f50:	f8687970 	ldr	x16, [x11, x8, lsl #3]
    4f54:	f9408031 	ldr	x17, [x1, #256]
    4f58:	f9000030 	str	x16, [x1]
    4f5c:	d1000630 	sub	x16, x17, #0x1
    4f60:	f9008030 	str	x16, [x1, #256]
    4f64:	2a0a03f1 	mov	w17, w10
    4f68:	92585930 	and	x16, x9, #0x7fffff0000000000
    4f6c:	aa096231 	orr	x17, x17, x9, lsl #24
    4f70:	aa080210 	orr	x16, x16, x8
    4f74:	b2410200 	orr	x0, x16, #0x8000000000000000
    4f78:	f8287971 	str	x17, [x11, x8, lsl #3]
    4f7c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    4f80:	a94327ea 	ldp	x10, x9, [sp, #48]
    4f84:	a9422fec 	ldp	x12, x11, [sp, #32]
    4f88:	a94137ee 	ldp	x14, x13, [sp, #16]
    4f8c:	f84507ef 	ldr	x15, [sp], #80
    4f90:	d65f03c0 	ret
    4f94:	aa0b03e0 	mov	x0, x11
    4f98:	2a1f03e2 	mov	w2, wzr
    4f9c:	97fffef4 	bl	4b6c <heap_alloc_miss>
    4fa0:	aa0003e8 	mov	x8, x0
    4fa4:	17fffff0 	b	4f64 <rfc_wrap+0x54>
    4fa8:	90000440 	adrp	x0, 8c000 <STAT_IMG+0x1d20>
    4fac:	91032000 	add	x0, x0, #0xc8
    4fb0:	94000233 	bl	587c <err_fail>

