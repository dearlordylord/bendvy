   19cfc:	d103c3ff 	sub	sp, sp, #0xf0
   19d00:	a90e7bfd 	stp	x29, x30, [sp, #224]
   19d04:	910383fd 	add	x29, sp, #0xe0
   19d08:	a941fbb3 	ldp	x19, x30, [x29, #24]
   19d0c:	f81f03ac 	stur	x12, [x29, #-16]
   19d10:	a944cbb0 	ldp	x16, x18, [x29, #72]
   19d14:	a9438ba8 	ldp	x8, x2, [x29, #56]
   19d18:	a93e2bb3 	stp	x19, x10, [x29, #-32]
   19d1c:	f9400bb3 	ldr	x19, [x29, #16]
   19d20:	a942c7b8 	ldp	x24, x17, [x29, #40]
   19d24:	f81d83b3 	stur	x19, [x29, #-40]
   19d28:	b85f82d3 	ldur	w19, [x22, #-8]
   19d2c:	34000437 	cbz	w23, 19db0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K212+0xb4>
   19d30:	aa1c03ea 	mov	x10, x28
   19d34:	aa0803fc 	mov	x28, x8
   19d38:	52800788 	mov	w8, #0x3c                  	// #60
   19d3c:	a93fa2d3 	stp	x19, x8, [x22, #-8]
   19d40:	2a1103e8 	mov	w8, w17
   19d44:	2a1903ec 	mov	w12, w25
   19d48:	a904cbb0 	stp	x16, x18, [x29, #72]
   19d4c:	2a1803f0 	mov	w16, w24
   19d50:	aa0c03f9 	mov	x25, x12
   19d54:	a902a3b0 	stp	x16, x8, [x29, #40]
   19d58:	f85e03b0 	ldur	x16, [x29, #-32]
   19d5c:	2a1e03e8 	mov	w8, w30
   19d60:	a9038bbc 	stp	x28, x2, [x29, #56]
   19d64:	aa0a03fc 	mov	x28, x10
   19d68:	2a1a03fa 	mov	w26, w26
   19d6c:	2a1003f0 	mov	w16, w16
   19d70:	a97eb3aa 	ldp	x10, x12, [x29, #-24]
   19d74:	a901a3b0 	stp	x16, x8, [x29, #24]
   19d78:	f85d83a8 	ldur	x8, [x29, #-40]
   19d7c:	2a0503e5 	mov	w5, w5
   19d80:	2a0703e7 	mov	w7, w7
   19d84:	2a0b03eb 	mov	w11, w11
   19d88:	2a0d03ed 	mov	w13, w13
   19d8c:	2a0803e8 	mov	w8, w8
   19d90:	2a0e03ee 	mov	w14, w14
   19d94:	2a0903e9 	mov	w9, w9
   19d98:	2a0f03ef 	mov	w15, w15
   19d9c:	910022d6 	add	x22, x22, #0x8
   19da0:	f9000ba8 	str	x8, [x29, #16]
   19da4:	a94e7bfd 	ldp	x29, x30, [sp, #224]
   19da8:	9103c3ff 	add	sp, sp, #0xf0
   19dac:	17fff246 	b	166c4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0>
   19db0:	f81a03b4 	stur	x20, [x29, #-96]
   19db4:	f94016b7 	ldr	x23, [x21, #40]
   19db8:	a9009fe5 	stp	x5, x7, [sp, #8]
   19dbc:	f81a83bb 	stur	x27, [x29, #-88]
   19dc0:	f9000feb 	str	x11, [sp, #24]
   19dc4:	f81b03bc 	stur	x28, [x29, #-80]
   19dc8:	a90207e0 	stp	x0, x1, [sp, #32]
   19dcc:	a9030fed 	stp	x13, x3, [sp, #48]
   19dd0:	f81b83be 	stur	x30, [x29, #-72]
   19dd4:	f90023e4 	str	x4, [sp, #64]
   19dd8:	f81c03b8 	stur	x24, [x29, #-64]
   19ddc:	a97e62db 	ldp	x27, x24, [x22, #-32]
   19de0:	a904c7ee 	stp	x14, x17, [sp, #72]
   19de4:	a905c3e6 	stp	x6, x16, [sp, #88]
   19de8:	f9003be9 	str	x9, [sp, #112]
   19dec:	f81983b2 	stur	x18, [x29, #-104]
   19df0:	a93cbfa8 	stp	x8, x15, [x29, #-56]
   19df4:	f90037e2 	str	x2, [sp, #104]
   19df8:	b4000ab7 	cbz	x23, 19f4c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K212+0x250>
   19dfc:	f85a03b4 	ldur	x20, [x29, #-96]
   19e00:	f94096a9 	ldr	x9, [x21, #296]
   19e04:	f8777a88 	ldr	x8, [x20, x23, lsl #3]
   19e08:	f90016a8 	str	x8, [x21, #40]
   19e0c:	d1008128 	sub	x8, x9, #0x20
   19e10:	f90096a8 	str	x8, [x21, #296]
   19e14:	8b170e9c 	add	x28, x20, x23, lsl #3
   19e18:	52801fe1 	mov	w1, #0xff                  	// #255
   19e1c:	52801c02 	mov	w2, #0xe0                  	// #224
   19e20:	91002380 	add	x0, x28, #0x8
   19e24:	97ffa733 	bl	3af0 <memset@plt>
   19e28:	52800028 	mov	w8, #0x1                   	// #1
   19e2c:	d2c78009 	mov	x9, #0x3c0000000000        	// #65970697666560
   19e30:	f9000393 	str	x19, [x28]
   19e34:	aa18810a 	orr	x10, x8, x24, lsl #32
   19e38:	f2e0a009 	movk	x9, #0x500, lsl #48
   19e3c:	aa0902e9 	orr	x9, x23, x9
   19e40:	a90eab9b 	stp	x27, x10, [x28, #232]
   19e44:	a93e22c9 	stp	x9, x8, [x22, #-32]
   19e48:	f94016a0 	ldr	x0, [x21, #40]
   19e4c:	b40008e0 	cbz	x0, 19f68 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K212+0x26c>
   19e50:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   19e54:	f94096aa 	ldr	x10, [x21, #296]
   19e58:	f90016a8 	str	x8, [x21, #40]
   19e5c:	d1008148 	sub	x8, x10, #0x20
   19e60:	f90096a8 	str	x8, [x21, #296]
   19e64:	8b000e88 	add	x8, x20, x0, lsl #3
   19e68:	d2c0002a 	mov	x10, #0x100000000           	// #4294967296
   19e6c:	2a1a03eb 	mov	w11, w26
   19e70:	f85f03ac 	ldur	x12, [x29, #-16]
   19e74:	a97cb7ae 	ldp	x14, x13, [x29, #-56]
   19e78:	f900710a 	str	x10, [x8, #224]
   19e7c:	2a1903ea 	mov	w10, w25
   19e80:	f85e03b1 	ldur	x17, [x29, #-32]
   19e84:	a9002d0a 	stp	x10, x11, [x8]
   19e88:	a9422beb 	ldp	x11, x10, [sp, #32]
   19e8c:	a97bbfb0 	ldp	x16, x15, [x29, #-72]
   19e90:	f9006d09 	str	x9, [x8, #216]
   19e94:	a97acbb3 	ldp	x19, x18, [x29, #-88]
   19e98:	f85983a9 	ldur	x9, [x29, #-104]
   19e9c:	a902290b 	stp	x11, x10, [x8, #32]
   19ea0:	a943abeb 	ldp	x11, x10, [sp, #56]
   19ea4:	a9014913 	stp	x19, x18, [x8, #16]
   19ea8:	a903290b 	stp	x11, x10, [x8, #48]
   19eac:	f94007ea 	ldr	x10, [sp, #8]
   19eb0:	f9402feb 	ldr	x11, [sp, #88]
   19eb4:	2a0a03ea 	mov	w10, w10
   19eb8:	f900210a 	str	x10, [x8, #64]
   19ebc:	f9400bea 	ldr	x10, [sp, #16]
   19ec0:	2a0a03ea 	mov	w10, w10
   19ec4:	a904a90b 	stp	x11, x10, [x8, #72]
   19ec8:	f9400fea 	ldr	x10, [sp, #24]
   19ecc:	f85e83ab 	ldur	x11, [x29, #-24]
   19ed0:	2a0a03ea 	mov	w10, w10
   19ed4:	a905a90b 	stp	x11, x10, [x8, #88]
   19ed8:	f9401bea 	ldr	x10, [sp, #48]
   19edc:	f94027eb 	ldr	x11, [sp, #72]
   19ee0:	2a0a03ea 	mov	w10, w10
   19ee4:	2a0b03eb 	mov	w11, w11
   19ee8:	a906a90c 	stp	x12, x10, [x8, #104]
   19eec:	f9403bea 	ldr	x10, [sp, #112]
   19ef0:	f9003d0b 	str	x11, [x8, #120]
   19ef4:	2a0d03eb 	mov	w11, w13
   19ef8:	2a0a03ea 	mov	w10, w10
   19efc:	a9082d0a 	stp	x10, x11, [x8, #128]
   19f00:	f85d83aa 	ldur	x10, [x29, #-40]
   19f04:	2a1103eb 	mov	w11, w17
   19f08:	2a0a03ea 	mov	w10, w10
   19f0c:	a9092d0a 	stp	x10, x11, [x8, #144]
   19f10:	2a1003ea 	mov	w10, w16
   19f14:	2a0f03eb 	mov	w11, w15
   19f18:	a90a2d0a 	stp	x10, x11, [x8, #160]
   19f1c:	f9402bea 	ldr	x10, [sp, #80]
   19f20:	2a0a03ea 	mov	w10, w10
   19f24:	a90b390a 	stp	x10, x14, [x8, #176]
   19f28:	a9462fea 	ldp	x10, x11, [sp, #96]
   19f2c:	a90c290b 	stp	x11, x10, [x8, #192]
   19f30:	d2c5400a 	mov	x10, #0x2a0000000000        	// #46179488366592
   19f34:	f2e0a00a 	movk	x10, #0x500, lsl #48
   19f38:	aa0a0000 	orr	x0, x0, x10
   19f3c:	f9006909 	str	x9, [x8, #208]
   19f40:	a94e7bfd 	ldp	x29, x30, [sp, #224]
   19f44:	9103c3ff 	add	sp, sp, #0xf0
   19f48:	d65f03c0 	ret
   19f4c:	f85a03b4 	ldur	x20, [x29, #-96]
   19f50:	aa1503e1 	mov	x1, x21
   19f54:	528000a2 	mov	w2, #0x5                   	// #5
   19f58:	aa1403e0 	mov	x0, x20
   19f5c:	97ffab04 	bl	4b6c <heap_alloc_miss>
   19f60:	aa0003f7 	mov	x23, x0
   19f64:	17ffffac 	b	19e14 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K212+0x118>
   19f68:	aa1403e0 	mov	x0, x20
   19f6c:	aa1503e1 	mov	x1, x21
   19f70:	528000a2 	mov	w2, #0x5                   	// #5
   19f74:	97ffaafe 	bl	4b6c <heap_alloc_miss>
   19f78:	17ffffbb 	b	19e64 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K212+0x168>

