   1cd4c:	d103c3ff 	sub	sp, sp, #0xf0
   1cd50:	a90e7bfd 	stp	x29, x30, [sp, #224]
   1cd54:	910383fd 	add	x29, sp, #0xe0
   1cd58:	a944c7b0 	ldp	x16, x17, [x29, #72]
   1cd5c:	f81d03b9 	stur	x25, [x29, #-48]
   1cd60:	a945a3b9 	ldp	x25, x8, [x29, #88]
   1cd64:	f9400bb3 	ldr	x19, [x29, #16]
   1cd68:	a93ec7b0 	stp	x16, x17, [x29, #-24]
   1cd6c:	a943c3a2 	ldp	x2, x16, [x29, #56]
   1cd70:	a941c7b2 	ldp	x18, x17, [x29, #24]
   1cd74:	f81e03b0 	stur	x16, [x29, #-32]
   1cd78:	a942fbb0 	ldp	x16, x30, [x29, #40]
   1cd7c:	b7f806fc 	tbnz	x28, #63, 1ce58 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x10c>
   1cd80:	b7f80720 	tbnz	x0, #63, 1ce64 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x118>
   1cd84:	b7f80761 	tbnz	x1, #63, 1ce70 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x124>
   1cd88:	b7f807a3 	tbnz	x3, #63, 1ce7c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x130>
   1cd8c:	b7f807e4 	tbnz	x4, #63, 1ce88 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x13c>
   1cd90:	b7f80825 	tbnz	x5, #63, 1ce94 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x148>
   1cd94:	b7f8086b 	tbnz	x11, #63, 1cea0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x154>
   1cd98:	b7f808ad 	tbnz	x13, #63, 1ceac <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x160>
   1cd9c:	f85e03b8 	ldur	x24, [x29, #-32]
   1cda0:	b6f80098 	tbz	x24, #63, 1cdb0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x64>
   1cda4:	f85e03b8 	ldur	x24, [x29, #-32]
   1cda8:	92409f18 	and	x24, x24, #0xffffffffff
   1cdac:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1cdb0:	f85e83b8 	ldur	x24, [x29, #-24]
   1cdb4:	b6f80098 	tbz	x24, #63, 1cdc4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x78>
   1cdb8:	f85e83b8 	ldur	x24, [x29, #-24]
   1cdbc:	92409f18 	and	x24, x24, #0xffffffffff
   1cdc0:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1cdc4:	f85f03b8 	ldur	x24, [x29, #-16]
   1cdc8:	b7f80798 	tbnz	x24, #63, 1ceb8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x16c>
   1cdcc:	b7f807f9 	tbnz	x25, #63, 1cec8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x17c>
   1cdd0:	f81d83b9 	stur	x25, [x29, #-40]
   1cdd4:	2a1a03fa 	mov	w26, w26
   1cdd8:	2a1b03fb 	mov	w27, w27
   1cddc:	2a0603e6 	mov	w6, w6
   1cde0:	2a0a03ea 	mov	w10, w10
   1cde4:	2a0c03ec 	mov	w12, w12
   1cde8:	2a0e03ee 	mov	w14, w14
   1cdec:	2a0903e9 	mov	w9, w9
   1cdf0:	2a0f03ef 	mov	w15, w15
   1cdf4:	2a1303f8 	mov	w24, w19
   1cdf8:	2a1203f2 	mov	w18, w18
   1cdfc:	2a1103f1 	mov	w17, w17
   1ce00:	2a1003f0 	mov	w16, w16
   1ce04:	2a1e03fe 	mov	w30, w30
   1ce08:	2a0203f9 	mov	w25, w2
   1ce0c:	2a0803f3 	mov	w19, w8
   1ce10:	34000637 	cbz	w23, 1ced4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x188>
   1ce14:	528009e8 	mov	w8, #0x4f                  	// #79
   1ce18:	f80086c8 	str	x8, [x22], #8
   1ce1c:	f85d83a8 	ldur	x8, [x29, #-40]
   1ce20:	a902fbb0 	stp	x16, x30, [x29, #40]
   1ce24:	a905cfa8 	stp	x8, x19, [x29, #88]
   1ce28:	f85f03a8 	ldur	x8, [x29, #-16]
   1ce2c:	a901c7b2 	stp	x18, x17, [x29, #24]
   1ce30:	f9002ba8 	str	x8, [x29, #80]
   1ce34:	f85e83a8 	ldur	x8, [x29, #-24]
   1ce38:	f90027a8 	str	x8, [x29, #72]
   1ce3c:	f85e03a8 	ldur	x8, [x29, #-32]
   1ce40:	a903a3b9 	stp	x25, x8, [x29, #56]
   1ce44:	f85d03b9 	ldur	x25, [x29, #-48]
   1ce48:	f9000bb8 	str	x24, [x29, #16]
   1ce4c:	a94e7bfd 	ldp	x29, x30, [sp, #224]
   1ce50:	9103c3ff 	add	sp, sp, #0xf0
   1ce54:	17fff70a 	b	1aa7c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0>
   1ce58:	92409f98 	and	x24, x28, #0xffffffffff
   1ce5c:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1ce60:	b6fff920 	tbz	x0, #63, 1cd84 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x38>
   1ce64:	92409c18 	and	x24, x0, #0xffffffffff
   1ce68:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1ce6c:	b6fff8e1 	tbz	x1, #63, 1cd88 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x3c>
   1ce70:	92409c38 	and	x24, x1, #0xffffffffff
   1ce74:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1ce78:	b6fff8a3 	tbz	x3, #63, 1cd8c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x40>
   1ce7c:	92409c78 	and	x24, x3, #0xffffffffff
   1ce80:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1ce84:	b6fff864 	tbz	x4, #63, 1cd90 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x44>
   1ce88:	92409c98 	and	x24, x4, #0xffffffffff
   1ce8c:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1ce90:	b6fff825 	tbz	x5, #63, 1cd94 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x48>
   1ce94:	92409cb8 	and	x24, x5, #0xffffffffff
   1ce98:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1ce9c:	b6fff7eb 	tbz	x11, #63, 1cd98 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x4c>
   1cea0:	92409d78 	and	x24, x11, #0xffffffffff
   1cea4:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1cea8:	b6fff7ad 	tbz	x13, #63, 1cd9c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x50>
   1ceac:	92409db8 	and	x24, x13, #0xffffffffff
   1ceb0:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1ceb4:	17ffffba 	b	1cd9c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x50>
   1ceb8:	f85f03b8 	ldur	x24, [x29, #-16]
   1cebc:	92409f18 	and	x24, x24, #0xffffffffff
   1cec0:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1cec4:	b6fff879 	tbz	x25, #63, 1cdd0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x84>
   1cec8:	92409f38 	and	x24, x25, #0xffffffffff
   1cecc:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1ced0:	17ffffc0 	b	1cdd0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x84>
   1ced4:	a904f3e9 	stp	x9, x28, [sp, #72]
   1ced8:	a97ea2c9 	ldp	x9, x8, [x22, #-24]
   1cedc:	f94016b7 	ldr	x23, [x21, #40]
   1cee0:	aa0e03fc 	mov	x28, x14
   1cee4:	a901c3fe 	stp	x30, x16, [sp, #24]
   1cee8:	a902cbf1 	stp	x17, x18, [sp, #40]
   1ceec:	f9001fe6 	str	x6, [sp, #56]
   1cef0:	a90587e0 	stp	x0, x1, [sp, #88]
   1cef4:	f9003be4 	str	x4, [sp, #112]
   1cef8:	a9399fa5 	stp	x5, x7, [x29, #-104]
   1cefc:	a93ab7ab 	stp	x11, x13, [x29, #-88]
   1cf00:	a900a7e8 	stp	x8, x9, [sp, #8]
   1cf04:	f90037e3 	str	x3, [sp, #104]
   1cf08:	f81c83ac 	stur	x12, [x29, #-56]
   1cf0c:	f90023ea 	str	x10, [sp, #64]
   1cf10:	a93bbfb8 	stp	x24, x15, [x29, #-72]
   1cf14:	b4000957 	cbz	x23, 1d03c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x2f0>
   1cf18:	f8777a88 	ldr	x8, [x20, x23, lsl #3]
   1cf1c:	f94096a9 	ldr	x9, [x21, #296]
   1cf20:	f90016a8 	str	x8, [x21, #40]
   1cf24:	d1008128 	sub	x8, x9, #0x20
   1cf28:	f90096a8 	str	x8, [x21, #296]
   1cf2c:	8b170e98 	add	x24, x20, x23, lsl #3
   1cf30:	52801fe1 	mov	w1, #0xff                  	// #255
   1cf34:	52801c02 	mov	w2, #0xe0                  	// #224
   1cf38:	aa1803e0 	mov	x0, x24
   1cf3c:	97ff9aed 	bl	3af0 <memset@plt>
   1cf40:	a940abe9 	ldp	x9, x10, [sp, #8]
   1cf44:	52800028 	mov	w8, #0x1                   	// #1
   1cf48:	aa098108 	orr	x8, x8, x9, lsl #32
   1cf4c:	d2c9e009 	mov	x9, #0x4f0000000000        	// #86861418594304
   1cf50:	f2e0a009 	movk	x9, #0x500, lsl #48
   1cf54:	aa0902e9 	orr	x9, x23, x9
   1cf58:	a90e230a 	stp	x10, x8, [x24, #224]
   1cf5c:	a93efec9 	stp	x9, xzr, [x22, #-24]
   1cf60:	f94016a0 	ldr	x0, [x21, #40]
   1cf64:	b4000780 	cbz	x0, 1d054 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x308>
   1cf68:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   1cf6c:	f94096aa 	ldr	x10, [x21, #296]
   1cf70:	f90016a8 	str	x8, [x21, #40]
   1cf74:	d1008148 	sub	x8, x10, #0x20
   1cf78:	f90096a8 	str	x8, [x21, #296]
   1cf7c:	8b000e88 	add	x8, x20, x0, lsl #3
   1cf80:	f85d03aa 	ldur	x10, [x29, #-48]
   1cf84:	f85b83ad 	ldur	x13, [x29, #-72]
   1cf88:	a97c2fac 	ldp	x12, x11, [x29, #-64]
   1cf8c:	a900690a 	stp	x10, x26, [x8]
   1cf90:	f9402bea 	ldr	x10, [sp, #80]
   1cf94:	f900791f 	str	xzr, [x8, #240]
   1cf98:	a901291b 	stp	x27, x10, [x8, #16]
   1cf9c:	f9402fea 	ldr	x10, [sp, #88]
   1cfa0:	f900110a 	str	x10, [x8, #32]
   1cfa4:	f94033ea 	ldr	x10, [sp, #96]
   1cfa8:	f900150a 	str	x10, [x8, #40]
   1cfac:	f94037ea 	ldr	x10, [sp, #104]
   1cfb0:	f900190a 	str	x10, [x8, #48]
   1cfb4:	f9403bea 	ldr	x10, [sp, #112]
   1cfb8:	f9001d0a 	str	x10, [x8, #56]
   1cfbc:	f85983aa 	ldur	x10, [x29, #-104]
   1cfc0:	f900210a 	str	x10, [x8, #64]
   1cfc4:	f9401fea 	ldr	x10, [sp, #56]
   1cfc8:	f900250a 	str	x10, [x8, #72]
   1cfcc:	f85a03aa 	ldur	x10, [x29, #-96]
   1cfd0:	f900290a 	str	x10, [x8, #80]
   1cfd4:	f94023ea 	ldr	x10, [sp, #64]
   1cfd8:	f9002d0a 	str	x10, [x8, #88]
   1cfdc:	f85a83aa 	ldur	x10, [x29, #-88]
   1cfe0:	a9062d0a 	stp	x10, x11, [x8, #96]
   1cfe4:	f85b03aa 	ldur	x10, [x29, #-80]
   1cfe8:	a907710a 	stp	x10, x28, [x8, #112]
   1cfec:	f94027ea 	ldr	x10, [sp, #72]
   1cff0:	a908310a 	stp	x10, x12, [x8, #128]
   1cff4:	a942afea 	ldp	x10, x11, [sp, #40]
   1cff8:	a9092d0d 	stp	x13, x11, [x8, #144]
   1cffc:	f900510a 	str	x10, [x8, #160]
   1d000:	a941afea 	ldp	x10, x11, [sp, #24]
   1d004:	a90aa90b 	stp	x11, x10, [x8, #168]
   1d008:	a97e2bab 	ldp	x11, x10, [x29, #-32]
   1d00c:	a90bad19 	stp	x25, x11, [x8, #184]
   1d010:	f85f03ab 	ldur	x11, [x29, #-16]
   1d014:	f900650a 	str	x10, [x8, #200]
   1d018:	f85d83aa 	ldur	x10, [x29, #-40]
   1d01c:	a90d290b 	stp	x11, x10, [x8, #208]
   1d020:	d2c8200a 	mov	x10, #0x410000000000        	// #71468255805440
   1d024:	f2e0a00a 	movk	x10, #0x500, lsl #48
   1d028:	aa0a0000 	orr	x0, x0, x10
   1d02c:	a90e2513 	stp	x19, x9, [x8, #224]
   1d030:	a94e7bfd 	ldp	x29, x30, [sp, #224]
   1d034:	9103c3ff 	add	sp, sp, #0xf0
   1d038:	d65f03c0 	ret
   1d03c:	aa1403e0 	mov	x0, x20
   1d040:	aa1503e1 	mov	x1, x21
   1d044:	528000a2 	mov	w2, #0x5                   	// #5
   1d048:	97ff9ec9 	bl	4b6c <heap_alloc_miss>
   1d04c:	aa0003f7 	mov	x23, x0
   1d050:	17ffffb7 	b	1cf2c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x1e0>
   1d054:	aa1403e0 	mov	x0, x20
   1d058:	aa1503e1 	mov	x1, x21
   1d05c:	528000a2 	mov	w2, #0x5                   	// #5
   1d060:	97ff9ec3 	bl	4b6c <heap_alloc_miss>
   1d064:	17ffffc6 	b	1cf7c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x230>

