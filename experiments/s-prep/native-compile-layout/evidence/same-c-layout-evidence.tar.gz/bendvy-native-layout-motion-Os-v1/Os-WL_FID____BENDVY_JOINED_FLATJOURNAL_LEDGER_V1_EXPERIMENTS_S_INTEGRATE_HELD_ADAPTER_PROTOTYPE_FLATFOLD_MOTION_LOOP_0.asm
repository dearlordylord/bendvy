   1aa7c:	d10443ff 	sub	sp, sp, #0x110
   1aa80:	a9107bfd 	stp	x29, x30, [sp, #256]
   1aa84:	910403fd 	add	x29, sp, #0x100
   1aa88:	aa0903f0 	mov	x16, x9
   1aa8c:	92583f28 	and	x8, x25, #0xffff0000000000
   1aa90:	d2c1c009 	mov	x9, #0xe0000000000         	// #15393162788864
   1aa94:	aa0c03e2 	mov	x2, x12
   1aa98:	aa0b03fe 	mov	x30, x11
   1aa9c:	a93e17a7 	stp	x7, x5, [x29, #-32]
   1aaa0:	a93d13a3 	stp	x3, x4, [x29, #-48]
   1aaa4:	aa1c03e3 	mov	x3, x28
   1aaa8:	eb09011f 	cmp	x8, x9
   1aaac:	a9459fb1 	ldp	x17, x7, [x29, #88]
   1aab0:	b81f03b7 	stur	w23, [x29, #-16]
   1aab4:	a944b3a5 	ldp	x5, x12, [x29, #72]
   1aab8:	f9400bb7 	ldr	x23, [x29, #16]
   1aabc:	a943f3b3 	ldp	x19, x28, [x29, #56]
   1aac0:	a94293ab 	ldp	x11, x4, [x29, #40]
   1aac4:	a941a7b8 	ldp	x24, x9, [x29, #24]
   1aac8:	54000581 	b.ne	1ab78 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0xfc>  // b.any
   1aacc:	b85f8ec8 	ldr	w8, [x22, #-8]!
   1aad0:	aa1103f9 	mov	x25, x17
   1aad4:	aa0903f1 	mov	x17, x9
   1aad8:	90000ca9 	adrp	x9, 1ae000 <io_eff_rows+0xff0d0>
   1aadc:	913f2129 	add	x9, x9, #0xfc8
   1aae0:	f8687928 	ldr	x8, [x9, x8, lsl #3]
   1aae4:	a904e7ac 	stp	x12, x25, [x29, #72]
   1aae8:	aa0d03f2 	mov	x18, x13
   1aaec:	a90397bc 	stp	x28, x5, [x29, #56]
   1aaf0:	2a0603e5 	mov	w5, w6
   1aaf4:	aa0003fc 	mov	x28, x0
   1aaf8:	f81c83a8 	stur	x8, [x29, #-56]
   1aafc:	2a0703e8 	mov	w8, w7
   1ab00:	aa0103e0 	mov	x0, x1
   1ab04:	a905e7a8 	stp	x8, x25, [x29, #88]
   1ab08:	2a1303e8 	mov	w8, w19
   1ab0c:	2a1a03f9 	mov	w25, w26
   1ab10:	f9001ba8 	str	x8, [x29, #48]
   1ab14:	2a0403e8 	mov	w8, w4
   1ab18:	2a1b03fa 	mov	w26, w27
   1ab1c:	f90017a8 	str	x8, [x29, #40]
   1ab20:	2a0b03e8 	mov	w8, w11
   1ab24:	aa0303fb 	mov	x27, x3
   1ab28:	a97d0fa1 	ldp	x1, x3, [x29, #-48]
   1ab2c:	f90013a8 	str	x8, [x29, #32]
   1ab30:	a97e13a6 	ldp	x6, x4, [x29, #-32]
   1ab34:	2a0a03e7 	mov	w7, w10
   1ab38:	2a0f03e9 	mov	w9, w15
   1ab3c:	2a1703ef 	mov	w15, w23
   1ab40:	2a1803e8 	mov	w8, w24
   1ab44:	2a1103ea 	mov	w10, w17
   1ab48:	b85f03b7 	ldur	w23, [x29, #-16]
   1ab4c:	2a0203eb 	mov	w11, w2
   1ab50:	2a0e03ed 	mov	w13, w14
   1ab54:	2a1003ee 	mov	w14, w16
   1ab58:	a9012ba8 	stp	x8, x10, [x29, #16]
   1ab5c:	52800398 	mov	w24, #0x1c                  	// #28
   1ab60:	aa1e03ea 	mov	x10, x30
   1ab64:	aa1203ec 	mov	x12, x18
   1ab68:	f85c83a2 	ldur	x2, [x29, #-56]
   1ab6c:	a9507bfd 	ldp	x29, x30, [sp, #256]
   1ab70:	910443ff 	add	sp, sp, #0x110
   1ab74:	d61f0040 	br	x2
   1ab78:	f81a83b8 	stur	x24, [x29, #-88]
   1ab7c:	aa1e03f8 	mov	x24, x30
   1ab80:	aa1003f2 	mov	x18, x16
   1ab84:	a97e7bb0 	ldp	x16, x30, [x29, #-32]
   1ab88:	92409f28 	and	x8, x25, #0xffffffffff
   1ab8c:	f81c83b6 	stur	x22, [x29, #-56]
   1ab90:	aa1103f6 	mov	x22, x17
   1ab94:	aa0203f1 	mov	x17, x2
   1ab98:	a905cfe4 	stp	x4, x19, [sp, #88]
   1ab9c:	aa0003e2 	mov	x2, x0
   1aba0:	a939afba 	stp	x26, x11, [x29, #-104]
   1aba4:	8b080e8b 	add	x11, x20, x8, lsl #3
   1aba8:	aa0d03fa 	mov	x26, x13
   1abac:	a93b1ba9 	stp	x9, x6, [x29, #-80]
   1abb0:	f81c03aa 	stur	x10, [x29, #-64]
   1abb4:	f81903af 	stur	x15, [x29, #-112]
   1abb8:	b7f80119 	tbnz	x25, #63, 1abd8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x15c>
   1abbc:	a9402969 	ldp	x9, x10, [x11]
   1abc0:	aa0803f3 	mov	x19, x8
   1abc4:	aa1e03e6 	mov	x6, x30
   1abc8:	aa0503fe 	mov	x30, x5
   1abcc:	f9003fea 	str	x10, [sp, #120]
   1abd0:	aa1003ea 	mov	x10, x16
   1abd4:	1400001b 	b	1ac40 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x1c4>
   1abd8:	b9400569 	ldr	w9, [x11, #4]
   1abdc:	b940016a 	ldr	w10, [x11]
   1abe0:	aa1e03e6 	mov	x6, x30
   1abe4:	92405d4d 	and	x13, x10, #0xffffff
   1abe8:	f10005bf 	cmp	x13, #0x1
   1abec:	54002661 	b.ne	1b0b8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x63c>  // b.any
   1abf0:	aa098149 	orr	x9, x10, x9, lsl #32
   1abf4:	88dffd7f 	ldar	wzr, [x11]
   1abf8:	f94002ab 	ldr	x11, [x21]
   1abfc:	aa0503fe 	mov	x30, x5
   1ac00:	d358fd33 	lsr	x19, x9, #24
   1ac04:	8b130e8d 	add	x13, x20, x19, lsl #3
   1ac08:	a94029a9 	ldp	x9, x10, [x13]
   1ac0c:	f8287a8b 	str	x11, [x20, x8, lsl #3]
   1ac10:	d0000cab 	adrp	x11, 1b0000 <memcpy@GLIBC_2.17>
   1ac14:	f94082ad 	ldr	x13, [x21, #256]
   1ac18:	f90002a8 	str	x8, [x21]
   1ac1c:	3948316b 	ldrb	w11, [x11, #524]
   1ac20:	f9003fea 	str	x10, [sp, #120]
   1ac24:	910005a8 	add	x8, x13, #0x1
   1ac28:	aa1003ea 	mov	x10, x16
   1ac2c:	7100057f 	cmp	w11, #0x1
   1ac30:	f90082a8 	str	x8, [x21, #256]
   1ac34:	54002d81 	b.ne	1b1e4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x768>  // b.any
   1ac38:	f140211f 	cmp	x8, #0x8, lsl #12
   1ac3c:	54002d42 	b.cs	1b1e4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x768>  // b.hs, b.nlast
   1ac40:	aa1203f0 	mov	x16, x18
   1ac44:	aa0203f2 	mov	x18, x2
   1ac48:	aa0c03e5 	mov	x5, x12
   1ac4c:	aa0e03ec 	mov	x12, x14
   1ac50:	aa1103ee 	mov	x14, x17
   1ac54:	aa1603f1 	mov	x17, x22
   1ac58:	aa0703e4 	mov	x4, x7
   1ac5c:	aa1c03e7 	mov	x7, x28
   1ac60:	aa1703fc 	mov	x28, x23
   1ac64:	92409d28 	and	x8, x9, #0xffffffffff
   1ac68:	52909feb 	mov	w11, #0x84ff                	// #34047
   1ac6c:	8b080e82 	add	x2, x20, x8, lsl #3
   1ac70:	72a0620b 	movk	w11, #0x310, lsl #16
   1ac74:	b7f800e9 	tbnz	x9, #63, 1ac90 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x214>
   1ac78:	b9400049 	ldr	w9, [x2]
   1ac7c:	f81883a9 	stur	x9, [x29, #-120]
   1ac80:	b9400849 	ldr	w9, [x2, #8]
   1ac84:	f90043e9 	str	x9, [sp, #128]
   1ac88:	aa0803e9 	mov	x9, x8
   1ac8c:	14000020 	b	1ad0c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x290>
   1ac90:	a9069ffc 	stp	x28, x7, [sp, #104]
   1ac94:	aa0e03f9 	mov	x25, x14
   1ac98:	aa0c03fc 	mov	x28, x12
   1ac9c:	b940044d 	ldr	w13, [x2, #4]
   1aca0:	b940004e 	ldr	w14, [x2]
   1aca4:	92405dcf 	and	x15, x14, #0xffffff
   1aca8:	f10005ff 	cmp	x15, #0x1
   1acac:	54002481 	b.ne	1b13c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x6c0>  // b.any
   1acb0:	aa0d81c9 	orr	x9, x14, x13, lsl #32
   1acb4:	88dffc5f 	ldar	wzr, [x2]
   1acb8:	f94002ac 	ldr	x12, [x21]
   1acbc:	d358fd29 	lsr	x9, x9, #24
   1acc0:	8b090e8d 	add	x13, x20, x9, lsl #3
   1acc4:	b94001ae 	ldr	w14, [x13]
   1acc8:	b94009ad 	ldr	w13, [x13, #8]
   1accc:	f8287a8c 	str	x12, [x20, x8, lsl #3]
   1acd0:	d0000cac 	adrp	x12, 1b0000 <memcpy@GLIBC_2.17>
   1acd4:	f90002a8 	str	x8, [x21]
   1acd8:	f81883ae 	stur	x14, [x29, #-120]
   1acdc:	3948318c 	ldrb	w12, [x12, #524]
   1ace0:	f90043ed 	str	x13, [sp, #128]
   1ace4:	f94082ad 	ldr	x13, [x21, #256]
   1ace8:	7100059f 	cmp	w12, #0x1
   1acec:	910005a8 	add	x8, x13, #0x1
   1acf0:	f90082a8 	str	x8, [x21, #256]
   1acf4:	54002a81 	b.ne	1b244 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x7c8>  // b.any
   1acf8:	f140211f 	cmp	x8, #0x8, lsl #12
   1acfc:	54002a42 	b.cs	1b244 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x7c8>  // b.hs, b.nlast
   1ad00:	aa1c03ec 	mov	x12, x28
   1ad04:	a9469ffc 	ldp	x28, x7, [sp, #104]
   1ad08:	aa1903ee 	mov	x14, x25
   1ad0c:	eb0b013f 	cmp	x9, x11
   1ad10:	aa1a03e2 	mov	x2, x26
   1ad14:	540001e9 	b.ls	1ad50 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x2d4>  // b.plast
   1ad18:	f94006a8 	ldr	x8, [x21, #8]
   1ad1c:	aa1c03f9 	mov	x25, x28
   1ad20:	f8297a88 	str	x8, [x20, x9, lsl #3]
   1ad24:	d0000ca8 	adrp	x8, 1b0000 <memcpy@GLIBC_2.17>
   1ad28:	f94086af 	ldr	x15, [x21, #264]
   1ad2c:	3948310d 	ldrb	w13, [x8, #524]
   1ad30:	f90006a9 	str	x9, [x21, #8]
   1ad34:	910009e8 	add	x8, x15, #0x2
   1ad38:	710005bf 	cmp	w13, #0x1
   1ad3c:	f90086a8 	str	x8, [x21, #264]
   1ad40:	540018a1 	b.ne	1b054 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x5d8>  // b.any
   1ad44:	f140211f 	cmp	x8, #0x8, lsl #12
   1ad48:	54001862 	b.cs	1b054 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x5d8>  // b.hs, b.nlast
   1ad4c:	aa1903fc 	mov	x28, x25
   1ad50:	eb0b027f 	cmp	x19, x11
   1ad54:	540001a9 	b.ls	1ad88 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x30c>  // b.plast
   1ad58:	f94006a8 	ldr	x8, [x21, #8]
   1ad5c:	f8337a88 	str	x8, [x20, x19, lsl #3]
   1ad60:	d0000ca8 	adrp	x8, 1b0000 <memcpy@GLIBC_2.17>
   1ad64:	f94086a9 	ldr	x9, [x21, #264]
   1ad68:	3948310b 	ldrb	w11, [x8, #524]
   1ad6c:	f90006b3 	str	x19, [x21, #8]
   1ad70:	91000928 	add	x8, x9, #0x2
   1ad74:	7100057f 	cmp	w11, #0x1
   1ad78:	f90086a8 	str	x8, [x21, #264]
   1ad7c:	54001361 	b.ne	1afe8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x56c>  // b.any
   1ad80:	f140211f 	cmp	x8, #0x8, lsl #12
   1ad84:	54001322 	b.cs	1afe8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x56c>  // b.hs, b.nlast
   1ad88:	b85f03a8 	ldur	w8, [x29, #-16]
   1ad8c:	340005a8 	cbz	w8, 1ae40 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x3c4>
   1ad90:	f85c83b6 	ldur	x22, [x29, #-56]
   1ad94:	f9403fe9 	ldr	x9, [sp, #120]
   1ad98:	52800848 	mov	w8, #0x42                  	// #66
   1ad9c:	2a0e03ed 	mov	w13, w14
   1ada0:	a978bbb9 	ldp	x25, x14, [x29, #-120]
   1ada4:	a88122c9 	stp	x9, x8, [x22], #16
   1ada8:	2a0403e8 	mov	w8, w4
   1adac:	f90037a8 	str	x8, [x29, #104]
   1adb0:	f85a03a8 	ldur	x8, [x29, #-96]
   1adb4:	2a1003ef 	mov	w15, w16
   1adb8:	a905c7a5 	stp	x5, x17, [x29, #88]
   1adbc:	a97d17a4 	ldp	x4, x5, [x29, #-48]
   1adc0:	2a0803e8 	mov	w8, w8
   1adc4:	a904fba7 	stp	x7, x30, [x29, #72]
   1adc8:	2a0e03f0 	mov	w16, w14
   1adcc:	f9001ba8 	str	x8, [x29, #48]
   1add0:	a97b27a8 	ldp	x8, x9, [x29, #-80]
   1add4:	b85f03b7 	ldur	w23, [x29, #-16]
   1add8:	aa0303e0 	mov	x0, x3
   1addc:	aa0203ee 	mov	x14, x2
   1ade0:	2a0803e8 	mov	w8, w8
   1ade4:	2a0903e7 	mov	w7, w9
   1ade8:	f85c03a9 	ldur	x9, [x29, #-64]
   1adec:	f90017a8 	str	x8, [x29, #40]
   1adf0:	f85a83a8 	ldur	x8, [x29, #-88]
   1adf4:	2a0903eb 	mov	w11, w9
   1adf8:	2a0c03e9 	mov	w9, w12
   1adfc:	aa1803ec 	mov	x12, x24
   1ae00:	2a0803e8 	mov	w8, w8
   1ae04:	f90013a8 	str	x8, [x29, #32]
   1ae08:	2a1c03e8 	mov	w8, w28
   1ae0c:	2a1b03fc 	mov	w28, w27
   1ae10:	f9000fa8 	str	x8, [x29, #24]
   1ae14:	f85983a8 	ldur	x8, [x29, #-104]
   1ae18:	f94043fa 	ldr	x26, [sp, #128]
   1ae1c:	2a0803e8 	mov	w8, w8
   1ae20:	aa0803fb 	mov	x27, x8
   1ae24:	aa0103e8 	mov	x8, x1
   1ae28:	aa1203e1 	mov	x1, x18
   1ae2c:	aa0803e3 	mov	x3, x8
   1ae30:	f9000bb0 	str	x16, [x29, #16]
   1ae34:	a9507bfd 	ldp	x29, x30, [sp, #256]
   1ae38:	910443ff 	add	sp, sp, #0x110
   1ae3c:	17fff550 	b	1837c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0>
   1ae40:	a9038ff1 	stp	x17, x3, [sp, #56]
   1ae44:	f94016b7 	ldr	x23, [x21, #40]
   1ae48:	aa0203f9 	mov	x25, x2
   1ae4c:	a90017fb 	stp	x27, x5, [sp]
   1ae50:	f9000bfe 	str	x30, [sp, #16]
   1ae54:	a904cbe4 	stp	x4, x18, [sp, #72]
   1ae58:	f9001be1 	str	x1, [sp, #48]
   1ae5c:	f81f03b0 	stur	x16, [x29, #-16]
   1ae60:	f85903ba 	ldur	x26, [x29, #-112]
   1ae64:	f9000ff8 	str	x24, [sp, #24]
   1ae68:	f85c83a8 	ldur	x8, [x29, #-56]
   1ae6c:	a90233ee 	stp	x14, x12, [sp, #32]
   1ae70:	a9069ffc 	stp	x28, x7, [sp, #104]
   1ae74:	a97ecd18 	ldp	x24, x19, [x8, #-24]
   1ae78:	b4001a17 	cbz	x23, 1b1b8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x73c>
   1ae7c:	f8777a88 	ldr	x8, [x20, x23, lsl #3]
   1ae80:	f94096a9 	ldr	x9, [x21, #296]
   1ae84:	f90016a8 	str	x8, [x21, #40]
   1ae88:	d1008128 	sub	x8, x9, #0x20
   1ae8c:	f90096a8 	str	x8, [x21, #296]
   1ae90:	8b170e9c 	add	x28, x20, x23, lsl #3
   1ae94:	52801fe1 	mov	w1, #0xff                  	// #255
   1ae98:	52801c02 	mov	w2, #0xe0                  	// #224
   1ae9c:	91002380 	add	x0, x28, #0x8
   1aea0:	97ffa314 	bl	3af0 <memset@plt>
   1aea4:	f9403fe9 	ldr	x9, [sp, #120]
   1aea8:	52800028 	mov	w8, #0x1                   	// #1
   1aeac:	f85c83b6 	ldur	x22, [x29, #-56]
   1aeb0:	aa13810a 	orr	x10, x8, x19, lsl #32
   1aeb4:	f9000389 	str	x9, [x28]
   1aeb8:	d2c84009 	mov	x9, #0x420000000000        	// #72567767433216
   1aebc:	f2e0a009 	movk	x9, #0x500, lsl #48
   1aec0:	a90eab98 	stp	x24, x10, [x28, #232]
   1aec4:	aa0902e9 	orr	x9, x23, x9
   1aec8:	a93ea2c9 	stp	x9, x8, [x22, #-24]
   1aecc:	f94016a0 	ldr	x0, [x21, #40]
   1aed0:	b4001800 	cbz	x0, 1b1d0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x754>
   1aed4:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   1aed8:	f94096aa 	ldr	x10, [x21, #296]
   1aedc:	f90016a8 	str	x8, [x21, #40]
   1aee0:	d1008148 	sub	x8, x10, #0x20
   1aee4:	f90096a8 	str	x8, [x21, #296]
   1aee8:	8b000e88 	add	x8, x20, x0, lsl #3
   1aeec:	d2c0002a 	mov	x10, #0x100000000           	// #4294967296
   1aef0:	f85983b0 	ldur	x16, [x29, #-104]
   1aef4:	a9422fec 	ldp	x12, x11, [sp, #32]
   1aef8:	f85a83ae 	ldur	x14, [x29, #-88]
   1aefc:	a90f2909 	stp	x9, x10, [x8, #240]
   1af00:	f85883aa 	ldur	x10, [x29, #-120]
   1af04:	f94043e9 	ldr	x9, [sp, #128]
   1af08:	a946b7ef 	ldp	x15, x13, [sp, #104]
   1af0c:	a900250a 	stp	x10, x9, [x8]
   1af10:	2a1003e9 	mov	w9, w16
   1af14:	f94003ea 	ldr	x10, [sp]
   1af18:	a945c7f2 	ldp	x18, x17, [sp, #88]
   1af1c:	2a0a03ea 	mov	w10, w10
   1af20:	a9012909 	stp	x9, x10, [x8, #16]
   1af24:	f94023ea 	ldr	x10, [sp, #64]
   1af28:	f9402be9 	ldr	x9, [sp, #80]
   1af2c:	a902250a 	stp	x10, x9, [x8, #32]
   1af30:	f9401bea 	ldr	x10, [sp, #48]
   1af34:	f85d03a9 	ldur	x9, [x29, #-48]
   1af38:	a903250a 	stp	x10, x9, [x8, #48]
   1af3c:	f85d83aa 	ldur	x10, [x29, #-40]
   1af40:	f85e83a9 	ldur	x9, [x29, #-24]
   1af44:	a904250a 	stp	x10, x9, [x8, #64]
   1af48:	f85b83a9 	ldur	x9, [x29, #-72]
   1af4c:	f85e03aa 	ldur	x10, [x29, #-32]
   1af50:	2a0903e9 	mov	w9, w9
   1af54:	f9002909 	str	x9, [x8, #80]
   1af58:	f85c03a9 	ldur	x9, [x29, #-64]
   1af5c:	2a0903e9 	mov	w9, w9
   1af60:	a905a50a 	stp	x10, x9, [x8, #88]
   1af64:	f9400fea 	ldr	x10, [sp, #24]
   1af68:	2a0c03e9 	mov	w9, w12
   1af6c:	a906a50a 	stp	x10, x9, [x8, #104]
   1af70:	f85f03aa 	ldur	x10, [x29, #-16]
   1af74:	2a0b03e9 	mov	w9, w11
   1af78:	a907a519 	stp	x25, x9, [x8, #120]
   1af7c:	2a1a03e9 	mov	w9, w26
   1af80:	2a0a03ea 	mov	w10, w10
   1af84:	f900450a 	str	x10, [x8, #136]
   1af88:	2a0f03ea 	mov	w10, w15
   1af8c:	a9092909 	stp	x9, x10, [x8, #144]
   1af90:	f85b03aa 	ldur	x10, [x29, #-80]
   1af94:	2a0e03e9 	mov	w9, w14
   1af98:	2a0a03ea 	mov	w10, w10
   1af9c:	a90a2909 	stp	x9, x10, [x8, #160]
   1afa0:	f85a03a9 	ldur	x9, [x29, #-96]
   1afa4:	2a1203ea 	mov	w10, w18
   1afa8:	2a0903e9 	mov	w9, w9
   1afac:	a90b2909 	stp	x9, x10, [x8, #176]
   1afb0:	2a1103e9 	mov	w9, w17
   1afb4:	a90c3509 	stp	x9, x13, [x8, #192]
   1afb8:	a940abe9 	ldp	x9, x10, [sp, #8]
   1afbc:	a90d250a 	stp	x10, x9, [x8, #208]
   1afc0:	d2c70009 	mov	x9, #0x380000000000        	// #61572651155456
   1afc4:	f9401fea 	ldr	x10, [sp, #56]
   1afc8:	f2e0a009 	movk	x9, #0x500, lsl #48
   1afcc:	aa090000 	orr	x0, x0, x9
   1afd0:	f94027e9 	ldr	x9, [sp, #72]
   1afd4:	2a0903e9 	mov	w9, w9
   1afd8:	a90e250a 	stp	x10, x9, [x8, #224]
   1afdc:	a9507bfd 	ldp	x29, x30, [sp, #256]
   1afe0:	910443ff 	add	sp, sp, #0x110
   1afe4:	d65f03c0 	ret
   1afe8:	aa1403e0 	mov	x0, x20
   1afec:	aa0103ef 	mov	x15, x1
   1aff0:	aa1503e1 	mov	x1, x21
   1aff4:	52800022 	mov	w2, #0x1                   	// #1
   1aff8:	a90413e3 	stp	x3, x4, [sp, #64]
   1affc:	aa0603eb 	mov	x11, x6
   1b000:	f9002bf2 	str	x18, [sp, #80]
   1b004:	aa1003e9 	mov	x9, x16
   1b008:	aa1e03f9 	mov	x25, x30
   1b00c:	a901bbf8 	stp	x24, x14, [sp, #24]
   1b010:	a9069ffc 	stp	x28, x7, [sp, #104]
   1b014:	f90017ec 	str	x12, [sp, #40]
   1b018:	aa0503ec 	mov	x12, x5
   1b01c:	f9001ff1 	str	x17, [sp, #56]
   1b020:	97ffa510 	bl	4460 <heap_hand>
   1b024:	a9438ff1 	ldp	x17, x3, [sp, #56]
   1b028:	aa0c03e5 	mov	x5, x12
   1b02c:	a944cbe4 	ldp	x4, x18, [sp, #72]
   1b030:	aa1a03e2 	mov	x2, x26
   1b034:	a9469ffc 	ldp	x28, x7, [sp, #104]
   1b038:	aa1903fe 	mov	x30, x25
   1b03c:	a94233ee 	ldp	x14, x12, [sp, #32]
   1b040:	aa0f03e1 	mov	x1, x15
   1b044:	f9400ff8 	ldr	x24, [sp, #24]
   1b048:	aa0903f0 	mov	x16, x9
   1b04c:	aa0b03e6 	mov	x6, x11
   1b050:	17ffff4e 	b	1ad88 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x30c>
   1b054:	aa1403e0 	mov	x0, x20
   1b058:	aa0103e8 	mov	x8, x1
   1b05c:	aa1503e1 	mov	x1, x21
   1b060:	52800022 	mov	w2, #0x1                   	// #1
   1b064:	a90413e3 	stp	x3, x4, [sp, #64]
   1b068:	aa1003e9 	mov	x9, x16
   1b06c:	f9002bf2 	str	x18, [sp, #80]
   1b070:	a901bbf8 	stp	x24, x14, [sp, #24]
   1b074:	f9003be7 	str	x7, [sp, #112]
   1b078:	a902a3ec 	stp	x12, x8, [sp, #40]
   1b07c:	aa0503ec 	mov	x12, x5
   1b080:	f9000bfe 	str	x30, [sp, #16]
   1b084:	f9001ff1 	str	x17, [sp, #56]
   1b088:	97ffa4f6 	bl	4460 <heap_hand>
   1b08c:	a9438ff1 	ldp	x17, x3, [sp, #56]
   1b090:	aa0c03e5 	mov	x5, x12
   1b094:	a94163fe 	ldp	x30, x24, [sp, #16]
   1b098:	aa1a03e2 	mov	x2, x26
   1b09c:	a944cbe4 	ldp	x4, x18, [sp, #72]
   1b0a0:	aa0903f0 	mov	x16, x9
   1b0a4:	a94287ec 	ldp	x12, x1, [sp, #40]
   1b0a8:	f94013ee 	ldr	x14, [sp, #32]
   1b0ac:	f85e83a6 	ldur	x6, [x29, #-24]
   1b0b0:	f9403be7 	ldr	x7, [sp, #112]
   1b0b4:	17ffff26 	b	1ad4c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x2d0>
   1b0b8:	aa098148 	orr	x8, x10, x9, lsl #32
   1b0bc:	a9041fe3 	stp	x3, x7, [sp, #64]
   1b0c0:	aa1403e0 	mov	x0, x20
   1b0c4:	a90287ee 	stp	x14, x1, [sp, #40]
   1b0c8:	aa1503e1 	mov	x1, x21
   1b0cc:	52800044 	mov	w4, #0x2                   	// #2
   1b0d0:	d358fd0a 	lsr	x10, x8, #24
   1b0d4:	f9002be2 	str	x2, [sp, #80]
   1b0d8:	aa1903e2 	mov	x2, x25
   1b0dc:	aa1003eb 	mov	x11, x16
   1b0e0:	f90013f1 	str	x17, [sp, #32]
   1b0e4:	aa1203ef 	mov	x15, x18
   1b0e8:	8b0a0e88 	add	x8, x20, x10, lsl #3
   1b0ec:	aa0a03e3 	mov	x3, x10
   1b0f0:	aa0603ea 	mov	x10, x6
   1b0f4:	f90037f7 	str	x23, [sp, #104]
   1b0f8:	aa0503f9 	mov	x25, x5
   1b0fc:	a9402109 	ldp	x9, x8, [x8]
   1b100:	a90723fc 	stp	x28, x8, [sp, #112]
   1b104:	97ffa50a 	bl	452c <span_fade>
   1b108:	aa0c03e5 	mov	x5, x12
   1b10c:	a94413e3 	ldp	x3, x4, [sp, #64]
   1b110:	a94287ec 	ldp	x12, x1, [sp, #40]
   1b114:	aa1603f1 	mov	x17, x22
   1b118:	a9469ffc 	ldp	x28, x7, [sp, #104]
   1b11c:	aa1903fe 	mov	x30, x25
   1b120:	f9402bf2 	ldr	x18, [sp, #80]
   1b124:	f94013ee 	ldr	x14, [sp, #32]
   1b128:	aa0f03f0 	mov	x16, x15
   1b12c:	aa0a03e6 	mov	x6, x10
   1b130:	aa0b03ea 	mov	x10, x11
   1b134:	aa1f03f3 	mov	x19, xzr
   1b138:	17fffecb 	b	1ac64 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x1e8>
   1b13c:	aa0d81c8 	orr	x8, x14, x13, lsl #32
   1b140:	f9001be1 	str	x1, [sp, #48]
   1b144:	aa1403e0 	mov	x0, x20
   1b148:	aa1503e1 	mov	x1, x21
   1b14c:	aa0903e2 	mov	x2, x9
   1b150:	aa1003ef 	mov	x15, x16
   1b154:	d358fd0d 	lsr	x13, x8, #24
   1b158:	8b0d0e88 	add	x8, x20, x13, lsl #3
   1b15c:	b940010c 	ldr	w12, [x8]
   1b160:	b9400908 	ldr	w8, [x8, #8]
   1b164:	f81883ac 	stur	x12, [x29, #-120]
   1b168:	a90413e3 	stp	x3, x4, [sp, #64]
   1b16c:	aa0d03e3 	mov	x3, x13
   1b170:	52800044 	mov	w4, #0x2                   	// #2
   1b174:	f90043e8 	str	x8, [sp, #128]
   1b178:	aa0603ed 	mov	x13, x6
   1b17c:	f9002bf2 	str	x18, [sp, #80]
   1b180:	a900fbe5 	stp	x5, x30, [sp, #8]
   1b184:	f9001ff1 	str	x17, [sp, #56]
   1b188:	97ffa4e9 	bl	452c <span_fade>
   1b18c:	a9438ff1 	ldp	x17, x3, [sp, #56]
   1b190:	aa1c03ec 	mov	x12, x28
   1b194:	a940fbe5 	ldp	x5, x30, [sp, #8]
   1b198:	aa0f03f0 	mov	x16, x15
   1b19c:	a944cbe4 	ldp	x4, x18, [sp, #72]
   1b1a0:	aa0d03e6 	mov	x6, x13
   1b1a4:	a9469ffc 	ldp	x28, x7, [sp, #104]
   1b1a8:	aa1903ee 	mov	x14, x25
   1b1ac:	f9401be1 	ldr	x1, [sp, #48]
   1b1b0:	aa1a03e2 	mov	x2, x26
   1b1b4:	17fffee7 	b	1ad50 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x2d4>
   1b1b8:	aa1403e0 	mov	x0, x20
   1b1bc:	aa1503e1 	mov	x1, x21
   1b1c0:	528000a2 	mov	w2, #0x5                   	// #5
   1b1c4:	97ffa66a 	bl	4b6c <heap_alloc_miss>
   1b1c8:	aa0003f7 	mov	x23, x0
   1b1cc:	17ffff31 	b	1ae90 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x414>
   1b1d0:	aa1403e0 	mov	x0, x20
   1b1d4:	aa1503e1 	mov	x1, x21
   1b1d8:	528000a2 	mov	w2, #0x5                   	// #5
   1b1dc:	97ffa664 	bl	4b6c <heap_alloc_miss>
   1b1e0:	17ffff42 	b	1aee8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x46c>
   1b1e4:	aa1403e0 	mov	x0, x20
   1b1e8:	f9002be2 	str	x2, [sp, #80]
   1b1ec:	aa0103e8 	mov	x8, x1
   1b1f0:	aa1503e1 	mov	x1, x21
   1b1f4:	2a1f03e2 	mov	w2, wzr
   1b1f8:	a9041fe3 	stp	x3, x7, [sp, #64]
   1b1fc:	a901c7f8 	stp	x24, x17, [sp, #24]
   1b200:	aa0603ed 	mov	x13, x6
   1b204:	aa1203f9 	mov	x25, x18
   1b208:	a906f3f7 	stp	x23, x28, [sp, #104]
   1b20c:	a902a3ee 	stp	x14, x8, [sp, #40]
   1b210:	f9000bfe 	str	x30, [sp, #16]
   1b214:	f9001ff6 	str	x22, [sp, #56]
   1b218:	97ffa492 	bl	4460 <heap_hand>
   1b21c:	a9438ff1 	ldp	x17, x3, [sp, #56]
   1b220:	aa0c03e5 	mov	x5, x12
   1b224:	a94163fe 	ldp	x30, x24, [sp, #16]
   1b228:	aa1903f0 	mov	x16, x25
   1b22c:	a944cbe4 	ldp	x4, x18, [sp, #72]
   1b230:	aa0d03e6 	mov	x6, x13
   1b234:	a94287ec 	ldp	x12, x1, [sp, #40]
   1b238:	f94013ee 	ldr	x14, [sp, #32]
   1b23c:	a9469ffc 	ldp	x28, x7, [sp, #104]
   1b240:	17fffe89 	b	1ac64 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x1e8>
   1b244:	aa1403e0 	mov	x0, x20
   1b248:	aa0103e8 	mov	x8, x1
   1b24c:	aa1503e1 	mov	x1, x21
   1b250:	2a1f03e2 	mov	w2, wzr
   1b254:	a90413e3 	stp	x3, x4, [sp, #64]
   1b258:	aa1003ee 	mov	x14, x16
   1b25c:	f9002bf2 	str	x18, [sp, #80]
   1b260:	aa0503ec 	mov	x12, x5
   1b264:	a90163fe 	stp	x30, x24, [sp, #16]
   1b268:	a90347e8 	stp	x8, x17, [sp, #48]
   1b26c:	97ffa47d 	bl	4460 <heap_hand>
   1b270:	a9438ff1 	ldp	x17, x3, [sp, #56]
   1b274:	aa0c03e5 	mov	x5, x12
   1b278:	a94163fe 	ldp	x30, x24, [sp, #16]
   1b27c:	aa0e03f0 	mov	x16, x14
   1b280:	a944cbe4 	ldp	x4, x18, [sp, #72]
   1b284:	f9401be1 	ldr	x1, [sp, #48]
   1b288:	f85e83a6 	ldur	x6, [x29, #-24]
   1b28c:	17fffe9d 	b	1ad00 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x284>

