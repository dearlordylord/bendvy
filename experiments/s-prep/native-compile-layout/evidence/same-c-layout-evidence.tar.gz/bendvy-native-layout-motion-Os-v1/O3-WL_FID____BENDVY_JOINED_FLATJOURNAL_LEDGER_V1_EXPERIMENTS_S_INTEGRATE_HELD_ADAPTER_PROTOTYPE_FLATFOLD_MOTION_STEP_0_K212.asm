   1b294:	d102c3ff 	sub	sp, sp, #0xb0
   1b298:	a90a7bfd 	stp	x29, x30, [sp, #160]
   1b29c:	910283fd 	add	x29, sp, #0xa0
   1b2a0:	a93eb3af 	stp	x15, x12, [x29, #-24]
   1b2a4:	a943c7b0 	ldp	x16, x17, [x29, #56]
   1b2a8:	f81e03aa 	stur	x10, [x29, #-32]
   1b2ac:	aa0603ea 	mov	x10, x6
   1b2b0:	f9400ba2 	ldr	x2, [x29, #16]
   1b2b4:	a9449bb2 	ldp	x18, x6, [x29, #72]
   1b2b8:	b85f82cc 	ldur	w12, [x22, #-8]
   1b2bc:	a942fbb3 	ldp	x19, x30, [x29, #40]
   1b2c0:	a941bfb8 	ldp	x24, x15, [x29, #24]
   1b2c4:	340003b7 	cbz	w23, 1b338 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K212+0xa4>
   1b2c8:	52800788 	mov	w8, #0x3c                  	// #60
   1b2cc:	2a1903f9 	mov	w25, w25
   1b2d0:	2a1a03fa 	mov	w26, w26
   1b2d4:	a93fa2cc 	stp	x12, x8, [x22, #-8]
   1b2d8:	2a1e03e8 	mov	w8, w30
   1b2dc:	2a1303ec 	mov	w12, w19
   1b2e0:	a902a3ac 	stp	x12, x8, [x29, #40]
   1b2e4:	2a0f03e8 	mov	w8, w15
   1b2e8:	a9049bb2 	stp	x18, x6, [x29, #72]
   1b2ec:	aa0a03e6 	mov	x6, x10
   1b2f0:	a97e33aa 	ldp	x10, x12, [x29, #-32]
   1b2f4:	2a0c03ef 	mov	w15, w12
   1b2f8:	2a1803ec 	mov	w12, w24
   1b2fc:	2a0503e5 	mov	w5, w5
   1b300:	a901a3ac 	stp	x12, x8, [x29, #24]
   1b304:	2a0203e8 	mov	w8, w2
   1b308:	f85f03ac 	ldur	x12, [x29, #-16]
   1b30c:	2a0703e7 	mov	w7, w7
   1b310:	2a0b03eb 	mov	w11, w11
   1b314:	a903c7b0 	stp	x16, x17, [x29, #56]
   1b318:	2a0d03ed 	mov	w13, w13
   1b31c:	2a0e03ee 	mov	w14, w14
   1b320:	2a0903e9 	mov	w9, w9
   1b324:	910022d6 	add	x22, x22, #0x8
   1b328:	f9000ba8 	str	x8, [x29, #16]
   1b32c:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   1b330:	9102c3ff 	add	sp, sp, #0xb0
   1b334:	17fff158 	b	17894 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0>
   1b338:	a93c4fa2 	stp	x2, x19, [x29, #-64]
   1b33c:	f94016a8 	ldr	x8, [x21, #40]
   1b340:	a93d7baf 	stp	x15, x30, [x29, #-48]
   1b344:	a90447f2 	stp	x18, x17, [sp, #64]
   1b348:	f9002bf0 	str	x16, [sp, #80]
   1b34c:	f81b83a9 	stur	x9, [x29, #-72]
   1b350:	a97e26d7 	ldp	x23, x9, [x22, #-32]
   1b354:	b4000a88 	cbz	x8, 1b4a4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K212+0x210>
   1b358:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   1b35c:	f94096b1 	ldr	x17, [x21, #296]
   1b360:	f90016b0 	str	x16, [x21, #40]
   1b364:	d1008230 	sub	x16, x17, #0x20
   1b368:	f90096b0 	str	x16, [x21, #296]
   1b36c:	52800031 	mov	w17, #0x1                   	// #1
   1b370:	8b080e90 	add	x16, x20, x8, lsl #3
   1b374:	6f07e7e0 	movi	v0.2d, #0xffffffffffffffff
   1b378:	aa098229 	orr	x9, x17, x9, lsl #32
   1b37c:	f900020c 	str	x12, [x16]
   1b380:	a90ea617 	stp	x23, x9, [x16, #232]
   1b384:	d2c78009 	mov	x9, #0x3c0000000000        	// #65970697666560
   1b388:	f2e0a009 	movk	x9, #0x500, lsl #48
   1b38c:	3c8d8200 	stur	q0, [x16, #216]
   1b390:	aa090117 	orr	x23, x8, x9
   1b394:	3c8c8200 	stur	q0, [x16, #200]
   1b398:	3c8b8200 	stur	q0, [x16, #184]
   1b39c:	3c8a8200 	stur	q0, [x16, #168]
   1b3a0:	3c898200 	stur	q0, [x16, #152]
   1b3a4:	3c888200 	stur	q0, [x16, #136]
   1b3a8:	3c878200 	stur	q0, [x16, #120]
   1b3ac:	3c868200 	stur	q0, [x16, #104]
   1b3b0:	3c858200 	stur	q0, [x16, #88]
   1b3b4:	3c848200 	stur	q0, [x16, #72]
   1b3b8:	3c838200 	stur	q0, [x16, #56]
   1b3bc:	3c828200 	stur	q0, [x16, #40]
   1b3c0:	3c818200 	stur	q0, [x16, #24]
   1b3c4:	3c808200 	stur	q0, [x16, #8]
   1b3c8:	a93e46d7 	stp	x23, x17, [x22, #-32]
   1b3cc:	f94016a8 	ldr	x8, [x21, #40]
   1b3d0:	b40008a8 	cbz	x8, 1b4e4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K212+0x250>
   1b3d4:	f8687a89 	ldr	x9, [x20, x8, lsl #3]
   1b3d8:	f94096ac 	ldr	x12, [x21, #296]
   1b3dc:	f90016a9 	str	x9, [x21, #40]
   1b3e0:	d1008189 	sub	x9, x12, #0x20
   1b3e4:	f90096a9 	str	x9, [x21, #296]
   1b3e8:	8b080e90 	add	x16, x20, x8, lsl #3
   1b3ec:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
   1b3f0:	2a1a03ec 	mov	w12, w26
   1b3f4:	a97c4bb5 	ldp	x21, x18, [x29, #-64]
   1b3f8:	f9007209 	str	x9, [x16, #224]
   1b3fc:	2a1903e9 	mov	w9, w25
   1b400:	a9003209 	stp	x9, x12, [x16]
   1b404:	2a0503e9 	mov	w9, w5
   1b408:	a9042a09 	stp	x9, x10, [x16, #64]
   1b40c:	2a0703e9 	mov	w9, w7
   1b410:	f9002a09 	str	x9, [x16, #80]
   1b414:	a97e2ba9 	ldp	x9, x10, [x29, #-32]
   1b418:	a97d47af 	ldp	x15, x17, [x29, #-48]
   1b41c:	a901721b 	stp	x27, x28, [x16, #16]
   1b420:	a9020600 	stp	x0, x1, [x16, #32]
   1b424:	f9002e09 	str	x9, [x16, #88]
   1b428:	2a0b03e9 	mov	w9, w11
   1b42c:	2a0e03eb 	mov	w11, w14
   1b430:	f9003209 	str	x9, [x16, #96]
   1b434:	f85f03a9 	ldur	x9, [x29, #-16]
   1b438:	a9031203 	stp	x3, x4, [x16, #48]
   1b43c:	f9003609 	str	x9, [x16, #104]
   1b440:	2a0d03e9 	mov	w9, w13
   1b444:	a9072e09 	stp	x9, x11, [x16, #112]
   1b448:	f85b83a9 	ldur	x9, [x29, #-72]
   1b44c:	2a0a03eb 	mov	w11, w10
   1b450:	2a1203ea 	mov	w10, w18
   1b454:	2a0903e9 	mov	w9, w9
   1b458:	a9082e09 	stp	x9, x11, [x16, #128]
   1b45c:	2a1503e9 	mov	w9, w21
   1b460:	2a1803eb 	mov	w11, w24
   1b464:	a9092e09 	stp	x9, x11, [x16, #144]
   1b468:	2a0f03e9 	mov	w9, w15
   1b46c:	a90a2a09 	stp	x9, x10, [x16, #160]
   1b470:	2a1103e9 	mov	w9, w17
   1b474:	f9005a09 	str	x9, [x16, #176]
   1b478:	a944abe9 	ldp	x9, x10, [sp, #72]
   1b47c:	a90ba60a 	stp	x10, x9, [x16, #184]
   1b480:	f94023e9 	ldr	x9, [sp, #64]
   1b484:	a90c9a09 	stp	x9, x6, [x16, #200]
   1b488:	d2c54009 	mov	x9, #0x2a0000000000        	// #46179488366592
   1b48c:	f2e0a009 	movk	x9, #0x500, lsl #48
   1b490:	aa090100 	orr	x0, x8, x9
   1b494:	f9006e17 	str	x23, [x16, #216]
   1b498:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   1b49c:	9102c3ff 	add	sp, sp, #0xb0
   1b4a0:	d65f03c0 	ret
   1b4a4:	a90303e1 	stp	x1, x0, [sp, #48]
   1b4a8:	aa1403e0 	mov	x0, x20
   1b4ac:	aa1503e1 	mov	x1, x21
   1b4b0:	528000a2 	mov	w2, #0x5                   	// #5
   1b4b4:	a9009be7 	stp	x7, x6, [sp, #8]
   1b4b8:	a9022be3 	stp	x3, x10, [sp, #32]
   1b4bc:	f90003e4 	str	x4, [sp]
   1b4c0:	f9000fe5 	str	x5, [sp, #24]
   1b4c4:	97ffa673 	bl	4e90 <heap_alloc_miss>
   1b4c8:	a94117e6 	ldp	x6, x5, [sp, #16]
   1b4cc:	aa0003e8 	mov	x8, x0
   1b4d0:	a9401fe4 	ldp	x4, x7, [sp]
   1b4d4:	f94013e3 	ldr	x3, [sp, #32]
   1b4d8:	a94287ea 	ldp	x10, x1, [sp, #40]
   1b4dc:	f9401fe0 	ldr	x0, [sp, #56]
   1b4e0:	17ffffa3 	b	1b36c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K212+0xd8>
   1b4e4:	a90303e1 	stp	x1, x0, [sp, #48]
   1b4e8:	aa1403e0 	mov	x0, x20
   1b4ec:	aa1503e1 	mov	x1, x21
   1b4f0:	528000a2 	mov	w2, #0x5                   	// #5
   1b4f4:	a90117e6 	stp	x6, x5, [sp, #16]
   1b4f8:	aa0403e9 	mov	x9, x4
   1b4fc:	a9022be3 	stp	x3, x10, [sp, #32]
   1b500:	aa0703f5 	mov	x21, x7
   1b504:	97ffa663 	bl	4e90 <heap_alloc_miss>
   1b508:	a94117e6 	ldp	x6, x5, [sp, #16]
   1b50c:	aa0003e8 	mov	x8, x0
   1b510:	a94287ea 	ldp	x10, x1, [sp, #40]
   1b514:	aa1503e7 	mov	x7, x21
   1b518:	f94013e3 	ldr	x3, [sp, #32]
   1b51c:	f9401fe0 	ldr	x0, [sp, #56]
   1b520:	aa0903e4 	mov	x4, x9
   1b524:	17ffffb1 	b	1b3e8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K212+0x154>

