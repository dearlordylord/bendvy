   1837c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
   18380:	910003fd 	mov	x29, sp
   18384:	d10a03ff 	sub	sp, sp, #0x280
   18388:	a933bfa9 	stp	x9, x15, [x29, #-200]
   1838c:	aa0e03e2 	mov	x2, x14
   18390:	aa0d03f3 	mov	x19, x13
   18394:	aa1603f2 	mov	x18, x22
   18398:	a9463bad 	ldp	x13, x14, [x29, #96]
   1839c:	a94543b8 	ldp	x24, x16, [x29, #80]
   183a0:	f94027be 	ldr	x30, [x29, #72]
   183a4:	a942a7a8 	ldp	x8, x9, [x29, #40]
   183a8:	6b19037f 	cmp	w27, w25
   183ac:	a941dbb1 	ldp	x17, x22, [x29, #24]
   183b0:	f9400baf 	ldr	x15, [x29, #16]
   183b4:	a93513b9 	stp	x25, x4, [x29, #-176]
   183b8:	aa1c03e4 	mov	x4, x28
   183bc:	f81483a8 	stur	x8, [x29, #-184]
   183c0:	54000a01 	b.ne	18500 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x184>  // b.any
   183c4:	51000748 	sub	w8, w26, #0x1
   183c8:	6b07011f 	cmp	w8, w7
   183cc:	540009a2 	b.cs	18500 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x184>  // b.hs, b.nlast
   183d0:	6b0b035f 	cmp	w26, w11
   183d4:	54000968 	b.hi	18500 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x184>  // b.pmore
   183d8:	2a1303f3 	mov	w19, w19
   183dc:	f100067f 	cmp	x19, #0x1
   183e0:	54000ec1 	b.ne	185b8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x23c>  // b.any
   183e4:	f81003a9 	stur	x9, [x29, #-256]
   183e8:	92409c69 	and	x9, x3, #0xffffffffff
   183ec:	f900bbf6 	str	x22, [sp, #368]
   183f0:	a93297ac 	stp	x12, x5, [x29, #-216]
   183f4:	f90083e9 	str	x9, [sp, #256]
   183f8:	b6f80083 	tbz	x3, #63, 18408 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x8c>
   183fc:	f94083e9 	ldr	x9, [sp, #256]
   18400:	f8697a89 	ldr	x9, [x20, x9, lsl #3]
   18404:	d358fd29 	lsr	x9, x9, #24
   18408:	f85583ac 	ldur	x12, [x29, #-168]
   1840c:	aa1e03f6 	mov	x22, x30
   18410:	92409d93 	and	x19, x12, #0xffffffffff
   18414:	b6f8004c 	tbz	x12, #63, 1841c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xa0>
   18418:	f8737a9f 	ldr	xzr, [x20, x19, lsl #3]
   1841c:	f85303ac 	ldur	x12, [x29, #-208]
   18420:	92409d9e 	and	x30, x12, #0xffffffffff
   18424:	b6f8004c 	tbz	x12, #63, 1842c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xb0>
   18428:	f87e7a9f 	ldr	xzr, [x20, x30, lsl #3]
   1842c:	a930bfaa 	stp	x10, x15, [x29, #-248]
   18430:	92409ccf 	and	x15, x6, #0xffffffffff
   18434:	b6f80046 	tbz	x6, #63, 1843c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xc0>
   18438:	f86f7a9f 	ldr	xzr, [x20, x15, lsl #3]
   1843c:	d368fc6a 	lsr	x10, x3, #40
   18440:	1280000c 	mov	w12, #0xffffffff            	// #-1
   18444:	8b090e89 	add	x9, x20, x9, lsl #3
   18448:	1aca218a 	lsl	w10, w12, w10
   1844c:	0a2a010a 	bic	w10, w8, w10
   18450:	b86a5929 	ldr	w9, [x9, w10, uxtw #2]
   18454:	340019c9 	cbz	w9, 1878c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x410>
   18458:	f90077ef 	str	x15, [sp, #232]
   1845c:	92409c0f 	and	x15, x0, #0xffffffffff
   18460:	aa1103e5 	mov	x5, x17
   18464:	aa0f03e9 	mov	x9, x15
   18468:	f900b7e2 	str	x2, [sp, #360]
   1846c:	b6f80060 	tbz	x0, #63, 18478 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xfc>
   18470:	f86f7a89 	ldr	x9, [x20, x15, lsl #3]
   18474:	d358fd29 	lsr	x9, x9, #24
   18478:	d368b00a 	ubfx	x10, x0, #40, #5
   1847c:	9280000c 	mov	x12, #0xffffffffffffffff    	// #-1
   18480:	5100054a 	sub	w10, w10, #0x1
   18484:	9aca2191 	lsl	x17, x12, x10
   18488:	8b090e8c 	add	x12, x20, x9, lsl #3
   1848c:	0a310108 	bic	w8, w8, w17
   18490:	531f7908 	lsl	w8, w8, #1
   18494:	8b284e8a 	add	x10, x20, w8, uxtw #3
   18498:	8b284d88 	add	x8, x12, w8, uxtw #3
   1849c:	8b090d49 	add	x9, x10, x9, lsl #3
   184a0:	f9400502 	ldr	x2, [x8, #8]
   184a4:	b940012a 	ldr	w10, [x9]
   184a8:	a9007d3f 	stp	xzr, xzr, [x9]
   184ac:	3400256a 	cbz	w10, 18958 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x5dc>
   184b0:	92409c48 	and	x8, x2, #0xffffffffff
   184b4:	a90b7bf1 	stp	x17, x30, [sp, #176]
   184b8:	52909ff1 	mov	w17, #0x84ff                	// #34047
   184bc:	8b080e8a 	add	x10, x20, x8, lsl #3
   184c0:	72a06211 	movk	w17, #0x310, lsl #16
   184c4:	a90dbfeb 	stp	x11, x15, [sp, #216]
   184c8:	f9007bf5 	str	x21, [sp, #240]
   184cc:	b900cff7 	str	w23, [sp, #204]
   184d0:	f90063f3 	str	x19, [sp, #192]
   184d4:	f900b3e3 	str	x3, [sp, #352]
   184d8:	a91487e0 	stp	x0, x1, [sp, #328]
   184dc:	a91363e4 	stp	x4, x24, [sp, #304]
   184e0:	f90087e7 	str	x7, [sp, #264]
   184e4:	a9126fed 	stp	x13, x27, [sp, #288]
   184e8:	f9006bee 	str	x14, [sp, #208]
   184ec:	b7f828a2 	tbnz	x2, #63, 18a00 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x684>
   184f0:	a9402d4c 	ldp	x12, x11, [x10]
   184f4:	aa0803e9 	mov	x9, x8
   184f8:	aa1603ef 	mov	x15, x22
   184fc:	14000158 	b	18a5c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x6e0>
   18500:	34000b77 	cbz	w23, 1866c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x2f0>
   18504:	2a0e03e8 	mov	w8, w14
   18508:	aa1003fc 	mov	x28, x16
   1850c:	aa1e03f0 	mov	x16, x30
   18510:	aa0903fe 	mov	x30, x9
   18514:	528007e9 	mov	w9, #0x3f                  	// #63
   18518:	aa1803ee 	mov	x14, x24
   1851c:	aa0c03f8 	mov	x24, x12
   18520:	aa1103ec 	mov	x12, x17
   18524:	a9002648 	stp	x8, x9, [x18]
   18528:	aa1c03e9 	mov	x9, x28
   1852c:	2a1b03e8 	mov	w8, w27
   18530:	aa0c03fb 	mov	x27, x12
   18534:	a904b7a9 	stp	x9, x13, [x29, #72]
   18538:	a973b3a9 	ldp	x9, x12, [x29, #-200]
   1853c:	aa0103fc 	mov	x28, x1
   18540:	a903bbb0 	stp	x16, x14, [x29, #56]
   18544:	aa0503f1 	mov	x17, x5
   18548:	aa0403e5 	mov	x5, x4
   1854c:	aa0603e4 	mov	x4, x6
   18550:	aa0a03e6 	mov	x6, x10
   18554:	2a0c03ee 	mov	w14, w12
   18558:	a97507ac 	ldp	x12, x1, [x29, #-176]
   1855c:	2a0903ed 	mov	w13, w9
   18560:	2a1a03e9 	mov	w9, w26
   18564:	2a0503ea 	mov	w10, w5
   18568:	2a1e03f0 	mov	w16, w30
   1856c:	2a0703e5 	mov	w5, w7
   18570:	2a0b03e7 	mov	w7, w11
   18574:	2a0c03ec 	mov	w12, w12
   18578:	2a1303eb 	mov	w11, w19
   1857c:	aa0803f9 	mov	x25, x8
   18580:	a902a7ac 	stp	x12, x9, [x29, #40]
   18584:	f85483ac 	ldur	x12, [x29, #-184]
   18588:	2a0f03e9 	mov	w9, w15
   1858c:	2a1b03ef 	mov	w15, w27
   18590:	aa0a03fa 	mov	x26, x10
   18594:	aa0003fb 	mov	x27, x0
   18598:	2a0c03ec 	mov	w12, w12
   1859c:	aa0303e0 	mov	x0, x3
   185a0:	aa1103e3 	mov	x3, x17
   185a4:	a901c3ac 	stp	x12, x16, [x29, #24]
   185a8:	2a1603f0 	mov	w16, w22
   185ac:	91004256 	add	x22, x18, #0x10
   185b0:	aa1803ea 	mov	x10, x24
   185b4:	1400009e 	b	1882c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x4b0>
   185b8:	34001457 	cbz	w23, 18840 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x4c4>
   185bc:	2a0e03e8 	mov	w8, w14
   185c0:	aa1003fc 	mov	x28, x16
   185c4:	aa0903f0 	mov	x16, x9
   185c8:	528007a9 	mov	w9, #0x3d                  	// #61
   185cc:	aa1803ee 	mov	x14, x24
   185d0:	aa0c03f8 	mov	x24, x12
   185d4:	aa1103ec 	mov	x12, x17
   185d8:	aa0003f1 	mov	x17, x0
   185dc:	aa0303e0 	mov	x0, x3
   185e0:	aa0503e3 	mov	x3, x5
   185e4:	aa0403e5 	mov	x5, x4
   185e8:	a9002648 	stp	x8, x9, [x18]
   185ec:	aa1c03e9 	mov	x9, x28
   185f0:	aa0603e4 	mov	x4, x6
   185f4:	aa0a03e6 	mov	x6, x10
   185f8:	2a0503ea 	mov	w10, w5
   185fc:	a904b7a9 	stp	x9, x13, [x29, #72]
   18600:	2a0703e5 	mov	w5, w7
   18604:	2a0b03e7 	mov	w7, w11
   18608:	a973afa9 	ldp	x9, x11, [x29, #-200]
   1860c:	aa0103fc 	mov	x28, x1
   18610:	a903bbbe 	stp	x30, x14, [x29, #56]
   18614:	2a1b03e8 	mov	w8, w27
   18618:	aa0c03fb 	mov	x27, x12
   1861c:	2a1003ec 	mov	w12, w16
   18620:	2a1603f0 	mov	w16, w22
   18624:	2a0b03ee 	mov	w14, w11
   18628:	a97507ab 	ldp	x11, x1, [x29, #-176]
   1862c:	2a0903ed 	mov	w13, w9
   18630:	2a1a03e9 	mov	w9, w26
   18634:	91004256 	add	x22, x18, #0x10
   18638:	aa0803f9 	mov	x25, x8
   1863c:	aa0a03fa 	mov	x26, x10
   18640:	aa1803ea 	mov	x10, x24
   18644:	2a0b03eb 	mov	w11, w11
   18648:	a902a7ab 	stp	x11, x9, [x29, #40]
   1864c:	f85483ab 	ldur	x11, [x29, #-184]
   18650:	2a0f03e9 	mov	w9, w15
   18654:	2a1b03ef 	mov	w15, w27
   18658:	aa1103fb 	mov	x27, x17
   1865c:	2a0b03eb 	mov	w11, w11
   18660:	a901b3ab 	stp	x11, x12, [x29, #24]
   18664:	aa1303eb 	mov	x11, x19
   18668:	14000071 	b	1882c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x4b0>
   1866c:	a916dbe2 	stp	x2, x22, [sp, #360]
   18670:	f94016b7 	ldr	x23, [x21, #40]
   18674:	aa1203fc 	mov	x28, x18
   18678:	a913c3f8 	stp	x24, x16, [sp, #312]
   1867c:	a97ee256 	ldp	x22, x24, [x18, #-24]
   18680:	f90083f1 	str	x17, [sp, #256]
   18684:	aa0e03f9 	mov	x25, x14
   18688:	a91487e0 	stp	x0, x1, [sp, #328]
   1868c:	f81003a9 	stur	x9, [x29, #-256]
   18690:	f900b3e3 	str	x3, [sp, #352]
   18694:	f81303a5 	stur	x5, [x29, #-208]
   18698:	f900afe6 	str	x6, [sp, #344]
   1869c:	f81083aa 	stur	x10, [x29, #-248]
   186a0:	f81283ac 	stur	x12, [x29, #-216]
   186a4:	a910ebe7 	stp	x7, x26, [sp, #264]
   186a8:	aa0b03fa 	mov	x26, x11
   186ac:	a91293fb 	stp	x27, x4, [sp, #296]
   186b0:	f9008ffe 	str	x30, [sp, #280]
   186b4:	f81103af 	stur	x15, [x29, #-240]
   186b8:	f90093ed 	str	x13, [sp, #288]
   186bc:	b4006577 	cbz	x23, 19368 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xfec>
   186c0:	f8777a88 	ldr	x8, [x20, x23, lsl #3]
   186c4:	f94096a9 	ldr	x9, [x21, #296]
   186c8:	f90016a8 	str	x8, [x21, #40]
   186cc:	d1008128 	sub	x8, x9, #0x20
   186d0:	f90096a8 	str	x8, [x21, #296]
   186d4:	8b170e9b 	add	x27, x20, x23, lsl #3
   186d8:	52801fe1 	mov	w1, #0xff                  	// #255
   186dc:	52801b02 	mov	w2, #0xd8                  	// #216
   186e0:	91002360 	add	x0, x27, #0x8
   186e4:	97ffad03 	bl	3af0 <memset@plt>
   186e8:	2a1903e9 	mov	w9, w25
   186ec:	52800028 	mov	w8, #0x1                   	// #1
   186f0:	f9000369 	str	x9, [x27]
   186f4:	d2c7e009 	mov	x9, #0x3f0000000000        	// #69269232549888
   186f8:	aa18810a 	orr	x10, x8, x24, lsl #32
   186fc:	f2e0a009 	movk	x9, #0x500, lsl #48
   18700:	aa0902e9 	orr	x9, x23, x9
   18704:	a90e2b76 	stp	x22, x10, [x27, #224]
   18708:	a93ea389 	stp	x9, x8, [x28, #-24]
   1870c:	f94016a0 	ldr	x0, [x21, #40]
   18710:	b4006380 	cbz	x0, 19380 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1004>
   18714:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   18718:	f94096aa 	ldr	x10, [x21, #296]
   1871c:	f90016a8 	str	x8, [x21, #40]
   18720:	d1008148 	sub	x8, x10, #0x20
   18724:	f90096a8 	str	x8, [x21, #296]
   18728:	a952f3eb 	ldp	x11, x28, [sp, #296]
   1872c:	8b000e88 	add	x8, x20, x0, lsl #3
   18730:	d2c0002a 	mov	x10, #0x100000000           	// #4294967296
   18734:	aa1a03f6 	mov	x22, x26
   18738:	f85083b9 	ldur	x25, [x29, #-248]
   1873c:	a90da909 	stp	x9, x10, [x8, #216]
   18740:	a950bbfa 	ldp	x26, x14, [sp, #264]
   18744:	2a0b03e9 	mov	w9, w11
   18748:	2a1c03ea 	mov	w10, w28
   1874c:	f9408fed 	ldr	x13, [sp, #280]
   18750:	a9002909 	stp	x9, x10, [x8]
   18754:	a954a7ea 	ldp	x10, x9, [sp, #328]
   18758:	a973bfb1 	ldp	x17, x15, [x29, #-200]
   1875c:	2a1303f3 	mov	w19, w19
   18760:	a901250a 	stp	x10, x9, [x8, #16]
   18764:	f940b3ea 	ldr	x10, [sp, #352]
   18768:	f85583a9 	ldur	x9, [x29, #-168]
   1876c:	a902250a 	stp	x10, x9, [x8, #32]
   18770:	f85303aa 	ldur	x10, [x29, #-208]
   18774:	f940afe9 	ldr	x9, [sp, #344]
   18778:	a903250a 	stp	x10, x9, [x8, #48]
   1877c:	2a1a03e9 	mov	w9, w26
   18780:	a9046509 	stp	x9, x25, [x8, #64]
   18784:	2a1603e9 	mov	w9, w22
   18788:	140002d4 	b	192d8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xf5c>
   1878c:	34004ab7 	cbz	w23, 190e0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xd64>
   18790:	2a0e03e8 	mov	w8, w14
   18794:	52800729 	mov	w9, #0x39                  	// #57
   18798:	2a0703e5 	mov	w5, w7
   1879c:	a9002648 	stp	x8, x9, [x18]
   187a0:	2a0b03e7 	mov	w7, w11
   187a4:	f85003ac 	ldur	x12, [x29, #-256]
   187a8:	a973afa9 	ldp	x9, x11, [x29, #-200]
   187ac:	a904b7b0 	stp	x16, x13, [x29, #72]
   187b0:	2a0c03ec 	mov	w12, w12
   187b4:	2a0403ea 	mov	w10, w4
   187b8:	a903e3b6 	stp	x22, x24, [x29, #56]
   187bc:	f90013ac 	str	x12, [x29, #32]
   187c0:	2a1b03e8 	mov	w8, w27
   187c4:	aa0003fb 	mov	x27, x0
   187c8:	2a0b03ee 	mov	w14, w11
   187cc:	f85503ab 	ldur	x11, [x29, #-176]
   187d0:	2a0903ed 	mov	w13, w9
   187d4:	2a1a03e9 	mov	w9, w26
   187d8:	aa0a03fa 	mov	x26, x10
   187dc:	aa0303e0 	mov	x0, x3
   187e0:	2a0b03eb 	mov	w11, w11
   187e4:	a9728faa 	ldp	x10, x3, [x29, #-216]
   187e8:	a902a7ab 	stp	x11, x9, [x29, #40]
   187ec:	f85483ab 	ldur	x11, [x29, #-184]
   187f0:	f85103a9 	ldur	x9, [x29, #-240]
   187f4:	f940bbec 	ldr	x12, [sp, #368]
   187f8:	aa1103f3 	mov	x19, x17
   187fc:	aa0103fc 	mov	x28, x1
   18800:	2a0b03eb 	mov	w11, w11
   18804:	f85583a1 	ldur	x1, [x29, #-168]
   18808:	aa0603e4 	mov	x4, x6
   1880c:	f85083a6 	ldur	x6, [x29, #-248]
   18810:	2a0903e9 	mov	w9, w9
   18814:	2a1303ef 	mov	w15, w19
   18818:	2a0c03f0 	mov	w16, w12
   1881c:	91004256 	add	x22, x18, #0x10
   18820:	f9000fab 	str	x11, [x29, #24]
   18824:	aa0803f9 	mov	x25, x8
   18828:	5280002b 	mov	w11, #0x1                   	// #1
   1882c:	aa0203ec 	mov	x12, x2
   18830:	f9000bb0 	str	x16, [x29, #16]
   18834:	910a03ff 	add	sp, sp, #0x280
   18838:	a8c17bfd 	ldp	x29, x30, [sp], #16
   1883c:	17fff672 	b	16204 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_TRANSACTION_PROTOTYPE_FLAT_UNPACK_0>
   18840:	a916dbe2 	stp	x2, x22, [sp, #360]
   18844:	f94016b7 	ldr	x23, [x21, #40]
   18848:	aa0e03f9 	mov	x25, x14
   1884c:	a913c3f8 	stp	x24, x16, [sp, #312]
   18850:	a97ee256 	ldp	x22, x24, [x18, #-24]
   18854:	f90083f1 	str	x17, [sp, #256]
   18858:	a91487e0 	stp	x0, x1, [sp, #328]
   1885c:	f81003a9 	stur	x9, [x29, #-256]
   18860:	f900b3e3 	str	x3, [sp, #352]
   18864:	f81303a5 	stur	x5, [x29, #-208]
   18868:	f900afe6 	str	x6, [sp, #344]
   1886c:	f81083aa 	stur	x10, [x29, #-248]
   18870:	f81283ac 	stur	x12, [x29, #-216]
   18874:	a91293fb 	stp	x27, x4, [sp, #296]
   18878:	aa0703fb 	mov	x27, x7
   1887c:	a9117bfa 	stp	x26, x30, [sp, #272]
   18880:	aa0b03fa 	mov	x26, x11
   18884:	f9007ff2 	str	x18, [sp, #248]
   18888:	f81103af 	stur	x15, [x29, #-240]
   1888c:	f90093ed 	str	x13, [sp, #288]
   18890:	b4006837 	cbz	x23, 19594 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1218>
   18894:	f8777a88 	ldr	x8, [x20, x23, lsl #3]
   18898:	f94096a9 	ldr	x9, [x21, #296]
   1889c:	f90016a8 	str	x8, [x21, #40]
   188a0:	d1008128 	sub	x8, x9, #0x20
   188a4:	f90096a8 	str	x8, [x21, #296]
   188a8:	8b170e9c 	add	x28, x20, x23, lsl #3
   188ac:	52801fe1 	mov	w1, #0xff                  	// #255
   188b0:	52801b02 	mov	w2, #0xd8                  	// #216
   188b4:	91002380 	add	x0, x28, #0x8
   188b8:	97ffac8e 	bl	3af0 <memset@plt>
   188bc:	2a1903e9 	mov	w9, w25
   188c0:	52800028 	mov	w8, #0x1                   	// #1
   188c4:	f9407ff9 	ldr	x25, [sp, #248]
   188c8:	f9000389 	str	x9, [x28]
   188cc:	d2c7a009 	mov	x9, #0x3d0000000000        	// #67070209294336
   188d0:	aa18810a 	orr	x10, x8, x24, lsl #32
   188d4:	f2e0a009 	movk	x9, #0x500, lsl #48
   188d8:	aa0902e9 	orr	x9, x23, x9
   188dc:	a90e2b96 	stp	x22, x10, [x28, #224]
   188e0:	a93ea329 	stp	x9, x8, [x25, #-24]
   188e4:	f94016a0 	ldr	x0, [x21, #40]
   188e8:	b4006620 	cbz	x0, 195ac <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1230>
   188ec:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   188f0:	f94096aa 	ldr	x10, [x21, #296]
   188f4:	f90016a8 	str	x8, [x21, #40]
   188f8:	d1008148 	sub	x8, x10, #0x20
   188fc:	f90096a8 	str	x8, [x21, #296]
   18900:	a952afec 	ldp	x12, x11, [sp, #296]
   18904:	8b000e88 	add	x8, x20, x0, lsl #3
   18908:	d2c0002a 	mov	x10, #0x100000000           	// #4294967296
   1890c:	f85083b9 	ldur	x25, [x29, #-248]
   18910:	a90da909 	stp	x9, x10, [x8, #216]
   18914:	a95137ee 	ldp	x14, x13, [sp, #272]
   18918:	2a0c03e9 	mov	w9, w12
   1891c:	2a0b03ea 	mov	w10, w11
   18920:	a9002909 	stp	x9, x10, [x8]
   18924:	a954a7ea 	ldp	x10, x9, [sp, #328]
   18928:	a973bfb1 	ldp	x17, x15, [x29, #-200]
   1892c:	a901250a 	stp	x10, x9, [x8, #16]
   18930:	f940b3ea 	ldr	x10, [sp, #352]
   18934:	f85583a9 	ldur	x9, [x29, #-168]
   18938:	a902250a 	stp	x10, x9, [x8, #32]
   1893c:	f85303aa 	ldur	x10, [x29, #-208]
   18940:	f940afe9 	ldr	x9, [sp, #344]
   18944:	a903250a 	stp	x10, x9, [x8, #48]
   18948:	2a1b03e9 	mov	w9, w27
   1894c:	a9046509 	stp	x9, x25, [x8, #64]
   18950:	2a1a03e9 	mov	w9, w26
   18954:	14000261 	b	192d8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xf5c>
   18958:	f85103ac 	ldur	x12, [x29, #-240]
   1895c:	34004417 	cbz	w23, 191dc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xe60>
   18960:	2a0e03e8 	mov	w8, w14
   18964:	52800769 	mov	w9, #0x3b                  	// #59
   18968:	aa0503f3 	mov	x19, x5
   1896c:	a9002648 	stp	x8, x9, [x18]
   18970:	2a0703e5 	mov	w5, w7
   18974:	2a0b03e7 	mov	w7, w11
   18978:	a973afa9 	ldp	x9, x11, [x29, #-200]
   1897c:	a904b7b0 	stp	x16, x13, [x29, #72]
   18980:	a903e3b6 	stp	x22, x24, [x29, #56]
   18984:	2a0403ea 	mov	w10, w4
   18988:	2a1b03e8 	mov	w8, w27
   1898c:	aa0003fb 	mov	x27, x0
   18990:	aa0303e0 	mov	x0, x3
   18994:	aa0103fc 	mov	x28, x1
   18998:	2a0b03ee 	mov	w14, w11
   1899c:	f85503ab 	ldur	x11, [x29, #-176]
   189a0:	2a0903ed 	mov	w13, w9
   189a4:	2a1a03e9 	mov	w9, w26
   189a8:	aa0a03fa 	mov	x26, x10
   189ac:	f85583a1 	ldur	x1, [x29, #-168]
   189b0:	2a0b03eb 	mov	w11, w11
   189b4:	a9728faa 	ldp	x10, x3, [x29, #-216]
   189b8:	a902a7ab 	stp	x11, x9, [x29, #40]
   189bc:	2a0c03e9 	mov	w9, w12
   189c0:	f85003ac 	ldur	x12, [x29, #-256]
   189c4:	f85483ab 	ldur	x11, [x29, #-184]
   189c8:	aa0603e4 	mov	x4, x6
   189cc:	f85083a6 	ldur	x6, [x29, #-248]
   189d0:	2a0c03ec 	mov	w12, w12
   189d4:	2a1303ef 	mov	w15, w19
   189d8:	91004256 	add	x22, x18, #0x10
   189dc:	f90013ac 	str	x12, [x29, #32]
   189e0:	2a0b03eb 	mov	w11, w11
   189e4:	aa0803f9 	mov	x25, x8
   189e8:	f940bbec 	ldr	x12, [sp, #368]
   189ec:	f9000fab 	str	x11, [x29, #24]
   189f0:	5280002b 	mov	w11, #0x1                   	// #1
   189f4:	2a0c03f0 	mov	w16, w12
   189f8:	f940b7ec 	ldr	x12, [sp, #360]
   189fc:	17ffff8d 	b	18830 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x4b4>
   18a00:	b9400549 	ldr	w9, [x10, #4]
   18a04:	b940014b 	ldr	w11, [x10]
   18a08:	aa1603ef 	mov	x15, x22
   18a0c:	92405d6c 	and	x12, x11, #0xffffff
   18a10:	f100059f 	cmp	x12, #0x1
   18a14:	54006161 	b.ne	19640 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x12c4>  // b.any
   18a18:	aa098169 	orr	x9, x11, x9, lsl #32
   18a1c:	88dffd5f 	ldar	wzr, [x10]
   18a20:	f94002aa 	ldr	x10, [x21]
   18a24:	d358fd29 	lsr	x9, x9, #24
   18a28:	8b090e8b 	add	x11, x20, x9, lsl #3
   18a2c:	a9402d6c 	ldp	x12, x11, [x11]
   18a30:	f8287a8a 	str	x10, [x20, x8, lsl #3]
   18a34:	90000cca 	adrp	x10, 1b0000 <memcpy@GLIBC_2.17>
   18a38:	f94082ad 	ldr	x13, [x21, #256]
   18a3c:	f90002a8 	str	x8, [x21]
   18a40:	3948314a 	ldrb	w10, [x10, #524]
   18a44:	910005a8 	add	x8, x13, #0x1
   18a48:	7100055f 	cmp	w10, #0x1
   18a4c:	f90082a8 	str	x8, [x21, #256]
   18a50:	54006981 	b.ne	19780 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1404>  // b.any
   18a54:	f140211f 	cmp	x8, #0x8, lsl #12
   18a58:	54006942 	b.cs	19780 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1404>  // b.hs, b.nlast
   18a5c:	f85503b9 	ldur	x25, [x29, #-176]
   18a60:	f940b7e2 	ldr	x2, [sp, #360]
   18a64:	eb11013f 	cmp	x9, x17
   18a68:	540001c9 	b.ls	18aa0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x724>  // b.plast
   18a6c:	f9407bee 	ldr	x14, [sp, #240]
   18a70:	f94005c8 	ldr	x8, [x14, #8]
   18a74:	f8297a88 	str	x8, [x20, x9, lsl #3]
   18a78:	90000cc8 	adrp	x8, 1b0000 <memcpy@GLIBC_2.17>
   18a7c:	f94085ca 	ldr	x10, [x14, #264]
   18a80:	3948310d 	ldrb	w13, [x8, #524]
   18a84:	f90005c9 	str	x9, [x14, #8]
   18a88:	91000948 	add	x8, x10, #0x2
   18a8c:	710005bf 	cmp	w13, #0x1
   18a90:	f90085c8 	str	x8, [x14, #264]
   18a94:	54005961 	b.ne	195c0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1244>  // b.any
   18a98:	f140211f 	cmp	x8, #0x8, lsl #12
   18a9c:	54005922 	b.cs	195c0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1244>  // b.hs, b.nlast
   18aa0:	92409d88 	and	x8, x12, #0xffffffffff
   18aa4:	8b080e8d 	add	x13, x20, x8, lsl #3
   18aa8:	b7f8008c 	tbnz	x12, #63, 18ab8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x73c>
   18aac:	a94079a9 	ldp	x9, x30, [x13]
   18ab0:	aa0803ea 	mov	x10, x8
   18ab4:	14000019 	b	18b18 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x79c>
   18ab8:	b94005a9 	ldr	w9, [x13, #4]
   18abc:	b94001aa 	ldr	w10, [x13]
   18ac0:	92405d4e 	and	x14, x10, #0xffffff
   18ac4:	f10005df 	cmp	x14, #0x1
   18ac8:	54005ee1 	b.ne	196a4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1328>  // b.any
   18acc:	aa098149 	orr	x9, x10, x9, lsl #32
   18ad0:	88dffdbf 	ldar	wzr, [x13]
   18ad4:	f9407bee 	ldr	x14, [sp, #240]
   18ad8:	d358fd2a 	lsr	x10, x9, #24
   18adc:	f94001cd 	ldr	x13, [x14]
   18ae0:	8b0a0e8c 	add	x12, x20, x10, lsl #3
   18ae4:	a9407989 	ldp	x9, x30, [x12]
   18ae8:	f8287a8d 	str	x13, [x20, x8, lsl #3]
   18aec:	90000ccc 	adrp	x12, 1b0000 <memcpy@GLIBC_2.17>
   18af0:	f94081cd 	ldr	x13, [x14, #256]
   18af4:	f90001c8 	str	x8, [x14]
   18af8:	3948318c 	ldrb	w12, [x12, #524]
   18afc:	910005a8 	add	x8, x13, #0x1
   18b00:	7100059f 	cmp	w12, #0x1
   18b04:	f90081c8 	str	x8, [x14, #256]
   18b08:	54006641 	b.ne	197d0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1454>  // b.any
   18b0c:	f140211f 	cmp	x8, #0x8, lsl #12
   18b10:	54006602 	b.cs	197d0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1454>  // b.hs, b.nlast
   18b14:	f940b7e2 	ldr	x2, [sp, #360]
   18b18:	eb11015f 	cmp	x10, x17
   18b1c:	54000489 	b.ls	18bac <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x830>  // b.plast
   18b20:	f9407bf5 	ldr	x21, [sp, #240]
   18b24:	f94006a8 	ldr	x8, [x21, #8]
   18b28:	f82a7a88 	str	x8, [x20, x10, lsl #3]
   18b2c:	90000cc8 	adrp	x8, 1b0000 <memcpy@GLIBC_2.17>
   18b30:	f94086ac 	ldr	x12, [x21, #264]
   18b34:	3948310d 	ldrb	w13, [x8, #524]
   18b38:	f90006aa 	str	x10, [x21, #8]
   18b3c:	91000988 	add	x8, x12, #0x2
   18b40:	710005bf 	cmp	w13, #0x1
   18b44:	f90086a8 	str	x8, [x21, #264]
   18b48:	54000061 	b.ne	18b54 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x7d8>  // b.any
   18b4c:	f140211f 	cmp	x8, #0x8, lsl #12
   18b50:	54000303 	b.cc	18bb0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x834>  // b.lo, b.ul, b.last
   18b54:	aa1403e0 	mov	x0, x20
   18b58:	aa1503e1 	mov	x1, x21
   18b5c:	52800022 	mov	w2, #0x1                   	// #1
   18b60:	aa0603ec 	mov	x12, x6
   18b64:	f9008bfa 	str	x26, [sp, #272]
   18b68:	aa1003fb 	mov	x27, x16
   18b6c:	aa1403f5 	mov	x21, x20
   18b70:	aa1203f4 	mov	x20, x18
   18b74:	aa0503f3 	mov	x19, x5
   18b78:	aa1e03ed 	mov	x13, x30
   18b7c:	97ffae39 	bl	4460 <heap_hand>
   18b80:	52909ff1 	mov	w17, #0x84ff                	// #34047
   18b84:	f940b7e2 	ldr	x2, [sp, #360]
   18b88:	aa1403f2 	mov	x18, x20
   18b8c:	aa1503f4 	mov	x20, x21
   18b90:	f9407bf5 	ldr	x21, [sp, #240]
   18b94:	f85503b9 	ldur	x25, [x29, #-176]
   18b98:	f9408bfa 	ldr	x26, [sp, #272]
   18b9c:	aa0d03fe 	mov	x30, x13
   18ba0:	72a06211 	movk	w17, #0x310, lsl #16
   18ba4:	aa1303e5 	mov	x5, x19
   18ba8:	140002db 	b	19714 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1398>
   18bac:	f9407bf5 	ldr	x21, [sp, #240]
   18bb0:	aa1003f7 	mov	x23, x16
   18bb4:	92409d68 	and	x8, x11, #0xffffffffff
   18bb8:	aa0f03f3 	mov	x19, x15
   18bbc:	f900afe6 	str	x6, [sp, #344]
   18bc0:	8b080e90 	add	x16, x20, x8, lsl #3
   18bc4:	f900a3f7 	str	x23, [sp, #320]
   18bc8:	f9007ff2 	str	x18, [sp, #248]
   18bcc:	b7f800cb 	tbnz	x11, #63, 18be4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x868>
   18bd0:	a940360c 	ldp	x12, x13, [x16]
   18bd4:	aa0803ee 	mov	x14, x8
   18bd8:	a9412a0f 	ldp	x15, x10, [x16, #16]
   18bdc:	f9401216 	ldr	x22, [x16, #32]
   18be0:	14000023 	b	18c6c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x8f0>
   18be4:	b940060a 	ldr	w10, [x16, #4]
   18be8:	b940020c 	ldr	w12, [x16]
   18bec:	aa1803f9 	mov	x25, x24
   18bf0:	92405d91 	and	x17, x12, #0xffffff
   18bf4:	f100063f 	cmp	x17, #0x1
   18bf8:	54000041 	b.ne	18c00 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x884>  // b.any
   18bfc:	88dffe1f 	ldar	wzr, [x16]
   18c00:	aa0a818a 	orr	x10, x12, x10, lsl #32
   18c04:	aa0503fb 	mov	x27, x5
   18c08:	f100063f 	cmp	x17, #0x1
   18c0c:	d358fd4e 	lsr	x14, x10, #24
   18c10:	8b0e0e92 	add	x18, x20, x14, lsl #3
   18c14:	a940364c 	ldp	x12, x13, [x18]
   18c18:	f9401256 	ldr	x22, [x18, #32]
   18c1c:	a9412a4f 	ldp	x15, x10, [x18, #16]
   18c20:	54005801 	b.ne	19720 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x13a4>  // b.any
   18c24:	f94002ab 	ldr	x11, [x21]
   18c28:	f900020b 	str	x11, [x16]
   18c2c:	90000ccb 	adrp	x11, 1b0000 <memcpy@GLIBC_2.17>
   18c30:	f94082b0 	ldr	x16, [x21, #256]
   18c34:	3948316b 	ldrb	w11, [x11, #524]
   18c38:	f90002a8 	str	x8, [x21]
   18c3c:	91000608 	add	x8, x16, #0x1
   18c40:	7100057f 	cmp	w11, #0x1
   18c44:	f90082a8 	str	x8, [x21, #256]
   18c48:	54005f21 	b.ne	1982c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x14b0>  // b.any
   18c4c:	f140211f 	cmp	x8, #0x8, lsl #12
   18c50:	54005ee2 	b.cs	1982c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x14b0>  // b.hs, b.nlast
   18c54:	aa1903f8 	mov	x24, x25
   18c58:	f940b7e2 	ldr	x2, [sp, #360]
   18c5c:	f85503b9 	ldur	x25, [x29, #-176]
   18c60:	52909ff1 	mov	w17, #0x84ff                	// #34047
   18c64:	aa1b03e5 	mov	x5, x27
   18c68:	72a06211 	movk	w17, #0x310, lsl #16
   18c6c:	eb1101df 	cmp	x14, x17
   18c70:	540001a9 	b.ls	18ca4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x928>  // b.plast
   18c74:	f9400ea8 	ldr	x8, [x21, #24]
   18c78:	f82e7a88 	str	x8, [x20, x14, lsl #3]
   18c7c:	90000cc8 	adrp	x8, 1b0000 <memcpy@GLIBC_2.17>
   18c80:	f9408eab 	ldr	x11, [x21, #280]
   18c84:	39483110 	ldrb	w16, [x8, #524]
   18c88:	f9000eae 	str	x14, [x21, #24]
   18c8c:	91002168 	add	x8, x11, #0x8
   18c90:	7100061f 	cmp	w16, #0x1
   18c94:	f9008ea8 	str	x8, [x21, #280]
   18c98:	54004bc1 	b.ne	19610 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1294>  // b.any
   18c9c:	f140211f 	cmp	x8, #0x8, lsl #12
   18ca0:	54004b82 	b.cs	19610 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1294>  // b.hs, b.nlast
   18ca4:	92409d28 	and	x8, x9, #0xffffffffff
   18ca8:	b6f80069 	tbz	x9, #63, 18cb4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x938>
   18cac:	f8687a88 	ldr	x8, [x20, x8, lsl #3]
   18cb0:	d358fd08 	lsr	x8, x8, #24
   18cb4:	92409c4b 	and	x11, x2, #0xffffffffff
   18cb8:	b6f80062 	tbz	x2, #63, 18cc4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x948>
   18cbc:	f86b7a8b 	ldr	x11, [x20, x11, lsl #3]
   18cc0:	d358fd6b 	lsr	x11, x11, #24
   18cc4:	92409e6e 	and	x14, x19, #0xffffffffff
   18cc8:	b6f80073 	tbz	x19, #63, 18cd4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x958>
   18ccc:	f86e7a8e 	ldr	x14, [x20, x14, lsl #3]
   18cd0:	d358fdce 	lsr	x14, x14, #24
   18cd4:	f94093fc 	ldr	x28, [sp, #288]
   18cd8:	92409f90 	and	x16, x28, #0xffffffffff
   18cdc:	aa1c03fb 	mov	x27, x28
   18ce0:	b6f8007c 	tbz	x28, #63, 18cec <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x970>
   18ce4:	f8707a90 	ldr	x16, [x20, x16, lsl #3]
   18ce8:	d358fe10 	lsr	x16, x16, #24
   18cec:	eb1b013f 	cmp	x9, x27
   18cf0:	aa1003e4 	mov	x4, x16
   18cf4:	540000c0 	b.eq	18d0c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x990>  // b.none
   18cf8:	eb13013f 	cmp	x9, x19
   18cfc:	aa0e03e4 	mov	x4, x14
   18d00:	54000060 	b.eq	18d0c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x990>  // b.none
   18d04:	eb02013f 	cmp	x9, x2
   18d08:	9a880164 	csel	x4, x11, x8, eq	// eq = none
   18d0c:	eb13005f 	cmp	x2, x19
   18d10:	b900abea 	str	w10, [sp, #168]
   18d14:	aa1403e0 	mov	x0, x20
   18d18:	9a8b01c8 	csel	x8, x14, x11, eq	// eq = none
   18d1c:	eb1b005f 	cmp	x2, x27
   18d20:	b900a3ef 	str	w15, [sp, #160]
   18d24:	9a880208 	csel	x8, x16, x8, eq	// eq = none
   18d28:	eb1b027f 	cmp	x19, x27
   18d2c:	b9009bed 	str	w13, [sp, #152]
   18d30:	b90093ec 	str	w12, [sp, #144]
   18d34:	9a8e020b 	csel	x11, x16, x14, eq	// eq = none
   18d38:	aa1503e1 	mov	x1, x21
   18d3c:	b9008bff 	str	wzr, [sp, #136]
   18d40:	aa0903e3 	mov	x3, x9
   18d44:	2a0c03e6 	mov	w6, w12
   18d48:	a907c3fb 	stp	x27, x16, [sp, #120]
   18d4c:	2a0d03e7 	mov	w7, w13
   18d50:	b90063fa 	str	w26, [sp, #96]
   18d54:	b9005bf9 	str	w25, [sp, #88]
   18d58:	f85483ae 	ldur	x14, [x29, #-184]
   18d5c:	b90043e5 	str	w5, [sp, #64]
   18d60:	2a1e03e5 	mov	w5, w30
   18d64:	b90053ee 	str	w14, [sp, #80]
   18d68:	f940bbee 	ldr	x14, [sp, #368]
   18d6c:	b9004bee 	str	w14, [sp, #72]
   18d70:	f85103ae 	ldur	x14, [x29, #-240]
   18d74:	b9003bee 	str	w14, [sp, #56]
   18d78:	f85403ae 	ldur	x14, [x29, #-192]
   18d7c:	b90033ee 	str	w14, [sp, #48]
   18d80:	f85383ae 	ldur	x14, [x29, #-200]
   18d84:	b9000bea 	str	w10, [sp, #8]
   18d88:	aa0203ea 	mov	x10, x2
   18d8c:	d10283a2 	sub	x2, x29, #0xa0
   18d90:	b90013f6 	str	w22, [sp, #16]
   18d94:	b9002bee 	str	w14, [sp, #40]
   18d98:	b90003ef 	str	w15, [sp]
   18d9c:	a906aff3 	stp	x19, x11, [sp, #104]
   18da0:	a901a3ea 	stp	x10, x8, [sp, #24]
   18da4:	940187f1 	bl	7ad68 <spin_51>
   18da8:	b85a83a8 	ldur	w8, [x29, #-88]
   18dac:	ad7b8ba1 	ldp	q1, q2, [x29, #-144]
   18db0:	a97de7ad 	ldp	x13, x25, [x29, #-40]
   18db4:	f85603ba 	ldur	x26, [x29, #-160]
   18db8:	f81503a8 	stur	x8, [x29, #-176]
   18dbc:	b85b03a8 	ldur	w8, [x29, #-80]
   18dc0:	b85683b6 	ldur	w22, [x29, #-152]
   18dc4:	b85903ae 	ldur	w14, [x29, #-112]
   18dc8:	f85983ac 	ldur	x12, [x29, #-104]
   18dcc:	b85a03be 	ldur	w30, [x29, #-96]
   18dd0:	f81483a8 	stur	x8, [x29, #-184]
   18dd4:	b85b83a8 	ldur	w8, [x29, #-72]
   18dd8:	b85c03a0 	ldur	w0, [x29, #-64]
   18ddc:	b85c83a5 	ldur	w5, [x29, #-56]
   18de0:	b85d03b7 	ldur	w23, [x29, #-48]
   18de4:	f81403a8 	stur	x8, [x29, #-192]
   18de8:	a97ef3a6 	ldp	x6, x28, [x29, #-24]
   18dec:	b6f8007a 	tbz	x26, #63, 18df8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xa7c>
   18df0:	92409f48 	and	x8, x26, #0xffffffffff
   18df4:	f8687a9f 	ldr	xzr, [x20, x8, lsl #3]
   18df8:	a9728faa 	ldp	x10, x3, [x29, #-216]
   18dfc:	a95513f1 	ldp	x17, x4, [sp, #336]
   18e00:	a9546ff2 	ldp	x18, x27, [sp, #320]
   18e04:	a94e3fe1 	ldp	x1, x15, [sp, #224]
   18e08:	a94ba7eb 	ldp	x11, x9, [sp, #184]
   18e0c:	b7f8134c 	tbnz	x12, #63, 19074 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xcf8>
   18e10:	b7f81399 	tbnz	x25, #63, 19080 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xd04>
   18e14:	b7f813c6 	tbnz	x6, #63, 1908c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xd10>
   18e18:	b7f8141b 	tbnz	x27, #63, 19098 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xd1c>
   18e1c:	b7f81451 	tbnz	x17, #63, 190a4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xd28>
   18e20:	f940b3e8 	ldr	x8, [sp, #352]
   18e24:	b6f80068 	tbz	x8, #63, 18e30 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xab4>
   18e28:	f94083e8 	ldr	x8, [sp, #256]
   18e2c:	f8687a9f 	ldr	xzr, [x20, x8, lsl #3]
   18e30:	f85583a8 	ldur	x8, [x29, #-168]
   18e34:	b7f813e8 	tbnz	x8, #63, 190b0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xd34>
   18e38:	b7f81403 	tbnz	x3, #63, 190b8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xd3c>
   18e3c:	b7f81424 	tbnz	x4, #63, 190c0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xd44>
   18e40:	b7f8144a 	tbnz	x10, #63, 190c8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xd4c>
   18e44:	b7f81498 	tbnz	x24, #63, 190d4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xd58>
   18e48:	f9405be8 	ldr	x8, [sp, #176]
   18e4c:	2a2803e8 	mvn	w8, w8
   18e50:	b6f80072 	tbz	x18, #63, 18e5c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xae0>
   18e54:	92409e49 	and	x9, x18, #0xffffffffff
   18e58:	f8697a9f 	ldr	xzr, [x20, x9, lsl #3]
   18e5c:	510005a9 	sub	w9, w13, #0x1
   18e60:	f94006ab 	ldr	x11, [x21, #8]
   18e64:	0a080128 	and	w8, w9, w8
   18e68:	531f7913 	lsl	w19, w8, #1
   18e6c:	8b334e88 	add	x8, x20, w19, uxtw #3
   18e70:	8b010d0f 	add	x15, x8, x1, lsl #3
   18e74:	f94005e9 	ldr	x9, [x15, #8]
   18e78:	b40028eb 	cbz	x11, 19394 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1018>
   18e7c:	f86b7a88 	ldr	x8, [x20, x11, lsl #3]
   18e80:	f94086b0 	ldr	x16, [x21, #264]
   18e84:	f90006a8 	str	x8, [x21, #8]
   18e88:	d1000a08 	sub	x8, x16, #0x2
   18e8c:	f90086a8 	str	x8, [x21, #264]
   18e90:	d378ff48 	lsr	x8, x26, #56
   18e94:	f100091f 	cmp	x8, #0x2
   18e98:	54002ac0 	b.eq	193f0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1074>  // b.none
   18e9c:	8b0b0e88 	add	x8, x20, x11, lsl #3
   18ea0:	a900591a 	stp	x26, x22, [x8]
   18ea4:	f9400eba 	ldr	x26, [x21, #24]
   18ea8:	b4002d5a 	cbz	x26, 19450 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x10d4>
   18eac:	f87a7a88 	ldr	x8, [x20, x26, lsl #3]
   18eb0:	f9408eb0 	ldr	x16, [x21, #280]
   18eb4:	f9000ea8 	str	x8, [x21, #24]
   18eb8:	d1002208 	sub	x8, x16, #0x8
   18ebc:	f9008ea8 	str	x8, [x21, #280]
   18ec0:	6f00e5e0 	movi	v0.2d, #0xffffffff
   18ec4:	8b1a0e88 	add	x8, x20, x26, lsl #3
   18ec8:	f900110e 	str	x14, [x8, #32]
   18ecc:	4e201c21 	and	v1.16b, v1.16b, v0.16b
   18ed0:	4e201c40 	and	v0.16b, v2.16b, v0.16b
   18ed4:	ad000101 	stp	q1, q0, [x8]
   18ed8:	f94006b6 	ldr	x22, [x21, #8]
   18edc:	b4002e96 	cbz	x22, 194ac <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x1130>
   18ee0:	f8767a88 	ldr	x8, [x20, x22, lsl #3]
   18ee4:	f94086ae 	ldr	x14, [x21, #264]
   18ee8:	f90006a8 	str	x8, [x21, #8]
   18eec:	d10009c8 	sub	x8, x14, #0x2
   18ef0:	f90086a8 	str	x8, [x21, #264]
   18ef4:	d2c40008 	mov	x8, #0x200000000000        	// #35184372088832
   18ef8:	f2e04008 	movk	x8, #0x200, lsl #48
   18efc:	aa080162 	orr	x2, x11, x8
   18f00:	d378fc48 	lsr	x8, x2, #56
   18f04:	f100091f 	cmp	x8, #0x2
   18f08:	54002f80 	b.eq	194f8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x117c>  // b.none
   18f0c:	d2c42008 	mov	x8, #0x210000000000        	// #36283883716608
   18f10:	8b160e8b 	add	x11, x20, x22, lsl #3
   18f14:	f2e04008 	movk	x8, #0x200, lsl #48
   18f18:	aa080348 	orr	x8, x26, x8
   18f1c:	2a0d03fa 	mov	w26, w13
   18f20:	f9000162 	str	x2, [x11]
   18f24:	d378fd0e 	lsr	x14, x8, #56
   18f28:	f10009df 	cmp	x14, #0x2
   18f2c:	540030c0 	b.eq	19544 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x11c8>  // b.none
   18f30:	52909fed 	mov	w13, #0x84ff                	// #34047
   18f34:	f9000568 	str	x8, [x11, #8]
   18f38:	3200026b 	orr	w11, w19, #0x1
   18f3c:	72a0620d 	movk	w13, #0x310, lsl #16
   18f40:	8b2b4e8b 	add	x11, x20, w11, uxtw #3
   18f44:	92787d30 	and	x16, x9, #0xffffffff00
   18f48:	910005ad 	add	x13, x13, #0x1
   18f4c:	d2c3e00e 	mov	x14, #0x1f0000000000        	// #34084860461056
   18f50:	52800028 	mov	w8, #0x1                   	// #1
   18f54:	f2e0400e 	movk	x14, #0x200, lsl #48
   18f58:	eb0d021f 	cmp	x16, x13
   18f5c:	f90001e8 	str	x8, [x15]
   18f60:	aa0e02c8 	orr	x8, x22, x14
   18f64:	f8217968 	str	x8, [x11, x1, lsl #3]
   18f68:	54000403 	b.cc	18fe8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xc6c>  // b.lo, b.ul, b.last
   18f6c:	b100053f 	cmn	x9, #0x1
   18f70:	540003c0 	b.eq	18fe8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xc6c>  // b.none
   18f74:	92471528 	and	x8, x9, #0x7e00000000000000
   18f78:	b4000388 	cbz	x8, 18fe8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xc6c>
   18f7c:	f81383a0 	stur	x0, [x29, #-200]
   18f80:	aa1403e0 	mov	x0, x20
   18f84:	aa1503e1 	mov	x1, x21
   18f88:	aa0903e2 	mov	x2, x9
   18f8c:	aa0c03f3 	mov	x19, x12
   18f90:	aa1e03f6 	mov	x22, x30
   18f94:	aa1903f8 	mov	x24, x25
   18f98:	aa1c03f9 	mov	x25, x28
   18f9c:	aa1703fc 	mov	x28, x23
   18fa0:	aa0503f7 	mov	x23, x5
   18fa4:	aa1503fb 	mov	x27, x21
   18fa8:	aa1a03f5 	mov	x21, x26
   18fac:	aa0603fa 	mov	x26, x6
   18fb0:	97ffb291 	bl	59f4 <term_drop>
   18fb4:	aa1a03e6 	mov	x6, x26
   18fb8:	aa1503fa 	mov	x26, x21
   18fbc:	aa1b03f5 	mov	x21, x27
   18fc0:	a97303a3 	ldp	x3, x0, [x29, #-208]
   18fc4:	f85283aa 	ldur	x10, [x29, #-216]
   18fc8:	a9546ff2 	ldp	x18, x27, [sp, #320]
   18fcc:	aa1703e5 	mov	x5, x23
   18fd0:	a95513f1 	ldp	x17, x4, [sp, #336]
   18fd4:	aa1c03f7 	mov	x23, x28
   18fd8:	aa1903fc 	mov	x28, x25
   18fdc:	aa1803f9 	mov	x25, x24
   18fe0:	aa1603fe 	mov	x30, x22
   18fe4:	aa1303ec 	mov	x12, x19
   18fe8:	f9407ff6 	ldr	x22, [sp, #248]
   18fec:	d0000ca9 	adrp	x9, 1ae000 <io_eff_rows+0xff0d0>
   18ff0:	913f2129 	add	x9, x9, #0xfc8
   18ff4:	a97507ae 	ldp	x14, x1, [x29, #-176]
   18ff8:	52800398 	mov	w24, #0x1c                  	// #28
   18ffc:	b85f8ec8 	ldr	w8, [x22, #-8]!
   19000:	aa1e03ed 	mov	x13, x30
   19004:	f8687922 	ldr	x2, [x9, x8, lsl #3]
   19008:	a9049bb2 	stp	x18, x6, [x29, #72]
   1900c:	f9409fe8 	ldr	x8, [sp, #312]
   19010:	a902ebb7 	stp	x23, x26, [x29, #40]
   19014:	a903a3b9 	stp	x25, x8, [x29, #56]
   19018:	f9406be8 	ldr	x8, [sp, #208]
   1901c:	f9000fa5 	str	x5, [x29, #24]
   19020:	a952a7eb 	ldp	x11, x9, [sp, #296]
   19024:	0b080388 	add	w8, w28, w8
   19028:	aa1103fc 	mov	x28, x17
   1902c:	2a0903fa 	mov	w26, w9
   19030:	f94087e9 	ldr	x9, [sp, #264]
   19034:	2a0b03f9 	mov	w25, w11
   19038:	5280002b 	mov	w11, #0x1                   	// #1
   1903c:	2a0903e5 	mov	w5, w9
   19040:	f9406fe9 	ldr	x9, [sp, #216]
   19044:	f9000ba0 	str	x0, [x29, #16]
   19048:	2a0903e7 	mov	w7, w9
   1904c:	a9701ba9 	ldp	x9, x6, [x29, #-256]
   19050:	2a0903e9 	mov	w9, w9
   19054:	f90013a9 	str	x9, [x29, #32]
   19058:	a97427af 	ldp	x15, x9, [x29, #-192]
   1905c:	b940cff7 	ldr	w23, [sp, #204]
   19060:	f940b3e0 	ldr	x0, [sp, #352]
   19064:	f9002fa8 	str	x8, [x29, #88]
   19068:	910a03ff 	add	sp, sp, #0x280
   1906c:	a8c17bfd 	ldp	x29, x30, [sp], #16
   19070:	d61f0040 	br	x2
   19074:	92409d88 	and	x8, x12, #0xffffffffff
   19078:	f8687a9f 	ldr	xzr, [x20, x8, lsl #3]
   1907c:	b6ffecd9 	tbz	x25, #63, 18e14 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xa98>
   19080:	92409f28 	and	x8, x25, #0xffffffffff
   19084:	f8687a9f 	ldr	xzr, [x20, x8, lsl #3]
   19088:	b6ffec86 	tbz	x6, #63, 18e18 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xa9c>
   1908c:	92409cc8 	and	x8, x6, #0xffffffffff
   19090:	f8687a9f 	ldr	xzr, [x20, x8, lsl #3]
   19094:	b6ffec5b 	tbz	x27, #63, 18e1c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xaa0>
   19098:	f8617a88 	ldr	x8, [x20, x1, lsl #3]
   1909c:	d358fd01 	lsr	x1, x8, #24
   190a0:	b6ffec11 	tbz	x17, #63, 18e20 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xaa4>
   190a4:	92409e28 	and	x8, x17, #0xffffffffff
   190a8:	f8687a9f 	ldr	xzr, [x20, x8, lsl #3]
   190ac:	17ffff5d 	b	18e20 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xaa4>
   190b0:	f8697a9f 	ldr	xzr, [x20, x9, lsl #3]
   190b4:	b6ffec43 	tbz	x3, #63, 18e3c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xac0>
   190b8:	f86b7a9f 	ldr	xzr, [x20, x11, lsl #3]
   190bc:	b6ffec24 	tbz	x4, #63, 18e40 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xac4>
   190c0:	f86f7a9f 	ldr	xzr, [x20, x15, lsl #3]
   190c4:	b6ffec0a 	tbz	x10, #63, 18e44 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xac8>
   190c8:	92409d48 	and	x8, x10, #0xffffffffff
   190cc:	f8687a9f 	ldr	xzr, [x20, x8, lsl #3]
   190d0:	b6ffebd8 	tbz	x24, #63, 18e48 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xacc>
   190d4:	92409f08 	and	x8, x24, #0xffffffffff
   190d8:	f8687a9f 	ldr	xzr, [x20, x8, lsl #3]
   190dc:	17ffff5b 	b	18e48 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xacc>
   190e0:	a913c3f8 	stp	x24, x16, [sp, #312]
   190e4:	a97ee257 	ldp	x23, x24, [x18, #-24]
   190e8:	f94016b3 	ldr	x19, [x21, #40]
   190ec:	aa0e03f9 	mov	x25, x14
   190f0:	a91293fb 	stp	x27, x4, [sp, #296]
   190f4:	aa0b03fb 	mov	x27, x11
   190f8:	a90fc7f2 	stp	x18, x17, [sp, #248]
   190fc:	a9160be3 	stp	x3, x2, [sp, #352]
   19100:	a91487e0 	stp	x0, x1, [sp, #328]
   19104:	f900afe6 	str	x6, [sp, #344]
   19108:	a910ebe7 	stp	x7, x26, [sp, #264]
   1910c:	a911b7f6 	stp	x22, x13, [sp, #280]
   19110:	b4003233 	cbz	x19, 19754 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x13d8>
   19114:	f8737a88 	ldr	x8, [x20, x19, lsl #3]
   19118:	f94096a9 	ldr	x9, [x21, #296]
   1911c:	f90016a8 	str	x8, [x21, #40]
   19120:	d1008128 	sub	x8, x9, #0x20
   19124:	f90096a8 	str	x8, [x21, #296]
   19128:	8b130e9c 	add	x28, x20, x19, lsl #3
   1912c:	52801fe1 	mov	w1, #0xff                  	// #255
   19130:	52801b02 	mov	w2, #0xd8                  	// #216
   19134:	91002380 	add	x0, x28, #0x8
   19138:	97ffaa6e 	bl	3af0 <memset@plt>
   1913c:	2a1903e9 	mov	w9, w25
   19140:	52800028 	mov	w8, #0x1                   	// #1
   19144:	f9407ffa 	ldr	x26, [sp, #248]
   19148:	f9000389 	str	x9, [x28]
   1914c:	d2c72009 	mov	x9, #0x390000000000        	// #62672162783232
   19150:	aa18810a 	orr	x10, x8, x24, lsl #32
   19154:	f2e0a009 	movk	x9, #0x500, lsl #48
   19158:	aa090269 	orr	x9, x19, x9
   1915c:	a90e2b97 	stp	x23, x10, [x28, #224]
   19160:	a93ea349 	stp	x9, x8, [x26, #-24]
   19164:	f94016a0 	ldr	x0, [x21, #40]
   19168:	b4003020 	cbz	x0, 1976c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x13f0>
   1916c:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   19170:	f94096aa 	ldr	x10, [x21, #296]
   19174:	f90016a8 	str	x8, [x21, #40]
   19178:	d1008148 	sub	x8, x10, #0x20
   1917c:	f90096a8 	str	x8, [x21, #296]
   19180:	a952dbeb 	ldp	x11, x22, [sp, #296]
   19184:	8b000e88 	add	x8, x20, x0, lsl #3
   19188:	d2c0002a 	mov	x10, #0x100000000           	// #4294967296
   1918c:	aa1b03f9 	mov	x25, x27
   19190:	f85083ba 	ldur	x26, [x29, #-248]
   19194:	a90da909 	stp	x9, x10, [x8, #216]
   19198:	a950bbfb 	ldp	x27, x14, [sp, #264]
   1919c:	2a0b03e9 	mov	w9, w11
   191a0:	2a1603ea 	mov	w10, w22
   191a4:	f9408fed 	ldr	x13, [sp, #280]
   191a8:	a9002909 	stp	x9, x10, [x8]
   191ac:	a954a7ea 	ldp	x10, x9, [sp, #328]
   191b0:	a973bfb1 	ldp	x17, x15, [x29, #-200]
   191b4:	a901250a 	stp	x10, x9, [x8, #16]
   191b8:	f940b3ea 	ldr	x10, [sp, #352]
   191bc:	f85583a9 	ldur	x9, [x29, #-168]
   191c0:	a902250a 	stp	x10, x9, [x8, #32]
   191c4:	f85303aa 	ldur	x10, [x29, #-208]
   191c8:	f940afe9 	ldr	x9, [sp, #344]
   191cc:	a903250a 	stp	x10, x9, [x8, #48]
   191d0:	2a1b03e9 	mov	w9, w27
   191d4:	a9046909 	stp	x9, x26, [x8, #64]
   191d8:	1400003e 	b	192d0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xf54>
   191dc:	a913c3f8 	stp	x24, x16, [sp, #312]
   191e0:	a97ee257 	ldp	x23, x24, [x18, #-24]
   191e4:	f94016b3 	ldr	x19, [x21, #40]
   191e8:	aa0e03f9 	mov	x25, x14
   191ec:	a910ebe7 	stp	x7, x26, [sp, #264]
   191f0:	aa0b03fa 	mov	x26, x11
   191f4:	a90f97f2 	stp	x18, x5, [sp, #248]
   191f8:	a91487e0 	stp	x0, x1, [sp, #328]
   191fc:	a9158fe6 	stp	x6, x3, [sp, #344]
   19200:	a91293fb 	stp	x27, x4, [sp, #296]
   19204:	a911b7f6 	stp	x22, x13, [sp, #280]
   19208:	b4003253 	cbz	x19, 19850 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x14d4>
   1920c:	f8737a88 	ldr	x8, [x20, x19, lsl #3]
   19210:	f94096a9 	ldr	x9, [x21, #296]
   19214:	f90016a8 	str	x8, [x21, #40]
   19218:	d1008128 	sub	x8, x9, #0x20
   1921c:	f90096a8 	str	x8, [x21, #296]
   19220:	8b130e9c 	add	x28, x20, x19, lsl #3
   19224:	52801fe1 	mov	w1, #0xff                  	// #255
   19228:	52801b02 	mov	w2, #0xd8                  	// #216
   1922c:	91002380 	add	x0, x28, #0x8
   19230:	97ffaa30 	bl	3af0 <memset@plt>
   19234:	2a1903e9 	mov	w9, w25
   19238:	52800028 	mov	w8, #0x1                   	// #1
   1923c:	f9407ffb 	ldr	x27, [sp, #248]
   19240:	f9000389 	str	x9, [x28]
   19244:	d2c76009 	mov	x9, #0x3b0000000000        	// #64871186038784
   19248:	aa18810a 	orr	x10, x8, x24, lsl #32
   1924c:	f2e0a009 	movk	x9, #0x500, lsl #48
   19250:	aa090269 	orr	x9, x19, x9
   19254:	a90e2b97 	stp	x23, x10, [x28, #224]
   19258:	a93ea369 	stp	x9, x8, [x27, #-24]
   1925c:	f94016a0 	ldr	x0, [x21, #40]
   19260:	b4003040 	cbz	x0, 19868 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x14ec>
   19264:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   19268:	f94096aa 	ldr	x10, [x21, #296]
   1926c:	f90016a8 	str	x8, [x21, #40]
   19270:	d1008148 	sub	x8, x10, #0x20
   19274:	f90096a8 	str	x8, [x21, #296]
   19278:	aa1a03f9 	mov	x25, x26
   1927c:	a952ebeb 	ldp	x11, x26, [sp, #296]
   19280:	8b000e88 	add	x8, x20, x0, lsl #3
   19284:	d2c0002a 	mov	x10, #0x100000000           	// #4294967296
   19288:	f85083bb 	ldur	x27, [x29, #-248]
   1928c:	a950bbf6 	ldp	x22, x14, [sp, #264]
   19290:	f9408fed 	ldr	x13, [sp, #280]
   19294:	a90da909 	stp	x9, x10, [x8, #216]
   19298:	2a0b03e9 	mov	w9, w11
   1929c:	2a1a03ea 	mov	w10, w26
   192a0:	a9002909 	stp	x9, x10, [x8]
   192a4:	a954a7ea 	ldp	x10, x9, [sp, #328]
   192a8:	a973bfb1 	ldp	x17, x15, [x29, #-200]
   192ac:	a901250a 	stp	x10, x9, [x8, #16]
   192b0:	f940b3ea 	ldr	x10, [sp, #352]
   192b4:	f85583a9 	ldur	x9, [x29, #-168]
   192b8:	a902250a 	stp	x10, x9, [x8, #32]
   192bc:	f85303aa 	ldur	x10, [x29, #-208]
   192c0:	f940afe9 	ldr	x9, [sp, #344]
   192c4:	a903250a 	stp	x10, x9, [x8, #48]
   192c8:	2a1603e9 	mov	w9, w22
   192cc:	a9046d09 	stp	x9, x27, [x8, #64]
   192d0:	2a1903e9 	mov	w9, w25
   192d4:	52800033 	mov	w19, #0x1                   	// #1
   192d8:	f9002909 	str	x9, [x8, #80]
   192dc:	f85283a9 	ldur	x9, [x29, #-216]
   192e0:	2a0f03ea 	mov	w10, w15
   192e4:	f94083f0 	ldr	x16, [sp, #256]
   192e8:	f85483ac 	ldur	x12, [x29, #-184]
   192ec:	f940a3eb 	ldr	x11, [sp, #320]
   192f0:	a905cd09 	stp	x9, x19, [x8, #88]
   192f4:	f940b7e9 	ldr	x9, [sp, #360]
   192f8:	f9003509 	str	x9, [x8, #104]
   192fc:	2a1103e9 	mov	w9, w17
   19300:	a9072909 	stp	x9, x10, [x8, #112]
   19304:	f85103a9 	ldur	x9, [x29, #-240]
   19308:	2a1003ea 	mov	w10, w16
   1930c:	2a0903e9 	mov	w9, w9
   19310:	a9082909 	stp	x9, x10, [x8, #128]
   19314:	f940bbe9 	ldr	x9, [sp, #368]
   19318:	2a0c03ea 	mov	w10, w12
   1931c:	2a0903e9 	mov	w9, w9
   19320:	a9092909 	stp	x9, x10, [x8, #144]
   19324:	f85003a9 	ldur	x9, [x29, #-256]
   19328:	f85503aa 	ldur	x10, [x29, #-176]
   1932c:	2a0903e9 	mov	w9, w9
   19330:	2a0a03ea 	mov	w10, w10
   19334:	a90a2909 	stp	x9, x10, [x8, #160]
   19338:	2a0e03e9 	mov	w9, w14
   1933c:	f9409fea 	ldr	x10, [sp, #312]
   19340:	a90b3509 	stp	x9, x13, [x8, #176]
   19344:	d2c4e009 	mov	x9, #0x270000000000        	// #42880953483264
   19348:	f2e0a009 	movk	x9, #0x500, lsl #48
   1934c:	a90c2d0a 	stp	x10, x11, [x8, #192]
   19350:	aa090000 	orr	x0, x0, x9
   19354:	f94093e9 	ldr	x9, [sp, #288]
   19358:	f9006909 	str	x9, [x8, #208]
   1935c:	910a03ff 	add	sp, sp, #0x280
   19360:	a8c17bfd 	ldp	x29, x30, [sp], #16
   19364:	d65f03c0 	ret
   19368:	aa1403e0 	mov	x0, x20
   1936c:	aa1503e1 	mov	x1, x21
   19370:	528000a2 	mov	w2, #0x5                   	// #5
   19374:	97ffadfe 	bl	4b6c <heap_alloc_miss>
   19378:	aa0003f7 	mov	x23, x0
   1937c:	17fffcd6 	b	186d4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x358>
   19380:	aa1403e0 	mov	x0, x20
   19384:	aa1503e1 	mov	x1, x21
   19388:	528000a2 	mov	w2, #0x5                   	// #5
   1938c:	97ffadf8 	bl	4b6c <heap_alloc_miss>
   19390:	17fffce6 	b	18728 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x3ac>
   19394:	f81383a0 	stur	x0, [x29, #-200]
   19398:	aa1403e0 	mov	x0, x20
   1939c:	52800022 	mov	w2, #0x1                   	// #1
   193a0:	f90073e1 	str	x1, [sp, #224]
   193a4:	aa1503e1 	mov	x1, x21
   193a8:	aa1e03eb 	mov	x11, x30
   193ac:	aa0503fb 	mov	x27, x5
   193b0:	aa0603ea 	mov	x10, x6
   193b4:	3c9103a2 	stur	q2, [x29, #-240]
   193b8:	3d805fe1 	str	q1, [sp, #368]
   193bc:	97ffadec 	bl	4b6c <heap_alloc_miss>
   193c0:	aa0a03e6 	mov	x6, x10
   193c4:	aa1b03e5 	mov	x5, x27
   193c8:	3dc05fe1 	ldr	q1, [sp, #368]
   193cc:	a9546ff2 	ldp	x18, x27, [sp, #320]
   193d0:	3cd103a2 	ldur	q2, [x29, #-240]
   193d4:	a95513f1 	ldp	x17, x4, [sp, #336]
   193d8:	aa0b03fe 	mov	x30, x11
   193dc:	a9728faa 	ldp	x10, x3, [x29, #-216]
   193e0:	aa0003eb 	mov	x11, x0
   193e4:	f94073e1 	ldr	x1, [sp, #224]
   193e8:	f85383a0 	ldur	x0, [x29, #-200]
   193ec:	17fffea9 	b	18e90 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xb14>
   193f0:	f81383a0 	stur	x0, [x29, #-200]
   193f4:	aa1403e0 	mov	x0, x20
   193f8:	aa1a03e2 	mov	x2, x26
   193fc:	f90073e1 	str	x1, [sp, #224]
   19400:	aa1503e1 	mov	x1, x21
   19404:	52800023 	mov	w3, #0x1                   	// #1
   19408:	aa1e03fa 	mov	x26, x30
   1940c:	aa0503fb 	mov	x27, x5
   19410:	aa0603ea 	mov	x10, x6
   19414:	3c9103a2 	stur	q2, [x29, #-240]
   19418:	3d805fe1 	str	q1, [sp, #368]
   1941c:	97ffaebd 	bl	4f10 <rfc_wrap>
   19420:	aa0a03e6 	mov	x6, x10
   19424:	aa1b03e5 	mov	x5, x27
   19428:	3dc05fe1 	ldr	q1, [sp, #368]
   1942c:	a9546ff2 	ldp	x18, x27, [sp, #320]
   19430:	3cd103a2 	ldur	q2, [x29, #-240]
   19434:	a95513f1 	ldp	x17, x4, [sp, #336]
   19438:	aa1a03fe 	mov	x30, x26
   1943c:	a9728faa 	ldp	x10, x3, [x29, #-216]
   19440:	aa0003fa 	mov	x26, x0
   19444:	f94073e1 	ldr	x1, [sp, #224]
   19448:	f85383a0 	ldur	x0, [x29, #-200]
   1944c:	17fffe94 	b	18e9c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xb20>
   19450:	aa0003fb 	mov	x27, x0
   19454:	aa1403e0 	mov	x0, x20
   19458:	aa0103ea 	mov	x10, x1
   1945c:	aa1503e1 	mov	x1, x21
   19460:	52800062 	mov	w2, #0x3                   	// #3
   19464:	aa1e03f6 	mov	x22, x30
   19468:	aa0503fa 	mov	x26, x5
   1946c:	aa0603f8 	mov	x24, x6
   19470:	3c9103a2 	stur	q2, [x29, #-240]
   19474:	3d805fe1 	str	q1, [sp, #368]
   19478:	97ffadbd 	bl	4b6c <heap_alloc_miss>
   1947c:	aa1a03e5 	mov	x5, x26
   19480:	aa0a03e1 	mov	x1, x10
   19484:	aa0003fa 	mov	x26, x0
   19488:	a95513f1 	ldp	x17, x4, [sp, #336]
   1948c:	aa1b03e0 	mov	x0, x27
   19490:	a9728faa 	ldp	x10, x3, [x29, #-216]
   19494:	3dc05fe1 	ldr	q1, [sp, #368]
   19498:	a9546ff2 	ldp	x18, x27, [sp, #320]
   1949c:	3cd103a2 	ldur	q2, [x29, #-240]
   194a0:	aa1803e6 	mov	x6, x24
   194a4:	aa1603fe 	mov	x30, x22
   194a8:	17fffe86 	b	18ec0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xb44>
   194ac:	aa0003fb 	mov	x27, x0
   194b0:	aa1403e0 	mov	x0, x20
   194b4:	aa0103ea 	mov	x10, x1
   194b8:	aa1503e1 	mov	x1, x21
   194bc:	52800022 	mov	w2, #0x1                   	// #1
   194c0:	aa1e03ee 	mov	x14, x30
   194c4:	aa0503f6 	mov	x22, x5
   194c8:	aa0603f8 	mov	x24, x6
   194cc:	97ffada8 	bl	4b6c <heap_alloc_miss>
   194d0:	aa1603e5 	mov	x5, x22
   194d4:	aa0a03e1 	mov	x1, x10
   194d8:	aa0003f6 	mov	x22, x0
   194dc:	a95513f1 	ldp	x17, x4, [sp, #336]
   194e0:	aa1b03e0 	mov	x0, x27
   194e4:	a9728faa 	ldp	x10, x3, [x29, #-216]
   194e8:	aa1803e6 	mov	x6, x24
   194ec:	a9546ff2 	ldp	x18, x27, [sp, #320]
   194f0:	aa0e03fe 	mov	x30, x14
   194f4:	17fffe80 	b	18ef4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xb78>
   194f8:	aa0003ee 	mov	x14, x0
   194fc:	aa1403e0 	mov	x0, x20
   19500:	aa0103ea 	mov	x10, x1
   19504:	aa1503e1 	mov	x1, x21
   19508:	52800023 	mov	w3, #0x1                   	// #1
   1950c:	aa1e03eb 	mov	x11, x30
   19510:	aa0503fb 	mov	x27, x5
   19514:	aa0603f8 	mov	x24, x6
   19518:	97ffae7e 	bl	4f10 <rfc_wrap>
   1951c:	aa1b03e5 	mov	x5, x27
   19520:	aa0a03e1 	mov	x1, x10
   19524:	aa1803e6 	mov	x6, x24
   19528:	a9546ff2 	ldp	x18, x27, [sp, #320]
   1952c:	aa0b03fe 	mov	x30, x11
   19530:	a95513f1 	ldp	x17, x4, [sp, #336]
   19534:	aa0003e2 	mov	x2, x0
   19538:	a9728faa 	ldp	x10, x3, [x29, #-216]
   1953c:	aa0e03e0 	mov	x0, x14
   19540:	17fffe73 	b	18f0c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xb90>
   19544:	aa0003ee 	mov	x14, x0
   19548:	aa1403e0 	mov	x0, x20
   1954c:	aa0103ea 	mov	x10, x1
   19550:	aa1503e1 	mov	x1, x21
   19554:	aa0803e2 	mov	x2, x8
   19558:	52800023 	mov	w3, #0x1                   	// #1
   1955c:	aa1e03ed 	mov	x13, x30
   19560:	aa0503fb 	mov	x27, x5
   19564:	aa0603f8 	mov	x24, x6
   19568:	97ffae6a 	bl	4f10 <rfc_wrap>
   1956c:	aa1b03e5 	mov	x5, x27
   19570:	aa0a03e1 	mov	x1, x10
   19574:	aa1803e6 	mov	x6, x24
   19578:	a9546ff2 	ldp	x18, x27, [sp, #320]
   1957c:	aa0d03fe 	mov	x30, x13
   19580:	a95513f1 	ldp	x17, x4, [sp, #336]
   19584:	aa0003e8 	mov	x8, x0
   19588:	a9728faa 	ldp	x10, x3, [x29, #-216]
   1958c:	aa0e03e0 	mov	x0, x14
   19590:	17fffe68 	b	18f30 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xbb4>
   19594:	aa1403e0 	mov	x0, x20
   19598:	aa1503e1 	mov	x1, x21
   1959c:	528000a2 	mov	w2, #0x5                   	// #5
   195a0:	97ffad73 	bl	4b6c <heap_alloc_miss>
   195a4:	aa0003f7 	mov	x23, x0
   195a8:	17fffcc0 	b	188a8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x52c>
   195ac:	aa1403e0 	mov	x0, x20
   195b0:	aa1503e1 	mov	x1, x21
   195b4:	528000a2 	mov	w2, #0x5                   	// #5
   195b8:	97ffad6d 	bl	4b6c <heap_alloc_miss>
   195bc:	17fffcd1 	b	18900 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x584>
   195c0:	aa1403e0 	mov	x0, x20
   195c4:	aa0e03e1 	mov	x1, x14
   195c8:	52800022 	mov	w2, #0x1                   	// #1
   195cc:	aa0603ea 	mov	x10, x6
   195d0:	f9008fef 	str	x15, [sp, #280]
   195d4:	aa1003fb 	mov	x27, x16
   195d8:	aa1403f8 	mov	x24, x20
   195dc:	aa1203f4 	mov	x20, x18
   195e0:	aa0503f9 	mov	x25, x5
   195e4:	97ffab9f 	bl	4460 <heap_hand>
   195e8:	52909ff1 	mov	w17, #0x84ff                	// #34047
   195ec:	aa1903e5 	mov	x5, x25
   195f0:	f940b7e2 	ldr	x2, [sp, #360]
   195f4:	aa1403f2 	mov	x18, x20
   195f8:	aa1803f4 	mov	x20, x24
   195fc:	f85503b9 	ldur	x25, [x29, #-176]
   19600:	f9409ff8 	ldr	x24, [sp, #312]
   19604:	f9408fef 	ldr	x15, [sp, #280]
   19608:	72a06211 	movk	w17, #0x310, lsl #16
   1960c:	14000023 	b	19698 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x131c>
   19610:	aa1403e0 	mov	x0, x20
   19614:	aa1503e1 	mov	x1, x21
   19618:	52800062 	mov	w2, #0x3                   	// #3
   1961c:	aa0503fb 	mov	x27, x5
   19620:	aa1e03eb 	mov	x11, x30
   19624:	97ffab8f 	bl	4460 <heap_hand>
   19628:	f940b7e2 	ldr	x2, [sp, #360]
   1962c:	f9407bf5 	ldr	x21, [sp, #240]
   19630:	aa0b03fe 	mov	x30, x11
   19634:	f85503b9 	ldur	x25, [x29, #-176]
   19638:	f9409ff8 	ldr	x24, [sp, #312]
   1963c:	14000044 	b	1974c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x13d0>
   19640:	aa098168 	orr	x8, x11, x9, lsl #32
   19644:	aa1403e0 	mov	x0, x20
   19648:	aa1503e1 	mov	x1, x21
   1964c:	52800044 	mov	w4, #0x2                   	// #2
   19650:	f9008bfa 	str	x26, [sp, #272]
   19654:	aa0603ea 	mov	x10, x6
   19658:	d358fd03 	lsr	x3, x8, #24
   1965c:	aa1003fb 	mov	x27, x16
   19660:	aa1403f5 	mov	x21, x20
   19664:	aa0503fc 	mov	x28, x5
   19668:	8b030e88 	add	x8, x20, x3, lsl #3
   1966c:	aa1203f4 	mov	x20, x18
   19670:	a9402d0c 	ldp	x12, x11, [x8]
   19674:	97ffabae 	bl	452c <span_fade>
   19678:	52909ff1 	mov	w17, #0x84ff                	// #34047
   1967c:	f85503b9 	ldur	x25, [x29, #-176]
   19680:	f9408bfa 	ldr	x26, [sp, #272]
   19684:	f940b7e2 	ldr	x2, [sp, #360]
   19688:	72a06211 	movk	w17, #0x310, lsl #16
   1968c:	aa1c03e5 	mov	x5, x28
   19690:	aa1403f2 	mov	x18, x20
   19694:	aa1503f4 	mov	x20, x21
   19698:	aa1b03f0 	mov	x16, x27
   1969c:	aa0a03e6 	mov	x6, x10
   196a0:	17fffd00 	b	18aa0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x724>
   196a4:	aa098148 	orr	x8, x10, x9, lsl #32
   196a8:	f9407bf6 	ldr	x22, [sp, #240]
   196ac:	aa1403e0 	mov	x0, x20
   196b0:	aa0c03e2 	mov	x2, x12
   196b4:	52800044 	mov	w4, #0x2                   	// #2
   196b8:	aa1803f9 	mov	x25, x24
   196bc:	d358fd03 	lsr	x3, x8, #24
   196c0:	aa1603e1 	mov	x1, x22
   196c4:	f9008fef 	str	x15, [sp, #280]
   196c8:	aa0603ec 	mov	x12, x6
   196cc:	aa1003fb 	mov	x27, x16
   196d0:	aa1403f5 	mov	x21, x20
   196d4:	8b030e88 	add	x8, x20, x3, lsl #3
   196d8:	aa1203f4 	mov	x20, x18
   196dc:	aa0503f8 	mov	x24, x5
   196e0:	a9402909 	ldp	x9, x10, [x8]
   196e4:	97ffab92 	bl	452c <span_fade>
   196e8:	52909ff1 	mov	w17, #0x84ff                	// #34047
   196ec:	aa1803e5 	mov	x5, x24
   196f0:	f9408fef 	ldr	x15, [sp, #280]
   196f4:	aa1903f8 	mov	x24, x25
   196f8:	f85503b9 	ldur	x25, [x29, #-176]
   196fc:	f940b7e2 	ldr	x2, [sp, #360]
   19700:	aa0a03fe 	mov	x30, x10
   19704:	72a06211 	movk	w17, #0x310, lsl #16
   19708:	aa1403f2 	mov	x18, x20
   1970c:	aa1503f4 	mov	x20, x21
   19710:	aa1603f5 	mov	x21, x22
   19714:	aa1b03f7 	mov	x23, x27
   19718:	aa0c03e6 	mov	x6, x12
   1971c:	17fffd26 	b	18bb4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x838>
   19720:	aa1403e0 	mov	x0, x20
   19724:	aa1503e1 	mov	x1, x21
   19728:	aa0b03e2 	mov	x2, x11
   1972c:	aa0e03e3 	mov	x3, x14
   19730:	528000a4 	mov	w4, #0x5                   	// #5
   19734:	aa1e03eb 	mov	x11, x30
   19738:	97ffab7d 	bl	452c <span_fade>
   1973c:	aa1903f8 	mov	x24, x25
   19740:	f940b7e2 	ldr	x2, [sp, #360]
   19744:	f85503b9 	ldur	x25, [x29, #-176]
   19748:	aa0b03fe 	mov	x30, x11
   1974c:	aa1b03e5 	mov	x5, x27
   19750:	17fffd55 	b	18ca4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x928>
   19754:	aa1403e0 	mov	x0, x20
   19758:	aa1503e1 	mov	x1, x21
   1975c:	528000a2 	mov	w2, #0x5                   	// #5
   19760:	97ffad03 	bl	4b6c <heap_alloc_miss>
   19764:	aa0003f3 	mov	x19, x0
   19768:	17fffe70 	b	19128 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xdac>
   1976c:	aa1403e0 	mov	x0, x20
   19770:	aa1503e1 	mov	x1, x21
   19774:	528000a2 	mov	w2, #0x5                   	// #5
   19778:	97ffacfd 	bl	4b6c <heap_alloc_miss>
   1977c:	17fffe81 	b	19180 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xe04>
   19780:	aa1403e0 	mov	x0, x20
   19784:	aa1503e1 	mov	x1, x21
   19788:	2a1f03e2 	mov	w2, wzr
   1978c:	aa0603ed 	mov	x13, x6
   19790:	a9113ffa 	stp	x26, x15, [sp, #272]
   19794:	aa1003fb 	mov	x27, x16
   19798:	aa1403f5 	mov	x21, x20
   1979c:	aa1203f4 	mov	x20, x18
   197a0:	aa0503f3 	mov	x19, x5
   197a4:	97ffab2f 	bl	4460 <heap_hand>
   197a8:	a9513ffa 	ldp	x26, x15, [sp, #272]
   197ac:	52909ff1 	mov	w17, #0x84ff                	// #34047
   197b0:	f85503b9 	ldur	x25, [x29, #-176]
   197b4:	72a06211 	movk	w17, #0x310, lsl #16
   197b8:	aa1303e5 	mov	x5, x19
   197bc:	aa1403f2 	mov	x18, x20
   197c0:	aa1503f4 	mov	x20, x21
   197c4:	aa1b03f0 	mov	x16, x27
   197c8:	aa0d03e6 	mov	x6, x13
   197cc:	17fffca5 	b	18a60 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x6e4>
   197d0:	aa1403e0 	mov	x0, x20
   197d4:	aa0e03e1 	mov	x1, x14
   197d8:	2a1f03e2 	mov	w2, wzr
   197dc:	aa0603ed 	mov	x13, x6
   197e0:	f9008fef 	str	x15, [sp, #280]
   197e4:	aa1003fb 	mov	x27, x16
   197e8:	aa1403f8 	mov	x24, x20
   197ec:	aa1203f4 	mov	x20, x18
   197f0:	aa0503fc 	mov	x28, x5
   197f4:	aa1e03ec 	mov	x12, x30
   197f8:	97ffab1a 	bl	4460 <heap_hand>
   197fc:	52909ff1 	mov	w17, #0x84ff                	// #34047
   19800:	aa1403f2 	mov	x18, x20
   19804:	aa1803f4 	mov	x20, x24
   19808:	f85503b9 	ldur	x25, [x29, #-176]
   1980c:	f9409ff8 	ldr	x24, [sp, #312]
   19810:	f9408fef 	ldr	x15, [sp, #280]
   19814:	aa0c03fe 	mov	x30, x12
   19818:	72a06211 	movk	w17, #0x310, lsl #16
   1981c:	aa1c03e5 	mov	x5, x28
   19820:	aa1b03f0 	mov	x16, x27
   19824:	aa0d03e6 	mov	x6, x13
   19828:	17fffcbb 	b	18b14 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x798>
   1982c:	aa1403e0 	mov	x0, x20
   19830:	aa1503e1 	mov	x1, x21
   19834:	2a1f03e2 	mov	w2, wzr
   19838:	aa1603f7 	mov	x23, x22
   1983c:	aa1e03f6 	mov	x22, x30
   19840:	97ffab08 	bl	4460 <heap_hand>
   19844:	aa1603fe 	mov	x30, x22
   19848:	aa1703f6 	mov	x22, x23
   1984c:	17fffd02 	b	18c54 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0x8d8>
   19850:	aa1403e0 	mov	x0, x20
   19854:	aa1503e1 	mov	x1, x21
   19858:	528000a2 	mov	w2, #0x5                   	// #5
   1985c:	97ffacc4 	bl	4b6c <heap_alloc_miss>
   19860:	aa0003f3 	mov	x19, x0
   19864:	17fffe6f 	b	19220 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xea4>
   19868:	aa1403e0 	mov	x0, x20
   1986c:	aa1503e1 	mov	x1, x21
   19870:	528000a2 	mov	w2, #0x5                   	// #5
   19874:	97ffacbe 	bl	4b6c <heap_alloc_miss>
   19878:	17fffe80 	b	19278 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0+0xefc>

