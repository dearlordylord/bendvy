   1b0b8:	d10243ff 	sub	sp, sp, #0x90
   1b0bc:	a9087bfd 	stp	x29, x30, [sp, #128]
   1b0c0:	910203fd 	add	x29, sp, #0x80
   1b0c4:	f9402fa8 	ldr	x8, [x29, #88]
   1b0c8:	a93e3fac 	stp	x12, x15, [x29, #-32]
   1b0cc:	aa1603f0 	mov	x16, x22
   1b0d0:	f81d83aa 	stur	x10, [x29, #-40]
   1b0d4:	a943cbb1 	ldp	x17, x18, [x29, #56]
   1b0d8:	f81f03a8 	stur	x8, [x29, #-16]
   1b0dc:	f9400bb3 	ldr	x19, [x29, #16]
   1b0e0:	a944a3ac 	ldp	x12, x8, [x29, #72]
   1b0e4:	a942fba2 	ldp	x2, x30, [x29, #40]
   1b0e8:	a941abb8 	ldp	x24, x10, [x29, #24]
   1b0ec:	b85f8ecf 	ldr	w15, [x22, #-8]!
   1b0f0:	340003b7 	cbz	w23, 1b164 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K211+0xac>
   1b0f4:	a904a3ac 	stp	x12, x8, [x29, #72]
   1b0f8:	f85f03a8 	ldur	x8, [x29, #-16]
   1b0fc:	2a0a03f0 	mov	w16, w10
   1b100:	f90033af 	str	x15, [x29, #96]
   1b104:	2a1e03ef 	mov	w15, w30
   1b108:	f85d83aa 	ldur	x10, [x29, #-40]
   1b10c:	2a0803e8 	mov	w8, w8
   1b110:	2a1903f9 	mov	w25, w25
   1b114:	2a1a03fa 	mov	w26, w26
   1b118:	f9002fa8 	str	x8, [x29, #88]
   1b11c:	2a0203e8 	mov	w8, w2
   1b120:	2a0503e5 	mov	w5, w5
   1b124:	a902bfa8 	stp	x8, x15, [x29, #40]
   1b128:	a97e23ac 	ldp	x12, x8, [x29, #-32]
   1b12c:	2a0703e7 	mov	w7, w7
   1b130:	a903cbb1 	stp	x17, x18, [x29, #56]
   1b134:	2a0b03eb 	mov	w11, w11
   1b138:	2a0d03ed 	mov	w13, w13
   1b13c:	2a0e03ee 	mov	w14, w14
   1b140:	2a0903e9 	mov	w9, w9
   1b144:	2a0803ef 	mov	w15, w8
   1b148:	2a1803e8 	mov	w8, w24
   1b14c:	a901c3a8 	stp	x8, x16, [x29, #24]
   1b150:	2a1303f0 	mov	w16, w19
   1b154:	f9000bb0 	str	x16, [x29, #16]
   1b158:	a9487bfd 	ldp	x29, x30, [sp, #128]
   1b15c:	910243ff 	add	sp, sp, #0x90
   1b160:	17fff501 	b	18564 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_FALLBACK>
   1b164:	aa0203f6 	mov	x22, x2
   1b168:	a97e5e02 	ldp	x2, x23, [x16, #-32]
   1b16c:	a90333fe 	stp	x30, x12, [sp, #48]
   1b170:	f81c83b2 	stur	x18, [x29, #-56]
   1b174:	f90023f1 	str	x17, [sp, #64]
   1b178:	f81d03a8 	stur	x8, [x29, #-48]
   1b17c:	f94016a8 	ldr	x8, [x21, #40]
   1b180:	b40006a8 	cbz	x8, 1b254 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K211+0x19c>
   1b184:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   1b188:	f94096b1 	ldr	x17, [x21, #296]
   1b18c:	f90016b0 	str	x16, [x21, #40]
   1b190:	d1008230 	sub	x16, x17, #0x20
   1b194:	f90096b0 	str	x16, [x21, #296]
   1b198:	8b080e90 	add	x16, x20, x8, lsl #3
   1b19c:	2a0b03eb 	mov	w11, w11
   1b1a0:	d3607ef1 	lsl	x17, x23, #32
   1b1a4:	2a1a03f2 	mov	w18, w26
   1b1a8:	f900320b 	str	x11, [x16, #96]
   1b1ac:	a97dafac 	ldp	x12, x11, [x29, #-40]
   1b1b0:	f9007a11 	str	x17, [x16, #240]
   1b1b4:	2a1903f1 	mov	w17, w25
   1b1b8:	f900360b 	str	x11, [x16, #104]
   1b1bc:	2a0d03eb 	mov	w11, w13
   1b1c0:	2a0e03ed 	mov	w13, w14
   1b1c4:	a907360b 	stp	x11, x13, [x16, #112]
   1b1c8:	2a0903eb 	mov	w11, w9
   1b1cc:	f85e83a9 	ldur	x9, [x29, #-24]
   1b1d0:	a9004a11 	stp	x17, x18, [x16]
   1b1d4:	2a0503f1 	mov	w17, w5
   1b1d8:	a9041a11 	stp	x17, x6, [x16, #64]
   1b1dc:	2a0703f1 	mov	w17, w7
   1b1e0:	2a0903ed 	mov	w13, w9
   1b1e4:	a9053211 	stp	x17, x12, [x16, #80]
   1b1e8:	2a1803ec 	mov	w12, w24
   1b1ec:	f9401be9 	ldr	x9, [sp, #48]
   1b1f0:	a908360b 	stp	x11, x13, [x16, #128]
   1b1f4:	2a1303eb 	mov	w11, w19
   1b1f8:	a909320b 	stp	x11, x12, [x16, #144]
   1b1fc:	2a0a03eb 	mov	w11, w10
   1b200:	2a1603ea 	mov	w10, w22
   1b204:	a90a2a0b 	stp	x11, x10, [x16, #160]
   1b208:	2a0903ea 	mov	w10, w9
   1b20c:	a943afe9 	ldp	x9, x11, [sp, #56]
   1b210:	a901721b 	stp	x27, x28, [x16, #16]
   1b214:	a90b2e0a 	stp	x10, x11, [x16, #176]
   1b218:	f85c83aa 	ldur	x10, [x29, #-56]
   1b21c:	a9020600 	stp	x0, x1, [x16, #32]
   1b220:	a90c260a 	stp	x10, x9, [x16, #192]
   1b224:	f85f03a9 	ldur	x9, [x29, #-16]
   1b228:	a9031203 	stp	x3, x4, [x16, #48]
   1b22c:	2a0903ea 	mov	w10, w9
   1b230:	f85d03a9 	ldur	x9, [x29, #-48]
   1b234:	a90d2a09 	stp	x9, x10, [x16, #208]
   1b238:	d2c5e00a 	mov	x10, #0x2f0000000000        	// #51677046505472
   1b23c:	f2e0a00a 	movk	x10, #0x500, lsl #48
   1b240:	aa0a0100 	orr	x0, x8, x10
   1b244:	a90e0a0f 	stp	x15, x2, [x16, #224]
   1b248:	a9487bfd 	ldp	x29, x30, [sp, #128]
   1b24c:	910243ff 	add	sp, sp, #0x90
   1b250:	d65f03c0 	ret
   1b254:	a90203e1 	stp	x1, x0, [sp, #32]
   1b258:	aa1403e0 	mov	x0, x20
   1b25c:	aa1503e1 	mov	x1, x21
   1b260:	aa0203ec 	mov	x12, x2
   1b264:	528000a2 	mov	w2, #0x5                   	// #5
   1b268:	a9001be7 	stp	x7, x6, [sp]
   1b26c:	aa0403f5 	mov	x21, x4
   1b270:	a9010fe5 	stp	x5, x3, [sp, #16]
   1b274:	97ffa707 	bl	4e90 <heap_alloc_miss>
   1b278:	a9410fe5 	ldp	x5, x3, [sp, #16]
   1b27c:	aa0003e8 	mov	x8, x0
   1b280:	a9401be7 	ldp	x7, x6, [sp]
   1b284:	aa0c03e2 	mov	x2, x12
   1b288:	a94203e1 	ldp	x1, x0, [sp, #32]
   1b28c:	aa1503e4 	mov	x4, x21
   1b290:	17ffffc2 	b	1b198 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K211+0xe0>

