   17e68:	d10303ff 	sub	sp, sp, #0xc0
   17e6c:	a90b7bfd 	stp	x29, x30, [sp, #176]
   17e70:	9102c3fd 	add	x29, sp, #0xb0
   17e74:	a93e3fa9 	stp	x9, x15, [x29, #-32]
   17e78:	a943c7b2 	ldp	x18, x17, [x29, #56]
   17e7c:	f81f03ac 	stur	x12, [x29, #-16]
   17e80:	aa0e03e8 	mov	x8, x14
   17e84:	aa0d03ee 	mov	x14, x13
   17e88:	a944b3b0 	ldp	x16, x12, [x29, #72]
   17e8c:	f9400bb8 	ldr	x24, [x29, #16]
   17e90:	a9428bbe 	ldp	x30, x2, [x29, #40]
   17e94:	f85e02c9 	ldur	x9, [x22, #-32]
   17e98:	3cde82c2 	ldur	q2, [x22, #-24]
   17e9c:	f85f82cd 	ldur	x13, [x22, #-8]
   17ea0:	a941bfb3 	ldp	x19, x15, [x29, #24]
   17ea4:	340004f7 	cbz	w23, 17f40 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K159+0xd8>
   17ea8:	6e024040 	ext	v0.16b, v2.16b, v2.16b, #8
   17eac:	6f00e5e2 	movi	v2.2d, #0xffffffff
   17eb0:	2a1903f9 	mov	w25, w25
   17eb4:	2a1a03fa 	mov	w26, w26
   17eb8:	2a0503e5 	mov	w5, w5
   17ebc:	2a0703e7 	mov	w7, w7
   17ec0:	2a0b03eb 	mov	w11, w11
   17ec4:	4ea01c01 	mov	v1.16b, v0.16b
   17ec8:	4e181da0 	mov	v0.d[1], x13
   17ecc:	2a0e03ed 	mov	w13, w14
   17ed0:	4e081d21 	mov	v1.d[0], x9
   17ed4:	aa0803e9 	mov	x9, x8
   17ed8:	528005a8 	mov	w8, #0x2d                  	// #45
   17edc:	4e221c00 	and	v0.16b, v0.16b, v2.16b
   17ee0:	f90002c8 	str	x8, [x22]
   17ee4:	2a0203e8 	mov	w8, w2
   17ee8:	2a0903ee 	mov	w14, w9
   17eec:	4e221c21 	and	v1.16b, v1.16b, v2.16b
   17ef0:	ad3f02c1 	stp	q1, q0, [x22, #-32]
   17ef4:	910022d6 	add	x22, x22, #0x8
   17ef8:	f9001ba8 	str	x8, [x29, #48]
   17efc:	2a1e03e8 	mov	w8, w30
   17f00:	f90017a8 	str	x8, [x29, #40]
   17f04:	2a0f03e8 	mov	w8, w15
   17f08:	f90013a8 	str	x8, [x29, #32]
   17f0c:	2a1303e8 	mov	w8, w19
   17f10:	f9000fa8 	str	x8, [x29, #24]
   17f14:	f85e03a8 	ldur	x8, [x29, #-32]
   17f18:	a904b3b0 	stp	x16, x12, [x29, #72]
   17f1c:	2a0803e9 	mov	w9, w8
   17f20:	a97eb3a8 	ldp	x8, x12, [x29, #-24]
   17f24:	a903c7b2 	stp	x18, x17, [x29, #56]
   17f28:	2a0803ef 	mov	w15, w8
   17f2c:	2a1803e8 	mov	w8, w24
   17f30:	f9000ba8 	str	x8, [x29, #16]
   17f34:	a94b7bfd 	ldp	x29, x30, [sp, #176]
   17f38:	910303ff 	add	sp, sp, #0xc0
   17f3c:	17ffde93 	b	f988 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_TRANSACTION_DISPATCH_ADAPTERS_MOTION_READ_LEDGER>
   17f40:	a93c3fb3 	stp	x19, x15, [x29, #-64]
   17f44:	aa0803f3 	mov	x19, x8
   17f48:	f9401aa8 	ldr	x8, [x21, #48]
   17f4c:	a93d7bb8 	stp	x24, x30, [x29, #-48]
   17f50:	a904cbe2 	stp	x2, x18, [sp, #72]
   17f54:	f9002ff1 	str	x17, [sp, #88]
   17f58:	a93b33b0 	stp	x16, x12, [x29, #-80]
   17f5c:	a97cb2d7 	ldp	x23, x12, [x22, #-56]
   17f60:	b4000aa8 	cbz	x8, 180b4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K159+0x24c>
   17f64:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   17f68:	f9409ab1 	ldr	x17, [x21, #304]
   17f6c:	f9001ab0 	str	x16, [x21, #48]
   17f70:	d1010230 	sub	x16, x17, #0x40
   17f74:	f9009ab0 	str	x16, [x21, #304]
   17f78:	6f07e7e0 	movi	v0.2d, #0xffffffffffffffff
   17f7c:	6f00e5e1 	movi	v1.2d, #0xffffffff
   17f80:	52800032 	mov	w18, #0x1                   	// #1
   17f84:	8b080e90 	add	x16, x20, x8, lsl #3
   17f88:	aa0c824c 	orr	x12, x18, x12, lsl #32
   17f8c:	92800011 	mov	x17, #0xffffffffffffffff    	// #-1
   17f90:	2a0903e9 	mov	w9, w9
   17f94:	a97d4bb8 	ldp	x24, x18, [x29, #-48]
   17f98:	f9009a0c 	str	x12, [x16, #304]
   17f9c:	d2c5a00c 	mov	x12, #0x2d0000000000        	// #49478023249920
   17fa0:	ad010200 	stp	q0, q0, [x16, #32]
   17fa4:	f2e0a00c 	movk	x12, #0x500, lsl #48
   17fa8:	ad020200 	stp	q0, q0, [x16, #64]
   17fac:	a97c3fa2 	ldp	x2, x15, [x29, #-64]
   17fb0:	ad030200 	stp	q0, q0, [x16, #96]
   17fb4:	ad040200 	stp	q0, q0, [x16, #128]
   17fb8:	ad050200 	stp	q0, q0, [x16, #160]
   17fbc:	ad060200 	stp	q0, q0, [x16, #192]
   17fc0:	ad070200 	stp	q0, q0, [x16, #224]
   17fc4:	ad080200 	stp	q0, q0, [x16, #256]
   17fc8:	4e211c40 	and	v0.16b, v2.16b, v1.16b
   17fcc:	a9125e11 	stp	x17, x23, [x16, #288]
   17fd0:	aa0c0117 	orr	x23, x8, x12
   17fd4:	52800088 	mov	w8, #0x4                   	// #4
   17fd8:	f9000209 	str	x9, [x16]
   17fdc:	2a0d03e9 	mov	w9, w13
   17fe0:	3c808200 	stur	q0, [x16, #8]
   17fe4:	f9000e09 	str	x9, [x16, #24]
   17fe8:	a93ca2d7 	stp	x23, x8, [x22, #-56]
   17fec:	f94016a8 	ldr	x8, [x21, #40]
   17ff0:	b4000848 	cbz	x8, 180f8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K159+0x290>
   17ff4:	f8687a89 	ldr	x9, [x20, x8, lsl #3]
   17ff8:	f94096ac 	ldr	x12, [x21, #296]
   17ffc:	f90016a9 	str	x9, [x21, #40]
   18000:	d1008189 	sub	x9, x12, #0x20
   18004:	f90096a9 	str	x9, [x21, #296]
   18008:	8b080e91 	add	x17, x20, x8, lsl #3
   1800c:	d2c00089 	mov	x9, #0x400000000           	// #17179869184
   18010:	2a1a03f0 	mov	w16, w26
   18014:	2a0b03eb 	mov	w11, w11
   18018:	2a1303ed 	mov	w13, w19
   1801c:	f9007229 	str	x9, [x17, #224]
   18020:	2a1903e9 	mov	w9, w25
   18024:	a9004229 	stp	x9, x16, [x17]
   18028:	2a0503e9 	mov	w9, w5
   1802c:	a9041a29 	stp	x9, x6, [x17, #64]
   18030:	2a0703e9 	mov	w9, w7
   18034:	a9052a29 	stp	x9, x10, [x17, #80]
   18038:	f85f03a9 	ldur	x9, [x29, #-16]
   1803c:	a9020620 	stp	x0, x1, [x17, #32]
   18040:	a906262b 	stp	x11, x9, [x17, #96]
   18044:	a97e27aa 	ldp	x10, x9, [x29, #-32]
   18048:	2a0e03eb 	mov	w11, w14
   1804c:	a901723b 	stp	x27, x28, [x17, #16]
   18050:	a907362b 	stp	x11, x13, [x17, #112]
   18054:	2a0a03eb 	mov	w11, w10
   18058:	2a0903ed 	mov	w13, w9
   1805c:	2a1803ea 	mov	w10, w24
   18060:	a908362b 	stp	x11, x13, [x17, #128]
   18064:	2a0203eb 	mov	w11, w2
   18068:	2a1203e9 	mov	w9, w18
   1806c:	a9092e2a 	stp	x10, x11, [x17, #144]
   18070:	2a0f03ea 	mov	w10, w15
   18074:	a90a262a 	stp	x10, x9, [x17, #160]
   18078:	f94027e9 	ldr	x9, [sp, #72]
   1807c:	a9031223 	stp	x3, x4, [x17, #48]
   18080:	2a0903e9 	mov	w9, w9
   18084:	f9006e37 	str	x23, [x17, #216]
   18088:	f9005a29 	str	x9, [x17, #176]
   1808c:	a94527ea 	ldp	x10, x9, [sp, #80]
   18090:	a90ba62a 	stp	x10, x9, [x17, #184]
   18094:	d2c28009 	mov	x9, #0x140000000000        	// #21990232555520
   18098:	f2e0a009 	movk	x9, #0x500, lsl #48
   1809c:	aa090100 	orr	x0, x8, x9
   180a0:	a97b23aa 	ldp	x10, x8, [x29, #-80]
   180a4:	a90ca22a 	stp	x10, x8, [x17, #200]
   180a8:	a94b7bfd 	ldp	x29, x30, [sp, #176]
   180ac:	910303ff 	add	sp, sp, #0xc0
   180b0:	d65f03c0 	ret
   180b4:	a90383e1 	stp	x1, x0, [sp, #56]
   180b8:	aa1403e0 	mov	x0, x20
   180bc:	aa1503e1 	mov	x1, x21
   180c0:	528000c2 	mov	w2, #0x6                   	// #6
   180c4:	a9029be3 	stp	x3, x6, [sp, #40]
   180c8:	a9011fe4 	stp	x4, x7, [sp, #16]
   180cc:	f90013e5 	str	x5, [sp, #32]
   180d0:	3d8003e2 	str	q2, [sp]
   180d4:	97ffb36f 	bl	4e90 <heap_alloc_miss>
   180d8:	a94197e7 	ldp	x7, x5, [sp, #24]
   180dc:	aa0003e8 	mov	x8, x0
   180e0:	a94307e6 	ldp	x6, x1, [sp, #48]
   180e4:	3dc003e2 	ldr	q2, [sp]
   180e8:	f94017e3 	ldr	x3, [sp, #40]
   180ec:	f9400be4 	ldr	x4, [sp, #16]
   180f0:	f94023e0 	ldr	x0, [sp, #64]
   180f4:	17ffffa1 	b	17f78 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K159+0x110>
   180f8:	a90383e1 	stp	x1, x0, [sp, #56]
   180fc:	aa1403e0 	mov	x0, x20
   18100:	aa1503e1 	mov	x1, x21
   18104:	528000a2 	mov	w2, #0x5                   	// #5
   18108:	f9001be6 	str	x6, [sp, #48]
   1810c:	aa0403e9 	mov	x9, x4
   18110:	aa0303f5 	mov	x21, x3
   18114:	aa0703ec 	mov	x12, x7
   18118:	aa0503f6 	mov	x22, x5
   1811c:	97ffb35d 	bl	4e90 <heap_alloc_miss>
   18120:	a97c3fa2 	ldp	x2, x15, [x29, #-64]
   18124:	aa0003e8 	mov	x8, x0
   18128:	a97d4bb8 	ldp	x24, x18, [x29, #-48]
   1812c:	aa1603e5 	mov	x5, x22
   18130:	a94307e6 	ldp	x6, x1, [sp, #48]
   18134:	aa0c03e7 	mov	x7, x12
   18138:	f94023e0 	ldr	x0, [sp, #64]
   1813c:	aa1503e3 	mov	x3, x21
   18140:	aa0903e4 	mov	x4, x9
   18144:	17ffffb1 	b	18008 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K159+0x1a0>

