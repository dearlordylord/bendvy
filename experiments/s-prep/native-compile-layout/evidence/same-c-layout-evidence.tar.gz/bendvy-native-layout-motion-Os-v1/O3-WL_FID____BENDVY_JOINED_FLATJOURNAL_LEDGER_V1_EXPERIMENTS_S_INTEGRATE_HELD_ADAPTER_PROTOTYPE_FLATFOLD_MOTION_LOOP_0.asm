   1bfe4:	d10383ff 	sub	sp, sp, #0xe0
   1bfe8:	a90d7bfd 	stp	x29, x30, [sp, #208]
   1bfec:	910343fd 	add	x29, sp, #0xd0
   1bff0:	aa0b03fe 	mov	x30, x11
   1bff4:	a945a3ab 	ldp	x11, x8, [x29, #88]
   1bff8:	a93eb7a5 	stp	x5, x13, [x29, #-24]
   1bffc:	aa0c03f2 	mov	x18, x12
   1c000:	aa0703f3 	mov	x19, x7
   1c004:	a93da3a3 	stp	x3, x8, [x29, #-40]
   1c008:	aa0103e3 	mov	x3, x1
   1c00c:	aa0003e1 	mov	x1, x0
   1c010:	a944a3a5 	ldp	x5, x8, [x29, #72]
   1c014:	aa1c03e0 	mov	x0, x28
   1c018:	a943b3a2 	ldp	x2, x12, [x29, #56]
   1c01c:	a9429fad 	ldp	x13, x7, [x29, #40]
   1c020:	aa0903f8 	mov	x24, x9
   1c024:	a941c3bc 	ldp	x28, x16, [x29, #24]
   1c028:	f81d03a8 	stur	x8, [x29, #-48]
   1c02c:	92583f28 	and	x8, x25, #0xffff0000000000
   1c030:	d2c1c009 	mov	x9, #0xe0000000000         	// #15393162788864
   1c034:	f9400bb1 	ldr	x17, [x29, #16]
   1c038:	eb09011f 	cmp	x8, x9
   1c03c:	54000541 	b.ne	1c0e4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x100>  // b.any
   1c040:	b85f8ec8 	ldr	w8, [x22, #-8]!
   1c044:	d0000c89 	adrp	x9, 1ae000 <io_eff_rows+0xff118>
   1c048:	913f2129 	add	x9, x9, #0xfc8
   1c04c:	aa0203f9 	mov	x25, x2
   1c050:	f8687922 	ldr	x2, [x9, x8, lsl #3]
   1c054:	f85d03a8 	ldur	x8, [x29, #-48]
   1c058:	a90397ac 	stp	x12, x5, [x29, #56]
   1c05c:	2a0603e5 	mov	w5, w6
   1c060:	2a0f03e9 	mov	w9, w15
   1c064:	2a1103ef 	mov	w15, w17
   1c068:	a904afa8 	stp	x8, x11, [x29, #72]
   1c06c:	f85e03a8 	ldur	x8, [x29, #-32]
   1c070:	aa1303e6 	mov	x6, x19
   1c074:	2a0803e8 	mov	w8, w8
   1c078:	a905afa8 	stp	x8, x11, [x29, #88]
   1c07c:	2a1903e8 	mov	w8, w25
   1c080:	2a1a03f9 	mov	w25, w26
   1c084:	f9001ba8 	str	x8, [x29, #48]
   1c088:	2a0703e8 	mov	w8, w7
   1c08c:	2a1b03fa 	mov	w26, w27
   1c090:	f90017a8 	str	x8, [x29, #40]
   1c094:	2a0d03e8 	mov	w8, w13
   1c098:	aa0003fb 	mov	x27, x0
   1c09c:	aa0303e0 	mov	x0, x3
   1c0a0:	aa0403e3 	mov	x3, x4
   1c0a4:	f90013a8 	str	x8, [x29, #32]
   1c0a8:	a97eb3a4 	ldp	x4, x12, [x29, #-24]
   1c0ac:	2a0a03e7 	mov	w7, w10
   1c0b0:	2a1c03e8 	mov	w8, w28
   1c0b4:	2a1003ea 	mov	w10, w16
   1c0b8:	aa0103fc 	mov	x28, x1
   1c0bc:	f85d83a1 	ldur	x1, [x29, #-40]
   1c0c0:	2a1203eb 	mov	w11, w18
   1c0c4:	2a0e03ed 	mov	w13, w14
   1c0c8:	2a1803ee 	mov	w14, w24
   1c0cc:	a9012ba8 	stp	x8, x10, [x29, #16]
   1c0d0:	52800398 	mov	w24, #0x1c                  	// #28
   1c0d4:	aa1e03ea 	mov	x10, x30
   1c0d8:	a94d7bfd 	ldp	x29, x30, [sp, #208]
   1c0dc:	910383ff 	add	sp, sp, #0xe0
   1c0e0:	d61f0040 	br	x2
   1c0e4:	92409f28 	and	x8, x25, #0xffffffffff
   1c0e8:	a93a37be 	stp	x30, x13, [x29, #-96]
   1c0ec:	8b080e8d 	add	x13, x20, x8, lsl #3
   1c0f0:	b819c3b7 	stur	w23, [x29, #-100]
   1c0f4:	a93c1fb0 	stp	x16, x7, [x29, #-64]
   1c0f8:	a93b1bbc 	stp	x28, x6, [x29, #-80]
   1c0fc:	b7f800d9 	tbnz	x25, #63, 1c114 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x130>
   1c100:	a9401dbc 	ldp	x28, x7, [x13]
   1c104:	aa0803e9 	mov	x9, x8
   1c108:	aa1303fe 	mov	x30, x19
   1c10c:	aa1803f3 	mov	x19, x24
   1c110:	14000023 	b	1c19c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x1b8>
   1c114:	a904b3f1 	stp	x17, x12, [sp, #72]
   1c118:	aa1203ec 	mov	x12, x18
   1c11c:	aa0303f7 	mov	x23, x3
   1c120:	f9002fea 	str	x10, [sp, #88]
   1c124:	aa0403ea 	mov	x10, x4
   1c128:	aa1303fe 	mov	x30, x19
   1c12c:	b94005a9 	ldr	w9, [x13, #4]
   1c130:	b94001b0 	ldr	w16, [x13]
   1c134:	92405e11 	and	x17, x16, #0xffffff
   1c138:	f100063f 	cmp	x17, #0x1
   1c13c:	540004c1 	b.ne	1c1d4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x1f0>  // b.any
   1c140:	aa098209 	orr	x9, x16, x9, lsl #32
   1c144:	88dffdbf 	ldar	wzr, [x13]
   1c148:	f94002ad 	ldr	x13, [x21]
   1c14c:	aa1803f3 	mov	x19, x24
   1c150:	d358fd29 	lsr	x9, x9, #24
   1c154:	8b090e90 	add	x16, x20, x9, lsl #3
   1c158:	a9401e1c 	ldp	x28, x7, [x16]
   1c15c:	f8287a8d 	str	x13, [x20, x8, lsl #3]
   1c160:	f94082ad 	ldr	x13, [x21, #256]
   1c164:	f90002a8 	str	x8, [x21]
   1c168:	910005a8 	add	x8, x13, #0x1
   1c16c:	90000d6d 	adrp	x13, 1c8000 <ALC+0x17e00>
   1c170:	f90082a8 	str	x8, [x21, #256]
   1c174:	395401ad 	ldrb	w13, [x13, #1280]
   1c178:	710005bf 	cmp	w13, #0x1
   1c17c:	54000601 	b.ne	1c23c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x258>  // b.any
   1c180:	f140211f 	cmp	x8, #0x8, lsl #12
   1c184:	540005c2 	b.cs	1c23c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x258>  // b.hs, b.nlast
   1c188:	aa0a03e4 	mov	x4, x10
   1c18c:	aa0c03f2 	mov	x18, x12
   1c190:	f94027f1 	ldr	x17, [sp, #72]
   1c194:	a9452bec 	ldp	x12, x10, [sp, #80]
   1c198:	aa1703e3 	mov	x3, x23
   1c19c:	aa0f03f8 	mov	x24, x15
   1c1a0:	92409f88 	and	x8, x28, #0xffffffffff
   1c1a4:	52909fed 	mov	w13, #0x84ff                	// #34047
   1c1a8:	f85c83a6 	ldur	x6, [x29, #-56]
   1c1ac:	8b080e90 	add	x16, x20, x8, lsl #3
   1c1b0:	72a0620d 	movk	w13, #0x310, lsl #16
   1c1b4:	b7f8079c 	tbnz	x28, #63, 1c2a4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x2c0>
   1c1b8:	b9400219 	ldr	w25, [x16]
   1c1bc:	b9400a0f 	ldr	w15, [x16, #8]
   1c1c0:	aa0803fc 	mov	x28, x8
   1c1c4:	f90033ef 	str	x15, [sp, #96]
   1c1c8:	eb0d011f 	cmp	x8, x13
   1c1cc:	54000c48 	b.hi	1c354 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x370>  // b.pmore
   1c1d0:	1400006d 	b	1c384 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x3a0>
   1c1d4:	aa098208 	orr	x8, x16, x9, lsl #32
   1c1d8:	a90187e0 	stp	x0, x1, [sp, #24]
   1c1dc:	aa1403e0 	mov	x0, x20
   1c1e0:	aa1503e1 	mov	x1, x21
   1c1e4:	f90033e2 	str	x2, [sp, #96]
   1c1e8:	aa1903e2 	mov	x2, x25
   1c1ec:	d358fd03 	lsr	x3, x8, #24
   1c1f0:	52800044 	mov	w4, #0x2                   	// #2
   1c1f4:	f90023ee 	str	x14, [sp, #64]
   1c1f8:	aa1e03ed 	mov	x13, x30
   1c1fc:	f9001be5 	str	x5, [sp, #48]
   1c200:	8b030e88 	add	x8, x20, x3, lsl #3
   1c204:	a940251c 	ldp	x28, x9, [x8]
   1c208:	97ffa141 	bl	470c <span_fade>
   1c20c:	a94187e0 	ldp	x0, x1, [sp, #24]
   1c210:	aa0a03e4 	mov	x4, x10
   1c214:	a94447ee 	ldp	x14, x17, [sp, #64]
   1c218:	aa0c03f2 	mov	x18, x12
   1c21c:	a9458bea 	ldp	x10, x2, [sp, #88]
   1c220:	aa0903e7 	mov	x7, x9
   1c224:	f9401be5 	ldr	x5, [sp, #48]
   1c228:	f9402bec 	ldr	x12, [sp, #80]
   1c22c:	aa0d03fe 	mov	x30, x13
   1c230:	aa1f03e9 	mov	x9, xzr
   1c234:	aa1703e3 	mov	x3, x23
   1c238:	17ffffb5 	b	1c10c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x128>
   1c23c:	a90187e0 	stp	x0, x1, [sp, #24]
   1c240:	aa1403e0 	mov	x0, x20
   1c244:	aa1503e1 	mov	x1, x21
   1c248:	f90033e2 	str	x2, [sp, #96]
   1c24c:	2a1f03e2 	mov	w2, wzr
   1c250:	aa0703ed 	mov	x13, x7
   1c254:	a900fbef 	stp	x15, x30, [sp, #8]
   1c258:	f90023ee 	str	x14, [sp, #64]
   1c25c:	f9001be5 	str	x5, [sp, #48]
   1c260:	97ffa0f8 	bl	4640 <heap_hand>
   1c264:	a94187e0 	ldp	x0, x1, [sp, #24]
   1c268:	aa0a03e4 	mov	x4, x10
   1c26c:	a94447ee 	ldp	x14, x17, [sp, #64]
   1c270:	aa0c03f2 	mov	x18, x12
   1c274:	a940fbf8 	ldp	x24, x30, [sp, #8]
   1c278:	aa0d03e7 	mov	x7, x13
   1c27c:	a9458bea 	ldp	x10, x2, [sp, #88]
   1c280:	aa1703e3 	mov	x3, x23
   1c284:	f9401be5 	ldr	x5, [sp, #48]
   1c288:	f9402bec 	ldr	x12, [sp, #80]
   1c28c:	92409f88 	and	x8, x28, #0xffffffffff
   1c290:	52909fed 	mov	w13, #0x84ff                	// #34047
   1c294:	f85c83a6 	ldur	x6, [x29, #-56]
   1c298:	8b080e90 	add	x16, x20, x8, lsl #3
   1c29c:	72a0620d 	movk	w13, #0x310, lsl #16
   1c2a0:	b6fff8dc 	tbz	x28, #63, 1c1b8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x1d4>
   1c2a4:	a904b3f1 	stp	x17, x12, [sp, #72]
   1c2a8:	aa0303ef 	mov	x15, x3
   1c2ac:	a9034be5 	stp	x5, x18, [sp, #48]
   1c2b0:	f9002fea 	str	x10, [sp, #88]
   1c2b4:	aa1803ea 	mov	x10, x24
   1c2b8:	aa1e03f8 	mov	x24, x30
   1c2bc:	f90023ee 	str	x14, [sp, #64]
   1c2c0:	f90017f3 	str	x19, [sp, #40]
   1c2c4:	aa0403f3 	mov	x19, x4
   1c2c8:	b9400611 	ldr	w17, [x16, #4]
   1c2cc:	b9400212 	ldr	w18, [x16]
   1c2d0:	92405e59 	and	x25, x18, #0xffffff
   1c2d4:	f100073f 	cmp	x25, #0x1
   1c2d8:	54001e21 	b.ne	1c69c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x6b8>  // b.any
   1c2dc:	aa118251 	orr	x17, x18, x17, lsl #32
   1c2e0:	88dffe1f 	ldar	wzr, [x16]
   1c2e4:	f94002b0 	ldr	x16, [x21]
   1c2e8:	d358fe3c 	lsr	x28, x17, #24
   1c2ec:	8b1c0e91 	add	x17, x20, x28, lsl #3
   1c2f0:	b9400239 	ldr	w25, [x17]
   1c2f4:	b9400a2c 	ldr	w12, [x17, #8]
   1c2f8:	f8287a90 	str	x16, [x20, x8, lsl #3]
   1c2fc:	f94082b0 	ldr	x16, [x21, #256]
   1c300:	f90002a8 	str	x8, [x21]
   1c304:	f90033ec 	str	x12, [sp, #96]
   1c308:	91000608 	add	x8, x16, #0x1
   1c30c:	90000d70 	adrp	x16, 1c8000 <ALC+0x17e00>
   1c310:	f90082a8 	str	x8, [x21, #256]
   1c314:	39540210 	ldrb	w16, [x16, #1280]
   1c318:	7100061f 	cmp	w16, #0x1
   1c31c:	540025c1 	b.ne	1c7d4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x7f0>  // b.any
   1c320:	f140211f 	cmp	x8, #0x8, lsl #12
   1c324:	54002582 	b.cs	1c7d4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x7f0>  // b.hs, b.nlast
   1c328:	aa1803fe 	mov	x30, x24
   1c32c:	aa0a03f8 	mov	x24, x10
   1c330:	aa1303e4 	mov	x4, x19
   1c334:	a94297f3 	ldp	x19, x5, [sp, #40]
   1c338:	f94027f1 	ldr	x17, [sp, #72]
   1c33c:	a943bbf2 	ldp	x18, x14, [sp, #56]
   1c340:	f85c83a6 	ldur	x6, [x29, #-56]
   1c344:	a9452bec 	ldp	x12, x10, [sp, #80]
   1c348:	aa0f03e3 	mov	x3, x15
   1c34c:	eb0d039f 	cmp	x28, x13
   1c350:	540001a9 	b.ls	1c384 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x3a0>  // b.plast
   1c354:	f94006a8 	ldr	x8, [x21, #8]
   1c358:	90000d70 	adrp	x16, 1c8000 <ALC+0x17e00>
   1c35c:	f83c7a88 	str	x8, [x20, x28, lsl #3]
   1c360:	f94086a8 	ldr	x8, [x21, #264]
   1c364:	f90006bc 	str	x28, [x21, #8]
   1c368:	91000908 	add	x8, x8, #0x2
   1c36c:	f90086a8 	str	x8, [x21, #264]
   1c370:	39540210 	ldrb	w16, [x16, #1280]
   1c374:	7100061f 	cmp	w16, #0x1
   1c378:	54001561 	b.ne	1c624 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x640>  // b.any
   1c37c:	f140211f 	cmp	x8, #0x8, lsl #12
   1c380:	54001522 	b.cs	1c624 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x640>  // b.hs, b.nlast
   1c384:	f85c03bc 	ldur	x28, [x29, #-64]
   1c388:	eb0d013f 	cmp	x9, x13
   1c38c:	540001a9 	b.ls	1c3c0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x3dc>  // b.plast
   1c390:	f94006a8 	ldr	x8, [x21, #8]
   1c394:	90000d6d 	adrp	x13, 1c8000 <ALC+0x17e00>
   1c398:	f8297a88 	str	x8, [x20, x9, lsl #3]
   1c39c:	f94086a8 	ldr	x8, [x21, #264]
   1c3a0:	f90006a9 	str	x9, [x21, #8]
   1c3a4:	91000908 	add	x8, x8, #0x2
   1c3a8:	f90086a8 	str	x8, [x21, #264]
   1c3ac:	395401ad 	ldrb	w13, [x13, #1280]
   1c3b0:	710005bf 	cmp	w13, #0x1
   1c3b4:	54000501 	b.ne	1c454 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x470>  // b.any
   1c3b8:	f140211f 	cmp	x8, #0x8, lsl #12
   1c3bc:	540004c2 	b.cs	1c454 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x470>  // b.hs, b.nlast
   1c3c0:	b859c3b7 	ldur	w23, [x29, #-100]
   1c3c4:	340007b7 	cbz	w23, 1c4b8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x4d4>
   1c3c8:	52800848 	mov	w8, #0x42                  	// #66
   1c3cc:	2a1803f0 	mov	w16, w24
   1c3d0:	2a1203ed 	mov	w13, w18
   1c3d4:	a88122c7 	stp	x7, x8, [x22], #16
   1c3d8:	a90497ac 	stp	x12, x5, [x29, #72]
   1c3dc:	aa0403e5 	mov	x5, x4
   1c3e0:	a97d13a8 	ldp	x8, x4, [x29, #-48]
   1c3e4:	a905afa8 	stp	x8, x11, [x29, #88]
   1c3e8:	f85e03a8 	ldur	x8, [x29, #-32]
   1c3ec:	2a0a03eb 	mov	w11, w10
   1c3f0:	2a1303ef 	mov	w15, w19
   1c3f4:	aa1e03ea 	mov	x10, x30
   1c3f8:	2a0803e8 	mov	w8, w8
   1c3fc:	f90037a8 	str	x8, [x29, #104]
   1c400:	a97a23ac 	ldp	x12, x8, [x29, #-96]
   1c404:	2a0803e8 	mov	w8, w8
   1c408:	f9001ba8 	str	x8, [x29, #48]
   1c40c:	2a1c03e8 	mov	w8, w28
   1c410:	2a1b03fc 	mov	w28, w27
   1c414:	f90017a8 	str	x8, [x29, #40]
   1c418:	a97b27a8 	ldp	x8, x9, [x29, #-80]
   1c41c:	2a0803e8 	mov	w8, w8
   1c420:	2a0903e7 	mov	w7, w9
   1c424:	2a0e03e9 	mov	w9, w14
   1c428:	f90013a8 	str	x8, [x29, #32]
   1c42c:	2a1103e8 	mov	w8, w17
   1c430:	f9000fa8 	str	x8, [x29, #24]
   1c434:	a97ebba6 	ldp	x6, x14, [x29, #-24]
   1c438:	2a1a03e8 	mov	w8, w26
   1c43c:	f94033fa 	ldr	x26, [sp, #96]
   1c440:	aa0803fb 	mov	x27, x8
   1c444:	f9000bb0 	str	x16, [x29, #16]
   1c448:	a94d7bfd 	ldp	x29, x30, [sp, #208]
   1c44c:	910383ff 	add	sp, sp, #0xe0
   1c450:	17fff47e 	b	19648 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0>
   1c454:	a90187e0 	stp	x0, x1, [sp, #24]
   1c458:	aa1403e0 	mov	x0, x20
   1c45c:	aa1503e1 	mov	x1, x21
   1c460:	aa0203fc 	mov	x28, x2
   1c464:	52800022 	mov	w2, #0x1                   	// #1
   1c468:	a900fbf8 	stp	x24, x30, [sp, #8]
   1c46c:	a9034be5 	stp	x5, x18, [sp, #48]
   1c470:	aa1303ef 	mov	x15, x19
   1c474:	aa0403f3 	mov	x19, x4
   1c478:	a90447ee 	stp	x14, x17, [sp, #64]
   1c47c:	aa0303f8 	mov	x24, x3
   1c480:	aa0703e9 	mov	x9, x7
   1c484:	97ffa06f 	bl	4640 <heap_hand>
   1c488:	aa1c03e2 	mov	x2, x28
   1c48c:	a94187e0 	ldp	x0, x1, [sp, #24]
   1c490:	a97c1bbc 	ldp	x28, x6, [x29, #-64]
   1c494:	aa1803e3 	mov	x3, x24
   1c498:	a94447ee 	ldp	x14, x17, [sp, #64]
   1c49c:	aa0903e7 	mov	x7, x9
   1c4a0:	a9434be5 	ldp	x5, x18, [sp, #48]
   1c4a4:	aa1303e4 	mov	x4, x19
   1c4a8:	a940fbf8 	ldp	x24, x30, [sp, #8]
   1c4ac:	aa0f03f3 	mov	x19, x15
   1c4b0:	b859c3b7 	ldur	w23, [x29, #-100]
   1c4b4:	35fff8b7 	cbnz	w23, 1c3c8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x3e4>
   1c4b8:	a97eb6c9 	ldp	x9, x13, [x22, #-24]
   1c4bc:	aa0003ef 	mov	x15, x0
   1c4c0:	f94016a0 	ldr	x0, [x21, #40]
   1c4c4:	aa1103f7 	mov	x23, x17
   1c4c8:	b4001240 	cbz	x0, 1c710 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x72c>
   1c4cc:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   1c4d0:	f94096b0 	ldr	x16, [x21, #296]
   1c4d4:	f90016a8 	str	x8, [x21, #40]
   1c4d8:	d1008208 	sub	x8, x16, #0x20
   1c4dc:	f90096a8 	str	x8, [x21, #296]
   1c4e0:	52800030 	mov	w16, #0x1                   	// #1
   1c4e4:	8b000e88 	add	x8, x20, x0, lsl #3
   1c4e8:	6f07e7e0 	movi	v0.2d, #0xffffffffffffffff
   1c4ec:	aa0d820d 	orr	x13, x16, x13, lsl #32
   1c4f0:	f9000107 	str	x7, [x8]
   1c4f4:	a90eb509 	stp	x9, x13, [x8, #232]
   1c4f8:	d2c84009 	mov	x9, #0x420000000000        	// #72567767433216
   1c4fc:	f2e0a009 	movk	x9, #0x500, lsl #48
   1c500:	3c8d8100 	stur	q0, [x8, #216]
   1c504:	aa090009 	orr	x9, x0, x9
   1c508:	3c8c8100 	stur	q0, [x8, #200]
   1c50c:	3c8b8100 	stur	q0, [x8, #184]
   1c510:	3c8a8100 	stur	q0, [x8, #168]
   1c514:	3c898100 	stur	q0, [x8, #152]
   1c518:	3c888100 	stur	q0, [x8, #136]
   1c51c:	3c878100 	stur	q0, [x8, #120]
   1c520:	3c868100 	stur	q0, [x8, #104]
   1c524:	3c858100 	stur	q0, [x8, #88]
   1c528:	3c848100 	stur	q0, [x8, #72]
   1c52c:	3c838100 	stur	q0, [x8, #56]
   1c530:	3c828100 	stur	q0, [x8, #40]
   1c534:	3c818100 	stur	q0, [x8, #24]
   1c538:	3c808100 	stur	q0, [x8, #8]
   1c53c:	a93ec2c9 	stp	x9, x16, [x22, #-24]
   1c540:	f94016a0 	ldr	x0, [x21, #40]
   1c544:	b40011a0 	cbz	x0, 1c778 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x794>
   1c548:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   1c54c:	f94096ad 	ldr	x13, [x21, #296]
   1c550:	f85a03b0 	ldur	x16, [x29, #-96]
   1c554:	f90016a8 	str	x8, [x21, #40]
   1c558:	d10081a8 	sub	x8, x13, #0x20
   1c55c:	f90096a8 	str	x8, [x21, #296]
   1c560:	8b000e88 	add	x8, x20, x0, lsl #3
   1c564:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
   1c568:	a90f3509 	stp	x9, x13, [x8, #240]
   1c56c:	f94033e9 	ldr	x9, [sp, #96]
   1c570:	2a1b03ed 	mov	w13, w27
   1c574:	a902050f 	stp	x15, x1, [x8, #32]
   1c578:	a9002519 	stp	x25, x9, [x8]
   1c57c:	2a1a03e9 	mov	w9, w26
   1c580:	a9013509 	stp	x9, x13, [x8, #16]
   1c584:	f85d83a9 	ldur	x9, [x29, #-40]
   1c588:	a9032503 	stp	x3, x9, [x8, #48]
   1c58c:	f85e83a9 	ldur	x9, [x29, #-24]
   1c590:	a9042504 	stp	x4, x9, [x8, #64]
   1c594:	f85b83a9 	ldur	x9, [x29, #-72]
   1c598:	2a0903e9 	mov	w9, w9
   1c59c:	a9057909 	stp	x9, x30, [x8, #80]
   1c5a0:	2a0a03e9 	mov	w9, w10
   1c5a4:	2a1303ea 	mov	w10, w19
   1c5a8:	a9064109 	stp	x9, x16, [x8, #96]
   1c5ac:	2a1203e9 	mov	w9, w18
   1c5b0:	f9003909 	str	x9, [x8, #112]
   1c5b4:	f85f03a9 	ldur	x9, [x29, #-16]
   1c5b8:	f9003d09 	str	x9, [x8, #120]
   1c5bc:	2a0e03e9 	mov	w9, w14
   1c5c0:	a9082909 	stp	x9, x10, [x8, #128]
   1c5c4:	2a1803e9 	mov	w9, w24
   1c5c8:	2a1703ea 	mov	w10, w23
   1c5cc:	a9092909 	stp	x9, x10, [x8, #144]
   1c5d0:	f85b03a9 	ldur	x9, [x29, #-80]
   1c5d4:	2a1c03ea 	mov	w10, w28
   1c5d8:	2a0903e9 	mov	w9, w9
   1c5dc:	a90a2909 	stp	x9, x10, [x8, #160]
   1c5e0:	f85a83a9 	ldur	x9, [x29, #-88]
   1c5e4:	2a0603ea 	mov	w10, w6
   1c5e8:	2a0903e9 	mov	w9, w9
   1c5ec:	a90b2909 	stp	x9, x10, [x8, #176]
   1c5f0:	2a0203e9 	mov	w9, w2
   1c5f4:	a90c3109 	stp	x9, x12, [x8, #192]
   1c5f8:	f85d03a9 	ldur	x9, [x29, #-48]
   1c5fc:	a90d2505 	stp	x5, x9, [x8, #208]
   1c600:	d2c70009 	mov	x9, #0x380000000000        	// #61572651155456
   1c604:	f2e0a009 	movk	x9, #0x500, lsl #48
   1c608:	aa090000 	orr	x0, x0, x9
   1c60c:	f85e03a9 	ldur	x9, [x29, #-32]
   1c610:	2a0903e9 	mov	w9, w9
   1c614:	a90e250b 	stp	x11, x9, [x8, #224]
   1c618:	a94d7bfd 	ldp	x29, x30, [sp, #208]
   1c61c:	910383ff 	add	sp, sp, #0xe0
   1c620:	d65f03c0 	ret
   1c624:	a90187e0 	stp	x0, x1, [sp, #24]
   1c628:	aa1403e0 	mov	x0, x20
   1c62c:	aa1503e1 	mov	x1, x21
   1c630:	a90063fa 	stp	x26, x24, [sp]
   1c634:	aa0203fa 	mov	x26, x2
   1c638:	52800022 	mov	w2, #0x1                   	// #1
   1c63c:	f9000bfe 	str	x30, [sp, #16]
   1c640:	aa1303ef 	mov	x15, x19
   1c644:	aa0403f3 	mov	x19, x4
   1c648:	a903bbf2 	stp	x18, x14, [sp, #56]
   1c64c:	aa0303f8 	mov	x24, x3
   1c650:	a9052bec 	stp	x12, x10, [sp, #80]
   1c654:	aa0503ec 	mov	x12, x5
   1c658:	aa0703ea 	mov	x10, x7
   1c65c:	f90027f1 	str	x17, [sp, #72]
   1c660:	97ff9ff8 	bl	4640 <heap_hand>
   1c664:	aa1a03e2 	mov	x2, x26
   1c668:	a94187e0 	ldp	x0, x1, [sp, #24]
   1c66c:	aa0c03e5 	mov	x5, x12
   1c670:	aa1803e3 	mov	x3, x24
   1c674:	aa0a03e7 	mov	x7, x10
   1c678:	a944b3f1 	ldp	x17, x12, [sp, #72]
   1c67c:	f85c83a6 	ldur	x6, [x29, #-56]
   1c680:	a943bbf2 	ldp	x18, x14, [sp, #56]
   1c684:	f9402fea 	ldr	x10, [sp, #88]
   1c688:	a94063fa 	ldp	x26, x24, [sp]
   1c68c:	aa1303e4 	mov	x4, x19
   1c690:	f9400bfe 	ldr	x30, [sp, #16]
   1c694:	aa0f03f3 	mov	x19, x15
   1c698:	17ffff3b 	b	1c384 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x3a0>
   1c69c:	aa118248 	orr	x8, x18, x17, lsl #32
   1c6a0:	a90187e0 	stp	x0, x1, [sp, #24]
   1c6a4:	aa1403e0 	mov	x0, x20
   1c6a8:	aa1503e1 	mov	x1, x21
   1c6ac:	f90003fa 	str	x26, [sp]
   1c6b0:	aa0203fa 	mov	x26, x2
   1c6b4:	d358fd03 	lsr	x3, x8, #24
   1c6b8:	aa1c03e2 	mov	x2, x28
   1c6bc:	52800044 	mov	w4, #0x2                   	// #2
   1c6c0:	aa0703ec 	mov	x12, x7
   1c6c4:	8b030e88 	add	x8, x20, x3, lsl #3
   1c6c8:	b9400119 	ldr	w25, [x8]
   1c6cc:	b9400908 	ldr	w8, [x8, #8]
   1c6d0:	f90033e8 	str	x8, [sp, #96]
   1c6d4:	97ffa00e 	bl	470c <span_fade>
   1c6d8:	aa0c03e7 	mov	x7, x12
   1c6dc:	a94187e0 	ldp	x0, x1, [sp, #24]
   1c6e0:	aa1803fe 	mov	x30, x24
   1c6e4:	aa0a03f8 	mov	x24, x10
   1c6e8:	aa1303e4 	mov	x4, x19
   1c6ec:	a94297f3 	ldp	x19, x5, [sp, #40]
   1c6f0:	aa1a03e2 	mov	x2, x26
   1c6f4:	a943bbf2 	ldp	x18, x14, [sp, #56]
   1c6f8:	f94003fa 	ldr	x26, [sp]
   1c6fc:	a9452bec 	ldp	x12, x10, [sp, #80]
   1c700:	f94027f1 	ldr	x17, [sp, #72]
   1c704:	f85c83a6 	ldur	x6, [x29, #-56]
   1c708:	aa0f03e3 	mov	x3, x15
   1c70c:	17ffff1e 	b	1c384 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x3a0>
   1c710:	aa1403e0 	mov	x0, x20
   1c714:	a9024fe1 	stp	x1, x19, [sp, #32]
   1c718:	aa1503e1 	mov	x1, x21
   1c71c:	a90063fa 	stp	x26, x24, [sp]
   1c720:	aa0203fa 	mov	x26, x2
   1c724:	528000a2 	mov	w2, #0x5                   	// #5
   1c728:	f9000bfe 	str	x30, [sp, #16]
   1c72c:	aa0403f3 	mov	x19, x4
   1c730:	a903bbf2 	stp	x18, x14, [sp, #56]
   1c734:	a9052bec 	stp	x12, x10, [sp, #80]
   1c738:	aa0303ec 	mov	x12, x3
   1c73c:	aa0703ea 	mov	x10, x7
   1c740:	f9001be5 	str	x5, [sp, #48]
   1c744:	97ffa1d3 	bl	4e90 <heap_alloc_miss>
   1c748:	aa0a03e7 	mov	x7, x10
   1c74c:	aa1a03e2 	mov	x2, x26
   1c750:	aa0c03e3 	mov	x3, x12
   1c754:	a94063fa 	ldp	x26, x24, [sp]
   1c758:	aa1303e4 	mov	x4, x19
   1c75c:	a9452bec 	ldp	x12, x10, [sp, #80]
   1c760:	f85c83a6 	ldur	x6, [x29, #-56]
   1c764:	a94297f3 	ldp	x19, x5, [sp, #40]
   1c768:	f94013e1 	ldr	x1, [sp, #32]
   1c76c:	a943bbf2 	ldp	x18, x14, [sp, #56]
   1c770:	f9400bfe 	ldr	x30, [sp, #16]
   1c774:	17ffff5b 	b	1c4e0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x4fc>
   1c778:	aa1403e0 	mov	x0, x20
   1c77c:	f90013e1 	str	x1, [sp, #32]
   1c780:	aa1503e1 	mov	x1, x21
   1c784:	aa0203f5 	mov	x21, x2
   1c788:	528000a2 	mov	w2, #0x5                   	// #5
   1c78c:	f9000bfe 	str	x30, [sp, #16]
   1c790:	aa0403fc 	mov	x28, x4
   1c794:	a903bbf2 	stp	x18, x14, [sp, #56]
   1c798:	aa0503f6 	mov	x22, x5
   1c79c:	a9052bec 	stp	x12, x10, [sp, #80]
   1c7a0:	aa0303ea 	mov	x10, x3
   1c7a4:	97ffa1bb 	bl	4e90 <heap_alloc_miss>
   1c7a8:	aa0a03e3 	mov	x3, x10
   1c7ac:	a9452bec 	ldp	x12, x10, [sp, #80]
   1c7b0:	a943bbf2 	ldp	x18, x14, [sp, #56]
   1c7b4:	aa1c03e4 	mov	x4, x28
   1c7b8:	a97c1bbc 	ldp	x28, x6, [x29, #-64]
   1c7bc:	aa1503e2 	mov	x2, x21
   1c7c0:	f94013e1 	ldr	x1, [sp, #32]
   1c7c4:	f85a03b0 	ldur	x16, [x29, #-96]
   1c7c8:	aa1603e5 	mov	x5, x22
   1c7cc:	f9400bfe 	ldr	x30, [sp, #16]
   1c7d0:	17ffff64 	b	1c560 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x57c>
   1c7d4:	a90187e0 	stp	x0, x1, [sp, #24]
   1c7d8:	aa1403e0 	mov	x0, x20
   1c7dc:	aa1503e1 	mov	x1, x21
   1c7e0:	f90003fa 	str	x26, [sp]
   1c7e4:	aa0203fa 	mov	x26, x2
   1c7e8:	2a1f03e2 	mov	w2, wzr
   1c7ec:	aa0703ec 	mov	x12, x7
   1c7f0:	97ff9f94 	bl	4640 <heap_hand>
   1c7f4:	a94187e0 	ldp	x0, x1, [sp, #24]
   1c7f8:	aa1a03e2 	mov	x2, x26
   1c7fc:	f94003fa 	ldr	x26, [sp]
   1c800:	aa0c03e7 	mov	x7, x12
   1c804:	17fffec9 	b	1c328 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0+0x344>

