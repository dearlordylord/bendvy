   17894:	d10283ff 	sub	sp, sp, #0xa0
   17898:	a9097bfd 	stp	x29, x30, [sp, #144]
   1789c:	910243fd 	add	x29, sp, #0x90
   178a0:	a93e3fa9 	stp	x9, x15, [x29, #-32]
   178a4:	a944bfb2 	ldp	x18, x15, [x29, #72]
   178a8:	f81f03ac 	stur	x12, [x29, #-16]
   178ac:	f9400bb8 	ldr	x24, [x29, #16]
   178b0:	a943c7b0 	ldp	x16, x17, [x29, #56]
   178b4:	a942cfbe 	ldp	x30, x19, [x29, #40]
   178b8:	a941b3a2 	ldp	x2, x12, [x29, #24]
   178bc:	34000397 	cbz	w23, 1792c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0+0x98>
   178c0:	52800568 	mov	w8, #0x2b                  	// #43
   178c4:	2a1903f9 	mov	w25, w25
   178c8:	2a1a03fa 	mov	w26, w26
   178cc:	f80086c8 	str	x8, [x22], #8
   178d0:	2a1303e8 	mov	w8, w19
   178d4:	a903c7b0 	stp	x16, x17, [x29, #56]
   178d8:	2a1e03f0 	mov	w16, w30
   178dc:	2a0503e5 	mov	w5, w5
   178e0:	a902a3b0 	stp	x16, x8, [x29, #40]
   178e4:	f85e03a8 	ldur	x8, [x29, #-32]
   178e8:	2a0203f0 	mov	w16, w2
   178ec:	a904bfb2 	stp	x18, x15, [x29, #72]
   178f0:	2a0703e7 	mov	w7, w7
   178f4:	2a0b03eb 	mov	w11, w11
   178f8:	2a0803e9 	mov	w9, w8
   178fc:	2a0c03e8 	mov	w8, w12
   17900:	f85e83ac 	ldur	x12, [x29, #-24]
   17904:	a901a3b0 	stp	x16, x8, [x29, #24]
   17908:	2a1803e8 	mov	w8, w24
   1790c:	2a0d03ed 	mov	w13, w13
   17910:	2a0c03ef 	mov	w15, w12
   17914:	f85f03ac 	ldur	x12, [x29, #-16]
   17918:	2a0e03ee 	mov	w14, w14
   1791c:	f9000ba8 	str	x8, [x29, #16]
   17920:	a9497bfd 	ldp	x29, x30, [sp, #144]
   17924:	910283ff 	add	sp, sp, #0xa0
   17928:	17ffefa7 	b	137c4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_TRANSACTION_DISPATCH_ADAPTERS_MOTION_READ_MAIN>
   1792c:	f81d83ac 	stur	x12, [x29, #-40]
   17930:	f9401aa8 	ldr	x8, [x21, #48]
   17934:	aa0e03e9 	mov	x9, x14
   17938:	a9044ffe 	stp	x30, x19, [sp, #64]
   1793c:	a97eced7 	ldp	x23, x19, [x22, #-24]
   17940:	aa0203ee 	mov	x14, x2
   17944:	a93c47b2 	stp	x18, x17, [x29, #-64]
   17948:	f81d03b0 	stur	x16, [x29, #-48]
   1794c:	b4000988 	cbz	x8, 17a7c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0+0x1e8>
   17950:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   17954:	f9409ab1 	ldr	x17, [x21, #304]
   17958:	f9001ab0 	str	x16, [x21, #48]
   1795c:	d1010230 	sub	x16, x17, #0x40
   17960:	f9009ab0 	str	x16, [x21, #304]
   17964:	8b080e90 	add	x16, x20, x8, lsl #3
   17968:	6f07e7e0 	movi	v0.2d, #0xffffffffffffffff
   1796c:	92800011 	mov	x17, #0xffffffffffffffff    	// #-1
   17970:	52800032 	mov	w18, #0x1                   	// #1
   17974:	a9105e11 	stp	x17, x23, [x16, #256]
   17978:	d2c56011 	mov	x17, #0x2b0000000000        	// #47278999994368
   1797c:	aa138252 	orr	x18, x18, x19, lsl #32
   17980:	f2e0a011 	movk	x17, #0x500, lsl #48
   17984:	aa110117 	orr	x23, x8, x17
   17988:	ad000200 	stp	q0, q0, [x16]
   1798c:	ad010200 	stp	q0, q0, [x16, #32]
   17990:	ad020200 	stp	q0, q0, [x16, #64]
   17994:	ad030200 	stp	q0, q0, [x16, #96]
   17998:	ad040200 	stp	q0, q0, [x16, #128]
   1799c:	ad050200 	stp	q0, q0, [x16, #160]
   179a0:	ad060200 	stp	q0, q0, [x16, #192]
   179a4:	ad070200 	stp	q0, q0, [x16, #224]
   179a8:	f9008a12 	str	x18, [x16, #272]
   179ac:	a93efed7 	stp	x23, xzr, [x22, #-24]
   179b0:	f94016a8 	ldr	x8, [x21, #40]
   179b4:	b4000848 	cbz	x8, 17abc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0+0x228>
   179b8:	f94096b0 	ldr	x16, [x21, #296]
   179bc:	f8687a91 	ldr	x17, [x20, x8, lsl #3]
   179c0:	d1008210 	sub	x16, x16, #0x20
   179c4:	f90016b1 	str	x17, [x21, #40]
   179c8:	f90096b0 	str	x16, [x21, #296]
   179cc:	8b080e90 	add	x16, x20, x8, lsl #3
   179d0:	2a1903f2 	mov	w18, w25
   179d4:	2a1a03f1 	mov	w17, w26
   179d8:	2a0b03eb 	mov	w11, w11
   179dc:	2a0e03ec 	mov	w12, w14
   179e0:	f85d83b3 	ldur	x19, [x29, #-40]
   179e4:	a9004612 	stp	x18, x17, [x16]
   179e8:	2a0503f1 	mov	w17, w5
   179ec:	a9041a11 	stp	x17, x6, [x16, #64]
   179f0:	2a0703f1 	mov	w17, w7
   179f4:	a9052a11 	stp	x17, x10, [x16, #80]
   179f8:	f85f03aa 	ldur	x10, [x29, #-16]
   179fc:	f900721f 	str	xzr, [x16, #224]
   17a00:	a9062a0b 	stp	x11, x10, [x16, #96]
   17a04:	2a0d03eb 	mov	w11, w13
   17a08:	2a0903ed 	mov	w13, w9
   17a0c:	a97e27aa 	ldp	x10, x9, [x29, #-32]
   17a10:	a907360b 	stp	x11, x13, [x16, #112]
   17a14:	a901721b 	stp	x27, x28, [x16, #16]
   17a18:	a9020600 	stp	x0, x1, [x16, #32]
   17a1c:	2a0a03eb 	mov	w11, w10
   17a20:	2a0903ed 	mov	w13, w9
   17a24:	f94023e9 	ldr	x9, [sp, #64]
   17a28:	a908360b 	stp	x11, x13, [x16, #128]
   17a2c:	2a1803eb 	mov	w11, w24
   17a30:	2a1303ea 	mov	w10, w19
   17a34:	a909320b 	stp	x11, x12, [x16, #144]
   17a38:	2a0903eb 	mov	w11, w9
   17a3c:	f94027e9 	ldr	x9, [sp, #72]
   17a40:	a90a2e0a 	stp	x10, x11, [x16, #160]
   17a44:	2a0903e9 	mov	w9, w9
   17a48:	a9031203 	stp	x3, x4, [x16, #48]
   17a4c:	f9005a09 	str	x9, [x16, #176]
   17a50:	a97caba9 	ldp	x9, x10, [x29, #-56]
   17a54:	a90ba60a 	stp	x10, x9, [x16, #184]
   17a58:	f85c03a9 	ldur	x9, [x29, #-64]
   17a5c:	a90cbe09 	stp	x9, x15, [x16, #200]
   17a60:	d2c3c009 	mov	x9, #0x1e0000000000        	// #32985348833280
   17a64:	f2e0a009 	movk	x9, #0x500, lsl #48
   17a68:	aa090100 	orr	x0, x8, x9
   17a6c:	f9006e17 	str	x23, [x16, #216]
   17a70:	a9497bfd 	ldp	x29, x30, [sp, #144]
   17a74:	910283ff 	add	sp, sp, #0xa0
   17a78:	d65f03c0 	ret
   17a7c:	a90303e1 	stp	x1, x0, [sp, #48]
   17a80:	aa1403e0 	mov	x0, x20
   17a84:	aa1503e1 	mov	x1, x21
   17a88:	528000c2 	mov	w2, #0x6                   	// #6
   17a8c:	a900abe7 	stp	x7, x10, [sp, #8]
   17a90:	a9021be3 	stp	x3, x6, [sp, #32]
   17a94:	f90003e4 	str	x4, [sp]
   17a98:	f9000fe5 	str	x5, [sp, #24]
   17a9c:	97ffb4fd 	bl	4e90 <heap_alloc_miss>
   17aa0:	a94117ea 	ldp	x10, x5, [sp, #16]
   17aa4:	aa0003e8 	mov	x8, x0
   17aa8:	a9401fe4 	ldp	x4, x7, [sp]
   17aac:	f94013e3 	ldr	x3, [sp, #32]
   17ab0:	a94287e6 	ldp	x6, x1, [sp, #40]
   17ab4:	f9401fe0 	ldr	x0, [sp, #56]
   17ab8:	17ffffab 	b	17964 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0+0xd0>
   17abc:	a90303e1 	stp	x1, x0, [sp, #48]
   17ac0:	aa1403e0 	mov	x0, x20
   17ac4:	aa1503e1 	mov	x1, x21
   17ac8:	528000a2 	mov	w2, #0x5                   	// #5
   17acc:	a90117ea 	stp	x10, x5, [sp, #16]
   17ad0:	aa0403f5 	mov	x21, x4
   17ad4:	a9021be3 	stp	x3, x6, [sp, #32]
   17ad8:	aa0703f6 	mov	x22, x7
   17adc:	97ffb4ed 	bl	4e90 <heap_alloc_miss>
   17ae0:	a94117ea 	ldp	x10, x5, [sp, #16]
   17ae4:	aa0003e8 	mov	x8, x0
   17ae8:	a94287e6 	ldp	x6, x1, [sp, #40]
   17aec:	aa1603e7 	mov	x7, x22
   17af0:	f94013e3 	ldr	x3, [sp, #32]
   17af4:	f9401fe0 	ldr	x0, [sp, #56]
   17af8:	aa1503e4 	mov	x4, x21
   17afc:	17ffffb4 	b	179cc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0+0x138>

