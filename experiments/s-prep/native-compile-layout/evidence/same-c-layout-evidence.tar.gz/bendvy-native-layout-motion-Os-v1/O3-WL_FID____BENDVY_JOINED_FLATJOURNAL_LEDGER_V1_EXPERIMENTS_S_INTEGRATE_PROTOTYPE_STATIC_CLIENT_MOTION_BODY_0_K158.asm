   17b00:	d102c3ff 	sub	sp, sp, #0xb0
   17b04:	a90a7bfd 	stp	x29, x30, [sp, #160]
   17b08:	910283fd 	add	x29, sp, #0xa0
   17b0c:	a93db3aa 	stp	x10, x12, [x29, #-40]
   17b10:	a943cfb8 	ldp	x24, x19, [x29, #56]
   17b14:	a93e9ba4 	stp	x4, x6, [x29, #-24]
   17b18:	b9405ba8 	ldr	w8, [x29, #88]
   17b1c:	f9400ba2 	ldr	x2, [x29, #16]
   17b20:	a944b3a4 	ldp	x4, x12, [x29, #72]
   17b24:	a942cbbe 	ldp	x30, x18, [x29, #40]
   17b28:	a941c3b1 	ldp	x17, x16, [x29, #24]
   17b2c:	34000448 	cbz	w8, 17bb4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K158+0xb4>
   17b30:	b85f8ec8 	ldr	w8, [x22, #-8]!
   17b34:	f0000caa 	adrp	x10, 1ae000 <io_eff_rows+0xff118>
   17b38:	913f214a 	add	x10, x10, #0xfc8
   17b3c:	12800006 	mov	w6, #0xffffffff            	// #-1
   17b40:	2a1903f9 	mov	w25, w25
   17b44:	f8687948 	ldr	x8, [x10, x8, lsl #3]
   17b48:	a9051bac 	stp	x12, x6, [x29, #80]
   17b4c:	2a1103ec 	mov	w12, w17
   17b50:	a90413b3 	stp	x19, x4, [x29, #64]
   17b54:	a97e9ba4 	ldp	x4, x6, [x29, #-24]
   17b58:	f81d03a8 	stur	x8, [x29, #-48]
   17b5c:	2a1203e8 	mov	w8, w18
   17b60:	2a1a03fa 	mov	w26, w26
   17b64:	a90363a8 	stp	x8, x24, [x29, #48]
   17b68:	2a1e03e8 	mov	w8, w30
   17b6c:	2a0503e5 	mov	w5, w5
   17b70:	f90017a8 	str	x8, [x29, #40]
   17b74:	2a1003e8 	mov	w8, w16
   17b78:	2a0703e7 	mov	w7, w7
   17b7c:	f90013a8 	str	x8, [x29, #32]
   17b80:	2a0203e8 	mov	w8, w2
   17b84:	2a0b03eb 	mov	w11, w11
   17b88:	a90133a8 	stp	x8, x12, [x29, #16]
   17b8c:	a97db3aa 	ldp	x10, x12, [x29, #-40]
   17b90:	2a0d03ed 	mov	w13, w13
   17b94:	2a0e03ee 	mov	w14, w14
   17b98:	2a0903e9 	mov	w9, w9
   17b9c:	2a0f03ef 	mov	w15, w15
   17ba0:	52800398 	mov	w24, #0x1c                  	// #28
   17ba4:	f85d03a2 	ldur	x2, [x29, #-48]
   17ba8:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   17bac:	9102c3ff 	add	sp, sp, #0xb0
   17bb0:	d61f0040 	br	x2
   17bb4:	a93c63be 	stp	x30, x24, [x29, #-64]
   17bb8:	a94663a6 	ldp	x6, x24, [x29, #96]
   17bbc:	f81d03b3 	stur	x19, [x29, #-48]
   17bc0:	a9472bb3 	ldp	x19, x10, [x29, #112]
   17bc4:	34000537 	cbz	w23, 17c68 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K158+0x168>
   17bc8:	2a0603e8 	mov	w8, w6
   17bcc:	aa1003fe 	mov	x30, x16
   17bd0:	2a1803f0 	mov	w16, w24
   17bd4:	a90042c8 	stp	x8, x16, [x22]
   17bd8:	2a1303e8 	mov	w8, w19
   17bdc:	2a0a03ea 	mov	w10, w10
   17be0:	a9012ac8 	stp	x8, x10, [x22, #16]
   17be4:	52800588 	mov	w8, #0x2c                  	// #44
   17be8:	2a1903f9 	mov	w25, w25
   17bec:	f90012c8 	str	x8, [x22, #32]
   17bf0:	110004c8 	add	w8, w6, #0x1
   17bf4:	2a1a03fa 	mov	w26, w26
   17bf8:	a90523ac 	stp	x12, x8, [x29, #80]
   17bfc:	a97caba8 	ldp	x8, x10, [x29, #-56]
   17c00:	2a0503e5 	mov	w5, w5
   17c04:	2a0703e7 	mov	w7, w7
   17c08:	2a0b03eb 	mov	w11, w11
   17c0c:	2a0d03ed 	mov	w13, w13
   17c10:	2a0e03ee 	mov	w14, w14
   17c14:	2a0903e9 	mov	w9, w9
   17c18:	f9001fa8 	str	x8, [x29, #56]
   17c1c:	2a1203e8 	mov	w8, w18
   17c20:	2a0f03ef 	mov	w15, w15
   17c24:	f9001ba8 	str	x8, [x29, #48]
   17c28:	f85c03a8 	ldur	x8, [x29, #-64]
   17c2c:	9100a2d6 	add	x22, x22, #0x28
   17c30:	a90413aa 	stp	x10, x4, [x29, #64]
   17c34:	a97e9ba4 	ldp	x4, x6, [x29, #-24]
   17c38:	2a0803e8 	mov	w8, w8
   17c3c:	a97db3aa 	ldp	x10, x12, [x29, #-40]
   17c40:	f90017a8 	str	x8, [x29, #40]
   17c44:	2a1e03e8 	mov	w8, w30
   17c48:	f90013a8 	str	x8, [x29, #32]
   17c4c:	2a1103e8 	mov	w8, w17
   17c50:	f9000fa8 	str	x8, [x29, #24]
   17c54:	2a0203e8 	mov	w8, w2
   17c58:	f9000ba8 	str	x8, [x29, #16]
   17c5c:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   17c60:	9102c3ff 	add	sp, sp, #0xb0
   17c64:	17ffd0b5 	b	bf38 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_TRANSACTION_DISPATCH_ADAPTERS_MOTION_SET_MAIN0>
   17c68:	a90347f0 	stp	x16, x17, [sp, #48]
   17c6c:	f9401aa8 	ldr	x8, [x21, #48]
   17c70:	a90413f2 	stp	x18, x4, [sp, #64]
   17c74:	f9002bec 	str	x12, [sp, #80]
   17c78:	f81b83ad 	stur	x13, [x29, #-72]
   17c7c:	a97edecd 	ldp	x13, x23, [x22, #-24]
   17c80:	b4000b08 	cbz	x8, 17de0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K158+0x2e0>
   17c84:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   17c88:	f9409ab1 	ldr	x17, [x21, #304]
   17c8c:	f9001ab0 	str	x16, [x21, #48]
   17c90:	d1010230 	sub	x16, x17, #0x40
   17c94:	f9009ab0 	str	x16, [x21, #304]
   17c98:	52800032 	mov	w18, #0x1                   	// #1
   17c9c:	8b080e90 	add	x16, x20, x8, lsl #3
   17ca0:	92800011 	mov	x17, #0xffffffffffffffff    	// #-1
   17ca4:	aa178252 	orr	x18, x18, x23, lsl #32
   17ca8:	6f07e7e0 	movi	v0.2d, #0xffffffffffffffff
   17cac:	f85c03ac 	ldur	x12, [x29, #-64]
   17cb0:	a90f3611 	stp	x17, x13, [x16, #240]
   17cb4:	2a0603f1 	mov	w17, w6
   17cb8:	2a0a03ed 	mov	w13, w10
   17cbc:	f9008212 	str	x18, [x16, #256]
   17cc0:	2a1803f2 	mov	w18, w24
   17cc4:	a9004a11 	stp	x17, x18, [x16]
   17cc8:	d2c58012 	mov	x18, #0x2c0000000000        	// #48378511622144
   17ccc:	2a1303f1 	mov	w17, w19
   17cd0:	f2e0a012 	movk	x18, #0x500, lsl #48
   17cd4:	ad018200 	stp	q0, q0, [x16, #48]
   17cd8:	aa120113 	orr	x19, x8, x18
   17cdc:	52800088 	mov	w8, #0x4                   	// #4
   17ce0:	ad028200 	stp	q0, q0, [x16, #80]
   17ce4:	ad038200 	stp	q0, q0, [x16, #112]
   17ce8:	ad048200 	stp	q0, q0, [x16, #144]
   17cec:	ad058200 	stp	q0, q0, [x16, #176]
   17cf0:	ad068200 	stp	q0, q0, [x16, #208]
   17cf4:	3d800a00 	str	q0, [x16, #32]
   17cf8:	a9013611 	stp	x17, x13, [x16, #16]
   17cfc:	a93ea2d3 	stp	x19, x8, [x22, #-24]
   17d00:	f94016a8 	ldr	x8, [x21, #40]
   17d04:	b40008e8 	cbz	x8, 17e20 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K158+0x320>
   17d08:	f8687a8d 	ldr	x13, [x20, x8, lsl #3]
   17d0c:	f94096b0 	ldr	x16, [x21, #296]
   17d10:	f90016ad 	str	x13, [x21, #40]
   17d14:	d100820d 	sub	x13, x16, #0x20
   17d18:	f90096ad 	str	x13, [x21, #296]
   17d1c:	8b080e8d 	add	x13, x20, x8, lsl #3
   17d20:	f85e83aa 	ldur	x10, [x29, #-24]
   17d24:	d2c00090 	mov	x16, #0x400000000           	// #17179869184
   17d28:	2a1903f1 	mov	w17, w25
   17d2c:	2a0b03eb 	mov	w11, w11
   17d30:	a90e41b3 	stp	x19, x16, [x13, #224]
   17d34:	2a1a03f0 	mov	w16, w26
   17d38:	a90329a3 	stp	x3, x10, [x13, #48]
   17d3c:	f85f03aa 	ldur	x10, [x29, #-16]
   17d40:	a90041b1 	stp	x17, x16, [x13]
   17d44:	2a0503f0 	mov	w16, w5
   17d48:	a90429b0 	stp	x16, x10, [x13, #64]
   17d4c:	2a0703f0 	mov	w16, w7
   17d50:	f90031ab 	str	x11, [x13, #96]
   17d54:	a97dafaa 	ldp	x10, x11, [x29, #-40]
   17d58:	a90529b0 	stp	x16, x10, [x13, #80]
   17d5c:	f85b83aa 	ldur	x10, [x29, #-72]
   17d60:	2a0e03f0 	mov	w16, w14
   17d64:	f90035ab 	str	x11, [x13, #104]
   17d68:	2a0a03eb 	mov	w11, w10
   17d6c:	2a0203ea 	mov	w10, w2
   17d70:	a90205a0 	stp	x0, x1, [x13, #32]
   17d74:	a90741ab 	stp	x11, x16, [x13, #112]
   17d78:	2a0903eb 	mov	w11, w9
   17d7c:	f9401fe9 	ldr	x9, [sp, #56]
   17d80:	2a0f03f0 	mov	w16, w15
   17d84:	a90171bb 	stp	x27, x28, [x13, #16]
   17d88:	a90841ab 	stp	x11, x16, [x13, #128]
   17d8c:	2a0903eb 	mov	w11, w9
   17d90:	f9401be9 	ldr	x9, [sp, #48]
   17d94:	a9092daa 	stp	x10, x11, [x13, #144]
   17d98:	2a0c03ea 	mov	w10, w12
   17d9c:	2a0903e9 	mov	w9, w9
   17da0:	a90a29a9 	stp	x9, x10, [x13, #160]
   17da4:	a9442fe9 	ldp	x9, x11, [sp, #64]
   17da8:	2a0903e9 	mov	w9, w9
   17dac:	f90059a9 	str	x9, [x13, #176]
   17db0:	a97ca7aa 	ldp	x10, x9, [x29, #-56]
   17db4:	a90ba5aa 	stp	x10, x9, [x13, #184]
   17db8:	d2c16009 	mov	x9, #0xb0000000000         	// #12094627905536
   17dbc:	110004ca 	add	w10, w6, #0x1
   17dc0:	f2e0a009 	movk	x9, #0x500, lsl #48
   17dc4:	aa090100 	orr	x0, x8, x9
   17dc8:	f9402be8 	ldr	x8, [sp, #80]
   17dcc:	a90ca1ab 	stp	x11, x8, [x13, #200]
   17dd0:	f9006daa 	str	x10, [x13, #216]
   17dd4:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   17dd8:	9102c3ff 	add	sp, sp, #0xb0
   17ddc:	d65f03c0 	ret
   17de0:	a90203e1 	stp	x1, x0, [sp, #32]
   17de4:	aa1403e0 	mov	x0, x20
   17de8:	aa1503e1 	mov	x1, x21
   17dec:	a9001fed 	stp	x13, x7, [sp]
   17df0:	aa0203ed 	mov	x13, x2
   17df4:	528000c2 	mov	w2, #0x6                   	// #6
   17df8:	a9010fe5 	stp	x5, x3, [sp, #16]
   17dfc:	aa0603ec 	mov	x12, x6
   17e00:	97ffb424 	bl	4e90 <heap_alloc_miss>
   17e04:	aa0d03e2 	mov	x2, x13
   17e08:	a9401fed 	ldp	x13, x7, [sp]
   17e0c:	a9410fe5 	ldp	x5, x3, [sp, #16]
   17e10:	aa0003e8 	mov	x8, x0
   17e14:	a94203e1 	ldp	x1, x0, [sp, #32]
   17e18:	aa0c03e6 	mov	x6, x12
   17e1c:	17ffff9f 	b	17c98 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K158+0x198>
   17e20:	a90203e1 	stp	x1, x0, [sp, #32]
   17e24:	aa1403e0 	mov	x0, x20
   17e28:	aa1503e1 	mov	x1, x21
   17e2c:	aa0203ea 	mov	x10, x2
   17e30:	528000a2 	mov	w2, #0x5                   	// #5
   17e34:	aa0303f7 	mov	x23, x3
   17e38:	aa0703ed 	mov	x13, x7
   17e3c:	aa0503f8 	mov	x24, x5
   17e40:	aa0603f5 	mov	x21, x6
   17e44:	97ffb413 	bl	4e90 <heap_alloc_miss>
   17e48:	aa0003e8 	mov	x8, x0
   17e4c:	a94203e1 	ldp	x1, x0, [sp, #32]
   17e50:	aa1503e6 	mov	x6, x21
   17e54:	aa0a03e2 	mov	x2, x10
   17e58:	aa1803e5 	mov	x5, x24
   17e5c:	aa0d03e7 	mov	x7, x13
   17e60:	aa1703e3 	mov	x3, x23
   17e64:	17ffffae 	b	17d1c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K158+0x21c>

