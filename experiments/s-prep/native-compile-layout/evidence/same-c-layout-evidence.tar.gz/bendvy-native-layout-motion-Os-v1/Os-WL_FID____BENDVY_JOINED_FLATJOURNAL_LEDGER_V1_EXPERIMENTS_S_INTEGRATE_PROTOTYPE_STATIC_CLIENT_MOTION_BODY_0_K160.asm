   16f88:	d103c3ff 	sub	sp, sp, #0xf0
   16f8c:	a90e7bfd 	stp	x29, x30, [sp, #224]
   16f90:	910383fd 	add	x29, sp, #0xe0
   16f94:	aa0c03f0 	mov	x16, x12
   16f98:	aa0603f1 	mov	x17, x6
   16f9c:	a93daba4 	stp	x4, x10, [x29, #-40]
   16fa0:	a93e8fb0 	stp	x16, x3, [x29, #-24]
   16fa4:	aa1c03e3 	mov	x3, x28
   16fa8:	aa1a03fc 	mov	x28, x26
   16fac:	a944fba6 	ldp	x6, x30, [x29, #72]
   16fb0:	b9405ba8 	ldr	w8, [x29, #88]
   16fb4:	a943cfb8 	ldp	x24, x19, [x29, #56]
   16fb8:	f9400ba2 	ldr	x2, [x29, #16]
   16fbc:	a942ebac 	ldp	x12, x26, [x29, #40]
   16fc0:	7100051f 	cmp	w8, #0x1
   16fc4:	a94193b2 	ldp	x18, x4, [x29, #24]
   16fc8:	54000681 	b.ne	17098 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K160+0x110>  // b.any
   16fcc:	aa1603e8 	mov	x8, x22
   16fd0:	a93cc7a3 	stp	x3, x17, [x29, #-56]
   16fd4:	f85f03a3 	ldur	x3, [x29, #-16]
   16fd8:	a93ae3a5 	stp	x5, x24, [x29, #-88]
   16fdc:	b85f0d10 	ldr	w16, [x8, #-16]!
   16fe0:	a93b9fb2 	stp	x18, x7, [x29, #-72]
   16fe4:	b85f0111 	ldur	w17, [x8, #-16]
   16fe8:	b85f8118 	ldur	w24, [x8, #-8]
   16fec:	b9400912 	ldr	w18, [x8, #8]
   16ff0:	a939eba4 	stp	x4, x26, [x29, #-104]
   16ff4:	f94033a4 	ldr	x4, [x29, #96]
   16ff8:	0b110311 	add	w17, w24, w17
   16ffc:	0b120210 	add	w16, w16, w18
   17000:	0b100238 	add	w24, w17, w16
   17004:	34000937 	cbz	w23, 17128 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K160+0x1a0>
   17008:	528005d0 	mov	w16, #0x2e                  	// #46
   1700c:	2a1c03fa 	mov	w26, w28
   17010:	2a1903f9 	mov	w25, w25
   17014:	a93e42d8 	stp	x24, x16, [x22, #-32]
   17018:	f85b03b0 	ldur	x16, [x29, #-80]
   1701c:	2a0b03eb 	mov	w11, w11
   17020:	a904fba6 	stp	x6, x30, [x29, #72]
   17024:	2a0d03ed 	mov	w13, w13
   17028:	2a0e03ee 	mov	w14, w14
   1702c:	a903cfb0 	stp	x16, x19, [x29, #56]
   17030:	a979c3aa 	ldp	x10, x16, [x29, #-104]
   17034:	2a0903e9 	mov	w9, w9
   17038:	2a0f03ef 	mov	w15, w15
   1703c:	aa0803f6 	mov	x22, x8
   17040:	2a1003f0 	mov	w16, w16
   17044:	f9001bb0 	str	x16, [x29, #48]
   17048:	2a0c03f0 	mov	w16, w12
   1704c:	f90017b0 	str	x16, [x29, #40]
   17050:	2a0a03f0 	mov	w16, w10
   17054:	f90013b0 	str	x16, [x29, #32]
   17058:	f85b83b0 	ldur	x16, [x29, #-72]
   1705c:	a97e33aa 	ldp	x10, x12, [x29, #-32]
   17060:	2a1003f0 	mov	w16, w16
   17064:	f9000fb0 	str	x16, [x29, #24]
   17068:	2a0203f0 	mov	w16, w2
   1706c:	f9000bb0 	str	x16, [x29, #16]
   17070:	f85a83b0 	ldur	x16, [x29, #-88]
   17074:	2a1003e5 	mov	w5, w16
   17078:	a97c73b0 	ldp	x16, x28, [x29, #-64]
   1707c:	2a1003e7 	mov	w7, w16
   17080:	11000490 	add	w16, w4, #0x1
   17084:	a97d13a6 	ldp	x6, x4, [x29, #-48]
   17088:	f9002fb0 	str	x16, [x29, #88]
   1708c:	a94e7bfd 	ldp	x29, x30, [sp, #224]
   17090:	9103c3ff 	add	sp, sp, #0xf0
   17094:	17ffc506 	b	84ac <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_TRANSACTION_DISPATCH_ADAPTERS_MOTION_SET_LEDGER0>
   17098:	b85d8ec8 	ldr	w8, [x22, #-40]!
   1709c:	f0000cb0 	adrp	x16, 1ae000 <io_eff_rows+0xff0d0>
   170a0:	913f2210 	add	x16, x16, #0xfc8
   170a4:	aa1103ea 	mov	x10, x17
   170a8:	12800011 	mov	w17, #0xffffffff            	// #-1
   170ac:	f8687a08 	ldr	x8, [x16, x8, lsl #3]
   170b0:	a9041bb3 	stp	x19, x6, [x29, #64]
   170b4:	aa0a03e6 	mov	x6, x10
   170b8:	2a1203f0 	mov	w16, w18
   170bc:	a90547be 	stp	x30, x17, [x29, #80]
   170c0:	2a1903f9 	mov	w25, w25
   170c4:	f81d03a8 	stur	x8, [x29, #-48]
   170c8:	2a1a03e8 	mov	w8, w26
   170cc:	2a1c03fa 	mov	w26, w28
   170d0:	a90363a8 	stp	x8, x24, [x29, #48]
   170d4:	2a0c03e8 	mov	w8, w12
   170d8:	aa0303fc 	mov	x28, x3
   170dc:	f90017a8 	str	x8, [x29, #40]
   170e0:	2a0403e8 	mov	w8, w4
   170e4:	2a0503e5 	mov	w5, w5
   170e8:	a97e8fac 	ldp	x12, x3, [x29, #-24]
   170ec:	f90013a8 	str	x8, [x29, #32]
   170f0:	a97daba4 	ldp	x4, x10, [x29, #-40]
   170f4:	2a0203e8 	mov	w8, w2
   170f8:	2a0703e7 	mov	w7, w7
   170fc:	2a0b03eb 	mov	w11, w11
   17100:	2a0d03ed 	mov	w13, w13
   17104:	2a0e03ee 	mov	w14, w14
   17108:	2a0903e9 	mov	w9, w9
   1710c:	2a0f03ef 	mov	w15, w15
   17110:	a90143a8 	stp	x8, x16, [x29, #16]
   17114:	52800398 	mov	w24, #0x1c                  	// #28
   17118:	f85d03a2 	ldur	x2, [x29, #-48]
   1711c:	a94e7bfd 	ldp	x29, x30, [sp, #224]
   17120:	9103c3ff 	add	sp, sp, #0xf0
   17124:	d61f0040 	br	x2
   17128:	a906bfe9 	stp	x9, x15, [sp, #104]
   1712c:	a97ca2c9 	ldp	x9, x8, [x22, #-56]
   17130:	f94016b7 	ldr	x23, [x21, #40]
   17134:	aa1c03fa 	mov	x26, x28
   17138:	a9018be4 	stp	x4, x2, [sp, #24]
   1713c:	a9029bf3 	stp	x19, x6, [sp, #40]
   17140:	a903fbeb 	stp	x11, x30, [sp, #56]
   17144:	a90483ed 	stp	x13, x0, [sp, #72]
   17148:	a905bbe1 	stp	x1, x14, [sp, #88]
   1714c:	a900a7e8 	stp	x8, x9, [sp, #8]
   17150:	b4000af7 	cbz	x23, 172ac <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K160+0x324>
   17154:	f8777a88 	ldr	x8, [x20, x23, lsl #3]
   17158:	f94096a9 	ldr	x9, [x21, #296]
   1715c:	f90016a8 	str	x8, [x21, #40]
   17160:	d1008128 	sub	x8, x9, #0x20
   17164:	f90096a8 	str	x8, [x21, #296]
   17168:	8b170e9c 	add	x28, x20, x23, lsl #3
   1716c:	52801fe1 	mov	w1, #0xff                  	// #255
   17170:	52801b02 	mov	w2, #0xd8                  	// #216
   17174:	aa0c03f3 	mov	x19, x12
   17178:	91002380 	add	x0, x28, #0x8
   1717c:	97ffb25d 	bl	3af0 <memset@plt>
   17180:	a940afe9 	ldp	x9, x11, [sp, #8]
   17184:	52800028 	mov	w8, #0x1                   	// #1
   17188:	f9000398 	str	x24, [x28]
   1718c:	aa09810a 	orr	x10, x8, x9, lsl #32
   17190:	d2c5c009 	mov	x9, #0x2e0000000000        	// #50577534877696
   17194:	f2e0a009 	movk	x9, #0x500, lsl #48
   17198:	aa0902e9 	orr	x9, x23, x9
   1719c:	a90e2b8b 	stp	x11, x10, [x28, #224]
   171a0:	a93ca2c9 	stp	x9, x8, [x22, #-56]
   171a4:	f94016a0 	ldr	x0, [x21, #40]
   171a8:	b40008e0 	cbz	x0, 172c4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K160+0x33c>
   171ac:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   171b0:	f94096aa 	ldr	x10, [x21, #296]
   171b4:	f90016a8 	str	x8, [x21, #40]
   171b8:	d1008148 	sub	x8, x10, #0x20
   171bc:	f90096a8 	str	x8, [x21, #296]
   171c0:	8b000e88 	add	x8, x20, x0, lsl #3
   171c4:	d2c0002a 	mov	x10, #0x100000000           	// #4294967296
   171c8:	f9403beb 	ldr	x11, [sp, #112]
   171cc:	a97ab7ae 	ldp	x14, x13, [x29, #-88]
   171d0:	f85c83ac 	ldur	x12, [x29, #-56]
   171d4:	a90e2909 	stp	x9, x10, [x8, #224]
   171d8:	2a1903e9 	mov	w9, w25
   171dc:	2a1a03ea 	mov	w10, w26
   171e0:	a9002909 	stp	x9, x10, [x8]
   171e4:	a94527ea 	ldp	x10, x9, [sp, #80]
   171e8:	a979bfb0 	ldp	x16, x15, [x29, #-104]
   171ec:	a901311b 	stp	x27, x12, [x8, #16]
   171f0:	a902250a 	stp	x10, x9, [x8, #32]
   171f4:	f85f03aa 	ldur	x10, [x29, #-16]
   171f8:	f85d83a9 	ldur	x9, [x29, #-40]
   171fc:	a903250a 	stp	x10, x9, [x8, #48]
   17200:	2a0e03e9 	mov	w9, w14
   17204:	f85d03aa 	ldur	x10, [x29, #-48]
   17208:	f9002109 	str	x9, [x8, #64]
   1720c:	f85c03a9 	ldur	x9, [x29, #-64]
   17210:	2a0903e9 	mov	w9, w9
   17214:	a904a50a 	stp	x10, x9, [x8, #72]
   17218:	f9401fe9 	ldr	x9, [sp, #56]
   1721c:	f85e03aa 	ldur	x10, [x29, #-32]
   17220:	2a0903e9 	mov	w9, w9
   17224:	a905a50a 	stp	x10, x9, [x8, #88]
   17228:	f85e83a9 	ldur	x9, [x29, #-24]
   1722c:	f94033ea 	ldr	x10, [sp, #96]
   17230:	f9003509 	str	x9, [x8, #104]
   17234:	f94027e9 	ldr	x9, [sp, #72]
   17238:	2a0a03ea 	mov	w10, w10
   1723c:	2a0903e9 	mov	w9, w9
   17240:	a9072909 	stp	x9, x10, [x8, #112]
   17244:	f94037e9 	ldr	x9, [sp, #104]
   17248:	2a0b03ea 	mov	w10, w11
   1724c:	2a0903e9 	mov	w9, w9
   17250:	a9082909 	stp	x9, x10, [x8, #128]
   17254:	f94013e9 	ldr	x9, [sp, #32]
   17258:	f85b83aa 	ldur	x10, [x29, #-72]
   1725c:	2a0903e9 	mov	w9, w9
   17260:	2a0a03ea 	mov	w10, w10
   17264:	a9092909 	stp	x9, x10, [x8, #144]
   17268:	2a1003e9 	mov	w9, w16
   1726c:	2a1303ea 	mov	w10, w19
   17270:	a90a2909 	stp	x9, x10, [x8, #160]
   17274:	2a0f03e9 	mov	w9, w15
   17278:	a90b3509 	stp	x9, x13, [x8, #176]
   1727c:	a942a7ea 	ldp	x10, x9, [sp, #40]
   17280:	a90c250a 	stp	x10, x9, [x8, #192]
   17284:	d2c08009 	mov	x9, #0x40000000000         	// #4398046511104
   17288:	f9400fea 	ldr	x10, [sp, #24]
   1728c:	f2e0a009 	movk	x9, #0x500, lsl #48
   17290:	aa090000 	orr	x0, x0, x9
   17294:	f94023e9 	ldr	x9, [sp, #64]
   17298:	1100054a 	add	w10, w10, #0x1
   1729c:	a90d2909 	stp	x9, x10, [x8, #208]
   172a0:	a94e7bfd 	ldp	x29, x30, [sp, #224]
   172a4:	9103c3ff 	add	sp, sp, #0xf0
   172a8:	d65f03c0 	ret
   172ac:	aa1403e0 	mov	x0, x20
   172b0:	aa1503e1 	mov	x1, x21
   172b4:	528000a2 	mov	w2, #0x5                   	// #5
   172b8:	97ffb62d 	bl	4b6c <heap_alloc_miss>
   172bc:	aa0003f7 	mov	x23, x0
   172c0:	17ffffaa 	b	17168 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K160+0x1e0>
   172c4:	aa1403e0 	mov	x0, x20
   172c8:	aa1503e1 	mov	x1, x21
   172cc:	528000a2 	mov	w2, #0x5                   	// #5
   172d0:	97ffb627 	bl	4b6c <heap_alloc_miss>
   172d4:	17ffffbb 	b	171c0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K160+0x238>

