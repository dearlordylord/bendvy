   1b528:	d10243ff 	sub	sp, sp, #0x90
   1b52c:	a9087bfd 	stp	x29, x30, [sp, #128]
   1b530:	910203fd 	add	x29, sp, #0x80
   1b534:	f9402fa8 	ldr	x8, [x29, #88]
   1b538:	a93e3fac 	stp	x12, x15, [x29, #-32]
   1b53c:	aa1603f0 	mov	x16, x22
   1b540:	f81d83aa 	stur	x10, [x29, #-40]
   1b544:	a943cbb1 	ldp	x17, x18, [x29, #56]
   1b548:	f81f03a8 	stur	x8, [x29, #-16]
   1b54c:	f9400bb3 	ldr	x19, [x29, #16]
   1b550:	a944a3ac 	ldp	x12, x8, [x29, #72]
   1b554:	a942fba2 	ldp	x2, x30, [x29, #40]
   1b558:	a941abb8 	ldp	x24, x10, [x29, #24]
   1b55c:	b85f8ecf 	ldr	w15, [x22, #-8]!
   1b560:	340003b7 	cbz	w23, 1b5d4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K213+0xac>
   1b564:	a904a3ac 	stp	x12, x8, [x29, #72]
   1b568:	f85f03a8 	ldur	x8, [x29, #-16]
   1b56c:	2a0a03f0 	mov	w16, w10
   1b570:	f90033af 	str	x15, [x29, #96]
   1b574:	2a1e03ef 	mov	w15, w30
   1b578:	f85d83aa 	ldur	x10, [x29, #-40]
   1b57c:	2a0803e8 	mov	w8, w8
   1b580:	2a1903f9 	mov	w25, w25
   1b584:	2a1a03fa 	mov	w26, w26
   1b588:	f9002fa8 	str	x8, [x29, #88]
   1b58c:	2a0203e8 	mov	w8, w2
   1b590:	2a0503e5 	mov	w5, w5
   1b594:	a902bfa8 	stp	x8, x15, [x29, #40]
   1b598:	a97e23ac 	ldp	x12, x8, [x29, #-32]
   1b59c:	2a0703e7 	mov	w7, w7
   1b5a0:	a903cbb1 	stp	x17, x18, [x29, #56]
   1b5a4:	2a0b03eb 	mov	w11, w11
   1b5a8:	2a0d03ed 	mov	w13, w13
   1b5ac:	2a0e03ee 	mov	w14, w14
   1b5b0:	2a0903e9 	mov	w9, w9
   1b5b4:	2a0803ef 	mov	w15, w8
   1b5b8:	2a1803e8 	mov	w8, w24
   1b5bc:	a901c3a8 	stp	x8, x16, [x29, #24]
   1b5c0:	2a1303f0 	mov	w16, w19
   1b5c4:	f9000bb0 	str	x16, [x29, #16]
   1b5c8:	a9487bfd 	ldp	x29, x30, [sp, #128]
   1b5cc:	910243ff 	add	sp, sp, #0x90
   1b5d0:	17fff3e5 	b	18564 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_FALLBACK>
   1b5d4:	aa0203f6 	mov	x22, x2
   1b5d8:	a97e5e02 	ldp	x2, x23, [x16, #-32]
   1b5dc:	a90333fe 	stp	x30, x12, [sp, #48]
   1b5e0:	f81c83b2 	stur	x18, [x29, #-56]
   1b5e4:	f90023f1 	str	x17, [sp, #64]
   1b5e8:	f81d03a8 	stur	x8, [x29, #-48]
   1b5ec:	f94016a8 	ldr	x8, [x21, #40]
   1b5f0:	b40006a8 	cbz	x8, 1b6c4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K213+0x19c>
   1b5f4:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   1b5f8:	f94096b1 	ldr	x17, [x21, #296]
   1b5fc:	f90016b0 	str	x16, [x21, #40]
   1b600:	d1008230 	sub	x16, x17, #0x20
   1b604:	f90096b0 	str	x16, [x21, #296]
   1b608:	8b080e90 	add	x16, x20, x8, lsl #3
   1b60c:	2a0b03eb 	mov	w11, w11
   1b610:	d3607ef1 	lsl	x17, x23, #32
   1b614:	2a1a03f2 	mov	w18, w26
   1b618:	f900320b 	str	x11, [x16, #96]
   1b61c:	a97dafac 	ldp	x12, x11, [x29, #-40]
   1b620:	f9007a11 	str	x17, [x16, #240]
   1b624:	2a1903f1 	mov	w17, w25
   1b628:	f900360b 	str	x11, [x16, #104]
   1b62c:	2a0d03eb 	mov	w11, w13
   1b630:	2a0e03ed 	mov	w13, w14
   1b634:	a907360b 	stp	x11, x13, [x16, #112]
   1b638:	2a0903eb 	mov	w11, w9
   1b63c:	f85e83a9 	ldur	x9, [x29, #-24]
   1b640:	a9004a11 	stp	x17, x18, [x16]
   1b644:	2a0503f1 	mov	w17, w5
   1b648:	a9041a11 	stp	x17, x6, [x16, #64]
   1b64c:	2a0703f1 	mov	w17, w7
   1b650:	2a0903ed 	mov	w13, w9
   1b654:	a9053211 	stp	x17, x12, [x16, #80]
   1b658:	2a1803ec 	mov	w12, w24
   1b65c:	f9401be9 	ldr	x9, [sp, #48]
   1b660:	a908360b 	stp	x11, x13, [x16, #128]
   1b664:	2a1303eb 	mov	w11, w19
   1b668:	a909320b 	stp	x11, x12, [x16, #144]
   1b66c:	2a0a03eb 	mov	w11, w10
   1b670:	2a1603ea 	mov	w10, w22
   1b674:	a90a2a0b 	stp	x11, x10, [x16, #160]
   1b678:	2a0903ea 	mov	w10, w9
   1b67c:	a943afe9 	ldp	x9, x11, [sp, #56]
   1b680:	a901721b 	stp	x27, x28, [x16, #16]
   1b684:	a90b2e0a 	stp	x10, x11, [x16, #176]
   1b688:	f85c83aa 	ldur	x10, [x29, #-56]
   1b68c:	a9020600 	stp	x0, x1, [x16, #32]
   1b690:	a90c260a 	stp	x10, x9, [x16, #192]
   1b694:	f85f03a9 	ldur	x9, [x29, #-16]
   1b698:	a9031203 	stp	x3, x4, [x16, #48]
   1b69c:	2a0903ea 	mov	w10, w9
   1b6a0:	f85d03a9 	ldur	x9, [x29, #-48]
   1b6a4:	a90d2a09 	stp	x9, x10, [x16, #208]
   1b6a8:	d2c5e00a 	mov	x10, #0x2f0000000000        	// #51677046505472
   1b6ac:	f2e0a00a 	movk	x10, #0x500, lsl #48
   1b6b0:	aa0a0100 	orr	x0, x8, x10
   1b6b4:	a90e0a0f 	stp	x15, x2, [x16, #224]
   1b6b8:	a9487bfd 	ldp	x29, x30, [sp, #128]
   1b6bc:	910243ff 	add	sp, sp, #0x90
   1b6c0:	d65f03c0 	ret
   1b6c4:	a90203e1 	stp	x1, x0, [sp, #32]
   1b6c8:	aa1403e0 	mov	x0, x20
   1b6cc:	aa1503e1 	mov	x1, x21
   1b6d0:	aa0203ec 	mov	x12, x2
   1b6d4:	528000a2 	mov	w2, #0x5                   	// #5
   1b6d8:	a9001be7 	stp	x7, x6, [sp]
   1b6dc:	aa0403f5 	mov	x21, x4
   1b6e0:	a9010fe5 	stp	x5, x3, [sp, #16]
   1b6e4:	97ffa5eb 	bl	4e90 <heap_alloc_miss>
   1b6e8:	a9410fe5 	ldp	x5, x3, [sp, #16]
   1b6ec:	aa0003e8 	mov	x8, x0
   1b6f0:	a9401be7 	ldp	x7, x6, [sp]
   1b6f4:	aa0c03e2 	mov	x2, x12
   1b6f8:	a94203e1 	ldp	x1, x0, [sp, #32]
   1b6fc:	aa1503e4 	mov	x4, x21
   1b700:	17ffffc2 	b	1b608 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K213+0xe0>

