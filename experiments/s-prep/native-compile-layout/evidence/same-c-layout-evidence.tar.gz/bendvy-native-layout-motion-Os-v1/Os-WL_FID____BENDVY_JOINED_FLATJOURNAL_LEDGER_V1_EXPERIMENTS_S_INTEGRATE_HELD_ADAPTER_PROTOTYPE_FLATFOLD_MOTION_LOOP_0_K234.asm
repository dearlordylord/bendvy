   1b290:	d10243ff 	sub	sp, sp, #0x90
   1b294:	a9087bfd 	stp	x29, x30, [sp, #128]
   1b298:	910203fd 	add	x29, sp, #0x80
   1b29c:	a93d1baf 	stp	x15, x6, [x29, #-48]
   1b2a0:	a9444bbe 	ldp	x30, x18, [x29, #64]
   1b2a4:	a93e2ba9 	stp	x9, x10, [x29, #-32]
   1b2a8:	aa0703e9 	mov	x9, x7
   1b2ac:	aa1c03f8 	mov	x24, x28
   1b2b0:	f81f03ac 	stur	x12, [x29, #-16]
   1b2b4:	aa0503ec 	mov	x12, x5
   1b2b8:	aa0403e5 	mov	x5, x4
   1b2bc:	aa0303e4 	mov	x4, x3
   1b2c0:	aa0103e3 	mov	x3, x1
   1b2c4:	aa0003e1 	mov	x1, x0
   1b2c8:	a9450baa 	ldp	x10, x2, [x29, #80]
   1b2cc:	aa1b03fc 	mov	x28, x27
   1b2d0:	a9431fa0 	ldp	x0, x7, [x29, #48]
   1b2d4:	aa1903fb 	mov	x27, x25
   1b2d8:	a9421bb1 	ldp	x17, x6, [x29, #32]
   1b2dc:	aa1603e8 	mov	x8, x22
   1b2e0:	a9413fb3 	ldp	x19, x15, [x29, #16]
   1b2e4:	aa0e03f0 	mov	x16, x14
   1b2e8:	f85f8ed9 	ldr	x25, [x22, #-8]!
   1b2ec:	34000417 	cbz	w23, 1b36c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0_K234+0xdc>
   1b2f0:	2a1b03e8 	mov	w8, w27
   1b2f4:	2a1a03fb 	mov	w27, w26
   1b2f8:	aa0603fa 	mov	x26, x6
   1b2fc:	2a0c03e6 	mov	w6, w12
   1b300:	2a0203ec 	mov	w12, w2
   1b304:	a9052bb2 	stp	x18, x10, [x29, #80]
   1b308:	2a0903ea 	mov	w10, w9
   1b30c:	2a0003e9 	mov	w9, w0
   1b310:	f90033ac 	str	x12, [x29, #96]
   1b314:	2a0b03ec 	mov	w12, w11
   1b318:	2a1a03eb 	mov	w11, w26
   1b31c:	a9047ba7 	stp	x7, x30, [x29, #64]
   1b320:	a90327ab 	stp	x11, x9, [x29, #48]
   1b324:	aa1003e9 	mov	x9, x16
   1b328:	2a1103f0 	mov	w16, w17
   1b32c:	2a0f03eb 	mov	w11, w15
   1b330:	a97dbfa7 	ldp	x7, x15, [x29, #-40]
   1b334:	a90243ab 	stp	x11, x16, [x29, #32]
   1b338:	f85d03ab 	ldur	x11, [x29, #-48]
   1b33c:	2a1303f0 	mov	w16, w19
   1b340:	2a0d03ee 	mov	w14, w13
   1b344:	2a0903e9 	mov	w9, w9
   1b348:	aa0803fa 	mov	x26, x8
   1b34c:	2a0b03f1 	mov	w17, w11
   1b350:	2a0f03ef 	mov	w15, w15
   1b354:	aa1803e0 	mov	x0, x24
   1b358:	a90143b1 	stp	x17, x16, [x29, #16]
   1b35c:	a97eb7ab 	ldp	x11, x13, [x29, #-24]
   1b360:	a9487bfd 	ldp	x29, x30, [sp, #128]
   1b364:	910243ff 	add	sp, sp, #0x90
   1b368:	17fffdc5 	b	1aa7c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0>
   1b36c:	f9001ff1 	str	x17, [sp, #56]
   1b370:	a97e5d11 	ldp	x17, x23, [x8, #-32]
   1b374:	a90297ed 	stp	x13, x5, [sp, #40]
   1b378:	aa0103f6 	mov	x22, x1
   1b37c:	aa0303ee 	mov	x14, x3
   1b380:	f81c83a0 	stur	x0, [x29, #-56]
   1b384:	f94016a0 	ldr	x0, [x21, #40]
   1b388:	aa0403ed 	mov	x13, x4
   1b38c:	f90023f0 	str	x16, [sp, #64]
   1b390:	b40006e0 	cbz	x0, 1b46c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0_K234+0x1dc>
   1b394:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   1b398:	f94096b0 	ldr	x16, [x21, #296]
   1b39c:	f90016a8 	str	x8, [x21, #40]
   1b3a0:	d1008208 	sub	x8, x16, #0x20
   1b3a4:	f90096a8 	str	x8, [x21, #296]
   1b3a8:	8b000e88 	add	x8, x20, x0, lsl #3
   1b3ac:	2a0c03ec 	mov	w12, w12
   1b3b0:	2a0903e9 	mov	w9, w9
   1b3b4:	d3607ef0 	lsl	x16, x23, #32
   1b3b8:	a903350e 	stp	x14, x13, [x8, #48]
   1b3bc:	f9401bed 	ldr	x13, [sp, #48]
   1b3c0:	f9007910 	str	x16, [x8, #240]
   1b3c4:	2a1b03f0 	mov	w16, w27
   1b3c8:	a904310d 	stp	x13, x12, [x8, #64]
   1b3cc:	f85d83ac 	ldur	x12, [x29, #-40]
   1b3d0:	a9004119 	stp	x25, x16, [x8]
   1b3d4:	2a1a03f0 	mov	w16, w26
   1b3d8:	a905250c 	stp	x12, x9, [x8, #80]
   1b3dc:	2a0b03e9 	mov	w9, w11
   1b3e0:	f85e83ab 	ldur	x11, [x29, #-24]
   1b3e4:	a9017110 	stp	x16, x28, [x8, #16]
   1b3e8:	a906250b 	stp	x11, x9, [x8, #96]
   1b3ec:	f94017e9 	ldr	x9, [sp, #40]
   1b3f0:	f85f03ab 	ldur	x11, [x29, #-16]
   1b3f4:	a9025918 	stp	x24, x22, [x8, #32]
   1b3f8:	2a0903e9 	mov	w9, w9
   1b3fc:	a90c7907 	stp	x7, x30, [x8, #192]
   1b400:	a907250b 	stp	x11, x9, [x8, #112]
   1b404:	f94023e9 	ldr	x9, [sp, #64]
   1b408:	f85e03ab 	ldur	x11, [x29, #-32]
   1b40c:	a90d2912 	stp	x18, x10, [x8, #208]
   1b410:	2a0903e9 	mov	w9, w9
   1b414:	2a0b03eb 	mov	w11, w11
   1b418:	a9082d09 	stp	x9, x11, [x8, #128]
   1b41c:	f85d03a9 	ldur	x9, [x29, #-48]
   1b420:	2a1303eb 	mov	w11, w19
   1b424:	2a0903e9 	mov	w9, w9
   1b428:	a9092d09 	stp	x9, x11, [x8, #144]
   1b42c:	f9401feb 	ldr	x11, [sp, #56]
   1b430:	2a0f03e9 	mov	w9, w15
   1b434:	2a0b03eb 	mov	w11, w11
   1b438:	a90a2d09 	stp	x9, x11, [x8, #160]
   1b43c:	f85c83ab 	ldur	x11, [x29, #-56]
   1b440:	2a0603e9 	mov	w9, w6
   1b444:	2a0b03eb 	mov	w11, w11
   1b448:	a90b2d09 	stp	x9, x11, [x8, #176]
   1b44c:	d2c82009 	mov	x9, #0x410000000000        	// #71468255805440
   1b450:	f2e0a009 	movk	x9, #0x500, lsl #48
   1b454:	aa090000 	orr	x0, x0, x9
   1b458:	2a0203e9 	mov	w9, w2
   1b45c:	a90e4509 	stp	x9, x17, [x8, #224]
   1b460:	a9487bfd 	ldp	x29, x30, [sp, #128]
   1b464:	910243ff 	add	sp, sp, #0x90
   1b468:	d65f03c0 	ret
   1b46c:	aa1403e0 	mov	x0, x20
   1b470:	a9018be7 	stp	x7, x2, [sp, #24]
   1b474:	aa1503e1 	mov	x1, x21
   1b478:	528000a2 	mov	w2, #0x5                   	// #5
   1b47c:	a900fbf2 	stp	x18, x30, [sp, #8]
   1b480:	aa1103f5 	mov	x21, x17
   1b484:	f90003e6 	str	x6, [sp]
   1b488:	97ffa5b9 	bl	4b6c <heap_alloc_miss>
   1b48c:	a9404be6 	ldp	x6, x18, [sp]
   1b490:	aa1503f1 	mov	x17, x21
   1b494:	a9411ffe 	ldp	x30, x7, [sp, #16]
   1b498:	f94013e2 	ldr	x2, [sp, #32]
   1b49c:	17ffffc3 	b	1b3a8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0_K234+0x118>

