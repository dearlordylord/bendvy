    6014:	d101c3ff 	sub	sp, sp, #0x70
    6018:	a9017bfd 	stp	x29, x30, [sp, #16]
    601c:	a9026ffc 	stp	x28, x27, [sp, #32]
    6020:	a90367fa 	stp	x26, x25, [sp, #48]
    6024:	a9045ff8 	stp	x24, x23, [sp, #64]
    6028:	a90557f6 	stp	x22, x21, [sp, #80]
    602c:	a9064ff4 	stp	x20, x19, [sp, #96]
    6030:	910043fd 	add	x29, sp, #0x10
    6034:	5290a00e 	mov	w14, #0x8500                	// #34048
    6038:	aa0203f5 	mov	x21, x2
    603c:	aa0103f3 	mov	x19, x1
    6040:	72a0620e 	movk	w14, #0x310, lsl #16
    6044:	aa0003f4 	mov	x20, x0
    6048:	aa1f03f7 	mov	x23, xzr
    604c:	aa1f03f8 	mov	x24, xzr
    6050:	91040039 	add	x25, x1, #0x100
    6054:	9100201a 	add	x26, x0, #0x8
    6058:	d10005cf 	sub	x15, x14, #0x1
    605c:	d0000e16 	adrp	x22, 1c8000 <ALC+0x17e00>
    6060:	5280003b 	mov	w27, #0x1                   	// #1
    6064:	d2c0201c 	mov	x28, #0x10000000000         	// #1099511627776
    6068:	b6f804b5 	tbz	x21, #63, 60fc <term_drop+0xe8>
    606c:	92787ea8 	and	x8, x21, #0xffffffff00
    6070:	eb0f011f 	cmp	x8, x15
    6074:	54000449 	b.ls	60fc <term_drop+0xe8>  // b.plast
    6078:	b10006bf 	cmn	x21, #0x1
    607c:	54000400 	b.eq	60fc <term_drop+0xe8>  // b.none
    6080:	924716a8 	and	x8, x21, #0x7e00000000000000
    6084:	b40003c8 	cbz	x8, 60fc <term_drop+0xe8>
    6088:	92409ebc 	and	x28, x21, #0xffffffffff
    608c:	12800000 	mov	w0, #0xffffffff            	// #-1
    6090:	f90007ef 	str	x15, [sp, #8]
    6094:	8b1c0e96 	add	x22, x20, x28, lsl #3
    6098:	aa1603e1 	mov	x1, x22
    609c:	94022b99 	bl	90f00 <__aarch64_ldadd4_rel>
    60a0:	12005c08 	and	w8, w0, #0xffffff
    60a4:	7100051f 	cmp	w8, #0x1
    60a8:	54000701 	b.ne	6188 <term_drop+0x174>  // b.any
    60ac:	88dffedf 	ldar	wzr, [x22]
    60b0:	f9400268 	ldr	x8, [x19]
    60b4:	92585ab5 	and	x21, x21, #0x7fffff0000000000
    60b8:	f94002c9 	ldr	x9, [x22]
    60bc:	f90002c8 	str	x8, [x22]
    60c0:	d0000e16 	adrp	x22, 1c8000 <ALC+0x17e00>
    60c4:	f9408268 	ldr	x8, [x19, #256]
    60c8:	f900027c 	str	x28, [x19]
    60cc:	b358fd35 	bfxil	x21, x9, #24, #40
    60d0:	91000508 	add	x8, x8, #0x1
    60d4:	f9008268 	str	x8, [x19, #256]
    60d8:	395402ca 	ldrb	w10, [x22, #1280]
    60dc:	7100055f 	cmp	w10, #0x1
    60e0:	54001301 	b.ne	6340 <term_drop+0x32c>  // b.any
    60e4:	f140211f 	cmp	x8, #0x8, lsl #12
    60e8:	540012c2 	b.cs	6340 <term_drop+0x32c>  // b.hs, b.nlast
    60ec:	5290a00e 	mov	w14, #0x8500                	// #34048
    60f0:	f94007ef 	ldr	x15, [sp, #8]
    60f4:	d2c0201c 	mov	x28, #0x10000000000         	// #1099511627776
    60f8:	72a0620e 	movk	w14, #0x310, lsl #16
    60fc:	92787ea8 	and	x8, x21, #0xffffffff00
    6100:	eb0e011f 	cmp	x8, x14
    6104:	540004c3 	b.cc	619c <term_drop+0x188>  // b.lo, b.ul, b.last
    6108:	b10006bf 	cmn	x21, #0x1
    610c:	54000480 	b.eq	619c <term_drop+0x188>  // b.none
    6110:	924716a8 	and	x8, x21, #0x7e00000000000000
    6114:	b4000448 	cbz	x8, 619c <term_drop+0x188>
    6118:	d378faa9 	ubfx	x9, x21, #56, #7
    611c:	f100113f 	cmp	x9, #0x4
    6120:	54000421 	b.ne	61a4 <term_drop+0x190>  // b.any
    6124:	d368b2a8 	ubfx	x8, x21, #40, #5
    6128:	92481aa9 	and	x9, x21, #0x7f00000000000000
    612c:	d2e0c00b 	mov	x11, #0x600000000000000     	// #432345564227567616
    6130:	7100050a 	subs	w10, w8, #0x1
    6134:	1a8a33ea 	csel	w10, wzr, w10, cc	// cc = lo, ul, last
    6138:	eb0b013f 	cmp	x9, x11
    613c:	1a8a0102 	csel	w2, w8, w10, eq	// eq = none
    6140:	92409ea8 	and	x8, x21, #0xffffffffff
    6144:	f8625a69 	ldr	x9, [x19, w2, uxtw #3]
    6148:	f8287a89 	str	x9, [x20, x8, lsl #3]
    614c:	f8225a68 	str	x8, [x19, w2, uxtw #3]
    6150:	9ac22368 	lsl	x8, x27, x2
    6154:	f8625b29 	ldr	x9, [x25, w2, uxtw #3]
    6158:	8b080128 	add	x8, x9, x8
    615c:	f8225b28 	str	x8, [x25, w2, uxtw #3]
    6160:	395402c9 	ldrb	w9, [x22, #1280]
    6164:	7100053f 	cmp	w9, #0x1
    6168:	54000061 	b.ne	6174 <term_drop+0x160>  // b.any
    616c:	f140211f 	cmp	x8, #0x8, lsl #12
    6170:	54000163 	b.cc	619c <term_drop+0x188>  // b.lo, b.ul, b.last
    6174:	aa1403e0 	mov	x0, x20
    6178:	aa1303e1 	mov	x1, x19
    617c:	97fff931 	bl	4640 <heap_hand>
    6180:	b5000738 	cbnz	x24, 6264 <term_drop+0x250>
    6184:	14000074 	b	6354 <term_drop+0x340>
    6188:	5290a00e 	mov	w14, #0x8500                	// #34048
    618c:	f94007ef 	ldr	x15, [sp, #8]
    6190:	d0000e16 	adrp	x22, 1c8000 <ALC+0x17e00>
    6194:	72a0620e 	movk	w14, #0x310, lsl #16
    6198:	d2c0201c 	mov	x28, #0x10000000000         	// #1099511627776
    619c:	b5000658 	cbnz	x24, 6264 <term_drop+0x250>
    61a0:	1400006d 	b	6354 <term_drop+0x340>
    61a4:	f100193f 	cmp	x9, #0x6
    61a8:	540001a0 	b.eq	61dc <term_drop+0x1c8>  // b.none
    61ac:	d368dea8 	ubfx	x8, x21, #40, #16
    61b0:	f100093f 	cmp	x9, #0x2
    61b4:	540001c1 	b.ne	61ec <term_drop+0x1d8>  // b.any
    61b8:	d37ff908 	lsl	x8, x8, #1
    61bc:	f000044a 	adrp	x10, 91000 <_IO_stdin_used+0xb0>
    61c0:	91033d4a 	add	x10, x10, #0xcf
    61c4:	38686948 	ldrb	w8, [x10, x8]
    61c8:	7103e11f 	cmp	w8, #0xf8
    61cc:	54000223 	b.cc	6210 <term_drop+0x1fc>  // b.lo, b.ul, b.last
    61d0:	5103c109 	sub	w9, w8, #0xf0
    61d4:	321a0129 	orr	w9, w9, #0x40
    61d8:	14000017 	b	6234 <term_drop+0x220>
    61dc:	d368b2a9 	ubfx	x9, x21, #40, #5
    61e0:	2a1f03e8 	mov	w8, wzr
    61e4:	321a0129 	orr	w9, w9, #0x40
    61e8:	14000013 	b	6234 <term_drop+0x220>
    61ec:	8b080508 	add	x8, x8, x8, lsl #1
    61f0:	f000044a 	adrp	x10, 91000 <_IO_stdin_used+0xb0>
    61f4:	9109754a 	add	x10, x10, #0x25d
    61f8:	f1000d3f 	cmp	x9, #0x3
    61fc:	38686948 	ldrb	w8, [x10, x8]
    6200:	1a9f17ea 	cset	w10, eq	// eq = none
    6204:	4b0a0108 	sub	w8, w8, w10
    6208:	7103e11f 	cmp	w8, #0xf8
    620c:	54fffe22 	b.cs	61d0 <term_drop+0x1bc>  // b.hs, b.nlast
    6210:	1100090a 	add	w10, w8, #0x2
    6214:	f100153f 	cmp	x9, #0x5
    6218:	5280040b 	mov	w11, #0x20                  	// #32
    621c:	1a880149 	csel	w9, w10, w8, eq	// eq = none
    6220:	7100052a 	subs	w10, w9, #0x1
    6224:	5ac0114a 	clz	w10, w10
    6228:	7100053f 	cmp	w9, #0x1
    622c:	4b0a016a 	sub	w10, w11, w10
    6230:	1a9f8149 	csel	w9, w10, wzr, hi	// hi = pmore
    6234:	d3503d08 	lsl	x8, x8, #48
    6238:	92409eaa 	and	x10, x21, #0xffffffffff
    623c:	f86a7a97 	ldr	x23, [x20, x10, lsl #3]
    6240:	f82a7a98 	str	x24, [x20, x10, lsl #3]
    6244:	aa09e108 	orr	x8, x8, x9, lsl #56
    6248:	aa0a0118 	orr	x24, x8, x10
    624c:	b50000d8 	cbnz	x24, 6264 <term_drop+0x250>
    6250:	14000041 	b	6354 <term_drop+0x340>
    6254:	aa1403e0 	mov	x0, x20
    6258:	aa1303e1 	mov	x1, x19
    625c:	97fff8f9 	bl	4640 <heap_hand>
    6260:	b40007b8 	cbz	x24, 6354 <term_drop+0x340>
    6264:	d37eff08 	lsr	x8, x24, #62
    6268:	d368bf09 	ubfx	x9, x24, #40, #8
    626c:	d378ff02 	lsr	x2, x24, #56
    6270:	92409f0a 	and	x10, x24, #0xffffffffff
    6274:	b4000148 	cbz	x8, 629c <term_drop+0x288>
    6278:	1ac2236b 	lsl	w11, w27, w2
    627c:	7100093f 	cmp	w9, #0x2
    6280:	1200144d 	and	w13, w2, #0x3f
    6284:	540003a1 	b.ne	62f8 <term_drop+0x2e4>  // b.any
    6288:	f86a7b4c 	ldr	x12, [x26, x10, lsl #3]
    628c:	2a0d03e2 	mov	w2, w13
    6290:	6b0b019f 	cmp	w12, w11
    6294:	540000c3 	b.cc	62ac <term_drop+0x298>  // b.lo, b.ul, b.last
    6298:	1400001c 	b	6308 <term_drop+0x2f4>
    629c:	d370df0b 	ubfx	x11, x24, #48, #8
    62a0:	2a0903ec 	mov	w12, w9
    62a4:	6b0b019f 	cmp	w12, w11
    62a8:	54000302 	b.cs	6308 <term_drop+0x2f4>  // b.hs, b.nlast
    62ac:	aa1703f5 	mov	x21, x23
    62b0:	340000cc 	cbz	w12, 62c8 <term_drop+0x2b4>
    62b4:	8b0a0e8b 	add	x11, x20, x10, lsl #3
    62b8:	f86c5975 	ldr	x21, [x11, w12, uxtw #3]
    62bc:	b4000068 	cbz	x8, 62c8 <term_drop+0x2b4>
    62c0:	1100058b 	add	w11, w12, #0x1
    62c4:	f82a7b4b 	str	x11, [x26, x10, lsl #3]
    62c8:	7100053f 	cmp	w9, #0x1
    62cc:	fa408904 	ccmp	x8, #0x0, #0x4, hi	// hi = pmore
    62d0:	8b1c0308 	add	x8, x24, x28
    62d4:	9a881318 	csel	x24, x24, x8, ne	// ne = any
    62d8:	b10006bf 	cmn	x21, #0x1
    62dc:	54fffc20 	b.eq	6260 <term_drop+0x24c>  // b.none
    62e0:	924716a8 	and	x8, x21, #0x7e00000000000000
    62e4:	b4fffbe8 	cbz	x8, 6260 <term_drop+0x24c>
    62e8:	92787ea8 	and	x8, x21, #0xffffffff00
    62ec:	eb0e011f 	cmp	x8, x14
    62f0:	54fffb83 	b.cc	6260 <term_drop+0x24c>  // b.lo, b.ul, b.last
    62f4:	17ffff5d 	b	6068 <term_drop+0x54>
    62f8:	2a0d03e2 	mov	w2, w13
    62fc:	2a0903ec 	mov	w12, w9
    6300:	6b0b019f 	cmp	w12, w11
    6304:	54fffd43 	b.cc	62ac <term_drop+0x298>  // b.lo, b.ul, b.last
    6308:	f8625a68 	ldr	x8, [x19, w2, uxtw #3]
    630c:	f86a7a98 	ldr	x24, [x20, x10, lsl #3]
    6310:	f82a7a88 	str	x8, [x20, x10, lsl #3]
    6314:	9ac22368 	lsl	x8, x27, x2
    6318:	f8225a6a 	str	x10, [x19, w2, uxtw #3]
    631c:	f8625b29 	ldr	x9, [x25, w2, uxtw #3]
    6320:	8b080128 	add	x8, x9, x8
    6324:	f8225b28 	str	x8, [x25, w2, uxtw #3]
    6328:	395402c9 	ldrb	w9, [x22, #1280]
    632c:	7100053f 	cmp	w9, #0x1
    6330:	54fff921 	b.ne	6254 <term_drop+0x240>  // b.any
    6334:	f140211f 	cmp	x8, #0x8, lsl #12
    6338:	54fff943 	b.cc	6260 <term_drop+0x24c>  // b.lo, b.ul, b.last
    633c:	17ffffc6 	b	6254 <term_drop+0x240>
    6340:	aa1403e0 	mov	x0, x20
    6344:	aa1303e1 	mov	x1, x19
    6348:	2a1f03e2 	mov	w2, wzr
    634c:	97fff8bd 	bl	4640 <heap_hand>
    6350:	17ffff67 	b	60ec <term_drop+0xd8>
    6354:	a9464ff4 	ldp	x20, x19, [sp, #96]
    6358:	a94557f6 	ldp	x22, x21, [sp, #80]
    635c:	a9445ff8 	ldp	x24, x23, [sp, #64]
    6360:	a94367fa 	ldp	x26, x25, [sp, #48]
    6364:	a9426ffc 	ldp	x28, x27, [sp, #32]
    6368:	a9417bfd 	ldp	x29, x30, [sp, #16]
    636c:	9101c3ff 	add	sp, sp, #0x70
    6370:	d65f03c0 	ret

