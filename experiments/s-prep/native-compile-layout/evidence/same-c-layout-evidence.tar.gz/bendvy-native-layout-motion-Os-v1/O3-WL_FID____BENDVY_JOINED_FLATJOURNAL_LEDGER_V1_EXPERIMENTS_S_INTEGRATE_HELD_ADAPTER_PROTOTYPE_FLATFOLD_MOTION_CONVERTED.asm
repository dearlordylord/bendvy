   170f0:	d10283ff 	sub	sp, sp, #0xa0
   170f4:	a9097bfd 	stp	x29, x30, [sp, #144]
   170f8:	910243fd 	add	x29, sp, #0x90
   170fc:	a93e3fa9 	stp	x9, x15, [x29, #-32]
   17100:	a9444bb1 	ldp	x17, x18, [x29, #64]
   17104:	f81f03ac 	stur	x12, [x29, #-16]
   17108:	a94527ac 	ldp	x12, x9, [x29, #80]
   1710c:	a94343a2 	ldp	x2, x16, [x29, #48]
   17110:	a9427baf 	ldp	x15, x30, [x29, #32]
   17114:	a9414fb8 	ldp	x24, x19, [x29, #16]
   17118:	34000397 	cbz	w23, 17188 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_CONVERTED+0x98>
   1711c:	2a0903e8 	mov	w8, w9
   17120:	528004c9 	mov	w9, #0x26                  	// #38
   17124:	2a1903f9 	mov	w25, w25
   17128:	a88126c8 	stp	x8, x9, [x22], #16
   1712c:	2a0203e8 	mov	w8, w2
   17130:	a904b3b2 	stp	x18, x12, [x29, #72]
   17134:	2a1e03ec 	mov	w12, w30
   17138:	2a1a03fa 	mov	w26, w26
   1713c:	a902a3ac 	stp	x12, x8, [x29, #40]
   17140:	a97e33a8 	ldp	x8, x12, [x29, #-32]
   17144:	2a0503e5 	mov	w5, w5
   17148:	2a0703e7 	mov	w7, w7
   1714c:	2a0b03eb 	mov	w11, w11
   17150:	a903c7b0 	stp	x16, x17, [x29, #56]
   17154:	2a0d03ed 	mov	w13, w13
   17158:	2a0e03ee 	mov	w14, w14
   1715c:	2a0803e9 	mov	w9, w8
   17160:	2a0f03e8 	mov	w8, w15
   17164:	2a0c03ef 	mov	w15, w12
   17168:	2a1303ec 	mov	w12, w19
   1716c:	a901a3ac 	stp	x12, x8, [x29, #24]
   17170:	2a1803e8 	mov	w8, w24
   17174:	f85f03ac 	ldur	x12, [x29, #-16]
   17178:	f9000ba8 	str	x8, [x29, #16]
   1717c:	a9497bfd 	ldp	x29, x30, [sp, #144]
   17180:	910283ff 	add	sp, sp, #0xa0
   17184:	140021e5 	b	1f918 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_TRANSACTION_PROTOTYPE_FLAT_PACK_0>
   17188:	a93d7baf 	stp	x15, x30, [x29, #-48]
   1718c:	f94016a8 	ldr	x8, [x21, #40]
   17190:	a903cbe2 	stp	x2, x18, [sp, #56]
   17194:	f90027f1 	str	x17, [sp, #72]
   17198:	a93c33b0 	stp	x16, x12, [x29, #-64]
   1719c:	a97eb2d7 	ldp	x23, x12, [x22, #-24]
   171a0:	b4000aa8 	cbz	x8, 172f4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_CONVERTED+0x204>
   171a4:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   171a8:	f94096b1 	ldr	x17, [x21, #296]
   171ac:	f90016b0 	str	x16, [x21, #40]
   171b0:	d1008230 	sub	x16, x17, #0x20
   171b4:	f90096b0 	str	x16, [x21, #296]
   171b8:	52800032 	mov	w18, #0x1                   	// #1
   171bc:	8b080e90 	add	x16, x20, x8, lsl #3
   171c0:	6f07e7e0 	movi	v0.2d, #0xffffffffffffffff
   171c4:	aa0c824c 	orr	x12, x18, x12, lsl #32
   171c8:	92800011 	mov	x17, #0xffffffffffffffff    	// #-1
   171cc:	2a0903e9 	mov	w9, w9
   171d0:	a90dde11 	stp	x17, x23, [x16, #216]
   171d4:	f900760c 	str	x12, [x16, #232]
   171d8:	d2c4c00c 	mov	x12, #0x260000000000        	// #41781441855488
   171dc:	f2e0a00c 	movk	x12, #0x500, lsl #48
   171e0:	3c8c8200 	stur	q0, [x16, #200]
   171e4:	aa0c0117 	orr	x23, x8, x12
   171e8:	3c8b8200 	stur	q0, [x16, #184]
   171ec:	3c8a8200 	stur	q0, [x16, #168]
   171f0:	3c898200 	stur	q0, [x16, #152]
   171f4:	3c888200 	stur	q0, [x16, #136]
   171f8:	3c878200 	stur	q0, [x16, #120]
   171fc:	3c868200 	stur	q0, [x16, #104]
   17200:	3c858200 	stur	q0, [x16, #88]
   17204:	3c848200 	stur	q0, [x16, #72]
   17208:	3c838200 	stur	q0, [x16, #56]
   1720c:	3c828200 	stur	q0, [x16, #40]
   17210:	3c818200 	stur	q0, [x16, #24]
   17214:	3c808200 	stur	q0, [x16, #8]
   17218:	f9000209 	str	x9, [x16]
   1721c:	a93ecad7 	stp	x23, x18, [x22, #-24]
   17220:	a97d47b2 	ldp	x18, x17, [x29, #-48]
   17224:	f94016a8 	ldr	x8, [x21, #40]
   17228:	b4000828 	cbz	x8, 1732c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_CONVERTED+0x23c>
   1722c:	f8687a89 	ldr	x9, [x20, x8, lsl #3]
   17230:	f94096ac 	ldr	x12, [x21, #296]
   17234:	f90016a9 	str	x9, [x21, #40]
   17238:	d1008189 	sub	x9, x12, #0x20
   1723c:	f90096a9 	str	x9, [x21, #296]
   17240:	8b080e90 	add	x16, x20, x8, lsl #3
   17244:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
   17248:	2a1a03ec 	mov	w12, w26
   1724c:	f9007209 	str	x9, [x16, #224]
   17250:	2a1903e9 	mov	w9, w25
   17254:	a9003209 	stp	x9, x12, [x16]
   17258:	2a0503e9 	mov	w9, w5
   1725c:	a9041a09 	stp	x9, x6, [x16, #64]
   17260:	2a0703e9 	mov	w9, w7
   17264:	a9052a09 	stp	x9, x10, [x16, #80]
   17268:	2a0b03e9 	mov	w9, w11
   1726c:	2a0e03eb 	mov	w11, w14
   17270:	f9003209 	str	x9, [x16, #96]
   17274:	a97ea7aa 	ldp	x10, x9, [x29, #-24]
   17278:	a9020600 	stp	x0, x1, [x16, #32]
   1727c:	a901721b 	stp	x27, x28, [x16, #16]
   17280:	f9003609 	str	x9, [x16, #104]
   17284:	2a0d03e9 	mov	w9, w13
   17288:	a9072e09 	stp	x9, x11, [x16, #112]
   1728c:	f85e03a9 	ldur	x9, [x29, #-32]
   17290:	2a0a03eb 	mov	w11, w10
   17294:	2a1103ea 	mov	w10, w17
   17298:	a9031203 	stp	x3, x4, [x16, #48]
   1729c:	2a0903e9 	mov	w9, w9
   172a0:	a9082e09 	stp	x9, x11, [x16, #128]
   172a4:	2a1803e9 	mov	w9, w24
   172a8:	2a1303eb 	mov	w11, w19
   172ac:	a9092e09 	stp	x9, x11, [x16, #144]
   172b0:	2a1203e9 	mov	w9, w18
   172b4:	a90a2a09 	stp	x9, x10, [x16, #160]
   172b8:	f9401fe9 	ldr	x9, [sp, #56]
   172bc:	f85c03aa 	ldur	x10, [x29, #-64]
   172c0:	2a0903e9 	mov	w9, w9
   172c4:	f9005a09 	str	x9, [x16, #176]
   172c8:	a9442fe9 	ldp	x9, x11, [sp, #64]
   172cc:	f9006609 	str	x9, [x16, #200]
   172d0:	d2ca8009 	mov	x9, #0x540000000000        	// #92358976733184
   172d4:	f2e0a009 	movk	x9, #0x500, lsl #48
   172d8:	a90bae0a 	stp	x10, x11, [x16, #184]
   172dc:	aa090100 	orr	x0, x8, x9
   172e0:	f85c83a8 	ldur	x8, [x29, #-56]
   172e4:	a90d5e08 	stp	x8, x23, [x16, #208]
   172e8:	a9497bfd 	ldp	x29, x30, [sp, #144]
   172ec:	910283ff 	add	sp, sp, #0xa0
   172f0:	d65f03c0 	ret
   172f4:	a90283e1 	stp	x1, x0, [sp, #40]
   172f8:	aa1403e0 	mov	x0, x20
   172fc:	aa1503e1 	mov	x1, x21
   17300:	528000a2 	mov	w2, #0x5                   	// #5
   17304:	a9019be5 	stp	x5, x6, [sp, #24]
   17308:	a9001fe4 	stp	x4, x7, [sp]
   1730c:	f9000be3 	str	x3, [sp, #16]
   17310:	97ffb6e0 	bl	4e90 <heap_alloc_miss>
   17314:	a94117e3 	ldp	x3, x5, [sp, #16]
   17318:	aa0003e8 	mov	x8, x0
   1731c:	a9401fe4 	ldp	x4, x7, [sp]
   17320:	f9401be0 	ldr	x0, [sp, #48]
   17324:	a94207e6 	ldp	x6, x1, [sp, #32]
   17328:	17ffffa4 	b	171b8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_CONVERTED+0xc8>
   1732c:	a90283e1 	stp	x1, x0, [sp, #40]
   17330:	aa1403e0 	mov	x0, x20
   17334:	aa1503e1 	mov	x1, x21
   17338:	528000a2 	mov	w2, #0x5                   	// #5
   1733c:	a9019be5 	stp	x5, x6, [sp, #24]
   17340:	aa0403e9 	mov	x9, x4
   17344:	aa0303f6 	mov	x22, x3
   17348:	aa0703f5 	mov	x21, x7
   1734c:	97ffb6d1 	bl	4e90 <heap_alloc_miss>
   17350:	a97d47b2 	ldp	x18, x17, [x29, #-48]
   17354:	aa0003e8 	mov	x8, x0
   17358:	a9419be5 	ldp	x5, x6, [sp, #24]
   1735c:	aa1503e7 	mov	x7, x21
   17360:	a94283e1 	ldp	x1, x0, [sp, #40]
   17364:	aa1603e3 	mov	x3, x22
   17368:	aa0903e4 	mov	x4, x9
   1736c:	17ffffb5 	b	17240 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_CONVERTED+0x150>

