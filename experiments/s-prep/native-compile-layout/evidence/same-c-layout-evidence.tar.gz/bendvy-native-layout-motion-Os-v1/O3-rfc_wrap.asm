    525c:	f81b0fef 	str	x15, [sp, #-80]!
    5260:	a90137ee 	stp	x14, x13, [sp, #16]
    5264:	a9022fec 	stp	x12, x11, [sp, #32]
    5268:	a90327ea 	stp	x10, x9, [sp, #48]
    526c:	a9047bfd 	stp	x29, x30, [sp, #64]
    5270:	910103fd 	add	x29, sp, #0x40
    5274:	d378f848 	ubfx	x8, x2, #56, #7
    5278:	f100151f 	cmp	x8, #0x5
    527c:	540003c0 	b.eq	52f4 <rfc_wrap+0x98>  // b.none
    5280:	f1000d1f 	cmp	x8, #0x3
    5284:	54000380 	b.eq	52f4 <rfc_wrap+0x98>  // b.none
    5288:	f9400028 	ldr	x8, [x1]
    528c:	2a0303ea 	mov	w10, w3
    5290:	aa0203e9 	mov	x9, x2
    5294:	aa0003eb 	mov	x11, x0
    5298:	b4000248 	cbz	x8, 52e0 <rfc_wrap+0x84>
    529c:	f8687970 	ldr	x16, [x11, x8, lsl #3]
    52a0:	f9408031 	ldr	x17, [x1, #256]
    52a4:	f9000030 	str	x16, [x1]
    52a8:	d1000630 	sub	x16, x17, #0x1
    52ac:	f9008030 	str	x16, [x1, #256]
    52b0:	2a0a03f1 	mov	w17, w10
    52b4:	92585930 	and	x16, x9, #0x7fffff0000000000
    52b8:	aa096231 	orr	x17, x17, x9, lsl #24
    52bc:	aa080210 	orr	x16, x16, x8
    52c0:	b2410200 	orr	x0, x16, #0x8000000000000000
    52c4:	f8287971 	str	x17, [x11, x8, lsl #3]
    52c8:	a9447bfd 	ldp	x29, x30, [sp, #64]
    52cc:	a94327ea 	ldp	x10, x9, [sp, #48]
    52d0:	a9422fec 	ldp	x12, x11, [sp, #32]
    52d4:	a94137ee 	ldp	x14, x13, [sp, #16]
    52d8:	f84507ef 	ldr	x15, [sp], #80
    52dc:	d65f03c0 	ret
    52e0:	aa0b03e0 	mov	x0, x11
    52e4:	2a1f03e2 	mov	w2, wzr
    52e8:	97fffeea 	bl	4e90 <heap_alloc_miss>
    52ec:	aa0003e8 	mov	x8, x0
    52f0:	17fffff0 	b	52b0 <rfc_wrap+0x54>
    52f4:	528000c0 	mov	w0, #0x6                   	// #6
    52f8:	94000334 	bl	5fc8 <err_post>

