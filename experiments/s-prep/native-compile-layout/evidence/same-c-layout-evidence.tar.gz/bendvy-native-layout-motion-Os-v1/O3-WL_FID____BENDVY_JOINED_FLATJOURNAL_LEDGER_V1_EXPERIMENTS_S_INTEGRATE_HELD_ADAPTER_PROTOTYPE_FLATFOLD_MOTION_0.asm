   1e730:	d102c3ff 	sub	sp, sp, #0xb0
   1e734:	a90a7bfd 	stp	x29, x30, [sp, #160]
   1e738:	910283fd 	add	x29, sp, #0xa0
   1e73c:	a944c7b0 	ldp	x16, x17, [x29, #72]
   1e740:	a93d37ab 	stp	x11, x13, [x29, #-48]
   1e744:	a93c1fb9 	stp	x25, x7, [x29, #-64]
   1e748:	aa0503eb 	mov	x11, x5
   1e74c:	f9400bb3 	ldr	x19, [x29, #16]
   1e750:	a945a3a5 	ldp	x5, x8, [x29, #88]
   1e754:	a93ec7b0 	stp	x16, x17, [x29, #-24]
   1e758:	a943c7b0 	ldp	x16, x17, [x29, #56]
   1e75c:	a9418bb9 	ldp	x25, x2, [x29, #24]
   1e760:	f81e03b1 	stur	x17, [x29, #-32]
   1e764:	a942c7b2 	ldp	x18, x17, [x29, #40]
   1e768:	b7f8067c 	tbnz	x28, #63, 1e834 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x104>
   1e76c:	b7f806a0 	tbnz	x0, #63, 1e840 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x110>
   1e770:	b7f806e1 	tbnz	x1, #63, 1e84c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x11c>
   1e774:	b7f80723 	tbnz	x3, #63, 1e858 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x128>
   1e778:	b7f80764 	tbnz	x4, #63, 1e864 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x134>
   1e77c:	b7f807ab 	tbnz	x11, #63, 1e870 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x140>
   1e780:	f85d03ad 	ldur	x13, [x29, #-48]
   1e784:	b7f807ed 	tbnz	x13, #63, 1e880 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x150>
   1e788:	f85d83ad 	ldur	x13, [x29, #-40]
   1e78c:	b7f8084d 	tbnz	x13, #63, 1e894 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x164>
   1e790:	f85e03b8 	ldur	x24, [x29, #-32]
   1e794:	b7f808b8 	tbnz	x24, #63, 1e8a8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x178>
   1e798:	f85e83b8 	ldur	x24, [x29, #-24]
   1e79c:	b7f80918 	tbnz	x24, #63, 1e8bc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x18c>
   1e7a0:	f85f03b8 	ldur	x24, [x29, #-16]
   1e7a4:	b7f80978 	tbnz	x24, #63, 1e8d0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x1a0>
   1e7a8:	b7f809c5 	tbnz	x5, #63, 1e8e0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x1b0>
   1e7ac:	2a1a03fa 	mov	w26, w26
   1e7b0:	2a1b03fb 	mov	w27, w27
   1e7b4:	2a0603e6 	mov	w6, w6
   1e7b8:	2a0a03ea 	mov	w10, w10
   1e7bc:	2a0c03ec 	mov	w12, w12
   1e7c0:	2a0e03ee 	mov	w14, w14
   1e7c4:	2a0903e9 	mov	w9, w9
   1e7c8:	2a0f03ef 	mov	w15, w15
   1e7cc:	2a1303fe 	mov	w30, w19
   1e7d0:	2a1903e7 	mov	w7, w25
   1e7d4:	2a0203e2 	mov	w2, w2
   1e7d8:	2a1203f8 	mov	w24, w18
   1e7dc:	2a1103ed 	mov	w13, w17
   1e7e0:	2a1003f9 	mov	w25, w16
   1e7e4:	2a0803f3 	mov	w19, w8
   1e7e8:	34000837 	cbz	w23, 1e8ec <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x1bc>
   1e7ec:	528009e8 	mov	w8, #0x4f                  	// #79
   1e7f0:	f80086c8 	str	x8, [x22], #8
   1e7f4:	f85f03a8 	ldur	x8, [x29, #-16]
   1e7f8:	a905cfa5 	stp	x5, x19, [x29, #88]
   1e7fc:	aa0b03e5 	mov	x5, x11
   1e800:	f9002ba8 	str	x8, [x29, #80]
   1e804:	f85e83a8 	ldur	x8, [x29, #-24]
   1e808:	a902b7b8 	stp	x24, x13, [x29, #40]
   1e80c:	a97d37ab 	ldp	x11, x13, [x29, #-48]
   1e810:	f90027a8 	str	x8, [x29, #72]
   1e814:	f85e03a8 	ldur	x8, [x29, #-32]
   1e818:	a9018ba7 	stp	x7, x2, [x29, #24]
   1e81c:	a903a3b9 	stp	x25, x8, [x29, #56]
   1e820:	a97c1fb9 	ldp	x25, x7, [x29, #-64]
   1e824:	f9000bbe 	str	x30, [x29, #16]
   1e828:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   1e82c:	9102c3ff 	add	sp, sp, #0xb0
   1e830:	17fff5ed 	b	1bfe4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0>
   1e834:	92409f98 	and	x24, x28, #0xffffffffff
   1e838:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1e83c:	b6fff9a0 	tbz	x0, #63, 1e770 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x40>
   1e840:	92409c18 	and	x24, x0, #0xffffffffff
   1e844:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1e848:	b6fff961 	tbz	x1, #63, 1e774 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x44>
   1e84c:	92409c38 	and	x24, x1, #0xffffffffff
   1e850:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1e854:	b6fff923 	tbz	x3, #63, 1e778 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x48>
   1e858:	92409c78 	and	x24, x3, #0xffffffffff
   1e85c:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1e860:	b6fff8e4 	tbz	x4, #63, 1e77c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x4c>
   1e864:	92409c98 	and	x24, x4, #0xffffffffff
   1e868:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1e86c:	b6fff8ab 	tbz	x11, #63, 1e780 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x50>
   1e870:	92409d78 	and	x24, x11, #0xffffffffff
   1e874:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1e878:	f85d03ad 	ldur	x13, [x29, #-48]
   1e87c:	b6fff86d 	tbz	x13, #63, 1e788 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x58>
   1e880:	f85d03ad 	ldur	x13, [x29, #-48]
   1e884:	92409db8 	and	x24, x13, #0xffffffffff
   1e888:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1e88c:	f85d83ad 	ldur	x13, [x29, #-40]
   1e890:	b6fff80d 	tbz	x13, #63, 1e790 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x60>
   1e894:	f85d83ad 	ldur	x13, [x29, #-40]
   1e898:	92409db8 	and	x24, x13, #0xffffffffff
   1e89c:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1e8a0:	f85e03b8 	ldur	x24, [x29, #-32]
   1e8a4:	b6fff7b8 	tbz	x24, #63, 1e798 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x68>
   1e8a8:	f85e03b8 	ldur	x24, [x29, #-32]
   1e8ac:	92409f18 	and	x24, x24, #0xffffffffff
   1e8b0:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1e8b4:	f85e83b8 	ldur	x24, [x29, #-24]
   1e8b8:	b6fff758 	tbz	x24, #63, 1e7a0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x70>
   1e8bc:	f85e83b8 	ldur	x24, [x29, #-24]
   1e8c0:	92409f18 	and	x24, x24, #0xffffffffff
   1e8c4:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1e8c8:	f85f03b8 	ldur	x24, [x29, #-16]
   1e8cc:	b6fff6f8 	tbz	x24, #63, 1e7a8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x78>
   1e8d0:	f85f03b8 	ldur	x24, [x29, #-16]
   1e8d4:	92409f18 	and	x24, x24, #0xffffffffff
   1e8d8:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1e8dc:	b6fff685 	tbz	x5, #63, 1e7ac <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x7c>
   1e8e0:	92409cb8 	and	x24, x5, #0xffffffffff
   1e8e4:	f8787a9f 	ldr	xzr, [x20, x24, lsl #3]
   1e8e8:	17ffffb1 	b	1e7ac <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x7c>
   1e8ec:	a9049fe2 	stp	x2, x7, [sp, #72]
   1e8f0:	a97edec2 	ldp	x2, x23, [x22, #-24]
   1e8f4:	f94016a8 	ldr	x8, [x21, #40]
   1e8f8:	f81b83be 	stur	x30, [x29, #-72]
   1e8fc:	b40007a8 	cbz	x8, 1e9f0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x2c0>
   1e900:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   1e904:	f94096b1 	ldr	x17, [x21, #296]
   1e908:	f90016b0 	str	x16, [x21, #40]
   1e90c:	d1008230 	sub	x16, x17, #0x20
   1e910:	f90096b0 	str	x16, [x21, #296]
   1e914:	6f07e7e0 	movi	v0.2d, #0xffffffffffffffff
   1e918:	52800031 	mov	w17, #0x1                   	// #1
   1e91c:	d2c9e012 	mov	x18, #0x4f0000000000        	// #86861418594304
   1e920:	8b080e90 	add	x16, x20, x8, lsl #3
   1e924:	aa178231 	orr	x17, x17, x23, lsl #32
   1e928:	f2e0a012 	movk	x18, #0x500, lsl #48
   1e92c:	aa120117 	orr	x23, x8, x18
   1e930:	a90e4602 	stp	x2, x17, [x16, #224]
   1e934:	ad000200 	stp	q0, q0, [x16]
   1e938:	ad010200 	stp	q0, q0, [x16, #32]
   1e93c:	ad020200 	stp	q0, q0, [x16, #64]
   1e940:	ad030200 	stp	q0, q0, [x16, #96]
   1e944:	ad040200 	stp	q0, q0, [x16, #128]
   1e948:	ad050200 	stp	q0, q0, [x16, #160]
   1e94c:	ad060200 	stp	q0, q0, [x16, #192]
   1e950:	a93efed7 	stp	x23, xzr, [x22, #-24]
   1e954:	f94016a8 	ldr	x8, [x21, #40]
   1e958:	b40006e8 	cbz	x8, 1ea34 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x304>
   1e95c:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   1e960:	f94096b1 	ldr	x17, [x21, #296]
   1e964:	aa0e03f2 	mov	x18, x14
   1e968:	aa0c03e2 	mov	x2, x12
   1e96c:	aa1a03fe 	mov	x30, x26
   1e970:	f90016b0 	str	x16, [x21, #40]
   1e974:	d1008230 	sub	x16, x17, #0x20
   1e978:	f90096b0 	str	x16, [x21, #296]
   1e97c:	a97c33b1 	ldp	x17, x12, [x29, #-64]
   1e980:	8b080e90 	add	x16, x20, x8, lsl #3
   1e984:	a9041a0b 	stp	x11, x6, [x16, #64]
   1e988:	a9052a0c 	stp	x12, x10, [x16, #80]
   1e98c:	a97d2faa 	ldp	x10, x11, [x29, #-48]
   1e990:	a9083e09 	stp	x9, x15, [x16, #128]
   1e994:	f9007a1f 	str	xzr, [x16, #240]
   1e998:	a9074a0b 	stp	x11, x18, [x16, #112]
   1e99c:	a944afe9 	ldp	x9, x11, [sp, #72]
   1e9a0:	a9060a0a 	stp	x10, x2, [x16, #96]
   1e9a4:	f85b83aa 	ldur	x10, [x29, #-72]
   1e9a8:	a9007a11 	stp	x17, x30, [x16]
   1e9ac:	a9092e0a 	stp	x10, x11, [x16, #144]
   1e9b0:	a90a6209 	stp	x9, x24, [x16, #160]
   1e9b4:	a97e27aa 	ldp	x10, x9, [x29, #-32]
   1e9b8:	a901721b 	stp	x27, x28, [x16, #16]
   1e9bc:	a9020600 	stp	x0, x1, [x16, #32]
   1e9c0:	a90c260a 	stp	x10, x9, [x16, #192]
   1e9c4:	f85f03a9 	ldur	x9, [x29, #-16]
   1e9c8:	a9031203 	stp	x3, x4, [x16, #48]
   1e9cc:	a90d1609 	stp	x9, x5, [x16, #208]
   1e9d0:	d2c82009 	mov	x9, #0x410000000000        	// #71468255805440
   1e9d4:	f2e0a009 	movk	x9, #0x500, lsl #48
   1e9d8:	a90b660d 	stp	x13, x25, [x16, #176]
   1e9dc:	aa090100 	orr	x0, x8, x9
   1e9e0:	a90e5e13 	stp	x19, x23, [x16, #224]
   1e9e4:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   1e9e8:	9102c3ff 	add	sp, sp, #0xb0
   1e9ec:	d65f03c0 	ret
   1e9f0:	a90383e1 	stp	x1, x0, [sp, #56]
   1e9f4:	aa1403e0 	mov	x0, x20
   1e9f8:	aa1503e1 	mov	x1, x21
   1e9fc:	a9008fe2 	stp	x2, x3, [sp, #8]
   1ea00:	528000a2 	mov	w2, #0x5                   	// #5
   1ea04:	a901f3eb 	stp	x11, x28, [sp, #24]
   1ea08:	aa0503fc 	mov	x28, x5
   1ea0c:	a90293e6 	stp	x6, x4, [sp, #40]
   1ea10:	97ff9920 	bl	4e90 <heap_alloc_miss>
   1ea14:	a9408fe2 	ldp	x2, x3, [sp, #8]
   1ea18:	aa1c03e5 	mov	x5, x28
   1ea1c:	a9421bfc 	ldp	x28, x6, [sp, #32]
   1ea20:	aa0003e8 	mov	x8, x0
   1ea24:	a94307e4 	ldp	x4, x1, [sp, #48]
   1ea28:	f9400feb 	ldr	x11, [sp, #24]
   1ea2c:	f94023e0 	ldr	x0, [sp, #64]
   1ea30:	17ffffb9 	b	1e914 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x1e4>
   1ea34:	a90383e1 	stp	x1, x0, [sp, #56]
   1ea38:	aa1403e0 	mov	x0, x20
   1ea3c:	aa1503e1 	mov	x1, x21
   1ea40:	528000a2 	mov	w2, #0x5                   	// #5
   1ea44:	a9021bfc 	stp	x28, x6, [sp, #32]
   1ea48:	aa0303f6 	mov	x22, x3
   1ea4c:	f9001be4 	str	x4, [sp, #48]
   1ea50:	aa0503fc 	mov	x28, x5
   1ea54:	97ff990f 	bl	4e90 <heap_alloc_miss>
   1ea58:	aa1c03e5 	mov	x5, x28
   1ea5c:	a9421bfc 	ldp	x28, x6, [sp, #32]
   1ea60:	a94307e4 	ldp	x4, x1, [sp, #48]
   1ea64:	aa0003e8 	mov	x8, x0
   1ea68:	f94023e0 	ldr	x0, [sp, #64]
   1ea6c:	aa1a03fe 	mov	x30, x26
   1ea70:	aa0c03e2 	mov	x2, x12
   1ea74:	aa0e03f2 	mov	x18, x14
   1ea78:	aa1603e3 	mov	x3, x22
   1ea7c:	17ffffc0 	b	1e97c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_0+0x24c>

