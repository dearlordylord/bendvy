   17370:	d103c3ff 	sub	sp, sp, #0xf0
   17374:	a90e7bfd 	stp	x29, x30, [sp, #224]
   17378:	910383fd 	add	x29, sp, #0xe0
   1737c:	aa0a03e8 	mov	x8, x10
   17380:	a93e1ba4 	stp	x4, x6, [x29, #-32]
   17384:	aa1b03e4 	mov	x4, x27
   17388:	f81d83a3 	stur	x3, [x29, #-40]
   1738c:	aa1c03e3 	mov	x3, x28
   17390:	f9400bbe 	ldr	x30, [x29, #16]
   17394:	a945cfb0 	ldp	x16, x19, [x29, #88]
   17398:	f81f03ac 	stur	x12, [x29, #-16]
   1739c:	a944c7b2 	ldp	x18, x17, [x29, #72]
   173a0:	a943e3bb 	ldp	x27, x24, [x29, #56]
   173a4:	a942f3a2 	ldp	x2, x28, [x29, #40]
   173a8:	a9419baa 	ldp	x10, x6, [x29, #24]
   173ac:	34000477 	cbz	w23, 17438 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_FALLBACK+0xc8>
   173b0:	aa0803ec 	mov	x12, x8
   173b4:	2a1303e8 	mov	w8, w19
   173b8:	52800613 	mov	w19, #0x30                  	// #48
   173bc:	a8814ec8 	stp	x8, x19, [x22], #16
   173c0:	2a1003e8 	mov	w8, w16
   173c4:	a90523b1 	stp	x17, x8, [x29, #80]
   173c8:	2a1c03e8 	mov	w8, w28
   173cc:	aa0303fc 	mov	x28, x3
   173d0:	a9036fa8 	stp	x8, x27, [x29, #48]
   173d4:	2a0203e8 	mov	w8, w2
   173d8:	aa0403fb 	mov	x27, x4
   173dc:	f90017a8 	str	x8, [x29, #40]
   173e0:	2a0603e8 	mov	w8, w6
   173e4:	2a1903f9 	mov	w25, w25
   173e8:	f90013a8 	str	x8, [x29, #32]
   173ec:	2a0a03e8 	mov	w8, w10
   173f0:	aa0c03ea 	mov	x10, x12
   173f4:	a97d93a3 	ldp	x3, x4, [x29, #-40]
   173f8:	f9000fa8 	str	x8, [x29, #24]
   173fc:	a97eb3a6 	ldp	x6, x12, [x29, #-24]
   17400:	2a1e03e8 	mov	w8, w30
   17404:	a9044bb8 	stp	x24, x18, [x29, #64]
   17408:	2a1a03fa 	mov	w26, w26
   1740c:	2a0503e5 	mov	w5, w5
   17410:	2a0703e7 	mov	w7, w7
   17414:	2a0b03eb 	mov	w11, w11
   17418:	2a0d03ed 	mov	w13, w13
   1741c:	2a0e03ee 	mov	w14, w14
   17420:	2a0903e9 	mov	w9, w9
   17424:	2a0f03ef 	mov	w15, w15
   17428:	f9000ba8 	str	x8, [x29, #16]
   1742c:	a94e7bfd 	ldp	x29, x30, [sp, #224]
   17430:	9103c3ff 	add	sp, sp, #0xf0
   17434:	17fffab2 	b	15efc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_CONVERTED>
   17438:	a900abe5 	stp	x5, x10, [sp, #8]
   1743c:	f94016b7 	ldr	x23, [x21, #40]
   17440:	a9398fa4 	stp	x4, x3, [x29, #-104]
   17444:	a9019be7 	stp	x7, x6, [sp, #24]
   17448:	a90283fe 	stp	x30, x0, [sp, #40]
   1744c:	a90387e2 	stp	x2, x1, [sp, #56]
   17450:	f90027eb 	str	x11, [sp, #72]
   17454:	a93b63bb 	stp	x27, x24, [x29, #-80]
   17458:	a97ee2db 	ldp	x27, x24, [x22, #-24]
   1745c:	a90537f2 	stp	x18, x13, [sp, #80]
   17460:	a90627f0 	stp	x16, x9, [sp, #96]
   17464:	f81d03af 	stur	x15, [x29, #-48]
   17468:	f9003be8 	str	x8, [sp, #112]
   1746c:	a93c47ae 	stp	x14, x17, [x29, #-64]
   17470:	f81a83bc 	stur	x28, [x29, #-88]
   17474:	b4000af7 	cbz	x23, 175d0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_FALLBACK+0x260>
   17478:	f8777a88 	ldr	x8, [x20, x23, lsl #3]
   1747c:	f94096a9 	ldr	x9, [x21, #296]
   17480:	f90016a8 	str	x8, [x21, #40]
   17484:	d1008128 	sub	x8, x9, #0x20
   17488:	f90096a8 	str	x8, [x21, #296]
   1748c:	8b170e9c 	add	x28, x20, x23, lsl #3
   17490:	52801fe1 	mov	w1, #0xff                  	// #255
   17494:	52801c02 	mov	w2, #0xe0                  	// #224
   17498:	91002380 	add	x0, x28, #0x8
   1749c:	97ffb195 	bl	3af0 <memset@plt>
   174a0:	2a1303e9 	mov	w9, w19
   174a4:	52800028 	mov	w8, #0x1                   	// #1
   174a8:	f9000389 	str	x9, [x28]
   174ac:	d2c60009 	mov	x9, #0x300000000000        	// #52776558133248
   174b0:	aa18810a 	orr	x10, x8, x24, lsl #32
   174b4:	f2e0a009 	movk	x9, #0x500, lsl #48
   174b8:	aa0902e9 	orr	x9, x23, x9
   174bc:	a90eab9b 	stp	x27, x10, [x28, #232]
   174c0:	a93ea2c9 	stp	x9, x8, [x22, #-24]
   174c4:	f94016a0 	ldr	x0, [x21, #40]
   174c8:	b4000900 	cbz	x0, 175e8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_FALLBACK+0x278>
   174cc:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   174d0:	f94096aa 	ldr	x10, [x21, #296]
   174d4:	f90016a8 	str	x8, [x21, #40]
   174d8:	d1008148 	sub	x8, x10, #0x20
   174dc:	f90096a8 	str	x8, [x21, #296]
   174e0:	8b000e88 	add	x8, x20, x0, lsl #3
   174e4:	d2c0002a 	mov	x10, #0x100000000           	// #4294967296
   174e8:	f85f03ab 	ldur	x11, [x29, #-16]
   174ec:	a97bbbaf 	ldp	x15, x14, [x29, #-72]
   174f0:	a90e2909 	stp	x9, x10, [x8, #224]
   174f4:	2a1903e9 	mov	w9, w25
   174f8:	2a1a03ea 	mov	w10, w26
   174fc:	a9002909 	stp	x9, x10, [x8]
   17500:	f9401bea 	ldr	x10, [sp, #48]
   17504:	f94023e9 	ldr	x9, [sp, #64]
   17508:	a97cb3ad 	ldp	x13, x12, [x29, #-56]
   1750c:	a902250a 	stp	x10, x9, [x8, #32]
   17510:	a97da7aa 	ldp	x10, x9, [x29, #-40]
   17514:	a97ac3b1 	ldp	x17, x16, [x29, #-88]
   17518:	a979cbb3 	ldp	x19, x18, [x29, #-104]
   1751c:	a903250a 	stp	x10, x9, [x8, #48]
   17520:	f94007e9 	ldr	x9, [sp, #8]
   17524:	f85e83aa 	ldur	x10, [x29, #-24]
   17528:	2a0903e9 	mov	w9, w9
   1752c:	a9014913 	stp	x19, x18, [x8, #16]
   17530:	f9002109 	str	x9, [x8, #64]
   17534:	f9400fe9 	ldr	x9, [sp, #24]
   17538:	2a0903e9 	mov	w9, w9
   1753c:	a904a50a 	stp	x10, x9, [x8, #72]
   17540:	f94027e9 	ldr	x9, [sp, #72]
   17544:	f9403bea 	ldr	x10, [sp, #112]
   17548:	2a0903e9 	mov	w9, w9
   1754c:	a905a50a 	stp	x10, x9, [x8, #88]
   17550:	f9402fe9 	ldr	x9, [sp, #88]
   17554:	2a0e03ea 	mov	w10, w14
   17558:	f9003d0a 	str	x10, [x8, #120]
   1755c:	2a0c03ea 	mov	w10, w12
   17560:	2a0903e9 	mov	w9, w9
   17564:	a906a50b 	stp	x11, x9, [x8, #104]
   17568:	f94037e9 	ldr	x9, [sp, #104]
   1756c:	2a0903e9 	mov	w9, w9
   17570:	a9082909 	stp	x9, x10, [x8, #128]
   17574:	f94017e9 	ldr	x9, [sp, #40]
   17578:	f9400bea 	ldr	x10, [sp, #16]
   1757c:	2a0903e9 	mov	w9, w9
   17580:	2a0a03ea 	mov	w10, w10
   17584:	a9092909 	stp	x9, x10, [x8, #144]
   17588:	f94013e9 	ldr	x9, [sp, #32]
   1758c:	f9401fea 	ldr	x10, [sp, #56]
   17590:	2a0903e9 	mov	w9, w9
   17594:	2a0a03ea 	mov	w10, w10
   17598:	a90a2909 	stp	x9, x10, [x8, #160]
   1759c:	2a1103e9 	mov	w9, w17
   175a0:	f94033ea 	ldr	x10, [sp, #96]
   175a4:	a90b4109 	stp	x9, x16, [x8, #176]
   175a8:	f9402be9 	ldr	x9, [sp, #80]
   175ac:	2a0a03ea 	mov	w10, w10
   175b0:	a90c250f 	stp	x15, x9, [x8, #192]
   175b4:	d2c4a009 	mov	x9, #0x250000000000        	// #40681930227712
   175b8:	f2e0a009 	movk	x9, #0x500, lsl #48
   175bc:	aa090000 	orr	x0, x0, x9
   175c0:	a90d290d 	stp	x13, x10, [x8, #208]
   175c4:	a94e7bfd 	ldp	x29, x30, [sp, #224]
   175c8:	9103c3ff 	add	sp, sp, #0xf0
   175cc:	d65f03c0 	ret
   175d0:	aa1403e0 	mov	x0, x20
   175d4:	aa1503e1 	mov	x1, x21
   175d8:	528000a2 	mov	w2, #0x5                   	// #5
   175dc:	97ffb564 	bl	4b6c <heap_alloc_miss>
   175e0:	aa0003f7 	mov	x23, x0
   175e4:	17ffffaa 	b	1748c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_FALLBACK+0x11c>
   175e8:	aa1403e0 	mov	x0, x20
   175ec:	aa1503e1 	mov	x1, x21
   175f0:	528000a2 	mov	w2, #0x5                   	// #5
   175f4:	97ffb55e 	bl	4b6c <heap_alloc_miss>
   175f8:	17ffffba 	b	174e0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_FALLBACK+0x170>

