   1be08:	d10243ff 	sub	sp, sp, #0x90
   1be0c:	a9087bfd 	stp	x29, x30, [sp, #128]
   1be10:	910203fd 	add	x29, sp, #0x80
   1be14:	f9402fa8 	ldr	x8, [x29, #88]
   1be18:	a93e3fac 	stp	x12, x15, [x29, #-32]
   1be1c:	aa1603f0 	mov	x16, x22
   1be20:	f81d83aa 	stur	x10, [x29, #-40]
   1be24:	a943cbb1 	ldp	x17, x18, [x29, #56]
   1be28:	f81f03a8 	stur	x8, [x29, #-16]
   1be2c:	f9400bb3 	ldr	x19, [x29, #16]
   1be30:	a944a3ac 	ldp	x12, x8, [x29, #72]
   1be34:	a942fba2 	ldp	x2, x30, [x29, #40]
   1be38:	a941abb8 	ldp	x24, x10, [x29, #24]
   1be3c:	b85f8ecf 	ldr	w15, [x22, #-8]!
   1be40:	340003b7 	cbz	w23, 1beb4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K217+0xac>
   1be44:	a904a3ac 	stp	x12, x8, [x29, #72]
   1be48:	f85f03a8 	ldur	x8, [x29, #-16]
   1be4c:	2a0a03f0 	mov	w16, w10
   1be50:	f90033af 	str	x15, [x29, #96]
   1be54:	2a1e03ef 	mov	w15, w30
   1be58:	f85d83aa 	ldur	x10, [x29, #-40]
   1be5c:	2a0803e8 	mov	w8, w8
   1be60:	2a1903f9 	mov	w25, w25
   1be64:	2a1a03fa 	mov	w26, w26
   1be68:	f9002fa8 	str	x8, [x29, #88]
   1be6c:	2a0203e8 	mov	w8, w2
   1be70:	2a0503e5 	mov	w5, w5
   1be74:	a902bfa8 	stp	x8, x15, [x29, #40]
   1be78:	a97e23ac 	ldp	x12, x8, [x29, #-32]
   1be7c:	2a0703e7 	mov	w7, w7
   1be80:	a903cbb1 	stp	x17, x18, [x29, #56]
   1be84:	2a0b03eb 	mov	w11, w11
   1be88:	2a0d03ed 	mov	w13, w13
   1be8c:	2a0e03ee 	mov	w14, w14
   1be90:	2a0903e9 	mov	w9, w9
   1be94:	2a0803ef 	mov	w15, w8
   1be98:	2a1803e8 	mov	w8, w24
   1be9c:	a901c3a8 	stp	x8, x16, [x29, #24]
   1bea0:	2a1303f0 	mov	w16, w19
   1bea4:	f9000bb0 	str	x16, [x29, #16]
   1bea8:	a9487bfd 	ldp	x29, x30, [sp, #128]
   1beac:	910243ff 	add	sp, sp, #0x90
   1beb0:	17fff1ad 	b	18564 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_FALLBACK>
   1beb4:	aa0203f6 	mov	x22, x2
   1beb8:	a97e5e02 	ldp	x2, x23, [x16, #-32]
   1bebc:	a90333fe 	stp	x30, x12, [sp, #48]
   1bec0:	f81c83b2 	stur	x18, [x29, #-56]
   1bec4:	f90023f1 	str	x17, [sp, #64]
   1bec8:	f81d03a8 	stur	x8, [x29, #-48]
   1becc:	f94016a8 	ldr	x8, [x21, #40]
   1bed0:	b40006a8 	cbz	x8, 1bfa4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K217+0x19c>
   1bed4:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   1bed8:	f94096b1 	ldr	x17, [x21, #296]
   1bedc:	f90016b0 	str	x16, [x21, #40]
   1bee0:	d1008230 	sub	x16, x17, #0x20
   1bee4:	f90096b0 	str	x16, [x21, #296]
   1bee8:	8b080e90 	add	x16, x20, x8, lsl #3
   1beec:	2a0b03eb 	mov	w11, w11
   1bef0:	d3607ef1 	lsl	x17, x23, #32
   1bef4:	2a1a03f2 	mov	w18, w26
   1bef8:	f900320b 	str	x11, [x16, #96]
   1befc:	a97dafac 	ldp	x12, x11, [x29, #-40]
   1bf00:	f9007a11 	str	x17, [x16, #240]
   1bf04:	2a1903f1 	mov	w17, w25
   1bf08:	f900360b 	str	x11, [x16, #104]
   1bf0c:	2a0d03eb 	mov	w11, w13
   1bf10:	2a0e03ed 	mov	w13, w14
   1bf14:	a907360b 	stp	x11, x13, [x16, #112]
   1bf18:	2a0903eb 	mov	w11, w9
   1bf1c:	f85e83a9 	ldur	x9, [x29, #-24]
   1bf20:	a9004a11 	stp	x17, x18, [x16]
   1bf24:	2a0503f1 	mov	w17, w5
   1bf28:	a9041a11 	stp	x17, x6, [x16, #64]
   1bf2c:	2a0703f1 	mov	w17, w7
   1bf30:	2a0903ed 	mov	w13, w9
   1bf34:	a9053211 	stp	x17, x12, [x16, #80]
   1bf38:	2a1803ec 	mov	w12, w24
   1bf3c:	f9401be9 	ldr	x9, [sp, #48]
   1bf40:	a908360b 	stp	x11, x13, [x16, #128]
   1bf44:	2a1303eb 	mov	w11, w19
   1bf48:	a909320b 	stp	x11, x12, [x16, #144]
   1bf4c:	2a0a03eb 	mov	w11, w10
   1bf50:	2a1603ea 	mov	w10, w22
   1bf54:	a90a2a0b 	stp	x11, x10, [x16, #160]
   1bf58:	2a0903ea 	mov	w10, w9
   1bf5c:	a943afe9 	ldp	x9, x11, [sp, #56]
   1bf60:	a901721b 	stp	x27, x28, [x16, #16]
   1bf64:	a90b2e0a 	stp	x10, x11, [x16, #176]
   1bf68:	f85c83aa 	ldur	x10, [x29, #-56]
   1bf6c:	a9020600 	stp	x0, x1, [x16, #32]
   1bf70:	a90c260a 	stp	x10, x9, [x16, #192]
   1bf74:	f85f03a9 	ldur	x9, [x29, #-16]
   1bf78:	a9031203 	stp	x3, x4, [x16, #48]
   1bf7c:	2a0903ea 	mov	w10, w9
   1bf80:	f85d03a9 	ldur	x9, [x29, #-48]
   1bf84:	a90d2a09 	stp	x9, x10, [x16, #208]
   1bf88:	d2c5e00a 	mov	x10, #0x2f0000000000        	// #51677046505472
   1bf8c:	f2e0a00a 	movk	x10, #0x500, lsl #48
   1bf90:	aa0a0100 	orr	x0, x8, x10
   1bf94:	a90e0a0f 	stp	x15, x2, [x16, #224]
   1bf98:	a9487bfd 	ldp	x29, x30, [sp, #128]
   1bf9c:	910243ff 	add	sp, sp, #0x90
   1bfa0:	d65f03c0 	ret
   1bfa4:	a90203e1 	stp	x1, x0, [sp, #32]
   1bfa8:	aa1403e0 	mov	x0, x20
   1bfac:	aa1503e1 	mov	x1, x21
   1bfb0:	aa0203ec 	mov	x12, x2
   1bfb4:	528000a2 	mov	w2, #0x5                   	// #5
   1bfb8:	a9001be7 	stp	x7, x6, [sp]
   1bfbc:	aa0403f5 	mov	x21, x4
   1bfc0:	a9010fe5 	stp	x5, x3, [sp, #16]
   1bfc4:	97ffa3b3 	bl	4e90 <heap_alloc_miss>
   1bfc8:	a9410fe5 	ldp	x5, x3, [sp, #16]
   1bfcc:	aa0003e8 	mov	x8, x0
   1bfd0:	a9401be7 	ldp	x7, x6, [sp]
   1bfd4:	aa0c03e2 	mov	x2, x12
   1bfd8:	a94203e1 	ldp	x1, x0, [sp, #32]
   1bfdc:	aa1503e4 	mov	x4, x21
   1bfe0:	17ffffc2 	b	1bee8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K217+0xe0>

