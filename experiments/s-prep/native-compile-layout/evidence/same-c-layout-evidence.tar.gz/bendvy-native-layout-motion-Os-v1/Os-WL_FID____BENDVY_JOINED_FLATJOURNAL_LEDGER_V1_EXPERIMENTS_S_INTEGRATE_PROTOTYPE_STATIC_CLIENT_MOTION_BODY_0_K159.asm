   16cb0:	d10403ff 	sub	sp, sp, #0x100
   16cb4:	a90f7bfd 	stp	x29, x30, [sp, #240]
   16cb8:	9103c3fd 	add	x29, sp, #0xf0
   16cbc:	a943c3b1 	ldp	x17, x16, [x29, #56]
   16cc0:	f9400bb3 	ldr	x19, [x29, #16]
   16cc4:	f81e03b9 	stur	x25, [x29, #-32]
   16cc8:	f85e02d8 	ldur	x24, [x22, #-32]
   16ccc:	3cde82c0 	ldur	q0, [x22, #-24]
   16cd0:	f81e83b3 	stur	x19, [x29, #-24]
   16cd4:	f85f82d3 	ldur	x19, [x22, #-8]
   16cd8:	f81f03b0 	stur	x16, [x29, #-16]
   16cdc:	a944a3b2 	ldp	x18, x8, [x29, #72]
   16ce0:	b81d83b7 	stur	w23, [x29, #-40]
   16ce4:	a942e7b0 	ldp	x16, x25, [x29, #40]
   16ce8:	a9418bbe 	ldp	x30, x2, [x29, #24]
   16cec:	34000537 	cbz	w23, 16d90 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K159+0xe0>
   16cf0:	6e004000 	ext	v0.16b, v0.16b, v0.16b, #8
   16cf4:	6f00e5e2 	movi	v2.2d, #0xffffffff
   16cf8:	b85d83b7 	ldur	w23, [x29, #-40]
   16cfc:	2a1a03fa 	mov	w26, w26
   16d00:	2a0503e5 	mov	w5, w5
   16d04:	2a0703e7 	mov	w7, w7
   16d08:	2a0b03eb 	mov	w11, w11
   16d0c:	2a0d03ed 	mov	w13, w13
   16d10:	2a0e03ee 	mov	w14, w14
   16d14:	2a0903e9 	mov	w9, w9
   16d18:	2a0f03ef 	mov	w15, w15
   16d1c:	4ea01c01 	mov	v1.16b, v0.16b
   16d20:	4e181e60 	mov	v0.d[1], x19
   16d24:	aa0803f3 	mov	x19, x8
   16d28:	528005a8 	mov	w8, #0x2d                  	// #45
   16d2c:	f90002c8 	str	x8, [x22]
   16d30:	f85f03a8 	ldur	x8, [x29, #-16]
   16d34:	4e081f01 	mov	v1.d[0], x24
   16d38:	4e221c00 	and	v0.16b, v0.16b, v2.16b
   16d3c:	4e221c21 	and	v1.16b, v1.16b, v2.16b
   16d40:	ad3f02c1 	stp	q1, q0, [x22, #-32]
   16d44:	910022d6 	add	x22, x22, #0x8
   16d48:	a903a3b1 	stp	x17, x8, [x29, #56]
   16d4c:	2a1903e8 	mov	w8, w25
   16d50:	f9001ba8 	str	x8, [x29, #48]
   16d54:	2a1003e8 	mov	w8, w16
   16d58:	f90017a8 	str	x8, [x29, #40]
   16d5c:	2a0203e8 	mov	w8, w2
   16d60:	f90013a8 	str	x8, [x29, #32]
   16d64:	2a1e03e8 	mov	w8, w30
   16d68:	f9000fa8 	str	x8, [x29, #24]
   16d6c:	f85e03a8 	ldur	x8, [x29, #-32]
   16d70:	a904cfb2 	stp	x18, x19, [x29, #72]
   16d74:	2a0803f9 	mov	w25, w8
   16d78:	f85e83a8 	ldur	x8, [x29, #-24]
   16d7c:	2a0803e8 	mov	w8, w8
   16d80:	f9000ba8 	str	x8, [x29, #16]
   16d84:	a94f7bfd 	ldp	x29, x30, [sp, #240]
   16d88:	910403ff 	add	sp, sp, #0x100
   16d8c:	17ffdf6f 	b	eb48 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_TRANSACTION_DISPATCH_ADAPTERS_MOTION_READ_LEDGER>
   16d90:	3d8003e0 	str	q0, [sp]
   16d94:	f9401ab7 	ldr	x23, [x21, #48]
   16d98:	f81a03ba 	stur	x26, [x29, #-96]
   16d9c:	f9000be5 	str	x5, [sp, #16]
   16da0:	a93af3bb 	stp	x27, x28, [x29, #-88]
   16da4:	a97cf2da 	ldp	x26, x28, [x22, #-56]
   16da8:	a9019ffe 	stp	x30, x7, [sp, #24]
   16dac:	a9028be0 	stp	x0, x2, [sp, #40]
   16db0:	a903afe1 	stp	x1, x11, [sp, #56]
   16db4:	a90493e3 	stp	x3, x4, [sp, #72]
   16db8:	f81d83b9 	stur	x25, [x29, #-40]
   16dbc:	a905c7ed 	stp	x13, x17, [sp, #88]
   16dc0:	f9003be6 	str	x6, [sp, #112]
   16dc4:	a9392ba9 	stp	x9, x10, [x29, #-112]
   16dc8:	a93cb3af 	stp	x15, x12, [x29, #-56]
   16dcc:	f9003fe8 	str	x8, [sp, #120]
   16dd0:	f81c03ae 	stur	x14, [x29, #-64]
   16dd4:	f90037f2 	str	x18, [sp, #104]
   16dd8:	f81b83b0 	stur	x16, [x29, #-72]
   16ddc:	b4000c17 	cbz	x23, 16f5c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K159+0x2ac>
   16de0:	f8777a88 	ldr	x8, [x20, x23, lsl #3]
   16de4:	f9409aa9 	ldr	x9, [x21, #304]
   16de8:	f9001aa8 	str	x8, [x21, #48]
   16dec:	d1010128 	sub	x8, x9, #0x40
   16df0:	f9009aa8 	str	x8, [x21, #304]
   16df4:	8b170e9b 	add	x27, x20, x23, lsl #3
   16df8:	52801fe1 	mov	w1, #0xff                  	// #255
   16dfc:	52802102 	mov	w2, #0x108                 	// #264
   16e00:	91008360 	add	x0, x27, #0x20
   16e04:	97ffb33b 	bl	3af0 <memset@plt>
   16e08:	6f00e5e0 	movi	v0.2d, #0xffffffff
   16e0c:	2a1803e8 	mov	w8, w24
   16e10:	3dc003e1 	ldr	q1, [sp]
   16e14:	f9000368 	str	x8, [x27]
   16e18:	52800028 	mov	w8, #0x1                   	// #1
   16e1c:	2a1303e9 	mov	w9, w19
   16e20:	aa1c8108 	orr	x8, x8, x28, lsl #32
   16e24:	f9000f69 	str	x9, [x27, #24]
   16e28:	d2c5a009 	mov	x9, #0x2d0000000000        	// #49478023249920
   16e2c:	f2e0a009 	movk	x9, #0x500, lsl #48
   16e30:	4e201c20 	and	v0.16b, v1.16b, v0.16b
   16e34:	a912a37a 	stp	x26, x8, [x27, #296]
   16e38:	aa0902e9 	orr	x9, x23, x9
   16e3c:	52800088 	mov	w8, #0x4                   	// #4
   16e40:	3c808360 	stur	q0, [x27, #8]
   16e44:	a93ca2c9 	stp	x9, x8, [x22, #-56]
   16e48:	f85e03b6 	ldur	x22, [x29, #-32]
   16e4c:	f94016a0 	ldr	x0, [x21, #40]
   16e50:	b4000920 	cbz	x0, 16f74 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K159+0x2c4>
   16e54:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   16e58:	f94096aa 	ldr	x10, [x21, #296]
   16e5c:	f90016a8 	str	x8, [x21, #40]
   16e60:	d1008148 	sub	x8, x10, #0x20
   16e64:	f90096a8 	str	x8, [x21, #296]
   16e68:	f85a03ab 	ldur	x11, [x29, #-96]
   16e6c:	8b000e88 	add	x8, x20, x0, lsl #3
   16e70:	d2c0008a 	mov	x10, #0x400000000           	// #17179869184
   16e74:	a97cb3ad 	ldp	x13, x12, [x29, #-56]
   16e78:	f85e83b1 	ldur	x17, [x29, #-24]
   16e7c:	f900710a 	str	x10, [x8, #224]
   16e80:	2a1603ea 	mov	w10, w22
   16e84:	2a0b03eb 	mov	w11, w11
   16e88:	a9002d0a 	stp	x10, x11, [x8]
   16e8c:	f94017eb 	ldr	x11, [sp, #40]
   16e90:	f9401fea 	ldr	x10, [sp, #56]
   16e94:	a97bbbb0 	ldp	x16, x14, [x29, #-72]
   16e98:	f85d83af 	ldur	x15, [x29, #-40]
   16e9c:	a902290b 	stp	x11, x10, [x8, #32]
   16ea0:	a944abeb 	ldp	x11, x10, [sp, #72]
   16ea4:	f9006d09 	str	x9, [x8, #216]
   16ea8:	f9403fe9 	ldr	x9, [sp, #120]
   16eac:	a97acbb3 	ldp	x19, x18, [x29, #-88]
   16eb0:	a903290b 	stp	x11, x10, [x8, #48]
   16eb4:	f9400bea 	ldr	x10, [sp, #16]
   16eb8:	f9403beb 	ldr	x11, [sp, #112]
   16ebc:	2a0a03ea 	mov	w10, w10
   16ec0:	a9014913 	stp	x19, x18, [x8, #16]
   16ec4:	f900210a 	str	x10, [x8, #64]
   16ec8:	f94013ea 	ldr	x10, [sp, #32]
   16ecc:	2a0a03ea 	mov	w10, w10
   16ed0:	a904a90b 	stp	x11, x10, [x8, #72]
   16ed4:	f94023ea 	ldr	x10, [sp, #64]
   16ed8:	f85983ab 	ldur	x11, [x29, #-104]
   16edc:	2a0a03ea 	mov	w10, w10
   16ee0:	a905a90b 	stp	x11, x10, [x8, #88]
   16ee4:	f9402fea 	ldr	x10, [sp, #88]
   16ee8:	2a0e03eb 	mov	w11, w14
   16eec:	f9003d0b 	str	x11, [x8, #120]
   16ef0:	2a0d03eb 	mov	w11, w13
   16ef4:	2a0a03ea 	mov	w10, w10
   16ef8:	a906a90c 	stp	x12, x10, [x8, #104]
   16efc:	f85903aa 	ldur	x10, [x29, #-112]
   16f00:	2a0a03ea 	mov	w10, w10
   16f04:	a9082d0a 	stp	x10, x11, [x8, #128]
   16f08:	f9400feb 	ldr	x11, [sp, #24]
   16f0c:	2a1103ea 	mov	w10, w17
   16f10:	2a0b03eb 	mov	w11, w11
   16f14:	a9092d0a 	stp	x10, x11, [x8, #144]
   16f18:	f9401bea 	ldr	x10, [sp, #48]
   16f1c:	2a1003eb 	mov	w11, w16
   16f20:	2a0a03ea 	mov	w10, w10
   16f24:	a90a2d0a 	stp	x10, x11, [x8, #160]
   16f28:	2a0f03ea 	mov	w10, w15
   16f2c:	f94033eb 	ldr	x11, [sp, #96]
   16f30:	f900590a 	str	x10, [x8, #176]
   16f34:	f85f03aa 	ldur	x10, [x29, #-16]
   16f38:	a90ba90b 	stp	x11, x10, [x8, #184]
   16f3c:	f94037eb 	ldr	x11, [sp, #104]
   16f40:	d2c2800a 	mov	x10, #0x140000000000        	// #21990232555520
   16f44:	f2e0a00a 	movk	x10, #0x500, lsl #48
   16f48:	aa0a0000 	orr	x0, x0, x10
   16f4c:	a90ca50b 	stp	x11, x9, [x8, #200]
   16f50:	a94f7bfd 	ldp	x29, x30, [sp, #240]
   16f54:	910403ff 	add	sp, sp, #0x100
   16f58:	d65f03c0 	ret
   16f5c:	aa1403e0 	mov	x0, x20
   16f60:	aa1503e1 	mov	x1, x21
   16f64:	528000c2 	mov	w2, #0x6                   	// #6
   16f68:	97ffb701 	bl	4b6c <heap_alloc_miss>
   16f6c:	aa0003f7 	mov	x23, x0
   16f70:	17ffffa1 	b	16df4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K159+0x144>
   16f74:	aa1403e0 	mov	x0, x20
   16f78:	aa1503e1 	mov	x1, x21
   16f7c:	528000a2 	mov	w2, #0x5                   	// #5
   16f80:	97ffb6fb 	bl	4b6c <heap_alloc_miss>
   16f84:	17ffffb9 	b	16e68 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0_K159+0x1b8>

