   1bb74:	d102c3ff 	sub	sp, sp, #0xb0
   1bb78:	a90a7bfd 	stp	x29, x30, [sp, #160]
   1bb7c:	910283fd 	add	x29, sp, #0xa0
   1bb80:	a93eb3af 	stp	x15, x12, [x29, #-24]
   1bb84:	a943c7b0 	ldp	x16, x17, [x29, #56]
   1bb88:	f81e03aa 	stur	x10, [x29, #-32]
   1bb8c:	aa0603ea 	mov	x10, x6
   1bb90:	f9400ba2 	ldr	x2, [x29, #16]
   1bb94:	a9449bb2 	ldp	x18, x6, [x29, #72]
   1bb98:	b85f82cc 	ldur	w12, [x22, #-8]
   1bb9c:	a942fbb3 	ldp	x19, x30, [x29, #40]
   1bba0:	a941bfb8 	ldp	x24, x15, [x29, #24]
   1bba4:	340003b7 	cbz	w23, 1bc18 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K216+0xa4>
   1bba8:	52800808 	mov	w8, #0x40                  	// #64
   1bbac:	2a1903f9 	mov	w25, w25
   1bbb0:	2a1a03fa 	mov	w26, w26
   1bbb4:	a93fa2cc 	stp	x12, x8, [x22, #-8]
   1bbb8:	2a1e03e8 	mov	w8, w30
   1bbbc:	2a1303ec 	mov	w12, w19
   1bbc0:	a902a3ac 	stp	x12, x8, [x29, #40]
   1bbc4:	2a0f03e8 	mov	w8, w15
   1bbc8:	a9049bb2 	stp	x18, x6, [x29, #72]
   1bbcc:	aa0a03e6 	mov	x6, x10
   1bbd0:	a97e33aa 	ldp	x10, x12, [x29, #-32]
   1bbd4:	2a0c03ef 	mov	w15, w12
   1bbd8:	2a1803ec 	mov	w12, w24
   1bbdc:	2a0503e5 	mov	w5, w5
   1bbe0:	a901a3ac 	stp	x12, x8, [x29, #24]
   1bbe4:	2a0203e8 	mov	w8, w2
   1bbe8:	f85f03ac 	ldur	x12, [x29, #-16]
   1bbec:	2a0703e7 	mov	w7, w7
   1bbf0:	2a0b03eb 	mov	w11, w11
   1bbf4:	a903c7b0 	stp	x16, x17, [x29, #56]
   1bbf8:	2a0d03ed 	mov	w13, w13
   1bbfc:	2a0e03ee 	mov	w14, w14
   1bc00:	2a0903e9 	mov	w9, w9
   1bc04:	910022d6 	add	x22, x22, #0x8
   1bc08:	f9000ba8 	str	x8, [x29, #16]
   1bc0c:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   1bc10:	9102c3ff 	add	sp, sp, #0xb0
   1bc14:	17ffef20 	b	17894 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0>
   1bc18:	a93c4fa2 	stp	x2, x19, [x29, #-64]
   1bc1c:	f94016a8 	ldr	x8, [x21, #40]
   1bc20:	a93d7baf 	stp	x15, x30, [x29, #-48]
   1bc24:	a90447f2 	stp	x18, x17, [sp, #64]
   1bc28:	f9002bf0 	str	x16, [sp, #80]
   1bc2c:	f81b83a9 	stur	x9, [x29, #-72]
   1bc30:	a97e26d7 	ldp	x23, x9, [x22, #-32]
   1bc34:	b4000a88 	cbz	x8, 1bd84 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K216+0x210>
   1bc38:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   1bc3c:	f94096b1 	ldr	x17, [x21, #296]
   1bc40:	f90016b0 	str	x16, [x21, #40]
   1bc44:	d1008230 	sub	x16, x17, #0x20
   1bc48:	f90096b0 	str	x16, [x21, #296]
   1bc4c:	52800031 	mov	w17, #0x1                   	// #1
   1bc50:	8b080e90 	add	x16, x20, x8, lsl #3
   1bc54:	6f07e7e0 	movi	v0.2d, #0xffffffffffffffff
   1bc58:	aa098229 	orr	x9, x17, x9, lsl #32
   1bc5c:	f900020c 	str	x12, [x16]
   1bc60:	a90ea617 	stp	x23, x9, [x16, #232]
   1bc64:	d2c80009 	mov	x9, #0x400000000000        	// #70368744177664
   1bc68:	f2e0a009 	movk	x9, #0x500, lsl #48
   1bc6c:	3c8d8200 	stur	q0, [x16, #216]
   1bc70:	aa090117 	orr	x23, x8, x9
   1bc74:	3c8c8200 	stur	q0, [x16, #200]
   1bc78:	3c8b8200 	stur	q0, [x16, #184]
   1bc7c:	3c8a8200 	stur	q0, [x16, #168]
   1bc80:	3c898200 	stur	q0, [x16, #152]
   1bc84:	3c888200 	stur	q0, [x16, #136]
   1bc88:	3c878200 	stur	q0, [x16, #120]
   1bc8c:	3c868200 	stur	q0, [x16, #104]
   1bc90:	3c858200 	stur	q0, [x16, #88]
   1bc94:	3c848200 	stur	q0, [x16, #72]
   1bc98:	3c838200 	stur	q0, [x16, #56]
   1bc9c:	3c828200 	stur	q0, [x16, #40]
   1bca0:	3c818200 	stur	q0, [x16, #24]
   1bca4:	3c808200 	stur	q0, [x16, #8]
   1bca8:	a93e46d7 	stp	x23, x17, [x22, #-32]
   1bcac:	f94016a8 	ldr	x8, [x21, #40]
   1bcb0:	b40008a8 	cbz	x8, 1bdc4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K216+0x250>
   1bcb4:	f8687a89 	ldr	x9, [x20, x8, lsl #3]
   1bcb8:	f94096ac 	ldr	x12, [x21, #296]
   1bcbc:	f90016a9 	str	x9, [x21, #40]
   1bcc0:	d1008189 	sub	x9, x12, #0x20
   1bcc4:	f90096a9 	str	x9, [x21, #296]
   1bcc8:	8b080e90 	add	x16, x20, x8, lsl #3
   1bccc:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
   1bcd0:	2a1a03ec 	mov	w12, w26
   1bcd4:	a97c4bb5 	ldp	x21, x18, [x29, #-64]
   1bcd8:	f9007209 	str	x9, [x16, #224]
   1bcdc:	2a1903e9 	mov	w9, w25
   1bce0:	a9003209 	stp	x9, x12, [x16]
   1bce4:	2a0503e9 	mov	w9, w5
   1bce8:	a9042a09 	stp	x9, x10, [x16, #64]
   1bcec:	2a0703e9 	mov	w9, w7
   1bcf0:	f9002a09 	str	x9, [x16, #80]
   1bcf4:	a97e2ba9 	ldp	x9, x10, [x29, #-32]
   1bcf8:	a97d47af 	ldp	x15, x17, [x29, #-48]
   1bcfc:	a901721b 	stp	x27, x28, [x16, #16]
   1bd00:	a9020600 	stp	x0, x1, [x16, #32]
   1bd04:	f9002e09 	str	x9, [x16, #88]
   1bd08:	2a0b03e9 	mov	w9, w11
   1bd0c:	2a0e03eb 	mov	w11, w14
   1bd10:	f9003209 	str	x9, [x16, #96]
   1bd14:	f85f03a9 	ldur	x9, [x29, #-16]
   1bd18:	a9031203 	stp	x3, x4, [x16, #48]
   1bd1c:	f9003609 	str	x9, [x16, #104]
   1bd20:	2a0d03e9 	mov	w9, w13
   1bd24:	a9072e09 	stp	x9, x11, [x16, #112]
   1bd28:	f85b83a9 	ldur	x9, [x29, #-72]
   1bd2c:	2a0a03eb 	mov	w11, w10
   1bd30:	2a1203ea 	mov	w10, w18
   1bd34:	2a0903e9 	mov	w9, w9
   1bd38:	a9082e09 	stp	x9, x11, [x16, #128]
   1bd3c:	2a1503e9 	mov	w9, w21
   1bd40:	2a1803eb 	mov	w11, w24
   1bd44:	a9092e09 	stp	x9, x11, [x16, #144]
   1bd48:	2a0f03e9 	mov	w9, w15
   1bd4c:	a90a2a09 	stp	x9, x10, [x16, #160]
   1bd50:	2a1103e9 	mov	w9, w17
   1bd54:	f9005a09 	str	x9, [x16, #176]
   1bd58:	a944abe9 	ldp	x9, x10, [sp, #72]
   1bd5c:	a90ba60a 	stp	x10, x9, [x16, #184]
   1bd60:	f94023e9 	ldr	x9, [sp, #64]
   1bd64:	a90c9a09 	stp	x9, x6, [x16, #200]
   1bd68:	d2c54009 	mov	x9, #0x2a0000000000        	// #46179488366592
   1bd6c:	f2e0a009 	movk	x9, #0x500, lsl #48
   1bd70:	aa090100 	orr	x0, x8, x9
   1bd74:	f9006e17 	str	x23, [x16, #216]
   1bd78:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   1bd7c:	9102c3ff 	add	sp, sp, #0xb0
   1bd80:	d65f03c0 	ret
   1bd84:	a90303e1 	stp	x1, x0, [sp, #48]
   1bd88:	aa1403e0 	mov	x0, x20
   1bd8c:	aa1503e1 	mov	x1, x21
   1bd90:	528000a2 	mov	w2, #0x5                   	// #5
   1bd94:	a9009be7 	stp	x7, x6, [sp, #8]
   1bd98:	a9022be3 	stp	x3, x10, [sp, #32]
   1bd9c:	f90003e4 	str	x4, [sp]
   1bda0:	f9000fe5 	str	x5, [sp, #24]
   1bda4:	97ffa43b 	bl	4e90 <heap_alloc_miss>
   1bda8:	a94117e6 	ldp	x6, x5, [sp, #16]
   1bdac:	aa0003e8 	mov	x8, x0
   1bdb0:	a9401fe4 	ldp	x4, x7, [sp]
   1bdb4:	f94013e3 	ldr	x3, [sp, #32]
   1bdb8:	a94287ea 	ldp	x10, x1, [sp, #40]
   1bdbc:	f9401fe0 	ldr	x0, [sp, #56]
   1bdc0:	17ffffa3 	b	1bc4c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K216+0xd8>
   1bdc4:	a90303e1 	stp	x1, x0, [sp, #48]
   1bdc8:	aa1403e0 	mov	x0, x20
   1bdcc:	aa1503e1 	mov	x1, x21
   1bdd0:	528000a2 	mov	w2, #0x5                   	// #5
   1bdd4:	a90117e6 	stp	x6, x5, [sp, #16]
   1bdd8:	aa0403e9 	mov	x9, x4
   1bddc:	a9022be3 	stp	x3, x10, [sp, #32]
   1bde0:	aa0703f5 	mov	x21, x7
   1bde4:	97ffa42b 	bl	4e90 <heap_alloc_miss>
   1bde8:	a94117e6 	ldp	x6, x5, [sp, #16]
   1bdec:	aa0003e8 	mov	x8, x0
   1bdf0:	a94287ea 	ldp	x10, x1, [sp, #40]
   1bdf4:	aa1503e7 	mov	x7, x21
   1bdf8:	f94013e3 	ldr	x3, [sp, #32]
   1bdfc:	f9401fe0 	ldr	x0, [sp, #56]
   1be00:	aa0903e4 	mov	x4, x9
   1be04:	17ffffb1 	b	1bcc8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K216+0x154>

