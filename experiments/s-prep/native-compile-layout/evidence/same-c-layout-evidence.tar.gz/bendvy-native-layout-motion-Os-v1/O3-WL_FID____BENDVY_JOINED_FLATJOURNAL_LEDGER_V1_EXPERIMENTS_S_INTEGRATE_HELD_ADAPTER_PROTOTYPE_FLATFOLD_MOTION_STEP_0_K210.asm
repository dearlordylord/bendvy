   1ae24:	d102c3ff 	sub	sp, sp, #0xb0
   1ae28:	a90a7bfd 	stp	x29, x30, [sp, #160]
   1ae2c:	910283fd 	add	x29, sp, #0xa0
   1ae30:	a93eb3af 	stp	x15, x12, [x29, #-24]
   1ae34:	a943c7b0 	ldp	x16, x17, [x29, #56]
   1ae38:	f81e03aa 	stur	x10, [x29, #-32]
   1ae3c:	aa0603ea 	mov	x10, x6
   1ae40:	f9400ba2 	ldr	x2, [x29, #16]
   1ae44:	a9449bb2 	ldp	x18, x6, [x29, #72]
   1ae48:	b85f82cc 	ldur	w12, [x22, #-8]
   1ae4c:	a942fbb3 	ldp	x19, x30, [x29, #40]
   1ae50:	a941bfb8 	ldp	x24, x15, [x29, #24]
   1ae54:	340003b7 	cbz	w23, 1aec8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K210+0xa4>
   1ae58:	52800748 	mov	w8, #0x3a                  	// #58
   1ae5c:	2a1903f9 	mov	w25, w25
   1ae60:	2a1a03fa 	mov	w26, w26
   1ae64:	a93fa2cc 	stp	x12, x8, [x22, #-8]
   1ae68:	2a1e03e8 	mov	w8, w30
   1ae6c:	2a1303ec 	mov	w12, w19
   1ae70:	a902a3ac 	stp	x12, x8, [x29, #40]
   1ae74:	2a0f03e8 	mov	w8, w15
   1ae78:	a9049bb2 	stp	x18, x6, [x29, #72]
   1ae7c:	aa0a03e6 	mov	x6, x10
   1ae80:	a97e33aa 	ldp	x10, x12, [x29, #-32]
   1ae84:	2a0c03ef 	mov	w15, w12
   1ae88:	2a1803ec 	mov	w12, w24
   1ae8c:	2a0503e5 	mov	w5, w5
   1ae90:	a901a3ac 	stp	x12, x8, [x29, #24]
   1ae94:	2a0203e8 	mov	w8, w2
   1ae98:	f85f03ac 	ldur	x12, [x29, #-16]
   1ae9c:	2a0703e7 	mov	w7, w7
   1aea0:	2a0b03eb 	mov	w11, w11
   1aea4:	a903c7b0 	stp	x16, x17, [x29, #56]
   1aea8:	2a0d03ed 	mov	w13, w13
   1aeac:	2a0e03ee 	mov	w14, w14
   1aeb0:	2a0903e9 	mov	w9, w9
   1aeb4:	910022d6 	add	x22, x22, #0x8
   1aeb8:	f9000ba8 	str	x8, [x29, #16]
   1aebc:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   1aec0:	9102c3ff 	add	sp, sp, #0xb0
   1aec4:	17fff274 	b	17894 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_MOTION_BODY_0>
   1aec8:	a93c4fa2 	stp	x2, x19, [x29, #-64]
   1aecc:	f94016a8 	ldr	x8, [x21, #40]
   1aed0:	a93d7baf 	stp	x15, x30, [x29, #-48]
   1aed4:	a90447f2 	stp	x18, x17, [sp, #64]
   1aed8:	f9002bf0 	str	x16, [sp, #80]
   1aedc:	f81b83a9 	stur	x9, [x29, #-72]
   1aee0:	a97e26d7 	ldp	x23, x9, [x22, #-32]
   1aee4:	b4000a88 	cbz	x8, 1b034 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K210+0x210>
   1aee8:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   1aeec:	f94096b1 	ldr	x17, [x21, #296]
   1aef0:	f90016b0 	str	x16, [x21, #40]
   1aef4:	d1008230 	sub	x16, x17, #0x20
   1aef8:	f90096b0 	str	x16, [x21, #296]
   1aefc:	52800031 	mov	w17, #0x1                   	// #1
   1af00:	8b080e90 	add	x16, x20, x8, lsl #3
   1af04:	6f07e7e0 	movi	v0.2d, #0xffffffffffffffff
   1af08:	aa098229 	orr	x9, x17, x9, lsl #32
   1af0c:	f900020c 	str	x12, [x16]
   1af10:	a90ea617 	stp	x23, x9, [x16, #232]
   1af14:	d2c74009 	mov	x9, #0x3a0000000000        	// #63771674411008
   1af18:	f2e0a009 	movk	x9, #0x500, lsl #48
   1af1c:	3c8d8200 	stur	q0, [x16, #216]
   1af20:	aa090117 	orr	x23, x8, x9
   1af24:	3c8c8200 	stur	q0, [x16, #200]
   1af28:	3c8b8200 	stur	q0, [x16, #184]
   1af2c:	3c8a8200 	stur	q0, [x16, #168]
   1af30:	3c898200 	stur	q0, [x16, #152]
   1af34:	3c888200 	stur	q0, [x16, #136]
   1af38:	3c878200 	stur	q0, [x16, #120]
   1af3c:	3c868200 	stur	q0, [x16, #104]
   1af40:	3c858200 	stur	q0, [x16, #88]
   1af44:	3c848200 	stur	q0, [x16, #72]
   1af48:	3c838200 	stur	q0, [x16, #56]
   1af4c:	3c828200 	stur	q0, [x16, #40]
   1af50:	3c818200 	stur	q0, [x16, #24]
   1af54:	3c808200 	stur	q0, [x16, #8]
   1af58:	a93e46d7 	stp	x23, x17, [x22, #-32]
   1af5c:	f94016a8 	ldr	x8, [x21, #40]
   1af60:	b40008a8 	cbz	x8, 1b074 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K210+0x250>
   1af64:	f8687a89 	ldr	x9, [x20, x8, lsl #3]
   1af68:	f94096ac 	ldr	x12, [x21, #296]
   1af6c:	f90016a9 	str	x9, [x21, #40]
   1af70:	d1008189 	sub	x9, x12, #0x20
   1af74:	f90096a9 	str	x9, [x21, #296]
   1af78:	8b080e90 	add	x16, x20, x8, lsl #3
   1af7c:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
   1af80:	2a1a03ec 	mov	w12, w26
   1af84:	a97c4bb5 	ldp	x21, x18, [x29, #-64]
   1af88:	f9007209 	str	x9, [x16, #224]
   1af8c:	2a1903e9 	mov	w9, w25
   1af90:	a9003209 	stp	x9, x12, [x16]
   1af94:	2a0503e9 	mov	w9, w5
   1af98:	a9042a09 	stp	x9, x10, [x16, #64]
   1af9c:	2a0703e9 	mov	w9, w7
   1afa0:	f9002a09 	str	x9, [x16, #80]
   1afa4:	a97e2ba9 	ldp	x9, x10, [x29, #-32]
   1afa8:	a97d47af 	ldp	x15, x17, [x29, #-48]
   1afac:	a901721b 	stp	x27, x28, [x16, #16]
   1afb0:	a9020600 	stp	x0, x1, [x16, #32]
   1afb4:	f9002e09 	str	x9, [x16, #88]
   1afb8:	2a0b03e9 	mov	w9, w11
   1afbc:	2a0e03eb 	mov	w11, w14
   1afc0:	f9003209 	str	x9, [x16, #96]
   1afc4:	f85f03a9 	ldur	x9, [x29, #-16]
   1afc8:	a9031203 	stp	x3, x4, [x16, #48]
   1afcc:	f9003609 	str	x9, [x16, #104]
   1afd0:	2a0d03e9 	mov	w9, w13
   1afd4:	a9072e09 	stp	x9, x11, [x16, #112]
   1afd8:	f85b83a9 	ldur	x9, [x29, #-72]
   1afdc:	2a0a03eb 	mov	w11, w10
   1afe0:	2a1203ea 	mov	w10, w18
   1afe4:	2a0903e9 	mov	w9, w9
   1afe8:	a9082e09 	stp	x9, x11, [x16, #128]
   1afec:	2a1503e9 	mov	w9, w21
   1aff0:	2a1803eb 	mov	w11, w24
   1aff4:	a9092e09 	stp	x9, x11, [x16, #144]
   1aff8:	2a0f03e9 	mov	w9, w15
   1affc:	a90a2a09 	stp	x9, x10, [x16, #160]
   1b000:	2a1103e9 	mov	w9, w17
   1b004:	f9005a09 	str	x9, [x16, #176]
   1b008:	a944abe9 	ldp	x9, x10, [sp, #72]
   1b00c:	a90ba60a 	stp	x10, x9, [x16, #184]
   1b010:	f94023e9 	ldr	x9, [sp, #64]
   1b014:	a90c9a09 	stp	x9, x6, [x16, #200]
   1b018:	d2c54009 	mov	x9, #0x2a0000000000        	// #46179488366592
   1b01c:	f2e0a009 	movk	x9, #0x500, lsl #48
   1b020:	aa090100 	orr	x0, x8, x9
   1b024:	f9006e17 	str	x23, [x16, #216]
   1b028:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   1b02c:	9102c3ff 	add	sp, sp, #0xb0
   1b030:	d65f03c0 	ret
   1b034:	a90303e1 	stp	x1, x0, [sp, #48]
   1b038:	aa1403e0 	mov	x0, x20
   1b03c:	aa1503e1 	mov	x1, x21
   1b040:	528000a2 	mov	w2, #0x5                   	// #5
   1b044:	a9009be7 	stp	x7, x6, [sp, #8]
   1b048:	a9022be3 	stp	x3, x10, [sp, #32]
   1b04c:	f90003e4 	str	x4, [sp]
   1b050:	f9000fe5 	str	x5, [sp, #24]
   1b054:	97ffa78f 	bl	4e90 <heap_alloc_miss>
   1b058:	a94117e6 	ldp	x6, x5, [sp, #16]
   1b05c:	aa0003e8 	mov	x8, x0
   1b060:	a9401fe4 	ldp	x4, x7, [sp]
   1b064:	f94013e3 	ldr	x3, [sp, #32]
   1b068:	a94287ea 	ldp	x10, x1, [sp, #40]
   1b06c:	f9401fe0 	ldr	x0, [sp, #56]
   1b070:	17ffffa3 	b	1aefc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K210+0xd8>
   1b074:	a90303e1 	stp	x1, x0, [sp, #48]
   1b078:	aa1403e0 	mov	x0, x20
   1b07c:	aa1503e1 	mov	x1, x21
   1b080:	528000a2 	mov	w2, #0x5                   	// #5
   1b084:	a90117e6 	stp	x6, x5, [sp, #16]
   1b088:	aa0403e9 	mov	x9, x4
   1b08c:	a9022be3 	stp	x3, x10, [sp, #32]
   1b090:	aa0703f5 	mov	x21, x7
   1b094:	97ffa77f 	bl	4e90 <heap_alloc_miss>
   1b098:	a94117e6 	ldp	x6, x5, [sp, #16]
   1b09c:	aa0003e8 	mov	x8, x0
   1b0a0:	a94287ea 	ldp	x10, x1, [sp, #40]
   1b0a4:	aa1503e7 	mov	x7, x21
   1b0a8:	f94013e3 	ldr	x3, [sp, #32]
   1b0ac:	f9401fe0 	ldr	x0, [sp, #56]
   1b0b0:	aa0903e4 	mov	x4, x9
   1b0b4:	17ffffb1 	b	1af78 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K210+0x154>

