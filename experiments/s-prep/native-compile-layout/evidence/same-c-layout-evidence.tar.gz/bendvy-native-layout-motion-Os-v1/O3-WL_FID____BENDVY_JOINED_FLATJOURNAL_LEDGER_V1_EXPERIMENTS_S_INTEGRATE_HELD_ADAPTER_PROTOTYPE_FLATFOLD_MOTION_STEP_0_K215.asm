   1b998:	d10243ff 	sub	sp, sp, #0x90
   1b99c:	a9087bfd 	stp	x29, x30, [sp, #128]
   1b9a0:	910203fd 	add	x29, sp, #0x80
   1b9a4:	f9402fa8 	ldr	x8, [x29, #88]
   1b9a8:	a93e3fac 	stp	x12, x15, [x29, #-32]
   1b9ac:	aa1603f0 	mov	x16, x22
   1b9b0:	f81d83aa 	stur	x10, [x29, #-40]
   1b9b4:	a943cbb1 	ldp	x17, x18, [x29, #56]
   1b9b8:	f81f03a8 	stur	x8, [x29, #-16]
   1b9bc:	f9400bb3 	ldr	x19, [x29, #16]
   1b9c0:	a944a3ac 	ldp	x12, x8, [x29, #72]
   1b9c4:	a942fba2 	ldp	x2, x30, [x29, #40]
   1b9c8:	a941abb8 	ldp	x24, x10, [x29, #24]
   1b9cc:	b85f8ecf 	ldr	w15, [x22, #-8]!
   1b9d0:	340003b7 	cbz	w23, 1ba44 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K215+0xac>
   1b9d4:	a904a3ac 	stp	x12, x8, [x29, #72]
   1b9d8:	f85f03a8 	ldur	x8, [x29, #-16]
   1b9dc:	2a0a03f0 	mov	w16, w10
   1b9e0:	f90033af 	str	x15, [x29, #96]
   1b9e4:	2a1e03ef 	mov	w15, w30
   1b9e8:	f85d83aa 	ldur	x10, [x29, #-40]
   1b9ec:	2a0803e8 	mov	w8, w8
   1b9f0:	2a1903f9 	mov	w25, w25
   1b9f4:	2a1a03fa 	mov	w26, w26
   1b9f8:	f9002fa8 	str	x8, [x29, #88]
   1b9fc:	2a0203e8 	mov	w8, w2
   1ba00:	2a0503e5 	mov	w5, w5
   1ba04:	a902bfa8 	stp	x8, x15, [x29, #40]
   1ba08:	a97e23ac 	ldp	x12, x8, [x29, #-32]
   1ba0c:	2a0703e7 	mov	w7, w7
   1ba10:	a903cbb1 	stp	x17, x18, [x29, #56]
   1ba14:	2a0b03eb 	mov	w11, w11
   1ba18:	2a0d03ed 	mov	w13, w13
   1ba1c:	2a0e03ee 	mov	w14, w14
   1ba20:	2a0903e9 	mov	w9, w9
   1ba24:	2a0803ef 	mov	w15, w8
   1ba28:	2a1803e8 	mov	w8, w24
   1ba2c:	a901c3a8 	stp	x8, x16, [x29, #24]
   1ba30:	2a1303f0 	mov	w16, w19
   1ba34:	f9000bb0 	str	x16, [x29, #16]
   1ba38:	a9487bfd 	ldp	x29, x30, [sp, #128]
   1ba3c:	910243ff 	add	sp, sp, #0x90
   1ba40:	17fff2c9 	b	18564 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_FALLBACK>
   1ba44:	aa0203f6 	mov	x22, x2
   1ba48:	a97e5e02 	ldp	x2, x23, [x16, #-32]
   1ba4c:	a90333fe 	stp	x30, x12, [sp, #48]
   1ba50:	f81c83b2 	stur	x18, [x29, #-56]
   1ba54:	f90023f1 	str	x17, [sp, #64]
   1ba58:	f81d03a8 	stur	x8, [x29, #-48]
   1ba5c:	f94016a8 	ldr	x8, [x21, #40]
   1ba60:	b40006a8 	cbz	x8, 1bb34 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K215+0x19c>
   1ba64:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   1ba68:	f94096b1 	ldr	x17, [x21, #296]
   1ba6c:	f90016b0 	str	x16, [x21, #40]
   1ba70:	d1008230 	sub	x16, x17, #0x20
   1ba74:	f90096b0 	str	x16, [x21, #296]
   1ba78:	8b080e90 	add	x16, x20, x8, lsl #3
   1ba7c:	2a0b03eb 	mov	w11, w11
   1ba80:	d3607ef1 	lsl	x17, x23, #32
   1ba84:	2a1a03f2 	mov	w18, w26
   1ba88:	f900320b 	str	x11, [x16, #96]
   1ba8c:	a97dafac 	ldp	x12, x11, [x29, #-40]
   1ba90:	f9007a11 	str	x17, [x16, #240]
   1ba94:	2a1903f1 	mov	w17, w25
   1ba98:	f900360b 	str	x11, [x16, #104]
   1ba9c:	2a0d03eb 	mov	w11, w13
   1baa0:	2a0e03ed 	mov	w13, w14
   1baa4:	a907360b 	stp	x11, x13, [x16, #112]
   1baa8:	2a0903eb 	mov	w11, w9
   1baac:	f85e83a9 	ldur	x9, [x29, #-24]
   1bab0:	a9004a11 	stp	x17, x18, [x16]
   1bab4:	2a0503f1 	mov	w17, w5
   1bab8:	a9041a11 	stp	x17, x6, [x16, #64]
   1babc:	2a0703f1 	mov	w17, w7
   1bac0:	2a0903ed 	mov	w13, w9
   1bac4:	a9053211 	stp	x17, x12, [x16, #80]
   1bac8:	2a1803ec 	mov	w12, w24
   1bacc:	f9401be9 	ldr	x9, [sp, #48]
   1bad0:	a908360b 	stp	x11, x13, [x16, #128]
   1bad4:	2a1303eb 	mov	w11, w19
   1bad8:	a909320b 	stp	x11, x12, [x16, #144]
   1badc:	2a0a03eb 	mov	w11, w10
   1bae0:	2a1603ea 	mov	w10, w22
   1bae4:	a90a2a0b 	stp	x11, x10, [x16, #160]
   1bae8:	2a0903ea 	mov	w10, w9
   1baec:	a943afe9 	ldp	x9, x11, [sp, #56]
   1baf0:	a901721b 	stp	x27, x28, [x16, #16]
   1baf4:	a90b2e0a 	stp	x10, x11, [x16, #176]
   1baf8:	f85c83aa 	ldur	x10, [x29, #-56]
   1bafc:	a9020600 	stp	x0, x1, [x16, #32]
   1bb00:	a90c260a 	stp	x10, x9, [x16, #192]
   1bb04:	f85f03a9 	ldur	x9, [x29, #-16]
   1bb08:	a9031203 	stp	x3, x4, [x16, #48]
   1bb0c:	2a0903ea 	mov	w10, w9
   1bb10:	f85d03a9 	ldur	x9, [x29, #-48]
   1bb14:	a90d2a09 	stp	x9, x10, [x16, #208]
   1bb18:	d2c5e00a 	mov	x10, #0x2f0000000000        	// #51677046505472
   1bb1c:	f2e0a00a 	movk	x10, #0x500, lsl #48
   1bb20:	aa0a0100 	orr	x0, x8, x10
   1bb24:	a90e0a0f 	stp	x15, x2, [x16, #224]
   1bb28:	a9487bfd 	ldp	x29, x30, [sp, #128]
   1bb2c:	910243ff 	add	sp, sp, #0x90
   1bb30:	d65f03c0 	ret
   1bb34:	a90203e1 	stp	x1, x0, [sp, #32]
   1bb38:	aa1403e0 	mov	x0, x20
   1bb3c:	aa1503e1 	mov	x1, x21
   1bb40:	aa0203ec 	mov	x12, x2
   1bb44:	528000a2 	mov	w2, #0x5                   	// #5
   1bb48:	a9001be7 	stp	x7, x6, [sp]
   1bb4c:	aa0403f5 	mov	x21, x4
   1bb50:	a9010fe5 	stp	x5, x3, [sp, #16]
   1bb54:	97ffa4cf 	bl	4e90 <heap_alloc_miss>
   1bb58:	a9410fe5 	ldp	x5, x3, [sp, #16]
   1bb5c:	aa0003e8 	mov	x8, x0
   1bb60:	a9401be7 	ldp	x7, x6, [sp]
   1bb64:	aa0c03e2 	mov	x2, x12
   1bb68:	a94203e1 	ldp	x1, x0, [sp, #32]
   1bb6c:	aa1503e4 	mov	x4, x21
   1bb70:	17ffffc2 	b	1ba78 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_STEP_0_K215+0xe0>

