   172d8:	d100c3ff 	sub	sp, sp, #0x30
   172dc:	a9027bfd 	stp	x29, x30, [sp, #32]
   172e0:	b94033e8 	ldr	w8, [sp, #48]
   172e4:	f9000fec 	str	x12, [sp, #24]
   172e8:	aa0a03ec 	mov	x12, x10
   172ec:	a946f7ea 	ldp	x10, x29, [sp, #104]
   172f0:	f0000cb8 	adrp	x24, 1ae000 <io_eff_rows+0xff0d0>
   172f4:	913f2318 	add	x24, x24, #0xfc8
   172f8:	f9000be8 	str	x8, [sp, #16]
   172fc:	b94053f0 	ldr	w16, [sp, #80]
   17300:	b85f0ec2 	ldr	w2, [x22, #-16]!
   17304:	b9404bf1 	ldr	w17, [sp, #72]
   17308:	a945fbe8 	ldp	x8, x30, [sp, #88]
   1730c:	2a1903f9 	mov	w25, w25
   17310:	f8627b02 	ldr	x2, [x24, x2, lsl #3]
   17314:	b9400ad8 	ldr	w24, [x22, #8]
   17318:	2a1a03fa 	mov	w26, w26
   1731c:	f90037ea 	str	x10, [sp, #104]
   17320:	aa0c03ea 	mov	x10, x12
   17324:	b94043f2 	ldr	w18, [sp, #64]
   17328:	a905fbe8 	stp	x8, x30, [sp, #88]
   1732c:	a94133e8 	ldp	x8, x12, [sp, #16]
   17330:	b9403bf3 	ldr	w19, [sp, #56]
   17334:	2a0503e5 	mov	w5, w5
   17338:	2a0703e7 	mov	w7, w7
   1733c:	a90763fd 	stp	x29, x24, [sp, #112]
   17340:	a9427bfd 	ldp	x29, x30, [sp, #32]
   17344:	a903cbf3 	stp	x19, x18, [sp, #56]
   17348:	2a0b03eb 	mov	w11, w11
   1734c:	2a0d03ed 	mov	w13, w13
   17350:	a904c3f1 	stp	x17, x16, [sp, #72]
   17354:	2a0e03ee 	mov	w14, w14
   17358:	2a0903e9 	mov	w9, w9
   1735c:	2a0f03ef 	mov	w15, w15
   17360:	52800398 	mov	w24, #0x1c                  	// #28
   17364:	f9001be8 	str	x8, [sp, #48]
   17368:	9100c3ff 	add	sp, sp, #0x30
   1736c:	d61f0040 	br	x2

