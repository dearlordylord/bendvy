   1c808:	d10243ff 	sub	sp, sp, #0x90
   1c80c:	a9087bfd 	stp	x29, x30, [sp, #128]
   1c810:	910203fd 	add	x29, sp, #0x80
   1c814:	a93d1baf 	stp	x15, x6, [x29, #-48]
   1c818:	a9444bbe 	ldp	x30, x18, [x29, #64]
   1c81c:	a93e2ba9 	stp	x9, x10, [x29, #-32]
   1c820:	aa0703e9 	mov	x9, x7
   1c824:	aa1c03f8 	mov	x24, x28
   1c828:	f81f03ac 	stur	x12, [x29, #-16]
   1c82c:	aa0503ec 	mov	x12, x5
   1c830:	aa0403e5 	mov	x5, x4
   1c834:	aa0303e4 	mov	x4, x3
   1c838:	aa0103e3 	mov	x3, x1
   1c83c:	aa0003e1 	mov	x1, x0
   1c840:	a9450baa 	ldp	x10, x2, [x29, #80]
   1c844:	aa1b03fc 	mov	x28, x27
   1c848:	a9431fa0 	ldp	x0, x7, [x29, #48]
   1c84c:	aa1903fb 	mov	x27, x25
   1c850:	a9421bb1 	ldp	x17, x6, [x29, #32]
   1c854:	aa1603e8 	mov	x8, x22
   1c858:	a9413fb3 	ldp	x19, x15, [x29, #16]
   1c85c:	aa0e03f0 	mov	x16, x14
   1c860:	f85f8ed9 	ldr	x25, [x22, #-8]!
   1c864:	34000417 	cbz	w23, 1c8e4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0_K234+0xdc>
   1c868:	2a1b03e8 	mov	w8, w27
   1c86c:	2a1a03fb 	mov	w27, w26
   1c870:	aa0603fa 	mov	x26, x6
   1c874:	2a0c03e6 	mov	w6, w12
   1c878:	2a0203ec 	mov	w12, w2
   1c87c:	a9052bb2 	stp	x18, x10, [x29, #80]
   1c880:	2a0903ea 	mov	w10, w9
   1c884:	2a0003e9 	mov	w9, w0
   1c888:	f90033ac 	str	x12, [x29, #96]
   1c88c:	2a0b03ec 	mov	w12, w11
   1c890:	2a1a03eb 	mov	w11, w26
   1c894:	a9047ba7 	stp	x7, x30, [x29, #64]
   1c898:	a90327ab 	stp	x11, x9, [x29, #48]
   1c89c:	aa1003e9 	mov	x9, x16
   1c8a0:	2a1103f0 	mov	w16, w17
   1c8a4:	2a0f03eb 	mov	w11, w15
   1c8a8:	a97dbfa7 	ldp	x7, x15, [x29, #-40]
   1c8ac:	a90243ab 	stp	x11, x16, [x29, #32]
   1c8b0:	f85d03ab 	ldur	x11, [x29, #-48]
   1c8b4:	2a1303f0 	mov	w16, w19
   1c8b8:	2a0d03ee 	mov	w14, w13
   1c8bc:	2a0903e9 	mov	w9, w9
   1c8c0:	aa0803fa 	mov	x26, x8
   1c8c4:	2a0b03f1 	mov	w17, w11
   1c8c8:	2a0f03ef 	mov	w15, w15
   1c8cc:	aa1803e0 	mov	x0, x24
   1c8d0:	a90143b1 	stp	x17, x16, [x29, #16]
   1c8d4:	a97eb7ab 	ldp	x11, x13, [x29, #-24]
   1c8d8:	a9487bfd 	ldp	x29, x30, [sp, #128]
   1c8dc:	910243ff 	add	sp, sp, #0x90
   1c8e0:	17fffdc1 	b	1bfe4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0>
   1c8e4:	f9001ff1 	str	x17, [sp, #56]
   1c8e8:	a97e5d11 	ldp	x17, x23, [x8, #-32]
   1c8ec:	a90297ed 	stp	x13, x5, [sp, #40]
   1c8f0:	aa0103f6 	mov	x22, x1
   1c8f4:	aa0303ee 	mov	x14, x3
   1c8f8:	f81c83a0 	stur	x0, [x29, #-56]
   1c8fc:	f94016a0 	ldr	x0, [x21, #40]
   1c900:	aa0403ed 	mov	x13, x4
   1c904:	f90023f0 	str	x16, [sp, #64]
   1c908:	b40006e0 	cbz	x0, 1c9e4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0_K234+0x1dc>
   1c90c:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   1c910:	f94096b0 	ldr	x16, [x21, #296]
   1c914:	f90016a8 	str	x8, [x21, #40]
   1c918:	d1008208 	sub	x8, x16, #0x20
   1c91c:	f90096a8 	str	x8, [x21, #296]
   1c920:	8b000e88 	add	x8, x20, x0, lsl #3
   1c924:	2a0c03ec 	mov	w12, w12
   1c928:	2a0903e9 	mov	w9, w9
   1c92c:	d3607ef0 	lsl	x16, x23, #32
   1c930:	a903350e 	stp	x14, x13, [x8, #48]
   1c934:	f9401bed 	ldr	x13, [sp, #48]
   1c938:	f9007910 	str	x16, [x8, #240]
   1c93c:	2a1b03f0 	mov	w16, w27
   1c940:	a904310d 	stp	x13, x12, [x8, #64]
   1c944:	f85d83ac 	ldur	x12, [x29, #-40]
   1c948:	a9004119 	stp	x25, x16, [x8]
   1c94c:	2a1a03f0 	mov	w16, w26
   1c950:	a905250c 	stp	x12, x9, [x8, #80]
   1c954:	2a0b03e9 	mov	w9, w11
   1c958:	f85e83ab 	ldur	x11, [x29, #-24]
   1c95c:	a9017110 	stp	x16, x28, [x8, #16]
   1c960:	a906250b 	stp	x11, x9, [x8, #96]
   1c964:	f94017e9 	ldr	x9, [sp, #40]
   1c968:	f85f03ab 	ldur	x11, [x29, #-16]
   1c96c:	a9025918 	stp	x24, x22, [x8, #32]
   1c970:	2a0903e9 	mov	w9, w9
   1c974:	a90c7907 	stp	x7, x30, [x8, #192]
   1c978:	a907250b 	stp	x11, x9, [x8, #112]
   1c97c:	f94023e9 	ldr	x9, [sp, #64]
   1c980:	f85e03ab 	ldur	x11, [x29, #-32]
   1c984:	a90d2912 	stp	x18, x10, [x8, #208]
   1c988:	2a0903e9 	mov	w9, w9
   1c98c:	2a0b03eb 	mov	w11, w11
   1c990:	a9082d09 	stp	x9, x11, [x8, #128]
   1c994:	f85d03a9 	ldur	x9, [x29, #-48]
   1c998:	2a1303eb 	mov	w11, w19
   1c99c:	2a0903e9 	mov	w9, w9
   1c9a0:	a9092d09 	stp	x9, x11, [x8, #144]
   1c9a4:	f9401feb 	ldr	x11, [sp, #56]
   1c9a8:	2a0f03e9 	mov	w9, w15
   1c9ac:	2a0b03eb 	mov	w11, w11
   1c9b0:	a90a2d09 	stp	x9, x11, [x8, #160]
   1c9b4:	f85c83ab 	ldur	x11, [x29, #-56]
   1c9b8:	2a0603e9 	mov	w9, w6
   1c9bc:	2a0b03eb 	mov	w11, w11
   1c9c0:	a90b2d09 	stp	x9, x11, [x8, #176]
   1c9c4:	d2c82009 	mov	x9, #0x410000000000        	// #71468255805440
   1c9c8:	f2e0a009 	movk	x9, #0x500, lsl #48
   1c9cc:	aa090000 	orr	x0, x0, x9
   1c9d0:	2a0203e9 	mov	w9, w2
   1c9d4:	a90e4509 	stp	x9, x17, [x8, #224]
   1c9d8:	a9487bfd 	ldp	x29, x30, [sp, #128]
   1c9dc:	910243ff 	add	sp, sp, #0x90
   1c9e0:	d65f03c0 	ret
   1c9e4:	aa1403e0 	mov	x0, x20
   1c9e8:	a9018be7 	stp	x7, x2, [sp, #24]
   1c9ec:	aa1503e1 	mov	x1, x21
   1c9f0:	528000a2 	mov	w2, #0x5                   	// #5
   1c9f4:	a900fbf2 	stp	x18, x30, [sp, #8]
   1c9f8:	aa1103f5 	mov	x21, x17
   1c9fc:	f90003e6 	str	x6, [sp]
   1ca00:	97ffa124 	bl	4e90 <heap_alloc_miss>
   1ca04:	a9404be6 	ldp	x6, x18, [sp]
   1ca08:	aa1503f1 	mov	x17, x21
   1ca0c:	a9411ffe 	ldp	x30, x7, [sp, #16]
   1ca10:	f94013e2 	ldr	x2, [sp, #32]
   1ca14:	17ffffc3 	b	1c920 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_MOTION_LOOP_0_K234+0x118>

