   16ee4:	d100c3ff 	sub	sp, sp, #0x30
   16ee8:	a9027bfd 	stp	x29, x30, [sp, #32]
   16eec:	b94033e8 	ldr	w8, [sp, #48]
   16ef0:	f9000fec 	str	x12, [sp, #24]
   16ef4:	aa0a03ec 	mov	x12, x10
   16ef8:	a946f7ea 	ldp	x10, x29, [sp, #104]
   16efc:	90000cd8 	adrp	x24, 1ae000 <io_eff_rows+0xff0b0>
   16f00:	913fa318 	add	x24, x24, #0xfe8
   16f04:	f9000be8 	str	x8, [sp, #16]
   16f08:	b94053f0 	ldr	w16, [sp, #80]
   16f0c:	b85f0ec2 	ldr	w2, [x22, #-16]!
   16f10:	b9404bf1 	ldr	w17, [sp, #72]
   16f14:	a945fbe8 	ldp	x8, x30, [sp, #88]
   16f18:	2a1903f9 	mov	w25, w25
   16f1c:	f8627b02 	ldr	x2, [x24, x2, lsl #3]
   16f20:	b9400ad8 	ldr	w24, [x22, #8]
   16f24:	2a1a03fa 	mov	w26, w26
   16f28:	f90037ea 	str	x10, [sp, #104]
   16f2c:	aa0c03ea 	mov	x10, x12
   16f30:	b94043f2 	ldr	w18, [sp, #64]
   16f34:	a905fbe8 	stp	x8, x30, [sp, #88]
   16f38:	a94133e8 	ldp	x8, x12, [sp, #16]
   16f3c:	b9403bf3 	ldr	w19, [sp, #56]
   16f40:	2a0503e5 	mov	w5, w5
   16f44:	2a0703e7 	mov	w7, w7
   16f48:	a90763fd 	stp	x29, x24, [sp, #112]
   16f4c:	a9427bfd 	ldp	x29, x30, [sp, #32]
   16f50:	a903cbf3 	stp	x19, x18, [sp, #56]
   16f54:	2a0b03eb 	mov	w11, w11
   16f58:	2a0d03ed 	mov	w13, w13
   16f5c:	a904c3f1 	stp	x17, x16, [sp, #72]
   16f60:	2a0e03ee 	mov	w14, w14
   16f64:	2a0903e9 	mov	w9, w9
   16f68:	2a0f03ef 	mov	w15, w15
   16f6c:	52800398 	mov	w24, #0x1c                  	// #28
   16f70:	f9001be8 	str	x8, [sp, #48]
   16f74:	9100c3ff 	add	sp, sp, #0x30
   16f78:	d61f0040 	br	x2

