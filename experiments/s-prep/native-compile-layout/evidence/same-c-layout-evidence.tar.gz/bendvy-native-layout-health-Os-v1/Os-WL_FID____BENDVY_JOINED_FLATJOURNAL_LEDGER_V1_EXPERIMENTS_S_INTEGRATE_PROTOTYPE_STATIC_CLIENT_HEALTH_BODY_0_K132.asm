   1652c:	d10443ff 	sub	sp, sp, #0x110
   16530:	a9107bfd 	stp	x29, x30, [sp, #256]
   16534:	910403fd 	add	x29, sp, #0x100
   16538:	aa0a03f3 	mov	x19, x10
   1653c:	a93e97b9 	stp	x25, x5, [x29, #-24]
   16540:	b9405ba8 	ldr	w8, [x29, #88]
   16544:	a944abbe 	ldp	x30, x10, [x29, #72]
   16548:	f9400bb0 	ldr	x16, [x29, #16]
   1654c:	a94397b9 	ldp	x25, x5, [x29, #56]
   16550:	a942e3a2 	ldp	x2, x24, [x29, #40]
   16554:	a941c7b2 	ldp	x18, x17, [x29, #24]
   16558:	34000468 	cbz	w8, 165e4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K132+0xb8>
   1655c:	b85f8ec8 	ldr	w8, [x22, #-8]!
   16560:	a93db3b3 	stp	x19, x12, [x29, #-40]
   16564:	90000cd3 	adrp	x19, 1ae000 <io_eff_rows+0xff0b0>
   16568:	913fa273 	add	x19, x19, #0xfe8
   1656c:	1280000c 	mov	w12, #0xffffffff            	// #-1
   16570:	f8687a68 	ldr	x8, [x19, x8, lsl #3]
   16574:	a90533aa 	stp	x10, x12, [x29, #80]
   16578:	2a1a03fa 	mov	w26, w26
   1657c:	a9047ba5 	stp	x5, x30, [x29, #64]
   16580:	2a0703e7 	mov	w7, w7
   16584:	2a0b03eb 	mov	w11, w11
   16588:	f81d03a8 	stur	x8, [x29, #-48]
   1658c:	2a1803e8 	mov	w8, w24
   16590:	2a0d03ed 	mov	w13, w13
   16594:	a90367a8 	stp	x8, x25, [x29, #48]
   16598:	2a0203e8 	mov	w8, w2
   1659c:	2a0e03ee 	mov	w14, w14
   165a0:	f90017a8 	str	x8, [x29, #40]
   165a4:	2a1103e8 	mov	w8, w17
   165a8:	2a0903e9 	mov	w9, w9
   165ac:	f90013a8 	str	x8, [x29, #32]
   165b0:	a97ea3aa 	ldp	x10, x8, [x29, #-24]
   165b4:	2a0f03ef 	mov	w15, w15
   165b8:	52800398 	mov	w24, #0x1c                  	// #28
   165bc:	2a0a03f9 	mov	w25, w10
   165c0:	a97db3aa 	ldp	x10, x12, [x29, #-40]
   165c4:	2a0803e5 	mov	w5, w8
   165c8:	2a1003e8 	mov	w8, w16
   165cc:	2a1203f0 	mov	w16, w18
   165d0:	a90143a8 	stp	x8, x16, [x29, #16]
   165d4:	f85d03a2 	ldur	x2, [x29, #-48]
   165d8:	a9507bfd 	ldp	x29, x30, [sp, #256]
   165dc:	910443ff 	add	sp, sp, #0x110
   165e0:	d61f0040 	br	x2
   165e4:	a93c17b9 	stp	x25, x5, [x29, #-64]
   165e8:	f85e83b9 	ldur	x25, [x29, #-24]
   165ec:	f81d03aa 	stur	x10, [x29, #-48]
   165f0:	a93aebb5 	stp	x21, x26, [x29, #-88]
   165f4:	a9466ba5 	ldp	x5, x26, [x29, #96]
   165f8:	f81b83b8 	stur	x24, [x29, #-72]
   165fc:	a9472bb8 	ldp	x24, x10, [x29, #112]
   16600:	340005d7 	cbz	w23, 166b8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K132+0x18c>
   16604:	2a0503e8 	mov	w8, w5
   16608:	aa1003f5 	mov	x21, x16
   1660c:	2a1a03f0 	mov	w16, w26
   16610:	a90042c8 	stp	x8, x16, [x22]
   16614:	2a1803e8 	mov	w8, w24
   16618:	2a0a03f0 	mov	w16, w10
   1661c:	a90142c8 	stp	x8, x16, [x22, #16]
   16620:	52800548 	mov	w8, #0x2a                  	// #42
   16624:	2a1903f9 	mov	w25, w25
   16628:	f90012c8 	str	x8, [x22, #32]
   1662c:	110004a8 	add	w8, w5, #0x1
   16630:	2a0703e7 	mov	w7, w7
   16634:	f9002fa8 	str	x8, [x29, #88]
   16638:	f85d03a8 	ldur	x8, [x29, #-48]
   1663c:	2a0b03eb 	mov	w11, w11
   16640:	2a0d03ed 	mov	w13, w13
   16644:	2a0e03ee 	mov	w14, w14
   16648:	2a0903e9 	mov	w9, w9
   1664c:	a904a3be 	stp	x30, x8, [x29, #72]
   16650:	f85c83a8 	ldur	x8, [x29, #-56]
   16654:	2a0f03ef 	mov	w15, w15
   16658:	9100a2d6 	add	x22, x22, #0x28
   1665c:	aa1303ea 	mov	x10, x19
   16660:	f90023a8 	str	x8, [x29, #64]
   16664:	f85c03a8 	ldur	x8, [x29, #-64]
   16668:	f9001fa8 	str	x8, [x29, #56]
   1666c:	f85b83a8 	ldur	x8, [x29, #-72]
   16670:	2a0803e8 	mov	w8, w8
   16674:	f9001ba8 	str	x8, [x29, #48]
   16678:	2a0203e8 	mov	w8, w2
   1667c:	f90017a8 	str	x8, [x29, #40]
   16680:	2a1103e8 	mov	w8, w17
   16684:	f90013a8 	str	x8, [x29, #32]
   16688:	2a1203e8 	mov	w8, w18
   1668c:	f9000fa8 	str	x8, [x29, #24]
   16690:	f85b03a8 	ldur	x8, [x29, #-80]
   16694:	2a0803fa 	mov	w26, w8
   16698:	f85f03a8 	ldur	x8, [x29, #-16]
   1669c:	2a0803e5 	mov	w5, w8
   166a0:	2a1503e8 	mov	w8, w21
   166a4:	f85a83b5 	ldur	x21, [x29, #-88]
   166a8:	f9000ba8 	str	x8, [x29, #16]
   166ac:	a9507bfd 	ldp	x29, x30, [sp, #256]
   166b0:	910443ff 	add	sp, sp, #0x110
   166b4:	17ffd363 	b	b440 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0>
   166b8:	f81a03a5 	stur	x5, [x29, #-96]
   166bc:	a9020bf1 	stp	x17, x2, [sp, #32]
   166c0:	a9031ff2 	stp	x18, x7, [sp, #48]
   166c4:	a90473f0 	stp	x16, x28, [sp, #64]
   166c8:	aa1e03fc 	mov	x28, x30
   166cc:	a90537eb 	stp	x11, x13, [sp, #80]
   166d0:	f9000ffb 	str	x27, [sp, #24]
   166d4:	aa0a03fb 	mov	x27, x10
   166d8:	f90033e0 	str	x0, [sp, #96]
   166dc:	a9070fe1 	stp	x1, x3, [sp, #112]
   166e0:	f90043e9 	str	x9, [sp, #128]
   166e4:	a97ea2c9 	ldp	x9, x8, [x22, #-24]
   166e8:	f85a83b5 	ldur	x21, [x29, #-88]
   166ec:	f81883a4 	stur	x4, [x29, #-120]
   166f0:	f81983a6 	stur	x6, [x29, #-104]
   166f4:	f9401ab7 	ldr	x23, [x21, #48]
   166f8:	f81d83b3 	stur	x19, [x29, #-40]
   166fc:	a900a7e8 	stp	x8, x9, [sp, #8]
   16700:	f81e03ac 	stur	x12, [x29, #-32]
   16704:	f81903af 	stur	x15, [x29, #-112]
   16708:	f90037ee 	str	x14, [sp, #104]
   1670c:	b4000c17 	cbz	x23, 1688c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K132+0x360>
   16710:	f8777a88 	ldr	x8, [x20, x23, lsl #3]
   16714:	f9409aa9 	ldr	x9, [x21, #304]
   16718:	f9001aa8 	str	x8, [x21, #48]
   1671c:	d1010128 	sub	x8, x9, #0x40
   16720:	f9009aa8 	str	x8, [x21, #304]
   16724:	8b170e93 	add	x19, x20, x23, lsl #3
   16728:	52801fe1 	mov	w1, #0xff                  	// #255
   1672c:	52801b02 	mov	w2, #0xd8                  	// #216
   16730:	91008260 	add	x0, x19, #0x20
   16734:	97ffb4d7 	bl	3a90 <memset@plt>
   16738:	f85a03b1 	ldur	x17, [x29, #-96]
   1673c:	2a1a03ea 	mov	w10, w26
   16740:	52800029 	mov	w9, #0x1                   	// #1
   16744:	2a1103e8 	mov	w8, w17
   16748:	a9002a68 	stp	x8, x10, [x19]
   1674c:	f94007e8 	ldr	x8, [sp, #8]
   16750:	d2c5400a 	mov	x10, #0x2a0000000000        	// #46179488366592
   16754:	f2e0a00a 	movk	x10, #0x500, lsl #48
   16758:	aa088128 	orr	x8, x9, x8, lsl #32
   1675c:	f9400be9 	ldr	x9, [sp, #16]
   16760:	a90fa269 	stp	x9, x8, [x19, #248]
   16764:	2a1803e9 	mov	w9, w24
   16768:	2a1b03e8 	mov	w8, w27
   1676c:	a9012269 	stp	x9, x8, [x19, #16]
   16770:	aa0a02e9 	orr	x9, x23, x10
   16774:	52800088 	mov	w8, #0x4                   	// #4
   16778:	a93ea2c9 	stp	x9, x8, [x22, #-24]
   1677c:	f94016a0 	ldr	x0, [x21, #40]
   16780:	b4000920 	cbz	x0, 168a4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K132+0x378>
   16784:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   16788:	f94096aa 	ldr	x10, [x21, #296]
   1678c:	f90016a8 	str	x8, [x21, #40]
   16790:	d1008148 	sub	x8, x10, #0x20
   16794:	f90096a8 	str	x8, [x21, #296]
   16798:	a97b3bb0 	ldp	x16, x14, [x29, #-80]
   1679c:	8b000e88 	add	x8, x20, x0, lsl #3
   167a0:	d2c0008a 	mov	x10, #0x400000000           	// #17179869184
   167a4:	f85f03af 	ldur	x15, [x29, #-16]
   167a8:	f85e03ab 	ldur	x11, [x29, #-32]
   167ac:	a90e2909 	stp	x9, x10, [x8, #224]
   167b0:	2a1903e9 	mov	w9, w25
   167b4:	f85903ac 	ldur	x12, [x29, #-112]
   167b8:	2a1003ea 	mov	w10, w16
   167bc:	a9002909 	stp	x9, x10, [x8]
   167c0:	f9400fea 	ldr	x10, [sp, #24]
   167c4:	f94027e9 	ldr	x9, [sp, #72]
   167c8:	a901250a 	stp	x10, x9, [x8, #16]
   167cc:	a94637ea 	ldp	x10, x13, [sp, #96]
   167d0:	f9403be9 	ldr	x9, [sp, #112]
   167d4:	a902250a 	stp	x10, x9, [x8, #32]
   167d8:	f9403fea 	ldr	x10, [sp, #120]
   167dc:	f85883a9 	ldur	x9, [x29, #-120]
   167e0:	a903250a 	stp	x10, x9, [x8, #48]
   167e4:	2a0f03e9 	mov	w9, w15
   167e8:	f85983aa 	ldur	x10, [x29, #-104]
   167ec:	f9002109 	str	x9, [x8, #64]
   167f0:	f9401fe9 	ldr	x9, [sp, #56]
   167f4:	2a0903e9 	mov	w9, w9
   167f8:	a904a50a 	stp	x10, x9, [x8, #72]
   167fc:	f9402be9 	ldr	x9, [sp, #80]
   16800:	f85d83aa 	ldur	x10, [x29, #-40]
   16804:	2a0903e9 	mov	w9, w9
   16808:	a905a50a 	stp	x10, x9, [x8, #88]
   1680c:	f9402fe9 	ldr	x9, [sp, #88]
   16810:	2a0d03ea 	mov	w10, w13
   16814:	f9003d0a 	str	x10, [x8, #120]
   16818:	2a0c03ea 	mov	w10, w12
   1681c:	2a0903e9 	mov	w9, w9
   16820:	a906a50b 	stp	x11, x9, [x8, #104]
   16824:	f94043e9 	ldr	x9, [sp, #128]
   16828:	2a0903e9 	mov	w9, w9
   1682c:	a9082909 	stp	x9, x10, [x8, #128]
   16830:	f94023e9 	ldr	x9, [sp, #64]
   16834:	f9401bea 	ldr	x10, [sp, #48]
   16838:	2a0903e9 	mov	w9, w9
   1683c:	2a0a03ea 	mov	w10, w10
   16840:	a9092909 	stp	x9, x10, [x8, #144]
   16844:	a9422be9 	ldp	x9, x10, [sp, #32]
   16848:	2a0903e9 	mov	w9, w9
   1684c:	2a0a03ea 	mov	w10, w10
   16850:	a90a2909 	stp	x9, x10, [x8, #160]
   16854:	2a0e03e9 	mov	w9, w14
   16858:	f9005909 	str	x9, [x8, #176]
   1685c:	a97c27aa 	ldp	x10, x9, [x29, #-64]
   16860:	a90ba50a 	stp	x10, x9, [x8, #184]
   16864:	d2c16009 	mov	x9, #0xb0000000000         	// #12094627905536
   16868:	1100062a 	add	w10, w17, #0x1
   1686c:	f2e0a009 	movk	x9, #0x500, lsl #48
   16870:	aa090000 	orr	x0, x0, x9
   16874:	f85d03a9 	ldur	x9, [x29, #-48]
   16878:	a90ca51c 	stp	x28, x9, [x8, #200]
   1687c:	f9006d0a 	str	x10, [x8, #216]
   16880:	a9507bfd 	ldp	x29, x30, [sp, #256]
   16884:	910443ff 	add	sp, sp, #0x110
   16888:	d65f03c0 	ret
   1688c:	aa1403e0 	mov	x0, x20
   16890:	aa1503e1 	mov	x1, x21
   16894:	528000c2 	mov	w2, #0x6                   	// #6
   16898:	97ffb895 	bl	4aec <heap_alloc_miss>
   1689c:	aa0003f7 	mov	x23, x0
   168a0:	17ffffa1 	b	16724 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K132+0x1f8>
   168a4:	aa1403e0 	mov	x0, x20
   168a8:	aa1503e1 	mov	x1, x21
   168ac:	528000a2 	mov	w2, #0x5                   	// #5
   168b0:	97ffb88f 	bl	4aec <heap_alloc_miss>
   168b4:	f85a03b1 	ldur	x17, [x29, #-96]
   168b8:	17ffffb8 	b	16798 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K132+0x26c>

