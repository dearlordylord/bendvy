   162d0:	d10383ff 	sub	sp, sp, #0xe0
   162d4:	a90d7bfd 	stp	x29, x30, [sp, #208]
   162d8:	910343fd 	add	x29, sp, #0xd0
   162dc:	a93e2bad 	stp	x13, x10, [x29, #-32]
   162e0:	a944cbb0 	ldp	x16, x18, [x29, #72]
   162e4:	a943b7a8 	ldp	x8, x13, [x29, #56]
   162e8:	f9400ba2 	ldr	x2, [x29, #16]
   162ec:	f81f03ac 	stur	x12, [x29, #-16]
   162f0:	a942c7be 	ldp	x30, x17, [x29, #40]
   162f4:	a941e3b3 	ldp	x19, x24, [x29, #24]
   162f8:	340003f7 	cbz	w23, 16374 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0+0xa4>
   162fc:	aa1b03ea 	mov	x10, x27
   16300:	aa0803fb 	mov	x27, x8
   16304:	52800528 	mov	w8, #0x29                  	// #41
   16308:	f80086c8 	str	x8, [x22], #8
   1630c:	f85e03a8 	ldur	x8, [x29, #-32]
   16310:	2a1903ec 	mov	w12, w25
   16314:	a904cbb0 	stp	x16, x18, [x29, #72]
   16318:	2a1e03f0 	mov	w16, w30
   1631c:	a903b7bb 	stp	x27, x13, [x29, #56]
   16320:	2a0803ed 	mov	w13, w8
   16324:	2a1103e8 	mov	w8, w17
   16328:	a902a3b0 	stp	x16, x8, [x29, #40]
   1632c:	2a1803e8 	mov	w8, w24
   16330:	2a1303f0 	mov	w16, w19
   16334:	aa0c03f9 	mov	x25, x12
   16338:	aa0a03fb 	mov	x27, x10
   1633c:	a901a3b0 	stp	x16, x8, [x29, #24]
   16340:	a97eb3aa 	ldp	x10, x12, [x29, #-24]
   16344:	2a0203e8 	mov	w8, w2
   16348:	2a1a03fa 	mov	w26, w26
   1634c:	2a0503e5 	mov	w5, w5
   16350:	2a0703e7 	mov	w7, w7
   16354:	2a0b03eb 	mov	w11, w11
   16358:	2a0e03ee 	mov	w14, w14
   1635c:	2a0903e9 	mov	w9, w9
   16360:	2a0f03ef 	mov	w15, w15
   16364:	f9000ba8 	str	x8, [x29, #16]
   16368:	a94d7bfd 	ldp	x29, x30, [sp, #208]
   1636c:	910383ff 	add	sp, sp, #0xe0
   16370:	17fff0fa 	b	12758 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN>
   16374:	a90017fb 	stp	x27, x5, [sp]
   16378:	f9401ab7 	ldr	x23, [x21, #48]
   1637c:	f9000be7 	str	x7, [sp, #16]
   16380:	f81b03bc 	stur	x28, [x29, #-80]
   16384:	a90183eb 	stp	x11, x0, [sp, #24]
   16388:	a9028be1 	stp	x1, x2, [sp, #40]
   1638c:	f9001fe3 	str	x3, [sp, #56]
   16390:	f81b83b3 	stur	x19, [x29, #-72]
   16394:	f90023e4 	str	x4, [sp, #64]
   16398:	f81c03b8 	stur	x24, [x29, #-64]
   1639c:	a97ee2dc 	ldp	x28, x24, [x22, #-24]
   163a0:	a9049bee 	stp	x14, x6, [sp, #72]
   163a4:	a905c3f1 	stp	x17, x16, [sp, #88]
   163a8:	a93a4ba9 	stp	x9, x18, [x29, #-96]
   163ac:	a93d3fa8 	stp	x8, x15, [x29, #-48]
   163b0:	f90037ed 	str	x13, [sp, #104]
   163b4:	f81c83be 	stur	x30, [x29, #-56]
   163b8:	b4000a57 	cbz	x23, 16500 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0+0x230>
   163bc:	f8777a88 	ldr	x8, [x20, x23, lsl #3]
   163c0:	f9409aa9 	ldr	x9, [x21, #304]
   163c4:	f9001aa8 	str	x8, [x21, #48]
   163c8:	d1010128 	sub	x8, x9, #0x40
   163cc:	f9009aa8 	str	x8, [x21, #304]
   163d0:	8b170e93 	add	x19, x20, x23, lsl #3
   163d4:	52801fe1 	mov	w1, #0xff                  	// #255
   163d8:	52802202 	mov	w2, #0x110                 	// #272
   163dc:	aa1303e0 	mov	x0, x19
   163e0:	97ffb5ac 	bl	3a90 <memset@plt>
   163e4:	52800028 	mov	w8, #0x1                   	// #1
   163e8:	d2c52009 	mov	x9, #0x290000000000        	// #45079976738816
   163ec:	aa188108 	orr	x8, x8, x24, lsl #32
   163f0:	f2e0a009 	movk	x9, #0x500, lsl #48
   163f4:	aa0902e9 	orr	x9, x23, x9
   163f8:	a911227c 	stp	x28, x8, [x19, #272]
   163fc:	f94003f3 	ldr	x19, [sp]
   16400:	a93efec9 	stp	x9, xzr, [x22, #-24]
   16404:	f94016a0 	ldr	x0, [x21, #40]
   16408:	b4000880 	cbz	x0, 16518 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0+0x248>
   1640c:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   16410:	f94096aa 	ldr	x10, [x21, #296]
   16414:	f90016a8 	str	x8, [x21, #40]
   16418:	d1008148 	sub	x8, x10, #0x20
   1641c:	f90096a8 	str	x8, [x21, #296]
   16420:	8b000e88 	add	x8, x20, x0, lsl #3
   16424:	2a1903ea 	mov	w10, w25
   16428:	2a1a03eb 	mov	w11, w26
   1642c:	f85f03ac 	ldur	x12, [x29, #-16]
   16430:	a97d37ae 	ldp	x14, x13, [x29, #-48]
   16434:	a9002d0a 	stp	x10, x11, [x8]
   16438:	a9422beb 	ldp	x11, x10, [sp, #32]
   1643c:	a97b47b2 	ldp	x18, x17, [x29, #-80]
   16440:	f9006d09 	str	x9, [x8, #216]
   16444:	a97c3fb0 	ldp	x16, x15, [x29, #-64]
   16448:	f85a83a9 	ldur	x9, [x29, #-88]
   1644c:	a902290b 	stp	x11, x10, [x8, #32]
   16450:	a943abeb 	ldp	x11, x10, [sp, #56]
   16454:	f900711f 	str	xzr, [x8, #224]
   16458:	a9014913 	stp	x19, x18, [x8, #16]
   1645c:	a903290b 	stp	x11, x10, [x8, #48]
   16460:	f94007ea 	ldr	x10, [sp, #8]
   16464:	2a0a03ea 	mov	w10, w10
   16468:	f900210a 	str	x10, [x8, #64]
   1646c:	a944abeb 	ldp	x11, x10, [sp, #72]
   16470:	f900250a 	str	x10, [x8, #72]
   16474:	f9400bea 	ldr	x10, [sp, #16]
   16478:	2a0b03eb 	mov	w11, w11
   1647c:	2a0a03ea 	mov	w10, w10
   16480:	f900290a 	str	x10, [x8, #80]
   16484:	f85e83aa 	ldur	x10, [x29, #-24]
   16488:	f9002d0a 	str	x10, [x8, #88]
   1648c:	f9400fea 	ldr	x10, [sp, #24]
   16490:	2a0a03ea 	mov	w10, w10
   16494:	a906310a 	stp	x10, x12, [x8, #96]
   16498:	f85e03aa 	ldur	x10, [x29, #-32]
   1649c:	2a0a03ea 	mov	w10, w10
   164a0:	a9072d0a 	stp	x10, x11, [x8, #112]
   164a4:	f85a03aa 	ldur	x10, [x29, #-96]
   164a8:	2a0d03eb 	mov	w11, w13
   164ac:	2a0a03ea 	mov	w10, w10
   164b0:	a9082d0a 	stp	x10, x11, [x8, #128]
   164b4:	f9401bea 	ldr	x10, [sp, #48]
   164b8:	2a1103eb 	mov	w11, w17
   164bc:	2a0a03ea 	mov	w10, w10
   164c0:	a9092d0a 	stp	x10, x11, [x8, #144]
   164c4:	2a1003ea 	mov	w10, w16
   164c8:	2a0f03eb 	mov	w11, w15
   164cc:	a90a2d0a 	stp	x10, x11, [x8, #160]
   164d0:	f9402fea 	ldr	x10, [sp, #88]
   164d4:	2a0a03ea 	mov	w10, w10
   164d8:	a90b390a 	stp	x10, x14, [x8, #176]
   164dc:	a9462fea 	ldp	x10, x11, [sp, #96]
   164e0:	a90c290b 	stp	x11, x10, [x8, #192]
   164e4:	d2c3c00a 	mov	x10, #0x1e0000000000        	// #32985348833280
   164e8:	f2e0a00a 	movk	x10, #0x500, lsl #48
   164ec:	aa0a0000 	orr	x0, x0, x10
   164f0:	f9006909 	str	x9, [x8, #208]
   164f4:	a94d7bfd 	ldp	x29, x30, [sp, #208]
   164f8:	910383ff 	add	sp, sp, #0xe0
   164fc:	d65f03c0 	ret
   16500:	aa1403e0 	mov	x0, x20
   16504:	aa1503e1 	mov	x1, x21
   16508:	528000c2 	mov	w2, #0x6                   	// #6
   1650c:	97ffb978 	bl	4aec <heap_alloc_miss>
   16510:	aa0003f7 	mov	x23, x0
   16514:	17ffffaf 	b	163d0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0+0x100>
   16518:	aa1403e0 	mov	x0, x20
   1651c:	aa1503e1 	mov	x1, x21
   16520:	528000a2 	mov	w2, #0x5                   	// #5
   16524:	97ffb972 	bl	4aec <heap_alloc_miss>
   16528:	17ffffbe 	b	16420 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0+0x150>

