   181c4:	d100c3ff 	sub	sp, sp, #0x30
   181c8:	a9027bfd 	stp	x29, x30, [sp, #32]
   181cc:	b94033e8 	ldr	w8, [sp, #48]
   181d0:	a90133e8 	stp	x8, x12, [sp, #16]
   181d4:	aa0a03ec 	mov	x12, x10
   181d8:	a946f7ea 	ldp	x10, x29, [sp, #104]
   181dc:	d0000cb8 	adrp	x24, 1ae000 <io_eff_rows+0xff0f8>
   181e0:	913fa318 	add	x24, x24, #0xfe8
   181e4:	b94053f0 	ldr	w16, [sp, #80]
   181e8:	b85f0ec2 	ldr	w2, [x22, #-16]!
   181ec:	b9404bf1 	ldr	w17, [sp, #72]
   181f0:	a945fbe8 	ldp	x8, x30, [sp, #88]
   181f4:	2a1903f9 	mov	w25, w25
   181f8:	f8627b02 	ldr	x2, [x24, x2, lsl #3]
   181fc:	b9400ad8 	ldr	w24, [x22, #8]
   18200:	2a1a03fa 	mov	w26, w26
   18204:	f90037ea 	str	x10, [sp, #104]
   18208:	aa0c03ea 	mov	x10, x12
   1820c:	b94043f2 	ldr	w18, [sp, #64]
   18210:	a905fbe8 	stp	x8, x30, [sp, #88]
   18214:	a94133e8 	ldp	x8, x12, [sp, #16]
   18218:	b9403bf3 	ldr	w19, [sp, #56]
   1821c:	2a0503e5 	mov	w5, w5
   18220:	2a0703e7 	mov	w7, w7
   18224:	a90763fd 	stp	x29, x24, [sp, #112]
   18228:	a9427bfd 	ldp	x29, x30, [sp, #32]
   1822c:	a903cbf3 	stp	x19, x18, [sp, #56]
   18230:	2a0b03eb 	mov	w11, w11
   18234:	2a0d03ed 	mov	w13, w13
   18238:	a904c3f1 	stp	x17, x16, [sp, #72]
   1823c:	2a0e03ee 	mov	w14, w14
   18240:	2a0903e9 	mov	w9, w9
   18244:	2a0f03ef 	mov	w15, w15
   18248:	52800398 	mov	w24, #0x1c                  	// #28
   1824c:	f8030fe8 	str	x8, [sp, #48]!
   18250:	d61f0040 	br	x2

