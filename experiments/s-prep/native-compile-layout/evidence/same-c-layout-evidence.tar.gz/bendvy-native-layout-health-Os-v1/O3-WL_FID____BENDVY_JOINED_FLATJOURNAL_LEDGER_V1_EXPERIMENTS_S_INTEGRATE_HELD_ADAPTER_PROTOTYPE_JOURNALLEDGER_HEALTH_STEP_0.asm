   18fa8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
   18fac:	910003fd 	mov	x29, sp
   18fb0:	d10ac3ff 	sub	sp, sp, #0x2b0
   18fb4:	a933bfb6 	stp	x22, x15, [x29, #-200]
   18fb8:	a9467bb0 	ldp	x16, x30, [x29, #96]
   18fbc:	a94547b2 	ldp	x18, x17, [x29, #80]
   18fc0:	aa1903ef 	mov	x15, x25
   18fc4:	a9428bb3 	ldp	x19, x2, [x29, #40]
   18fc8:	6b0f037f 	cmp	w27, w15
   18fcc:	a941a3b6 	ldp	x22, x8, [x29, #24]
   18fd0:	f94027b8 	ldr	x24, [x29, #72]
   18fd4:	f9400bb9 	ldr	x25, [x29, #16]
   18fd8:	f81483aa 	stur	x10, [x29, #-184]
   18fdc:	f81303a8 	stur	x8, [x29, #-208]
   18fe0:	540008e1 	b.ne	190fc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x154>  // b.any
   18fe4:	51000748 	sub	w8, w26, #0x1
   18fe8:	6b07011f 	cmp	w8, w7
   18fec:	54000882 	b.cs	190fc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x154>  // b.hs, b.nlast
   18ff0:	6b0b035f 	cmp	w26, w11
   18ff4:	54000848 	b.hi	190fc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x154>  // b.pmore
   18ff8:	f900d3fa 	str	x26, [sp, #416]
   18ffc:	f81083b3 	stur	x19, [x29, #-248]
   19000:	2a0d03f3 	mov	w19, w13
   19004:	f100067f 	cmp	x19, #0x1
   19008:	54000d41 	b.ne	191b0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x208>  // b.any
   1900c:	92409c73 	and	x19, x3, #0xffffffffff
   19010:	aa1303ed 	mov	x13, x19
   19014:	b7f816e3 	tbnz	x3, #63, 192f0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x348>
   19018:	f81103b3 	stur	x19, [x29, #-240]
   1901c:	92409c93 	and	x19, x4, #0xffffffffff
   19020:	f81283b3 	stur	x19, [x29, #-216]
   19024:	f85083b3 	ldur	x19, [x29, #-248]
   19028:	b7f81724 	tbnz	x4, #63, 1930c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x364>
   1902c:	92409cba 	and	x26, x5, #0xffffffffff
   19030:	b7f81765 	tbnz	x5, #63, 1931c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x374>
   19034:	f81003b0 	stur	x16, [x29, #-256]
   19038:	f900cbec 	str	x12, [sp, #400]
   1903c:	92409ccc 	and	x12, x6, #0xffffffffff
   19040:	a91873fb 	stp	x27, x28, [sp, #384]
   19044:	f900d7f1 	str	x17, [sp, #424]
   19048:	b7f81786 	tbnz	x6, #63, 19338 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x390>
   1904c:	d368fc70 	lsr	x16, x3, #40
   19050:	12800011 	mov	w17, #0xffffffff            	// #-1
   19054:	8b0d0e8d 	add	x13, x20, x13, lsl #3
   19058:	1ad02230 	lsl	w16, w17, w16
   1905c:	0a300110 	bic	w16, w8, w16
   19060:	b87059ad 	ldr	w13, [x13, w16, uxtw #2]
   19064:	340016ed 	cbz	w13, 19340 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x398>
   19068:	92409c1b 	and	x27, x0, #0xffffffffff
   1906c:	f9006bec 	str	x12, [sp, #208]
   19070:	aa1b03ed 	mov	x13, x27
   19074:	f900bfe2 	str	x2, [sp, #376]
   19078:	b6f80060 	tbz	x0, #63, 19084 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xdc>
   1907c:	f87b7a8d 	ldr	x13, [x20, x27, lsl #3]
   19080:	d358fdad 	lsr	x13, x13, #24
   19084:	d368b010 	ubfx	x16, x0, #40, #5
   19088:	92800011 	mov	x17, #0xffffffffffffffff    	// #-1
   1908c:	d37df1ad 	lsl	x13, x13, #3
   19090:	51000610 	sub	w16, w16, #0x1
   19094:	8b0d028d 	add	x13, x20, x13
   19098:	9ad0222c 	lsl	x12, x17, x16
   1909c:	0a2c0108 	bic	w8, w8, w12
   190a0:	531f7908 	lsl	w8, w8, #1
   190a4:	d37d7d08 	ubfiz	x8, x8, #3, #32
   190a8:	8b0801a8 	add	x8, x13, x8
   190ac:	b940010d 	ldr	w13, [x8]
   190b0:	f9400502 	ldr	x2, [x8, #8]
   190b4:	a9007d1f 	stp	xzr, xzr, [x8]
   190b8:	34001b0d 	cbz	w13, 19418 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x470>
   190bc:	92409c48 	and	x8, x2, #0xffffffffff
   190c0:	f90093ec 	str	x12, [sp, #288]
   190c4:	52909fec 	mov	w12, #0x84ff                	// #34047
   190c8:	8b080e90 	add	x16, x20, x8, lsl #3
   190cc:	72a0620c 	movk	w12, #0x310, lsl #16
   190d0:	a9169fe4 	stp	x4, x7, [sp, #360]
   190d4:	a9138fe5 	stp	x5, x3, [sp, #312]
   190d8:	a91587e0 	stp	x0, x1, [sp, #344]
   190dc:	a9149bfe 	stp	x30, x6, [sp, #328]
   190e0:	f9009bf2 	str	x18, [sp, #304]
   190e4:	b7f81fa2 	tbnz	x2, #63, 194d8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x530>
   190e8:	a9407213 	ldp	x19, x28, [x16]
   190ec:	aa0803ed 	mov	x13, x8
   190f0:	eb0c011f 	cmp	x8, x12
   190f4:	54002248 	b.hi	1953c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x594>  // b.pmore
   190f8:	1400011d 	b	1956c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x5c4>
   190fc:	f81283af 	stur	x15, [x29, #-216]
   19100:	aa1803ef 	mov	x15, x24
   19104:	f81103b6 	stur	x22, [x29, #-240]
   19108:	34000b37 	cbz	w23, 1926c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x2c4>
   1910c:	aa0c03ea 	mov	x10, x12
   19110:	a973b3b6 	ldp	x22, x12, [x29, #-200]
   19114:	a903cbaf 	stp	x15, x18, [x29, #56]
   19118:	2a1e03f2 	mov	w18, w30
   1911c:	2a1303f3 	mov	w19, w19
   19120:	f9002fb2 	str	x18, [x29, #88]
   19124:	2a1b03e8 	mov	w8, w27
   19128:	aa0003fb 	mov	x27, x0
   1912c:	2a0c03f2 	mov	w18, w12
   19130:	f85283ac 	ldur	x12, [x29, #-216]
   19134:	a904c3b1 	stp	x17, x16, [x29, #72]
   19138:	2a0703f1 	mov	w17, w7
   1913c:	2a0b03e7 	mov	w7, w11
   19140:	2a0d03eb 	mov	w11, w13
   19144:	2a0903ed 	mov	w13, w9
   19148:	2a1a03e9 	mov	w9, w26
   1914c:	2a0c03ef 	mov	w15, w12
   19150:	2a0203ec 	mov	w12, w2
   19154:	a902a7af 	stp	x15, x9, [x29, #40]
   19158:	f85103af 	ldur	x15, [x29, #-240]
   1915c:	a901b3b3 	stp	x19, x12, [x29, #24]
   19160:	f85303ac 	ldur	x12, [x29, #-208]
   19164:	2a1c03f0 	mov	w16, w28
   19168:	aa0103fc 	mov	x28, x1
   1916c:	aa0403e1 	mov	x1, x4
   19170:	aa0603e4 	mov	x4, x6
   19174:	f85483a6 	ldur	x6, [x29, #-184]
   19178:	2a1903e9 	mov	w9, w25
   1917c:	2a0f03ef 	mov	w15, w15
   19180:	2a0c03f8 	mov	w24, w12
   19184:	aa0803f9 	mov	x25, x8
   19188:	aa1003fa 	mov	x26, x16
   1918c:	aa0303e0 	mov	x0, x3
   19190:	aa0503e3 	mov	x3, x5
   19194:	aa1103e5 	mov	x5, x17
   19198:	aa0e03ec 	mov	x12, x14
   1919c:	aa1203ee 	mov	x14, x18
   191a0:	f9000bb8 	str	x24, [x29, #16]
   191a4:	910ac3ff 	add	sp, sp, #0x2b0
   191a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
   191ac:	17fffcee 	b	18564 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0>
   191b0:	f81283af 	stur	x15, [x29, #-216]
   191b4:	aa1803ef 	mov	x15, x24
   191b8:	f81103b6 	stur	x22, [x29, #-240]
   191bc:	34000f37 	cbz	w23, 193a0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x3f8>
   191c0:	a904c3b1 	stp	x17, x16, [x29, #72]
   191c4:	2a0703f1 	mov	w17, w7
   191c8:	2a0b03e7 	mov	w7, w11
   191cc:	a903cbaf 	stp	x15, x18, [x29, #56]
   191d0:	2a1e03eb 	mov	w11, w30
   191d4:	2a0903ed 	mov	w13, w9
   191d8:	f940d3e9 	ldr	x9, [sp, #416]
   191dc:	f9002fab 	str	x11, [x29, #88]
   191e0:	aa0c03ea 	mov	x10, x12
   191e4:	a973afb6 	ldp	x22, x11, [x29, #-200]
   191e8:	2a0203ec 	mov	w12, w2
   191ec:	2a0903e9 	mov	w9, w9
   191f0:	2a1b03e8 	mov	w8, w27
   191f4:	2a1c03f0 	mov	w16, w28
   191f8:	aa0103fc 	mov	x28, x1
   191fc:	aa0403e1 	mov	x1, x4
   19200:	aa0603e4 	mov	x4, x6
   19204:	2a0b03f2 	mov	w18, w11
   19208:	f85283ab 	ldur	x11, [x29, #-216]
   1920c:	f85483a6 	ldur	x6, [x29, #-184]
   19210:	aa1003fa 	mov	x26, x16
   19214:	aa0003fb 	mov	x27, x0
   19218:	aa0303e0 	mov	x0, x3
   1921c:	2a0b03eb 	mov	w11, w11
   19220:	aa0503e3 	mov	x3, x5
   19224:	aa1103e5 	mov	x5, x17
   19228:	a902a7ab 	stp	x11, x9, [x29, #40]
   1922c:	f85103ab 	ldur	x11, [x29, #-240]
   19230:	2a1903e9 	mov	w9, w25
   19234:	aa0803f9 	mov	x25, x8
   19238:	2a0b03ef 	mov	w15, w11
   1923c:	f85083ab 	ldur	x11, [x29, #-248]
   19240:	2a0b03eb 	mov	w11, w11
   19244:	a901b3ab 	stp	x11, x12, [x29, #24]
   19248:	f85303ac 	ldur	x12, [x29, #-208]
   1924c:	aa1303eb 	mov	x11, x19
   19250:	2a0c03f8 	mov	w24, w12
   19254:	aa0e03ec 	mov	x12, x14
   19258:	aa1203ee 	mov	x14, x18
   1925c:	f9000bb8 	str	x24, [x29, #16]
   19260:	910ac3ff 	add	sp, sp, #0x2b0
   19264:	a8c17bfd 	ldp	x29, x30, [sp], #16
   19268:	17fffcbf 	b	18564 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0>
   1926c:	f81003b0 	stur	x16, [x29, #-256]
   19270:	f94016a8 	ldr	x8, [x21, #40]
   19274:	aa1203f7 	mov	x23, x18
   19278:	f900cfe9 	str	x9, [sp, #408]
   1927c:	aa0e03e9 	mov	x9, x14
   19280:	f81083b3 	stur	x19, [x29, #-248]
   19284:	f900d7f1 	str	x17, [sp, #424]
   19288:	f85383aa 	ldur	x10, [x29, #-200]
   1928c:	a97ed953 	ldp	x19, x22, [x10, #-24]
   19290:	b4005508 	cbz	x8, 19d30 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xd88>
   19294:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   19298:	f94096b1 	ldr	x17, [x21, #296]
   1929c:	f85303b8 	ldur	x24, [x29, #-208]
   192a0:	f90016b0 	str	x16, [x21, #40]
   192a4:	d1008230 	sub	x16, x17, #0x20
   192a8:	f90096b0 	str	x16, [x21, #296]
   192ac:	8b080e90 	add	x16, x20, x8, lsl #3
   192b0:	d3607ed1 	lsl	x17, x22, #32
   192b4:	2a1b03f2 	mov	w18, w27
   192b8:	f85483aa 	ldur	x10, [x29, #-184]
   192bc:	a90e4613 	stp	x19, x17, [x16, #224]
   192c0:	2a1c03f1 	mov	w17, w28
   192c4:	2a0d03f3 	mov	w19, w13
   192c8:	a9004612 	stp	x18, x17, [x16]
   192cc:	2a0703f1 	mov	w17, w7
   192d0:	aa1703f2 	mov	x18, x23
   192d4:	a9042a11 	stp	x17, x10, [x16, #64]
   192d8:	2a0b03ea 	mov	w10, w11
   192dc:	a9010600 	stp	x0, x1, [x16, #16]
   192e0:	a9021203 	stp	x3, x4, [x16, #32]
   192e4:	a9031a05 	stp	x5, x6, [x16, #48]
   192e8:	a905320a 	stp	x10, x12, [x16, #80]
   192ec:	14000272 	b	19cb4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xd0c>
   192f0:	f8737a8d 	ldr	x13, [x20, x19, lsl #3]
   192f4:	d358fdad 	lsr	x13, x13, #24
   192f8:	f81103b3 	stur	x19, [x29, #-240]
   192fc:	92409c93 	and	x19, x4, #0xffffffffff
   19300:	f81283b3 	stur	x19, [x29, #-216]
   19304:	f85083b3 	ldur	x19, [x29, #-248]
   19308:	b6ffe924 	tbz	x4, #63, 1902c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x84>
   1930c:	f85283ba 	ldur	x26, [x29, #-216]
   19310:	f87a7a9f 	ldr	xzr, [x20, x26, lsl #3]
   19314:	92409cba 	and	x26, x5, #0xffffffffff
   19318:	b6ffe8e5 	tbz	x5, #63, 19034 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x8c>
   1931c:	f87a7a9f 	ldr	xzr, [x20, x26, lsl #3]
   19320:	f81003b0 	stur	x16, [x29, #-256]
   19324:	f900cbec 	str	x12, [sp, #400]
   19328:	92409ccc 	and	x12, x6, #0xffffffffff
   1932c:	a91873fb 	stp	x27, x28, [sp, #384]
   19330:	f900d7f1 	str	x17, [sp, #424]
   19334:	b6ffe8c6 	tbz	x6, #63, 1904c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xa4>
   19338:	f86c7a9f 	ldr	xzr, [x20, x12, lsl #3]
   1933c:	17ffff44 	b	1904c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xa4>
   19340:	34004577 	cbz	w23, 19bec <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xc44>
   19344:	f85003a8 	ldur	x8, [x29, #-256]
   19348:	f85403aa 	ldur	x10, [x29, #-192]
   1934c:	2a0703f0 	mov	w16, w7
   19350:	2a0b03e7 	mov	w7, w11
   19354:	2a1e03eb 	mov	w11, w30
   19358:	2a0203ec 	mov	w12, w2
   1935c:	f9002ba8 	str	x8, [x29, #80]
   19360:	f940d7ed 	ldr	x13, [sp, #424]
   19364:	f940c3e8 	ldr	x8, [sp, #384]
   19368:	f90027ad 	str	x13, [x29, #72]
   1936c:	2a0803e8 	mov	w8, w8
   19370:	f940c7ed 	ldr	x13, [sp, #392]
   19374:	a903cbb8 	stp	x24, x18, [x29, #56]
   19378:	2a0a03f2 	mov	w18, w10
   1937c:	2a0d03f1 	mov	w17, w13
   19380:	2a0903ed 	mov	w13, w9
   19384:	f940d3e9 	ldr	x9, [sp, #416]
   19388:	f9002fab 	str	x11, [x29, #88]
   1938c:	2a0f03eb 	mov	w11, w15
   19390:	2a0903e9 	mov	w9, w9
   19394:	f9001ba9 	str	x9, [x29, #48]
   19398:	2a1903e9 	mov	w9, w25
   1939c:	14000037 	b	19478 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x4d0>
   193a0:	f81003b0 	stur	x16, [x29, #-256]
   193a4:	f94016a8 	ldr	x8, [x21, #40]
   193a8:	f900cfe9 	str	x9, [sp, #408]
   193ac:	aa0e03e9 	mov	x9, x14
   193b0:	f900d7f1 	str	x17, [sp, #424]
   193b4:	f85383aa 	ldur	x10, [x29, #-200]
   193b8:	a97ed94d 	ldp	x13, x22, [x10, #-24]
   193bc:	b4005f88 	cbz	x8, 19fac <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x1004>
   193c0:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   193c4:	f94096b1 	ldr	x17, [x21, #296]
   193c8:	f85303b8 	ldur	x24, [x29, #-208]
   193cc:	f90016b0 	str	x16, [x21, #40]
   193d0:	d1008230 	sub	x16, x17, #0x20
   193d4:	f90096b0 	str	x16, [x21, #296]
   193d8:	8b080e90 	add	x16, x20, x8, lsl #3
   193dc:	d3607ed1 	lsl	x17, x22, #32
   193e0:	f85483aa 	ldur	x10, [x29, #-184]
   193e4:	f940d3fa 	ldr	x26, [sp, #416]
   193e8:	a90e460d 	stp	x13, x17, [x16, #224]
   193ec:	2a1b03ed 	mov	w13, w27
   193f0:	2a1c03f1 	mov	w17, w28
   193f4:	a900460d 	stp	x13, x17, [x16]
   193f8:	2a0703ed 	mov	w13, w7
   193fc:	a9042a0d 	stp	x13, x10, [x16, #64]
   19400:	2a0b03ea 	mov	w10, w11
   19404:	a9010600 	stp	x0, x1, [x16, #16]
   19408:	a9021203 	stp	x3, x4, [x16, #32]
   1940c:	a9031a05 	stp	x5, x6, [x16, #48]
   19410:	a905320a 	stp	x10, x12, [x16, #80]
   19414:	14000228 	b	19cb4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xd0c>
   19418:	f940d7ed 	ldr	x13, [sp, #424]
   1941c:	34004077 	cbz	w23, 19c28 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xc80>
   19420:	f85003a8 	ldur	x8, [x29, #-256]
   19424:	2a0703f0 	mov	w16, w7
   19428:	2a0b03e7 	mov	w7, w11
   1942c:	2a1e03eb 	mov	w11, w30
   19430:	f85403aa 	ldur	x10, [x29, #-192]
   19434:	f9002ba8 	str	x8, [x29, #80]
   19438:	f940c3e8 	ldr	x8, [sp, #384]
   1943c:	f90027ad 	str	x13, [x29, #72]
   19440:	f940c7ed 	ldr	x13, [sp, #392]
   19444:	a903cbb8 	stp	x24, x18, [x29, #56]
   19448:	2a0a03f2 	mov	w18, w10
   1944c:	2a0803e8 	mov	w8, w8
   19450:	2a0d03f1 	mov	w17, w13
   19454:	2a0903ed 	mov	w13, w9
   19458:	f940d3e9 	ldr	x9, [sp, #416]
   1945c:	f9002fab 	str	x11, [x29, #88]
   19460:	2a0f03eb 	mov	w11, w15
   19464:	2a0903e9 	mov	w9, w9
   19468:	f9001ba9 	str	x9, [x29, #48]
   1946c:	2a1903e9 	mov	w9, w25
   19470:	f940bfec 	ldr	x12, [sp, #376]
   19474:	2a0c03ec 	mov	w12, w12
   19478:	2a1603ef 	mov	w15, w22
   1947c:	a9735baa 	ldp	x10, x22, [x29, #-208]
   19480:	a9022fac 	stp	x12, x11, [x29, #32]
   19484:	2a1303eb 	mov	w11, w19
   19488:	aa0103fc 	mov	x28, x1
   1948c:	f9000fab 	str	x11, [x29, #24]
   19490:	aa0403e1 	mov	x1, x4
   19494:	aa0603e4 	mov	x4, x6
   19498:	2a0a03f3 	mov	w19, w10
   1949c:	f85483a6 	ldur	x6, [x29, #-184]
   194a0:	f940cbea 	ldr	x10, [sp, #400]
   194a4:	aa0803f9 	mov	x25, x8
   194a8:	aa1103fa 	mov	x26, x17
   194ac:	aa0003fb 	mov	x27, x0
   194b0:	aa0303e0 	mov	x0, x3
   194b4:	aa0503e3 	mov	x3, x5
   194b8:	aa1003e5 	mov	x5, x16
   194bc:	5280002b 	mov	w11, #0x1                   	// #1
   194c0:	aa0e03ec 	mov	x12, x14
   194c4:	aa1203ee 	mov	x14, x18
   194c8:	f9000bb3 	str	x19, [x29, #16]
   194cc:	910ac3ff 	add	sp, sp, #0x2b0
   194d0:	a8c17bfd 	ldp	x29, x30, [sp], #16
   194d4:	17fffc24 	b	18564 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0>
   194d8:	b940060d 	ldr	w13, [x16, #4]
   194dc:	b9400211 	ldr	w17, [x16]
   194e0:	92405e32 	and	x18, x17, #0xffffff
   194e4:	f100065f 	cmp	x18, #0x1
   194e8:	54005b01 	b.ne	1a048 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x10a0>  // b.any
   194ec:	aa0d822d 	orr	x13, x17, x13, lsl #32
   194f0:	88dffe1f 	ldar	wzr, [x16]
   194f4:	f94002b0 	ldr	x16, [x21]
   194f8:	d358fdad 	lsr	x13, x13, #24
   194fc:	8b0d0e91 	add	x17, x20, x13, lsl #3
   19500:	a9407233 	ldp	x19, x28, [x17]
   19504:	f8287a90 	str	x16, [x20, x8, lsl #3]
   19508:	f94082b0 	ldr	x16, [x21, #256]
   1950c:	f90002a8 	str	x8, [x21]
   19510:	91000608 	add	x8, x16, #0x1
   19514:	f0000d70 	adrp	x16, 1c8000 <ALC+0x17e00>
   19518:	f90082a8 	str	x8, [x21, #256]
   1951c:	39540210 	ldrb	w16, [x16, #1280]
   19520:	7100061f 	cmp	w16, #0x1
   19524:	54005dc1 	b.ne	1a0dc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x1134>  // b.any
   19528:	f140211f 	cmp	x8, #0x8, lsl #12
   1952c:	54005d82 	b.cs	1a0dc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x1134>  // b.hs, b.nlast
   19530:	f9409bf2 	ldr	x18, [sp, #304]
   19534:	eb0c01bf 	cmp	x13, x12
   19538:	540001a9 	b.ls	1956c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x5c4>  // b.plast
   1953c:	f94006a8 	ldr	x8, [x21, #8]
   19540:	f0000d70 	adrp	x16, 1c8000 <ALC+0x17e00>
   19544:	f82d7a88 	str	x8, [x20, x13, lsl #3]
   19548:	f94086a8 	ldr	x8, [x21, #264]
   1954c:	f90006ad 	str	x13, [x21, #8]
   19550:	91000908 	add	x8, x8, #0x2
   19554:	f90086a8 	str	x8, [x21, #264]
   19558:	39540210 	ldrb	w16, [x16, #1280]
   1955c:	7100061f 	cmp	w16, #0x1
   19560:	54005501 	b.ne	1a000 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x1058>  // b.any
   19564:	f140211f 	cmp	x8, #0x8, lsl #12
   19568:	540054c2 	b.cs	1a000 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x1058>  // b.hs, b.nlast
   1956c:	92409e68 	and	x8, x19, #0xffffffffff
   19570:	8b080e90 	add	x16, x20, x8, lsl #3
   19574:	b7f80133 	tbnz	x19, #63, 19598 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x5f0>
   19578:	a940460d 	ldp	x13, x17, [x16]
   1957c:	aa0803f3 	mov	x19, x8
   19580:	f9400a10 	ldr	x16, [x16, #16]
   19584:	f9008ff1 	str	x17, [sp, #280]
   19588:	f90083f0 	str	x16, [sp, #256]
   1958c:	eb0c011f 	cmp	x8, x12
   19590:	540003c8 	b.hi	19608 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x660>  // b.pmore
   19594:	14000029 	b	19638 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x690>
   19598:	b940060d 	ldr	w13, [x16, #4]
   1959c:	b9400211 	ldr	w17, [x16]
   195a0:	92405e32 	and	x18, x17, #0xffffff
   195a4:	f100065f 	cmp	x18, #0x1
   195a8:	54005661 	b.ne	1a074 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x10cc>  // b.any
   195ac:	aa0d822d 	orr	x13, x17, x13, lsl #32
   195b0:	88dffe1f 	ldar	wzr, [x16]
   195b4:	f94002b0 	ldr	x16, [x21]
   195b8:	d358fdb3 	lsr	x19, x13, #24
   195bc:	8b130e91 	add	x17, x20, x19, lsl #3
   195c0:	a9404a2d 	ldp	x13, x18, [x17]
   195c4:	f9400a31 	ldr	x17, [x17, #16]
   195c8:	f8287a90 	str	x16, [x20, x8, lsl #3]
   195cc:	f94082b0 	ldr	x16, [x21, #256]
   195d0:	f90002a8 	str	x8, [x21]
   195d4:	f9008ff2 	str	x18, [sp, #280]
   195d8:	91000608 	add	x8, x16, #0x1
   195dc:	f0000d70 	adrp	x16, 1c8000 <ALC+0x17e00>
   195e0:	f90083f1 	str	x17, [sp, #256]
   195e4:	f90082a8 	str	x8, [x21, #256]
   195e8:	39540210 	ldrb	w16, [x16, #1280]
   195ec:	7100061f 	cmp	w16, #0x1
   195f0:	54005861 	b.ne	1a0fc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x1154>  // b.any
   195f4:	f140211f 	cmp	x8, #0x8, lsl #12
   195f8:	54005822 	b.cs	1a0fc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x1154>  // b.hs, b.nlast
   195fc:	f9409bf2 	ldr	x18, [sp, #304]
   19600:	eb0c027f 	cmp	x19, x12
   19604:	540001a9 	b.ls	19638 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x690>  // b.plast
   19608:	f9400aa8 	ldr	x8, [x21, #16]
   1960c:	f0000d70 	adrp	x16, 1c8000 <ALC+0x17e00>
   19610:	f8337a88 	str	x8, [x20, x19, lsl #3]
   19614:	f9408aa8 	ldr	x8, [x21, #272]
   19618:	f9000ab3 	str	x19, [x21, #16]
   1961c:	91001108 	add	x8, x8, #0x4
   19620:	f9008aa8 	str	x8, [x21, #272]
   19624:	39540210 	ldrb	w16, [x16, #1280]
   19628:	7100061f 	cmp	w16, #0x1
   1962c:	54004f41 	b.ne	1a014 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x106c>  // b.any
   19630:	f140211f 	cmp	x8, #0x8, lsl #12
   19634:	54004f02 	b.cs	1a014 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x106c>  // b.hs, b.nlast
   19638:	92409f88 	and	x8, x28, #0xffffffffff
   1963c:	f90067fa 	str	x26, [sp, #200]
   19640:	8b080e90 	add	x16, x20, x8, lsl #3
   19644:	b7f8019c 	tbnz	x28, #63, 19674 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x6cc>
   19648:	a941461a 	ldp	x26, x17, [x16, #16]
   1964c:	aa0803f3 	mov	x19, x8
   19650:	a9403202 	ldp	x2, x12, [x16]
   19654:	a90eb3f1 	stp	x17, x12, [sp, #232]
   19658:	a9424211 	ldp	x17, x16, [x16, #32]
   1965c:	52909fec 	mov	w12, #0x84ff                	// #34047
   19660:	72a0620c 	movk	w12, #0x310, lsl #16
   19664:	a90dc7f0 	stp	x16, x17, [sp, #216]
   19668:	eb0c011f 	cmp	x8, x12
   1966c:	540004c8 	b.hi	19704 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x75c>  // b.pmore
   19670:	14000031 	b	19734 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x78c>
   19674:	f900cffb 	str	x27, [sp, #408]
   19678:	b9400612 	ldr	w18, [x16, #4]
   1967c:	b9400213 	ldr	w19, [x16]
   19680:	92405e71 	and	x17, x19, #0xffffff
   19684:	f100063f 	cmp	x17, #0x1
   19688:	54000041 	b.ne	19690 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x6e8>  // b.any
   1968c:	88dffe1f 	ldar	wzr, [x16]
   19690:	aa128272 	orr	x18, x19, x18, lsl #32
   19694:	f100063f 	cmp	x17, #0x1
   19698:	d358fe53 	lsr	x19, x18, #24
   1969c:	8b130e92 	add	x18, x20, x19, lsl #3
   196a0:	a9403242 	ldp	x2, x12, [x18]
   196a4:	f9007bec 	str	x12, [sp, #240]
   196a8:	a941325a 	ldp	x26, x12, [x18, #16]
   196ac:	a9424a5b 	ldp	x27, x18, [x18, #32]
   196b0:	a90e33fb 	stp	x27, x12, [sp, #224]
   196b4:	f9006ff2 	str	x18, [sp, #216]
   196b8:	54004fc1 	b.ne	1a0b0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x1108>  // b.any
   196bc:	f94002b1 	ldr	x17, [x21]
   196c0:	f940cffb 	ldr	x27, [sp, #408]
   196c4:	f9000211 	str	x17, [x16]
   196c8:	f94082b0 	ldr	x16, [x21, #256]
   196cc:	f90002a8 	str	x8, [x21]
   196d0:	91000608 	add	x8, x16, #0x1
   196d4:	f0000d70 	adrp	x16, 1c8000 <ALC+0x17e00>
   196d8:	f90082a8 	str	x8, [x21, #256]
   196dc:	39540210 	ldrb	w16, [x16, #1280]
   196e0:	7100061f 	cmp	w16, #0x1
   196e4:	540051c1 	b.ne	1a11c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x1174>  // b.any
   196e8:	f140211f 	cmp	x8, #0x8, lsl #12
   196ec:	54005182 	b.cs	1a11c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x1174>  // b.hs, b.nlast
   196f0:	f9409bf2 	ldr	x18, [sp, #304]
   196f4:	52909fec 	mov	w12, #0x84ff                	// #34047
   196f8:	72a0620c 	movk	w12, #0x310, lsl #16
   196fc:	eb0c027f 	cmp	x19, x12
   19700:	540001a9 	b.ls	19734 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x78c>  // b.plast
   19704:	f9400ea8 	ldr	x8, [x21, #24]
   19708:	f0000d70 	adrp	x16, 1c8000 <ALC+0x17e00>
   1970c:	f8337a88 	str	x8, [x20, x19, lsl #3]
   19710:	f9408ea8 	ldr	x8, [x21, #280]
   19714:	f9000eb3 	str	x19, [x21, #24]
   19718:	91002108 	add	x8, x8, #0x8
   1971c:	f9008ea8 	str	x8, [x21, #280]
   19720:	39540210 	ldrb	w16, [x16, #1280]
   19724:	7100061f 	cmp	w16, #0x1
   19728:	54004801 	b.ne	1a028 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x1080>  // b.any
   1972c:	f140211f 	cmp	x8, #0x8, lsl #12
   19730:	540047c2 	b.cs	1a028 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x1080>  // b.hs, b.nlast
   19734:	92409da8 	and	x8, x13, #0xffffffffff
   19738:	b7f81e6d 	tbnz	x13, #63, 19b04 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xb5c>
   1973c:	92409dd0 	and	x16, x14, #0xffffffffff
   19740:	b7f81eae 	tbnz	x14, #63, 19b14 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xb6c>
   19744:	92409f11 	and	x17, x24, #0xffffffffff
   19748:	aa1203f3 	mov	x19, x18
   1974c:	b7f81ef8 	tbnz	x24, #63, 19b28 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xb80>
   19750:	f85003ac 	ldur	x12, [x29, #-256]
   19754:	92409d92 	and	x18, x12, #0xffffffffff
   19758:	b7f81f2c 	tbnz	x12, #63, 19b3c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xb94>
   1975c:	f85103bc 	ldur	x28, [x29, #-240]
   19760:	f85303ac 	ldur	x12, [x29, #-208]
   19764:	aa1203e4 	mov	x4, x18
   19768:	f900cfeb 	str	x11, [sp, #408]
   1976c:	f85003aa 	ldur	x10, [x29, #-256]
   19770:	eb0a01bf 	cmp	x13, x10
   19774:	540000c0 	b.eq	1978c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x7e4>  // b.none
   19778:	eb1801bf 	cmp	x13, x24
   1977c:	aa1103e4 	mov	x4, x17
   19780:	54000060 	b.eq	1978c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x7e4>  // b.none
   19784:	eb0e01bf 	cmp	x13, x14
   19788:	9a880204 	csel	x4, x16, x8, eq	// eq = none
   1978c:	f85003ab 	ldur	x11, [x29, #-256]
   19790:	eb1801df 	cmp	x14, x24
   19794:	b900b3fa 	str	w26, [sp, #176]
   19798:	9a900228 	csel	x8, x17, x16, eq	// eq = none
   1979c:	b900a3e2 	str	w2, [sp, #160]
   197a0:	aa0203e7 	mov	x7, x2
   197a4:	eb0b01df 	cmp	x14, x11
   197a8:	a908cbeb 	stp	x11, x18, [sp, #136]
   197ac:	d102c3a2 	sub	x2, x29, #0xb0
   197b0:	9a880248 	csel	x8, x18, x8, eq	// eq = none
   197b4:	eb0b031f 	cmp	x24, x11
   197b8:	f940d3eb 	ldr	x11, [sp, #416]
   197bc:	9a91024a 	csel	x10, x18, x17, eq	// eq = none
   197c0:	a94ec3f1 	ldp	x17, x16, [sp, #232]
   197c4:	b9009bff 	str	wzr, [sp, #152]
   197c8:	aa1403e0 	mov	x0, x20
   197cc:	aa1503e1 	mov	x1, x21
   197d0:	b90073eb 	str	w11, [sp, #112]
   197d4:	aa0d03e3 	mov	x3, x13
   197d8:	f9408fe5 	ldr	x5, [sp, #280]
   197dc:	b900bbf1 	str	w17, [sp, #184]
   197e0:	f94083e6 	ldr	x6, [sp, #256]
   197e4:	b900abf0 	str	w16, [sp, #168]
   197e8:	b9006bef 	str	w15, [sp, #104]
   197ec:	f85083ab 	ldur	x11, [x29, #-248]
   197f0:	b9005bec 	str	w12, [sp, #88]
   197f4:	b90053f6 	str	w22, [sp, #80]
   197f8:	b90063eb 	str	w11, [sp, #96]
   197fc:	b9004bf9 	str	w25, [sp, #72]
   19800:	f85403ab 	ldur	x11, [x29, #-192]
   19804:	b9003be9 	str	w9, [sp, #56]
   19808:	f9406fe9 	ldr	x9, [sp, #216]
   1980c:	b90013f1 	str	w17, [sp, #16]
   19810:	b90023e9 	str	w9, [sp, #32]
   19814:	f94073e9 	ldr	x9, [sp, #224]
   19818:	b90043eb 	str	w11, [sp, #64]
   1981c:	b9001be9 	str	w9, [sp, #24]
   19820:	b9000bfa 	str	w26, [sp, #8]
   19824:	b90003f0 	str	w16, [sp]
   19828:	a907abf8 	stp	x24, x10, [sp, #120]
   1982c:	a902a3ee 	stp	x14, x8, [sp, #40]
   19830:	94019a25 	bl	800c4 <spin_51>
   19834:	b85a03a8 	ldur	w8, [x29, #-96]
   19838:	a97dbfba 	ldp	x26, x15, [x29, #-40]
   1983c:	f85503ad 	ldur	x13, [x29, #-176]
   19840:	3cd583a4 	ldur	q4, [x29, #-168]
   19844:	3cd683a1 	ldur	q1, [x29, #-152]
   19848:	f81403a8 	stur	x8, [x29, #-192]
   1984c:	b85a83a8 	ldur	w8, [x29, #-88]
   19850:	3cd783a2 	ldur	q2, [x29, #-136]
   19854:	3cd883a3 	ldur	q3, [x29, #-120]
   19858:	f85983be 	ldur	x30, [x29, #-104]
   1985c:	b85c03a0 	ldur	w0, [x29, #-64]
   19860:	f81303a8 	stur	x8, [x29, #-208]
   19864:	b85b03a8 	ldur	w8, [x29, #-80]
   19868:	b85c83a7 	ldur	w7, [x29, #-56]
   1986c:	f81083a8 	stur	x8, [x29, #-248]
   19870:	b85b83a8 	ldur	w8, [x29, #-72]
   19874:	f81003a8 	stur	x8, [x29, #-256]
   19878:	b85d03a8 	ldur	w8, [x29, #-48]
   1987c:	f900d3e8 	str	x8, [sp, #416]
   19880:	a97ea3b9 	ldp	x25, x8, [x29, #-24]
   19884:	f9008fe8 	str	x8, [sp, #280]
   19888:	b6f8006d 	tbz	x13, #63, 19894 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x8ec>
   1988c:	92409da8 	and	x8, x13, #0xffffffffff
   19890:	f8687a9f 	ldr	xzr, [x20, x8, lsl #3]
   19894:	a9552fe4 	ldp	x4, x11, [sp, #336]
   19898:	aa1303f8 	mov	x24, x19
   1989c:	a953a3e3 	ldp	x3, x8, [sp, #312]
   198a0:	f940cbea 	ldr	x10, [sp, #400]
   198a4:	a95607e9 	ldp	x9, x1, [sp, #352]
   198a8:	f940d7ee 	ldr	x14, [sp, #424]
   198ac:	b7f814fe 	tbnz	x30, #63, 19b48 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xba0>
   198b0:	f85483a6 	ldur	x6, [x29, #-184]
   198b4:	f940bbf0 	ldr	x16, [sp, #368]
   198b8:	f940a7e5 	ldr	x5, [sp, #328]
   198bc:	b7f8152f 	tbnz	x15, #63, 19b60 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xbb8>
   198c0:	b7f81579 	tbnz	x25, #63, 19b6c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xbc4>
   198c4:	b7f815ab 	tbnz	x11, #63, 19b78 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xbd0>
   198c8:	b7f815e9 	tbnz	x9, #63, 19b84 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xbdc>
   198cc:	b7f81628 	tbnz	x8, #63, 19b90 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xbe8>
   198d0:	b7f81641 	tbnz	x1, #63, 19b98 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xbf0>
   198d4:	b7f81683 	tbnz	x3, #63, 19ba4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xbfc>
   198d8:	b7f816c4 	tbnz	x4, #63, 19bb0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xc08>
   198dc:	aa1b03f6 	mov	x22, x27
   198e0:	b7f8170a 	tbnz	x10, #63, 19bc0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xc18>
   198e4:	b7f81758 	tbnz	x24, #63, 19bcc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xc24>
   198e8:	f94093ec 	ldr	x12, [sp, #288]
   198ec:	2a2c03ec 	mvn	w12, w12
   198f0:	b7f8178e 	tbnz	x14, #63, 19be0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xc38>
   198f4:	5100074e 	sub	w14, w26, #0x1
   198f8:	f81283af 	stur	x15, [x29, #-216]
   198fc:	0a0c01cc 	and	w12, w14, w12
   19900:	f9400aae 	ldr	x14, [x21, #16]
   19904:	531f7993 	lsl	w19, w12, #1
   19908:	8b334e8c 	add	x12, x20, w19, uxtw #3
   1990c:	8b160d9c 	add	x28, x12, x22, lsl #3
   19910:	f940078c 	ldr	x12, [x28, #8]
   19914:	b400232e 	cbz	x14, 19d78 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xdd0>
   19918:	f86e7a8f 	ldr	x15, [x20, x14, lsl #3]
   1991c:	f9408ab1 	ldr	x17, [x21, #272]
   19920:	f9000aaf 	str	x15, [x21, #16]
   19924:	d100122f 	sub	x15, x17, #0x4
   19928:	f9008aaf 	str	x15, [x21, #272]
   1992c:	d378fdaf 	lsr	x15, x13, #56
   19930:	f10009ff 	cmp	x15, #0x2
   19934:	54002580 	b.eq	19de4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xe3c>  // b.none
   19938:	6f00e5e0 	movi	v0.2d, #0xffffffff
   1993c:	8b0e0e8f 	add	x15, x20, x14, lsl #3
   19940:	f90001ed 	str	x13, [x15]
   19944:	4e201c80 	and	v0.16b, v4.16b, v0.16b
   19948:	3c8081e0 	stur	q0, [x15, #8]
   1994c:	f9400eaf 	ldr	x15, [x21, #24]
   19950:	b40027ef 	cbz	x15, 19e4c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xea4>
   19954:	f86f7a8d 	ldr	x13, [x20, x15, lsl #3]
   19958:	f9408eb1 	ldr	x17, [x21, #280]
   1995c:	f9000ead 	str	x13, [x21, #24]
   19960:	d100222d 	sub	x13, x17, #0x8
   19964:	f9008ead 	str	x13, [x21, #280]
   19968:	6f00e5e0 	movi	v0.2d, #0xffffffff
   1996c:	8b0f0e8d 	add	x13, x20, x15, lsl #3
   19970:	4e201c21 	and	v1.16b, v1.16b, v0.16b
   19974:	4e201c42 	and	v2.16b, v2.16b, v0.16b
   19978:	4e201c60 	and	v0.16b, v3.16b, v0.16b
   1997c:	ad0009a1 	stp	q1, q2, [x13]
   19980:	3d8009a0 	str	q0, [x13, #32]
   19984:	f94006ad 	ldr	x13, [x21, #8]
   19988:	b400294d 	cbz	x13, 19eb0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xf08>
   1998c:	f86d7a91 	ldr	x17, [x20, x13, lsl #3]
   19990:	f94086b2 	ldr	x18, [x21, #264]
   19994:	f90006b1 	str	x17, [x21, #8]
   19998:	d1000a51 	sub	x17, x18, #0x2
   1999c:	f90086b1 	str	x17, [x21, #264]
   199a0:	d2c40011 	mov	x17, #0x200000000000        	// #35184372088832
   199a4:	f2e04011 	movk	x17, #0x200, lsl #48
   199a8:	aa1101c2 	orr	x2, x14, x17
   199ac:	d378fc4e 	lsr	x14, x2, #56
   199b0:	f10009df 	cmp	x14, #0x2
   199b4:	54002ae0 	b.eq	19f10 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xf68>  // b.none
   199b8:	d2c4200e 	mov	x14, #0x210000000000        	// #36283883716608
   199bc:	2a1a03fa 	mov	w26, w26
   199c0:	f2e0400e 	movk	x14, #0x200, lsl #48
   199c4:	aa0e01ee 	orr	x14, x15, x14
   199c8:	8b0d0e8f 	add	x15, x20, x13, lsl #3
   199cc:	d378fdd1 	lsr	x17, x14, #56
   199d0:	f90001e2 	str	x2, [x15]
   199d4:	f1000a3f 	cmp	x17, #0x2
   199d8:	54002c20 	b.eq	19f5c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xfb4>  // b.none
   199dc:	52909ff2 	mov	w18, #0x84ff                	// #34047
   199e0:	f90005ee 	str	x14, [x15, #8]
   199e4:	5280002e 	mov	w14, #0x1                   	// #1
   199e8:	3200026f 	orr	w15, w19, #0x1
   199ec:	72a06212 	movk	w18, #0x310, lsl #16
   199f0:	92787d91 	and	x17, x12, #0xffffffff00
   199f4:	8b2f4e8f 	add	x15, x20, w15, uxtw #3
   199f8:	91000652 	add	x18, x18, #0x1
   199fc:	d2c3e013 	mov	x19, #0x1f0000000000        	// #34084860461056
   19a00:	f900038e 	str	x14, [x28]
   19a04:	f940cfee 	ldr	x14, [sp, #408]
   19a08:	f2e04013 	movk	x19, #0x200, lsl #48
   19a0c:	eb12023f 	cmp	x17, x18
   19a10:	aa1301ad 	orr	x13, x13, x19
   19a14:	f83679ed 	str	x13, [x15, x22, lsl #3]
   19a18:	540002c3 	b.cc	19a70 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xac8>  // b.lo, b.ul, b.last
   19a1c:	b100059f 	cmn	x12, #0x1
   19a20:	54000280 	b.eq	19a70 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xac8>  // b.none
   19a24:	9247158d 	and	x13, x12, #0x7e00000000000000
   19a28:	b400024d 	cbz	x13, 19a70 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xac8>
   19a2c:	aa0003f6 	mov	x22, x0
   19a30:	aa1403e0 	mov	x0, x20
   19a34:	aa1503e1 	mov	x1, x21
   19a38:	aa0c03e2 	mov	x2, x12
   19a3c:	aa1e03f3 	mov	x19, x30
   19a40:	aa0703fb 	mov	x27, x7
   19a44:	97ffb154 	bl	5f94 <term_drop>
   19a48:	a95417e8 	ldp	x8, x5, [sp, #320]
   19a4c:	aa1b03e7 	mov	x7, x27
   19a50:	a956c3e1 	ldp	x1, x16, [sp, #360]
   19a54:	aa1603e0 	mov	x0, x22
   19a58:	a9593bea 	ldp	x10, x14, [sp, #400]
   19a5c:	aa1303fe 	mov	x30, x19
   19a60:	a955a7eb 	ldp	x11, x9, [sp, #344]
   19a64:	f9409fe3 	ldr	x3, [sp, #312]
   19a68:	f940abe4 	ldr	x4, [sp, #336]
   19a6c:	f85483a6 	ldur	x6, [x29, #-184]
   19a70:	f85383b6 	ldur	x22, [x29, #-200]
   19a74:	b0000cad 	adrp	x13, 1ae000 <io_eff_rows+0xff0f8>
   19a78:	913fa1ad 	add	x13, x13, #0xfe8
   19a7c:	aa0903fc 	mov	x28, x9
   19a80:	a97027af 	ldp	x15, x9, [x29, #-256]
   19a84:	b85f8ecc 	ldr	w12, [x22, #-8]!
   19a88:	aa0b03fb 	mov	x27, x11
   19a8c:	5280002b 	mov	w11, #0x1                   	// #1
   19a90:	f86c79a2 	ldr	x2, [x13, x12, lsl #3]
   19a94:	f9002bb9 	str	x25, [x29, #80]
   19a98:	f940d7ec 	ldr	x12, [sp, #424]
   19a9c:	a90433b8 	stp	x24, x12, [x29, #64]
   19aa0:	f85283ac 	ldur	x12, [x29, #-216]
   19aa4:	52800398 	mov	w24, #0x1c                  	// #28
   19aa8:	a90333ba 	stp	x26, x12, [x29, #48]
   19aac:	f940d3ec 	ldr	x12, [sp, #416]
   19ab0:	f90017ac 	str	x12, [x29, #40]
   19ab4:	f9408fec 	ldr	x12, [sp, #280]
   19ab8:	f9000fa7 	str	x7, [x29, #24]
   19abc:	2a0e03e7 	mov	w7, w14
   19ac0:	f85303ae 	ldur	x14, [x29, #-208]
   19ac4:	0b050191 	add	w17, w12, w5
   19ac8:	a95833ed 	ldp	x13, x12, [sp, #384]
   19acc:	2a1003e5 	mov	w5, w16
   19ad0:	2a0c03fa 	mov	w26, w12
   19ad4:	f940bfec 	ldr	x12, [sp, #376]
   19ad8:	2a0d03f9 	mov	w25, w13
   19adc:	f85403ad 	ldur	x13, [x29, #-192]
   19ae0:	f9000ba0 	str	x0, [x29, #16]
   19ae4:	aa0803e0 	mov	x0, x8
   19ae8:	2a0c03ec 	mov	w12, w12
   19aec:	f9002fb1 	str	x17, [x29, #88]
   19af0:	f90013ac 	str	x12, [x29, #32]
   19af4:	aa1e03ec 	mov	x12, x30
   19af8:	910ac3ff 	add	sp, sp, #0x2b0
   19afc:	a8c17bfd 	ldp	x29, x30, [sp], #16
   19b00:	d61f0040 	br	x2
   19b04:	f8687a88 	ldr	x8, [x20, x8, lsl #3]
   19b08:	d358fd08 	lsr	x8, x8, #24
   19b0c:	92409dd0 	and	x16, x14, #0xffffffffff
   19b10:	b6ffe1ae 	tbz	x14, #63, 19744 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x79c>
   19b14:	f8707a90 	ldr	x16, [x20, x16, lsl #3]
   19b18:	d358fe10 	lsr	x16, x16, #24
   19b1c:	92409f11 	and	x17, x24, #0xffffffffff
   19b20:	aa1203f3 	mov	x19, x18
   19b24:	b6ffe178 	tbz	x24, #63, 19750 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x7a8>
   19b28:	f8717a91 	ldr	x17, [x20, x17, lsl #3]
   19b2c:	d358fe31 	lsr	x17, x17, #24
   19b30:	f85003ac 	ldur	x12, [x29, #-256]
   19b34:	92409d92 	and	x18, x12, #0xffffffffff
   19b38:	b6ffe12c 	tbz	x12, #63, 1975c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x7b4>
   19b3c:	f8727a92 	ldr	x18, [x20, x18, lsl #3]
   19b40:	d358fe52 	lsr	x18, x18, #24
   19b44:	17ffff06 	b	1975c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x7b4>
   19b48:	92409fcc 	and	x12, x30, #0xffffffffff
   19b4c:	f86c7a9f 	ldr	xzr, [x20, x12, lsl #3]
   19b50:	f85483a6 	ldur	x6, [x29, #-184]
   19b54:	f940bbf0 	ldr	x16, [sp, #368]
   19b58:	f940a7e5 	ldr	x5, [sp, #328]
   19b5c:	b6ffeb2f 	tbz	x15, #63, 198c0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x918>
   19b60:	92409dec 	and	x12, x15, #0xffffffffff
   19b64:	f86c7a9f 	ldr	xzr, [x20, x12, lsl #3]
   19b68:	b6ffeaf9 	tbz	x25, #63, 198c4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x91c>
   19b6c:	92409f2c 	and	x12, x25, #0xffffffffff
   19b70:	f86c7a9f 	ldr	xzr, [x20, x12, lsl #3]
   19b74:	b6ffeaab 	tbz	x11, #63, 198c8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x920>
   19b78:	f87b7a8c 	ldr	x12, [x20, x27, lsl #3]
   19b7c:	d358fd9b 	lsr	x27, x12, #24
   19b80:	b6ffea69 	tbz	x9, #63, 198cc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x924>
   19b84:	92409d2c 	and	x12, x9, #0xffffffffff
   19b88:	f86c7a9f 	ldr	xzr, [x20, x12, lsl #3]
   19b8c:	b6ffea28 	tbz	x8, #63, 198d0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x928>
   19b90:	f87c7a9f 	ldr	xzr, [x20, x28, lsl #3]
   19b94:	b6ffea01 	tbz	x1, #63, 198d4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x92c>
   19b98:	f85283ac 	ldur	x12, [x29, #-216]
   19b9c:	f86c7a9f 	ldr	xzr, [x20, x12, lsl #3]
   19ba0:	b6ffe9c3 	tbz	x3, #63, 198d8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x930>
   19ba4:	f94067ec 	ldr	x12, [sp, #200]
   19ba8:	f86c7a9f 	ldr	xzr, [x20, x12, lsl #3]
   19bac:	b6ffe984 	tbz	x4, #63, 198dc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x934>
   19bb0:	f9406bec 	ldr	x12, [sp, #208]
   19bb4:	f86c7a9f 	ldr	xzr, [x20, x12, lsl #3]
   19bb8:	aa1b03f6 	mov	x22, x27
   19bbc:	b6ffe94a 	tbz	x10, #63, 198e4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x93c>
   19bc0:	92409d4c 	and	x12, x10, #0xffffffffff
   19bc4:	f86c7a9f 	ldr	xzr, [x20, x12, lsl #3]
   19bc8:	b6ffe918 	tbz	x24, #63, 198e8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x940>
   19bcc:	92409f0c 	and	x12, x24, #0xffffffffff
   19bd0:	f86c7a9f 	ldr	xzr, [x20, x12, lsl #3]
   19bd4:	f94093ec 	ldr	x12, [sp, #288]
   19bd8:	2a2c03ec 	mvn	w12, w12
   19bdc:	b6ffe8ce 	tbz	x14, #63, 198f4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x94c>
   19be0:	92409dce 	and	x14, x14, #0xffffffffff
   19be4:	f86e7a9f 	ldr	xzr, [x20, x14, lsl #3]
   19be8:	17ffff43 	b	198f4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x94c>
   19bec:	f900cfe9 	str	x9, [sp, #408]
   19bf0:	f94016a8 	ldr	x8, [x21, #40]
   19bf4:	aa0e03e9 	mov	x9, x14
   19bf8:	f85383aa 	ldur	x10, [x29, #-200]
   19bfc:	f81283af 	stur	x15, [x29, #-216]
   19c00:	aa1803ef 	mov	x15, x24
   19c04:	f81103b6 	stur	x22, [x29, #-240]
   19c08:	a97ecd4d 	ldp	x13, x19, [x10, #-24]
   19c0c:	b5000228 	cbnz	x8, 19c50 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xca8>
   19c10:	f85303b8 	ldur	x24, [x29, #-208]
   19c14:	a91587e0 	stp	x0, x1, [sp, #344]
   19c18:	aa1403e0 	mov	x0, x20
   19c1c:	aa1503e1 	mov	x1, x21
   19c20:	f900bfe2 	str	x2, [sp, #376]
   19c24:	1400014e 	b	1a15c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x11b4>
   19c28:	f900cfe9 	str	x9, [sp, #408]
   19c2c:	f94016a8 	ldr	x8, [x21, #40]
   19c30:	aa0e03e9 	mov	x9, x14
   19c34:	f85383aa 	ldur	x10, [x29, #-200]
   19c38:	f81283af 	stur	x15, [x29, #-216]
   19c3c:	aa1803ef 	mov	x15, x24
   19c40:	f81103b6 	stur	x22, [x29, #-240]
   19c44:	a97ecd4d 	ldp	x13, x19, [x10, #-24]
   19c48:	f940bfe2 	ldr	x2, [sp, #376]
   19c4c:	b4002808 	cbz	x8, 1a14c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x11a4>
   19c50:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   19c54:	f94096b1 	ldr	x17, [x21, #296]
   19c58:	f85303b8 	ldur	x24, [x29, #-208]
   19c5c:	f90016b0 	str	x16, [x21, #40]
   19c60:	d1008230 	sub	x16, x17, #0x20
   19c64:	f90096b0 	str	x16, [x21, #296]
   19c68:	8b080e90 	add	x16, x20, x8, lsl #3
   19c6c:	d3607e71 	lsl	x17, x19, #32
   19c70:	f940d3fa 	ldr	x26, [sp, #416]
   19c74:	52800033 	mov	w19, #0x1                   	// #1
   19c78:	a90e460d 	stp	x13, x17, [x16, #224]
   19c7c:	a95847ea 	ldp	x10, x17, [sp, #384]
   19c80:	a9010600 	stp	x0, x1, [x16, #16]
   19c84:	a9021203 	stp	x3, x4, [x16, #32]
   19c88:	2a0a03ed 	mov	w13, w10
   19c8c:	2a1103f1 	mov	w17, w17
   19c90:	f85483aa 	ldur	x10, [x29, #-184]
   19c94:	a900460d 	stp	x13, x17, [x16]
   19c98:	2a0703ed 	mov	w13, w7
   19c9c:	a9042a0d 	stp	x13, x10, [x16, #64]
   19ca0:	2a0b03ea 	mov	w10, w11
   19ca4:	f9002a0a 	str	x10, [x16, #80]
   19ca8:	f940cbea 	ldr	x10, [sp, #400]
   19cac:	a9031a05 	stp	x5, x6, [x16, #48]
   19cb0:	f9002e0a 	str	x10, [x16, #88]
   19cb4:	a9062613 	stp	x19, x9, [x16, #96]
   19cb8:	f940cfe9 	ldr	x9, [sp, #408]
   19cbc:	f85403aa 	ldur	x10, [x29, #-192]
   19cc0:	2a0903e9 	mov	w9, w9
   19cc4:	2a0a03ea 	mov	w10, w10
   19cc8:	a9072a09 	stp	x9, x10, [x16, #112]
   19ccc:	f85103aa 	ldur	x10, [x29, #-240]
   19cd0:	2a1903e9 	mov	w9, w25
   19cd4:	2a0a03ea 	mov	w10, w10
   19cd8:	a9082a09 	stp	x9, x10, [x16, #128]
   19cdc:	f85083aa 	ldur	x10, [x29, #-248]
   19ce0:	2a1803e9 	mov	w9, w24
   19ce4:	2a0a03ea 	mov	w10, w10
   19ce8:	a9092a09 	stp	x9, x10, [x16, #144]
   19cec:	f85283aa 	ldur	x10, [x29, #-216]
   19cf0:	2a0203e9 	mov	w9, w2
   19cf4:	2a0a03ea 	mov	w10, w10
   19cf8:	a90a2a09 	stp	x9, x10, [x16, #160]
   19cfc:	2a1a03e9 	mov	w9, w26
   19d00:	2a1e03ea 	mov	w10, w30
   19d04:	a90b3e09 	stp	x9, x15, [x16, #176]
   19d08:	f940d7e9 	ldr	x9, [sp, #424]
   19d0c:	a90c2612 	stp	x18, x9, [x16, #192]
   19d10:	d2c5e009 	mov	x9, #0x2f0000000000        	// #51677046505472
   19d14:	f2e0a009 	movk	x9, #0x500, lsl #48
   19d18:	aa090100 	orr	x0, x8, x9
   19d1c:	f85003a8 	ldur	x8, [x29, #-256]
   19d20:	a90d2a08 	stp	x8, x10, [x16, #208]
   19d24:	910ac3ff 	add	sp, sp, #0x2b0
   19d28:	a8c17bfd 	ldp	x29, x30, [sp], #16
   19d2c:	d65f03c0 	ret
   19d30:	f85303b8 	ldur	x24, [x29, #-208]
   19d34:	a91587e0 	stp	x0, x1, [sp, #344]
   19d38:	aa1403e0 	mov	x0, x20
   19d3c:	aa1503e1 	mov	x1, x21
   19d40:	a9170be7 	stp	x7, x2, [sp, #368]
   19d44:	528000a2 	mov	w2, #0x5                   	// #5
   19d48:	a9149bfe 	stp	x30, x6, [sp, #328]
   19d4c:	aa0503ea 	mov	x10, x5
   19d50:	f900b7e4 	str	x4, [sp, #360]
   19d54:	f900a3e3 	str	x3, [sp, #320]
   19d58:	97ffac2e 	bl	4e10 <heap_alloc_miss>
   19d5c:	a9547be3 	ldp	x3, x30, [sp, #320]
   19d60:	aa0003e8 	mov	x8, x0
   19d64:	a9570be7 	ldp	x7, x2, [sp, #368]
   19d68:	aa0a03e5 	mov	x5, x10
   19d6c:	a95613e1 	ldp	x1, x4, [sp, #352]
   19d70:	a95503e6 	ldp	x6, x0, [sp, #336]
   19d74:	17fffd4e 	b	192ac <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x304>
   19d78:	aa0003ef 	mov	x15, x0
   19d7c:	aa1403e0 	mov	x0, x20
   19d80:	aa1503e1 	mov	x1, x21
   19d84:	52800042 	mov	w2, #0x2                   	// #2
   19d88:	aa0603e9 	mov	x9, x6
   19d8c:	aa1e03eb 	mov	x11, x30
   19d90:	aa0703ee 	mov	x14, x7
   19d94:	3c9103a3 	stur	q3, [x29, #-240]
   19d98:	3d804be2 	str	q2, [sp, #288]
   19d9c:	ad0787e4 	stp	q4, q1, [sp, #240]
   19da0:	97ffac1c 	bl	4e10 <heap_alloc_miss>
   19da4:	ad4787e4 	ldp	q4, q1, [sp, #240]
   19da8:	aa0b03fe 	mov	x30, x11
   19dac:	a95417e8 	ldp	x8, x5, [sp, #320]
   19db0:	aa0903e6 	mov	x6, x9
   19db4:	a956c3e1 	ldp	x1, x16, [sp, #360]
   19db8:	aa0e03e7 	mov	x7, x14
   19dbc:	a955a7eb 	ldp	x11, x9, [sp, #344]
   19dc0:	aa0003ee 	mov	x14, x0
   19dc4:	3dc04be2 	ldr	q2, [sp, #288]
   19dc8:	3cd103a3 	ldur	q3, [x29, #-240]
   19dcc:	aa0f03e0 	mov	x0, x15
   19dd0:	f9409fe3 	ldr	x3, [sp, #312]
   19dd4:	f940abe4 	ldr	x4, [sp, #336]
   19dd8:	d378fdaf 	lsr	x15, x13, #56
   19ddc:	f10009ff 	cmp	x15, #0x2
   19de0:	54ffdac1 	b.ne	19938 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x990>  // b.any
   19de4:	aa0003ef 	mov	x15, x0
   19de8:	aa1403e0 	mov	x0, x20
   19dec:	aa1503e1 	mov	x1, x21
   19df0:	aa0d03e2 	mov	x2, x13
   19df4:	52800023 	mov	w3, #0x1                   	// #1
   19df8:	aa0603e9 	mov	x9, x6
   19dfc:	aa1e03eb 	mov	x11, x30
   19e00:	aa0703ed 	mov	x13, x7
   19e04:	3c9103a3 	stur	q3, [x29, #-240]
   19e08:	3d804be2 	str	q2, [sp, #288]
   19e0c:	ad0787e4 	stp	q4, q1, [sp, #240]
   19e10:	97ffacf3 	bl	51dc <rfc_wrap>
   19e14:	ad4787e4 	ldp	q4, q1, [sp, #240]
   19e18:	aa0b03fe 	mov	x30, x11
   19e1c:	a95417e8 	ldp	x8, x5, [sp, #320]
   19e20:	aa0903e6 	mov	x6, x9
   19e24:	a956c3e1 	ldp	x1, x16, [sp, #360]
   19e28:	aa0d03e7 	mov	x7, x13
   19e2c:	a955a7eb 	ldp	x11, x9, [sp, #344]
   19e30:	aa0003ed 	mov	x13, x0
   19e34:	3dc04be2 	ldr	q2, [sp, #288]
   19e38:	3cd103a3 	ldur	q3, [x29, #-240]
   19e3c:	aa0f03e0 	mov	x0, x15
   19e40:	f9409fe3 	ldr	x3, [sp, #312]
   19e44:	f940abe4 	ldr	x4, [sp, #336]
   19e48:	17fffebc 	b	19938 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x990>
   19e4c:	aa0003ed 	mov	x13, x0
   19e50:	aa1403e0 	mov	x0, x20
   19e54:	aa1503e1 	mov	x1, x21
   19e58:	52800062 	mov	w2, #0x3                   	// #3
   19e5c:	aa0603e9 	mov	x9, x6
   19e60:	aa1e03eb 	mov	x11, x30
   19e64:	aa0703ef 	mov	x15, x7
   19e68:	3c9103a3 	stur	q3, [x29, #-240]
   19e6c:	3d804be2 	str	q2, [sp, #288]
   19e70:	3d8043e1 	str	q1, [sp, #256]
   19e74:	97ffabe7 	bl	4e10 <heap_alloc_miss>
   19e78:	aa0b03fe 	mov	x30, x11
   19e7c:	a95417e8 	ldp	x8, x5, [sp, #320]
   19e80:	aa0903e6 	mov	x6, x9
   19e84:	a956c3e1 	ldp	x1, x16, [sp, #360]
   19e88:	a955a7eb 	ldp	x11, x9, [sp, #344]
   19e8c:	aa0f03e7 	mov	x7, x15
   19e90:	3dc043e1 	ldr	q1, [sp, #256]
   19e94:	3dc04be2 	ldr	q2, [sp, #288]
   19e98:	aa0003ef 	mov	x15, x0
   19e9c:	3cd103a3 	ldur	q3, [x29, #-240]
   19ea0:	f9409fe3 	ldr	x3, [sp, #312]
   19ea4:	aa0d03e0 	mov	x0, x13
   19ea8:	f940abe4 	ldr	x4, [sp, #336]
   19eac:	17fffeaf 	b	19968 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x9c0>
   19eb0:	aa0003fb 	mov	x27, x0
   19eb4:	aa1403e0 	mov	x0, x20
   19eb8:	aa1503e1 	mov	x1, x21
   19ebc:	52800022 	mov	w2, #0x1                   	// #1
   19ec0:	aa0603e9 	mov	x9, x6
   19ec4:	aa1e03eb 	mov	x11, x30
   19ec8:	aa0703ed 	mov	x13, x7
   19ecc:	97ffabd1 	bl	4e10 <heap_alloc_miss>
   19ed0:	aa0b03fe 	mov	x30, x11
   19ed4:	a95417e8 	ldp	x8, x5, [sp, #320]
   19ed8:	aa0903e6 	mov	x6, x9
   19edc:	a956c3e1 	ldp	x1, x16, [sp, #360]
   19ee0:	a955a7eb 	ldp	x11, x9, [sp, #344]
   19ee4:	aa0d03e7 	mov	x7, x13
   19ee8:	f9409fe3 	ldr	x3, [sp, #312]
   19eec:	f940abe4 	ldr	x4, [sp, #336]
   19ef0:	aa0003ed 	mov	x13, x0
   19ef4:	aa1b03e0 	mov	x0, x27
   19ef8:	d2c40011 	mov	x17, #0x200000000000        	// #35184372088832
   19efc:	f2e04011 	movk	x17, #0x200, lsl #48
   19f00:	aa1101c2 	orr	x2, x14, x17
   19f04:	d378fc4e 	lsr	x14, x2, #56
   19f08:	f10009df 	cmp	x14, #0x2
   19f0c:	54ffd561 	b.ne	199b8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xa10>  // b.any
   19f10:	aa0003ee 	mov	x14, x0
   19f14:	aa1403e0 	mov	x0, x20
   19f18:	aa1503e1 	mov	x1, x21
   19f1c:	52800023 	mov	w3, #0x1                   	// #1
   19f20:	aa0603e9 	mov	x9, x6
   19f24:	aa1e03eb 	mov	x11, x30
   19f28:	aa0703fb 	mov	x27, x7
   19f2c:	97ffacac 	bl	51dc <rfc_wrap>
   19f30:	aa0b03fe 	mov	x30, x11
   19f34:	a95417e8 	ldp	x8, x5, [sp, #320]
   19f38:	aa0903e6 	mov	x6, x9
   19f3c:	a956c3e1 	ldp	x1, x16, [sp, #360]
   19f40:	a955a7eb 	ldp	x11, x9, [sp, #344]
   19f44:	aa1b03e7 	mov	x7, x27
   19f48:	f9409fe3 	ldr	x3, [sp, #312]
   19f4c:	f940abe4 	ldr	x4, [sp, #336]
   19f50:	aa0003e2 	mov	x2, x0
   19f54:	aa0e03e0 	mov	x0, x14
   19f58:	17fffe98 	b	199b8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xa10>
   19f5c:	aa0003fb 	mov	x27, x0
   19f60:	aa1403e0 	mov	x0, x20
   19f64:	aa1503e1 	mov	x1, x21
   19f68:	aa0e03e2 	mov	x2, x14
   19f6c:	52800023 	mov	w3, #0x1                   	// #1
   19f70:	aa0603e9 	mov	x9, x6
   19f74:	aa1e03eb 	mov	x11, x30
   19f78:	aa0703ee 	mov	x14, x7
   19f7c:	97ffac98 	bl	51dc <rfc_wrap>
   19f80:	aa0b03fe 	mov	x30, x11
   19f84:	a95417e8 	ldp	x8, x5, [sp, #320]
   19f88:	aa0903e6 	mov	x6, x9
   19f8c:	a956c3e1 	ldp	x1, x16, [sp, #360]
   19f90:	a955a7eb 	ldp	x11, x9, [sp, #344]
   19f94:	aa0e03e7 	mov	x7, x14
   19f98:	f9409fe3 	ldr	x3, [sp, #312]
   19f9c:	f940abe4 	ldr	x4, [sp, #336]
   19fa0:	aa0003ee 	mov	x14, x0
   19fa4:	aa1b03e0 	mov	x0, x27
   19fa8:	17fffe8d 	b	199dc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xa34>
   19fac:	f85303b8 	ldur	x24, [x29, #-208]
   19fb0:	a91587e0 	stp	x0, x1, [sp, #344]
   19fb4:	aa1403e0 	mov	x0, x20
   19fb8:	aa1503e1 	mov	x1, x21
   19fbc:	a9170be7 	stp	x7, x2, [sp, #368]
   19fc0:	528000a2 	mov	w2, #0x5                   	// #5
   19fc4:	a9149bfe 	stp	x30, x6, [sp, #328]
   19fc8:	aa0503ea 	mov	x10, x5
   19fcc:	aa0303f7 	mov	x23, x3
   19fd0:	f900b7e4 	str	x4, [sp, #360]
   19fd4:	f9009bf2 	str	x18, [sp, #304]
   19fd8:	97ffab8e 	bl	4e10 <heap_alloc_miss>
   19fdc:	a9549bfe 	ldp	x30, x6, [sp, #328]
   19fe0:	aa0003e8 	mov	x8, x0
   19fe4:	a9570be7 	ldp	x7, x2, [sp, #368]
   19fe8:	aa1703e3 	mov	x3, x23
   19fec:	a95613e1 	ldp	x1, x4, [sp, #352]
   19ff0:	aa0a03e5 	mov	x5, x10
   19ff4:	f9409bf2 	ldr	x18, [sp, #304]
   19ff8:	f940afe0 	ldr	x0, [sp, #344]
   19ffc:	17fffcf7 	b	193d8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x430>
   1a000:	aa1403e0 	mov	x0, x20
   1a004:	aa1503e1 	mov	x1, x21
   1a008:	52800022 	mov	w2, #0x1                   	// #1
   1a00c:	97ffa96d 	bl	45c0 <heap_hand>
   1a010:	14000017 	b	1a06c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x10c4>
   1a014:	aa1403e0 	mov	x0, x20
   1a018:	aa1503e1 	mov	x1, x21
   1a01c:	52800042 	mov	w2, #0x2                   	// #2
   1a020:	97ffa968 	bl	45c0 <heap_hand>
   1a024:	14000021 	b	1a0a8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x1100>
   1a028:	aa1403e0 	mov	x0, x20
   1a02c:	aa1503e1 	mov	x1, x21
   1a030:	aa0203ec 	mov	x12, x2
   1a034:	52800062 	mov	w2, #0x3                   	// #3
   1a038:	97ffa962 	bl	45c0 <heap_hand>
   1a03c:	f9409bf2 	ldr	x18, [sp, #304]
   1a040:	aa0c03e2 	mov	x2, x12
   1a044:	17fffdbc 	b	19734 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x78c>
   1a048:	aa0d8228 	orr	x8, x17, x13, lsl #32
   1a04c:	aa1403e0 	mov	x0, x20
   1a050:	aa1503e1 	mov	x1, x21
   1a054:	52800044 	mov	w4, #0x2                   	// #2
   1a058:	d358fd08 	lsr	x8, x8, #24
   1a05c:	8b080e8d 	add	x13, x20, x8, lsl #3
   1a060:	aa0803e3 	mov	x3, x8
   1a064:	a94071b3 	ldp	x19, x28, [x13]
   1a068:	97ffa989 	bl	468c <span_fade>
   1a06c:	f9409bf2 	ldr	x18, [sp, #304]
   1a070:	17fffd3f 	b	1956c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x5c4>
   1a074:	aa0d8228 	orr	x8, x17, x13, lsl #32
   1a078:	aa1403e0 	mov	x0, x20
   1a07c:	aa1503e1 	mov	x1, x21
   1a080:	aa1303e2 	mov	x2, x19
   1a084:	52800064 	mov	w4, #0x3                   	// #3
   1a088:	d358fd08 	lsr	x8, x8, #24
   1a08c:	8b080e90 	add	x16, x20, x8, lsl #3
   1a090:	aa0803e3 	mov	x3, x8
   1a094:	a940460d 	ldp	x13, x17, [x16]
   1a098:	f9400a10 	ldr	x16, [x16, #16]
   1a09c:	f90083f0 	str	x16, [sp, #256]
   1a0a0:	f9008ff1 	str	x17, [sp, #280]
   1a0a4:	97ffa97a 	bl	468c <span_fade>
   1a0a8:	f9409bf2 	ldr	x18, [sp, #304]
   1a0ac:	17fffd63 	b	19638 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x690>
   1a0b0:	aa1403e0 	mov	x0, x20
   1a0b4:	aa1503e1 	mov	x1, x21
   1a0b8:	aa0203ec 	mov	x12, x2
   1a0bc:	aa1c03e2 	mov	x2, x28
   1a0c0:	aa1303e3 	mov	x3, x19
   1a0c4:	528000c4 	mov	w4, #0x6                   	// #6
   1a0c8:	97ffa971 	bl	468c <span_fade>
   1a0cc:	f9409bf2 	ldr	x18, [sp, #304]
   1a0d0:	f940cffb 	ldr	x27, [sp, #408]
   1a0d4:	aa0c03e2 	mov	x2, x12
   1a0d8:	17fffd97 	b	19734 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x78c>
   1a0dc:	aa1403e0 	mov	x0, x20
   1a0e0:	aa1503e1 	mov	x1, x21
   1a0e4:	2a1f03e2 	mov	w2, wzr
   1a0e8:	97ffa936 	bl	45c0 <heap_hand>
   1a0ec:	f9409bf2 	ldr	x18, [sp, #304]
   1a0f0:	eb0c01bf 	cmp	x13, x12
   1a0f4:	54ffa248 	b.hi	1953c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x594>  // b.pmore
   1a0f8:	17fffd1d 	b	1956c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x5c4>
   1a0fc:	aa1403e0 	mov	x0, x20
   1a100:	aa1503e1 	mov	x1, x21
   1a104:	2a1f03e2 	mov	w2, wzr
   1a108:	97ffa92e 	bl	45c0 <heap_hand>
   1a10c:	f9409bf2 	ldr	x18, [sp, #304]
   1a110:	eb0c027f 	cmp	x19, x12
   1a114:	54ffa7a8 	b.hi	19608 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x660>  // b.pmore
   1a118:	17fffd48 	b	19638 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x690>
   1a11c:	aa1403e0 	mov	x0, x20
   1a120:	aa1503e1 	mov	x1, x21
   1a124:	aa0203fc 	mov	x28, x2
   1a128:	2a1f03e2 	mov	w2, wzr
   1a12c:	97ffa925 	bl	45c0 <heap_hand>
   1a130:	aa1c03e2 	mov	x2, x28
   1a134:	f9409bf2 	ldr	x18, [sp, #304]
   1a138:	52909fec 	mov	w12, #0x84ff                	// #34047
   1a13c:	72a0620c 	movk	w12, #0x310, lsl #16
   1a140:	eb0c027f 	cmp	x19, x12
   1a144:	54ffae08 	b.hi	19704 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x75c>  // b.pmore
   1a148:	17fffd7b 	b	19734 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x78c>
   1a14c:	f85303b8 	ldur	x24, [x29, #-208]
   1a150:	a91587e0 	stp	x0, x1, [sp, #344]
   1a154:	aa1403e0 	mov	x0, x20
   1a158:	aa1503e1 	mov	x1, x21
   1a15c:	528000a2 	mov	w2, #0x5                   	// #5
   1a160:	f900abe6 	str	x6, [sp, #336]
   1a164:	aa0503ea 	mov	x10, x5
   1a168:	a9169fe4 	stp	x4, x7, [sp, #360]
   1a16c:	aa0303f6 	mov	x22, x3
   1a170:	aa1e03f7 	mov	x23, x30
   1a174:	f9009bf2 	str	x18, [sp, #304]
   1a178:	97ffab26 	bl	4e10 <heap_alloc_miss>
   1a17c:	a9570be7 	ldp	x7, x2, [sp, #368]
   1a180:	aa0003e8 	mov	x8, x0
   1a184:	a95613e1 	ldp	x1, x4, [sp, #352]
   1a188:	aa1703fe 	mov	x30, x23
   1a18c:	a95503e6 	ldp	x6, x0, [sp, #336]
   1a190:	aa1603e3 	mov	x3, x22
   1a194:	f9409bf2 	ldr	x18, [sp, #304]
   1a198:	aa0a03e5 	mov	x5, x10
   1a19c:	17fffeb3 	b	19c68 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xcc0>

