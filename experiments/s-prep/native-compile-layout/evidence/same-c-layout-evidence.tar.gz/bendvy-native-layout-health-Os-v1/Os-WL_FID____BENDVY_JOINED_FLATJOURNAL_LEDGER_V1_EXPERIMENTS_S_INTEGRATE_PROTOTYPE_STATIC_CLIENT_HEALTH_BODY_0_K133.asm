   168bc:	d10403ff 	sub	sp, sp, #0x100
   168c0:	a90f7bfd 	stp	x29, x30, [sp, #240]
   168c4:	9103c3fd 	add	x29, sp, #0xf0
   168c8:	a943c3b1 	ldp	x17, x16, [x29, #56]
   168cc:	f9400bb3 	ldr	x19, [x29, #16]
   168d0:	f81e03b9 	stur	x25, [x29, #-32]
   168d4:	f85e02d8 	ldur	x24, [x22, #-32]
   168d8:	3cde82c0 	ldur	q0, [x22, #-24]
   168dc:	f81e83b3 	stur	x19, [x29, #-24]
   168e0:	f85f82d3 	ldur	x19, [x22, #-8]
   168e4:	f81f03b0 	stur	x16, [x29, #-16]
   168e8:	a944a3b2 	ldp	x18, x8, [x29, #72]
   168ec:	b81d83b7 	stur	w23, [x29, #-40]
   168f0:	a942e7b0 	ldp	x16, x25, [x29, #40]
   168f4:	a9418bbe 	ldp	x30, x2, [x29, #24]
   168f8:	34000537 	cbz	w23, 1699c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K133+0xe0>
   168fc:	6e004000 	ext	v0.16b, v0.16b, v0.16b, #8
   16900:	6f00e5e2 	movi	v2.2d, #0xffffffff
   16904:	b85d83b7 	ldur	w23, [x29, #-40]
   16908:	2a1a03fa 	mov	w26, w26
   1690c:	2a0503e5 	mov	w5, w5
   16910:	2a0703e7 	mov	w7, w7
   16914:	2a0b03eb 	mov	w11, w11
   16918:	2a0d03ed 	mov	w13, w13
   1691c:	2a0e03ee 	mov	w14, w14
   16920:	2a0903e9 	mov	w9, w9
   16924:	2a0f03ef 	mov	w15, w15
   16928:	4ea01c01 	mov	v1.16b, v0.16b
   1692c:	4e181e60 	mov	v0.d[1], x19
   16930:	aa0803f3 	mov	x19, x8
   16934:	52800568 	mov	w8, #0x2b                  	// #43
   16938:	f90002c8 	str	x8, [x22]
   1693c:	f85f03a8 	ldur	x8, [x29, #-16]
   16940:	4e081f01 	mov	v1.d[0], x24
   16944:	4e221c00 	and	v0.16b, v0.16b, v2.16b
   16948:	4e221c21 	and	v1.16b, v1.16b, v2.16b
   1694c:	ad3f02c1 	stp	q1, q0, [x22, #-32]
   16950:	910022d6 	add	x22, x22, #0x8
   16954:	a903a3b1 	stp	x17, x8, [x29, #56]
   16958:	2a1903e8 	mov	w8, w25
   1695c:	f9001ba8 	str	x8, [x29, #48]
   16960:	2a1003e8 	mov	w8, w16
   16964:	f90017a8 	str	x8, [x29, #40]
   16968:	2a0203e8 	mov	w8, w2
   1696c:	f90013a8 	str	x8, [x29, #32]
   16970:	2a1e03e8 	mov	w8, w30
   16974:	f9000fa8 	str	x8, [x29, #24]
   16978:	f85e03a8 	ldur	x8, [x29, #-32]
   1697c:	a904cfb2 	stp	x18, x19, [x29, #72]
   16980:	2a0803f9 	mov	w25, w8
   16984:	f85e83a8 	ldur	x8, [x29, #-24]
   16988:	2a0803e8 	mov	w8, w8
   1698c:	f9000ba8 	str	x8, [x29, #16]
   16990:	a94f7bfd 	ldp	x29, x30, [sp, #240]
   16994:	910403ff 	add	sp, sp, #0x100
   16998:	17ffe053 	b	eae4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER>
   1699c:	3d8003e0 	str	q0, [sp]
   169a0:	f9401ab7 	ldr	x23, [x21, #48]
   169a4:	f81a03ba 	stur	x26, [x29, #-96]
   169a8:	f9000be5 	str	x5, [sp, #16]
   169ac:	a93af3bb 	stp	x27, x28, [x29, #-88]
   169b0:	a97cf2da 	ldp	x26, x28, [x22, #-56]
   169b4:	a9019ffe 	stp	x30, x7, [sp, #24]
   169b8:	a9028be0 	stp	x0, x2, [sp, #40]
   169bc:	a903afe1 	stp	x1, x11, [sp, #56]
   169c0:	a90493e3 	stp	x3, x4, [sp, #72]
   169c4:	f81d83b9 	stur	x25, [x29, #-40]
   169c8:	a905c7ed 	stp	x13, x17, [sp, #88]
   169cc:	f9003be6 	str	x6, [sp, #112]
   169d0:	a9392ba9 	stp	x9, x10, [x29, #-112]
   169d4:	a93cb3af 	stp	x15, x12, [x29, #-56]
   169d8:	f9003fe8 	str	x8, [sp, #120]
   169dc:	f81c03ae 	stur	x14, [x29, #-64]
   169e0:	f90037f2 	str	x18, [sp, #104]
   169e4:	f81b83b0 	stur	x16, [x29, #-72]
   169e8:	b4000c17 	cbz	x23, 16b68 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K133+0x2ac>
   169ec:	f8777a88 	ldr	x8, [x20, x23, lsl #3]
   169f0:	f9409aa9 	ldr	x9, [x21, #304]
   169f4:	f9001aa8 	str	x8, [x21, #48]
   169f8:	d1010128 	sub	x8, x9, #0x40
   169fc:	f9009aa8 	str	x8, [x21, #304]
   16a00:	8b170e9b 	add	x27, x20, x23, lsl #3
   16a04:	52801fe1 	mov	w1, #0xff                  	// #255
   16a08:	52802102 	mov	w2, #0x108                 	// #264
   16a0c:	91008360 	add	x0, x27, #0x20
   16a10:	97ffb420 	bl	3a90 <memset@plt>
   16a14:	6f00e5e0 	movi	v0.2d, #0xffffffff
   16a18:	2a1803e8 	mov	w8, w24
   16a1c:	3dc003e1 	ldr	q1, [sp]
   16a20:	f9000368 	str	x8, [x27]
   16a24:	52800028 	mov	w8, #0x1                   	// #1
   16a28:	2a1303e9 	mov	w9, w19
   16a2c:	aa1c8108 	orr	x8, x8, x28, lsl #32
   16a30:	f9000f69 	str	x9, [x27, #24]
   16a34:	d2c56009 	mov	x9, #0x2b0000000000        	// #47278999994368
   16a38:	f2e0a009 	movk	x9, #0x500, lsl #48
   16a3c:	4e201c20 	and	v0.16b, v1.16b, v0.16b
   16a40:	a912a37a 	stp	x26, x8, [x27, #296]
   16a44:	aa0902e9 	orr	x9, x23, x9
   16a48:	52800088 	mov	w8, #0x4                   	// #4
   16a4c:	3c808360 	stur	q0, [x27, #8]
   16a50:	a93ca2c9 	stp	x9, x8, [x22, #-56]
   16a54:	f85e03b6 	ldur	x22, [x29, #-32]
   16a58:	f94016a0 	ldr	x0, [x21, #40]
   16a5c:	b4000920 	cbz	x0, 16b80 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K133+0x2c4>
   16a60:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   16a64:	f94096aa 	ldr	x10, [x21, #296]
   16a68:	f90016a8 	str	x8, [x21, #40]
   16a6c:	d1008148 	sub	x8, x10, #0x20
   16a70:	f90096a8 	str	x8, [x21, #296]
   16a74:	f85a03ab 	ldur	x11, [x29, #-96]
   16a78:	8b000e88 	add	x8, x20, x0, lsl #3
   16a7c:	d2c0008a 	mov	x10, #0x400000000           	// #17179869184
   16a80:	a97cb3ad 	ldp	x13, x12, [x29, #-56]
   16a84:	f85e83b1 	ldur	x17, [x29, #-24]
   16a88:	f900710a 	str	x10, [x8, #224]
   16a8c:	2a1603ea 	mov	w10, w22
   16a90:	2a0b03eb 	mov	w11, w11
   16a94:	a9002d0a 	stp	x10, x11, [x8]
   16a98:	f94017eb 	ldr	x11, [sp, #40]
   16a9c:	f9401fea 	ldr	x10, [sp, #56]
   16aa0:	a97bbbb0 	ldp	x16, x14, [x29, #-72]
   16aa4:	f85d83af 	ldur	x15, [x29, #-40]
   16aa8:	a902290b 	stp	x11, x10, [x8, #32]
   16aac:	a944abeb 	ldp	x11, x10, [sp, #72]
   16ab0:	f9006d09 	str	x9, [x8, #216]
   16ab4:	f9403fe9 	ldr	x9, [sp, #120]
   16ab8:	a97acbb3 	ldp	x19, x18, [x29, #-88]
   16abc:	a903290b 	stp	x11, x10, [x8, #48]
   16ac0:	f9400bea 	ldr	x10, [sp, #16]
   16ac4:	f9403beb 	ldr	x11, [sp, #112]
   16ac8:	2a0a03ea 	mov	w10, w10
   16acc:	a9014913 	stp	x19, x18, [x8, #16]
   16ad0:	f900210a 	str	x10, [x8, #64]
   16ad4:	f94013ea 	ldr	x10, [sp, #32]
   16ad8:	2a0a03ea 	mov	w10, w10
   16adc:	a904a90b 	stp	x11, x10, [x8, #72]
   16ae0:	f94023ea 	ldr	x10, [sp, #64]
   16ae4:	f85983ab 	ldur	x11, [x29, #-104]
   16ae8:	2a0a03ea 	mov	w10, w10
   16aec:	a905a90b 	stp	x11, x10, [x8, #88]
   16af0:	f9402fea 	ldr	x10, [sp, #88]
   16af4:	2a0e03eb 	mov	w11, w14
   16af8:	f9003d0b 	str	x11, [x8, #120]
   16afc:	2a0d03eb 	mov	w11, w13
   16b00:	2a0a03ea 	mov	w10, w10
   16b04:	a906a90c 	stp	x12, x10, [x8, #104]
   16b08:	f85903aa 	ldur	x10, [x29, #-112]
   16b0c:	2a0a03ea 	mov	w10, w10
   16b10:	a9082d0a 	stp	x10, x11, [x8, #128]
   16b14:	f9400feb 	ldr	x11, [sp, #24]
   16b18:	2a1103ea 	mov	w10, w17
   16b1c:	2a0b03eb 	mov	w11, w11
   16b20:	a9092d0a 	stp	x10, x11, [x8, #144]
   16b24:	f9401bea 	ldr	x10, [sp, #48]
   16b28:	2a1003eb 	mov	w11, w16
   16b2c:	2a0a03ea 	mov	w10, w10
   16b30:	a90a2d0a 	stp	x10, x11, [x8, #160]
   16b34:	2a0f03ea 	mov	w10, w15
   16b38:	f94033eb 	ldr	x11, [sp, #96]
   16b3c:	f900590a 	str	x10, [x8, #176]
   16b40:	f85f03aa 	ldur	x10, [x29, #-16]
   16b44:	a90ba90b 	stp	x11, x10, [x8, #184]
   16b48:	f94037eb 	ldr	x11, [sp, #104]
   16b4c:	d2c2800a 	mov	x10, #0x140000000000        	// #21990232555520
   16b50:	f2e0a00a 	movk	x10, #0x500, lsl #48
   16b54:	aa0a0000 	orr	x0, x0, x10
   16b58:	a90ca50b 	stp	x11, x9, [x8, #200]
   16b5c:	a94f7bfd 	ldp	x29, x30, [sp, #240]
   16b60:	910403ff 	add	sp, sp, #0x100
   16b64:	d65f03c0 	ret
   16b68:	aa1403e0 	mov	x0, x20
   16b6c:	aa1503e1 	mov	x1, x21
   16b70:	528000c2 	mov	w2, #0x6                   	// #6
   16b74:	97ffb7de 	bl	4aec <heap_alloc_miss>
   16b78:	aa0003f7 	mov	x23, x0
   16b7c:	17ffffa1 	b	16a00 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K133+0x144>
   16b80:	aa1403e0 	mov	x0, x20
   16b84:	aa1503e1 	mov	x1, x21
   16b88:	528000a2 	mov	w2, #0x5                   	// #5
   16b8c:	97ffb7d8 	bl	4aec <heap_alloc_miss>
   16b90:	17ffffb9 	b	16a74 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K133+0x1b8>

