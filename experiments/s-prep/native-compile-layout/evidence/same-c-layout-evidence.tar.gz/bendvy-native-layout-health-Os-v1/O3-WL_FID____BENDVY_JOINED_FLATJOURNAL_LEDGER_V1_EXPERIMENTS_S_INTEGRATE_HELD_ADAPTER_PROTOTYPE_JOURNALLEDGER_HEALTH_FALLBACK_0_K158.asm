   188cc:	d102c3ff 	sub	sp, sp, #0xb0
   188d0:	a90a7bfd 	stp	x29, x30, [sp, #160]
   188d4:	910283fd 	add	x29, sp, #0xa0
   188d8:	a93eb3af 	stp	x15, x12, [x29, #-24]
   188dc:	a943c7b0 	ldp	x16, x17, [x29, #56]
   188e0:	f81e03aa 	stur	x10, [x29, #-32]
   188e4:	aa0603ea 	mov	x10, x6
   188e8:	f9400ba2 	ldr	x2, [x29, #16]
   188ec:	a9449bb2 	ldp	x18, x6, [x29, #72]
   188f0:	b85f82cc 	ldur	w12, [x22, #-8]
   188f4:	a942fbb3 	ldp	x19, x30, [x29, #40]
   188f8:	a941bfb8 	ldp	x24, x15, [x29, #24]
   188fc:	340003b7 	cbz	w23, 18970 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0_K158+0xa4>
   18900:	52800628 	mov	w8, #0x31                  	// #49
   18904:	2a1903f9 	mov	w25, w25
   18908:	2a1a03fa 	mov	w26, w26
   1890c:	a93fa2cc 	stp	x12, x8, [x22, #-8]
   18910:	2a1e03e8 	mov	w8, w30
   18914:	2a1303ec 	mov	w12, w19
   18918:	a902a3ac 	stp	x12, x8, [x29, #40]
   1891c:	2a0f03e8 	mov	w8, w15
   18920:	a9049bb2 	stp	x18, x6, [x29, #72]
   18924:	aa0a03e6 	mov	x6, x10
   18928:	a97e33aa 	ldp	x10, x12, [x29, #-32]
   1892c:	2a0c03ef 	mov	w15, w12
   18930:	2a1803ec 	mov	w12, w24
   18934:	2a0503e5 	mov	w5, w5
   18938:	a901a3ac 	stp	x12, x8, [x29, #24]
   1893c:	2a0203e8 	mov	w8, w2
   18940:	f85f03ac 	ldur	x12, [x29, #-16]
   18944:	2a0703e7 	mov	w7, w7
   18948:	2a0b03eb 	mov	w11, w11
   1894c:	a903c7b0 	stp	x16, x17, [x29, #56]
   18950:	2a0d03ed 	mov	w13, w13
   18954:	2a0e03ee 	mov	w14, w14
   18958:	2a0903e9 	mov	w9, w9
   1895c:	910022d6 	add	x22, x22, #0x8
   18960:	f9000ba8 	str	x8, [x29, #16]
   18964:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   18968:	9102c3ff 	add	sp, sp, #0xb0
   1896c:	17fffb09 	b	17590 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0>
   18970:	a93c4fa2 	stp	x2, x19, [x29, #-64]
   18974:	f94016a8 	ldr	x8, [x21, #40]
   18978:	a93d7baf 	stp	x15, x30, [x29, #-48]
   1897c:	a90447f2 	stp	x18, x17, [sp, #64]
   18980:	f9002bf0 	str	x16, [sp, #80]
   18984:	f81b83a9 	stur	x9, [x29, #-72]
   18988:	a97e26d7 	ldp	x23, x9, [x22, #-32]
   1898c:	b4000a88 	cbz	x8, 18adc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0_K158+0x210>
   18990:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   18994:	f94096b1 	ldr	x17, [x21, #296]
   18998:	f90016b0 	str	x16, [x21, #40]
   1899c:	d1008230 	sub	x16, x17, #0x20
   189a0:	f90096b0 	str	x16, [x21, #296]
   189a4:	52800031 	mov	w17, #0x1                   	// #1
   189a8:	8b080e90 	add	x16, x20, x8, lsl #3
   189ac:	6f07e7e0 	movi	v0.2d, #0xffffffffffffffff
   189b0:	aa098229 	orr	x9, x17, x9, lsl #32
   189b4:	f900020c 	str	x12, [x16]
   189b8:	a90ea617 	stp	x23, x9, [x16, #232]
   189bc:	d2c62009 	mov	x9, #0x310000000000        	// #53876069761024
   189c0:	f2e0a009 	movk	x9, #0x500, lsl #48
   189c4:	3c8d8200 	stur	q0, [x16, #216]
   189c8:	aa090117 	orr	x23, x8, x9
   189cc:	3c8c8200 	stur	q0, [x16, #200]
   189d0:	3c8b8200 	stur	q0, [x16, #184]
   189d4:	3c8a8200 	stur	q0, [x16, #168]
   189d8:	3c898200 	stur	q0, [x16, #152]
   189dc:	3c888200 	stur	q0, [x16, #136]
   189e0:	3c878200 	stur	q0, [x16, #120]
   189e4:	3c868200 	stur	q0, [x16, #104]
   189e8:	3c858200 	stur	q0, [x16, #88]
   189ec:	3c848200 	stur	q0, [x16, #72]
   189f0:	3c838200 	stur	q0, [x16, #56]
   189f4:	3c828200 	stur	q0, [x16, #40]
   189f8:	3c818200 	stur	q0, [x16, #24]
   189fc:	3c808200 	stur	q0, [x16, #8]
   18a00:	a93e46d7 	stp	x23, x17, [x22, #-32]
   18a04:	f94016a8 	ldr	x8, [x21, #40]
   18a08:	b40008a8 	cbz	x8, 18b1c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0_K158+0x250>
   18a0c:	f8687a89 	ldr	x9, [x20, x8, lsl #3]
   18a10:	f94096ac 	ldr	x12, [x21, #296]
   18a14:	f90016a9 	str	x9, [x21, #40]
   18a18:	d1008189 	sub	x9, x12, #0x20
   18a1c:	f90096a9 	str	x9, [x21, #296]
   18a20:	8b080e90 	add	x16, x20, x8, lsl #3
   18a24:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
   18a28:	2a1a03ec 	mov	w12, w26
   18a2c:	a97c4bb5 	ldp	x21, x18, [x29, #-64]
   18a30:	f9007209 	str	x9, [x16, #224]
   18a34:	2a1903e9 	mov	w9, w25
   18a38:	a9003209 	stp	x9, x12, [x16]
   18a3c:	2a0503e9 	mov	w9, w5
   18a40:	a9042a09 	stp	x9, x10, [x16, #64]
   18a44:	2a0703e9 	mov	w9, w7
   18a48:	f9002a09 	str	x9, [x16, #80]
   18a4c:	a97e2ba9 	ldp	x9, x10, [x29, #-32]
   18a50:	a97d47af 	ldp	x15, x17, [x29, #-48]
   18a54:	a901721b 	stp	x27, x28, [x16, #16]
   18a58:	a9020600 	stp	x0, x1, [x16, #32]
   18a5c:	f9002e09 	str	x9, [x16, #88]
   18a60:	2a0b03e9 	mov	w9, w11
   18a64:	2a0e03eb 	mov	w11, w14
   18a68:	f9003209 	str	x9, [x16, #96]
   18a6c:	f85f03a9 	ldur	x9, [x29, #-16]
   18a70:	a9031203 	stp	x3, x4, [x16, #48]
   18a74:	f9003609 	str	x9, [x16, #104]
   18a78:	2a0d03e9 	mov	w9, w13
   18a7c:	a9072e09 	stp	x9, x11, [x16, #112]
   18a80:	f85b83a9 	ldur	x9, [x29, #-72]
   18a84:	2a0a03eb 	mov	w11, w10
   18a88:	2a1203ea 	mov	w10, w18
   18a8c:	2a0903e9 	mov	w9, w9
   18a90:	a9082e09 	stp	x9, x11, [x16, #128]
   18a94:	2a1503e9 	mov	w9, w21
   18a98:	2a1803eb 	mov	w11, w24
   18a9c:	a9092e09 	stp	x9, x11, [x16, #144]
   18aa0:	2a0f03e9 	mov	w9, w15
   18aa4:	a90a2a09 	stp	x9, x10, [x16, #160]
   18aa8:	2a1103e9 	mov	w9, w17
   18aac:	f9005a09 	str	x9, [x16, #176]
   18ab0:	a944abe9 	ldp	x9, x10, [sp, #72]
   18ab4:	a90ba60a 	stp	x10, x9, [x16, #184]
   18ab8:	f94023e9 	ldr	x9, [sp, #64]
   18abc:	a90c9a09 	stp	x9, x6, [x16, #200]
   18ac0:	d2c50009 	mov	x9, #0x280000000000        	// #43980465111040
   18ac4:	f2e0a009 	movk	x9, #0x500, lsl #48
   18ac8:	aa090100 	orr	x0, x8, x9
   18acc:	f9006e17 	str	x23, [x16, #216]
   18ad0:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   18ad4:	9102c3ff 	add	sp, sp, #0xb0
   18ad8:	d65f03c0 	ret
   18adc:	a90303e1 	stp	x1, x0, [sp, #48]
   18ae0:	aa1403e0 	mov	x0, x20
   18ae4:	aa1503e1 	mov	x1, x21
   18ae8:	528000a2 	mov	w2, #0x5                   	// #5
   18aec:	a9009be7 	stp	x7, x6, [sp, #8]
   18af0:	a9022be3 	stp	x3, x10, [sp, #32]
   18af4:	f90003e4 	str	x4, [sp]
   18af8:	f9000fe5 	str	x5, [sp, #24]
   18afc:	97ffb0c5 	bl	4e10 <heap_alloc_miss>
   18b00:	a94117e6 	ldp	x6, x5, [sp, #16]
   18b04:	aa0003e8 	mov	x8, x0
   18b08:	a9401fe4 	ldp	x4, x7, [sp]
   18b0c:	f94013e3 	ldr	x3, [sp, #32]
   18b10:	a94287ea 	ldp	x10, x1, [sp, #40]
   18b14:	f9401fe0 	ldr	x0, [sp, #56]
   18b18:	17ffffa3 	b	189a4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0_K158+0xd8>
   18b1c:	a90303e1 	stp	x1, x0, [sp, #48]
   18b20:	aa1403e0 	mov	x0, x20
   18b24:	aa1503e1 	mov	x1, x21
   18b28:	528000a2 	mov	w2, #0x5                   	// #5
   18b2c:	a90117e6 	stp	x6, x5, [sp, #16]
   18b30:	aa0403e9 	mov	x9, x4
   18b34:	a9022be3 	stp	x3, x10, [sp, #32]
   18b38:	aa0703f5 	mov	x21, x7
   18b3c:	97ffb0b5 	bl	4e10 <heap_alloc_miss>
   18b40:	a94117e6 	ldp	x6, x5, [sp, #16]
   18b44:	aa0003e8 	mov	x8, x0
   18b48:	a94287ea 	ldp	x10, x1, [sp, #40]
   18b4c:	aa1503e7 	mov	x7, x21
   18b50:	f94013e3 	ldr	x3, [sp, #32]
   18b54:	f9401fe0 	ldr	x0, [sp, #56]
   18b58:	aa0903e4 	mov	x4, x9
   18b5c:	17ffffb1 	b	18a20 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0_K158+0x154>

