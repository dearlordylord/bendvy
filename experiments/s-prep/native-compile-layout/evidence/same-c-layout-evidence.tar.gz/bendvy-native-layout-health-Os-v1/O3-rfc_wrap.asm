    51dc:	f81b0fef 	str	x15, [sp, #-80]!
    51e0:	a90137ee 	stp	x14, x13, [sp, #16]
    51e4:	a9022fec 	stp	x12, x11, [sp, #32]
    51e8:	a90327ea 	stp	x10, x9, [sp, #48]
    51ec:	a9047bfd 	stp	x29, x30, [sp, #64]
    51f0:	910103fd 	add	x29, sp, #0x40
    51f4:	d378f848 	ubfx	x8, x2, #56, #7
    51f8:	f100151f 	cmp	x8, #0x5
    51fc:	540003c0 	b.eq	5274 <rfc_wrap+0x98>  // b.none
    5200:	f1000d1f 	cmp	x8, #0x3
    5204:	54000380 	b.eq	5274 <rfc_wrap+0x98>  // b.none
    5208:	f9400028 	ldr	x8, [x1]
    520c:	2a0303ea 	mov	w10, w3
    5210:	aa0203e9 	mov	x9, x2
    5214:	aa0003eb 	mov	x11, x0
    5218:	b4000248 	cbz	x8, 5260 <rfc_wrap+0x84>
    521c:	f8687970 	ldr	x16, [x11, x8, lsl #3]
    5220:	f9408031 	ldr	x17, [x1, #256]
    5224:	f9000030 	str	x16, [x1]
    5228:	d1000630 	sub	x16, x17, #0x1
    522c:	f9008030 	str	x16, [x1, #256]
    5230:	2a0a03f1 	mov	w17, w10
    5234:	92585930 	and	x16, x9, #0x7fffff0000000000
    5238:	aa096231 	orr	x17, x17, x9, lsl #24
    523c:	aa080210 	orr	x16, x16, x8
    5240:	b2410200 	orr	x0, x16, #0x8000000000000000
    5244:	f8287971 	str	x17, [x11, x8, lsl #3]
    5248:	a9447bfd 	ldp	x29, x30, [sp, #64]
    524c:	a94327ea 	ldp	x10, x9, [sp, #48]
    5250:	a9422fec 	ldp	x12, x11, [sp, #32]
    5254:	a94137ee 	ldp	x14, x13, [sp, #16]
    5258:	f84507ef 	ldr	x15, [sp], #80
    525c:	d65f03c0 	ret
    5260:	aa0b03e0 	mov	x0, x11
    5264:	2a1f03e2 	mov	w2, wzr
    5268:	97fffeea 	bl	4e10 <heap_alloc_miss>
    526c:	aa0003e8 	mov	x8, x0
    5270:	17fffff0 	b	5230 <rfc_wrap+0x54>
    5274:	528000c0 	mov	w0, #0x6                   	// #6
    5278:	94000334 	bl	5f48 <err_post>

