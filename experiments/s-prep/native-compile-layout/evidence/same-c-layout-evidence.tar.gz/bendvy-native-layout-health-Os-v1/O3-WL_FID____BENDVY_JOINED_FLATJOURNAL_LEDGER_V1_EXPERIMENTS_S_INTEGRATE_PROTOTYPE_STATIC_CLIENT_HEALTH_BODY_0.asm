   17590:	d10283ff 	sub	sp, sp, #0xa0
   17594:	a9097bfd 	stp	x29, x30, [sp, #144]
   17598:	910243fd 	add	x29, sp, #0x90
   1759c:	a93ebfac 	stp	x12, x15, [x29, #-24]
   175a0:	aa0a03ec 	mov	x12, x10
   175a4:	f9400bb8 	ldr	x24, [x29, #16]
   175a8:	a9448bb1 	ldp	x17, x2, [x29, #72]
   175ac:	a943c3af 	ldp	x15, x16, [x29, #56]
   175b0:	a942cbbe 	ldp	x30, x18, [x29, #40]
   175b4:	a941abb3 	ldp	x19, x10, [x29, #24]
   175b8:	34000397 	cbz	w23, 17628 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0+0x98>
   175bc:	52800528 	mov	w8, #0x29                  	// #41
   175c0:	2a1903f9 	mov	w25, w25
   175c4:	2a1a03fa 	mov	w26, w26
   175c8:	f80086c8 	str	x8, [x22], #8
   175cc:	2a1203e8 	mov	w8, w18
   175d0:	a903c3af 	stp	x15, x16, [x29, #56]
   175d4:	2a1e03f0 	mov	w16, w30
   175d8:	2a0503e5 	mov	w5, w5
   175dc:	a902a3b0 	stp	x16, x8, [x29, #40]
   175e0:	2a0a03e8 	mov	w8, w10
   175e4:	f85f03aa 	ldur	x10, [x29, #-16]
   175e8:	2a1303f0 	mov	w16, w19
   175ec:	a9048bb1 	stp	x17, x2, [x29, #72]
   175f0:	2a0703e7 	mov	w7, w7
   175f4:	2a0a03ef 	mov	w15, w10
   175f8:	a901a3b0 	stp	x16, x8, [x29, #24]
   175fc:	2a1803e8 	mov	w8, w24
   17600:	aa0c03ea 	mov	x10, x12
   17604:	f85e83ac 	ldur	x12, [x29, #-24]
   17608:	2a0b03eb 	mov	w11, w11
   1760c:	2a0d03ed 	mov	w13, w13
   17610:	2a0e03ee 	mov	w14, w14
   17614:	2a0903e9 	mov	w9, w9
   17618:	f9000ba8 	str	x8, [x29, #16]
   1761c:	a9497bfd 	ldp	x29, x30, [sp, #144]
   17620:	910283ff 	add	sp, sp, #0xa0
   17624:	17fff046 	b	1373c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_MAIN>
   17628:	a93dfbaf 	stp	x15, x30, [x29, #-40]
   1762c:	a97ebed7 	ldp	x23, x15, [x22, #-24]
   17630:	f9401aa8 	ldr	x8, [x21, #48]
   17634:	a93c47b2 	stp	x18, x17, [x29, #-64]
   17638:	f81d03b0 	stur	x16, [x29, #-48]
   1763c:	b4000948 	cbz	x8, 17764 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0+0x1d4>
   17640:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   17644:	f9409ab1 	ldr	x17, [x21, #304]
   17648:	f9001ab0 	str	x16, [x21, #48]
   1764c:	d1010230 	sub	x16, x17, #0x40
   17650:	f9009ab0 	str	x16, [x21, #304]
   17654:	6f07e7e0 	movi	v0.2d, #0xffffffffffffffff
   17658:	52800031 	mov	w17, #0x1                   	// #1
   1765c:	8b080e90 	add	x16, x20, x8, lsl #3
   17660:	aa0f822f 	orr	x15, x17, x15, lsl #32
   17664:	d2c52011 	mov	x17, #0x290000000000        	// #45079976738816
   17668:	f85e03b2 	ldur	x18, [x29, #-32]
   1766c:	f2e0a011 	movk	x17, #0x500, lsl #48
   17670:	a9113e17 	stp	x23, x15, [x16, #272]
   17674:	aa110117 	orr	x23, x8, x17
   17678:	ad008200 	stp	q0, q0, [x16, #16]
   1767c:	ad018200 	stp	q0, q0, [x16, #48]
   17680:	ad028200 	stp	q0, q0, [x16, #80]
   17684:	ad038200 	stp	q0, q0, [x16, #112]
   17688:	ad048200 	stp	q0, q0, [x16, #144]
   1768c:	ad058200 	stp	q0, q0, [x16, #176]
   17690:	ad068200 	stp	q0, q0, [x16, #208]
   17694:	ad078200 	stp	q0, q0, [x16, #240]
   17698:	3d800200 	str	q0, [x16]
   1769c:	a93efed7 	stp	x23, xzr, [x22, #-24]
   176a0:	f94016a8 	ldr	x8, [x21, #40]
   176a4:	b4000828 	cbz	x8, 177a8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0+0x218>
   176a8:	f8687a8f 	ldr	x15, [x20, x8, lsl #3]
   176ac:	f94096b0 	ldr	x16, [x21, #296]
   176b0:	f90016af 	str	x15, [x21, #40]
   176b4:	d100820f 	sub	x15, x16, #0x20
   176b8:	f90096af 	str	x15, [x21, #296]
   176bc:	8b080e90 	add	x16, x20, x8, lsl #3
   176c0:	2a0b03eb 	mov	w11, w11
   176c4:	2a1903ef 	mov	w15, w25
   176c8:	2a1a03f1 	mov	w17, w26
   176cc:	2a0a03ea 	mov	w10, w10
   176d0:	f900320b 	str	x11, [x16, #96]
   176d4:	f85e83ab 	ldur	x11, [x29, #-24]
   176d8:	a900460f 	stp	x15, x17, [x16]
   176dc:	2a0503ef 	mov	w15, w5
   176e0:	f900360b 	str	x11, [x16, #104]
   176e4:	2a0d03eb 	mov	w11, w13
   176e8:	2a0e03ed 	mov	w13, w14
   176ec:	a907360b 	stp	x11, x13, [x16, #112]
   176f0:	2a0903eb 	mov	w11, w9
   176f4:	f85f03a9 	ldur	x9, [x29, #-16]
   176f8:	a9041a0f 	stp	x15, x6, [x16, #64]
   176fc:	2a0703ef 	mov	w15, w7
   17700:	2a0903ed 	mov	w13, w9
   17704:	f85c03a9 	ldur	x9, [x29, #-64]
   17708:	a905320f 	stp	x15, x12, [x16, #80]
   1770c:	a908360b 	stp	x11, x13, [x16, #128]
   17710:	2a1803eb 	mov	w11, w24
   17714:	2a1303ec 	mov	w12, w19
   17718:	a909320b 	stp	x11, x12, [x16, #144]
   1771c:	2a1203eb 	mov	w11, w18
   17720:	2a0903e9 	mov	w9, w9
   17724:	a90a2e0a 	stp	x10, x11, [x16, #160]
   17728:	f9005a09 	str	x9, [x16, #176]
   1772c:	a97d2ba9 	ldp	x9, x10, [x29, #-48]
   17730:	a90dfe17 	stp	x23, xzr, [x16, #216]
   17734:	a901721b 	stp	x27, x28, [x16, #16]
   17738:	a90ba60a 	stp	x10, x9, [x16, #184]
   1773c:	f85c83a9 	ldur	x9, [x29, #-56]
   17740:	a9020600 	stp	x0, x1, [x16, #32]
   17744:	a90c8a09 	stp	x9, x2, [x16, #200]
   17748:	d2c3c009 	mov	x9, #0x1e0000000000        	// #32985348833280
   1774c:	f2e0a009 	movk	x9, #0x500, lsl #48
   17750:	a9031203 	stp	x3, x4, [x16, #48]
   17754:	aa090100 	orr	x0, x8, x9
   17758:	a9497bfd 	ldp	x29, x30, [sp, #144]
   1775c:	910283ff 	add	sp, sp, #0xa0
   17760:	d65f03c0 	ret
   17764:	a90403e1 	stp	x1, x0, [sp, #64]
   17768:	aa1403e0 	mov	x0, x20
   1776c:	aa1503e1 	mov	x1, x21
   17770:	a9018be7 	stp	x7, x2, [sp, #24]
   17774:	528000c2 	mov	w2, #0x6                   	// #6
   17778:	a9031be3 	stp	x3, x6, [sp, #48]
   1777c:	a90093ec 	stp	x12, x4, [sp, #8]
   17780:	f90017e5 	str	x5, [sp, #40]
   17784:	97ffb5a3 	bl	4e10 <heap_alloc_miss>
   17788:	a94217e2 	ldp	x2, x5, [sp, #32]
   1778c:	aa0003e8 	mov	x8, x0
   17790:	a94093ec 	ldp	x12, x4, [sp, #8]
   17794:	f9400fe7 	ldr	x7, [sp, #24]
   17798:	a94387e6 	ldp	x6, x1, [sp, #56]
   1779c:	f9401be3 	ldr	x3, [sp, #48]
   177a0:	f94027e0 	ldr	x0, [sp, #72]
   177a4:	17ffffac 	b	17654 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0+0xc4>
   177a8:	a90403e1 	stp	x1, x0, [sp, #64]
   177ac:	aa1403e0 	mov	x0, x20
   177b0:	aa1503e1 	mov	x1, x21
   177b4:	a90217e2 	stp	x2, x5, [sp, #32]
   177b8:	528000a2 	mov	w2, #0x5                   	// #5
   177bc:	aa0403f5 	mov	x21, x4
   177c0:	a9031be3 	stp	x3, x6, [sp, #48]
   177c4:	aa0703f6 	mov	x22, x7
   177c8:	97ffb592 	bl	4e10 <heap_alloc_miss>
   177cc:	a94217e2 	ldp	x2, x5, [sp, #32]
   177d0:	aa0003e8 	mov	x8, x0
   177d4:	a94387e6 	ldp	x6, x1, [sp, #56]
   177d8:	aa1603e7 	mov	x7, x22
   177dc:	f85e03b2 	ldur	x18, [x29, #-32]
   177e0:	f9401be3 	ldr	x3, [sp, #48]
   177e4:	aa1503e4 	mov	x4, x21
   177e8:	f94027e0 	ldr	x0, [sp, #72]
   177ec:	17ffffb4 	b	176bc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0+0x12c>

