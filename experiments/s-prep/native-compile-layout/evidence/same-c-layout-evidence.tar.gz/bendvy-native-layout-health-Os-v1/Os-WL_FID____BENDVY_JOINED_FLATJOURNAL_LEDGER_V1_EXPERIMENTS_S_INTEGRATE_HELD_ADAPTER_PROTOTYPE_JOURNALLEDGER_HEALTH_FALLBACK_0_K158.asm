   175c0:	d103c3ff 	sub	sp, sp, #0xf0
   175c4:	a90e7bfd 	stp	x29, x30, [sp, #224]
   175c8:	910383fd 	add	x29, sp, #0xe0
   175cc:	a941fbb3 	ldp	x19, x30, [x29, #24]
   175d0:	f81f03ac 	stur	x12, [x29, #-16]
   175d4:	a944cbb0 	ldp	x16, x18, [x29, #72]
   175d8:	a9438ba8 	ldp	x8, x2, [x29, #56]
   175dc:	a93e2bb3 	stp	x19, x10, [x29, #-32]
   175e0:	f9400bb3 	ldr	x19, [x29, #16]
   175e4:	a942c7b8 	ldp	x24, x17, [x29, #40]
   175e8:	f81d83b3 	stur	x19, [x29, #-40]
   175ec:	b85f82d3 	ldur	w19, [x22, #-8]
   175f0:	34000437 	cbz	w23, 17674 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0_K158+0xb4>
   175f4:	aa1c03ea 	mov	x10, x28
   175f8:	aa0803fc 	mov	x28, x8
   175fc:	52800628 	mov	w8, #0x31                  	// #49
   17600:	a93fa2d3 	stp	x19, x8, [x22, #-8]
   17604:	2a1103e8 	mov	w8, w17
   17608:	2a1903ec 	mov	w12, w25
   1760c:	a904cbb0 	stp	x16, x18, [x29, #72]
   17610:	2a1803f0 	mov	w16, w24
   17614:	aa0c03f9 	mov	x25, x12
   17618:	a902a3b0 	stp	x16, x8, [x29, #40]
   1761c:	f85e03b0 	ldur	x16, [x29, #-32]
   17620:	2a1e03e8 	mov	w8, w30
   17624:	a9038bbc 	stp	x28, x2, [x29, #56]
   17628:	aa0a03fc 	mov	x28, x10
   1762c:	2a1a03fa 	mov	w26, w26
   17630:	2a1003f0 	mov	w16, w16
   17634:	a97eb3aa 	ldp	x10, x12, [x29, #-24]
   17638:	a901a3b0 	stp	x16, x8, [x29, #24]
   1763c:	f85d83a8 	ldur	x8, [x29, #-40]
   17640:	2a0503e5 	mov	w5, w5
   17644:	2a0703e7 	mov	w7, w7
   17648:	2a0b03eb 	mov	w11, w11
   1764c:	2a0d03ed 	mov	w13, w13
   17650:	2a0803e8 	mov	w8, w8
   17654:	2a0e03ee 	mov	w14, w14
   17658:	2a0903e9 	mov	w9, w9
   1765c:	2a0f03ef 	mov	w15, w15
   17660:	910022d6 	add	x22, x22, #0x8
   17664:	f9000ba8 	str	x8, [x29, #16]
   17668:	a94e7bfd 	ldp	x29, x30, [sp, #224]
   1766c:	9103c3ff 	add	sp, sp, #0xf0
   17670:	17fffb18 	b	162d0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0>
   17674:	f81a03b4 	stur	x20, [x29, #-96]
   17678:	f94016b7 	ldr	x23, [x21, #40]
   1767c:	a9009fe5 	stp	x5, x7, [sp, #8]
   17680:	f81a83bb 	stur	x27, [x29, #-88]
   17684:	f9000feb 	str	x11, [sp, #24]
   17688:	f81b03bc 	stur	x28, [x29, #-80]
   1768c:	a90207e0 	stp	x0, x1, [sp, #32]
   17690:	a9030fed 	stp	x13, x3, [sp, #48]
   17694:	f81b83be 	stur	x30, [x29, #-72]
   17698:	f90023e4 	str	x4, [sp, #64]
   1769c:	f81c03b8 	stur	x24, [x29, #-64]
   176a0:	a97e62db 	ldp	x27, x24, [x22, #-32]
   176a4:	a904c7ee 	stp	x14, x17, [sp, #72]
   176a8:	a905c3e6 	stp	x6, x16, [sp, #88]
   176ac:	f9003be9 	str	x9, [sp, #112]
   176b0:	f81983b2 	stur	x18, [x29, #-104]
   176b4:	a93cbfa8 	stp	x8, x15, [x29, #-56]
   176b8:	f90037e2 	str	x2, [sp, #104]
   176bc:	b4000ab7 	cbz	x23, 17810 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0_K158+0x250>
   176c0:	f85a03b4 	ldur	x20, [x29, #-96]
   176c4:	f94096a9 	ldr	x9, [x21, #296]
   176c8:	f8777a88 	ldr	x8, [x20, x23, lsl #3]
   176cc:	f90016a8 	str	x8, [x21, #40]
   176d0:	d1008128 	sub	x8, x9, #0x20
   176d4:	f90096a8 	str	x8, [x21, #296]
   176d8:	8b170e9c 	add	x28, x20, x23, lsl #3
   176dc:	52801fe1 	mov	w1, #0xff                  	// #255
   176e0:	52801c02 	mov	w2, #0xe0                  	// #224
   176e4:	91002380 	add	x0, x28, #0x8
   176e8:	97ffb0ea 	bl	3a90 <memset@plt>
   176ec:	52800028 	mov	w8, #0x1                   	// #1
   176f0:	d2c62009 	mov	x9, #0x310000000000        	// #53876069761024
   176f4:	f9000393 	str	x19, [x28]
   176f8:	aa18810a 	orr	x10, x8, x24, lsl #32
   176fc:	f2e0a009 	movk	x9, #0x500, lsl #48
   17700:	aa0902e9 	orr	x9, x23, x9
   17704:	a90eab9b 	stp	x27, x10, [x28, #232]
   17708:	a93e22c9 	stp	x9, x8, [x22, #-32]
   1770c:	f94016a0 	ldr	x0, [x21, #40]
   17710:	b40008e0 	cbz	x0, 1782c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0_K158+0x26c>
   17714:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   17718:	f94096aa 	ldr	x10, [x21, #296]
   1771c:	f90016a8 	str	x8, [x21, #40]
   17720:	d1008148 	sub	x8, x10, #0x20
   17724:	f90096a8 	str	x8, [x21, #296]
   17728:	8b000e88 	add	x8, x20, x0, lsl #3
   1772c:	d2c0002a 	mov	x10, #0x100000000           	// #4294967296
   17730:	2a1a03eb 	mov	w11, w26
   17734:	f85f03ac 	ldur	x12, [x29, #-16]
   17738:	a97cb7ae 	ldp	x14, x13, [x29, #-56]
   1773c:	f900710a 	str	x10, [x8, #224]
   17740:	2a1903ea 	mov	w10, w25
   17744:	f85e03b1 	ldur	x17, [x29, #-32]
   17748:	a9002d0a 	stp	x10, x11, [x8]
   1774c:	a9422beb 	ldp	x11, x10, [sp, #32]
   17750:	a97bbfb0 	ldp	x16, x15, [x29, #-72]
   17754:	f9006d09 	str	x9, [x8, #216]
   17758:	a97acbb3 	ldp	x19, x18, [x29, #-88]
   1775c:	f85983a9 	ldur	x9, [x29, #-104]
   17760:	a902290b 	stp	x11, x10, [x8, #32]
   17764:	a943abeb 	ldp	x11, x10, [sp, #56]
   17768:	a9014913 	stp	x19, x18, [x8, #16]
   1776c:	a903290b 	stp	x11, x10, [x8, #48]
   17770:	f94007ea 	ldr	x10, [sp, #8]
   17774:	f9402feb 	ldr	x11, [sp, #88]
   17778:	2a0a03ea 	mov	w10, w10
   1777c:	f900210a 	str	x10, [x8, #64]
   17780:	f9400bea 	ldr	x10, [sp, #16]
   17784:	2a0a03ea 	mov	w10, w10
   17788:	a904a90b 	stp	x11, x10, [x8, #72]
   1778c:	f9400fea 	ldr	x10, [sp, #24]
   17790:	f85e83ab 	ldur	x11, [x29, #-24]
   17794:	2a0a03ea 	mov	w10, w10
   17798:	a905a90b 	stp	x11, x10, [x8, #88]
   1779c:	f9401bea 	ldr	x10, [sp, #48]
   177a0:	f94027eb 	ldr	x11, [sp, #72]
   177a4:	2a0a03ea 	mov	w10, w10
   177a8:	2a0b03eb 	mov	w11, w11
   177ac:	a906a90c 	stp	x12, x10, [x8, #104]
   177b0:	f9403bea 	ldr	x10, [sp, #112]
   177b4:	f9003d0b 	str	x11, [x8, #120]
   177b8:	2a0d03eb 	mov	w11, w13
   177bc:	2a0a03ea 	mov	w10, w10
   177c0:	a9082d0a 	stp	x10, x11, [x8, #128]
   177c4:	f85d83aa 	ldur	x10, [x29, #-40]
   177c8:	2a1103eb 	mov	w11, w17
   177cc:	2a0a03ea 	mov	w10, w10
   177d0:	a9092d0a 	stp	x10, x11, [x8, #144]
   177d4:	2a1003ea 	mov	w10, w16
   177d8:	2a0f03eb 	mov	w11, w15
   177dc:	a90a2d0a 	stp	x10, x11, [x8, #160]
   177e0:	f9402bea 	ldr	x10, [sp, #80]
   177e4:	2a0a03ea 	mov	w10, w10
   177e8:	a90b390a 	stp	x10, x14, [x8, #176]
   177ec:	a9462fea 	ldp	x10, x11, [sp, #96]
   177f0:	a90c290b 	stp	x11, x10, [x8, #192]
   177f4:	d2c5000a 	mov	x10, #0x280000000000        	// #43980465111040
   177f8:	f2e0a00a 	movk	x10, #0x500, lsl #48
   177fc:	aa0a0000 	orr	x0, x0, x10
   17800:	f9006909 	str	x9, [x8, #208]
   17804:	a94e7bfd 	ldp	x29, x30, [sp, #224]
   17808:	9103c3ff 	add	sp, sp, #0xf0
   1780c:	d65f03c0 	ret
   17810:	f85a03b4 	ldur	x20, [x29, #-96]
   17814:	aa1503e1 	mov	x1, x21
   17818:	528000a2 	mov	w2, #0x5                   	// #5
   1781c:	aa1403e0 	mov	x0, x20
   17820:	97ffb4b3 	bl	4aec <heap_alloc_miss>
   17824:	aa0003f7 	mov	x23, x0
   17828:	17ffffac 	b	176d8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0_K158+0x118>
   1782c:	aa1403e0 	mov	x0, x20
   17830:	aa1503e1 	mov	x1, x21
   17834:	528000a2 	mov	w2, #0x5                   	// #5
   17838:	97ffb4ad 	bl	4aec <heap_alloc_miss>
   1783c:	17ffffbb 	b	17728 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0_K158+0x168>

