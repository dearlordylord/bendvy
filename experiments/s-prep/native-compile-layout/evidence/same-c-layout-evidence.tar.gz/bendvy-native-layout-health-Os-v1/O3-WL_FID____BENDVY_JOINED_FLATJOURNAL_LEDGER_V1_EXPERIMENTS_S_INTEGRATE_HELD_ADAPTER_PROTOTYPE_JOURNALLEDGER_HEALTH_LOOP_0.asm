   1aeb4:	d10383ff 	sub	sp, sp, #0xe0
   1aeb8:	a90d7bfd 	stp	x29, x30, [sp, #208]
   1aebc:	910343fd 	add	x29, sp, #0xd0
   1aec0:	aa0b03fe 	mov	x30, x11
   1aec4:	a945a3ab 	ldp	x11, x8, [x29, #88]
   1aec8:	a93eb7a5 	stp	x5, x13, [x29, #-24]
   1aecc:	aa0c03f2 	mov	x18, x12
   1aed0:	aa0703f3 	mov	x19, x7
   1aed4:	a93da3a3 	stp	x3, x8, [x29, #-40]
   1aed8:	aa0103e3 	mov	x3, x1
   1aedc:	aa0003e1 	mov	x1, x0
   1aee0:	a944a3a5 	ldp	x5, x8, [x29, #72]
   1aee4:	aa1c03e0 	mov	x0, x28
   1aee8:	a943b3a2 	ldp	x2, x12, [x29, #56]
   1aeec:	a9429fad 	ldp	x13, x7, [x29, #40]
   1aef0:	aa0903f8 	mov	x24, x9
   1aef4:	a941c3bc 	ldp	x28, x16, [x29, #24]
   1aef8:	f81d03a8 	stur	x8, [x29, #-48]
   1aefc:	92583f28 	and	x8, x25, #0xffff0000000000
   1af00:	d2c1c009 	mov	x9, #0xe0000000000         	// #15393162788864
   1af04:	f9400bb1 	ldr	x17, [x29, #16]
   1af08:	eb09011f 	cmp	x8, x9
   1af0c:	54000541 	b.ne	1afb4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x100>  // b.any
   1af10:	b85f8ec8 	ldr	w8, [x22, #-8]!
   1af14:	90000ca9 	adrp	x9, 1ae000 <io_eff_rows+0xff0f8>
   1af18:	913fa129 	add	x9, x9, #0xfe8
   1af1c:	aa0203f9 	mov	x25, x2
   1af20:	f8687922 	ldr	x2, [x9, x8, lsl #3]
   1af24:	f85d03a8 	ldur	x8, [x29, #-48]
   1af28:	a90397ac 	stp	x12, x5, [x29, #56]
   1af2c:	2a0603e5 	mov	w5, w6
   1af30:	2a0f03e9 	mov	w9, w15
   1af34:	2a1103ef 	mov	w15, w17
   1af38:	a904afa8 	stp	x8, x11, [x29, #72]
   1af3c:	f85e03a8 	ldur	x8, [x29, #-32]
   1af40:	aa1303e6 	mov	x6, x19
   1af44:	2a0803e8 	mov	w8, w8
   1af48:	a905afa8 	stp	x8, x11, [x29, #88]
   1af4c:	2a1903e8 	mov	w8, w25
   1af50:	2a1a03f9 	mov	w25, w26
   1af54:	f9001ba8 	str	x8, [x29, #48]
   1af58:	2a0703e8 	mov	w8, w7
   1af5c:	2a1b03fa 	mov	w26, w27
   1af60:	f90017a8 	str	x8, [x29, #40]
   1af64:	2a0d03e8 	mov	w8, w13
   1af68:	aa0003fb 	mov	x27, x0
   1af6c:	aa0303e0 	mov	x0, x3
   1af70:	aa0403e3 	mov	x3, x4
   1af74:	f90013a8 	str	x8, [x29, #32]
   1af78:	a97eb3a4 	ldp	x4, x12, [x29, #-24]
   1af7c:	2a0a03e7 	mov	w7, w10
   1af80:	2a1c03e8 	mov	w8, w28
   1af84:	2a1003ea 	mov	w10, w16
   1af88:	aa0103fc 	mov	x28, x1
   1af8c:	f85d83a1 	ldur	x1, [x29, #-40]
   1af90:	2a1203eb 	mov	w11, w18
   1af94:	2a0e03ed 	mov	w13, w14
   1af98:	2a1803ee 	mov	w14, w24
   1af9c:	a9012ba8 	stp	x8, x10, [x29, #16]
   1afa0:	52800398 	mov	w24, #0x1c                  	// #28
   1afa4:	aa1e03ea 	mov	x10, x30
   1afa8:	a94d7bfd 	ldp	x29, x30, [sp, #208]
   1afac:	910383ff 	add	sp, sp, #0xe0
   1afb0:	d61f0040 	br	x2
   1afb4:	92409f28 	and	x8, x25, #0xffffffffff
   1afb8:	a93a37be 	stp	x30, x13, [x29, #-96]
   1afbc:	8b080e8d 	add	x13, x20, x8, lsl #3
   1afc0:	b819c3b7 	stur	w23, [x29, #-100]
   1afc4:	a93c1fb0 	stp	x16, x7, [x29, #-64]
   1afc8:	a93b1bbc 	stp	x28, x6, [x29, #-80]
   1afcc:	b7f800d9 	tbnz	x25, #63, 1afe4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x130>
   1afd0:	a9401dbc 	ldp	x28, x7, [x13]
   1afd4:	aa0803e9 	mov	x9, x8
   1afd8:	aa1303fe 	mov	x30, x19
   1afdc:	aa1803f3 	mov	x19, x24
   1afe0:	14000023 	b	1b06c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x1b8>
   1afe4:	a904b3f1 	stp	x17, x12, [sp, #72]
   1afe8:	aa1203ec 	mov	x12, x18
   1afec:	aa0303f7 	mov	x23, x3
   1aff0:	f9002fea 	str	x10, [sp, #88]
   1aff4:	aa0403ea 	mov	x10, x4
   1aff8:	aa1303fe 	mov	x30, x19
   1affc:	b94005a9 	ldr	w9, [x13, #4]
   1b000:	b94001b0 	ldr	w16, [x13]
   1b004:	92405e11 	and	x17, x16, #0xffffff
   1b008:	f100063f 	cmp	x17, #0x1
   1b00c:	540004c1 	b.ne	1b0a4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x1f0>  // b.any
   1b010:	aa098209 	orr	x9, x16, x9, lsl #32
   1b014:	88dffdbf 	ldar	wzr, [x13]
   1b018:	f94002ad 	ldr	x13, [x21]
   1b01c:	aa1803f3 	mov	x19, x24
   1b020:	d358fd29 	lsr	x9, x9, #24
   1b024:	8b090e90 	add	x16, x20, x9, lsl #3
   1b028:	a9401e1c 	ldp	x28, x7, [x16]
   1b02c:	f8287a8d 	str	x13, [x20, x8, lsl #3]
   1b030:	f94082ad 	ldr	x13, [x21, #256]
   1b034:	f90002a8 	str	x8, [x21]
   1b038:	910005a8 	add	x8, x13, #0x1
   1b03c:	b0000d6d 	adrp	x13, 1c8000 <ALC+0x17e00>
   1b040:	f90082a8 	str	x8, [x21, #256]
   1b044:	395401ad 	ldrb	w13, [x13, #1280]
   1b048:	710005bf 	cmp	w13, #0x1
   1b04c:	54000601 	b.ne	1b10c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x258>  // b.any
   1b050:	f140211f 	cmp	x8, #0x8, lsl #12
   1b054:	540005c2 	b.cs	1b10c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x258>  // b.hs, b.nlast
   1b058:	aa0a03e4 	mov	x4, x10
   1b05c:	aa0c03f2 	mov	x18, x12
   1b060:	f94027f1 	ldr	x17, [sp, #72]
   1b064:	a9452bec 	ldp	x12, x10, [sp, #80]
   1b068:	aa1703e3 	mov	x3, x23
   1b06c:	aa0f03f8 	mov	x24, x15
   1b070:	92409f88 	and	x8, x28, #0xffffffffff
   1b074:	52909fed 	mov	w13, #0x84ff                	// #34047
   1b078:	f85c83a6 	ldur	x6, [x29, #-56]
   1b07c:	8b080e90 	add	x16, x20, x8, lsl #3
   1b080:	72a0620d 	movk	w13, #0x310, lsl #16
   1b084:	b7f8079c 	tbnz	x28, #63, 1b174 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x2c0>
   1b088:	b9400219 	ldr	w25, [x16]
   1b08c:	b9400a0f 	ldr	w15, [x16, #8]
   1b090:	aa0803fc 	mov	x28, x8
   1b094:	f90033ef 	str	x15, [sp, #96]
   1b098:	eb0d011f 	cmp	x8, x13
   1b09c:	54000c48 	b.hi	1b224 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x370>  // b.pmore
   1b0a0:	1400006d 	b	1b254 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x3a0>
   1b0a4:	aa098208 	orr	x8, x16, x9, lsl #32
   1b0a8:	a90187e0 	stp	x0, x1, [sp, #24]
   1b0ac:	aa1403e0 	mov	x0, x20
   1b0b0:	aa1503e1 	mov	x1, x21
   1b0b4:	f90033e2 	str	x2, [sp, #96]
   1b0b8:	aa1903e2 	mov	x2, x25
   1b0bc:	d358fd03 	lsr	x3, x8, #24
   1b0c0:	52800044 	mov	w4, #0x2                   	// #2
   1b0c4:	f90023ee 	str	x14, [sp, #64]
   1b0c8:	aa1e03ed 	mov	x13, x30
   1b0cc:	f9001be5 	str	x5, [sp, #48]
   1b0d0:	8b030e88 	add	x8, x20, x3, lsl #3
   1b0d4:	a940251c 	ldp	x28, x9, [x8]
   1b0d8:	97ffa56d 	bl	468c <span_fade>
   1b0dc:	a94187e0 	ldp	x0, x1, [sp, #24]
   1b0e0:	aa0a03e4 	mov	x4, x10
   1b0e4:	a94447ee 	ldp	x14, x17, [sp, #64]
   1b0e8:	aa0c03f2 	mov	x18, x12
   1b0ec:	a9458bea 	ldp	x10, x2, [sp, #88]
   1b0f0:	aa0903e7 	mov	x7, x9
   1b0f4:	f9401be5 	ldr	x5, [sp, #48]
   1b0f8:	f9402bec 	ldr	x12, [sp, #80]
   1b0fc:	aa0d03fe 	mov	x30, x13
   1b100:	aa1f03e9 	mov	x9, xzr
   1b104:	aa1703e3 	mov	x3, x23
   1b108:	17ffffb5 	b	1afdc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x128>
   1b10c:	a90187e0 	stp	x0, x1, [sp, #24]
   1b110:	aa1403e0 	mov	x0, x20
   1b114:	aa1503e1 	mov	x1, x21
   1b118:	f90033e2 	str	x2, [sp, #96]
   1b11c:	2a1f03e2 	mov	w2, wzr
   1b120:	aa0703ed 	mov	x13, x7
   1b124:	a900fbef 	stp	x15, x30, [sp, #8]
   1b128:	f90023ee 	str	x14, [sp, #64]
   1b12c:	f9001be5 	str	x5, [sp, #48]
   1b130:	97ffa524 	bl	45c0 <heap_hand>
   1b134:	a94187e0 	ldp	x0, x1, [sp, #24]
   1b138:	aa0a03e4 	mov	x4, x10
   1b13c:	a94447ee 	ldp	x14, x17, [sp, #64]
   1b140:	aa0c03f2 	mov	x18, x12
   1b144:	a940fbf8 	ldp	x24, x30, [sp, #8]
   1b148:	aa0d03e7 	mov	x7, x13
   1b14c:	a9458bea 	ldp	x10, x2, [sp, #88]
   1b150:	aa1703e3 	mov	x3, x23
   1b154:	f9401be5 	ldr	x5, [sp, #48]
   1b158:	f9402bec 	ldr	x12, [sp, #80]
   1b15c:	92409f88 	and	x8, x28, #0xffffffffff
   1b160:	52909fed 	mov	w13, #0x84ff                	// #34047
   1b164:	f85c83a6 	ldur	x6, [x29, #-56]
   1b168:	8b080e90 	add	x16, x20, x8, lsl #3
   1b16c:	72a0620d 	movk	w13, #0x310, lsl #16
   1b170:	b6fff8dc 	tbz	x28, #63, 1b088 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x1d4>
   1b174:	a904b3f1 	stp	x17, x12, [sp, #72]
   1b178:	aa0303ef 	mov	x15, x3
   1b17c:	a9034be5 	stp	x5, x18, [sp, #48]
   1b180:	f9002fea 	str	x10, [sp, #88]
   1b184:	aa1803ea 	mov	x10, x24
   1b188:	aa1e03f8 	mov	x24, x30
   1b18c:	f90023ee 	str	x14, [sp, #64]
   1b190:	f90017f3 	str	x19, [sp, #40]
   1b194:	aa0403f3 	mov	x19, x4
   1b198:	b9400611 	ldr	w17, [x16, #4]
   1b19c:	b9400212 	ldr	w18, [x16]
   1b1a0:	92405e59 	and	x25, x18, #0xffffff
   1b1a4:	f100073f 	cmp	x25, #0x1
   1b1a8:	54001e21 	b.ne	1b56c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x6b8>  // b.any
   1b1ac:	aa118251 	orr	x17, x18, x17, lsl #32
   1b1b0:	88dffe1f 	ldar	wzr, [x16]
   1b1b4:	f94002b0 	ldr	x16, [x21]
   1b1b8:	d358fe3c 	lsr	x28, x17, #24
   1b1bc:	8b1c0e91 	add	x17, x20, x28, lsl #3
   1b1c0:	b9400239 	ldr	w25, [x17]
   1b1c4:	b9400a2c 	ldr	w12, [x17, #8]
   1b1c8:	f8287a90 	str	x16, [x20, x8, lsl #3]
   1b1cc:	f94082b0 	ldr	x16, [x21, #256]
   1b1d0:	f90002a8 	str	x8, [x21]
   1b1d4:	f90033ec 	str	x12, [sp, #96]
   1b1d8:	91000608 	add	x8, x16, #0x1
   1b1dc:	b0000d70 	adrp	x16, 1c8000 <ALC+0x17e00>
   1b1e0:	f90082a8 	str	x8, [x21, #256]
   1b1e4:	39540210 	ldrb	w16, [x16, #1280]
   1b1e8:	7100061f 	cmp	w16, #0x1
   1b1ec:	540025c1 	b.ne	1b6a4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x7f0>  // b.any
   1b1f0:	f140211f 	cmp	x8, #0x8, lsl #12
   1b1f4:	54002582 	b.cs	1b6a4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x7f0>  // b.hs, b.nlast
   1b1f8:	aa1803fe 	mov	x30, x24
   1b1fc:	aa0a03f8 	mov	x24, x10
   1b200:	aa1303e4 	mov	x4, x19
   1b204:	a94297f3 	ldp	x19, x5, [sp, #40]
   1b208:	f94027f1 	ldr	x17, [sp, #72]
   1b20c:	a943bbf2 	ldp	x18, x14, [sp, #56]
   1b210:	f85c83a6 	ldur	x6, [x29, #-56]
   1b214:	a9452bec 	ldp	x12, x10, [sp, #80]
   1b218:	aa0f03e3 	mov	x3, x15
   1b21c:	eb0d039f 	cmp	x28, x13
   1b220:	540001a9 	b.ls	1b254 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x3a0>  // b.plast
   1b224:	f94006a8 	ldr	x8, [x21, #8]
   1b228:	b0000d70 	adrp	x16, 1c8000 <ALC+0x17e00>
   1b22c:	f83c7a88 	str	x8, [x20, x28, lsl #3]
   1b230:	f94086a8 	ldr	x8, [x21, #264]
   1b234:	f90006bc 	str	x28, [x21, #8]
   1b238:	91000908 	add	x8, x8, #0x2
   1b23c:	f90086a8 	str	x8, [x21, #264]
   1b240:	39540210 	ldrb	w16, [x16, #1280]
   1b244:	7100061f 	cmp	w16, #0x1
   1b248:	54001561 	b.ne	1b4f4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x640>  // b.any
   1b24c:	f140211f 	cmp	x8, #0x8, lsl #12
   1b250:	54001522 	b.cs	1b4f4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x640>  // b.hs, b.nlast
   1b254:	f85c03bc 	ldur	x28, [x29, #-64]
   1b258:	eb0d013f 	cmp	x9, x13
   1b25c:	540001a9 	b.ls	1b290 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x3dc>  // b.plast
   1b260:	f94006a8 	ldr	x8, [x21, #8]
   1b264:	b0000d6d 	adrp	x13, 1c8000 <ALC+0x17e00>
   1b268:	f8297a88 	str	x8, [x20, x9, lsl #3]
   1b26c:	f94086a8 	ldr	x8, [x21, #264]
   1b270:	f90006a9 	str	x9, [x21, #8]
   1b274:	91000908 	add	x8, x8, #0x2
   1b278:	f90086a8 	str	x8, [x21, #264]
   1b27c:	395401ad 	ldrb	w13, [x13, #1280]
   1b280:	710005bf 	cmp	w13, #0x1
   1b284:	54000501 	b.ne	1b324 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x470>  // b.any
   1b288:	f140211f 	cmp	x8, #0x8, lsl #12
   1b28c:	540004c2 	b.cs	1b324 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x470>  // b.hs, b.nlast
   1b290:	b859c3b7 	ldur	w23, [x29, #-100]
   1b294:	340007b7 	cbz	w23, 1b388 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x4d4>
   1b298:	52800788 	mov	w8, #0x3c                  	// #60
   1b29c:	2a1803f0 	mov	w16, w24
   1b2a0:	2a1203ed 	mov	w13, w18
   1b2a4:	a88122c7 	stp	x7, x8, [x22], #16
   1b2a8:	a90497ac 	stp	x12, x5, [x29, #72]
   1b2ac:	aa0403e5 	mov	x5, x4
   1b2b0:	a97d13a8 	ldp	x8, x4, [x29, #-48]
   1b2b4:	a905afa8 	stp	x8, x11, [x29, #88]
   1b2b8:	f85e03a8 	ldur	x8, [x29, #-32]
   1b2bc:	2a0a03eb 	mov	w11, w10
   1b2c0:	2a1303ef 	mov	w15, w19
   1b2c4:	aa1e03ea 	mov	x10, x30
   1b2c8:	2a0803e8 	mov	w8, w8
   1b2cc:	f90037a8 	str	x8, [x29, #104]
   1b2d0:	a97a23ac 	ldp	x12, x8, [x29, #-96]
   1b2d4:	2a0803e8 	mov	w8, w8
   1b2d8:	f9001ba8 	str	x8, [x29, #48]
   1b2dc:	2a1c03e8 	mov	w8, w28
   1b2e0:	2a1b03fc 	mov	w28, w27
   1b2e4:	f90017a8 	str	x8, [x29, #40]
   1b2e8:	a97b27a8 	ldp	x8, x9, [x29, #-80]
   1b2ec:	2a0803e8 	mov	w8, w8
   1b2f0:	2a0903e7 	mov	w7, w9
   1b2f4:	2a0e03e9 	mov	w9, w14
   1b2f8:	f90013a8 	str	x8, [x29, #32]
   1b2fc:	2a1103e8 	mov	w8, w17
   1b300:	f9000fa8 	str	x8, [x29, #24]
   1b304:	a97ebba6 	ldp	x6, x14, [x29, #-24]
   1b308:	2a1a03e8 	mov	w8, w26
   1b30c:	f94033fa 	ldr	x26, [sp, #96]
   1b310:	aa0803fb 	mov	x27, x8
   1b314:	f9000bb0 	str	x16, [x29, #16]
   1b318:	a94d7bfd 	ldp	x29, x30, [sp, #208]
   1b31c:	910383ff 	add	sp, sp, #0xe0
   1b320:	17fff722 	b	18fa8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0>
   1b324:	a90187e0 	stp	x0, x1, [sp, #24]
   1b328:	aa1403e0 	mov	x0, x20
   1b32c:	aa1503e1 	mov	x1, x21
   1b330:	aa0203fc 	mov	x28, x2
   1b334:	52800022 	mov	w2, #0x1                   	// #1
   1b338:	a900fbf8 	stp	x24, x30, [sp, #8]
   1b33c:	a9034be5 	stp	x5, x18, [sp, #48]
   1b340:	aa1303ef 	mov	x15, x19
   1b344:	aa0403f3 	mov	x19, x4
   1b348:	a90447ee 	stp	x14, x17, [sp, #64]
   1b34c:	aa0303f8 	mov	x24, x3
   1b350:	aa0703e9 	mov	x9, x7
   1b354:	97ffa49b 	bl	45c0 <heap_hand>
   1b358:	aa1c03e2 	mov	x2, x28
   1b35c:	a94187e0 	ldp	x0, x1, [sp, #24]
   1b360:	a97c1bbc 	ldp	x28, x6, [x29, #-64]
   1b364:	aa1803e3 	mov	x3, x24
   1b368:	a94447ee 	ldp	x14, x17, [sp, #64]
   1b36c:	aa0903e7 	mov	x7, x9
   1b370:	a9434be5 	ldp	x5, x18, [sp, #48]
   1b374:	aa1303e4 	mov	x4, x19
   1b378:	a940fbf8 	ldp	x24, x30, [sp, #8]
   1b37c:	aa0f03f3 	mov	x19, x15
   1b380:	b859c3b7 	ldur	w23, [x29, #-100]
   1b384:	35fff8b7 	cbnz	w23, 1b298 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x3e4>
   1b388:	a97eb6c9 	ldp	x9, x13, [x22, #-24]
   1b38c:	aa0003ef 	mov	x15, x0
   1b390:	f94016a0 	ldr	x0, [x21, #40]
   1b394:	aa1103f7 	mov	x23, x17
   1b398:	b4001240 	cbz	x0, 1b5e0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x72c>
   1b39c:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   1b3a0:	f94096b0 	ldr	x16, [x21, #296]
   1b3a4:	f90016a8 	str	x8, [x21, #40]
   1b3a8:	d1008208 	sub	x8, x16, #0x20
   1b3ac:	f90096a8 	str	x8, [x21, #296]
   1b3b0:	52800030 	mov	w16, #0x1                   	// #1
   1b3b4:	8b000e88 	add	x8, x20, x0, lsl #3
   1b3b8:	6f07e7e0 	movi	v0.2d, #0xffffffffffffffff
   1b3bc:	aa0d820d 	orr	x13, x16, x13, lsl #32
   1b3c0:	f9000107 	str	x7, [x8]
   1b3c4:	a90eb509 	stp	x9, x13, [x8, #232]
   1b3c8:	d2c78009 	mov	x9, #0x3c0000000000        	// #65970697666560
   1b3cc:	f2e0a009 	movk	x9, #0x500, lsl #48
   1b3d0:	3c8d8100 	stur	q0, [x8, #216]
   1b3d4:	aa090009 	orr	x9, x0, x9
   1b3d8:	3c8c8100 	stur	q0, [x8, #200]
   1b3dc:	3c8b8100 	stur	q0, [x8, #184]
   1b3e0:	3c8a8100 	stur	q0, [x8, #168]
   1b3e4:	3c898100 	stur	q0, [x8, #152]
   1b3e8:	3c888100 	stur	q0, [x8, #136]
   1b3ec:	3c878100 	stur	q0, [x8, #120]
   1b3f0:	3c868100 	stur	q0, [x8, #104]
   1b3f4:	3c858100 	stur	q0, [x8, #88]
   1b3f8:	3c848100 	stur	q0, [x8, #72]
   1b3fc:	3c838100 	stur	q0, [x8, #56]
   1b400:	3c828100 	stur	q0, [x8, #40]
   1b404:	3c818100 	stur	q0, [x8, #24]
   1b408:	3c808100 	stur	q0, [x8, #8]
   1b40c:	a93ec2c9 	stp	x9, x16, [x22, #-24]
   1b410:	f94016a0 	ldr	x0, [x21, #40]
   1b414:	b40011a0 	cbz	x0, 1b648 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x794>
   1b418:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   1b41c:	f94096ad 	ldr	x13, [x21, #296]
   1b420:	f85a03b0 	ldur	x16, [x29, #-96]
   1b424:	f90016a8 	str	x8, [x21, #40]
   1b428:	d10081a8 	sub	x8, x13, #0x20
   1b42c:	f90096a8 	str	x8, [x21, #296]
   1b430:	8b000e88 	add	x8, x20, x0, lsl #3
   1b434:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
   1b438:	a90f3509 	stp	x9, x13, [x8, #240]
   1b43c:	f94033e9 	ldr	x9, [sp, #96]
   1b440:	2a1b03ed 	mov	w13, w27
   1b444:	a902050f 	stp	x15, x1, [x8, #32]
   1b448:	a9002519 	stp	x25, x9, [x8]
   1b44c:	2a1a03e9 	mov	w9, w26
   1b450:	a9013509 	stp	x9, x13, [x8, #16]
   1b454:	f85d83a9 	ldur	x9, [x29, #-40]
   1b458:	a9032503 	stp	x3, x9, [x8, #48]
   1b45c:	f85e83a9 	ldur	x9, [x29, #-24]
   1b460:	a9042504 	stp	x4, x9, [x8, #64]
   1b464:	f85b83a9 	ldur	x9, [x29, #-72]
   1b468:	2a0903e9 	mov	w9, w9
   1b46c:	a9057909 	stp	x9, x30, [x8, #80]
   1b470:	2a0a03e9 	mov	w9, w10
   1b474:	2a1303ea 	mov	w10, w19
   1b478:	a9064109 	stp	x9, x16, [x8, #96]
   1b47c:	2a1203e9 	mov	w9, w18
   1b480:	f9003909 	str	x9, [x8, #112]
   1b484:	f85f03a9 	ldur	x9, [x29, #-16]
   1b488:	f9003d09 	str	x9, [x8, #120]
   1b48c:	2a0e03e9 	mov	w9, w14
   1b490:	a9082909 	stp	x9, x10, [x8, #128]
   1b494:	2a1803e9 	mov	w9, w24
   1b498:	2a1703ea 	mov	w10, w23
   1b49c:	a9092909 	stp	x9, x10, [x8, #144]
   1b4a0:	f85b03a9 	ldur	x9, [x29, #-80]
   1b4a4:	2a1c03ea 	mov	w10, w28
   1b4a8:	2a0903e9 	mov	w9, w9
   1b4ac:	a90a2909 	stp	x9, x10, [x8, #160]
   1b4b0:	f85a83a9 	ldur	x9, [x29, #-88]
   1b4b4:	2a0603ea 	mov	w10, w6
   1b4b8:	2a0903e9 	mov	w9, w9
   1b4bc:	a90b2909 	stp	x9, x10, [x8, #176]
   1b4c0:	2a0203e9 	mov	w9, w2
   1b4c4:	a90c3109 	stp	x9, x12, [x8, #192]
   1b4c8:	f85d03a9 	ldur	x9, [x29, #-48]
   1b4cc:	a90d2505 	stp	x5, x9, [x8, #208]
   1b4d0:	d2c66009 	mov	x9, #0x330000000000        	// #56075093016576
   1b4d4:	f2e0a009 	movk	x9, #0x500, lsl #48
   1b4d8:	aa090000 	orr	x0, x0, x9
   1b4dc:	f85e03a9 	ldur	x9, [x29, #-32]
   1b4e0:	2a0903e9 	mov	w9, w9
   1b4e4:	a90e250b 	stp	x11, x9, [x8, #224]
   1b4e8:	a94d7bfd 	ldp	x29, x30, [sp, #208]
   1b4ec:	910383ff 	add	sp, sp, #0xe0
   1b4f0:	d65f03c0 	ret
   1b4f4:	a90187e0 	stp	x0, x1, [sp, #24]
   1b4f8:	aa1403e0 	mov	x0, x20
   1b4fc:	aa1503e1 	mov	x1, x21
   1b500:	a90063fa 	stp	x26, x24, [sp]
   1b504:	aa0203fa 	mov	x26, x2
   1b508:	52800022 	mov	w2, #0x1                   	// #1
   1b50c:	f9000bfe 	str	x30, [sp, #16]
   1b510:	aa1303ef 	mov	x15, x19
   1b514:	aa0403f3 	mov	x19, x4
   1b518:	a903bbf2 	stp	x18, x14, [sp, #56]
   1b51c:	aa0303f8 	mov	x24, x3
   1b520:	a9052bec 	stp	x12, x10, [sp, #80]
   1b524:	aa0503ec 	mov	x12, x5
   1b528:	aa0703ea 	mov	x10, x7
   1b52c:	f90027f1 	str	x17, [sp, #72]
   1b530:	97ffa424 	bl	45c0 <heap_hand>
   1b534:	aa1a03e2 	mov	x2, x26
   1b538:	a94187e0 	ldp	x0, x1, [sp, #24]
   1b53c:	aa0c03e5 	mov	x5, x12
   1b540:	aa1803e3 	mov	x3, x24
   1b544:	aa0a03e7 	mov	x7, x10
   1b548:	a944b3f1 	ldp	x17, x12, [sp, #72]
   1b54c:	f85c83a6 	ldur	x6, [x29, #-56]
   1b550:	a943bbf2 	ldp	x18, x14, [sp, #56]
   1b554:	f9402fea 	ldr	x10, [sp, #88]
   1b558:	a94063fa 	ldp	x26, x24, [sp]
   1b55c:	aa1303e4 	mov	x4, x19
   1b560:	f9400bfe 	ldr	x30, [sp, #16]
   1b564:	aa0f03f3 	mov	x19, x15
   1b568:	17ffff3b 	b	1b254 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x3a0>
   1b56c:	aa118248 	orr	x8, x18, x17, lsl #32
   1b570:	a90187e0 	stp	x0, x1, [sp, #24]
   1b574:	aa1403e0 	mov	x0, x20
   1b578:	aa1503e1 	mov	x1, x21
   1b57c:	f90003fa 	str	x26, [sp]
   1b580:	aa0203fa 	mov	x26, x2
   1b584:	d358fd03 	lsr	x3, x8, #24
   1b588:	aa1c03e2 	mov	x2, x28
   1b58c:	52800044 	mov	w4, #0x2                   	// #2
   1b590:	aa0703ec 	mov	x12, x7
   1b594:	8b030e88 	add	x8, x20, x3, lsl #3
   1b598:	b9400119 	ldr	w25, [x8]
   1b59c:	b9400908 	ldr	w8, [x8, #8]
   1b5a0:	f90033e8 	str	x8, [sp, #96]
   1b5a4:	97ffa43a 	bl	468c <span_fade>
   1b5a8:	aa0c03e7 	mov	x7, x12
   1b5ac:	a94187e0 	ldp	x0, x1, [sp, #24]
   1b5b0:	aa1803fe 	mov	x30, x24
   1b5b4:	aa0a03f8 	mov	x24, x10
   1b5b8:	aa1303e4 	mov	x4, x19
   1b5bc:	a94297f3 	ldp	x19, x5, [sp, #40]
   1b5c0:	aa1a03e2 	mov	x2, x26
   1b5c4:	a943bbf2 	ldp	x18, x14, [sp, #56]
   1b5c8:	f94003fa 	ldr	x26, [sp]
   1b5cc:	a9452bec 	ldp	x12, x10, [sp, #80]
   1b5d0:	f94027f1 	ldr	x17, [sp, #72]
   1b5d4:	f85c83a6 	ldur	x6, [x29, #-56]
   1b5d8:	aa0f03e3 	mov	x3, x15
   1b5dc:	17ffff1e 	b	1b254 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x3a0>
   1b5e0:	aa1403e0 	mov	x0, x20
   1b5e4:	a9024fe1 	stp	x1, x19, [sp, #32]
   1b5e8:	aa1503e1 	mov	x1, x21
   1b5ec:	a90063fa 	stp	x26, x24, [sp]
   1b5f0:	aa0203fa 	mov	x26, x2
   1b5f4:	528000a2 	mov	w2, #0x5                   	// #5
   1b5f8:	f9000bfe 	str	x30, [sp, #16]
   1b5fc:	aa0403f3 	mov	x19, x4
   1b600:	a903bbf2 	stp	x18, x14, [sp, #56]
   1b604:	a9052bec 	stp	x12, x10, [sp, #80]
   1b608:	aa0303ec 	mov	x12, x3
   1b60c:	aa0703ea 	mov	x10, x7
   1b610:	f9001be5 	str	x5, [sp, #48]
   1b614:	97ffa5ff 	bl	4e10 <heap_alloc_miss>
   1b618:	aa0a03e7 	mov	x7, x10
   1b61c:	aa1a03e2 	mov	x2, x26
   1b620:	aa0c03e3 	mov	x3, x12
   1b624:	a94063fa 	ldp	x26, x24, [sp]
   1b628:	aa1303e4 	mov	x4, x19
   1b62c:	a9452bec 	ldp	x12, x10, [sp, #80]
   1b630:	f85c83a6 	ldur	x6, [x29, #-56]
   1b634:	a94297f3 	ldp	x19, x5, [sp, #40]
   1b638:	f94013e1 	ldr	x1, [sp, #32]
   1b63c:	a943bbf2 	ldp	x18, x14, [sp, #56]
   1b640:	f9400bfe 	ldr	x30, [sp, #16]
   1b644:	17ffff5b 	b	1b3b0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x4fc>
   1b648:	aa1403e0 	mov	x0, x20
   1b64c:	f90013e1 	str	x1, [sp, #32]
   1b650:	aa1503e1 	mov	x1, x21
   1b654:	aa0203f5 	mov	x21, x2
   1b658:	528000a2 	mov	w2, #0x5                   	// #5
   1b65c:	f9000bfe 	str	x30, [sp, #16]
   1b660:	aa0403fc 	mov	x28, x4
   1b664:	a903bbf2 	stp	x18, x14, [sp, #56]
   1b668:	aa0503f6 	mov	x22, x5
   1b66c:	a9052bec 	stp	x12, x10, [sp, #80]
   1b670:	aa0303ea 	mov	x10, x3
   1b674:	97ffa5e7 	bl	4e10 <heap_alloc_miss>
   1b678:	aa0a03e3 	mov	x3, x10
   1b67c:	a9452bec 	ldp	x12, x10, [sp, #80]
   1b680:	a943bbf2 	ldp	x18, x14, [sp, #56]
   1b684:	aa1c03e4 	mov	x4, x28
   1b688:	a97c1bbc 	ldp	x28, x6, [x29, #-64]
   1b68c:	aa1503e2 	mov	x2, x21
   1b690:	f94013e1 	ldr	x1, [sp, #32]
   1b694:	f85a03b0 	ldur	x16, [x29, #-96]
   1b698:	aa1603e5 	mov	x5, x22
   1b69c:	f9400bfe 	ldr	x30, [sp, #16]
   1b6a0:	17ffff64 	b	1b430 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x57c>
   1b6a4:	a90187e0 	stp	x0, x1, [sp, #24]
   1b6a8:	aa1403e0 	mov	x0, x20
   1b6ac:	aa1503e1 	mov	x1, x21
   1b6b0:	f90003fa 	str	x26, [sp]
   1b6b4:	aa0203fa 	mov	x26, x2
   1b6b8:	2a1f03e2 	mov	w2, wzr
   1b6bc:	aa0703ec 	mov	x12, x7
   1b6c0:	97ffa3c0 	bl	45c0 <heap_hand>
   1b6c4:	a94187e0 	ldp	x0, x1, [sp, #24]
   1b6c8:	aa1a03e2 	mov	x2, x26
   1b6cc:	f94003fa 	ldr	x26, [sp]
   1b6d0:	aa0c03e7 	mov	x7, x12
   1b6d4:	17fffec9 	b	1b1f8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x344>

