   17c6c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
   17c70:	910003fd 	mov	x29, sp
   17c74:	d10ac3ff 	sub	sp, sp, #0x2b0
   17c78:	aa0903f1 	mov	x17, x9
   17c7c:	a9343baa 	stp	x10, x14, [x29, #-192]
   17c80:	aa0c03f2 	mov	x18, x12
   17c84:	aa0b03ec 	mov	x12, x11
   17c88:	aa0503f3 	mov	x19, x5
   17c8c:	aa0003ee 	mov	x14, x0
   17c90:	aa1c03eb 	mov	x11, x28
   17c94:	aa1b03e5 	mov	x5, x27
   17c98:	2a1703e9 	mov	w9, w23
   17c9c:	a9460bb0 	ldp	x16, x2, [x29, #96]
   17ca0:	f81383b6 	stur	x22, [x29, #-200]
   17ca4:	a94503bb 	ldp	x27, x0, [x29, #80]
   17ca8:	f94027b6 	ldr	x22, [x29, #72]
   17cac:	a942aba8 	ldp	x8, x10, [x29, #40]
   17cb0:	f9400bb8 	ldr	x24, [x29, #16]
   17cb4:	a941f3b7 	ldp	x23, x28, [x29, #24]
   17cb8:	6b1900bf 	cmp	w5, w25
   17cbc:	aa1403fe 	mov	x30, x20
   17cc0:	f81303a8 	stur	x8, [x29, #-208]
   17cc4:	54000a01 	b.ne	17e04 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x198>  // b.any
   17cc8:	51000748 	sub	w8, w26, #0x1
   17ccc:	6b07011f 	cmp	w8, w7
   17cd0:	540009a2 	b.cs	17e04 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x198>  // b.hs, b.nlast
   17cd4:	6b0c035f 	cmp	w26, w12
   17cd8:	54000968 	b.hi	17e04 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x198>  // b.pmore
   17cdc:	a930afa7 	stp	x7, x11, [x29, #-248]
   17ce0:	2a0d03eb 	mov	w11, w13
   17ce4:	f100057f 	cmp	x11, #0x1
   17ce8:	f81203aa 	stur	x10, [x29, #-224]
   17cec:	54000e01 	b.ne	17eac <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x240>  // b.any
   17cf0:	92409c74 	and	x20, x3, #0xffffffffff
   17cf4:	aa1b03e7 	mov	x7, x27
   17cf8:	f81183b6 	stur	x22, [x29, #-232]
   17cfc:	aa1403eb 	mov	x11, x20
   17d00:	b6f80063 	tbz	x3, #63, 17d0c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xa0>
   17d04:	f8747bcb 	ldr	x11, [x30, x20, lsl #3]
   17d08:	d358fd6b 	lsr	x11, x11, #24
   17d0c:	92409c8d 	and	x13, x4, #0xffffffffff
   17d10:	aa1103f6 	mov	x22, x17
   17d14:	b6f80044 	tbz	x4, #63, 17d1c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xb0>
   17d18:	f86d7bdf 	ldr	xzr, [x30, x13, lsl #3]
   17d1c:	92409e71 	and	x17, x19, #0xffffffffff
   17d20:	b6f80053 	tbz	x19, #63, 17d28 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xbc>
   17d24:	f8717bdf 	ldr	xzr, [x30, x17, lsl #3]
   17d28:	f900cfec 	str	x12, [sp, #408]
   17d2c:	92409ccc 	and	x12, x6, #0xffffffffff
   17d30:	f9009bed 	str	x13, [sp, #304]
   17d34:	b6f80046 	tbz	x6, #63, 17d3c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xd0>
   17d38:	f86c7bdf 	ldr	xzr, [x30, x12, lsl #3]
   17d3c:	f90093ec 	str	x12, [sp, #288]
   17d40:	d368fc6c 	lsr	x12, x3, #40
   17d44:	1280000d 	mov	w13, #0xffffffff            	// #-1
   17d48:	8b0b0fcb 	add	x11, x30, x11, lsl #3
   17d4c:	f900d3e1 	str	x1, [sp, #416]
   17d50:	1acc21ac 	lsl	w12, w13, w12
   17d54:	0a2c010c 	bic	w12, w8, w12
   17d58:	b86c596b 	ldr	w11, [x11, w12, uxtw #2]
   17d5c:	3400156b 	cbz	w11, 18008 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x39c>
   17d60:	92409dca 	and	x10, x14, #0xffffffffff
   17d64:	f9006bf1 	str	x17, [sp, #208]
   17d68:	aa0303f1 	mov	x17, x3
   17d6c:	aa0a03eb 	mov	x11, x10
   17d70:	f900c3e2 	str	x2, [sp, #384]
   17d74:	f900cbf3 	str	x19, [sp, #400]
   17d78:	b6f8006e 	tbz	x14, #63, 17d84 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x118>
   17d7c:	f86a7bcb 	ldr	x11, [x30, x10, lsl #3]
   17d80:	d358fd6b 	lsr	x11, x11, #24
   17d84:	d368b1cc 	ubfx	x12, x14, #40, #5
   17d88:	9280000d 	mov	x13, #0xffffffffffffffff    	// #-1
   17d8c:	f900c7f1 	str	x17, [sp, #392]
   17d90:	5100058c 	sub	w12, w12, #0x1
   17d94:	9acc21bb 	lsl	x27, x13, x12
   17d98:	8b0b0fcd 	add	x13, x30, x11, lsl #3
   17d9c:	0a3b0108 	bic	w8, w8, w27
   17da0:	531f7908 	lsl	w8, w8, #1
   17da4:	8b284fcc 	add	x12, x30, w8, uxtw #3
   17da8:	8b284da8 	add	x8, x13, w8, uxtw #3
   17dac:	8b0b0d8b 	add	x11, x12, x11, lsl #3
   17db0:	f9400502 	ldr	x2, [x8, #8]
   17db4:	b940016c 	ldr	w12, [x11]
   17db8:	a9007d7f 	stp	xzr, xzr, [x11]
   17dbc:	34001bac 	cbz	w12, 18130 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x4c4>
   17dc0:	92409c48 	and	x8, x2, #0xffffffffff
   17dc4:	52909fe3 	mov	w3, #0x84ff                	// #34047
   17dc8:	f9007ffb 	str	x27, [sp, #248]
   17dcc:	8b080fcd 	add	x13, x30, x8, lsl #3
   17dd0:	72a06203 	movk	w3, #0x310, lsl #16
   17dd4:	f81283bc 	stur	x28, [x29, #-216]
   17dd8:	b9010fe9 	str	w9, [sp, #268]
   17ddc:	f90083ea 	str	x10, [sp, #256]
   17de0:	f90067f4 	str	x20, [sp, #200]
   17de4:	f900d7f2 	str	x18, [sp, #424]
   17de8:	f900afe4 	str	x4, [sp, #344]
   17dec:	f900a7ee 	str	x14, [sp, #328]
   17df0:	f81003a0 	stur	x0, [x29, #-256]
   17df4:	b7f81f02 	tbnz	x2, #63, 181d4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x568>
   17df8:	a94051ab 	ldp	x11, x20, [x13]
   17dfc:	aa0803ec 	mov	x12, x8
   17e00:	1400010d 	b	18234 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x5c8>
   17e04:	aa1c03e8 	mov	x8, x28
   17e08:	aa0103fc 	mov	x28, x1
   17e0c:	aa1e03f4 	mov	x20, x30
   17e10:	aa0a03fe 	mov	x30, x10
   17e14:	aa1503e1 	mov	x1, x21
   17e18:	aa1203ea 	mov	x10, x18
   17e1c:	f81283a8 	stur	x8, [x29, #-216]
   17e20:	34000a89 	cbz	w9, 17f70 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x304>
   17e24:	a904c3a0 	stp	x0, x16, [x29, #72]
   17e28:	aa0203f0 	mov	x16, x2
   17e2c:	2a0503e8 	mov	w8, w5
   17e30:	2a0703e5 	mov	w5, w7
   17e34:	2a0c03e7 	mov	w7, w12
   17e38:	2a1003ec 	mov	w12, w16
   17e3c:	aa0303e0 	mov	x0, x3
   17e40:	2a0903e3 	mov	w3, w9
   17e44:	2a1a03e9 	mov	w9, w26
   17e48:	f9002fac 	str	x12, [x29, #88]
   17e4c:	2a1903ec 	mov	w12, w25
   17e50:	aa0e03e2 	mov	x2, x14
   17e54:	a902a7ac 	stp	x12, x9, [x29, #40]
   17e58:	a972b3ae 	ldp	x14, x12, [x29, #-216]
   17e5c:	a903efb6 	stp	x22, x27, [x29, #56]
   17e60:	aa0103f5 	mov	x21, x1
   17e64:	aa0403e1 	mov	x1, x4
   17e68:	aa0603e4 	mov	x4, x6
   17e6c:	a9739bb6 	ldp	x22, x6, [x29, #-200]
   17e70:	2a0b03f2 	mov	w18, w11
   17e74:	2a0d03eb 	mov	w11, w13
   17e78:	2a1103ed 	mov	w13, w17
   17e7c:	2a1e03f1 	mov	w17, w30
   17e80:	2a0c03ec 	mov	w12, w12
   17e84:	2a0f03f0 	mov	w16, w15
   17e88:	2a1803e9 	mov	w9, w24
   17e8c:	2a1703ef 	mov	w15, w23
   17e90:	a901c7ac 	stp	x12, x17, [x29, #24]
   17e94:	2a0e03f1 	mov	w17, w14
   17e98:	2a0303f7 	mov	w23, w3
   17e9c:	aa0803f9 	mov	x25, x8
   17ea0:	aa1203fa 	mov	x26, x18
   17ea4:	aa0203fb 	mov	x27, x2
   17ea8:	1400002b 	b	17f54 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x2e8>
   17eac:	f900d7f2 	str	x18, [sp, #424]
   17eb0:	aa1803f4 	mov	x20, x24
   17eb4:	aa0e03ea 	mov	x10, x14
   17eb8:	aa1703ee 	mov	x14, x23
   17ebc:	aa0503f8 	mov	x24, x5
   17ec0:	f81283bc 	stur	x28, [x29, #-216]
   17ec4:	aa0103fc 	mov	x28, x1
   17ec8:	aa1b03e7 	mov	x7, x27
   17ecc:	34000e69 	cbz	w9, 18098 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x42c>
   17ed0:	2a0903f7 	mov	w23, w9
   17ed4:	f85103a9 	ldur	x9, [x29, #-240]
   17ed8:	a904c3a0 	stp	x0, x16, [x29, #72]
   17edc:	a9039fb6 	stp	x22, x7, [x29, #56]
   17ee0:	2a0c03e7 	mov	w7, w12
   17ee4:	2a0203ec 	mov	w12, w2
   17ee8:	2a0903f2 	mov	w18, w9
   17eec:	f85083a9 	ldur	x9, [x29, #-248]
   17ef0:	2a0f03f0 	mov	w16, w15
   17ef4:	f85203af 	ldur	x15, [x29, #-224]
   17ef8:	f9002fac 	str	x12, [x29, #88]
   17efc:	2a1903ec 	mov	w12, w25
   17f00:	2a0903e5 	mov	w5, w9
   17f04:	2a1a03e9 	mov	w9, w26
   17f08:	2a1103ed 	mov	w13, w17
   17f0c:	a902a7ac 	stp	x12, x9, [x29, #40]
   17f10:	2a0f03f1 	mov	w17, w15
   17f14:	2a0e03ef 	mov	w15, w14
   17f18:	a972b3ae 	ldp	x14, x12, [x29, #-216]
   17f1c:	aa0403e1 	mov	x1, x4
   17f20:	aa0603e4 	mov	x4, x6
   17f24:	a9739bb6 	ldp	x22, x6, [x29, #-200]
   17f28:	2a1803e8 	mov	w8, w24
   17f2c:	aa0a03fb 	mov	x27, x10
   17f30:	aa0303e0 	mov	x0, x3
   17f34:	2a0c03ec 	mov	w12, w12
   17f38:	2a1403e9 	mov	w9, w20
   17f3c:	aa1e03f4 	mov	x20, x30
   17f40:	a901c7ac 	stp	x12, x17, [x29, #24]
   17f44:	2a0e03f1 	mov	w17, w14
   17f48:	aa0803f9 	mov	x25, x8
   17f4c:	f940d7ea 	ldr	x10, [sp, #424]
   17f50:	aa1203fa 	mov	x26, x18
   17f54:	aa1303e3 	mov	x3, x19
   17f58:	f85483ac 	ldur	x12, [x29, #-184]
   17f5c:	aa1003ee 	mov	x14, x16
   17f60:	f9000bb1 	str	x17, [x29, #16]
   17f64:	910ac3ff 	add	sp, sp, #0x2b0
   17f68:	a8c17bfd 	ldp	x29, x30, [sp], #16
   17f6c:	17fffcc6 	b	17284 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0>
   17f70:	f85383a8 	ldur	x8, [x29, #-200]
   17f74:	aa0b03f2 	mov	x18, x11
   17f78:	aa0c03e9 	mov	x9, x12
   17f7c:	f81003a0 	stur	x0, [x29, #-256]
   17f80:	f9401420 	ldr	x0, [x1, #40]
   17f84:	aa1403f5 	mov	x21, x20
   17f88:	a97eb10b 	ldp	x11, x12, [x8, #-24]
   17f8c:	a931fbb6 	stp	x22, x30, [x29, #-232]
   17f90:	aa1003f6 	mov	x22, x16
   17f94:	aa1703f4 	mov	x20, x23
   17f98:	aa0703f7 	mov	x23, x7
   17f9c:	b4005900 	cbz	x0, 18abc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xe50>
   17fa0:	f8607aa8 	ldr	x8, [x21, x0, lsl #3]
   17fa4:	f9409430 	ldr	x16, [x1, #296]
   17fa8:	aa1b03e7 	mov	x7, x27
   17fac:	f9001428 	str	x8, [x1, #40]
   17fb0:	d1008208 	sub	x8, x16, #0x20
   17fb4:	f85403b0 	ldur	x16, [x29, #-192]
   17fb8:	f9009428 	str	x8, [x1, #296]
   17fbc:	8b000ea8 	add	x8, x21, x0, lsl #3
   17fc0:	d3607d8c 	lsl	x12, x12, #32
   17fc4:	a90e310b 	stp	x11, x12, [x8, #224]
   17fc8:	2a0503eb 	mov	w11, w5
   17fcc:	2a1203ec 	mov	w12, w18
   17fd0:	a900310b 	stp	x11, x12, [x8]
   17fd4:	2a1703eb 	mov	w11, w23
   17fd8:	aa1403f7 	mov	x23, x20
   17fdc:	a901710e 	stp	x14, x28, [x8, #16]
   17fe0:	a972cbbc 	ldp	x28, x18, [x29, #-216]
   17fe4:	a904410b 	stp	x11, x16, [x8, #64]
   17fe8:	2a0903eb 	mov	w11, w9
   17fec:	aa1603f0 	mov	x16, x22
   17ff0:	a905290b 	stp	x11, x10, [x8, #80]
   17ff4:	2a0d03eb 	mov	w11, w13
   17ff8:	aa1103f6 	mov	x22, x17
   17ffc:	a9021103 	stp	x3, x4, [x8, #32]
   18000:	a9031913 	stp	x19, x6, [x8, #48]
   18004:	14000291 	b	18a48 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xddc>
   18008:	340049e9 	cbz	w9, 18944 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xcd8>
   1800c:	a970abab 	ldp	x11, x10, [x29, #-248]
   18010:	2a0503e8 	mov	w8, w5
   18014:	a904c3a0 	stp	x0, x16, [x29, #72]
   18018:	f85183ac 	ldur	x12, [x29, #-232]
   1801c:	aa0e03fb 	mov	x27, x14
   18020:	f90023a7 	str	x7, [x29, #64]
   18024:	2a0903ee 	mov	w14, w9
   18028:	2a1a03e9 	mov	w9, w26
   1802c:	2a0b03e5 	mov	w5, w11
   18030:	f940cfeb 	ldr	x11, [sp, #408]
   18034:	a90333a9 	stp	x9, x12, [x29, #48]
   18038:	f85203ac 	ldur	x12, [x29, #-224]
   1803c:	2a1603ed 	mov	w13, w22
   18040:	2a0a03ea 	mov	w10, w10
   18044:	2a0b03e7 	mov	w7, w11
   18048:	2a0203eb 	mov	w11, w2
   1804c:	2a1c03f1 	mov	w17, w28
   18050:	f9002fab 	str	x11, [x29, #88]
   18054:	2a1903eb 	mov	w11, w25
   18058:	2a0c03ec 	mov	w12, w12
   1805c:	a9022fac 	stp	x12, x11, [x29, #32]
   18060:	a9735bab 	ldp	x11, x22, [x29, #-208]
   18064:	aa0303e0 	mov	x0, x3
   18068:	2a0f03f0 	mov	w16, w15
   1806c:	2a1803e9 	mov	w9, w24
   18070:	2a1703ef 	mov	w15, w23
   18074:	aa1e03f4 	mov	x20, x30
   18078:	2a0e03f7 	mov	w23, w14
   1807c:	2a0b03eb 	mov	w11, w11
   18080:	aa0803f9 	mov	x25, x8
   18084:	aa0a03fa 	mov	x26, x10
   18088:	f9000fab 	str	x11, [x29, #24]
   1808c:	aa0403e1 	mov	x1, x4
   18090:	aa1303e3 	mov	x3, x19
   18094:	1400004a 	b	181bc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x550>
   18098:	f900b3f0 	str	x16, [sp, #352]
   1809c:	aa0c03f7 	mov	x23, x12
   180a0:	f9008ff1 	str	x17, [sp, #280]
   180a4:	f900bbef 	str	x15, [sp, #368]
   180a8:	f85383a8 	ldur	x8, [x29, #-200]
   180ac:	a970bfa9 	ldp	x9, x15, [x29, #-248]
   180b0:	f81003a0 	stur	x0, [x29, #-256]
   180b4:	f94016a0 	ldr	x0, [x21, #40]
   180b8:	a97eb50c 	ldp	x12, x13, [x8, #-24]
   180bc:	b40068c0 	cbz	x0, 18dd4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x1168>
   180c0:	f8607bc8 	ldr	x8, [x30, x0, lsl #3]
   180c4:	f94096b0 	ldr	x16, [x21, #296]
   180c8:	f90016a8 	str	x8, [x21, #40]
   180cc:	d1008208 	sub	x8, x16, #0x20
   180d0:	f90096a8 	str	x8, [x21, #296]
   180d4:	8b000fc8 	add	x8, x30, x0, lsl #3
   180d8:	d3607dad 	lsl	x13, x13, #32
   180dc:	f85403b0 	ldur	x16, [x29, #-192]
   180e0:	a90e350c 	stp	x12, x13, [x8, #224]
   180e4:	2a1803ec 	mov	w12, w24
   180e8:	2a0f03ed 	mov	w13, w15
   180ec:	a900350c 	stp	x12, x13, [x8]
   180f0:	2a0903ec 	mov	w12, w9
   180f4:	f940d7e9 	ldr	x9, [sp, #424]
   180f8:	a901710a 	stp	x10, x28, [x8, #16]
   180fc:	a972cbbc 	ldp	x28, x18, [x29, #-216]
   18100:	f940bbef 	ldr	x15, [sp, #368]
   18104:	f81183b6 	stur	x22, [x29, #-232]
   18108:	aa1403f8 	mov	x24, x20
   1810c:	a904410c 	stp	x12, x16, [x8, #64]
   18110:	2a1703ec 	mov	w12, w23
   18114:	f9408ff6 	ldr	x22, [sp, #280]
   18118:	f940b3f0 	ldr	x16, [sp, #352]
   1811c:	a9021103 	stp	x3, x4, [x8, #32]
   18120:	aa0e03f7 	mov	x23, x14
   18124:	a9031913 	stp	x19, x6, [x8, #48]
   18128:	a905250c 	stp	x12, x9, [x8, #80]
   1812c:	14000247 	b	18a48 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xddc>
   18130:	f85083ab 	ldur	x11, [x29, #-248]
   18134:	34004449 	cbz	w9, 189bc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xd50>
   18138:	a904c3a0 	stp	x0, x16, [x29, #72]
   1813c:	2a0503e8 	mov	w8, w5
   18140:	2a0b03e5 	mov	w5, w11
   18144:	f90023a7 	str	x7, [x29, #64]
   18148:	a97133aa 	ldp	x10, x12, [x29, #-240]
   1814c:	f940cfeb 	ldr	x11, [sp, #408]
   18150:	aa0e03fb 	mov	x27, x14
   18154:	2a0903ee 	mov	w14, w9
   18158:	2a1a03e9 	mov	w9, w26
   1815c:	2a1603ed 	mov	w13, w22
   18160:	2a1c03f1 	mov	w17, w28
   18164:	2a0b03e7 	mov	w7, w11
   18168:	f940c3eb 	ldr	x11, [sp, #384]
   1816c:	a90333a9 	stp	x9, x12, [x29, #48]
   18170:	f85203ac 	ldur	x12, [x29, #-224]
   18174:	2a0a03ea 	mov	w10, w10
   18178:	2a0f03f0 	mov	w16, w15
   1817c:	2a0b03eb 	mov	w11, w11
   18180:	2a1803e9 	mov	w9, w24
   18184:	2a1703ef 	mov	w15, w23
   18188:	f9002fab 	str	x11, [x29, #88]
   1818c:	2a1903eb 	mov	w11, w25
   18190:	2a0c03ec 	mov	w12, w12
   18194:	a9022fac 	stp	x12, x11, [x29, #32]
   18198:	a9735bab 	ldp	x11, x22, [x29, #-208]
   1819c:	aa1e03f4 	mov	x20, x30
   181a0:	2a0e03f7 	mov	w23, w14
   181a4:	aa0803f9 	mov	x25, x8
   181a8:	aa0a03fa 	mov	x26, x10
   181ac:	aa0403e1 	mov	x1, x4
   181b0:	2a0b03eb 	mov	w11, w11
   181b4:	f9000fab 	str	x11, [x29, #24]
   181b8:	a9588fe0 	ldp	x0, x3, [sp, #392]
   181bc:	f940d3fc 	ldr	x28, [sp, #416]
   181c0:	aa0603e4 	mov	x4, x6
   181c4:	f85403a6 	ldur	x6, [x29, #-192]
   181c8:	aa1203ea 	mov	x10, x18
   181cc:	5280002b 	mov	w11, #0x1                   	// #1
   181d0:	17ffff62 	b	17f58 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x2ec>
   181d4:	b94005ab 	ldr	w11, [x13, #4]
   181d8:	b94001ac 	ldr	w12, [x13]
   181dc:	aa1003e9 	mov	x9, x16
   181e0:	92405d90 	and	x16, x12, #0xffffff
   181e4:	f100061f 	cmp	x16, #0x1
   181e8:	540067c1 	b.ne	18ee0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x1274>  // b.any
   181ec:	aa0b818b 	orr	x11, x12, x11, lsl #32
   181f0:	88dffdbf 	ldar	wzr, [x13]
   181f4:	f94002ad 	ldr	x13, [x21]
   181f8:	d358fd6c 	lsr	x12, x11, #24
   181fc:	8b0c0fd0 	add	x16, x30, x12, lsl #3
   18200:	a940520b 	ldp	x11, x20, [x16]
   18204:	f8287bcd 	str	x13, [x30, x8, lsl #3]
   18208:	90000ccd 	adrp	x13, 1b0000 <memcpy@GLIBC_2.17>
   1820c:	f94082b0 	ldr	x16, [x21, #256]
   18210:	f90002a8 	str	x8, [x21]
   18214:	394831ad 	ldrb	w13, [x13, #524]
   18218:	91000608 	add	x8, x16, #0x1
   1821c:	710005bf 	cmp	w13, #0x1
   18220:	f90082a8 	str	x8, [x21, #256]
   18224:	540073c1 	b.ne	1909c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x1430>  // b.any
   18228:	f140211f 	cmp	x8, #0x8, lsl #12
   1822c:	54007382 	b.cs	1909c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x1430>  // b.hs, b.nlast
   18230:	aa0903f0 	mov	x16, x9
   18234:	eb03019f 	cmp	x12, x3
   18238:	540001e9 	b.ls	18274 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x608>  // b.plast
   1823c:	f94006a8 	ldr	x8, [x21, #8]
   18240:	aa1003e9 	mov	x9, x16
   18244:	f82c7bc8 	str	x8, [x30, x12, lsl #3]
   18248:	90000cc8 	adrp	x8, 1b0000 <memcpy@GLIBC_2.17>
   1824c:	f94086ad 	ldr	x13, [x21, #264]
   18250:	39483110 	ldrb	w16, [x8, #524]
   18254:	f90006ac 	str	x12, [x21, #8]
   18258:	910009a8 	add	x8, x13, #0x2
   1825c:	7100061f 	cmp	w16, #0x1
   18260:	f90086a8 	str	x8, [x21, #264]
   18264:	54005da1 	b.ne	18e18 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x11ac>  // b.any
   18268:	f140211f 	cmp	x8, #0x8, lsl #12
   1826c:	54005d62 	b.cs	18e18 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x11ac>  // b.hs, b.nlast
   18270:	aa0903f0 	mov	x16, x9
   18274:	92409d68 	and	x8, x11, #0xffffffffff
   18278:	f900bbef 	str	x15, [sp, #368]
   1827c:	8b080fcc 	add	x12, x30, x8, lsl #3
   18280:	f900b3f0 	str	x16, [sp, #352]
   18284:	b7f800eb 	tbnz	x11, #63, 182a0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x634>
   18288:	a940298d 	ldp	x13, x10, [x12]
   1828c:	aa0803eb 	mov	x11, x8
   18290:	f9400989 	ldr	x9, [x12, #16]
   18294:	a90eabe9 	stp	x9, x10, [sp, #232]
   18298:	f85303b2 	ldur	x18, [x29, #-208]
   1829c:	14000022 	b	18324 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x6b8>
   182a0:	f90073f4 	str	x20, [sp, #224]
   182a4:	aa1803f3 	mov	x19, x24
   182a8:	aa0503f8 	mov	x24, x5
   182ac:	b940058d 	ldr	w13, [x12, #4]
   182b0:	b9400190 	ldr	w16, [x12]
   182b4:	f85303b2 	ldur	x18, [x29, #-208]
   182b8:	aa0703fb 	mov	x27, x7
   182bc:	92405e11 	and	x17, x16, #0xffffff
   182c0:	f100063f 	cmp	x17, #0x1
   182c4:	540063e1 	b.ne	18f40 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x12d4>  // b.any
   182c8:	aa0d820b 	orr	x11, x16, x13, lsl #32
   182cc:	88dffd9f 	ldar	wzr, [x12]
   182d0:	f94002ac 	ldr	x12, [x21]
   182d4:	d358fd6b 	lsr	x11, x11, #24
   182d8:	8b0b0fd0 	add	x16, x30, x11, lsl #3
   182dc:	a9403a0d 	ldp	x13, x14, [x16]
   182e0:	f9400a0f 	ldr	x15, [x16, #16]
   182e4:	f8287bcc 	str	x12, [x30, x8, lsl #3]
   182e8:	90000ccc 	adrp	x12, 1b0000 <memcpy@GLIBC_2.17>
   182ec:	f94082b0 	ldr	x16, [x21, #256]
   182f0:	3948318c 	ldrb	w12, [x12, #524]
   182f4:	f90002a8 	str	x8, [x21]
   182f8:	a90ebbef 	stp	x15, x14, [sp, #232]
   182fc:	91000608 	add	x8, x16, #0x1
   18300:	7100059f 	cmp	w12, #0x1
   18304:	f90082a8 	str	x8, [x21, #256]
   18308:	54006f41 	b.ne	190f0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x1484>  // b.any
   1830c:	f140211f 	cmp	x8, #0x8, lsl #12
   18310:	54006f02 	b.cs	190f0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x1484>  // b.hs, b.nlast
   18314:	f94073f4 	ldr	x20, [sp, #224]
   18318:	aa1b03e7 	mov	x7, x27
   1831c:	aa1803e5 	mov	x5, x24
   18320:	aa1303f8 	mov	x24, x19
   18324:	eb03017f 	cmp	x11, x3
   18328:	540001a9 	b.ls	1835c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x6f0>  // b.plast
   1832c:	f9400aa8 	ldr	x8, [x21, #16]
   18330:	f82b7bc8 	str	x8, [x30, x11, lsl #3]
   18334:	90000cc8 	adrp	x8, 1b0000 <memcpy@GLIBC_2.17>
   18338:	f9408aac 	ldr	x12, [x21, #272]
   1833c:	39483110 	ldrb	w16, [x8, #524]
   18340:	f9000aab 	str	x11, [x21, #16]
   18344:	91001188 	add	x8, x12, #0x4
   18348:	7100061f 	cmp	w16, #0x1
   1834c:	f9008aa8 	str	x8, [x21, #272]
   18350:	54005861 	b.ne	18e5c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x11f0>  // b.any
   18354:	f140211f 	cmp	x8, #0x8, lsl #12
   18358:	54005822 	b.cs	18e5c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x11f0>  // b.hs, b.nlast
   1835c:	92409e88 	and	x8, x20, #0xffffffffff
   18360:	f81303b5 	stur	x21, [x29, #-208]
   18364:	8b080fd0 	add	x16, x30, x8, lsl #3
   18368:	f900a3e6 	str	x6, [sp, #320]
   1836c:	f9008be5 	str	x5, [sp, #272]
   18370:	b7f80114 	tbnz	x20, #63, 18390 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x724>
   18374:	aa0703f1 	mov	x17, x7
   18378:	a9400607 	ldp	x7, x1, [x16]
   1837c:	a9412a1b 	ldp	x27, x10, [x16, #16]
   18380:	aa0803ec 	mov	x12, x8
   18384:	a942260b 	ldp	x11, x9, [x16, #32]
   18388:	a90da7ea 	stp	x10, x9, [sp, #216]
   1838c:	1400002c 	b	1843c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x7d0>
   18390:	f90063fa 	str	x26, [sp, #192]
   18394:	aa1903fa 	mov	x26, x25
   18398:	aa1803ef 	mov	x15, x24
   1839c:	f85283ae 	ldur	x14, [x29, #-216]
   183a0:	b940060b 	ldr	w11, [x16, #4]
   183a4:	b940020c 	ldr	w12, [x16]
   183a8:	aa1603f8 	mov	x24, x22
   183ac:	aa1203f6 	mov	x22, x18
   183b0:	aa0703ea 	mov	x10, x7
   183b4:	92405d91 	and	x17, x12, #0xffffff
   183b8:	f100063f 	cmp	x17, #0x1
   183bc:	54000041 	b.ne	183c4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x758>  // b.any
   183c0:	88dffe1f 	ldar	wzr, [x16]
   183c4:	aa0b818b 	orr	x11, x12, x11, lsl #32
   183c8:	f100063f 	cmp	x17, #0x1
   183cc:	d358fd6c 	lsr	x12, x11, #24
   183d0:	8b0c0fd2 	add	x18, x30, x12, lsl #3
   183d4:	a9400655 	ldp	x21, x1, [x18]
   183d8:	a9410a49 	ldp	x9, x2, [x18, #16]
   183dc:	a9424a4b 	ldp	x11, x18, [x18, #32]
   183e0:	a90dcbe2 	stp	x2, x18, [sp, #216]
   183e4:	54005e21 	b.ne	18fa8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x133c>  // b.any
   183e8:	f85303b2 	ldur	x18, [x29, #-208]
   183ec:	f9400251 	ldr	x17, [x18]
   183f0:	f9000211 	str	x17, [x16]
   183f4:	90000cd0 	adrp	x16, 1b0000 <memcpy@GLIBC_2.17>
   183f8:	f9408251 	ldr	x17, [x18, #256]
   183fc:	39483210 	ldrb	w16, [x16, #524]
   18400:	f9000248 	str	x8, [x18]
   18404:	91000628 	add	x8, x17, #0x1
   18408:	7100061f 	cmp	w16, #0x1
   1840c:	f9008248 	str	x8, [x18, #256]
   18410:	540068e1 	b.ne	1912c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x14c0>  // b.any
   18414:	f140211f 	cmp	x8, #0x8, lsl #12
   18418:	540068a2 	b.cs	1912c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x14c0>  // b.hs, b.nlast
   1841c:	aa1a03f9 	mov	x25, x26
   18420:	f94063fa 	ldr	x26, [sp, #192]
   18424:	aa0a03f1 	mov	x17, x10
   18428:	aa1603f2 	mov	x18, x22
   1842c:	aa1803f6 	mov	x22, x24
   18430:	aa0f03f8 	mov	x24, x15
   18434:	aa1503e7 	mov	x7, x21
   18438:	aa0903fb 	mov	x27, x9
   1843c:	eb03019f 	cmp	x12, x3
   18440:	540003c9 	b.ls	184b8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x84c>  // b.plast
   18444:	f90063eb 	str	x11, [sp, #192]
   18448:	aa0103e9 	mov	x9, x1
   1844c:	aa1b03eb 	mov	x11, x27
   18450:	f85303a1 	ldur	x1, [x29, #-208]
   18454:	aa1103fb 	mov	x27, x17
   18458:	aa0703f5 	mov	x21, x7
   1845c:	aa1803f3 	mov	x19, x24
   18460:	aa1e03ef 	mov	x15, x30
   18464:	f9400c28 	ldr	x8, [x1, #24]
   18468:	f82c7bc8 	str	x8, [x30, x12, lsl #3]
   1846c:	90000cc8 	adrp	x8, 1b0000 <memcpy@GLIBC_2.17>
   18470:	f9408c30 	ldr	x16, [x1, #280]
   18474:	39483111 	ldrb	w17, [x8, #524]
   18478:	f9000c2c 	str	x12, [x1, #24]
   1847c:	91002208 	add	x8, x16, #0x8
   18480:	7100063f 	cmp	w17, #0x1
   18484:	f9008c28 	str	x8, [x1, #280]
   18488:	54005141 	b.ne	18eb0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x1244>  // b.any
   1848c:	f140211f 	cmp	x8, #0x8, lsl #12
   18490:	54005102 	b.cs	18eb0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x1244>  // b.hs, b.nlast
   18494:	f85283bc 	ldur	x28, [x29, #-216]
   18498:	aa1b03f1 	mov	x17, x27
   1849c:	aa1303f8 	mov	x24, x19
   184a0:	aa0f03fe 	mov	x30, x15
   184a4:	aa0b03fb 	mov	x27, x11
   184a8:	f94063eb 	ldr	x11, [sp, #192]
   184ac:	aa1503e7 	mov	x7, x21
   184b0:	aa0903e1 	mov	x1, x9
   184b4:	14000002 	b	184bc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x850>
   184b8:	f85283bc 	ldur	x28, [x29, #-216]
   184bc:	92409da8 	and	x8, x13, #0xffffffffff
   184c0:	b6f8006d 	tbz	x13, #63, 184cc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x860>
   184c4:	f8687bc8 	ldr	x8, [x30, x8, lsl #3]
   184c8:	d358fd08 	lsr	x8, x8, #24
   184cc:	f85483aa 	ldur	x10, [x29, #-184]
   184d0:	92409d4c 	and	x12, x10, #0xffffffffff
   184d4:	b6f8006a 	tbz	x10, #63, 184e0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x874>
   184d8:	f86c7bcc 	ldr	x12, [x30, x12, lsl #3]
   184dc:	d358fd8c 	lsr	x12, x12, #24
   184e0:	f85183aa 	ldur	x10, [x29, #-232]
   184e4:	f900abf1 	str	x17, [sp, #336]
   184e8:	92409d50 	and	x16, x10, #0xffffffffff
   184ec:	b6f8006a 	tbz	x10, #63, 184f8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x88c>
   184f0:	f8707bd0 	ldr	x16, [x30, x16, lsl #3]
   184f4:	d358fe10 	lsr	x16, x16, #24
   184f8:	f940b3ea 	ldr	x10, [sp, #352]
   184fc:	92409d51 	and	x17, x10, #0xffffffffff
   18500:	aa0a03e9 	mov	x9, x10
   18504:	b6f8006a 	tbz	x10, #63, 18510 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x8a4>
   18508:	f8717bd1 	ldr	x17, [x30, x17, lsl #3]
   1850c:	d358fe31 	lsr	x17, x17, #24
   18510:	eb0901bf 	cmp	x13, x9
   18514:	aa1103f3 	mov	x19, x17
   18518:	54000100 	b.eq	18538 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x8cc>  // b.none
   1851c:	f85183aa 	ldur	x10, [x29, #-232]
   18520:	aa1003f3 	mov	x19, x16
   18524:	eb0a01bf 	cmp	x13, x10
   18528:	54000080 	b.eq	18538 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x8cc>  // b.none
   1852c:	f85483aa 	ldur	x10, [x29, #-184]
   18530:	eb0a01bf 	cmp	x13, x10
   18534:	9a880193 	csel	x19, x12, x8, eq	// eq = none
   18538:	f85483aa 	ldur	x10, [x29, #-184]
   1853c:	f85183af 	ldur	x15, [x29, #-232]
   18540:	d102c3a2 	sub	x2, x29, #0xb0
   18544:	a908c7e9 	stp	x9, x17, [sp, #136]
   18548:	aa1e03e0 	mov	x0, x30
   1854c:	aa0d03e3 	mov	x3, x13
   18550:	eb0f015f 	cmp	x10, x15
   18554:	b900b3fb 	str	w27, [sp, #176]
   18558:	aa1303e4 	mov	x4, x19
   1855c:	9a8c0208 	csel	x8, x16, x12, eq	// eq = none
   18560:	eb09015f 	cmp	x10, x9
   18564:	b900abe1 	str	w1, [sp, #168]
   18568:	9a880228 	csel	x8, x17, x8, eq	// eq = none
   1856c:	eb0901ff 	cmp	x15, x9
   18570:	f940bbe9 	ldr	x9, [sp, #368]
   18574:	9a90022c 	csel	x12, x17, x16, eq	// eq = none
   18578:	f9406ff0 	ldr	x16, [sp, #216]
   1857c:	b900a3e7 	str	w7, [sp, #160]
   18580:	b90043e9 	str	w9, [sp, #64]
   18584:	f94073e9 	ldr	x9, [sp, #224]
   18588:	b900bbf0 	str	w16, [sp, #184]
   1858c:	b9009bff 	str	wzr, [sp, #152]
   18590:	b90073fa 	str	w26, [sp, #112]
   18594:	b9006bf9 	str	w25, [sp, #104]
   18598:	b90063f2 	str	w18, [sp, #96]
   1859c:	b9005bfc 	str	w28, [sp, #88]
   185a0:	b90053f7 	str	w23, [sp, #80]
   185a4:	b9004bf8 	str	w24, [sp, #72]
   185a8:	b9003bf6 	str	w22, [sp, #56]
   185ac:	b90023e9 	str	w9, [sp, #32]
   185b0:	b9001beb 	str	w11, [sp, #24]
   185b4:	b90013f0 	str	w16, [sp, #16]
   185b8:	b9000bfb 	str	w27, [sp, #8]
   185bc:	b90003e1 	str	w1, [sp]
   185c0:	a907b3ef 	stp	x15, x12, [sp, #120]
   185c4:	f90017ea 	str	x10, [sp, #40]
   185c8:	f85303b5 	ldur	x21, [x29, #-208]
   185cc:	f81483be 	stur	x30, [x29, #-184]
   185d0:	a94e97e6 	ldp	x6, x5, [sp, #232]
   185d4:	f9001be8 	str	x8, [sp, #48]
   185d8:	aa1503e1 	mov	x1, x21
   185dc:	9401883d 	bl	7a6d0 <spin_51>
   185e0:	a974f3b4 	ldp	x20, x28, [x29, #-184]
   185e4:	3cd583a4 	ldur	q4, [x29, #-168]
   185e8:	a97d9fb8 	ldp	x24, x7, [x29, #-40]
   185ec:	3cd683a1 	ldur	q1, [x29, #-152]
   185f0:	3cd783a2 	ldur	q2, [x29, #-136]
   185f4:	3cd883a3 	ldur	q3, [x29, #-120]
   185f8:	f85983ac 	ldur	x12, [x29, #-104]
   185fc:	b85a03ad 	ldur	w13, [x29, #-96]
   18600:	b85a83ae 	ldur	w14, [x29, #-88]
   18604:	b85b03be 	ldur	w30, [x29, #-80]
   18608:	b85b83b9 	ldur	w25, [x29, #-72]
   1860c:	b85c03a0 	ldur	w0, [x29, #-64]
   18610:	b85c83a3 	ldur	w3, [x29, #-56]
   18614:	b85d03a5 	ldur	w5, [x29, #-48]
   18618:	a97e9bba 	ldp	x26, x6, [x29, #-24]
   1861c:	b6f8007c 	tbz	x28, #63, 18628 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x9bc>
   18620:	92409f88 	and	x8, x28, #0xffffffffff
   18624:	f8687a9f 	ldr	xzr, [x20, x8, lsl #3]
   18628:	a9543fe4 	ldp	x4, x15, [sp, #320]
   1862c:	f940d7ea 	ldr	x10, [sp, #424]
   18630:	a958a7eb 	ldp	x11, x9, [sp, #392]
   18634:	f85003b3 	ldur	x19, [x29, #-256]
   18638:	a94fdff0 	ldp	x16, x23, [sp, #248]
   1863c:	b6f8006c 	tbz	x12, #63, 18648 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x9dc>
   18640:	92409d88 	and	x8, x12, #0xffffffffff
   18644:	f8687a9f 	ldr	xzr, [x20, x8, lsl #3]
   18648:	f85203b1 	ldur	x17, [x29, #-224]
   1864c:	f940c3f2 	ldr	x18, [sp, #384]
   18650:	52909fe1 	mov	w1, #0x84ff                	// #34047
   18654:	72a06201 	movk	w1, #0x310, lsl #16
   18658:	b7f814c7 	tbnz	x7, #63, 188f0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xc84>
   1865c:	b7f8151a 	tbnz	x26, #63, 188fc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xc90>
   18660:	b7f8154f 	tbnz	x15, #63, 18908 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xc9c>
   18664:	f940d3e8 	ldr	x8, [sp, #416]
   18668:	b6f80088 	tbz	x8, #63, 18678 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xa0c>
   1866c:	f940d3e8 	ldr	x8, [sp, #416]
   18670:	92409d08 	and	x8, x8, #0xffffffffff
   18674:	f8687a9f 	ldr	xzr, [x20, x8, lsl #3]
   18678:	b6f8006b 	tbz	x11, #63, 18684 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xa18>
   1867c:	f94067e8 	ldr	x8, [sp, #200]
   18680:	f8687a9f 	ldr	xzr, [x20, x8, lsl #3]
   18684:	f940afe8 	ldr	x8, [sp, #344]
   18688:	b7f81468 	tbnz	x8, #63, 18914 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xca8>
   1868c:	b7f814a9 	tbnz	x9, #63, 18920 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xcb4>
   18690:	b7f814e4 	tbnz	x4, #63, 1892c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xcc0>
   18694:	b7f8152a 	tbnz	x10, #63, 18938 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xccc>
   18698:	f940abe8 	ldr	x8, [sp, #336]
   1869c:	b6f80088 	tbz	x8, #63, 186ac <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xa40>
   186a0:	f940abe8 	ldr	x8, [sp, #336]
   186a4:	92409d08 	and	x8, x8, #0xffffffffff
   186a8:	f8687a9f 	ldr	xzr, [x20, x8, lsl #3]
   186ac:	2a3003e8 	mvn	w8, w16
   186b0:	b6f80073 	tbz	x19, #63, 186bc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xa50>
   186b4:	92409e69 	and	x9, x19, #0xffffffffff
   186b8:	f8697a9f 	ldr	xzr, [x20, x9, lsl #3]
   186bc:	51000709 	sub	w9, w24, #0x1
   186c0:	f9400aab 	ldr	x11, [x21, #16]
   186c4:	0a080128 	and	w8, w9, w8
   186c8:	531f790f 	lsl	w15, w8, #1
   186cc:	8b2f4e88 	add	x8, x20, w15, uxtw #3
   186d0:	8b170d1b 	add	x27, x8, x23, lsl #3
   186d4:	f9400769 	ldr	x9, [x27, #8]
   186d8:	b400230b 	cbz	x11, 18b38 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xecc>
   186dc:	f86b7a88 	ldr	x8, [x20, x11, lsl #3]
   186e0:	f9408ab0 	ldr	x16, [x21, #272]
   186e4:	f9000aa8 	str	x8, [x21, #16]
   186e8:	d1001208 	sub	x8, x16, #0x4
   186ec:	f9008aa8 	str	x8, [x21, #272]
   186f0:	d378ff88 	lsr	x8, x28, #56
   186f4:	f100091f 	cmp	x8, #0x2
   186f8:	540025a0 	b.eq	18bac <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xf40>  // b.none
   186fc:	6f00e5e0 	movi	v0.2d, #0xffffffff
   18700:	8b0b0e88 	add	x8, x20, x11, lsl #3
   18704:	f81283b9 	stur	x25, [x29, #-216]
   18708:	f900011c 	str	x28, [x8]
   1870c:	4e201c80 	and	v0.16b, v4.16b, v0.16b
   18710:	3c808100 	stur	q0, [x8, #8]
   18714:	f9400ebc 	ldr	x28, [x21, #24]
   18718:	b400287c 	cbz	x28, 18c24 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xfb8>
   1871c:	f87c7a88 	ldr	x8, [x20, x28, lsl #3]
   18720:	f9408eb0 	ldr	x16, [x21, #280]
   18724:	f9000ea8 	str	x8, [x21, #24]
   18728:	d1002208 	sub	x8, x16, #0x8
   1872c:	f9008ea8 	str	x8, [x21, #280]
   18730:	6f00e5e0 	movi	v0.2d, #0xffffffff
   18734:	8b1c0e88 	add	x8, x20, x28, lsl #3
   18738:	4e201c21 	and	v1.16b, v1.16b, v0.16b
   1873c:	4e201c42 	and	v2.16b, v2.16b, v0.16b
   18740:	4e201c60 	and	v0.16b, v3.16b, v0.16b
   18744:	ad000901 	stp	q1, q2, [x8]
   18748:	3d800900 	str	q0, [x8, #32]
   1874c:	f94006b9 	ldr	x25, [x21, #8]
   18750:	b4002a79 	cbz	x25, 18c9c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x1030>
   18754:	f8797a88 	ldr	x8, [x20, x25, lsl #3]
   18758:	f94086b0 	ldr	x16, [x21, #264]
   1875c:	f90006a8 	str	x8, [x21, #8]
   18760:	d1000a08 	sub	x8, x16, #0x2
   18764:	f90086a8 	str	x8, [x21, #264]
   18768:	d2c40008 	mov	x8, #0x200000000000        	// #35184372088832
   1876c:	f2e04008 	movk	x8, #0x200, lsl #48
   18770:	aa080162 	orr	x2, x11, x8
   18774:	d378fc48 	lsr	x8, x2, #56
   18778:	f100091f 	cmp	x8, #0x2
   1877c:	54002c20 	b.eq	18d00 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x1094>  // b.none
   18780:	d2c42008 	mov	x8, #0x210000000000        	// #36283883716608
   18784:	8b190e8b 	add	x11, x20, x25, lsl #3
   18788:	f2e04008 	movk	x8, #0x200, lsl #48
   1878c:	aa080388 	orr	x8, x28, x8
   18790:	2a1803fc 	mov	w28, w24
   18794:	f9000162 	str	x2, [x11]
   18798:	d378fd10 	lsr	x16, x8, #56
   1879c:	f1000a1f 	cmp	x16, #0x2
   187a0:	54002e20 	b.eq	18d64 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x10f8>  // b.none
   187a4:	f9000568 	str	x8, [x11, #8]
   187a8:	320001eb 	orr	w11, w15, #0x1
   187ac:	92787d30 	and	x16, x9, #0xffffffff00
   187b0:	8b2b4e8b 	add	x11, x20, w11, uxtw #3
   187b4:	91000438 	add	x24, x1, #0x1
   187b8:	d2c3e00f 	mov	x15, #0x1f0000000000        	// #34084860461056
   187bc:	52800028 	mov	w8, #0x1                   	// #1
   187c0:	f2e0400f 	movk	x15, #0x200, lsl #48
   187c4:	eb18021f 	cmp	x16, x24
   187c8:	f9000368 	str	x8, [x27]
   187cc:	aa0f0328 	orr	x8, x25, x15
   187d0:	f8377968 	str	x8, [x11, x23, lsl #3]
   187d4:	54000483 	b.cc	18864 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xbf8>  // b.lo, b.ul, b.last
   187d8:	b100053f 	cmn	x9, #0x1
   187dc:	54000440 	b.eq	18864 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xbf8>  // b.none
   187e0:	92471528 	and	x8, x9, #0x7e00000000000000
   187e4:	b4000408 	cbz	x8, 18864 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xbf8>
   187e8:	f81183a0 	stur	x0, [x29, #-232]
   187ec:	aa1403e0 	mov	x0, x20
   187f0:	aa1503e1 	mov	x1, x21
   187f4:	aa0903e2 	mov	x2, x9
   187f8:	aa0c03f3 	mov	x19, x12
   187fc:	aa0d03f4 	mov	x20, x13
   18800:	aa0e03f7 	mov	x23, x14
   18804:	aa1e03f8 	mov	x24, x30
   18808:	aa0303fb 	mov	x27, x3
   1880c:	aa0503f6 	mov	x22, x5
   18810:	f900bbfc 	str	x28, [sp, #368]
   18814:	aa1a03fc 	mov	x28, x26
   18818:	aa0603fa 	mov	x26, x6
   1881c:	aa0703f9 	mov	x25, x7
   18820:	97ffb455 	bl	5974 <term_drop>
   18824:	a971c7a0 	ldp	x0, x17, [x29, #-232]
   18828:	aa1a03e6 	mov	x6, x26
   1882c:	aa1c03fa 	mov	x26, x28
   18830:	f940bbfc 	ldr	x28, [sp, #368]
   18834:	aa1403ed 	mov	x13, x20
   18838:	aa1303ec 	mov	x12, x19
   1883c:	f85483b4 	ldur	x20, [x29, #-184]
   18840:	f85003b3 	ldur	x19, [x29, #-256]
   18844:	f940c3f2 	ldr	x18, [sp, #384]
   18848:	f940a3e4 	ldr	x4, [sp, #320]
   1884c:	f940d7ea 	ldr	x10, [sp, #424]
   18850:	aa1903e7 	mov	x7, x25
   18854:	aa1603e5 	mov	x5, x22
   18858:	aa1b03e3 	mov	x3, x27
   1885c:	aa1803fe 	mov	x30, x24
   18860:	aa1703ee 	mov	x14, x23
   18864:	f85383b6 	ldur	x22, [x29, #-200]
   18868:	d0000ca9 	adrp	x9, 1ae000 <io_eff_rows+0xff0b0>
   1886c:	913fa129 	add	x9, x9, #0xfe8
   18870:	f85283af 	ldur	x15, [x29, #-216]
   18874:	52800398 	mov	w24, #0x1c                  	// #28
   18878:	b85f8ec8 	ldr	w8, [x22, #-8]!
   1887c:	f8687922 	ldr	x2, [x9, x8, lsl #3]
   18880:	a904ebb3 	stp	x19, x26, [x29, #72]
   18884:	f940abe8 	ldr	x8, [sp, #336]
   18888:	a902f3a5 	stp	x5, x28, [x29, #40]
   1888c:	f9000fa3 	str	x3, [x29, #24]
   18890:	a903a3a7 	stp	x7, x8, [x29, #56]
   18894:	0b1200c8 	add	w8, w6, w18
   18898:	f85403a6 	ldur	x6, [x29, #-192]
   1889c:	f9408be9 	ldr	x9, [sp, #272]
   188a0:	2a0903f9 	mov	w25, w9
   188a4:	a970afa9 	ldp	x9, x11, [x29, #-248]
   188a8:	2a0903e5 	mov	w5, w9
   188ac:	f940cfe9 	ldr	x9, [sp, #408]
   188b0:	f9000ba0 	str	x0, [x29, #16]
   188b4:	2a0b03fa 	mov	w26, w11
   188b8:	5280002b 	mov	w11, #0x1                   	// #1
   188bc:	2a0903e7 	mov	w7, w9
   188c0:	2a1103e9 	mov	w9, w17
   188c4:	f90013a9 	str	x9, [x29, #32]
   188c8:	aa1e03e9 	mov	x9, x30
   188cc:	a9588fe0 	ldp	x0, x3, [sp, #392]
   188d0:	b9410ff7 	ldr	w23, [sp, #268]
   188d4:	f940a7fb 	ldr	x27, [sp, #328]
   188d8:	f940d3fc 	ldr	x28, [sp, #416]
   188dc:	f940afe1 	ldr	x1, [sp, #344]
   188e0:	f9002fa8 	str	x8, [x29, #88]
   188e4:	910ac3ff 	add	sp, sp, #0x2b0
   188e8:	a8c17bfd 	ldp	x29, x30, [sp], #16
   188ec:	d61f0040 	br	x2
   188f0:	92409ce8 	and	x8, x7, #0xffffffffff
   188f4:	f8687a9f 	ldr	xzr, [x20, x8, lsl #3]
   188f8:	b6ffeb5a 	tbz	x26, #63, 18660 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x9f4>
   188fc:	92409f48 	and	x8, x26, #0xffffffffff
   18900:	f8687a9f 	ldr	xzr, [x20, x8, lsl #3]
   18904:	b6ffeb0f 	tbz	x15, #63, 18664 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x9f8>
   18908:	f8777a88 	ldr	x8, [x20, x23, lsl #3]
   1890c:	d358fd17 	lsr	x23, x8, #24
   18910:	17ffff55 	b	18664 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x9f8>
   18914:	f9409be8 	ldr	x8, [sp, #304]
   18918:	f8687a9f 	ldr	xzr, [x20, x8, lsl #3]
   1891c:	b6ffeba9 	tbz	x9, #63, 18690 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xa24>
   18920:	f9406be8 	ldr	x8, [sp, #208]
   18924:	f8687a9f 	ldr	xzr, [x20, x8, lsl #3]
   18928:	b6ffeb64 	tbz	x4, #63, 18694 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xa28>
   1892c:	f94093e8 	ldr	x8, [sp, #288]
   18930:	f8687a9f 	ldr	xzr, [x20, x8, lsl #3]
   18934:	b6ffeb2a 	tbz	x10, #63, 18698 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xa2c>
   18938:	92409d48 	and	x8, x10, #0xffffffffff
   1893c:	f8687a9f 	ldr	xzr, [x20, x8, lsl #3]
   18940:	17ffff56 	b	18698 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xa2c>
   18944:	f85383a8 	ldur	x8, [x29, #-200]
   18948:	f81003a0 	stur	x0, [x29, #-256]
   1894c:	f94016a0 	ldr	x0, [x21, #40]
   18950:	a97eb10b 	ldp	x11, x12, [x8, #-24]
   18954:	b4003520 	cbz	x0, 18ff8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x138c>
   18958:	f8607bc8 	ldr	x8, [x30, x0, lsl #3]
   1895c:	f94096ad 	ldr	x13, [x21, #296]
   18960:	f85403aa 	ldur	x10, [x29, #-192]
   18964:	f90016a8 	str	x8, [x21, #40]
   18968:	d10081a8 	sub	x8, x13, #0x20
   1896c:	f90096a8 	str	x8, [x21, #296]
   18970:	8b000fc8 	add	x8, x30, x0, lsl #3
   18974:	d3607d8c 	lsl	x12, x12, #32
   18978:	f85103a9 	ldur	x9, [x29, #-240]
   1897c:	a90e310b 	stp	x11, x12, [x8, #224]
   18980:	2a0503eb 	mov	w11, w5
   18984:	2a0903ec 	mov	w12, w9
   18988:	a900310b 	stp	x11, x12, [x8]
   1898c:	f940d3eb 	ldr	x11, [sp, #416]
   18990:	f85083a9 	ldur	x9, [x29, #-248]
   18994:	a9021103 	stp	x3, x4, [x8, #32]
   18998:	a9012d0e 	stp	x14, x11, [x8, #16]
   1899c:	2a0903eb 	mov	w11, w9
   189a0:	a904290b 	stp	x11, x10, [x8, #64]
   189a4:	f940cfea 	ldr	x10, [sp, #408]
   189a8:	a9031913 	stp	x19, x6, [x8, #48]
   189ac:	2a0a03eb 	mov	w11, w10
   189b0:	a905490b 	stp	x11, x18, [x8, #80]
   189b4:	f85303b2 	ldur	x18, [x29, #-208]
   189b8:	14000023 	b	18a44 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xdd8>
   189bc:	a973aba8 	ldp	x8, x10, [x29, #-200]
   189c0:	aa1003f3 	mov	x19, x16
   189c4:	f81003a0 	stur	x0, [x29, #-256]
   189c8:	f94016a0 	ldr	x0, [x21, #40]
   189cc:	aa1203e9 	mov	x9, x18
   189d0:	f940cbf0 	ldr	x16, [sp, #400]
   189d4:	f940c3e2 	ldr	x2, [sp, #384]
   189d8:	a97eb10b 	ldp	x11, x12, [x8, #-24]
   189dc:	b4003be0 	cbz	x0, 19158 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x14ec>
   189e0:	f8607bc8 	ldr	x8, [x30, x0, lsl #3]
   189e4:	f94096ad 	ldr	x13, [x21, #296]
   189e8:	f85303b2 	ldur	x18, [x29, #-208]
   189ec:	f90016a8 	str	x8, [x21, #40]
   189f0:	d10081a8 	sub	x8, x13, #0x20
   189f4:	f90096a8 	str	x8, [x21, #296]
   189f8:	8b000fc8 	add	x8, x30, x0, lsl #3
   189fc:	d3607d8c 	lsl	x12, x12, #32
   18a00:	a90e310b 	stp	x11, x12, [x8, #224]
   18a04:	f85103ac 	ldur	x12, [x29, #-240]
   18a08:	2a0503eb 	mov	w11, w5
   18a0c:	a9031910 	stp	x16, x6, [x8, #48]
   18a10:	aa1303f0 	mov	x16, x19
   18a14:	2a0c03ec 	mov	w12, w12
   18a18:	a900310b 	stp	x11, x12, [x8]
   18a1c:	f940d3eb 	ldr	x11, [sp, #416]
   18a20:	a9012d0e 	stp	x14, x11, [x8, #16]
   18a24:	f940c7eb 	ldr	x11, [sp, #392]
   18a28:	a902110b 	stp	x11, x4, [x8, #32]
   18a2c:	f85083ab 	ldur	x11, [x29, #-248]
   18a30:	2a0b03eb 	mov	w11, w11
   18a34:	a904290b 	stp	x11, x10, [x8, #64]
   18a38:	f940cfea 	ldr	x10, [sp, #408]
   18a3c:	2a0a03eb 	mov	w11, w10
   18a40:	a905250b 	stp	x11, x9, [x8, #80]
   18a44:	5280002b 	mov	w11, #0x1                   	// #1
   18a48:	f85483aa 	ldur	x10, [x29, #-184]
   18a4c:	2a1603e9 	mov	w9, w22
   18a50:	a906290b 	stp	x11, x10, [x8, #96]
   18a54:	2a0f03eb 	mov	w11, w15
   18a58:	a9072d09 	stp	x9, x11, [x8, #112]
   18a5c:	2a1803e9 	mov	w9, w24
   18a60:	2a1703eb 	mov	w11, w23
   18a64:	a9082d09 	stp	x9, x11, [x8, #128]
   18a68:	2a1c03e9 	mov	w9, w28
   18a6c:	2a1203eb 	mov	w11, w18
   18a70:	a9092d09 	stp	x9, x11, [x8, #144]
   18a74:	f85203a9 	ldur	x9, [x29, #-224]
   18a78:	2a1903eb 	mov	w11, w25
   18a7c:	2a0903e9 	mov	w9, w9
   18a80:	a90a2d09 	stp	x9, x11, [x8, #160]
   18a84:	2a1a03e9 	mov	w9, w26
   18a88:	2a0203eb 	mov	w11, w2
   18a8c:	f9005909 	str	x9, [x8, #176]
   18a90:	f85183a9 	ldur	x9, [x29, #-232]
   18a94:	f9006d0b 	str	x11, [x8, #216]
   18a98:	a90b9d09 	stp	x9, x7, [x8, #184]
   18a9c:	f85003a9 	ldur	x9, [x29, #-256]
   18aa0:	a90cc109 	stp	x9, x16, [x8, #200]
   18aa4:	d2c5e009 	mov	x9, #0x2f0000000000        	// #51677046505472
   18aa8:	f2e0a009 	movk	x9, #0x500, lsl #48
   18aac:	aa090000 	orr	x0, x0, x9
   18ab0:	910ac3ff 	add	sp, sp, #0x2b0
   18ab4:	a8c17bfd 	ldp	x29, x30, [sp], #16
   18ab8:	d65f03c0 	ret
   18abc:	aa1503e0 	mov	x0, x21
   18ac0:	aa0203e8 	mov	x8, x2
   18ac4:	528000a2 	mov	w2, #0x5                   	// #5
   18ac8:	f900cbf3 	str	x19, [sp, #400]
   18acc:	f900d7ea 	str	x10, [sp, #424]
   18ad0:	aa0803ea 	mov	x10, x8
   18ad4:	f90063fa 	str	x26, [sp, #192]
   18ad8:	aa0303fa 	mov	x26, x3
   18adc:	f81383b9 	stur	x25, [x29, #-200]
   18ae0:	aa0603f9 	mov	x25, x6
   18ae4:	f81103b2 	stur	x18, [x29, #-240]
   18ae8:	f9008ff1 	str	x17, [sp, #280]
   18aec:	f900afe4 	str	x4, [sp, #344]
   18af0:	f900d3fc 	str	x28, [sp, #416]
   18af4:	f900a7ee 	str	x14, [sp, #328]
   18af8:	aa0503ee 	mov	x14, x5
   18afc:	97ffaffc 	bl	4aec <heap_alloc_miss>
   18b00:	aa0a03e2 	mov	x2, x10
   18b04:	aa1903e6 	mov	x6, x25
   18b08:	aa0e03e5 	mov	x5, x14
   18b0c:	a973c3b9 	ldp	x25, x16, [x29, #-200]
   18b10:	f940a7ee 	ldr	x14, [sp, #328]
   18b14:	a95a2bfc 	ldp	x28, x10, [sp, #416]
   18b18:	aa1a03e3 	mov	x3, x26
   18b1c:	f940afe4 	ldr	x4, [sp, #344]
   18b20:	f940cbf3 	ldr	x19, [sp, #400]
   18b24:	f9408ff1 	ldr	x17, [sp, #280]
   18b28:	f85103b2 	ldur	x18, [x29, #-240]
   18b2c:	f94063fa 	ldr	x26, [sp, #192]
   18b30:	aa1b03e7 	mov	x7, x27
   18b34:	17fffd22 	b	17fbc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x350>
   18b38:	f81183a0 	stur	x0, [x29, #-232]
   18b3c:	aa1403e0 	mov	x0, x20
   18b40:	aa1503e1 	mov	x1, x21
   18b44:	52800042 	mov	w2, #0x2                   	// #2
   18b48:	aa1e03ea 	mov	x10, x30
   18b4c:	aa0303eb 	mov	x11, x3
   18b50:	aa0503f4 	mov	x20, x5
   18b54:	aa0603f6 	mov	x22, x6
   18b58:	aa0703f3 	mov	x19, x7
   18b5c:	ad0907e4 	stp	q4, q1, [sp, #288]
   18b60:	ad0b0fe2 	stp	q2, q3, [sp, #352]
   18b64:	97ffafe2 	bl	4aec <heap_alloc_miss>
   18b68:	ad4907e4 	ldp	q4, q1, [sp, #288]
   18b6c:	aa0b03e3 	mov	x3, x11
   18b70:	ad4b0fe2 	ldp	q2, q3, [sp, #352]
   18b74:	aa0003eb 	mov	x11, x0
   18b78:	a971c7a0 	ldp	x0, x17, [x29, #-232]
   18b7c:	aa1303e7 	mov	x7, x19
   18b80:	aa1403e5 	mov	x5, x20
   18b84:	aa0a03fe 	mov	x30, x10
   18b88:	52909fe1 	mov	w1, #0x84ff                	// #34047
   18b8c:	f85483b4 	ldur	x20, [x29, #-184]
   18b90:	f940c3f2 	ldr	x18, [sp, #384]
   18b94:	f940a3e4 	ldr	x4, [sp, #320]
   18b98:	f940d7ea 	ldr	x10, [sp, #424]
   18b9c:	f85003b3 	ldur	x19, [x29, #-256]
   18ba0:	aa1603e6 	mov	x6, x22
   18ba4:	72a06201 	movk	w1, #0x310, lsl #16
   18ba8:	17fffed2 	b	186f0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xa84>
   18bac:	f81183a0 	stur	x0, [x29, #-232]
   18bb0:	aa1403e0 	mov	x0, x20
   18bb4:	aa1503e1 	mov	x1, x21
   18bb8:	aa1c03e2 	mov	x2, x28
   18bbc:	aa0303f4 	mov	x20, x3
   18bc0:	52800023 	mov	w3, #0x1                   	// #1
   18bc4:	aa1e03ea 	mov	x10, x30
   18bc8:	aa0503fc 	mov	x28, x5
   18bcc:	aa0603f6 	mov	x22, x6
   18bd0:	aa0703f3 	mov	x19, x7
   18bd4:	ad0907e4 	stp	q4, q1, [sp, #288]
   18bd8:	ad0b0fe2 	stp	q2, q3, [sp, #352]
   18bdc:	97ffb0ad 	bl	4e90 <rfc_wrap>
   18be0:	ad4907e4 	ldp	q4, q1, [sp, #288]
   18be4:	aa1c03e5 	mov	x5, x28
   18be8:	ad4b0fe2 	ldp	q2, q3, [sp, #352]
   18bec:	aa0003fc 	mov	x28, x0
   18bf0:	a971c7a0 	ldp	x0, x17, [x29, #-232]
   18bf4:	aa1303e7 	mov	x7, x19
   18bf8:	aa1403e3 	mov	x3, x20
   18bfc:	aa0a03fe 	mov	x30, x10
   18c00:	52909fe1 	mov	w1, #0x84ff                	// #34047
   18c04:	f85483b4 	ldur	x20, [x29, #-184]
   18c08:	f940c3f2 	ldr	x18, [sp, #384]
   18c0c:	f940a3e4 	ldr	x4, [sp, #320]
   18c10:	f940d7ea 	ldr	x10, [sp, #424]
   18c14:	f85003b3 	ldur	x19, [x29, #-256]
   18c18:	aa1603e6 	mov	x6, x22
   18c1c:	72a06201 	movk	w1, #0x310, lsl #16
   18c20:	17fffeb7 	b	186fc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xa90>
   18c24:	aa0003f3 	mov	x19, x0
   18c28:	aa1403e0 	mov	x0, x20
   18c2c:	aa1503e1 	mov	x1, x21
   18c30:	52800062 	mov	w2, #0x3                   	// #3
   18c34:	aa1e03ea 	mov	x10, x30
   18c38:	aa0303f4 	mov	x20, x3
   18c3c:	aa0503f9 	mov	x25, x5
   18c40:	aa0603f6 	mov	x22, x6
   18c44:	aa0703fc 	mov	x28, x7
   18c48:	ad0b0fe2 	stp	q2, q3, [sp, #352]
   18c4c:	3d804fe1 	str	q1, [sp, #304]
   18c50:	97ffafa7 	bl	4aec <heap_alloc_miss>
   18c54:	ad4b0fe2 	ldp	q2, q3, [sp, #352]
   18c58:	aa1c03e7 	mov	x7, x28
   18c5c:	3dc04fe1 	ldr	q1, [sp, #304]
   18c60:	aa1403e3 	mov	x3, x20
   18c64:	aa0a03fe 	mov	x30, x10
   18c68:	52909fe1 	mov	w1, #0x84ff                	// #34047
   18c6c:	f85483b4 	ldur	x20, [x29, #-184]
   18c70:	f940c3f2 	ldr	x18, [sp, #384]
   18c74:	f85203b1 	ldur	x17, [x29, #-224]
   18c78:	f940a3e4 	ldr	x4, [sp, #320]
   18c7c:	f940d7ea 	ldr	x10, [sp, #424]
   18c80:	aa0003fc 	mov	x28, x0
   18c84:	aa1303e0 	mov	x0, x19
   18c88:	f85003b3 	ldur	x19, [x29, #-256]
   18c8c:	aa1603e6 	mov	x6, x22
   18c90:	aa1903e5 	mov	x5, x25
   18c94:	72a06201 	movk	w1, #0x310, lsl #16
   18c98:	17fffea6 	b	18730 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xac4>
   18c9c:	f81183a0 	stur	x0, [x29, #-232]
   18ca0:	aa1403e0 	mov	x0, x20
   18ca4:	aa1503e1 	mov	x1, x21
   18ca8:	52800022 	mov	w2, #0x1                   	// #1
   18cac:	aa1e03ea 	mov	x10, x30
   18cb0:	aa0303f4 	mov	x20, x3
   18cb4:	aa0503f9 	mov	x25, x5
   18cb8:	aa0603f6 	mov	x22, x6
   18cbc:	aa0703f3 	mov	x19, x7
   18cc0:	97ffaf8b 	bl	4aec <heap_alloc_miss>
   18cc4:	aa1903e5 	mov	x5, x25
   18cc8:	aa0003f9 	mov	x25, x0
   18ccc:	aa1303e7 	mov	x7, x19
   18cd0:	a971c7a0 	ldp	x0, x17, [x29, #-232]
   18cd4:	aa1403e3 	mov	x3, x20
   18cd8:	aa0a03fe 	mov	x30, x10
   18cdc:	52909fe1 	mov	w1, #0x84ff                	// #34047
   18ce0:	f85483b4 	ldur	x20, [x29, #-184]
   18ce4:	f940c3f2 	ldr	x18, [sp, #384]
   18ce8:	f940a3e4 	ldr	x4, [sp, #320]
   18cec:	f940d7ea 	ldr	x10, [sp, #424]
   18cf0:	f85003b3 	ldur	x19, [x29, #-256]
   18cf4:	aa1603e6 	mov	x6, x22
   18cf8:	72a06201 	movk	w1, #0x310, lsl #16
   18cfc:	17fffe9b 	b	18768 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xafc>
   18d00:	f81183a0 	stur	x0, [x29, #-232]
   18d04:	aa1403e0 	mov	x0, x20
   18d08:	aa1503e1 	mov	x1, x21
   18d0c:	aa0303f3 	mov	x19, x3
   18d10:	52800023 	mov	w3, #0x1                   	// #1
   18d14:	aa1e03ea 	mov	x10, x30
   18d18:	aa0503f4 	mov	x20, x5
   18d1c:	aa0603f6 	mov	x22, x6
   18d20:	aa0703eb 	mov	x11, x7
   18d24:	97ffb05b 	bl	4e90 <rfc_wrap>
   18d28:	aa0003e2 	mov	x2, x0
   18d2c:	a971c7a0 	ldp	x0, x17, [x29, #-232]
   18d30:	aa1403e5 	mov	x5, x20
   18d34:	aa1303e3 	mov	x3, x19
   18d38:	aa0a03fe 	mov	x30, x10
   18d3c:	52909fe1 	mov	w1, #0x84ff                	// #34047
   18d40:	f85483b4 	ldur	x20, [x29, #-184]
   18d44:	f940c3f2 	ldr	x18, [sp, #384]
   18d48:	f940a3e4 	ldr	x4, [sp, #320]
   18d4c:	f940d7ea 	ldr	x10, [sp, #424]
   18d50:	f85003b3 	ldur	x19, [x29, #-256]
   18d54:	aa0b03e7 	mov	x7, x11
   18d58:	aa1603e6 	mov	x6, x22
   18d5c:	72a06201 	movk	w1, #0x310, lsl #16
   18d60:	17fffe88 	b	18780 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xb14>
   18d64:	f81183a0 	stur	x0, [x29, #-232]
   18d68:	aa1403e0 	mov	x0, x20
   18d6c:	aa1503e1 	mov	x1, x21
   18d70:	aa0803e2 	mov	x2, x8
   18d74:	aa0303f4 	mov	x20, x3
   18d78:	52800023 	mov	w3, #0x1                   	// #1
   18d7c:	aa1e03ea 	mov	x10, x30
   18d80:	aa0503f8 	mov	x24, x5
   18d84:	aa0603f6 	mov	x22, x6
   18d88:	aa1c03f3 	mov	x19, x28
   18d8c:	aa0703fc 	mov	x28, x7
   18d90:	97ffb040 	bl	4e90 <rfc_wrap>
   18d94:	aa0003e8 	mov	x8, x0
   18d98:	a971c7a0 	ldp	x0, x17, [x29, #-232]
   18d9c:	aa1c03e7 	mov	x7, x28
   18da0:	aa1303fc 	mov	x28, x19
   18da4:	aa1403e3 	mov	x3, x20
   18da8:	aa0a03fe 	mov	x30, x10
   18dac:	52909fe1 	mov	w1, #0x84ff                	// #34047
   18db0:	f85483b4 	ldur	x20, [x29, #-184]
   18db4:	f940c3f2 	ldr	x18, [sp, #384]
   18db8:	f940a3e4 	ldr	x4, [sp, #320]
   18dbc:	f940d7ea 	ldr	x10, [sp, #424]
   18dc0:	f85003b3 	ldur	x19, [x29, #-256]
   18dc4:	aa1603e6 	mov	x6, x22
   18dc8:	aa1803e5 	mov	x5, x24
   18dcc:	72a06201 	movk	w1, #0x310, lsl #16
   18dd0:	17fffe75 	b	187a4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xb38>
   18dd4:	aa1e03e0 	mov	x0, x30
   18dd8:	aa1503e1 	mov	x1, x21
   18ddc:	a918cfe3 	stp	x3, x19, [sp, #392]
   18de0:	aa0203f3 	mov	x19, x2
   18de4:	528000a2 	mov	w2, #0x5                   	// #5
   18de8:	aa1e03fb 	mov	x27, x30
   18dec:	f900a3e6 	str	x6, [sp, #320]
   18df0:	aa0703f5 	mov	x21, x7
   18df4:	f900afe4 	str	x4, [sp, #344]
   18df8:	97ffaf3d 	bl	4aec <heap_alloc_miss>
   18dfc:	aa1303e2 	mov	x2, x19
   18e00:	a958cfe3 	ldp	x3, x19, [sp, #392]
   18e04:	f940afe4 	ldr	x4, [sp, #344]
   18e08:	f940a3e6 	ldr	x6, [sp, #320]
   18e0c:	aa1b03fe 	mov	x30, x27
   18e10:	aa1503e7 	mov	x7, x21
   18e14:	17fffcb0 	b	180d4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x468>
   18e18:	aa1e03e0 	mov	x0, x30
   18e1c:	aa1503e1 	mov	x1, x21
   18e20:	52800022 	mov	w2, #0x1                   	// #1
   18e24:	aa1403ec 	mov	x12, x20
   18e28:	aa1e03f4 	mov	x20, x30
   18e2c:	aa0603ea 	mov	x10, x6
   18e30:	f9008ff6 	str	x22, [sp, #280]
   18e34:	aa1803f3 	mov	x19, x24
   18e38:	aa0503f8 	mov	x24, x5
   18e3c:	aa0703fb 	mov	x27, x7
   18e40:	97ffad68 	bl	43e0 <heap_hand>
   18e44:	52909fe3 	mov	w3, #0x84ff                	// #34047
   18e48:	aa1403fe 	mov	x30, x20
   18e4c:	aa0c03f4 	mov	x20, x12
   18e50:	72a06203 	movk	w3, #0x310, lsl #16
   18e54:	aa1b03e7 	mov	x7, x27
   18e58:	14000035 	b	18f2c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x12c0>
   18e5c:	aa1e03e0 	mov	x0, x30
   18e60:	aa1503e1 	mov	x1, x21
   18e64:	52800042 	mov	w2, #0x2                   	// #2
   18e68:	aa1e03ef 	mov	x15, x30
   18e6c:	aa0603ea 	mov	x10, x6
   18e70:	f9008ff6 	str	x22, [sp, #280]
   18e74:	aa1203f6 	mov	x22, x18
   18e78:	aa1803f3 	mov	x19, x24
   18e7c:	aa0503f8 	mov	x24, x5
   18e80:	aa0703fb 	mov	x27, x7
   18e84:	97ffad57 	bl	43e0 <heap_hand>
   18e88:	52909fe3 	mov	w3, #0x84ff                	// #34047
   18e8c:	aa1603f2 	mov	x18, x22
   18e90:	f9408ff6 	ldr	x22, [sp, #280]
   18e94:	72a06203 	movk	w3, #0x310, lsl #16
   18e98:	aa0f03fe 	mov	x30, x15
   18e9c:	aa1b03e7 	mov	x7, x27
   18ea0:	aa1803e5 	mov	x5, x24
   18ea4:	aa1303f8 	mov	x24, x19
   18ea8:	aa0a03e6 	mov	x6, x10
   18eac:	17fffd2c 	b	1835c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x6f0>
   18eb0:	aa0f03e0 	mov	x0, x15
   18eb4:	52800062 	mov	w2, #0x3                   	// #3
   18eb8:	f9008ff6 	str	x22, [sp, #280]
   18ebc:	aa1203f6 	mov	x22, x18
   18ec0:	97ffad48 	bl	43e0 <heap_hand>
   18ec4:	f85283bc 	ldur	x28, [x29, #-216]
   18ec8:	aa1603f2 	mov	x18, x22
   18ecc:	f9408ff6 	ldr	x22, [sp, #280]
   18ed0:	aa0f03fe 	mov	x30, x15
   18ed4:	aa1b03f1 	mov	x17, x27
   18ed8:	aa1303f8 	mov	x24, x19
   18edc:	17fffd72 	b	184a4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x838>
   18ee0:	aa0b8188 	orr	x8, x12, x11, lsl #32
   18ee4:	aa1e03e0 	mov	x0, x30
   18ee8:	aa1503e1 	mov	x1, x21
   18eec:	52800044 	mov	w4, #0x2                   	// #2
   18ef0:	aa1e03f4 	mov	x20, x30
   18ef4:	aa0603ea 	mov	x10, x6
   18ef8:	d358fd03 	lsr	x3, x8, #24
   18efc:	f9008ff6 	str	x22, [sp, #280]
   18f00:	aa1803f3 	mov	x19, x24
   18f04:	aa0503f8 	mov	x24, x5
   18f08:	aa0703ec 	mov	x12, x7
   18f0c:	8b030fc8 	add	x8, x30, x3, lsl #3
   18f10:	a940710b 	ldp	x11, x28, [x8]
   18f14:	97ffad66 	bl	44ac <span_fade>
   18f18:	52909fe3 	mov	w3, #0x84ff                	// #34047
   18f1c:	aa1403fe 	mov	x30, x20
   18f20:	aa1c03f4 	mov	x20, x28
   18f24:	72a06203 	movk	w3, #0x310, lsl #16
   18f28:	aa0c03e7 	mov	x7, x12
   18f2c:	f9408ff6 	ldr	x22, [sp, #280]
   18f30:	aa1803e5 	mov	x5, x24
   18f34:	aa1303f8 	mov	x24, x19
   18f38:	aa0a03e6 	mov	x6, x10
   18f3c:	17fffccd 	b	18270 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x604>
   18f40:	aa0d8208 	orr	x8, x16, x13, lsl #32
   18f44:	aa1e03e0 	mov	x0, x30
   18f48:	aa1503e1 	mov	x1, x21
   18f4c:	aa0b03e2 	mov	x2, x11
   18f50:	52800064 	mov	w4, #0x3                   	// #3
   18f54:	aa1e03ef 	mov	x15, x30
   18f58:	d358fd03 	lsr	x3, x8, #24
   18f5c:	aa0603ea 	mov	x10, x6
   18f60:	f9008ff6 	str	x22, [sp, #280]
   18f64:	aa1203f6 	mov	x22, x18
   18f68:	8b030fc8 	add	x8, x30, x3, lsl #3
   18f6c:	a940310d 	ldp	x13, x12, [x8]
   18f70:	f9400908 	ldr	x8, [x8, #16]
   18f74:	a90eb3e8 	stp	x8, x12, [sp, #232]
   18f78:	97ffad4d 	bl	44ac <span_fade>
   18f7c:	52909fe3 	mov	w3, #0x84ff                	// #34047
   18f80:	aa1603f2 	mov	x18, x22
   18f84:	f9408ff6 	ldr	x22, [sp, #280]
   18f88:	f94073f4 	ldr	x20, [sp, #224]
   18f8c:	72a06203 	movk	w3, #0x310, lsl #16
   18f90:	aa0f03fe 	mov	x30, x15
   18f94:	aa0a03e6 	mov	x6, x10
   18f98:	aa1b03e7 	mov	x7, x27
   18f9c:	aa1803e5 	mov	x5, x24
   18fa0:	aa1303f8 	mov	x24, x19
   18fa4:	17fffcee 	b	1835c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x6f0>
   18fa8:	aa0103fc 	mov	x28, x1
   18fac:	f85303a1 	ldur	x1, [x29, #-208]
   18fb0:	aa1e03e0 	mov	x0, x30
   18fb4:	aa1403e2 	mov	x2, x20
   18fb8:	aa0c03e3 	mov	x3, x12
   18fbc:	528000c4 	mov	w4, #0x6                   	// #6
   18fc0:	aa1e03f4 	mov	x20, x30
   18fc4:	97ffad3a 	bl	44ac <span_fade>
   18fc8:	aa1a03f9 	mov	x25, x26
   18fcc:	f94063fa 	ldr	x26, [sp, #192]
   18fd0:	aa1c03e1 	mov	x1, x28
   18fd4:	aa1403fe 	mov	x30, x20
   18fd8:	aa0a03f1 	mov	x17, x10
   18fdc:	aa0e03fc 	mov	x28, x14
   18fe0:	aa1603f2 	mov	x18, x22
   18fe4:	aa1803f6 	mov	x22, x24
   18fe8:	aa0f03f8 	mov	x24, x15
   18fec:	aa1503e7 	mov	x7, x21
   18ff0:	aa0903fb 	mov	x27, x9
   18ff4:	17fffd32 	b	184bc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x850>
   18ff8:	aa1e03e0 	mov	x0, x30
   18ffc:	aa1503e1 	mov	x1, x21
   19000:	aa0203e9 	mov	x9, x2
   19004:	528000a2 	mov	w2, #0x5                   	// #5
   19008:	aa0e03ea 	mov	x10, x14
   1900c:	aa1e03f4 	mov	x20, x30
   19010:	f900cbf3 	str	x19, [sp, #400]
   19014:	aa1203ed 	mov	x13, x18
   19018:	aa0603f5 	mov	x21, x6
   1901c:	f900afe4 	str	x4, [sp, #344]
   19020:	aa0903ee 	mov	x14, x9
   19024:	aa1c03e9 	mov	x9, x28
   19028:	f9009bf7 	str	x23, [sp, #304]
   1902c:	aa0303fc 	mov	x28, x3
   19030:	aa0a03fb 	mov	x27, x10
   19034:	f90063fa 	str	x26, [sp, #192]
   19038:	aa1803fa 	mov	x26, x24
   1903c:	aa0503f8 	mov	x24, x5
   19040:	f81383b9 	stur	x25, [x29, #-200]
   19044:	aa0703ea 	mov	x10, x7
   19048:	aa1003f3 	mov	x19, x16
   1904c:	f9008ff6 	str	x22, [sp, #280]
   19050:	97ffaea7 	bl	4aec <heap_alloc_miss>
   19054:	aa0a03e7 	mov	x7, x10
   19058:	a973abb9 	ldp	x25, x10, [x29, #-200]
   1905c:	aa1303f0 	mov	x16, x19
   19060:	aa1803e5 	mov	x5, x24
   19064:	aa1a03f8 	mov	x24, x26
   19068:	f9408ff6 	ldr	x22, [sp, #280]
   1906c:	f94063fa 	ldr	x26, [sp, #192]
   19070:	f9409bf7 	ldr	x23, [sp, #304]
   19074:	f940afe4 	ldr	x4, [sp, #344]
   19078:	f940cbf3 	ldr	x19, [sp, #400]
   1907c:	aa1403fe 	mov	x30, x20
   19080:	aa1c03e3 	mov	x3, x28
   19084:	aa0903fc 	mov	x28, x9
   19088:	aa0e03e2 	mov	x2, x14
   1908c:	aa1b03ee 	mov	x14, x27
   19090:	aa1503e6 	mov	x6, x21
   19094:	aa0d03f2 	mov	x18, x13
   19098:	17fffe36 	b	18970 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xd04>
   1909c:	aa1e03e0 	mov	x0, x30
   190a0:	aa1503e1 	mov	x1, x21
   190a4:	2a1f03e2 	mov	w2, wzr
   190a8:	aa1403ed 	mov	x13, x20
   190ac:	aa1e03f4 	mov	x20, x30
   190b0:	aa0603ea 	mov	x10, x6
   190b4:	f9008ff6 	str	x22, [sp, #280]
   190b8:	aa1803f3 	mov	x19, x24
   190bc:	aa0503f8 	mov	x24, x5
   190c0:	aa0703fb 	mov	x27, x7
   190c4:	97ffacc7 	bl	43e0 <heap_hand>
   190c8:	52909fe3 	mov	w3, #0x84ff                	// #34047
   190cc:	f9408ff6 	ldr	x22, [sp, #280]
   190d0:	aa1403fe 	mov	x30, x20
   190d4:	72a06203 	movk	w3, #0x310, lsl #16
   190d8:	aa0d03f4 	mov	x20, x13
   190dc:	aa1b03e7 	mov	x7, x27
   190e0:	aa1803e5 	mov	x5, x24
   190e4:	aa1303f8 	mov	x24, x19
   190e8:	aa0a03e6 	mov	x6, x10
   190ec:	17fffc51 	b	18230 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x5c4>
   190f0:	aa1e03e0 	mov	x0, x30
   190f4:	aa1503e1 	mov	x1, x21
   190f8:	2a1f03e2 	mov	w2, wzr
   190fc:	aa1e03ef 	mov	x15, x30
   19100:	aa0603ea 	mov	x10, x6
   19104:	f9008ff6 	str	x22, [sp, #280]
   19108:	aa1203f6 	mov	x22, x18
   1910c:	97ffacb5 	bl	43e0 <heap_hand>
   19110:	52909fe3 	mov	w3, #0x84ff                	// #34047
   19114:	aa1603f2 	mov	x18, x22
   19118:	f9408ff6 	ldr	x22, [sp, #280]
   1911c:	72a06203 	movk	w3, #0x310, lsl #16
   19120:	aa0f03fe 	mov	x30, x15
   19124:	aa0a03e6 	mov	x6, x10
   19128:	17fffc7b 	b	18314 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x6a8>
   1912c:	aa0103ee 	mov	x14, x1
   19130:	f85303a1 	ldur	x1, [x29, #-208]
   19134:	aa1e03e0 	mov	x0, x30
   19138:	2a1f03e2 	mov	w2, wzr
   1913c:	aa1e03f4 	mov	x20, x30
   19140:	97ffaca8 	bl	43e0 <heap_hand>
   19144:	52909fe3 	mov	w3, #0x84ff                	// #34047
   19148:	aa0e03e1 	mov	x1, x14
   1914c:	aa1403fe 	mov	x30, x20
   19150:	72a06203 	movk	w3, #0x310, lsl #16
   19154:	17fffcb2 	b	1841c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0x7b0>
   19158:	aa1e03e0 	mov	x0, x30
   1915c:	aa1503e1 	mov	x1, x21
   19160:	aa0203ed 	mov	x13, x2
   19164:	528000a2 	mov	w2, #0x5                   	// #5
   19168:	aa1e03f4 	mov	x20, x30
   1916c:	f900d7e9 	str	x9, [sp, #424]
   19170:	aa0603ea 	mov	x10, x6
   19174:	aa0403f5 	mov	x21, x4
   19178:	f81283bc 	stur	x28, [x29, #-216]
   1917c:	f81383b8 	stur	x24, [x29, #-200]
   19180:	aa0503f8 	mov	x24, x5
   19184:	aa0e03fb 	mov	x27, x14
   19188:	f9009bf7 	str	x23, [sp, #304]
   1918c:	aa0703ee 	mov	x14, x7
   19190:	f90063fa 	str	x26, [sp, #192]
   19194:	97ffae56 	bl	4aec <heap_alloc_miss>
   19198:	aa1803e5 	mov	x5, x24
   1919c:	a97363b2 	ldp	x18, x24, [x29, #-208]
   191a0:	f94063fa 	ldr	x26, [sp, #192]
   191a4:	f9409bf7 	ldr	x23, [sp, #304]
   191a8:	aa0a03e6 	mov	x6, x10
   191ac:	f85283bc 	ldur	x28, [x29, #-216]
   191b0:	f940cbf0 	ldr	x16, [sp, #400]
   191b4:	aa1403fe 	mov	x30, x20
   191b8:	f85403aa 	ldur	x10, [x29, #-192]
   191bc:	f940d7e9 	ldr	x9, [sp, #424]
   191c0:	aa0e03e7 	mov	x7, x14
   191c4:	aa1b03ee 	mov	x14, x27
   191c8:	aa0d03e2 	mov	x2, x13
   191cc:	aa1503e4 	mov	x4, x21
   191d0:	17fffe0a 	b	189f8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0+0xd8c>

