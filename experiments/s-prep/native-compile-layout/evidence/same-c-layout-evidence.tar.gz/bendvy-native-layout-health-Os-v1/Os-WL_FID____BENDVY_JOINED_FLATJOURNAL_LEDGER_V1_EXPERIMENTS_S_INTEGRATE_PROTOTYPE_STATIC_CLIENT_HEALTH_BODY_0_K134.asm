   16b94:	d103c3ff 	sub	sp, sp, #0xf0
   16b98:	a90e7bfd 	stp	x29, x30, [sp, #224]
   16b9c:	910383fd 	add	x29, sp, #0xe0
   16ba0:	aa0c03f0 	mov	x16, x12
   16ba4:	aa0603f1 	mov	x17, x6
   16ba8:	a93daba4 	stp	x4, x10, [x29, #-40]
   16bac:	a93e8fb0 	stp	x16, x3, [x29, #-24]
   16bb0:	aa1c03e3 	mov	x3, x28
   16bb4:	aa1a03fc 	mov	x28, x26
   16bb8:	a944fba6 	ldp	x6, x30, [x29, #72]
   16bbc:	b9405ba8 	ldr	w8, [x29, #88]
   16bc0:	a943cfb8 	ldp	x24, x19, [x29, #56]
   16bc4:	f9400ba2 	ldr	x2, [x29, #16]
   16bc8:	a942ebac 	ldp	x12, x26, [x29, #40]
   16bcc:	7100051f 	cmp	w8, #0x1
   16bd0:	a94193b2 	ldp	x18, x4, [x29, #24]
   16bd4:	54000681 	b.ne	16ca4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K134+0x110>  // b.any
   16bd8:	aa1603e8 	mov	x8, x22
   16bdc:	a93cc7a3 	stp	x3, x17, [x29, #-56]
   16be0:	f85f03a3 	ldur	x3, [x29, #-16]
   16be4:	a93ae3a5 	stp	x5, x24, [x29, #-88]
   16be8:	b85f0d10 	ldr	w16, [x8, #-16]!
   16bec:	a93b9fb2 	stp	x18, x7, [x29, #-72]
   16bf0:	b85f0111 	ldur	w17, [x8, #-16]
   16bf4:	b85f8118 	ldur	w24, [x8, #-8]
   16bf8:	b9400912 	ldr	w18, [x8, #8]
   16bfc:	a939eba4 	stp	x4, x26, [x29, #-104]
   16c00:	f94033a4 	ldr	x4, [x29, #96]
   16c04:	0b110311 	add	w17, w24, w17
   16c08:	0b120210 	add	w16, w16, w18
   16c0c:	0b100238 	add	w24, w17, w16
   16c10:	34000937 	cbz	w23, 16d34 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K134+0x1a0>
   16c14:	52800590 	mov	w16, #0x2c                  	// #44
   16c18:	2a1c03fa 	mov	w26, w28
   16c1c:	2a1903f9 	mov	w25, w25
   16c20:	a93e42d8 	stp	x24, x16, [x22, #-32]
   16c24:	f85b03b0 	ldur	x16, [x29, #-80]
   16c28:	2a0b03eb 	mov	w11, w11
   16c2c:	a904fba6 	stp	x6, x30, [x29, #72]
   16c30:	2a0d03ed 	mov	w13, w13
   16c34:	2a0e03ee 	mov	w14, w14
   16c38:	a903cfb0 	stp	x16, x19, [x29, #56]
   16c3c:	a979c3aa 	ldp	x10, x16, [x29, #-104]
   16c40:	2a0903e9 	mov	w9, w9
   16c44:	2a0f03ef 	mov	w15, w15
   16c48:	aa0803f6 	mov	x22, x8
   16c4c:	2a1003f0 	mov	w16, w16
   16c50:	f9001bb0 	str	x16, [x29, #48]
   16c54:	2a0c03f0 	mov	w16, w12
   16c58:	f90017b0 	str	x16, [x29, #40]
   16c5c:	2a0a03f0 	mov	w16, w10
   16c60:	f90013b0 	str	x16, [x29, #32]
   16c64:	f85b83b0 	ldur	x16, [x29, #-72]
   16c68:	a97e33aa 	ldp	x10, x12, [x29, #-32]
   16c6c:	2a1003f0 	mov	w16, w16
   16c70:	f9000fb0 	str	x16, [x29, #24]
   16c74:	2a0203f0 	mov	w16, w2
   16c78:	f9000bb0 	str	x16, [x29, #16]
   16c7c:	f85a83b0 	ldur	x16, [x29, #-88]
   16c80:	2a1003e5 	mov	w5, w16
   16c84:	a97c73b0 	ldp	x16, x28, [x29, #-64]
   16c88:	2a1003e7 	mov	w7, w16
   16c8c:	11000490 	add	w16, w4, #0x1
   16c90:	a97d13a6 	ldp	x6, x4, [x29, #-48]
   16c94:	f9002fb0 	str	x16, [x29, #88]
   16c98:	a94e7bfd 	ldp	x29, x30, [sp, #224]
   16c9c:	9103c3ff 	add	sp, sp, #0xf0
   16ca0:	17ffc5e3 	b	842c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0>
   16ca4:	b85d8ec8 	ldr	w8, [x22, #-40]!
   16ca8:	90000cd0 	adrp	x16, 1ae000 <io_eff_rows+0xff0b0>
   16cac:	913fa210 	add	x16, x16, #0xfe8
   16cb0:	aa1103ea 	mov	x10, x17
   16cb4:	12800011 	mov	w17, #0xffffffff            	// #-1
   16cb8:	f8687a08 	ldr	x8, [x16, x8, lsl #3]
   16cbc:	a9041bb3 	stp	x19, x6, [x29, #64]
   16cc0:	aa0a03e6 	mov	x6, x10
   16cc4:	2a1203f0 	mov	w16, w18
   16cc8:	a90547be 	stp	x30, x17, [x29, #80]
   16ccc:	2a1903f9 	mov	w25, w25
   16cd0:	f81d03a8 	stur	x8, [x29, #-48]
   16cd4:	2a1a03e8 	mov	w8, w26
   16cd8:	2a1c03fa 	mov	w26, w28
   16cdc:	a90363a8 	stp	x8, x24, [x29, #48]
   16ce0:	2a0c03e8 	mov	w8, w12
   16ce4:	aa0303fc 	mov	x28, x3
   16ce8:	f90017a8 	str	x8, [x29, #40]
   16cec:	2a0403e8 	mov	w8, w4
   16cf0:	2a0503e5 	mov	w5, w5
   16cf4:	a97e8fac 	ldp	x12, x3, [x29, #-24]
   16cf8:	f90013a8 	str	x8, [x29, #32]
   16cfc:	a97daba4 	ldp	x4, x10, [x29, #-40]
   16d00:	2a0203e8 	mov	w8, w2
   16d04:	2a0703e7 	mov	w7, w7
   16d08:	2a0b03eb 	mov	w11, w11
   16d0c:	2a0d03ed 	mov	w13, w13
   16d10:	2a0e03ee 	mov	w14, w14
   16d14:	2a0903e9 	mov	w9, w9
   16d18:	2a0f03ef 	mov	w15, w15
   16d1c:	a90143a8 	stp	x8, x16, [x29, #16]
   16d20:	52800398 	mov	w24, #0x1c                  	// #28
   16d24:	f85d03a2 	ldur	x2, [x29, #-48]
   16d28:	a94e7bfd 	ldp	x29, x30, [sp, #224]
   16d2c:	9103c3ff 	add	sp, sp, #0xf0
   16d30:	d61f0040 	br	x2
   16d34:	a906bfe9 	stp	x9, x15, [sp, #104]
   16d38:	a97ca2c9 	ldp	x9, x8, [x22, #-56]
   16d3c:	f94016b7 	ldr	x23, [x21, #40]
   16d40:	aa1c03fa 	mov	x26, x28
   16d44:	a9018be4 	stp	x4, x2, [sp, #24]
   16d48:	a9029bf3 	stp	x19, x6, [sp, #40]
   16d4c:	a903fbeb 	stp	x11, x30, [sp, #56]
   16d50:	a90483ed 	stp	x13, x0, [sp, #72]
   16d54:	a905bbe1 	stp	x1, x14, [sp, #88]
   16d58:	a900a7e8 	stp	x8, x9, [sp, #8]
   16d5c:	b4000af7 	cbz	x23, 16eb8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K134+0x324>
   16d60:	f8777a88 	ldr	x8, [x20, x23, lsl #3]
   16d64:	f94096a9 	ldr	x9, [x21, #296]
   16d68:	f90016a8 	str	x8, [x21, #40]
   16d6c:	d1008128 	sub	x8, x9, #0x20
   16d70:	f90096a8 	str	x8, [x21, #296]
   16d74:	8b170e9c 	add	x28, x20, x23, lsl #3
   16d78:	52801fe1 	mov	w1, #0xff                  	// #255
   16d7c:	52801b02 	mov	w2, #0xd8                  	// #216
   16d80:	aa0c03f3 	mov	x19, x12
   16d84:	91002380 	add	x0, x28, #0x8
   16d88:	97ffb342 	bl	3a90 <memset@plt>
   16d8c:	a940afe9 	ldp	x9, x11, [sp, #8]
   16d90:	52800028 	mov	w8, #0x1                   	// #1
   16d94:	f9000398 	str	x24, [x28]
   16d98:	aa09810a 	orr	x10, x8, x9, lsl #32
   16d9c:	d2c58009 	mov	x9, #0x2c0000000000        	// #48378511622144
   16da0:	f2e0a009 	movk	x9, #0x500, lsl #48
   16da4:	aa0902e9 	orr	x9, x23, x9
   16da8:	a90e2b8b 	stp	x11, x10, [x28, #224]
   16dac:	a93ca2c9 	stp	x9, x8, [x22, #-56]
   16db0:	f94016a0 	ldr	x0, [x21, #40]
   16db4:	b40008e0 	cbz	x0, 16ed0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K134+0x33c>
   16db8:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   16dbc:	f94096aa 	ldr	x10, [x21, #296]
   16dc0:	f90016a8 	str	x8, [x21, #40]
   16dc4:	d1008148 	sub	x8, x10, #0x20
   16dc8:	f90096a8 	str	x8, [x21, #296]
   16dcc:	8b000e88 	add	x8, x20, x0, lsl #3
   16dd0:	d2c0002a 	mov	x10, #0x100000000           	// #4294967296
   16dd4:	f9403beb 	ldr	x11, [sp, #112]
   16dd8:	a97ab7ae 	ldp	x14, x13, [x29, #-88]
   16ddc:	f85c83ac 	ldur	x12, [x29, #-56]
   16de0:	a90e2909 	stp	x9, x10, [x8, #224]
   16de4:	2a1903e9 	mov	w9, w25
   16de8:	2a1a03ea 	mov	w10, w26
   16dec:	a9002909 	stp	x9, x10, [x8]
   16df0:	a94527ea 	ldp	x10, x9, [sp, #80]
   16df4:	a979bfb0 	ldp	x16, x15, [x29, #-104]
   16df8:	a901311b 	stp	x27, x12, [x8, #16]
   16dfc:	a902250a 	stp	x10, x9, [x8, #32]
   16e00:	f85f03aa 	ldur	x10, [x29, #-16]
   16e04:	f85d83a9 	ldur	x9, [x29, #-40]
   16e08:	a903250a 	stp	x10, x9, [x8, #48]
   16e0c:	2a0e03e9 	mov	w9, w14
   16e10:	f85d03aa 	ldur	x10, [x29, #-48]
   16e14:	f9002109 	str	x9, [x8, #64]
   16e18:	f85c03a9 	ldur	x9, [x29, #-64]
   16e1c:	2a0903e9 	mov	w9, w9
   16e20:	a904a50a 	stp	x10, x9, [x8, #72]
   16e24:	f9401fe9 	ldr	x9, [sp, #56]
   16e28:	f85e03aa 	ldur	x10, [x29, #-32]
   16e2c:	2a0903e9 	mov	w9, w9
   16e30:	a905a50a 	stp	x10, x9, [x8, #88]
   16e34:	f85e83a9 	ldur	x9, [x29, #-24]
   16e38:	f94033ea 	ldr	x10, [sp, #96]
   16e3c:	f9003509 	str	x9, [x8, #104]
   16e40:	f94027e9 	ldr	x9, [sp, #72]
   16e44:	2a0a03ea 	mov	w10, w10
   16e48:	2a0903e9 	mov	w9, w9
   16e4c:	a9072909 	stp	x9, x10, [x8, #112]
   16e50:	f94037e9 	ldr	x9, [sp, #104]
   16e54:	2a0b03ea 	mov	w10, w11
   16e58:	2a0903e9 	mov	w9, w9
   16e5c:	a9082909 	stp	x9, x10, [x8, #128]
   16e60:	f94013e9 	ldr	x9, [sp, #32]
   16e64:	f85b83aa 	ldur	x10, [x29, #-72]
   16e68:	2a0903e9 	mov	w9, w9
   16e6c:	2a0a03ea 	mov	w10, w10
   16e70:	a9092909 	stp	x9, x10, [x8, #144]
   16e74:	2a1003e9 	mov	w9, w16
   16e78:	2a1303ea 	mov	w10, w19
   16e7c:	a90a2909 	stp	x9, x10, [x8, #160]
   16e80:	2a0f03e9 	mov	w9, w15
   16e84:	a90b3509 	stp	x9, x13, [x8, #176]
   16e88:	a942a7ea 	ldp	x10, x9, [sp, #40]
   16e8c:	a90c250a 	stp	x10, x9, [x8, #192]
   16e90:	d2c08009 	mov	x9, #0x40000000000         	// #4398046511104
   16e94:	f9400fea 	ldr	x10, [sp, #24]
   16e98:	f2e0a009 	movk	x9, #0x500, lsl #48
   16e9c:	aa090000 	orr	x0, x0, x9
   16ea0:	f94023e9 	ldr	x9, [sp, #64]
   16ea4:	1100054a 	add	w10, w10, #0x1
   16ea8:	a90d2909 	stp	x9, x10, [x8, #208]
   16eac:	a94e7bfd 	ldp	x29, x30, [sp, #224]
   16eb0:	9103c3ff 	add	sp, sp, #0xf0
   16eb4:	d65f03c0 	ret
   16eb8:	aa1403e0 	mov	x0, x20
   16ebc:	aa1503e1 	mov	x1, x21
   16ec0:	528000a2 	mov	w2, #0x5                   	// #5
   16ec4:	97ffb70a 	bl	4aec <heap_alloc_miss>
   16ec8:	aa0003f7 	mov	x23, x0
   16ecc:	17ffffaa 	b	16d74 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K134+0x1e0>
   16ed0:	aa1403e0 	mov	x0, x20
   16ed4:	aa1503e1 	mov	x1, x21
   16ed8:	528000a2 	mov	w2, #0x5                   	// #5
   16edc:	97ffb704 	bl	4aec <heap_alloc_miss>
   16ee0:	17ffffbb 	b	16dcc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K134+0x238>

