    4e90:	f81b0fef 	str	x15, [sp, #-80]!
    4e94:	a90137ee 	stp	x14, x13, [sp, #16]
    4e98:	a9022fec 	stp	x12, x11, [sp, #32]
    4e9c:	a90327ea 	stp	x10, x9, [sp, #48]
    4ea0:	a9047bfd 	stp	x29, x30, [sp, #64]
    4ea4:	910103fd 	add	x29, sp, #0x40
    4ea8:	d378f848 	ubfx	x8, x2, #56, #7
    4eac:	f100151f 	cmp	x8, #0x5
    4eb0:	540003c0 	b.eq	4f28 <rfc_wrap+0x98>  // b.none
    4eb4:	f1000d1f 	cmp	x8, #0x3
    4eb8:	54000380 	b.eq	4f28 <rfc_wrap+0x98>  // b.none
    4ebc:	f9400028 	ldr	x8, [x1]
    4ec0:	2a0303ea 	mov	w10, w3
    4ec4:	aa0203e9 	mov	x9, x2
    4ec8:	aa0003eb 	mov	x11, x0
    4ecc:	b4000248 	cbz	x8, 4f14 <rfc_wrap+0x84>
    4ed0:	f8687970 	ldr	x16, [x11, x8, lsl #3]
    4ed4:	f9408031 	ldr	x17, [x1, #256]
    4ed8:	f9000030 	str	x16, [x1]
    4edc:	d1000630 	sub	x16, x17, #0x1
    4ee0:	f9008030 	str	x16, [x1, #256]
    4ee4:	2a0a03f1 	mov	w17, w10
    4ee8:	92585930 	and	x16, x9, #0x7fffff0000000000
    4eec:	aa096231 	orr	x17, x17, x9, lsl #24
    4ef0:	aa080210 	orr	x16, x16, x8
    4ef4:	b2410200 	orr	x0, x16, #0x8000000000000000
    4ef8:	f8287971 	str	x17, [x11, x8, lsl #3]
    4efc:	a9447bfd 	ldp	x29, x30, [sp, #64]
    4f00:	a94327ea 	ldp	x10, x9, [sp, #48]
    4f04:	a9422fec 	ldp	x12, x11, [sp, #32]
    4f08:	a94137ee 	ldp	x14, x13, [sp, #16]
    4f0c:	f84507ef 	ldr	x15, [sp], #80
    4f10:	d65f03c0 	ret
    4f14:	aa0b03e0 	mov	x0, x11
    4f18:	2a1f03e2 	mov	w2, wzr
    4f1c:	97fffef4 	bl	4aec <heap_alloc_miss>
    4f20:	aa0003e8 	mov	x8, x0
    4f24:	17fffff0 	b	4ee4 <rfc_wrap+0x54>
    4f28:	90000440 	adrp	x0, 8c000 <STAT_IMG+0x1840>
    4f2c:	9116e000 	add	x0, x0, #0x5b8
    4f30:	94000233 	bl	57fc <err_fail>

