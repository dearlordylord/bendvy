    5f94:	d101c3ff 	sub	sp, sp, #0x70
    5f98:	a9017bfd 	stp	x29, x30, [sp, #16]
    5f9c:	a9026ffc 	stp	x28, x27, [sp, #32]
    5fa0:	a90367fa 	stp	x26, x25, [sp, #48]
    5fa4:	a9045ff8 	stp	x24, x23, [sp, #64]
    5fa8:	a90557f6 	stp	x22, x21, [sp, #80]
    5fac:	a9064ff4 	stp	x20, x19, [sp, #96]
    5fb0:	910043fd 	add	x29, sp, #0x10
    5fb4:	5290a00e 	mov	w14, #0x8500                	// #34048
    5fb8:	aa0203f5 	mov	x21, x2
    5fbc:	aa0103f3 	mov	x19, x1
    5fc0:	72a0620e 	movk	w14, #0x310, lsl #16
    5fc4:	aa0003f4 	mov	x20, x0
    5fc8:	aa1f03f7 	mov	x23, xzr
    5fcc:	aa1f03f8 	mov	x24, xzr
    5fd0:	91040039 	add	x25, x1, #0x100
    5fd4:	9100201a 	add	x26, x0, #0x8
    5fd8:	d10005cf 	sub	x15, x14, #0x1
    5fdc:	f0000e16 	adrp	x22, 1c8000 <ALC+0x17e00>
    5fe0:	5280003b 	mov	w27, #0x1                   	// #1
    5fe4:	d2c0201c 	mov	x28, #0x10000000000         	// #1099511627776
    5fe8:	b6f804b5 	tbz	x21, #63, 607c <term_drop+0xe8>
    5fec:	92787ea8 	and	x8, x21, #0xffffffff00
    5ff0:	eb0f011f 	cmp	x8, x15
    5ff4:	54000449 	b.ls	607c <term_drop+0xe8>  // b.plast
    5ff8:	b10006bf 	cmn	x21, #0x1
    5ffc:	54000400 	b.eq	607c <term_drop+0xe8>  // b.none
    6000:	924716a8 	and	x8, x21, #0x7e00000000000000
    6004:	b40003c8 	cbz	x8, 607c <term_drop+0xe8>
    6008:	92409ebc 	and	x28, x21, #0xffffffffff
    600c:	12800000 	mov	w0, #0xffffffff            	// #-1
    6010:	f90007ef 	str	x15, [sp, #8]
    6014:	8b1c0e96 	add	x22, x20, x28, lsl #3
    6018:	aa1603e1 	mov	x1, x22
    601c:	94022af5 	bl	90bf0 <__aarch64_ldadd4_rel>
    6020:	12005c08 	and	w8, w0, #0xffffff
    6024:	7100051f 	cmp	w8, #0x1
    6028:	54000701 	b.ne	6108 <term_drop+0x174>  // b.any
    602c:	88dffedf 	ldar	wzr, [x22]
    6030:	f9400268 	ldr	x8, [x19]
    6034:	92585ab5 	and	x21, x21, #0x7fffff0000000000
    6038:	f94002c9 	ldr	x9, [x22]
    603c:	f90002c8 	str	x8, [x22]
    6040:	d0000e16 	adrp	x22, 1c8000 <ALC+0x17e00>
    6044:	f9408268 	ldr	x8, [x19, #256]
    6048:	f900027c 	str	x28, [x19]
    604c:	b358fd35 	bfxil	x21, x9, #24, #40
    6050:	91000508 	add	x8, x8, #0x1
    6054:	f9008268 	str	x8, [x19, #256]
    6058:	395402ca 	ldrb	w10, [x22, #1280]
    605c:	7100055f 	cmp	w10, #0x1
    6060:	54001301 	b.ne	62c0 <term_drop+0x32c>  // b.any
    6064:	f140211f 	cmp	x8, #0x8, lsl #12
    6068:	540012c2 	b.cs	62c0 <term_drop+0x32c>  // b.hs, b.nlast
    606c:	5290a00e 	mov	w14, #0x8500                	// #34048
    6070:	f94007ef 	ldr	x15, [sp, #8]
    6074:	d2c0201c 	mov	x28, #0x10000000000         	// #1099511627776
    6078:	72a0620e 	movk	w14, #0x310, lsl #16
    607c:	92787ea8 	and	x8, x21, #0xffffffff00
    6080:	eb0e011f 	cmp	x8, x14
    6084:	540004c3 	b.cc	611c <term_drop+0x188>  // b.lo, b.ul, b.last
    6088:	b10006bf 	cmn	x21, #0x1
    608c:	54000480 	b.eq	611c <term_drop+0x188>  // b.none
    6090:	924716a8 	and	x8, x21, #0x7e00000000000000
    6094:	b4000448 	cbz	x8, 611c <term_drop+0x188>
    6098:	d378faa9 	ubfx	x9, x21, #56, #7
    609c:	f100113f 	cmp	x9, #0x4
    60a0:	54000421 	b.ne	6124 <term_drop+0x190>  // b.any
    60a4:	d368b2a8 	ubfx	x8, x21, #40, #5
    60a8:	92481aa9 	and	x9, x21, #0x7f00000000000000
    60ac:	d2e0c00b 	mov	x11, #0x600000000000000     	// #432345564227567616
    60b0:	7100050a 	subs	w10, w8, #0x1
    60b4:	1a8a33ea 	csel	w10, wzr, w10, cc	// cc = lo, ul, last
    60b8:	eb0b013f 	cmp	x9, x11
    60bc:	1a8a0102 	csel	w2, w8, w10, eq	// eq = none
    60c0:	92409ea8 	and	x8, x21, #0xffffffffff
    60c4:	f8625a69 	ldr	x9, [x19, w2, uxtw #3]
    60c8:	f8287a89 	str	x9, [x20, x8, lsl #3]
    60cc:	f8225a68 	str	x8, [x19, w2, uxtw #3]
    60d0:	9ac22368 	lsl	x8, x27, x2
    60d4:	f8625b29 	ldr	x9, [x25, w2, uxtw #3]
    60d8:	8b080128 	add	x8, x9, x8
    60dc:	f8225b28 	str	x8, [x25, w2, uxtw #3]
    60e0:	395402c9 	ldrb	w9, [x22, #1280]
    60e4:	7100053f 	cmp	w9, #0x1
    60e8:	54000061 	b.ne	60f4 <term_drop+0x160>  // b.any
    60ec:	f140211f 	cmp	x8, #0x8, lsl #12
    60f0:	54000163 	b.cc	611c <term_drop+0x188>  // b.lo, b.ul, b.last
    60f4:	aa1403e0 	mov	x0, x20
    60f8:	aa1303e1 	mov	x1, x19
    60fc:	97fff931 	bl	45c0 <heap_hand>
    6100:	b5000738 	cbnz	x24, 61e4 <term_drop+0x250>
    6104:	14000074 	b	62d4 <term_drop+0x340>
    6108:	5290a00e 	mov	w14, #0x8500                	// #34048
    610c:	f94007ef 	ldr	x15, [sp, #8]
    6110:	d0000e16 	adrp	x22, 1c8000 <ALC+0x17e00>
    6114:	72a0620e 	movk	w14, #0x310, lsl #16
    6118:	d2c0201c 	mov	x28, #0x10000000000         	// #1099511627776
    611c:	b5000658 	cbnz	x24, 61e4 <term_drop+0x250>
    6120:	1400006d 	b	62d4 <term_drop+0x340>
    6124:	f100193f 	cmp	x9, #0x6
    6128:	540001a0 	b.eq	615c <term_drop+0x1c8>  // b.none
    612c:	d368dea8 	ubfx	x8, x21, #40, #16
    6130:	f100093f 	cmp	x9, #0x2
    6134:	540001c1 	b.ne	616c <term_drop+0x1d8>  // b.any
    6138:	d37ff908 	lsl	x8, x8, #1
    613c:	d000044a 	adrp	x10, 90000 <spin_345+0x2044>
    6140:	9136fd4a 	add	x10, x10, #0xdbf
    6144:	38686948 	ldrb	w8, [x10, x8]
    6148:	7103e11f 	cmp	w8, #0xf8
    614c:	54000223 	b.cc	6190 <term_drop+0x1fc>  // b.lo, b.ul, b.last
    6150:	5103c109 	sub	w9, w8, #0xf0
    6154:	321a0129 	orr	w9, w9, #0x40
    6158:	14000017 	b	61b4 <term_drop+0x220>
    615c:	d368b2a9 	ubfx	x9, x21, #40, #5
    6160:	2a1f03e8 	mov	w8, wzr
    6164:	321a0129 	orr	w9, w9, #0x40
    6168:	14000013 	b	61b4 <term_drop+0x220>
    616c:	8b080508 	add	x8, x8, x8, lsl #1
    6170:	d000044a 	adrp	x10, 90000 <spin_345+0x2044>
    6174:	913d3d4a 	add	x10, x10, #0xf4f
    6178:	f1000d3f 	cmp	x9, #0x3
    617c:	38686948 	ldrb	w8, [x10, x8]
    6180:	1a9f17ea 	cset	w10, eq	// eq = none
    6184:	4b0a0108 	sub	w8, w8, w10
    6188:	7103e11f 	cmp	w8, #0xf8
    618c:	54fffe22 	b.cs	6150 <term_drop+0x1bc>  // b.hs, b.nlast
    6190:	1100090a 	add	w10, w8, #0x2
    6194:	f100153f 	cmp	x9, #0x5
    6198:	5280040b 	mov	w11, #0x20                  	// #32
    619c:	1a880149 	csel	w9, w10, w8, eq	// eq = none
    61a0:	7100052a 	subs	w10, w9, #0x1
    61a4:	5ac0114a 	clz	w10, w10
    61a8:	7100053f 	cmp	w9, #0x1
    61ac:	4b0a016a 	sub	w10, w11, w10
    61b0:	1a9f8149 	csel	w9, w10, wzr, hi	// hi = pmore
    61b4:	d3503d08 	lsl	x8, x8, #48
    61b8:	92409eaa 	and	x10, x21, #0xffffffffff
    61bc:	f86a7a97 	ldr	x23, [x20, x10, lsl #3]
    61c0:	f82a7a98 	str	x24, [x20, x10, lsl #3]
    61c4:	aa09e108 	orr	x8, x8, x9, lsl #56
    61c8:	aa0a0118 	orr	x24, x8, x10
    61cc:	b50000d8 	cbnz	x24, 61e4 <term_drop+0x250>
    61d0:	14000041 	b	62d4 <term_drop+0x340>
    61d4:	aa1403e0 	mov	x0, x20
    61d8:	aa1303e1 	mov	x1, x19
    61dc:	97fff8f9 	bl	45c0 <heap_hand>
    61e0:	b40007b8 	cbz	x24, 62d4 <term_drop+0x340>
    61e4:	d37eff08 	lsr	x8, x24, #62
    61e8:	d368bf09 	ubfx	x9, x24, #40, #8
    61ec:	d378ff02 	lsr	x2, x24, #56
    61f0:	92409f0a 	and	x10, x24, #0xffffffffff
    61f4:	b4000148 	cbz	x8, 621c <term_drop+0x288>
    61f8:	1ac2236b 	lsl	w11, w27, w2
    61fc:	7100093f 	cmp	w9, #0x2
    6200:	1200144d 	and	w13, w2, #0x3f
    6204:	540003a1 	b.ne	6278 <term_drop+0x2e4>  // b.any
    6208:	f86a7b4c 	ldr	x12, [x26, x10, lsl #3]
    620c:	2a0d03e2 	mov	w2, w13
    6210:	6b0b019f 	cmp	w12, w11
    6214:	540000c3 	b.cc	622c <term_drop+0x298>  // b.lo, b.ul, b.last
    6218:	1400001c 	b	6288 <term_drop+0x2f4>
    621c:	d370df0b 	ubfx	x11, x24, #48, #8
    6220:	2a0903ec 	mov	w12, w9
    6224:	6b0b019f 	cmp	w12, w11
    6228:	54000302 	b.cs	6288 <term_drop+0x2f4>  // b.hs, b.nlast
    622c:	aa1703f5 	mov	x21, x23
    6230:	340000cc 	cbz	w12, 6248 <term_drop+0x2b4>
    6234:	8b0a0e8b 	add	x11, x20, x10, lsl #3
    6238:	f86c5975 	ldr	x21, [x11, w12, uxtw #3]
    623c:	b4000068 	cbz	x8, 6248 <term_drop+0x2b4>
    6240:	1100058b 	add	w11, w12, #0x1
    6244:	f82a7b4b 	str	x11, [x26, x10, lsl #3]
    6248:	7100053f 	cmp	w9, #0x1
    624c:	fa408904 	ccmp	x8, #0x0, #0x4, hi	// hi = pmore
    6250:	8b1c0308 	add	x8, x24, x28
    6254:	9a881318 	csel	x24, x24, x8, ne	// ne = any
    6258:	b10006bf 	cmn	x21, #0x1
    625c:	54fffc20 	b.eq	61e0 <term_drop+0x24c>  // b.none
    6260:	924716a8 	and	x8, x21, #0x7e00000000000000
    6264:	b4fffbe8 	cbz	x8, 61e0 <term_drop+0x24c>
    6268:	92787ea8 	and	x8, x21, #0xffffffff00
    626c:	eb0e011f 	cmp	x8, x14
    6270:	54fffb83 	b.cc	61e0 <term_drop+0x24c>  // b.lo, b.ul, b.last
    6274:	17ffff5d 	b	5fe8 <term_drop+0x54>
    6278:	2a0d03e2 	mov	w2, w13
    627c:	2a0903ec 	mov	w12, w9
    6280:	6b0b019f 	cmp	w12, w11
    6284:	54fffd43 	b.cc	622c <term_drop+0x298>  // b.lo, b.ul, b.last
    6288:	f8625a68 	ldr	x8, [x19, w2, uxtw #3]
    628c:	f86a7a98 	ldr	x24, [x20, x10, lsl #3]
    6290:	f82a7a88 	str	x8, [x20, x10, lsl #3]
    6294:	9ac22368 	lsl	x8, x27, x2
    6298:	f8225a6a 	str	x10, [x19, w2, uxtw #3]
    629c:	f8625b29 	ldr	x9, [x25, w2, uxtw #3]
    62a0:	8b080128 	add	x8, x9, x8
    62a4:	f8225b28 	str	x8, [x25, w2, uxtw #3]
    62a8:	395402c9 	ldrb	w9, [x22, #1280]
    62ac:	7100053f 	cmp	w9, #0x1
    62b0:	54fff921 	b.ne	61d4 <term_drop+0x240>  // b.any
    62b4:	f140211f 	cmp	x8, #0x8, lsl #12
    62b8:	54fff943 	b.cc	61e0 <term_drop+0x24c>  // b.lo, b.ul, b.last
    62bc:	17ffffc6 	b	61d4 <term_drop+0x240>
    62c0:	aa1403e0 	mov	x0, x20
    62c4:	aa1303e1 	mov	x1, x19
    62c8:	2a1f03e2 	mov	w2, wzr
    62cc:	97fff8bd 	bl	45c0 <heap_hand>
    62d0:	17ffff67 	b	606c <term_drop+0xd8>
    62d4:	a9464ff4 	ldp	x20, x19, [sp, #96]
    62d8:	a94557f6 	ldp	x22, x21, [sp, #80]
    62dc:	a9445ff8 	ldp	x24, x23, [sp, #64]
    62e0:	a94367fa 	ldp	x26, x25, [sp, #48]
    62e4:	a9426ffc 	ldp	x28, x27, [sp, #32]
    62e8:	a9417bfd 	ldp	x29, x30, [sp, #16]
    62ec:	9101c3ff 	add	sp, sp, #0x70
    62f0:	d65f03c0 	ret

