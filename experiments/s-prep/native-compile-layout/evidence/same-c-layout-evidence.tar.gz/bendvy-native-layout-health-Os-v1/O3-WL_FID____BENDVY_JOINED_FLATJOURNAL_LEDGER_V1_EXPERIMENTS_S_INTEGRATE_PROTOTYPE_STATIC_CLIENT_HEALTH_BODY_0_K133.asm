   17b58:	d10303ff 	sub	sp, sp, #0xc0
   17b5c:	a90b7bfd 	stp	x29, x30, [sp, #176]
   17b60:	9102c3fd 	add	x29, sp, #0xb0
   17b64:	a93e3fa9 	stp	x9, x15, [x29, #-32]
   17b68:	a943c7b2 	ldp	x18, x17, [x29, #56]
   17b6c:	f81f03ac 	stur	x12, [x29, #-16]
   17b70:	aa0e03e8 	mov	x8, x14
   17b74:	aa0d03ee 	mov	x14, x13
   17b78:	a944b3b0 	ldp	x16, x12, [x29, #72]
   17b7c:	f9400bb8 	ldr	x24, [x29, #16]
   17b80:	a9428bbe 	ldp	x30, x2, [x29, #40]
   17b84:	f85e02c9 	ldur	x9, [x22, #-32]
   17b88:	3cde82c2 	ldur	q2, [x22, #-24]
   17b8c:	f85f82cd 	ldur	x13, [x22, #-8]
   17b90:	a941bfb3 	ldp	x19, x15, [x29, #24]
   17b94:	340004f7 	cbz	w23, 17c30 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K133+0xd8>
   17b98:	6e024040 	ext	v0.16b, v2.16b, v2.16b, #8
   17b9c:	6f00e5e2 	movi	v2.2d, #0xffffffff
   17ba0:	2a1903f9 	mov	w25, w25
   17ba4:	2a1a03fa 	mov	w26, w26
   17ba8:	2a0503e5 	mov	w5, w5
   17bac:	2a0703e7 	mov	w7, w7
   17bb0:	2a0b03eb 	mov	w11, w11
   17bb4:	4ea01c01 	mov	v1.16b, v0.16b
   17bb8:	4e181da0 	mov	v0.d[1], x13
   17bbc:	2a0e03ed 	mov	w13, w14
   17bc0:	4e081d21 	mov	v1.d[0], x9
   17bc4:	aa0803e9 	mov	x9, x8
   17bc8:	52800568 	mov	w8, #0x2b                  	// #43
   17bcc:	4e221c00 	and	v0.16b, v0.16b, v2.16b
   17bd0:	f90002c8 	str	x8, [x22]
   17bd4:	2a0203e8 	mov	w8, w2
   17bd8:	2a0903ee 	mov	w14, w9
   17bdc:	4e221c21 	and	v1.16b, v1.16b, v2.16b
   17be0:	ad3f02c1 	stp	q1, q0, [x22, #-32]
   17be4:	910022d6 	add	x22, x22, #0x8
   17be8:	f9001ba8 	str	x8, [x29, #48]
   17bec:	2a1e03e8 	mov	w8, w30
   17bf0:	f90017a8 	str	x8, [x29, #40]
   17bf4:	2a0f03e8 	mov	w8, w15
   17bf8:	f90013a8 	str	x8, [x29, #32]
   17bfc:	2a1303e8 	mov	w8, w19
   17c00:	f9000fa8 	str	x8, [x29, #24]
   17c04:	f85e03a8 	ldur	x8, [x29, #-32]
   17c08:	a904b3b0 	stp	x16, x12, [x29, #72]
   17c0c:	2a0803e9 	mov	w9, w8
   17c10:	a97eb3a8 	ldp	x8, x12, [x29, #-24]
   17c14:	a903c7b2 	stp	x18, x17, [x29, #56]
   17c18:	2a0803ef 	mov	w15, w8
   17c1c:	2a1803e8 	mov	w8, w24
   17c20:	f9000ba8 	str	x8, [x29, #16]
   17c24:	a94b7bfd 	ldp	x29, x30, [sp, #176]
   17c28:	910303ff 	add	sp, sp, #0xc0
   17c2c:	17ffdf35 	b	f900 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_READ_LEDGER>
   17c30:	a93c3fb3 	stp	x19, x15, [x29, #-64]
   17c34:	aa0803f3 	mov	x19, x8
   17c38:	f9401aa8 	ldr	x8, [x21, #48]
   17c3c:	a93d7bb8 	stp	x24, x30, [x29, #-48]
   17c40:	a904cbe2 	stp	x2, x18, [sp, #72]
   17c44:	f9002ff1 	str	x17, [sp, #88]
   17c48:	a93b33b0 	stp	x16, x12, [x29, #-80]
   17c4c:	a97cb2d7 	ldp	x23, x12, [x22, #-56]
   17c50:	b4000aa8 	cbz	x8, 17da4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K133+0x24c>
   17c54:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   17c58:	f9409ab1 	ldr	x17, [x21, #304]
   17c5c:	f9001ab0 	str	x16, [x21, #48]
   17c60:	d1010230 	sub	x16, x17, #0x40
   17c64:	f9009ab0 	str	x16, [x21, #304]
   17c68:	6f07e7e0 	movi	v0.2d, #0xffffffffffffffff
   17c6c:	6f00e5e1 	movi	v1.2d, #0xffffffff
   17c70:	52800032 	mov	w18, #0x1                   	// #1
   17c74:	8b080e90 	add	x16, x20, x8, lsl #3
   17c78:	aa0c824c 	orr	x12, x18, x12, lsl #32
   17c7c:	92800011 	mov	x17, #0xffffffffffffffff    	// #-1
   17c80:	2a0903e9 	mov	w9, w9
   17c84:	a97d4bb8 	ldp	x24, x18, [x29, #-48]
   17c88:	f9009a0c 	str	x12, [x16, #304]
   17c8c:	d2c5600c 	mov	x12, #0x2b0000000000        	// #47278999994368
   17c90:	ad010200 	stp	q0, q0, [x16, #32]
   17c94:	f2e0a00c 	movk	x12, #0x500, lsl #48
   17c98:	ad020200 	stp	q0, q0, [x16, #64]
   17c9c:	a97c3fa2 	ldp	x2, x15, [x29, #-64]
   17ca0:	ad030200 	stp	q0, q0, [x16, #96]
   17ca4:	ad040200 	stp	q0, q0, [x16, #128]
   17ca8:	ad050200 	stp	q0, q0, [x16, #160]
   17cac:	ad060200 	stp	q0, q0, [x16, #192]
   17cb0:	ad070200 	stp	q0, q0, [x16, #224]
   17cb4:	ad080200 	stp	q0, q0, [x16, #256]
   17cb8:	4e211c40 	and	v0.16b, v2.16b, v1.16b
   17cbc:	a9125e11 	stp	x17, x23, [x16, #288]
   17cc0:	aa0c0117 	orr	x23, x8, x12
   17cc4:	52800088 	mov	w8, #0x4                   	// #4
   17cc8:	f9000209 	str	x9, [x16]
   17ccc:	2a0d03e9 	mov	w9, w13
   17cd0:	3c808200 	stur	q0, [x16, #8]
   17cd4:	f9000e09 	str	x9, [x16, #24]
   17cd8:	a93ca2d7 	stp	x23, x8, [x22, #-56]
   17cdc:	f94016a8 	ldr	x8, [x21, #40]
   17ce0:	b4000848 	cbz	x8, 17de8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K133+0x290>
   17ce4:	f8687a89 	ldr	x9, [x20, x8, lsl #3]
   17ce8:	f94096ac 	ldr	x12, [x21, #296]
   17cec:	f90016a9 	str	x9, [x21, #40]
   17cf0:	d1008189 	sub	x9, x12, #0x20
   17cf4:	f90096a9 	str	x9, [x21, #296]
   17cf8:	8b080e91 	add	x17, x20, x8, lsl #3
   17cfc:	d2c00089 	mov	x9, #0x400000000           	// #17179869184
   17d00:	2a1a03f0 	mov	w16, w26
   17d04:	2a0b03eb 	mov	w11, w11
   17d08:	2a1303ed 	mov	w13, w19
   17d0c:	f9007229 	str	x9, [x17, #224]
   17d10:	2a1903e9 	mov	w9, w25
   17d14:	a9004229 	stp	x9, x16, [x17]
   17d18:	2a0503e9 	mov	w9, w5
   17d1c:	a9041a29 	stp	x9, x6, [x17, #64]
   17d20:	2a0703e9 	mov	w9, w7
   17d24:	a9052a29 	stp	x9, x10, [x17, #80]
   17d28:	f85f03a9 	ldur	x9, [x29, #-16]
   17d2c:	a9020620 	stp	x0, x1, [x17, #32]
   17d30:	a906262b 	stp	x11, x9, [x17, #96]
   17d34:	a97e27aa 	ldp	x10, x9, [x29, #-32]
   17d38:	2a0e03eb 	mov	w11, w14
   17d3c:	a901723b 	stp	x27, x28, [x17, #16]
   17d40:	a907362b 	stp	x11, x13, [x17, #112]
   17d44:	2a0a03eb 	mov	w11, w10
   17d48:	2a0903ed 	mov	w13, w9
   17d4c:	2a1803ea 	mov	w10, w24
   17d50:	a908362b 	stp	x11, x13, [x17, #128]
   17d54:	2a0203eb 	mov	w11, w2
   17d58:	2a1203e9 	mov	w9, w18
   17d5c:	a9092e2a 	stp	x10, x11, [x17, #144]
   17d60:	2a0f03ea 	mov	w10, w15
   17d64:	a90a262a 	stp	x10, x9, [x17, #160]
   17d68:	f94027e9 	ldr	x9, [sp, #72]
   17d6c:	a9031223 	stp	x3, x4, [x17, #48]
   17d70:	2a0903e9 	mov	w9, w9
   17d74:	f9006e37 	str	x23, [x17, #216]
   17d78:	f9005a29 	str	x9, [x17, #176]
   17d7c:	a94527ea 	ldp	x10, x9, [sp, #80]
   17d80:	a90ba62a 	stp	x10, x9, [x17, #184]
   17d84:	d2c28009 	mov	x9, #0x140000000000        	// #21990232555520
   17d88:	f2e0a009 	movk	x9, #0x500, lsl #48
   17d8c:	aa090100 	orr	x0, x8, x9
   17d90:	a97b23aa 	ldp	x10, x8, [x29, #-80]
   17d94:	a90ca22a 	stp	x10, x8, [x17, #200]
   17d98:	a94b7bfd 	ldp	x29, x30, [sp, #176]
   17d9c:	910303ff 	add	sp, sp, #0xc0
   17da0:	d65f03c0 	ret
   17da4:	a90383e1 	stp	x1, x0, [sp, #56]
   17da8:	aa1403e0 	mov	x0, x20
   17dac:	aa1503e1 	mov	x1, x21
   17db0:	528000c2 	mov	w2, #0x6                   	// #6
   17db4:	a9029be3 	stp	x3, x6, [sp, #40]
   17db8:	a9011fe4 	stp	x4, x7, [sp, #16]
   17dbc:	f90013e5 	str	x5, [sp, #32]
   17dc0:	3d8003e2 	str	q2, [sp]
   17dc4:	97ffb413 	bl	4e10 <heap_alloc_miss>
   17dc8:	a94197e7 	ldp	x7, x5, [sp, #24]
   17dcc:	aa0003e8 	mov	x8, x0
   17dd0:	a94307e6 	ldp	x6, x1, [sp, #48]
   17dd4:	3dc003e2 	ldr	q2, [sp]
   17dd8:	f94017e3 	ldr	x3, [sp, #40]
   17ddc:	f9400be4 	ldr	x4, [sp, #16]
   17de0:	f94023e0 	ldr	x0, [sp, #64]
   17de4:	17ffffa1 	b	17c68 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K133+0x110>
   17de8:	a90383e1 	stp	x1, x0, [sp, #56]
   17dec:	aa1403e0 	mov	x0, x20
   17df0:	aa1503e1 	mov	x1, x21
   17df4:	528000a2 	mov	w2, #0x5                   	// #5
   17df8:	f9001be6 	str	x6, [sp, #48]
   17dfc:	aa0403e9 	mov	x9, x4
   17e00:	aa0303f5 	mov	x21, x3
   17e04:	aa0703ec 	mov	x12, x7
   17e08:	aa0503f6 	mov	x22, x5
   17e0c:	97ffb401 	bl	4e10 <heap_alloc_miss>
   17e10:	a97c3fa2 	ldp	x2, x15, [x29, #-64]
   17e14:	aa0003e8 	mov	x8, x0
   17e18:	a97d4bb8 	ldp	x24, x18, [x29, #-48]
   17e1c:	aa1603e5 	mov	x5, x22
   17e20:	a94307e6 	ldp	x6, x1, [sp, #48]
   17e24:	aa0c03e7 	mov	x7, x12
   17e28:	f94023e0 	ldr	x0, [sp, #64]
   17e2c:	aa1503e3 	mov	x3, x21
   17e30:	aa0903e4 	mov	x4, x9
   17e34:	17ffffb1 	b	17cf8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K133+0x1a0>

