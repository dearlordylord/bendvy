   18b60:	d10303ff 	sub	sp, sp, #0xc0
   18b64:	a90b7bfd 	stp	x29, x30, [sp, #176]
   18b68:	9102c3fd 	add	x29, sp, #0xb0
   18b6c:	a94523b0 	ldp	x16, x8, [x29, #80]
   18b70:	a93da7ac 	stp	x12, x9, [x29, #-40]
   18b74:	a94447b2 	ldp	x18, x17, [x29, #64]
   18b78:	b85f82c9 	ldur	w9, [x22, #-8]
   18b7c:	a94363be 	ldp	x30, x24, [x29, #48]
   18b80:	a93ebfa8 	stp	x8, x15, [x29, #-24]
   18b84:	a9420baf 	ldp	x15, x2, [x29, #32]
   18b88:	a9414fac 	ldp	x12, x19, [x29, #16]
   18b8c:	34000457 	cbz	w23, 18c14 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0_K159+0xb4>
   18b90:	52800648 	mov	w8, #0x32                  	// #50
   18b94:	2a1903f9 	mov	w25, w25
   18b98:	2a1a03fa 	mov	w26, w26
   18b9c:	a93fa2c9 	stp	x9, x8, [x22, #-8]
   18ba0:	f85e83a8 	ldur	x8, [x29, #-24]
   18ba4:	2a0503e5 	mov	w5, w5
   18ba8:	a904c3b1 	stp	x17, x16, [x29, #72]
   18bac:	2a0703e7 	mov	w7, w7
   18bb0:	2a0b03eb 	mov	w11, w11
   18bb4:	2a0803e8 	mov	w8, w8
   18bb8:	a903cbb8 	stp	x24, x18, [x29, #56]
   18bbc:	2a0d03ed 	mov	w13, w13
   18bc0:	f9002fa8 	str	x8, [x29, #88]
   18bc4:	2a1e03e8 	mov	w8, w30
   18bc8:	2a0e03ee 	mov	w14, w14
   18bcc:	f9001ba8 	str	x8, [x29, #48]
   18bd0:	2a0203e8 	mov	w8, w2
   18bd4:	910022d6 	add	x22, x22, #0x8
   18bd8:	f90017a8 	str	x8, [x29, #40]
   18bdc:	2a0f03e8 	mov	w8, w15
   18be0:	f90013a8 	str	x8, [x29, #32]
   18be4:	2a1303e8 	mov	w8, w19
   18be8:	f9000fa8 	str	x8, [x29, #24]
   18bec:	f85e03a8 	ldur	x8, [x29, #-32]
   18bf0:	2a0803e9 	mov	w9, w8
   18bf4:	f85f03a8 	ldur	x8, [x29, #-16]
   18bf8:	2a0803ef 	mov	w15, w8
   18bfc:	2a0c03e8 	mov	w8, w12
   18c00:	f85d83ac 	ldur	x12, [x29, #-40]
   18c04:	f9000ba8 	str	x8, [x29, #16]
   18c08:	a94b7bfd 	ldp	x29, x30, [sp, #176]
   18c0c:	910303ff 	add	sp, sp, #0xc0
   18c10:	17fffd91 	b	18254 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_HEALTH_CONVERTED>
   18c14:	a93bbfb3 	stp	x19, x15, [x29, #-72]
   18c18:	f94016a8 	ldr	x8, [x21, #40]
   18c1c:	a93c8bac 	stp	x12, x2, [x29, #-56]
   18c20:	a903e3fe 	stp	x30, x24, [sp, #56]
   18c24:	a97e62d7 	ldp	x23, x24, [x22, #-32]
   18c28:	a904c7f2 	stp	x18, x17, [sp, #72]
   18c2c:	f9002fed 	str	x13, [sp, #88]
   18c30:	f81b03b0 	stur	x16, [x29, #-80]
   18c34:	b4000ae8 	cbz	x8, 18d90 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0_K159+0x230>
   18c38:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   18c3c:	f94096b1 	ldr	x17, [x21, #296]
   18c40:	f90016b0 	str	x16, [x21, #40]
   18c44:	d1008230 	sub	x16, x17, #0x20
   18c48:	f90096b0 	str	x16, [x21, #296]
   18c4c:	52800031 	mov	w17, #0x1                   	// #1
   18c50:	8b080e90 	add	x16, x20, x8, lsl #3
   18c54:	6f07e7e0 	movi	v0.2d, #0xffffffffffffffff
   18c58:	aa188232 	orr	x18, x17, x24, lsl #32
   18c5c:	f9000209 	str	x9, [x16]
   18c60:	a90eca17 	stp	x23, x18, [x16, #232]
   18c64:	d2c64012 	mov	x18, #0x320000000000        	// #54975581388800
   18c68:	f2e0a012 	movk	x18, #0x500, lsl #48
   18c6c:	3c8d8200 	stur	q0, [x16, #216]
   18c70:	aa12010d 	orr	x13, x8, x18
   18c74:	3c8c8200 	stur	q0, [x16, #200]
   18c78:	3c8b8200 	stur	q0, [x16, #184]
   18c7c:	3c8a8200 	stur	q0, [x16, #168]
   18c80:	3c898200 	stur	q0, [x16, #152]
   18c84:	3c888200 	stur	q0, [x16, #136]
   18c88:	3c878200 	stur	q0, [x16, #120]
   18c8c:	3c868200 	stur	q0, [x16, #104]
   18c90:	3c858200 	stur	q0, [x16, #88]
   18c94:	3c848200 	stur	q0, [x16, #72]
   18c98:	3c838200 	stur	q0, [x16, #56]
   18c9c:	3c828200 	stur	q0, [x16, #40]
   18ca0:	3c818200 	stur	q0, [x16, #24]
   18ca4:	3c808200 	stur	q0, [x16, #8]
   18ca8:	a93e46cd 	stp	x13, x17, [x22, #-32]
   18cac:	f94016a8 	ldr	x8, [x21, #40]
   18cb0:	b40008c8 	cbz	x8, 18dc8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0_K159+0x268>
   18cb4:	f94096b0 	ldr	x16, [x21, #296]
   18cb8:	f8687a91 	ldr	x17, [x20, x8, lsl #3]
   18cbc:	d1008210 	sub	x16, x16, #0x20
   18cc0:	f90016b1 	str	x17, [x21, #40]
   18cc4:	f90096b0 	str	x16, [x21, #296]
   18cc8:	8b080e90 	add	x16, x20, x8, lsl #3
   18ccc:	d2c00031 	mov	x17, #0x100000000           	// #4294967296
   18cd0:	f85d83a9 	ldur	x9, [x29, #-40]
   18cd4:	2a0b03eb 	mov	w11, w11
   18cd8:	a97ccbb3 	ldp	x19, x18, [x29, #-56]
   18cdc:	a90e460d 	stp	x13, x17, [x16, #224]
   18ce0:	2a1903ed 	mov	w13, w25
   18ce4:	2a1a03f1 	mov	w17, w26
   18ce8:	a900460d 	stp	x13, x17, [x16]
   18cec:	2a0503ed 	mov	w13, w5
   18cf0:	2a0e03ec 	mov	w12, w14
   18cf4:	a906260b 	stp	x11, x9, [x16, #96]
   18cf8:	f9402fe9 	ldr	x9, [sp, #88]
   18cfc:	a9041a0d 	stp	x13, x6, [x16, #64]
   18d00:	2a0703ed 	mov	w13, w7
   18d04:	a97bbfb5 	ldp	x21, x15, [x29, #-72]
   18d08:	a9052a0d 	stp	x13, x10, [x16, #80]
   18d0c:	2a0903eb 	mov	w11, w9
   18d10:	f85e03a9 	ldur	x9, [x29, #-32]
   18d14:	f85f03aa 	ldur	x10, [x29, #-16]
   18d18:	a907320b 	stp	x11, x12, [x16, #112]
   18d1c:	2a0903eb 	mov	w11, w9
   18d20:	2a0a03ec 	mov	w12, w10
   18d24:	2a1303ea 	mov	w10, w19
   18d28:	a908320b 	stp	x11, x12, [x16, #128]
   18d2c:	2a1503eb 	mov	w11, w21
   18d30:	2a1203e9 	mov	w9, w18
   18d34:	a9092e0a 	stp	x10, x11, [x16, #144]
   18d38:	2a0f03ea 	mov	w10, w15
   18d3c:	f9402beb 	ldr	x11, [sp, #80]
   18d40:	a90a260a 	stp	x10, x9, [x16, #160]
   18d44:	f9401fe9 	ldr	x9, [sp, #56]
   18d48:	a9020600 	stp	x0, x1, [x16, #32]
   18d4c:	2a0903e9 	mov	w9, w9
   18d50:	a901721b 	stp	x27, x28, [x16, #16]
   18d54:	f9005a09 	str	x9, [x16, #176]
   18d58:	a94427ea 	ldp	x10, x9, [sp, #64]
   18d5c:	a9031203 	stp	x3, x4, [x16, #48]
   18d60:	a90ba60a 	stp	x10, x9, [x16, #184]
   18d64:	d2c5a009 	mov	x9, #0x2d0000000000        	// #49478023249920
   18d68:	f85e83aa 	ldur	x10, [x29, #-24]
   18d6c:	f2e0a009 	movk	x9, #0x500, lsl #48
   18d70:	aa090100 	orr	x0, x8, x9
   18d74:	f85b03a8 	ldur	x8, [x29, #-80]
   18d78:	2a0a03ea 	mov	w10, w10
   18d7c:	a90ca20b 	stp	x11, x8, [x16, #200]
   18d80:	f9006e0a 	str	x10, [x16, #216]
   18d84:	a94b7bfd 	ldp	x29, x30, [sp, #176]
   18d88:	910303ff 	add	sp, sp, #0xc0
   18d8c:	d65f03c0 	ret
   18d90:	a90283e1 	stp	x1, x0, [sp, #40]
   18d94:	aa1403e0 	mov	x0, x20
   18d98:	aa1503e1 	mov	x1, x21
   18d9c:	528000a2 	mov	w2, #0x5                   	// #5
   18da0:	a9019be5 	stp	x5, x6, [sp, #24]
   18da4:	a9001fe4 	stp	x4, x7, [sp]
   18da8:	f9000be3 	str	x3, [sp, #16]
   18dac:	97ffb019 	bl	4e10 <heap_alloc_miss>
   18db0:	a94117e3 	ldp	x3, x5, [sp, #16]
   18db4:	aa0003e8 	mov	x8, x0
   18db8:	a9401fe4 	ldp	x4, x7, [sp]
   18dbc:	f9401be0 	ldr	x0, [sp, #48]
   18dc0:	a94207e6 	ldp	x6, x1, [sp, #32]
   18dc4:	17ffffa2 	b	18c4c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0_K159+0xec>
   18dc8:	a90283e1 	stp	x1, x0, [sp, #40]
   18dcc:	aa1403e0 	mov	x0, x20
   18dd0:	aa1503e1 	mov	x1, x21
   18dd4:	528000a2 	mov	w2, #0x5                   	// #5
   18dd8:	a9019be5 	stp	x5, x6, [sp, #24]
   18ddc:	aa0403f5 	mov	x21, x4
   18de0:	aa0303f7 	mov	x23, x3
   18de4:	aa0703f6 	mov	x22, x7
   18de8:	97ffb00a 	bl	4e10 <heap_alloc_miss>
   18dec:	a9419be5 	ldp	x5, x6, [sp, #24]
   18df0:	aa0003e8 	mov	x8, x0
   18df4:	a94283e1 	ldp	x1, x0, [sp, #40]
   18df8:	aa1603e7 	mov	x7, x22
   18dfc:	aa1703e3 	mov	x3, x23
   18e00:	aa1503e4 	mov	x4, x21
   18e04:	17ffffb1 	b	18cc8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0_K159+0x168>

