   809a0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
   809a4:	a9016ffc 	stp	x28, x27, [sp, #16]
   809a8:	a90267fa 	stp	x26, x25, [sp, #32]
   809ac:	a9035ff8 	stp	x24, x23, [sp, #48]
   809b0:	a90457f6 	stp	x22, x21, [sp, #64]
   809b4:	a9054ff4 	stp	x20, x19, [sp, #80]
   809b8:	910003fd 	mov	x29, sp
   809bc:	d106c3ff 	sub	sp, sp, #0x1b0
   809c0:	f9404ba9 	ldr	x9, [x29, #144]
   809c4:	a949aba8 	ldp	x8, x10, [x29, #152]
   809c8:	d2c1c017 	mov	x23, #0xe0000000000         	// #15393162788864
   809cc:	b940bbb6 	ldr	w22, [x29, #184]
   809d0:	aa0203f5 	mov	x21, x2
   809d4:	f9001be9 	str	x9, [sp, #48]
   809d8:	a94827ab 	ldp	x11, x9, [x29, #128]
   809dc:	f2e02017 	movk	x23, #0x100, lsl #48
   809e0:	aa0103f9 	mov	x25, x1
   809e4:	aa0003fa 	mov	x26, x0
   809e8:	eb17011f 	cmp	x8, x23
   809ec:	aa0a03f3 	mov	x19, x10
   809f0:	f81b83a7 	stur	x7, [x29, #-72]
   809f4:	a93e23a9 	stp	x9, x8, [x29, #-32]
   809f8:	a94727ad 	ldp	x13, x9, [x29, #112]
   809fc:	f9001fe6 	str	x6, [sp, #56]
   80a00:	f81f03a5 	stur	x5, [x29, #-16]
   80a04:	f81c83a9 	stur	x9, [x29, #-56]
   80a08:	f94037a9 	ldr	x9, [x29, #104]
   80a0c:	b9002fe4 	str	w4, [sp, #44]
   80a10:	f81c03a9 	stur	x9, [x29, #-64]
   80a14:	f94033a9 	ldr	x9, [x29, #96]
   80a18:	f9004fea 	str	x10, [sp, #152]
   80a1c:	540002a0 	b.eq	80a70 <spin_92+0xd0>  // b.none
   80a20:	f85e03a8 	ldur	x8, [x29, #-32]
   80a24:	f9401bf3 	ldr	x19, [sp, #48]
   80a28:	eb17011f 	cmp	x8, x23
   80a2c:	54000220 	b.eq	80a70 <spin_92+0xd0>  // b.none
   80a30:	f85c83a8 	ldur	x8, [x29, #-56]
   80a34:	aa0b03f3 	mov	x19, x11
   80a38:	eb17011f 	cmp	x8, x23
   80a3c:	540001a0 	b.eq	80a70 <spin_92+0xd0>  // b.none
   80a40:	f85c03a8 	ldur	x8, [x29, #-64]
   80a44:	aa0d03f3 	mov	x19, x13
   80a48:	eb17011f 	cmp	x8, x23
   80a4c:	54000120 	b.eq	80a70 <spin_92+0xd0>  // b.none
   80a50:	f85b83a8 	ldur	x8, [x29, #-72]
   80a54:	aa0903f3 	mov	x19, x9
   80a58:	eb17011f 	cmp	x8, x23
   80a5c:	540000a0 	b.eq	80a70 <spin_92+0xd0>  // b.none
   80a60:	f85f03a8 	ldur	x8, [x29, #-16]
   80a64:	eb17011f 	cmp	x8, x23
   80a68:	f9401fe8 	ldr	x8, [sp, #56]
   80a6c:	9a9f0113 	csel	x19, x8, xzr, eq	// eq = none
   80a70:	b940abb8 	ldr	w24, [x29, #168]
   80a74:	52909fe1 	mov	w1, #0x84ff                	// #34047
   80a78:	b9002be3 	str	w3, [sp, #40]
   80a7c:	72a06201 	movk	w1, #0x310, lsl #16
   80a80:	340136b6 	cbz	w22, 83154 <spin_92+0x27b4>
   80a84:	8b0b0f48 	add	x8, x26, x11, lsl #3
   80a88:	f90007e9 	str	x9, [sp, #8]
   80a8c:	9280000a 	mov	x10, #0xffffffffffffffff    	// #-1
   80a90:	a901aff5 	stp	x21, x11, [sp, #24]
   80a94:	f85f03ab 	ldur	x11, [x29, #-16]
   80a98:	f85b83ac 	ldur	x12, [x29, #-72]
   80a9c:	f81383a8 	stur	x8, [x29, #-200]
   80aa0:	f9401fe8 	ldr	x8, [sp, #56]
   80aa4:	d2c1c01b 	mov	x27, #0xe0000000000         	// #15393162788864
   80aa8:	d368b16b 	ubfx	x11, x11, #40, #5
   80aac:	d368b18c 	ubfx	x12, x12, #40, #5
   80ab0:	aa1f03f5 	mov	x21, xzr
   80ab4:	8b080f48 	add	x8, x26, x8, lsl #3
   80ab8:	f2e0201b 	movk	x27, #0x100, lsl #48
   80abc:	f9000bed 	str	x13, [sp, #16]
   80ac0:	5100056b 	sub	w11, w11, #0x1
   80ac4:	5100058c 	sub	w12, w12, #0x1
   80ac8:	a90d63f3 	stp	x19, x24, [sp, #208]
   80acc:	f81a03a8 	stur	x8, [x29, #-96]
   80ad0:	8b090f48 	add	x8, x26, x9, lsl #3
   80ad4:	9acb214b 	lsl	x11, x10, x11
   80ad8:	f9003ff6 	str	x22, [sp, #120]
   80adc:	f81703a8 	stur	x8, [x29, #-144]
   80ae0:	a97c27a8 	ldp	x8, x9, [x29, #-64]
   80ae4:	d368b108 	ubfx	x8, x8, #40, #5
   80ae8:	d368b129 	ubfx	x9, x9, #40, #5
   80aec:	9ac82148 	lsl	x8, x10, x8
   80af0:	51000529 	sub	w9, w9, #0x1
   80af4:	9ac92149 	lsl	x9, x10, x9
   80af8:	9acc214a 	lsl	x10, x10, x12
   80afc:	aa2803e8 	mvn	x8, x8
   80b00:	f81983a8 	stur	x8, [x29, #-104]
   80b04:	8b0d0f48 	add	x8, x26, x13, lsl #3
   80b08:	f81903a8 	stur	x8, [x29, #-112]
   80b0c:	aa2903e8 	mvn	x8, x9
   80b10:	f81303a8 	stur	x8, [x29, #-208]
   80b14:	2a2b03e8 	mvn	w8, w11
   80b18:	b900cfe8 	str	w8, [sp, #204]
   80b1c:	2a2a03e8 	mvn	w8, w10
   80b20:	b90077e8 	str	w8, [sp, #116]
   80b24:	2a0303e8 	mov	w8, w3
   80b28:	90000a43 	adrp	x3, 1c8000 <ALC+0x17e00>
   80b2c:	f90037e8 	str	x8, [sp, #104]
   80b30:	14000005 	b	80b44 <spin_92+0x1a4>
   80b34:	a94d63f3 	ldp	x19, x24, [sp, #208]
   80b38:	910006b5 	add	x21, x21, #0x1
   80b3c:	eb1502df 	cmp	x22, x21
   80b40:	54012f20 	b.eq	83124 <spin_92+0x2784>  // b.none
   80b44:	eb17037f 	cmp	x27, x23
   80b48:	aa1303fc 	mov	x28, x19
   80b4c:	54000060 	b.eq	80b58 <spin_92+0x1b8>  // b.none
   80b50:	92409f7c 	and	x28, x27, #0xffffffffff
   80b54:	b7f8043b 	tbnz	x27, #63, 80bd8 <spin_92+0x238>
   80b58:	eb1802bf 	cmp	x21, x24
   80b5c:	54fffee2 	b.cs	80b38 <spin_92+0x198>  // b.hs, b.nlast
   80b60:	a97923a9 	ldp	x9, x8, [x29, #-112]
   80b64:	8a0802a8 	and	x8, x21, x8
   80b68:	b8687928 	ldr	w8, [x9, x8, lsl #2]
   80b6c:	34fffe68 	cbz	w8, 80b38 <spin_92+0x198>
   80b70:	a97327a8 	ldp	x8, x9, [x29, #-208]
   80b74:	0a0802a8 	and	w8, w21, w8
   80b78:	531f7908 	lsl	w8, w8, #1
   80b7c:	8b284d29 	add	x9, x9, w8, uxtw #3
   80b80:	f9400533 	ldr	x19, [x9, #8]
   80b84:	b9400134 	ldr	w20, [x9]
   80b88:	b7f80333 	tbnz	x19, #63, 80bec <spin_92+0x24c>
   80b8c:	d379fe68 	lsr	x8, x19, #57
   80b90:	b4000428 	cbz	x8, 80c14 <spin_92+0x274>
   80b94:	92787e68 	and	x8, x19, #0xffffffff00
   80b98:	9100042a 	add	x10, x1, #0x1
   80b9c:	eb0a011f 	cmp	x8, x10
   80ba0:	540003a3 	b.cc	80c14 <spin_92+0x274>  // b.lo, b.ul, b.last
   80ba4:	aa1a03e0 	mov	x0, x26
   80ba8:	aa1903e1 	mov	x1, x25
   80bac:	aa1303e2 	mov	x2, x19
   80bb0:	52800043 	mov	w3, #0x2                   	// #2
   80bb4:	97fe118a 	bl	51dc <rfc_wrap>
   80bb8:	52909fe1 	mov	w1, #0x84ff                	// #34047
   80bbc:	90000a43 	adrp	x3, 1c8000 <ALC+0x17e00>
   80bc0:	eb13001f 	cmp	x0, x19
   80bc4:	72a06201 	movk	w1, #0x310, lsl #16
   80bc8:	54000260 	b.eq	80c14 <spin_92+0x274>  // b.none
   80bcc:	aa0003f3 	mov	x19, x0
   80bd0:	f9000520 	str	x0, [x9, #8]
   80bd4:	14000010 	b	80c14 <spin_92+0x274>
   80bd8:	f87c7b48 	ldr	x8, [x26, x28, lsl #3]
   80bdc:	d358fd1c 	lsr	x28, x8, #24
   80be0:	eb1802bf 	cmp	x21, x24
   80be4:	54fffaa2 	b.cs	80b38 <spin_92+0x198>  // b.hs, b.nlast
   80be8:	17ffffde 	b	80b60 <spin_92+0x1c0>
   80bec:	92409e68 	and	x8, x19, #0xffffffffff
   80bf0:	52800020 	mov	w0, #0x1                   	// #1
   80bf4:	8b080f41 	add	x1, x26, x8, lsl #3
   80bf8:	94003fe6 	bl	90b90 <__aarch64_ldadd4_relax>
   80bfc:	52909fe1 	mov	w1, #0x84ff                	// #34047
   80c00:	321f5be8 	mov	w8, #0xfffffe              	// #16777214
   80c04:	90000a43 	adrp	x3, 1c8000 <ALC+0x17e00>
   80c08:	72a06201 	movk	w1, #0x310, lsl #16
   80c0c:	6a20011f 	bics	wzr, w8, w0
   80c10:	54016fe0 	b.eq	83a0c <spin_92+0x306c>  // b.none
   80c14:	b940cfe8 	ldr	w8, [sp, #204]
   80c18:	f85a03aa 	ldur	x10, [x29, #-96]
   80c1c:	6f00e401 	movi	v1.2d, #0x0
   80c20:	a937d3b3 	stp	x19, x20, [x29, #-136]
   80c24:	0a0802a8 	and	w8, w21, w8
   80c28:	531f7909 	lsl	w9, w8, #1
   80c2c:	8b294d53 	add	x19, x10, w9, uxtw #3
   80c30:	52800029 	mov	w9, #0x1                   	// #1
   80c34:	331f7909 	bfi	w9, w8, #1, #31
   80c38:	b940026c 	ldr	w12, [x19]
   80c3c:	f9400662 	ldr	x2, [x19, #8]
   80c40:	3d800261 	str	q1, [x19]
   80c44:	b818c3a9 	stur	w9, [x29, #-116]
   80c48:	b400012c 	cbz	x12, 80c6c <spin_92+0x2cc>
   80c4c:	92409c48 	and	x8, x2, #0xffffffffff
   80c50:	8b080f4a 	add	x10, x26, x8, lsl #3
   80c54:	b7f801a2 	tbnz	x2, #63, 80c88 <spin_92+0x2e8>
   80c58:	a940294b 	ldp	x11, x10, [x10]
   80c5c:	aa0803e9 	mov	x9, x8
   80c60:	eb01011f 	cmp	x8, x1
   80c64:	54000408 	b.hi	80ce4 <spin_92+0x344>  // b.pmore
   80c68:	1400002a 	b	80d10 <spin_92+0x370>
   80c6c:	aa1f03f2 	mov	x18, xzr
   80c70:	aa1f03ef 	mov	x15, xzr
   80c74:	aa1f03f8 	mov	x24, xzr
   80c78:	aa1f03f1 	mov	x17, xzr
   80c7c:	6f00e402 	movi	v2.2d, #0x0
   80c80:	aa1f03e9 	mov	x9, xzr
   80c84:	1400008b 	b	80eb0 <spin_92+0x510>
   80c88:	b9400549 	ldr	w9, [x10, #4]
   80c8c:	b940014b 	ldr	w11, [x10]
   80c90:	92405d6d 	and	x13, x11, #0xffffff
   80c94:	f10005bf 	cmp	x13, #0x1
   80c98:	5400e121 	b.ne	828bc <spin_92+0x1f1c>  // b.any
   80c9c:	aa098169 	orr	x9, x11, x9, lsl #32
   80ca0:	88dffd5f 	ldar	wzr, [x10]
   80ca4:	f940032e 	ldr	x14, [x25]
   80ca8:	d358fd29 	lsr	x9, x9, #24
   80cac:	8b090f4d 	add	x13, x26, x9, lsl #3
   80cb0:	a94029ab 	ldp	x11, x10, [x13]
   80cb4:	f8287b4e 	str	x14, [x26, x8, lsl #3]
   80cb8:	f940832d 	ldr	x13, [x25, #256]
   80cbc:	f9000328 	str	x8, [x25]
   80cc0:	910005a8 	add	x8, x13, #0x1
   80cc4:	f9008328 	str	x8, [x25, #256]
   80cc8:	3954006d 	ldrb	w13, [x3, #1280]
   80ccc:	710005bf 	cmp	w13, #0x1
   80cd0:	5400eee1 	b.ne	82aac <spin_92+0x210c>  // b.any
   80cd4:	f140211f 	cmp	x8, #0x8, lsl #12
   80cd8:	5400eea2 	b.cs	82aac <spin_92+0x210c>  // b.hs, b.nlast
   80cdc:	eb01013f 	cmp	x9, x1
   80ce0:	54000189 	b.ls	80d10 <spin_92+0x370>  // b.plast
   80ce4:	f9400728 	ldr	x8, [x25, #8]
   80ce8:	f8297b48 	str	x8, [x26, x9, lsl #3]
   80cec:	f9408728 	ldr	x8, [x25, #264]
   80cf0:	f9000729 	str	x9, [x25, #8]
   80cf4:	91000908 	add	x8, x8, #0x2
   80cf8:	f9008728 	str	x8, [x25, #264]
   80cfc:	3954006d 	ldrb	w13, [x3, #1280]
   80d00:	710005bf 	cmp	w13, #0x1
   80d04:	54007041 	b.ne	81b0c <spin_92+0x116c>  // b.any
   80d08:	f140211f 	cmp	x8, #0x8, lsl #12
   80d0c:	54007002 	b.cs	81b0c <spin_92+0x116c>  // b.hs, b.nlast
   80d10:	92409d68 	and	x8, x11, #0xffffffffff
   80d14:	8b080f4d 	add	x13, x26, x8, lsl #3
   80d18:	b7f8010b 	tbnz	x11, #63, 80d38 <spin_92+0x398>
   80d1c:	f94001a9 	ldr	x9, [x13]
   80d20:	b94009b1 	ldr	w17, [x13, #8]
   80d24:	aa0803eb 	mov	x11, x8
   80d28:	b94011b2 	ldr	w18, [x13, #16]
   80d2c:	eb01011f 	cmp	x8, x1
   80d30:	54000368 	b.hi	80d9c <spin_92+0x3fc>  // b.pmore
   80d34:	14000025 	b	80dc8 <spin_92+0x428>
   80d38:	b94005a9 	ldr	w9, [x13, #4]
   80d3c:	b94001ae 	ldr	w14, [x13]
   80d40:	92405dcf 	and	x15, x14, #0xffffff
   80d44:	f10005ff 	cmp	x15, #0x1
   80d48:	5400dd21 	b.ne	828ec <spin_92+0x1f4c>  // b.any
   80d4c:	aa0981c9 	orr	x9, x14, x9, lsl #32
   80d50:	88dffdbf 	ldar	wzr, [x13]
   80d54:	f940032d 	ldr	x13, [x25]
   80d58:	d358fd2b 	lsr	x11, x9, #24
   80d5c:	8b0b0f4e 	add	x14, x26, x11, lsl #3
   80d60:	f94001c9 	ldr	x9, [x14]
   80d64:	b94009d1 	ldr	w17, [x14, #8]
   80d68:	b94011d2 	ldr	w18, [x14, #16]
   80d6c:	f8287b4d 	str	x13, [x26, x8, lsl #3]
   80d70:	f940832d 	ldr	x13, [x25, #256]
   80d74:	f9000328 	str	x8, [x25]
   80d78:	910005a8 	add	x8, x13, #0x1
   80d7c:	f9008328 	str	x8, [x25, #256]
   80d80:	3954006d 	ldrb	w13, [x3, #1280]
   80d84:	710005bf 	cmp	w13, #0x1
   80d88:	5400ea61 	b.ne	82ad4 <spin_92+0x2134>  // b.any
   80d8c:	f140211f 	cmp	x8, #0x8, lsl #12
   80d90:	5400ea22 	b.cs	82ad4 <spin_92+0x2134>  // b.hs, b.nlast
   80d94:	eb01017f 	cmp	x11, x1
   80d98:	54000189 	b.ls	80dc8 <spin_92+0x428>  // b.plast
   80d9c:	f9400b28 	ldr	x8, [x25, #16]
   80da0:	f82b7b48 	str	x8, [x26, x11, lsl #3]
   80da4:	f9408b28 	ldr	x8, [x25, #272]
   80da8:	f9000b2b 	str	x11, [x25, #16]
   80dac:	91001108 	add	x8, x8, #0x4
   80db0:	f9008b28 	str	x8, [x25, #272]
   80db4:	3954006d 	ldrb	w13, [x3, #1280]
   80db8:	710005bf 	cmp	w13, #0x1
   80dbc:	54006b21 	b.ne	81b20 <spin_92+0x1180>  // b.any
   80dc0:	f140211f 	cmp	x8, #0x8, lsl #12
   80dc4:	54006ae2 	b.cs	81b20 <spin_92+0x1180>  // b.hs, b.nlast
   80dc8:	92409d48 	and	x8, x10, #0xffffffffff
   80dcc:	8b080f4d 	add	x13, x26, x8, lsl #3
   80dd0:	b7f8012a 	tbnz	x10, #63, 80df4 <spin_92+0x454>
   80dd4:	b94001af 	ldr	w15, [x13]
   80dd8:	3cc081a1 	ldur	q1, [x13, #8]
   80ddc:	aa0803eb 	mov	x11, x8
   80de0:	3cc181a2 	ldur	q2, [x13, #24]
   80de4:	b94029b8 	ldr	w24, [x13, #40]
   80de8:	eb01011f 	cmp	x8, x1
   80dec:	540004c8 	b.hi	80e84 <spin_92+0x4e4>  // b.pmore
   80df0:	14000030 	b	80eb0 <spin_92+0x510>
   80df4:	b94005ab 	ldr	w11, [x13, #4]
   80df8:	b94001af 	ldr	w15, [x13]
   80dfc:	aa1303f7 	mov	x23, x19
   80e00:	92405dee 	and	x14, x15, #0xffffff
   80e04:	f10005df 	cmp	x14, #0x1
   80e08:	54000041 	b.ne	80e10 <spin_92+0x470>  // b.any
   80e0c:	88dffdbf 	ldar	wzr, [x13]
   80e10:	aa0b81eb 	orr	x11, x15, x11, lsl #32
   80e14:	aa1203f4 	mov	x20, x18
   80e18:	aa1103f3 	mov	x19, x17
   80e1c:	f10005df 	cmp	x14, #0x1
   80e20:	d358fd6b 	lsr	x11, x11, #24
   80e24:	8b0b0f50 	add	x16, x26, x11, lsl #3
   80e28:	b940020f 	ldr	w15, [x16]
   80e2c:	3cc08201 	ldur	q1, [x16, #8]
   80e30:	3cc18202 	ldur	q2, [x16, #24]
   80e34:	b9402a18 	ldr	w24, [x16, #40]
   80e38:	5400d7c1 	b.ne	82930 <spin_92+0x1f90>  // b.any
   80e3c:	f940032a 	ldr	x10, [x25]
   80e40:	f90001aa 	str	x10, [x13]
   80e44:	f940832a 	ldr	x10, [x25, #256]
   80e48:	f9000328 	str	x8, [x25]
   80e4c:	91000548 	add	x8, x10, #0x1
   80e50:	f9008328 	str	x8, [x25, #256]
   80e54:	3954006a 	ldrb	w10, [x3, #1280]
   80e58:	7100055f 	cmp	w10, #0x1
   80e5c:	5400e581 	b.ne	82b0c <spin_92+0x216c>  // b.any
   80e60:	f140211f 	cmp	x8, #0x8, lsl #12
   80e64:	5400e542 	b.cs	82b0c <spin_92+0x216c>  // b.hs, b.nlast
   80e68:	aa1303f1 	mov	x17, x19
   80e6c:	aa1703f3 	mov	x19, x23
   80e70:	d2c1c017 	mov	x23, #0xe0000000000         	// #15393162788864
   80e74:	f2e02017 	movk	x23, #0x100, lsl #48
   80e78:	aa1403f2 	mov	x18, x20
   80e7c:	eb01017f 	cmp	x11, x1
   80e80:	54000189 	b.ls	80eb0 <spin_92+0x510>  // b.plast
   80e84:	f9400f28 	ldr	x8, [x25, #24]
   80e88:	f82b7b48 	str	x8, [x26, x11, lsl #3]
   80e8c:	f9408f28 	ldr	x8, [x25, #280]
   80e90:	f9000f2b 	str	x11, [x25, #24]
   80e94:	91002108 	add	x8, x8, #0x8
   80e98:	f9008f28 	str	x8, [x25, #280]
   80e9c:	3954006a 	ldrb	w10, [x3, #1280]
   80ea0:	7100055f 	cmp	w10, #0x1
   80ea4:	54006501 	b.ne	81b44 <spin_92+0x11a4>  // b.any
   80ea8:	f140211f 	cmp	x8, #0x8, lsl #12
   80eac:	540064c2 	b.cs	81b44 <spin_92+0x11a4>  // b.hs, b.nlast
   80eb0:	eb1b013f 	cmp	x9, x27
   80eb4:	aa1c03eb 	mov	x11, x28
   80eb8:	540003a0 	b.eq	80f2c <spin_92+0x58c>  // b.none
   80ebc:	f85e83a8 	ldur	x8, [x29, #-24]
   80ec0:	f9404feb 	ldr	x11, [sp, #152]
   80ec4:	eb08013f 	cmp	x9, x8
   80ec8:	54000320 	b.eq	80f2c <spin_92+0x58c>  // b.none
   80ecc:	f85e03a8 	ldur	x8, [x29, #-32]
   80ed0:	f9401beb 	ldr	x11, [sp, #48]
   80ed4:	eb08013f 	cmp	x9, x8
   80ed8:	540002a0 	b.eq	80f2c <spin_92+0x58c>  // b.none
   80edc:	f85c83a8 	ldur	x8, [x29, #-56]
   80ee0:	f94013eb 	ldr	x11, [sp, #32]
   80ee4:	eb08013f 	cmp	x9, x8
   80ee8:	54000220 	b.eq	80f2c <spin_92+0x58c>  // b.none
   80eec:	f85c03a8 	ldur	x8, [x29, #-64]
   80ef0:	f9400beb 	ldr	x11, [sp, #16]
   80ef4:	eb08013f 	cmp	x9, x8
   80ef8:	540001a0 	b.eq	80f2c <spin_92+0x58c>  // b.none
   80efc:	f85b83a8 	ldur	x8, [x29, #-72]
   80f00:	f94007eb 	ldr	x11, [sp, #8]
   80f04:	eb08013f 	cmp	x9, x8
   80f08:	54000120 	b.eq	80f2c <spin_92+0x58c>  // b.none
   80f0c:	f85f03a8 	ldur	x8, [x29, #-16]
   80f10:	f9401feb 	ldr	x11, [sp, #56]
   80f14:	eb08013f 	cmp	x9, x8
   80f18:	540000a0 	b.eq	80f2c <spin_92+0x58c>  // b.none
   80f1c:	92409d2b 	and	x11, x9, #0xffffffffff
   80f20:	b6f80069 	tbz	x9, #63, 80f2c <spin_92+0x58c>
   80f24:	f86b7b48 	ldr	x8, [x26, x11, lsl #3]
   80f28:	d358fd0b 	lsr	x11, x8, #24
   80f2c:	b4ffe04c 	cbz	x12, 80b34 <spin_92+0x194>
   80f30:	b94077e8 	ldr	w8, [sp, #116]
   80f34:	f85703ac 	ldur	x12, [x29, #-144]
   80f38:	0a0802a8 	and	w8, w21, w8
   80f3c:	531f790a 	lsl	w10, w8, #1
   80f40:	8b2a4d8a 	add	x10, x12, w10, uxtw #3
   80f44:	5280002c 	mov	w12, #0x1                   	// #1
   80f48:	331f790c 	bfi	w12, w8, #1, #31
   80f4c:	b9400154 	ldr	w20, [x10]
   80f50:	f9400542 	ldr	x2, [x10, #8]
   80f54:	a9007d5f 	stp	xzr, xzr, [x10]
   80f58:	b81643ac 	stur	w12, [x29, #-156]
   80f5c:	f81683aa 	stur	x10, [x29, #-152]
   80f60:	b4000154 	cbz	x20, 80f88 <spin_92+0x5e8>
   80f64:	92409c48 	and	x8, x2, #0xffffffffff
   80f68:	8b080f4d 	add	x13, x26, x8, lsl #3
   80f6c:	b7f80142 	tbnz	x2, #63, 80f94 <spin_92+0x5f4>
   80f70:	f94001aa 	ldr	x10, [x13]
   80f74:	b94009ad 	ldr	w13, [x13, #8]
   80f78:	aa0803ec 	mov	x12, x8
   80f7c:	eb01011f 	cmp	x8, x1
   80f80:	540003a8 	b.hi	80ff4 <spin_92+0x654>  // b.pmore
   80f84:	14000027 	b	81020 <spin_92+0x680>
   80f88:	aa1f03ea 	mov	x10, xzr
   80f8c:	aa1f03ed 	mov	x13, xzr
   80f90:	14000024 	b	81020 <spin_92+0x680>
   80f94:	b94005aa 	ldr	w10, [x13, #4]
   80f98:	b94001ac 	ldr	w12, [x13]
   80f9c:	92405d8e 	and	x14, x12, #0xffffff
   80fa0:	f10005df 	cmp	x14, #0x1
   80fa4:	5400ef41 	b.ne	82d8c <spin_92+0x23ec>  // b.any
   80fa8:	aa0a818a 	orr	x10, x12, x10, lsl #32
   80fac:	88dffdbf 	ldar	wzr, [x13]
   80fb0:	f9400330 	ldr	x16, [x25]
   80fb4:	d358fd4c 	lsr	x12, x10, #24
   80fb8:	8b0c0f4e 	add	x14, x26, x12, lsl #3
   80fbc:	f94001ca 	ldr	x10, [x14]
   80fc0:	b94009cd 	ldr	w13, [x14, #8]
   80fc4:	f8287b50 	str	x16, [x26, x8, lsl #3]
   80fc8:	f940832e 	ldr	x14, [x25, #256]
   80fcc:	f9000328 	str	x8, [x25]
   80fd0:	910005c8 	add	x8, x14, #0x1
   80fd4:	f9008328 	str	x8, [x25, #256]
   80fd8:	3954006e 	ldrb	w14, [x3, #1280]
   80fdc:	710005df 	cmp	w14, #0x1
   80fe0:	5400f8c1 	b.ne	82ef8 <spin_92+0x2558>  // b.any
   80fe4:	f140211f 	cmp	x8, #0x8, lsl #12
   80fe8:	5400f882 	b.cs	82ef8 <spin_92+0x2558>  // b.hs, b.nlast
   80fec:	eb01019f 	cmp	x12, x1
   80ff0:	54000189 	b.ls	81020 <spin_92+0x680>  // b.plast
   80ff4:	f9400728 	ldr	x8, [x25, #8]
   80ff8:	f82c7b48 	str	x8, [x26, x12, lsl #3]
   80ffc:	f9408728 	ldr	x8, [x25, #264]
   81000:	f900072c 	str	x12, [x25, #8]
   81004:	91000908 	add	x8, x8, #0x2
   81008:	f9008728 	str	x8, [x25, #264]
   8100c:	3954006e 	ldrb	w14, [x3, #1280]
   81010:	710005df 	cmp	w14, #0x1
   81014:	5400e0a1 	b.ne	82c28 <spin_92+0x2288>  // b.any
   81018:	f140211f 	cmp	x8, #0x8, lsl #12
   8101c:	5400e062 	b.cs	82c28 <spin_92+0x2288>  // b.hs, b.nlast
   81020:	eb09015f 	cmp	x10, x9
   81024:	54000400 	b.eq	810a4 <spin_92+0x704>  // b.none
   81028:	f85f03a8 	ldur	x8, [x29, #-16]
   8102c:	f9401feb 	ldr	x11, [sp, #56]
   81030:	eb08015f 	cmp	x10, x8
   81034:	54000380 	b.eq	810a4 <spin_92+0x704>  // b.none
   81038:	eb1b015f 	cmp	x10, x27
   8103c:	aa1c03eb 	mov	x11, x28
   81040:	54000320 	b.eq	810a4 <spin_92+0x704>  // b.none
   81044:	f85e83a8 	ldur	x8, [x29, #-24]
   81048:	f9404feb 	ldr	x11, [sp, #152]
   8104c:	eb08015f 	cmp	x10, x8
   81050:	540002a0 	b.eq	810a4 <spin_92+0x704>  // b.none
   81054:	f85e03a8 	ldur	x8, [x29, #-32]
   81058:	f9401beb 	ldr	x11, [sp, #48]
   8105c:	eb08015f 	cmp	x10, x8
   81060:	54000220 	b.eq	810a4 <spin_92+0x704>  // b.none
   81064:	f85c83a8 	ldur	x8, [x29, #-56]
   81068:	f94013eb 	ldr	x11, [sp, #32]
   8106c:	eb08015f 	cmp	x10, x8
   81070:	540001a0 	b.eq	810a4 <spin_92+0x704>  // b.none
   81074:	f85c03a8 	ldur	x8, [x29, #-64]
   81078:	f9400beb 	ldr	x11, [sp, #16]
   8107c:	eb08015f 	cmp	x10, x8
   81080:	54000120 	b.eq	810a4 <spin_92+0x704>  // b.none
   81084:	f85b83a8 	ldur	x8, [x29, #-72]
   81088:	f94007eb 	ldr	x11, [sp, #8]
   8108c:	eb08015f 	cmp	x10, x8
   81090:	540000a0 	b.eq	810a4 <spin_92+0x704>  // b.none
   81094:	92409d4b 	and	x11, x10, #0xffffffffff
   81098:	b6f8006a 	tbz	x10, #63, 810a4 <spin_92+0x704>
   8109c:	f86b7b48 	ldr	x8, [x26, x11, lsl #3]
   810a0:	d358fd0b 	lsr	x11, x8, #24
   810a4:	f81d03b4 	stur	x20, [x29, #-48]
   810a8:	b4000834 	cbz	x20, 811ac <spin_92+0x80c>
   810ac:	d368fd48 	lsr	x8, x10, #40
   810b0:	8b0b0f4c 	add	x12, x26, x11, lsl #3
   810b4:	1280000b 	mov	w11, #0xffffffff            	// #-1
   810b8:	f258115f 	tst	x10, #0x1f0000000000
   810bc:	ad3a07a2 	stp	q2, q1, [x29, #-192]
   810c0:	1ac82168 	lsl	w8, w11, w8
   810c4:	1a9f07ee 	cset	w14, ne	// ne = any
   810c8:	b9400196 	ldr	w22, [x12]
   810cc:	f940072b 	ldr	x11, [x25, #8]
   810d0:	b86e599c 	ldr	w28, [x12, w14, uxtw #2]
   810d4:	2a2803e8 	mvn	w8, w8
   810d8:	927f0110 	and	x16, x8, #0x2
   810dc:	92400508 	and	x8, x8, #0x3
   810e0:	b870798e 	ldr	w14, [x12, x16, lsl #2]
   810e4:	b8687994 	ldr	w20, [x12, x8, lsl #2]
   810e8:	b400430b 	cbz	x11, 81948 <spin_92+0xfa8>
   810ec:	f86b7b48 	ldr	x8, [x26, x11, lsl #3]
   810f0:	f940872c 	ldr	x12, [x25, #264]
   810f4:	f9000728 	str	x8, [x25, #8]
   810f8:	d1000988 	sub	x8, x12, #0x2
   810fc:	f9008728 	str	x8, [x25, #264]
   81100:	d378fd48 	lsr	x8, x10, #56
   81104:	aa0a03e0 	mov	x0, x10
   81108:	f100091f 	cmp	x8, #0x2
   8110c:	54004400 	b.eq	8198c <spin_92+0xfec>  // b.none
   81110:	8b0b0f48 	add	x8, x26, x11, lsl #3
   81114:	a9003500 	stp	x0, x13, [x8]
   81118:	f9400f2c 	ldr	x12, [x25, #24]
   8111c:	b40045ac 	cbz	x12, 819d0 <spin_92+0x1030>
   81120:	f86c7b48 	ldr	x8, [x26, x12, lsl #3]
   81124:	f9408f30 	ldr	x16, [x25, #280]
   81128:	f9000f28 	str	x8, [x25, #24]
   8112c:	d1002208 	sub	x8, x16, #0x8
   81130:	f9008f28 	str	x8, [x25, #280]
   81134:	8b0c0f48 	add	x8, x26, x12, lsl #3
   81138:	a901510e 	stp	x14, x20, [x8, #16]
   8113c:	d2c4400e 	mov	x14, #0x220000000000        	// #37383395344384
   81140:	f2e0400e 	movk	x14, #0x200, lsl #48
   81144:	a9007116 	stp	x22, x28, [x8]
   81148:	aa0e0162 	orr	x2, x11, x14
   8114c:	f900110d 	str	x13, [x8, #32]
   81150:	b6f800ab 	tbz	x11, #63, 81164 <spin_92+0x7c4>
   81154:	eb0a005f 	cmp	x2, x10
   81158:	54000060 	b.eq	81164 <spin_92+0x7c4>  // b.none
   8115c:	92409d68 	and	x8, x11, #0xffffffffff
   81160:	f8687b5f 	ldr	xzr, [x26, x8, lsl #3]
   81164:	d2c52008 	mov	x8, #0x290000000000        	// #45079976738816
   81168:	f85d03b4 	ldur	x20, [x29, #-48]
   8116c:	f2e04008 	movk	x8, #0x200, lsl #48
   81170:	aa08018d 	orr	x13, x12, x8
   81174:	b6f800ac 	tbz	x12, #63, 81188 <spin_92+0x7e8>
   81178:	eb0a01bf 	cmp	x13, x10
   8117c:	54000060 	b.eq	81188 <spin_92+0x7e8>  // b.none
   81180:	92409d88 	and	x8, x12, #0xffffffffff
   81184:	f8687b5f 	ldr	xzr, [x26, x8, lsl #3]
   81188:	92409d68 	and	x8, x11, #0xffffffffff
   8118c:	8b080f50 	add	x16, x26, x8, lsl #3
   81190:	b7f8066b 	tbnz	x11, #63, 8125c <spin_92+0x8bc>
   81194:	f940020b 	ldr	x11, [x16]
   81198:	b9400a1c 	ldr	w28, [x16, #8]
   8119c:	aa0803ee 	mov	x14, x8
   811a0:	eb01011f 	cmp	x8, x1
   811a4:	54000a68 	b.hi	812f0 <spin_92+0x950>  // b.pmore
   811a8:	1400005d 	b	8131c <spin_92+0x97c>
   811ac:	aa1f03f6 	mov	x22, xzr
   811b0:	aa1f03fc 	mov	x28, xzr
   811b4:	6f00e403 	movi	v3.2d, #0x0
   811b8:	6f00e404 	movi	v4.2d, #0x0
   811bc:	aa1f03eb 	mov	x11, xzr
   811c0:	f9400b2c 	ldr	x12, [x25, #16]
   811c4:	b500138c 	cbnz	x12, 81434 <spin_92+0xa94>
   811c8:	aa1a03e0 	mov	x0, x26
   811cc:	aa1903e1 	mov	x1, x25
   811d0:	52800042 	mov	w2, #0x2                   	// #2
   811d4:	aa1103ec 	mov	x12, x17
   811d8:	aa1203ed 	mov	x13, x18
   811dc:	ad3a07a2 	stp	q2, q1, [x29, #-192]
   811e0:	ad050fe4 	stp	q4, q3, [sp, #160]
   811e4:	97fe0f0b 	bl	4e10 <heap_alloc_miss>
   811e8:	ad450fe4 	ldp	q4, q3, [sp, #160]
   811ec:	52909fe1 	mov	w1, #0x84ff                	// #34047
   811f0:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   811f4:	aa0d03f2 	mov	x18, x13
   811f8:	aa0c03f1 	mov	x17, x12
   811fc:	f0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   81200:	72a06201 	movk	w1, #0x310, lsl #16
   81204:	aa0003ec 	mov	x12, x0
   81208:	d378fd28 	lsr	x8, x9, #56
   8120c:	aa0903e0 	mov	x0, x9
   81210:	f100091f 	cmp	x8, #0x2
   81214:	54001221 	b.ne	81458 <spin_92+0xab8>  // b.any
   81218:	aa1a03e0 	mov	x0, x26
   8121c:	aa1903e1 	mov	x1, x25
   81220:	aa0903e2 	mov	x2, x9
   81224:	52800023 	mov	w3, #0x1                   	// #1
   81228:	aa1103ed 	mov	x13, x17
   8122c:	aa1203ee 	mov	x14, x18
   81230:	ad3a07a2 	stp	q2, q1, [x29, #-192]
   81234:	ad050fe4 	stp	q4, q3, [sp, #160]
   81238:	97fe0fe9 	bl	51dc <rfc_wrap>
   8123c:	ad450fe4 	ldp	q4, q3, [sp, #160]
   81240:	52909fe1 	mov	w1, #0x84ff                	// #34047
   81244:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   81248:	aa0e03f2 	mov	x18, x14
   8124c:	aa0d03f1 	mov	x17, x13
   81250:	f0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   81254:	72a06201 	movk	w1, #0x310, lsl #16
   81258:	14000080 	b	81458 <spin_92+0xab8>
   8125c:	b940060b 	ldr	w11, [x16, #4]
   81260:	b940020e 	ldr	w14, [x16]
   81264:	aa1103f6 	mov	x22, x17
   81268:	aa1303f7 	mov	x23, x19
   8126c:	aa1803f3 	mov	x19, x24
   81270:	aa0f03f8 	mov	x24, x15
   81274:	92405dd1 	and	x17, x14, #0xffffff
   81278:	aa1203ef 	mov	x15, x18
   8127c:	f100063f 	cmp	x17, #0x1
   81280:	5400dac1 	b.ne	82dd8 <spin_92+0x2438>  // b.any
   81284:	aa0b81cb 	orr	x11, x14, x11, lsl #32
   81288:	88dffe1f 	ldar	wzr, [x16]
   8128c:	f9400330 	ldr	x16, [x25]
   81290:	d358fd6e 	lsr	x14, x11, #24
   81294:	8b0e0f51 	add	x17, x26, x14, lsl #3
   81298:	f940022b 	ldr	x11, [x17]
   8129c:	b9400a3c 	ldr	w28, [x17, #8]
   812a0:	f8287b50 	str	x16, [x26, x8, lsl #3]
   812a4:	f9408330 	ldr	x16, [x25, #256]
   812a8:	f9000328 	str	x8, [x25]
   812ac:	91000608 	add	x8, x16, #0x1
   812b0:	f9008328 	str	x8, [x25, #256]
   812b4:	39540070 	ldrb	w16, [x3, #1280]
   812b8:	7100061f 	cmp	w16, #0x1
   812bc:	5400e3e1 	b.ne	82f38 <spin_92+0x2598>  // b.any
   812c0:	f140211f 	cmp	x8, #0x8, lsl #12
   812c4:	5400e3a2 	b.cs	82f38 <spin_92+0x2598>  // b.hs, b.nlast
   812c8:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   812cc:	aa0f03f2 	mov	x18, x15
   812d0:	aa1803ef 	mov	x15, x24
   812d4:	aa1303f8 	mov	x24, x19
   812d8:	aa1703f3 	mov	x19, x23
   812dc:	d2c1c017 	mov	x23, #0xe0000000000         	// #15393162788864
   812e0:	aa1603f1 	mov	x17, x22
   812e4:	f2e02017 	movk	x23, #0x100, lsl #48
   812e8:	eb0101df 	cmp	x14, x1
   812ec:	54000189 	b.ls	8131c <spin_92+0x97c>  // b.plast
   812f0:	f9400728 	ldr	x8, [x25, #8]
   812f4:	f82e7b48 	str	x8, [x26, x14, lsl #3]
   812f8:	f9408728 	ldr	x8, [x25, #264]
   812fc:	f900072e 	str	x14, [x25, #8]
   81300:	91000908 	add	x8, x8, #0x2
   81304:	f9008728 	str	x8, [x25, #264]
   81308:	39540070 	ldrb	w16, [x3, #1280]
   8130c:	7100061f 	cmp	w16, #0x1
   81310:	5400c9c1 	b.ne	82c48 <spin_92+0x22a8>  // b.any
   81314:	f140211f 	cmp	x8, #0x8, lsl #12
   81318:	5400c982 	b.cs	82c48 <spin_92+0x22a8>  // b.hs, b.nlast
   8131c:	92409d88 	and	x8, x12, #0xffffffffff
   81320:	8b080f4e 	add	x14, x26, x8, lsl #3
   81324:	b7f800ec 	tbnz	x12, #63, 81340 <spin_92+0x9a0>
   81328:	ad4011c3 	ldp	q3, q4, [x14]
   8132c:	aa0803ec 	mov	x12, x8
   81330:	b94021d6 	ldr	w22, [x14, #32]
   81334:	eb01011f 	cmp	x8, x1
   81338:	540005e8 	b.hi	813f4 <spin_92+0xa54>  // b.pmore
   8133c:	14000039 	b	81420 <spin_92+0xa80>
   81340:	f9005be9 	str	x9, [sp, #176]
   81344:	aa1303f7 	mov	x23, x19
   81348:	aa1103f3 	mov	x19, x17
   8134c:	b94005cc 	ldr	w12, [x14, #4]
   81350:	b94001d1 	ldr	w17, [x14]
   81354:	aa0b03e9 	mov	x9, x11
   81358:	aa1803eb 	mov	x11, x24
   8135c:	aa0f03f8 	mov	x24, x15
   81360:	aa1c03ef 	mov	x15, x28
   81364:	92405e30 	and	x16, x17, #0xffffff
   81368:	f100061f 	cmp	x16, #0x1
   8136c:	54000041 	b.ne	81374 <spin_92+0x9d4>  // b.any
   81370:	88dffddf 	ldar	wzr, [x14]
   81374:	aa0c822c 	orr	x12, x17, x12, lsl #32
   81378:	aa1203fc 	mov	x28, x18
   8137c:	f100061f 	cmp	x16, #0x1
   81380:	d358fd8c 	lsr	x12, x12, #24
   81384:	8b0c0f51 	add	x17, x26, x12, lsl #3
   81388:	ad401223 	ldp	q3, q4, [x17]
   8138c:	b9402236 	ldr	w22, [x17, #32]
   81390:	5400d4e1 	b.ne	82e2c <spin_92+0x248c>  // b.any
   81394:	f940032d 	ldr	x13, [x25]
   81398:	f90001cd 	str	x13, [x14]
   8139c:	f940832d 	ldr	x13, [x25, #256]
   813a0:	f9000328 	str	x8, [x25]
   813a4:	910005a8 	add	x8, x13, #0x1
   813a8:	f9008328 	str	x8, [x25, #256]
   813ac:	3954006d 	ldrb	w13, [x3, #1280]
   813b0:	710005bf 	cmp	w13, #0x1
   813b4:	5400dd21 	b.ne	82f58 <spin_92+0x25b8>  // b.any
   813b8:	f140211f 	cmp	x8, #0x8, lsl #12
   813bc:	5400dce2 	b.cs	82f58 <spin_92+0x25b8>  // b.hs, b.nlast
   813c0:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   813c4:	aa1303f1 	mov	x17, x19
   813c8:	aa1703f3 	mov	x19, x23
   813cc:	d2c1c017 	mov	x23, #0xe0000000000         	// #15393162788864
   813d0:	aa1c03f2 	mov	x18, x28
   813d4:	aa0f03fc 	mov	x28, x15
   813d8:	aa1803ef 	mov	x15, x24
   813dc:	aa0b03f8 	mov	x24, x11
   813e0:	aa0903eb 	mov	x11, x9
   813e4:	f9405be9 	ldr	x9, [sp, #176]
   813e8:	f2e02017 	movk	x23, #0x100, lsl #48
   813ec:	eb01019f 	cmp	x12, x1
   813f0:	54000189 	b.ls	81420 <spin_92+0xa80>  // b.plast
   813f4:	f9400f28 	ldr	x8, [x25, #24]
   813f8:	f82c7b48 	str	x8, [x26, x12, lsl #3]
   813fc:	f9408f28 	ldr	x8, [x25, #280]
   81400:	f9000f2c 	str	x12, [x25, #24]
   81404:	91002108 	add	x8, x8, #0x8
   81408:	f9008f28 	str	x8, [x25, #280]
   8140c:	3954006d 	ldrb	w13, [x3, #1280]
   81410:	710005bf 	cmp	w13, #0x1
   81414:	5400c341 	b.ne	82c7c <spin_92+0x22dc>  // b.any
   81418:	f140211f 	cmp	x8, #0x8, lsl #12
   8141c:	5400c302 	b.cs	82c7c <spin_92+0x22dc>  // b.hs, b.nlast
   81420:	6f00e5e0 	movi	v0.2d, #0xffffffff
   81424:	4e201c63 	and	v3.16b, v3.16b, v0.16b
   81428:	4e201c84 	and	v4.16b, v4.16b, v0.16b
   8142c:	f9400b2c 	ldr	x12, [x25, #16]
   81430:	b4ffeccc 	cbz	x12, 811c8 <spin_92+0x828>
   81434:	f86c7b48 	ldr	x8, [x26, x12, lsl #3]
   81438:	f9408b2d 	ldr	x13, [x25, #272]
   8143c:	f9000b28 	str	x8, [x25, #16]
   81440:	d10011a8 	sub	x8, x13, #0x4
   81444:	f9008b28 	str	x8, [x25, #272]
   81448:	d378fd28 	lsr	x8, x9, #56
   8144c:	aa0903e0 	mov	x0, x9
   81450:	f100091f 	cmp	x8, #0x2
   81454:	54ffee20 	b.eq	81218 <spin_92+0x878>  // b.none
   81458:	8b0c0f48 	add	x8, x26, x12, lsl #3
   8145c:	a9004500 	stp	x0, x17, [x8]
   81460:	f9000912 	str	x18, [x8, #16]
   81464:	f9400f2e 	ldr	x14, [x25, #24]
   81468:	b4000c4e 	cbz	x14, 815f0 <spin_92+0xc50>
   8146c:	f86e7b48 	ldr	x8, [x26, x14, lsl #3]
   81470:	f9408f2d 	ldr	x13, [x25, #280]
   81474:	f9000f28 	str	x8, [x25, #24]
   81478:	d10021a8 	sub	x8, x13, #0x8
   8147c:	f9008f28 	str	x8, [x25, #280]
   81480:	6f00e5e0 	movi	v0.2d, #0xffffffff
   81484:	8b0e0f48 	add	x8, x26, x14, lsl #3
   81488:	f900010f 	str	x15, [x8]
   8148c:	f9001518 	str	x24, [x8, #40]
   81490:	4e201c21 	and	v1.16b, v1.16b, v0.16b
   81494:	4e201c40 	and	v0.16b, v2.16b, v0.16b
   81498:	3c808101 	stur	q1, [x8, #8]
   8149c:	3c818100 	stur	q0, [x8, #24]
   814a0:	f940072d 	ldr	x13, [x25, #8]
   814a4:	b4000c0d 	cbz	x13, 81624 <spin_92+0xc84>
   814a8:	f86d7b48 	ldr	x8, [x26, x13, lsl #3]
   814ac:	f9408730 	ldr	x16, [x25, #264]
   814b0:	f9000728 	str	x8, [x25, #8]
   814b4:	d1000a08 	sub	x8, x16, #0x2
   814b8:	f9008728 	str	x8, [x25, #264]
   814bc:	d2c40008 	mov	x8, #0x200000000000        	// #35184372088832
   814c0:	f2e04008 	movk	x8, #0x200, lsl #48
   814c4:	aa080182 	orr	x2, x12, x8
   814c8:	d378fc48 	lsr	x8, x2, #56
   814cc:	f100091f 	cmp	x8, #0x2
   814d0:	54000ce0 	b.eq	8166c <spin_92+0xccc>  // b.none
   814d4:	d2c42008 	mov	x8, #0x210000000000        	// #36283883716608
   814d8:	8b0d0f4c 	add	x12, x26, x13, lsl #3
   814dc:	f2e04008 	movk	x8, #0x200, lsl #48
   814e0:	aa0801c8 	orr	x8, x14, x8
   814e4:	f9000182 	str	x2, [x12]
   814e8:	d378fd0e 	lsr	x14, x8, #56
   814ec:	f10009df 	cmp	x14, #0x2
   814f0:	54000d80 	b.eq	816a0 <spin_92+0xd00>  // b.none
   814f4:	f9000588 	str	x8, [x12, #8]
   814f8:	f9400f2c 	ldr	x12, [x25, #24]
   814fc:	b4000f0c 	cbz	x12, 816dc <spin_92+0xd3c>
   81500:	f86c7b48 	ldr	x8, [x26, x12, lsl #3]
   81504:	f9408f2e 	ldr	x14, [x25, #280]
   81508:	f9000f28 	str	x8, [x25, #24]
   8150c:	d10021c8 	sub	x8, x14, #0x8
   81510:	f9008f28 	str	x8, [x25, #280]
   81514:	8b0c0f48 	add	x8, x26, x12, lsl #3
   81518:	f900010f 	str	x15, [x8]
   8151c:	3c808101 	stur	q1, [x8, #8]
   81520:	3c818100 	stur	q0, [x8, #24]
   81524:	f9001518 	str	x24, [x8, #40]
   81528:	b4000ff4 	cbz	x20, 81724 <spin_92+0xd84>
   8152c:	f940072e 	ldr	x14, [x25, #8]
   81530:	b40026ce 	cbz	x14, 81a08 <spin_92+0x1068>
   81534:	f86e7b48 	ldr	x8, [x26, x14, lsl #3]
   81538:	f940872f 	ldr	x15, [x25, #264]
   8153c:	f9000728 	str	x8, [x25, #8]
   81540:	d10009e8 	sub	x8, x15, #0x2
   81544:	f9008728 	str	x8, [x25, #264]
   81548:	d378fd68 	lsr	x8, x11, #56
   8154c:	f100091f 	cmp	x8, #0x2
   81550:	54002760 	b.eq	81a3c <spin_92+0x109c>  // b.none
   81554:	8b0e0f48 	add	x8, x26, x14, lsl #3
   81558:	a900710b 	stp	x11, x28, [x8]
   8155c:	f940032b 	ldr	x11, [x25]
   81560:	b40028ab 	cbz	x11, 81a74 <spin_92+0x10d4>
   81564:	f86b7b48 	ldr	x8, [x26, x11, lsl #3]
   81568:	f940832f 	ldr	x15, [x25, #256]
   8156c:	f9000328 	str	x8, [x25]
   81570:	d10005e8 	sub	x8, x15, #0x1
   81574:	f9008328 	str	x8, [x25, #256]
   81578:	d2c44008 	mov	x8, #0x220000000000        	// #37383395344384
   8157c:	f2e04008 	movk	x8, #0x200, lsl #48
   81580:	aa0801c2 	orr	x2, x14, x8
   81584:	d378fc48 	lsr	x8, x2, #56
   81588:	f100091f 	cmp	x8, #0x2
   8158c:	54002940 	b.eq	81ab4 <spin_92+0x1114>  // b.none
   81590:	f82b7b42 	str	x2, [x26, x11, lsl #3]
   81594:	f9400f20 	ldr	x0, [x25, #24]
   81598:	b4002a60 	cbz	x0, 81ae4 <spin_92+0x1144>
   8159c:	f8607b48 	ldr	x8, [x26, x0, lsl #3]
   815a0:	f9408f2e 	ldr	x14, [x25, #280]
   815a4:	f9000f28 	str	x8, [x25, #24]
   815a8:	d10021c8 	sub	x8, x14, #0x8
   815ac:	f9008f28 	str	x8, [x25, #280]
   815b0:	8b000f48 	add	x8, x26, x0, lsl #3
   815b4:	d2c1200e 	mov	x14, #0x90000000000         	// #9895604649984
   815b8:	f2e0400e 	movk	x14, #0x200, lsl #48
   815bc:	ad001103 	stp	q3, q4, [x8]
   815c0:	aa0e016f 	orr	x15, x11, x14
   815c4:	f9001116 	str	x22, [x8, #32]
   815c8:	d2c52008 	mov	x8, #0x290000000000        	// #45079976738816
   815cc:	f2e04008 	movk	x8, #0x200, lsl #48
   815d0:	aa08000b 	orr	x11, x0, x8
   815d4:	d2c3e008 	mov	x8, #0x1f0000000000        	// #34084860461056
   815d8:	d2c10016 	mov	x22, #0x80000000000         	// #8796093022208
   815dc:	f2e04008 	movk	x8, #0x200, lsl #48
   815e0:	aa0801a2 	orr	x2, x13, x8
   815e4:	eb09005f 	cmp	x2, x9
   815e8:	54000b01 	b.ne	81748 <spin_92+0xda8>  // b.any
   815ec:	1400005c 	b	8175c <spin_92+0xdbc>
   815f0:	aa1a03e0 	mov	x0, x26
   815f4:	aa1903e1 	mov	x1, x25
   815f8:	52800062 	mov	w2, #0x3                   	// #3
   815fc:	ad3a07a2 	stp	q2, q1, [x29, #-192]
   81600:	ad050fe4 	stp	q4, q3, [sp, #160]
   81604:	97fe0e03 	bl	4e10 <heap_alloc_miss>
   81608:	ad450fe4 	ldp	q4, q3, [sp, #160]
   8160c:	52909fe1 	mov	w1, #0x84ff                	// #34047
   81610:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   81614:	f0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   81618:	72a06201 	movk	w1, #0x310, lsl #16
   8161c:	aa0003ee 	mov	x14, x0
   81620:	17ffff98 	b	81480 <spin_92+0xae0>
   81624:	aa1a03e0 	mov	x0, x26
   81628:	aa1903e1 	mov	x1, x25
   8162c:	52800022 	mov	w2, #0x1                   	// #1
   81630:	ad050fe4 	stp	q4, q3, [sp, #160]
   81634:	ad3a07a0 	stp	q0, q1, [x29, #-192]
   81638:	97fe0df6 	bl	4e10 <heap_alloc_miss>
   8163c:	ad7a07a0 	ldp	q0, q1, [x29, #-192]
   81640:	52909fe1 	mov	w1, #0x84ff                	// #34047
   81644:	ad450fe4 	ldp	q4, q3, [sp, #160]
   81648:	f0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   8164c:	72a06201 	movk	w1, #0x310, lsl #16
   81650:	aa0003ed 	mov	x13, x0
   81654:	d2c40008 	mov	x8, #0x200000000000        	// #35184372088832
   81658:	f2e04008 	movk	x8, #0x200, lsl #48
   8165c:	aa080182 	orr	x2, x12, x8
   81660:	d378fc48 	lsr	x8, x2, #56
   81664:	f100091f 	cmp	x8, #0x2
   81668:	54fff361 	b.ne	814d4 <spin_92+0xb34>  // b.any
   8166c:	aa1a03e0 	mov	x0, x26
   81670:	aa1903e1 	mov	x1, x25
   81674:	52800023 	mov	w3, #0x1                   	// #1
   81678:	ad050fe4 	stp	q4, q3, [sp, #160]
   8167c:	ad3a07a0 	stp	q0, q1, [x29, #-192]
   81680:	97fe0ed7 	bl	51dc <rfc_wrap>
   81684:	ad7a07a0 	ldp	q0, q1, [x29, #-192]
   81688:	52909fe1 	mov	w1, #0x84ff                	// #34047
   8168c:	ad450fe4 	ldp	q4, q3, [sp, #160]
   81690:	f0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   81694:	72a06201 	movk	w1, #0x310, lsl #16
   81698:	aa0003e2 	mov	x2, x0
   8169c:	17ffff8e 	b	814d4 <spin_92+0xb34>
   816a0:	aa1a03e0 	mov	x0, x26
   816a4:	aa1903e1 	mov	x1, x25
   816a8:	aa0803e2 	mov	x2, x8
   816ac:	52800023 	mov	w3, #0x1                   	// #1
   816b0:	ad050fe4 	stp	q4, q3, [sp, #160]
   816b4:	ad3a07a0 	stp	q0, q1, [x29, #-192]
   816b8:	97fe0ec9 	bl	51dc <rfc_wrap>
   816bc:	ad7a07a0 	ldp	q0, q1, [x29, #-192]
   816c0:	52909fe1 	mov	w1, #0x84ff                	// #34047
   816c4:	ad450fe4 	ldp	q4, q3, [sp, #160]
   816c8:	f0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   816cc:	72a06201 	movk	w1, #0x310, lsl #16
   816d0:	f9000580 	str	x0, [x12, #8]
   816d4:	f9400f2c 	ldr	x12, [x25, #24]
   816d8:	b5fff14c 	cbnz	x12, 81500 <spin_92+0xb60>
   816dc:	aa1a03e0 	mov	x0, x26
   816e0:	aa1903e1 	mov	x1, x25
   816e4:	52800062 	mov	w2, #0x3                   	// #3
   816e8:	ad050fe4 	stp	q4, q3, [sp, #160]
   816ec:	ad3a07a0 	stp	q0, q1, [x29, #-192]
   816f0:	97fe0dc8 	bl	4e10 <heap_alloc_miss>
   816f4:	ad7a07a0 	ldp	q0, q1, [x29, #-192]
   816f8:	52909fe1 	mov	w1, #0x84ff                	// #34047
   816fc:	ad450fe4 	ldp	q4, q3, [sp, #160]
   81700:	f0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   81704:	72a06201 	movk	w1, #0x310, lsl #16
   81708:	aa0003ec 	mov	x12, x0
   8170c:	8b000f48 	add	x8, x26, x0, lsl #3
   81710:	f900010f 	str	x15, [x8]
   81714:	3c808101 	stur	q1, [x8, #8]
   81718:	3c818100 	stur	q0, [x8, #24]
   8171c:	f9001518 	str	x24, [x8, #40]
   81720:	b5fff074 	cbnz	x20, 8152c <spin_92+0xb8c>
   81724:	d2c1000f 	mov	x15, #0x80000000000         	// #8796093022208
   81728:	aa1f03eb 	mov	x11, xzr
   8172c:	f2e0200f 	movk	x15, #0x100, lsl #48
   81730:	d2c3e008 	mov	x8, #0x1f0000000000        	// #34084860461056
   81734:	d2c10016 	mov	x22, #0x80000000000         	// #8796093022208
   81738:	f2e04008 	movk	x8, #0x200, lsl #48
   8173c:	aa0801a2 	orr	x2, x13, x8
   81740:	eb09005f 	cmp	x2, x9
   81744:	540000c0 	b.eq	8175c <spin_92+0xdbc>  // b.none
   81748:	eb0a005f 	cmp	x2, x10
   8174c:	54000080 	b.eq	8175c <spin_92+0xdbc>  // b.none
   81750:	b6f8006d 	tbz	x13, #63, 8175c <spin_92+0xdbc>
   81754:	92409da8 	and	x8, x13, #0xffffffffff
   81758:	f8687b5f 	ldr	xzr, [x26, x8, lsl #3]
   8175c:	d2c42008 	mov	x8, #0x210000000000        	// #36283883716608
   81760:	f2e04008 	movk	x8, #0x200, lsl #48
   81764:	aa08018e 	orr	x14, x12, x8
   81768:	b6f800ec 	tbz	x12, #63, 81784 <spin_92+0xde4>
   8176c:	eb0901df 	cmp	x14, x9
   81770:	540000a0 	b.eq	81784 <spin_92+0xde4>  // b.none
   81774:	eb0a01df 	cmp	x14, x10
   81778:	54000060 	b.eq	81784 <spin_92+0xde4>  // b.none
   8177c:	92409d88 	and	x8, x12, #0xffffffffff
   81780:	f8687b5f 	ldr	xzr, [x26, x8, lsl #3]
   81784:	b6f800ef 	tbz	x15, #63, 817a0 <spin_92+0xe00>
   81788:	eb0901ff 	cmp	x15, x9
   8178c:	540000a0 	b.eq	817a0 <spin_92+0xe00>  // b.none
   81790:	eb0a01ff 	cmp	x15, x10
   81794:	54000060 	b.eq	817a0 <spin_92+0xe00>  // b.none
   81798:	92409de8 	and	x8, x15, #0xffffffffff
   8179c:	f8687b5f 	ldr	xzr, [x26, x8, lsl #3]
   817a0:	f90053ee 	str	x14, [sp, #160]
   817a4:	b6f800eb 	tbz	x11, #63, 817c0 <spin_92+0xe20>
   817a8:	eb09017f 	cmp	x11, x9
   817ac:	540000a0 	b.eq	817c0 <spin_92+0xe20>  // b.none
   817b0:	eb0a017f 	cmp	x11, x10
   817b4:	54000060 	b.eq	817c0 <spin_92+0xe20>  // b.none
   817b8:	92409d68 	and	x8, x11, #0xffffffffff
   817bc:	f8687b5f 	ldr	xzr, [x26, x8, lsl #3]
   817c0:	92409da8 	and	x8, x13, #0xffffffffff
   817c4:	8b080f50 	add	x16, x26, x8, lsl #3
   817c8:	b7f800cd 	tbnz	x13, #63, 817e0 <spin_92+0xe40>
   817cc:	a940621c 	ldp	x28, x24, [x16]
   817d0:	aa0803ed 	mov	x13, x8
   817d4:	eb01011f 	cmp	x8, x1
   817d8:	54000328 	b.hi	8183c <spin_92+0xe9c>  // b.pmore
   817dc:	14000023 	b	81868 <spin_92+0xec8>
   817e0:	b940060d 	ldr	w13, [x16, #4]
   817e4:	b9400211 	ldr	w17, [x16]
   817e8:	92405e32 	and	x18, x17, #0xffffff
   817ec:	f100065f 	cmp	x18, #0x1
   817f0:	54008c21 	b.ne	82974 <spin_92+0x1fd4>  // b.any
   817f4:	aa0d822d 	orr	x13, x17, x13, lsl #32
   817f8:	88dffe1f 	ldar	wzr, [x16]
   817fc:	f9400330 	ldr	x16, [x25]
   81800:	d358fdad 	lsr	x13, x13, #24
   81804:	8b0d0f51 	add	x17, x26, x13, lsl #3
   81808:	a940623c 	ldp	x28, x24, [x17]
   8180c:	f8287b50 	str	x16, [x26, x8, lsl #3]
   81810:	f9408330 	ldr	x16, [x25, #256]
   81814:	f9000328 	str	x8, [x25]
   81818:	91000608 	add	x8, x16, #0x1
   8181c:	f9008328 	str	x8, [x25, #256]
   81820:	39540070 	ldrb	w16, [x3, #1280]
   81824:	7100061f 	cmp	w16, #0x1
   81828:	54009861 	b.ne	82b34 <spin_92+0x2194>  // b.any
   8182c:	f140211f 	cmp	x8, #0x8, lsl #12
   81830:	54009822 	b.cs	82b34 <spin_92+0x2194>  // b.hs, b.nlast
   81834:	eb0101bf 	cmp	x13, x1
   81838:	54000189 	b.ls	81868 <spin_92+0xec8>  // b.plast
   8183c:	f9400728 	ldr	x8, [x25, #8]
   81840:	f82d7b48 	str	x8, [x26, x13, lsl #3]
   81844:	f9408728 	ldr	x8, [x25, #264]
   81848:	f900072d 	str	x13, [x25, #8]
   8184c:	91000908 	add	x8, x8, #0x2
   81850:	f9008728 	str	x8, [x25, #264]
   81854:	39540070 	ldrb	w16, [x3, #1280]
   81858:	7100061f 	cmp	w16, #0x1
   8185c:	54001901 	b.ne	81b7c <spin_92+0x11dc>  // b.any
   81860:	f140211f 	cmp	x8, #0x8, lsl #12
   81864:	540018c2 	b.cs	81b7c <spin_92+0x11dc>  // b.hs, b.nlast
   81868:	92409f88 	and	x8, x28, #0xffffffffff
   8186c:	8b080f50 	add	x16, x26, x8, lsl #3
   81870:	b7f8011c 	tbnz	x28, #63, 81890 <spin_92+0xef0>
   81874:	f940020d 	ldr	x13, [x16]
   81878:	b9400a02 	ldr	w2, [x16, #8]
   8187c:	aa0803f4 	mov	x20, x8
   81880:	b9401204 	ldr	w4, [x16, #16]
   81884:	eb01011f 	cmp	x8, x1
   81888:	54000368 	b.hi	818f4 <spin_92+0xf54>  // b.pmore
   8188c:	14000025 	b	81920 <spin_92+0xf80>
   81890:	b940060d 	ldr	w13, [x16, #4]
   81894:	b9400211 	ldr	w17, [x16]
   81898:	92405e32 	and	x18, x17, #0xffffff
   8189c:	f100065f 	cmp	x18, #0x1
   818a0:	54008821 	b.ne	829a4 <spin_92+0x2004>  // b.any
   818a4:	aa0d822d 	orr	x13, x17, x13, lsl #32
   818a8:	88dffe1f 	ldar	wzr, [x16]
   818ac:	f9400330 	ldr	x16, [x25]
   818b0:	d358fdb4 	lsr	x20, x13, #24
   818b4:	8b140f51 	add	x17, x26, x20, lsl #3
   818b8:	f940022d 	ldr	x13, [x17]
   818bc:	b9400a22 	ldr	w2, [x17, #8]
   818c0:	b9401224 	ldr	w4, [x17, #16]
   818c4:	f8287b50 	str	x16, [x26, x8, lsl #3]
   818c8:	f9408330 	ldr	x16, [x25, #256]
   818cc:	f9000328 	str	x8, [x25]
   818d0:	91000608 	add	x8, x16, #0x1
   818d4:	f9008328 	str	x8, [x25, #256]
   818d8:	39540070 	ldrb	w16, [x3, #1280]
   818dc:	7100061f 	cmp	w16, #0x1
   818e0:	540093e1 	b.ne	82b5c <spin_92+0x21bc>  // b.any
   818e4:	f140211f 	cmp	x8, #0x8, lsl #12
   818e8:	540093a2 	b.cs	82b5c <spin_92+0x21bc>  // b.hs, b.nlast
   818ec:	eb01029f 	cmp	x20, x1
   818f0:	54000189 	b.ls	81920 <spin_92+0xf80>  // b.plast
   818f4:	f9400b28 	ldr	x8, [x25, #16]
   818f8:	f8347b48 	str	x8, [x26, x20, lsl #3]
   818fc:	f9408b28 	ldr	x8, [x25, #272]
   81900:	f9000b34 	str	x20, [x25, #16]
   81904:	91001108 	add	x8, x8, #0x4
   81908:	f9008b28 	str	x8, [x25, #272]
   8190c:	39540070 	ldrb	w16, [x3, #1280]
   81910:	7100061f 	cmp	w16, #0x1
   81914:	540013e1 	b.ne	81b90 <spin_92+0x11f0>  // b.any
   81918:	f140211f 	cmp	x8, #0x8, lsl #12
   8191c:	540013a2 	b.cs	81b90 <spin_92+0x11f0>  // b.hs, b.nlast
   81920:	f85d03b4 	ldur	x20, [x29, #-48]
   81924:	92409f08 	and	x8, x24, #0xffffffffff
   81928:	8b080f50 	add	x16, x26, x8, lsl #3
   8192c:	b7f81518 	tbnz	x24, #63, 81bcc <spin_92+0x122c>
   81930:	ad401201 	ldp	q1, q4, [x16]
   81934:	aa0803fc 	mov	x28, x8
   81938:	3dc00a03 	ldr	q3, [x16, #32]
   8193c:	eb01011f 	cmp	x8, x1
   81940:	540017a8 	b.hi	81c34 <spin_92+0x1294>  // b.pmore
   81944:	140000c7 	b	81c60 <spin_92+0x12c0>
   81948:	aa1a03e0 	mov	x0, x26
   8194c:	aa1903e1 	mov	x1, x25
   81950:	52800022 	mov	w2, #0x1                   	// #1
   81954:	aa1103eb 	mov	x11, x17
   81958:	aa1203ec 	mov	x12, x18
   8195c:	97fe0d2d 	bl	4e10 <heap_alloc_miss>
   81960:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   81964:	52909fe1 	mov	w1, #0x84ff                	// #34047
   81968:	aa0c03f2 	mov	x18, x12
   8196c:	aa0b03f1 	mov	x17, x11
   81970:	f0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   81974:	72a06201 	movk	w1, #0x310, lsl #16
   81978:	aa0003eb 	mov	x11, x0
   8197c:	d378fd48 	lsr	x8, x10, #56
   81980:	aa0a03e0 	mov	x0, x10
   81984:	f100091f 	cmp	x8, #0x2
   81988:	54ffbc41 	b.ne	81110 <spin_92+0x770>  // b.any
   8198c:	aa1a03e0 	mov	x0, x26
   81990:	aa1903e1 	mov	x1, x25
   81994:	aa0a03e2 	mov	x2, x10
   81998:	52800023 	mov	w3, #0x1                   	// #1
   8199c:	aa1103ec 	mov	x12, x17
   819a0:	f9005bf2 	str	x18, [sp, #176]
   819a4:	97fe0e0e 	bl	51dc <rfc_wrap>
   819a8:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   819ac:	52909fe1 	mov	w1, #0x84ff                	// #34047
   819b0:	f9405bf2 	ldr	x18, [sp, #176]
   819b4:	aa0c03f1 	mov	x17, x12
   819b8:	f0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   819bc:	72a06201 	movk	w1, #0x310, lsl #16
   819c0:	8b0b0f48 	add	x8, x26, x11, lsl #3
   819c4:	a9003500 	stp	x0, x13, [x8]
   819c8:	f9400f2c 	ldr	x12, [x25, #24]
   819cc:	b5ffbaac 	cbnz	x12, 81120 <spin_92+0x780>
   819d0:	aa1a03e0 	mov	x0, x26
   819d4:	aa1903e1 	mov	x1, x25
   819d8:	52800062 	mov	w2, #0x3                   	// #3
   819dc:	aa1103ec 	mov	x12, x17
   819e0:	f9005bf2 	str	x18, [sp, #176]
   819e4:	97fe0d0b 	bl	4e10 <heap_alloc_miss>
   819e8:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   819ec:	52909fe1 	mov	w1, #0x84ff                	// #34047
   819f0:	f9405bf2 	ldr	x18, [sp, #176]
   819f4:	aa0c03f1 	mov	x17, x12
   819f8:	f0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   819fc:	72a06201 	movk	w1, #0x310, lsl #16
   81a00:	aa0003ec 	mov	x12, x0
   81a04:	17fffdcc 	b	81134 <spin_92+0x794>
   81a08:	aa1a03e0 	mov	x0, x26
   81a0c:	aa1903e1 	mov	x1, x25
   81a10:	52800022 	mov	w2, #0x1                   	// #1
   81a14:	ad050fe4 	stp	q4, q3, [sp, #160]
   81a18:	97fe0cfe 	bl	4e10 <heap_alloc_miss>
   81a1c:	ad450fe4 	ldp	q4, q3, [sp, #160]
   81a20:	52909fe1 	mov	w1, #0x84ff                	// #34047
   81a24:	f0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   81a28:	72a06201 	movk	w1, #0x310, lsl #16
   81a2c:	aa0003ee 	mov	x14, x0
   81a30:	d378fd68 	lsr	x8, x11, #56
   81a34:	f100091f 	cmp	x8, #0x2
   81a38:	54ffd8e1 	b.ne	81554 <spin_92+0xbb4>  // b.any
   81a3c:	aa1a03e0 	mov	x0, x26
   81a40:	aa1903e1 	mov	x1, x25
   81a44:	aa0b03e2 	mov	x2, x11
   81a48:	52800023 	mov	w3, #0x1                   	// #1
   81a4c:	ad050fe4 	stp	q4, q3, [sp, #160]
   81a50:	97fe0de3 	bl	51dc <rfc_wrap>
   81a54:	ad450fe4 	ldp	q4, q3, [sp, #160]
   81a58:	52909fe1 	mov	w1, #0x84ff                	// #34047
   81a5c:	f0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   81a60:	72a06201 	movk	w1, #0x310, lsl #16
   81a64:	8b0e0f48 	add	x8, x26, x14, lsl #3
   81a68:	a9007100 	stp	x0, x28, [x8]
   81a6c:	f940032b 	ldr	x11, [x25]
   81a70:	b5ffd7ab 	cbnz	x11, 81564 <spin_92+0xbc4>
   81a74:	aa1a03e0 	mov	x0, x26
   81a78:	aa1903e1 	mov	x1, x25
   81a7c:	2a1f03e2 	mov	w2, wzr
   81a80:	ad050fe4 	stp	q4, q3, [sp, #160]
   81a84:	97fe0ce3 	bl	4e10 <heap_alloc_miss>
   81a88:	ad450fe4 	ldp	q4, q3, [sp, #160]
   81a8c:	52909fe1 	mov	w1, #0x84ff                	// #34047
   81a90:	f0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   81a94:	72a06201 	movk	w1, #0x310, lsl #16
   81a98:	aa0003eb 	mov	x11, x0
   81a9c:	d2c44008 	mov	x8, #0x220000000000        	// #37383395344384
   81aa0:	f2e04008 	movk	x8, #0x200, lsl #48
   81aa4:	aa0801c2 	orr	x2, x14, x8
   81aa8:	d378fc48 	lsr	x8, x2, #56
   81aac:	f100091f 	cmp	x8, #0x2
   81ab0:	54ffd701 	b.ne	81590 <spin_92+0xbf0>  // b.any
   81ab4:	aa1a03e0 	mov	x0, x26
   81ab8:	aa1903e1 	mov	x1, x25
   81abc:	52800023 	mov	w3, #0x1                   	// #1
   81ac0:	ad050fe4 	stp	q4, q3, [sp, #160]
   81ac4:	97fe0dc6 	bl	51dc <rfc_wrap>
   81ac8:	ad450fe4 	ldp	q4, q3, [sp, #160]
   81acc:	52909fe1 	mov	w1, #0x84ff                	// #34047
   81ad0:	f0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   81ad4:	72a06201 	movk	w1, #0x310, lsl #16
   81ad8:	f82b7b40 	str	x0, [x26, x11, lsl #3]
   81adc:	f9400f20 	ldr	x0, [x25, #24]
   81ae0:	b5ffd5e0 	cbnz	x0, 8159c <spin_92+0xbfc>
   81ae4:	aa1a03e0 	mov	x0, x26
   81ae8:	aa1903e1 	mov	x1, x25
   81aec:	52800062 	mov	w2, #0x3                   	// #3
   81af0:	ad050fe4 	stp	q4, q3, [sp, #160]
   81af4:	97fe0cc7 	bl	4e10 <heap_alloc_miss>
   81af8:	ad450fe4 	ldp	q4, q3, [sp, #160]
   81afc:	52909fe1 	mov	w1, #0x84ff                	// #34047
   81b00:	f0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   81b04:	72a06201 	movk	w1, #0x310, lsl #16
   81b08:	17fffeaa 	b	815b0 <spin_92+0xc10>
   81b0c:	aa1a03e0 	mov	x0, x26
   81b10:	aa1903e1 	mov	x1, x25
   81b14:	52800022 	mov	w2, #0x1                   	// #1
   81b18:	97fe0aaa 	bl	45c0 <heap_hand>
   81b1c:	14000370 	b	828dc <spin_92+0x1f3c>
   81b20:	aa1a03e0 	mov	x0, x26
   81b24:	aa1903e1 	mov	x1, x25
   81b28:	52800042 	mov	w2, #0x2                   	// #2
   81b2c:	aa1103eb 	mov	x11, x17
   81b30:	aa1203ed 	mov	x13, x18
   81b34:	97fe0aa3 	bl	45c0 <heap_hand>
   81b38:	aa0d03f2 	mov	x18, x13
   81b3c:	aa0b03f1 	mov	x17, x11
   81b40:	14000378 	b	82920 <spin_92+0x1f80>
   81b44:	aa1a03e0 	mov	x0, x26
   81b48:	aa1903e1 	mov	x1, x25
   81b4c:	52800062 	mov	w2, #0x3                   	// #3
   81b50:	aa1103ea 	mov	x10, x17
   81b54:	aa1203eb 	mov	x11, x18
   81b58:	ad3a07a2 	stp	q2, q1, [x29, #-192]
   81b5c:	97fe0a99 	bl	45c0 <heap_hand>
   81b60:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   81b64:	52909fe1 	mov	w1, #0x84ff                	// #34047
   81b68:	aa0b03f2 	mov	x18, x11
   81b6c:	aa0a03f1 	mov	x17, x10
   81b70:	f0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   81b74:	72a06201 	movk	w1, #0x310, lsl #16
   81b78:	17fffcce 	b	80eb0 <spin_92+0x510>
   81b7c:	aa1a03e0 	mov	x0, x26
   81b80:	aa1903e1 	mov	x1, x25
   81b84:	52800022 	mov	w2, #0x1                   	// #1
   81b88:	97fe0a8e 	bl	45c0 <heap_hand>
   81b8c:	14000382 	b	82994 <spin_92+0x1ff4>
   81b90:	aa1a03e0 	mov	x0, x26
   81b94:	aa1903e1 	mov	x1, x25
   81b98:	aa0203f4 	mov	x20, x2
   81b9c:	52800042 	mov	w2, #0x2                   	// #2
   81ba0:	aa0403ee 	mov	x14, x4
   81ba4:	97fe0a87 	bl	45c0 <heap_hand>
   81ba8:	52909fe1 	mov	w1, #0x84ff                	// #34047
   81bac:	aa0e03e4 	mov	x4, x14
   81bb0:	aa1403e2 	mov	x2, x20
   81bb4:	f0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   81bb8:	72a06201 	movk	w1, #0x310, lsl #16
   81bbc:	f85d03b4 	ldur	x20, [x29, #-48]
   81bc0:	92409f08 	and	x8, x24, #0xffffffffff
   81bc4:	8b080f50 	add	x16, x26, x8, lsl #3
   81bc8:	b6ffeb58 	tbz	x24, #63, 81930 <spin_92+0xf90>
   81bcc:	b9400612 	ldr	w18, [x16, #4]
   81bd0:	b9400200 	ldr	w0, [x16]
   81bd4:	92405c11 	and	x17, x0, #0xffffff
   81bd8:	f100063f 	cmp	x17, #0x1
   81bdc:	54000041 	b.ne	81be4 <spin_92+0x1244>  // b.any
   81be0:	88dffe1f 	ldar	wzr, [x16]
   81be4:	aa128012 	orr	x18, x0, x18, lsl #32
   81be8:	f100063f 	cmp	x17, #0x1
   81bec:	d358fe5c 	lsr	x28, x18, #24
   81bf0:	8b1c0f52 	add	x18, x26, x28, lsl #3
   81bf4:	ad401241 	ldp	q1, q4, [x18]
   81bf8:	3dc00a43 	ldr	q3, [x18, #32]
   81bfc:	54006fe1 	b.ne	829f8 <spin_92+0x2058>  // b.any
   81c00:	f9400331 	ldr	x17, [x25]
   81c04:	f9000211 	str	x17, [x16]
   81c08:	f9408330 	ldr	x16, [x25, #256]
   81c0c:	f9000328 	str	x8, [x25]
   81c10:	91000608 	add	x8, x16, #0x1
   81c14:	f9008328 	str	x8, [x25, #256]
   81c18:	39540070 	ldrb	w16, [x3, #1280]
   81c1c:	7100061f 	cmp	w16, #0x1
   81c20:	54007bc1 	b.ne	82b98 <spin_92+0x21f8>  // b.any
   81c24:	f140211f 	cmp	x8, #0x8, lsl #12
   81c28:	54007b82 	b.cs	82b98 <spin_92+0x21f8>  // b.hs, b.nlast
   81c2c:	eb01039f 	cmp	x28, x1
   81c30:	54000189 	b.ls	81c60 <spin_92+0x12c0>  // b.plast
   81c34:	f9400f28 	ldr	x8, [x25, #24]
   81c38:	f83c7b48 	str	x8, [x26, x28, lsl #3]
   81c3c:	f9408f28 	ldr	x8, [x25, #280]
   81c40:	f9000f3c 	str	x28, [x25, #24]
   81c44:	91002108 	add	x8, x8, #0x8
   81c48:	f9008f28 	str	x8, [x25, #280]
   81c4c:	39540070 	ldrb	w16, [x3, #1280]
   81c50:	7100061f 	cmp	w16, #0x1
   81c54:	54005e81 	b.ne	82824 <spin_92+0x1e84>  // b.any
   81c58:	f140211f 	cmp	x8, #0x8, lsl #12
   81c5c:	54005e42 	b.cs	82824 <spin_92+0x1e84>  // b.hs, b.nlast
   81c60:	92583dfc 	and	x28, x15, #0xffff0000000000
   81c64:	eb16039f 	cmp	x28, x22
   81c68:	54000181 	b.ne	81c98 <spin_92+0x12f8>  // b.any
   81c6c:	aa1f03ef 	mov	x15, xzr
   81c70:	aa1f03f8 	mov	x24, xzr
   81c74:	92409d88 	and	x8, x12, #0xffffffffff
   81c78:	8b080f50 	add	x16, x26, x8, lsl #3
   81c7c:	b7f80d2c 	tbnz	x12, #63, 81e20 <spin_92+0x1480>
   81c80:	ad401e05 	ldp	q5, q7, [x16]
   81c84:	aa0803ec 	mov	x12, x8
   81c88:	3dc00a06 	ldr	q6, [x16, #32]
   81c8c:	eb01011f 	cmp	x8, x1
   81c90:	54001128 	b.hi	81eb4 <spin_92+0x1514>  // b.pmore
   81c94:	14000093 	b	81ee0 <spin_92+0x1540>
   81c98:	92409de8 	and	x8, x15, #0xffffffffff
   81c9c:	8b080f50 	add	x16, x26, x8, lsl #3
   81ca0:	b7f800cf 	tbnz	x15, #63, 81cb8 <spin_92+0x1318>
   81ca4:	f9400218 	ldr	x24, [x16]
   81ca8:	aa0803ef 	mov	x15, x8
   81cac:	eb01011f 	cmp	x8, x1
   81cb0:	54000308 	b.hi	81d10 <spin_92+0x1370>  // b.pmore
   81cb4:	14000022 	b	81d3c <spin_92+0x139c>
   81cb8:	b9400611 	ldr	w17, [x16, #4]
   81cbc:	b9400212 	ldr	w18, [x16]
   81cc0:	92405e40 	and	x0, x18, #0xffffff
   81cc4:	f100041f 	cmp	x0, #0x1
   81cc8:	54009a21 	b.ne	8300c <spin_92+0x266c>  // b.any
   81ccc:	aa11824f 	orr	x15, x18, x17, lsl #32
   81cd0:	88dffe1f 	ldar	wzr, [x16]
   81cd4:	f9400330 	ldr	x16, [x25]
   81cd8:	d358fdef 	lsr	x15, x15, #24
   81cdc:	f86f7b58 	ldr	x24, [x26, x15, lsl #3]
   81ce0:	f8287b50 	str	x16, [x26, x8, lsl #3]
   81ce4:	f9408330 	ldr	x16, [x25, #256]
   81ce8:	f9000328 	str	x8, [x25]
   81cec:	91000608 	add	x8, x16, #0x1
   81cf0:	f9008328 	str	x8, [x25, #256]
   81cf4:	39540070 	ldrb	w16, [x3, #1280]
   81cf8:	7100061f 	cmp	w16, #0x1
   81cfc:	54009e01 	b.ne	830bc <spin_92+0x271c>  // b.any
   81d00:	f140211f 	cmp	x8, #0x8, lsl #12
   81d04:	54009dc2 	b.cs	830bc <spin_92+0x271c>  // b.hs, b.nlast
   81d08:	eb0101ff 	cmp	x15, x1
   81d0c:	54000189 	b.ls	81d3c <spin_92+0x139c>  // b.plast
   81d10:	f9400328 	ldr	x8, [x25]
   81d14:	f82f7b48 	str	x8, [x26, x15, lsl #3]
   81d18:	f9408328 	ldr	x8, [x25, #256]
   81d1c:	f900032f 	str	x15, [x25]
   81d20:	91000508 	add	x8, x8, #0x1
   81d24:	f9008328 	str	x8, [x25, #256]
   81d28:	3954006f 	ldrb	w15, [x3, #1280]
   81d2c:	710005ff 	cmp	w15, #0x1
   81d30:	54007ec1 	b.ne	82d08 <spin_92+0x2368>  // b.any
   81d34:	f140211f 	cmp	x8, #0x8, lsl #12
   81d38:	54007e82 	b.cs	82d08 <spin_92+0x2368>  // b.hs, b.nlast
   81d3c:	92409f08 	and	x8, x24, #0xffffffffff
   81d40:	8b080f50 	add	x16, x26, x8, lsl #3
   81d44:	b7f800f8 	tbnz	x24, #63, 81d60 <spin_92+0x13c0>
   81d48:	f940020f 	ldr	x15, [x16]
   81d4c:	b9400a18 	ldr	w24, [x16, #8]
   81d50:	aa0803f4 	mov	x20, x8
   81d54:	eb01011f 	cmp	x8, x1
   81d58:	54000468 	b.hi	81de4 <spin_92+0x1444>  // b.pmore
   81d5c:	1400002d 	b	81e10 <spin_92+0x1470>
   81d60:	3d802fe4 	str	q4, [sp, #176]
   81d64:	aa0403ee 	mov	x14, x4
   81d68:	aa0203f6 	mov	x22, x2
   81d6c:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   81d70:	b940060f 	ldr	w15, [x16, #4]
   81d74:	b9400211 	ldr	w17, [x16]
   81d78:	92405e32 	and	x18, x17, #0xffffff
   81d7c:	f100065f 	cmp	x18, #0x1
   81d80:	540096e1 	b.ne	8305c <spin_92+0x26bc>  // b.any
   81d84:	aa0f822f 	orr	x15, x17, x15, lsl #32
   81d88:	88dffe1f 	ldar	wzr, [x16]
   81d8c:	f9400330 	ldr	x16, [x25]
   81d90:	d358fdf4 	lsr	x20, x15, #24
   81d94:	8b140f51 	add	x17, x26, x20, lsl #3
   81d98:	f940022f 	ldr	x15, [x17]
   81d9c:	b9400a38 	ldr	w24, [x17, #8]
   81da0:	f8287b50 	str	x16, [x26, x8, lsl #3]
   81da4:	f9408330 	ldr	x16, [x25, #256]
   81da8:	f9000328 	str	x8, [x25]
   81dac:	91000608 	add	x8, x16, #0x1
   81db0:	f9008328 	str	x8, [x25, #256]
   81db4:	39540070 	ldrb	w16, [x3, #1280]
   81db8:	7100061f 	cmp	w16, #0x1
   81dbc:	54009a41 	b.ne	83104 <spin_92+0x2764>  // b.any
   81dc0:	f140211f 	cmp	x8, #0x8, lsl #12
   81dc4:	54009a02 	b.cs	83104 <spin_92+0x2764>  // b.hs, b.nlast
   81dc8:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   81dcc:	aa1603e2 	mov	x2, x22
   81dd0:	3dc02fe4 	ldr	q4, [sp, #176]
   81dd4:	d2c10016 	mov	x22, #0x80000000000         	// #8796093022208
   81dd8:	aa0e03e4 	mov	x4, x14
   81ddc:	eb01029f 	cmp	x20, x1
   81de0:	54000189 	b.ls	81e10 <spin_92+0x1470>  // b.plast
   81de4:	f9400728 	ldr	x8, [x25, #8]
   81de8:	f8347b48 	str	x8, [x26, x20, lsl #3]
   81dec:	f9408728 	ldr	x8, [x25, #264]
   81df0:	f9000734 	str	x20, [x25, #8]
   81df4:	91000908 	add	x8, x8, #0x2
   81df8:	f9008728 	str	x8, [x25, #264]
   81dfc:	39540070 	ldrb	w16, [x3, #1280]
   81e00:	7100061f 	cmp	w16, #0x1
   81e04:	540079c1 	b.ne	82d3c <spin_92+0x239c>  // b.any
   81e08:	f140211f 	cmp	x8, #0x8, lsl #12
   81e0c:	54007982 	b.cs	82d3c <spin_92+0x239c>  // b.hs, b.nlast
   81e10:	f85d03b4 	ldur	x20, [x29, #-48]
   81e14:	92409d88 	and	x8, x12, #0xffffffffff
   81e18:	8b080f50 	add	x16, x26, x8, lsl #3
   81e1c:	b6fff32c 	tbz	x12, #63, 81c80 <spin_92+0x12e0>
   81e20:	b940060c 	ldr	w12, [x16, #4]
   81e24:	b9400212 	ldr	w18, [x16]
   81e28:	aa0f03f7 	mov	x23, x15
   81e2c:	aa1803ef 	mov	x15, x24
   81e30:	92405e51 	and	x17, x18, #0xffffff
   81e34:	f100063f 	cmp	x17, #0x1
   81e38:	54000041 	b.ne	81e40 <spin_92+0x14a0>  // b.any
   81e3c:	88dffe1f 	ldar	wzr, [x16]
   81e40:	aa0c824c 	orr	x12, x18, x12, lsl #32
   81e44:	aa0403f8 	mov	x24, x4
   81e48:	aa0203f6 	mov	x22, x2
   81e4c:	f100063f 	cmp	x17, #0x1
   81e50:	d358fd8c 	lsr	x12, x12, #24
   81e54:	8b0c0f52 	add	x18, x26, x12, lsl #3
   81e58:	ad401e45 	ldp	q5, q7, [x18]
   81e5c:	3dc00a46 	ldr	q6, [x18, #32]
   81e60:	54005f21 	b.ne	82a44 <spin_92+0x20a4>  // b.any
   81e64:	f940032e 	ldr	x14, [x25]
   81e68:	f900020e 	str	x14, [x16]
   81e6c:	f940832e 	ldr	x14, [x25, #256]
   81e70:	f9000328 	str	x8, [x25]
   81e74:	910005c8 	add	x8, x14, #0x1
   81e78:	f9008328 	str	x8, [x25, #256]
   81e7c:	3954006e 	ldrb	w14, [x3, #1280]
   81e80:	710005df 	cmp	w14, #0x1
   81e84:	54006b01 	b.ne	82be4 <spin_92+0x2244>  // b.any
   81e88:	f140211f 	cmp	x8, #0x8, lsl #12
   81e8c:	54006ac2 	b.cs	82be4 <spin_92+0x2244>  // b.hs, b.nlast
   81e90:	aa1803e4 	mov	x4, x24
   81e94:	aa0f03f8 	mov	x24, x15
   81e98:	aa1703ef 	mov	x15, x23
   81e9c:	d2c1c017 	mov	x23, #0xe0000000000         	// #15393162788864
   81ea0:	aa1603e2 	mov	x2, x22
   81ea4:	d2c10016 	mov	x22, #0x80000000000         	// #8796093022208
   81ea8:	f2e02017 	movk	x23, #0x100, lsl #48
   81eac:	eb01019f 	cmp	x12, x1
   81eb0:	54000189 	b.ls	81ee0 <spin_92+0x1540>  // b.plast
   81eb4:	f9400f28 	ldr	x8, [x25, #24]
   81eb8:	f82c7b48 	str	x8, [x26, x12, lsl #3]
   81ebc:	f9408f28 	ldr	x8, [x25, #280]
   81ec0:	f9000f2c 	str	x12, [x25, #24]
   81ec4:	91002108 	add	x8, x8, #0x8
   81ec8:	f9008f28 	str	x8, [x25, #280]
   81ecc:	3954006e 	ldrb	w14, [x3, #1280]
   81ed0:	710005df 	cmp	w14, #0x1
   81ed4:	54004ca1 	b.ne	82868 <spin_92+0x1ec8>  // b.any
   81ed8:	f140211f 	cmp	x8, #0x8, lsl #12
   81edc:	54004c62 	b.cs	82868 <spin_92+0x1ec8>  // b.hs, b.nlast
   81ee0:	b4000154 	cbz	x20, 81f08 <spin_92+0x1568>
   81ee4:	92409d68 	and	x8, x11, #0xffffffffff
   81ee8:	8b080f50 	add	x16, x26, x8, lsl #3
   81eec:	b7f807eb 	tbnz	x11, #63, 81fe8 <spin_92+0x1648>
   81ef0:	ad404602 	ldp	q2, q17, [x16]
   81ef4:	aa0803ec 	mov	x12, x8
   81ef8:	b940220e 	ldr	w14, [x16, #32]
   81efc:	eb01011f 	cmp	x8, x1
   81f00:	54000a88 	b.hi	82050 <spin_92+0x16b0>  // b.pmore
   81f04:	1400005e 	b	8207c <spin_92+0x16dc>
   81f08:	6f00e410 	movi	v16.2d, #0x0
   81f0c:	6f00e411 	movi	v17.2d, #0x0
   81f10:	aa1f03ee 	mov	x14, xzr
   81f14:	f9400b2c 	ldr	x12, [x25, #16]
   81f18:	b5000bcc 	cbnz	x12, 82090 <spin_92+0x16f0>
   81f1c:	aa1a03e0 	mov	x0, x26
   81f20:	aa1903e1 	mov	x1, x25
   81f24:	aa0203eb 	mov	x11, x2
   81f28:	52800042 	mov	w2, #0x2                   	// #2
   81f2c:	aa0403ec 	mov	x12, x4
   81f30:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   81f34:	3d802fe4 	str	q4, [sp, #176]
   81f38:	3c9d03a5 	stur	q5, [x29, #-48]
   81f3c:	3d802be6 	str	q6, [sp, #160]
   81f40:	3d8023e7 	str	q7, [sp, #128]
   81f44:	ad0243f1 	stp	q17, q16, [sp, #64]
   81f48:	97fe0bb2 	bl	4e10 <heap_alloc_miss>
   81f4c:	ad4243f1 	ldp	q17, q16, [sp, #64]
   81f50:	52909fe1 	mov	w1, #0x84ff                	// #34047
   81f54:	ad4513e6 	ldp	q6, q4, [sp, #160]
   81f58:	aa0c03e4 	mov	x4, x12
   81f5c:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   81f60:	aa0b03e2 	mov	x2, x11
   81f64:	3dc023e7 	ldr	q7, [sp, #128]
   81f68:	3cdd03a5 	ldur	q5, [x29, #-48]
   81f6c:	f0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   81f70:	72a06201 	movk	w1, #0x310, lsl #16
   81f74:	aa0003ec 	mov	x12, x0
   81f78:	d378fda8 	lsr	x8, x13, #56
   81f7c:	f100091f 	cmp	x8, #0x2
   81f80:	54000981 	b.ne	820b0 <spin_92+0x1710>  // b.any
   81f84:	aa1a03e0 	mov	x0, x26
   81f88:	aa1903e1 	mov	x1, x25
   81f8c:	aa0203eb 	mov	x11, x2
   81f90:	aa0d03e2 	mov	x2, x13
   81f94:	52800023 	mov	w3, #0x1                   	// #1
   81f98:	aa0403ed 	mov	x13, x4
   81f9c:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   81fa0:	3d802fe4 	str	q4, [sp, #176]
   81fa4:	3c9d03a5 	stur	q5, [x29, #-48]
   81fa8:	3d802be6 	str	q6, [sp, #160]
   81fac:	3d8023e7 	str	q7, [sp, #128]
   81fb0:	ad0243f1 	stp	q17, q16, [sp, #64]
   81fb4:	97fe0c8a 	bl	51dc <rfc_wrap>
   81fb8:	ad4243f1 	ldp	q17, q16, [sp, #64]
   81fbc:	52909fe1 	mov	w1, #0x84ff                	// #34047
   81fc0:	ad4513e6 	ldp	q6, q4, [sp, #160]
   81fc4:	aa0d03e4 	mov	x4, x13
   81fc8:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   81fcc:	aa0b03e2 	mov	x2, x11
   81fd0:	3dc023e7 	ldr	q7, [sp, #128]
   81fd4:	3cdd03a5 	ldur	q5, [x29, #-48]
   81fd8:	f0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   81fdc:	72a06201 	movk	w1, #0x310, lsl #16
   81fe0:	aa0003ed 	mov	x13, x0
   81fe4:	14000033 	b	820b0 <spin_92+0x1710>
   81fe8:	b940060c 	ldr	w12, [x16, #4]
   81fec:	b940020e 	ldr	w14, [x16]
   81ff0:	92405dd1 	and	x17, x14, #0xffffff
   81ff4:	f100063f 	cmp	x17, #0x1
   81ff8:	54000041 	b.ne	82000 <spin_92+0x1660>  // b.any
   81ffc:	88dffe1f 	ldar	wzr, [x16]
   82000:	aa0c81cc 	orr	x12, x14, x12, lsl #32
   82004:	f100063f 	cmp	x17, #0x1
   82008:	d358fd8c 	lsr	x12, x12, #24
   8200c:	8b0c0f4e 	add	x14, x26, x12, lsl #3
   82010:	ad4045c2 	ldp	q2, q17, [x14]
   82014:	b94021ce 	ldr	w14, [x14, #32]
   82018:	540073c1 	b.ne	82e90 <spin_92+0x24f0>  // b.any
   8201c:	f940032b 	ldr	x11, [x25]
   82020:	f900020b 	str	x11, [x16]
   82024:	f940832b 	ldr	x11, [x25, #256]
   82028:	f9000328 	str	x8, [x25]
   8202c:	91000568 	add	x8, x11, #0x1
   82030:	f9008328 	str	x8, [x25, #256]
   82034:	3954006b 	ldrb	w11, [x3, #1280]
   82038:	7100057f 	cmp	w11, #0x1
   8203c:	54007a61 	b.ne	82f88 <spin_92+0x25e8>  // b.any
   82040:	f140211f 	cmp	x8, #0x8, lsl #12
   82044:	54007a22 	b.cs	82f88 <spin_92+0x25e8>  // b.hs, b.nlast
   82048:	eb01019f 	cmp	x12, x1
   8204c:	54000189 	b.ls	8207c <spin_92+0x16dc>  // b.plast
   82050:	f9400f28 	ldr	x8, [x25, #24]
   82054:	f82c7b48 	str	x8, [x26, x12, lsl #3]
   82058:	f9408f28 	ldr	x8, [x25, #280]
   8205c:	f9000f2c 	str	x12, [x25, #24]
   82060:	91002108 	add	x8, x8, #0x8
   82064:	f9008f28 	str	x8, [x25, #280]
   82068:	3954006b 	ldrb	w11, [x3, #1280]
   8206c:	7100057f 	cmp	w11, #0x1
   82070:	54006281 	b.ne	82cc0 <spin_92+0x2320>  // b.any
   82074:	f140211f 	cmp	x8, #0x8, lsl #12
   82078:	54006242 	b.cs	82cc0 <spin_92+0x2320>  // b.hs, b.nlast
   8207c:	6f00e5e0 	movi	v0.2d, #0xffffffff
   82080:	4e201c50 	and	v16.16b, v2.16b, v0.16b
   82084:	4e201e31 	and	v17.16b, v17.16b, v0.16b
   82088:	f9400b2c 	ldr	x12, [x25, #16]
   8208c:	b4fff48c 	cbz	x12, 81f1c <spin_92+0x157c>
   82090:	f86c7b48 	ldr	x8, [x26, x12, lsl #3]
   82094:	f9408b2b 	ldr	x11, [x25, #272]
   82098:	f9000b28 	str	x8, [x25, #16]
   8209c:	d1001168 	sub	x8, x11, #0x4
   820a0:	f9008b28 	str	x8, [x25, #272]
   820a4:	d378fda8 	lsr	x8, x13, #56
   820a8:	f100091f 	cmp	x8, #0x2
   820ac:	54fff6c0 	b.eq	81f84 <spin_92+0x15e4>  // b.none
   820b0:	8b0c0f48 	add	x8, x26, x12, lsl #3
   820b4:	a900090d 	stp	x13, x2, [x8]
   820b8:	f9000904 	str	x4, [x8, #16]
   820bc:	f9400f2d 	ldr	x13, [x25, #24]
   820c0:	b4001f2d 	cbz	x13, 824a4 <spin_92+0x1b04>
   820c4:	f86d7b48 	ldr	x8, [x26, x13, lsl #3]
   820c8:	f9408f2b 	ldr	x11, [x25, #280]
   820cc:	f9000f28 	str	x8, [x25, #24]
   820d0:	d1002168 	sub	x8, x11, #0x8
   820d4:	f9008f28 	str	x8, [x25, #280]
   820d8:	6f00e5e2 	movi	v2.2d, #0xffffffff
   820dc:	8b0d0f48 	add	x8, x26, x13, lsl #3
   820e0:	4e221c20 	and	v0.16b, v1.16b, v2.16b
   820e4:	4e221c81 	and	v1.16b, v4.16b, v2.16b
   820e8:	4e221c62 	and	v2.16b, v3.16b, v2.16b
   820ec:	ad000500 	stp	q0, q1, [x8]
   820f0:	3d800902 	str	q2, [x8, #32]
   820f4:	f940072b 	ldr	x11, [x25, #8]
   820f8:	b4001feb 	cbz	x11, 824f4 <spin_92+0x1b54>
   820fc:	f86b7b48 	ldr	x8, [x26, x11, lsl #3]
   82100:	f9408730 	ldr	x16, [x25, #264]
   82104:	f9000728 	str	x8, [x25, #8]
   82108:	d1000a08 	sub	x8, x16, #0x2
   8210c:	f9008728 	str	x8, [x25, #264]
   82110:	d2c40008 	mov	x8, #0x200000000000        	// #35184372088832
   82114:	f2e04008 	movk	x8, #0x200, lsl #48
   82118:	aa080182 	orr	x2, x12, x8
   8211c:	d378fc48 	lsr	x8, x2, #56
   82120:	f100091f 	cmp	x8, #0x2
   82124:	54002140 	b.eq	8254c <spin_92+0x1bac>  // b.none
   82128:	d2c42008 	mov	x8, #0x210000000000        	// #36283883716608
   8212c:	8b0b0f4c 	add	x12, x26, x11, lsl #3
   82130:	f2e04008 	movk	x8, #0x200, lsl #48
   82134:	aa0801a8 	orr	x8, x13, x8
   82138:	f9000182 	str	x2, [x12]
   8213c:	d378fd0d 	lsr	x13, x8, #56
   82140:	f10009bf 	cmp	x13, #0x2
   82144:	54002260 	b.eq	82590 <spin_92+0x1bf0>  // b.none
   82148:	eb16039f 	cmp	x28, x22
   8214c:	f9000588 	str	x8, [x12, #8]
   82150:	54002461 	b.ne	825dc <spin_92+0x1c3c>  // b.any
   82154:	aa1f03fc 	mov	x28, xzr
   82158:	aa1f03f8 	mov	x24, xzr
   8215c:	f9400f2d 	ldr	x13, [x25, #24]
   82160:	b400262d 	cbz	x13, 82624 <spin_92+0x1c84>
   82164:	f86d7b48 	ldr	x8, [x26, x13, lsl #3]
   82168:	f9408f2c 	ldr	x12, [x25, #280]
   8216c:	f9000f28 	str	x8, [x25, #24]
   82170:	d1002188 	sub	x8, x12, #0x8
   82174:	f9008f28 	str	x8, [x25, #280]
   82178:	6f00e5e2 	movi	v2.2d, #0xffffffff
   8217c:	8b0d0f48 	add	x8, x26, x13, lsl #3
   82180:	4e221ca0 	and	v0.16b, v5.16b, v2.16b
   82184:	4e221ce1 	and	v1.16b, v7.16b, v2.16b
   82188:	4e221cc2 	and	v2.16b, v6.16b, v2.16b
   8218c:	ad000500 	stp	q0, q1, [x8]
   82190:	3d800902 	str	q2, [x8, #32]
   82194:	b4000214 	cbz	x20, 821d4 <spin_92+0x1834>
   82198:	f9400f20 	ldr	x0, [x25, #24]
   8219c:	b4002e60 	cbz	x0, 82768 <spin_92+0x1dc8>
   821a0:	f8607b48 	ldr	x8, [x26, x0, lsl #3]
   821a4:	f9408f2c 	ldr	x12, [x25, #280]
   821a8:	f9000f28 	str	x8, [x25, #24]
   821ac:	d1002188 	sub	x8, x12, #0x8
   821b0:	f9008f28 	str	x8, [x25, #280]
   821b4:	8b000f48 	add	x8, x26, x0, lsl #3
   821b8:	52800034 	mov	w20, #0x1                   	// #1
   821bc:	ad004510 	stp	q16, q17, [x8]
   821c0:	f900110e 	str	x14, [x8, #32]
   821c4:	d2c52008 	mov	x8, #0x290000000000        	// #45079976738816
   821c8:	f2e04008 	movk	x8, #0x200, lsl #48
   821cc:	aa08000e 	orr	x14, x0, x8
   821d0:	14000002 	b	821d8 <spin_92+0x1838>
   821d4:	aa1f03ee 	mov	x14, xzr
   821d8:	a977bfac 	ldp	x12, x15, [x29, #-136]
   821dc:	d2c46008 	mov	x8, #0x230000000000        	// #38482906972160
   821e0:	f2e02008 	movk	x8, #0x100, lsl #48
   821e4:	b3407d88 	bfxil	x8, x12, #0, #32
   821e8:	f9400f2c 	ldr	x12, [x25, #24]
   821ec:	f10001ff 	cmp	x15, #0x0
   821f0:	1a9f07f6 	cset	w22, ne	// ne = any
   821f4:	9a9f110f 	csel	x15, x8, xzr, ne	// ne = any
   821f8:	b400238c 	cbz	x12, 82668 <spin_92+0x1cc8>
   821fc:	f86c7b48 	ldr	x8, [x26, x12, lsl #3]
   82200:	f9408f30 	ldr	x16, [x25, #280]
   82204:	f9000f28 	str	x8, [x25, #24]
   82208:	d1002208 	sub	x8, x16, #0x8
   8220c:	f9008f28 	str	x8, [x25, #280]
   82210:	d2c42008 	mov	x8, #0x210000000000        	// #36283883716608
   82214:	910006b0 	add	x16, x21, #0x1
   82218:	f2e04008 	movk	x8, #0x200, lsl #48
   8221c:	aa0801a2 	orr	x2, x13, x8
   82220:	8b0c0f4d 	add	x13, x26, x12, lsl #3
   82224:	d378fc48 	lsr	x8, x2, #56
   82228:	f100091f 	cmp	x8, #0x2
   8222c:	f94037e8 	ldr	x8, [sp, #104]
   82230:	a90041a8 	stp	x8, x16, [x13]
   82234:	540022c0 	b.eq	8268c <spin_92+0x1cec>  // b.none
   82238:	d378fdc8 	lsr	x8, x14, #56
   8223c:	a90151a2 	stp	x2, x20, [x13, #16]
   82240:	f100091f 	cmp	x8, #0x2
   82244:	540023a0 	b.eq	826b8 <spin_92+0x1d18>  // b.none
   82248:	d2c3e008 	mov	x8, #0x1f0000000000        	// #34084860461056
   8224c:	a90259ae 	stp	x14, x22, [x13, #32]
   82250:	f85f03ae 	ldur	x14, [x29, #-16]
   82254:	f2e04008 	movk	x8, #0x200, lsl #48
   82258:	f90019af 	str	x15, [x13, #48]
   8225c:	aa080168 	orr	x8, x11, x8
   82260:	eb0e011f 	cmp	x8, x14
   82264:	54000320 	b.eq	822c8 <spin_92+0x1928>  // b.none
   82268:	eb09011f 	cmp	x8, x9
   8226c:	540002e0 	b.eq	822c8 <spin_92+0x1928>  // b.none
   82270:	f85c03ad 	ldur	x13, [x29, #-64]
   82274:	eb0d011f 	cmp	x8, x13
   82278:	54000280 	b.eq	822c8 <spin_92+0x1928>  // b.none
   8227c:	f85c83ad 	ldur	x13, [x29, #-56]
   82280:	eb0d011f 	cmp	x8, x13
   82284:	54000220 	b.eq	822c8 <spin_92+0x1928>  // b.none
   82288:	f85e03ad 	ldur	x13, [x29, #-32]
   8228c:	eb0d011f 	cmp	x8, x13
   82290:	540001c0 	b.eq	822c8 <spin_92+0x1928>  // b.none
   82294:	f85e83ad 	ldur	x13, [x29, #-24]
   82298:	eb0d011f 	cmp	x8, x13
   8229c:	54000160 	b.eq	822c8 <spin_92+0x1928>  // b.none
   822a0:	eb1b011f 	cmp	x8, x27
   822a4:	54000120 	b.eq	822c8 <spin_92+0x1928>  // b.none
   822a8:	eb0a011f 	cmp	x8, x10
   822ac:	540000e0 	b.eq	822c8 <spin_92+0x1928>  // b.none
   822b0:	f85b83ad 	ldur	x13, [x29, #-72]
   822b4:	eb0d011f 	cmp	x8, x13
   822b8:	54000080 	b.eq	822c8 <spin_92+0x1928>  // b.none
   822bc:	b6f8006b 	tbz	x11, #63, 822c8 <spin_92+0x1928>
   822c0:	92409d6b 	and	x11, x11, #0xffffffffff
   822c4:	f86b7b5f 	ldr	xzr, [x26, x11, lsl #3]
   822c8:	b6f80378 	tbz	x24, #63, 82334 <spin_92+0x1994>
   822cc:	f85f03ab 	ldur	x11, [x29, #-16]
   822d0:	eb0b031f 	cmp	x24, x11
   822d4:	54000300 	b.eq	82334 <spin_92+0x1994>  // b.none
   822d8:	eb09031f 	cmp	x24, x9
   822dc:	540002c0 	b.eq	82334 <spin_92+0x1994>  // b.none
   822e0:	f85c03ab 	ldur	x11, [x29, #-64]
   822e4:	eb0b031f 	cmp	x24, x11
   822e8:	54000260 	b.eq	82334 <spin_92+0x1994>  // b.none
   822ec:	f85c83ab 	ldur	x11, [x29, #-56]
   822f0:	eb0b031f 	cmp	x24, x11
   822f4:	54000200 	b.eq	82334 <spin_92+0x1994>  // b.none
   822f8:	f85e03ab 	ldur	x11, [x29, #-32]
   822fc:	eb0b031f 	cmp	x24, x11
   82300:	540001a0 	b.eq	82334 <spin_92+0x1994>  // b.none
   82304:	f85e83ab 	ldur	x11, [x29, #-24]
   82308:	eb0b031f 	cmp	x24, x11
   8230c:	54000140 	b.eq	82334 <spin_92+0x1994>  // b.none
   82310:	eb1b031f 	cmp	x24, x27
   82314:	54000100 	b.eq	82334 <spin_92+0x1994>  // b.none
   82318:	eb0a031f 	cmp	x24, x10
   8231c:	540000c0 	b.eq	82334 <spin_92+0x1994>  // b.none
   82320:	f85b83ab 	ldur	x11, [x29, #-72]
   82324:	eb0b031f 	cmp	x24, x11
   82328:	54000060 	b.eq	82334 <spin_92+0x1994>  // b.none
   8232c:	92409f0b 	and	x11, x24, #0xffffffffff
   82330:	f86b7b5f 	ldr	xzr, [x26, x11, lsl #3]
   82334:	d2ccc00b 	mov	x11, #0x660000000000        	// #112150186033152
   82338:	f2e0400b 	movk	x11, #0x200, lsl #48
   8233c:	aa0b0196 	orr	x22, x12, x11
   82340:	b6f8036c 	tbz	x12, #63, 823ac <spin_92+0x1a0c>
   82344:	f85f03ab 	ldur	x11, [x29, #-16]
   82348:	eb0b02df 	cmp	x22, x11
   8234c:	54000300 	b.eq	823ac <spin_92+0x1a0c>  // b.none
   82350:	eb0902df 	cmp	x22, x9
   82354:	540002c0 	b.eq	823ac <spin_92+0x1a0c>  // b.none
   82358:	f85c03a9 	ldur	x9, [x29, #-64]
   8235c:	eb0902df 	cmp	x22, x9
   82360:	54000260 	b.eq	823ac <spin_92+0x1a0c>  // b.none
   82364:	f85c83a9 	ldur	x9, [x29, #-56]
   82368:	eb0902df 	cmp	x22, x9
   8236c:	54000200 	b.eq	823ac <spin_92+0x1a0c>  // b.none
   82370:	f85e03a9 	ldur	x9, [x29, #-32]
   82374:	eb0902df 	cmp	x22, x9
   82378:	540001a0 	b.eq	823ac <spin_92+0x1a0c>  // b.none
   8237c:	f85e83a9 	ldur	x9, [x29, #-24]
   82380:	eb0902df 	cmp	x22, x9
   82384:	54000140 	b.eq	823ac <spin_92+0x1a0c>  // b.none
   82388:	eb1b02df 	cmp	x22, x27
   8238c:	54000100 	b.eq	823ac <spin_92+0x1a0c>  // b.none
   82390:	eb0a02df 	cmp	x22, x10
   82394:	540000c0 	b.eq	823ac <spin_92+0x1a0c>  // b.none
   82398:	f85b83a9 	ldur	x9, [x29, #-72]
   8239c:	eb0902df 	cmp	x22, x9
   823a0:	54000060 	b.eq	823ac <spin_92+0x1a0c>  // b.none
   823a4:	92409d89 	and	x9, x12, #0xffffffffff
   823a8:	f8697b5f 	ldr	xzr, [x26, x9, lsl #3]
   823ac:	f9400662 	ldr	x2, [x19, #8]
   823b0:	91000434 	add	x20, x1, #0x1
   823b4:	5280002a 	mov	w10, #0x1                   	// #1
   823b8:	f900026a 	str	x10, [x19]
   823bc:	b858c3aa 	ldur	w10, [x29, #-116]
   823c0:	92787c49 	and	x9, x2, #0xffffffff00
   823c4:	eb14013f 	cmp	x9, x20
   823c8:	f85a03a9 	ldur	x9, [x29, #-96]
   823cc:	f82a5928 	str	x8, [x9, w10, uxtw #3]
   823d0:	54000163 	b.cc	823fc <spin_92+0x1a5c>  // b.lo, b.ul, b.last
   823d4:	b100045f 	cmn	x2, #0x1
   823d8:	54000120 	b.eq	823fc <spin_92+0x1a5c>  // b.none
   823dc:	92471448 	and	x8, x2, #0x7e00000000000000
   823e0:	b40000e8 	cbz	x8, 823fc <spin_92+0x1a5c>
   823e4:	aa1a03e0 	mov	x0, x26
   823e8:	aa1903e1 	mov	x1, x25
   823ec:	97fe0eea 	bl	5f94 <term_drop>
   823f0:	52909fe1 	mov	w1, #0x84ff                	// #34047
   823f4:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   823f8:	72a06201 	movk	w1, #0x310, lsl #16
   823fc:	f85683a9 	ldur	x9, [x29, #-152]
   82400:	f9406bf3 	ldr	x19, [sp, #208]
   82404:	f9400522 	ldr	x2, [x9, #8]
   82408:	f900013c 	str	x28, [x9]
   8240c:	b85643a9 	ldur	w9, [x29, #-156]
   82410:	92787c48 	and	x8, x2, #0xffffffff00
   82414:	eb14011f 	cmp	x8, x20
   82418:	f85703a8 	ldur	x8, [x29, #-144]
   8241c:	f8295918 	str	x24, [x8, w9, uxtw #3]
   82420:	54000163 	b.cc	8244c <spin_92+0x1aac>  // b.lo, b.ul, b.last
   82424:	b100045f 	cmn	x2, #0x1
   82428:	54000120 	b.eq	8244c <spin_92+0x1aac>  // b.none
   8242c:	92471448 	and	x8, x2, #0x7e00000000000000
   82430:	b40000e8 	cbz	x8, 8244c <spin_92+0x1aac>
   82434:	aa1a03e0 	mov	x0, x26
   82438:	aa1903e1 	mov	x1, x25
   8243c:	97fe0ed6 	bl	5f94 <term_drop>
   82440:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82444:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82448:	72a06201 	movk	w1, #0x310, lsl #16
   8244c:	f9400729 	ldr	x9, [x25, #8]
   82450:	f9406ff8 	ldr	x24, [sp, #216]
   82454:	b4001469 	cbz	x9, 826e0 <spin_92+0x1d40>
   82458:	f8697b48 	ldr	x8, [x26, x9, lsl #3]
   8245c:	f940872a 	ldr	x10, [x25, #264]
   82460:	f9000728 	str	x8, [x25, #8]
   82464:	d1000948 	sub	x8, x10, #0x2
   82468:	f9008728 	str	x8, [x25, #264]
   8246c:	d378fec8 	lsr	x8, x22, #56
   82470:	f100091f 	cmp	x8, #0x2
   82474:	540014c0 	b.eq	8270c <spin_92+0x1d6c>  // b.none
   82478:	d378ff68 	lsr	x8, x27, #56
   8247c:	8b090f4a 	add	x10, x26, x9, lsl #3
   82480:	f100091f 	cmp	x8, #0x2
   82484:	f9000156 	str	x22, [x10]
   82488:	540015c0 	b.eq	82740 <spin_92+0x1da0>  // b.none
   8248c:	d2c1e008 	mov	x8, #0xf0000000000         	// #16492674416640
   82490:	f9403ff6 	ldr	x22, [sp, #120]
   82494:	f900055b 	str	x27, [x10, #8]
   82498:	f2e04008 	movk	x8, #0x200, lsl #48
   8249c:	aa08013b 	orr	x27, x9, x8
   824a0:	17fff9a6 	b	80b38 <spin_92+0x198>
   824a4:	aa1a03e0 	mov	x0, x26
   824a8:	aa1903e1 	mov	x1, x25
   824ac:	52800062 	mov	w2, #0x3                   	// #3
   824b0:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   824b4:	3d802fe4 	str	q4, [sp, #176]
   824b8:	3c9d03a5 	stur	q5, [x29, #-48]
   824bc:	3d802be6 	str	q6, [sp, #160]
   824c0:	3d8023e7 	str	q7, [sp, #128]
   824c4:	ad0243f1 	stp	q17, q16, [sp, #64]
   824c8:	97fe0a52 	bl	4e10 <heap_alloc_miss>
   824cc:	ad4243f1 	ldp	q17, q16, [sp, #64]
   824d0:	52909fe1 	mov	w1, #0x84ff                	// #34047
   824d4:	ad4513e6 	ldp	q6, q4, [sp, #160]
   824d8:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   824dc:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   824e0:	72a06201 	movk	w1, #0x310, lsl #16
   824e4:	3dc023e7 	ldr	q7, [sp, #128]
   824e8:	3cdd03a5 	ldur	q5, [x29, #-48]
   824ec:	aa0003ed 	mov	x13, x0
   824f0:	17fffefa 	b	820d8 <spin_92+0x1738>
   824f4:	aa1a03e0 	mov	x0, x26
   824f8:	aa1903e1 	mov	x1, x25
   824fc:	52800022 	mov	w2, #0x1                   	// #1
   82500:	3c9d03a5 	stur	q5, [x29, #-48]
   82504:	3d802be6 	str	q6, [sp, #160]
   82508:	3d8023e7 	str	q7, [sp, #128]
   8250c:	ad0243f1 	stp	q17, q16, [sp, #64]
   82510:	97fe0a40 	bl	4e10 <heap_alloc_miss>
   82514:	ad4243f1 	ldp	q17, q16, [sp, #64]
   82518:	52909fe1 	mov	w1, #0x84ff                	// #34047
   8251c:	3dc023e7 	ldr	q7, [sp, #128]
   82520:	3dc02be6 	ldr	q6, [sp, #160]
   82524:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82528:	3cdd03a5 	ldur	q5, [x29, #-48]
   8252c:	72a06201 	movk	w1, #0x310, lsl #16
   82530:	aa0003eb 	mov	x11, x0
   82534:	d2c40008 	mov	x8, #0x200000000000        	// #35184372088832
   82538:	f2e04008 	movk	x8, #0x200, lsl #48
   8253c:	aa080182 	orr	x2, x12, x8
   82540:	d378fc48 	lsr	x8, x2, #56
   82544:	f100091f 	cmp	x8, #0x2
   82548:	54ffdf01 	b.ne	82128 <spin_92+0x1788>  // b.any
   8254c:	aa1a03e0 	mov	x0, x26
   82550:	aa1903e1 	mov	x1, x25
   82554:	52800023 	mov	w3, #0x1                   	// #1
   82558:	3c9d03a5 	stur	q5, [x29, #-48]
   8255c:	3d802be6 	str	q6, [sp, #160]
   82560:	3d8023e7 	str	q7, [sp, #128]
   82564:	ad0243f1 	stp	q17, q16, [sp, #64]
   82568:	97fe0b1d 	bl	51dc <rfc_wrap>
   8256c:	ad4243f1 	ldp	q17, q16, [sp, #64]
   82570:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82574:	3dc023e7 	ldr	q7, [sp, #128]
   82578:	3dc02be6 	ldr	q6, [sp, #160]
   8257c:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82580:	3cdd03a5 	ldur	q5, [x29, #-48]
   82584:	72a06201 	movk	w1, #0x310, lsl #16
   82588:	aa0003e2 	mov	x2, x0
   8258c:	17fffee7 	b	82128 <spin_92+0x1788>
   82590:	aa1a03e0 	mov	x0, x26
   82594:	aa1903e1 	mov	x1, x25
   82598:	aa0803e2 	mov	x2, x8
   8259c:	52800023 	mov	w3, #0x1                   	// #1
   825a0:	3c9d03a5 	stur	q5, [x29, #-48]
   825a4:	3d802be6 	str	q6, [sp, #160]
   825a8:	3d8023e7 	str	q7, [sp, #128]
   825ac:	ad0243f1 	stp	q17, q16, [sp, #64]
   825b0:	97fe0b0b 	bl	51dc <rfc_wrap>
   825b4:	ad4243f1 	ldp	q17, q16, [sp, #64]
   825b8:	52909fe1 	mov	w1, #0x84ff                	// #34047
   825bc:	3dc023e7 	ldr	q7, [sp, #128]
   825c0:	3dc02be6 	ldr	q6, [sp, #160]
   825c4:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   825c8:	3cdd03a5 	ldur	q5, [x29, #-48]
   825cc:	72a06201 	movk	w1, #0x310, lsl #16
   825d0:	eb16039f 	cmp	x28, x22
   825d4:	f9000580 	str	x0, [x12, #8]
   825d8:	54ffdbe0 	b.eq	82154 <spin_92+0x17b4>  // b.none
   825dc:	f940072c 	ldr	x12, [x25, #8]
   825e0:	b4000d8c 	cbz	x12, 82790 <spin_92+0x1df0>
   825e4:	f86c7b48 	ldr	x8, [x26, x12, lsl #3]
   825e8:	f940872d 	ldr	x13, [x25, #264]
   825ec:	f9000728 	str	x8, [x25, #8]
   825f0:	d10009a8 	sub	x8, x13, #0x2
   825f4:	f9008728 	str	x8, [x25, #264]
   825f8:	d378fde8 	lsr	x8, x15, #56
   825fc:	f100091f 	cmp	x8, #0x2
   82600:	54000ee0 	b.eq	827dc <spin_92+0x1e3c>  // b.none
   82604:	8b0c0f48 	add	x8, x26, x12, lsl #3
   82608:	5280003c 	mov	w28, #0x1                   	// #1
   8260c:	a900610f 	stp	x15, x24, [x8]
   82610:	d2c44008 	mov	x8, #0x220000000000        	// #37383395344384
   82614:	f2e04008 	movk	x8, #0x200, lsl #48
   82618:	aa080198 	orr	x24, x12, x8
   8261c:	f9400f2d 	ldr	x13, [x25, #24]
   82620:	b5ffda2d 	cbnz	x13, 82164 <spin_92+0x17c4>
   82624:	aa1a03e0 	mov	x0, x26
   82628:	aa1903e1 	mov	x1, x25
   8262c:	52800062 	mov	w2, #0x3                   	// #3
   82630:	3c9d03a5 	stur	q5, [x29, #-48]
   82634:	3d802be6 	str	q6, [sp, #160]
   82638:	3d8023e7 	str	q7, [sp, #128]
   8263c:	ad0243f1 	stp	q17, q16, [sp, #64]
   82640:	97fe09f4 	bl	4e10 <heap_alloc_miss>
   82644:	ad4243f1 	ldp	q17, q16, [sp, #64]
   82648:	52909fe1 	mov	w1, #0x84ff                	// #34047
   8264c:	3dc023e7 	ldr	q7, [sp, #128]
   82650:	3dc02be6 	ldr	q6, [sp, #160]
   82654:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82658:	3cdd03a5 	ldur	q5, [x29, #-48]
   8265c:	72a06201 	movk	w1, #0x310, lsl #16
   82660:	aa0003ed 	mov	x13, x0
   82664:	17fffec5 	b	82178 <spin_92+0x17d8>
   82668:	aa1a03e0 	mov	x0, x26
   8266c:	aa1903e1 	mov	x1, x25
   82670:	52800062 	mov	w2, #0x3                   	// #3
   82674:	97fe09e7 	bl	4e10 <heap_alloc_miss>
   82678:	52909fe1 	mov	w1, #0x84ff                	// #34047
   8267c:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82680:	aa0003ec 	mov	x12, x0
   82684:	72a06201 	movk	w1, #0x310, lsl #16
   82688:	17fffee2 	b	82210 <spin_92+0x1870>
   8268c:	aa1a03e0 	mov	x0, x26
   82690:	aa1903e1 	mov	x1, x25
   82694:	52800023 	mov	w3, #0x1                   	// #1
   82698:	97fe0ad1 	bl	51dc <rfc_wrap>
   8269c:	52909fe1 	mov	w1, #0x84ff                	// #34047
   826a0:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   826a4:	72a06201 	movk	w1, #0x310, lsl #16
   826a8:	d378fdc8 	lsr	x8, x14, #56
   826ac:	a90151a0 	stp	x0, x20, [x13, #16]
   826b0:	f100091f 	cmp	x8, #0x2
   826b4:	54ffdca1 	b.ne	82248 <spin_92+0x18a8>  // b.any
   826b8:	aa1a03e0 	mov	x0, x26
   826bc:	aa1903e1 	mov	x1, x25
   826c0:	aa0e03e2 	mov	x2, x14
   826c4:	52800023 	mov	w3, #0x1                   	// #1
   826c8:	97fe0ac5 	bl	51dc <rfc_wrap>
   826cc:	52909fe1 	mov	w1, #0x84ff                	// #34047
   826d0:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   826d4:	aa0003ee 	mov	x14, x0
   826d8:	72a06201 	movk	w1, #0x310, lsl #16
   826dc:	17fffedb 	b	82248 <spin_92+0x18a8>
   826e0:	aa1a03e0 	mov	x0, x26
   826e4:	aa1903e1 	mov	x1, x25
   826e8:	52800022 	mov	w2, #0x1                   	// #1
   826ec:	97fe09c9 	bl	4e10 <heap_alloc_miss>
   826f0:	52909fe1 	mov	w1, #0x84ff                	// #34047
   826f4:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   826f8:	aa0003e9 	mov	x9, x0
   826fc:	72a06201 	movk	w1, #0x310, lsl #16
   82700:	d378fec8 	lsr	x8, x22, #56
   82704:	f100091f 	cmp	x8, #0x2
   82708:	54ffeb81 	b.ne	82478 <spin_92+0x1ad8>  // b.any
   8270c:	aa1a03e0 	mov	x0, x26
   82710:	aa1903e1 	mov	x1, x25
   82714:	aa1603e2 	mov	x2, x22
   82718:	52800023 	mov	w3, #0x1                   	// #1
   8271c:	97fe0ab0 	bl	51dc <rfc_wrap>
   82720:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82724:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82728:	72a06201 	movk	w1, #0x310, lsl #16
   8272c:	d378ff68 	lsr	x8, x27, #56
   82730:	8b090f4a 	add	x10, x26, x9, lsl #3
   82734:	f100091f 	cmp	x8, #0x2
   82738:	f9000140 	str	x0, [x10]
   8273c:	54ffea81 	b.ne	8248c <spin_92+0x1aec>  // b.any
   82740:	aa1a03e0 	mov	x0, x26
   82744:	aa1903e1 	mov	x1, x25
   82748:	aa1b03e2 	mov	x2, x27
   8274c:	52800023 	mov	w3, #0x1                   	// #1
   82750:	97fe0aa3 	bl	51dc <rfc_wrap>
   82754:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82758:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   8275c:	aa0003fb 	mov	x27, x0
   82760:	72a06201 	movk	w1, #0x310, lsl #16
   82764:	17ffff4a 	b	8248c <spin_92+0x1aec>
   82768:	aa1a03e0 	mov	x0, x26
   8276c:	aa1903e1 	mov	x1, x25
   82770:	52800062 	mov	w2, #0x3                   	// #3
   82774:	ad0243f1 	stp	q17, q16, [sp, #64]
   82778:	97fe09a6 	bl	4e10 <heap_alloc_miss>
   8277c:	ad4243f1 	ldp	q17, q16, [sp, #64]
   82780:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82784:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82788:	72a06201 	movk	w1, #0x310, lsl #16
   8278c:	17fffe8a 	b	821b4 <spin_92+0x1814>
   82790:	aa1a03e0 	mov	x0, x26
   82794:	aa1903e1 	mov	x1, x25
   82798:	52800022 	mov	w2, #0x1                   	// #1
   8279c:	3c9d03a5 	stur	q5, [x29, #-48]
   827a0:	3d802be6 	str	q6, [sp, #160]
   827a4:	3d8023e7 	str	q7, [sp, #128]
   827a8:	ad0243f1 	stp	q17, q16, [sp, #64]
   827ac:	97fe0999 	bl	4e10 <heap_alloc_miss>
   827b0:	ad4243f1 	ldp	q17, q16, [sp, #64]
   827b4:	52909fe1 	mov	w1, #0x84ff                	// #34047
   827b8:	3dc023e7 	ldr	q7, [sp, #128]
   827bc:	3dc02be6 	ldr	q6, [sp, #160]
   827c0:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   827c4:	3cdd03a5 	ldur	q5, [x29, #-48]
   827c8:	72a06201 	movk	w1, #0x310, lsl #16
   827cc:	aa0003ec 	mov	x12, x0
   827d0:	d378fde8 	lsr	x8, x15, #56
   827d4:	f100091f 	cmp	x8, #0x2
   827d8:	54fff161 	b.ne	82604 <spin_92+0x1c64>  // b.any
   827dc:	aa1a03e0 	mov	x0, x26
   827e0:	aa1903e1 	mov	x1, x25
   827e4:	aa0f03e2 	mov	x2, x15
   827e8:	52800023 	mov	w3, #0x1                   	// #1
   827ec:	3c9d03a5 	stur	q5, [x29, #-48]
   827f0:	3d802be6 	str	q6, [sp, #160]
   827f4:	3d8023e7 	str	q7, [sp, #128]
   827f8:	ad0243f1 	stp	q17, q16, [sp, #64]
   827fc:	97fe0a78 	bl	51dc <rfc_wrap>
   82800:	ad4243f1 	ldp	q17, q16, [sp, #64]
   82804:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82808:	3dc023e7 	ldr	q7, [sp, #128]
   8280c:	3dc02be6 	ldr	q6, [sp, #160]
   82810:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82814:	3cdd03a5 	ldur	q5, [x29, #-48]
   82818:	72a06201 	movk	w1, #0x310, lsl #16
   8281c:	aa0003ef 	mov	x15, x0
   82820:	17ffff79 	b	82604 <spin_92+0x1c64>
   82824:	aa1a03e0 	mov	x0, x26
   82828:	aa1903e1 	mov	x1, x25
   8282c:	aa0203f6 	mov	x22, x2
   82830:	52800062 	mov	w2, #0x3                   	// #3
   82834:	aa0403ee 	mov	x14, x4
   82838:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   8283c:	3d802fe4 	str	q4, [sp, #176]
   82840:	97fe0760 	bl	45c0 <heap_hand>
   82844:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   82848:	52909fe1 	mov	w1, #0x84ff                	// #34047
   8284c:	3dc02fe4 	ldr	q4, [sp, #176]
   82850:	aa0e03e4 	mov	x4, x14
   82854:	aa1603e2 	mov	x2, x22
   82858:	d2c10016 	mov	x22, #0x80000000000         	// #8796093022208
   8285c:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82860:	72a06201 	movk	w1, #0x310, lsl #16
   82864:	17fffcff 	b	81c60 <spin_92+0x12c0>
   82868:	aa1a03e0 	mov	x0, x26
   8286c:	aa1903e1 	mov	x1, x25
   82870:	aa0203ec 	mov	x12, x2
   82874:	52800062 	mov	w2, #0x3                   	// #3
   82878:	aa0403ee 	mov	x14, x4
   8287c:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   82880:	3d802fe4 	str	q4, [sp, #176]
   82884:	3c9d03a5 	stur	q5, [x29, #-48]
   82888:	3d802be6 	str	q6, [sp, #160]
   8288c:	3d8023e7 	str	q7, [sp, #128]
   82890:	97fe074c 	bl	45c0 <heap_hand>
   82894:	ad4513e6 	ldp	q6, q4, [sp, #160]
   82898:	52909fe1 	mov	w1, #0x84ff                	// #34047
   8289c:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   828a0:	aa0e03e4 	mov	x4, x14
   828a4:	3dc023e7 	ldr	q7, [sp, #128]
   828a8:	3cdd03a5 	ldur	q5, [x29, #-48]
   828ac:	aa0c03e2 	mov	x2, x12
   828b0:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   828b4:	72a06201 	movk	w1, #0x310, lsl #16
   828b8:	17fffd8a 	b	81ee0 <spin_92+0x1540>
   828bc:	aa098168 	orr	x8, x11, x9, lsl #32
   828c0:	aa1a03e0 	mov	x0, x26
   828c4:	aa1903e1 	mov	x1, x25
   828c8:	52800044 	mov	w4, #0x2                   	// #2
   828cc:	d358fd03 	lsr	x3, x8, #24
   828d0:	8b030f48 	add	x8, x26, x3, lsl #3
   828d4:	a940290b 	ldp	x11, x10, [x8]
   828d8:	97fe076d 	bl	468c <span_fade>
   828dc:	52909fe1 	mov	w1, #0x84ff                	// #34047
   828e0:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   828e4:	72a06201 	movk	w1, #0x310, lsl #16
   828e8:	17fff90a 	b	80d10 <spin_92+0x370>
   828ec:	aa0981c8 	orr	x8, x14, x9, lsl #32
   828f0:	aa1a03e0 	mov	x0, x26
   828f4:	aa1903e1 	mov	x1, x25
   828f8:	aa0b03e2 	mov	x2, x11
   828fc:	52800064 	mov	w4, #0x3                   	// #3
   82900:	d358fd03 	lsr	x3, x8, #24
   82904:	8b030f48 	add	x8, x26, x3, lsl #3
   82908:	f9400109 	ldr	x9, [x8]
   8290c:	b940090d 	ldr	w13, [x8, #8]
   82910:	b940110e 	ldr	w14, [x8, #16]
   82914:	97fe075e 	bl	468c <span_fade>
   82918:	aa0e03f2 	mov	x18, x14
   8291c:	aa0d03f1 	mov	x17, x13
   82920:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82924:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82928:	72a06201 	movk	w1, #0x310, lsl #16
   8292c:	17fff927 	b	80dc8 <spin_92+0x428>
   82930:	aa1a03e0 	mov	x0, x26
   82934:	aa1903e1 	mov	x1, x25
   82938:	aa0a03e2 	mov	x2, x10
   8293c:	aa0b03e3 	mov	x3, x11
   82940:	528000c4 	mov	w4, #0x6                   	// #6
   82944:	ad3a07a2 	stp	q2, q1, [x29, #-192]
   82948:	97fe0751 	bl	468c <span_fade>
   8294c:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   82950:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82954:	aa1303f1 	mov	x17, x19
   82958:	aa1703f3 	mov	x19, x23
   8295c:	d2c1c017 	mov	x23, #0xe0000000000         	// #15393162788864
   82960:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82964:	72a06201 	movk	w1, #0x310, lsl #16
   82968:	f2e02017 	movk	x23, #0x100, lsl #48
   8296c:	aa1403f2 	mov	x18, x20
   82970:	17fff950 	b	80eb0 <spin_92+0x510>
   82974:	aa0d8228 	orr	x8, x17, x13, lsl #32
   82978:	aa1a03e0 	mov	x0, x26
   8297c:	aa1903e1 	mov	x1, x25
   82980:	52800044 	mov	w4, #0x2                   	// #2
   82984:	d358fd03 	lsr	x3, x8, #24
   82988:	8b030f48 	add	x8, x26, x3, lsl #3
   8298c:	a940611c 	ldp	x28, x24, [x8]
   82990:	97fe073f 	bl	468c <span_fade>
   82994:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82998:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   8299c:	72a06201 	movk	w1, #0x310, lsl #16
   829a0:	17fffbb2 	b	81868 <spin_92+0xec8>
   829a4:	aa0d8228 	orr	x8, x17, x13, lsl #32
   829a8:	aa1a03e0 	mov	x0, x26
   829ac:	aa1903e1 	mov	x1, x25
   829b0:	aa1c03e2 	mov	x2, x28
   829b4:	52800064 	mov	w4, #0x3                   	// #3
   829b8:	d358fd03 	lsr	x3, x8, #24
   829bc:	8b030f48 	add	x8, x26, x3, lsl #3
   829c0:	f940010d 	ldr	x13, [x8]
   829c4:	b9400916 	ldr	w22, [x8, #8]
   829c8:	b940110e 	ldr	w14, [x8, #16]
   829cc:	97fe0730 	bl	468c <span_fade>
   829d0:	52909fe1 	mov	w1, #0x84ff                	// #34047
   829d4:	aa0e03e4 	mov	x4, x14
   829d8:	aa1603e2 	mov	x2, x22
   829dc:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   829e0:	72a06201 	movk	w1, #0x310, lsl #16
   829e4:	d2c10016 	mov	x22, #0x80000000000         	// #8796093022208
   829e8:	92409f08 	and	x8, x24, #0xffffffffff
   829ec:	8b080f50 	add	x16, x26, x8, lsl #3
   829f0:	b6ff7a18 	tbz	x24, #63, 81930 <spin_92+0xf90>
   829f4:	17fffc76 	b	81bcc <spin_92+0x122c>
   829f8:	aa1a03e0 	mov	x0, x26
   829fc:	aa1903e1 	mov	x1, x25
   82a00:	aa0203f6 	mov	x22, x2
   82a04:	aa1803e2 	mov	x2, x24
   82a08:	aa1c03e3 	mov	x3, x28
   82a0c:	aa0403ee 	mov	x14, x4
   82a10:	528000c4 	mov	w4, #0x6                   	// #6
   82a14:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   82a18:	3d802fe4 	str	q4, [sp, #176]
   82a1c:	97fe071c 	bl	468c <span_fade>
   82a20:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   82a24:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82a28:	3dc02fe4 	ldr	q4, [sp, #176]
   82a2c:	aa0e03e4 	mov	x4, x14
   82a30:	aa1603e2 	mov	x2, x22
   82a34:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82a38:	72a06201 	movk	w1, #0x310, lsl #16
   82a3c:	d2c10016 	mov	x22, #0x80000000000         	// #8796093022208
   82a40:	17fffc88 	b	81c60 <spin_92+0x12c0>
   82a44:	f94053e2 	ldr	x2, [sp, #160]
   82a48:	aa1a03e0 	mov	x0, x26
   82a4c:	aa1903e1 	mov	x1, x25
   82a50:	aa0c03e3 	mov	x3, x12
   82a54:	528000c4 	mov	w4, #0x6                   	// #6
   82a58:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   82a5c:	3d802fe4 	str	q4, [sp, #176]
   82a60:	3c9d03a5 	stur	q5, [x29, #-48]
   82a64:	3d802be6 	str	q6, [sp, #160]
   82a68:	3d8023e7 	str	q7, [sp, #128]
   82a6c:	97fe0708 	bl	468c <span_fade>
   82a70:	ad4513e6 	ldp	q6, q4, [sp, #160]
   82a74:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82a78:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   82a7c:	aa1803e4 	mov	x4, x24
   82a80:	3dc023e7 	ldr	q7, [sp, #128]
   82a84:	3cdd03a5 	ldur	q5, [x29, #-48]
   82a88:	aa0f03f8 	mov	x24, x15
   82a8c:	aa1703ef 	mov	x15, x23
   82a90:	d2c1c017 	mov	x23, #0xe0000000000         	// #15393162788864
   82a94:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82a98:	72a06201 	movk	w1, #0x310, lsl #16
   82a9c:	aa1603e2 	mov	x2, x22
   82aa0:	d2c10016 	mov	x22, #0x80000000000         	// #8796093022208
   82aa4:	f2e02017 	movk	x23, #0x100, lsl #48
   82aa8:	17fffd0e 	b	81ee0 <spin_92+0x1540>
   82aac:	aa1a03e0 	mov	x0, x26
   82ab0:	aa1903e1 	mov	x1, x25
   82ab4:	2a1f03e2 	mov	w2, wzr
   82ab8:	97fe06c2 	bl	45c0 <heap_hand>
   82abc:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82ac0:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82ac4:	72a06201 	movk	w1, #0x310, lsl #16
   82ac8:	eb01013f 	cmp	x9, x1
   82acc:	54ff10c8 	b.hi	80ce4 <spin_92+0x344>  // b.pmore
   82ad0:	17fff890 	b	80d10 <spin_92+0x370>
   82ad4:	aa1a03e0 	mov	x0, x26
   82ad8:	aa1903e1 	mov	x1, x25
   82adc:	2a1f03e2 	mov	w2, wzr
   82ae0:	aa1103ed 	mov	x13, x17
   82ae4:	aa1203ee 	mov	x14, x18
   82ae8:	97fe06b6 	bl	45c0 <heap_hand>
   82aec:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82af0:	aa0e03f2 	mov	x18, x14
   82af4:	aa0d03f1 	mov	x17, x13
   82af8:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82afc:	72a06201 	movk	w1, #0x310, lsl #16
   82b00:	eb01017f 	cmp	x11, x1
   82b04:	54ff14c8 	b.hi	80d9c <spin_92+0x3fc>  // b.pmore
   82b08:	17fff8b0 	b	80dc8 <spin_92+0x428>
   82b0c:	aa1a03e0 	mov	x0, x26
   82b10:	aa1903e1 	mov	x1, x25
   82b14:	2a1f03e2 	mov	w2, wzr
   82b18:	ad3a07a2 	stp	q2, q1, [x29, #-192]
   82b1c:	97fe06a9 	bl	45c0 <heap_hand>
   82b20:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   82b24:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82b28:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82b2c:	72a06201 	movk	w1, #0x310, lsl #16
   82b30:	17fff8ce 	b	80e68 <spin_92+0x4c8>
   82b34:	aa1a03e0 	mov	x0, x26
   82b38:	aa1903e1 	mov	x1, x25
   82b3c:	2a1f03e2 	mov	w2, wzr
   82b40:	97fe06a0 	bl	45c0 <heap_hand>
   82b44:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82b48:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82b4c:	72a06201 	movk	w1, #0x310, lsl #16
   82b50:	eb0101bf 	cmp	x13, x1
   82b54:	54ff6748 	b.hi	8183c <spin_92+0xe9c>  // b.pmore
   82b58:	17fffb44 	b	81868 <spin_92+0xec8>
   82b5c:	aa1a03e0 	mov	x0, x26
   82b60:	aa1903e1 	mov	x1, x25
   82b64:	aa0203f6 	mov	x22, x2
   82b68:	2a1f03e2 	mov	w2, wzr
   82b6c:	aa0403ee 	mov	x14, x4
   82b70:	97fe0694 	bl	45c0 <heap_hand>
   82b74:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82b78:	aa0e03e4 	mov	x4, x14
   82b7c:	aa1603e2 	mov	x2, x22
   82b80:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82b84:	72a06201 	movk	w1, #0x310, lsl #16
   82b88:	d2c10016 	mov	x22, #0x80000000000         	// #8796093022208
   82b8c:	eb01029f 	cmp	x20, x1
   82b90:	54ff6b28 	b.hi	818f4 <spin_92+0xf54>  // b.pmore
   82b94:	17fffb63 	b	81920 <spin_92+0xf80>
   82b98:	aa1a03e0 	mov	x0, x26
   82b9c:	aa1903e1 	mov	x1, x25
   82ba0:	aa0203f6 	mov	x22, x2
   82ba4:	2a1f03e2 	mov	w2, wzr
   82ba8:	aa0403ee 	mov	x14, x4
   82bac:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   82bb0:	3d802fe4 	str	q4, [sp, #176]
   82bb4:	97fe0683 	bl	45c0 <heap_hand>
   82bb8:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   82bbc:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82bc0:	3dc02fe4 	ldr	q4, [sp, #176]
   82bc4:	aa0e03e4 	mov	x4, x14
   82bc8:	aa1603e2 	mov	x2, x22
   82bcc:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82bd0:	72a06201 	movk	w1, #0x310, lsl #16
   82bd4:	d2c10016 	mov	x22, #0x80000000000         	// #8796093022208
   82bd8:	eb01039f 	cmp	x28, x1
   82bdc:	54ff82c8 	b.hi	81c34 <spin_92+0x1294>  // b.pmore
   82be0:	17fffc20 	b	81c60 <spin_92+0x12c0>
   82be4:	aa1a03e0 	mov	x0, x26
   82be8:	aa1903e1 	mov	x1, x25
   82bec:	2a1f03e2 	mov	w2, wzr
   82bf0:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   82bf4:	3d802fe4 	str	q4, [sp, #176]
   82bf8:	3c9d03a5 	stur	q5, [x29, #-48]
   82bfc:	3d802be6 	str	q6, [sp, #160]
   82c00:	3d8023e7 	str	q7, [sp, #128]
   82c04:	97fe066f 	bl	45c0 <heap_hand>
   82c08:	ad4513e6 	ldp	q6, q4, [sp, #160]
   82c0c:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82c10:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   82c14:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82c18:	3dc023e7 	ldr	q7, [sp, #128]
   82c1c:	3cdd03a5 	ldur	q5, [x29, #-48]
   82c20:	72a06201 	movk	w1, #0x310, lsl #16
   82c24:	17fffc9b 	b	81e90 <spin_92+0x14f0>
   82c28:	aa1a03e0 	mov	x0, x26
   82c2c:	aa1903e1 	mov	x1, x25
   82c30:	52800022 	mov	w2, #0x1                   	// #1
   82c34:	aa1103ec 	mov	x12, x17
   82c38:	aa1203ee 	mov	x14, x18
   82c3c:	ad3a07a2 	stp	q2, q1, [x29, #-192]
   82c40:	97fe0660 	bl	45c0 <heap_hand>
   82c44:	1400005e 	b	82dbc <spin_92+0x241c>
   82c48:	aa1a03e0 	mov	x0, x26
   82c4c:	aa1903e1 	mov	x1, x25
   82c50:	52800022 	mov	w2, #0x1                   	// #1
   82c54:	aa1103ee 	mov	x14, x17
   82c58:	aa1203f6 	mov	x22, x18
   82c5c:	97fe0659 	bl	45c0 <heap_hand>
   82c60:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   82c64:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82c68:	aa1603f2 	mov	x18, x22
   82c6c:	aa0e03f1 	mov	x17, x14
   82c70:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82c74:	72a06201 	movk	w1, #0x310, lsl #16
   82c78:	17fff9a9 	b	8131c <spin_92+0x97c>
   82c7c:	aa1a03e0 	mov	x0, x26
   82c80:	aa1903e1 	mov	x1, x25
   82c84:	52800062 	mov	w2, #0x3                   	// #3
   82c88:	aa1103ec 	mov	x12, x17
   82c8c:	aa1203ed 	mov	x13, x18
   82c90:	3d802be3 	str	q3, [sp, #160]
   82c94:	3d8023e4 	str	q4, [sp, #128]
   82c98:	97fe064a 	bl	45c0 <heap_hand>
   82c9c:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   82ca0:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82ca4:	3dc023e4 	ldr	q4, [sp, #128]
   82ca8:	3dc02be3 	ldr	q3, [sp, #160]
   82cac:	aa0d03f2 	mov	x18, x13
   82cb0:	aa0c03f1 	mov	x17, x12
   82cb4:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82cb8:	72a06201 	movk	w1, #0x310, lsl #16
   82cbc:	17fff9d9 	b	81420 <spin_92+0xa80>
   82cc0:	aa1a03e0 	mov	x0, x26
   82cc4:	aa1903e1 	mov	x1, x25
   82cc8:	aa0203eb 	mov	x11, x2
   82ccc:	52800062 	mov	w2, #0x3                   	// #3
   82cd0:	aa0403ec 	mov	x12, x4
   82cd4:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   82cd8:	3d802fe4 	str	q4, [sp, #176]
   82cdc:	3c9d03a5 	stur	q5, [x29, #-48]
   82ce0:	3d802be6 	str	q6, [sp, #160]
   82ce4:	3d8023e7 	str	q7, [sp, #128]
   82ce8:	ad020bf1 	stp	q17, q2, [sp, #64]
   82cec:	97fe0635 	bl	45c0 <heap_hand>
   82cf0:	ad420bf1 	ldp	q17, q2, [sp, #64]
   82cf4:	aa0c03e4 	mov	x4, x12
   82cf8:	ad4513e6 	ldp	q6, q4, [sp, #160]
   82cfc:	aa0b03e2 	mov	x2, x11
   82d00:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   82d04:	14000077 	b	82ee0 <spin_92+0x2540>
   82d08:	aa1a03e0 	mov	x0, x26
   82d0c:	aa1903e1 	mov	x1, x25
   82d10:	aa0203ef 	mov	x15, x2
   82d14:	2a1f03e2 	mov	w2, wzr
   82d18:	aa0403ee 	mov	x14, x4
   82d1c:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   82d20:	3d802fe4 	str	q4, [sp, #176]
   82d24:	97fe0627 	bl	45c0 <heap_hand>
   82d28:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   82d2c:	aa0e03e4 	mov	x4, x14
   82d30:	3dc02fe4 	ldr	q4, [sp, #176]
   82d34:	aa0f03e2 	mov	x2, x15
   82d38:	140000c5 	b	8304c <spin_92+0x26ac>
   82d3c:	aa1a03e0 	mov	x0, x26
   82d40:	aa1903e1 	mov	x1, x25
   82d44:	aa0203f4 	mov	x20, x2
   82d48:	52800022 	mov	w2, #0x1                   	// #1
   82d4c:	aa0403ee 	mov	x14, x4
   82d50:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   82d54:	3d802fe4 	str	q4, [sp, #176]
   82d58:	97fe061a 	bl	45c0 <heap_hand>
   82d5c:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   82d60:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82d64:	3dc02fe4 	ldr	q4, [sp, #176]
   82d68:	aa0e03e4 	mov	x4, x14
   82d6c:	aa1403e2 	mov	x2, x20
   82d70:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82d74:	72a06201 	movk	w1, #0x310, lsl #16
   82d78:	f85d03b4 	ldur	x20, [x29, #-48]
   82d7c:	92409d88 	and	x8, x12, #0xffffffffff
   82d80:	8b080f50 	add	x16, x26, x8, lsl #3
   82d84:	b6ff77ec 	tbz	x12, #63, 81c80 <spin_92+0x12e0>
   82d88:	17fffc26 	b	81e20 <spin_92+0x1480>
   82d8c:	aa0a8188 	orr	x8, x12, x10, lsl #32
   82d90:	aa1a03e0 	mov	x0, x26
   82d94:	aa1903e1 	mov	x1, x25
   82d98:	52800044 	mov	w4, #0x2                   	// #2
   82d9c:	aa1103ec 	mov	x12, x17
   82da0:	aa1203ee 	mov	x14, x18
   82da4:	d358fd03 	lsr	x3, x8, #24
   82da8:	ad3a07a2 	stp	q2, q1, [x29, #-192]
   82dac:	8b030f48 	add	x8, x26, x3, lsl #3
   82db0:	f940010a 	ldr	x10, [x8]
   82db4:	b940090d 	ldr	w13, [x8, #8]
   82db8:	97fe0635 	bl	468c <span_fade>
   82dbc:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   82dc0:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82dc4:	aa0e03f2 	mov	x18, x14
   82dc8:	aa0c03f1 	mov	x17, x12
   82dcc:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82dd0:	72a06201 	movk	w1, #0x310, lsl #16
   82dd4:	17fff893 	b	81020 <spin_92+0x680>
   82dd8:	aa0b81c8 	orr	x8, x14, x11, lsl #32
   82ddc:	aa1a03e0 	mov	x0, x26
   82de0:	aa1903e1 	mov	x1, x25
   82de4:	52800044 	mov	w4, #0x2                   	// #2
   82de8:	d358fd03 	lsr	x3, x8, #24
   82dec:	8b030f48 	add	x8, x26, x3, lsl #3
   82df0:	f940010b 	ldr	x11, [x8]
   82df4:	b940091c 	ldr	w28, [x8, #8]
   82df8:	97fe0625 	bl	468c <span_fade>
   82dfc:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   82e00:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82e04:	aa0f03f2 	mov	x18, x15
   82e08:	aa1803ef 	mov	x15, x24
   82e0c:	aa1303f8 	mov	x24, x19
   82e10:	aa1703f3 	mov	x19, x23
   82e14:	d2c1c017 	mov	x23, #0xe0000000000         	// #15393162788864
   82e18:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82e1c:	72a06201 	movk	w1, #0x310, lsl #16
   82e20:	aa1603f1 	mov	x17, x22
   82e24:	f2e02017 	movk	x23, #0x100, lsl #48
   82e28:	17fff93d 	b	8131c <spin_92+0x97c>
   82e2c:	aa1a03e0 	mov	x0, x26
   82e30:	aa1903e1 	mov	x1, x25
   82e34:	aa0d03e2 	mov	x2, x13
   82e38:	aa0c03e3 	mov	x3, x12
   82e3c:	528000a4 	mov	w4, #0x5                   	// #5
   82e40:	3d802be3 	str	q3, [sp, #160]
   82e44:	3d8023e4 	str	q4, [sp, #128]
   82e48:	97fe0611 	bl	468c <span_fade>
   82e4c:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   82e50:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82e54:	3dc023e4 	ldr	q4, [sp, #128]
   82e58:	3dc02be3 	ldr	q3, [sp, #160]
   82e5c:	aa1303f1 	mov	x17, x19
   82e60:	aa1703f3 	mov	x19, x23
   82e64:	d2c1c017 	mov	x23, #0xe0000000000         	// #15393162788864
   82e68:	aa1c03f2 	mov	x18, x28
   82e6c:	aa0f03fc 	mov	x28, x15
   82e70:	aa1803ef 	mov	x15, x24
   82e74:	aa0b03f8 	mov	x24, x11
   82e78:	aa0903eb 	mov	x11, x9
   82e7c:	f9405be9 	ldr	x9, [sp, #176]
   82e80:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82e84:	72a06201 	movk	w1, #0x310, lsl #16
   82e88:	f2e02017 	movk	x23, #0x100, lsl #48
   82e8c:	17fff965 	b	81420 <spin_92+0xa80>
   82e90:	aa1a03e0 	mov	x0, x26
   82e94:	aa1903e1 	mov	x1, x25
   82e98:	aa0203f6 	mov	x22, x2
   82e9c:	aa0b03e2 	mov	x2, x11
   82ea0:	aa0c03e3 	mov	x3, x12
   82ea4:	aa0403eb 	mov	x11, x4
   82ea8:	528000a4 	mov	w4, #0x5                   	// #5
   82eac:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   82eb0:	3d802fe4 	str	q4, [sp, #176]
   82eb4:	3c9d03a5 	stur	q5, [x29, #-48]
   82eb8:	3d802be6 	str	q6, [sp, #160]
   82ebc:	3d8023e7 	str	q7, [sp, #128]
   82ec0:	ad020bf1 	stp	q17, q2, [sp, #64]
   82ec4:	97fe05f2 	bl	468c <span_fade>
   82ec8:	ad420bf1 	ldp	q17, q2, [sp, #64]
   82ecc:	aa0b03e4 	mov	x4, x11
   82ed0:	ad4513e6 	ldp	q6, q4, [sp, #160]
   82ed4:	aa1603e2 	mov	x2, x22
   82ed8:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   82edc:	d2c10016 	mov	x22, #0x80000000000         	// #8796093022208
   82ee0:	3dc023e7 	ldr	q7, [sp, #128]
   82ee4:	3cdd03a5 	ldur	q5, [x29, #-48]
   82ee8:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82eec:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82ef0:	72a06201 	movk	w1, #0x310, lsl #16
   82ef4:	17fffc62 	b	8207c <spin_92+0x16dc>
   82ef8:	aa1a03e0 	mov	x0, x26
   82efc:	aa1903e1 	mov	x1, x25
   82f00:	2a1f03e2 	mov	w2, wzr
   82f04:	aa1103ee 	mov	x14, x17
   82f08:	f9005bf2 	str	x18, [sp, #176]
   82f0c:	ad3a07a2 	stp	q2, q1, [x29, #-192]
   82f10:	97fe05ac 	bl	45c0 <heap_hand>
   82f14:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   82f18:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82f1c:	f9405bf2 	ldr	x18, [sp, #176]
   82f20:	aa0e03f1 	mov	x17, x14
   82f24:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82f28:	72a06201 	movk	w1, #0x310, lsl #16
   82f2c:	eb01019f 	cmp	x12, x1
   82f30:	54ff0628 	b.hi	80ff4 <spin_92+0x654>  // b.pmore
   82f34:	17fff83b 	b	81020 <spin_92+0x680>
   82f38:	aa1a03e0 	mov	x0, x26
   82f3c:	aa1903e1 	mov	x1, x25
   82f40:	2a1f03e2 	mov	w2, wzr
   82f44:	97fe059f 	bl	45c0 <heap_hand>
   82f48:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82f4c:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82f50:	72a06201 	movk	w1, #0x310, lsl #16
   82f54:	17fff8dd 	b	812c8 <spin_92+0x928>
   82f58:	aa1a03e0 	mov	x0, x26
   82f5c:	aa1903e1 	mov	x1, x25
   82f60:	2a1f03e2 	mov	w2, wzr
   82f64:	3d802be3 	str	q3, [sp, #160]
   82f68:	3d8023e4 	str	q4, [sp, #128]
   82f6c:	97fe0595 	bl	45c0 <heap_hand>
   82f70:	3dc023e4 	ldr	q4, [sp, #128]
   82f74:	3dc02be3 	ldr	q3, [sp, #160]
   82f78:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82f7c:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82f80:	72a06201 	movk	w1, #0x310, lsl #16
   82f84:	17fff90f 	b	813c0 <spin_92+0xa20>
   82f88:	aa1a03e0 	mov	x0, x26
   82f8c:	aa1903e1 	mov	x1, x25
   82f90:	aa0203eb 	mov	x11, x2
   82f94:	2a1f03e2 	mov	w2, wzr
   82f98:	aa0f03f7 	mov	x23, x15
   82f9c:	aa1303ef 	mov	x15, x19
   82fa0:	aa1803f3 	mov	x19, x24
   82fa4:	aa0403f8 	mov	x24, x4
   82fa8:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   82fac:	3d802fe4 	str	q4, [sp, #176]
   82fb0:	3c9d03a5 	stur	q5, [x29, #-48]
   82fb4:	3d802be6 	str	q6, [sp, #160]
   82fb8:	3d8023e7 	str	q7, [sp, #128]
   82fbc:	ad020bf1 	stp	q17, q2, [sp, #64]
   82fc0:	97fe0580 	bl	45c0 <heap_hand>
   82fc4:	ad420bf1 	ldp	q17, q2, [sp, #64]
   82fc8:	aa1803e4 	mov	x4, x24
   82fcc:	ad4513e6 	ldp	q6, q4, [sp, #160]
   82fd0:	aa1303f8 	mov	x24, x19
   82fd4:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   82fd8:	aa0f03f3 	mov	x19, x15
   82fdc:	3dc023e7 	ldr	q7, [sp, #128]
   82fe0:	3cdd03a5 	ldur	q5, [x29, #-48]
   82fe4:	aa1703ef 	mov	x15, x23
   82fe8:	d2c1c017 	mov	x23, #0xe0000000000         	// #15393162788864
   82fec:	52909fe1 	mov	w1, #0x84ff                	// #34047
   82ff0:	aa0b03e2 	mov	x2, x11
   82ff4:	f2e02017 	movk	x23, #0x100, lsl #48
   82ff8:	d0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   82ffc:	72a06201 	movk	w1, #0x310, lsl #16
   83000:	eb01019f 	cmp	x12, x1
   83004:	54ff8268 	b.hi	82050 <spin_92+0x16b0>  // b.pmore
   83008:	17fffc1d 	b	8207c <spin_92+0x16dc>
   8300c:	aa118248 	orr	x8, x18, x17, lsl #32
   83010:	aa1a03e0 	mov	x0, x26
   83014:	aa1903e1 	mov	x1, x25
   83018:	aa0203f4 	mov	x20, x2
   8301c:	aa0f03e2 	mov	x2, x15
   83020:	aa0403ee 	mov	x14, x4
   83024:	d358fd03 	lsr	x3, x8, #24
   83028:	52800024 	mov	w4, #0x1                   	// #1
   8302c:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   83030:	3d802fe4 	str	q4, [sp, #176]
   83034:	f8637b58 	ldr	x24, [x26, x3, lsl #3]
   83038:	97fe0595 	bl	468c <span_fade>
   8303c:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   83040:	aa0e03e4 	mov	x4, x14
   83044:	3dc02fe4 	ldr	q4, [sp, #176]
   83048:	aa1403e2 	mov	x2, x20
   8304c:	52909fe1 	mov	w1, #0x84ff                	// #34047
   83050:	b0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   83054:	72a06201 	movk	w1, #0x310, lsl #16
   83058:	17fffb39 	b	81d3c <spin_92+0x139c>
   8305c:	aa0f8228 	orr	x8, x17, x15, lsl #32
   83060:	aa1a03e0 	mov	x0, x26
   83064:	aa1903e1 	mov	x1, x25
   83068:	aa1803e2 	mov	x2, x24
   8306c:	52800044 	mov	w4, #0x2                   	// #2
   83070:	d358fd03 	lsr	x3, x8, #24
   83074:	8b030f48 	add	x8, x26, x3, lsl #3
   83078:	f940010f 	ldr	x15, [x8]
   8307c:	b9400908 	ldr	w8, [x8, #8]
   83080:	aa0803f8 	mov	x24, x8
   83084:	97fe0582 	bl	468c <span_fade>
   83088:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   8308c:	52909fe1 	mov	w1, #0x84ff                	// #34047
   83090:	f85d03b4 	ldur	x20, [x29, #-48]
   83094:	3dc02fe4 	ldr	q4, [sp, #176]
   83098:	b0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   8309c:	72a06201 	movk	w1, #0x310, lsl #16
   830a0:	aa1603e2 	mov	x2, x22
   830a4:	d2c10016 	mov	x22, #0x80000000000         	// #8796093022208
   830a8:	aa0e03e4 	mov	x4, x14
   830ac:	92409d88 	and	x8, x12, #0xffffffffff
   830b0:	8b080f50 	add	x16, x26, x8, lsl #3
   830b4:	b6ff5e6c 	tbz	x12, #63, 81c80 <spin_92+0x12e0>
   830b8:	17fffb5a 	b	81e20 <spin_92+0x1480>
   830bc:	aa1a03e0 	mov	x0, x26
   830c0:	aa1903e1 	mov	x1, x25
   830c4:	aa0203f4 	mov	x20, x2
   830c8:	2a1f03e2 	mov	w2, wzr
   830cc:	aa0403ee 	mov	x14, x4
   830d0:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   830d4:	3d802fe4 	str	q4, [sp, #176]
   830d8:	97fe053a 	bl	45c0 <heap_hand>
   830dc:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   830e0:	52909fe1 	mov	w1, #0x84ff                	// #34047
   830e4:	3dc02fe4 	ldr	q4, [sp, #176]
   830e8:	aa0e03e4 	mov	x4, x14
   830ec:	aa1403e2 	mov	x2, x20
   830f0:	b0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   830f4:	72a06201 	movk	w1, #0x310, lsl #16
   830f8:	eb0101ff 	cmp	x15, x1
   830fc:	54ff60a8 	b.hi	81d10 <spin_92+0x1370>  // b.pmore
   83100:	17fffb0f 	b	81d3c <spin_92+0x139c>
   83104:	aa1a03e0 	mov	x0, x26
   83108:	aa1903e1 	mov	x1, x25
   8310c:	2a1f03e2 	mov	w2, wzr
   83110:	97fe052c 	bl	45c0 <heap_hand>
   83114:	52909fe1 	mov	w1, #0x84ff                	// #34047
   83118:	b0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   8311c:	72a06201 	movk	w1, #0x310, lsl #16
   83120:	17fffb2a 	b	81dc8 <spin_92+0x1428>
   83124:	eb17037f 	cmp	x27, x23
   83128:	54000061 	b.ne	83134 <spin_92+0x2794>  // b.any
   8312c:	f9400ff5 	ldr	x21, [sp, #24]
   83130:	14000009 	b	83154 <spin_92+0x27b4>
   83134:	f9400ff5 	ldr	x21, [sp, #24]
   83138:	b6f8007b 	tbz	x27, #63, 83144 <spin_92+0x27a4>
   8313c:	92409f68 	and	x8, x27, #0xffffffffff
   83140:	f8687b5f 	ldr	xzr, [x26, x8, lsl #3]
   83144:	92583f68 	and	x8, x27, #0xffff0000000000
   83148:	d2c1c00b 	mov	x11, #0xe0000000000         	// #15393162788864
   8314c:	eb0b011f 	cmp	x8, x11
   83150:	54001321 	b.ne	833b4 <spin_92+0x2a14>  // b.any
   83154:	b940cbae 	ldr	w14, [x29, #200]
   83158:	f9406ba9 	ldr	x9, [x29, #208]
   8315c:	3400076e 	cbz	w14, 83248 <spin_92+0x28a8>
   83160:	f940072a 	ldr	x10, [x25, #8]
   83164:	b400332a 	cbz	x10, 837c8 <spin_92+0x2e28>
   83168:	f86a7b48 	ldr	x8, [x26, x10, lsl #3]
   8316c:	f940872b 	ldr	x11, [x25, #264]
   83170:	f9000728 	str	x8, [x25, #8]
   83174:	d1000968 	sub	x8, x11, #0x2
   83178:	f9008728 	str	x8, [x25, #264]
   8317c:	d378fd28 	lsr	x8, x9, #56
   83180:	b940dbab 	ldr	w11, [x29, #216]
   83184:	f100091f 	cmp	x8, #0x2
   83188:	54003360 	b.eq	837f4 <spin_92+0x2e54>  // b.none
   8318c:	aa0903e0 	mov	x0, x9
   83190:	8b0a0f48 	add	x8, x26, x10, lsl #3
   83194:	b94103ac 	ldr	w12, [x29, #256]
   83198:	b940fbad 	ldr	w13, [x29, #248]
   8319c:	b940f3af 	ldr	w15, [x29, #240]
   831a0:	b940ebb3 	ldr	w19, [x29, #232]
   831a4:	b940e3b4 	ldr	w20, [x29, #224]
   831a8:	a9002d00 	stp	x0, x11, [x8]
   831ac:	f9400f2b 	ldr	x11, [x25, #24]
   831b0:	b400332b 	cbz	x11, 83814 <spin_92+0x2e74>
   831b4:	f86b7b48 	ldr	x8, [x26, x11, lsl #3]
   831b8:	f9408f30 	ldr	x16, [x25, #280]
   831bc:	f9000f28 	str	x8, [x25, #24]
   831c0:	d1002208 	sub	x8, x16, #0x8
   831c4:	f9008f28 	str	x8, [x25, #280]
   831c8:	8b0b0f48 	add	x8, x26, x11, lsl #3
   831cc:	a9004d14 	stp	x20, x19, [x8]
   831d0:	a901350f 	stp	x15, x13, [x8, #16]
   831d4:	f900110c 	str	x12, [x8, #32]
   831d8:	f940072c 	ldr	x12, [x25, #8]
   831dc:	b400336c 	cbz	x12, 83848 <spin_92+0x2ea8>
   831e0:	f86c7b48 	ldr	x8, [x26, x12, lsl #3]
   831e4:	f940872d 	ldr	x13, [x25, #264]
   831e8:	f9000728 	str	x8, [x25, #8]
   831ec:	d10009a8 	sub	x8, x13, #0x2
   831f0:	f9008728 	str	x8, [x25, #264]
   831f4:	d2c48008 	mov	x8, #0x240000000000        	// #39582418599936
   831f8:	f2e04008 	movk	x8, #0x200, lsl #48
   831fc:	aa080142 	orr	x2, x10, x8
   83200:	d378fc48 	lsr	x8, x2, #56
   83204:	f100091f 	cmp	x8, #0x2
   83208:	540033a0 	b.eq	8387c <spin_92+0x2edc>  // b.none
   8320c:	d2c4a008 	mov	x8, #0x250000000000        	// #40681930227712
   83210:	8b0c0f4a 	add	x10, x26, x12, lsl #3
   83214:	f2e04008 	movk	x8, #0x200, lsl #48
   83218:	aa080168 	orr	x8, x11, x8
   8321c:	f9000142 	str	x2, [x10]
   83220:	d378fd0b 	lsr	x11, x8, #56
   83224:	f100097f 	cmp	x11, #0x2
   83228:	540033a0 	b.eq	8389c <spin_92+0x2efc>  // b.none
   8322c:	f9000548 	str	x8, [x10, #8]
   83230:	d2c3e008 	mov	x8, #0x1f0000000000        	// #34084860461056
   83234:	f2e04008 	movk	x8, #0x200, lsl #48
   83238:	aa080182 	orr	x2, x12, x8
   8323c:	f94063ab 	ldr	x11, [x29, #192]
   83240:	b7f800a2 	tbnz	x2, #63, 83254 <spin_92+0x28b4>
   83244:	1400001c 	b	832b4 <spin_92+0x2914>
   83248:	aa1f03e2 	mov	x2, xzr
   8324c:	f94063ab 	ldr	x11, [x29, #192]
   83250:	b6f8033f 	tbz	xzr, #63, 832b4 <spin_92+0x2914>
   83254:	f85f03a8 	ldur	x8, [x29, #-16]
   83258:	eb08005f 	cmp	x2, x8
   8325c:	540002c0 	b.eq	832b4 <spin_92+0x2914>  // b.none
   83260:	f85b83a8 	ldur	x8, [x29, #-72]
   83264:	eb08005f 	cmp	x2, x8
   83268:	54000260 	b.eq	832b4 <spin_92+0x2914>  // b.none
   8326c:	f85c03a8 	ldur	x8, [x29, #-64]
   83270:	eb08005f 	cmp	x2, x8
   83274:	54000200 	b.eq	832b4 <spin_92+0x2914>  // b.none
   83278:	f85c83a8 	ldur	x8, [x29, #-56]
   8327c:	eb08005f 	cmp	x2, x8
   83280:	540001a0 	b.eq	832b4 <spin_92+0x2914>  // b.none
   83284:	f85e03a8 	ldur	x8, [x29, #-32]
   83288:	eb08005f 	cmp	x2, x8
   8328c:	54000140 	b.eq	832b4 <spin_92+0x2914>  // b.none
   83290:	f85e83a8 	ldur	x8, [x29, #-24]
   83294:	eb08005f 	cmp	x2, x8
   83298:	540000e0 	b.eq	832b4 <spin_92+0x2914>  // b.none
   8329c:	eb09005f 	cmp	x2, x9
   832a0:	540000a0 	b.eq	832b4 <spin_92+0x2914>  // b.none
   832a4:	eb0b005f 	cmp	x2, x11
   832a8:	54000060 	b.eq	832b4 <spin_92+0x2914>  // b.none
   832ac:	92409c48 	and	x8, x2, #0xffffffffff
   832b0:	f8687b5f 	ldr	xzr, [x26, x8, lsl #3]
   832b4:	b9402bf4 	ldr	w20, [sp, #40]
   832b8:	b6f80337 	tbz	x23, #63, 8331c <spin_92+0x297c>
   832bc:	f85f03a8 	ldur	x8, [x29, #-16]
   832c0:	eb0802ff 	cmp	x23, x8
   832c4:	540002c0 	b.eq	8331c <spin_92+0x297c>  // b.none
   832c8:	f85b83a8 	ldur	x8, [x29, #-72]
   832cc:	eb0802ff 	cmp	x23, x8
   832d0:	54000260 	b.eq	8331c <spin_92+0x297c>  // b.none
   832d4:	f85c03a8 	ldur	x8, [x29, #-64]
   832d8:	eb0802ff 	cmp	x23, x8
   832dc:	54000200 	b.eq	8331c <spin_92+0x297c>  // b.none
   832e0:	f85c83a8 	ldur	x8, [x29, #-56]
   832e4:	eb0802ff 	cmp	x23, x8
   832e8:	540001a0 	b.eq	8331c <spin_92+0x297c>  // b.none
   832ec:	f85e03a8 	ldur	x8, [x29, #-32]
   832f0:	eb0802ff 	cmp	x23, x8
   832f4:	54000140 	b.eq	8331c <spin_92+0x297c>  // b.none
   832f8:	f85e83a8 	ldur	x8, [x29, #-24]
   832fc:	eb0802ff 	cmp	x23, x8
   83300:	540000e0 	b.eq	8331c <spin_92+0x297c>  // b.none
   83304:	eb0902ff 	cmp	x23, x9
   83308:	540000a0 	b.eq	8331c <spin_92+0x297c>  // b.none
   8330c:	eb0b02ff 	cmp	x23, x11
   83310:	54000060 	b.eq	8331c <spin_92+0x297c>  // b.none
   83314:	92409ee8 	and	x8, x23, #0xffffffffff
   83318:	f8687b5f 	ldr	xzr, [x26, x8, lsl #3]
   8331c:	b9410bac 	ldr	w12, [x29, #264]
   83320:	f9405bad 	ldr	x13, [x29, #176]
   83324:	3400012e 	cbz	w14, 83348 <spin_92+0x29a8>
   83328:	92409c48 	and	x8, x2, #0xffffffffff
   8332c:	8b080f49 	add	x9, x26, x8, lsl #3
   83330:	b7f81062 	tbnz	x2, #63, 8353c <spin_92+0x2b9c>
   83334:	a940252a 	ldp	x10, x9, [x9]
   83338:	aa0803ee 	mov	x14, x8
   8333c:	eb01011f 	cmp	x8, x1
   83340:	540012e8 	b.hi	8359c <spin_92+0x2bfc>  // b.pmore
   83344:	140000a2 	b	835cc <spin_92+0x2c2c>
   83348:	aa1f03e8 	mov	x8, xzr
   8334c:	aa1f03ee 	mov	x14, xzr
   83350:	aa1f03ef 	mov	x15, xzr
   83354:	6f00e400 	movi	v0.2d, #0x0
   83358:	6f00e401 	movi	v1.2d, #0x0
   8335c:	aa1f03f3 	mov	x19, xzr
   83360:	140000fd 	b	83754 <spin_92+0x2db4>
   83364:	aa1a03e0 	mov	x0, x26
   83368:	aa1903e1 	mov	x1, x25
   8336c:	aa0a03e2 	mov	x2, x10
   83370:	52800023 	mov	w3, #0x1                   	// #1
   83374:	97fe079a 	bl	51dc <rfc_wrap>
   83378:	52909fe1 	mov	w1, #0x84ff                	// #34047
   8337c:	b0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   83380:	72a06201 	movk	w1, #0x310, lsl #16
   83384:	d378fee8 	lsr	x8, x23, #56
   83388:	8b090f4c 	add	x12, x26, x9, lsl #3
   8338c:	f100091f 	cmp	x8, #0x2
   83390:	f9000180 	str	x0, [x12]
   83394:	54000760 	b.eq	83480 <spin_92+0x2ae0>  // b.none
   83398:	92583f68 	and	x8, x27, #0xffff0000000000
   8339c:	f9000597 	str	x23, [x12, #8]
   833a0:	eb0b011f 	cmp	x8, x11
   833a4:	d2c1e008 	mov	x8, #0xf0000000000         	// #16492674416640
   833a8:	f2e04008 	movk	x8, #0x200, lsl #48
   833ac:	aa080137 	orr	x23, x9, x8
   833b0:	54ffed20 	b.eq	83154 <spin_92+0x27b4>  // b.none
   833b4:	92409f68 	and	x8, x27, #0xffffffffff
   833b8:	8b080f4c 	add	x12, x26, x8, lsl #3
   833bc:	b7f8013b 	tbnz	x27, #63, 833e0 <spin_92+0x2a40>
   833c0:	a9406d8a 	ldp	x10, x27, [x12]
   833c4:	aa0803e9 	mov	x9, x8
   833c8:	eb01011f 	cmp	x8, x1
   833cc:	540003c9 	b.ls	83444 <spin_92+0x2aa4>  // b.plast
   833d0:	d378fd48 	lsr	x8, x10, #56
   833d4:	f100091f 	cmp	x8, #0x2
   833d8:	540004a1 	b.ne	8346c <spin_92+0x2acc>  // b.any
   833dc:	17ffffe2 	b	83364 <spin_92+0x29c4>
   833e0:	b9400589 	ldr	w9, [x12, #4]
   833e4:	b940018a 	ldr	w10, [x12]
   833e8:	92405d4d 	and	x13, x10, #0xffffff
   833ec:	f10005bf 	cmp	x13, #0x1
   833f0:	540005c1 	b.ne	834a8 <spin_92+0x2b08>  // b.any
   833f4:	aa098149 	orr	x9, x10, x9, lsl #32
   833f8:	88dffd9f 	ldar	wzr, [x12]
   833fc:	f940032c 	ldr	x12, [x25]
   83400:	d358fd29 	lsr	x9, x9, #24
   83404:	8b090f4d 	add	x13, x26, x9, lsl #3
   83408:	a9406daa 	ldp	x10, x27, [x13]
   8340c:	f8287b4c 	str	x12, [x26, x8, lsl #3]
   83410:	f940832c 	ldr	x12, [x25, #256]
   83414:	f9000328 	str	x8, [x25]
   83418:	91000588 	add	x8, x12, #0x1
   8341c:	f9008328 	str	x8, [x25, #256]
   83420:	3954006c 	ldrb	w12, [x3, #1280]
   83424:	7100059f 	cmp	w12, #0x1
   83428:	54000761 	b.ne	83514 <spin_92+0x2b74>  // b.any
   8342c:	f140211f 	cmp	x8, #0x8, lsl #12
   83430:	54000722 	b.cs	83514 <spin_92+0x2b74>  // b.hs, b.nlast
   83434:	52909fe1 	mov	w1, #0x84ff                	// #34047
   83438:	72a06201 	movk	w1, #0x310, lsl #16
   8343c:	eb01013f 	cmp	x9, x1
   83440:	54fffc88 	b.hi	833d0 <spin_92+0x2a30>  // b.pmore
   83444:	f9400729 	ldr	x9, [x25, #8]
   83448:	b40004e9 	cbz	x9, 834e4 <spin_92+0x2b44>
   8344c:	f8697b48 	ldr	x8, [x26, x9, lsl #3]
   83450:	f940872c 	ldr	x12, [x25, #264]
   83454:	f9000728 	str	x8, [x25, #8]
   83458:	d1000988 	sub	x8, x12, #0x2
   8345c:	f9008728 	str	x8, [x25, #264]
   83460:	d378fd48 	lsr	x8, x10, #56
   83464:	f100091f 	cmp	x8, #0x2
   83468:	54fff7e0 	b.eq	83364 <spin_92+0x29c4>  // b.none
   8346c:	d378fee8 	lsr	x8, x23, #56
   83470:	8b090f4c 	add	x12, x26, x9, lsl #3
   83474:	f100091f 	cmp	x8, #0x2
   83478:	f900018a 	str	x10, [x12]
   8347c:	54fff8e1 	b.ne	83398 <spin_92+0x29f8>  // b.any
   83480:	aa1a03e0 	mov	x0, x26
   83484:	aa1903e1 	mov	x1, x25
   83488:	aa1703e2 	mov	x2, x23
   8348c:	52800023 	mov	w3, #0x1                   	// #1
   83490:	97fe0753 	bl	51dc <rfc_wrap>
   83494:	52909fe1 	mov	w1, #0x84ff                	// #34047
   83498:	b0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   8349c:	aa0003f7 	mov	x23, x0
   834a0:	72a06201 	movk	w1, #0x310, lsl #16
   834a4:	17ffffbd 	b	83398 <spin_92+0x29f8>
   834a8:	aa098148 	orr	x8, x10, x9, lsl #32
   834ac:	aa1a03e0 	mov	x0, x26
   834b0:	aa1903e1 	mov	x1, x25
   834b4:	aa1b03e2 	mov	x2, x27
   834b8:	52800044 	mov	w4, #0x2                   	// #2
   834bc:	d358fd03 	lsr	x3, x8, #24
   834c0:	8b030f48 	add	x8, x26, x3, lsl #3
   834c4:	a940250a 	ldp	x10, x9, [x8]
   834c8:	97fe0471 	bl	468c <span_fade>
   834cc:	52909fe1 	mov	w1, #0x84ff                	// #34047
   834d0:	b0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   834d4:	aa0903fb 	mov	x27, x9
   834d8:	72a06201 	movk	w1, #0x310, lsl #16
   834dc:	f9400729 	ldr	x9, [x25, #8]
   834e0:	b5fffb69 	cbnz	x9, 8344c <spin_92+0x2aac>
   834e4:	aa1a03e0 	mov	x0, x26
   834e8:	aa1903e1 	mov	x1, x25
   834ec:	52800022 	mov	w2, #0x1                   	// #1
   834f0:	97fe0648 	bl	4e10 <heap_alloc_miss>
   834f4:	52909fe1 	mov	w1, #0x84ff                	// #34047
   834f8:	b0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   834fc:	aa0003e9 	mov	x9, x0
   83500:	72a06201 	movk	w1, #0x310, lsl #16
   83504:	d378fd48 	lsr	x8, x10, #56
   83508:	f100091f 	cmp	x8, #0x2
   8350c:	54fffb01 	b.ne	8346c <spin_92+0x2acc>  // b.any
   83510:	17ffff95 	b	83364 <spin_92+0x29c4>
   83514:	aa1a03e0 	mov	x0, x26
   83518:	aa1903e1 	mov	x1, x25
   8351c:	2a1f03e2 	mov	w2, wzr
   83520:	97fe0428 	bl	45c0 <heap_hand>
   83524:	b0000a23 	adrp	x3, 1c8000 <ALC+0x17e00>
   83528:	52909fe1 	mov	w1, #0x84ff                	// #34047
   8352c:	72a06201 	movk	w1, #0x310, lsl #16
   83530:	eb01013f 	cmp	x9, x1
   83534:	54fff889 	b.ls	83444 <spin_92+0x2aa4>  // b.plast
   83538:	17ffffa6 	b	833d0 <spin_92+0x2a30>
   8353c:	b940052a 	ldr	w10, [x9, #4]
   83540:	b940012e 	ldr	w14, [x9]
   83544:	92405dcf 	and	x15, x14, #0xffffff
   83548:	f10005ff 	cmp	x15, #0x1
   8354c:	54001dc1 	b.ne	83904 <spin_92+0x2f64>  // b.any
   83550:	aa0a81ca 	orr	x10, x14, x10, lsl #32
   83554:	88dffd3f 	ldar	wzr, [x9]
   83558:	f9400330 	ldr	x16, [x25]
   8355c:	d358fd4e 	lsr	x14, x10, #24
   83560:	8b0e0f4f 	add	x15, x26, x14, lsl #3
   83564:	a94025ea 	ldp	x10, x9, [x15]
   83568:	f8287b50 	str	x16, [x26, x8, lsl #3]
   8356c:	f940832f 	ldr	x15, [x25, #256]
   83570:	f9000328 	str	x8, [x25]
   83574:	910005e8 	add	x8, x15, #0x1
   83578:	b0000a2f 	adrp	x15, 1c8000 <ALC+0x17e00>
   8357c:	f9008328 	str	x8, [x25, #256]
   83580:	395401ef 	ldrb	w15, [x15, #1280]
   83584:	710005ff 	cmp	w15, #0x1
   83588:	54002041 	b.ne	83990 <spin_92+0x2ff0>  // b.any
   8358c:	f140211f 	cmp	x8, #0x8, lsl #12
   83590:	54002002 	b.cs	83990 <spin_92+0x2ff0>  // b.hs, b.nlast
   83594:	eb0101df 	cmp	x14, x1
   83598:	540001a9 	b.ls	835cc <spin_92+0x2c2c>  // b.plast
   8359c:	f9400728 	ldr	x8, [x25, #8]
   835a0:	b0000a2f 	adrp	x15, 1c8000 <ALC+0x17e00>
   835a4:	f82e7b48 	str	x8, [x26, x14, lsl #3]
   835a8:	f9408728 	ldr	x8, [x25, #264]
   835ac:	f900072e 	str	x14, [x25, #8]
   835b0:	91000908 	add	x8, x8, #0x2
   835b4:	f9008728 	str	x8, [x25, #264]
   835b8:	395401ef 	ldrb	w15, [x15, #1280]
   835bc:	710005ff 	cmp	w15, #0x1
   835c0:	54001801 	b.ne	838c0 <spin_92+0x2f20>  // b.any
   835c4:	f140211f 	cmp	x8, #0x8, lsl #12
   835c8:	540017c2 	b.cs	838c0 <spin_92+0x2f20>  // b.hs, b.nlast
   835cc:	92409d48 	and	x8, x10, #0xffffffffff
   835d0:	8b080f4f 	add	x15, x26, x8, lsl #3
   835d4:	b7f800ea 	tbnz	x10, #63, 835f0 <spin_92+0x2c50>
   835d8:	f94001ee 	ldr	x14, [x15]
   835dc:	b94009ef 	ldr	w15, [x15, #8]
   835e0:	aa0803ea 	mov	x10, x8
   835e4:	eb01011f 	cmp	x8, x1
   835e8:	54000368 	b.hi	83654 <spin_92+0x2cb4>  // b.pmore
   835ec:	14000026 	b	83684 <spin_92+0x2ce4>
   835f0:	b94005ee 	ldr	w14, [x15, #4]
   835f4:	b94001f0 	ldr	w16, [x15]
   835f8:	92405e11 	and	x17, x16, #0xffffff
   835fc:	f100063f 	cmp	x17, #0x1
   83600:	54001981 	b.ne	83930 <spin_92+0x2f90>  // b.any
   83604:	aa0e820a 	orr	x10, x16, x14, lsl #32
   83608:	88dffdff 	ldar	wzr, [x15]
   8360c:	f9400331 	ldr	x17, [x25]
   83610:	d358fd4a 	lsr	x10, x10, #24
   83614:	8b0a0f50 	add	x16, x26, x10, lsl #3
   83618:	f940020e 	ldr	x14, [x16]
   8361c:	b9400a0f 	ldr	w15, [x16, #8]
   83620:	f8287b51 	str	x17, [x26, x8, lsl #3]
   83624:	f9408330 	ldr	x16, [x25, #256]
   83628:	f9000328 	str	x8, [x25]
   8362c:	91000608 	add	x8, x16, #0x1
   83630:	b0000a30 	adrp	x16, 1c8000 <ALC+0x17e00>
   83634:	f9008328 	str	x8, [x25, #256]
   83638:	39540210 	ldrb	w16, [x16, #1280]
   8363c:	7100061f 	cmp	w16, #0x1
   83640:	54001ba1 	b.ne	839b4 <spin_92+0x3014>  // b.any
   83644:	f140211f 	cmp	x8, #0x8, lsl #12
   83648:	54001b62 	b.cs	839b4 <spin_92+0x3014>  // b.hs, b.nlast
   8364c:	eb01015f 	cmp	x10, x1
   83650:	540001a9 	b.ls	83684 <spin_92+0x2ce4>  // b.plast
   83654:	f9400728 	ldr	x8, [x25, #8]
   83658:	b0000a30 	adrp	x16, 1c8000 <ALC+0x17e00>
   8365c:	f82a7b48 	str	x8, [x26, x10, lsl #3]
   83660:	f9408728 	ldr	x8, [x25, #264]
   83664:	f900072a 	str	x10, [x25, #8]
   83668:	91000908 	add	x8, x8, #0x2
   8366c:	f9008728 	str	x8, [x25, #264]
   83670:	39540210 	ldrb	w16, [x16, #1280]
   83674:	7100061f 	cmp	w16, #0x1
   83678:	540012e1 	b.ne	838d4 <spin_92+0x2f34>  // b.any
   8367c:	f140211f 	cmp	x8, #0x8, lsl #12
   83680:	540012a2 	b.cs	838d4 <spin_92+0x2f34>  // b.hs, b.nlast
   83684:	92409d28 	and	x8, x9, #0xffffffffff
   83688:	8b080f50 	add	x16, x26, x8, lsl #3
   8368c:	b7f800e9 	tbnz	x9, #63, 836a8 <spin_92+0x2d08>
   83690:	ad400a00 	ldp	q0, q2, [x16]
   83694:	aa0803ea 	mov	x10, x8
   83698:	b9402213 	ldr	w19, [x16, #32]
   8369c:	eb01011f 	cmp	x8, x1
   836a0:	540003a8 	b.hi	83714 <spin_92+0x2d74>  // b.pmore
   836a4:	14000028 	b	83744 <spin_92+0x2da4>
   836a8:	b940060a 	ldr	w10, [x16, #4]
   836ac:	b9400212 	ldr	w18, [x16]
   836b0:	92405e51 	and	x17, x18, #0xffffff
   836b4:	f100063f 	cmp	x17, #0x1
   836b8:	54000041 	b.ne	836c0 <spin_92+0x2d20>  // b.any
   836bc:	88dffe1f 	ldar	wzr, [x16]
   836c0:	aa0a824a 	orr	x10, x18, x10, lsl #32
   836c4:	f100063f 	cmp	x17, #0x1
   836c8:	d358fd4a 	lsr	x10, x10, #24
   836cc:	8b0a0f52 	add	x18, x26, x10, lsl #3
   836d0:	ad400a40 	ldp	q0, q2, [x18]
   836d4:	b9402253 	ldr	w19, [x18, #32]
   836d8:	54001461 	b.ne	83964 <spin_92+0x2fc4>  // b.any
   836dc:	f9400329 	ldr	x9, [x25]
   836e0:	f9000209 	str	x9, [x16]
   836e4:	f9408329 	ldr	x9, [x25, #256]
   836e8:	f9000328 	str	x8, [x25]
   836ec:	91000528 	add	x8, x9, #0x1
   836f0:	b0000a29 	adrp	x9, 1c8000 <ALC+0x17e00>
   836f4:	f9008328 	str	x8, [x25, #256]
   836f8:	39540129 	ldrb	w9, [x9, #1280]
   836fc:	7100053f 	cmp	w9, #0x1
   83700:	540016c1 	b.ne	839d8 <spin_92+0x3038>  // b.any
   83704:	f140211f 	cmp	x8, #0x8, lsl #12
   83708:	54001682 	b.cs	839d8 <spin_92+0x3038>  // b.hs, b.nlast
   8370c:	eb01015f 	cmp	x10, x1
   83710:	540001a9 	b.ls	83744 <spin_92+0x2da4>  // b.plast
   83714:	f9400f28 	ldr	x8, [x25, #24]
   83718:	b0000a29 	adrp	x9, 1c8000 <ALC+0x17e00>
   8371c:	f82a7b48 	str	x8, [x26, x10, lsl #3]
   83720:	f9408f28 	ldr	x8, [x25, #280]
   83724:	f9000f2a 	str	x10, [x25, #24]
   83728:	91002108 	add	x8, x8, #0x8
   8372c:	f9008f28 	str	x8, [x25, #280]
   83730:	39540129 	ldrb	w9, [x9, #1280]
   83734:	7100053f 	cmp	w9, #0x1
   83738:	54000d81 	b.ne	838e8 <spin_92+0x2f48>  // b.any
   8373c:	f140211f 	cmp	x8, #0x8, lsl #12
   83740:	54000d42 	b.cs	838e8 <spin_92+0x2f48>  // b.hs, b.nlast
   83744:	6f00e5e1 	movi	v1.2d, #0xffffffff
   83748:	52800028 	mov	w8, #0x1                   	// #1
   8374c:	4e211c00 	and	v0.16b, v0.16b, v1.16b
   83750:	4e211c41 	and	v1.16b, v2.16b, v1.16b
   83754:	b9402fea 	ldr	w10, [sp, #44]
   83758:	2a1403e9 	mov	w9, w20
   8375c:	7100019f 	cmp	w12, #0x0
   83760:	a9063aa8 	stp	x8, x14, [x21, #96]
   83764:	1a9f07e8 	cset	w8, ne	// ne = any
   83768:	2a0a03ea 	mov	w10, w10
   8376c:	a90436b8 	stp	x24, x13, [x21, #64]
   83770:	a9002aa9 	stp	x9, x10, [x21]
   83774:	f85f03aa 	ldur	x10, [x29, #-16]
   83778:	f85b83a9 	ldur	x9, [x29, #-72]
   8377c:	a9052eb6 	stp	x22, x11, [x21, #80]
   83780:	a90126aa 	stp	x10, x9, [x21, #16]
   83784:	a97c27aa 	ldp	x10, x9, [x29, #-64]
   83788:	f9003aaf 	str	x15, [x21, #112]
   8378c:	3c8782a0 	stur	q0, [x21, #120]
   83790:	a90226aa 	stp	x10, x9, [x21, #32]
   83794:	a97e27aa 	ldp	x10, x9, [x29, #-32]
   83798:	3c8882a1 	stur	q1, [x21, #136]
   8379c:	a909a2b3 	stp	x19, x8, [x21, #152]
   837a0:	a90326aa 	stp	x10, x9, [x21, #48]
   837a4:	f90056b7 	str	x23, [x21, #168]
   837a8:	9106c3ff 	add	sp, sp, #0x1b0
   837ac:	a9454ff4 	ldp	x20, x19, [sp, #80]
   837b0:	a94457f6 	ldp	x22, x21, [sp, #64]
   837b4:	a9435ff8 	ldp	x24, x23, [sp, #48]
   837b8:	a94267fa 	ldp	x26, x25, [sp, #32]
   837bc:	a9416ffc 	ldp	x28, x27, [sp, #16]
   837c0:	a8c67bfd 	ldp	x29, x30, [sp], #96
   837c4:	d65f03c0 	ret
   837c8:	aa1a03e0 	mov	x0, x26
   837cc:	aa1903e1 	mov	x1, x25
   837d0:	52800022 	mov	w2, #0x1                   	// #1
   837d4:	97fe058f 	bl	4e10 <heap_alloc_miss>
   837d8:	52909fe1 	mov	w1, #0x84ff                	// #34047
   837dc:	aa0003ea 	mov	x10, x0
   837e0:	72a06201 	movk	w1, #0x310, lsl #16
   837e4:	d378fd28 	lsr	x8, x9, #56
   837e8:	b940dbab 	ldr	w11, [x29, #216]
   837ec:	f100091f 	cmp	x8, #0x2
   837f0:	54ffcce1 	b.ne	8318c <spin_92+0x27ec>  // b.any
   837f4:	aa1a03e0 	mov	x0, x26
   837f8:	aa1903e1 	mov	x1, x25
   837fc:	aa0903e2 	mov	x2, x9
   83800:	52800023 	mov	w3, #0x1                   	// #1
   83804:	97fe0676 	bl	51dc <rfc_wrap>
   83808:	52909fe1 	mov	w1, #0x84ff                	// #34047
   8380c:	72a06201 	movk	w1, #0x310, lsl #16
   83810:	17fffe60 	b	83190 <spin_92+0x27f0>
   83814:	aa1a03e0 	mov	x0, x26
   83818:	aa1903e1 	mov	x1, x25
   8381c:	52800062 	mov	w2, #0x3                   	// #3
   83820:	97fe057c 	bl	4e10 <heap_alloc_miss>
   83824:	52909fe1 	mov	w1, #0x84ff                	// #34047
   83828:	aa0003eb 	mov	x11, x0
   8382c:	72a06201 	movk	w1, #0x310, lsl #16
   83830:	8b000f48 	add	x8, x26, x0, lsl #3
   83834:	a9004d14 	stp	x20, x19, [x8]
   83838:	a901350f 	stp	x15, x13, [x8, #16]
   8383c:	f900110c 	str	x12, [x8, #32]
   83840:	f940072c 	ldr	x12, [x25, #8]
   83844:	b5ffccec 	cbnz	x12, 831e0 <spin_92+0x2840>
   83848:	aa1a03e0 	mov	x0, x26
   8384c:	aa1903e1 	mov	x1, x25
   83850:	52800022 	mov	w2, #0x1                   	// #1
   83854:	97fe056f 	bl	4e10 <heap_alloc_miss>
   83858:	52909fe1 	mov	w1, #0x84ff                	// #34047
   8385c:	aa0003ec 	mov	x12, x0
   83860:	72a06201 	movk	w1, #0x310, lsl #16
   83864:	d2c48008 	mov	x8, #0x240000000000        	// #39582418599936
   83868:	f2e04008 	movk	x8, #0x200, lsl #48
   8386c:	aa080142 	orr	x2, x10, x8
   83870:	d378fc48 	lsr	x8, x2, #56
   83874:	f100091f 	cmp	x8, #0x2
   83878:	54ffcca1 	b.ne	8320c <spin_92+0x286c>  // b.any
   8387c:	aa1a03e0 	mov	x0, x26
   83880:	aa1903e1 	mov	x1, x25
   83884:	52800023 	mov	w3, #0x1                   	// #1
   83888:	97fe0655 	bl	51dc <rfc_wrap>
   8388c:	52909fe1 	mov	w1, #0x84ff                	// #34047
   83890:	aa0003e2 	mov	x2, x0
   83894:	72a06201 	movk	w1, #0x310, lsl #16
   83898:	17fffe5d 	b	8320c <spin_92+0x286c>
   8389c:	aa1a03e0 	mov	x0, x26
   838a0:	aa1903e1 	mov	x1, x25
   838a4:	aa0803e2 	mov	x2, x8
   838a8:	52800023 	mov	w3, #0x1                   	// #1
   838ac:	97fe064c 	bl	51dc <rfc_wrap>
   838b0:	52909fe1 	mov	w1, #0x84ff                	// #34047
   838b4:	aa0003e8 	mov	x8, x0
   838b8:	72a06201 	movk	w1, #0x310, lsl #16
   838bc:	17fffe5c 	b	8322c <spin_92+0x288c>
   838c0:	aa1a03e0 	mov	x0, x26
   838c4:	aa1903e1 	mov	x1, x25
   838c8:	52800022 	mov	w2, #0x1                   	// #1
   838cc:	97fe033d 	bl	45c0 <heap_hand>
   838d0:	14000015 	b	83924 <spin_92+0x2f84>
   838d4:	aa1a03e0 	mov	x0, x26
   838d8:	aa1903e1 	mov	x1, x25
   838dc:	52800022 	mov	w2, #0x1                   	// #1
   838e0:	97fe0338 	bl	45c0 <heap_hand>
   838e4:	1400001d 	b	83958 <spin_92+0x2fb8>
   838e8:	aa1a03e0 	mov	x0, x26
   838ec:	aa1903e1 	mov	x1, x25
   838f0:	52800062 	mov	w2, #0x3                   	// #3
   838f4:	3c9d03a0 	stur	q0, [x29, #-48]
   838f8:	3c9a03a2 	stur	q2, [x29, #-96]
   838fc:	97fe0331 	bl	45c0 <heap_hand>
   83900:	14000021 	b	83984 <spin_92+0x2fe4>
   83904:	aa0a81c8 	orr	x8, x14, x10, lsl #32
   83908:	aa1a03e0 	mov	x0, x26
   8390c:	aa1903e1 	mov	x1, x25
   83910:	52800044 	mov	w4, #0x2                   	// #2
   83914:	d358fd03 	lsr	x3, x8, #24
   83918:	8b030f48 	add	x8, x26, x3, lsl #3
   8391c:	a940250a 	ldp	x10, x9, [x8]
   83920:	97fe035b 	bl	468c <span_fade>
   83924:	52909fe1 	mov	w1, #0x84ff                	// #34047
   83928:	72a06201 	movk	w1, #0x310, lsl #16
   8392c:	17ffff28 	b	835cc <spin_92+0x2c2c>
   83930:	aa0e8208 	orr	x8, x16, x14, lsl #32
   83934:	aa1a03e0 	mov	x0, x26
   83938:	aa1903e1 	mov	x1, x25
   8393c:	aa0a03e2 	mov	x2, x10
   83940:	52800044 	mov	w4, #0x2                   	// #2
   83944:	d358fd03 	lsr	x3, x8, #24
   83948:	8b030f48 	add	x8, x26, x3, lsl #3
   8394c:	f940010e 	ldr	x14, [x8]
   83950:	b940090f 	ldr	w15, [x8, #8]
   83954:	97fe034e 	bl	468c <span_fade>
   83958:	52909fe1 	mov	w1, #0x84ff                	// #34047
   8395c:	72a06201 	movk	w1, #0x310, lsl #16
   83960:	17ffff49 	b	83684 <spin_92+0x2ce4>
   83964:	aa1a03e0 	mov	x0, x26
   83968:	aa1903e1 	mov	x1, x25
   8396c:	aa0903e2 	mov	x2, x9
   83970:	aa0a03e3 	mov	x3, x10
   83974:	528000a4 	mov	w4, #0x5                   	// #5
   83978:	3c9d03a0 	stur	q0, [x29, #-48]
   8397c:	3c9a03a2 	stur	q2, [x29, #-96]
   83980:	97fe0343 	bl	468c <span_fade>
   83984:	3cda03a2 	ldur	q2, [x29, #-96]
   83988:	3cdd03a0 	ldur	q0, [x29, #-48]
   8398c:	17ffff6e 	b	83744 <spin_92+0x2da4>
   83990:	aa1a03e0 	mov	x0, x26
   83994:	aa1903e1 	mov	x1, x25
   83998:	2a1f03e2 	mov	w2, wzr
   8399c:	97fe0309 	bl	45c0 <heap_hand>
   839a0:	52909fe1 	mov	w1, #0x84ff                	// #34047
   839a4:	72a06201 	movk	w1, #0x310, lsl #16
   839a8:	eb0101df 	cmp	x14, x1
   839ac:	54ffdf88 	b.hi	8359c <spin_92+0x2bfc>  // b.pmore
   839b0:	17ffff07 	b	835cc <spin_92+0x2c2c>
   839b4:	aa1a03e0 	mov	x0, x26
   839b8:	aa1903e1 	mov	x1, x25
   839bc:	2a1f03e2 	mov	w2, wzr
   839c0:	97fe0300 	bl	45c0 <heap_hand>
   839c4:	52909fe1 	mov	w1, #0x84ff                	// #34047
   839c8:	72a06201 	movk	w1, #0x310, lsl #16
   839cc:	eb01015f 	cmp	x10, x1
   839d0:	54ffe428 	b.hi	83654 <spin_92+0x2cb4>  // b.pmore
   839d4:	17ffff2c 	b	83684 <spin_92+0x2ce4>
   839d8:	aa1a03e0 	mov	x0, x26
   839dc:	aa1903e1 	mov	x1, x25
   839e0:	2a1f03e2 	mov	w2, wzr
   839e4:	3c9d03a0 	stur	q0, [x29, #-48]
   839e8:	3c9a03a2 	stur	q2, [x29, #-96]
   839ec:	97fe02f5 	bl	45c0 <heap_hand>
   839f0:	3cda03a2 	ldur	q2, [x29, #-96]
   839f4:	3cdd03a0 	ldur	q0, [x29, #-48]
   839f8:	52909fe1 	mov	w1, #0x84ff                	// #34047
   839fc:	72a06201 	movk	w1, #0x310, lsl #16
   83a00:	eb01015f 	cmp	x10, x1
   83a04:	54ffe888 	b.hi	83714 <spin_92+0x2d74>  // b.pmore
   83a08:	17ffff4f 	b	83744 <spin_92+0x2da4>
   83a0c:	90000968 	adrp	x8, 1af000 <wl_tab+0x18>
   83a10:	f947e508 	ldr	x8, [x8, #4040]
   83a14:	f9400100 	ldr	x0, [x8]
   83a18:	97fe00a2 	bl	3ca0 <fflush@plt>
   83a1c:	90000968 	adrp	x8, 1af000 <wl_tab+0x18>
   83a20:	90000081 	adrp	x1, 93000 <STAT_IMG+0x1b80>
   83a24:	91143c21 	add	x1, x1, #0x50f
   83a28:	f947e108 	ldr	x8, [x8, #4032]
   83a2c:	90000082 	adrp	x2, 93000 <STAT_IMG+0x1b80>
   83a30:	9109e042 	add	x2, x2, #0x278
   83a34:	f9400100 	ldr	x0, [x8]
   83a38:	97fe00be 	bl	3d30 <fprintf@plt>
   83a3c:	52800020 	mov	w0, #0x1                   	// #1
   83a40:	97fe0014 	bl	3a90 <_exit@plt>

