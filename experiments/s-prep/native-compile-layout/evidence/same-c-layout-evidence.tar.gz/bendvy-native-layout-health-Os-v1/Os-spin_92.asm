   7ae54:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
   7ae58:	a9016ffc 	stp	x28, x27, [sp, #16]
   7ae5c:	a90267fa 	stp	x26, x25, [sp, #32]
   7ae60:	a9035ff8 	stp	x24, x23, [sp, #48]
   7ae64:	a90457f6 	stp	x22, x21, [sp, #64]
   7ae68:	a9054ff4 	stp	x20, x19, [sp, #80]
   7ae6c:	910003fd 	mov	x29, sp
   7ae70:	d106c3ff 	sub	sp, sp, #0x1b0
   7ae74:	f9404ba9 	ldr	x9, [x29, #144]
   7ae78:	a949aba8 	ldp	x8, x10, [x29, #152]
   7ae7c:	d2c1c017 	mov	x23, #0xe0000000000         	// #15393162788864
   7ae80:	b940bbb6 	ldr	w22, [x29, #184]
   7ae84:	aa0203f5 	mov	x21, x2
   7ae88:	f9001be9 	str	x9, [sp, #48]
   7ae8c:	a94827ab 	ldp	x11, x9, [x29, #128]
   7ae90:	f2e02017 	movk	x23, #0x100, lsl #48
   7ae94:	aa0103f9 	mov	x25, x1
   7ae98:	aa0003fa 	mov	x26, x0
   7ae9c:	eb17011f 	cmp	x8, x23
   7aea0:	aa0a03f3 	mov	x19, x10
   7aea4:	f81b83a7 	stur	x7, [x29, #-72]
   7aea8:	a93e23a9 	stp	x9, x8, [x29, #-32]
   7aeac:	a94727ad 	ldp	x13, x9, [x29, #112]
   7aeb0:	f9001fe6 	str	x6, [sp, #56]
   7aeb4:	f81f03a5 	stur	x5, [x29, #-16]
   7aeb8:	f81c83a9 	stur	x9, [x29, #-56]
   7aebc:	f94037a9 	ldr	x9, [x29, #104]
   7aec0:	b9002fe4 	str	w4, [sp, #44]
   7aec4:	f81c03a9 	stur	x9, [x29, #-64]
   7aec8:	f94033a9 	ldr	x9, [x29, #96]
   7aecc:	f9004fea 	str	x10, [sp, #152]
   7aed0:	540002a0 	b.eq	7af24 <spin_92+0xd0>  // b.none
   7aed4:	f85e03a8 	ldur	x8, [x29, #-32]
   7aed8:	f9401bf3 	ldr	x19, [sp, #48]
   7aedc:	eb17011f 	cmp	x8, x23
   7aee0:	54000220 	b.eq	7af24 <spin_92+0xd0>  // b.none
   7aee4:	f85c83a8 	ldur	x8, [x29, #-56]
   7aee8:	aa0b03f3 	mov	x19, x11
   7aeec:	eb17011f 	cmp	x8, x23
   7aef0:	540001a0 	b.eq	7af24 <spin_92+0xd0>  // b.none
   7aef4:	f85c03a8 	ldur	x8, [x29, #-64]
   7aef8:	aa0d03f3 	mov	x19, x13
   7aefc:	eb17011f 	cmp	x8, x23
   7af00:	54000120 	b.eq	7af24 <spin_92+0xd0>  // b.none
   7af04:	f85b83a8 	ldur	x8, [x29, #-72]
   7af08:	aa0903f3 	mov	x19, x9
   7af0c:	eb17011f 	cmp	x8, x23
   7af10:	540000a0 	b.eq	7af24 <spin_92+0xd0>  // b.none
   7af14:	f85f03a8 	ldur	x8, [x29, #-16]
   7af18:	eb17011f 	cmp	x8, x23
   7af1c:	f9401fe8 	ldr	x8, [sp, #56]
   7af20:	9a9f0113 	csel	x19, x8, xzr, eq	// eq = none
   7af24:	b940abb8 	ldr	w24, [x29, #168]
   7af28:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7af2c:	b9002be3 	str	w3, [sp, #40]
   7af30:	72a06201 	movk	w1, #0x310, lsl #16
   7af34:	34012856 	cbz	w22, 7d43c <spin_92+0x25e8>
   7af38:	8b0b0f48 	add	x8, x26, x11, lsl #3
   7af3c:	f90007e9 	str	x9, [sp, #8]
   7af40:	9280000a 	mov	x10, #0xffffffffffffffff    	// #-1
   7af44:	a901aff5 	stp	x21, x11, [sp, #24]
   7af48:	f85f03ab 	ldur	x11, [x29, #-16]
   7af4c:	f85b83ac 	ldur	x12, [x29, #-72]
   7af50:	f81383a8 	stur	x8, [x29, #-200]
   7af54:	f9401fe8 	ldr	x8, [sp, #56]
   7af58:	d2c1c01b 	mov	x27, #0xe0000000000         	// #15393162788864
   7af5c:	d368b16b 	ubfx	x11, x11, #40, #5
   7af60:	d368b18c 	ubfx	x12, x12, #40, #5
   7af64:	aa1f03f5 	mov	x21, xzr
   7af68:	8b080f48 	add	x8, x26, x8, lsl #3
   7af6c:	f2e0201b 	movk	x27, #0x100, lsl #48
   7af70:	f9000bed 	str	x13, [sp, #16]
   7af74:	5100056b 	sub	w11, w11, #0x1
   7af78:	5100058c 	sub	w12, w12, #0x1
   7af7c:	a90d63f3 	stp	x19, x24, [sp, #208]
   7af80:	f81a03a8 	stur	x8, [x29, #-96]
   7af84:	8b090f48 	add	x8, x26, x9, lsl #3
   7af88:	9acb214b 	lsl	x11, x10, x11
   7af8c:	f9003ff6 	str	x22, [sp, #120]
   7af90:	f81703a8 	stur	x8, [x29, #-144]
   7af94:	a97c27a8 	ldp	x8, x9, [x29, #-64]
   7af98:	d368b108 	ubfx	x8, x8, #40, #5
   7af9c:	d368b129 	ubfx	x9, x9, #40, #5
   7afa0:	9ac82148 	lsl	x8, x10, x8
   7afa4:	51000529 	sub	w9, w9, #0x1
   7afa8:	9ac92149 	lsl	x9, x10, x9
   7afac:	9acc214a 	lsl	x10, x10, x12
   7afb0:	aa2803e8 	mvn	x8, x8
   7afb4:	f81983a8 	stur	x8, [x29, #-104]
   7afb8:	8b0d0f48 	add	x8, x26, x13, lsl #3
   7afbc:	f81903a8 	stur	x8, [x29, #-112]
   7afc0:	aa2903e8 	mvn	x8, x9
   7afc4:	f81303a8 	stur	x8, [x29, #-208]
   7afc8:	2a2b03e8 	mvn	w8, w11
   7afcc:	b900cfe8 	str	w8, [sp, #204]
   7afd0:	2a2a03e8 	mvn	w8, w10
   7afd4:	b90077e8 	str	w8, [sp, #116]
   7afd8:	2a0303e8 	mov	w8, w3
   7afdc:	d00009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7afe0:	f90037e8 	str	x8, [sp, #104]
   7afe4:	eb17037f 	cmp	x27, x23
   7afe8:	aa1303fc 	mov	x28, x19
   7afec:	540000a0 	b.eq	7b000 <spin_92+0x1ac>  // b.none
   7aff0:	92409f7c 	and	x28, x27, #0xffffffffff
   7aff4:	b6f8007b 	tbz	x27, #63, 7b000 <spin_92+0x1ac>
   7aff8:	f87c7b48 	ldr	x8, [x26, x28, lsl #3]
   7affc:	d358fd1c 	lsr	x28, x8, #24
   7b000:	eb1802bf 	cmp	x21, x24
   7b004:	54009ec2 	b.cs	7c3dc <spin_92+0x1588>  // b.hs, b.nlast
   7b008:	a97923a9 	ldp	x9, x8, [x29, #-112]
   7b00c:	8a0802a8 	and	x8, x21, x8
   7b010:	b8687928 	ldr	w8, [x9, x8, lsl #2]
   7b014:	34009e48 	cbz	w8, 7c3dc <spin_92+0x1588>
   7b018:	a97327a8 	ldp	x8, x9, [x29, #-208]
   7b01c:	0a0802a8 	and	w8, w21, w8
   7b020:	531f7908 	lsl	w8, w8, #1
   7b024:	8b284d29 	add	x9, x9, w8, uxtw #3
   7b028:	f9400533 	ldr	x19, [x9, #8]
   7b02c:	b9400134 	ldr	w20, [x9]
   7b030:	b7f80293 	tbnz	x19, #63, 7b080 <spin_92+0x22c>
   7b034:	d379fe68 	lsr	x8, x19, #57
   7b038:	b4000388 	cbz	x8, 7b0a8 <spin_92+0x254>
   7b03c:	92787e68 	and	x8, x19, #0xffffffff00
   7b040:	9100042a 	add	x10, x1, #0x1
   7b044:	eb0a011f 	cmp	x8, x10
   7b048:	54000303 	b.cc	7b0a8 <spin_92+0x254>  // b.lo, b.ul, b.last
   7b04c:	aa1a03e0 	mov	x0, x26
   7b050:	aa1903e1 	mov	x1, x25
   7b054:	aa1303e2 	mov	x2, x19
   7b058:	52800043 	mov	w3, #0x2                   	// #2
   7b05c:	97fe278d 	bl	4e90 <rfc_wrap>
   7b060:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7b064:	b00009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7b068:	eb13001f 	cmp	x0, x19
   7b06c:	72a06201 	movk	w1, #0x310, lsl #16
   7b070:	540001c0 	b.eq	7b0a8 <spin_92+0x254>  // b.none
   7b074:	aa0003f3 	mov	x19, x0
   7b078:	f9000520 	str	x0, [x9, #8]
   7b07c:	1400000b 	b	7b0a8 <spin_92+0x254>
   7b080:	92409e68 	and	x8, x19, #0xffffffffff
   7b084:	52800020 	mov	w0, #0x1                   	// #1
   7b088:	8b080f41 	add	x1, x26, x8, lsl #3
   7b08c:	94003b89 	bl	89eb0 <__aarch64_ldadd4_relax>
   7b090:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7b094:	321f5be8 	mov	w8, #0xfffffe              	// #16777214
   7b098:	b00009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7b09c:	72a06201 	movk	w1, #0x310, lsl #16
   7b0a0:	6a20011f 	bics	wzr, w8, w0
   7b0a4:	54015d40 	b.eq	7dc4c <spin_92+0x2df8>  // b.none
   7b0a8:	b940cfe8 	ldr	w8, [sp, #204]
   7b0ac:	f85a03aa 	ldur	x10, [x29, #-96]
   7b0b0:	6f00e401 	movi	v1.2d, #0x0
   7b0b4:	f81783b3 	stur	x19, [x29, #-136]
   7b0b8:	0a0802a8 	and	w8, w21, w8
   7b0bc:	f81803b4 	stur	x20, [x29, #-128]
   7b0c0:	531f7909 	lsl	w9, w8, #1
   7b0c4:	8b294d53 	add	x19, x10, w9, uxtw #3
   7b0c8:	52800029 	mov	w9, #0x1                   	// #1
   7b0cc:	331f7909 	bfi	w9, w8, #1, #31
   7b0d0:	b940026c 	ldr	w12, [x19]
   7b0d4:	f9400662 	ldr	x2, [x19, #8]
   7b0d8:	3d800261 	str	q1, [x19]
   7b0dc:	b818c3a9 	stur	w9, [x29, #-116]
   7b0e0:	b40000ec 	cbz	x12, 7b0fc <spin_92+0x2a8>
   7b0e4:	92409c48 	and	x8, x2, #0xffffffffff
   7b0e8:	8b080f4a 	add	x10, x26, x8, lsl #3
   7b0ec:	b7f80162 	tbnz	x2, #63, 7b118 <spin_92+0x2c4>
   7b0f0:	a940294b 	ldp	x11, x10, [x10]
   7b0f4:	aa0803e9 	mov	x9, x8
   7b0f8:	1400001d 	b	7b16c <spin_92+0x318>
   7b0fc:	aa1f03f2 	mov	x18, xzr
   7b100:	aa1f03ef 	mov	x15, xzr
   7b104:	aa1f03f8 	mov	x24, xzr
   7b108:	aa1f03f1 	mov	x17, xzr
   7b10c:	6f00e402 	movi	v2.2d, #0x0
   7b110:	aa1f03e9 	mov	x9, xzr
   7b114:	14000087 	b	7b330 <spin_92+0x4dc>
   7b118:	b9400549 	ldr	w9, [x10, #4]
   7b11c:	b940014b 	ldr	w11, [x10]
   7b120:	92405d6d 	and	x13, x11, #0xffffff
   7b124:	f10005bf 	cmp	x13, #0x1
   7b128:	5400d721 	b.ne	7cc0c <spin_92+0x1db8>  // b.any
   7b12c:	aa098169 	orr	x9, x11, x9, lsl #32
   7b130:	88dffd5f 	ldar	wzr, [x10]
   7b134:	f940032e 	ldr	x14, [x25]
   7b138:	d358fd29 	lsr	x9, x9, #24
   7b13c:	8b090f4d 	add	x13, x26, x9, lsl #3
   7b140:	a94029ab 	ldp	x11, x10, [x13]
   7b144:	f8287b4e 	str	x14, [x26, x8, lsl #3]
   7b148:	f940832d 	ldr	x13, [x25, #256]
   7b14c:	3948306e 	ldrb	w14, [x3, #524]
   7b150:	f9000328 	str	x8, [x25]
   7b154:	910005a8 	add	x8, x13, #0x1
   7b158:	710005df 	cmp	w14, #0x1
   7b15c:	f9008328 	str	x8, [x25, #256]
   7b160:	5400e481 	b.ne	7cdf0 <spin_92+0x1f9c>  // b.any
   7b164:	f140211f 	cmp	x8, #0x8, lsl #12
   7b168:	5400e442 	b.cs	7cdf0 <spin_92+0x1f9c>  // b.hs, b.nlast
   7b16c:	eb01013f 	cmp	x9, x1
   7b170:	54000189 	b.ls	7b1a0 <spin_92+0x34c>  // b.plast
   7b174:	f9400728 	ldr	x8, [x25, #8]
   7b178:	3948306d 	ldrb	w13, [x3, #524]
   7b17c:	f8297b48 	str	x8, [x26, x9, lsl #3]
   7b180:	f9408728 	ldr	x8, [x25, #264]
   7b184:	710005bf 	cmp	w13, #0x1
   7b188:	f9000729 	str	x9, [x25, #8]
   7b18c:	91000908 	add	x8, x8, #0x2
   7b190:	f9008728 	str	x8, [x25, #264]
   7b194:	5400c961 	b.ne	7cac0 <spin_92+0x1c6c>  // b.any
   7b198:	f140211f 	cmp	x8, #0x8, lsl #12
   7b19c:	5400c922 	b.cs	7cac0 <spin_92+0x1c6c>  // b.hs, b.nlast
   7b1a0:	92409d68 	and	x8, x11, #0xffffffffff
   7b1a4:	8b080f4d 	add	x13, x26, x8, lsl #3
   7b1a8:	b7f800cb 	tbnz	x11, #63, 7b1c0 <spin_92+0x36c>
   7b1ac:	f94001a9 	ldr	x9, [x13]
   7b1b0:	b94009b1 	ldr	w17, [x13, #8]
   7b1b4:	aa0803eb 	mov	x11, x8
   7b1b8:	b94011b2 	ldr	w18, [x13, #16]
   7b1bc:	14000018 	b	7b21c <spin_92+0x3c8>
   7b1c0:	b94005a9 	ldr	w9, [x13, #4]
   7b1c4:	b94001ae 	ldr	w14, [x13]
   7b1c8:	92405dcf 	and	x15, x14, #0xffffff
   7b1cc:	f10005ff 	cmp	x15, #0x1
   7b1d0:	5400d361 	b.ne	7cc3c <spin_92+0x1de8>  // b.any
   7b1d4:	aa0981c9 	orr	x9, x14, x9, lsl #32
   7b1d8:	88dffdbf 	ldar	wzr, [x13]
   7b1dc:	f940032d 	ldr	x13, [x25]
   7b1e0:	d358fd2b 	lsr	x11, x9, #24
   7b1e4:	8b0b0f4e 	add	x14, x26, x11, lsl #3
   7b1e8:	f94001c9 	ldr	x9, [x14]
   7b1ec:	b94009d1 	ldr	w17, [x14, #8]
   7b1f0:	b94011d2 	ldr	w18, [x14, #16]
   7b1f4:	f8287b4d 	str	x13, [x26, x8, lsl #3]
   7b1f8:	3948306e 	ldrb	w14, [x3, #524]
   7b1fc:	f940832d 	ldr	x13, [x25, #256]
   7b200:	f9000328 	str	x8, [x25]
   7b204:	710005df 	cmp	w14, #0x1
   7b208:	910005a8 	add	x8, x13, #0x1
   7b20c:	f9008328 	str	x8, [x25, #256]
   7b210:	5400e001 	b.ne	7ce10 <spin_92+0x1fbc>  // b.any
   7b214:	f140211f 	cmp	x8, #0x8, lsl #12
   7b218:	5400dfc2 	b.cs	7ce10 <spin_92+0x1fbc>  // b.hs, b.nlast
   7b21c:	eb01017f 	cmp	x11, x1
   7b220:	54000189 	b.ls	7b250 <spin_92+0x3fc>  // b.plast
   7b224:	f9400b28 	ldr	x8, [x25, #16]
   7b228:	3948306d 	ldrb	w13, [x3, #524]
   7b22c:	f82b7b48 	str	x8, [x26, x11, lsl #3]
   7b230:	f9408b28 	ldr	x8, [x25, #272]
   7b234:	710005bf 	cmp	w13, #0x1
   7b238:	f9000b2b 	str	x11, [x25, #16]
   7b23c:	91001108 	add	x8, x8, #0x4
   7b240:	f9008b28 	str	x8, [x25, #272]
   7b244:	5400c481 	b.ne	7cad4 <spin_92+0x1c80>  // b.any
   7b248:	f140211f 	cmp	x8, #0x8, lsl #12
   7b24c:	5400c442 	b.cs	7cad4 <spin_92+0x1c80>  // b.hs, b.nlast
   7b250:	92409d48 	and	x8, x10, #0xffffffffff
   7b254:	8b080f4d 	add	x13, x26, x8, lsl #3
   7b258:	b7f800ea 	tbnz	x10, #63, 7b274 <spin_92+0x420>
   7b25c:	b94001af 	ldr	w15, [x13]
   7b260:	3cc081a1 	ldur	q1, [x13, #8]
   7b264:	aa0803eb 	mov	x11, x8
   7b268:	3cc181a2 	ldur	q2, [x13, #24]
   7b26c:	b94029b8 	ldr	w24, [x13, #40]
   7b270:	14000023 	b	7b2fc <spin_92+0x4a8>
   7b274:	b94005ab 	ldr	w11, [x13, #4]
   7b278:	b94001af 	ldr	w15, [x13]
   7b27c:	aa1303f7 	mov	x23, x19
   7b280:	92405dee 	and	x14, x15, #0xffffff
   7b284:	f10005df 	cmp	x14, #0x1
   7b288:	54000041 	b.ne	7b290 <spin_92+0x43c>  // b.any
   7b28c:	88dffdbf 	ldar	wzr, [x13]
   7b290:	aa0b81eb 	orr	x11, x15, x11, lsl #32
   7b294:	aa1203f4 	mov	x20, x18
   7b298:	aa1103f3 	mov	x19, x17
   7b29c:	f10005df 	cmp	x14, #0x1
   7b2a0:	d358fd6b 	lsr	x11, x11, #24
   7b2a4:	8b0b0f50 	add	x16, x26, x11, lsl #3
   7b2a8:	b940020f 	ldr	w15, [x16]
   7b2ac:	3cc08201 	ldur	q1, [x16, #8]
   7b2b0:	3cc18202 	ldur	q2, [x16, #24]
   7b2b4:	b9402a18 	ldr	w24, [x16, #40]
   7b2b8:	5400ce41 	b.ne	7cc80 <spin_92+0x1e2c>  // b.any
   7b2bc:	f940032a 	ldr	x10, [x25]
   7b2c0:	f90001aa 	str	x10, [x13]
   7b2c4:	3948306d 	ldrb	w13, [x3, #524]
   7b2c8:	f940832a 	ldr	x10, [x25, #256]
   7b2cc:	f9000328 	str	x8, [x25]
   7b2d0:	710005bf 	cmp	w13, #0x1
   7b2d4:	91000548 	add	x8, x10, #0x1
   7b2d8:	f9008328 	str	x8, [x25, #256]
   7b2dc:	5400db21 	b.ne	7ce40 <spin_92+0x1fec>  // b.any
   7b2e0:	f140211f 	cmp	x8, #0x8, lsl #12
   7b2e4:	5400dae2 	b.cs	7ce40 <spin_92+0x1fec>  // b.hs, b.nlast
   7b2e8:	aa1303f1 	mov	x17, x19
   7b2ec:	aa1703f3 	mov	x19, x23
   7b2f0:	d2c1c017 	mov	x23, #0xe0000000000         	// #15393162788864
   7b2f4:	f2e02017 	movk	x23, #0x100, lsl #48
   7b2f8:	aa1403f2 	mov	x18, x20
   7b2fc:	eb01017f 	cmp	x11, x1
   7b300:	54000189 	b.ls	7b330 <spin_92+0x4dc>  // b.plast
   7b304:	f9400f28 	ldr	x8, [x25, #24]
   7b308:	3948306a 	ldrb	w10, [x3, #524]
   7b30c:	f82b7b48 	str	x8, [x26, x11, lsl #3]
   7b310:	f9408f28 	ldr	x8, [x25, #280]
   7b314:	7100055f 	cmp	w10, #0x1
   7b318:	f9000f2b 	str	x11, [x25, #24]
   7b31c:	91002108 	add	x8, x8, #0x8
   7b320:	f9008f28 	str	x8, [x25, #280]
   7b324:	5400bea1 	b.ne	7caf8 <spin_92+0x1ca4>  // b.any
   7b328:	f140211f 	cmp	x8, #0x8, lsl #12
   7b32c:	5400be62 	b.cs	7caf8 <spin_92+0x1ca4>  // b.hs, b.nlast
   7b330:	eb1b013f 	cmp	x9, x27
   7b334:	aa1c03eb 	mov	x11, x28
   7b338:	540003a0 	b.eq	7b3ac <spin_92+0x558>  // b.none
   7b33c:	f85e83a8 	ldur	x8, [x29, #-24]
   7b340:	f9404feb 	ldr	x11, [sp, #152]
   7b344:	eb08013f 	cmp	x9, x8
   7b348:	54000320 	b.eq	7b3ac <spin_92+0x558>  // b.none
   7b34c:	f85e03a8 	ldur	x8, [x29, #-32]
   7b350:	f9401beb 	ldr	x11, [sp, #48]
   7b354:	eb08013f 	cmp	x9, x8
   7b358:	540002a0 	b.eq	7b3ac <spin_92+0x558>  // b.none
   7b35c:	f85c83a8 	ldur	x8, [x29, #-56]
   7b360:	f94013eb 	ldr	x11, [sp, #32]
   7b364:	eb08013f 	cmp	x9, x8
   7b368:	54000220 	b.eq	7b3ac <spin_92+0x558>  // b.none
   7b36c:	f85c03a8 	ldur	x8, [x29, #-64]
   7b370:	f9400beb 	ldr	x11, [sp, #16]
   7b374:	eb08013f 	cmp	x9, x8
   7b378:	540001a0 	b.eq	7b3ac <spin_92+0x558>  // b.none
   7b37c:	f85b83a8 	ldur	x8, [x29, #-72]
   7b380:	f94007eb 	ldr	x11, [sp, #8]
   7b384:	eb08013f 	cmp	x9, x8
   7b388:	54000120 	b.eq	7b3ac <spin_92+0x558>  // b.none
   7b38c:	f85f03a8 	ldur	x8, [x29, #-16]
   7b390:	f9401feb 	ldr	x11, [sp, #56]
   7b394:	eb08013f 	cmp	x9, x8
   7b398:	540000a0 	b.eq	7b3ac <spin_92+0x558>  // b.none
   7b39c:	92409d2b 	and	x11, x9, #0xffffffffff
   7b3a0:	b6f80069 	tbz	x9, #63, 7b3ac <spin_92+0x558>
   7b3a4:	f86b7b48 	ldr	x8, [x26, x11, lsl #3]
   7b3a8:	d358fd0b 	lsr	x11, x8, #24
   7b3ac:	b40002ac 	cbz	x12, 7b400 <spin_92+0x5ac>
   7b3b0:	b94077e8 	ldr	w8, [sp, #116]
   7b3b4:	f85703ac 	ldur	x12, [x29, #-144]
   7b3b8:	0a0802a8 	and	w8, w21, w8
   7b3bc:	531f790a 	lsl	w10, w8, #1
   7b3c0:	8b2a4d8a 	add	x10, x12, w10, uxtw #3
   7b3c4:	5280002c 	mov	w12, #0x1                   	// #1
   7b3c8:	331f790c 	bfi	w12, w8, #1, #31
   7b3cc:	b9400154 	ldr	w20, [x10]
   7b3d0:	f9400542 	ldr	x2, [x10, #8]
   7b3d4:	a9007d5f 	stp	xzr, xzr, [x10]
   7b3d8:	b81643ac 	stur	w12, [x29, #-156]
   7b3dc:	f81683aa 	stur	x10, [x29, #-152]
   7b3e0:	b4000154 	cbz	x20, 7b408 <spin_92+0x5b4>
   7b3e4:	92409c48 	and	x8, x2, #0xffffffffff
   7b3e8:	8b080f4d 	add	x13, x26, x8, lsl #3
   7b3ec:	b7f80142 	tbnz	x2, #63, 7b414 <spin_92+0x5c0>
   7b3f0:	f94001aa 	ldr	x10, [x13]
   7b3f4:	b94009ad 	ldr	w13, [x13, #8]
   7b3f8:	aa0803ec 	mov	x12, x8
   7b3fc:	1400001c 	b	7b46c <spin_92+0x618>
   7b400:	a94d63f3 	ldp	x19, x24, [sp, #208]
   7b404:	140003f6 	b	7c3dc <spin_92+0x1588>
   7b408:	aa1f03ea 	mov	x10, xzr
   7b40c:	aa1f03ed 	mov	x13, xzr
   7b410:	14000024 	b	7b4a0 <spin_92+0x64c>
   7b414:	b94005aa 	ldr	w10, [x13, #4]
   7b418:	b94001ac 	ldr	w12, [x13]
   7b41c:	92405d8e 	and	x14, x12, #0xffffff
   7b420:	f10005df 	cmp	x14, #0x1
   7b424:	5400e3a1 	b.ne	7d098 <spin_92+0x2244>  // b.any
   7b428:	aa0a818a 	orr	x10, x12, x10, lsl #32
   7b42c:	88dffdbf 	ldar	wzr, [x13]
   7b430:	f9400330 	ldr	x16, [x25]
   7b434:	d358fd4c 	lsr	x12, x10, #24
   7b438:	8b0c0f4e 	add	x14, x26, x12, lsl #3
   7b43c:	f94001ca 	ldr	x10, [x14]
   7b440:	b94009cd 	ldr	w13, [x14, #8]
   7b444:	f8287b50 	str	x16, [x26, x8, lsl #3]
   7b448:	f940832e 	ldr	x14, [x25, #256]
   7b44c:	39483070 	ldrb	w16, [x3, #524]
   7b450:	f9000328 	str	x8, [x25]
   7b454:	910005c8 	add	x8, x14, #0x1
   7b458:	7100061f 	cmp	w16, #0x1
   7b45c:	f9008328 	str	x8, [x25, #256]
   7b460:	5400ed21 	b.ne	7d204 <spin_92+0x23b0>  // b.any
   7b464:	f140211f 	cmp	x8, #0x8, lsl #12
   7b468:	5400ece2 	b.cs	7d204 <spin_92+0x23b0>  // b.hs, b.nlast
   7b46c:	eb01019f 	cmp	x12, x1
   7b470:	54000189 	b.ls	7b4a0 <spin_92+0x64c>  // b.plast
   7b474:	f9400728 	ldr	x8, [x25, #8]
   7b478:	3948306e 	ldrb	w14, [x3, #524]
   7b47c:	f82c7b48 	str	x8, [x26, x12, lsl #3]
   7b480:	f9408728 	ldr	x8, [x25, #264]
   7b484:	710005df 	cmp	w14, #0x1
   7b488:	f900072c 	str	x12, [x25, #8]
   7b48c:	91000908 	add	x8, x8, #0x2
   7b490:	f9008728 	str	x8, [x25, #264]
   7b494:	5400d581 	b.ne	7cf44 <spin_92+0x20f0>  // b.any
   7b498:	f140211f 	cmp	x8, #0x8, lsl #12
   7b49c:	5400d542 	b.cs	7cf44 <spin_92+0x20f0>  // b.hs, b.nlast
   7b4a0:	eb09015f 	cmp	x10, x9
   7b4a4:	54000400 	b.eq	7b524 <spin_92+0x6d0>  // b.none
   7b4a8:	f85f03a8 	ldur	x8, [x29, #-16]
   7b4ac:	f9401feb 	ldr	x11, [sp, #56]
   7b4b0:	eb08015f 	cmp	x10, x8
   7b4b4:	54000380 	b.eq	7b524 <spin_92+0x6d0>  // b.none
   7b4b8:	eb1b015f 	cmp	x10, x27
   7b4bc:	aa1c03eb 	mov	x11, x28
   7b4c0:	54000320 	b.eq	7b524 <spin_92+0x6d0>  // b.none
   7b4c4:	f85e83a8 	ldur	x8, [x29, #-24]
   7b4c8:	f9404feb 	ldr	x11, [sp, #152]
   7b4cc:	eb08015f 	cmp	x10, x8
   7b4d0:	540002a0 	b.eq	7b524 <spin_92+0x6d0>  // b.none
   7b4d4:	f85e03a8 	ldur	x8, [x29, #-32]
   7b4d8:	f9401beb 	ldr	x11, [sp, #48]
   7b4dc:	eb08015f 	cmp	x10, x8
   7b4e0:	54000220 	b.eq	7b524 <spin_92+0x6d0>  // b.none
   7b4e4:	f85c83a8 	ldur	x8, [x29, #-56]
   7b4e8:	f94013eb 	ldr	x11, [sp, #32]
   7b4ec:	eb08015f 	cmp	x10, x8
   7b4f0:	540001a0 	b.eq	7b524 <spin_92+0x6d0>  // b.none
   7b4f4:	f85c03a8 	ldur	x8, [x29, #-64]
   7b4f8:	f9400beb 	ldr	x11, [sp, #16]
   7b4fc:	eb08015f 	cmp	x10, x8
   7b500:	54000120 	b.eq	7b524 <spin_92+0x6d0>  // b.none
   7b504:	f85b83a8 	ldur	x8, [x29, #-72]
   7b508:	f94007eb 	ldr	x11, [sp, #8]
   7b50c:	eb08015f 	cmp	x10, x8
   7b510:	540000a0 	b.eq	7b524 <spin_92+0x6d0>  // b.none
   7b514:	92409d4b 	and	x11, x10, #0xffffffffff
   7b518:	b6f8006a 	tbz	x10, #63, 7b524 <spin_92+0x6d0>
   7b51c:	f86b7b48 	ldr	x8, [x26, x11, lsl #3]
   7b520:	d358fd0b 	lsr	x11, x8, #24
   7b524:	f81d03b4 	stur	x20, [x29, #-48]
   7b528:	b40007f4 	cbz	x20, 7b624 <spin_92+0x7d0>
   7b52c:	d368fd48 	lsr	x8, x10, #40
   7b530:	8b0b0f4c 	add	x12, x26, x11, lsl #3
   7b534:	1280000b 	mov	w11, #0xffffffff            	// #-1
   7b538:	f258115f 	tst	x10, #0x1f0000000000
   7b53c:	ad3a07a2 	stp	q2, q1, [x29, #-192]
   7b540:	1ac82168 	lsl	w8, w11, w8
   7b544:	1a9f07ee 	cset	w14, ne	// ne = any
   7b548:	b9400196 	ldr	w22, [x12]
   7b54c:	f940072b 	ldr	x11, [x25, #8]
   7b550:	b86e599c 	ldr	w28, [x12, w14, uxtw #2]
   7b554:	2a2803e8 	mvn	w8, w8
   7b558:	927f0110 	and	x16, x8, #0x2
   7b55c:	92400508 	and	x8, x8, #0x3
   7b560:	b870798e 	ldr	w14, [x12, x16, lsl #2]
   7b564:	b8687994 	ldr	w20, [x12, x8, lsl #2]
   7b568:	b400990b 	cbz	x11, 7c888 <spin_92+0x1a34>
   7b56c:	f86b7b48 	ldr	x8, [x26, x11, lsl #3]
   7b570:	f940872c 	ldr	x12, [x25, #264]
   7b574:	f9000728 	str	x8, [x25, #8]
   7b578:	d1000988 	sub	x8, x12, #0x2
   7b57c:	f9008728 	str	x8, [x25, #264]
   7b580:	d378fd48 	lsr	x8, x10, #56
   7b584:	aa0a03e0 	mov	x0, x10
   7b588:	f100091f 	cmp	x8, #0x2
   7b58c:	540099a0 	b.eq	7c8c0 <spin_92+0x1a6c>  // b.none
   7b590:	8b0b0f48 	add	x8, x26, x11, lsl #3
   7b594:	a9003500 	stp	x0, x13, [x8]
   7b598:	f9400f2c 	ldr	x12, [x25, #24]
   7b59c:	b4009aec 	cbz	x12, 7c8f8 <spin_92+0x1aa4>
   7b5a0:	f86c7b48 	ldr	x8, [x26, x12, lsl #3]
   7b5a4:	f9408f30 	ldr	x16, [x25, #280]
   7b5a8:	f9000f28 	str	x8, [x25, #24]
   7b5ac:	d1002208 	sub	x8, x16, #0x8
   7b5b0:	f9008f28 	str	x8, [x25, #280]
   7b5b4:	8b0c0f48 	add	x8, x26, x12, lsl #3
   7b5b8:	a901510e 	stp	x14, x20, [x8, #16]
   7b5bc:	d2c4400e 	mov	x14, #0x220000000000        	// #37383395344384
   7b5c0:	f2e0400e 	movk	x14, #0x200, lsl #48
   7b5c4:	a9007116 	stp	x22, x28, [x8]
   7b5c8:	aa0e0162 	orr	x2, x11, x14
   7b5cc:	f900110d 	str	x13, [x8, #32]
   7b5d0:	b6f800ab 	tbz	x11, #63, 7b5e4 <spin_92+0x790>
   7b5d4:	eb0a005f 	cmp	x2, x10
   7b5d8:	54000060 	b.eq	7b5e4 <spin_92+0x790>  // b.none
   7b5dc:	92409d68 	and	x8, x11, #0xffffffffff
   7b5e0:	f8687b5f 	ldr	xzr, [x26, x8, lsl #3]
   7b5e4:	d2c52008 	mov	x8, #0x290000000000        	// #45079976738816
   7b5e8:	f85d03b4 	ldur	x20, [x29, #-48]
   7b5ec:	f2e04008 	movk	x8, #0x200, lsl #48
   7b5f0:	aa08018d 	orr	x13, x12, x8
   7b5f4:	b6f800ac 	tbz	x12, #63, 7b608 <spin_92+0x7b4>
   7b5f8:	eb0a01bf 	cmp	x13, x10
   7b5fc:	54000060 	b.eq	7b608 <spin_92+0x7b4>  // b.none
   7b600:	92409d88 	and	x8, x12, #0xffffffffff
   7b604:	f8687b5f 	ldr	xzr, [x26, x8, lsl #3]
   7b608:	92409d68 	and	x8, x11, #0xffffffffff
   7b60c:	8b080f50 	add	x16, x26, x8, lsl #3
   7b610:	b7f8016b 	tbnz	x11, #63, 7b63c <spin_92+0x7e8>
   7b614:	f940020b 	ldr	x11, [x16]
   7b618:	b9400a1c 	ldr	w28, [x16, #8]
   7b61c:	aa0803ee 	mov	x14, x8
   7b620:	1400002a 	b	7b6c8 <spin_92+0x874>
   7b624:	aa1f03f6 	mov	x22, xzr
   7b628:	aa1f03fc 	mov	x28, xzr
   7b62c:	6f00e403 	movi	v3.2d, #0x0
   7b630:	6f00e404 	movi	v4.2d, #0x0
   7b634:	aa1f03eb 	mov	x11, xzr
   7b638:	14000073 	b	7b804 <spin_92+0x9b0>
   7b63c:	b940060b 	ldr	w11, [x16, #4]
   7b640:	b940020e 	ldr	w14, [x16]
   7b644:	aa1103f6 	mov	x22, x17
   7b648:	aa1303f7 	mov	x23, x19
   7b64c:	aa1803f3 	mov	x19, x24
   7b650:	aa0f03f8 	mov	x24, x15
   7b654:	92405dd1 	and	x17, x14, #0xffffff
   7b658:	aa1203ef 	mov	x15, x18
   7b65c:	f100063f 	cmp	x17, #0x1
   7b660:	5400d421 	b.ne	7d0e4 <spin_92+0x2290>  // b.any
   7b664:	aa0b81cb 	orr	x11, x14, x11, lsl #32
   7b668:	88dffe1f 	ldar	wzr, [x16]
   7b66c:	f9400330 	ldr	x16, [x25]
   7b670:	d358fd6e 	lsr	x14, x11, #24
   7b674:	8b0e0f51 	add	x17, x26, x14, lsl #3
   7b678:	f940022b 	ldr	x11, [x17]
   7b67c:	b9400a3c 	ldr	w28, [x17, #8]
   7b680:	f8287b50 	str	x16, [x26, x8, lsl #3]
   7b684:	f9408330 	ldr	x16, [x25, #256]
   7b688:	39483071 	ldrb	w17, [x3, #524]
   7b68c:	f9000328 	str	x8, [x25]
   7b690:	91000608 	add	x8, x16, #0x1
   7b694:	7100063f 	cmp	w17, #0x1
   7b698:	f9008328 	str	x8, [x25, #256]
   7b69c:	5400dd01 	b.ne	7d23c <spin_92+0x23e8>  // b.any
   7b6a0:	f140211f 	cmp	x8, #0x8, lsl #12
   7b6a4:	5400dcc2 	b.cs	7d23c <spin_92+0x23e8>  // b.hs, b.nlast
   7b6a8:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   7b6ac:	aa0f03f2 	mov	x18, x15
   7b6b0:	aa1803ef 	mov	x15, x24
   7b6b4:	aa1303f8 	mov	x24, x19
   7b6b8:	aa1703f3 	mov	x19, x23
   7b6bc:	d2c1c017 	mov	x23, #0xe0000000000         	// #15393162788864
   7b6c0:	aa1603f1 	mov	x17, x22
   7b6c4:	f2e02017 	movk	x23, #0x100, lsl #48
   7b6c8:	eb0101df 	cmp	x14, x1
   7b6cc:	54000189 	b.ls	7b6fc <spin_92+0x8a8>  // b.plast
   7b6d0:	f9400728 	ldr	x8, [x25, #8]
   7b6d4:	39483070 	ldrb	w16, [x3, #524]
   7b6d8:	f82e7b48 	str	x8, [x26, x14, lsl #3]
   7b6dc:	f9408728 	ldr	x8, [x25, #264]
   7b6e0:	7100061f 	cmp	w16, #0x1
   7b6e4:	f900072e 	str	x14, [x25, #8]
   7b6e8:	91000908 	add	x8, x8, #0x2
   7b6ec:	f9008728 	str	x8, [x25, #264]
   7b6f0:	5400c3a1 	b.ne	7cf64 <spin_92+0x2110>  // b.any
   7b6f4:	f140211f 	cmp	x8, #0x8, lsl #12
   7b6f8:	5400c362 	b.cs	7cf64 <spin_92+0x2110>  // b.hs, b.nlast
   7b6fc:	92409d88 	and	x8, x12, #0xffffffffff
   7b700:	8b080f4e 	add	x14, x26, x8, lsl #3
   7b704:	b7f800ac 	tbnz	x12, #63, 7b718 <spin_92+0x8c4>
   7b708:	ad4011c3 	ldp	q3, q4, [x14]
   7b70c:	aa0803ec 	mov	x12, x8
   7b710:	b94021d6 	ldr	w22, [x14, #32]
   7b714:	1400002c 	b	7b7c4 <spin_92+0x970>
   7b718:	f9005be9 	str	x9, [sp, #176]
   7b71c:	aa1303f7 	mov	x23, x19
   7b720:	aa1103f3 	mov	x19, x17
   7b724:	b94005cc 	ldr	w12, [x14, #4]
   7b728:	b94001d1 	ldr	w17, [x14]
   7b72c:	aa0b03e9 	mov	x9, x11
   7b730:	aa1803eb 	mov	x11, x24
   7b734:	aa0f03f8 	mov	x24, x15
   7b738:	aa1c03ef 	mov	x15, x28
   7b73c:	92405e30 	and	x16, x17, #0xffffff
   7b740:	f100061f 	cmp	x16, #0x1
   7b744:	54000041 	b.ne	7b74c <spin_92+0x8f8>  // b.any
   7b748:	88dffddf 	ldar	wzr, [x14]
   7b74c:	aa0c822c 	orr	x12, x17, x12, lsl #32
   7b750:	aa1203fc 	mov	x28, x18
   7b754:	f100061f 	cmp	x16, #0x1
   7b758:	d358fd8c 	lsr	x12, x12, #24
   7b75c:	8b0c0f51 	add	x17, x26, x12, lsl #3
   7b760:	ad401223 	ldp	q3, q4, [x17]
   7b764:	b9402236 	ldr	w22, [x17, #32]
   7b768:	5400ce81 	b.ne	7d138 <spin_92+0x22e4>  // b.any
   7b76c:	f940032d 	ldr	x13, [x25]
   7b770:	f90001cd 	str	x13, [x14]
   7b774:	3948306e 	ldrb	w14, [x3, #524]
   7b778:	f940832d 	ldr	x13, [x25, #256]
   7b77c:	f9000328 	str	x8, [x25]
   7b780:	710005df 	cmp	w14, #0x1
   7b784:	910005a8 	add	x8, x13, #0x1
   7b788:	f9008328 	str	x8, [x25, #256]
   7b78c:	5400d681 	b.ne	7d25c <spin_92+0x2408>  // b.any
   7b790:	f140211f 	cmp	x8, #0x8, lsl #12
   7b794:	5400d642 	b.cs	7d25c <spin_92+0x2408>  // b.hs, b.nlast
   7b798:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   7b79c:	aa1303f1 	mov	x17, x19
   7b7a0:	aa1703f3 	mov	x19, x23
   7b7a4:	d2c1c017 	mov	x23, #0xe0000000000         	// #15393162788864
   7b7a8:	aa1c03f2 	mov	x18, x28
   7b7ac:	aa0f03fc 	mov	x28, x15
   7b7b0:	aa1803ef 	mov	x15, x24
   7b7b4:	aa0b03f8 	mov	x24, x11
   7b7b8:	aa0903eb 	mov	x11, x9
   7b7bc:	f9405be9 	ldr	x9, [sp, #176]
   7b7c0:	f2e02017 	movk	x23, #0x100, lsl #48
   7b7c4:	eb01019f 	cmp	x12, x1
   7b7c8:	54000189 	b.ls	7b7f8 <spin_92+0x9a4>  // b.plast
   7b7cc:	f9400f28 	ldr	x8, [x25, #24]
   7b7d0:	3948306d 	ldrb	w13, [x3, #524]
   7b7d4:	f82c7b48 	str	x8, [x26, x12, lsl #3]
   7b7d8:	f9408f28 	ldr	x8, [x25, #280]
   7b7dc:	710005bf 	cmp	w13, #0x1
   7b7e0:	f9000f2c 	str	x12, [x25, #24]
   7b7e4:	91002108 	add	x8, x8, #0x8
   7b7e8:	f9008f28 	str	x8, [x25, #280]
   7b7ec:	5400bd61 	b.ne	7cf98 <spin_92+0x2144>  // b.any
   7b7f0:	f140211f 	cmp	x8, #0x8, lsl #12
   7b7f4:	5400bd22 	b.cs	7cf98 <spin_92+0x2144>  // b.hs, b.nlast
   7b7f8:	6f00e5e0 	movi	v0.2d, #0xffffffff
   7b7fc:	4e201c63 	and	v3.16b, v3.16b, v0.16b
   7b800:	4e201c84 	and	v4.16b, v4.16b, v0.16b
   7b804:	f9400b2c 	ldr	x12, [x25, #16]
   7b808:	b4005f2c 	cbz	x12, 7c3ec <spin_92+0x1598>
   7b80c:	f86c7b48 	ldr	x8, [x26, x12, lsl #3]
   7b810:	f9408b2d 	ldr	x13, [x25, #272]
   7b814:	f9000b28 	str	x8, [x25, #16]
   7b818:	d10011a8 	sub	x8, x13, #0x4
   7b81c:	f9008b28 	str	x8, [x25, #272]
   7b820:	d378fd28 	lsr	x8, x9, #56
   7b824:	aa0903e0 	mov	x0, x9
   7b828:	f100091f 	cmp	x8, #0x2
   7b82c:	54006020 	b.eq	7c430 <spin_92+0x15dc>  // b.none
   7b830:	8b0c0f48 	add	x8, x26, x12, lsl #3
   7b834:	a9004500 	stp	x0, x17, [x8]
   7b838:	f9000912 	str	x18, [x8, #16]
   7b83c:	f9400f2e 	ldr	x14, [x25, #24]
   7b840:	b40061ae 	cbz	x14, 7c474 <spin_92+0x1620>
   7b844:	f86e7b48 	ldr	x8, [x26, x14, lsl #3]
   7b848:	f9408f2d 	ldr	x13, [x25, #280]
   7b84c:	f9000f28 	str	x8, [x25, #24]
   7b850:	d10021a8 	sub	x8, x13, #0x8
   7b854:	f9008f28 	str	x8, [x25, #280]
   7b858:	6f00e5e0 	movi	v0.2d, #0xffffffff
   7b85c:	8b0e0f48 	add	x8, x26, x14, lsl #3
   7b860:	f900010f 	str	x15, [x8]
   7b864:	f9001518 	str	x24, [x8, #40]
   7b868:	4e201c21 	and	v1.16b, v1.16b, v0.16b
   7b86c:	4e201c40 	and	v0.16b, v2.16b, v0.16b
   7b870:	3c808101 	stur	q1, [x8, #8]
   7b874:	3c818100 	stur	q0, [x8, #24]
   7b878:	f940072d 	ldr	x13, [x25, #8]
   7b87c:	b400616d 	cbz	x13, 7c4a8 <spin_92+0x1654>
   7b880:	f86d7b48 	ldr	x8, [x26, x13, lsl #3]
   7b884:	f9408730 	ldr	x16, [x25, #264]
   7b888:	f9000728 	str	x8, [x25, #8]
   7b88c:	d1000a08 	sub	x8, x16, #0x2
   7b890:	f9008728 	str	x8, [x25, #264]
   7b894:	d2c40008 	mov	x8, #0x200000000000        	// #35184372088832
   7b898:	f2e04008 	movk	x8, #0x200, lsl #48
   7b89c:	aa080182 	orr	x2, x12, x8
   7b8a0:	d378fc48 	lsr	x8, x2, #56
   7b8a4:	f100091f 	cmp	x8, #0x2
   7b8a8:	540061a0 	b.eq	7c4dc <spin_92+0x1688>  // b.none
   7b8ac:	d2c42008 	mov	x8, #0x210000000000        	// #36283883716608
   7b8b0:	8b0d0f4c 	add	x12, x26, x13, lsl #3
   7b8b4:	f2e04008 	movk	x8, #0x200, lsl #48
   7b8b8:	aa0801c8 	orr	x8, x14, x8
   7b8bc:	f9000182 	str	x2, [x12]
   7b8c0:	d378fd0e 	lsr	x14, x8, #56
   7b8c4:	f10009df 	cmp	x14, #0x2
   7b8c8:	54006240 	b.eq	7c510 <spin_92+0x16bc>  // b.none
   7b8cc:	f9000588 	str	x8, [x12, #8]
   7b8d0:	f9400f2c 	ldr	x12, [x25, #24]
   7b8d4:	b40063ac 	cbz	x12, 7c548 <spin_92+0x16f4>
   7b8d8:	f86c7b48 	ldr	x8, [x26, x12, lsl #3]
   7b8dc:	f9408f2e 	ldr	x14, [x25, #280]
   7b8e0:	f9000f28 	str	x8, [x25, #24]
   7b8e4:	d10021c8 	sub	x8, x14, #0x8
   7b8e8:	f9008f28 	str	x8, [x25, #280]
   7b8ec:	8b0c0f48 	add	x8, x26, x12, lsl #3
   7b8f0:	f900010f 	str	x15, [x8]
   7b8f4:	3c808101 	stur	q1, [x8, #8]
   7b8f8:	3c818100 	stur	q0, [x8, #24]
   7b8fc:	f9001518 	str	x24, [x8, #40]
   7b900:	b4000594 	cbz	x20, 7b9b0 <spin_92+0xb5c>
   7b904:	f940072e 	ldr	x14, [x25, #8]
   7b908:	b400814e 	cbz	x14, 7c930 <spin_92+0x1adc>
   7b90c:	f86e7b48 	ldr	x8, [x26, x14, lsl #3]
   7b910:	f940872f 	ldr	x15, [x25, #264]
   7b914:	f9000728 	str	x8, [x25, #8]
   7b918:	d10009e8 	sub	x8, x15, #0x2
   7b91c:	f9008728 	str	x8, [x25, #264]
   7b920:	d378fd68 	lsr	x8, x11, #56
   7b924:	f100091f 	cmp	x8, #0x2
   7b928:	540081a0 	b.eq	7c95c <spin_92+0x1b08>  // b.none
   7b92c:	8b0e0f48 	add	x8, x26, x14, lsl #3
   7b930:	a900710b 	stp	x11, x28, [x8]
   7b934:	f940032b 	ldr	x11, [x25]
   7b938:	b40082ab 	cbz	x11, 7c98c <spin_92+0x1b38>
   7b93c:	f86b7b48 	ldr	x8, [x26, x11, lsl #3]
   7b940:	f940832f 	ldr	x15, [x25, #256]
   7b944:	f9000328 	str	x8, [x25]
   7b948:	d10005e8 	sub	x8, x15, #0x1
   7b94c:	f9008328 	str	x8, [x25, #256]
   7b950:	d2c44008 	mov	x8, #0x220000000000        	// #37383395344384
   7b954:	f2e04008 	movk	x8, #0x200, lsl #48
   7b958:	aa0801c2 	orr	x2, x14, x8
   7b95c:	d378fc48 	lsr	x8, x2, #56
   7b960:	f100091f 	cmp	x8, #0x2
   7b964:	540082a0 	b.eq	7c9b8 <spin_92+0x1b64>  // b.none
   7b968:	f82b7b42 	str	x2, [x26, x11, lsl #3]
   7b96c:	f9400f20 	ldr	x0, [x25, #24]
   7b970:	b40083a0 	cbz	x0, 7c9e4 <spin_92+0x1b90>
   7b974:	f8607b48 	ldr	x8, [x26, x0, lsl #3]
   7b978:	f9408f2e 	ldr	x14, [x25, #280]
   7b97c:	f9000f28 	str	x8, [x25, #24]
   7b980:	d10021c8 	sub	x8, x14, #0x8
   7b984:	f9008f28 	str	x8, [x25, #280]
   7b988:	8b000f48 	add	x8, x26, x0, lsl #3
   7b98c:	d2c1200e 	mov	x14, #0x90000000000         	// #9895604649984
   7b990:	f2e0400e 	movk	x14, #0x200, lsl #48
   7b994:	ad001103 	stp	q3, q4, [x8]
   7b998:	aa0e016f 	orr	x15, x11, x14
   7b99c:	f9001116 	str	x22, [x8, #32]
   7b9a0:	d2c52008 	mov	x8, #0x290000000000        	// #45079976738816
   7b9a4:	f2e04008 	movk	x8, #0x200, lsl #48
   7b9a8:	aa08000b 	orr	x11, x0, x8
   7b9ac:	14000004 	b	7b9bc <spin_92+0xb68>
   7b9b0:	d2c1000f 	mov	x15, #0x80000000000         	// #8796093022208
   7b9b4:	aa1f03eb 	mov	x11, xzr
   7b9b8:	f2e0200f 	movk	x15, #0x100, lsl #48
   7b9bc:	d2c3e008 	mov	x8, #0x1f0000000000        	// #34084860461056
   7b9c0:	d2c10016 	mov	x22, #0x80000000000         	// #8796093022208
   7b9c4:	f2e04008 	movk	x8, #0x200, lsl #48
   7b9c8:	aa0801a2 	orr	x2, x13, x8
   7b9cc:	eb09005f 	cmp	x2, x9
   7b9d0:	540000c0 	b.eq	7b9e8 <spin_92+0xb94>  // b.none
   7b9d4:	eb0a005f 	cmp	x2, x10
   7b9d8:	54000080 	b.eq	7b9e8 <spin_92+0xb94>  // b.none
   7b9dc:	b6f8006d 	tbz	x13, #63, 7b9e8 <spin_92+0xb94>
   7b9e0:	92409da8 	and	x8, x13, #0xffffffffff
   7b9e4:	f8687b5f 	ldr	xzr, [x26, x8, lsl #3]
   7b9e8:	d2c42008 	mov	x8, #0x210000000000        	// #36283883716608
   7b9ec:	f2e04008 	movk	x8, #0x200, lsl #48
   7b9f0:	aa08018e 	orr	x14, x12, x8
   7b9f4:	b6f800ec 	tbz	x12, #63, 7ba10 <spin_92+0xbbc>
   7b9f8:	eb0901df 	cmp	x14, x9
   7b9fc:	540000a0 	b.eq	7ba10 <spin_92+0xbbc>  // b.none
   7ba00:	eb0a01df 	cmp	x14, x10
   7ba04:	54000060 	b.eq	7ba10 <spin_92+0xbbc>  // b.none
   7ba08:	92409d88 	and	x8, x12, #0xffffffffff
   7ba0c:	f8687b5f 	ldr	xzr, [x26, x8, lsl #3]
   7ba10:	b6f800ef 	tbz	x15, #63, 7ba2c <spin_92+0xbd8>
   7ba14:	eb0901ff 	cmp	x15, x9
   7ba18:	540000a0 	b.eq	7ba2c <spin_92+0xbd8>  // b.none
   7ba1c:	eb0a01ff 	cmp	x15, x10
   7ba20:	54000060 	b.eq	7ba2c <spin_92+0xbd8>  // b.none
   7ba24:	92409de8 	and	x8, x15, #0xffffffffff
   7ba28:	f8687b5f 	ldr	xzr, [x26, x8, lsl #3]
   7ba2c:	f90053ee 	str	x14, [sp, #160]
   7ba30:	b6f800eb 	tbz	x11, #63, 7ba4c <spin_92+0xbf8>
   7ba34:	eb09017f 	cmp	x11, x9
   7ba38:	540000a0 	b.eq	7ba4c <spin_92+0xbf8>  // b.none
   7ba3c:	eb0a017f 	cmp	x11, x10
   7ba40:	54000060 	b.eq	7ba4c <spin_92+0xbf8>  // b.none
   7ba44:	92409d68 	and	x8, x11, #0xffffffffff
   7ba48:	f8687b5f 	ldr	xzr, [x26, x8, lsl #3]
   7ba4c:	92409da8 	and	x8, x13, #0xffffffffff
   7ba50:	8b080f50 	add	x16, x26, x8, lsl #3
   7ba54:	b7f8008d 	tbnz	x13, #63, 7ba64 <spin_92+0xc10>
   7ba58:	a940621c 	ldp	x28, x24, [x16]
   7ba5c:	aa0803ed 	mov	x13, x8
   7ba60:	14000016 	b	7bab8 <spin_92+0xc64>
   7ba64:	b940060d 	ldr	w13, [x16, #4]
   7ba68:	b9400211 	ldr	w17, [x16]
   7ba6c:	92405e32 	and	x18, x17, #0xffffff
   7ba70:	f100065f 	cmp	x18, #0x1
   7ba74:	54009281 	b.ne	7ccc4 <spin_92+0x1e70>  // b.any
   7ba78:	aa0d822d 	orr	x13, x17, x13, lsl #32
   7ba7c:	88dffe1f 	ldar	wzr, [x16]
   7ba80:	f9400330 	ldr	x16, [x25]
   7ba84:	d358fdad 	lsr	x13, x13, #24
   7ba88:	8b0d0f51 	add	x17, x26, x13, lsl #3
   7ba8c:	a940623c 	ldp	x28, x24, [x17]
   7ba90:	f8287b50 	str	x16, [x26, x8, lsl #3]
   7ba94:	f9408330 	ldr	x16, [x25, #256]
   7ba98:	39483071 	ldrb	w17, [x3, #524]
   7ba9c:	f9000328 	str	x8, [x25]
   7baa0:	91000608 	add	x8, x16, #0x1
   7baa4:	7100063f 	cmp	w17, #0x1
   7baa8:	f9008328 	str	x8, [x25, #256]
   7baac:	54009de1 	b.ne	7ce68 <spin_92+0x2014>  // b.any
   7bab0:	f140211f 	cmp	x8, #0x8, lsl #12
   7bab4:	54009da2 	b.cs	7ce68 <spin_92+0x2014>  // b.hs, b.nlast
   7bab8:	eb0101bf 	cmp	x13, x1
   7babc:	54000189 	b.ls	7baec <spin_92+0xc98>  // b.plast
   7bac0:	f9400728 	ldr	x8, [x25, #8]
   7bac4:	39483070 	ldrb	w16, [x3, #524]
   7bac8:	f82d7b48 	str	x8, [x26, x13, lsl #3]
   7bacc:	f9408728 	ldr	x8, [x25, #264]
   7bad0:	7100061f 	cmp	w16, #0x1
   7bad4:	f900072d 	str	x13, [x25, #8]
   7bad8:	91000908 	add	x8, x8, #0x2
   7badc:	f9008728 	str	x8, [x25, #264]
   7bae0:	54008281 	b.ne	7cb30 <spin_92+0x1cdc>  // b.any
   7bae4:	f140211f 	cmp	x8, #0x8, lsl #12
   7bae8:	54008242 	b.cs	7cb30 <spin_92+0x1cdc>  // b.hs, b.nlast
   7baec:	92409f88 	and	x8, x28, #0xffffffffff
   7baf0:	8b080f50 	add	x16, x26, x8, lsl #3
   7baf4:	b7f800dc 	tbnz	x28, #63, 7bb0c <spin_92+0xcb8>
   7baf8:	f940020d 	ldr	x13, [x16]
   7bafc:	b9400a02 	ldr	w2, [x16, #8]
   7bb00:	aa0803f4 	mov	x20, x8
   7bb04:	b9401204 	ldr	w4, [x16, #16]
   7bb08:	14000018 	b	7bb68 <spin_92+0xd14>
   7bb0c:	b940060d 	ldr	w13, [x16, #4]
   7bb10:	b9400211 	ldr	w17, [x16]
   7bb14:	92405e32 	and	x18, x17, #0xffffff
   7bb18:	f100065f 	cmp	x18, #0x1
   7bb1c:	54008ec1 	b.ne	7ccf4 <spin_92+0x1ea0>  // b.any
   7bb20:	aa0d822d 	orr	x13, x17, x13, lsl #32
   7bb24:	88dffe1f 	ldar	wzr, [x16]
   7bb28:	f9400330 	ldr	x16, [x25]
   7bb2c:	d358fdb4 	lsr	x20, x13, #24
   7bb30:	8b140f51 	add	x17, x26, x20, lsl #3
   7bb34:	f940022d 	ldr	x13, [x17]
   7bb38:	b9400a22 	ldr	w2, [x17, #8]
   7bb3c:	b9401224 	ldr	w4, [x17, #16]
   7bb40:	f8287b50 	str	x16, [x26, x8, lsl #3]
   7bb44:	39483071 	ldrb	w17, [x3, #524]
   7bb48:	f9408330 	ldr	x16, [x25, #256]
   7bb4c:	f9000328 	str	x8, [x25]
   7bb50:	7100063f 	cmp	w17, #0x1
   7bb54:	91000608 	add	x8, x16, #0x1
   7bb58:	f9008328 	str	x8, [x25, #256]
   7bb5c:	54009961 	b.ne	7ce88 <spin_92+0x2034>  // b.any
   7bb60:	f140211f 	cmp	x8, #0x8, lsl #12
   7bb64:	54009922 	b.cs	7ce88 <spin_92+0x2034>  // b.hs, b.nlast
   7bb68:	eb01029f 	cmp	x20, x1
   7bb6c:	54000189 	b.ls	7bb9c <spin_92+0xd48>  // b.plast
   7bb70:	f9400b28 	ldr	x8, [x25, #16]
   7bb74:	39483070 	ldrb	w16, [x3, #524]
   7bb78:	f8347b48 	str	x8, [x26, x20, lsl #3]
   7bb7c:	f9408b28 	ldr	x8, [x25, #272]
   7bb80:	7100061f 	cmp	w16, #0x1
   7bb84:	f9000b34 	str	x20, [x25, #16]
   7bb88:	91001108 	add	x8, x8, #0x4
   7bb8c:	f9008b28 	str	x8, [x25, #272]
   7bb90:	54007da1 	b.ne	7cb44 <spin_92+0x1cf0>  // b.any
   7bb94:	f140211f 	cmp	x8, #0x8, lsl #12
   7bb98:	54007d62 	b.cs	7cb44 <spin_92+0x1cf0>  // b.hs, b.nlast
   7bb9c:	f85d03b4 	ldur	x20, [x29, #-48]
   7bba0:	92409f08 	and	x8, x24, #0xffffffffff
   7bba4:	8b080f50 	add	x16, x26, x8, lsl #3
   7bba8:	b7f800b8 	tbnz	x24, #63, 7bbbc <spin_92+0xd68>
   7bbac:	ad401201 	ldp	q1, q4, [x16]
   7bbb0:	aa0803fc 	mov	x28, x8
   7bbb4:	3dc00a03 	ldr	q3, [x16, #32]
   7bbb8:	14000019 	b	7bc1c <spin_92+0xdc8>
   7bbbc:	b9400612 	ldr	w18, [x16, #4]
   7bbc0:	b9400200 	ldr	w0, [x16]
   7bbc4:	92405c11 	and	x17, x0, #0xffffff
   7bbc8:	f100063f 	cmp	x17, #0x1
   7bbcc:	54000041 	b.ne	7bbd4 <spin_92+0xd80>  // b.any
   7bbd0:	88dffe1f 	ldar	wzr, [x16]
   7bbd4:	aa128012 	orr	x18, x0, x18, lsl #32
   7bbd8:	f100063f 	cmp	x17, #0x1
   7bbdc:	d358fe5c 	lsr	x28, x18, #24
   7bbe0:	8b1c0f52 	add	x18, x26, x28, lsl #3
   7bbe4:	ad401241 	ldp	q1, q4, [x18]
   7bbe8:	3dc00a43 	ldr	q3, [x18, #32]
   7bbec:	54008a81 	b.ne	7cd3c <spin_92+0x1ee8>  // b.any
   7bbf0:	f9400331 	ldr	x17, [x25]
   7bbf4:	f9000211 	str	x17, [x16]
   7bbf8:	39483071 	ldrb	w17, [x3, #524]
   7bbfc:	f9408330 	ldr	x16, [x25, #256]
   7bc00:	f9000328 	str	x8, [x25]
   7bc04:	7100063f 	cmp	w17, #0x1
   7bc08:	91000608 	add	x8, x16, #0x1
   7bc0c:	f9008328 	str	x8, [x25, #256]
   7bc10:	54009561 	b.ne	7cebc <spin_92+0x2068>  // b.any
   7bc14:	f140211f 	cmp	x8, #0x8, lsl #12
   7bc18:	54009522 	b.cs	7cebc <spin_92+0x2068>  // b.hs, b.nlast
   7bc1c:	eb01039f 	cmp	x28, x1
   7bc20:	54000189 	b.ls	7bc50 <spin_92+0xdfc>  // b.plast
   7bc24:	f9400f28 	ldr	x8, [x25, #24]
   7bc28:	39483070 	ldrb	w16, [x3, #524]
   7bc2c:	f83c7b48 	str	x8, [x26, x28, lsl #3]
   7bc30:	f9408f28 	ldr	x8, [x25, #280]
   7bc34:	7100061f 	cmp	w16, #0x1
   7bc38:	f9000f3c 	str	x28, [x25, #24]
   7bc3c:	91002108 	add	x8, x8, #0x8
   7bc40:	f9008f28 	str	x8, [x25, #280]
   7bc44:	54007981 	b.ne	7cb74 <spin_92+0x1d20>  // b.any
   7bc48:	f140211f 	cmp	x8, #0x8, lsl #12
   7bc4c:	54007942 	b.cs	7cb74 <spin_92+0x1d20>  // b.hs, b.nlast
   7bc50:	92583dfc 	and	x28, x15, #0xffff0000000000
   7bc54:	eb16039f 	cmp	x28, x22
   7bc58:	54000081 	b.ne	7bc68 <spin_92+0xe14>  // b.any
   7bc5c:	aa1f03ef 	mov	x15, xzr
   7bc60:	aa1f03f8 	mov	x24, xzr
   7bc64:	1400005c 	b	7bdd4 <spin_92+0xf80>
   7bc68:	92409de8 	and	x8, x15, #0xffffffffff
   7bc6c:	8b080f50 	add	x16, x26, x8, lsl #3
   7bc70:	b7f8008f 	tbnz	x15, #63, 7bc80 <spin_92+0xe2c>
   7bc74:	f9400218 	ldr	x24, [x16]
   7bc78:	aa0803ef 	mov	x15, x8
   7bc7c:	14000015 	b	7bcd0 <spin_92+0xe7c>
   7bc80:	b9400611 	ldr	w17, [x16, #4]
   7bc84:	b9400212 	ldr	w18, [x16]
   7bc88:	92405e40 	and	x0, x18, #0xffffff
   7bc8c:	f100041f 	cmp	x0, #0x1
   7bc90:	5400b3c1 	b.ne	7d308 <spin_92+0x24b4>  // b.any
   7bc94:	aa11824f 	orr	x15, x18, x17, lsl #32
   7bc98:	88dffe1f 	ldar	wzr, [x16]
   7bc9c:	f9400330 	ldr	x16, [x25]
   7bca0:	39483071 	ldrb	w17, [x3, #524]
   7bca4:	d358fdef 	lsr	x15, x15, #24
   7bca8:	7100063f 	cmp	w17, #0x1
   7bcac:	f86f7b58 	ldr	x24, [x26, x15, lsl #3]
   7bcb0:	f8287b50 	str	x16, [x26, x8, lsl #3]
   7bcb4:	f9408330 	ldr	x16, [x25, #256]
   7bcb8:	f9000328 	str	x8, [x25]
   7bcbc:	91000608 	add	x8, x16, #0x1
   7bcc0:	f9008328 	str	x8, [x25, #256]
   7bcc4:	5400b741 	b.ne	7d3ac <spin_92+0x2558>  // b.any
   7bcc8:	f140211f 	cmp	x8, #0x8, lsl #12
   7bccc:	5400b702 	b.cs	7d3ac <spin_92+0x2558>  // b.hs, b.nlast
   7bcd0:	eb0101ff 	cmp	x15, x1
   7bcd4:	54000189 	b.ls	7bd04 <spin_92+0xeb0>  // b.plast
   7bcd8:	f9400328 	ldr	x8, [x25]
   7bcdc:	39483070 	ldrb	w16, [x3, #524]
   7bce0:	f82f7b48 	str	x8, [x26, x15, lsl #3]
   7bce4:	f9408328 	ldr	x8, [x25, #256]
   7bce8:	7100061f 	cmp	w16, #0x1
   7bcec:	f900032f 	str	x15, [x25]
   7bcf0:	91000508 	add	x8, x8, #0x1
   7bcf4:	f9008328 	str	x8, [x25, #256]
   7bcf8:	54009961 	b.ne	7d024 <spin_92+0x21d0>  // b.any
   7bcfc:	f140211f 	cmp	x8, #0x8, lsl #12
   7bd00:	54009922 	b.cs	7d024 <spin_92+0x21d0>  // b.hs, b.nlast
   7bd04:	92409f08 	and	x8, x24, #0xffffffffff
   7bd08:	8b080f50 	add	x16, x26, x8, lsl #3
   7bd0c:	b7f800b8 	tbnz	x24, #63, 7bd20 <spin_92+0xecc>
   7bd10:	f940020f 	ldr	x15, [x16]
   7bd14:	b9400a18 	ldr	w24, [x16, #8]
   7bd18:	aa0803f4 	mov	x20, x8
   7bd1c:	14000020 	b	7bd9c <spin_92+0xf48>
   7bd20:	3d802fe4 	str	q4, [sp, #176]
   7bd24:	aa0403ee 	mov	x14, x4
   7bd28:	aa0203f6 	mov	x22, x2
   7bd2c:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   7bd30:	b940060f 	ldr	w15, [x16, #4]
   7bd34:	b9400211 	ldr	w17, [x16]
   7bd38:	92405e32 	and	x18, x17, #0xffffff
   7bd3c:	f100065f 	cmp	x18, #0x1
   7bd40:	5400b0c1 	b.ne	7d358 <spin_92+0x2504>  // b.any
   7bd44:	aa0f822f 	orr	x15, x17, x15, lsl #32
   7bd48:	88dffe1f 	ldar	wzr, [x16]
   7bd4c:	f9400330 	ldr	x16, [x25]
   7bd50:	d358fdf4 	lsr	x20, x15, #24
   7bd54:	8b140f51 	add	x17, x26, x20, lsl #3
   7bd58:	f940022f 	ldr	x15, [x17]
   7bd5c:	b9400a38 	ldr	w24, [x17, #8]
   7bd60:	f8287b50 	str	x16, [x26, x8, lsl #3]
   7bd64:	f9408330 	ldr	x16, [x25, #256]
   7bd68:	39483071 	ldrb	w17, [x3, #524]
   7bd6c:	f9000328 	str	x8, [x25]
   7bd70:	91000608 	add	x8, x16, #0x1
   7bd74:	7100063f 	cmp	w17, #0x1
   7bd78:	f9008328 	str	x8, [x25, #256]
   7bd7c:	5400b381 	b.ne	7d3ec <spin_92+0x2598>  // b.any
   7bd80:	f140211f 	cmp	x8, #0x8, lsl #12
   7bd84:	5400b342 	b.cs	7d3ec <spin_92+0x2598>  // b.hs, b.nlast
   7bd88:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   7bd8c:	aa1603e2 	mov	x2, x22
   7bd90:	3dc02fe4 	ldr	q4, [sp, #176]
   7bd94:	d2c10016 	mov	x22, #0x80000000000         	// #8796093022208
   7bd98:	aa0e03e4 	mov	x4, x14
   7bd9c:	eb01029f 	cmp	x20, x1
   7bda0:	54000189 	b.ls	7bdd0 <spin_92+0xf7c>  // b.plast
   7bda4:	f9400728 	ldr	x8, [x25, #8]
   7bda8:	39483070 	ldrb	w16, [x3, #524]
   7bdac:	f8347b48 	str	x8, [x26, x20, lsl #3]
   7bdb0:	f9408728 	ldr	x8, [x25, #264]
   7bdb4:	7100061f 	cmp	w16, #0x1
   7bdb8:	f9000734 	str	x20, [x25, #8]
   7bdbc:	91000908 	add	x8, x8, #0x2
   7bdc0:	f9008728 	str	x8, [x25, #264]
   7bdc4:	540094a1 	b.ne	7d058 <spin_92+0x2204>  // b.any
   7bdc8:	f140211f 	cmp	x8, #0x8, lsl #12
   7bdcc:	54009462 	b.cs	7d058 <spin_92+0x2204>  // b.hs, b.nlast
   7bdd0:	f85d03b4 	ldur	x20, [x29, #-48]
   7bdd4:	92409d88 	and	x8, x12, #0xffffffffff
   7bdd8:	8b080f50 	add	x16, x26, x8, lsl #3
   7bddc:	b7f800ac 	tbnz	x12, #63, 7bdf0 <spin_92+0xf9c>
   7bde0:	ad401e05 	ldp	q5, q7, [x16]
   7bde4:	aa0803ec 	mov	x12, x8
   7bde8:	3dc00a06 	ldr	q6, [x16, #32]
   7bdec:	14000024 	b	7be7c <spin_92+0x1028>
   7bdf0:	b940060c 	ldr	w12, [x16, #4]
   7bdf4:	b9400212 	ldr	w18, [x16]
   7bdf8:	aa1303f7 	mov	x23, x19
   7bdfc:	aa1803f3 	mov	x19, x24
   7be00:	92405e51 	and	x17, x18, #0xffffff
   7be04:	f100063f 	cmp	x17, #0x1
   7be08:	54000041 	b.ne	7be10 <spin_92+0xfbc>  // b.any
   7be0c:	88dffe1f 	ldar	wzr, [x16]
   7be10:	aa0c824c 	orr	x12, x18, x12, lsl #32
   7be14:	aa0403f8 	mov	x24, x4
   7be18:	aa0203f6 	mov	x22, x2
   7be1c:	f100063f 	cmp	x17, #0x1
   7be20:	d358fd8c 	lsr	x12, x12, #24
   7be24:	8b0c0f52 	add	x18, x26, x12, lsl #3
   7be28:	ad401e45 	ldp	q5, q7, [x18]
   7be2c:	3dc00a46 	ldr	q6, [x18, #32]
   7be30:	54007ac1 	b.ne	7cd88 <spin_92+0x1f34>  // b.any
   7be34:	f940032e 	ldr	x14, [x25]
   7be38:	f900020e 	str	x14, [x16]
   7be3c:	39483070 	ldrb	w16, [x3, #524]
   7be40:	f940832e 	ldr	x14, [x25, #256]
   7be44:	f9000328 	str	x8, [x25]
   7be48:	7100061f 	cmp	w16, #0x1
   7be4c:	910005c8 	add	x8, x14, #0x1
   7be50:	f9008328 	str	x8, [x25, #256]
   7be54:	54008561 	b.ne	7cf00 <spin_92+0x20ac>  // b.any
   7be58:	f140211f 	cmp	x8, #0x8, lsl #12
   7be5c:	54008522 	b.cs	7cf00 <spin_92+0x20ac>  // b.hs, b.nlast
   7be60:	aa1803e4 	mov	x4, x24
   7be64:	aa1303f8 	mov	x24, x19
   7be68:	aa1703f3 	mov	x19, x23
   7be6c:	d2c1c017 	mov	x23, #0xe0000000000         	// #15393162788864
   7be70:	aa1603e2 	mov	x2, x22
   7be74:	d2c10016 	mov	x22, #0x80000000000         	// #8796093022208
   7be78:	f2e02017 	movk	x23, #0x100, lsl #48
   7be7c:	eb01019f 	cmp	x12, x1
   7be80:	54000189 	b.ls	7beb0 <spin_92+0x105c>  // b.plast
   7be84:	f9400f28 	ldr	x8, [x25, #24]
   7be88:	3948306e 	ldrb	w14, [x3, #524]
   7be8c:	f82c7b48 	str	x8, [x26, x12, lsl #3]
   7be90:	f9408f28 	ldr	x8, [x25, #280]
   7be94:	710005df 	cmp	w14, #0x1
   7be98:	f9000f2c 	str	x12, [x25, #24]
   7be9c:	91002108 	add	x8, x8, #0x8
   7bea0:	f9008f28 	str	x8, [x25, #280]
   7bea4:	540068a1 	b.ne	7cbb8 <spin_92+0x1d64>  // b.any
   7bea8:	f140211f 	cmp	x8, #0x8, lsl #12
   7beac:	54006862 	b.cs	7cbb8 <spin_92+0x1d64>  // b.hs, b.nlast
   7beb0:	b4000114 	cbz	x20, 7bed0 <spin_92+0x107c>
   7beb4:	92409d68 	and	x8, x11, #0xffffffffff
   7beb8:	8b080f50 	add	x16, x26, x8, lsl #3
   7bebc:	b7f8012b 	tbnz	x11, #63, 7bee0 <spin_92+0x108c>
   7bec0:	ad404602 	ldp	q2, q17, [x16]
   7bec4:	aa0803ec 	mov	x12, x8
   7bec8:	b940220e 	ldr	w14, [x16, #32]
   7becc:	1400001d 	b	7bf40 <spin_92+0x10ec>
   7bed0:	6f00e410 	movi	v16.2d, #0x0
   7bed4:	6f00e411 	movi	v17.2d, #0x0
   7bed8:	aa1f03ee 	mov	x14, xzr
   7bedc:	14000029 	b	7bf80 <spin_92+0x112c>
   7bee0:	b940060c 	ldr	w12, [x16, #4]
   7bee4:	b940020e 	ldr	w14, [x16]
   7bee8:	92405dd1 	and	x17, x14, #0xffffff
   7beec:	f100063f 	cmp	x17, #0x1
   7bef0:	54000041 	b.ne	7bef8 <spin_92+0x10a4>  // b.any
   7bef4:	88dffe1f 	ldar	wzr, [x16]
   7bef8:	aa0c81cc 	orr	x12, x14, x12, lsl #32
   7befc:	f100063f 	cmp	x17, #0x1
   7bf00:	d358fd8c 	lsr	x12, x12, #24
   7bf04:	8b0c0f4e 	add	x14, x26, x12, lsl #3
   7bf08:	ad4045c2 	ldp	q2, q17, [x14]
   7bf0c:	b94021ce 	ldr	w14, [x14, #32]
   7bf10:	54009461 	b.ne	7d19c <spin_92+0x2348>  // b.any
   7bf14:	f940032b 	ldr	x11, [x25]
   7bf18:	f900020b 	str	x11, [x16]
   7bf1c:	39483070 	ldrb	w16, [x3, #524]
   7bf20:	f940832b 	ldr	x11, [x25, #256]
   7bf24:	f9000328 	str	x8, [x25]
   7bf28:	7100061f 	cmp	w16, #0x1
   7bf2c:	91000568 	add	x8, x11, #0x1
   7bf30:	f9008328 	str	x8, [x25, #256]
   7bf34:	54009ac1 	b.ne	7d28c <spin_92+0x2438>  // b.any
   7bf38:	f140211f 	cmp	x8, #0x8, lsl #12
   7bf3c:	54009a82 	b.cs	7d28c <spin_92+0x2438>  // b.hs, b.nlast
   7bf40:	eb01019f 	cmp	x12, x1
   7bf44:	54000189 	b.ls	7bf74 <spin_92+0x1120>  // b.plast
   7bf48:	f9400f28 	ldr	x8, [x25, #24]
   7bf4c:	3948306b 	ldrb	w11, [x3, #524]
   7bf50:	f82c7b48 	str	x8, [x26, x12, lsl #3]
   7bf54:	f9408f28 	ldr	x8, [x25, #280]
   7bf58:	7100057f 	cmp	w11, #0x1
   7bf5c:	f9000f2c 	str	x12, [x25, #24]
   7bf60:	91002108 	add	x8, x8, #0x8
   7bf64:	f9008f28 	str	x8, [x25, #280]
   7bf68:	540083a1 	b.ne	7cfdc <spin_92+0x2188>  // b.any
   7bf6c:	f140211f 	cmp	x8, #0x8, lsl #12
   7bf70:	54008362 	b.cs	7cfdc <spin_92+0x2188>  // b.hs, b.nlast
   7bf74:	6f00e5e0 	movi	v0.2d, #0xffffffff
   7bf78:	4e201c50 	and	v16.16b, v2.16b, v0.16b
   7bf7c:	4e201e31 	and	v17.16b, v17.16b, v0.16b
   7bf80:	f9400b2c 	ldr	x12, [x25, #16]
   7bf84:	b4002fcc 	cbz	x12, 7c57c <spin_92+0x1728>
   7bf88:	f86c7b48 	ldr	x8, [x26, x12, lsl #3]
   7bf8c:	f9408b2b 	ldr	x11, [x25, #272]
   7bf90:	f9000b28 	str	x8, [x25, #16]
   7bf94:	d1001168 	sub	x8, x11, #0x4
   7bf98:	f9008b28 	str	x8, [x25, #272]
   7bf9c:	d378fda8 	lsr	x8, x13, #56
   7bfa0:	f100091f 	cmp	x8, #0x2
   7bfa4:	540031c0 	b.eq	7c5dc <spin_92+0x1788>  // b.none
   7bfa8:	8b0c0f48 	add	x8, x26, x12, lsl #3
   7bfac:	a900090d 	stp	x13, x2, [x8]
   7bfb0:	f9000904 	str	x4, [x8, #16]
   7bfb4:	f9400f2d 	ldr	x13, [x25, #24]
   7bfb8:	b400344d 	cbz	x13, 7c640 <spin_92+0x17ec>
   7bfbc:	f86d7b48 	ldr	x8, [x26, x13, lsl #3]
   7bfc0:	f9408f2b 	ldr	x11, [x25, #280]
   7bfc4:	f9000f28 	str	x8, [x25, #24]
   7bfc8:	d1002168 	sub	x8, x11, #0x8
   7bfcc:	f9008f28 	str	x8, [x25, #280]
   7bfd0:	6f00e5e2 	movi	v2.2d, #0xffffffff
   7bfd4:	8b0d0f48 	add	x8, x26, x13, lsl #3
   7bfd8:	4e221c20 	and	v0.16b, v1.16b, v2.16b
   7bfdc:	4e221c81 	and	v1.16b, v4.16b, v2.16b
   7bfe0:	4e221c62 	and	v2.16b, v3.16b, v2.16b
   7bfe4:	ad000500 	stp	q0, q1, [x8]
   7bfe8:	3d800902 	str	q2, [x8, #32]
   7bfec:	f940072b 	ldr	x11, [x25, #8]
   7bff0:	b400350b 	cbz	x11, 7c690 <spin_92+0x183c>
   7bff4:	f86b7b48 	ldr	x8, [x26, x11, lsl #3]
   7bff8:	f9408730 	ldr	x16, [x25, #264]
   7bffc:	f9000728 	str	x8, [x25, #8]
   7c000:	d1000a08 	sub	x8, x16, #0x2
   7c004:	f9008728 	str	x8, [x25, #264]
   7c008:	d2c40008 	mov	x8, #0x200000000000        	// #35184372088832
   7c00c:	f2e04008 	movk	x8, #0x200, lsl #48
   7c010:	aa080182 	orr	x2, x12, x8
   7c014:	d378fc48 	lsr	x8, x2, #56
   7c018:	f100091f 	cmp	x8, #0x2
   7c01c:	540035c0 	b.eq	7c6d4 <spin_92+0x1880>  // b.none
   7c020:	d2c42008 	mov	x8, #0x210000000000        	// #36283883716608
   7c024:	8b0b0f4c 	add	x12, x26, x11, lsl #3
   7c028:	f2e04008 	movk	x8, #0x200, lsl #48
   7c02c:	aa0801a8 	orr	x8, x13, x8
   7c030:	f9000182 	str	x2, [x12]
   7c034:	d378fd0d 	lsr	x13, x8, #56
   7c038:	f10009bf 	cmp	x13, #0x2
   7c03c:	540036e0 	b.eq	7c718 <spin_92+0x18c4>  // b.none
   7c040:	eb16039f 	cmp	x28, x22
   7c044:	f9000588 	str	x8, [x12, #8]
   7c048:	54000081 	b.ne	7c058 <spin_92+0x1204>  // b.any
   7c04c:	aa1f03fc 	mov	x28, xzr
   7c050:	aa1f03f8 	mov	x24, xzr
   7c054:	14000011 	b	7c098 <spin_92+0x1244>
   7c058:	f940072c 	ldr	x12, [x25, #8]
   7c05c:	b4004ecc 	cbz	x12, 7ca34 <spin_92+0x1be0>
   7c060:	f86c7b48 	ldr	x8, [x26, x12, lsl #3]
   7c064:	f940872d 	ldr	x13, [x25, #264]
   7c068:	f9000728 	str	x8, [x25, #8]
   7c06c:	d10009a8 	sub	x8, x13, #0x2
   7c070:	f9008728 	str	x8, [x25, #264]
   7c074:	d378fde8 	lsr	x8, x15, #56
   7c078:	f100091f 	cmp	x8, #0x2
   7c07c:	54004fe0 	b.eq	7ca78 <spin_92+0x1c24>  // b.none
   7c080:	8b0c0f48 	add	x8, x26, x12, lsl #3
   7c084:	5280003c 	mov	w28, #0x1                   	// #1
   7c088:	a900610f 	stp	x15, x24, [x8]
   7c08c:	d2c44008 	mov	x8, #0x220000000000        	// #37383395344384
   7c090:	f2e04008 	movk	x8, #0x200, lsl #48
   7c094:	aa080198 	orr	x24, x12, x8
   7c098:	f9400f2d 	ldr	x13, [x25, #24]
   7c09c:	b400362d 	cbz	x13, 7c760 <spin_92+0x190c>
   7c0a0:	f86d7b48 	ldr	x8, [x26, x13, lsl #3]
   7c0a4:	f9408f2c 	ldr	x12, [x25, #280]
   7c0a8:	f9000f28 	str	x8, [x25, #24]
   7c0ac:	d1002188 	sub	x8, x12, #0x8
   7c0b0:	f9008f28 	str	x8, [x25, #280]
   7c0b4:	6f00e5e2 	movi	v2.2d, #0xffffffff
   7c0b8:	8b0d0f48 	add	x8, x26, x13, lsl #3
   7c0bc:	4e221ca0 	and	v0.16b, v5.16b, v2.16b
   7c0c0:	4e221ce1 	and	v1.16b, v7.16b, v2.16b
   7c0c4:	4e221cc2 	and	v2.16b, v6.16b, v2.16b
   7c0c8:	ad000500 	stp	q0, q1, [x8]
   7c0cc:	3d800902 	str	q2, [x8, #32]
   7c0d0:	b4000214 	cbz	x20, 7c110 <spin_92+0x12bc>
   7c0d4:	f9400f20 	ldr	x0, [x25, #24]
   7c0d8:	b40049a0 	cbz	x0, 7ca0c <spin_92+0x1bb8>
   7c0dc:	f8607b48 	ldr	x8, [x26, x0, lsl #3]
   7c0e0:	f9408f2c 	ldr	x12, [x25, #280]
   7c0e4:	f9000f28 	str	x8, [x25, #24]
   7c0e8:	d1002188 	sub	x8, x12, #0x8
   7c0ec:	f9008f28 	str	x8, [x25, #280]
   7c0f0:	8b000f48 	add	x8, x26, x0, lsl #3
   7c0f4:	52800034 	mov	w20, #0x1                   	// #1
   7c0f8:	ad004510 	stp	q16, q17, [x8]
   7c0fc:	f900110e 	str	x14, [x8, #32]
   7c100:	d2c52008 	mov	x8, #0x290000000000        	// #45079976738816
   7c104:	f2e04008 	movk	x8, #0x200, lsl #48
   7c108:	aa08000e 	orr	x14, x0, x8
   7c10c:	14000002 	b	7c114 <spin_92+0x12c0>
   7c110:	aa1f03ee 	mov	x14, xzr
   7c114:	a977bfac 	ldp	x12, x15, [x29, #-136]
   7c118:	d2c46008 	mov	x8, #0x230000000000        	// #38482906972160
   7c11c:	f2e02008 	movk	x8, #0x100, lsl #48
   7c120:	b3407d88 	bfxil	x8, x12, #0, #32
   7c124:	f9400f2c 	ldr	x12, [x25, #24]
   7c128:	f10001ff 	cmp	x15, #0x0
   7c12c:	1a9f07f6 	cset	w22, ne	// ne = any
   7c130:	9a9f110f 	csel	x15, x8, xzr, ne	// ne = any
   7c134:	b400338c 	cbz	x12, 7c7a4 <spin_92+0x1950>
   7c138:	f86c7b48 	ldr	x8, [x26, x12, lsl #3]
   7c13c:	f9408f30 	ldr	x16, [x25, #280]
   7c140:	f9000f28 	str	x8, [x25, #24]
   7c144:	d1002208 	sub	x8, x16, #0x8
   7c148:	f9008f28 	str	x8, [x25, #280]
   7c14c:	d2c42008 	mov	x8, #0x210000000000        	// #36283883716608
   7c150:	910006b0 	add	x16, x21, #0x1
   7c154:	f2e04008 	movk	x8, #0x200, lsl #48
   7c158:	aa0801a2 	orr	x2, x13, x8
   7c15c:	8b0c0f4d 	add	x13, x26, x12, lsl #3
   7c160:	d378fc48 	lsr	x8, x2, #56
   7c164:	f100091f 	cmp	x8, #0x2
   7c168:	f94037e8 	ldr	x8, [sp, #104]
   7c16c:	a90041a8 	stp	x8, x16, [x13]
   7c170:	540032c0 	b.eq	7c7c8 <spin_92+0x1974>  // b.none
   7c174:	d378fdc8 	lsr	x8, x14, #56
   7c178:	a90151a2 	stp	x2, x20, [x13, #16]
   7c17c:	f100091f 	cmp	x8, #0x2
   7c180:	54003360 	b.eq	7c7ec <spin_92+0x1998>  // b.none
   7c184:	d2c3e008 	mov	x8, #0x1f0000000000        	// #34084860461056
   7c188:	a90259ae 	stp	x14, x22, [x13, #32]
   7c18c:	f85f03ae 	ldur	x14, [x29, #-16]
   7c190:	f2e04008 	movk	x8, #0x200, lsl #48
   7c194:	f90019af 	str	x15, [x13, #48]
   7c198:	aa080168 	orr	x8, x11, x8
   7c19c:	eb0e011f 	cmp	x8, x14
   7c1a0:	54000320 	b.eq	7c204 <spin_92+0x13b0>  // b.none
   7c1a4:	eb09011f 	cmp	x8, x9
   7c1a8:	540002e0 	b.eq	7c204 <spin_92+0x13b0>  // b.none
   7c1ac:	f85c03ad 	ldur	x13, [x29, #-64]
   7c1b0:	eb0d011f 	cmp	x8, x13
   7c1b4:	54000280 	b.eq	7c204 <spin_92+0x13b0>  // b.none
   7c1b8:	f85c83ad 	ldur	x13, [x29, #-56]
   7c1bc:	eb0d011f 	cmp	x8, x13
   7c1c0:	54000220 	b.eq	7c204 <spin_92+0x13b0>  // b.none
   7c1c4:	f85e03ad 	ldur	x13, [x29, #-32]
   7c1c8:	eb0d011f 	cmp	x8, x13
   7c1cc:	540001c0 	b.eq	7c204 <spin_92+0x13b0>  // b.none
   7c1d0:	f85e83ad 	ldur	x13, [x29, #-24]
   7c1d4:	eb0d011f 	cmp	x8, x13
   7c1d8:	54000160 	b.eq	7c204 <spin_92+0x13b0>  // b.none
   7c1dc:	eb1b011f 	cmp	x8, x27
   7c1e0:	54000120 	b.eq	7c204 <spin_92+0x13b0>  // b.none
   7c1e4:	eb0a011f 	cmp	x8, x10
   7c1e8:	540000e0 	b.eq	7c204 <spin_92+0x13b0>  // b.none
   7c1ec:	f85b83ad 	ldur	x13, [x29, #-72]
   7c1f0:	eb0d011f 	cmp	x8, x13
   7c1f4:	54000080 	b.eq	7c204 <spin_92+0x13b0>  // b.none
   7c1f8:	b6f8006b 	tbz	x11, #63, 7c204 <spin_92+0x13b0>
   7c1fc:	92409d6b 	and	x11, x11, #0xffffffffff
   7c200:	f86b7b5f 	ldr	xzr, [x26, x11, lsl #3]
   7c204:	b6f80378 	tbz	x24, #63, 7c270 <spin_92+0x141c>
   7c208:	f85f03ab 	ldur	x11, [x29, #-16]
   7c20c:	eb0b031f 	cmp	x24, x11
   7c210:	54000300 	b.eq	7c270 <spin_92+0x141c>  // b.none
   7c214:	eb09031f 	cmp	x24, x9
   7c218:	540002c0 	b.eq	7c270 <spin_92+0x141c>  // b.none
   7c21c:	f85c03ab 	ldur	x11, [x29, #-64]
   7c220:	eb0b031f 	cmp	x24, x11
   7c224:	54000260 	b.eq	7c270 <spin_92+0x141c>  // b.none
   7c228:	f85c83ab 	ldur	x11, [x29, #-56]
   7c22c:	eb0b031f 	cmp	x24, x11
   7c230:	54000200 	b.eq	7c270 <spin_92+0x141c>  // b.none
   7c234:	f85e03ab 	ldur	x11, [x29, #-32]
   7c238:	eb0b031f 	cmp	x24, x11
   7c23c:	540001a0 	b.eq	7c270 <spin_92+0x141c>  // b.none
   7c240:	f85e83ab 	ldur	x11, [x29, #-24]
   7c244:	eb0b031f 	cmp	x24, x11
   7c248:	54000140 	b.eq	7c270 <spin_92+0x141c>  // b.none
   7c24c:	eb1b031f 	cmp	x24, x27
   7c250:	54000100 	b.eq	7c270 <spin_92+0x141c>  // b.none
   7c254:	eb0a031f 	cmp	x24, x10
   7c258:	540000c0 	b.eq	7c270 <spin_92+0x141c>  // b.none
   7c25c:	f85b83ab 	ldur	x11, [x29, #-72]
   7c260:	eb0b031f 	cmp	x24, x11
   7c264:	54000060 	b.eq	7c270 <spin_92+0x141c>  // b.none
   7c268:	92409f0b 	and	x11, x24, #0xffffffffff
   7c26c:	f86b7b5f 	ldr	xzr, [x26, x11, lsl #3]
   7c270:	d2ccc00b 	mov	x11, #0x660000000000        	// #112150186033152
   7c274:	f2e0400b 	movk	x11, #0x200, lsl #48
   7c278:	aa0b0196 	orr	x22, x12, x11
   7c27c:	b6f8036c 	tbz	x12, #63, 7c2e8 <spin_92+0x1494>
   7c280:	f85f03ab 	ldur	x11, [x29, #-16]
   7c284:	eb0b02df 	cmp	x22, x11
   7c288:	54000300 	b.eq	7c2e8 <spin_92+0x1494>  // b.none
   7c28c:	eb0902df 	cmp	x22, x9
   7c290:	540002c0 	b.eq	7c2e8 <spin_92+0x1494>  // b.none
   7c294:	f85c03a9 	ldur	x9, [x29, #-64]
   7c298:	eb0902df 	cmp	x22, x9
   7c29c:	54000260 	b.eq	7c2e8 <spin_92+0x1494>  // b.none
   7c2a0:	f85c83a9 	ldur	x9, [x29, #-56]
   7c2a4:	eb0902df 	cmp	x22, x9
   7c2a8:	54000200 	b.eq	7c2e8 <spin_92+0x1494>  // b.none
   7c2ac:	f85e03a9 	ldur	x9, [x29, #-32]
   7c2b0:	eb0902df 	cmp	x22, x9
   7c2b4:	540001a0 	b.eq	7c2e8 <spin_92+0x1494>  // b.none
   7c2b8:	f85e83a9 	ldur	x9, [x29, #-24]
   7c2bc:	eb0902df 	cmp	x22, x9
   7c2c0:	54000140 	b.eq	7c2e8 <spin_92+0x1494>  // b.none
   7c2c4:	eb1b02df 	cmp	x22, x27
   7c2c8:	54000100 	b.eq	7c2e8 <spin_92+0x1494>  // b.none
   7c2cc:	eb0a02df 	cmp	x22, x10
   7c2d0:	540000c0 	b.eq	7c2e8 <spin_92+0x1494>  // b.none
   7c2d4:	f85b83a9 	ldur	x9, [x29, #-72]
   7c2d8:	eb0902df 	cmp	x22, x9
   7c2dc:	54000060 	b.eq	7c2e8 <spin_92+0x1494>  // b.none
   7c2e0:	92409d89 	and	x9, x12, #0xffffffffff
   7c2e4:	f8697b5f 	ldr	xzr, [x26, x9, lsl #3]
   7c2e8:	f9400662 	ldr	x2, [x19, #8]
   7c2ec:	91000434 	add	x20, x1, #0x1
   7c2f0:	5280002a 	mov	w10, #0x1                   	// #1
   7c2f4:	f900026a 	str	x10, [x19]
   7c2f8:	b858c3aa 	ldur	w10, [x29, #-116]
   7c2fc:	92787c49 	and	x9, x2, #0xffffffff00
   7c300:	eb14013f 	cmp	x9, x20
   7c304:	f85a03a9 	ldur	x9, [x29, #-96]
   7c308:	f82a5928 	str	x8, [x9, w10, uxtw #3]
   7c30c:	54000163 	b.cc	7c338 <spin_92+0x14e4>  // b.lo, b.ul, b.last
   7c310:	b100045f 	cmn	x2, #0x1
   7c314:	54000120 	b.eq	7c338 <spin_92+0x14e4>  // b.none
   7c318:	92471448 	and	x8, x2, #0x7e00000000000000
   7c31c:	b40000e8 	cbz	x8, 7c338 <spin_92+0x14e4>
   7c320:	aa1a03e0 	mov	x0, x26
   7c324:	aa1903e1 	mov	x1, x25
   7c328:	97fe2593 	bl	5974 <term_drop>
   7c32c:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c330:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c334:	72a06201 	movk	w1, #0x310, lsl #16
   7c338:	f85683a9 	ldur	x9, [x29, #-152]
   7c33c:	f9406bf3 	ldr	x19, [sp, #208]
   7c340:	f9400522 	ldr	x2, [x9, #8]
   7c344:	f900013c 	str	x28, [x9]
   7c348:	b85643a9 	ldur	w9, [x29, #-156]
   7c34c:	92787c48 	and	x8, x2, #0xffffffff00
   7c350:	eb14011f 	cmp	x8, x20
   7c354:	f85703a8 	ldur	x8, [x29, #-144]
   7c358:	f8295918 	str	x24, [x8, w9, uxtw #3]
   7c35c:	54000163 	b.cc	7c388 <spin_92+0x1534>  // b.lo, b.ul, b.last
   7c360:	b100045f 	cmn	x2, #0x1
   7c364:	54000120 	b.eq	7c388 <spin_92+0x1534>  // b.none
   7c368:	92471448 	and	x8, x2, #0x7e00000000000000
   7c36c:	b40000e8 	cbz	x8, 7c388 <spin_92+0x1534>
   7c370:	aa1a03e0 	mov	x0, x26
   7c374:	aa1903e1 	mov	x1, x25
   7c378:	97fe257f 	bl	5974 <term_drop>
   7c37c:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c380:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c384:	72a06201 	movk	w1, #0x310, lsl #16
   7c388:	f9400729 	ldr	x9, [x25, #8]
   7c38c:	f9406ff8 	ldr	x24, [sp, #216]
   7c390:	b4002429 	cbz	x9, 7c814 <spin_92+0x19c0>
   7c394:	f8697b48 	ldr	x8, [x26, x9, lsl #3]
   7c398:	f940872a 	ldr	x10, [x25, #264]
   7c39c:	f9000728 	str	x8, [x25, #8]
   7c3a0:	d1000948 	sub	x8, x10, #0x2
   7c3a4:	f9008728 	str	x8, [x25, #264]
   7c3a8:	d378fec8 	lsr	x8, x22, #56
   7c3ac:	f100091f 	cmp	x8, #0x2
   7c3b0:	54002440 	b.eq	7c838 <spin_92+0x19e4>  // b.none
   7c3b4:	d378ff68 	lsr	x8, x27, #56
   7c3b8:	8b090f4a 	add	x10, x26, x9, lsl #3
   7c3bc:	f100091f 	cmp	x8, #0x2
   7c3c0:	f9000156 	str	x22, [x10]
   7c3c4:	540024e0 	b.eq	7c860 <spin_92+0x1a0c>  // b.none
   7c3c8:	d2c1e008 	mov	x8, #0xf0000000000         	// #16492674416640
   7c3cc:	f9403ff6 	ldr	x22, [sp, #120]
   7c3d0:	f900055b 	str	x27, [x10, #8]
   7c3d4:	f2e04008 	movk	x8, #0x200, lsl #48
   7c3d8:	aa08013b 	orr	x27, x9, x8
   7c3dc:	910006b5 	add	x21, x21, #0x1
   7c3e0:	eb1502df 	cmp	x22, x21
   7c3e4:	54ff6001 	b.ne	7afe4 <spin_92+0x190>  // b.any
   7c3e8:	14000409 	b	7d40c <spin_92+0x25b8>
   7c3ec:	aa1a03e0 	mov	x0, x26
   7c3f0:	aa1903e1 	mov	x1, x25
   7c3f4:	52800042 	mov	w2, #0x2                   	// #2
   7c3f8:	aa1103ec 	mov	x12, x17
   7c3fc:	aa1203ed 	mov	x13, x18
   7c400:	ad3a07a2 	stp	q2, q1, [x29, #-192]
   7c404:	ad050fe4 	stp	q4, q3, [sp, #160]
   7c408:	97fe21b9 	bl	4aec <heap_alloc_miss>
   7c40c:	ad450fe4 	ldp	q4, q3, [sp, #160]
   7c410:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c414:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   7c418:	aa0d03f2 	mov	x18, x13
   7c41c:	aa0c03f1 	mov	x17, x12
   7c420:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c424:	72a06201 	movk	w1, #0x310, lsl #16
   7c428:	aa0003ec 	mov	x12, x0
   7c42c:	17fffcfd 	b	7b820 <spin_92+0x9cc>
   7c430:	aa1a03e0 	mov	x0, x26
   7c434:	aa1903e1 	mov	x1, x25
   7c438:	aa0903e2 	mov	x2, x9
   7c43c:	52800023 	mov	w3, #0x1                   	// #1
   7c440:	aa1103ed 	mov	x13, x17
   7c444:	aa1203ee 	mov	x14, x18
   7c448:	ad3a07a2 	stp	q2, q1, [x29, #-192]
   7c44c:	ad050fe4 	stp	q4, q3, [sp, #160]
   7c450:	97fe2290 	bl	4e90 <rfc_wrap>
   7c454:	ad450fe4 	ldp	q4, q3, [sp, #160]
   7c458:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c45c:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   7c460:	aa0e03f2 	mov	x18, x14
   7c464:	aa0d03f1 	mov	x17, x13
   7c468:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c46c:	72a06201 	movk	w1, #0x310, lsl #16
   7c470:	17fffcf0 	b	7b830 <spin_92+0x9dc>
   7c474:	aa1a03e0 	mov	x0, x26
   7c478:	aa1903e1 	mov	x1, x25
   7c47c:	52800062 	mov	w2, #0x3                   	// #3
   7c480:	ad3a07a2 	stp	q2, q1, [x29, #-192]
   7c484:	ad050fe4 	stp	q4, q3, [sp, #160]
   7c488:	97fe2199 	bl	4aec <heap_alloc_miss>
   7c48c:	ad450fe4 	ldp	q4, q3, [sp, #160]
   7c490:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c494:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   7c498:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c49c:	72a06201 	movk	w1, #0x310, lsl #16
   7c4a0:	aa0003ee 	mov	x14, x0
   7c4a4:	17fffced 	b	7b858 <spin_92+0xa04>
   7c4a8:	aa1a03e0 	mov	x0, x26
   7c4ac:	aa1903e1 	mov	x1, x25
   7c4b0:	52800022 	mov	w2, #0x1                   	// #1
   7c4b4:	ad050fe4 	stp	q4, q3, [sp, #160]
   7c4b8:	ad3a07a0 	stp	q0, q1, [x29, #-192]
   7c4bc:	97fe218c 	bl	4aec <heap_alloc_miss>
   7c4c0:	ad7a07a0 	ldp	q0, q1, [x29, #-192]
   7c4c4:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c4c8:	ad450fe4 	ldp	q4, q3, [sp, #160]
   7c4cc:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c4d0:	72a06201 	movk	w1, #0x310, lsl #16
   7c4d4:	aa0003ed 	mov	x13, x0
   7c4d8:	17fffcef 	b	7b894 <spin_92+0xa40>
   7c4dc:	aa1a03e0 	mov	x0, x26
   7c4e0:	aa1903e1 	mov	x1, x25
   7c4e4:	52800023 	mov	w3, #0x1                   	// #1
   7c4e8:	ad050fe4 	stp	q4, q3, [sp, #160]
   7c4ec:	ad3a07a0 	stp	q0, q1, [x29, #-192]
   7c4f0:	97fe2268 	bl	4e90 <rfc_wrap>
   7c4f4:	ad7a07a0 	ldp	q0, q1, [x29, #-192]
   7c4f8:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c4fc:	ad450fe4 	ldp	q4, q3, [sp, #160]
   7c500:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c504:	72a06201 	movk	w1, #0x310, lsl #16
   7c508:	aa0003e2 	mov	x2, x0
   7c50c:	17fffce8 	b	7b8ac <spin_92+0xa58>
   7c510:	aa1a03e0 	mov	x0, x26
   7c514:	aa1903e1 	mov	x1, x25
   7c518:	aa0803e2 	mov	x2, x8
   7c51c:	52800023 	mov	w3, #0x1                   	// #1
   7c520:	ad050fe4 	stp	q4, q3, [sp, #160]
   7c524:	ad3a07a0 	stp	q0, q1, [x29, #-192]
   7c528:	97fe225a 	bl	4e90 <rfc_wrap>
   7c52c:	ad7a07a0 	ldp	q0, q1, [x29, #-192]
   7c530:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c534:	ad450fe4 	ldp	q4, q3, [sp, #160]
   7c538:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c53c:	72a06201 	movk	w1, #0x310, lsl #16
   7c540:	aa0003e8 	mov	x8, x0
   7c544:	17fffce2 	b	7b8cc <spin_92+0xa78>
   7c548:	aa1a03e0 	mov	x0, x26
   7c54c:	aa1903e1 	mov	x1, x25
   7c550:	52800062 	mov	w2, #0x3                   	// #3
   7c554:	ad050fe4 	stp	q4, q3, [sp, #160]
   7c558:	ad3a07a0 	stp	q0, q1, [x29, #-192]
   7c55c:	97fe2164 	bl	4aec <heap_alloc_miss>
   7c560:	ad7a07a0 	ldp	q0, q1, [x29, #-192]
   7c564:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c568:	ad450fe4 	ldp	q4, q3, [sp, #160]
   7c56c:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c570:	72a06201 	movk	w1, #0x310, lsl #16
   7c574:	aa0003ec 	mov	x12, x0
   7c578:	17fffcdd 	b	7b8ec <spin_92+0xa98>
   7c57c:	aa1a03e0 	mov	x0, x26
   7c580:	aa1903e1 	mov	x1, x25
   7c584:	aa0203eb 	mov	x11, x2
   7c588:	52800042 	mov	w2, #0x2                   	// #2
   7c58c:	aa0403ec 	mov	x12, x4
   7c590:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   7c594:	3d802fe4 	str	q4, [sp, #176]
   7c598:	3c9d03a5 	stur	q5, [x29, #-48]
   7c59c:	3d802be6 	str	q6, [sp, #160]
   7c5a0:	3d8023e7 	str	q7, [sp, #128]
   7c5a4:	ad0243f1 	stp	q17, q16, [sp, #64]
   7c5a8:	97fe2151 	bl	4aec <heap_alloc_miss>
   7c5ac:	ad4243f1 	ldp	q17, q16, [sp, #64]
   7c5b0:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c5b4:	ad4513e6 	ldp	q6, q4, [sp, #160]
   7c5b8:	aa0c03e4 	mov	x4, x12
   7c5bc:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   7c5c0:	aa0b03e2 	mov	x2, x11
   7c5c4:	3dc023e7 	ldr	q7, [sp, #128]
   7c5c8:	3cdd03a5 	ldur	q5, [x29, #-48]
   7c5cc:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c5d0:	72a06201 	movk	w1, #0x310, lsl #16
   7c5d4:	aa0003ec 	mov	x12, x0
   7c5d8:	17fffe71 	b	7bf9c <spin_92+0x1148>
   7c5dc:	aa1a03e0 	mov	x0, x26
   7c5e0:	aa1903e1 	mov	x1, x25
   7c5e4:	aa0203eb 	mov	x11, x2
   7c5e8:	aa0d03e2 	mov	x2, x13
   7c5ec:	52800023 	mov	w3, #0x1                   	// #1
   7c5f0:	aa0403ed 	mov	x13, x4
   7c5f4:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   7c5f8:	3d802fe4 	str	q4, [sp, #176]
   7c5fc:	3c9d03a5 	stur	q5, [x29, #-48]
   7c600:	3d802be6 	str	q6, [sp, #160]
   7c604:	3d8023e7 	str	q7, [sp, #128]
   7c608:	ad0243f1 	stp	q17, q16, [sp, #64]
   7c60c:	97fe2221 	bl	4e90 <rfc_wrap>
   7c610:	ad4243f1 	ldp	q17, q16, [sp, #64]
   7c614:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c618:	ad4513e6 	ldp	q6, q4, [sp, #160]
   7c61c:	aa0d03e4 	mov	x4, x13
   7c620:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   7c624:	aa0b03e2 	mov	x2, x11
   7c628:	3dc023e7 	ldr	q7, [sp, #128]
   7c62c:	3cdd03a5 	ldur	q5, [x29, #-48]
   7c630:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c634:	72a06201 	movk	w1, #0x310, lsl #16
   7c638:	aa0003ed 	mov	x13, x0
   7c63c:	17fffe5b 	b	7bfa8 <spin_92+0x1154>
   7c640:	aa1a03e0 	mov	x0, x26
   7c644:	aa1903e1 	mov	x1, x25
   7c648:	52800062 	mov	w2, #0x3                   	// #3
   7c64c:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   7c650:	3d802fe4 	str	q4, [sp, #176]
   7c654:	3c9d03a5 	stur	q5, [x29, #-48]
   7c658:	3d802be6 	str	q6, [sp, #160]
   7c65c:	3d8023e7 	str	q7, [sp, #128]
   7c660:	ad0243f1 	stp	q17, q16, [sp, #64]
   7c664:	97fe2122 	bl	4aec <heap_alloc_miss>
   7c668:	ad4243f1 	ldp	q17, q16, [sp, #64]
   7c66c:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c670:	ad4513e6 	ldp	q6, q4, [sp, #160]
   7c674:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c678:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   7c67c:	72a06201 	movk	w1, #0x310, lsl #16
   7c680:	3dc023e7 	ldr	q7, [sp, #128]
   7c684:	3cdd03a5 	ldur	q5, [x29, #-48]
   7c688:	aa0003ed 	mov	x13, x0
   7c68c:	17fffe51 	b	7bfd0 <spin_92+0x117c>
   7c690:	aa1a03e0 	mov	x0, x26
   7c694:	aa1903e1 	mov	x1, x25
   7c698:	52800022 	mov	w2, #0x1                   	// #1
   7c69c:	3c9d03a5 	stur	q5, [x29, #-48]
   7c6a0:	3d802be6 	str	q6, [sp, #160]
   7c6a4:	3d8023e7 	str	q7, [sp, #128]
   7c6a8:	ad0243f1 	stp	q17, q16, [sp, #64]
   7c6ac:	97fe2110 	bl	4aec <heap_alloc_miss>
   7c6b0:	ad4243f1 	ldp	q17, q16, [sp, #64]
   7c6b4:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c6b8:	3dc023e7 	ldr	q7, [sp, #128]
   7c6bc:	3dc02be6 	ldr	q6, [sp, #160]
   7c6c0:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c6c4:	3cdd03a5 	ldur	q5, [x29, #-48]
   7c6c8:	72a06201 	movk	w1, #0x310, lsl #16
   7c6cc:	aa0003eb 	mov	x11, x0
   7c6d0:	17fffe4e 	b	7c008 <spin_92+0x11b4>
   7c6d4:	aa1a03e0 	mov	x0, x26
   7c6d8:	aa1903e1 	mov	x1, x25
   7c6dc:	52800023 	mov	w3, #0x1                   	// #1
   7c6e0:	3c9d03a5 	stur	q5, [x29, #-48]
   7c6e4:	3d802be6 	str	q6, [sp, #160]
   7c6e8:	3d8023e7 	str	q7, [sp, #128]
   7c6ec:	ad0243f1 	stp	q17, q16, [sp, #64]
   7c6f0:	97fe21e8 	bl	4e90 <rfc_wrap>
   7c6f4:	ad4243f1 	ldp	q17, q16, [sp, #64]
   7c6f8:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c6fc:	3dc023e7 	ldr	q7, [sp, #128]
   7c700:	3dc02be6 	ldr	q6, [sp, #160]
   7c704:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c708:	3cdd03a5 	ldur	q5, [x29, #-48]
   7c70c:	72a06201 	movk	w1, #0x310, lsl #16
   7c710:	aa0003e2 	mov	x2, x0
   7c714:	17fffe43 	b	7c020 <spin_92+0x11cc>
   7c718:	aa1a03e0 	mov	x0, x26
   7c71c:	aa1903e1 	mov	x1, x25
   7c720:	aa0803e2 	mov	x2, x8
   7c724:	52800023 	mov	w3, #0x1                   	// #1
   7c728:	3c9d03a5 	stur	q5, [x29, #-48]
   7c72c:	3d802be6 	str	q6, [sp, #160]
   7c730:	3d8023e7 	str	q7, [sp, #128]
   7c734:	ad0243f1 	stp	q17, q16, [sp, #64]
   7c738:	97fe21d6 	bl	4e90 <rfc_wrap>
   7c73c:	ad4243f1 	ldp	q17, q16, [sp, #64]
   7c740:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c744:	3dc023e7 	ldr	q7, [sp, #128]
   7c748:	3dc02be6 	ldr	q6, [sp, #160]
   7c74c:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c750:	3cdd03a5 	ldur	q5, [x29, #-48]
   7c754:	72a06201 	movk	w1, #0x310, lsl #16
   7c758:	aa0003e8 	mov	x8, x0
   7c75c:	17fffe39 	b	7c040 <spin_92+0x11ec>
   7c760:	aa1a03e0 	mov	x0, x26
   7c764:	aa1903e1 	mov	x1, x25
   7c768:	52800062 	mov	w2, #0x3                   	// #3
   7c76c:	3c9d03a5 	stur	q5, [x29, #-48]
   7c770:	3d802be6 	str	q6, [sp, #160]
   7c774:	3d8023e7 	str	q7, [sp, #128]
   7c778:	ad0243f1 	stp	q17, q16, [sp, #64]
   7c77c:	97fe20dc 	bl	4aec <heap_alloc_miss>
   7c780:	ad4243f1 	ldp	q17, q16, [sp, #64]
   7c784:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c788:	3dc023e7 	ldr	q7, [sp, #128]
   7c78c:	3dc02be6 	ldr	q6, [sp, #160]
   7c790:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c794:	3cdd03a5 	ldur	q5, [x29, #-48]
   7c798:	72a06201 	movk	w1, #0x310, lsl #16
   7c79c:	aa0003ed 	mov	x13, x0
   7c7a0:	17fffe45 	b	7c0b4 <spin_92+0x1260>
   7c7a4:	aa1a03e0 	mov	x0, x26
   7c7a8:	aa1903e1 	mov	x1, x25
   7c7ac:	52800062 	mov	w2, #0x3                   	// #3
   7c7b0:	97fe20cf 	bl	4aec <heap_alloc_miss>
   7c7b4:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c7b8:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c7bc:	aa0003ec 	mov	x12, x0
   7c7c0:	72a06201 	movk	w1, #0x310, lsl #16
   7c7c4:	17fffe62 	b	7c14c <spin_92+0x12f8>
   7c7c8:	aa1a03e0 	mov	x0, x26
   7c7cc:	aa1903e1 	mov	x1, x25
   7c7d0:	52800023 	mov	w3, #0x1                   	// #1
   7c7d4:	97fe21af 	bl	4e90 <rfc_wrap>
   7c7d8:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c7dc:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c7e0:	aa0003e2 	mov	x2, x0
   7c7e4:	72a06201 	movk	w1, #0x310, lsl #16
   7c7e8:	17fffe63 	b	7c174 <spin_92+0x1320>
   7c7ec:	aa1a03e0 	mov	x0, x26
   7c7f0:	aa1903e1 	mov	x1, x25
   7c7f4:	aa0e03e2 	mov	x2, x14
   7c7f8:	52800023 	mov	w3, #0x1                   	// #1
   7c7fc:	97fe21a5 	bl	4e90 <rfc_wrap>
   7c800:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c804:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c808:	aa0003ee 	mov	x14, x0
   7c80c:	72a06201 	movk	w1, #0x310, lsl #16
   7c810:	17fffe5d 	b	7c184 <spin_92+0x1330>
   7c814:	aa1a03e0 	mov	x0, x26
   7c818:	aa1903e1 	mov	x1, x25
   7c81c:	52800022 	mov	w2, #0x1                   	// #1
   7c820:	97fe20b3 	bl	4aec <heap_alloc_miss>
   7c824:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c828:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c82c:	aa0003e9 	mov	x9, x0
   7c830:	72a06201 	movk	w1, #0x310, lsl #16
   7c834:	17fffedd 	b	7c3a8 <spin_92+0x1554>
   7c838:	aa1a03e0 	mov	x0, x26
   7c83c:	aa1903e1 	mov	x1, x25
   7c840:	aa1603e2 	mov	x2, x22
   7c844:	52800023 	mov	w3, #0x1                   	// #1
   7c848:	97fe2192 	bl	4e90 <rfc_wrap>
   7c84c:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c850:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c854:	aa0003f6 	mov	x22, x0
   7c858:	72a06201 	movk	w1, #0x310, lsl #16
   7c85c:	17fffed6 	b	7c3b4 <spin_92+0x1560>
   7c860:	aa1a03e0 	mov	x0, x26
   7c864:	aa1903e1 	mov	x1, x25
   7c868:	aa1b03e2 	mov	x2, x27
   7c86c:	52800023 	mov	w3, #0x1                   	// #1
   7c870:	97fe2188 	bl	4e90 <rfc_wrap>
   7c874:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c878:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c87c:	aa0003fb 	mov	x27, x0
   7c880:	72a06201 	movk	w1, #0x310, lsl #16
   7c884:	17fffed1 	b	7c3c8 <spin_92+0x1574>
   7c888:	aa1a03e0 	mov	x0, x26
   7c88c:	aa1903e1 	mov	x1, x25
   7c890:	52800022 	mov	w2, #0x1                   	// #1
   7c894:	aa1103eb 	mov	x11, x17
   7c898:	aa1203ec 	mov	x12, x18
   7c89c:	97fe2094 	bl	4aec <heap_alloc_miss>
   7c8a0:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   7c8a4:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c8a8:	aa0c03f2 	mov	x18, x12
   7c8ac:	aa0b03f1 	mov	x17, x11
   7c8b0:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c8b4:	72a06201 	movk	w1, #0x310, lsl #16
   7c8b8:	aa0003eb 	mov	x11, x0
   7c8bc:	17fffb31 	b	7b580 <spin_92+0x72c>
   7c8c0:	aa1a03e0 	mov	x0, x26
   7c8c4:	aa1903e1 	mov	x1, x25
   7c8c8:	aa0a03e2 	mov	x2, x10
   7c8cc:	52800023 	mov	w3, #0x1                   	// #1
   7c8d0:	aa1103ec 	mov	x12, x17
   7c8d4:	f9005bf2 	str	x18, [sp, #176]
   7c8d8:	97fe216e 	bl	4e90 <rfc_wrap>
   7c8dc:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   7c8e0:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c8e4:	f9405bf2 	ldr	x18, [sp, #176]
   7c8e8:	aa0c03f1 	mov	x17, x12
   7c8ec:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c8f0:	72a06201 	movk	w1, #0x310, lsl #16
   7c8f4:	17fffb27 	b	7b590 <spin_92+0x73c>
   7c8f8:	aa1a03e0 	mov	x0, x26
   7c8fc:	aa1903e1 	mov	x1, x25
   7c900:	52800062 	mov	w2, #0x3                   	// #3
   7c904:	aa1103ec 	mov	x12, x17
   7c908:	f9005bf2 	str	x18, [sp, #176]
   7c90c:	97fe2078 	bl	4aec <heap_alloc_miss>
   7c910:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   7c914:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c918:	f9405bf2 	ldr	x18, [sp, #176]
   7c91c:	aa0c03f1 	mov	x17, x12
   7c920:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c924:	72a06201 	movk	w1, #0x310, lsl #16
   7c928:	aa0003ec 	mov	x12, x0
   7c92c:	17fffb22 	b	7b5b4 <spin_92+0x760>
   7c930:	aa1a03e0 	mov	x0, x26
   7c934:	aa1903e1 	mov	x1, x25
   7c938:	52800022 	mov	w2, #0x1                   	// #1
   7c93c:	ad050fe4 	stp	q4, q3, [sp, #160]
   7c940:	97fe206b 	bl	4aec <heap_alloc_miss>
   7c944:	ad450fe4 	ldp	q4, q3, [sp, #160]
   7c948:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c94c:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c950:	72a06201 	movk	w1, #0x310, lsl #16
   7c954:	aa0003ee 	mov	x14, x0
   7c958:	17fffbf2 	b	7b920 <spin_92+0xacc>
   7c95c:	aa1a03e0 	mov	x0, x26
   7c960:	aa1903e1 	mov	x1, x25
   7c964:	aa0b03e2 	mov	x2, x11
   7c968:	52800023 	mov	w3, #0x1                   	// #1
   7c96c:	ad050fe4 	stp	q4, q3, [sp, #160]
   7c970:	97fe2148 	bl	4e90 <rfc_wrap>
   7c974:	ad450fe4 	ldp	q4, q3, [sp, #160]
   7c978:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c97c:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c980:	72a06201 	movk	w1, #0x310, lsl #16
   7c984:	aa0003eb 	mov	x11, x0
   7c988:	17fffbe9 	b	7b92c <spin_92+0xad8>
   7c98c:	aa1a03e0 	mov	x0, x26
   7c990:	aa1903e1 	mov	x1, x25
   7c994:	2a1f03e2 	mov	w2, wzr
   7c998:	ad050fe4 	stp	q4, q3, [sp, #160]
   7c99c:	97fe2054 	bl	4aec <heap_alloc_miss>
   7c9a0:	ad450fe4 	ldp	q4, q3, [sp, #160]
   7c9a4:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c9a8:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c9ac:	72a06201 	movk	w1, #0x310, lsl #16
   7c9b0:	aa0003eb 	mov	x11, x0
   7c9b4:	17fffbe7 	b	7b950 <spin_92+0xafc>
   7c9b8:	aa1a03e0 	mov	x0, x26
   7c9bc:	aa1903e1 	mov	x1, x25
   7c9c0:	52800023 	mov	w3, #0x1                   	// #1
   7c9c4:	ad050fe4 	stp	q4, q3, [sp, #160]
   7c9c8:	97fe2132 	bl	4e90 <rfc_wrap>
   7c9cc:	ad450fe4 	ldp	q4, q3, [sp, #160]
   7c9d0:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7c9d4:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7c9d8:	72a06201 	movk	w1, #0x310, lsl #16
   7c9dc:	aa0003e2 	mov	x2, x0
   7c9e0:	17fffbe2 	b	7b968 <spin_92+0xb14>
   7c9e4:	aa1a03e0 	mov	x0, x26
   7c9e8:	aa1903e1 	mov	x1, x25
   7c9ec:	52800062 	mov	w2, #0x3                   	// #3
   7c9f0:	ad050fe4 	stp	q4, q3, [sp, #160]
   7c9f4:	97fe203e 	bl	4aec <heap_alloc_miss>
   7c9f8:	ad450fe4 	ldp	q4, q3, [sp, #160]
   7c9fc:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7ca00:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7ca04:	72a06201 	movk	w1, #0x310, lsl #16
   7ca08:	17fffbe0 	b	7b988 <spin_92+0xb34>
   7ca0c:	aa1a03e0 	mov	x0, x26
   7ca10:	aa1903e1 	mov	x1, x25
   7ca14:	52800062 	mov	w2, #0x3                   	// #3
   7ca18:	ad0243f1 	stp	q17, q16, [sp, #64]
   7ca1c:	97fe2034 	bl	4aec <heap_alloc_miss>
   7ca20:	ad4243f1 	ldp	q17, q16, [sp, #64]
   7ca24:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7ca28:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7ca2c:	72a06201 	movk	w1, #0x310, lsl #16
   7ca30:	17fffdb0 	b	7c0f0 <spin_92+0x129c>
   7ca34:	aa1a03e0 	mov	x0, x26
   7ca38:	aa1903e1 	mov	x1, x25
   7ca3c:	52800022 	mov	w2, #0x1                   	// #1
   7ca40:	3c9d03a5 	stur	q5, [x29, #-48]
   7ca44:	3d802be6 	str	q6, [sp, #160]
   7ca48:	3d8023e7 	str	q7, [sp, #128]
   7ca4c:	ad0243f1 	stp	q17, q16, [sp, #64]
   7ca50:	97fe2027 	bl	4aec <heap_alloc_miss>
   7ca54:	ad4243f1 	ldp	q17, q16, [sp, #64]
   7ca58:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7ca5c:	3dc023e7 	ldr	q7, [sp, #128]
   7ca60:	3dc02be6 	ldr	q6, [sp, #160]
   7ca64:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7ca68:	3cdd03a5 	ldur	q5, [x29, #-48]
   7ca6c:	72a06201 	movk	w1, #0x310, lsl #16
   7ca70:	aa0003ec 	mov	x12, x0
   7ca74:	17fffd80 	b	7c074 <spin_92+0x1220>
   7ca78:	aa1a03e0 	mov	x0, x26
   7ca7c:	aa1903e1 	mov	x1, x25
   7ca80:	aa0f03e2 	mov	x2, x15
   7ca84:	52800023 	mov	w3, #0x1                   	// #1
   7ca88:	3c9d03a5 	stur	q5, [x29, #-48]
   7ca8c:	3d802be6 	str	q6, [sp, #160]
   7ca90:	3d8023e7 	str	q7, [sp, #128]
   7ca94:	ad0243f1 	stp	q17, q16, [sp, #64]
   7ca98:	97fe20fe 	bl	4e90 <rfc_wrap>
   7ca9c:	ad4243f1 	ldp	q17, q16, [sp, #64]
   7caa0:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7caa4:	3dc023e7 	ldr	q7, [sp, #128]
   7caa8:	3dc02be6 	ldr	q6, [sp, #160]
   7caac:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7cab0:	3cdd03a5 	ldur	q5, [x29, #-48]
   7cab4:	72a06201 	movk	w1, #0x310, lsl #16
   7cab8:	aa0003ef 	mov	x15, x0
   7cabc:	17fffd71 	b	7c080 <spin_92+0x122c>
   7cac0:	aa1a03e0 	mov	x0, x26
   7cac4:	aa1903e1 	mov	x1, x25
   7cac8:	52800022 	mov	w2, #0x1                   	// #1
   7cacc:	97fe1e45 	bl	43e0 <heap_hand>
   7cad0:	14000057 	b	7cc2c <spin_92+0x1dd8>
   7cad4:	aa1a03e0 	mov	x0, x26
   7cad8:	aa1903e1 	mov	x1, x25
   7cadc:	52800042 	mov	w2, #0x2                   	// #2
   7cae0:	aa1103eb 	mov	x11, x17
   7cae4:	aa1203ed 	mov	x13, x18
   7cae8:	97fe1e3e 	bl	43e0 <heap_hand>
   7caec:	aa0d03f2 	mov	x18, x13
   7caf0:	aa0b03f1 	mov	x17, x11
   7caf4:	1400005f 	b	7cc70 <spin_92+0x1e1c>
   7caf8:	aa1a03e0 	mov	x0, x26
   7cafc:	aa1903e1 	mov	x1, x25
   7cb00:	52800062 	mov	w2, #0x3                   	// #3
   7cb04:	aa1103ea 	mov	x10, x17
   7cb08:	aa1203eb 	mov	x11, x18
   7cb0c:	ad3a07a2 	stp	q2, q1, [x29, #-192]
   7cb10:	97fe1e34 	bl	43e0 <heap_hand>
   7cb14:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   7cb18:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7cb1c:	aa0b03f2 	mov	x18, x11
   7cb20:	aa0a03f1 	mov	x17, x10
   7cb24:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7cb28:	72a06201 	movk	w1, #0x310, lsl #16
   7cb2c:	17fffa01 	b	7b330 <spin_92+0x4dc>
   7cb30:	aa1a03e0 	mov	x0, x26
   7cb34:	aa1903e1 	mov	x1, x25
   7cb38:	52800022 	mov	w2, #0x1                   	// #1
   7cb3c:	97fe1e29 	bl	43e0 <heap_hand>
   7cb40:	14000069 	b	7cce4 <spin_92+0x1e90>
   7cb44:	aa1a03e0 	mov	x0, x26
   7cb48:	aa1903e1 	mov	x1, x25
   7cb4c:	aa0203f4 	mov	x20, x2
   7cb50:	52800042 	mov	w2, #0x2                   	// #2
   7cb54:	aa0403ee 	mov	x14, x4
   7cb58:	97fe1e22 	bl	43e0 <heap_hand>
   7cb5c:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7cb60:	aa0e03e4 	mov	x4, x14
   7cb64:	aa1403e2 	mov	x2, x20
   7cb68:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7cb6c:	72a06201 	movk	w1, #0x310, lsl #16
   7cb70:	17fffc0b 	b	7bb9c <spin_92+0xd48>
   7cb74:	aa1a03e0 	mov	x0, x26
   7cb78:	aa1903e1 	mov	x1, x25
   7cb7c:	aa0203f6 	mov	x22, x2
   7cb80:	52800062 	mov	w2, #0x3                   	// #3
   7cb84:	aa0403ee 	mov	x14, x4
   7cb88:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   7cb8c:	3d802fe4 	str	q4, [sp, #176]
   7cb90:	97fe1e14 	bl	43e0 <heap_hand>
   7cb94:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   7cb98:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7cb9c:	3dc02fe4 	ldr	q4, [sp, #176]
   7cba0:	aa0e03e4 	mov	x4, x14
   7cba4:	aa1603e2 	mov	x2, x22
   7cba8:	d2c10016 	mov	x22, #0x80000000000         	// #8796093022208
   7cbac:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7cbb0:	72a06201 	movk	w1, #0x310, lsl #16
   7cbb4:	17fffc27 	b	7bc50 <spin_92+0xdfc>
   7cbb8:	aa1a03e0 	mov	x0, x26
   7cbbc:	aa1903e1 	mov	x1, x25
   7cbc0:	aa0203ec 	mov	x12, x2
   7cbc4:	52800062 	mov	w2, #0x3                   	// #3
   7cbc8:	aa0403ee 	mov	x14, x4
   7cbcc:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   7cbd0:	3d802fe4 	str	q4, [sp, #176]
   7cbd4:	3c9d03a5 	stur	q5, [x29, #-48]
   7cbd8:	3d802be6 	str	q6, [sp, #160]
   7cbdc:	3d8023e7 	str	q7, [sp, #128]
   7cbe0:	97fe1e00 	bl	43e0 <heap_hand>
   7cbe4:	ad4513e6 	ldp	q6, q4, [sp, #160]
   7cbe8:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7cbec:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   7cbf0:	aa0e03e4 	mov	x4, x14
   7cbf4:	3dc023e7 	ldr	q7, [sp, #128]
   7cbf8:	3cdd03a5 	ldur	q5, [x29, #-48]
   7cbfc:	aa0c03e2 	mov	x2, x12
   7cc00:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7cc04:	72a06201 	movk	w1, #0x310, lsl #16
   7cc08:	17fffcaa 	b	7beb0 <spin_92+0x105c>
   7cc0c:	aa098168 	orr	x8, x11, x9, lsl #32
   7cc10:	aa1a03e0 	mov	x0, x26
   7cc14:	aa1903e1 	mov	x1, x25
   7cc18:	52800044 	mov	w4, #0x2                   	// #2
   7cc1c:	d358fd03 	lsr	x3, x8, #24
   7cc20:	8b030f48 	add	x8, x26, x3, lsl #3
   7cc24:	a940290b 	ldp	x11, x10, [x8]
   7cc28:	97fe1e21 	bl	44ac <span_fade>
   7cc2c:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7cc30:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7cc34:	72a06201 	movk	w1, #0x310, lsl #16
   7cc38:	17fff95a 	b	7b1a0 <spin_92+0x34c>
   7cc3c:	aa0981c8 	orr	x8, x14, x9, lsl #32
   7cc40:	aa1a03e0 	mov	x0, x26
   7cc44:	aa1903e1 	mov	x1, x25
   7cc48:	aa0b03e2 	mov	x2, x11
   7cc4c:	52800064 	mov	w4, #0x3                   	// #3
   7cc50:	d358fd03 	lsr	x3, x8, #24
   7cc54:	8b030f48 	add	x8, x26, x3, lsl #3
   7cc58:	f9400109 	ldr	x9, [x8]
   7cc5c:	b940090d 	ldr	w13, [x8, #8]
   7cc60:	b940110e 	ldr	w14, [x8, #16]
   7cc64:	97fe1e12 	bl	44ac <span_fade>
   7cc68:	aa0e03f2 	mov	x18, x14
   7cc6c:	aa0d03f1 	mov	x17, x13
   7cc70:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7cc74:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7cc78:	72a06201 	movk	w1, #0x310, lsl #16
   7cc7c:	17fff975 	b	7b250 <spin_92+0x3fc>
   7cc80:	aa1a03e0 	mov	x0, x26
   7cc84:	aa1903e1 	mov	x1, x25
   7cc88:	aa0a03e2 	mov	x2, x10
   7cc8c:	aa0b03e3 	mov	x3, x11
   7cc90:	528000c4 	mov	w4, #0x6                   	// #6
   7cc94:	ad3a07a2 	stp	q2, q1, [x29, #-192]
   7cc98:	97fe1e05 	bl	44ac <span_fade>
   7cc9c:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   7cca0:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7cca4:	aa1303f1 	mov	x17, x19
   7cca8:	aa1703f3 	mov	x19, x23
   7ccac:	d2c1c017 	mov	x23, #0xe0000000000         	// #15393162788864
   7ccb0:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7ccb4:	72a06201 	movk	w1, #0x310, lsl #16
   7ccb8:	f2e02017 	movk	x23, #0x100, lsl #48
   7ccbc:	aa1403f2 	mov	x18, x20
   7ccc0:	17fff99c 	b	7b330 <spin_92+0x4dc>
   7ccc4:	aa0d8228 	orr	x8, x17, x13, lsl #32
   7ccc8:	aa1a03e0 	mov	x0, x26
   7cccc:	aa1903e1 	mov	x1, x25
   7ccd0:	52800044 	mov	w4, #0x2                   	// #2
   7ccd4:	d358fd03 	lsr	x3, x8, #24
   7ccd8:	8b030f48 	add	x8, x26, x3, lsl #3
   7ccdc:	a940611c 	ldp	x28, x24, [x8]
   7cce0:	97fe1df3 	bl	44ac <span_fade>
   7cce4:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7cce8:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7ccec:	72a06201 	movk	w1, #0x310, lsl #16
   7ccf0:	17fffb7f 	b	7baec <spin_92+0xc98>
   7ccf4:	aa0d8228 	orr	x8, x17, x13, lsl #32
   7ccf8:	aa1a03e0 	mov	x0, x26
   7ccfc:	aa1903e1 	mov	x1, x25
   7cd00:	aa1c03e2 	mov	x2, x28
   7cd04:	52800064 	mov	w4, #0x3                   	// #3
   7cd08:	d358fd03 	lsr	x3, x8, #24
   7cd0c:	8b030f48 	add	x8, x26, x3, lsl #3
   7cd10:	f940010d 	ldr	x13, [x8]
   7cd14:	b9400916 	ldr	w22, [x8, #8]
   7cd18:	b940110e 	ldr	w14, [x8, #16]
   7cd1c:	97fe1de4 	bl	44ac <span_fade>
   7cd20:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7cd24:	aa0e03e4 	mov	x4, x14
   7cd28:	aa1603e2 	mov	x2, x22
   7cd2c:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7cd30:	72a06201 	movk	w1, #0x310, lsl #16
   7cd34:	d2c10016 	mov	x22, #0x80000000000         	// #8796093022208
   7cd38:	17fffb9a 	b	7bba0 <spin_92+0xd4c>
   7cd3c:	aa1a03e0 	mov	x0, x26
   7cd40:	aa1903e1 	mov	x1, x25
   7cd44:	aa0203f6 	mov	x22, x2
   7cd48:	aa1803e2 	mov	x2, x24
   7cd4c:	aa1c03e3 	mov	x3, x28
   7cd50:	aa0403ee 	mov	x14, x4
   7cd54:	528000c4 	mov	w4, #0x6                   	// #6
   7cd58:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   7cd5c:	3d802fe4 	str	q4, [sp, #176]
   7cd60:	97fe1dd3 	bl	44ac <span_fade>
   7cd64:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   7cd68:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7cd6c:	3dc02fe4 	ldr	q4, [sp, #176]
   7cd70:	aa0e03e4 	mov	x4, x14
   7cd74:	aa1603e2 	mov	x2, x22
   7cd78:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7cd7c:	72a06201 	movk	w1, #0x310, lsl #16
   7cd80:	d2c10016 	mov	x22, #0x80000000000         	// #8796093022208
   7cd84:	17fffbb3 	b	7bc50 <spin_92+0xdfc>
   7cd88:	f94053e2 	ldr	x2, [sp, #160]
   7cd8c:	aa1a03e0 	mov	x0, x26
   7cd90:	aa1903e1 	mov	x1, x25
   7cd94:	aa0c03e3 	mov	x3, x12
   7cd98:	528000c4 	mov	w4, #0x6                   	// #6
   7cd9c:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   7cda0:	3d802fe4 	str	q4, [sp, #176]
   7cda4:	3c9d03a5 	stur	q5, [x29, #-48]
   7cda8:	3d802be6 	str	q6, [sp, #160]
   7cdac:	3d8023e7 	str	q7, [sp, #128]
   7cdb0:	97fe1dbf 	bl	44ac <span_fade>
   7cdb4:	ad4513e6 	ldp	q6, q4, [sp, #160]
   7cdb8:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7cdbc:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   7cdc0:	aa1803e4 	mov	x4, x24
   7cdc4:	3dc023e7 	ldr	q7, [sp, #128]
   7cdc8:	3cdd03a5 	ldur	q5, [x29, #-48]
   7cdcc:	aa1303f8 	mov	x24, x19
   7cdd0:	aa1703f3 	mov	x19, x23
   7cdd4:	d2c1c017 	mov	x23, #0xe0000000000         	// #15393162788864
   7cdd8:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7cddc:	72a06201 	movk	w1, #0x310, lsl #16
   7cde0:	aa1603e2 	mov	x2, x22
   7cde4:	d2c10016 	mov	x22, #0x80000000000         	// #8796093022208
   7cde8:	f2e02017 	movk	x23, #0x100, lsl #48
   7cdec:	17fffc31 	b	7beb0 <spin_92+0x105c>
   7cdf0:	aa1a03e0 	mov	x0, x26
   7cdf4:	aa1903e1 	mov	x1, x25
   7cdf8:	2a1f03e2 	mov	w2, wzr
   7cdfc:	97fe1d79 	bl	43e0 <heap_hand>
   7ce00:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7ce04:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7ce08:	72a06201 	movk	w1, #0x310, lsl #16
   7ce0c:	17fff8d8 	b	7b16c <spin_92+0x318>
   7ce10:	aa1a03e0 	mov	x0, x26
   7ce14:	aa1903e1 	mov	x1, x25
   7ce18:	2a1f03e2 	mov	w2, wzr
   7ce1c:	aa1103ed 	mov	x13, x17
   7ce20:	aa1203ee 	mov	x14, x18
   7ce24:	97fe1d6f 	bl	43e0 <heap_hand>
   7ce28:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7ce2c:	aa0e03f2 	mov	x18, x14
   7ce30:	aa0d03f1 	mov	x17, x13
   7ce34:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7ce38:	72a06201 	movk	w1, #0x310, lsl #16
   7ce3c:	17fff8f8 	b	7b21c <spin_92+0x3c8>
   7ce40:	aa1a03e0 	mov	x0, x26
   7ce44:	aa1903e1 	mov	x1, x25
   7ce48:	2a1f03e2 	mov	w2, wzr
   7ce4c:	ad3a07a2 	stp	q2, q1, [x29, #-192]
   7ce50:	97fe1d64 	bl	43e0 <heap_hand>
   7ce54:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   7ce58:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7ce5c:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7ce60:	72a06201 	movk	w1, #0x310, lsl #16
   7ce64:	17fff921 	b	7b2e8 <spin_92+0x494>
   7ce68:	aa1a03e0 	mov	x0, x26
   7ce6c:	aa1903e1 	mov	x1, x25
   7ce70:	2a1f03e2 	mov	w2, wzr
   7ce74:	97fe1d5b 	bl	43e0 <heap_hand>
   7ce78:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7ce7c:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7ce80:	72a06201 	movk	w1, #0x310, lsl #16
   7ce84:	17fffb0d 	b	7bab8 <spin_92+0xc64>
   7ce88:	aa1a03e0 	mov	x0, x26
   7ce8c:	aa1903e1 	mov	x1, x25
   7ce90:	aa0203f6 	mov	x22, x2
   7ce94:	2a1f03e2 	mov	w2, wzr
   7ce98:	aa0403ee 	mov	x14, x4
   7ce9c:	97fe1d51 	bl	43e0 <heap_hand>
   7cea0:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7cea4:	aa0e03e4 	mov	x4, x14
   7cea8:	aa1603e2 	mov	x2, x22
   7ceac:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7ceb0:	72a06201 	movk	w1, #0x310, lsl #16
   7ceb4:	d2c10016 	mov	x22, #0x80000000000         	// #8796093022208
   7ceb8:	17fffb2c 	b	7bb68 <spin_92+0xd14>
   7cebc:	aa1a03e0 	mov	x0, x26
   7cec0:	aa1903e1 	mov	x1, x25
   7cec4:	aa0203f6 	mov	x22, x2
   7cec8:	2a1f03e2 	mov	w2, wzr
   7cecc:	aa0403ee 	mov	x14, x4
   7ced0:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   7ced4:	3d802fe4 	str	q4, [sp, #176]
   7ced8:	97fe1d42 	bl	43e0 <heap_hand>
   7cedc:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   7cee0:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7cee4:	3dc02fe4 	ldr	q4, [sp, #176]
   7cee8:	aa0e03e4 	mov	x4, x14
   7ceec:	aa1603e2 	mov	x2, x22
   7cef0:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7cef4:	72a06201 	movk	w1, #0x310, lsl #16
   7cef8:	d2c10016 	mov	x22, #0x80000000000         	// #8796093022208
   7cefc:	17fffb48 	b	7bc1c <spin_92+0xdc8>
   7cf00:	aa1a03e0 	mov	x0, x26
   7cf04:	aa1903e1 	mov	x1, x25
   7cf08:	2a1f03e2 	mov	w2, wzr
   7cf0c:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   7cf10:	3d802fe4 	str	q4, [sp, #176]
   7cf14:	3c9d03a5 	stur	q5, [x29, #-48]
   7cf18:	3d802be6 	str	q6, [sp, #160]
   7cf1c:	3d8023e7 	str	q7, [sp, #128]
   7cf20:	97fe1d30 	bl	43e0 <heap_hand>
   7cf24:	ad4513e6 	ldp	q6, q4, [sp, #160]
   7cf28:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7cf2c:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   7cf30:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7cf34:	3dc023e7 	ldr	q7, [sp, #128]
   7cf38:	3cdd03a5 	ldur	q5, [x29, #-48]
   7cf3c:	72a06201 	movk	w1, #0x310, lsl #16
   7cf40:	17fffbc8 	b	7be60 <spin_92+0x100c>
   7cf44:	aa1a03e0 	mov	x0, x26
   7cf48:	aa1903e1 	mov	x1, x25
   7cf4c:	52800022 	mov	w2, #0x1                   	// #1
   7cf50:	aa1103ec 	mov	x12, x17
   7cf54:	aa1203ee 	mov	x14, x18
   7cf58:	ad3a07a2 	stp	q2, q1, [x29, #-192]
   7cf5c:	97fe1d21 	bl	43e0 <heap_hand>
   7cf60:	1400005a 	b	7d0c8 <spin_92+0x2274>
   7cf64:	aa1a03e0 	mov	x0, x26
   7cf68:	aa1903e1 	mov	x1, x25
   7cf6c:	52800022 	mov	w2, #0x1                   	// #1
   7cf70:	aa1103ee 	mov	x14, x17
   7cf74:	aa1203f6 	mov	x22, x18
   7cf78:	97fe1d1a 	bl	43e0 <heap_hand>
   7cf7c:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   7cf80:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7cf84:	aa1603f2 	mov	x18, x22
   7cf88:	aa0e03f1 	mov	x17, x14
   7cf8c:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7cf90:	72a06201 	movk	w1, #0x310, lsl #16
   7cf94:	17fff9da 	b	7b6fc <spin_92+0x8a8>
   7cf98:	aa1a03e0 	mov	x0, x26
   7cf9c:	aa1903e1 	mov	x1, x25
   7cfa0:	52800062 	mov	w2, #0x3                   	// #3
   7cfa4:	aa1103ec 	mov	x12, x17
   7cfa8:	aa1203ed 	mov	x13, x18
   7cfac:	3d802be3 	str	q3, [sp, #160]
   7cfb0:	3d8023e4 	str	q4, [sp, #128]
   7cfb4:	97fe1d0b 	bl	43e0 <heap_hand>
   7cfb8:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   7cfbc:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7cfc0:	3dc023e4 	ldr	q4, [sp, #128]
   7cfc4:	3dc02be3 	ldr	q3, [sp, #160]
   7cfc8:	aa0d03f2 	mov	x18, x13
   7cfcc:	aa0c03f1 	mov	x17, x12
   7cfd0:	900009a3 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7cfd4:	72a06201 	movk	w1, #0x310, lsl #16
   7cfd8:	17fffa08 	b	7b7f8 <spin_92+0x9a4>
   7cfdc:	aa1a03e0 	mov	x0, x26
   7cfe0:	aa1903e1 	mov	x1, x25
   7cfe4:	aa0203eb 	mov	x11, x2
   7cfe8:	52800062 	mov	w2, #0x3                   	// #3
   7cfec:	aa0403ec 	mov	x12, x4
   7cff0:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   7cff4:	3d802fe4 	str	q4, [sp, #176]
   7cff8:	3c9d03a5 	stur	q5, [x29, #-48]
   7cffc:	3d802be6 	str	q6, [sp, #160]
   7d000:	3d8023e7 	str	q7, [sp, #128]
   7d004:	ad020bf1 	stp	q17, q2, [sp, #64]
   7d008:	97fe1cf6 	bl	43e0 <heap_hand>
   7d00c:	ad420bf1 	ldp	q17, q2, [sp, #64]
   7d010:	aa0c03e4 	mov	x4, x12
   7d014:	ad4513e6 	ldp	q6, q4, [sp, #160]
   7d018:	aa0b03e2 	mov	x2, x11
   7d01c:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   7d020:	14000073 	b	7d1ec <spin_92+0x2398>
   7d024:	aa1a03e0 	mov	x0, x26
   7d028:	aa1903e1 	mov	x1, x25
   7d02c:	aa0203ef 	mov	x15, x2
   7d030:	2a1f03e2 	mov	w2, wzr
   7d034:	aa0403ee 	mov	x14, x4
   7d038:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   7d03c:	3d802fe4 	str	q4, [sp, #176]
   7d040:	97fe1ce8 	bl	43e0 <heap_hand>
   7d044:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   7d048:	aa0e03e4 	mov	x4, x14
   7d04c:	3dc02fe4 	ldr	q4, [sp, #176]
   7d050:	aa0f03e2 	mov	x2, x15
   7d054:	140000bd 	b	7d348 <spin_92+0x24f4>
   7d058:	aa1a03e0 	mov	x0, x26
   7d05c:	aa1903e1 	mov	x1, x25
   7d060:	aa0203f4 	mov	x20, x2
   7d064:	52800022 	mov	w2, #0x1                   	// #1
   7d068:	aa0403ee 	mov	x14, x4
   7d06c:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   7d070:	3d802fe4 	str	q4, [sp, #176]
   7d074:	97fe1cdb 	bl	43e0 <heap_hand>
   7d078:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   7d07c:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7d080:	3dc02fe4 	ldr	q4, [sp, #176]
   7d084:	aa0e03e4 	mov	x4, x14
   7d088:	aa1403e2 	mov	x2, x20
   7d08c:	f0000983 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7d090:	72a06201 	movk	w1, #0x310, lsl #16
   7d094:	17fffb4f 	b	7bdd0 <spin_92+0xf7c>
   7d098:	aa0a8188 	orr	x8, x12, x10, lsl #32
   7d09c:	aa1a03e0 	mov	x0, x26
   7d0a0:	aa1903e1 	mov	x1, x25
   7d0a4:	52800044 	mov	w4, #0x2                   	// #2
   7d0a8:	aa1103ec 	mov	x12, x17
   7d0ac:	aa1203ee 	mov	x14, x18
   7d0b0:	d358fd03 	lsr	x3, x8, #24
   7d0b4:	ad3a07a2 	stp	q2, q1, [x29, #-192]
   7d0b8:	8b030f48 	add	x8, x26, x3, lsl #3
   7d0bc:	f940010a 	ldr	x10, [x8]
   7d0c0:	b940090d 	ldr	w13, [x8, #8]
   7d0c4:	97fe1cfa 	bl	44ac <span_fade>
   7d0c8:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   7d0cc:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7d0d0:	aa0e03f2 	mov	x18, x14
   7d0d4:	aa0c03f1 	mov	x17, x12
   7d0d8:	f0000983 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7d0dc:	72a06201 	movk	w1, #0x310, lsl #16
   7d0e0:	17fff8f0 	b	7b4a0 <spin_92+0x64c>
   7d0e4:	aa0b81c8 	orr	x8, x14, x11, lsl #32
   7d0e8:	aa1a03e0 	mov	x0, x26
   7d0ec:	aa1903e1 	mov	x1, x25
   7d0f0:	52800044 	mov	w4, #0x2                   	// #2
   7d0f4:	d358fd03 	lsr	x3, x8, #24
   7d0f8:	8b030f48 	add	x8, x26, x3, lsl #3
   7d0fc:	f940010b 	ldr	x11, [x8]
   7d100:	b940091c 	ldr	w28, [x8, #8]
   7d104:	97fe1cea 	bl	44ac <span_fade>
   7d108:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   7d10c:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7d110:	aa0f03f2 	mov	x18, x15
   7d114:	aa1803ef 	mov	x15, x24
   7d118:	aa1303f8 	mov	x24, x19
   7d11c:	aa1703f3 	mov	x19, x23
   7d120:	d2c1c017 	mov	x23, #0xe0000000000         	// #15393162788864
   7d124:	f0000983 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7d128:	72a06201 	movk	w1, #0x310, lsl #16
   7d12c:	aa1603f1 	mov	x17, x22
   7d130:	f2e02017 	movk	x23, #0x100, lsl #48
   7d134:	17fff972 	b	7b6fc <spin_92+0x8a8>
   7d138:	aa1a03e0 	mov	x0, x26
   7d13c:	aa1903e1 	mov	x1, x25
   7d140:	aa0d03e2 	mov	x2, x13
   7d144:	aa0c03e3 	mov	x3, x12
   7d148:	528000a4 	mov	w4, #0x5                   	// #5
   7d14c:	3d802be3 	str	q3, [sp, #160]
   7d150:	3d8023e4 	str	q4, [sp, #128]
   7d154:	97fe1cd6 	bl	44ac <span_fade>
   7d158:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   7d15c:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7d160:	3dc023e4 	ldr	q4, [sp, #128]
   7d164:	3dc02be3 	ldr	q3, [sp, #160]
   7d168:	aa1303f1 	mov	x17, x19
   7d16c:	aa1703f3 	mov	x19, x23
   7d170:	d2c1c017 	mov	x23, #0xe0000000000         	// #15393162788864
   7d174:	aa1c03f2 	mov	x18, x28
   7d178:	aa0f03fc 	mov	x28, x15
   7d17c:	aa1803ef 	mov	x15, x24
   7d180:	aa0b03f8 	mov	x24, x11
   7d184:	aa0903eb 	mov	x11, x9
   7d188:	f9405be9 	ldr	x9, [sp, #176]
   7d18c:	f0000983 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7d190:	72a06201 	movk	w1, #0x310, lsl #16
   7d194:	f2e02017 	movk	x23, #0x100, lsl #48
   7d198:	17fff998 	b	7b7f8 <spin_92+0x9a4>
   7d19c:	aa1a03e0 	mov	x0, x26
   7d1a0:	aa1903e1 	mov	x1, x25
   7d1a4:	aa0203f6 	mov	x22, x2
   7d1a8:	aa0b03e2 	mov	x2, x11
   7d1ac:	aa0c03e3 	mov	x3, x12
   7d1b0:	aa0403eb 	mov	x11, x4
   7d1b4:	528000a4 	mov	w4, #0x5                   	// #5
   7d1b8:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   7d1bc:	3d802fe4 	str	q4, [sp, #176]
   7d1c0:	3c9d03a5 	stur	q5, [x29, #-48]
   7d1c4:	3d802be6 	str	q6, [sp, #160]
   7d1c8:	3d8023e7 	str	q7, [sp, #128]
   7d1cc:	ad020bf1 	stp	q17, q2, [sp, #64]
   7d1d0:	97fe1cb7 	bl	44ac <span_fade>
   7d1d4:	ad420bf1 	ldp	q17, q2, [sp, #64]
   7d1d8:	aa0b03e4 	mov	x4, x11
   7d1dc:	ad4513e6 	ldp	q6, q4, [sp, #160]
   7d1e0:	aa1603e2 	mov	x2, x22
   7d1e4:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   7d1e8:	d2c10016 	mov	x22, #0x80000000000         	// #8796093022208
   7d1ec:	3dc023e7 	ldr	q7, [sp, #128]
   7d1f0:	3cdd03a5 	ldur	q5, [x29, #-48]
   7d1f4:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7d1f8:	f0000983 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7d1fc:	72a06201 	movk	w1, #0x310, lsl #16
   7d200:	17fffb5d 	b	7bf74 <spin_92+0x1120>
   7d204:	aa1a03e0 	mov	x0, x26
   7d208:	aa1903e1 	mov	x1, x25
   7d20c:	2a1f03e2 	mov	w2, wzr
   7d210:	aa1103ee 	mov	x14, x17
   7d214:	f9005bf2 	str	x18, [sp, #176]
   7d218:	ad3a07a2 	stp	q2, q1, [x29, #-192]
   7d21c:	97fe1c71 	bl	43e0 <heap_hand>
   7d220:	ad7a07a2 	ldp	q2, q1, [x29, #-192]
   7d224:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7d228:	f9405bf2 	ldr	x18, [sp, #176]
   7d22c:	aa0e03f1 	mov	x17, x14
   7d230:	f0000983 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7d234:	72a06201 	movk	w1, #0x310, lsl #16
   7d238:	17fff88d 	b	7b46c <spin_92+0x618>
   7d23c:	aa1a03e0 	mov	x0, x26
   7d240:	aa1903e1 	mov	x1, x25
   7d244:	2a1f03e2 	mov	w2, wzr
   7d248:	97fe1c66 	bl	43e0 <heap_hand>
   7d24c:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7d250:	f0000983 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7d254:	72a06201 	movk	w1, #0x310, lsl #16
   7d258:	17fff914 	b	7b6a8 <spin_92+0x854>
   7d25c:	aa1a03e0 	mov	x0, x26
   7d260:	aa1903e1 	mov	x1, x25
   7d264:	2a1f03e2 	mov	w2, wzr
   7d268:	3d802be3 	str	q3, [sp, #160]
   7d26c:	3d8023e4 	str	q4, [sp, #128]
   7d270:	97fe1c5c 	bl	43e0 <heap_hand>
   7d274:	3dc023e4 	ldr	q4, [sp, #128]
   7d278:	3dc02be3 	ldr	q3, [sp, #160]
   7d27c:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7d280:	f0000983 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7d284:	72a06201 	movk	w1, #0x310, lsl #16
   7d288:	17fff944 	b	7b798 <spin_92+0x944>
   7d28c:	aa1a03e0 	mov	x0, x26
   7d290:	aa1903e1 	mov	x1, x25
   7d294:	aa0203eb 	mov	x11, x2
   7d298:	2a1f03e2 	mov	w2, wzr
   7d29c:	aa1303f7 	mov	x23, x19
   7d2a0:	aa0f03f3 	mov	x19, x15
   7d2a4:	aa1803ef 	mov	x15, x24
   7d2a8:	aa0403f8 	mov	x24, x4
   7d2ac:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   7d2b0:	3d802fe4 	str	q4, [sp, #176]
   7d2b4:	3c9d03a5 	stur	q5, [x29, #-48]
   7d2b8:	3d802be6 	str	q6, [sp, #160]
   7d2bc:	3d8023e7 	str	q7, [sp, #128]
   7d2c0:	ad020bf1 	stp	q17, q2, [sp, #64]
   7d2c4:	97fe1c47 	bl	43e0 <heap_hand>
   7d2c8:	ad420bf1 	ldp	q17, q2, [sp, #64]
   7d2cc:	aa1803e4 	mov	x4, x24
   7d2d0:	ad4513e6 	ldp	q6, q4, [sp, #160]
   7d2d4:	aa0f03f8 	mov	x24, x15
   7d2d8:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   7d2dc:	aa1303ef 	mov	x15, x19
   7d2e0:	3dc023e7 	ldr	q7, [sp, #128]
   7d2e4:	3cdd03a5 	ldur	q5, [x29, #-48]
   7d2e8:	aa1703f3 	mov	x19, x23
   7d2ec:	d2c1c017 	mov	x23, #0xe0000000000         	// #15393162788864
   7d2f0:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7d2f4:	aa0b03e2 	mov	x2, x11
   7d2f8:	f2e02017 	movk	x23, #0x100, lsl #48
   7d2fc:	f0000983 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7d300:	72a06201 	movk	w1, #0x310, lsl #16
   7d304:	17fffb0f 	b	7bf40 <spin_92+0x10ec>
   7d308:	aa118248 	orr	x8, x18, x17, lsl #32
   7d30c:	aa1a03e0 	mov	x0, x26
   7d310:	aa1903e1 	mov	x1, x25
   7d314:	aa0203f4 	mov	x20, x2
   7d318:	aa0f03e2 	mov	x2, x15
   7d31c:	aa0403ee 	mov	x14, x4
   7d320:	d358fd03 	lsr	x3, x8, #24
   7d324:	52800024 	mov	w4, #0x1                   	// #1
   7d328:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   7d32c:	3d802fe4 	str	q4, [sp, #176]
   7d330:	f8637b58 	ldr	x24, [x26, x3, lsl #3]
   7d334:	97fe1c5e 	bl	44ac <span_fade>
   7d338:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   7d33c:	aa0e03e4 	mov	x4, x14
   7d340:	3dc02fe4 	ldr	q4, [sp, #176]
   7d344:	aa1403e2 	mov	x2, x20
   7d348:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7d34c:	f0000983 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7d350:	72a06201 	movk	w1, #0x310, lsl #16
   7d354:	17fffa6c 	b	7bd04 <spin_92+0xeb0>
   7d358:	aa0f8228 	orr	x8, x17, x15, lsl #32
   7d35c:	aa1a03e0 	mov	x0, x26
   7d360:	aa1903e1 	mov	x1, x25
   7d364:	aa1803e2 	mov	x2, x24
   7d368:	52800044 	mov	w4, #0x2                   	// #2
   7d36c:	d358fd03 	lsr	x3, x8, #24
   7d370:	8b030f48 	add	x8, x26, x3, lsl #3
   7d374:	f940010f 	ldr	x15, [x8]
   7d378:	b9400908 	ldr	w8, [x8, #8]
   7d37c:	aa0803f8 	mov	x24, x8
   7d380:	97fe1c4b 	bl	44ac <span_fade>
   7d384:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   7d388:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7d38c:	f85d03b4 	ldur	x20, [x29, #-48]
   7d390:	3dc02fe4 	ldr	q4, [sp, #176]
   7d394:	f0000983 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7d398:	72a06201 	movk	w1, #0x310, lsl #16
   7d39c:	aa1603e2 	mov	x2, x22
   7d3a0:	d2c10016 	mov	x22, #0x80000000000         	// #8796093022208
   7d3a4:	aa0e03e4 	mov	x4, x14
   7d3a8:	17fffa8b 	b	7bdd4 <spin_92+0xf80>
   7d3ac:	aa1a03e0 	mov	x0, x26
   7d3b0:	aa1903e1 	mov	x1, x25
   7d3b4:	aa0203f4 	mov	x20, x2
   7d3b8:	2a1f03e2 	mov	w2, wzr
   7d3bc:	aa0403ee 	mov	x14, x4
   7d3c0:	ad3a07a3 	stp	q3, q1, [x29, #-192]
   7d3c4:	3d802fe4 	str	q4, [sp, #176]
   7d3c8:	97fe1c06 	bl	43e0 <heap_hand>
   7d3cc:	ad7a07a3 	ldp	q3, q1, [x29, #-192]
   7d3d0:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7d3d4:	3dc02fe4 	ldr	q4, [sp, #176]
   7d3d8:	aa0e03e4 	mov	x4, x14
   7d3dc:	aa1403e2 	mov	x2, x20
   7d3e0:	f0000983 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7d3e4:	72a06201 	movk	w1, #0x310, lsl #16
   7d3e8:	17fffa3a 	b	7bcd0 <spin_92+0xe7c>
   7d3ec:	aa1a03e0 	mov	x0, x26
   7d3f0:	aa1903e1 	mov	x1, x25
   7d3f4:	2a1f03e2 	mov	w2, wzr
   7d3f8:	97fe1bfa 	bl	43e0 <heap_hand>
   7d3fc:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7d400:	f0000983 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7d404:	72a06201 	movk	w1, #0x310, lsl #16
   7d408:	17fffa60 	b	7bd88 <spin_92+0xf34>
   7d40c:	eb17037f 	cmp	x27, x23
   7d410:	54000061 	b.ne	7d41c <spin_92+0x25c8>  // b.any
   7d414:	f9400ff5 	ldr	x21, [sp, #24]
   7d418:	14000009 	b	7d43c <spin_92+0x25e8>
   7d41c:	f9400ff5 	ldr	x21, [sp, #24]
   7d420:	b6f8007b 	tbz	x27, #63, 7d42c <spin_92+0x25d8>
   7d424:	92409f68 	and	x8, x27, #0xffffffffff
   7d428:	f8687b5f 	ldr	xzr, [x26, x8, lsl #3]
   7d42c:	92583f68 	and	x8, x27, #0xffff0000000000
   7d430:	d2c1c00b 	mov	x11, #0xe0000000000         	// #15393162788864
   7d434:	eb0b011f 	cmp	x8, x11
   7d438:	54000781 	b.ne	7d528 <spin_92+0x26d4>  // b.any
   7d43c:	b940cbae 	ldr	w14, [x29, #200]
   7d440:	f9406ba9 	ldr	x9, [x29, #208]
   7d444:	3400140e 	cbz	w14, 7d6c4 <spin_92+0x2870>
   7d448:	f940072a 	ldr	x10, [x25, #8]
   7d44c:	b400304a 	cbz	x10, 7da54 <spin_92+0x2c00>
   7d450:	f86a7b48 	ldr	x8, [x26, x10, lsl #3]
   7d454:	f940872b 	ldr	x11, [x25, #264]
   7d458:	f9000728 	str	x8, [x25, #8]
   7d45c:	d1000968 	sub	x8, x11, #0x2
   7d460:	f9008728 	str	x8, [x25, #264]
   7d464:	d378fd28 	lsr	x8, x9, #56
   7d468:	b940dbab 	ldr	w11, [x29, #216]
   7d46c:	f100091f 	cmp	x8, #0x2
   7d470:	54003020 	b.eq	7da74 <spin_92+0x2c20>  // b.none
   7d474:	aa0903e0 	mov	x0, x9
   7d478:	8b0a0f48 	add	x8, x26, x10, lsl #3
   7d47c:	b94103ac 	ldr	w12, [x29, #256]
   7d480:	b940fbad 	ldr	w13, [x29, #248]
   7d484:	b940f3af 	ldr	w15, [x29, #240]
   7d488:	b940ebb3 	ldr	w19, [x29, #232]
   7d48c:	b940e3b4 	ldr	w20, [x29, #224]
   7d490:	a9002d00 	stp	x0, x11, [x8]
   7d494:	f9400f2b 	ldr	x11, [x25, #24]
   7d498:	b4002feb 	cbz	x11, 7da94 <spin_92+0x2c40>
   7d49c:	f86b7b48 	ldr	x8, [x26, x11, lsl #3]
   7d4a0:	f9408f30 	ldr	x16, [x25, #280]
   7d4a4:	f9000f28 	str	x8, [x25, #24]
   7d4a8:	d1002208 	sub	x8, x16, #0x8
   7d4ac:	f9008f28 	str	x8, [x25, #280]
   7d4b0:	8b0b0f48 	add	x8, x26, x11, lsl #3
   7d4b4:	a9004d14 	stp	x20, x19, [x8]
   7d4b8:	a901350f 	stp	x15, x13, [x8, #16]
   7d4bc:	f900110c 	str	x12, [x8, #32]
   7d4c0:	f940072c 	ldr	x12, [x25, #8]
   7d4c4:	b4002f8c 	cbz	x12, 7dab4 <spin_92+0x2c60>
   7d4c8:	f86c7b48 	ldr	x8, [x26, x12, lsl #3]
   7d4cc:	f940872d 	ldr	x13, [x25, #264]
   7d4d0:	f9000728 	str	x8, [x25, #8]
   7d4d4:	d10009a8 	sub	x8, x13, #0x2
   7d4d8:	f9008728 	str	x8, [x25, #264]
   7d4dc:	d2c48008 	mov	x8, #0x240000000000        	// #39582418599936
   7d4e0:	f2e04008 	movk	x8, #0x200, lsl #48
   7d4e4:	aa080142 	orr	x2, x10, x8
   7d4e8:	d378fc48 	lsr	x8, x2, #56
   7d4ec:	f100091f 	cmp	x8, #0x2
   7d4f0:	54002f20 	b.eq	7dad4 <spin_92+0x2c80>  // b.none
   7d4f4:	d2c4a008 	mov	x8, #0x250000000000        	// #40681930227712
   7d4f8:	8b0c0f4a 	add	x10, x26, x12, lsl #3
   7d4fc:	f2e04008 	movk	x8, #0x200, lsl #48
   7d500:	aa080168 	orr	x8, x11, x8
   7d504:	f9000142 	str	x2, [x10]
   7d508:	d378fd0b 	lsr	x11, x8, #56
   7d50c:	f100097f 	cmp	x11, #0x2
   7d510:	54002f20 	b.eq	7daf4 <spin_92+0x2ca0>  // b.none
   7d514:	f9000548 	str	x8, [x10, #8]
   7d518:	d2c3e008 	mov	x8, #0x1f0000000000        	// #34084860461056
   7d51c:	f2e04008 	movk	x8, #0x200, lsl #48
   7d520:	aa080182 	orr	x2, x12, x8
   7d524:	14000069 	b	7d6c8 <spin_92+0x2874>
   7d528:	92409f68 	and	x8, x27, #0xffffffffff
   7d52c:	8b080f4c 	add	x12, x26, x8, lsl #3
   7d530:	b7f8009b 	tbnz	x27, #63, 7d540 <spin_92+0x26ec>
   7d534:	a9406d8a 	ldp	x10, x27, [x12]
   7d538:	aa0803e9 	mov	x9, x8
   7d53c:	14000018 	b	7d59c <spin_92+0x2748>
   7d540:	b9400589 	ldr	w9, [x12, #4]
   7d544:	b940018a 	ldr	w10, [x12]
   7d548:	92405d4d 	and	x13, x10, #0xffffff
   7d54c:	f10005bf 	cmp	x13, #0x1
   7d550:	54000921 	b.ne	7d674 <spin_92+0x2820>  // b.any
   7d554:	aa098149 	orr	x9, x10, x9, lsl #32
   7d558:	88dffd9f 	ldar	wzr, [x12]
   7d55c:	f940032c 	ldr	x12, [x25]
   7d560:	d358fd29 	lsr	x9, x9, #24
   7d564:	8b090f4d 	add	x13, x26, x9, lsl #3
   7d568:	a9406daa 	ldp	x10, x27, [x13]
   7d56c:	f8287b4c 	str	x12, [x26, x8, lsl #3]
   7d570:	f940832c 	ldr	x12, [x25, #256]
   7d574:	3948306d 	ldrb	w13, [x3, #524]
   7d578:	f9000328 	str	x8, [x25]
   7d57c:	91000588 	add	x8, x12, #0x1
   7d580:	710005bf 	cmp	w13, #0x1
   7d584:	f9008328 	str	x8, [x25, #256]
   7d588:	54000921 	b.ne	7d6ac <spin_92+0x2858>  // b.any
   7d58c:	f140211f 	cmp	x8, #0x8, lsl #12
   7d590:	540008e2 	b.cs	7d6ac <spin_92+0x2858>  // b.hs, b.nlast
   7d594:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7d598:	72a06201 	movk	w1, #0x310, lsl #16
   7d59c:	eb01013f 	cmp	x9, x1
   7d5a0:	54000108 	b.hi	7d5c0 <spin_92+0x276c>  // b.pmore
   7d5a4:	f9400729 	ldr	x9, [x25, #8]
   7d5a8:	b4000549 	cbz	x9, 7d650 <spin_92+0x27fc>
   7d5ac:	f8697b48 	ldr	x8, [x26, x9, lsl #3]
   7d5b0:	f940872c 	ldr	x12, [x25, #264]
   7d5b4:	f9000728 	str	x8, [x25, #8]
   7d5b8:	d1000988 	sub	x8, x12, #0x2
   7d5bc:	f9008728 	str	x8, [x25, #264]
   7d5c0:	d378fd48 	lsr	x8, x10, #56
   7d5c4:	f100091f 	cmp	x8, #0x2
   7d5c8:	540001c0 	b.eq	7d600 <spin_92+0x27ac>  // b.none
   7d5cc:	d378fee8 	lsr	x8, x23, #56
   7d5d0:	8b090f4c 	add	x12, x26, x9, lsl #3
   7d5d4:	f100091f 	cmp	x8, #0x2
   7d5d8:	f900018a 	str	x10, [x12]
   7d5dc:	54000260 	b.eq	7d628 <spin_92+0x27d4>  // b.none
   7d5e0:	92583f68 	and	x8, x27, #0xffff0000000000
   7d5e4:	f9000597 	str	x23, [x12, #8]
   7d5e8:	eb0b011f 	cmp	x8, x11
   7d5ec:	d2c1e008 	mov	x8, #0xf0000000000         	// #16492674416640
   7d5f0:	f2e04008 	movk	x8, #0x200, lsl #48
   7d5f4:	aa080137 	orr	x23, x9, x8
   7d5f8:	54fff981 	b.ne	7d528 <spin_92+0x26d4>  // b.any
   7d5fc:	17ffff90 	b	7d43c <spin_92+0x25e8>
   7d600:	aa1a03e0 	mov	x0, x26
   7d604:	aa1903e1 	mov	x1, x25
   7d608:	aa0a03e2 	mov	x2, x10
   7d60c:	52800023 	mov	w3, #0x1                   	// #1
   7d610:	97fe1e20 	bl	4e90 <rfc_wrap>
   7d614:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7d618:	f0000983 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7d61c:	aa0003ea 	mov	x10, x0
   7d620:	72a06201 	movk	w1, #0x310, lsl #16
   7d624:	17ffffea 	b	7d5cc <spin_92+0x2778>
   7d628:	aa1a03e0 	mov	x0, x26
   7d62c:	aa1903e1 	mov	x1, x25
   7d630:	aa1703e2 	mov	x2, x23
   7d634:	52800023 	mov	w3, #0x1                   	// #1
   7d638:	97fe1e16 	bl	4e90 <rfc_wrap>
   7d63c:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7d640:	f0000983 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7d644:	aa0003f7 	mov	x23, x0
   7d648:	72a06201 	movk	w1, #0x310, lsl #16
   7d64c:	17ffffe5 	b	7d5e0 <spin_92+0x278c>
   7d650:	aa1a03e0 	mov	x0, x26
   7d654:	aa1903e1 	mov	x1, x25
   7d658:	52800022 	mov	w2, #0x1                   	// #1
   7d65c:	97fe1d24 	bl	4aec <heap_alloc_miss>
   7d660:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7d664:	f0000983 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7d668:	aa0003e9 	mov	x9, x0
   7d66c:	72a06201 	movk	w1, #0x310, lsl #16
   7d670:	17ffffd4 	b	7d5c0 <spin_92+0x276c>
   7d674:	aa098148 	orr	x8, x10, x9, lsl #32
   7d678:	aa1a03e0 	mov	x0, x26
   7d67c:	aa1903e1 	mov	x1, x25
   7d680:	aa1b03e2 	mov	x2, x27
   7d684:	52800044 	mov	w4, #0x2                   	// #2
   7d688:	d358fd03 	lsr	x3, x8, #24
   7d68c:	8b030f48 	add	x8, x26, x3, lsl #3
   7d690:	a940250a 	ldp	x10, x9, [x8]
   7d694:	97fe1b86 	bl	44ac <span_fade>
   7d698:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7d69c:	f0000983 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7d6a0:	aa0903fb 	mov	x27, x9
   7d6a4:	72a06201 	movk	w1, #0x310, lsl #16
   7d6a8:	17ffffbf 	b	7d5a4 <spin_92+0x2750>
   7d6ac:	aa1a03e0 	mov	x0, x26
   7d6b0:	aa1903e1 	mov	x1, x25
   7d6b4:	2a1f03e2 	mov	w2, wzr
   7d6b8:	97fe1b4a 	bl	43e0 <heap_hand>
   7d6bc:	f0000983 	adrp	x3, 1b0000 <memcpy@GLIBC_2.17>
   7d6c0:	17ffffb5 	b	7d594 <spin_92+0x2740>
   7d6c4:	aa1f03e2 	mov	x2, xzr
   7d6c8:	f94063ab 	ldr	x11, [x29, #192]
   7d6cc:	b6f80322 	tbz	x2, #63, 7d730 <spin_92+0x28dc>
   7d6d0:	f85f03a8 	ldur	x8, [x29, #-16]
   7d6d4:	eb08005f 	cmp	x2, x8
   7d6d8:	540002c0 	b.eq	7d730 <spin_92+0x28dc>  // b.none
   7d6dc:	f85b83a8 	ldur	x8, [x29, #-72]
   7d6e0:	eb08005f 	cmp	x2, x8
   7d6e4:	54000260 	b.eq	7d730 <spin_92+0x28dc>  // b.none
   7d6e8:	f85c03a8 	ldur	x8, [x29, #-64]
   7d6ec:	eb08005f 	cmp	x2, x8
   7d6f0:	54000200 	b.eq	7d730 <spin_92+0x28dc>  // b.none
   7d6f4:	f85c83a8 	ldur	x8, [x29, #-56]
   7d6f8:	eb08005f 	cmp	x2, x8
   7d6fc:	540001a0 	b.eq	7d730 <spin_92+0x28dc>  // b.none
   7d700:	f85e03a8 	ldur	x8, [x29, #-32]
   7d704:	eb08005f 	cmp	x2, x8
   7d708:	54000140 	b.eq	7d730 <spin_92+0x28dc>  // b.none
   7d70c:	f85e83a8 	ldur	x8, [x29, #-24]
   7d710:	eb08005f 	cmp	x2, x8
   7d714:	540000e0 	b.eq	7d730 <spin_92+0x28dc>  // b.none
   7d718:	eb09005f 	cmp	x2, x9
   7d71c:	540000a0 	b.eq	7d730 <spin_92+0x28dc>  // b.none
   7d720:	eb0b005f 	cmp	x2, x11
   7d724:	54000060 	b.eq	7d730 <spin_92+0x28dc>  // b.none
   7d728:	92409c48 	and	x8, x2, #0xffffffffff
   7d72c:	f8687b5f 	ldr	xzr, [x26, x8, lsl #3]
   7d730:	b9402bf4 	ldr	w20, [sp, #40]
   7d734:	b6f80337 	tbz	x23, #63, 7d798 <spin_92+0x2944>
   7d738:	f85f03a8 	ldur	x8, [x29, #-16]
   7d73c:	eb0802ff 	cmp	x23, x8
   7d740:	540002c0 	b.eq	7d798 <spin_92+0x2944>  // b.none
   7d744:	f85b83a8 	ldur	x8, [x29, #-72]
   7d748:	eb0802ff 	cmp	x23, x8
   7d74c:	54000260 	b.eq	7d798 <spin_92+0x2944>  // b.none
   7d750:	f85c03a8 	ldur	x8, [x29, #-64]
   7d754:	eb0802ff 	cmp	x23, x8
   7d758:	54000200 	b.eq	7d798 <spin_92+0x2944>  // b.none
   7d75c:	f85c83a8 	ldur	x8, [x29, #-56]
   7d760:	eb0802ff 	cmp	x23, x8
   7d764:	540001a0 	b.eq	7d798 <spin_92+0x2944>  // b.none
   7d768:	f85e03a8 	ldur	x8, [x29, #-32]
   7d76c:	eb0802ff 	cmp	x23, x8
   7d770:	54000140 	b.eq	7d798 <spin_92+0x2944>  // b.none
   7d774:	f85e83a8 	ldur	x8, [x29, #-24]
   7d778:	eb0802ff 	cmp	x23, x8
   7d77c:	540000e0 	b.eq	7d798 <spin_92+0x2944>  // b.none
   7d780:	eb0902ff 	cmp	x23, x9
   7d784:	540000a0 	b.eq	7d798 <spin_92+0x2944>  // b.none
   7d788:	eb0b02ff 	cmp	x23, x11
   7d78c:	54000060 	b.eq	7d798 <spin_92+0x2944>  // b.none
   7d790:	92409ee8 	and	x8, x23, #0xffffffffff
   7d794:	f8687b5f 	ldr	xzr, [x26, x8, lsl #3]
   7d798:	b9410bac 	ldr	w12, [x29, #264]
   7d79c:	f9405bad 	ldr	x13, [x29, #176]
   7d7a0:	340000ee 	cbz	w14, 7d7bc <spin_92+0x2968>
   7d7a4:	92409c48 	and	x8, x2, #0xffffffffff
   7d7a8:	8b080f49 	add	x9, x26, x8, lsl #3
   7d7ac:	b7f80162 	tbnz	x2, #63, 7d7d8 <spin_92+0x2984>
   7d7b0:	a940252a 	ldp	x10, x9, [x9]
   7d7b4:	aa0803ee 	mov	x14, x8
   7d7b8:	1400001e 	b	7d830 <spin_92+0x29dc>
   7d7bc:	aa1f03e8 	mov	x8, xzr
   7d7c0:	aa1f03ee 	mov	x14, xzr
   7d7c4:	aa1f03ef 	mov	x15, xzr
   7d7c8:	6f00e400 	movi	v0.2d, #0x0
   7d7cc:	6f00e401 	movi	v1.2d, #0x0
   7d7d0:	aa1f03f3 	mov	x19, xzr
   7d7d4:	14000083 	b	7d9e0 <spin_92+0x2b8c>
   7d7d8:	b940052a 	ldr	w10, [x9, #4]
   7d7dc:	b940012e 	ldr	w14, [x9]
   7d7e0:	92405dcf 	and	x15, x14, #0xffffff
   7d7e4:	f10005ff 	cmp	x15, #0x1
   7d7e8:	54001ba1 	b.ne	7db5c <spin_92+0x2d08>  // b.any
   7d7ec:	aa0a81ca 	orr	x10, x14, x10, lsl #32
   7d7f0:	88dffd3f 	ldar	wzr, [x9]
   7d7f4:	f9400330 	ldr	x16, [x25]
   7d7f8:	d358fd4e 	lsr	x14, x10, #24
   7d7fc:	8b0e0f4f 	add	x15, x26, x14, lsl #3
   7d800:	a94025ea 	ldp	x10, x9, [x15]
   7d804:	f8287b50 	str	x16, [x26, x8, lsl #3]
   7d808:	f000098f 	adrp	x15, 1b0000 <memcpy@GLIBC_2.17>
   7d80c:	f9408330 	ldr	x16, [x25, #256]
   7d810:	f9000328 	str	x8, [x25]
   7d814:	394831ef 	ldrb	w15, [x15, #524]
   7d818:	91000608 	add	x8, x16, #0x1
   7d81c:	710005ff 	cmp	w15, #0x1
   7d820:	f9008328 	str	x8, [x25, #256]
   7d824:	54001e21 	b.ne	7dbe8 <spin_92+0x2d94>  // b.any
   7d828:	f140211f 	cmp	x8, #0x8, lsl #12
   7d82c:	54001de2 	b.cs	7dbe8 <spin_92+0x2d94>  // b.hs, b.nlast
   7d830:	eb0101df 	cmp	x14, x1
   7d834:	540001a9 	b.ls	7d868 <spin_92+0x2a14>  // b.plast
   7d838:	f9400728 	ldr	x8, [x25, #8]
   7d83c:	f82e7b48 	str	x8, [x26, x14, lsl #3]
   7d840:	f0000988 	adrp	x8, 1b0000 <memcpy@GLIBC_2.17>
   7d844:	f940872f 	ldr	x15, [x25, #264]
   7d848:	39483110 	ldrb	w16, [x8, #524]
   7d84c:	f900072e 	str	x14, [x25, #8]
   7d850:	910009e8 	add	x8, x15, #0x2
   7d854:	7100061f 	cmp	w16, #0x1
   7d858:	f9008728 	str	x8, [x25, #264]
   7d85c:	540015e1 	b.ne	7db18 <spin_92+0x2cc4>  // b.any
   7d860:	f140211f 	cmp	x8, #0x8, lsl #12
   7d864:	540015a2 	b.cs	7db18 <spin_92+0x2cc4>  // b.hs, b.nlast
   7d868:	92409d48 	and	x8, x10, #0xffffffffff
   7d86c:	8b080f4f 	add	x15, x26, x8, lsl #3
   7d870:	b7f800aa 	tbnz	x10, #63, 7d884 <spin_92+0x2a30>
   7d874:	f94001ee 	ldr	x14, [x15]
   7d878:	b94009ef 	ldr	w15, [x15, #8]
   7d87c:	aa0803ea 	mov	x10, x8
   7d880:	14000018 	b	7d8e0 <spin_92+0x2a8c>
   7d884:	b94005ee 	ldr	w14, [x15, #4]
   7d888:	b94001f0 	ldr	w16, [x15]
   7d88c:	92405e11 	and	x17, x16, #0xffffff
   7d890:	f100063f 	cmp	x17, #0x1
   7d894:	540017a1 	b.ne	7db88 <spin_92+0x2d34>  // b.any
   7d898:	aa0e820a 	orr	x10, x16, x14, lsl #32
   7d89c:	88dffdff 	ldar	wzr, [x15]
   7d8a0:	f9400331 	ldr	x17, [x25]
   7d8a4:	d358fd4a 	lsr	x10, x10, #24
   7d8a8:	8b0a0f50 	add	x16, x26, x10, lsl #3
   7d8ac:	f940020e 	ldr	x14, [x16]
   7d8b0:	b9400a0f 	ldr	w15, [x16, #8]
   7d8b4:	f8287b51 	str	x17, [x26, x8, lsl #3]
   7d8b8:	f0000990 	adrp	x16, 1b0000 <memcpy@GLIBC_2.17>
   7d8bc:	f9408331 	ldr	x17, [x25, #256]
   7d8c0:	f9000328 	str	x8, [x25]
   7d8c4:	39483210 	ldrb	w16, [x16, #524]
   7d8c8:	91000628 	add	x8, x17, #0x1
   7d8cc:	7100061f 	cmp	w16, #0x1
   7d8d0:	f9008328 	str	x8, [x25, #256]
   7d8d4:	54001981 	b.ne	7dc04 <spin_92+0x2db0>  // b.any
   7d8d8:	f140211f 	cmp	x8, #0x8, lsl #12
   7d8dc:	54001942 	b.cs	7dc04 <spin_92+0x2db0>  // b.hs, b.nlast
   7d8e0:	eb01015f 	cmp	x10, x1
   7d8e4:	540001a9 	b.ls	7d918 <spin_92+0x2ac4>  // b.plast
   7d8e8:	f9400728 	ldr	x8, [x25, #8]
   7d8ec:	f82a7b48 	str	x8, [x26, x10, lsl #3]
   7d8f0:	f0000988 	adrp	x8, 1b0000 <memcpy@GLIBC_2.17>
   7d8f4:	f9408730 	ldr	x16, [x25, #264]
   7d8f8:	39483111 	ldrb	w17, [x8, #524]
   7d8fc:	f900072a 	str	x10, [x25, #8]
   7d900:	91000a08 	add	x8, x16, #0x2
   7d904:	7100063f 	cmp	w17, #0x1
   7d908:	f9008728 	str	x8, [x25, #264]
   7d90c:	54001101 	b.ne	7db2c <spin_92+0x2cd8>  // b.any
   7d910:	f140211f 	cmp	x8, #0x8, lsl #12
   7d914:	540010c2 	b.cs	7db2c <spin_92+0x2cd8>  // b.hs, b.nlast
   7d918:	92409d28 	and	x8, x9, #0xffffffffff
   7d91c:	8b080f50 	add	x16, x26, x8, lsl #3
   7d920:	b7f800a9 	tbnz	x9, #63, 7d934 <spin_92+0x2ae0>
   7d924:	ad400a00 	ldp	q0, q2, [x16]
   7d928:	aa0803ea 	mov	x10, x8
   7d92c:	b9402213 	ldr	w19, [x16, #32]
   7d930:	1400001a 	b	7d998 <spin_92+0x2b44>
   7d934:	b940060a 	ldr	w10, [x16, #4]
   7d938:	b9400212 	ldr	w18, [x16]
   7d93c:	92405e51 	and	x17, x18, #0xffffff
   7d940:	f100063f 	cmp	x17, #0x1
   7d944:	54000041 	b.ne	7d94c <spin_92+0x2af8>  // b.any
   7d948:	88dffe1f 	ldar	wzr, [x16]
   7d94c:	aa0a824a 	orr	x10, x18, x10, lsl #32
   7d950:	f100063f 	cmp	x17, #0x1
   7d954:	d358fd4a 	lsr	x10, x10, #24
   7d958:	8b0a0f52 	add	x18, x26, x10, lsl #3
   7d95c:	ad400a40 	ldp	q0, q2, [x18]
   7d960:	b9402253 	ldr	w19, [x18, #32]
   7d964:	540012c1 	b.ne	7dbbc <spin_92+0x2d68>  // b.any
   7d968:	f9400329 	ldr	x9, [x25]
   7d96c:	f9000209 	str	x9, [x16]
   7d970:	f0000989 	adrp	x9, 1b0000 <memcpy@GLIBC_2.17>
   7d974:	f9408330 	ldr	x16, [x25, #256]
   7d978:	39483129 	ldrb	w9, [x9, #524]
   7d97c:	f9000328 	str	x8, [x25]
   7d980:	91000608 	add	x8, x16, #0x1
   7d984:	7100053f 	cmp	w9, #0x1
   7d988:	f9008328 	str	x8, [x25, #256]
   7d98c:	540014a1 	b.ne	7dc20 <spin_92+0x2dcc>  // b.any
   7d990:	f140211f 	cmp	x8, #0x8, lsl #12
   7d994:	54001462 	b.cs	7dc20 <spin_92+0x2dcc>  // b.hs, b.nlast
   7d998:	eb01015f 	cmp	x10, x1
   7d99c:	540001a9 	b.ls	7d9d0 <spin_92+0x2b7c>  // b.plast
   7d9a0:	f9400f28 	ldr	x8, [x25, #24]
   7d9a4:	f82a7b48 	str	x8, [x26, x10, lsl #3]
   7d9a8:	f0000988 	adrp	x8, 1b0000 <memcpy@GLIBC_2.17>
   7d9ac:	f9408f29 	ldr	x9, [x25, #280]
   7d9b0:	39483110 	ldrb	w16, [x8, #524]
   7d9b4:	f9000f2a 	str	x10, [x25, #24]
   7d9b8:	91002128 	add	x8, x9, #0x8
   7d9bc:	7100061f 	cmp	w16, #0x1
   7d9c0:	f9008f28 	str	x8, [x25, #280]
   7d9c4:	54000be1 	b.ne	7db40 <spin_92+0x2cec>  // b.any
   7d9c8:	f140211f 	cmp	x8, #0x8, lsl #12
   7d9cc:	54000ba2 	b.cs	7db40 <spin_92+0x2cec>  // b.hs, b.nlast
   7d9d0:	6f00e5e1 	movi	v1.2d, #0xffffffff
   7d9d4:	52800028 	mov	w8, #0x1                   	// #1
   7d9d8:	4e211c00 	and	v0.16b, v0.16b, v1.16b
   7d9dc:	4e211c41 	and	v1.16b, v2.16b, v1.16b
   7d9e0:	b9402fea 	ldr	w10, [sp, #44]
   7d9e4:	2a1403e9 	mov	w9, w20
   7d9e8:	7100019f 	cmp	w12, #0x0
   7d9ec:	a9063aa8 	stp	x8, x14, [x21, #96]
   7d9f0:	1a9f07e8 	cset	w8, ne	// ne = any
   7d9f4:	2a0a03ea 	mov	w10, w10
   7d9f8:	a90436b8 	stp	x24, x13, [x21, #64]
   7d9fc:	a9002aa9 	stp	x9, x10, [x21]
   7da00:	f85f03aa 	ldur	x10, [x29, #-16]
   7da04:	f85b83a9 	ldur	x9, [x29, #-72]
   7da08:	a9052eb6 	stp	x22, x11, [x21, #80]
   7da0c:	a90126aa 	stp	x10, x9, [x21, #16]
   7da10:	a97c27aa 	ldp	x10, x9, [x29, #-64]
   7da14:	f9003aaf 	str	x15, [x21, #112]
   7da18:	3c8782a0 	stur	q0, [x21, #120]
   7da1c:	a90226aa 	stp	x10, x9, [x21, #32]
   7da20:	a97e27aa 	ldp	x10, x9, [x29, #-32]
   7da24:	3c8882a1 	stur	q1, [x21, #136]
   7da28:	a909a2b3 	stp	x19, x8, [x21, #152]
   7da2c:	a90326aa 	stp	x10, x9, [x21, #48]
   7da30:	f90056b7 	str	x23, [x21, #168]
   7da34:	9106c3ff 	add	sp, sp, #0x1b0
   7da38:	a9454ff4 	ldp	x20, x19, [sp, #80]
   7da3c:	a94457f6 	ldp	x22, x21, [sp, #64]
   7da40:	a9435ff8 	ldp	x24, x23, [sp, #48]
   7da44:	a94267fa 	ldp	x26, x25, [sp, #32]
   7da48:	a9416ffc 	ldp	x28, x27, [sp, #16]
   7da4c:	a8c67bfd 	ldp	x29, x30, [sp], #96
   7da50:	d65f03c0 	ret
   7da54:	aa1a03e0 	mov	x0, x26
   7da58:	aa1903e1 	mov	x1, x25
   7da5c:	52800022 	mov	w2, #0x1                   	// #1
   7da60:	97fe1c23 	bl	4aec <heap_alloc_miss>
   7da64:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7da68:	aa0003ea 	mov	x10, x0
   7da6c:	72a06201 	movk	w1, #0x310, lsl #16
   7da70:	17fffe7d 	b	7d464 <spin_92+0x2610>
   7da74:	aa1a03e0 	mov	x0, x26
   7da78:	aa1903e1 	mov	x1, x25
   7da7c:	aa0903e2 	mov	x2, x9
   7da80:	52800023 	mov	w3, #0x1                   	// #1
   7da84:	97fe1d03 	bl	4e90 <rfc_wrap>
   7da88:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7da8c:	72a06201 	movk	w1, #0x310, lsl #16
   7da90:	17fffe7a 	b	7d478 <spin_92+0x2624>
   7da94:	aa1a03e0 	mov	x0, x26
   7da98:	aa1903e1 	mov	x1, x25
   7da9c:	52800062 	mov	w2, #0x3                   	// #3
   7daa0:	97fe1c13 	bl	4aec <heap_alloc_miss>
   7daa4:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7daa8:	aa0003eb 	mov	x11, x0
   7daac:	72a06201 	movk	w1, #0x310, lsl #16
   7dab0:	17fffe80 	b	7d4b0 <spin_92+0x265c>
   7dab4:	aa1a03e0 	mov	x0, x26
   7dab8:	aa1903e1 	mov	x1, x25
   7dabc:	52800022 	mov	w2, #0x1                   	// #1
   7dac0:	97fe1c0b 	bl	4aec <heap_alloc_miss>
   7dac4:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7dac8:	aa0003ec 	mov	x12, x0
   7dacc:	72a06201 	movk	w1, #0x310, lsl #16
   7dad0:	17fffe83 	b	7d4dc <spin_92+0x2688>
   7dad4:	aa1a03e0 	mov	x0, x26
   7dad8:	aa1903e1 	mov	x1, x25
   7dadc:	52800023 	mov	w3, #0x1                   	// #1
   7dae0:	97fe1cec 	bl	4e90 <rfc_wrap>
   7dae4:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7dae8:	aa0003e2 	mov	x2, x0
   7daec:	72a06201 	movk	w1, #0x310, lsl #16
   7daf0:	17fffe81 	b	7d4f4 <spin_92+0x26a0>
   7daf4:	aa1a03e0 	mov	x0, x26
   7daf8:	aa1903e1 	mov	x1, x25
   7dafc:	aa0803e2 	mov	x2, x8
   7db00:	52800023 	mov	w3, #0x1                   	// #1
   7db04:	97fe1ce3 	bl	4e90 <rfc_wrap>
   7db08:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7db0c:	aa0003e8 	mov	x8, x0
   7db10:	72a06201 	movk	w1, #0x310, lsl #16
   7db14:	17fffe80 	b	7d514 <spin_92+0x26c0>
   7db18:	aa1a03e0 	mov	x0, x26
   7db1c:	aa1903e1 	mov	x1, x25
   7db20:	52800022 	mov	w2, #0x1                   	// #1
   7db24:	97fe1a2f 	bl	43e0 <heap_hand>
   7db28:	14000015 	b	7db7c <spin_92+0x2d28>
   7db2c:	aa1a03e0 	mov	x0, x26
   7db30:	aa1903e1 	mov	x1, x25
   7db34:	52800022 	mov	w2, #0x1                   	// #1
   7db38:	97fe1a2a 	bl	43e0 <heap_hand>
   7db3c:	1400001d 	b	7dbb0 <spin_92+0x2d5c>
   7db40:	aa1a03e0 	mov	x0, x26
   7db44:	aa1903e1 	mov	x1, x25
   7db48:	52800062 	mov	w2, #0x3                   	// #3
   7db4c:	3c9d03a0 	stur	q0, [x29, #-48]
   7db50:	3c9a03a2 	stur	q2, [x29, #-96]
   7db54:	97fe1a23 	bl	43e0 <heap_hand>
   7db58:	14000021 	b	7dbdc <spin_92+0x2d88>
   7db5c:	aa0a81c8 	orr	x8, x14, x10, lsl #32
   7db60:	aa1a03e0 	mov	x0, x26
   7db64:	aa1903e1 	mov	x1, x25
   7db68:	52800044 	mov	w4, #0x2                   	// #2
   7db6c:	d358fd03 	lsr	x3, x8, #24
   7db70:	8b030f48 	add	x8, x26, x3, lsl #3
   7db74:	a940250a 	ldp	x10, x9, [x8]
   7db78:	97fe1a4d 	bl	44ac <span_fade>
   7db7c:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7db80:	72a06201 	movk	w1, #0x310, lsl #16
   7db84:	17ffff39 	b	7d868 <spin_92+0x2a14>
   7db88:	aa0e8208 	orr	x8, x16, x14, lsl #32
   7db8c:	aa1a03e0 	mov	x0, x26
   7db90:	aa1903e1 	mov	x1, x25
   7db94:	aa0a03e2 	mov	x2, x10
   7db98:	52800044 	mov	w4, #0x2                   	// #2
   7db9c:	d358fd03 	lsr	x3, x8, #24
   7dba0:	8b030f48 	add	x8, x26, x3, lsl #3
   7dba4:	f940010e 	ldr	x14, [x8]
   7dba8:	b940090f 	ldr	w15, [x8, #8]
   7dbac:	97fe1a40 	bl	44ac <span_fade>
   7dbb0:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7dbb4:	72a06201 	movk	w1, #0x310, lsl #16
   7dbb8:	17ffff58 	b	7d918 <spin_92+0x2ac4>
   7dbbc:	aa1a03e0 	mov	x0, x26
   7dbc0:	aa1903e1 	mov	x1, x25
   7dbc4:	aa0903e2 	mov	x2, x9
   7dbc8:	aa0a03e3 	mov	x3, x10
   7dbcc:	528000a4 	mov	w4, #0x5                   	// #5
   7dbd0:	3c9d03a0 	stur	q0, [x29, #-48]
   7dbd4:	3c9a03a2 	stur	q2, [x29, #-96]
   7dbd8:	97fe1a35 	bl	44ac <span_fade>
   7dbdc:	3cda03a2 	ldur	q2, [x29, #-96]
   7dbe0:	3cdd03a0 	ldur	q0, [x29, #-48]
   7dbe4:	17ffff7b 	b	7d9d0 <spin_92+0x2b7c>
   7dbe8:	aa1a03e0 	mov	x0, x26
   7dbec:	aa1903e1 	mov	x1, x25
   7dbf0:	2a1f03e2 	mov	w2, wzr
   7dbf4:	97fe19fb 	bl	43e0 <heap_hand>
   7dbf8:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7dbfc:	72a06201 	movk	w1, #0x310, lsl #16
   7dc00:	17ffff0c 	b	7d830 <spin_92+0x29dc>
   7dc04:	aa1a03e0 	mov	x0, x26
   7dc08:	aa1903e1 	mov	x1, x25
   7dc0c:	2a1f03e2 	mov	w2, wzr
   7dc10:	97fe19f4 	bl	43e0 <heap_hand>
   7dc14:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7dc18:	72a06201 	movk	w1, #0x310, lsl #16
   7dc1c:	17ffff31 	b	7d8e0 <spin_92+0x2a8c>
   7dc20:	aa1a03e0 	mov	x0, x26
   7dc24:	aa1903e1 	mov	x1, x25
   7dc28:	2a1f03e2 	mov	w2, wzr
   7dc2c:	3c9d03a0 	stur	q0, [x29, #-48]
   7dc30:	3c9a03a2 	stur	q2, [x29, #-96]
   7dc34:	97fe19eb 	bl	43e0 <heap_hand>
   7dc38:	3cda03a2 	ldur	q2, [x29, #-96]
   7dc3c:	3cdd03a0 	ldur	q0, [x29, #-48]
   7dc40:	52909fe1 	mov	w1, #0x84ff                	// #34047
   7dc44:	72a06201 	movk	w1, #0x310, lsl #16
   7dc48:	17ffff54 	b	7d998 <spin_92+0x2b44>
   7dc4c:	f0000060 	adrp	x0, 8c000 <STAT_IMG+0x1840>
   7dc50:	9116e000 	add	x0, x0, #0x5b8
   7dc54:	97fe1eea 	bl	57fc <err_fail>

