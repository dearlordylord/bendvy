   17840:	d103c3ff 	sub	sp, sp, #0xf0
   17844:	a90e7bfd 	stp	x29, x30, [sp, #224]
   17848:	910383fd 	add	x29, sp, #0xe0
   1784c:	aa0c03e8 	mov	x8, x12
   17850:	a93e2ba6 	stp	x6, x10, [x29, #-32]
   17854:	aa1b03ea 	mov	x10, x27
   17858:	f81d83a3 	stur	x3, [x29, #-40]
   1785c:	aa1c03e3 	mov	x3, x28
   17860:	b85f82d3 	ldur	w19, [x22, #-8]
   17864:	a94573b0 	ldp	x16, x28, [x29, #80]
   17868:	f81f03a8 	stur	x8, [x29, #-16]
   1786c:	a94447b2 	ldp	x18, x17, [x29, #64]
   17870:	a94363bb 	ldp	x27, x24, [x29, #48]
   17874:	a9427ba6 	ldp	x6, x30, [x29, #32]
   17878:	a94133a2 	ldp	x2, x12, [x29, #16]
   1787c:	34000457 	cbz	w23, 17904 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0_K159+0xc4>
   17880:	52800648 	mov	w8, #0x32                  	// #50
   17884:	2a1903f9 	mov	w25, w25
   17888:	2a1a03fa 	mov	w26, w26
   1788c:	a93fa2d3 	stp	x19, x8, [x22, #-8]
   17890:	2a1c03e8 	mov	w8, w28
   17894:	aa0303fc 	mov	x28, x3
   17898:	f9002fa8 	str	x8, [x29, #88]
   1789c:	2a1b03e8 	mov	w8, w27
   178a0:	aa0a03fb 	mov	x27, x10
   178a4:	f9001ba8 	str	x8, [x29, #48]
   178a8:	2a1e03e8 	mov	w8, w30
   178ac:	2a0503e5 	mov	w5, w5
   178b0:	f90017a8 	str	x8, [x29, #40]
   178b4:	2a0603e8 	mov	w8, w6
   178b8:	2a0703e7 	mov	w7, w7
   178bc:	f90013a8 	str	x8, [x29, #32]
   178c0:	2a0c03e8 	mov	w8, w12
   178c4:	2a0b03eb 	mov	w11, w11
   178c8:	a97d9ba3 	ldp	x3, x6, [x29, #-40]
   178cc:	f9000fa8 	str	x8, [x29, #24]
   178d0:	a97eb3aa 	ldp	x10, x12, [x29, #-24]
   178d4:	2a0203e8 	mov	w8, w2
   178d8:	a904c3b1 	stp	x17, x16, [x29, #72]
   178dc:	2a0d03ed 	mov	w13, w13
   178e0:	2a0e03ee 	mov	w14, w14
   178e4:	a903cbb8 	stp	x24, x18, [x29, #56]
   178e8:	2a0903e9 	mov	w9, w9
   178ec:	2a0f03ef 	mov	w15, w15
   178f0:	910022d6 	add	x22, x22, #0x8
   178f4:	f9000ba8 	str	x8, [x29, #16]
   178f8:	a94e7bfd 	ldp	x29, x30, [sp, #224]
   178fc:	9103c3ff 	add	sp, sp, #0xf0
   17900:	17fffd9f 	b	16f7c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_FLATFOLD_HEALTH_CONVERTED>
   17904:	f90007e5 	str	x5, [sp, #8]
   17908:	f94016b7 	ldr	x23, [x21, #40]
   1790c:	f81a03aa 	stur	x10, [x29, #-96]
   17910:	f9000bec 	str	x12, [sp, #16]
   17914:	f81a83a3 	stur	x3, [x29, #-88]
   17918:	a90183e7 	stp	x7, x0, [sp, #24]
   1791c:	a9028be6 	stp	x6, x2, [sp, #40]
   17920:	a903fbe1 	stp	x1, x30, [sp, #56]
   17924:	a90493eb 	stp	x11, x4, [sp, #72]
   17928:	a93b63bb 	stp	x27, x24, [x29, #-80]
   1792c:	a97e62db 	ldp	x27, x24, [x22, #-32]
   17930:	a905c7f2 	stp	x18, x17, [sp, #88]
   17934:	f90037ed 	str	x13, [sp, #104]
   17938:	f81983a9 	stur	x9, [x29, #-104]
   1793c:	f81d03af 	stur	x15, [x29, #-48]
   17940:	f9003bfc 	str	x28, [sp, #112]
   17944:	a93c43ae 	stp	x14, x16, [x29, #-64]
   17948:	b4000af7 	cbz	x23, 17aa4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0_K159+0x264>
   1794c:	f8777a88 	ldr	x8, [x20, x23, lsl #3]
   17950:	f94096a9 	ldr	x9, [x21, #296]
   17954:	f90016a8 	str	x8, [x21, #40]
   17958:	d1008128 	sub	x8, x9, #0x20
   1795c:	f90096a8 	str	x8, [x21, #296]
   17960:	8b170e9c 	add	x28, x20, x23, lsl #3
   17964:	52801fe1 	mov	w1, #0xff                  	// #255
   17968:	52801c02 	mov	w2, #0xe0                  	// #224
   1796c:	91002380 	add	x0, x28, #0x8
   17970:	97ffb048 	bl	3a90 <memset@plt>
   17974:	52800028 	mov	w8, #0x1                   	// #1
   17978:	d2c64009 	mov	x9, #0x320000000000        	// #54975581388800
   1797c:	f9000393 	str	x19, [x28]
   17980:	aa18810a 	orr	x10, x8, x24, lsl #32
   17984:	f2e0a009 	movk	x9, #0x500, lsl #48
   17988:	aa0902e9 	orr	x9, x23, x9
   1798c:	a90eab9b 	stp	x27, x10, [x28, #232]
   17990:	a93e22c9 	stp	x9, x8, [x22, #-32]
   17994:	f94016a0 	ldr	x0, [x21, #40]
   17998:	b4000920 	cbz	x0, 17abc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0_K159+0x27c>
   1799c:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   179a0:	f94096aa 	ldr	x10, [x21, #296]
   179a4:	f90016a8 	str	x8, [x21, #40]
   179a8:	d1008148 	sub	x8, x10, #0x20
   179ac:	f90096a8 	str	x8, [x21, #296]
   179b0:	8b000e88 	add	x8, x20, x0, lsl #3
   179b4:	d2c0002a 	mov	x10, #0x100000000           	// #4294967296
   179b8:	f85f03ab 	ldur	x11, [x29, #-16]
   179bc:	a97bbbaf 	ldp	x15, x14, [x29, #-72]
   179c0:	f85a03b2 	ldur	x18, [x29, #-96]
   179c4:	a90e2909 	stp	x9, x10, [x8, #224]
   179c8:	2a1903e9 	mov	w9, w25
   179cc:	2a1a03ea 	mov	w10, w26
   179d0:	a9002909 	stp	x9, x10, [x8]
   179d4:	f94013ea 	ldr	x10, [sp, #32]
   179d8:	f9401fe9 	ldr	x9, [sp, #56]
   179dc:	a97cb3ad 	ldp	x13, x12, [x29, #-56]
   179e0:	a902250a 	stp	x10, x9, [x8, #32]
   179e4:	f85d83aa 	ldur	x10, [x29, #-40]
   179e8:	f9402be9 	ldr	x9, [sp, #80]
   179ec:	a97ac3b1 	ldp	x17, x16, [x29, #-88]
   179f0:	a903250a 	stp	x10, x9, [x8, #48]
   179f4:	f94007e9 	ldr	x9, [sp, #8]
   179f8:	f85e03aa 	ldur	x10, [x29, #-32]
   179fc:	2a0903e9 	mov	w9, w9
   17a00:	a9014512 	stp	x18, x17, [x8, #16]
   17a04:	f9002109 	str	x9, [x8, #64]
   17a08:	f9400fe9 	ldr	x9, [sp, #24]
   17a0c:	2a0903e9 	mov	w9, w9
   17a10:	a904a50a 	stp	x10, x9, [x8, #72]
   17a14:	f94027e9 	ldr	x9, [sp, #72]
   17a18:	f85e83aa 	ldur	x10, [x29, #-24]
   17a1c:	2a0903e9 	mov	w9, w9
   17a20:	a905a50a 	stp	x10, x9, [x8, #88]
   17a24:	f94037e9 	ldr	x9, [sp, #104]
   17a28:	2a0e03ea 	mov	w10, w14
   17a2c:	f9003d0a 	str	x10, [x8, #120]
   17a30:	2a0c03ea 	mov	w10, w12
   17a34:	2a0903e9 	mov	w9, w9
   17a38:	a906a50b 	stp	x11, x9, [x8, #104]
   17a3c:	f85983a9 	ldur	x9, [x29, #-104]
   17a40:	2a0903e9 	mov	w9, w9
   17a44:	a9082909 	stp	x9, x10, [x8, #128]
   17a48:	f9401be9 	ldr	x9, [sp, #48]
   17a4c:	f9400bea 	ldr	x10, [sp, #16]
   17a50:	2a0903e9 	mov	w9, w9
   17a54:	2a0a03ea 	mov	w10, w10
   17a58:	a9092909 	stp	x9, x10, [x8, #144]
   17a5c:	f94017e9 	ldr	x9, [sp, #40]
   17a60:	f94023ea 	ldr	x10, [sp, #64]
   17a64:	2a0903e9 	mov	w9, w9
   17a68:	2a0a03ea 	mov	w10, w10
   17a6c:	a90a2909 	stp	x9, x10, [x8, #160]
   17a70:	2a1003e9 	mov	w9, w16
   17a74:	a90b3d09 	stp	x9, x15, [x8, #176]
   17a78:	a945a7ea 	ldp	x10, x9, [sp, #88]
   17a7c:	a90c250a 	stp	x10, x9, [x8, #192]
   17a80:	f9403bea 	ldr	x10, [sp, #112]
   17a84:	d2c5a009 	mov	x9, #0x2d0000000000        	// #49478023249920
   17a88:	f2e0a009 	movk	x9, #0x500, lsl #48
   17a8c:	2a0a03ea 	mov	w10, w10
   17a90:	aa090000 	orr	x0, x0, x9
   17a94:	a90d290d 	stp	x13, x10, [x8, #208]
   17a98:	a94e7bfd 	ldp	x29, x30, [sp, #224]
   17a9c:	9103c3ff 	add	sp, sp, #0xf0
   17aa0:	d65f03c0 	ret
   17aa4:	aa1403e0 	mov	x0, x20
   17aa8:	aa1503e1 	mov	x1, x21
   17aac:	528000a2 	mov	w2, #0x5                   	// #5
   17ab0:	97ffb40f 	bl	4aec <heap_alloc_miss>
   17ab4:	aa0003f7 	mov	x23, x0
   17ab8:	17ffffaa 	b	17960 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0_K159+0x120>
   17abc:	aa1403e0 	mov	x0, x20
   17ac0:	aa1503e1 	mov	x1, x21
   17ac4:	528000a2 	mov	w2, #0x5                   	// #5
   17ac8:	97ffb409 	bl	4aec <heap_alloc_miss>
   17acc:	17ffffb9 	b	179b0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_FALLBACK_0_K159+0x170>

