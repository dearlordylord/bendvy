    5974:	d101c3ff 	sub	sp, sp, #0x70
    5978:	a9017bfd 	stp	x29, x30, [sp, #16]
    597c:	a9026ffc 	stp	x28, x27, [sp, #32]
    5980:	a90367fa 	stp	x26, x25, [sp, #48]
    5984:	a9045ff8 	stp	x24, x23, [sp, #64]
    5988:	a90557f6 	stp	x22, x21, [sp, #80]
    598c:	a9064ff4 	stp	x20, x19, [sp, #96]
    5990:	910043fd 	add	x29, sp, #0x10
    5994:	5290a00e 	mov	w14, #0x8500                	// #34048
    5998:	aa0203f5 	mov	x21, x2
    599c:	aa0103f3 	mov	x19, x1
    59a0:	72a0620e 	movk	w14, #0x310, lsl #16
    59a4:	aa0003f4 	mov	x20, x0
    59a8:	aa1f03f7 	mov	x23, xzr
    59ac:	aa1f03f8 	mov	x24, xzr
    59b0:	91040039 	add	x25, x1, #0x100
    59b4:	9100201a 	add	x26, x0, #0x8
    59b8:	d10005cf 	sub	x15, x14, #0x1
    59bc:	f0000d56 	adrp	x22, 1b0000 <memcpy@GLIBC_2.17>
    59c0:	5280003b 	mov	w27, #0x1                   	// #1
    59c4:	d2c0201c 	mov	x28, #0x10000000000         	// #1099511627776
    59c8:	b6f804b5 	tbz	x21, #63, 5a5c <term_drop+0xe8>
    59cc:	92787ea8 	and	x8, x21, #0xffffffff00
    59d0:	eb0f011f 	cmp	x8, x15
    59d4:	54000449 	b.ls	5a5c <term_drop+0xe8>  // b.plast
    59d8:	b10006bf 	cmn	x21, #0x1
    59dc:	54000400 	b.eq	5a5c <term_drop+0xe8>  // b.none
    59e0:	924716a8 	and	x8, x21, #0x7e00000000000000
    59e4:	b40003c8 	cbz	x8, 5a5c <term_drop+0xe8>
    59e8:	92409ebc 	and	x28, x21, #0xffffffffff
    59ec:	12800000 	mov	w0, #0xffffffff            	// #-1
    59f0:	f90007ef 	str	x15, [sp, #8]
    59f4:	8b1c0e96 	add	x22, x20, x28, lsl #3
    59f8:	aa1603e1 	mov	x1, x22
    59fc:	94021145 	bl	89f10 <__aarch64_ldadd4_rel>
    5a00:	12005c08 	and	w8, w0, #0xffffff
    5a04:	7100051f 	cmp	w8, #0x1
    5a08:	54000561 	b.ne	5ab4 <term_drop+0x140>  // b.any
    5a0c:	88dffedf 	ldar	wzr, [x22]
    5a10:	f9400268 	ldr	x8, [x19]
    5a14:	92585ab5 	and	x21, x21, #0x7fffff0000000000
    5a18:	f94002c9 	ldr	x9, [x22]
    5a1c:	f90002c8 	str	x8, [x22]
    5a20:	f0000d56 	adrp	x22, 1b0000 <memcpy@GLIBC_2.17>
    5a24:	f9408268 	ldr	x8, [x19, #256]
    5a28:	394832ca 	ldrb	w10, [x22, #524]
    5a2c:	b358fd35 	bfxil	x21, x9, #24, #40
    5a30:	f900027c 	str	x28, [x19]
    5a34:	91000508 	add	x8, x8, #0x1
    5a38:	7100055f 	cmp	w10, #0x1
    5a3c:	f9008268 	str	x8, [x19, #256]
    5a40:	540009a1 	b.ne	5b74 <term_drop+0x200>  // b.any
    5a44:	f140211f 	cmp	x8, #0x8, lsl #12
    5a48:	54000962 	b.cs	5b74 <term_drop+0x200>  // b.hs, b.nlast
    5a4c:	5290a00e 	mov	w14, #0x8500                	// #34048
    5a50:	f94007ef 	ldr	x15, [sp, #8]
    5a54:	d2c0201c 	mov	x28, #0x10000000000         	// #1099511627776
    5a58:	72a0620e 	movk	w14, #0x310, lsl #16
    5a5c:	92787ea8 	and	x8, x21, #0xffffffff00
    5a60:	eb0e011f 	cmp	x8, x14
    5a64:	54000923 	b.cc	5b88 <term_drop+0x214>  // b.lo, b.ul, b.last
    5a68:	b10006bf 	cmn	x21, #0x1
    5a6c:	540008e0 	b.eq	5b88 <term_drop+0x214>  // b.none
    5a70:	924716a8 	and	x8, x21, #0x7e00000000000000
    5a74:	b40008a8 	cbz	x8, 5b88 <term_drop+0x214>
    5a78:	d378faa9 	ubfx	x9, x21, #56, #7
    5a7c:	f100113f 	cmp	x9, #0x4
    5a80:	54000261 	b.ne	5acc <term_drop+0x158>  // b.any
    5a84:	d368b2a8 	ubfx	x8, x21, #40, #5
    5a88:	92481aa9 	and	x9, x21, #0x7f00000000000000
    5a8c:	d2e0c00b 	mov	x11, #0x600000000000000     	// #432345564227567616
    5a90:	7100050a 	subs	w10, w8, #0x1
    5a94:	1a8a33ea 	csel	w10, wzr, w10, cc	// cc = lo, ul, last
    5a98:	eb0b013f 	cmp	x9, x11
    5a9c:	1a8a0102 	csel	w2, w8, w10, eq	// eq = none
    5aa0:	92409ea8 	and	x8, x21, #0xffffffffff
    5aa4:	f8625a69 	ldr	x9, [x19, w2, uxtw #3]
    5aa8:	f8287a89 	str	x9, [x20, x8, lsl #3]
    5aac:	f8225a68 	str	x8, [x19, w2, uxtw #3]
    5ab0:	14000060 	b	5c30 <term_drop+0x2bc>
    5ab4:	5290a00e 	mov	w14, #0x8500                	// #34048
    5ab8:	f94007ef 	ldr	x15, [sp, #8]
    5abc:	f0000d56 	adrp	x22, 1b0000 <memcpy@GLIBC_2.17>
    5ac0:	72a0620e 	movk	w14, #0x310, lsl #16
    5ac4:	d2c0201c 	mov	x28, #0x10000000000         	// #1099511627776
    5ac8:	14000030 	b	5b88 <term_drop+0x214>
    5acc:	f100193f 	cmp	x9, #0x6
    5ad0:	54000120 	b.eq	5af4 <term_drop+0x180>  // b.none
    5ad4:	d368dea8 	ubfx	x8, x21, #40, #16
    5ad8:	f100093f 	cmp	x9, #0x2
    5adc:	54000141 	b.ne	5b04 <term_drop+0x190>  // b.any
    5ae0:	d37ff908 	lsl	x8, x8, #1
    5ae4:	b000042a 	adrp	x10, 8a000 <_IO_stdin_used+0xa0>
    5ae8:	9104114a 	add	x10, x10, #0x104
    5aec:	38686948 	ldrb	w8, [x10, x8]
    5af0:	1400000c 	b	5b20 <term_drop+0x1ac>
    5af4:	d368b2a9 	ubfx	x9, x21, #40, #5
    5af8:	2a1f03e8 	mov	w8, wzr
    5afc:	321a0129 	orr	w9, w9, #0x40
    5b00:	14000016 	b	5b58 <term_drop+0x1e4>
    5b04:	8b080508 	add	x8, x8, x8, lsl #1
    5b08:	b000042a 	adrp	x10, 8a000 <_IO_stdin_used+0xa0>
    5b0c:	910a514a 	add	x10, x10, #0x294
    5b10:	f1000d3f 	cmp	x9, #0x3
    5b14:	38686948 	ldrb	w8, [x10, x8]
    5b18:	1a9f17ea 	cset	w10, eq	// eq = none
    5b1c:	4b0a0108 	sub	w8, w8, w10
    5b20:	7103e11f 	cmp	w8, #0xf8
    5b24:	54000083 	b.cc	5b34 <term_drop+0x1c0>  // b.lo, b.ul, b.last
    5b28:	5103c109 	sub	w9, w8, #0xf0
    5b2c:	321a0129 	orr	w9, w9, #0x40
    5b30:	1400000a 	b	5b58 <term_drop+0x1e4>
    5b34:	1100090a 	add	w10, w8, #0x2
    5b38:	f100153f 	cmp	x9, #0x5
    5b3c:	5280040b 	mov	w11, #0x20                  	// #32
    5b40:	1a880149 	csel	w9, w10, w8, eq	// eq = none
    5b44:	7100052a 	subs	w10, w9, #0x1
    5b48:	5ac0114a 	clz	w10, w10
    5b4c:	7100053f 	cmp	w9, #0x1
    5b50:	4b0a016a 	sub	w10, w11, w10
    5b54:	1a9f8149 	csel	w9, w10, wzr, hi	// hi = pmore
    5b58:	d3503d08 	lsl	x8, x8, #48
    5b5c:	92409eaa 	and	x10, x21, #0xffffffffff
    5b60:	f86a7a97 	ldr	x23, [x20, x10, lsl #3]
    5b64:	f82a7a98 	str	x24, [x20, x10, lsl #3]
    5b68:	aa09e108 	orr	x8, x8, x9, lsl #56
    5b6c:	aa0a0118 	orr	x24, x8, x10
    5b70:	14000006 	b	5b88 <term_drop+0x214>
    5b74:	aa1403e0 	mov	x0, x20
    5b78:	aa1303e1 	mov	x1, x19
    5b7c:	2a1f03e2 	mov	w2, wzr
    5b80:	97fffa18 	bl	43e0 <heap_hand>
    5b84:	17ffffb2 	b	5a4c <term_drop+0xd8>
    5b88:	b40006f8 	cbz	x24, 5c64 <term_drop+0x2f0>
    5b8c:	d37eff08 	lsr	x8, x24, #62
    5b90:	d368bf09 	ubfx	x9, x24, #40, #8
    5b94:	d378ff02 	lsr	x2, x24, #56
    5b98:	92409f0a 	and	x10, x24, #0xffffffffff
    5b9c:	b4000108 	cbz	x8, 5bbc <term_drop+0x248>
    5ba0:	1ac2236b 	lsl	w11, w27, w2
    5ba4:	7100093f 	cmp	w9, #0x2
    5ba8:	1200144d 	and	w13, w2, #0x3f
    5bac:	540000c1 	b.ne	5bc4 <term_drop+0x250>  // b.any
    5bb0:	f86a7b4c 	ldr	x12, [x26, x10, lsl #3]
    5bb4:	2a0d03e2 	mov	w2, w13
    5bb8:	14000005 	b	5bcc <term_drop+0x258>
    5bbc:	d370df0b 	ubfx	x11, x24, #48, #8
    5bc0:	14000002 	b	5bc8 <term_drop+0x254>
    5bc4:	2a0d03e2 	mov	w2, w13
    5bc8:	2a0903ec 	mov	w12, w9
    5bcc:	6b0b019f 	cmp	w12, w11
    5bd0:	54000282 	b.cs	5c20 <term_drop+0x2ac>  // b.hs, b.nlast
    5bd4:	aa1703f5 	mov	x21, x23
    5bd8:	340000cc 	cbz	w12, 5bf0 <term_drop+0x27c>
    5bdc:	8b0a0e8b 	add	x11, x20, x10, lsl #3
    5be0:	f86c5975 	ldr	x21, [x11, w12, uxtw #3]
    5be4:	b4000068 	cbz	x8, 5bf0 <term_drop+0x27c>
    5be8:	1100058b 	add	w11, w12, #0x1
    5bec:	f82a7b4b 	str	x11, [x26, x10, lsl #3]
    5bf0:	7100053f 	cmp	w9, #0x1
    5bf4:	fa408904 	ccmp	x8, #0x0, #0x4, hi	// hi = pmore
    5bf8:	8b1c0308 	add	x8, x24, x28
    5bfc:	9a881318 	csel	x24, x24, x8, ne	// ne = any
    5c00:	b10006bf 	cmn	x21, #0x1
    5c04:	54fffc20 	b.eq	5b88 <term_drop+0x214>  // b.none
    5c08:	924716a8 	and	x8, x21, #0x7e00000000000000
    5c0c:	b4fffbe8 	cbz	x8, 5b88 <term_drop+0x214>
    5c10:	92787ea8 	and	x8, x21, #0xffffffff00
    5c14:	eb0e011f 	cmp	x8, x14
    5c18:	54fffb83 	b.cc	5b88 <term_drop+0x214>  // b.lo, b.ul, b.last
    5c1c:	17ffff6b 	b	59c8 <term_drop+0x54>
    5c20:	f8625a68 	ldr	x8, [x19, w2, uxtw #3]
    5c24:	f86a7a98 	ldr	x24, [x20, x10, lsl #3]
    5c28:	f82a7a88 	str	x8, [x20, x10, lsl #3]
    5c2c:	f8225a6a 	str	x10, [x19, w2, uxtw #3]
    5c30:	394832c8 	ldrb	w8, [x22, #524]
    5c34:	9ac22369 	lsl	x9, x27, x2
    5c38:	f8625b2a 	ldr	x10, [x25, w2, uxtw #3]
    5c3c:	7100051f 	cmp	w8, #0x1
    5c40:	8b090148 	add	x8, x10, x9
    5c44:	f8225b28 	str	x8, [x25, w2, uxtw #3]
    5c48:	54000061 	b.ne	5c54 <term_drop+0x2e0>  // b.any
    5c4c:	f140211f 	cmp	x8, #0x8, lsl #12
    5c50:	54fff9c3 	b.cc	5b88 <term_drop+0x214>  // b.lo, b.ul, b.last
    5c54:	aa1403e0 	mov	x0, x20
    5c58:	aa1303e1 	mov	x1, x19
    5c5c:	97fff9e1 	bl	43e0 <heap_hand>
    5c60:	17ffffca 	b	5b88 <term_drop+0x214>
    5c64:	a9464ff4 	ldp	x20, x19, [sp, #96]
    5c68:	a94557f6 	ldp	x22, x21, [sp, #80]
    5c6c:	a9445ff8 	ldp	x24, x23, [sp, #64]
    5c70:	a94367fa 	ldp	x26, x25, [sp, #48]
    5c74:	a9426ffc 	ldp	x28, x27, [sp, #32]
    5c78:	a9417bfd 	ldp	x29, x30, [sp, #16]
    5c7c:	9101c3ff 	add	sp, sp, #0x70
    5c80:	d65f03c0 	ret

