   1a650:	d10243ff 	sub	sp, sp, #0x90
   1a654:	a9087bfd 	stp	x29, x30, [sp, #128]
   1a658:	910203fd 	add	x29, sp, #0x80
   1a65c:	a93d1baf 	stp	x15, x6, [x29, #-48]
   1a660:	a9444bbe 	ldp	x30, x18, [x29, #64]
   1a664:	a93e2ba9 	stp	x9, x10, [x29, #-32]
   1a668:	aa0703e9 	mov	x9, x7
   1a66c:	aa1c03f8 	mov	x24, x28
   1a670:	f81f03ac 	stur	x12, [x29, #-16]
   1a674:	aa0503ec 	mov	x12, x5
   1a678:	aa0403e5 	mov	x5, x4
   1a67c:	aa0303e4 	mov	x4, x3
   1a680:	aa0103e3 	mov	x3, x1
   1a684:	aa0003e1 	mov	x1, x0
   1a688:	a9450baa 	ldp	x10, x2, [x29, #80]
   1a68c:	aa1b03fc 	mov	x28, x27
   1a690:	a9431fa0 	ldp	x0, x7, [x29, #48]
   1a694:	aa1903fb 	mov	x27, x25
   1a698:	a9421bb1 	ldp	x17, x6, [x29, #32]
   1a69c:	aa1603e8 	mov	x8, x22
   1a6a0:	a9413fb3 	ldp	x19, x15, [x29, #16]
   1a6a4:	aa0e03f0 	mov	x16, x14
   1a6a8:	f85f8ed9 	ldr	x25, [x22, #-8]!
   1a6ac:	34000417 	cbz	w23, 1a72c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0_K202+0xdc>
   1a6b0:	2a1b03e8 	mov	w8, w27
   1a6b4:	2a1a03fb 	mov	w27, w26
   1a6b8:	aa0603fa 	mov	x26, x6
   1a6bc:	2a0c03e6 	mov	w6, w12
   1a6c0:	2a0203ec 	mov	w12, w2
   1a6c4:	a9052bb2 	stp	x18, x10, [x29, #80]
   1a6c8:	2a0903ea 	mov	w10, w9
   1a6cc:	2a0003e9 	mov	w9, w0
   1a6d0:	f90033ac 	str	x12, [x29, #96]
   1a6d4:	2a0b03ec 	mov	w12, w11
   1a6d8:	2a1a03eb 	mov	w11, w26
   1a6dc:	a9047ba7 	stp	x7, x30, [x29, #64]
   1a6e0:	a90327ab 	stp	x11, x9, [x29, #48]
   1a6e4:	aa1003e9 	mov	x9, x16
   1a6e8:	2a1103f0 	mov	w16, w17
   1a6ec:	2a0f03eb 	mov	w11, w15
   1a6f0:	a97dbfa7 	ldp	x7, x15, [x29, #-40]
   1a6f4:	a90243ab 	stp	x11, x16, [x29, #32]
   1a6f8:	f85d03ab 	ldur	x11, [x29, #-48]
   1a6fc:	2a1303f0 	mov	w16, w19
   1a700:	2a0d03ee 	mov	w14, w13
   1a704:	2a0903e9 	mov	w9, w9
   1a708:	aa0803fa 	mov	x26, x8
   1a70c:	2a0b03f1 	mov	w17, w11
   1a710:	2a0f03ef 	mov	w15, w15
   1a714:	aa1803e0 	mov	x0, x24
   1a718:	a90143b1 	stp	x17, x16, [x29, #16]
   1a71c:	a97eb7ab 	ldp	x11, x13, [x29, #-24]
   1a720:	a9487bfd 	ldp	x29, x30, [sp, #128]
   1a724:	910243ff 	add	sp, sp, #0x90
   1a728:	17fffdc5 	b	19e3c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0>
   1a72c:	f9001ff1 	str	x17, [sp, #56]
   1a730:	a97e5d11 	ldp	x17, x23, [x8, #-32]
   1a734:	a90297ed 	stp	x13, x5, [sp, #40]
   1a738:	aa0103f6 	mov	x22, x1
   1a73c:	aa0303ee 	mov	x14, x3
   1a740:	f81c83a0 	stur	x0, [x29, #-56]
   1a744:	f94016a0 	ldr	x0, [x21, #40]
   1a748:	aa0403ed 	mov	x13, x4
   1a74c:	f90023f0 	str	x16, [sp, #64]
   1a750:	b40006e0 	cbz	x0, 1a82c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0_K202+0x1dc>
   1a754:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   1a758:	f94096b0 	ldr	x16, [x21, #296]
   1a75c:	f90016a8 	str	x8, [x21, #40]
   1a760:	d1008208 	sub	x8, x16, #0x20
   1a764:	f90096a8 	str	x8, [x21, #296]
   1a768:	8b000e88 	add	x8, x20, x0, lsl #3
   1a76c:	2a0c03ec 	mov	w12, w12
   1a770:	2a0903e9 	mov	w9, w9
   1a774:	d3607ef0 	lsl	x16, x23, #32
   1a778:	a903350e 	stp	x14, x13, [x8, #48]
   1a77c:	f9401bed 	ldr	x13, [sp, #48]
   1a780:	f9007910 	str	x16, [x8, #240]
   1a784:	2a1b03f0 	mov	w16, w27
   1a788:	a904310d 	stp	x13, x12, [x8, #64]
   1a78c:	f85d83ac 	ldur	x12, [x29, #-40]
   1a790:	a9004119 	stp	x25, x16, [x8]
   1a794:	2a1a03f0 	mov	w16, w26
   1a798:	a905250c 	stp	x12, x9, [x8, #80]
   1a79c:	2a0b03e9 	mov	w9, w11
   1a7a0:	f85e83ab 	ldur	x11, [x29, #-24]
   1a7a4:	a9017110 	stp	x16, x28, [x8, #16]
   1a7a8:	a906250b 	stp	x11, x9, [x8, #96]
   1a7ac:	f94017e9 	ldr	x9, [sp, #40]
   1a7b0:	f85f03ab 	ldur	x11, [x29, #-16]
   1a7b4:	a9025918 	stp	x24, x22, [x8, #32]
   1a7b8:	2a0903e9 	mov	w9, w9
   1a7bc:	a90c7907 	stp	x7, x30, [x8, #192]
   1a7c0:	a907250b 	stp	x11, x9, [x8, #112]
   1a7c4:	f94023e9 	ldr	x9, [sp, #64]
   1a7c8:	f85e03ab 	ldur	x11, [x29, #-32]
   1a7cc:	a90d2912 	stp	x18, x10, [x8, #208]
   1a7d0:	2a0903e9 	mov	w9, w9
   1a7d4:	2a0b03eb 	mov	w11, w11
   1a7d8:	a9082d09 	stp	x9, x11, [x8, #128]
   1a7dc:	f85d03a9 	ldur	x9, [x29, #-48]
   1a7e0:	2a1303eb 	mov	w11, w19
   1a7e4:	2a0903e9 	mov	w9, w9
   1a7e8:	a9092d09 	stp	x9, x11, [x8, #144]
   1a7ec:	f9401feb 	ldr	x11, [sp, #56]
   1a7f0:	2a0f03e9 	mov	w9, w15
   1a7f4:	2a0b03eb 	mov	w11, w11
   1a7f8:	a90a2d09 	stp	x9, x11, [x8, #160]
   1a7fc:	f85c83ab 	ldur	x11, [x29, #-56]
   1a800:	2a0603e9 	mov	w9, w6
   1a804:	2a0b03eb 	mov	w11, w11
   1a808:	a90b2d09 	stp	x9, x11, [x8, #176]
   1a80c:	d2c76009 	mov	x9, #0x3b0000000000        	// #64871186038784
   1a810:	f2e0a009 	movk	x9, #0x500, lsl #48
   1a814:	aa090000 	orr	x0, x0, x9
   1a818:	2a0203e9 	mov	w9, w2
   1a81c:	a90e4509 	stp	x9, x17, [x8, #224]
   1a820:	a9487bfd 	ldp	x29, x30, [sp, #128]
   1a824:	910243ff 	add	sp, sp, #0x90
   1a828:	d65f03c0 	ret
   1a82c:	aa1403e0 	mov	x0, x20
   1a830:	a9018be7 	stp	x7, x2, [sp, #24]
   1a834:	aa1503e1 	mov	x1, x21
   1a838:	528000a2 	mov	w2, #0x5                   	// #5
   1a83c:	a900fbf2 	stp	x18, x30, [sp, #8]
   1a840:	aa1103f5 	mov	x21, x17
   1a844:	f90003e6 	str	x6, [sp]
   1a848:	97ffa8a9 	bl	4aec <heap_alloc_miss>
   1a84c:	a9404be6 	ldp	x6, x18, [sp]
   1a850:	aa1503f1 	mov	x17, x21
   1a854:	a9411ffe 	ldp	x30, x7, [sp, #16]
   1a858:	f94013e2 	ldr	x2, [sp, #32]
   1a85c:	17ffffc3 	b	1a768 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0_K202+0x118>

