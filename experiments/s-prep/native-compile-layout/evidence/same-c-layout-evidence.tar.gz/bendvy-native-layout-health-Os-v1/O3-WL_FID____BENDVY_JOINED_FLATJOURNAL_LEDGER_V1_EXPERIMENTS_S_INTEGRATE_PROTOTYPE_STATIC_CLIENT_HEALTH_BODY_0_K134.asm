   17e38:	d102c3ff 	sub	sp, sp, #0xb0
   17e3c:	a90a7bfd 	stp	x29, x30, [sp, #160]
   17e40:	910283fd 	add	x29, sp, #0xa0
   17e44:	a93db3af 	stp	x15, x12, [x29, #-40]
   17e48:	aa0b03f0 	mov	x16, x11
   17e4c:	b9405ba8 	ldr	w8, [x29, #88]
   17e50:	a93e9baa 	stp	x10, x6, [x29, #-24]
   17e54:	a944cba2 	ldp	x2, x18, [x29, #72]
   17e58:	a943fbaa 	ldp	x10, x30, [x29, #56]
   17e5c:	7100051f 	cmp	w8, #0x1
   17e60:	a942cfab 	ldp	x11, x19, [x29, #40]
   17e64:	f9400bb8 	ldr	x24, [x29, #16]
   17e68:	a941bfac 	ldp	x12, x15, [x29, #24]
   17e6c:	54000681 	b.ne	17f3c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K134+0x104>  // b.any
   17e70:	aa1603e8 	mov	x8, x22
   17e74:	a9043ff0 	stp	x16, x15, [sp, #64]
   17e78:	f9002bea 	str	x10, [sp, #80]
   17e7c:	a93bcbbe 	stp	x30, x18, [x29, #-72]
   17e80:	f94033be 	ldr	x30, [x29, #96]
   17e84:	a93ca7bc 	stp	x28, x9, [x29, #-56]
   17e88:	b85f0d1c 	ldr	w28, [x8, #-16]!
   17e8c:	b85f0110 	ldur	w16, [x8, #-16]
   17e90:	b85f8111 	ldur	w17, [x8, #-8]
   17e94:	b9400912 	ldr	w18, [x8, #8]
   17e98:	0b100230 	add	w16, w17, w16
   17e9c:	0b120391 	add	w17, w28, w18
   17ea0:	0b11021c 	add	w28, w16, w17
   17ea4:	340008b7 	cbz	w23, 17fb8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K134+0x180>
   17ea8:	a97baba9 	ldp	x9, x10, [x29, #-72]
   17eac:	52800590 	mov	w16, #0x2c                  	// #44
   17eb0:	a93e42dc 	stp	x28, x16, [x22, #-32]
   17eb4:	110007d0 	add	w16, w30, #0x1
   17eb8:	f85c83bc 	ldur	x28, [x29, #-56]
   17ebc:	2a1903f9 	mov	w25, w25
   17ec0:	2a1a03fa 	mov	w26, w26
   17ec4:	2a0503e5 	mov	w5, w5
   17ec8:	a904aba2 	stp	x2, x10, [x29, #72]
   17ecc:	2a0703e7 	mov	w7, w7
   17ed0:	2a0d03ed 	mov	w13, w13
   17ed4:	f90023a9 	str	x9, [x29, #64]
   17ed8:	2a1303e9 	mov	w9, w19
   17edc:	2a0e03ee 	mov	w14, w14
   17ee0:	f9402bea 	ldr	x10, [sp, #80]
   17ee4:	aa0803f6 	mov	x22, x8
   17ee8:	a9032ba9 	stp	x9, x10, [x29, #48]
   17eec:	2a0b03e9 	mov	w9, w11
   17ef0:	f90017a9 	str	x9, [x29, #40]
   17ef4:	f94027e9 	ldr	x9, [sp, #72]
   17ef8:	2a0903e9 	mov	w9, w9
   17efc:	f90013a9 	str	x9, [x29, #32]
   17f00:	2a0c03e9 	mov	w9, w12
   17f04:	f85e03ac 	ldur	x12, [x29, #-32]
   17f08:	f9000fa9 	str	x9, [x29, #24]
   17f0c:	2a1803e9 	mov	w9, w24
   17f10:	f9000ba9 	str	x9, [x29, #16]
   17f14:	f94023e9 	ldr	x9, [sp, #64]
   17f18:	2a0903eb 	mov	w11, w9
   17f1c:	a97d2ba9 	ldp	x9, x10, [x29, #-48]
   17f20:	2a0a03ef 	mov	w15, w10
   17f24:	a97e9baa 	ldp	x10, x6, [x29, #-24]
   17f28:	2a0903e9 	mov	w9, w9
   17f2c:	f9002fb0 	str	x16, [x29, #88]
   17f30:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   17f34:	9102c3ff 	add	sp, sp, #0xb0
   17f38:	17ffc30f 	b	8b74 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_LEDGER0>
   17f3c:	b85d8ec8 	ldr	w8, [x22, #-40]!
   17f40:	f0000cb1 	adrp	x17, 1ae000 <io_eff_rows+0xff0f8>
   17f44:	913fa231 	add	x17, x17, #0xfe8
   17f48:	12800006 	mov	w6, #0xffffffff            	// #-1
   17f4c:	2a1903f9 	mov	w25, w25
   17f50:	f8687a31 	ldr	x17, [x17, x8, lsl #3]
   17f54:	2a1303e8 	mov	w8, w19
   17f58:	a9051bb2 	stp	x18, x6, [x29, #80]
   17f5c:	a9032ba8 	stp	x8, x10, [x29, #48]
   17f60:	2a0b03e8 	mov	w8, w11
   17f64:	2a1003eb 	mov	w11, w16
   17f68:	f90017a8 	str	x8, [x29, #40]
   17f6c:	2a0f03e8 	mov	w8, w15
   17f70:	2a0c03f0 	mov	w16, w12
   17f74:	f90013a8 	str	x8, [x29, #32]
   17f78:	a97db3a8 	ldp	x8, x12, [x29, #-40]
   17f7c:	2a1a03fa 	mov	w26, w26
   17f80:	a97e9baa 	ldp	x10, x6, [x29, #-24]
   17f84:	a9040bbe 	stp	x30, x2, [x29, #64]
   17f88:	2a0803ef 	mov	w15, w8
   17f8c:	2a1803e8 	mov	w8, w24
   17f90:	2a0503e5 	mov	w5, w5
   17f94:	2a0703e7 	mov	w7, w7
   17f98:	2a0d03ed 	mov	w13, w13
   17f9c:	2a0e03ee 	mov	w14, w14
   17fa0:	2a0903e9 	mov	w9, w9
   17fa4:	a90143a8 	stp	x8, x16, [x29, #16]
   17fa8:	52800398 	mov	w24, #0x1c                  	// #28
   17fac:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   17fb0:	9102c3ff 	add	sp, sp, #0xb0
   17fb4:	d61f0220 	br	x17
   17fb8:	a97cdecf 	ldp	x15, x23, [x22, #-56]
   17fbc:	aa1803ea 	mov	x10, x24
   17fc0:	f94016a8 	ldr	x8, [x21, #40]
   17fc4:	f9001ffe 	str	x30, [sp, #56]
   17fc8:	b4000b88 	cbz	x8, 18138 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K134+0x300>
   17fcc:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   17fd0:	f94096b1 	ldr	x17, [x21, #296]
   17fd4:	aa0c03fe 	mov	x30, x12
   17fd8:	f90016b0 	str	x16, [x21, #40]
   17fdc:	d1008230 	sub	x16, x17, #0x20
   17fe0:	f90096b0 	str	x16, [x21, #296]
   17fe4:	8b080e90 	add	x16, x20, x8, lsl #3
   17fe8:	6f07e7e0 	movi	v0.2d, #0xffffffffffffffff
   17fec:	92800011 	mov	x17, #0xffffffffffffffff    	// #-1
   17ff0:	52800032 	mov	w18, #0x1                   	// #1
   17ff4:	aa1303f8 	mov	x24, x19
   17ff8:	aa0b03f3 	mov	x19, x11
   17ffc:	a90dbe11 	stp	x17, x15, [x16, #216]
   18000:	d2c58011 	mov	x17, #0x2c0000000000        	// #48378511622144
   18004:	aa178257 	orr	x23, x18, x23, lsl #32
   18008:	f2e0a011 	movk	x17, #0x500, lsl #48
   1800c:	f900021c 	str	x28, [x16]
   18010:	aa11011c 	orr	x28, x8, x17
   18014:	3c8c8200 	stur	q0, [x16, #200]
   18018:	3c8b8200 	stur	q0, [x16, #184]
   1801c:	3c8a8200 	stur	q0, [x16, #168]
   18020:	3c898200 	stur	q0, [x16, #152]
   18024:	3c888200 	stur	q0, [x16, #136]
   18028:	3c878200 	stur	q0, [x16, #120]
   1802c:	3c868200 	stur	q0, [x16, #104]
   18030:	3c858200 	stur	q0, [x16, #88]
   18034:	3c848200 	stur	q0, [x16, #72]
   18038:	3c838200 	stur	q0, [x16, #56]
   1803c:	3c828200 	stur	q0, [x16, #40]
   18040:	3c818200 	stur	q0, [x16, #24]
   18044:	3c808200 	stur	q0, [x16, #8]
   18048:	f9007617 	str	x23, [x16, #232]
   1804c:	a93ccadc 	stp	x28, x18, [x22, #-56]
   18050:	f94016a8 	ldr	x8, [x21, #40]
   18054:	b4000928 	cbz	x8, 18178 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K134+0x340>
   18058:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   1805c:	f94096b1 	ldr	x17, [x21, #296]
   18060:	f90016b0 	str	x16, [x21, #40]
   18064:	d1008230 	sub	x16, x17, #0x20
   18068:	f90096b0 	str	x16, [x21, #296]
   1806c:	8b080e90 	add	x16, x20, x8, lsl #3
   18070:	f85c83a9 	ldur	x9, [x29, #-56]
   18074:	d2c00031 	mov	x17, #0x100000000           	// #4294967296
   18078:	2a1903f2 	mov	w18, w25
   1807c:	f94023eb 	ldr	x11, [sp, #64]
   18080:	2a0e03ec 	mov	w12, w14
   18084:	a90e461c 	stp	x28, x17, [x16, #224]
   18088:	2a1a03f1 	mov	w17, w26
   1808c:	a901261b 	stp	x27, x9, [x16, #16]
   18090:	f85f03a9 	ldur	x9, [x29, #-16]
   18094:	2a0b03eb 	mov	w11, w11
   18098:	a9004612 	stp	x18, x17, [x16]
   1809c:	2a0503f1 	mov	w17, w5
   180a0:	a9042611 	stp	x17, x9, [x16, #64]
   180a4:	f85e83a9 	ldur	x9, [x29, #-24]
   180a8:	2a0703f1 	mov	w17, w7
   180ac:	a9020600 	stp	x0, x1, [x16, #32]
   180b0:	a9052611 	stp	x17, x9, [x16, #80]
   180b4:	f85e03a9 	ldur	x9, [x29, #-32]
   180b8:	a9031203 	stp	x3, x4, [x16, #48]
   180bc:	a906260b 	stp	x11, x9, [x16, #96]
   180c0:	f85d03a9 	ldur	x9, [x29, #-48]
   180c4:	2a0d03eb 	mov	w11, w13
   180c8:	a907320b 	stp	x11, x12, [x16, #112]
   180cc:	2a1e03ec 	mov	w12, w30
   180d0:	2a0903eb 	mov	w11, w9
   180d4:	f85d83a9 	ldur	x9, [x29, #-40]
   180d8:	2a0903ef 	mov	w15, w9
   180dc:	f94027e9 	ldr	x9, [sp, #72]
   180e0:	a9083e0b 	stp	x11, x15, [x16, #128]
   180e4:	2a0a03eb 	mov	w11, w10
   180e8:	f9401fea 	ldr	x10, [sp, #56]
   180ec:	a909320b 	stp	x11, x12, [x16, #144]
   180f0:	2a0903eb 	mov	w11, w9
   180f4:	2a1303ec 	mov	w12, w19
   180f8:	2a1803e9 	mov	w9, w24
   180fc:	a90a320b 	stp	x11, x12, [x16, #160]
   18100:	f9402beb 	ldr	x11, [sp, #80]
   18104:	f9005a09 	str	x9, [x16, #176]
   18108:	f85b83a9 	ldur	x9, [x29, #-72]
   1810c:	1100054a 	add	w10, w10, #0x1
   18110:	a90ba60b 	stp	x11, x9, [x16, #184]
   18114:	d2c08009 	mov	x9, #0x40000000000         	// #4398046511104
   18118:	f2e0a009 	movk	x9, #0x500, lsl #48
   1811c:	aa090100 	orr	x0, x8, x9
   18120:	f85c03a8 	ldur	x8, [x29, #-64]
   18124:	a90ca202 	stp	x2, x8, [x16, #200]
   18128:	f9006e0a 	str	x10, [x16, #216]
   1812c:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   18130:	9102c3ff 	add	sp, sp, #0xb0
   18134:	d65f03c0 	ret
   18138:	a90283e1 	stp	x1, x0, [sp, #40]
   1813c:	aa1403e0 	mov	x0, x20
   18140:	aa1503e1 	mov	x1, x21
   18144:	aa0203e9 	mov	x9, x2
   18148:	528000a2 	mov	w2, #0x5                   	// #5
   1814c:	a9009fe4 	stp	x4, x7, [sp, #8]
   18150:	a9018fe5 	stp	x5, x3, [sp, #24]
   18154:	97ffb32f 	bl	4e10 <heap_alloc_miss>
   18158:	a94117e7 	ldp	x7, x5, [sp, #16]
   1815c:	aa0003e8 	mov	x8, x0
   18160:	a94207e3 	ldp	x3, x1, [sp, #32]
   18164:	aa0c03fe 	mov	x30, x12
   18168:	f94007e4 	ldr	x4, [sp, #8]
   1816c:	f9401be0 	ldr	x0, [sp, #48]
   18170:	aa0903e2 	mov	x2, x9
   18174:	17ffff9c 	b	17fe4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K134+0x1ac>
   18178:	a90283e1 	stp	x1, x0, [sp, #40]
   1817c:	aa1403e0 	mov	x0, x20
   18180:	aa1503e1 	mov	x1, x21
   18184:	aa0203e9 	mov	x9, x2
   18188:	528000a2 	mov	w2, #0x5                   	// #5
   1818c:	aa0403f6 	mov	x22, x4
   18190:	f90013e3 	str	x3, [sp, #32]
   18194:	aa0703f5 	mov	x21, x7
   18198:	aa0503f7 	mov	x23, x5
   1819c:	97ffb31d 	bl	4e10 <heap_alloc_miss>
   181a0:	a94207e3 	ldp	x3, x1, [sp, #32]
   181a4:	aa0003e8 	mov	x8, x0
   181a8:	f9401be0 	ldr	x0, [sp, #48]
   181ac:	aa0c03fe 	mov	x30, x12
   181b0:	aa0903e2 	mov	x2, x9
   181b4:	aa1703e5 	mov	x5, x23
   181b8:	aa1503e7 	mov	x7, x21
   181bc:	aa1603e4 	mov	x4, x22
   181c0:	17ffffab 	b	1806c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K134+0x234>

