   177f0:	d102c3ff 	sub	sp, sp, #0xb0
   177f4:	a90a7bfd 	stp	x29, x30, [sp, #160]
   177f8:	910283fd 	add	x29, sp, #0xa0
   177fc:	a93db3aa 	stp	x10, x12, [x29, #-40]
   17800:	a943cfb8 	ldp	x24, x19, [x29, #56]
   17804:	a93e9ba4 	stp	x4, x6, [x29, #-24]
   17808:	b9405ba8 	ldr	w8, [x29, #88]
   1780c:	f9400ba2 	ldr	x2, [x29, #16]
   17810:	a944b3a4 	ldp	x4, x12, [x29, #72]
   17814:	a942cbbe 	ldp	x30, x18, [x29, #40]
   17818:	a941c3b1 	ldp	x17, x16, [x29, #24]
   1781c:	34000448 	cbz	w8, 178a4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K132+0xb4>
   17820:	b85f8ec8 	ldr	w8, [x22, #-8]!
   17824:	f0000caa 	adrp	x10, 1ae000 <io_eff_rows+0xff0f8>
   17828:	913fa14a 	add	x10, x10, #0xfe8
   1782c:	12800006 	mov	w6, #0xffffffff            	// #-1
   17830:	2a1903f9 	mov	w25, w25
   17834:	f8687948 	ldr	x8, [x10, x8, lsl #3]
   17838:	a9051bac 	stp	x12, x6, [x29, #80]
   1783c:	2a1103ec 	mov	w12, w17
   17840:	a90413b3 	stp	x19, x4, [x29, #64]
   17844:	a97e9ba4 	ldp	x4, x6, [x29, #-24]
   17848:	f81d03a8 	stur	x8, [x29, #-48]
   1784c:	2a1203e8 	mov	w8, w18
   17850:	2a1a03fa 	mov	w26, w26
   17854:	a90363a8 	stp	x8, x24, [x29, #48]
   17858:	2a1e03e8 	mov	w8, w30
   1785c:	2a0503e5 	mov	w5, w5
   17860:	f90017a8 	str	x8, [x29, #40]
   17864:	2a1003e8 	mov	w8, w16
   17868:	2a0703e7 	mov	w7, w7
   1786c:	f90013a8 	str	x8, [x29, #32]
   17870:	2a0203e8 	mov	w8, w2
   17874:	2a0b03eb 	mov	w11, w11
   17878:	a90133a8 	stp	x8, x12, [x29, #16]
   1787c:	a97db3aa 	ldp	x10, x12, [x29, #-40]
   17880:	2a0d03ed 	mov	w13, w13
   17884:	2a0e03ee 	mov	w14, w14
   17888:	2a0903e9 	mov	w9, w9
   1788c:	2a0f03ef 	mov	w15, w15
   17890:	52800398 	mov	w24, #0x1c                  	// #28
   17894:	f85d03a2 	ldur	x2, [x29, #-48]
   17898:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   1789c:	9102c3ff 	add	sp, sp, #0xb0
   178a0:	d61f0040 	br	x2
   178a4:	a93c63be 	stp	x30, x24, [x29, #-64]
   178a8:	a94663a6 	ldp	x6, x24, [x29, #96]
   178ac:	f81d03b3 	stur	x19, [x29, #-48]
   178b0:	a9472bb3 	ldp	x19, x10, [x29, #112]
   178b4:	34000537 	cbz	w23, 17958 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K132+0x168>
   178b8:	2a0603e8 	mov	w8, w6
   178bc:	aa1003fe 	mov	x30, x16
   178c0:	2a1803f0 	mov	w16, w24
   178c4:	a90042c8 	stp	x8, x16, [x22]
   178c8:	2a1303e8 	mov	w8, w19
   178cc:	2a0a03ea 	mov	w10, w10
   178d0:	a9012ac8 	stp	x8, x10, [x22, #16]
   178d4:	52800548 	mov	w8, #0x2a                  	// #42
   178d8:	2a1903f9 	mov	w25, w25
   178dc:	f90012c8 	str	x8, [x22, #32]
   178e0:	110004c8 	add	w8, w6, #0x1
   178e4:	2a1a03fa 	mov	w26, w26
   178e8:	a90523ac 	stp	x12, x8, [x29, #80]
   178ec:	a97caba8 	ldp	x8, x10, [x29, #-56]
   178f0:	2a0503e5 	mov	w5, w5
   178f4:	2a0703e7 	mov	w7, w7
   178f8:	2a0b03eb 	mov	w11, w11
   178fc:	2a0d03ed 	mov	w13, w13
   17900:	2a0e03ee 	mov	w14, w14
   17904:	2a0903e9 	mov	w9, w9
   17908:	f9001fa8 	str	x8, [x29, #56]
   1790c:	2a1203e8 	mov	w8, w18
   17910:	2a0f03ef 	mov	w15, w15
   17914:	f9001ba8 	str	x8, [x29, #48]
   17918:	f85c03a8 	ldur	x8, [x29, #-64]
   1791c:	9100a2d6 	add	x22, x22, #0x28
   17920:	a90413aa 	stp	x10, x4, [x29, #64]
   17924:	a97e9ba4 	ldp	x4, x6, [x29, #-24]
   17928:	2a0803e8 	mov	w8, w8
   1792c:	a97db3aa 	ldp	x10, x12, [x29, #-40]
   17930:	f90017a8 	str	x8, [x29, #40]
   17934:	2a1e03e8 	mov	w8, w30
   17938:	f90013a8 	str	x8, [x29, #32]
   1793c:	2a1103e8 	mov	w8, w17
   17940:	f9000fa8 	str	x8, [x29, #24]
   17944:	2a0203e8 	mov	w8, w2
   17948:	f9000ba8 	str	x8, [x29, #16]
   1794c:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   17950:	9102c3ff 	add	sp, sp, #0xb0
   17954:	17ffd159 	b	beb8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_TRANSACTION_DISPATCH_ADAPTERS_HEALTH_SET_MAIN0>
   17958:	a90347f0 	stp	x16, x17, [sp, #48]
   1795c:	f9401aa8 	ldr	x8, [x21, #48]
   17960:	a90413f2 	stp	x18, x4, [sp, #64]
   17964:	f9002bec 	str	x12, [sp, #80]
   17968:	f81b83ad 	stur	x13, [x29, #-72]
   1796c:	a97edecd 	ldp	x13, x23, [x22, #-24]
   17970:	b4000b08 	cbz	x8, 17ad0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K132+0x2e0>
   17974:	f8687a90 	ldr	x16, [x20, x8, lsl #3]
   17978:	f9409ab1 	ldr	x17, [x21, #304]
   1797c:	f9001ab0 	str	x16, [x21, #48]
   17980:	d1010230 	sub	x16, x17, #0x40
   17984:	f9009ab0 	str	x16, [x21, #304]
   17988:	52800032 	mov	w18, #0x1                   	// #1
   1798c:	8b080e90 	add	x16, x20, x8, lsl #3
   17990:	92800011 	mov	x17, #0xffffffffffffffff    	// #-1
   17994:	aa178252 	orr	x18, x18, x23, lsl #32
   17998:	6f07e7e0 	movi	v0.2d, #0xffffffffffffffff
   1799c:	f85c03ac 	ldur	x12, [x29, #-64]
   179a0:	a90f3611 	stp	x17, x13, [x16, #240]
   179a4:	2a0603f1 	mov	w17, w6
   179a8:	2a0a03ed 	mov	w13, w10
   179ac:	f9008212 	str	x18, [x16, #256]
   179b0:	2a1803f2 	mov	w18, w24
   179b4:	a9004a11 	stp	x17, x18, [x16]
   179b8:	d2c54012 	mov	x18, #0x2a0000000000        	// #46179488366592
   179bc:	2a1303f1 	mov	w17, w19
   179c0:	f2e0a012 	movk	x18, #0x500, lsl #48
   179c4:	ad018200 	stp	q0, q0, [x16, #48]
   179c8:	aa120113 	orr	x19, x8, x18
   179cc:	52800088 	mov	w8, #0x4                   	// #4
   179d0:	ad028200 	stp	q0, q0, [x16, #80]
   179d4:	ad038200 	stp	q0, q0, [x16, #112]
   179d8:	ad048200 	stp	q0, q0, [x16, #144]
   179dc:	ad058200 	stp	q0, q0, [x16, #176]
   179e0:	ad068200 	stp	q0, q0, [x16, #208]
   179e4:	3d800a00 	str	q0, [x16, #32]
   179e8:	a9013611 	stp	x17, x13, [x16, #16]
   179ec:	a93ea2d3 	stp	x19, x8, [x22, #-24]
   179f0:	f94016a8 	ldr	x8, [x21, #40]
   179f4:	b40008e8 	cbz	x8, 17b10 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K132+0x320>
   179f8:	f8687a8d 	ldr	x13, [x20, x8, lsl #3]
   179fc:	f94096b0 	ldr	x16, [x21, #296]
   17a00:	f90016ad 	str	x13, [x21, #40]
   17a04:	d100820d 	sub	x13, x16, #0x20
   17a08:	f90096ad 	str	x13, [x21, #296]
   17a0c:	8b080e8d 	add	x13, x20, x8, lsl #3
   17a10:	f85e83aa 	ldur	x10, [x29, #-24]
   17a14:	d2c00090 	mov	x16, #0x400000000           	// #17179869184
   17a18:	2a1903f1 	mov	w17, w25
   17a1c:	2a0b03eb 	mov	w11, w11
   17a20:	a90e41b3 	stp	x19, x16, [x13, #224]
   17a24:	2a1a03f0 	mov	w16, w26
   17a28:	a90329a3 	stp	x3, x10, [x13, #48]
   17a2c:	f85f03aa 	ldur	x10, [x29, #-16]
   17a30:	a90041b1 	stp	x17, x16, [x13]
   17a34:	2a0503f0 	mov	w16, w5
   17a38:	a90429b0 	stp	x16, x10, [x13, #64]
   17a3c:	2a0703f0 	mov	w16, w7
   17a40:	f90031ab 	str	x11, [x13, #96]
   17a44:	a97dafaa 	ldp	x10, x11, [x29, #-40]
   17a48:	a90529b0 	stp	x16, x10, [x13, #80]
   17a4c:	f85b83aa 	ldur	x10, [x29, #-72]
   17a50:	2a0e03f0 	mov	w16, w14
   17a54:	f90035ab 	str	x11, [x13, #104]
   17a58:	2a0a03eb 	mov	w11, w10
   17a5c:	2a0203ea 	mov	w10, w2
   17a60:	a90205a0 	stp	x0, x1, [x13, #32]
   17a64:	a90741ab 	stp	x11, x16, [x13, #112]
   17a68:	2a0903eb 	mov	w11, w9
   17a6c:	f9401fe9 	ldr	x9, [sp, #56]
   17a70:	2a0f03f0 	mov	w16, w15
   17a74:	a90171bb 	stp	x27, x28, [x13, #16]
   17a78:	a90841ab 	stp	x11, x16, [x13, #128]
   17a7c:	2a0903eb 	mov	w11, w9
   17a80:	f9401be9 	ldr	x9, [sp, #48]
   17a84:	a9092daa 	stp	x10, x11, [x13, #144]
   17a88:	2a0c03ea 	mov	w10, w12
   17a8c:	2a0903e9 	mov	w9, w9
   17a90:	a90a29a9 	stp	x9, x10, [x13, #160]
   17a94:	a9442fe9 	ldp	x9, x11, [sp, #64]
   17a98:	2a0903e9 	mov	w9, w9
   17a9c:	f90059a9 	str	x9, [x13, #176]
   17aa0:	a97ca7aa 	ldp	x10, x9, [x29, #-56]
   17aa4:	a90ba5aa 	stp	x10, x9, [x13, #184]
   17aa8:	d2c16009 	mov	x9, #0xb0000000000         	// #12094627905536
   17aac:	110004ca 	add	w10, w6, #0x1
   17ab0:	f2e0a009 	movk	x9, #0x500, lsl #48
   17ab4:	aa090100 	orr	x0, x8, x9
   17ab8:	f9402be8 	ldr	x8, [sp, #80]
   17abc:	a90ca1ab 	stp	x11, x8, [x13, #200]
   17ac0:	f9006daa 	str	x10, [x13, #216]
   17ac4:	a94a7bfd 	ldp	x29, x30, [sp, #160]
   17ac8:	9102c3ff 	add	sp, sp, #0xb0
   17acc:	d65f03c0 	ret
   17ad0:	a90203e1 	stp	x1, x0, [sp, #32]
   17ad4:	aa1403e0 	mov	x0, x20
   17ad8:	aa1503e1 	mov	x1, x21
   17adc:	a9001fed 	stp	x13, x7, [sp]
   17ae0:	aa0203ed 	mov	x13, x2
   17ae4:	528000c2 	mov	w2, #0x6                   	// #6
   17ae8:	a9010fe5 	stp	x5, x3, [sp, #16]
   17aec:	aa0603ec 	mov	x12, x6
   17af0:	97ffb4c8 	bl	4e10 <heap_alloc_miss>
   17af4:	aa0d03e2 	mov	x2, x13
   17af8:	a9401fed 	ldp	x13, x7, [sp]
   17afc:	a9410fe5 	ldp	x5, x3, [sp, #16]
   17b00:	aa0003e8 	mov	x8, x0
   17b04:	a94203e1 	ldp	x1, x0, [sp, #32]
   17b08:	aa0c03e6 	mov	x6, x12
   17b0c:	17ffff9f 	b	17988 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K132+0x198>
   17b10:	a90203e1 	stp	x1, x0, [sp, #32]
   17b14:	aa1403e0 	mov	x0, x20
   17b18:	aa1503e1 	mov	x1, x21
   17b1c:	aa0203ea 	mov	x10, x2
   17b20:	528000a2 	mov	w2, #0x5                   	// #5
   17b24:	aa0303f7 	mov	x23, x3
   17b28:	aa0703ed 	mov	x13, x7
   17b2c:	aa0503f8 	mov	x24, x5
   17b30:	aa0603f5 	mov	x21, x6
   17b34:	97ffb4b7 	bl	4e10 <heap_alloc_miss>
   17b38:	aa0003e8 	mov	x8, x0
   17b3c:	a94203e1 	ldp	x1, x0, [sp, #32]
   17b40:	aa1503e6 	mov	x6, x21
   17b44:	aa0a03e2 	mov	x2, x10
   17b48:	aa1803e5 	mov	x5, x24
   17b4c:	aa0d03e7 	mov	x7, x13
   17b50:	aa1703e3 	mov	x3, x23
   17b54:	17ffffae 	b	17a0c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_PROTOTYPE_STATIC_CLIENT_HEALTH_BODY_0_K132+0x21c>

