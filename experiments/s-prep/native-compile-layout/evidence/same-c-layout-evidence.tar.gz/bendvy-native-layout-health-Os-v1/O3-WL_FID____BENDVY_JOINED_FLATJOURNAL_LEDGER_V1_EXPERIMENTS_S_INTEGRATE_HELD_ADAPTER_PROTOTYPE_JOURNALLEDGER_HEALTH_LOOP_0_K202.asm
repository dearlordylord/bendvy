   1b6d8:	d10243ff 	sub	sp, sp, #0x90
   1b6dc:	a9087bfd 	stp	x29, x30, [sp, #128]
   1b6e0:	910203fd 	add	x29, sp, #0x80
   1b6e4:	a93d1baf 	stp	x15, x6, [x29, #-48]
   1b6e8:	a9444bbe 	ldp	x30, x18, [x29, #64]
   1b6ec:	a93e2ba9 	stp	x9, x10, [x29, #-32]
   1b6f0:	aa0703e9 	mov	x9, x7
   1b6f4:	aa1c03f8 	mov	x24, x28
   1b6f8:	f81f03ac 	stur	x12, [x29, #-16]
   1b6fc:	aa0503ec 	mov	x12, x5
   1b700:	aa0403e5 	mov	x5, x4
   1b704:	aa0303e4 	mov	x4, x3
   1b708:	aa0103e3 	mov	x3, x1
   1b70c:	aa0003e1 	mov	x1, x0
   1b710:	a9450baa 	ldp	x10, x2, [x29, #80]
   1b714:	aa1b03fc 	mov	x28, x27
   1b718:	a9431fa0 	ldp	x0, x7, [x29, #48]
   1b71c:	aa1903fb 	mov	x27, x25
   1b720:	a9421bb1 	ldp	x17, x6, [x29, #32]
   1b724:	aa1603e8 	mov	x8, x22
   1b728:	a9413fb3 	ldp	x19, x15, [x29, #16]
   1b72c:	aa0e03f0 	mov	x16, x14
   1b730:	f85f8ed9 	ldr	x25, [x22, #-8]!
   1b734:	34000417 	cbz	w23, 1b7b4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0_K202+0xdc>
   1b738:	2a1b03e8 	mov	w8, w27
   1b73c:	2a1a03fb 	mov	w27, w26
   1b740:	aa0603fa 	mov	x26, x6
   1b744:	2a0c03e6 	mov	w6, w12
   1b748:	2a0203ec 	mov	w12, w2
   1b74c:	a9052bb2 	stp	x18, x10, [x29, #80]
   1b750:	2a0903ea 	mov	w10, w9
   1b754:	2a0003e9 	mov	w9, w0
   1b758:	f90033ac 	str	x12, [x29, #96]
   1b75c:	2a0b03ec 	mov	w12, w11
   1b760:	2a1a03eb 	mov	w11, w26
   1b764:	a9047ba7 	stp	x7, x30, [x29, #64]
   1b768:	a90327ab 	stp	x11, x9, [x29, #48]
   1b76c:	aa1003e9 	mov	x9, x16
   1b770:	2a1103f0 	mov	w16, w17
   1b774:	2a0f03eb 	mov	w11, w15
   1b778:	a97dbfa7 	ldp	x7, x15, [x29, #-40]
   1b77c:	a90243ab 	stp	x11, x16, [x29, #32]
   1b780:	f85d03ab 	ldur	x11, [x29, #-48]
   1b784:	2a1303f0 	mov	w16, w19
   1b788:	2a0d03ee 	mov	w14, w13
   1b78c:	2a0903e9 	mov	w9, w9
   1b790:	aa0803fa 	mov	x26, x8
   1b794:	2a0b03f1 	mov	w17, w11
   1b798:	2a0f03ef 	mov	w15, w15
   1b79c:	aa1803e0 	mov	x0, x24
   1b7a0:	a90143b1 	stp	x17, x16, [x29, #16]
   1b7a4:	a97eb7ab 	ldp	x11, x13, [x29, #-24]
   1b7a8:	a9487bfd 	ldp	x29, x30, [sp, #128]
   1b7ac:	910243ff 	add	sp, sp, #0x90
   1b7b0:	17fffdc1 	b	1aeb4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0>
   1b7b4:	f9001ff1 	str	x17, [sp, #56]
   1b7b8:	a97e5d11 	ldp	x17, x23, [x8, #-32]
   1b7bc:	a90297ed 	stp	x13, x5, [sp, #40]
   1b7c0:	aa0103f6 	mov	x22, x1
   1b7c4:	aa0303ee 	mov	x14, x3
   1b7c8:	f81c83a0 	stur	x0, [x29, #-56]
   1b7cc:	f94016a0 	ldr	x0, [x21, #40]
   1b7d0:	aa0403ed 	mov	x13, x4
   1b7d4:	f90023f0 	str	x16, [sp, #64]
   1b7d8:	b40006e0 	cbz	x0, 1b8b4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0_K202+0x1dc>
   1b7dc:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   1b7e0:	f94096b0 	ldr	x16, [x21, #296]
   1b7e4:	f90016a8 	str	x8, [x21, #40]
   1b7e8:	d1008208 	sub	x8, x16, #0x20
   1b7ec:	f90096a8 	str	x8, [x21, #296]
   1b7f0:	8b000e88 	add	x8, x20, x0, lsl #3
   1b7f4:	2a0c03ec 	mov	w12, w12
   1b7f8:	2a0903e9 	mov	w9, w9
   1b7fc:	d3607ef0 	lsl	x16, x23, #32
   1b800:	a903350e 	stp	x14, x13, [x8, #48]
   1b804:	f9401bed 	ldr	x13, [sp, #48]
   1b808:	f9007910 	str	x16, [x8, #240]
   1b80c:	2a1b03f0 	mov	w16, w27
   1b810:	a904310d 	stp	x13, x12, [x8, #64]
   1b814:	f85d83ac 	ldur	x12, [x29, #-40]
   1b818:	a9004119 	stp	x25, x16, [x8]
   1b81c:	2a1a03f0 	mov	w16, w26
   1b820:	a905250c 	stp	x12, x9, [x8, #80]
   1b824:	2a0b03e9 	mov	w9, w11
   1b828:	f85e83ab 	ldur	x11, [x29, #-24]
   1b82c:	a9017110 	stp	x16, x28, [x8, #16]
   1b830:	a906250b 	stp	x11, x9, [x8, #96]
   1b834:	f94017e9 	ldr	x9, [sp, #40]
   1b838:	f85f03ab 	ldur	x11, [x29, #-16]
   1b83c:	a9025918 	stp	x24, x22, [x8, #32]
   1b840:	2a0903e9 	mov	w9, w9
   1b844:	a90c7907 	stp	x7, x30, [x8, #192]
   1b848:	a907250b 	stp	x11, x9, [x8, #112]
   1b84c:	f94023e9 	ldr	x9, [sp, #64]
   1b850:	f85e03ab 	ldur	x11, [x29, #-32]
   1b854:	a90d2912 	stp	x18, x10, [x8, #208]
   1b858:	2a0903e9 	mov	w9, w9
   1b85c:	2a0b03eb 	mov	w11, w11
   1b860:	a9082d09 	stp	x9, x11, [x8, #128]
   1b864:	f85d03a9 	ldur	x9, [x29, #-48]
   1b868:	2a1303eb 	mov	w11, w19
   1b86c:	2a0903e9 	mov	w9, w9
   1b870:	a9092d09 	stp	x9, x11, [x8, #144]
   1b874:	f9401feb 	ldr	x11, [sp, #56]
   1b878:	2a0f03e9 	mov	w9, w15
   1b87c:	2a0b03eb 	mov	w11, w11
   1b880:	a90a2d09 	stp	x9, x11, [x8, #160]
   1b884:	f85c83ab 	ldur	x11, [x29, #-56]
   1b888:	2a0603e9 	mov	w9, w6
   1b88c:	2a0b03eb 	mov	w11, w11
   1b890:	a90b2d09 	stp	x9, x11, [x8, #176]
   1b894:	d2c76009 	mov	x9, #0x3b0000000000        	// #64871186038784
   1b898:	f2e0a009 	movk	x9, #0x500, lsl #48
   1b89c:	aa090000 	orr	x0, x0, x9
   1b8a0:	2a0203e9 	mov	w9, w2
   1b8a4:	a90e4509 	stp	x9, x17, [x8, #224]
   1b8a8:	a9487bfd 	ldp	x29, x30, [sp, #128]
   1b8ac:	910243ff 	add	sp, sp, #0x90
   1b8b0:	d65f03c0 	ret
   1b8b4:	aa1403e0 	mov	x0, x20
   1b8b8:	a9018be7 	stp	x7, x2, [sp, #24]
   1b8bc:	aa1503e1 	mov	x1, x21
   1b8c0:	528000a2 	mov	w2, #0x5                   	// #5
   1b8c4:	a900fbf2 	stp	x18, x30, [sp, #8]
   1b8c8:	aa1103f5 	mov	x21, x17
   1b8cc:	f90003e6 	str	x6, [sp]
   1b8d0:	97ffa550 	bl	4e10 <heap_alloc_miss>
   1b8d4:	a9404be6 	ldp	x6, x18, [sp]
   1b8d8:	aa1503f1 	mov	x17, x21
   1b8dc:	a9411ffe 	ldp	x30, x7, [sp, #16]
   1b8e0:	f94013e2 	ldr	x2, [sp, #32]
   1b8e4:	17ffffc3 	b	1b7f0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0_K202+0x118>

