   19e3c:	d10443ff 	sub	sp, sp, #0x110
   19e40:	a9107bfd 	stp	x29, x30, [sp, #256]
   19e44:	910403fd 	add	x29, sp, #0x100
   19e48:	aa0903f0 	mov	x16, x9
   19e4c:	92583f28 	and	x8, x25, #0xffff0000000000
   19e50:	d2c1c009 	mov	x9, #0xe0000000000         	// #15393162788864
   19e54:	aa0c03e2 	mov	x2, x12
   19e58:	aa0b03fe 	mov	x30, x11
   19e5c:	a93e17a7 	stp	x7, x5, [x29, #-32]
   19e60:	a93d13a3 	stp	x3, x4, [x29, #-48]
   19e64:	aa1c03e3 	mov	x3, x28
   19e68:	eb09011f 	cmp	x8, x9
   19e6c:	a9459fb1 	ldp	x17, x7, [x29, #88]
   19e70:	b81f03b7 	stur	w23, [x29, #-16]
   19e74:	a944b3a5 	ldp	x5, x12, [x29, #72]
   19e78:	f9400bb7 	ldr	x23, [x29, #16]
   19e7c:	a943f3b3 	ldp	x19, x28, [x29, #56]
   19e80:	a94293ab 	ldp	x11, x4, [x29, #40]
   19e84:	a941a7b8 	ldp	x24, x9, [x29, #24]
   19e88:	54000581 	b.ne	19f38 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0xfc>  // b.any
   19e8c:	b85f8ec8 	ldr	w8, [x22, #-8]!
   19e90:	aa1103f9 	mov	x25, x17
   19e94:	aa0903f1 	mov	x17, x9
   19e98:	b0000ca9 	adrp	x9, 1ae000 <io_eff_rows+0xff0b0>
   19e9c:	913fa129 	add	x9, x9, #0xfe8
   19ea0:	f8687928 	ldr	x8, [x9, x8, lsl #3]
   19ea4:	a904e7ac 	stp	x12, x25, [x29, #72]
   19ea8:	aa0d03f2 	mov	x18, x13
   19eac:	a90397bc 	stp	x28, x5, [x29, #56]
   19eb0:	2a0603e5 	mov	w5, w6
   19eb4:	aa0003fc 	mov	x28, x0
   19eb8:	f81c83a8 	stur	x8, [x29, #-56]
   19ebc:	2a0703e8 	mov	w8, w7
   19ec0:	aa0103e0 	mov	x0, x1
   19ec4:	a905e7a8 	stp	x8, x25, [x29, #88]
   19ec8:	2a1303e8 	mov	w8, w19
   19ecc:	2a1a03f9 	mov	w25, w26
   19ed0:	f9001ba8 	str	x8, [x29, #48]
   19ed4:	2a0403e8 	mov	w8, w4
   19ed8:	2a1b03fa 	mov	w26, w27
   19edc:	f90017a8 	str	x8, [x29, #40]
   19ee0:	2a0b03e8 	mov	w8, w11
   19ee4:	aa0303fb 	mov	x27, x3
   19ee8:	a97d0fa1 	ldp	x1, x3, [x29, #-48]
   19eec:	f90013a8 	str	x8, [x29, #32]
   19ef0:	a97e13a6 	ldp	x6, x4, [x29, #-32]
   19ef4:	2a0a03e7 	mov	w7, w10
   19ef8:	2a0f03e9 	mov	w9, w15
   19efc:	2a1703ef 	mov	w15, w23
   19f00:	2a1803e8 	mov	w8, w24
   19f04:	2a1103ea 	mov	w10, w17
   19f08:	b85f03b7 	ldur	w23, [x29, #-16]
   19f0c:	2a0203eb 	mov	w11, w2
   19f10:	2a0e03ed 	mov	w13, w14
   19f14:	2a1003ee 	mov	w14, w16
   19f18:	a9012ba8 	stp	x8, x10, [x29, #16]
   19f1c:	52800398 	mov	w24, #0x1c                  	// #28
   19f20:	aa1e03ea 	mov	x10, x30
   19f24:	aa1203ec 	mov	x12, x18
   19f28:	f85c83a2 	ldur	x2, [x29, #-56]
   19f2c:	a9507bfd 	ldp	x29, x30, [sp, #256]
   19f30:	910443ff 	add	sp, sp, #0x110
   19f34:	d61f0040 	br	x2
   19f38:	f81a83b8 	stur	x24, [x29, #-88]
   19f3c:	aa1e03f8 	mov	x24, x30
   19f40:	aa1003f2 	mov	x18, x16
   19f44:	a97e7bb0 	ldp	x16, x30, [x29, #-32]
   19f48:	92409f28 	and	x8, x25, #0xffffffffff
   19f4c:	f81c83b6 	stur	x22, [x29, #-56]
   19f50:	aa1103f6 	mov	x22, x17
   19f54:	aa0203f1 	mov	x17, x2
   19f58:	a905cfe4 	stp	x4, x19, [sp, #88]
   19f5c:	aa0003e2 	mov	x2, x0
   19f60:	a939afba 	stp	x26, x11, [x29, #-104]
   19f64:	8b080e8b 	add	x11, x20, x8, lsl #3
   19f68:	aa0d03fa 	mov	x26, x13
   19f6c:	a93b1ba9 	stp	x9, x6, [x29, #-80]
   19f70:	f81c03aa 	stur	x10, [x29, #-64]
   19f74:	f81903af 	stur	x15, [x29, #-112]
   19f78:	b7f80119 	tbnz	x25, #63, 19f98 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x15c>
   19f7c:	a9402969 	ldp	x9, x10, [x11]
   19f80:	aa0803f3 	mov	x19, x8
   19f84:	aa1e03e6 	mov	x6, x30
   19f88:	aa0503fe 	mov	x30, x5
   19f8c:	f9003fea 	str	x10, [sp, #120]
   19f90:	aa1003ea 	mov	x10, x16
   19f94:	1400001b 	b	1a000 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x1c4>
   19f98:	b9400569 	ldr	w9, [x11, #4]
   19f9c:	b940016a 	ldr	w10, [x11]
   19fa0:	aa1e03e6 	mov	x6, x30
   19fa4:	92405d4d 	and	x13, x10, #0xffffff
   19fa8:	f10005bf 	cmp	x13, #0x1
   19fac:	54002661 	b.ne	1a478 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x63c>  // b.any
   19fb0:	aa098149 	orr	x9, x10, x9, lsl #32
   19fb4:	88dffd7f 	ldar	wzr, [x11]
   19fb8:	f94002ab 	ldr	x11, [x21]
   19fbc:	aa0503fe 	mov	x30, x5
   19fc0:	d358fd33 	lsr	x19, x9, #24
   19fc4:	8b130e8d 	add	x13, x20, x19, lsl #3
   19fc8:	a94029a9 	ldp	x9, x10, [x13]
   19fcc:	f8287a8b 	str	x11, [x20, x8, lsl #3]
   19fd0:	f0000cab 	adrp	x11, 1b0000 <memcpy@GLIBC_2.17>
   19fd4:	f94082ad 	ldr	x13, [x21, #256]
   19fd8:	f90002a8 	str	x8, [x21]
   19fdc:	3948316b 	ldrb	w11, [x11, #524]
   19fe0:	f9003fea 	str	x10, [sp, #120]
   19fe4:	910005a8 	add	x8, x13, #0x1
   19fe8:	aa1003ea 	mov	x10, x16
   19fec:	7100057f 	cmp	w11, #0x1
   19ff0:	f90082a8 	str	x8, [x21, #256]
   19ff4:	54002d81 	b.ne	1a5a4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x768>  // b.any
   19ff8:	f140211f 	cmp	x8, #0x8, lsl #12
   19ffc:	54002d42 	b.cs	1a5a4 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x768>  // b.hs, b.nlast
   1a000:	aa1203f0 	mov	x16, x18
   1a004:	aa0203f2 	mov	x18, x2
   1a008:	aa0c03e5 	mov	x5, x12
   1a00c:	aa0e03ec 	mov	x12, x14
   1a010:	aa1103ee 	mov	x14, x17
   1a014:	aa1603f1 	mov	x17, x22
   1a018:	aa0703e4 	mov	x4, x7
   1a01c:	aa1c03e7 	mov	x7, x28
   1a020:	aa1703fc 	mov	x28, x23
   1a024:	92409d28 	and	x8, x9, #0xffffffffff
   1a028:	52909feb 	mov	w11, #0x84ff                	// #34047
   1a02c:	8b080e82 	add	x2, x20, x8, lsl #3
   1a030:	72a0620b 	movk	w11, #0x310, lsl #16
   1a034:	b7f800e9 	tbnz	x9, #63, 1a050 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x214>
   1a038:	b9400049 	ldr	w9, [x2]
   1a03c:	f81883a9 	stur	x9, [x29, #-120]
   1a040:	b9400849 	ldr	w9, [x2, #8]
   1a044:	f90043e9 	str	x9, [sp, #128]
   1a048:	aa0803e9 	mov	x9, x8
   1a04c:	14000020 	b	1a0cc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x290>
   1a050:	a9069ffc 	stp	x28, x7, [sp, #104]
   1a054:	aa0e03f9 	mov	x25, x14
   1a058:	aa0c03fc 	mov	x28, x12
   1a05c:	b940044d 	ldr	w13, [x2, #4]
   1a060:	b940004e 	ldr	w14, [x2]
   1a064:	92405dcf 	and	x15, x14, #0xffffff
   1a068:	f10005ff 	cmp	x15, #0x1
   1a06c:	54002481 	b.ne	1a4fc <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x6c0>  // b.any
   1a070:	aa0d81c9 	orr	x9, x14, x13, lsl #32
   1a074:	88dffc5f 	ldar	wzr, [x2]
   1a078:	f94002ac 	ldr	x12, [x21]
   1a07c:	d358fd29 	lsr	x9, x9, #24
   1a080:	8b090e8d 	add	x13, x20, x9, lsl #3
   1a084:	b94001ae 	ldr	w14, [x13]
   1a088:	b94009ad 	ldr	w13, [x13, #8]
   1a08c:	f8287a8c 	str	x12, [x20, x8, lsl #3]
   1a090:	d0000cac 	adrp	x12, 1b0000 <memcpy@GLIBC_2.17>
   1a094:	f90002a8 	str	x8, [x21]
   1a098:	f81883ae 	stur	x14, [x29, #-120]
   1a09c:	3948318c 	ldrb	w12, [x12, #524]
   1a0a0:	f90043ed 	str	x13, [sp, #128]
   1a0a4:	f94082ad 	ldr	x13, [x21, #256]
   1a0a8:	7100059f 	cmp	w12, #0x1
   1a0ac:	910005a8 	add	x8, x13, #0x1
   1a0b0:	f90082a8 	str	x8, [x21, #256]
   1a0b4:	54002a81 	b.ne	1a604 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x7c8>  // b.any
   1a0b8:	f140211f 	cmp	x8, #0x8, lsl #12
   1a0bc:	54002a42 	b.cs	1a604 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x7c8>  // b.hs, b.nlast
   1a0c0:	aa1c03ec 	mov	x12, x28
   1a0c4:	a9469ffc 	ldp	x28, x7, [sp, #104]
   1a0c8:	aa1903ee 	mov	x14, x25
   1a0cc:	eb0b013f 	cmp	x9, x11
   1a0d0:	aa1a03e2 	mov	x2, x26
   1a0d4:	540001e9 	b.ls	1a110 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x2d4>  // b.plast
   1a0d8:	f94006a8 	ldr	x8, [x21, #8]
   1a0dc:	aa1c03f9 	mov	x25, x28
   1a0e0:	f8297a88 	str	x8, [x20, x9, lsl #3]
   1a0e4:	d0000ca8 	adrp	x8, 1b0000 <memcpy@GLIBC_2.17>
   1a0e8:	f94086af 	ldr	x15, [x21, #264]
   1a0ec:	3948310d 	ldrb	w13, [x8, #524]
   1a0f0:	f90006a9 	str	x9, [x21, #8]
   1a0f4:	910009e8 	add	x8, x15, #0x2
   1a0f8:	710005bf 	cmp	w13, #0x1
   1a0fc:	f90086a8 	str	x8, [x21, #264]
   1a100:	540018a1 	b.ne	1a414 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x5d8>  // b.any
   1a104:	f140211f 	cmp	x8, #0x8, lsl #12
   1a108:	54001862 	b.cs	1a414 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x5d8>  // b.hs, b.nlast
   1a10c:	aa1903fc 	mov	x28, x25
   1a110:	eb0b027f 	cmp	x19, x11
   1a114:	540001a9 	b.ls	1a148 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x30c>  // b.plast
   1a118:	f94006a8 	ldr	x8, [x21, #8]
   1a11c:	f8337a88 	str	x8, [x20, x19, lsl #3]
   1a120:	d0000ca8 	adrp	x8, 1b0000 <memcpy@GLIBC_2.17>
   1a124:	f94086a9 	ldr	x9, [x21, #264]
   1a128:	3948310b 	ldrb	w11, [x8, #524]
   1a12c:	f90006b3 	str	x19, [x21, #8]
   1a130:	91000928 	add	x8, x9, #0x2
   1a134:	7100057f 	cmp	w11, #0x1
   1a138:	f90086a8 	str	x8, [x21, #264]
   1a13c:	54001361 	b.ne	1a3a8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x56c>  // b.any
   1a140:	f140211f 	cmp	x8, #0x8, lsl #12
   1a144:	54001322 	b.cs	1a3a8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x56c>  // b.hs, b.nlast
   1a148:	b85f03a8 	ldur	w8, [x29, #-16]
   1a14c:	340005a8 	cbz	w8, 1a200 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x3c4>
   1a150:	f85c83b6 	ldur	x22, [x29, #-56]
   1a154:	f9403fe9 	ldr	x9, [sp, #120]
   1a158:	52800788 	mov	w8, #0x3c                  	// #60
   1a15c:	2a0e03ed 	mov	w13, w14
   1a160:	a978bbb9 	ldp	x25, x14, [x29, #-120]
   1a164:	a88122c9 	stp	x9, x8, [x22], #16
   1a168:	2a0403e8 	mov	w8, w4
   1a16c:	f90037a8 	str	x8, [x29, #104]
   1a170:	f85a03a8 	ldur	x8, [x29, #-96]
   1a174:	2a1003ef 	mov	w15, w16
   1a178:	a905c7a5 	stp	x5, x17, [x29, #88]
   1a17c:	a97d17a4 	ldp	x4, x5, [x29, #-48]
   1a180:	2a0803e8 	mov	w8, w8
   1a184:	a904fba7 	stp	x7, x30, [x29, #72]
   1a188:	2a0e03f0 	mov	w16, w14
   1a18c:	f9001ba8 	str	x8, [x29, #48]
   1a190:	a97b27a8 	ldp	x8, x9, [x29, #-80]
   1a194:	b85f03b7 	ldur	w23, [x29, #-16]
   1a198:	aa0303e0 	mov	x0, x3
   1a19c:	aa0203ee 	mov	x14, x2
   1a1a0:	2a0803e8 	mov	w8, w8
   1a1a4:	2a0903e7 	mov	w7, w9
   1a1a8:	f85c03a9 	ldur	x9, [x29, #-64]
   1a1ac:	f90017a8 	str	x8, [x29, #40]
   1a1b0:	f85a83a8 	ldur	x8, [x29, #-88]
   1a1b4:	2a0903eb 	mov	w11, w9
   1a1b8:	2a0c03e9 	mov	w9, w12
   1a1bc:	aa1803ec 	mov	x12, x24
   1a1c0:	2a0803e8 	mov	w8, w8
   1a1c4:	f90013a8 	str	x8, [x29, #32]
   1a1c8:	2a1c03e8 	mov	w8, w28
   1a1cc:	2a1b03fc 	mov	w28, w27
   1a1d0:	f9000fa8 	str	x8, [x29, #24]
   1a1d4:	f85983a8 	ldur	x8, [x29, #-104]
   1a1d8:	f94043fa 	ldr	x26, [sp, #128]
   1a1dc:	2a0803e8 	mov	w8, w8
   1a1e0:	aa0803fb 	mov	x27, x8
   1a1e4:	aa0103e8 	mov	x8, x1
   1a1e8:	aa1203e1 	mov	x1, x18
   1a1ec:	aa0803e3 	mov	x3, x8
   1a1f0:	f9000bb0 	str	x16, [x29, #16]
   1a1f4:	a9507bfd 	ldp	x29, x30, [sp, #256]
   1a1f8:	910443ff 	add	sp, sp, #0x110
   1a1fc:	17fff69c 	b	17c6c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_STEP_0>
   1a200:	a9038ff1 	stp	x17, x3, [sp, #56]
   1a204:	f94016b7 	ldr	x23, [x21, #40]
   1a208:	aa0203f9 	mov	x25, x2
   1a20c:	a90017fb 	stp	x27, x5, [sp]
   1a210:	f9000bfe 	str	x30, [sp, #16]
   1a214:	a904cbe4 	stp	x4, x18, [sp, #72]
   1a218:	f9001be1 	str	x1, [sp, #48]
   1a21c:	f81f03b0 	stur	x16, [x29, #-16]
   1a220:	f85903ba 	ldur	x26, [x29, #-112]
   1a224:	f9000ff8 	str	x24, [sp, #24]
   1a228:	f85c83a8 	ldur	x8, [x29, #-56]
   1a22c:	a90233ee 	stp	x14, x12, [sp, #32]
   1a230:	a9069ffc 	stp	x28, x7, [sp, #104]
   1a234:	a97ecd18 	ldp	x24, x19, [x8, #-24]
   1a238:	b4001a17 	cbz	x23, 1a578 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x73c>
   1a23c:	f8777a88 	ldr	x8, [x20, x23, lsl #3]
   1a240:	f94096a9 	ldr	x9, [x21, #296]
   1a244:	f90016a8 	str	x8, [x21, #40]
   1a248:	d1008128 	sub	x8, x9, #0x20
   1a24c:	f90096a8 	str	x8, [x21, #296]
   1a250:	8b170e9c 	add	x28, x20, x23, lsl #3
   1a254:	52801fe1 	mov	w1, #0xff                  	// #255
   1a258:	52801c02 	mov	w2, #0xe0                  	// #224
   1a25c:	91002380 	add	x0, x28, #0x8
   1a260:	97ffa60c 	bl	3a90 <memset@plt>
   1a264:	f9403fe9 	ldr	x9, [sp, #120]
   1a268:	52800028 	mov	w8, #0x1                   	// #1
   1a26c:	f85c83b6 	ldur	x22, [x29, #-56]
   1a270:	aa13810a 	orr	x10, x8, x19, lsl #32
   1a274:	f9000389 	str	x9, [x28]
   1a278:	d2c78009 	mov	x9, #0x3c0000000000        	// #65970697666560
   1a27c:	f2e0a009 	movk	x9, #0x500, lsl #48
   1a280:	a90eab98 	stp	x24, x10, [x28, #232]
   1a284:	aa0902e9 	orr	x9, x23, x9
   1a288:	a93ea2c9 	stp	x9, x8, [x22, #-24]
   1a28c:	f94016a0 	ldr	x0, [x21, #40]
   1a290:	b4001800 	cbz	x0, 1a590 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x754>
   1a294:	f8607a88 	ldr	x8, [x20, x0, lsl #3]
   1a298:	f94096aa 	ldr	x10, [x21, #296]
   1a29c:	f90016a8 	str	x8, [x21, #40]
   1a2a0:	d1008148 	sub	x8, x10, #0x20
   1a2a4:	f90096a8 	str	x8, [x21, #296]
   1a2a8:	8b000e88 	add	x8, x20, x0, lsl #3
   1a2ac:	d2c0002a 	mov	x10, #0x100000000           	// #4294967296
   1a2b0:	f85983b0 	ldur	x16, [x29, #-104]
   1a2b4:	a9422fec 	ldp	x12, x11, [sp, #32]
   1a2b8:	f85a83ae 	ldur	x14, [x29, #-88]
   1a2bc:	a90f2909 	stp	x9, x10, [x8, #240]
   1a2c0:	f85883aa 	ldur	x10, [x29, #-120]
   1a2c4:	f94043e9 	ldr	x9, [sp, #128]
   1a2c8:	a946b7ef 	ldp	x15, x13, [sp, #104]
   1a2cc:	a900250a 	stp	x10, x9, [x8]
   1a2d0:	2a1003e9 	mov	w9, w16
   1a2d4:	f94003ea 	ldr	x10, [sp]
   1a2d8:	a945c7f2 	ldp	x18, x17, [sp, #88]
   1a2dc:	2a0a03ea 	mov	w10, w10
   1a2e0:	a9012909 	stp	x9, x10, [x8, #16]
   1a2e4:	f94023ea 	ldr	x10, [sp, #64]
   1a2e8:	f9402be9 	ldr	x9, [sp, #80]
   1a2ec:	a902250a 	stp	x10, x9, [x8, #32]
   1a2f0:	f9401bea 	ldr	x10, [sp, #48]
   1a2f4:	f85d03a9 	ldur	x9, [x29, #-48]
   1a2f8:	a903250a 	stp	x10, x9, [x8, #48]
   1a2fc:	f85d83aa 	ldur	x10, [x29, #-40]
   1a300:	f85e83a9 	ldur	x9, [x29, #-24]
   1a304:	a904250a 	stp	x10, x9, [x8, #64]
   1a308:	f85b83a9 	ldur	x9, [x29, #-72]
   1a30c:	f85e03aa 	ldur	x10, [x29, #-32]
   1a310:	2a0903e9 	mov	w9, w9
   1a314:	f9002909 	str	x9, [x8, #80]
   1a318:	f85c03a9 	ldur	x9, [x29, #-64]
   1a31c:	2a0903e9 	mov	w9, w9
   1a320:	a905a50a 	stp	x10, x9, [x8, #88]
   1a324:	f9400fea 	ldr	x10, [sp, #24]
   1a328:	2a0c03e9 	mov	w9, w12
   1a32c:	a906a50a 	stp	x10, x9, [x8, #104]
   1a330:	f85f03aa 	ldur	x10, [x29, #-16]
   1a334:	2a0b03e9 	mov	w9, w11
   1a338:	a907a519 	stp	x25, x9, [x8, #120]
   1a33c:	2a1a03e9 	mov	w9, w26
   1a340:	2a0a03ea 	mov	w10, w10
   1a344:	f900450a 	str	x10, [x8, #136]
   1a348:	2a0f03ea 	mov	w10, w15
   1a34c:	a9092909 	stp	x9, x10, [x8, #144]
   1a350:	f85b03aa 	ldur	x10, [x29, #-80]
   1a354:	2a0e03e9 	mov	w9, w14
   1a358:	2a0a03ea 	mov	w10, w10
   1a35c:	a90a2909 	stp	x9, x10, [x8, #160]
   1a360:	f85a03a9 	ldur	x9, [x29, #-96]
   1a364:	2a1203ea 	mov	w10, w18
   1a368:	2a0903e9 	mov	w9, w9
   1a36c:	a90b2909 	stp	x9, x10, [x8, #176]
   1a370:	2a1103e9 	mov	w9, w17
   1a374:	a90c3509 	stp	x9, x13, [x8, #192]
   1a378:	a940abe9 	ldp	x9, x10, [sp, #8]
   1a37c:	a90d250a 	stp	x10, x9, [x8, #208]
   1a380:	d2c66009 	mov	x9, #0x330000000000        	// #56075093016576
   1a384:	f9401fea 	ldr	x10, [sp, #56]
   1a388:	f2e0a009 	movk	x9, #0x500, lsl #48
   1a38c:	aa090000 	orr	x0, x0, x9
   1a390:	f94027e9 	ldr	x9, [sp, #72]
   1a394:	2a0903e9 	mov	w9, w9
   1a398:	a90e250a 	stp	x10, x9, [x8, #224]
   1a39c:	a9507bfd 	ldp	x29, x30, [sp, #256]
   1a3a0:	910443ff 	add	sp, sp, #0x110
   1a3a4:	d65f03c0 	ret
   1a3a8:	aa1403e0 	mov	x0, x20
   1a3ac:	aa0103ef 	mov	x15, x1
   1a3b0:	aa1503e1 	mov	x1, x21
   1a3b4:	52800022 	mov	w2, #0x1                   	// #1
   1a3b8:	a90413e3 	stp	x3, x4, [sp, #64]
   1a3bc:	aa0603eb 	mov	x11, x6
   1a3c0:	f9002bf2 	str	x18, [sp, #80]
   1a3c4:	aa1003e9 	mov	x9, x16
   1a3c8:	aa1e03f9 	mov	x25, x30
   1a3cc:	a901bbf8 	stp	x24, x14, [sp, #24]
   1a3d0:	a9069ffc 	stp	x28, x7, [sp, #104]
   1a3d4:	f90017ec 	str	x12, [sp, #40]
   1a3d8:	aa0503ec 	mov	x12, x5
   1a3dc:	f9001ff1 	str	x17, [sp, #56]
   1a3e0:	97ffa800 	bl	43e0 <heap_hand>
   1a3e4:	a9438ff1 	ldp	x17, x3, [sp, #56]
   1a3e8:	aa0c03e5 	mov	x5, x12
   1a3ec:	a944cbe4 	ldp	x4, x18, [sp, #72]
   1a3f0:	aa1a03e2 	mov	x2, x26
   1a3f4:	a9469ffc 	ldp	x28, x7, [sp, #104]
   1a3f8:	aa1903fe 	mov	x30, x25
   1a3fc:	a94233ee 	ldp	x14, x12, [sp, #32]
   1a400:	aa0f03e1 	mov	x1, x15
   1a404:	f9400ff8 	ldr	x24, [sp, #24]
   1a408:	aa0903f0 	mov	x16, x9
   1a40c:	aa0b03e6 	mov	x6, x11
   1a410:	17ffff4e 	b	1a148 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x30c>
   1a414:	aa1403e0 	mov	x0, x20
   1a418:	aa0103e8 	mov	x8, x1
   1a41c:	aa1503e1 	mov	x1, x21
   1a420:	52800022 	mov	w2, #0x1                   	// #1
   1a424:	a90413e3 	stp	x3, x4, [sp, #64]
   1a428:	aa1003e9 	mov	x9, x16
   1a42c:	f9002bf2 	str	x18, [sp, #80]
   1a430:	a901bbf8 	stp	x24, x14, [sp, #24]
   1a434:	f9003be7 	str	x7, [sp, #112]
   1a438:	a902a3ec 	stp	x12, x8, [sp, #40]
   1a43c:	aa0503ec 	mov	x12, x5
   1a440:	f9000bfe 	str	x30, [sp, #16]
   1a444:	f9001ff1 	str	x17, [sp, #56]
   1a448:	97ffa7e6 	bl	43e0 <heap_hand>
   1a44c:	a9438ff1 	ldp	x17, x3, [sp, #56]
   1a450:	aa0c03e5 	mov	x5, x12
   1a454:	a94163fe 	ldp	x30, x24, [sp, #16]
   1a458:	aa1a03e2 	mov	x2, x26
   1a45c:	a944cbe4 	ldp	x4, x18, [sp, #72]
   1a460:	aa0903f0 	mov	x16, x9
   1a464:	a94287ec 	ldp	x12, x1, [sp, #40]
   1a468:	f94013ee 	ldr	x14, [sp, #32]
   1a46c:	f85e83a6 	ldur	x6, [x29, #-24]
   1a470:	f9403be7 	ldr	x7, [sp, #112]
   1a474:	17ffff26 	b	1a10c <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x2d0>
   1a478:	aa098148 	orr	x8, x10, x9, lsl #32
   1a47c:	a9041fe3 	stp	x3, x7, [sp, #64]
   1a480:	aa1403e0 	mov	x0, x20
   1a484:	a90287ee 	stp	x14, x1, [sp, #40]
   1a488:	aa1503e1 	mov	x1, x21
   1a48c:	52800044 	mov	w4, #0x2                   	// #2
   1a490:	d358fd0a 	lsr	x10, x8, #24
   1a494:	f9002be2 	str	x2, [sp, #80]
   1a498:	aa1903e2 	mov	x2, x25
   1a49c:	aa1003eb 	mov	x11, x16
   1a4a0:	f90013f1 	str	x17, [sp, #32]
   1a4a4:	aa1203ef 	mov	x15, x18
   1a4a8:	8b0a0e88 	add	x8, x20, x10, lsl #3
   1a4ac:	aa0a03e3 	mov	x3, x10
   1a4b0:	aa0603ea 	mov	x10, x6
   1a4b4:	f90037f7 	str	x23, [sp, #104]
   1a4b8:	aa0503f9 	mov	x25, x5
   1a4bc:	a9402109 	ldp	x9, x8, [x8]
   1a4c0:	a90723fc 	stp	x28, x8, [sp, #112]
   1a4c4:	97ffa7fa 	bl	44ac <span_fade>
   1a4c8:	aa0c03e5 	mov	x5, x12
   1a4cc:	a94413e3 	ldp	x3, x4, [sp, #64]
   1a4d0:	a94287ec 	ldp	x12, x1, [sp, #40]
   1a4d4:	aa1603f1 	mov	x17, x22
   1a4d8:	a9469ffc 	ldp	x28, x7, [sp, #104]
   1a4dc:	aa1903fe 	mov	x30, x25
   1a4e0:	f9402bf2 	ldr	x18, [sp, #80]
   1a4e4:	f94013ee 	ldr	x14, [sp, #32]
   1a4e8:	aa0f03f0 	mov	x16, x15
   1a4ec:	aa0a03e6 	mov	x6, x10
   1a4f0:	aa0b03ea 	mov	x10, x11
   1a4f4:	aa1f03f3 	mov	x19, xzr
   1a4f8:	17fffecb 	b	1a024 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x1e8>
   1a4fc:	aa0d81c8 	orr	x8, x14, x13, lsl #32
   1a500:	f9001be1 	str	x1, [sp, #48]
   1a504:	aa1403e0 	mov	x0, x20
   1a508:	aa1503e1 	mov	x1, x21
   1a50c:	aa0903e2 	mov	x2, x9
   1a510:	aa1003ef 	mov	x15, x16
   1a514:	d358fd0d 	lsr	x13, x8, #24
   1a518:	8b0d0e88 	add	x8, x20, x13, lsl #3
   1a51c:	b940010c 	ldr	w12, [x8]
   1a520:	b9400908 	ldr	w8, [x8, #8]
   1a524:	f81883ac 	stur	x12, [x29, #-120]
   1a528:	a90413e3 	stp	x3, x4, [sp, #64]
   1a52c:	aa0d03e3 	mov	x3, x13
   1a530:	52800044 	mov	w4, #0x2                   	// #2
   1a534:	f90043e8 	str	x8, [sp, #128]
   1a538:	aa0603ed 	mov	x13, x6
   1a53c:	f9002bf2 	str	x18, [sp, #80]
   1a540:	a900fbe5 	stp	x5, x30, [sp, #8]
   1a544:	f9001ff1 	str	x17, [sp, #56]
   1a548:	97ffa7d9 	bl	44ac <span_fade>
   1a54c:	a9438ff1 	ldp	x17, x3, [sp, #56]
   1a550:	aa1c03ec 	mov	x12, x28
   1a554:	a940fbe5 	ldp	x5, x30, [sp, #8]
   1a558:	aa0f03f0 	mov	x16, x15
   1a55c:	a944cbe4 	ldp	x4, x18, [sp, #72]
   1a560:	aa0d03e6 	mov	x6, x13
   1a564:	a9469ffc 	ldp	x28, x7, [sp, #104]
   1a568:	aa1903ee 	mov	x14, x25
   1a56c:	f9401be1 	ldr	x1, [sp, #48]
   1a570:	aa1a03e2 	mov	x2, x26
   1a574:	17fffee7 	b	1a110 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x2d4>
   1a578:	aa1403e0 	mov	x0, x20
   1a57c:	aa1503e1 	mov	x1, x21
   1a580:	528000a2 	mov	w2, #0x5                   	// #5
   1a584:	97ffa95a 	bl	4aec <heap_alloc_miss>
   1a588:	aa0003f7 	mov	x23, x0
   1a58c:	17ffff31 	b	1a250 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x414>
   1a590:	aa1403e0 	mov	x0, x20
   1a594:	aa1503e1 	mov	x1, x21
   1a598:	528000a2 	mov	w2, #0x5                   	// #5
   1a59c:	97ffa954 	bl	4aec <heap_alloc_miss>
   1a5a0:	17ffff42 	b	1a2a8 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x46c>
   1a5a4:	aa1403e0 	mov	x0, x20
   1a5a8:	f9002be2 	str	x2, [sp, #80]
   1a5ac:	aa0103e8 	mov	x8, x1
   1a5b0:	aa1503e1 	mov	x1, x21
   1a5b4:	2a1f03e2 	mov	w2, wzr
   1a5b8:	a9041fe3 	stp	x3, x7, [sp, #64]
   1a5bc:	a901c7f8 	stp	x24, x17, [sp, #24]
   1a5c0:	aa0603ed 	mov	x13, x6
   1a5c4:	aa1203f9 	mov	x25, x18
   1a5c8:	a906f3f7 	stp	x23, x28, [sp, #104]
   1a5cc:	a902a3ee 	stp	x14, x8, [sp, #40]
   1a5d0:	f9000bfe 	str	x30, [sp, #16]
   1a5d4:	f9001ff6 	str	x22, [sp, #56]
   1a5d8:	97ffa782 	bl	43e0 <heap_hand>
   1a5dc:	a9438ff1 	ldp	x17, x3, [sp, #56]
   1a5e0:	aa0c03e5 	mov	x5, x12
   1a5e4:	a94163fe 	ldp	x30, x24, [sp, #16]
   1a5e8:	aa1903f0 	mov	x16, x25
   1a5ec:	a944cbe4 	ldp	x4, x18, [sp, #72]
   1a5f0:	aa0d03e6 	mov	x6, x13
   1a5f4:	a94287ec 	ldp	x12, x1, [sp, #40]
   1a5f8:	f94013ee 	ldr	x14, [sp, #32]
   1a5fc:	a9469ffc 	ldp	x28, x7, [sp, #104]
   1a600:	17fffe89 	b	1a024 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x1e8>
   1a604:	aa1403e0 	mov	x0, x20
   1a608:	aa0103e8 	mov	x8, x1
   1a60c:	aa1503e1 	mov	x1, x21
   1a610:	2a1f03e2 	mov	w2, wzr
   1a614:	a90413e3 	stp	x3, x4, [sp, #64]
   1a618:	aa1003ee 	mov	x14, x16
   1a61c:	f9002bf2 	str	x18, [sp, #80]
   1a620:	aa0503ec 	mov	x12, x5
   1a624:	a90163fe 	stp	x30, x24, [sp, #16]
   1a628:	a90347e8 	stp	x8, x17, [sp, #48]
   1a62c:	97ffa76d 	bl	43e0 <heap_hand>
   1a630:	a9438ff1 	ldp	x17, x3, [sp, #56]
   1a634:	aa0c03e5 	mov	x5, x12
   1a638:	a94163fe 	ldp	x30, x24, [sp, #16]
   1a63c:	aa0e03f0 	mov	x16, x14
   1a640:	a944cbe4 	ldp	x4, x18, [sp, #72]
   1a644:	f9401be1 	ldr	x1, [sp, #48]
   1a648:	f85e83a6 	ldur	x6, [x29, #-24]
   1a64c:	17fffe9d 	b	1a0c0 <WL_FID____BENDVY_JOINED_FLATJOURNAL_LEDGER_V1_EXPERIMENTS_S_INTEGRATE_HELD_ADAPTER_PROTOTYPE_JOURNALLEDGER_HEALTH_LOOP_0+0x284>

