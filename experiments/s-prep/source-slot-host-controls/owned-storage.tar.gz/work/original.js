function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

for (const k of ["IO.print"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  const _rows_0 = ($storage$058rows_empty$());
  return run_clo((_x_0) => {
  return $IO$bind$(($placement_print$("insert1:", ($storage$058rows_place$(_rows_0, {$: "storage.Row", "id": 1, "main": {$: "Some", "value": ($make_motion$(10))}, "aux": {$: "Some", "value": ($make_health$(110))}, "flag": {$: "Some", "value": {$: "Unit"}}, "added": 1, "changed": 2})))), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$bind$(($placement_print$("insert2:", ($storage$058rows_place$(_x_1, {$: "storage.Row", "id": 2, "main": {$: "None"}, "aux": {$: "Some", "value": ($make_health$(120))}, "flag": {$: "None"}, "added": 3, "changed": 4})))), run_clo((_x_3) => {
  return run_clo((_x_4) => {
  return $IO$bind$(($placement_print$("insert4:", ($storage$058rows_place$(_x_3, {$: "storage.Row", "id": 4, "main": {$: "Some", "value": ($make_motion$(40))}, "aux": {$: "Some", "value": ($make_health$(140))}, "flag": {$: "None"}, "added": 5, "changed": 6})))), run_clo((_x_5) => {
  return run_clo((_x_6) => {
  return $IO$bind$(($placement_print$("insert8:", ($storage$058rows_place$(_x_5, {$: "storage.Row", "id": 8, "main": {$: "Some", "value": ($make_motion$(80))}, "aux": {$: "Some", "value": ($make_health$(180))}, "flag": {$: "Some", "value": {$: "Unit"}}, "added": 7, "changed": 8})))), run_clo((_x_7) => {
  return run_clo((_x_8) => {
  return $IO$bind$(($placement_print$("insert65537:", ($storage$058rows_place$(_x_7, {$: "storage.Row", "id": 65537, "main": {$: "Some", "value": ($make_motion$(90))}, "aux": {$: "Some", "value": ($make_health$(190))}, "flag": {$: "Some", "value": {$: "Unit"}}, "added": 9, "changed": 10})))), run_clo((_x_9) => {
  return run_clo((_x_10) => {
  return $IO$bind$(($metadata_print$(_x_9)), run_clo((_x_11) => {
  return run_clo((_x_12) => {
  return $IO$bind$(($lookup_print$("first:", ($storage$058rows_extract$(_x_11, 1)))), run_clo((_x_13) => {
  return run_clo((_x_14) => {
  return $IO$bind$(($lookup_print$("no-main:", ($storage$058rows_extract$(_x_13, 2)))), run_clo((_x_15) => {
  return run_clo((_x_16) => {
  return $IO$bind$(($lookup_print$("middle:", ($storage$058rows_extract$(_x_15, 4)))), run_clo((_x_17) => {
  return run_clo((_x_18) => {
  return $IO$bind$(($lookup_print$("oldlast:", ($storage$058rows_extract$(_x_17, 8)))), run_clo((_x_19) => {
  return run_clo((_x_20) => {
  return $IO$bind$(($lookup_print$("last:", ($storage$058rows_extract$(_x_19, 65537)))), run_clo((_x_21) => {
  return run_clo((_x_22) => {
  return $IO$bind$(($lookup_print$("zero:", ($storage$058rows_extract$(_x_21, 0)))), run_clo((_x_23) => {
  return run_clo((_x_24) => {
  return $IO$bind$(($lookup_print$("hole:", ($storage$058rows_extract$(_x_23, 3)))), run_clo((_x_25) => {
  return run_clo((_x_26) => {
  return $IO$bind$(($lookup_print$("out:", ($storage$058rows_extract$(_x_25, 131073)))), run_clo((_x_27) => {
  return run_clo((_x_28) => {
  return $IO$bind$(($lookup_print$("max:", ($storage$058rows_extract$(_x_27, 4294967295)))), run_clo((_x_29) => {
  const _world_0 = {$: "storage.World", "namespace": 7, "next": 65538, "rows": _x_29, "pending": {$: "Nil"}, "ledger": {$: "None"}, "mode": {$: "Unit"}};
  return run_clo((_x_30) => {
  return $IO$bind$(($main_print$("roundtrip:", ($storage$058with_main$(_world_0, {$: "storage.Handle", "namespace": 7, "id": 4}, run_clo((_x_31) => {
  return $$$$047owned$045index$045core$058motion_roundtrip$(_x_31);
}))))), run_clo((_x_32) => {
  return run_clo((_x_33) => {
  return $IO$bind$(($main_print$("mismatch:", ($storage$058with_main$(_x_32, {$: "storage.Handle", "namespace": 7, "id": 2}, run_clo((_x_34) => {
  return $$$$047owned$045index$045core$058motion_observe$(_x_34);
}))))), run_clo((_x_35) => {
  return run_clo((_x_36) => {
  return $IO$bind$(($main_print$("foreign:", ($storage$058with_main$(_x_35, {$: "storage.Handle", "namespace": 8, "id": 1}, run_clo((_x_37) => {
  return $$$$047owned$045index$045core$058motion_observe$(_x_37);
}))))), run_clo((_x_38) => {
  const _world_1 = ($storage$058mark_main$(_x_38, {$: "storage.Handle", "namespace": 7, "id": 4}, 77));
  const _rows_1 = ($extract_world$(_world_1));
  return run_clo((_x_39) => {
  return $IO$bind$(($lookup_print$("marked:", ($storage$058rows_extract$(_rows_1, 4)))), run_clo((_x_40) => {
  return run_clo((_x_41) => {
  return $IO$bind$(($placement_print$("reject0:", ($storage$058rows_place$(_x_40, {$: "storage.Row", "id": 0, "main": {$: "Some", "value": ($make_motion$(200))}, "aux": {$: "Some", "value": ($make_health$(210))}, "flag": {$: "Some", "value": {$: "Unit"}}, "added": 11, "changed": 12})))), run_clo((_x_42) => {
  return run_clo((_x_43) => {
  return $IO$bind$(($placement_print$("rejectmax:", ($storage$058rows_place$(_x_42, {$: "storage.Row", "id": 4294967295, "main": {$: "Some", "value": ($make_motion$(220))}, "aux": {$: "Some", "value": ($make_health$(230))}, "flag": {$: "None"}, "added": 13, "changed": 14})))), run_clo((_x_44) => {
  return run_clo((_x_45) => {
  return $IO$bind$(($placement_print$("rejectoccupied:", ($storage$058rows_place$(_x_44, {$: "storage.Row", "id": 1, "main": {$: "Some", "value": ($make_motion$(240))}, "aux": {$: "Some", "value": ($make_health$(250))}, "flag": {$: "None"}, "added": 15, "changed": 16})))), run_clo((_x_46) => {
  return run_clo((_x_47) => {
  return $IO$bind$(($lookup_print$("retained-first:", ($storage$058rows_extract$(_x_46, 1)))), run_clo((_x_48) => {
  return run_clo((_x_49) => {
  return $IO$bind$(($lookup_print$("retained-last:", ($storage$058rows_extract$(_x_48, 65537)))), run_clo((_x_50) => {
  return run_clo((_x_51) => {
  return $IO$bind$(($effect_print$("main-add:", ($storage$058rows_replace_main$(_x_50, 2, {$: "Some", "value": ($make_motion$(20))}, 50)))), run_clo((_x_52) => {
  return run_clo((_x_53) => {
  return $IO$bind$(($lookup_print$("main-added:", ($storage$058rows_extract$(_x_52, 2)))), run_clo((_x_54) => {
  return run_clo((_x_55) => {
  return $IO$bind$(($effect_print$("main-change:", ($storage$058rows_replace_main$(_x_54, 2, {$: "Some", "value": ($make_motion$(21))}, 51)))), run_clo((_x_56) => {
  return run_clo((_x_57) => {
  return $IO$bind$(($lookup_print$("main-changed:", ($storage$058rows_extract$(_x_56, 2)))), run_clo((_x_58) => {
  return run_clo((_x_59) => {
  return $IO$bind$(($effect_print$("main-remove:", ($storage$058rows_replace_main$(_x_58, 2, {$: "None"}, 52)))), run_clo((_x_60) => {
  return run_clo((_x_61) => {
  return $IO$bind$(($lookup_print$("main-removed:", ($storage$058rows_extract$(_x_60, 2)))), run_clo((_x_62) => {
  return run_clo((_x_63) => {
  return $IO$bind$(($effect_print$("main-again:", ($storage$058rows_replace_main$(_x_62, 2, {$: "None"}, 53)))), run_clo((_x_64) => {
  return run_clo((_x_65) => {
  return $IO$bind$(($lookup_print$("main-unchanged:", ($storage$058rows_extract$(_x_64, 2)))), run_clo((_x_66) => {
  return run_clo((_x_67) => {
  return $IO$bind$(($effect_print$("main-stale:", ($storage$058rows_replace_main$(_x_66, 131073, {$: "Some", "value": ($make_motion$(99))}, 54)))), run_clo((_x_68) => {
  return run_clo((_x_69) => {
  return $IO$bind$(($remove_print$("removed:", ($storage$058rows_remove$(_x_68, 4)))), run_clo((_x_70) => {
  return run_clo((_x_71) => {
  return $IO$bind$(($lookup_print$("tombstone:", ($storage$058rows_extract$(_x_70, 4)))), run_clo((_x_72) => {
  return run_clo((_x_73) => {
  return $IO$bind$(($remove_print$("repeat-remove:", ($storage$058rows_remove$(_x_72, 4)))), run_clo((_x_74) => {
  return run_clo((_x_75) => {
  return $IO$bind$(($placement_print$("reinstall:", ($storage$058rows_place$(_x_74, {$: "storage.Row", "id": 4, "main": {$: "Some", "value": ($make_motion$(400))}, "aux": {$: "Some", "value": ($make_health$(410))}, "flag": {$: "Some", "value": {$: "Unit"}}, "added": 81, "changed": 82})))), run_clo((_x_76) => {
  return run_clo((_x_77) => {
  return $IO$bind$(($lookup_print$("reinstalled:", ($storage$058rows_extract$(_x_76, 4)))), run_clo((_x_78) => {
  return run_clo((_x_79) => {
  return $IO$bind$(($metadata_print$(_x_78)), run_clo((_x_80) => {
  return run_clo((_x_81) => {
  return $IO$pure$({$: "Unit"}, _x_81);
});
}), _x_79);
});
}), _x_77);
});
}), _x_75);
});
}), _x_73);
});
}), _x_71);
});
}), _x_69);
});
}), _x_67);
});
}), _x_65);
});
}), _x_63);
});
}), _x_61);
});
}), _x_59);
});
}), _x_57);
});
}), _x_55);
});
}), _x_53);
});
}), _x_51);
});
}), _x_49);
});
}), _x_47);
});
}), _x_45);
});
}), _x_43);
});
}), _x_41);
});
}), _x_39);
});
}), _x_36);
});
}), _x_33);
});
}), _x_30);
});
}), _x_28);
});
}), _x_26);
});
}), _x_24);
});
}), _x_22);
});
}), _x_20);
});
}), _x_18);
});
}), _x_16);
});
}), _x_14);
});
}), _x_12);
});
}), _x_10);
});
}), _x_8);
});
}), _x_6);
});
}), _x_4);
});
}), _x_2);
});
}), _x_0);
});
}

function $storage$058rows_empty$() {
  return {$: "storage.Rows", "main": [{$: "None"}], "aux": [{$: "None"}], "metadata": ($storage$058metadata_empty$(0)), "capacity": 1, "depth": 0, "high_water": 0};
}

function $IO$bind$(_m_0, _f_0, _k_0) {
  return run_tail(_m_0, run_clo((_x_0) => {
  return run_tail(_f_0(_x_0), _k_0);
}));
}

function $placement_print$(_prefix_0, _result_0) {
  if (_result_0.$ === "storage.Placed") {
    const _rows_0 = _result_0["rows"];
    return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $IO$print$((_prefix_0 + "placed"), _x_1), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $IO$pure$(_rows_0, _x_3);
});
}), _x_0);
});
  } else {
    const _rows_1 = _result_0["rows"];
    const _row_0 = _result_0["row"];
    return $rejected_observed$(_prefix_0, _rows_1, ($row_observe$(_row_0)));
  }
}

function $storage$058rows_place$(_rows_0, _row_0) {
  const _id_0 = _row_0["id"];
  const _m_0 = _row_0["main"];
  const _a_0 = _row_0["aux"];
  const _f_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  return $storage$058place_checked$(($Bool$and$((0 < _id_0), (_id_0 <= 131072))), _rows_0, {$: "storage.Row", "id": _id_0, "main": _m_0, "aux": _a_0, "flag": _f_0, "added": _added_0, "changed": _changed_0});
}

function $make_motion$(_base_0) {
  const _x_0 = array_new(2, _base_0);
  const _x_1 = ((_base_0 + 1) >>> 0);
  const _x_2 = (_x_0[1 % _x_0.length] = _x_1, _x_0);
  const _x_3 = ((_base_0 + 2) >>> 0);
  const _x_4 = (_x_2[2 % _x_2.length] = _x_3, _x_2);
  const _x_5 = ((_base_0 + 3) >>> 0);
  return {$: "../owned-index-core.Motion", "items": (_x_4[3 % _x_4.length] = _x_5, _x_4), "scalar": _base_0};
}

function $make_health$(_base_0) {
  const _x_0 = array_new(2, _base_0);
  const _x_1 = ((_base_0 + 1) >>> 0);
  const _x_2 = (_x_0[1 % _x_0.length] = _x_1, _x_0);
  const _x_3 = ((_base_0 + 2) >>> 0);
  const _x_4 = (_x_2[2 % _x_2.length] = _x_3, _x_2);
  const _x_5 = ((_base_0 + 3) >>> 0);
  return {$: "../owned-index-core.Health", "items": (_x_4[3 % _x_4.length] = _x_5, _x_4), "scalar": _base_0};
}

function $metadata_print$(_rows_0) {
  const _m_0 = _rows_0["main"];
  const _a_0 = _rows_0["aux"];
  const _f_0 = _rows_0["metadata"];
  const _c_0 = _rows_0["capacity"];
  const _d_0 = _rows_0["depth"];
  const _h_0 = _rows_0["high_water"];
  return run_clo((_x_0) => {
  const _x_1 = ($U32$show$(_h_0));
  const _x_2 = ($Nat$show$(_d_0));
  const _x_3 = (":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($U32$show$(_c_0));
  const _x_6 = (":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  return $IO$bind$((_x_8) => $IO$print$(("shape:" + _x_7), _x_8), run_clo((_x_9) => {
  return run_clo((_x_10) => {
  return $IO$pure$({$: "storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, _x_10);
});
}), _x_0);
});
}

function $lookup_print$(_prefix_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $IO$print$((_prefix_0 + "missing"), _x_1), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $IO$pure$(_rows_0, _x_3);
});
}), _x_0);
});
  } else {
    const _row_0 = _t_0["value"];
    return $lookup_observed$(_prefix_0, _rows_0, ($row_observe$(_row_0)));
  }
}

function $storage$058rows_extract$(_rows_0, _id_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _metadata_0 = _rows_0["metadata"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $storage$058extract_checked$(($Bool$and$((0 < _id_0), ($Bool$and$((_id_0 <= _capacity_0), (_id_0 <= _high_0))))), _id_0, {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0});
}

function $main_print$(_prefix_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _result_1 = _result_0["snd"];
  return run_clo((_x_0) => {
  const _x_1 = ($access_text$(_result_1));
  return $IO$bind$((_x_2) => $IO$print$((_prefix_0 + _x_1), _x_2), run_clo((_x_3) => {
  return run_clo((_x_4) => {
  return $IO$pure$(_world_0, _x_4);
});
}), _x_0);
});
}

function $storage$058with_main$(_world_0, _handle_0, _transform_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  const _foreign_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $storage$058hook_checked$((_namespace_0 === _foreign_0), {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, _id_0, _transform_0);
}

function $$$$047owned$045index$045core$058motion_roundtrip$(_m_0) {
  const _t_0 = _m_0["items"];
  if (_t_0.length !== 1) {
    const _t_1 = _t_0.slice(0, _t_0.length >> 1);
    if (_t_1.length !== 1) {
      const _t_2 = _t_1.slice(0, _t_1.length >> 1);
      if (_t_2.length === 1) {
        const _a_0 = _t_2[0];
        const _t_3 = _t_1.slice(_t_1.length >> 1);
        if (_t_3.length === 1) {
          const _b_0 = _t_3[0];
          const _t_4 = _t_0.slice(_t_0.length >> 1);
          if (_t_4.length !== 1) {
            const _t_5 = _t_4.slice(0, _t_4.length >> 1);
            if (_t_5.length === 1) {
              const _c_0 = _t_5[0];
              const _t_6 = _t_4.slice(_t_4.length >> 1);
              if (_t_6.length === 1) {
                const _d_0 = _t_6[0];
                const _s_0 = _m_0["scalar"];
                return $$$$047owned$045index$045core$058motion_observe$(($$$$047owned$045index$045core$058motion_restore$(($$$$047owned$045index$045core$058motion_set$(($$$$047owned$045index$045core$058motion_set$(($$$$047owned$045index$045core$058motion_set$({$: "../owned-index-core.Motion", "items": array_node(array_node([_a_0], [_b_0]), array_node([_c_0], [_d_0])), "scalar": _s_0}, 19)), 23)), 19)), _a_0, _b_0, _c_0, _d_0, _s_0)));
              } else {
                const _s_1 = _m_0["scalar"];
                return $$$$047owned$045index$045core$058motion_observe$({$: "../owned-index-core.Motion", "items": array_node(array_node([_a_0], [_b_0]), array_node([_c_0], _t_6)), "scalar": _s_1});
              }
            } else {
              const _27_0 = _t_4.slice(_t_4.length >> 1);
              const _s_2 = _m_0["scalar"];
              return $$$$047owned$045index$045core$058motion_observe$({$: "../owned-index-core.Motion", "items": array_node(array_node([_a_0], [_b_0]), array_node(_t_5, _27_0)), "scalar": _s_2});
            }
          } else {
            const _s_3 = _m_0["scalar"];
            return $$$$047owned$045index$045core$058motion_observe$({$: "../owned-index-core.Motion", "items": array_node(array_node([_a_0], [_b_0]), _t_4), "scalar": _s_3});
          }
        } else {
          const _23_0 = _t_0.slice(_t_0.length >> 1);
          const _s_4 = _m_0["scalar"];
          return $$$$047owned$045index$045core$058motion_observe$({$: "../owned-index-core.Motion", "items": array_node(array_node([_a_0], _t_3), _23_0), "scalar": _s_4});
        }
      } else {
        const _25_0 = _t_1.slice(_t_1.length >> 1);
        const _23_1 = _t_0.slice(_t_0.length >> 1);
        const _s_5 = _m_0["scalar"];
        return $$$$047owned$045index$045core$058motion_observe$({$: "../owned-index-core.Motion", "items": array_node(array_node(_t_2, _25_0), _23_1), "scalar": _s_5});
      }
    } else {
      const _23_2 = _t_0.slice(_t_0.length >> 1);
      const _s_6 = _m_0["scalar"];
      return $$$$047owned$045index$045core$058motion_observe$({$: "../owned-index-core.Motion", "items": array_node(_t_1, _23_2), "scalar": _s_6});
    }
  } else {
    const _s_7 = _m_0["scalar"];
    return $$$$047owned$045index$045core$058motion_observe$({$: "../owned-index-core.Motion", "items": _t_0, "scalar": _s_7});
  }
}

function $$$$047owned$045index$045core$058motion_observe$(_m_0) {
  const _a_0 = _m_0["items"];
  const _s_0 = _m_0["scalar"];
  const _x_0 = ($U32$show$(_s_0));
  return $$$$047owned$045index$045core$058motion_o0$(_s_0, (_x_0 + ":"), {$: "Tuple", fst: _a_0, snd: _a_0[0 % _a_0.length]});
}

function $storage$058mark_main$(_world_0, _handle_0, _tick_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _t_0 = _world_0["rows"];
  const _main_0 = _t_0["main"];
  const _aux_0 = _t_0["aux"];
  const _metadata_0 = _t_0["metadata"];
  const _capacity_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _high_0 = _t_0["high_water"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  const _foreign_0 = _handle_0["namespace"];
  const _target_0 = _handle_0["id"];
  return $storage$058prototype_mark_world_checked$(($Bool$and$((_namespace_0 === _foreign_0), ($Bool$and$((0 < _target_0), ($Bool$and$((_target_0 <= _capacity_0), (_target_0 <= _high_0))))))), _namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _target_0, _tick_0);
}

function $extract_world$(_world_0) {
  const _rows_0 = _world_0["rows"];
  return _rows_0;
}

function $effect_print$(_prefix_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _effect_0 = _result_0["snd"];
  return run_clo((_x_0) => {
  const _x_1 = ($effect_text$(_effect_0));
  return $IO$bind$((_x_2) => $IO$print$((_prefix_0 + _x_1), _x_2), run_clo((_x_3) => {
  return run_clo((_x_4) => {
  return $IO$pure$(_rows_0, _x_4);
});
}), _x_0);
});
}

function $storage$058rows_replace_main$(_rows_0, _id_0, _replacement_0, _tick_0) {
  const _m_0 = _rows_0["main"];
  const _a_0 = _rows_0["aux"];
  const _f_0 = _rows_0["metadata"];
  const _c_0 = _rows_0["capacity"];
  const _d_0 = _rows_0["depth"];
  const _h_0 = _rows_0["high_water"];
  return $storage$058replace_main_checked$(($Bool$and$((0 < _id_0), ($Bool$and$((_id_0 <= _c_0), (_id_0 <= _h_0))))), _id_0, _tick_0, {$: "storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, _replacement_0);
}

function $remove_print$(_prefix_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $IO$print$((_prefix_0 + "missing"), _x_1), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $IO$pure$(_rows_0, _x_3);
});
}), _x_0);
});
  } else {
    const _row_0 = _t_0["value"];
    return $removed_observed$(_prefix_0, _rows_0, ($row_observe$(_row_0)));
  }
}

function $storage$058rows_remove$(_rows_0, _id_0) {
  return $storage$058remove_done$(_id_0, ($storage$058rows_extract$(_rows_0, _id_0)));
}

function $IO$pure$(_x_0, _k_0) {
  return run_tail(_k_0, _x_0);
}

function $storage$058metadata_empty$(_depth_0) {
  const _x_0 = {$: "None"};
  return {$: "storage.MetadataColumns", "live": array_new(_depth_0, false), "flags": array_new(_depth_0, _x_0), "added": array_new(_depth_0, 0), "changed": array_new(_depth_0, 0)};
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $rejected_observed$(_prefix_0, _rows_0, _result_0) {
  const _text_0 = _result_0["snd"];
  return run_clo((_x_0) => {
  const _x_1 = ("rejected:" + _text_0);
  return $IO$bind$((_x_2) => $IO$print$((_prefix_0 + _x_1), _x_2), run_clo((_x_3) => {
  return run_clo((_x_4) => {
  return $IO$pure$(_rows_0, _x_4);
});
}), _x_0);
});
}

function $row_observe$(_row_0) {
  const _id_0 = _row_0["id"];
  const _m_0 = _row_0["main"];
  const _a_0 = _row_0["aux"];
  const _f_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  return $row_observed$(_id_0, _f_0, _added_0, _changed_0, {$: "Tuple", "fst": ($motion_observe$(_m_0)), "snd": ($health_observe$(_a_0))});
}

function $storage$058place_checked$(_valid_0, _rows_0, _row_0) {
  if (!_valid_0) {
    return {$: "storage.Rejected", "rows": _rows_0, "row": _row_0};
  } else {
    const _id_0 = _row_0["id"];
    const _m_0 = _row_0["main"];
    const _a_0 = _row_0["aux"];
    const _f_0 = _row_0["flag"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    return $storage$058place_grown$(run_loop($storage$058grow$(17, _id_0, _rows_0)), {$: "storage.Row", "id": _id_0, "main": _m_0, "aux": _a_0, "flag": _f_0, "added": _added_0, "changed": _changed_0});
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $lookup_observed$(_prefix_0, _rows_0, _result_0) {
  const _row_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $IO$print$((_prefix_0 + _text_0), _x_1), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $IO$pure$(($storage$058rows_restore$(_rows_0, _row_0)), _x_3);
});
}), _x_0);
});
}

function $storage$058extract_checked$(_valid_0, _id_0, _rows_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _rows_0, "snd": {$: "None"}};
  } else {
    const _main_0 = _rows_0["main"];
    const _aux_0 = _rows_0["aux"];
    const _metadata_0 = _rows_0["metadata"];
    const _capacity_0 = _rows_0["capacity"];
    const _depth_0 = _rows_0["depth"];
    const _high_0 = _rows_0["high_water"];
    return $storage$058extract_meta$(_id_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, ($storage$058metadata_get$(_metadata_0, ((_id_0 - 1) >>> 0))));
  }
}

function $access_text$(_result_0) {
  if (_result_0.$ === "types.Missing") {
    return "missing";
  } else if (_result_0.$ === "types.Mismatch") {
    return "mismatch";
  } else {
    const _text_0 = _result_0["value"];
    return _text_0;
  }
}

function $storage$058hook_checked$(_valid_0, _world_0, _target_0, _transform_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "types.Missing"}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _t_0 = _world_0["rows"];
    const _main_0 = _t_0["main"];
    const _aux_0 = _t_0["aux"];
    const _metadata_0 = _t_0["metadata"];
    const _capacity_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _high_0 = _t_0["high_water"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return $storage$058fuse_bounds$(($Bool$and$((0 < _target_0), ($Bool$and$((_target_0 <= _capacity_0), (_target_0 <= _high_0))))), {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, _target_0, _transform_0);
  }
}

function $$$$047owned$045index$045core$058motion_restore$(_m_0, _a_0, _b_0, _c_0, _d_0, _s_0) {
  const _items_0 = _m_0["items"];
  const _x_0 = (_items_0[0 % _items_0.length] = _a_0, _items_0);
  const _x_1 = (_x_0[1 % _x_0.length] = _b_0, _x_0);
  const _x_2 = (_x_1[2 % _x_1.length] = _c_0, _x_1);
  return {$: "../owned-index-core.Motion", "items": (_x_2[3 % _x_2.length] = _d_0, _x_2), "scalar": _s_0};
}

function $$$$047owned$045index$045core$058motion_set$(_m_0, _v_0) {
  const _a_0 = _m_0["items"];
  const _x_0 = (_a_0[0 % _a_0.length] = _v_0, _a_0);
  const _x_1 = (_x_0[1 % _x_0.length] = _v_0, _x_0);
  const _x_2 = (_x_1[2 % _x_1.length] = _v_0, _x_1);
  return {$: "../owned-index-core.Motion", "items": (_x_2[3 % _x_2.length] = _v_0, _x_2), "scalar": _v_0};
}

function $$$$047owned$045index$045core$058motion_o0$(_s_0, _text_0, _r_0) {
  const _a_0 = _r_0["fst"];
  const _x_0 = _r_0["snd"];
  const _x_1 = ($U32$show$(_x_0));
  const _x_2 = (_x_1 + ",");
  return $$$$047owned$045index$045core$058motion_o1$(_s_0, (_text_0 + _x_2), {$: "Tuple", fst: _a_0, snd: _a_0[1 % _a_0.length]});
}

function $storage$058prototype_mark_world_checked$(_valid_0, _namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _id_0, _tick_0) {
  if (!_valid_0) {
    return {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0};
  } else {
    return $storage$058prototype_mark_open_columns$(_namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, ((_id_0 - 1) >>> 0), _tick_0);
  }
}

function $effect_text$(_effect_0) {
  if (_effect_0.$ === "storage.MissingMainTarget") {
    return "missing";
  } else if (_effect_0.$ === "storage.AddedMain") {
    return "added";
  } else if (_effect_0.$ === "storage.ChangedMain") {
    return "changed";
  } else if (_effect_0.$ === "storage.RemovedMain") {
    return "removed";
  } else {
    return "unchanged";
  }
}

function $storage$058replace_main_checked$(_valid_0, _id_0, _tick_0, _rows_0, _replacement_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _rows_0, "snd": {$: "storage.MissingMainTarget"}};
  } else {
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    return $storage$058replace_main_meta_done$(_id_0, _tick_0, _m_0, _a_0, _c_0, _d_0, _h_0, _replacement_0, ($storage$058metadata_get$(_f_0, ((_id_0 - 1) >>> 0))));
  }
}

function $removed_observed$(_prefix_0, _rows_0, _result_0) {
  const _text_0 = _result_0["snd"];
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $IO$print$((_prefix_0 + _text_0), _x_1), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $IO$pure$(_rows_0, _x_3);
});
}), _x_0);
});
}

function $storage$058remove_done$(_id_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _m_0 = _t_0["main"];
  const _a_0 = _t_0["aux"];
  const _f_0 = _t_0["metadata"];
  const _c_0 = _t_0["capacity"];
  const _d_0 = _t_0["depth"];
  const _h_0 = _t_0["high_water"];
  const _t_1 = _result_0["snd"];
  if (_t_1.$ === "None") {
    return {$: "Tuple", "fst": {$: "storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, "snd": {$: "None"}};
  } else {
    const _row_0 = _t_1["value"];
    return {$: "Tuple", "fst": {$: "storage.Rows", "main": _m_0, "aux": _a_0, "metadata": ($storage$058metadata_set$(_f_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": false, "flag": {$: "None"}, "added": 0, "changed": 0})), "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, "snd": {$: "Some", "value": _row_0}};
  }
}

function $row_observed$(_id_0, _flag_0, _added_0, _changed_0, _both_0) {
  const _t_0 = _both_0["fst"];
  const _m_0 = _t_0["fst"];
  const _mt_0 = _t_0["snd"];
  const _t_1 = _both_0["snd"];
  const _a_0 = _t_1["fst"];
  const _at_0 = _t_1["snd"];
  const _x_0 = ($U32$show$(_changed_0));
  const _x_1 = ($U32$show$(_added_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($flag_text$(_flag_0));
  const _x_5 = ("|" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ("|" + _x_6);
  const _x_8 = (_at_0 + _x_7);
  const _x_9 = ("|" + _x_8);
  return {$: "Tuple", "fst": {$: "storage.Row", "id": _id_0, "main": _m_0, "aux": _a_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}, "snd": (_mt_0 + _x_9)};
}

function $motion_observe$(_m_0) {
  if (_m_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": "none"};
  } else {
    const _m_1 = _m_0["value"];
    return $motion_some$(($$$$047owned$045index$045core$058motion_observe$(_m_1)));
  }
}

function $health_observe$(_a_0) {
  if (_a_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": "none"};
  } else {
    const _a_1 = _a_0["value"];
    return $health_some$(($$$$047owned$045index$045core$058health_observe$(_a_1)));
  }
}

function $storage$058place_grown$(_rows_0, _row_0) {
  const _m_0 = _rows_0["main"];
  const _a_0 = _rows_0["aux"];
  const _f_0 = _rows_0["metadata"];
  const _c_0 = _rows_0["capacity"];
  const _d_0 = _rows_0["depth"];
  const _h_0 = _rows_0["high_water"];
  const _id_0 = _row_0["id"];
  const _main_0 = _row_0["main"];
  const _aux_0 = _row_0["aux"];
  const _flag_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  return $storage$058place_capacity$(($Bool$and$((0 < _id_0), (_id_0 <= _c_0))), {$: "storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, {$: "storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0});
}

function $storage$058grow$(_fuel_0, _id_0, _rows_0) {
  if (_fuel_0 === 0) {
    return _rows_0;
  } else {
    const _n_0 = (_fuel_0 - 1);
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    return $storage$058grow_decide$(($Bool$and$((_c_0 < _id_0), (_c_0 <= 65536))), {$: "storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, run_clo((_x_0) => {
  return $storage$058grow$(_n_0, _id_0, _x_0);
}));
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $storage$058rows_restore$(_rows_0, _row_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _metadata_0 = _rows_0["metadata"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  const _id_0 = _row_0["id"];
  const _m_0 = _row_0["main"];
  const _a_0 = _row_0["aux"];
  const _f_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = ((_id_0 - 1) >>> 0);
  return {$: "storage.Rows", "main": (_main_0[_x_0 % _main_0.length] = _m_0, _main_0), "aux": (_aux_0[_x_1 % _aux_0.length] = _a_0, _aux_0), "metadata": ($storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": true, "flag": _f_0, "added": _added_0, "changed": _changed_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0};
}

function $storage$058extract_meta$(_id_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _t_1 = _t_0["live"];
  if (!_t_1) {
    return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "None"}};
  } else {
    const _flag_1 = _t_0["flag"];
    const _added_1 = _t_0["added"];
    const _changed_1 = _t_0["changed"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $storage$058extract_main$(_id_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, {$: "storage.Metadata", "live": true, "flag": _flag_1, "added": _added_1, "changed": _changed_1}, array_rmw(_main_0, _x_0, () => _x_1));
  }
}

function $storage$058metadata_get$(_columns_0, _index_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  return $storage$058metadata_get_live$(_flags_0, _added_0, _changed_0, _index_0, {$: "Tuple", fst: _live_0, snd: _live_0[_index_0 % _live_0.length]});
}

function $storage$058fuse_bounds$(_valid_0, _world_0, _target_0, _transform_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "types.Missing"}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _t_0 = _world_0["rows"];
    const _main_0 = _t_0["main"];
    const _aux_0 = _t_0["aux"];
    const _metadata_0 = _t_0["metadata"];
    const _capacity_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _high_0 = _t_0["high_water"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return $storage$058prototype_fuse_columns$(_namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, ((_target_0 - 1) >>> 0), _transform_0);
  }
}

function $$$$047owned$045index$045core$058motion_o1$(_s_0, _text_0, _r_0) {
  const _a_0 = _r_0["fst"];
  const _x_0 = _r_0["snd"];
  const _x_1 = ($U32$show$(_x_0));
  const _x_2 = (_x_1 + ",");
  return $$$$047owned$045index$045core$058motion_o2$(_s_0, (_text_0 + _x_2), {$: "Tuple", fst: _a_0, snd: _a_0[2 % _a_0.length]});
}

function $storage$058prototype_mark_open_columns$(_namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _tick_0) {
  const _live_0 = _metadata_0["live"];
  const _flags_0 = _metadata_0["flags"];
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  return $storage$058prototype_mark_open_live$(_namespace_0, _next_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _tick_0, {$: "Tuple", fst: _live_0, snd: _live_0[_index_0 % _live_0.length]});
}

function $storage$058replace_main_meta_done$(_id_0, _tick_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, _replacement_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _meta_0 = _result_0["snd"];
  return $storage$058replace_main_meta$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _replacement_0, _meta_0);
}

function $storage$058metadata_set$(_columns_0, _index_0, _meta_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  const _l_0 = _meta_0["live"];
  const _f_0 = _meta_0["flag"];
  const _a_0 = _meta_0["added"];
  const _c_0 = _meta_0["changed"];
  return {$: "storage.MetadataColumns", "live": (_live_0[_index_0 % _live_0.length] = _l_0, _live_0), "flags": (_flags_0[_index_0 % _flags_0.length] = _f_0, _flags_0), "added": (_added_0[_index_0 % _added_0.length] = _a_0, _added_0), "changed": (_changed_0[_index_0 % _changed_0.length] = _c_0, _changed_0)};
}

function $flag_text$(_flag_0) {
  if (_flag_0.$ === "None") {
    return "absent";
  } else {
    return "present";
  }
}

function $motion_some$(_r_0) {
  const _m_0 = _r_0["fst"];
  const _text_0 = _r_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": _m_0}, "snd": _text_0};
}

function $health_some$(_r_0) {
  const _a_0 = _r_0["fst"];
  const _text_0 = _r_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": _a_0}, "snd": _text_0};
}

function $$$$047owned$045index$045core$058health_observe$(_m_0) {
  const _a_0 = _m_0["items"];
  const _s_0 = _m_0["scalar"];
  const _x_0 = ($U32$show$(_s_0));
  return $$$$047owned$045index$045core$058health_o0$(_s_0, (_x_0 + ":"), {$: "Tuple", fst: _a_0, snd: _a_0[0 % _a_0.length]});
}

function $storage$058place_capacity$(_valid_0, _rows_0, _row_0) {
  if (!_valid_0) {
    return {$: "storage.Rejected", "rows": _rows_0, "row": _row_0};
  } else {
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    const _id_0 = _row_0["id"];
    const _main_0 = _row_0["main"];
    const _aux_0 = _row_0["aux"];
    const _flag_0 = _row_0["flag"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    return $storage$058place_meta$(_m_0, _a_0, _c_0, _d_0, _h_0, {$: "storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}, ($storage$058metadata_live$(_f_0, ((_id_0 - 1) >>> 0))));
  }
}

function $storage$058grow_decide$(_needed_0, _rows_0, _recurse_0) {
  if (!_needed_0) {
    return _rows_0;
  } else {
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    return run_tail(_recurse_0, {$: "storage.Rows", "main": array_node(_m_0, ($storage$058slots_empty$(_d_0))), "aux": array_node(_a_0, ($storage$058slots_empty$(_d_0))), "metadata": ($storage$058metadata_grow$(_f_0, _d_0)), "capacity": ((_c_0 + _c_0) >>> 0), "depth": nat_chk(_d_0 + 1), "high_water": _h_0});
  }
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $storage$058extract_main$(_id_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _mv_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "None"};
  return $storage$058extract_aux$(_id_0, _main_0, _mv_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, array_rmw(_aux_0, _x_0, () => _x_1));
}

function $storage$058metadata_get_live$(_flags_0, _added_0, _changed_0, _index_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _l_0 = _result_0["snd"];
  return $storage$058metadata_get_flags$(_live_0, _added_0, _changed_0, _index_0, _l_0, {$: "Tuple", fst: _flags_0, snd: _flags_0[_index_0 % _flags_0.length]});
}

function $storage$058prototype_fuse_columns$(_namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0) {
  const _live_0 = _metadata_0["live"];
  const _flags_0 = _metadata_0["flags"];
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  return $storage$058prototype_fuse_live_result$(_namespace_0, _next_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, {$: "Tuple", fst: _live_0, snd: _live_0[_index_0 % _live_0.length]});
}

function $$$$047owned$045index$045core$058motion_o2$(_s_0, _text_0, _r_0) {
  const _a_0 = _r_0["fst"];
  const _x_0 = _r_0["snd"];
  const _x_1 = ($U32$show$(_x_0));
  const _x_2 = (_x_1 + ",");
  return $$$$047owned$045index$045core$058motion_o3$(_s_0, (_text_0 + _x_2), {$: "Tuple", fst: _a_0, snd: _a_0[3 % _a_0.length]});
}

function $storage$058prototype_mark_open_live$(_namespace_0, _next_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _tick_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": {$: "storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0};
  } else {
    return {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": {$: "storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": (_changed_0[_index_0 % _changed_0.length] = _tick_0, _changed_0)}, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0};
  }
}

function $storage$058replace_main_meta$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _replacement_0, _meta_0) {
  const _t_0 = _meta_0["live"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "storage.MissingMainTarget"}};
  } else {
    const __3 = _meta_0["flag"];
    const __4 = _meta_0["added"];
    const __5 = _meta_0["changed"];
    return $storage$058replace_main_slot$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, __3, __4, __5, _replacement_0);
  }
}

function $$$$047owned$045index$045core$058health_o0$(_s_0, _text_0, _r_0) {
  const _a_0 = _r_0["fst"];
  const _x_0 = _r_0["snd"];
  const _x_1 = ($U32$show$(_x_0));
  const _x_2 = (_x_1 + ",");
  return $$$$047owned$045index$045core$058health_o1$(_s_0, (_text_0 + _x_2), {$: "Tuple", fst: _a_0, snd: _a_0[1 % _a_0.length]});
}

function $storage$058place_meta$(_main_0, _aux_0, _capacity_0, _depth_0, _high_0, _row_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _meta_0 = _result_0["snd"];
  return $storage$058place_metadata$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _row_0, _meta_0);
}

function $storage$058metadata_live$(_columns_0, _index_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  return $storage$058metadata_live_done$(_flags_0, _added_0, _changed_0, {$: "Tuple", fst: _live_0, snd: _live_0[_index_0 % _live_0.length]});
}

function $storage$058slots_empty$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _d_0 = (_depth_0 - 1);
    return array_node(($storage$058slots_empty$(_d_0)), ($storage$058slots_empty$(_d_0)));
  }
}

function $storage$058metadata_grow$(_columns_0, _depth_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  const _x_0 = {$: "None"};
  return {$: "storage.MetadataColumns", "live": array_node(_live_0, array_new(_depth_0, false)), "flags": array_node(_flags_0, array_new(_depth_0, _x_0)), "added": array_node(_added_0, array_new(_depth_0, 0)), "changed": array_node(_changed_0, array_new(_depth_0, 0))};
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $storage$058extract_aux$(_id_0, _main_0, _value_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _av_0 = _result_0["snd"];
  return $storage$058extract_row$(_id_0, _main_0, _value_0, _aux_0, _av_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0);
}

function $storage$058metadata_get_flags$(_live_0, _added_0, _changed_0, _index_0, _l_0, _result_0) {
  const _flags_0 = _result_0["fst"];
  const _f_0 = _result_0["snd"];
  return $storage$058metadata_get_added$(_live_0, _flags_0, _changed_0, _index_0, _l_0, _f_0, {$: "Tuple", fst: _added_0, snd: _added_0[_index_0 % _added_0.length]});
}

function $storage$058prototype_fuse_live_result$(_namespace_0, _next_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $storage$058fuse_live$(_namespace_0, _next_0, _aux_0, {$: "storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0, _value_0);
}

function $$$$047owned$045index$045core$058motion_o3$(_s_0, _text_0, _r_0) {
  const _a_0 = _r_0["fst"];
  const _x_0 = _r_0["snd"];
  const _x_1 = ($U32$show$(_x_0));
  return {$: "Tuple", "fst": {$: "../owned-index-core.Motion", "items": _a_0, "scalar": _s_0}, "snd": (_text_0 + _x_1)};
}

function $storage$058replace_main_slot$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _replacement_0) {
  if (_replacement_0.$ === "None") {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $storage$058replace_main_done$(_id_0, _tick_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, false, array_rmw(_main_0, _x_0, () => _x_1));
  } else {
    const _value_0 = _replacement_0["value"];
    const _x_2 = ((_id_0 - 1) >>> 0);
    const _x_3 = {$: "Some", "value": _value_0};
    return $storage$058replace_main_done$(_id_0, _tick_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, true, array_rmw(_main_0, _x_2, () => _x_3));
  }
}

function $$$$047owned$045index$045core$058health_o1$(_s_0, _text_0, _r_0) {
  const _a_0 = _r_0["fst"];
  const _x_0 = _r_0["snd"];
  const _x_1 = ($U32$show$(_x_0));
  const _x_2 = (_x_1 + ",");
  return $$$$047owned$045index$045core$058health_o2$(_s_0, (_text_0 + _x_2), {$: "Tuple", fst: _a_0, snd: _a_0[2 % _a_0.length]});
}

function $storage$058place_metadata$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _row_0, _meta_0) {
  return $storage$058place_status$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, _row_0);
}

function $storage$058metadata_live_done$(_flags_0, _added_0, _changed_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "snd": _value_0};
}

function $storage$058extract_row$(_id_0, _main_0, _value_0, _aux_0, _av_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0) {
  const _flag_0 = _meta_0["flag"];
  const _added_0 = _meta_0["added"];
  const _changed_0 = _meta_0["changed"];
  return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "Some", "value": {$: "storage.Row", "id": _id_0, "main": _value_0, "aux": _av_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}}};
}

function $storage$058metadata_get_added$(_live_0, _flags_0, _changed_0, _index_0, _l_0, _f_0, _result_0) {
  const _added_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return $storage$058metadata_get_changed$(_live_0, _flags_0, _added_0, _l_0, _f_0, _a_0, {$: "Tuple", fst: _changed_0, snd: _changed_0[_index_0 % _changed_0.length]});
}

function $storage$058fuse_live$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0, _meta_0) {
  if (!_meta_0) {
    return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "types.Missing"}};
  } else {
    const _x_0 = {$: "None"};
    return $storage$058fuse_taken$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, array_rmw(_main_0, _index_0, () => _x_0));
  }
}

function $storage$058replace_main_done$(_id_0, _tick_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _insert_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return $storage$058replace_main_effect$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _insert_0, _old_0);
}

function $$$$047owned$045index$045core$058health_o2$(_s_0, _text_0, _r_0) {
  const _a_0 = _r_0["fst"];
  const _x_0 = _r_0["snd"];
  const _x_1 = ($U32$show$(_x_0));
  const _x_2 = (_x_1 + ",");
  return $$$$047owned$045index$045core$058health_o3$(_s_0, (_text_0 + _x_2), {$: "Tuple", fst: _a_0, snd: _a_0[3 % _a_0.length]});
}

function $storage$058place_status$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _live_0, _row_0) {
  if (_live_0) {
    return {$: "storage.Rejected", "rows": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "row": _row_0};
  } else {
    const _id_0 = _row_0["id"];
    const _m_0 = _row_0["main"];
    const _a_0 = _row_0["aux"];
    const _f_0 = _row_0["flag"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = ((_id_0 - 1) >>> 0);
    return {$: "storage.Placed", "rows": {$: "storage.Rows", "main": (_main_0[_x_0 % _main_0.length] = _m_0, _main_0), "aux": (_aux_0[_x_1 % _aux_0.length] = _a_0, _aux_0), "metadata": ($storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": true, "flag": _f_0, "added": _added_0, "changed": _changed_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": ($U32$max$(_high_0, _id_0))}};
  }
}

function $storage$058metadata_get_changed$(_live_0, _flags_0, _added_0, _l_0, _f_0, _a_0, _result_0) {
  const _changed_0 = _result_0["fst"];
  const _c_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "snd": {$: "storage.Metadata", "live": _l_0, "flag": _f_0, "added": _a_0, "changed": _c_0}};
}

function $storage$058fuse_taken$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "types.Mismatch"}};
  } else {
    const _value_0 = _t_0["value"];
    return $storage$058fuse_return$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0(_value_0));
  }
}

function $storage$058replace_main_effect$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _insert_0, _old_0) {
  if (!_insert_0) {
    if (_old_0.$ === "None") {
      return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "storage.NoMainChange"}};
    } else {
      return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": ($storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": true, "flag": _flag_0, "added": 0, "changed": 0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "storage.RemovedMain"}};
    }
  } else {
    if (_old_0.$ === "None") {
      return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": ($storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": true, "flag": _flag_0, "added": _tick_0, "changed": _tick_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "storage.AddedMain"}};
    } else {
      return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": ($storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": true, "flag": _flag_0, "added": _added_0, "changed": _tick_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "storage.ChangedMain"}};
    }
  }
}

function $$$$047owned$045index$045core$058health_o3$(_s_0, _text_0, _r_0) {
  const _a_0 = _r_0["fst"];
  const _x_0 = _r_0["snd"];
  const _x_1 = ($U32$show$(_x_0));
  return {$: "Tuple", "fst": {$: "../owned-index-core.Health", "items": _a_0, "scalar": _s_0}, "snd": (_text_0 + _x_1)};
}

function $U32$max$(_a_0, _b_0) {
  return $Bool$pick$((_a_0 < _b_0), _b_0, _a_0);
}

function $storage$058fuse_return$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _result_0) {
  const _value_0 = _result_0["fst"];
  const _observation_0 = _result_0["snd"];
  const _x_0 = {$: "Some", "value": _value_0};
  return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "storage.Rows", "main": (_main_0[_index_0 % _main_0.length] = _x_0, _main_0), "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "types.Found", "value": _observation_0}};
}

function $Bool$pick$(_c_0, _a_0, _b_0) {
  if (!_c_0) {
    return _b_0;
  } else {
    return _a_0;
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);