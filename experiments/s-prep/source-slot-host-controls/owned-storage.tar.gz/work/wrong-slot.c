
// Imports
// =======

// The Objective-C headers take #include, not #import: a build
// (-o) reads an #import as the framework of an effect.

#pragma clang fp contract(off)

#if defined(__CUDACC_RTC__)
#define BEND_RTC 1
#endif

#ifdef __METAL_VERSION__
#include <metal_stdlib>
using namespace metal;
#elif !defined(BEND_RTC)
#ifdef __APPLE__
#define _DARWIN_UNLIMITED_SELECT
#else
#define _GNU_SOURCE
#endif
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <unistd.h>
#include <signal.h>
#include <sys/mman.h>
#include <time.h>
#include <poll.h>
#include <sys/select.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif
#ifdef __OBJC__
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#elif BEND_CUDA
#include <cuda.h>
#include <nvrtc.h>
#include <fcntl.h>
#include <sys/stat.h>
#endif
#endif

// Dialect
// =======

// Metal needs coherent(device) (MSL 3.2), or M1-class parts lose stores
// across the threadgroups of a dispatch. CUDA keeps plain data cacheable
// in L1: lanes hand off through a32 and FENCE. Only clang 19+ has both
// preserve_none and preserve_most, and compiles preserve_most soundly; at
// -O0 its register allocator cannot place a preserve_none segment, so an
// unoptimized build takes neither. A segment is a case of the device's
// switch; on the host, a preserve_none function (WL_SIG) entered by
// musttail, its words fresh at WL_OPEN.

#ifdef __METAL_VERSION__
#if __METAL_VERSION__ >= 320
#define DEV     coherent(device) device
#else
#define DEV     device
#endif
#define THR     thread
#define TG      threadgroup
#define INLINE  inline
#define OUTLINE static
#define CONSTV  constant
#define DEVICE  1
#define CLZ(x)  clz(x)
#define FENCE() atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst)
#define BAR()   threadgroup_barrier(mem_flags::mem_threadgroup)
#define BARD()  threadgroup_barrier(mem_flags::mem_device \
  | mem_flags::mem_threadgroup)
#else
#define DEV
#define THR
#define TG
#define INLINE  static inline
#define CONSTV  static const
#ifdef BEND_RTC
#define OUTLINE static __attribute__((noinline))
#define DEVICE  1
#define CLZ(x)  (u32)__clz((int)(x))
#define FENCE() __threadfence()
#define BAR()   __syncthreads()
#define BARD()  \
  { __threadfence(); __syncthreads(); }
#else
#if __has_attribute(preserve_none) && __has_attribute(preserve_most) \
  && defined(__OPTIMIZE__)
#define PRESERVE(A) __attribute__((A))
#else
#define PRESERVE(A)
#endif
#define OUTLINE static __attribute__((noinline, cold)) PRESERVE(preserve_most)
#define DEVICE  0
#define CLZ(x)  (u32)__builtin_clz(x)
#define FENCE() ((void)0)
#endif
#endif
#define FAR static __attribute__((noinline))

#if DEVICE
#define LOCK(l)
#define UNLOCK(l)
#define WL_CASE(F) case F:
#define WL_OPEN    {
#define WL_JMP(F)  { fid = (F); break; }
#define WL_DYN     WL_JMP
#else
#define LOCK(l)    while (__atomic_exchange_n(&(l), 1, __ATOMIC_ACQUIRE)) {}
#define UNLOCK(l)  __atomic_store_n(&(l), 0, __ATOMIC_RELEASE)
#define WL_FN      static PRESERVE(preserve_none) __attribute__((noinline)) Term
#define WL_CASE(F) WL_FN WL_##F(WL_SIG)
#define WL_OPEN    { WL_BANK u32 rn;
#define WL_JMP(F)  __attribute__((musttail)) return WL_##F(WL_ALL)
#define WL_DYN(F)  __attribute__((musttail)) return wl_tab[F](WL_ALL)
#endif
#define WL_SPIN     for (;;) { if (err_spun(e.mem, &wpoll)) { return 0; }
#define WL_SPUN     } break;
#define WL_AGAIN(F) continue

#define LANE_STEP (DEVICE ? (long)CUBE : 1)
#define STK(I)    sp[(long)(I) * LANE_STEP]

#define WL_RETN(N)  { rn = (N); sp -= LANE_STEP; WL_DYN((u32)STK(0)); }
#define WL_CONT     STK(-3)
#define WL_IDX      STK(-2)
#define WL_POPN(N)  sp -= N * LANE_STEP
#define WL_PUSHN(N) sp += N * LANE_STEP
#define WL_FRAME(T) \
  u64 wtl = task_tail(T); \
  u64 wtw = e.mem[wtl + 1]; \
  STK(0) = e.mem[wtl]; \
  STK(1) = (wtw >> 32) & 0xFFFF; \
  STK(2) = FID_EXIT; \
  sp += 3 * LANE_STEP;
#define WL_ARGS(A, N) \
  for (u32 wi = 0; wi + 1 < N; wi += 1) { \
    STK(wi) = e.mem[A + wi]; \
  } \
  sp += (N - 1) * LANE_STEP;
#define WL_ROOM(N) \
  if (DEVICE && sp + (N) * CUBE >= e.mem + STAT_OFF + CUBE) { \
    err_post(e.mem, ERR_DEEP); \
    return 0; \
  }

// Types
// =====

#ifdef __METAL_VERSION__
typedef ulong u64;
typedef uint  u32;
typedef uchar u8;
#elif defined(BEND_RTC)
typedef unsigned long long u64;
typedef unsigned int       u32;
typedef unsigned char      u8;
#else
typedef uint64_t u64;
typedef uint32_t u32;
typedef uint8_t  u8;
#endif
typedef float f32;

typedef u64 Term;

typedef struct {
  DEV u64* mem;
  DEV u64* alc;
} Env;

typedef struct {
  u64 off;
  u32 rd;
  u32 wr;
  u32 top;
} Bank;

#if DEVICE
typedef u32 u32a;
#else
typedef u32 __attribute__((may_alias)) u32a;
#endif

// Constants
// =========

#define TAG_PAK 1ull
#define TAG_CTR 2ull
#define TAG_CLO 3ull
#define TAG_BUF 4ull
#define TAG_TSK 5ull
#define TAG_ARR 6ull

#define TERM_HOLE (~0ull)
#define LOC_MASK  ((1ull << 40) - 1)
#define RFC_BIT   (1ull << 63)
#define RFC_CNT   ((1u << 24) - 1)
#define NAT_IMM   ((1ull << 48) - 1)

#define ERR_RING 1
#define ERR_TAGS 2
#define ERR_HEAP 3
#define ERR_FIDS 4
#define ERR_NATS 5
#define ERR_RFCS 6
#define ERR_DEEP 7
#define ERR_ARRS 8

#define LINE      16
#define PAGE_BITS 7
#define PAGE_LEN  (1ull << PAGE_BITS)
#define CUBE_T    128
#define CUBE      ((u64)CUBE_T * CUBE_T)
#define CUBE_G    (1u << CUBE_LOG)
#define LANES     ((u64)CUBE_T << CUBE_LOG)
#define RING_LOG  (17 - CUBE_LOG)
#define RING_LEN  (1ull << RING_LOG)
#define STAK_LEN  (1ull << 11)
#define NCLS      8
#define NCLS_ALL  32
#define IO_HELP   64

#define TG_HOLD   2304
#define CHUNK     256
#define CAP_WORDS 32768
#define QUANTUM   (DEVICE ? PAGE_LEN \
  : KEEP_WORDS < 32 * PAGE_LEN ? KEEP_WORDS : 32 * PAGE_LEN)
#if DEVICE
#define KEEP_WORDS CHUNK
#endif
#define RING_WORDS ((1ull << 10) + 2)

#define H_BUMP       0
#define H_CAP        1
#define H_CURSOR     LINE
#define H_ROOT_DONE  (2 * LINE)
#define H_ERROR_CODE (3 * LINE)
#define H_ROOT_WORD  (4 * LINE)
#define H_BANK       (H_ROOT_WORD + WL_RESW)

#define PAGE_UP(n) (((n) + PAGE_LEN - 1) & ~(PAGE_LEN - 1))
#define ALC_OFF  PAGE_UP(H_BANK + 3 * NCLS_ALL)
#define RING_OFF (ALC_OFF + CUBE * 2 * NCLS_ALL)
#define STAK_OFF (RING_OFF + CUBE * RING_WORDS)
#define STAT_OFF (STAK_OFF + CUBE * STAK_LEN)
#define HEAP_OFF (STAT_OFF + PAGE_UP(STAT_LEN))

// Globals
// =======

// The bag is 2^CUBE_LOG groups of CUBE_T lanes (a -D constant on the
// device). The device program compiles from the binary's own text.

#if !DEVICE

static u64*    CORPUS;
static u64    ALC[CUBE_T + 1][3 * NCLS_ALL] __attribute__((aligned(128)));
static u32    KEEP_WORDS;
static u32    CUBE_LOG = 7;
static u32    bank_lock;

static u32             pool_size;
static u32             pool_row;
static u32             pool_done;
static pthread_mutex_t pool_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  pool_wake = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  pool_join = PTHREAD_COND_INITIALIZER;

#if BEND_METAL || BEND_CUDA
#pragma clang diagnostic ignored "-Wc23-extensions"
static const char BEND_SRC[] = {
#embed __FILE__
, 0 };
#endif

#ifdef __OBJC__
static id<MTLDevice>               gpu_dev;
static id<MTLCommandQueue>         gpu_que;
static id<MTLComputePipelineState> gpu_pso;
static id<MTLBuffer>               gpu_buf;
static id<MTLComputeCommandEncoder> gpu_enc;
#elif BEND_CUDA
static CUdevice   gpu_dev;
static CUmodule   gpu_lib;
static CUfunction gpu_pso;
#endif
static bool io_gpu;
static DEV Term*  io_stk;

static const char* CLI_HELP =
  "usage: %s [options] [arguments]\n"
  "  --threads N       worker threads, 1 to 128 (default: the CPU count)\n"
  "  --gpu on|off|4GB  run ! calls on the GPU, over this much of its memory\n"
  "                    (default: on if present, over 2GB on Metal)\n"
  "  --gpu-build       write the GPU program and exit\n"
  "  --bend-help       show this text\n"
  "  --                the rest are the program's arguments (IO.args)\n";

#endif

// Tables
// ======

#define CID_TUPLE 0
#define CID_SNIL 1
#define CID_SCON 2
#define CID_WCON 3
#define CID_EMIT 4
#define CID_HALT 5
#define CID_FAIL 6
#define CID_DONE 7
#define CID_NONE 8
#define CID_SOME 9
#define CID_FALSE 10
#define CID_TRUE 11
#define CID_UNIT 12
#define CID_STORAGE_ROWS 13
#define CID____OWNED_INDEX_CORE_MOTION 14
#define CID____OWNED_INDEX_CORE_HEALTH 15
#define CID_STORAGE_PLACED 16
#define CID_STORAGE_REJECTED 17
#define CID_STORAGE_ROW 18
#define CID_STORAGE_WORLD 19
#define CID_NIL 20
#define CID_CON 21
#define CID_STORAGE_SPAWN 22
#define CID_STORAGE_INSERTMAIN 23
#define CID_STORAGE_INSERTFLAG 24
#define CID_STORAGE_REMOVEMAIN 25
#define CID_STORAGE_REMOVEFLAG 26
#define CID_STORAGE_DESPAWN 27
#define CID_TYPES_FOUND 28
#define CID_TYPES_MISMATCH 29
#define CID_TYPES_MISSING 30
#define CID_STORAGE_HANDLE 31
#define CID_STORAGE_MISSINGMAINTARGET 32
#define CID_STORAGE_ADDEDMAIN 33
#define CID_STORAGE_CHANGEDMAIN 34
#define CID_STORAGE_REMOVEDMAIN 35
#define CID_STORAGE_NOMAINCHANGE 36
#define CID_CHR 37
#define CID_STORAGE_METADATACOLUMNS 38
#define CID_STORAGE_BUNDLE 39
#define CID_STORAGE_METADATA 40
#define CID_IO_PRINT 41
#define FID_STORAGE_SLOTS_EMPTY 0
#define FID_STORAGE_SLOTS_EMPTY_K44 1
#define FID_STORAGE_SLOTS_EMPTY_K45 2
#define FID_U32_SHOW_GO 3
#define FID____OWNED_INDEX_CORE_HEALTH_OBSERVE 4
#define FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K80 5
#define FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K81 6
#define FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K82 7
#define FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K83 8
#define FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K84 9
#define FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K85 10
#define FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K86 11
#define FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K87 12
#define FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K88 13
#define FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K89 14
#define FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K90 15
#define FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K91 16
#define FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K92 17
#define FID_NAT_SHOW_FIN 18
#define FID_STORAGE_GROW 19
#define FID_STORAGE_GROW_C117 20
#define FID_STORAGE_GROW_K118 21
#define FID_STORAGE_GROW_K119 22
#define FID_STORAGE_GROW_K120 23
#define FID_STORAGE_GROW_K121 24
#define FID_HEALTH_OBSERVE 25
#define FID_HEALTH_OBSERVE_K124 26
#define FID_MOTION_OBSERVE 27
#define FID_MOTION_OBSERVE_K126 28
#define FID_NAT_SHOW 29
#define FID_U32_SHOW 30
#define FID_ROW_OBSERVE 31
#define FID_ROW_OBSERVE_K176 32
#define FID_ROW_OBSERVE_K177 33
#define FID_ROW_OBSERVE_K178 34
#define FID_ROW_OBSERVE_K179 35
#define FID_ROW_OBSERVE_K180 36
#define FID_ROW_OBSERVE_K181 37
#define FID_ROW_OBSERVE_K182 38
#define FID_ROW_OBSERVE_K183 39
#define FID_ROW_OBSERVE_K184 40
#define FID_ROW_OBSERVE_K185 41
#define FID_ROW_OBSERVE_K186 42
#define FID_ROW_OBSERVE_K187 43
#define FID_STRING_APPEND 44
#define FID_STRING_APPEND_K195 45
#define FID_IO_PURE 46
#define FID_REMOVE_PRINT 47
#define FID_REMOVE_PRINT_K200 48
#define FID_REMOVE_PRINT_C201 49
#define FID_REMOVE_PRINT_C202 50
#define FID_REMOVE_PRINT_C203 51
#define FID_REMOVE_PRINT_K204 52
#define FID_REMOVE_PRINT_K205 53
#define FID_REMOVE_PRINT_C206 54
#define FID_REMOVE_PRINT_C207 55
#define FID_REMOVE_PRINT_C208 56
#define FID_EFFECT_PRINT 57
#define FID_EFFECT_PRINT_K211 58
#define FID_EFFECT_PRINT_C212 59
#define FID_EFFECT_PRINT_C213 60
#define FID_EFFECT_PRINT_C214 61
#define FID____OWNED_INDEX_CORE_MOTION_OBSERVE 62
#define FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K218 63
#define FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K219 64
#define FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K220 65
#define FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K221 66
#define FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K222 67
#define FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K223 68
#define FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K224 69
#define FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K225 70
#define FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K226 71
#define FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K227 72
#define FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K228 73
#define FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K229 74
#define FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K230 75
#define FID_STORAGE_WITH_MAIN 76
#define FID_STORAGE_WITH_MAIN_K233 77
#define FID_MAIN_PRINT 78
#define FID_MAIN_PRINT_K235 79
#define FID_MAIN_PRINT_C236 80
#define FID_MAIN_PRINT_C237 81
#define FID_MAIN_PRINT_C238 82
#define FID_LOOKUP_PRINT 83
#define FID_LOOKUP_PRINT_K241 84
#define FID_LOOKUP_PRINT_C242 85
#define FID_LOOKUP_PRINT_C243 86
#define FID_LOOKUP_PRINT_C244 87
#define FID_LOOKUP_PRINT_K245 88
#define FID_LOOKUP_PRINT_K246 89
#define FID_LOOKUP_PRINT_C247 90
#define FID_LOOKUP_PRINT_C248 91
#define FID_LOOKUP_PRINT_C249 92
#define FID_METADATA_PRINT 93
#define FID_METADATA_PRINT_K251 94
#define FID_METADATA_PRINT_K252 95
#define FID_METADATA_PRINT_K253 96
#define FID_METADATA_PRINT_K254 97
#define FID_METADATA_PRINT_K255 98
#define FID_METADATA_PRINT_K256 99
#define FID_METADATA_PRINT_K257 100
#define FID_METADATA_PRINT_K258 101
#define FID_METADATA_PRINT_C259 102
#define FID_METADATA_PRINT_C260 103
#define FID_METADATA_PRINT_C261 104
#define FID_STORAGE_ROWS_PLACE 105
#define FID_STORAGE_ROWS_PLACE_K265 106
#define FID_PLACEMENT_PRINT 107
#define FID_PLACEMENT_PRINT_K267 108
#define FID_PLACEMENT_PRINT_C268 109
#define FID_PLACEMENT_PRINT_C269 110
#define FID_PLACEMENT_PRINT_C270 111
#define FID_PLACEMENT_PRINT_K271 112
#define FID_PLACEMENT_PRINT_K272 113
#define FID_PLACEMENT_PRINT_K273 114
#define FID_PLACEMENT_PRINT_C274 115
#define FID_PLACEMENT_PRINT_C275 116
#define FID_PLACEMENT_PRINT_C276 117
#define FID_IO_BIND 118
#define FID_IO_BIND_C278 119
#define FID_IO_BIND_K279 120
#define FID_MAIN 121
#define FID_MAIN_K282 122
#define FID_MAIN_K283 123
#define FID_MAIN_C284 124
#define FID_MAIN_C285 125
#define FID_MAIN_K286 126
#define FID_MAIN_K287 127
#define FID_MAIN_C288 128
#define FID_MAIN_C289 129
#define FID_MAIN_K290 130
#define FID_MAIN_K291 131
#define FID_MAIN_C292 132
#define FID_MAIN_C293 133
#define FID_MAIN_K294 134
#define FID_MAIN_K295 135
#define FID_MAIN_C296 136
#define FID_MAIN_C297 137
#define FID_MAIN_K298 138
#define FID_MAIN_K299 139
#define FID_MAIN_C300 140
#define FID_MAIN_C301 141
#define FID_MAIN_K302 142
#define FID_MAIN_C303 143
#define FID_MAIN_C304 144
#define FID_MAIN_K305 145
#define FID_MAIN_C306 146
#define FID_MAIN_C307 147
#define FID_MAIN_K308 148
#define FID_MAIN_C309 149
#define FID_MAIN_C310 150
#define FID_MAIN_K311 151
#define FID_MAIN_C312 152
#define FID_MAIN_C313 153
#define FID_MAIN_K314 154
#define FID_MAIN_C315 155
#define FID_MAIN_C316 156
#define FID_MAIN_K317 157
#define FID_MAIN_C318 158
#define FID_MAIN_C319 159
#define FID_MAIN_K320 160
#define FID_MAIN_C321 161
#define FID_MAIN_C322 162
#define FID_MAIN_K323 163
#define FID_MAIN_C324 164
#define FID_MAIN_C325 165
#define FID_MAIN_K326 166
#define FID_MAIN_C327 167
#define FID_MAIN_C328 168
#define FID_MAIN_K329 169
#define FID_MAIN_C330 170
#define FID_MAIN_C331 171
#define FID_MAIN_C332 172
#define FID_MAIN_K333 173
#define FID_MAIN_K334 174
#define FID_MAIN_K335 175
#define FID_MAIN_K336 176
#define FID_MAIN_K337 177
#define FID_MAIN_K338 178
#define FID_MAIN_K339 179
#define FID_MAIN_K340 180
#define FID_MAIN_K341 181
#define FID_MAIN_K342 182
#define FID_MAIN_C343 183
#define FID_MAIN_C344 184
#define FID_MAIN_C345 185
#define FID_MAIN_K346 186
#define FID_MAIN_K347 187
#define FID_MAIN_K348 188
#define FID_MAIN_C349 189
#define FID_MAIN_C350 190
#define FID_MAIN_C351 191
#define FID_MAIN_K352 192
#define FID_MAIN_K353 193
#define FID_MAIN_K354 194
#define FID_MAIN_C355 195
#define FID_MAIN_C356 196
#define FID_MAIN_K357 197
#define FID_MAIN_C358 198
#define FID_MAIN_C359 199
#define FID_MAIN_K360 200
#define FID_MAIN_K361 201
#define FID_MAIN_C362 202
#define FID_MAIN_C363 203
#define FID_MAIN_K364 204
#define FID_MAIN_K365 205
#define FID_MAIN_C366 206
#define FID_MAIN_C367 207
#define FID_MAIN_K368 208
#define FID_MAIN_K369 209
#define FID_MAIN_C370 210
#define FID_MAIN_C371 211
#define FID_MAIN_K372 212
#define FID_MAIN_C373 213
#define FID_MAIN_C374 214
#define FID_MAIN_K375 215
#define FID_MAIN_C376 216
#define FID_MAIN_C377 217
#define FID_MAIN_K378 218
#define FID_MAIN_C379 219
#define FID_MAIN_C380 220
#define FID_MAIN_K381 221
#define FID_MAIN_C382 222
#define FID_MAIN_C383 223
#define FID_MAIN_K384 224
#define FID_MAIN_C385 225
#define FID_MAIN_C386 226
#define FID_MAIN_K387 227
#define FID_MAIN_C388 228
#define FID_MAIN_C389 229
#define FID_MAIN_K390 230
#define FID_MAIN_C391 231
#define FID_MAIN_C392 232
#define FID_MAIN_K393 233
#define FID_MAIN_C394 234
#define FID_MAIN_C395 235
#define FID_MAIN_K396 236
#define FID_MAIN_C397 237
#define FID_MAIN_C398 238
#define FID_MAIN_K399 239
#define FID_MAIN_C400 240
#define FID_MAIN_C401 241
#define FID_MAIN_K402 242
#define FID_MAIN_C403 243
#define FID_MAIN_C404 244
#define FID_MAIN_K405 245
#define FID_MAIN_C406 246
#define FID_MAIN_C407 247
#define FID_MAIN_K408 248
#define FID_MAIN_C409 249
#define FID_MAIN_C410 250
#define FID_MAIN_K411 251
#define FID_MAIN_C412 252
#define FID_MAIN_C413 253
#define FID_MAIN_K414 254
#define FID_MAIN_K415 255
#define FID_MAIN_C416 256
#define FID_MAIN_C417 257
#define FID_MAIN_K418 258
#define FID_MAIN_C419 259
#define FID_MAIN_C420 260
#define FID_MAIN_K421 261
#define FID_MAIN_C422 262
#define FID_MAIN_C423 263
#define FID_MAIN_C424 264
#define FID_IO_PRINT 265
#define FID_IO_EMIT 266
#define FID_CLO_APPLY 267
#define FID_EXIT 268
#define FID_ENTER 269
CONSTV u8 FID_T[][3] = { { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 3, 0, 2 }, { 2, 0, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 4, 0, 2 }, { 11, 0, 2 }, { 3, 0, 2 }, { 9, 9, 2 }, { 11, 1, 2 }, { 12, 1, 2 }, { 1, 1, 2 }, { 3, 0, 2 }, { 3, 3, 2 }, { 3, 0, 2 }, { 3, 3, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 10, 0, 2 }, { 11, 4, 2 }, { 12, 4, 2 }, { 13, 1, 2 }, { 14, 1, 2 }, { 14, 1, 2 }, { 13, 1, 2 }, { 13, 1, 2 }, { 13, 1, 2 }, { 13, 1, 2 }, { 12, 1, 2 }, { 12, 1, 2 }, { 11, 1, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 2, 0, 2 }, { 21, 0, 2 }, { 10, 1, 2 }, { 11, 0, 2 }, { 10, 0, 2 }, { 10, 0, 2 }, { 21, 11, 2 }, { 10, 1, 2 }, { 11, 0, 2 }, { 10, 0, 2 }, { 10, 0, 2 }, { 11, 0, 2 }, { 10, 1, 2 }, { 11, 0, 2 }, { 10, 0, 2 }, { 10, 0, 2 }, { 2, 0, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 18, 0, 2 }, { 17, 1, 2 }, { 16, 0, 2 }, { 14, 1, 2 }, { 15, 0, 2 }, { 14, 0, 2 }, { 14, 0, 2 }, { 21, 0, 2 }, { 10, 1, 2 }, { 11, 0, 2 }, { 10, 0, 2 }, { 10, 0, 2 }, { 21, 11, 2 }, { 20, 1, 2 }, { 21, 0, 2 }, { 20, 0, 2 }, { 20, 0, 2 }, { 9, 0, 2 }, { 10, 1, 2 }, { 11, 1, 2 }, { 12, 1, 2 }, { 12, 1, 2 }, { 11, 1, 2 }, { 11, 1, 2 }, { 10, 1, 2 }, { 10, 1, 2 }, { 11, 0, 2 }, { 10, 0, 2 }, { 10, 0, 2 }, { 18, 0, 2 }, { 18, 9, 2 }, { 21, 0, 2 }, { 10, 1, 2 }, { 11, 0, 2 }, { 10, 0, 2 }, { 10, 0, 2 }, { 21, 11, 2 }, { 11, 1, 2 }, { 10, 1, 2 }, { 11, 0, 2 }, { 10, 0, 2 }, { 10, 0, 2 }, { 3, 0, 2 }, { 3, 0, 2 }, { 2, 1, 2 }, { 0, 0, 2 }, { 19, 19, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 19, 19, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 19, 19, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 19, 19, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 19, 19, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 3, 3, 2 }, { 3, 3, 2 }, { 3, 3, 2 }, { 3, 3, 2 }, { 3, 3, 2 }, { 3, 3, 2 }, { 3, 3, 2 }, { 3, 3, 2 }, { 17, 17, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 3, 3, 2 }, { 17, 17, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 3, 3, 2 }, { 17, 17, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 19, 19, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 19, 19, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 19, 19, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 19, 19, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 } };
CONSTV u8 CID_T[][2] = { { 2, 1 }, { 0, 1 }, { 2, 1 }, { 2, 1 }, { 1, 0 }, { 2, 0 }, { 1, 0 }, { 1, 0 }, { 0, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 9, 1 }, { 2, 1 }, { 2, 1 }, { 9, 1 }, { 18, 1 }, { 9, 1 }, { 15, 1 }, { 0, 1 }, { 2, 1 }, { 7, 1 }, { 2, 1 }, { 2, 1 }, { 1, 1 }, { 1, 1 }, { 1, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 2, 0 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 1, 1 }, { 4, 1 }, { 6, 1 }, { 5, 1 }, { 2, 0 } };
#define STAT_LEN 634

#define WL_RESW 19
#define BANGS   0

#define WL_BANK Term r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20;

#define WL_LOAD(A, N) \
  do { \
    if ((N) <= 0) break; r0 = e.mem[(A) + 0]; \
    if ((N) <= 1) break; r1 = e.mem[(A) + 1]; \
    if ((N) <= 2) break; r2 = e.mem[(A) + 2]; \
    if ((N) <= 3) break; r3 = e.mem[(A) + 3]; \
    if ((N) <= 4) break; r4 = e.mem[(A) + 4]; \
    if ((N) <= 5) break; r5 = e.mem[(A) + 5]; \
    if ((N) <= 6) break; r6 = e.mem[(A) + 6]; \
    if ((N) <= 7) break; r7 = e.mem[(A) + 7]; \
    if ((N) <= 8) break; r8 = e.mem[(A) + 8]; \
    if ((N) <= 9) break; r9 = e.mem[(A) + 9]; \
    if ((N) <= 10) break; r10 = e.mem[(A) + 10]; \
    if ((N) <= 11) break; r11 = e.mem[(A) + 11]; \
    if ((N) <= 12) break; r12 = e.mem[(A) + 12]; \
    if ((N) <= 13) break; r13 = e.mem[(A) + 13]; \
    if ((N) <= 14) break; r14 = e.mem[(A) + 14]; \
    if ((N) <= 15) break; r15 = e.mem[(A) + 15]; \
    if ((N) <= 16) break; r16 = e.mem[(A) + 16]; \
    if ((N) <= 17) break; r17 = e.mem[(A) + 17]; \
    if ((N) <= 18) break; r18 = e.mem[(A) + 18]; \
    if ((N) <= 19) break; r19 = e.mem[(A) + 19]; \
    if ((N) <= 20) break; r20 = e.mem[(A) + 20]; \
  } while (0);

#define WL_LAST(X) \
  switch (war) { \
    case 0: r0 = (X); \
      break; \
    case 1: r1 = (X); \
      break; \
    case 2: r2 = (X); \
      break; \
    case 3: r3 = (X); \
      break; \
    case 4: r4 = (X); \
      break; \
    case 5: r5 = (X); \
      break; \
    case 6: r6 = (X); \
      break; \
    case 7: r7 = (X); \
      break; \
    case 8: r8 = (X); \
      break; \
    case 9: r9 = (X); \
      break; \
    case 10: r10 = (X); \
      break; \
    case 11: r11 = (X); \
      break; \
    case 12: r12 = (X); \
      break; \
    case 13: r13 = (X); \
      break; \
    case 14: r14 = (X); \
      break; \
    case 15: r15 = (X); \
      break; \
    case 16: r16 = (X); \
      break; \
    case 17: r17 = (X); \
      break; \
    case 18: r18 = (X); \
      break; \
    case 19: r19 = (X); \
      break; \
    case 20: r20 = (X); \
      break; \
  }

#define WL_SAVE(V) (V)[0] = r0; (V)[1] = r1; (V)[2] = r2; (V)[3] = r3; (V)[4] = r4; (V)[5] = r5; (V)[6] = r6; (V)[7] = r7; (V)[8] = r8; (V)[9] = r9; (V)[10] = r10; (V)[11] = r11; (V)[12] = r12; (V)[13] = r13; (V)[14] = r14; (V)[15] = r15; (V)[16] = r16; (V)[17] = r17; (V)[18] = r18;

#define WL_TAKE(V) r0 = (V)[0]; r1 = (V)[1]; r2 = (V)[2]; r3 = (V)[3]; r4 = (V)[4]; r5 = (V)[5]; r6 = (V)[6]; r7 = (V)[7]; r8 = (V)[8]; r9 = (V)[9]; r10 = (V)[10]; r11 = (V)[11]; r12 = (V)[12]; r13 = (V)[13]; r14 = (V)[14]; r15 = (V)[15]; r16 = (V)[16]; r17 = (V)[17]; r18 = (V)[18];

#define WL_SIG Env e, DEV Term* sp, u32 seq, u32 rn, Term r0, Term r1, Term r2, Term r3, Term r4, Term r5, Term rp, Term r6, Term r7, Term r8, Term r9, Term r10, Term r11, Term r12, Term r13, Term r14, Term r15, Term r16, Term r17, Term r18, Term r19, Term r20

#define WL_ALL e, sp, seq, rn, r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20

#define WL_TABLE WL_X(FID_STORAGE_SLOTS_EMPTY) WL_X(FID_STORAGE_SLOTS_EMPTY_K44) WL_X(FID_STORAGE_SLOTS_EMPTY_K45) WL_X(FID_U32_SHOW_GO) WL_X(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE) WL_X(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K80) WL_X(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K81) WL_X(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K82) WL_X(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K83) WL_X(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K84) WL_X(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K85) WL_X(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K86) WL_X(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K87) WL_X(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K88) WL_X(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K89) WL_X(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K90) WL_X(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K91) WL_X(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K92) WL_X(FID_NAT_SHOW_FIN) WL_X(FID_STORAGE_GROW) WL_X(FID_STORAGE_GROW_C117) WL_X(FID_STORAGE_GROW_K118) WL_X(FID_STORAGE_GROW_K119) WL_X(FID_STORAGE_GROW_K120) WL_X(FID_STORAGE_GROW_K121) WL_X(FID_HEALTH_OBSERVE) WL_X(FID_HEALTH_OBSERVE_K124) WL_X(FID_MOTION_OBSERVE) WL_X(FID_MOTION_OBSERVE_K126) WL_X(FID_NAT_SHOW) WL_X(FID_U32_SHOW) WL_X(FID_ROW_OBSERVE) WL_X(FID_ROW_OBSERVE_K176) WL_X(FID_ROW_OBSERVE_K177) WL_X(FID_ROW_OBSERVE_K178) WL_X(FID_ROW_OBSERVE_K179) WL_X(FID_ROW_OBSERVE_K180) WL_X(FID_ROW_OBSERVE_K181) WL_X(FID_ROW_OBSERVE_K182) WL_X(FID_ROW_OBSERVE_K183) WL_X(FID_ROW_OBSERVE_K184) WL_X(FID_ROW_OBSERVE_K185) WL_X(FID_ROW_OBSERVE_K186) WL_X(FID_ROW_OBSERVE_K187) WL_X(FID_STRING_APPEND) WL_X(FID_STRING_APPEND_K195) WL_X(FID_IO_PURE) WL_X(FID_REMOVE_PRINT) WL_X(FID_REMOVE_PRINT_K200) WL_X(FID_REMOVE_PRINT_C201) WL_X(FID_REMOVE_PRINT_C202) WL_X(FID_REMOVE_PRINT_C203) WL_X(FID_REMOVE_PRINT_K204) WL_X(FID_REMOVE_PRINT_K205) WL_X(FID_REMOVE_PRINT_C206) WL_X(FID_REMOVE_PRINT_C207) WL_X(FID_REMOVE_PRINT_C208) WL_X(FID_EFFECT_PRINT) WL_X(FID_EFFECT_PRINT_K211) WL_X(FID_EFFECT_PRINT_C212) WL_X(FID_EFFECT_PRINT_C213) WL_X(FID_EFFECT_PRINT_C214) WL_X(FID____OWNED_INDEX_CORE_MOTION_OBSERVE) WL_X(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K218) WL_X(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K219) WL_X(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K220) WL_X(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K221) WL_X(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K222) WL_X(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K223) WL_X(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K224) WL_X(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K225) WL_X(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K226) WL_X(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K227) WL_X(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K228) WL_X(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K229) WL_X(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K230) WL_X(FID_STORAGE_WITH_MAIN) WL_X(FID_STORAGE_WITH_MAIN_K233) WL_X(FID_MAIN_PRINT) WL_X(FID_MAIN_PRINT_K235) WL_X(FID_MAIN_PRINT_C236) WL_X(FID_MAIN_PRINT_C237) WL_X(FID_MAIN_PRINT_C238) WL_X(FID_LOOKUP_PRINT) WL_X(FID_LOOKUP_PRINT_K241) WL_X(FID_LOOKUP_PRINT_C242) WL_X(FID_LOOKUP_PRINT_C243) WL_X(FID_LOOKUP_PRINT_C244) WL_X(FID_LOOKUP_PRINT_K245) WL_X(FID_LOOKUP_PRINT_K246) WL_X(FID_LOOKUP_PRINT_C247) WL_X(FID_LOOKUP_PRINT_C248) WL_X(FID_LOOKUP_PRINT_C249) WL_X(FID_METADATA_PRINT) WL_X(FID_METADATA_PRINT_K251) WL_X(FID_METADATA_PRINT_K252) WL_X(FID_METADATA_PRINT_K253) WL_X(FID_METADATA_PRINT_K254) WL_X(FID_METADATA_PRINT_K255) WL_X(FID_METADATA_PRINT_K256) WL_X(FID_METADATA_PRINT_K257) WL_X(FID_METADATA_PRINT_K258) WL_X(FID_METADATA_PRINT_C259) WL_X(FID_METADATA_PRINT_C260) WL_X(FID_METADATA_PRINT_C261) WL_X(FID_STORAGE_ROWS_PLACE) WL_X(FID_STORAGE_ROWS_PLACE_K265) WL_X(FID_PLACEMENT_PRINT) WL_X(FID_PLACEMENT_PRINT_K267) WL_X(FID_PLACEMENT_PRINT_C268) WL_X(FID_PLACEMENT_PRINT_C269) WL_X(FID_PLACEMENT_PRINT_C270) WL_X(FID_PLACEMENT_PRINT_K271) WL_X(FID_PLACEMENT_PRINT_K272) WL_X(FID_PLACEMENT_PRINT_K273) WL_X(FID_PLACEMENT_PRINT_C274) WL_X(FID_PLACEMENT_PRINT_C275) WL_X(FID_PLACEMENT_PRINT_C276) WL_X(FID_IO_BIND) WL_X(FID_IO_BIND_C278) WL_X(FID_IO_BIND_K279) WL_X(FID_MAIN) WL_X(FID_MAIN_K282) WL_X(FID_MAIN_K283) WL_X(FID_MAIN_C284) WL_X(FID_MAIN_C285) WL_X(FID_MAIN_K286) WL_X(FID_MAIN_K287) WL_X(FID_MAIN_C288) WL_X(FID_MAIN_C289) WL_X(FID_MAIN_K290) WL_X(FID_MAIN_K291) WL_X(FID_MAIN_C292) WL_X(FID_MAIN_C293) WL_X(FID_MAIN_K294) WL_X(FID_MAIN_K295) WL_X(FID_MAIN_C296) WL_X(FID_MAIN_C297) WL_X(FID_MAIN_K298) WL_X(FID_MAIN_K299) WL_X(FID_MAIN_C300) WL_X(FID_MAIN_C301) WL_X(FID_MAIN_K302) WL_X(FID_MAIN_C303) WL_X(FID_MAIN_C304) WL_X(FID_MAIN_K305) WL_X(FID_MAIN_C306) WL_X(FID_MAIN_C307) WL_X(FID_MAIN_K308) WL_X(FID_MAIN_C309) WL_X(FID_MAIN_C310) WL_X(FID_MAIN_K311) WL_X(FID_MAIN_C312) WL_X(FID_MAIN_C313) WL_X(FID_MAIN_K314) WL_X(FID_MAIN_C315) WL_X(FID_MAIN_C316) WL_X(FID_MAIN_K317) WL_X(FID_MAIN_C318) WL_X(FID_MAIN_C319) WL_X(FID_MAIN_K320) WL_X(FID_MAIN_C321) WL_X(FID_MAIN_C322) WL_X(FID_MAIN_K323) WL_X(FID_MAIN_C324) WL_X(FID_MAIN_C325) WL_X(FID_MAIN_K326) WL_X(FID_MAIN_C327) WL_X(FID_MAIN_C328) WL_X(FID_MAIN_K329) WL_X(FID_MAIN_C330) WL_X(FID_MAIN_C331) WL_X(FID_MAIN_C332) WL_X(FID_MAIN_K333) WL_X(FID_MAIN_K334) WL_X(FID_MAIN_K335) WL_X(FID_MAIN_K336) WL_X(FID_MAIN_K337) WL_X(FID_MAIN_K338) WL_X(FID_MAIN_K339) WL_X(FID_MAIN_K340) WL_X(FID_MAIN_K341) WL_X(FID_MAIN_K342) WL_X(FID_MAIN_C343) WL_X(FID_MAIN_C344) WL_X(FID_MAIN_C345) WL_X(FID_MAIN_K346) WL_X(FID_MAIN_K347) WL_X(FID_MAIN_K348) WL_X(FID_MAIN_C349) WL_X(FID_MAIN_C350) WL_X(FID_MAIN_C351) WL_X(FID_MAIN_K352) WL_X(FID_MAIN_K353) WL_X(FID_MAIN_K354) WL_X(FID_MAIN_C355) WL_X(FID_MAIN_C356) WL_X(FID_MAIN_K357) WL_X(FID_MAIN_C358) WL_X(FID_MAIN_C359) WL_X(FID_MAIN_K360) WL_X(FID_MAIN_K361) WL_X(FID_MAIN_C362) WL_X(FID_MAIN_C363) WL_X(FID_MAIN_K364) WL_X(FID_MAIN_K365) WL_X(FID_MAIN_C366) WL_X(FID_MAIN_C367) WL_X(FID_MAIN_K368) WL_X(FID_MAIN_K369) WL_X(FID_MAIN_C370) WL_X(FID_MAIN_C371) WL_X(FID_MAIN_K372) WL_X(FID_MAIN_C373) WL_X(FID_MAIN_C374) WL_X(FID_MAIN_K375) WL_X(FID_MAIN_C376) WL_X(FID_MAIN_C377) WL_X(FID_MAIN_K378) WL_X(FID_MAIN_C379) WL_X(FID_MAIN_C380) WL_X(FID_MAIN_K381) WL_X(FID_MAIN_C382) WL_X(FID_MAIN_C383) WL_X(FID_MAIN_K384) WL_X(FID_MAIN_C385) WL_X(FID_MAIN_C386) WL_X(FID_MAIN_K387) WL_X(FID_MAIN_C388) WL_X(FID_MAIN_C389) WL_X(FID_MAIN_K390) WL_X(FID_MAIN_C391) WL_X(FID_MAIN_C392) WL_X(FID_MAIN_K393) WL_X(FID_MAIN_C394) WL_X(FID_MAIN_C395) WL_X(FID_MAIN_K396) WL_X(FID_MAIN_C397) WL_X(FID_MAIN_C398) WL_X(FID_MAIN_K399) WL_X(FID_MAIN_C400) WL_X(FID_MAIN_C401) WL_X(FID_MAIN_K402) WL_X(FID_MAIN_C403) WL_X(FID_MAIN_C404) WL_X(FID_MAIN_K405) WL_X(FID_MAIN_C406) WL_X(FID_MAIN_C407) WL_X(FID_MAIN_K408) WL_X(FID_MAIN_C409) WL_X(FID_MAIN_C410) WL_X(FID_MAIN_K411) WL_X(FID_MAIN_C412) WL_X(FID_MAIN_C413) WL_X(FID_MAIN_K414) WL_X(FID_MAIN_K415) WL_X(FID_MAIN_C416) WL_X(FID_MAIN_C417) WL_X(FID_MAIN_K418) WL_X(FID_MAIN_C419) WL_X(FID_MAIN_C420) WL_X(FID_MAIN_K421) WL_X(FID_MAIN_C422) WL_X(FID_MAIN_C423) WL_X(FID_MAIN_C424) WL_X(FID_IO_PRINT) WL_X(FID_IO_EMIT) WL_X(FID_CLO_APPLY) WL_X(FID_EXIT)
#define MAIN_FID FID_MAIN
#define MAIN_PURE 0
#define BLK_SHR 1

#define TAB_AT(T, S, I) T[S < I ? S : I]

#define fid_arity(x) ((u32)FID_T[x][0])
#define fid_resw(x)  ((u32)FID_T[x][1])
#define fid_bangs(x) ((bool)(FID_T[x][2] & 1))
#define fid_nofk(x)  ((bool)(FID_T[x][2] & 2))
#define cid_arity(x) ((u32)CID_T[x][0])
#define cid_hot(x)   ((bool)CID_T[x][1])

// A32
// ===

// C11's atomics on every lane; a device FENCE releases or acquires.
// Metal's loads read through a volatile local, or the M1 and M2 pipeline
// builds die. A weak CAS may fail with the cell still x: a32_cmpx loops.

#define A32_LOOP(k, x) \
  INLINE u32 a32_##k(DEV u32* p, u32 v) { \
    u32 o = a32_load(p); \
    while (!a32_cas(p, &o, x)) { \
    } \
    return o; \
  }

#ifdef __METAL_VERSION__

INLINE DEV atomic_uint* A32(DEV u32* p) {
  return (DEV atomic_uint*)p;
}

INLINE TG atomic_uint* A32(TG u32* p) {
  return (TG atomic_uint*)p;
}

#define a32_load(p) \
  ({ volatile thread u32 _a32v = atomic_load_explicit(A32(p), RLX); _a32v; })

#else

#define a32_load(p) atomic_load_explicit(A32(p), RLX)

#ifdef BEND_RTC

#define A32(p) (p)
#define atomic_load_explicit(p, o)     (*(volatile u32*)(p))
#define atomic_store_explicit(p, v, o) (*(volatile u32*)(p) = (v))
#define atomic_fetch_add_explicit(p, v, o) atomicAdd((u32*)(p), v)
#define atomic_fetch_sub_explicit(p, v, o) atomicSub((u32*)(p), v)
#define atomic_fetch_and_explicit(p, v, o) atomicAnd((u32*)(p), v)
#define atomic_fetch_or_explicit(p, v, o) atomicOr((u32*)(p), v)
#define atomic_fetch_xor_explicit(p, v, o) atomicXor((u32*)(p), v)
#define atomic_fetch_min_explicit(p, v, o) atomicMin((u32*)(p), v)
#define atomic_fetch_max_explicit(p, v, o) atomicMax((u32*)(p), v)
#define atomic_compare_exchange_weak_explicit(p, e, v, s, f) a32_swp(p, e, v)

INLINE bool a32_swp(DEV u32* p, u32* e, u32 v) {
  u32 x = *e;
  *e = atomicCAS((u32*)p, x, v);
  return *e == x;
}

#else

#define A32(p) ((_Atomic u32*)(p))
#define atomic_fetch_min_explicit __c11_atomic_fetch_min
#define atomic_fetch_max_explicit __c11_atomic_fetch_max

#endif

#endif

#define RLX memory_order_relaxed

#if DEVICE
#define REL RLX
#define ACQ RLX
#define ACR RLX
#define a32_acq(p) FENCE()
#define w64_load(p) (*(p))
#else
#define REL memory_order_release
#define ACQ memory_order_acquire
#define ACR memory_order_acq_rel
#define a32_acq(p) ((void)a32_load_acq(p))
#define w64_load(p) atomic_load_explicit((_Atomic u64*)(p), RLX)
#endif

#define a32_store(p, v)     atomic_store_explicit(A32(p), v, RLX)
#define a32_add(p, v) atomic_fetch_add_explicit(A32(p), v, RLX)
#define a32_sub(p, v) atomic_fetch_sub_explicit(A32(p), v, RLX)
#define a32_and(p, v) atomic_fetch_and_explicit(A32(p), v, RLX)
#define a32_or(p, v) atomic_fetch_or_explicit(A32(p), v, RLX)
#define a32_xor(p, v) atomic_fetch_xor_explicit(A32(p), v, RLX)
#define a32_min(p, v) atomic_fetch_min_explicit(A32(p), v, RLX)
#define a32_max(p, v) atomic_fetch_max_explicit(A32(p), v, RLX)
#define a32_sub_rel(p, v)   (FENCE(), atomic_fetch_sub_explicit(A32(p), v, REL))
#define a32_store_rel(p, v) (FENCE(), atomic_store_explicit(A32(p), v, REL))
#define a32_at(H, word)     ((DEV u32*)&(H)[word])

INLINE u32 a32_load_acq(DEV u32* p) {
  u32 v = DEVICE ? a32_load(p) : atomic_load_explicit(A32(p), ACQ);
  FENCE();
  return v;
}

INLINE bool a32_cas(DEV u32* p, THR u32* e, u32 v) {
  FENCE();
  bool ok = atomic_compare_exchange_weak_explicit(A32(p), e, v, ACR, ACQ);
  FENCE();
  return ok;
}

A32_LOOP(exch, v)

INLINE u32 a32_cmpx(DEV u32* p, u32 x, u32 v) {
  u32 o = x;
  while (!a32_cas(p, &o, v) && o == x) {
  }
  return o;
}

// Err
// ===

#if DEVICE

INLINE void err_post(DEV u64* H, u32 code) {
  a32_cmpx(a32_at(H, H_ERROR_CODE), 0, code);
}

#else

static const char* ERR_TEXT[] = { "",
  "runtime fail-stop",
  "runtime fail-stop",
  "out of memory: run again with a bigger span, as in --gpu 8GB",
  "a function the device does not hold",
  "a Nat past the largest immediate 2^48-1",
  "runtime fail-stop",
  "memory fault (machine stack overflow?)",
  "an array past the deepest block class 31" };

static void err_fail(const char* msg) {
  fflush(stdout);
  fprintf(stderr, "bend: %s\n", msg);
  _exit(1);
}

static void err_post(u64* H, u32 code) {
  err_fail(ERR_TEXT[code]);
}

static void err_trap(int sig) {
  err_post(NULL, ERR_DEEP);
}

#endif

#define err_seen(H)    (DEVICE && a32_load(a32_at(H, H_ERROR_CODE)) != 0)
#define err_spun(H, n) ((++*(n) & 4095) == 0 && err_seen(H))

#ifdef __METAL_VERSION__
INLINE f32 atan2_c99(f32 y, f32 x) {
  return y == 0.0f && x == x
    ? copysign(signbit(x) ? M_PI_F : 0.0f, y) : atan2(y, x);
}
#define sqrt  precise::sqrt
#define exp   precise::exp
#define log   precise::log
#define log2  precise::log2
#define log10 precise::log10
#define sin   fast::sin
#define cos   fast::cos
#define tan   fast::tan
#define pow   precise::pow
#define fmod  precise::fmod
#define atan2 atan2_c99
#define U32_QUO(a, b) \
  ((a) / 2 / (b) * 2 + ((a) - (a) / 2 / (b) * 2 * (b) >= (b)))
#else
#define U32_QUO(a, b) ((a) / (b))
#endif

#define U32_BIN(a, o, b) ((u64)((u32)(a) o (u32)(b)))

INLINE f32 f32_unbox(u64 x) {
  union { u32 u; f32 f; } p = { (u32)x };
  return p.f;
}

INLINE u64 f32_rewrap(f32 x) {
  union { f32 f; u32 u; } p = { x };
  return p.u;
}

INLINE u64 f32_to_u32(u64 a) {
  f32 v = f32_unbox(a);
  return v >= 0.0f && v < 4294967296.0f ? (u32)v : 0;
}

INLINE u64 nat_chk(Env e, u64 n) {
  if (n > NAT_IMM) {
    err_post(e.mem, ERR_NATS);
    return NAT_IMM;
  }
  return n;
}

INLINE u64 nat_mul(Env e, u64 a, u64 b) {
  return nat_chk(e, b != 0 && a > NAT_IMM / b ? NAT_IMM + 1 : a * b);
}

#if DEVICE

#define f32_show(e, x) (err_post(e.mem, ERR_FIDS), 0)
#define f32_read(e, s) (err_post(e.mem, ERR_FIDS), 0)

#else

static Term f32_show(Env e, Term x);
static Term f32_read(Env e, Term s);

#endif

A32_LOOP(fadd, f32_rewrap(f32_unbox(o) + f32_unbox(v)))

// Bank
// ====

// A stack of exact generations per class. The host pops and pushes at rd;
// a device pass pops below rd and pushes above top, compacted after it.

#define bank_at(H, c) ((DEV Bank*)((H) + H_BANK) + (c))

INLINE u64 bank_pop(DEV u64* H, u32 c) {
  DEV Bank* b = bank_at(H, c);
  u64 got = 0;
  LOCK(bank_lock);
  u32 t = a32_sub(&b->rd, 1);
  if ((int)t > 0) {
    got = H[b->off + t - 1];
  } else {
    a32_add(&b->rd, 1);
  }
  if (!DEVICE) {
    b->wr = b->top = b->rd;
  }
  UNLOCK(bank_lock);
  return got;
}

INLINE void bank_push(DEV u64* H, u32 c, u64 head) {
  DEV Bank* b = bank_at(H, c);
  LOCK(bank_lock);
  H[b->off + a32_add(&b->wr, 1)] = head;
  if (!DEVICE) {
    b->rd = b->top = b->wr;
  }
  UNLOCK(bank_lock);
}

// Heap
// ====

// Per lane and class: HOT, a LIFO free chain; LEN, its length in words;
// on the host COLD, one parked generation. A host free reaching KEEP_WORDS
// parks HOT as COLD and banks the old COLD. A miss takes COLD, a bank entry
// or a fresh quantum. A device lane banks its complete generations at the
// kernel end (dev_cut). The bump grows only when all of these are empty.

#define ALC_AT(e, i)   (e).alc[(i) * LANE_STEP]
#define ALC_LEN(e, c)  ALC_AT(e, NCLS_ALL + (c))
#define ALC_COLD(e, c) ALC_AT(e, 2 * NCLS_ALL + (c))
#define KEEP(c)        (KEEP_WORDS >> (c) ? KEEP_WORDS >> (c) : 1)

INLINE u32 cls_fit(u32 words) {
  return words > 1 ? 32 - CLZ(words - 1) : 0;
}

OUTLINE void heap_hand(Env e, u32 cls) {
  u64 cold = ALC_COLD(e, cls);
  if (cold) {
    bank_push(e.mem, cls, cold);
  }
  ALC_COLD(e, cls) = ALC_AT(e, cls);
  ALC_AT(e, cls)   = 0;
  ALC_LEN(e, cls)  = 0;
}

#if DEVICE
#define corpus_grow(H, n) false
#else
static bool corpus_grow(u64* H, u64 need);
#endif

OUTLINE u64 heap_alloc_miss(Env e, u32 cls) {
  DEV u64* H = e.mem;
  u64  got = 0;
  if (!DEVICE) {
    got = ALC_COLD(e, cls);
    ALC_COLD(e, cls) = 0;
  }
  if (!got) {
    got = bank_pop(H, cls);
  }
  u32 n = got ? KEEP(cls) : cls < NCLS ? QUANTUM >> cls : 1;
  if (!got) {
    u32 pages = (n << cls) >> PAGE_BITS;
    u32 p     = a32_add(a32_at(H, H_BUMP), pages);
    if ((u64)p + pages > a32_load_acq(a32_at(H, H_CAP))
      && !corpus_grow(H, (u64)p + pages)) {
      err_post(H, ERR_HEAP);
      return HEAP_OFF;
    }
    got = HEAP_OFF + ((u64)p << PAGE_BITS);
    for (u32 i = 1; i <= n; i += 1) {
      H[got + ((u64)(i - 1) << cls)] = i < n ? got + ((u64)i << cls) : 0;
    }
  }
  ALC_AT(e, cls)  = H[got];
  ALC_LEN(e, cls) = (u64)(n - 1) << cls;
  return got;
}

INLINE u64 heap_alloc(Env e, u32 cls) {
  u64 h = ALC_AT(e, cls);
  if (h) {
    ALC_AT(e, cls)   = e.mem[h];
    ALC_LEN(e, cls) -= 1ull << cls;
    return h;
  }
  return heap_alloc_miss(e, cls);
}

INLINE void heap_free(Env e, u32 cls, u64 loc) {
  if (err_seen(e.mem)) {
    return;
  }
  e.mem[loc]       = ALC_AT(e, cls);
  ALC_AT(e, cls)   = loc;
  ALC_LEN(e, cls) += 1ull << cls;
  if (!DEVICE && ALC_LEN(e, cls) >= KEEP_WORDS) {
    heap_hand(e, cls);
  }
}

INLINE void spare_free(Env e, u32 cls, u64 loc) {
  if (loc >= HEAP_OFF) {
    heap_free(e, cls, loc);
  }
}

// Term
// ====

#define term_make(tag, aux, loc) \
  (((u64)(tag) << 56) | ((u64)(aux) << 40) | (u64)(loc))

#define term_ctr(cid, loc) term_make(TAG_CTR, cid, loc)
#define term_pak(cid, loc) term_make(TAG_PAK, cid, loc)
#define term_clo(fid, loc) term_make(TAG_CLO, fid, loc)
#define term_buf(cls, loc) term_make(TAG_BUF, cls, loc)
#define term_tsk(fid, loc) term_make(TAG_TSK, fid, loc)

INLINE Term term_blk(bool arr, u32 cls, u64 loc) {
  return term_buf(cls, loc) | ((u64)arr << 57);
}

INLINE u64 term_tag(Term t) {
  return (t >> 56) & 0x7f;
}

INLINE bool term_rfc(Term t) {
  return (t & RFC_BIT) != 0;
}

INLINE u64 term_aux(Term t) {
  return (t >> 40) & 0xFFFF;
}

INLINE u64 term_loc(Term t) {
  return t & LOC_MASK;
}

INLINE bool term_triv(Term t) {
  return term_tag(t) <= TAG_PAK || t == TERM_HOLE || term_loc(t) < HEAP_OFF;
}

OUTLINE Term rfc_wrap(Env e, Term t, u32 cnt) {
  if (term_tag(t) == TAG_CLO || term_tag(t) == TAG_TSK) {
    err_post(e.mem, ERR_RFCS);
    return t;
  }
  u64 r = heap_alloc(e, 0);
  e.mem[r] = ((u64)term_loc(t) << 24) | cnt;
  return (t & ~LOC_MASK) | RFC_BIT | r;
}

INLINE Term rfc_seal(Env e, Term t) {
  if (term_tag(t) != TAG_CTR || term_rfc(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1);
}

// A redirect cell holds its target's loc over a 24-bit count, which
// changes by atomic adds on the low half, so a host never reads it as one
// plain word.
INLINE u64 rfc_view(DEV u64* H, u64 r) {
  DEV u32* w = a32_at(H, r);
  u64 cell = ((u64)a32_load(w + 1) << 32) | a32_load(w);
  if ((cell & RFC_CNT) == 1) {
    a32_acq(w);
  }
  return cell;
}

INLINE void rfc_bump(Env e, u64 r, u32 k) {
  u32 c = a32_add(a32_at(e.mem, r), k);
  if ((c & RFC_CNT) >= RFC_CNT - k) {
    err_post(e.mem, ERR_RFCS);
  }
}

INLINE Term term_keep(Env e, Term t, u32 k) {
  if (term_rfc(t)) {
    rfc_bump(e, term_loc(t), k);
    return t;
  }
  if (term_triv(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1 + k);
}

INLINE u64 term_peek(DEV u64* H, Term t) {
  if (term_rfc(t)) {
    return rfc_view(H, term_loc(t)) >> 24;
  }
  return term_loc(t);
}

#define blk_shr(t) (BLK_SHR && term_rfc(t))

INLINE u64 blk_loc(DEV u64* H, Term a) {
  return blk_shr(a) ? w64_load(&H[term_loc(a)]) >> 24 : term_loc(a);
}

INLINE u32 blk_cls(Term t) {
  return (u32)term_aux(t) & 31;
}

#define buf_wcls(c) ((c) == 0 ? 0 : (c) - 1)

INLINE u32 blk_span(Term t) {
  u32 c = blk_cls(t);
  return term_tag(t) == TAG_ARR ? c : buf_wcls(c);
}

FAR void term_drop(Env e, Term t) {
  DEV u64* H = e.mem;
  u64  cur = 0;
  Term c0  = 0;
  u32  step = 0;
  for (;;) {
    if (!term_triv(t) && term_rfc(t)) {
      u64      r = term_loc(t);
      DEV u32* p = a32_at(H, r);
      if ((a32_sub_rel(p, 1) & RFC_CNT) != 1) {
        t = 0;
      } else {
        a32_acq(p);
        t = (t & ~(RFC_BIT | LOC_MASK)) | (H[r] >> 24);
        heap_free(e, 0, r);
      }
    }
    if (!term_triv(t)) {
      u64 tag = term_tag(t);
      if (tag == TAG_BUF) {
        heap_free(e, blk_span(t), term_loc(t));
      } else {
        u32 aux = (u32)term_aux(t);
        u64 loc = term_loc(t);
        u32 n   = tag == TAG_ARR ? 0 : tag == TAG_CTR ? cid_arity(aux)
          : fid_arity(aux) - (tag == TAG_CLO);
        u32 cls = tag == TAG_ARR ? 64 | blk_cls(t)
          : n > 247 ? 64 | (n - 240)
          : cls_fit(tag == TAG_TSK ? n + 2 : n);
        c0 = H[loc];
        H[loc] = cur;
        cur = loc | ((u64)n << 48) | ((u64)cls << 56);
      }
    }
    for (;;) {
      if (err_spun(H, &step) || cur == 0) {
        return;
      }
      u64  loc = cur & LOC_MASK;
      u32  i   = (u8)(cur >> 40);
      u32  n   = (u8)(cur >> 48);
      u32  cls = (u32)(cur >> 56);
      bool arr = cls > 63;
      u32  j   = i;
      if (arr) {
        cls &= 63;
        n   = 1u << cls;
        if (i == 2) {
          j = (u32)H[loc + 1];
        }
      }
      if (j < n) {
        Term c = j == 0 ? c0 : H[loc + j];
        if (arr && j > 0) {
          H[loc + 1] = j + 1;
        }
        if (!arr || i < 2) {
          cur += 1ull << 40;
        }
        if (!term_triv(c)) {
          t = c;
          break;
        }
      } else {
        u64 up = H[loc];
        heap_free(e, cls, loc);
        cur = up;
      }
    }
  }
}

INLINE void term_sink(Env e, Term t) {
  if (!term_triv(t)) {
    term_drop(e, t);
  }
}

OUTLINE void span_fade(Env e, Term t, u64 src, u32 n) {
  for (u32 j = 0; j < n; j += 1) {
    Term f = e.mem[src + j];
    if (term_rfc(f)) {
      rfc_bump(e, term_loc(f), 1);
    } else if (!term_triv(f)) {
      err_post(e.mem, ERR_RFCS);
    }
  }
  term_drop(e, t);
}

INLINE u64 ctr_take(Env e, Term t, u32 n, THR Term* out) {
  DEV u64* H = e.mem;
  if (!term_rfc(t)) {
    for (u32 j = 0; j < n; j += 1) {
      out[j] = H[term_loc(t) + j];
    }
    return term_loc(t);
  }
  u64 r    = term_loc(t);
  u64 cell = rfc_view(H, r);
  u64 src  = cell >> 24;
  for (u32 j = 0; j < n; j += 1) {
    out[j] = H[src + j];
  }
  if ((cell & RFC_CNT) == 1) {
    heap_free(e, 0, r);
    return src;
  }
  span_fade(e, t, src, n);
  return 0;
}

INLINE Term term_word(Env e, Term w) {
  u32 x = 0;
  Term t = w;
  for (u32 i = 0; i < 32 && term_aux(t) == CID_WCON; i += 1) {
    u64 l = term_peek(e.mem, t);
    x |= (u32)(e.mem[l] & 1) << i;
    t = e.mem[l + 1];
  }
  term_sink(e, w);
  return x;
}

// Blk
// ===

// A block owns one allocation in its class (an ARR 2^c Terms, a BUF 2^c
// u32). Matching ANode is blk_half twice (the high call frees the source);
// ANode{l, r} is blk_node; Array.clone is blk_copy.

#define BLK_ALLOC(n, w) \
  u64 n = heap_alloc(e, w); \
  if (err_seen(e.mem)) { \
    return term_buf(0, n); \
  }

INLINE DEV u32a* blk_ptr(DEV u64* H, u64 loc, u32 i) {
  return (DEV u32a*)(H + loc) + i;
}

INLINE Term blk_read(DEV u64* H, bool arr, u64 loc, u32 i) {
  if (arr) {
    return H[loc + i];
  }
  return (u64)*blk_ptr(H, loc, i);
}

INLINE void blk_write(DEV u64* H, bool arr, u64 loc, u32 i, Term v) {
  if (arr) {
    H[loc + i] = v;
  } else {
    *blk_ptr(H, loc, i) = (u32)v;
  }
}

INLINE u32 blk_at(Term a, u64 i, u32 lgs) {
  return ((u32)i & (u32)((1ull << (blk_cls(a) - lgs)) - 1)) << lgs;
}

INLINE Term blk_keep(Env e, u64 at) {
  Term w = e.mem[at];
  Term v = term_keep(e, w, 1);
  if (v != w) {
    e.mem[at] = v;
  }
  return v;
}

INLINE void blk_fill(Env e, u64 dst, u64 src, u64 n, bool keep) {
  for (u64 j = 0; j < n; j += 1) {
    e.mem[dst + j] = keep ? blk_keep(e, src + j) : e.mem[src + j];
  }
}

INLINE void blk_free(Env e, Term t) {
  blk_shr(t) ? term_drop(e, t) : heap_free(e, blk_span(t), term_loc(t));
}

OUTLINE Term blk_copy(Env e, Term a) {
  bool arr = term_tag(a) == TAG_ARR;
  u32 cls = blk_span(a);
  BLK_ALLOC(dst, cls)
  blk_fill(e, dst, blk_loc(e.mem, a), 1ull << cls, arr);
  return term_blk(arr, blk_cls(a), dst);
}

INLINE Term blk_node(Env e, Term l, Term r) {
  DEV u64* H = e.mem;
  bool arr = term_tag(l) == TAG_ARR;
  u32 c = blk_cls(l);
  if (c != blk_cls(r) || c + 1 >= NCLS_ALL) {
    err_post(H, ERR_TAGS);
    return l;
  }
  u64 pl = blk_loc(H, l);
  u64 pr = blk_loc(H, r);
  BLK_ALLOC(n, arr ? c + 1 : c)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, pl, 0) | ((u64)*blk_ptr(H, pr, 0) << 32);
  } else {
    u64 cw = 1ull << blk_span(l);
    blk_fill(e, n, pl, cw, arr && blk_shr(l));
    blk_fill(e, n + cw, pr, cw, arr && blk_shr(r));
  }
  blk_free(e, l);
  blk_free(e, r);
  return term_blk(arr, c + 1, n);
}

INLINE Term blk_half(Env e, Term a, u32 hi) {
  DEV u64* H = e.mem;
  bool arr = term_tag(a) == TAG_ARR;
  u32 c = blk_cls(a);
  if (c == 0) {
    err_post(H, ERR_TAGS);
    return a;
  }
  c -= 1;
  u32 cw = arr ? c : buf_wcls(c);
  u64 src = blk_loc(H, a);
  BLK_ALLOC(n, cw)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, src, hi);
  } else {
    blk_fill(e, n, src + ((u64)hi << cw), 1ull << cw, arr && blk_shr(a));
  }
  if (hi) {
    blk_free(e, a);
  }
  return term_blk(arr, c, n);
}

INLINE Term blk_new(Env e, bool arr, u64 d, u32 lgs, u32 n, THR Term* v) {
  DEV u64* H = e.mem;
  if (d + lgs > 31) {
    err_post(H, ERR_ARRS);
    d = 0;
  }
  u32 c = (u32)d + lgs;
  BLK_ALLOC(l, arr ? c : buf_wcls(c))
  for (u32 j = 0; arr && d > 0 && j < n; j += 1) {
    if (d >= 24 && !term_triv(v[j])) {
      err_post(H, ERR_RFCS);
    }
    v[j] = term_keep(e, v[j], (1u << d) - 1);
  }
  for (u64 i = 0; i < (1ull << c); i += 1) {
    blk_write(H, arr, l, (u32)i, i % (1u << lgs) < n ? v[i % (1u << lgs)] : 0);
  }
  return term_blk(arr, c, l);
}

// Ring
// ====

#define ring_word(H, r, w) ((H) + RING_OFF + (w) * LANES + (r))
#define ring_slot(H, r, p) ring_word(H, r, (p) & (RING_LEN - 1))
#define ring_get(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN))
#define ring_put(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN + 1))

INLINE u32 ring_lap(u32 pos) {
  return ~(u32)(pos / RING_LEN) & 1;
}

INLINE void ring_push(DEV u64* H, u32 r, Term tsk) {
  u32 pos = a32_add(ring_put(H, r), 1);
  if (pos - a32_load(ring_get(H, r)) >= RING_LEN) {
    err_post(H, ERR_RING);
    return;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, r, pos);
  a32_store(lo, (u32)tsk);
  a32_store_rel(lo + 1, (u32)(tsk >> 32) | (ring_lap(pos) << 31));
}

INLINE u32 ring_flip(u32 i) {
  return (i % CUBE_T << CUBE_LOG) + i / CUBE_T;
}

#define ring_pick(b, s, c) ((b) + (s) * (a32_add(c, 1) & (CUBE_T - 1)))

// Task
// ====

INLINE u64 task_node(Env e, u32 fid, Term cont, u32 idx, u32 rem) {
  u32 ar  = fid_arity(fid);
  u64 loc = heap_alloc(e, cls_fit(ar + 2));
  for (u32 i = 0; rem && i < ar; i += 1) {
    e.mem[loc + i] = TERM_HOLE;
  }
  e.mem[loc + ar]     = cont;
  e.mem[loc + ar + 1] = ((u64)idx << 32) | rem;
  return loc;
}

INLINE u64 task_tail(Term t) {
  return term_loc(t) + fid_arity((u32)term_aux(t));
}

INLINE Term task_deliver(DEV u64* H, Term cont, u32 idx, THR Term* v, u32 n) {
  u64 at = cont == TERM_HOLE ? H_ROOT_WORD : term_loc(cont) + idx;
  for (u32 j = 0; j < WL_RESW; j += 1) {
    if (j < n) {
      H[at + j] = v[j];
    }
  }
  if (cont == TERM_HOLE) {
    a32_store_rel(a32_at(H, H_ROOT_DONE), n + 1);
    return 0;
  }
  u64 tl = task_tail(cont);
  if (a32_sub_rel(a32_at(H, tl + 1), 1) == 1) {
    a32_acq(a32_at(H, tl + 1));
    return cont;
  }
  return 0;
}

INLINE void task_deal(DEV u64* H, Term join, u32 base, u32 stride, TG u32* cur) {
  u64 loc = term_loc(join);
  u32 ar  = fid_arity((u32)term_aux(join));
  u32 g   = 0;
  if (stride == 0) {
    u32 rem = (u32)H[loc + ar + 1];
    g = a32_add(a32_at(H, H_CURSOR), rem);
  }
  for (u32 i = 0; i < ar; i += 1) {
    Term k = H[loc + i];
    if (term_tag(k) == TAG_TSK) {
      H[loc + i] = TERM_HOLE;
      u32 to;
      if (stride != 0) {
        to = ring_pick(base, stride, cur);
      } else {
        to = ring_flip(g & (u32)(LANES - 1));
        g += 1;
      }
      ring_push(H, to, k);
    }
  }
}

// Root
// ====

INLINE bool root_done(DEV u64* H) {
  return a32_load_acq(a32_at(H, H_ROOT_DONE)) != 0;
}

static u32 root_take(DEV u64* H, THR Term* v) {
  u32 n = a32_load_acq(a32_at(H, H_ROOT_DONE)) - 1;
  for (u32 j = 0; j < n; j += 1) {
    v[j] = H[H_ROOT_WORD + j];
  }
  a32_store(a32_at(H, H_ROOT_DONE), 0);
  return n;
}

// Spins
// =====

CONSTV u64 STAT_IMG[] = { 44ull, term_pak(CID_SNIL, 0), 58ull, term_pak(CID_SNIL, 0), 116ull, term_pak(CID_SNIL, 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 4), 101ull, term_ctr(CID_SCON, STAT_OFF + 6), 115ull, term_ctr(CID_SCON, STAT_OFF + 8), 98ull, term_ctr(CID_SCON, STAT_OFF + 10), 97ull, term_ctr(CID_SCON, STAT_OFF + 12), 101ull, term_ctr(CID_SCON, STAT_OFF + 10), 114ull, term_ctr(CID_SCON, STAT_OFF + 16), 112ull, term_ctr(CID_SCON, STAT_OFF + 18), 48ull, term_pak(CID_SNIL, 0), 101ull, term_pak(CID_SNIL, 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 24), 111ull, term_ctr(CID_SCON, STAT_OFF + 26), 110ull, term_ctr(CID_SCON, STAT_OFF + 28), 124ull, term_pak(CID_SNIL, 0), 103ull, term_pak(CID_SNIL, 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 34), 105ull, term_ctr(CID_SCON, STAT_OFF + 36), 115ull, term_ctr(CID_SCON, STAT_OFF + 38), 115ull, term_ctr(CID_SCON, STAT_OFF + 40), 105ull, term_ctr(CID_SCON, STAT_OFF + 42), 109ull, term_ctr(CID_SCON, STAT_OFF + 44), 100ull, term_pak(CID_SNIL, 0), 101ull, term_ctr(CID_SCON, STAT_OFF + 48), 100ull, term_ctr(CID_SCON, STAT_OFF + 50), 100ull, term_ctr(CID_SCON, STAT_OFF + 52), 97ull, term_ctr(CID_SCON, STAT_OFF + 54), 103ull, term_ctr(CID_SCON, STAT_OFF + 50), 110ull, term_ctr(CID_SCON, STAT_OFF + 58), 97ull, term_ctr(CID_SCON, STAT_OFF + 60), 104ull, term_ctr(CID_SCON, STAT_OFF + 62), 99ull, term_ctr(CID_SCON, STAT_OFF + 64), 118ull, term_ctr(CID_SCON, STAT_OFF + 50), 111ull, term_ctr(CID_SCON, STAT_OFF + 68), 109ull, term_ctr(CID_SCON, STAT_OFF + 70), 101ull, term_ctr(CID_SCON, STAT_OFF + 72), 114ull, term_ctr(CID_SCON, STAT_OFF + 74), 110ull, term_ctr(CID_SCON, STAT_OFF + 66), 117ull, term_ctr(CID_SCON, STAT_OFF + 78), 104ull, term_pak(CID_SNIL, 0), 99ull, term_ctr(CID_SCON, STAT_OFF + 82), 116ull, term_ctr(CID_SCON, STAT_OFF + 84), 97ull, term_ctr(CID_SCON, STAT_OFF + 86), 109ull, term_ctr(CID_SCON, STAT_OFF + 88), 115ull, term_ctr(CID_SCON, STAT_OFF + 90), 105ull, term_ctr(CID_SCON, STAT_OFF + 92), 109ull, term_ctr(CID_SCON, STAT_OFF + 94), 100ull, term_ctr(CID_SCON, STAT_OFF + 2), 101ull, term_ctr(CID_SCON, STAT_OFF + 98), 116ull, term_ctr(CID_SCON, STAT_OFF + 100), 99ull, term_ctr(CID_SCON, STAT_OFF + 102), 101ull, term_ctr(CID_SCON, STAT_OFF + 104), 106ull, term_ctr(CID_SCON, STAT_OFF + 106), 101ull, term_ctr(CID_SCON, STAT_OFF + 108), 114ull, term_ctr(CID_SCON, STAT_OFF + 110), 101ull, term_ctr(CID_SCON, STAT_OFF + 2), 112ull, term_ctr(CID_SCON, STAT_OFF + 114), 97ull, term_ctr(CID_SCON, STAT_OFF + 116), 104ull, term_ctr(CID_SCON, STAT_OFF + 118), 115ull, term_ctr(CID_SCON, STAT_OFF + 120), 99ull, term_ctr(CID_SCON, STAT_OFF + 50), 97ull, term_ctr(CID_SCON, STAT_OFF + 124), 108ull, term_ctr(CID_SCON, STAT_OFF + 126), 112ull, term_ctr(CID_SCON, STAT_OFF + 128), 49ull, term_ctr(CID_SCON, STAT_OFF + 2), 116ull, term_ctr(CID_SCON, STAT_OFF + 132), 114ull, term_ctr(CID_SCON, STAT_OFF + 134), 101ull, term_ctr(CID_SCON, STAT_OFF + 136), 115ull, term_ctr(CID_SCON, STAT_OFF + 138), 110ull, term_ctr(CID_SCON, STAT_OFF + 140), 105ull, term_ctr(CID_SCON, STAT_OFF + 142), 50ull, term_ctr(CID_SCON, STAT_OFF + 2), 116ull, term_ctr(CID_SCON, STAT_OFF + 146), 114ull, term_ctr(CID_SCON, STAT_OFF + 148), 101ull, term_ctr(CID_SCON, STAT_OFF + 150), 115ull, term_ctr(CID_SCON, STAT_OFF + 152), 110ull, term_ctr(CID_SCON, STAT_OFF + 154), 105ull, term_ctr(CID_SCON, STAT_OFF + 156), 52ull, term_ctr(CID_SCON, STAT_OFF + 2), 116ull, term_ctr(CID_SCON, STAT_OFF + 160), 114ull, term_ctr(CID_SCON, STAT_OFF + 162), 101ull, term_ctr(CID_SCON, STAT_OFF + 164), 115ull, term_ctr(CID_SCON, STAT_OFF + 166), 110ull, term_ctr(CID_SCON, STAT_OFF + 168), 105ull, term_ctr(CID_SCON, STAT_OFF + 170), 56ull, term_ctr(CID_SCON, STAT_OFF + 2), 116ull, term_ctr(CID_SCON, STAT_OFF + 174), 114ull, term_ctr(CID_SCON, STAT_OFF + 176), 101ull, term_ctr(CID_SCON, STAT_OFF + 178), 115ull, term_ctr(CID_SCON, STAT_OFF + 180), 110ull, term_ctr(CID_SCON, STAT_OFF + 182), 105ull, term_ctr(CID_SCON, STAT_OFF + 184), 55ull, term_ctr(CID_SCON, STAT_OFF + 2), 51ull, term_ctr(CID_SCON, STAT_OFF + 188), 53ull, term_ctr(CID_SCON, STAT_OFF + 190), 53ull, term_ctr(CID_SCON, STAT_OFF + 192), 54ull, term_ctr(CID_SCON, STAT_OFF + 194), 116ull, term_ctr(CID_SCON, STAT_OFF + 196), 114ull, term_ctr(CID_SCON, STAT_OFF + 198), 101ull, term_ctr(CID_SCON, STAT_OFF + 200), 115ull, term_ctr(CID_SCON, STAT_OFF + 202), 110ull, term_ctr(CID_SCON, STAT_OFF + 204), 105ull, term_ctr(CID_SCON, STAT_OFF + 206), 116ull, term_ctr(CID_SCON, STAT_OFF + 2), 115ull, term_ctr(CID_SCON, STAT_OFF + 210), 114ull, term_ctr(CID_SCON, STAT_OFF + 212), 105ull, term_ctr(CID_SCON, STAT_OFF + 214), 102ull, term_ctr(CID_SCON, STAT_OFF + 216), 110ull, term_ctr(CID_SCON, STAT_OFF + 2), 105ull, term_ctr(CID_SCON, STAT_OFF + 220), 97ull, term_ctr(CID_SCON, STAT_OFF + 222), 109ull, term_ctr(CID_SCON, STAT_OFF + 224), 45ull, term_ctr(CID_SCON, STAT_OFF + 226), 111ull, term_ctr(CID_SCON, STAT_OFF + 228), 110ull, term_ctr(CID_SCON, STAT_OFF + 230), 108ull, term_ctr(CID_SCON, STAT_OFF + 114), 100ull, term_ctr(CID_SCON, STAT_OFF + 234), 100ull, term_ctr(CID_SCON, STAT_OFF + 236), 105ull, term_ctr(CID_SCON, STAT_OFF + 238), 109ull, term_ctr(CID_SCON, STAT_OFF + 240), 97ull, term_ctr(CID_SCON, STAT_OFF + 212), 108ull, term_ctr(CID_SCON, STAT_OFF + 244), 100ull, term_ctr(CID_SCON, STAT_OFF + 246), 108ull, term_ctr(CID_SCON, STAT_OFF + 248), 111ull, term_ctr(CID_SCON, STAT_OFF + 250), 111ull, term_ctr(CID_SCON, STAT_OFF + 2), 114ull, term_ctr(CID_SCON, STAT_OFF + 254), 101ull, term_ctr(CID_SCON, STAT_OFF + 256), 122ull, term_ctr(CID_SCON, STAT_OFF + 258), 111ull, term_ctr(CID_SCON, STAT_OFF + 234), 104ull, term_ctr(CID_SCON, STAT_OFF + 262), 117ull, term_ctr(CID_SCON, STAT_OFF + 210), 111ull, term_ctr(CID_SCON, STAT_OFF + 266), 120ull, term_ctr(CID_SCON, STAT_OFF + 2), 97ull, term_ctr(CID_SCON, STAT_OFF + 270), 109ull, term_ctr(CID_SCON, STAT_OFF + 272), 112ull, term_ctr(CID_SCON, STAT_OFF + 2), 105ull, term_ctr(CID_SCON, STAT_OFF + 276), 114ull, term_ctr(CID_SCON, STAT_OFF + 278), 116ull, term_ctr(CID_SCON, STAT_OFF + 280), 100ull, term_ctr(CID_SCON, STAT_OFF + 282), 110ull, term_ctr(CID_SCON, STAT_OFF + 284), 117ull, term_ctr(CID_SCON, STAT_OFF + 286), 111ull, term_ctr(CID_SCON, STAT_OFF + 288), 114ull, term_ctr(CID_SCON, STAT_OFF + 290), 104ull, term_ctr(CID_SCON, STAT_OFF + 2), 99ull, term_ctr(CID_SCON, STAT_OFF + 294), 116ull, term_ctr(CID_SCON, STAT_OFF + 296), 97ull, term_ctr(CID_SCON, STAT_OFF + 298), 109ull, term_ctr(CID_SCON, STAT_OFF + 300), 115ull, term_ctr(CID_SCON, STAT_OFF + 302), 105ull, term_ctr(CID_SCON, STAT_OFF + 304), 109ull, term_ctr(CID_SCON, STAT_OFF + 306), 103ull, term_ctr(CID_SCON, STAT_OFF + 220), 105ull, term_ctr(CID_SCON, STAT_OFF + 310), 101ull, term_ctr(CID_SCON, STAT_OFF + 312), 114ull, term_ctr(CID_SCON, STAT_OFF + 314), 111ull, term_ctr(CID_SCON, STAT_OFF + 316), 102ull, term_ctr(CID_SCON, STAT_OFF + 318), 107ull, term_ctr(CID_SCON, STAT_OFF + 100), 114ull, term_ctr(CID_SCON, STAT_OFF + 322), 97ull, term_ctr(CID_SCON, STAT_OFF + 324), 109ull, term_ctr(CID_SCON, STAT_OFF + 326), 48ull, term_ctr(CID_SCON, STAT_OFF + 2), 116ull, term_ctr(CID_SCON, STAT_OFF + 330), 99ull, term_ctr(CID_SCON, STAT_OFF + 332), 101ull, term_ctr(CID_SCON, STAT_OFF + 334), 106ull, term_ctr(CID_SCON, STAT_OFF + 336), 101ull, term_ctr(CID_SCON, STAT_OFF + 338), 114ull, term_ctr(CID_SCON, STAT_OFF + 340), 116ull, term_ctr(CID_SCON, STAT_OFF + 274), 99ull, term_ctr(CID_SCON, STAT_OFF + 344), 101ull, term_ctr(CID_SCON, STAT_OFF + 346), 106ull, term_ctr(CID_SCON, STAT_OFF + 348), 101ull, term_ctr(CID_SCON, STAT_OFF + 350), 114ull, term_ctr(CID_SCON, STAT_OFF + 352), 105ull, term_ctr(CID_SCON, STAT_OFF + 100), 112ull, term_ctr(CID_SCON, STAT_OFF + 356), 117ull, term_ctr(CID_SCON, STAT_OFF + 358), 99ull, term_ctr(CID_SCON, STAT_OFF + 360), 99ull, term_ctr(CID_SCON, STAT_OFF + 362), 111ull, term_ctr(CID_SCON, STAT_OFF + 364), 116ull, term_ctr(CID_SCON, STAT_OFF + 366), 99ull, term_ctr(CID_SCON, STAT_OFF + 368), 101ull, term_ctr(CID_SCON, STAT_OFF + 370), 106ull, term_ctr(CID_SCON, STAT_OFF + 372), 101ull, term_ctr(CID_SCON, STAT_OFF + 374), 114ull, term_ctr(CID_SCON, STAT_OFF + 376), 45ull, term_ctr(CID_SCON, STAT_OFF + 218), 100ull, term_ctr(CID_SCON, STAT_OFF + 380), 101ull, term_ctr(CID_SCON, STAT_OFF + 382), 110ull, term_ctr(CID_SCON, STAT_OFF + 384), 105ull, term_ctr(CID_SCON, STAT_OFF + 386), 97ull, term_ctr(CID_SCON, STAT_OFF + 388), 116ull, term_ctr(CID_SCON, STAT_OFF + 390), 101ull, term_ctr(CID_SCON, STAT_OFF + 392), 114ull, term_ctr(CID_SCON, STAT_OFF + 394), 45ull, term_ctr(CID_SCON, STAT_OFF + 246), 100ull, term_ctr(CID_SCON, STAT_OFF + 398), 101ull, term_ctr(CID_SCON, STAT_OFF + 400), 110ull, term_ctr(CID_SCON, STAT_OFF + 402), 105ull, term_ctr(CID_SCON, STAT_OFF + 404), 97ull, term_ctr(CID_SCON, STAT_OFF + 406), 116ull, term_ctr(CID_SCON, STAT_OFF + 408), 101ull, term_ctr(CID_SCON, STAT_OFF + 410), 114ull, term_ctr(CID_SCON, STAT_OFF + 412), 100ull, term_ctr(CID_SCON, STAT_OFF + 98), 97ull, term_ctr(CID_SCON, STAT_OFF + 416), 45ull, term_ctr(CID_SCON, STAT_OFF + 418), 110ull, term_ctr(CID_SCON, STAT_OFF + 420), 105ull, term_ctr(CID_SCON, STAT_OFF + 422), 97ull, term_ctr(CID_SCON, STAT_OFF + 424), 109ull, term_ctr(CID_SCON, STAT_OFF + 426), 100ull, term_ctr(CID_SCON, STAT_OFF + 100), 100ull, term_ctr(CID_SCON, STAT_OFF + 430), 97ull, term_ctr(CID_SCON, STAT_OFF + 432), 45ull, term_ctr(CID_SCON, STAT_OFF + 434), 110ull, term_ctr(CID_SCON, STAT_OFF + 436), 105ull, term_ctr(CID_SCON, STAT_OFF + 438), 97ull, term_ctr(CID_SCON, STAT_OFF + 440), 109ull, term_ctr(CID_SCON, STAT_OFF + 442), 103ull, term_ctr(CID_SCON, STAT_OFF + 114), 110ull, term_ctr(CID_SCON, STAT_OFF + 446), 97ull, term_ctr(CID_SCON, STAT_OFF + 448), 104ull, term_ctr(CID_SCON, STAT_OFF + 450), 99ull, term_ctr(CID_SCON, STAT_OFF + 452), 45ull, term_ctr(CID_SCON, STAT_OFF + 454), 110ull, term_ctr(CID_SCON, STAT_OFF + 456), 105ull, term_ctr(CID_SCON, STAT_OFF + 458), 97ull, term_ctr(CID_SCON, STAT_OFF + 460), 109ull, term_ctr(CID_SCON, STAT_OFF + 462), 103ull, term_ctr(CID_SCON, STAT_OFF + 100), 110ull, term_ctr(CID_SCON, STAT_OFF + 466), 97ull, term_ctr(CID_SCON, STAT_OFF + 468), 104ull, term_ctr(CID_SCON, STAT_OFF + 470), 99ull, term_ctr(CID_SCON, STAT_OFF + 472), 45ull, term_ctr(CID_SCON, STAT_OFF + 474), 110ull, term_ctr(CID_SCON, STAT_OFF + 476), 105ull, term_ctr(CID_SCON, STAT_OFF + 478), 97ull, term_ctr(CID_SCON, STAT_OFF + 480), 109ull, term_ctr(CID_SCON, STAT_OFF + 482), 118ull, term_ctr(CID_SCON, STAT_OFF + 114), 111ull, term_ctr(CID_SCON, STAT_OFF + 486), 109ull, term_ctr(CID_SCON, STAT_OFF + 488), 101ull, term_ctr(CID_SCON, STAT_OFF + 490), 114ull, term_ctr(CID_SCON, STAT_OFF + 492), 45ull, term_ctr(CID_SCON, STAT_OFF + 494), 110ull, term_ctr(CID_SCON, STAT_OFF + 496), 105ull, term_ctr(CID_SCON, STAT_OFF + 498), 97ull, term_ctr(CID_SCON, STAT_OFF + 500), 109ull, term_ctr(CID_SCON, STAT_OFF + 502), 118ull, term_ctr(CID_SCON, STAT_OFF + 100), 111ull, term_ctr(CID_SCON, STAT_OFF + 506), 109ull, term_ctr(CID_SCON, STAT_OFF + 508), 101ull, term_ctr(CID_SCON, STAT_OFF + 510), 114ull, term_ctr(CID_SCON, STAT_OFF + 512), 45ull, term_ctr(CID_SCON, STAT_OFF + 514), 110ull, term_ctr(CID_SCON, STAT_OFF + 516), 105ull, term_ctr(CID_SCON, STAT_OFF + 518), 97ull, term_ctr(CID_SCON, STAT_OFF + 520), 109ull, term_ctr(CID_SCON, STAT_OFF + 522), 103ull, term_ctr(CID_SCON, STAT_OFF + 224), 97ull, term_ctr(CID_SCON, STAT_OFF + 526), 45ull, term_ctr(CID_SCON, STAT_OFF + 528), 110ull, term_ctr(CID_SCON, STAT_OFF + 530), 105ull, term_ctr(CID_SCON, STAT_OFF + 532), 97ull, term_ctr(CID_SCON, STAT_OFF + 534), 109ull, term_ctr(CID_SCON, STAT_OFF + 536), 110ull, term_ctr(CID_SCON, STAT_OFF + 474), 117ull, term_ctr(CID_SCON, STAT_OFF + 540), 45ull, term_ctr(CID_SCON, STAT_OFF + 542), 110ull, term_ctr(CID_SCON, STAT_OFF + 544), 105ull, term_ctr(CID_SCON, STAT_OFF + 546), 97ull, term_ctr(CID_SCON, STAT_OFF + 548), 109ull, term_ctr(CID_SCON, STAT_OFF + 550), 97ull, term_ctr(CID_SCON, STAT_OFF + 234), 116ull, term_ctr(CID_SCON, STAT_OFF + 554), 115ull, term_ctr(CID_SCON, STAT_OFF + 556), 45ull, term_ctr(CID_SCON, STAT_OFF + 558), 110ull, term_ctr(CID_SCON, STAT_OFF + 560), 105ull, term_ctr(CID_SCON, STAT_OFF + 562), 97ull, term_ctr(CID_SCON, STAT_OFF + 564), 109ull, term_ctr(CID_SCON, STAT_OFF + 566), 110ull, term_ctr(CID_SCON, STAT_OFF + 114), 111ull, term_ctr(CID_SCON, STAT_OFF + 570), 116ull, term_ctr(CID_SCON, STAT_OFF + 572), 115ull, term_ctr(CID_SCON, STAT_OFF + 574), 98ull, term_ctr(CID_SCON, STAT_OFF + 576), 109ull, term_ctr(CID_SCON, STAT_OFF + 578), 111ull, term_ctr(CID_SCON, STAT_OFF + 580), 116ull, term_ctr(CID_SCON, STAT_OFF + 582), 116ull, term_ctr(CID_SCON, STAT_OFF + 496), 97ull, term_ctr(CID_SCON, STAT_OFF + 586), 101ull, term_ctr(CID_SCON, STAT_OFF + 588), 112ull, term_ctr(CID_SCON, STAT_OFF + 590), 101ull, term_ctr(CID_SCON, STAT_OFF + 592), 114ull, term_ctr(CID_SCON, STAT_OFF + 594), 108ull, term_ctr(CID_SCON, STAT_OFF + 2), 108ull, term_ctr(CID_SCON, STAT_OFF + 598), 97ull, term_ctr(CID_SCON, STAT_OFF + 600), 116ull, term_ctr(CID_SCON, STAT_OFF + 602), 115ull, term_ctr(CID_SCON, STAT_OFF + 604), 110ull, term_ctr(CID_SCON, STAT_OFF + 606), 105ull, term_ctr(CID_SCON, STAT_OFF + 608), 101ull, term_ctr(CID_SCON, STAT_OFF + 610), 114ull, term_ctr(CID_SCON, STAT_OFF + 612), 108ull, term_ctr(CID_SCON, STAT_OFF + 100), 108ull, term_ctr(CID_SCON, STAT_OFF + 616), 97ull, term_ctr(CID_SCON, STAT_OFF + 618), 116ull, term_ctr(CID_SCON, STAT_OFF + 620), 115ull, term_ctr(CID_SCON, STAT_OFF + 622), 110ull, term_ctr(CID_SCON, STAT_OFF + 624), 105ull, term_ctr(CID_SCON, STAT_OFF + 626), 101ull, term_ctr(CID_SCON, STAT_OFF + 628), 114ull, term_ctr(CID_SCON, STAT_OFF + 630) };

INLINE Term spin_0(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term _v_1 = 0;
  u32 _c_0 = r0;
  Term _a_1 = r1;
  Term _b_1 = r2;
  WL_SPIN
    if (_c_0 == 0) {
      term_sink(e, _a_1);
      _v_1 = _b_1;
    } else {
      term_sink(e, _b_1);
      _v_1 = _a_1;
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_1(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5, u32 r6, Term r7, u64 q7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h7 = r7;
  Term _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _columns_0 = r0;
  Term _columns_1 = r1;
  Term _columns_2 = r2;
  Term _columns_3 = r3;
  u32 _index_0 = r4;
  u32 _meta_0 = r5;
  u32 _meta_1 = r6;
  Term _meta_2 = r7;
  u32 _meta_3 = r8;
  u32 _meta_4 = r9;
  WL_SPIN
    Term _at_0 = _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0);
    Term _at_1 = blk_at(_columns_0, _index_0, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    blk_write(e.mem, 0, _at_0, _at_1 + 0, _meta_0);
    Term _at_2 = _columns_1 == h1 ? q1 : blk_loc(e.mem, _columns_1);
    Term _at_3 = blk_at(_columns_1, _index_0, 1);
    u32 _c_1 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
    Term _c_2 = e.mem[_at_2 + _at_3 + 1];
    blk_write(e.mem, 1, _at_2, _at_3 + 0, _meta_1);
    blk_write(e.mem, 1, _at_2, _at_3 + 1, _meta_2);
    term_sink(e, _c_2);
    Term _at_4 = _columns_2 == h2 ? q2 : blk_loc(e.mem, _columns_2);
    Term _at_5 = blk_at(_columns_2, _index_0, 0);
    u32 _c_3 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    blk_write(e.mem, 0, _at_4, _at_5 + 0, _meta_3);
    Term _at_6 = _columns_3 == h3 ? q3 : blk_loc(e.mem, _columns_3);
    Term _at_7 = blk_at(_columns_3, _index_0, 0);
    u32 _c_4 = blk_read(e.mem, 0, _at_6, _at_7 + 0);
    blk_write(e.mem, 0, _at_6, _at_7 + 0, _meta_4);
    _v_8 = _columns_0;
    _v_9 = _columns_1;
    _v_10 = _columns_2;
    _v_11 = _columns_3;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  return 1;
}

INLINE Term spin_2(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, Term r10, u64 q10, u32 r11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, Term r17, u64 q17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h10 = r10;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  Term h16 = r16;
  Term h17 = r17;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  u32 _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  Term _v_28 = 0;
  u32 _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _namespace_2 = r0;
  u32 _next_2 = r1;
  Term _aux_2 = r2;
  Term _metadata_8 = r3;
  Term _metadata_9 = r4;
  Term _metadata_10 = r5;
  Term _metadata_11 = r6;
  u32 _capacity_2 = r7;
  Term _depth_2 = r8;
  u32 _high_2 = r9;
  Term _pending_2 = r10;
  u32 _ledger_4 = r11;
  Term _ledger_5 = r12;
  Term _mode_2 = r13;
  Term _main_0 = r14;
  u32 _index_2 = r15;
  Term _result_4 = r16;
  Term _result_5 = r17;
  WL_SPIN
    Term _at_0 = _main_0 == h14 ? q14 : blk_loc(e.mem, _main_0);
    Term _at_1 = blk_at(_main_0, _index_2, 1);
    u32 _c_0 = blk_read(e.mem, 1, _at_0, _at_1 + 0);
    Term _c_1 = e.mem[_at_0 + _at_1 + 1];
    blk_write(e.mem, 1, _at_0, _at_1 + 0, 1);
    blk_write(e.mem, 1, _at_0, _at_1 + 1, _result_4);
    term_sink(e, _c_1);
    _v_17 = _namespace_2;
    _v_18 = _next_2;
    _v_19 = _main_0;
    _v_20 = _aux_2;
    _v_21 = _metadata_8;
    _v_22 = _metadata_9;
    _v_23 = _metadata_10;
    _v_24 = _metadata_11;
    _v_25 = _capacity_2;
    _v_26 = _depth_2;
    _v_27 = _high_2;
    _v_28 = _pending_2;
    _v_29 = _ledger_4;
    _v_30 = _ledger_5;
    _v_31 = _mode_2;
    _v_32 = 0;
    _v_33 = _result_5;
  break;
  }
  o[0] = _v_17;
  o[1] = _v_18;
  o[2] = _v_19;
  o[3] = _v_20;
  o[4] = _v_21;
  o[5] = _v_22;
  o[6] = _v_23;
  o[7] = _v_24;
  o[8] = _v_25;
  o[9] = _v_26;
  o[10] = _v_27;
  o[11] = _v_28;
  o[12] = _v_29;
  o[13] = _v_30;
  o[14] = _v_31;
  o[15] = _v_32;
  o[16] = _v_33;
  return 1;
}

INLINE Term spin_3(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_10 = 0;
  u32 _a_0 = r0;
  u32 _b_0 = r1;
  WL_SPIN
    u32 _x_0 = ((_a_0 >> 0) & 1);
    u32 _x_1 = ((_a_0 >> 1) & 1);
    u32 _x_2 = ((_a_0 >> 2) & 1);
    u32 _x_3 = ((_a_0 >> 3) & 1);
    u32 _x_4 = ((_a_0 >> 4) & 1);
    u32 _x_5 = ((_a_0 >> 5) & 1);
    u32 _x_6 = ((_a_0 >> 6) & 1);
    u32 _x_7 = ((_a_0 >> 7) & 1);
    u32 _x_8 = ((_a_0 >> 8) & 1);
    u32 _x_9 = ((_a_0 >> 9) & 1);
    u32 _x_10 = ((_a_0 >> 10) & 1);
    u32 _x_11 = ((_a_0 >> 11) & 1);
    u32 _x_12 = ((_a_0 >> 12) & 1);
    u32 _x_13 = ((_a_0 >> 13) & 1);
    u32 _x_14 = ((_a_0 >> 14) & 1);
    u32 _x_15 = ((_a_0 >> 15) & 1);
    u32 _x_16 = ((_a_0 >> 16) & 1);
    u32 _x_17 = ((_a_0 >> 17) & 1);
    u32 _x_18 = ((_a_0 >> 18) & 1);
    u32 _x_19 = ((_a_0 >> 19) & 1);
    u32 _x_20 = ((_a_0 >> 20) & 1);
    u32 _x_21 = ((_a_0 >> 21) & 1);
    u32 _x_22 = ((_a_0 >> 22) & 1);
    u32 _x_23 = ((_a_0 >> 23) & 1);
    u32 _x_24 = ((_a_0 >> 24) & 1);
    u32 _x_25 = ((_a_0 >> 25) & 1);
    u32 _x_26 = ((_a_0 >> 26) & 1);
    u32 _x_27 = ((_a_0 >> 27) & 1);
    u32 _x_28 = ((_a_0 >> 28) & 1);
    u32 _x_29 = ((_a_0 >> 29) & 1);
    u32 _x_30 = ((_a_0 >> 30) & 1);
    u32 _x_31 = ((_a_0 >> 31) & 1);
    u32 _y_0 = ((_b_0 >> 0) & 1);
    u32 _y_1 = ((_b_0 >> 1) & 1);
    u32 _y_2 = ((_b_0 >> 2) & 1);
    u32 _y_3 = ((_b_0 >> 3) & 1);
    u32 _y_4 = ((_b_0 >> 4) & 1);
    u32 _y_5 = ((_b_0 >> 5) & 1);
    u32 _y_6 = ((_b_0 >> 6) & 1);
    u32 _y_7 = ((_b_0 >> 7) & 1);
    u32 _y_8 = ((_b_0 >> 8) & 1);
    u32 _y_9 = ((_b_0 >> 9) & 1);
    u32 _y_10 = ((_b_0 >> 10) & 1);
    u32 _y_11 = ((_b_0 >> 11) & 1);
    u32 _y_12 = ((_b_0 >> 12) & 1);
    u32 _y_13 = ((_b_0 >> 13) & 1);
    u32 _y_14 = ((_b_0 >> 14) & 1);
    u32 _y_15 = ((_b_0 >> 15) & 1);
    u32 _y_16 = ((_b_0 >> 16) & 1);
    u32 _y_17 = ((_b_0 >> 17) & 1);
    u32 _y_18 = ((_b_0 >> 18) & 1);
    u32 _y_19 = ((_b_0 >> 19) & 1);
    u32 _y_20 = ((_b_0 >> 20) & 1);
    u32 _y_21 = ((_b_0 >> 21) & 1);
    u32 _y_22 = ((_b_0 >> 22) & 1);
    u32 _y_23 = ((_b_0 >> 23) & 1);
    u32 _y_24 = ((_b_0 >> 24) & 1);
    u32 _y_25 = ((_b_0 >> 25) & 1);
    u32 _y_26 = ((_b_0 >> 26) & 1);
    u32 _y_27 = ((_b_0 >> 27) & 1);
    u32 _y_28 = ((_b_0 >> 28) & 1);
    u32 _y_29 = ((_b_0 >> 29) & 1);
    u32 _y_30 = ((_b_0 >> 30) & 1);
    u32 _y_31 = ((_b_0 >> 31) & 1);
    Term _v_11 = 0;
    Term _o_1[1];
    Term _a_1 = (((u64)_y_0 << 0) | ((u64)_y_1 << 1) | ((u64)_y_2 << 2) | ((u64)_y_3 << 3) | ((u64)_y_4 << 4) | ((u64)_y_5 << 5) | ((u64)_y_6 << 6) | ((u64)_y_7 << 7) | ((u64)_y_8 << 8) | ((u64)_y_9 << 9) | ((u64)_y_10 << 10) | ((u64)_y_11 << 11) | ((u64)_y_12 << 12) | ((u64)_y_13 << 13) | ((u64)_y_14 << 14) | ((u64)_y_15 << 15) | ((u64)_y_16 << 16) | ((u64)_y_17 << 17) | ((u64)_y_18 << 18) | ((u64)_y_19 << 19) | ((u64)_y_20 << 20) | ((u64)_y_21 << 21) | ((u64)_y_22 << 22) | ((u64)_y_23 << 23) | ((u64)_y_24 << 24) | ((u64)_y_25 << 25) | ((u64)_y_26 << 26) | ((u64)_y_27 << 27) | ((u64)_y_28 << 28) | ((u64)_y_29 << 29) | ((u64)_y_30 << 30) | ((u64)_y_31 << 31));
    Term _a_2 = (((u64)_x_0 << 0) | ((u64)_x_1 << 1) | ((u64)_x_2 << 2) | ((u64)_x_3 << 3) | ((u64)_x_4 << 4) | ((u64)_x_5 << 5) | ((u64)_x_6 << 6) | ((u64)_x_7 << 7) | ((u64)_x_8 << 8) | ((u64)_x_9 << 9) | ((u64)_x_10 << 10) | ((u64)_x_11 << 11) | ((u64)_x_12 << 12) | ((u64)_x_13 << 13) | ((u64)_x_14 << 14) | ((u64)_x_15 << 15) | ((u64)_x_16 << 16) | ((u64)_x_17 << 17) | ((u64)_x_18 << 18) | ((u64)_x_19 << 19) | ((u64)_x_20 << 20) | ((u64)_x_21 << 21) | ((u64)_x_22 << 22) | ((u64)_x_23 << 23) | ((u64)_x_24 << 24) | ((u64)_x_25 << 25) | ((u64)_x_26 << 26) | ((u64)_x_27 << 27) | ((u64)_x_28 << 28) | ((u64)_x_29 << 29) | ((u64)_x_30 << 30) | ((u64)_x_31 << 31));
    if (spin_0(e, _o_1, U32_BIN((((u64)_x_0 << 0) | ((u64)_x_1 << 1) | ((u64)_x_2 << 2) | ((u64)_x_3 << 3) | ((u64)_x_4 << 4) | ((u64)_x_5 << 5) | ((u64)_x_6 << 6) | ((u64)_x_7 << 7) | ((u64)_x_8 << 8) | ((u64)_x_9 << 9) | ((u64)_x_10 << 10) | ((u64)_x_11 << 11) | ((u64)_x_12 << 12) | ((u64)_x_13 << 13) | ((u64)_x_14 << 14) | ((u64)_x_15 << 15) | ((u64)_x_16 << 16) | ((u64)_x_17 << 17) | ((u64)_x_18 << 18) | ((u64)_x_19 << 19) | ((u64)_x_20 << 20) | ((u64)_x_21 << 21) | ((u64)_x_22 << 22) | ((u64)_x_23 << 23) | ((u64)_x_24 << 24) | ((u64)_x_25 << 25) | ((u64)_x_26 << 26) | ((u64)_x_27 << 27) | ((u64)_x_28 << 28) | ((u64)_x_29 << 29) | ((u64)_x_30 << 30) | ((u64)_x_31 << 31)), <, (((u64)_y_0 << 0) | ((u64)_y_1 << 1) | ((u64)_y_2 << 2) | ((u64)_y_3 << 3) | ((u64)_y_4 << 4) | ((u64)_y_5 << 5) | ((u64)_y_6 << 6) | ((u64)_y_7 << 7) | ((u64)_y_8 << 8) | ((u64)_y_9 << 9) | ((u64)_y_10 << 10) | ((u64)_y_11 << 11) | ((u64)_y_12 << 12) | ((u64)_y_13 << 13) | ((u64)_y_14 << 14) | ((u64)_y_15 << 15) | ((u64)_y_16 << 16) | ((u64)_y_17 << 17) | ((u64)_y_18 << 18) | ((u64)_y_19 << 19) | ((u64)_y_20 << 20) | ((u64)_y_21 << 21) | ((u64)_y_22 << 22) | ((u64)_y_23 << 23) | ((u64)_y_24 << 24) | ((u64)_y_25 << 25) | ((u64)_y_26 << 26) | ((u64)_y_27 << 27) | ((u64)_y_28 << 28) | ((u64)_y_29 << 29) | ((u64)_y_30 << 30) | ((u64)_y_31 << 31))), _a_1, blk_loc(e.mem, _a_1), _a_2, blk_loc(e.mem, _a_2)) == 0) {
      return 0;
    }
    _v_11 = _o_1[0];
    _v_10 = _v_11;
  break;
  }
  o[0] = _v_10;
  return 1;
}

INLINE Term spin_6(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h12 = r12;
  Term h14 = r14;
  Term h16 = r16;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _main_1 = r0;
  Term _aux_1 = r1;
  Term _metadata_4 = r2;
  Term _metadata_5 = r3;
  Term _metadata_6 = r4;
  Term _metadata_7 = r5;
  u32 _capacity_1 = r6;
  Term _depth_1 = r7;
  u32 _high_1 = r8;
  u32 _live_0 = r9;
  u32 _row_9 = r10;
  u32 _row_10 = r11;
  Term _row_11 = r12;
  u32 _row_12 = r13;
  Term _row_13 = r14;
  u32 _row_14 = r15;
  Term _row_15 = r16;
  u32 _row_16 = r17;
  u32 _row_17 = r18;
  WL_SPIN
    if (_live_0 == 1) {
      _v_19 = 1;
      _v_20 = _main_1;
      _v_21 = _aux_1;
      _v_22 = _metadata_4;
      _v_23 = _metadata_5;
      _v_24 = _metadata_6;
      _v_25 = _metadata_7;
      _v_26 = _capacity_1;
      _v_27 = _depth_1;
      _v_28 = _high_1;
      _v_29 = _row_9;
      _v_30 = _row_10;
      _v_31 = _row_11;
      _v_32 = _row_12;
      _v_33 = _row_13;
      _v_34 = _row_14;
      _v_35 = _row_15;
      _v_36 = _row_16;
      _v_37 = _row_17;
    } else {
      Term _at_0 = _main_1 == h0 ? q0 : blk_loc(e.mem, _main_1);
      Term _at_1 = blk_at(_main_1, U32_BIN(_row_9, -, 1ull), 1);
      u32 _c_0 = blk_read(e.mem, 1, _at_0, _at_1 + 0);
      Term _c_1 = e.mem[_at_0 + _at_1 + 1];
      blk_write(e.mem, 1, _at_0, _at_1 + 0, _row_10);
      blk_write(e.mem, 1, _at_0, _at_1 + 1, _row_11);
      term_sink(e, _c_1);
      Term _at_2 = _aux_1 == h1 ? q1 : blk_loc(e.mem, _aux_1);
      Term _at_3 = blk_at(_aux_1, U32_BIN(_row_9, -, 1ull), 1);
      u32 _c_2 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
      Term _c_3 = e.mem[_at_2 + _at_3 + 1];
      blk_write(e.mem, 1, _at_2, _at_3 + 0, _row_12);
      blk_write(e.mem, 1, _at_2, _at_3 + 1, _row_13);
      term_sink(e, _c_3);
      Term _v_38 = 0;
      Term _v_39 = 0;
      Term _v_40 = 0;
      Term _v_41 = 0;
      Term _v_42 = 0;
      Term _v_43 = 0;
      Term _v_44 = 0;
      Term _v_45 = 0;
      Term _o_0[4];
      if (spin_1(e, _o_0, _metadata_4, _metadata_4 == h2 ? q2 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h3 ? q3 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h4 ? q4 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h5 ? q5 : blk_loc(e.mem, _metadata_7), U32_BIN(_row_9, -, 1ull), 1, _row_14, _row_15, _row_15 == h16 ? q16 : blk_loc(e.mem, _row_15), _row_16, _row_17) == 0) {
        return 0;
      }
      _v_42 = _o_0[0];
      _v_43 = _o_0[1];
      _v_44 = _o_0[2];
      _v_45 = _o_0[3];
      _v_38 = _v_42;
      _v_39 = _v_43;
      _v_40 = _v_44;
      _v_41 = _v_45;
      u32 _v_46 = 0;
      u32 _v_47 = 0;
      Term _o_1[1];
      if (spin_3(e, _o_1, _high_1, _row_9) == 0) {
        return 0;
      }
      _v_47 = _o_1[0];
      _v_46 = _v_47;
      _v_19 = 0;
      _v_20 = _main_1;
      _v_21 = _aux_1;
      _v_22 = _v_38;
      _v_23 = _v_39;
      _v_24 = _v_40;
      _v_25 = _v_41;
      _v_26 = _capacity_1;
      _v_27 = _depth_1;
      _v_28 = _v_46;
      _v_29 = 0;
      _v_30 = 0;
      _v_31 = 0;
      _v_32 = 0;
      _v_33 = 0;
      _v_34 = 0;
      _v_35 = 0;
      _v_36 = 0;
      _v_37 = 0;
    }
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_10(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_5 = 0;
  Term _v_6 = 0;
  Term _v_7 = 0;
  Term _v_8 = 0;
  u32 _v_9 = 0;
  Term _flags_0 = r0;
  Term _added_0 = r1;
  Term _changed_0 = r2;
  Term _result_0 = r3;
  u32 _result_1 = r4;
  WL_SPIN
    _v_5 = _result_0;
    _v_6 = _flags_0;
    _v_7 = _added_0;
    _v_8 = _changed_0;
    _v_9 = _result_1;
  break;
  }
  o[0] = _v_5;
  o[1] = _v_6;
  o[2] = _v_7;
  o[3] = _v_8;
  o[4] = _v_9;
  return 1;
}

INLINE Term spin_11(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h13 = r13;
  Term h15 = r15;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _main_1 = r0;
  Term _aux_1 = r1;
  Term _metadata_0 = r2;
  Term _metadata_1 = r3;
  Term _metadata_2 = r4;
  Term _metadata_3 = r5;
  u32 _capacity_1 = r6;
  Term _depth_1 = r7;
  u32 _high_1 = r8;
  u32 _row_9 = r9;
  u32 _row_10 = r10;
  Term _row_11 = r11;
  u32 _row_12 = r12;
  Term _row_13 = r13;
  u32 _row_14 = r14;
  Term _row_15 = r15;
  u32 _row_16 = r16;
  u32 _row_17 = r17;
  u32 _meta_0 = r18;
  WL_SPIN
    u32 _v_38 = 0;
    Term _v_39 = 0;
    Term _v_40 = 0;
    Term _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    Term _v_44 = 0;
    u32 _v_45 = 0;
    Term _v_46 = 0;
    u32 _v_47 = 0;
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    Term _v_50 = 0;
    u32 _v_51 = 0;
    Term _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    u32 _v_56 = 0;
    Term _o_0[19];
    if (spin_6(e, _o_0, _main_1, _main_1 == h0 ? q0 : blk_loc(e.mem, _main_1), _aux_1, _aux_1 == h1 ? q1 : blk_loc(e.mem, _aux_1), _metadata_0, _metadata_0 == h2 ? q2 : blk_loc(e.mem, _metadata_0), _metadata_1, _metadata_1 == h3 ? q3 : blk_loc(e.mem, _metadata_1), _metadata_2, _metadata_2 == h4 ? q4 : blk_loc(e.mem, _metadata_2), _metadata_3, _metadata_3 == h5 ? q5 : blk_loc(e.mem, _metadata_3), _capacity_1, _depth_1, _high_1, _meta_0, _row_9, _row_10, _row_11, _row_11 == h11 ? q11 : blk_loc(e.mem, _row_11), _row_12, _row_13, _row_13 == h13 ? q13 : blk_loc(e.mem, _row_13), _row_14, _row_15, _row_15 == h15 ? q15 : blk_loc(e.mem, _row_15), _row_16, _row_17) == 0) {
      return 0;
    }
    _v_38 = _o_0[0];
    _v_39 = _o_0[1];
    _v_40 = _o_0[2];
    _v_41 = _o_0[3];
    _v_42 = _o_0[4];
    _v_43 = _o_0[5];
    _v_44 = _o_0[6];
    _v_45 = _o_0[7];
    _v_46 = _o_0[8];
    _v_47 = _o_0[9];
    _v_48 = _o_0[10];
    _v_49 = _o_0[11];
    _v_50 = _o_0[12];
    _v_51 = _o_0[13];
    _v_52 = _o_0[14];
    _v_53 = _o_0[15];
    _v_54 = _o_0[16];
    _v_55 = _o_0[17];
    _v_56 = _o_0[18];
    _v_19 = _v_38;
    _v_20 = _v_39;
    _v_21 = _v_40;
    _v_22 = _v_41;
    _v_23 = _v_42;
    _v_24 = _v_43;
    _v_25 = _v_44;
    _v_26 = _v_45;
    _v_27 = _v_46;
    _v_28 = _v_47;
    _v_29 = _v_48;
    _v_30 = _v_49;
    _v_31 = _v_50;
    _v_32 = _v_51;
    _v_33 = _v_52;
    _v_34 = _v_53;
    _v_35 = _v_54;
    _v_36 = _v_55;
    _v_37 = _v_56;
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_15(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  u32 _v_4 = 0;
  Term _v_5 = 0;
  Term _qr_0 = r0;
  Term _qr_1 = r1;
  WL_SPIN
    _v_4 = ((u64)(u32)(nat_chk(e, 48ull + _qr_1)));
    _v_5 = _qr_0;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  return 1;
}

INLINE Term spin_16(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _columns_0 = r0;
  Term _columns_1 = r1;
  Term _columns_2 = r2;
  Term _columns_3 = r3;
  Term _depth_0 = r4;
  WL_SPIN
    Term _fv_0[1];
    _fv_0[0] = 0;
    Term _fv_1[2];
    _fv_1[0] = 0;
    _fv_1[1] = 0;
    Term _fv_2[1];
    _fv_2[0] = 0ull;
    Term _fv_3[1];
    _fv_3[0] = 0ull;
    _v_8 = blk_node(e, _columns_0, blk_new(e, 0, _depth_0, 0, 1, _fv_0));
    _v_9 = blk_node(e, _columns_1, blk_new(e, 1, _depth_0, 1, 2, _fv_1));
    _v_10 = blk_node(e, _columns_2, blk_new(e, 0, _depth_0, 0, 1, _fv_2));
    _v_11 = blk_node(e, _columns_3, blk_new(e, 0, _depth_0, 0, 1, _fv_3));
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  return 1;
}

INLINE Term spin_17(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  u32 _v_14 = 0;
  Term _columns_0 = r0;
  Term _columns_1 = r1;
  Term _columns_2 = r2;
  Term _columns_3 = r3;
  u32 _index_0 = r4;
  WL_SPIN
    Term _at_0 = _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0);
    Term _at_1 = blk_at(_columns_0, _index_0, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    Term _v_15 = 0;
    Term _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    Term _o_0[5];
    if (spin_10(e, _o_0, _columns_1, _columns_1 == h1 ? q1 : blk_loc(e.mem, _columns_1), _columns_2, _columns_2 == h2 ? q2 : blk_loc(e.mem, _columns_2), _columns_3, _columns_3 == h3 ? q3 : blk_loc(e.mem, _columns_3), _columns_0, _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0), _c_0) == 0) {
      return 0;
    }
    _v_15 = _o_0[0];
    _v_16 = _o_0[1];
    _v_17 = _o_0[2];
    _v_18 = _o_0[3];
    _v_19 = _o_0[4];
    _v_10 = _v_15;
    _v_11 = _v_16;
    _v_12 = _v_17;
    _v_13 = _v_18;
    _v_14 = _v_19;
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  return 1;
}

INLINE Term spin_18(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2, Term r3, u32 r4, u32 r5, u32 r6, Term r7, u64 q7, u32 r8, Term r9, u64 q9, u32 r10, Term r11, u64 q11, u32 r12, u32 r13, Term r14, u64 q14, Term r15, u64 q15, Term r16, u64 q16, Term r17, u64 q17, u32 r18) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h7 = r7;
  Term h9 = r9;
  Term h11 = r11;
  Term h14 = r14;
  Term h15 = r15;
  Term h16 = r16;
  Term h17 = r17;
  u32 _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  Term _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  Term _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  Term _v_51 = 0;
  u32 _v_52 = 0;
  Term _v_53 = 0;
  u32 _v_54 = 0;
  Term _v_55 = 0;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  Term _main_0 = r0;
  Term _aux_0 = r1;
  u32 _capacity_0 = r2;
  Term _depth_0 = r3;
  u32 _high_0 = r4;
  u32 _row_9 = r5;
  u32 _row_10 = r6;
  Term _row_11 = r7;
  u32 _row_12 = r8;
  Term _row_13 = r9;
  u32 _row_14 = r10;
  Term _row_15 = r11;
  u32 _row_16 = r12;
  u32 _row_17 = r13;
  Term _result_0 = r14;
  Term _result_1 = r15;
  Term _result_2 = r16;
  Term _result_3 = r17;
  u32 _result_4 = r18;
  WL_SPIN
    u32 _v_58 = 0;
    Term _v_59 = 0;
    Term _v_60 = 0;
    Term _v_61 = 0;
    Term _v_62 = 0;
    Term _v_63 = 0;
    Term _v_64 = 0;
    u32 _v_65 = 0;
    Term _v_66 = 0;
    u32 _v_67 = 0;
    u32 _v_68 = 0;
    u32 _v_69 = 0;
    Term _v_70 = 0;
    u32 _v_71 = 0;
    Term _v_72 = 0;
    u32 _v_73 = 0;
    Term _v_74 = 0;
    u32 _v_75 = 0;
    u32 _v_76 = 0;
    Term _o_2[19];
    if (spin_11(e, _o_2, _main_0, _main_0 == h0 ? q0 : blk_loc(e.mem, _main_0), _aux_0, _aux_0 == h1 ? q1 : blk_loc(e.mem, _aux_0), _result_0, _result_0 == h14 ? q14 : blk_loc(e.mem, _result_0), _result_1, _result_1 == h15 ? q15 : blk_loc(e.mem, _result_1), _result_2, _result_2 == h16 ? q16 : blk_loc(e.mem, _result_2), _result_3, _result_3 == h17 ? q17 : blk_loc(e.mem, _result_3), _capacity_0, _depth_0, _high_0, _row_9, _row_10, _row_11, _row_11 == h7 ? q7 : blk_loc(e.mem, _row_11), _row_12, _row_13, _row_13 == h9 ? q9 : blk_loc(e.mem, _row_13), _row_14, _row_15, _row_15 == h11 ? q11 : blk_loc(e.mem, _row_15), _row_16, _row_17, _result_4) == 0) {
      return 0;
    }
    _v_58 = _o_2[0];
    _v_59 = _o_2[1];
    _v_60 = _o_2[2];
    _v_61 = _o_2[3];
    _v_62 = _o_2[4];
    _v_63 = _o_2[5];
    _v_64 = _o_2[6];
    _v_65 = _o_2[7];
    _v_66 = _o_2[8];
    _v_67 = _o_2[9];
    _v_68 = _o_2[10];
    _v_69 = _o_2[11];
    _v_70 = _o_2[12];
    _v_71 = _o_2[13];
    _v_72 = _o_2[14];
    _v_73 = _o_2[15];
    _v_74 = _o_2[16];
    _v_75 = _o_2[17];
    _v_76 = _o_2[18];
    _v_39 = _v_58;
    _v_40 = _v_59;
    _v_41 = _v_60;
    _v_42 = _v_61;
    _v_43 = _v_62;
    _v_44 = _v_63;
    _v_45 = _v_64;
    _v_46 = _v_65;
    _v_47 = _v_66;
    _v_48 = _v_67;
    _v_49 = _v_68;
    _v_50 = _v_69;
    _v_51 = _v_70;
    _v_52 = _v_71;
    _v_53 = _v_72;
    _v_54 = _v_73;
    _v_55 = _v_74;
    _v_56 = _v_75;
    _v_57 = _v_76;
  break;
  }
  o[0] = _v_39;
  o[1] = _v_40;
  o[2] = _v_41;
  o[3] = _v_42;
  o[4] = _v_43;
  o[5] = _v_44;
  o[6] = _v_45;
  o[7] = _v_46;
  o[8] = _v_47;
  o[9] = _v_48;
  o[10] = _v_49;
  o[11] = _v_50;
  o[12] = _v_51;
  o[13] = _v_52;
  o[14] = _v_53;
  o[15] = _v_54;
  o[16] = _v_55;
  o[17] = _v_56;
  o[18] = _v_57;
  return 1;
}

INLINE Term spin_23(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_2 = 0;
  u32 _a_0 = r0;
  u32 _b_0 = r1;
  WL_SPIN
    if (_a_0 == 0) {
      _v_2 = 0;
    } else {
      _v_2 = _b_0;
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_24(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h12 = r12;
  Term h14 = r14;
  Term h16 = r16;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  Term _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  u32 _valid_0 = r0;
  Term _rows_9 = r1;
  Term _rows_10 = r2;
  Term _rows_11 = r3;
  Term _rows_12 = r4;
  Term _rows_13 = r5;
  Term _rows_14 = r6;
  u32 _rows_15 = r7;
  Term _rows_16 = r8;
  u32 _rows_17 = r9;
  u32 _row_9 = r10;
  u32 _row_10 = r11;
  Term _row_11 = r12;
  u32 _row_12 = r13;
  Term _row_13 = r14;
  u32 _row_14 = r15;
  Term _row_15 = r16;
  u32 _row_16 = r17;
  u32 _row_17 = r18;
  WL_SPIN
    if (_valid_0 == 0) {
      _v_21 = 1;
      _v_22 = _rows_9;
      _v_23 = _rows_10;
      _v_24 = _rows_11;
      _v_25 = _rows_12;
      _v_26 = _rows_13;
      _v_27 = _rows_14;
      _v_28 = _rows_15;
      _v_29 = _rows_16;
      _v_30 = _rows_17;
      _v_31 = _row_9;
      _v_32 = _row_10;
      _v_33 = _row_11;
      _v_34 = _row_12;
      _v_35 = _row_13;
      _v_36 = _row_14;
      _v_37 = _row_15;
      _v_38 = _row_16;
      _v_39 = _row_17;
    } else {
      Term _v_40 = 0;
      Term _v_41 = 0;
      Term _v_42 = 0;
      Term _v_43 = 0;
      u32 _v_44 = 0;
      Term _v_45 = 0;
      Term _v_46 = 0;
      Term _v_47 = 0;
      Term _v_48 = 0;
      u32 _v_49 = 0;
      Term _o_1[5];
      if (spin_17(e, _o_1, _rows_11, _rows_11 == h3 ? q3 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h4 ? q4 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h5 ? q5 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h6 ? q6 : blk_loc(e.mem, _rows_14), U32_BIN(_row_9, -, 1ull)) == 0) {
        return 0;
      }
      _v_45 = _o_1[0];
      _v_46 = _o_1[1];
      _v_47 = _o_1[2];
      _v_48 = _o_1[3];
      _v_49 = _o_1[4];
      _v_40 = _v_45;
      _v_41 = _v_46;
      _v_42 = _v_47;
      _v_43 = _v_48;
      _v_44 = _v_49;
      u32 _v_50 = 0;
      Term _v_51 = 0;
      Term _v_52 = 0;
      Term _v_53 = 0;
      Term _v_54 = 0;
      Term _v_55 = 0;
      Term _v_56 = 0;
      u32 _v_57 = 0;
      Term _v_58 = 0;
      u32 _v_59 = 0;
      u32 _v_60 = 0;
      u32 _v_61 = 0;
      Term _v_62 = 0;
      u32 _v_63 = 0;
      Term _v_64 = 0;
      u32 _v_65 = 0;
      Term _v_66 = 0;
      u32 _v_67 = 0;
      u32 _v_68 = 0;
      Term _o_2[19];
      if (spin_18(e, _o_2, _rows_9, _rows_9 == h1 ? q1 : blk_loc(e.mem, _rows_9), _rows_10, _rows_10 == h2 ? q2 : blk_loc(e.mem, _rows_10), _rows_15, _rows_16, _rows_17, _row_9, _row_10, _row_11, _row_11 == h12 ? q12 : blk_loc(e.mem, _row_11), _row_12, _row_13, _row_13 == h14 ? q14 : blk_loc(e.mem, _row_13), _row_14, _row_15, _row_15 == h16 ? q16 : blk_loc(e.mem, _row_15), _row_16, _row_17, _v_40, _v_40 == h16 ? q16 : _v_40 == h14 ? q14 : _v_40 == h12 ? q12 : _v_40 == h6 ? q6 : _v_40 == h5 ? q5 : _v_40 == h4 ? q4 : _v_40 == h3 ? q3 : _v_40 == h2 ? q2 : _v_40 == h1 ? q1 : blk_loc(e.mem, _v_40), _v_41, _v_41 == h16 ? q16 : _v_41 == h14 ? q14 : _v_41 == h12 ? q12 : _v_41 == h6 ? q6 : _v_41 == h5 ? q5 : _v_41 == h4 ? q4 : _v_41 == h3 ? q3 : _v_41 == h2 ? q2 : _v_41 == h1 ? q1 : blk_loc(e.mem, _v_41), _v_42, _v_42 == h16 ? q16 : _v_42 == h14 ? q14 : _v_42 == h12 ? q12 : _v_42 == h6 ? q6 : _v_42 == h5 ? q5 : _v_42 == h4 ? q4 : _v_42 == h3 ? q3 : _v_42 == h2 ? q2 : _v_42 == h1 ? q1 : blk_loc(e.mem, _v_42), _v_43, _v_43 == h16 ? q16 : _v_43 == h14 ? q14 : _v_43 == h12 ? q12 : _v_43 == h6 ? q6 : _v_43 == h5 ? q5 : _v_43 == h4 ? q4 : _v_43 == h3 ? q3 : _v_43 == h2 ? q2 : _v_43 == h1 ? q1 : blk_loc(e.mem, _v_43), _v_44) == 0) {
        return 0;
      }
      _v_50 = _o_2[0];
      _v_51 = _o_2[1];
      _v_52 = _o_2[2];
      _v_53 = _o_2[3];
      _v_54 = _o_2[4];
      _v_55 = _o_2[5];
      _v_56 = _o_2[6];
      _v_57 = _o_2[7];
      _v_58 = _o_2[8];
      _v_59 = _o_2[9];
      _v_60 = _o_2[10];
      _v_61 = _o_2[11];
      _v_62 = _o_2[12];
      _v_63 = _o_2[13];
      _v_64 = _o_2[14];
      _v_65 = _o_2[15];
      _v_66 = _o_2[16];
      _v_67 = _o_2[17];
      _v_68 = _o_2[18];
      _v_21 = _v_50;
      _v_22 = _v_51;
      _v_23 = _v_52;
      _v_24 = _v_53;
      _v_25 = _v_54;
      _v_26 = _v_55;
      _v_27 = _v_56;
      _v_28 = _v_57;
      _v_29 = _v_58;
      _v_30 = _v_59;
      _v_31 = _v_60;
      _v_32 = _v_61;
      _v_33 = _v_62;
      _v_34 = _v_63;
      _v_35 = _v_64;
      _v_36 = _v_65;
      _v_37 = _v_66;
      _v_38 = _v_67;
      _v_39 = _v_68;
    }
  break;
  }
  o[0] = _v_21;
  o[1] = _v_22;
  o[2] = _v_23;
  o[3] = _v_24;
  o[4] = _v_25;
  o[5] = _v_26;
  o[6] = _v_27;
  o[7] = _v_28;
  o[8] = _v_29;
  o[9] = _v_30;
  o[10] = _v_31;
  o[11] = _v_32;
  o[12] = _v_33;
  o[13] = _v_34;
  o[14] = _v_35;
  o[15] = _v_36;
  o[16] = _v_37;
  o[17] = _v_38;
  o[18] = _v_39;
  return 1;
}

INLINE Term spin_25(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  u32 _v_4 = 0;
  Term _v_5 = 0;
  u32 _v_6 = 0;
  Term _v_7 = 0;
  Term _r_0 = r0;
  u32 _r_1 = r1;
  Term _r_2 = r2;
  WL_SPIN
    _v_4 = 1;
    _v_5 = _r_0;
    _v_6 = _r_1;
    _v_7 = _r_2;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  o[2] = _v_6;
  o[3] = _v_7;
  return 1;
}

INLINE Term spin_26(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  u32 _v_4 = 0;
  Term _v_5 = 0;
  u32 _v_6 = 0;
  Term _v_7 = 0;
  Term _r_0 = r0;
  u32 _r_1 = r1;
  Term _r_2 = r2;
  WL_SPIN
    _v_4 = 1;
    _v_5 = _r_0;
    _v_6 = _r_1;
    _v_7 = _r_2;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  o[2] = _v_6;
  o[3] = _v_7;
  return 1;
}

INLINE Term spin_27(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  Term _v_2 = 0;
  u32 _flag_6 = r0;
  WL_SPIN
    if (_flag_6 == 0) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 14);
    } else {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 20);
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_33(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5, u32 r6, Term r7, u64 q7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h7 = r7;
  Term _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  Term _v_38 = 0;
  Term _columns_0 = r0;
  Term _columns_1 = r1;
  Term _columns_2 = r2;
  Term _columns_3 = r3;
  u32 _index_0 = r4;
  u32 _meta_0 = r5;
  u32 _meta_1 = r6;
  Term _meta_2 = r7;
  u32 _meta_3 = r8;
  u32 _meta_4 = r9;
  WL_SPIN
    Term _at_4 = _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0);
    Term _at_5 = blk_at(_columns_0, _index_0, 0);
    u32 _c_4 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    blk_write(e.mem, 0, _at_4, _at_5 + 0, _meta_0);
    Term _at_6 = _columns_1 == h1 ? q1 : blk_loc(e.mem, _columns_1);
    Term _at_7 = blk_at(_columns_1, _index_0, 1);
    u32 _c_5 = blk_read(e.mem, 1, _at_6, _at_7 + 0);
    Term _c_6 = e.mem[_at_6 + _at_7 + 1];
    blk_write(e.mem, 1, _at_6, _at_7 + 0, _meta_1);
    blk_write(e.mem, 1, _at_6, _at_7 + 1, _meta_2);
    term_sink(e, _c_6);
    Term _at_8 = _columns_2 == h2 ? q2 : blk_loc(e.mem, _columns_2);
    Term _at_9 = blk_at(_columns_2, _index_0, 0);
    u32 _c_7 = blk_read(e.mem, 0, _at_8, _at_9 + 0);
    blk_write(e.mem, 0, _at_8, _at_9 + 0, _meta_3);
    Term _at_10 = _columns_3 == h3 ? q3 : blk_loc(e.mem, _columns_3);
    Term _at_11 = blk_at(_columns_3, _index_0, 0);
    u32 _c_8 = blk_read(e.mem, 0, _at_10, _at_11 + 0);
    blk_write(e.mem, 0, _at_10, _at_11 + 0, _meta_4);
    _v_35 = _columns_0;
    _v_36 = _columns_1;
    _v_37 = _columns_2;
    _v_38 = _columns_3;
  break;
  }
  o[0] = _v_35;
  o[1] = _v_36;
  o[2] = _v_37;
  o[3] = _v_38;
  return 1;
}

INLINE Term spin_32(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h13 = r13;
  Term h15 = r15;
  Term _v_18 = 0;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  u32 _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _rows_45 = r0;
  Term _rows_46 = r1;
  Term _rows_47 = r2;
  Term _rows_48 = r3;
  Term _rows_49 = r4;
  Term _rows_50 = r5;
  u32 _rows_51 = r6;
  Term _rows_52 = r7;
  u32 _rows_53 = r8;
  u32 _row_0 = r9;
  u32 _row_1 = r10;
  Term _row_2 = r11;
  u32 _row_3 = r12;
  Term _row_4 = r13;
  u32 _row_5 = r14;
  Term _row_6 = r15;
  u32 _row_7 = r16;
  u32 _row_8 = r17;
  WL_SPIN
    Term _at_0 = _rows_45 == h0 ? q0 : blk_loc(e.mem, _rows_45);
    Term _at_1 = blk_at(_rows_45, U32_BIN(_row_0, -, 1ull), 1);
    u32 _c_0 = blk_read(e.mem, 1, _at_0, _at_1 + 0);
    Term _c_1 = e.mem[_at_0 + _at_1 + 1];
    blk_write(e.mem, 1, _at_0, _at_1 + 0, _row_1);
    blk_write(e.mem, 1, _at_0, _at_1 + 1, _row_2);
    term_sink(e, _c_1);
    Term _at_2 = _rows_46 == h1 ? q1 : blk_loc(e.mem, _rows_46);
    Term _at_3 = blk_at(_rows_46, U32_BIN(_row_0, -, 1ull), 1);
    u32 _c_2 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
    Term _c_3 = e.mem[_at_2 + _at_3 + 1];
    blk_write(e.mem, 1, _at_2, _at_3 + 0, _row_3);
    blk_write(e.mem, 1, _at_2, _at_3 + 1, _row_4);
    term_sink(e, _c_3);
    Term _v_27 = 0;
    Term _v_28 = 0;
    Term _v_29 = 0;
    Term _v_30 = 0;
    Term _v_31 = 0;
    Term _v_32 = 0;
    Term _v_33 = 0;
    Term _v_34 = 0;
    Term _o_6[4];
    if (spin_33(e, _o_6, _rows_47, _rows_47 == h2 ? q2 : blk_loc(e.mem, _rows_47), _rows_48, _rows_48 == h3 ? q3 : blk_loc(e.mem, _rows_48), _rows_49, _rows_49 == h4 ? q4 : blk_loc(e.mem, _rows_49), _rows_50, _rows_50 == h5 ? q5 : blk_loc(e.mem, _rows_50), U32_BIN(_row_0, -, 1ull), 1, _row_5, _row_6, _row_6 == h15 ? q15 : blk_loc(e.mem, _row_6), _row_7, _row_8) == 0) {
      return 0;
    }
    _v_31 = _o_6[0];
    _v_32 = _o_6[1];
    _v_33 = _o_6[2];
    _v_34 = _o_6[3];
    _v_27 = _v_31;
    _v_28 = _v_32;
    _v_29 = _v_33;
    _v_30 = _v_34;
    _v_18 = _rows_45;
    _v_19 = _rows_46;
    _v_20 = _v_27;
    _v_21 = _v_28;
    _v_22 = _v_29;
    _v_23 = _v_30;
    _v_24 = _rows_51;
    _v_25 = _rows_52;
    _v_26 = _rows_53;
  break;
  }
  o[0] = _v_18;
  o[1] = _v_19;
  o[2] = _v_20;
  o[3] = _v_21;
  o[4] = _v_22;
  o[5] = _v_23;
  o[6] = _v_24;
  o[7] = _v_25;
  o[8] = _v_26;
  return 1;
}

INLINE Term spin_34(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h13 = r13;
  Term h15 = r15;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _rows_9 = r0;
  Term _rows_10 = r1;
  Term _rows_11 = r2;
  Term _rows_12 = r3;
  Term _rows_13 = r4;
  Term _rows_14 = r5;
  u32 _rows_15 = r6;
  Term _rows_16 = r7;
  u32 _rows_17 = r8;
  u32 _row_18 = r9;
  u32 _row_19 = r10;
  Term _row_20 = r11;
  u32 _row_21 = r12;
  Term _row_22 = r13;
  u32 _row_23 = r14;
  Term _row_24 = r15;
  u32 _row_25 = r16;
  u32 _row_26 = r17;
  WL_SPIN
    u32 _v_38 = 0;
    u32 _v_39 = 0;
    Term _o_0[1];
    if (spin_23(e, _o_0, U32_BIN(0ull, <, _row_18), U32_BIN(_row_18, <=, _rows_15)) == 0) {
      return 0;
    }
    _v_39 = _o_0[0];
    _v_38 = _v_39;
    u32 _v_40 = 0;
    Term _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    Term _v_44 = 0;
    Term _v_45 = 0;
    Term _v_46 = 0;
    u32 _v_47 = 0;
    Term _v_48 = 0;
    u32 _v_49 = 0;
    u32 _v_50 = 0;
    u32 _v_51 = 0;
    Term _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    Term _v_56 = 0;
    u32 _v_57 = 0;
    u32 _v_58 = 0;
    Term _o_1[19];
    if (spin_24(e, _o_1, _v_38, _rows_9, _rows_9 == h0 ? q0 : blk_loc(e.mem, _rows_9), _rows_10, _rows_10 == h1 ? q1 : blk_loc(e.mem, _rows_10), _rows_11, _rows_11 == h2 ? q2 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h3 ? q3 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h4 ? q4 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h5 ? q5 : blk_loc(e.mem, _rows_14), _rows_15, _rows_16, _rows_17, _row_18, _row_19, _row_20, _row_20 == h11 ? q11 : blk_loc(e.mem, _row_20), _row_21, _row_22, _row_22 == h13 ? q13 : blk_loc(e.mem, _row_22), _row_23, _row_24, _row_24 == h15 ? q15 : blk_loc(e.mem, _row_24), _row_25, _row_26) == 0) {
      return 0;
    }
    _v_40 = _o_1[0];
    _v_41 = _o_1[1];
    _v_42 = _o_1[2];
    _v_43 = _o_1[3];
    _v_44 = _o_1[4];
    _v_45 = _o_1[5];
    _v_46 = _o_1[6];
    _v_47 = _o_1[7];
    _v_48 = _o_1[8];
    _v_49 = _o_1[9];
    _v_50 = _o_1[10];
    _v_51 = _o_1[11];
    _v_52 = _o_1[12];
    _v_53 = _o_1[13];
    _v_54 = _o_1[14];
    _v_55 = _o_1[15];
    _v_56 = _o_1[16];
    _v_57 = _o_1[17];
    _v_58 = _o_1[18];
    _v_19 = _v_40;
    _v_20 = _v_41;
    _v_21 = _v_42;
    _v_22 = _v_43;
    _v_23 = _v_44;
    _v_24 = _v_45;
    _v_25 = _v_46;
    _v_26 = _v_47;
    _v_27 = _v_48;
    _v_28 = _v_49;
    _v_29 = _v_50;
    _v_30 = _v_51;
    _v_31 = _v_52;
    _v_32 = _v_53;
    _v_33 = _v_54;
    _v_34 = _v_55;
    _v_35 = _v_56;
    _v_36 = _v_57;
    _v_37 = _v_58;
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_39(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  Term _v_2 = 0;
  u32 _effect_0 = r0;
  WL_SPIN
    if (_effect_0 == 0) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 46);
    } else if (_effect_0 == 1) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 56);
    } else if (_effect_0 == 2) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 66);
    } else if (_effect_0 == 3) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 76);
    } else {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 80);
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_41(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_11 = 0;
  u32 _v_12 = 0;
  Term _m_2 = r0;
  u32 _m_3 = r1;
  u32 _v_10 = r2;
  WL_SPIN
    Term _at_0 = _m_2 == h0 ? q0 : blk_loc(e.mem, _m_2);
    Term _at_1 = blk_at(_m_2, 0ull, 0);
    u32 _c_4 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    blk_write(e.mem, 0, _at_0, _at_1 + 0, _v_10);
    Term _at_2 = _m_2 == h0 ? q0 : blk_loc(e.mem, _m_2);
    Term _at_3 = blk_at(_m_2, 1ull, 0);
    u32 _c_5 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    blk_write(e.mem, 0, _at_2, _at_3 + 0, _v_10);
    Term _at_4 = _m_2 == h0 ? q0 : blk_loc(e.mem, _m_2);
    Term _at_5 = blk_at(_m_2, 2ull, 0);
    u32 _c_6 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    blk_write(e.mem, 0, _at_4, _at_5 + 0, _v_10);
    Term _at_6 = _m_2 == h0 ? q0 : blk_loc(e.mem, _m_2);
    Term _at_7 = blk_at(_m_2, 3ull, 0);
    u32 _c_7 = blk_read(e.mem, 0, _at_6, _at_7 + 0);
    blk_write(e.mem, 0, _at_6, _at_7 + 0, _v_10);
    _v_11 = _m_2;
    _v_12 = _v_10;
  break;
  }
  o[0] = _v_11;
  o[1] = _v_12;
  return 1;
}

INLINE Term spin_42(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  Term _m_4 = r0;
  u32 _m_5 = r1;
  u32 _a_1 = r2;
  u32 _b_0 = r3;
  u32 _c_8 = r4;
  u32 _d_0 = r5;
  u32 _s_0 = r6;
  WL_SPIN
    Term _at_8 = _m_4 == h0 ? q0 : blk_loc(e.mem, _m_4);
    Term _at_9 = blk_at(_m_4, 0ull, 0);
    u32 _c_9 = blk_read(e.mem, 0, _at_8, _at_9 + 0);
    blk_write(e.mem, 0, _at_8, _at_9 + 0, _a_1);
    Term _at_10 = _m_4 == h0 ? q0 : blk_loc(e.mem, _m_4);
    Term _at_11 = blk_at(_m_4, 1ull, 0);
    u32 _c_10 = blk_read(e.mem, 0, _at_10, _at_11 + 0);
    blk_write(e.mem, 0, _at_10, _at_11 + 0, _b_0);
    Term _at_12 = _m_4 == h0 ? q0 : blk_loc(e.mem, _m_4);
    Term _at_13 = blk_at(_m_4, 2ull, 0);
    u32 _c_11 = blk_read(e.mem, 0, _at_12, _at_13 + 0);
    blk_write(e.mem, 0, _at_12, _at_13 + 0, _c_8);
    Term _at_14 = _m_4 == h0 ? q0 : blk_loc(e.mem, _m_4);
    Term _at_15 = blk_at(_m_4, 3ull, 0);
    u32 _c_12 = blk_read(e.mem, 0, _at_14, _at_15 + 0);
    blk_write(e.mem, 0, _at_14, _at_15 + 0, _d_0);
    _v_19 = _m_4;
    _v_20 = _s_0;
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  return 1;
}

INLINE Term spin_43(Env e, THR Term* o, u32 r0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term _v_2 = 0;
  u32 _result_15 = r0;
  Term _result_16 = r1;
  WL_SPIN
    if (_result_15 == 2) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 46);
    } else if (_result_15 == 1) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 96);
    } else {
      _v_2 = _result_16;
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_50(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, u64 q7, u32 r8) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h5 = r5;
  Term h7 = r7;
  Term _v_189 = 0;
  Term _v_190 = 0;
  Term _v_191 = 0;
  Term _v_192 = 0;
  u32 _v_193 = 0;
  u32 _v_194 = 0;
  Term _v_195 = 0;
  u32 _v_196 = 0;
  u32 _v_197 = 0;
  Term _live_2 = r0;
  Term _flags_2 = r1;
  Term _added_2 = r2;
  u32 _l_2 = r3;
  u32 _f_76 = r4;
  Term _f_77 = r5;
  u32 _a_9 = r6;
  Term _result_7 = r7;
  u32 _result_8 = r8;
  WL_SPIN
    _v_189 = _live_2;
    _v_190 = _flags_2;
    _v_191 = _added_2;
    _v_192 = _result_7;
    _v_193 = _l_2;
    _v_194 = _f_76;
    _v_195 = _f_77;
    _v_196 = _a_9;
    _v_197 = _result_8;
  break;
  }
  o[0] = _v_189;
  o[1] = _v_190;
  o[2] = _v_191;
  o[3] = _v_192;
  o[4] = _v_193;
  o[5] = _v_194;
  o[6] = _v_195;
  o[7] = _v_196;
  o[8] = _v_197;
  return 1;
}

INLINE Term spin_49(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, u32 r4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, u32 r8) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h6 = r6;
  Term h7 = r7;
  Term _v_171 = 0;
  Term _v_172 = 0;
  Term _v_173 = 0;
  Term _v_174 = 0;
  u32 _v_175 = 0;
  u32 _v_176 = 0;
  Term _v_177 = 0;
  u32 _v_178 = 0;
  u32 _v_179 = 0;
  Term _live_1 = r0;
  Term _flags_1 = r1;
  Term _changed_2 = r2;
  u32 _index_3 = r3;
  u32 _l_1 = r4;
  u32 _f_74 = r5;
  Term _f_75 = r6;
  Term _result_5 = r7;
  u32 _result_6 = r8;
  WL_SPIN
    Term _at_60 = _changed_2 == h2 ? q2 : blk_loc(e.mem, _changed_2);
    Term _at_61 = blk_at(_changed_2, _index_3, 0);
    u32 _c_31 = blk_read(e.mem, 0, _at_60, _at_61 + 0);
    Term _v_180 = 0;
    Term _v_181 = 0;
    Term _v_182 = 0;
    Term _v_183 = 0;
    u32 _v_184 = 0;
    u32 _v_185 = 0;
    Term _v_186 = 0;
    u32 _v_187 = 0;
    u32 _v_188 = 0;
    Term _o_137[9];
    if (spin_50(e, _o_137, _live_1, _live_1 == h0 ? q0 : blk_loc(e.mem, _live_1), _flags_1, _flags_1 == h1 ? q1 : blk_loc(e.mem, _flags_1), _result_5, _result_5 == h7 ? q7 : blk_loc(e.mem, _result_5), _l_1, _f_74, _f_75, _f_75 == h6 ? q6 : blk_loc(e.mem, _f_75), _result_6, _changed_2, _changed_2 == h2 ? q2 : blk_loc(e.mem, _changed_2), _c_31) == 0) {
      return 0;
    }
    _v_180 = _o_137[0];
    _v_181 = _o_137[1];
    _v_182 = _o_137[2];
    _v_183 = _o_137[3];
    _v_184 = _o_137[4];
    _v_185 = _o_137[5];
    _v_186 = _o_137[6];
    _v_187 = _o_137[7];
    _v_188 = _o_137[8];
    _v_171 = _v_180;
    _v_172 = _v_181;
    _v_173 = _v_182;
    _v_174 = _v_183;
    _v_175 = _v_184;
    _v_176 = _v_185;
    _v_177 = _v_186;
    _v_178 = _v_187;
    _v_179 = _v_188;
  break;
  }
  o[0] = _v_171;
  o[1] = _v_172;
  o[2] = _v_173;
  o[3] = _v_174;
  o[4] = _v_175;
  o[5] = _v_176;
  o[6] = _v_177;
  o[7] = _v_178;
  o[8] = _v_179;
  return 1;
}

INLINE Term spin_48(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, u64 q7) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h5 = r5;
  Term h7 = r7;
  Term _v_153 = 0;
  Term _v_154 = 0;
  Term _v_155 = 0;
  Term _v_156 = 0;
  u32 _v_157 = 0;
  u32 _v_158 = 0;
  Term _v_159 = 0;
  u32 _v_160 = 0;
  u32 _v_161 = 0;
  Term _live_0 = r0;
  Term _added_1 = r1;
  Term _changed_1 = r2;
  u32 _index_2 = r3;
  u32 _l_0 = r4;
  Term _result_2 = r5;
  u32 _result_3 = r6;
  Term _result_4 = r7;
  WL_SPIN
    Term _at_58 = _added_1 == h1 ? q1 : blk_loc(e.mem, _added_1);
    Term _at_59 = blk_at(_added_1, _index_2, 0);
    u32 _c_30 = blk_read(e.mem, 0, _at_58, _at_59 + 0);
    Term _v_162 = 0;
    Term _v_163 = 0;
    Term _v_164 = 0;
    Term _v_165 = 0;
    u32 _v_166 = 0;
    u32 _v_167 = 0;
    Term _v_168 = 0;
    u32 _v_169 = 0;
    u32 _v_170 = 0;
    Term _o_138[9];
    if (spin_49(e, _o_138, _live_0, _live_0 == h0 ? q0 : blk_loc(e.mem, _live_0), _result_2, _result_2 == h5 ? q5 : blk_loc(e.mem, _result_2), _changed_1, _changed_1 == h2 ? q2 : blk_loc(e.mem, _changed_1), _index_2, _l_0, _result_3, _result_4, _result_4 == h7 ? q7 : blk_loc(e.mem, _result_4), _added_1, _added_1 == h1 ? q1 : blk_loc(e.mem, _added_1), _c_30) == 0) {
      return 0;
    }
    _v_162 = _o_138[0];
    _v_163 = _o_138[1];
    _v_164 = _o_138[2];
    _v_165 = _o_138[3];
    _v_166 = _o_138[4];
    _v_167 = _o_138[5];
    _v_168 = _o_138[6];
    _v_169 = _o_138[7];
    _v_170 = _o_138[8];
    _v_153 = _v_162;
    _v_154 = _v_163;
    _v_155 = _v_164;
    _v_156 = _v_165;
    _v_157 = _v_166;
    _v_158 = _v_167;
    _v_159 = _v_168;
    _v_160 = _v_169;
    _v_161 = _v_170;
  break;
  }
  o[0] = _v_153;
  o[1] = _v_154;
  o[2] = _v_155;
  o[3] = _v_156;
  o[4] = _v_157;
  o[5] = _v_158;
  o[6] = _v_159;
  o[7] = _v_160;
  o[8] = _v_161;
  return 1;
}

INLINE Term spin_47(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, Term r4, u64 q4, u32 r5) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h4 = r4;
  Term _v_135 = 0;
  Term _v_136 = 0;
  Term _v_137 = 0;
  Term _v_138 = 0;
  u32 _v_139 = 0;
  u32 _v_140 = 0;
  Term _v_141 = 0;
  u32 _v_142 = 0;
  u32 _v_143 = 0;
  Term _flags_0 = r0;
  Term _added_0 = r1;
  Term _changed_0 = r2;
  u32 _index_1 = r3;
  Term _result_0 = r4;
  u32 _result_1 = r5;
  WL_SPIN
    Term _at_56 = _flags_0 == h0 ? q0 : blk_loc(e.mem, _flags_0);
    Term _at_57 = blk_at(_flags_0, _index_1, 1);
    u32 _c_28 = blk_read(e.mem, 1, _at_56, _at_57 + 0);
    Term _c_29 = blk_keep(e, _at_56 + _at_57 + 1);
    Term _v_144 = 0;
    Term _v_145 = 0;
    Term _v_146 = 0;
    Term _v_147 = 0;
    u32 _v_148 = 0;
    u32 _v_149 = 0;
    Term _v_150 = 0;
    u32 _v_151 = 0;
    u32 _v_152 = 0;
    Term _o_139[9];
    if (spin_48(e, _o_139, _result_0, _result_0 == h4 ? q4 : blk_loc(e.mem, _result_0), _added_0, _added_0 == h1 ? q1 : blk_loc(e.mem, _added_0), _changed_0, _changed_0 == h2 ? q2 : blk_loc(e.mem, _changed_0), _index_1, _result_1, _flags_0, _flags_0 == h0 ? q0 : blk_loc(e.mem, _flags_0), _c_28, _c_29, _c_29 == h4 ? q4 : _c_29 == h2 ? q2 : _c_29 == h1 ? q1 : _c_29 == h0 ? q0 : blk_loc(e.mem, _c_29)) == 0) {
      return 0;
    }
    _v_144 = _o_139[0];
    _v_145 = _o_139[1];
    _v_146 = _o_139[2];
    _v_147 = _o_139[3];
    _v_148 = _o_139[4];
    _v_149 = _o_139[5];
    _v_150 = _o_139[6];
    _v_151 = _o_139[7];
    _v_152 = _o_139[8];
    _v_135 = _v_144;
    _v_136 = _v_145;
    _v_137 = _v_146;
    _v_138 = _v_147;
    _v_139 = _v_148;
    _v_140 = _v_149;
    _v_141 = _v_150;
    _v_142 = _v_151;
    _v_143 = _v_152;
  break;
  }
  o[0] = _v_135;
  o[1] = _v_136;
  o[2] = _v_137;
  o[3] = _v_138;
  o[4] = _v_139;
  o[5] = _v_140;
  o[6] = _v_141;
  o[7] = _v_142;
  o[8] = _v_143;
  return 1;
}

INLINE Term spin_46(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_117 = 0;
  Term _v_118 = 0;
  Term _v_119 = 0;
  Term _v_120 = 0;
  u32 _v_121 = 0;
  u32 _v_122 = 0;
  Term _v_123 = 0;
  u32 _v_124 = 0;
  u32 _v_125 = 0;
  Term _columns_0 = r0;
  Term _columns_1 = r1;
  Term _columns_2 = r2;
  Term _columns_3 = r3;
  u32 _index_0 = r4;
  WL_SPIN
    Term _at_54 = _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0);
    Term _at_55 = blk_at(_columns_0, _index_0, 0);
    u32 _c_27 = blk_read(e.mem, 0, _at_54, _at_55 + 0);
    Term _v_126 = 0;
    Term _v_127 = 0;
    Term _v_128 = 0;
    Term _v_129 = 0;
    u32 _v_130 = 0;
    u32 _v_131 = 0;
    Term _v_132 = 0;
    u32 _v_133 = 0;
    u32 _v_134 = 0;
    Term _o_140[9];
    if (spin_47(e, _o_140, _columns_1, _columns_1 == h1 ? q1 : blk_loc(e.mem, _columns_1), _columns_2, _columns_2 == h2 ? q2 : blk_loc(e.mem, _columns_2), _columns_3, _columns_3 == h3 ? q3 : blk_loc(e.mem, _columns_3), _index_0, _columns_0, _columns_0 == h0 ? q0 : blk_loc(e.mem, _columns_0), _c_27) == 0) {
      return 0;
    }
    _v_126 = _o_140[0];
    _v_127 = _o_140[1];
    _v_128 = _o_140[2];
    _v_129 = _o_140[3];
    _v_130 = _o_140[4];
    _v_131 = _o_140[5];
    _v_132 = _o_140[6];
    _v_133 = _o_140[7];
    _v_134 = _o_140[8];
    _v_117 = _v_126;
    _v_118 = _v_127;
    _v_119 = _v_128;
    _v_120 = _v_129;
    _v_121 = _v_130;
    _v_122 = _v_131;
    _v_123 = _v_132;
    _v_124 = _v_133;
    _v_125 = _v_134;
  break;
  }
  o[0] = _v_117;
  o[1] = _v_118;
  o[2] = _v_119;
  o[3] = _v_120;
  o[4] = _v_121;
  o[5] = _v_122;
  o[6] = _v_123;
  o[7] = _v_124;
  o[8] = _v_125;
  return 1;
}

INLINE Term spin_54(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, u32 r11, Term r12, u32 r13, u32 r14, u32 r15, Term r16, u64 q16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h3 = r3;
  Term h4 = r4;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h16 = r16;
  Term _v_331 = 0;
  Term _v_332 = 0;
  Term _v_333 = 0;
  Term _v_334 = 0;
  Term _v_335 = 0;
  Term _v_336 = 0;
  u32 _v_337 = 0;
  Term _v_338 = 0;
  u32 _v_339 = 0;
  u32 _v_340 = 0;
  u32 _v_341 = 0;
  u32 _v_342 = 0;
  Term _v_343 = 0;
  u32 _v_344 = 0;
  Term _v_345 = 0;
  u32 _v_346 = 0;
  Term _v_347 = 0;
  u32 _v_348 = 0;
  u32 _v_349 = 0;
  u32 _id_5 = r0;
  Term _main_2 = r1;
  u32 _value_2 = r2;
  Term _value_3 = r3;
  Term _aux_2 = r4;
  u32 _av_0 = r5;
  Term _av_1 = r6;
  Term _metadata_8 = r7;
  Term _metadata_9 = r8;
  Term _metadata_10 = r9;
  Term _metadata_11 = r10;
  u32 _capacity_3 = r11;
  Term _depth_3 = r12;
  u32 _high_3 = r13;
  u32 _meta_10 = r14;
  u32 _meta_11 = r15;
  Term _meta_12 = r16;
  u32 _meta_13 = r17;
  u32 _meta_14 = r18;
  WL_SPIN
    _v_331 = _main_2;
    _v_332 = _aux_2;
    _v_333 = _metadata_8;
    _v_334 = _metadata_9;
    _v_335 = _metadata_10;
    _v_336 = _metadata_11;
    _v_337 = _capacity_3;
    _v_338 = _depth_3;
    _v_339 = _high_3;
    _v_340 = 1;
    _v_341 = _id_5;
    _v_342 = _value_2;
    _v_343 = _value_3;
    _v_344 = _av_0;
    _v_345 = _av_1;
    _v_346 = _meta_11;
    _v_347 = _meta_12;
    _v_348 = _meta_13;
    _v_349 = _meta_14;
  break;
  }
  o[0] = _v_331;
  o[1] = _v_332;
  o[2] = _v_333;
  o[3] = _v_334;
  o[4] = _v_335;
  o[5] = _v_336;
  o[6] = _v_337;
  o[7] = _v_338;
  o[8] = _v_339;
  o[9] = _v_340;
  o[10] = _v_341;
  o[11] = _v_342;
  o[12] = _v_343;
  o[13] = _v_344;
  o[14] = _v_345;
  o[15] = _v_346;
  o[16] = _v_347;
  o[17] = _v_348;
  o[18] = _v_349;
  return 1;
}

INLINE Term spin_53(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, u32 r14, u32 r15, Term r16, u64 q16, u32 r17, Term r18, u64 q18) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h13 = r13;
  Term h16 = r16;
  Term h18 = r18;
  Term _v_293 = 0;
  Term _v_294 = 0;
  Term _v_295 = 0;
  Term _v_296 = 0;
  Term _v_297 = 0;
  Term _v_298 = 0;
  u32 _v_299 = 0;
  Term _v_300 = 0;
  u32 _v_301 = 0;
  u32 _v_302 = 0;
  u32 _v_303 = 0;
  u32 _v_304 = 0;
  Term _v_305 = 0;
  u32 _v_306 = 0;
  Term _v_307 = 0;
  u32 _v_308 = 0;
  Term _v_309 = 0;
  u32 _v_310 = 0;
  u32 _v_311 = 0;
  u32 _id_4 = r0;
  Term _main_1 = r1;
  u32 _value_0 = r2;
  Term _value_1 = r3;
  Term _metadata_4 = r4;
  Term _metadata_5 = r5;
  Term _metadata_6 = r6;
  Term _metadata_7 = r7;
  u32 _capacity_2 = r8;
  Term _depth_2 = r9;
  u32 _high_2 = r10;
  u32 _meta_5 = r11;
  u32 _meta_6 = r12;
  Term _meta_7 = r13;
  u32 _meta_8 = r14;
  u32 _meta_9 = r15;
  Term _result_21 = r16;
  u32 _result_22 = r17;
  Term _result_23 = r18;
  WL_SPIN
    Term _v_312 = 0;
    Term _v_313 = 0;
    Term _v_314 = 0;
    Term _v_315 = 0;
    Term _v_316 = 0;
    Term _v_317 = 0;
    u32 _v_318 = 0;
    Term _v_319 = 0;
    u32 _v_320 = 0;
    u32 _v_321 = 0;
    u32 _v_322 = 0;
    u32 _v_323 = 0;
    Term _v_324 = 0;
    u32 _v_325 = 0;
    Term _v_326 = 0;
    u32 _v_327 = 0;
    Term _v_328 = 0;
    u32 _v_329 = 0;
    u32 _v_330 = 0;
    Term _o_142[19];
    if (spin_54(e, _o_142, _id_4, _main_1, _main_1 == h1 ? q1 : blk_loc(e.mem, _main_1), _value_0, _value_1, _value_1 == h3 ? q3 : blk_loc(e.mem, _value_1), _result_21, _result_21 == h16 ? q16 : blk_loc(e.mem, _result_21), _result_22, _result_23, _result_23 == h18 ? q18 : blk_loc(e.mem, _result_23), _metadata_4, _metadata_4 == h4 ? q4 : blk_loc(e.mem, _metadata_4), _metadata_5, _metadata_5 == h5 ? q5 : blk_loc(e.mem, _metadata_5), _metadata_6, _metadata_6 == h6 ? q6 : blk_loc(e.mem, _metadata_6), _metadata_7, _metadata_7 == h7 ? q7 : blk_loc(e.mem, _metadata_7), _capacity_2, _depth_2, _high_2, _meta_5, _meta_6, _meta_7, _meta_7 == h13 ? q13 : blk_loc(e.mem, _meta_7), _meta_8, _meta_9) == 0) {
      return 0;
    }
    _v_312 = _o_142[0];
    _v_313 = _o_142[1];
    _v_314 = _o_142[2];
    _v_315 = _o_142[3];
    _v_316 = _o_142[4];
    _v_317 = _o_142[5];
    _v_318 = _o_142[6];
    _v_319 = _o_142[7];
    _v_320 = _o_142[8];
    _v_321 = _o_142[9];
    _v_322 = _o_142[10];
    _v_323 = _o_142[11];
    _v_324 = _o_142[12];
    _v_325 = _o_142[13];
    _v_326 = _o_142[14];
    _v_327 = _o_142[15];
    _v_328 = _o_142[16];
    _v_329 = _o_142[17];
    _v_330 = _o_142[18];
    _v_293 = _v_312;
    _v_294 = _v_313;
    _v_295 = _v_314;
    _v_296 = _v_315;
    _v_297 = _v_316;
    _v_298 = _v_317;
    _v_299 = _v_318;
    _v_300 = _v_319;
    _v_301 = _v_320;
    _v_302 = _v_321;
    _v_303 = _v_322;
    _v_304 = _v_323;
    _v_305 = _v_324;
    _v_306 = _v_325;
    _v_307 = _v_326;
    _v_308 = _v_327;
    _v_309 = _v_328;
    _v_310 = _v_329;
    _v_311 = _v_330;
  break;
  }
  o[0] = _v_293;
  o[1] = _v_294;
  o[2] = _v_295;
  o[3] = _v_296;
  o[4] = _v_297;
  o[5] = _v_298;
  o[6] = _v_299;
  o[7] = _v_300;
  o[8] = _v_301;
  o[9] = _v_302;
  o[10] = _v_303;
  o[11] = _v_304;
  o[12] = _v_305;
  o[13] = _v_306;
  o[14] = _v_307;
  o[15] = _v_308;
  o[16] = _v_309;
  o[17] = _v_310;
  o[18] = _v_311;
  return 1;
}

INLINE Term spin_52(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, u32 r13, Term r14, u64 q14, u32 r15, Term r16, u64 q16) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term h14 = r14;
  Term h16 = r16;
  Term _v_255 = 0;
  Term _v_256 = 0;
  Term _v_257 = 0;
  Term _v_258 = 0;
  Term _v_259 = 0;
  Term _v_260 = 0;
  u32 _v_261 = 0;
  Term _v_262 = 0;
  u32 _v_263 = 0;
  u32 _v_264 = 0;
  u32 _v_265 = 0;
  u32 _v_266 = 0;
  Term _v_267 = 0;
  u32 _v_268 = 0;
  Term _v_269 = 0;
  u32 _v_270 = 0;
  Term _v_271 = 0;
  u32 _v_272 = 0;
  u32 _v_273 = 0;
  u32 _id_3 = r0;
  Term _aux_1 = r1;
  Term _metadata_0 = r2;
  Term _metadata_1 = r3;
  Term _metadata_2 = r4;
  Term _metadata_3 = r5;
  u32 _capacity_1 = r6;
  Term _depth_1 = r7;
  u32 _high_1 = r8;
  u32 _meta_0 = r9;
  u32 _meta_1 = r10;
  Term _meta_2 = r11;
  u32 _meta_3 = r12;
  u32 _meta_4 = r13;
  Term _result_18 = r14;
  u32 _result_19 = r15;
  Term _result_20 = r16;
  WL_SPIN
    Term _at_64 = _aux_1 == h1 ? q1 : blk_loc(e.mem, _aux_1);
    Term _at_65 = blk_at(_aux_1, U32_BIN(_id_3, -, 1ull), 1);
    u32 _c_34 = blk_read(e.mem, 1, _at_64, _at_65 + 0);
    Term _c_35 = e.mem[_at_64 + _at_65 + 1];
    blk_write(e.mem, 1, _at_64, _at_65 + 0, 0);
    blk_write(e.mem, 1, _at_64, _at_65 + 1, 0);
    Term _v_274 = 0;
    Term _v_275 = 0;
    Term _v_276 = 0;
    Term _v_277 = 0;
    Term _v_278 = 0;
    Term _v_279 = 0;
    u32 _v_280 = 0;
    Term _v_281 = 0;
    u32 _v_282 = 0;
    u32 _v_283 = 0;
    u32 _v_284 = 0;
    u32 _v_285 = 0;
    Term _v_286 = 0;
    u32 _v_287 = 0;
    Term _v_288 = 0;
    u32 _v_289 = 0;
    Term _v_290 = 0;
    u32 _v_291 = 0;
    u32 _v_292 = 0;
    Term _o_143[19];
    if (spin_53(e, _o_143, _id_3, _result_18, _result_18 == h14 ? q14 : blk_loc(e.mem, _result_18), _result_19, _result_20, _result_20 == h16 ? q16 : blk_loc(e.mem, _result_20), _metadata_0, _metadata_0 == h2 ? q2 : blk_loc(e.mem, _metadata_0), _metadata_1, _metadata_1 == h3 ? q3 : blk_loc(e.mem, _metadata_1), _metadata_2, _metadata_2 == h4 ? q4 : blk_loc(e.mem, _metadata_2), _metadata_3, _metadata_3 == h5 ? q5 : blk_loc(e.mem, _metadata_3), _capacity_1, _depth_1, _high_1, _meta_0, _meta_1, _meta_2, _meta_2 == h11 ? q11 : blk_loc(e.mem, _meta_2), _meta_3, _meta_4, _aux_1, _aux_1 == h1 ? q1 : blk_loc(e.mem, _aux_1), _c_34, _c_35, _c_35 == h16 ? q16 : _c_35 == h14 ? q14 : _c_35 == h11 ? q11 : _c_35 == h5 ? q5 : _c_35 == h4 ? q4 : _c_35 == h3 ? q3 : _c_35 == h2 ? q2 : _c_35 == h1 ? q1 : blk_loc(e.mem, _c_35)) == 0) {
      return 0;
    }
    _v_274 = _o_143[0];
    _v_275 = _o_143[1];
    _v_276 = _o_143[2];
    _v_277 = _o_143[3];
    _v_278 = _o_143[4];
    _v_279 = _o_143[5];
    _v_280 = _o_143[6];
    _v_281 = _o_143[7];
    _v_282 = _o_143[8];
    _v_283 = _o_143[9];
    _v_284 = _o_143[10];
    _v_285 = _o_143[11];
    _v_286 = _o_143[12];
    _v_287 = _o_143[13];
    _v_288 = _o_143[14];
    _v_289 = _o_143[15];
    _v_290 = _o_143[16];
    _v_291 = _o_143[17];
    _v_292 = _o_143[18];
    _v_255 = _v_274;
    _v_256 = _v_275;
    _v_257 = _v_276;
    _v_258 = _v_277;
    _v_259 = _v_278;
    _v_260 = _v_279;
    _v_261 = _v_280;
    _v_262 = _v_281;
    _v_263 = _v_282;
    _v_264 = _v_283;
    _v_265 = _v_284;
    _v_266 = _v_285;
    _v_267 = _v_286;
    _v_268 = _v_287;
    _v_269 = _v_288;
    _v_270 = _v_289;
    _v_271 = _v_290;
    _v_272 = _v_291;
    _v_273 = _v_292;
  break;
  }
  o[0] = _v_255;
  o[1] = _v_256;
  o[2] = _v_257;
  o[3] = _v_258;
  o[4] = _v_259;
  o[5] = _v_260;
  o[6] = _v_261;
  o[7] = _v_262;
  o[8] = _v_263;
  o[9] = _v_264;
  o[10] = _v_265;
  o[11] = _v_266;
  o[12] = _v_267;
  o[13] = _v_268;
  o[14] = _v_269;
  o[15] = _v_270;
  o[16] = _v_271;
  o[17] = _v_272;
  o[18] = _v_273;
  return 1;
}

INLINE Term spin_51(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, Term r4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, u32 r14) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h12 = r12;
  Term _v_217 = 0;
  Term _v_218 = 0;
  Term _v_219 = 0;
  Term _v_220 = 0;
  Term _v_221 = 0;
  Term _v_222 = 0;
  u32 _v_223 = 0;
  Term _v_224 = 0;
  u32 _v_225 = 0;
  u32 _v_226 = 0;
  u32 _v_227 = 0;
  u32 _v_228 = 0;
  Term _v_229 = 0;
  u32 _v_230 = 0;
  Term _v_231 = 0;
  u32 _v_232 = 0;
  Term _v_233 = 0;
  u32 _v_234 = 0;
  u32 _v_235 = 0;
  u32 _id_2 = r0;
  Term _main_0 = r1;
  Term _aux_0 = r2;
  u32 _capacity_0 = r3;
  Term _depth_0 = r4;
  u32 _high_0 = r5;
  Term _result_9 = r6;
  Term _result_10 = r7;
  Term _result_11 = r8;
  Term _result_12 = r9;
  u32 _result_13 = r10;
  u32 _result_14 = r11;
  Term _result_15 = r12;
  u32 _result_16 = r13;
  u32 _result_17 = r14;
  WL_SPIN
    if (_result_13 == 0) {
      term_sink(e, _result_15);
      _v_217 = _main_0;
      _v_218 = _aux_0;
      _v_219 = _result_9;
      _v_220 = _result_10;
      _v_221 = _result_11;
      _v_222 = _result_12;
      _v_223 = _capacity_0;
      _v_224 = _depth_0;
      _v_225 = _high_0;
      _v_226 = 0;
      _v_227 = 0;
      _v_228 = 0;
      _v_229 = 0;
      _v_230 = 0;
      _v_231 = 0;
      _v_232 = 0;
      _v_233 = 0;
      _v_234 = 0;
      _v_235 = 0;
    } else {
      Term _at_62 = _main_0 == h1 ? q1 : blk_loc(e.mem, _main_0);
      Term _at_63 = blk_at(_main_0, _id_2, 1);
      u32 _c_32 = blk_read(e.mem, 1, _at_62, _at_63 + 0);
      Term _c_33 = e.mem[_at_62 + _at_63 + 1];
      blk_write(e.mem, 1, _at_62, _at_63 + 0, 0);
      blk_write(e.mem, 1, _at_62, _at_63 + 1, 0);
      Term _v_236 = 0;
      Term _v_237 = 0;
      Term _v_238 = 0;
      Term _v_239 = 0;
      Term _v_240 = 0;
      Term _v_241 = 0;
      u32 _v_242 = 0;
      Term _v_243 = 0;
      u32 _v_244 = 0;
      u32 _v_245 = 0;
      u32 _v_246 = 0;
      u32 _v_247 = 0;
      Term _v_248 = 0;
      u32 _v_249 = 0;
      Term _v_250 = 0;
      u32 _v_251 = 0;
      Term _v_252 = 0;
      u32 _v_253 = 0;
      u32 _v_254 = 0;
      Term _o_144[19];
      if (spin_52(e, _o_144, _id_2, _aux_0, _aux_0 == h2 ? q2 : blk_loc(e.mem, _aux_0), _result_9, _result_9 == h6 ? q6 : blk_loc(e.mem, _result_9), _result_10, _result_10 == h7 ? q7 : blk_loc(e.mem, _result_10), _result_11, _result_11 == h8 ? q8 : blk_loc(e.mem, _result_11), _result_12, _result_12 == h9 ? q9 : blk_loc(e.mem, _result_12), _capacity_0, _depth_0, _high_0, 1, _result_14, _result_15, _result_15 == h12 ? q12 : blk_loc(e.mem, _result_15), _result_16, _result_17, _main_0, _main_0 == h1 ? q1 : blk_loc(e.mem, _main_0), _c_32, _c_33, _c_33 == h12 ? q12 : _c_33 == h9 ? q9 : _c_33 == h8 ? q8 : _c_33 == h7 ? q7 : _c_33 == h6 ? q6 : _c_33 == h2 ? q2 : _c_33 == h1 ? q1 : blk_loc(e.mem, _c_33)) == 0) {
        return 0;
      }
      _v_236 = _o_144[0];
      _v_237 = _o_144[1];
      _v_238 = _o_144[2];
      _v_239 = _o_144[3];
      _v_240 = _o_144[4];
      _v_241 = _o_144[5];
      _v_242 = _o_144[6];
      _v_243 = _o_144[7];
      _v_244 = _o_144[8];
      _v_245 = _o_144[9];
      _v_246 = _o_144[10];
      _v_247 = _o_144[11];
      _v_248 = _o_144[12];
      _v_249 = _o_144[13];
      _v_250 = _o_144[14];
      _v_251 = _o_144[15];
      _v_252 = _o_144[16];
      _v_253 = _o_144[17];
      _v_254 = _o_144[18];
      _v_217 = _v_236;
      _v_218 = _v_237;
      _v_219 = _v_238;
      _v_220 = _v_239;
      _v_221 = _v_240;
      _v_222 = _v_241;
      _v_223 = _v_242;
      _v_224 = _v_243;
      _v_225 = _v_244;
      _v_226 = _v_245;
      _v_227 = _v_246;
      _v_228 = _v_247;
      _v_229 = _v_248;
      _v_230 = _v_249;
      _v_231 = _v_250;
      _v_232 = _v_251;
      _v_233 = _v_252;
      _v_234 = _v_253;
      _v_235 = _v_254;
    }
  break;
  }
  o[0] = _v_217;
  o[1] = _v_218;
  o[2] = _v_219;
  o[3] = _v_220;
  o[4] = _v_221;
  o[5] = _v_222;
  o[6] = _v_223;
  o[7] = _v_224;
  o[8] = _v_225;
  o[9] = _v_226;
  o[10] = _v_227;
  o[11] = _v_228;
  o[12] = _v_229;
  o[13] = _v_230;
  o[14] = _v_231;
  o[15] = _v_232;
  o[16] = _v_233;
  o[17] = _v_234;
  o[18] = _v_235;
  return 1;
}

INLINE Term spin_45(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term _v_80 = 0;
  Term _v_81 = 0;
  Term _v_82 = 0;
  Term _v_83 = 0;
  Term _v_84 = 0;
  Term _v_85 = 0;
  u32 _v_86 = 0;
  Term _v_87 = 0;
  u32 _v_88 = 0;
  u32 _v_89 = 0;
  u32 _v_90 = 0;
  u32 _v_91 = 0;
  Term _v_92 = 0;
  u32 _v_93 = 0;
  Term _v_94 = 0;
  u32 _v_95 = 0;
  Term _v_96 = 0;
  u32 _v_97 = 0;
  u32 _v_98 = 0;
  u32 _valid_0 = r0;
  u32 _id_1 = r1;
  Term _rows_18 = r2;
  Term _rows_19 = r3;
  Term _rows_20 = r4;
  Term _rows_21 = r5;
  Term _rows_22 = r6;
  Term _rows_23 = r7;
  u32 _rows_24 = r8;
  Term _rows_25 = r9;
  u32 _rows_26 = r10;
  WL_SPIN
    if (_valid_0 == 0) {
      _v_80 = _rows_18;
      _v_81 = _rows_19;
      _v_82 = _rows_20;
      _v_83 = _rows_21;
      _v_84 = _rows_22;
      _v_85 = _rows_23;
      _v_86 = _rows_24;
      _v_87 = _rows_25;
      _v_88 = _rows_26;
      _v_89 = 0;
      _v_90 = 0;
      _v_91 = 0;
      _v_92 = 0;
      _v_93 = 0;
      _v_94 = 0;
      _v_95 = 0;
      _v_96 = 0;
      _v_97 = 0;
      _v_98 = 0;
    } else {
      Term _v_99 = 0;
      Term _v_100 = 0;
      Term _v_101 = 0;
      Term _v_102 = 0;
      u32 _v_103 = 0;
      u32 _v_104 = 0;
      Term _v_105 = 0;
      u32 _v_106 = 0;
      u32 _v_107 = 0;
      Term _v_108 = 0;
      Term _v_109 = 0;
      Term _v_110 = 0;
      Term _v_111 = 0;
      u32 _v_112 = 0;
      u32 _v_113 = 0;
      Term _v_114 = 0;
      u32 _v_115 = 0;
      u32 _v_116 = 0;
      Term _o_141[9];
      if (spin_46(e, _o_141, _rows_20, _rows_20 == h4 ? q4 : blk_loc(e.mem, _rows_20), _rows_21, _rows_21 == h5 ? q5 : blk_loc(e.mem, _rows_21), _rows_22, _rows_22 == h6 ? q6 : blk_loc(e.mem, _rows_22), _rows_23, _rows_23 == h7 ? q7 : blk_loc(e.mem, _rows_23), U32_BIN(_id_1, -, 1ull)) == 0) {
        return 0;
      }
      _v_108 = _o_141[0];
      _v_109 = _o_141[1];
      _v_110 = _o_141[2];
      _v_111 = _o_141[3];
      _v_112 = _o_141[4];
      _v_113 = _o_141[5];
      _v_114 = _o_141[6];
      _v_115 = _o_141[7];
      _v_116 = _o_141[8];
      _v_99 = _v_108;
      _v_100 = _v_109;
      _v_101 = _v_110;
      _v_102 = _v_111;
      _v_103 = _v_112;
      _v_104 = _v_113;
      _v_105 = _v_114;
      _v_106 = _v_115;
      _v_107 = _v_116;
      Term _v_198 = 0;
      Term _v_199 = 0;
      Term _v_200 = 0;
      Term _v_201 = 0;
      Term _v_202 = 0;
      Term _v_203 = 0;
      u32 _v_204 = 0;
      Term _v_205 = 0;
      u32 _v_206 = 0;
      u32 _v_207 = 0;
      u32 _v_208 = 0;
      u32 _v_209 = 0;
      Term _v_210 = 0;
      u32 _v_211 = 0;
      Term _v_212 = 0;
      u32 _v_213 = 0;
      Term _v_214 = 0;
      u32 _v_215 = 0;
      u32 _v_216 = 0;
      Term _o_145[19];
      if (spin_51(e, _o_145, _id_1, _rows_18, _rows_18 == h2 ? q2 : blk_loc(e.mem, _rows_18), _rows_19, _rows_19 == h3 ? q3 : blk_loc(e.mem, _rows_19), _rows_24, _rows_25, _rows_26, _v_99, _v_99 == h7 ? q7 : _v_99 == h6 ? q6 : _v_99 == h5 ? q5 : _v_99 == h4 ? q4 : _v_99 == h3 ? q3 : _v_99 == h2 ? q2 : blk_loc(e.mem, _v_99), _v_100, _v_100 == h7 ? q7 : _v_100 == h6 ? q6 : _v_100 == h5 ? q5 : _v_100 == h4 ? q4 : _v_100 == h3 ? q3 : _v_100 == h2 ? q2 : blk_loc(e.mem, _v_100), _v_101, _v_101 == h7 ? q7 : _v_101 == h6 ? q6 : _v_101 == h5 ? q5 : _v_101 == h4 ? q4 : _v_101 == h3 ? q3 : _v_101 == h2 ? q2 : blk_loc(e.mem, _v_101), _v_102, _v_102 == h7 ? q7 : _v_102 == h6 ? q6 : _v_102 == h5 ? q5 : _v_102 == h4 ? q4 : _v_102 == h3 ? q3 : _v_102 == h2 ? q2 : blk_loc(e.mem, _v_102), _v_103, _v_104, _v_105, _v_105 == h7 ? q7 : _v_105 == h6 ? q6 : _v_105 == h5 ? q5 : _v_105 == h4 ? q4 : _v_105 == h3 ? q3 : _v_105 == h2 ? q2 : blk_loc(e.mem, _v_105), _v_106, _v_107) == 0) {
        return 0;
      }
      _v_198 = _o_145[0];
      _v_199 = _o_145[1];
      _v_200 = _o_145[2];
      _v_201 = _o_145[3];
      _v_202 = _o_145[4];
      _v_203 = _o_145[5];
      _v_204 = _o_145[6];
      _v_205 = _o_145[7];
      _v_206 = _o_145[8];
      _v_207 = _o_145[9];
      _v_208 = _o_145[10];
      _v_209 = _o_145[11];
      _v_210 = _o_145[12];
      _v_211 = _o_145[13];
      _v_212 = _o_145[14];
      _v_213 = _o_145[15];
      _v_214 = _o_145[16];
      _v_215 = _o_145[17];
      _v_216 = _o_145[18];
      _v_80 = _v_198;
      _v_81 = _v_199;
      _v_82 = _v_200;
      _v_83 = _v_201;
      _v_84 = _v_202;
      _v_85 = _v_203;
      _v_86 = _v_204;
      _v_87 = _v_205;
      _v_88 = _v_206;
      _v_89 = _v_207;
      _v_90 = _v_208;
      _v_91 = _v_209;
      _v_92 = _v_210;
      _v_93 = _v_211;
      _v_94 = _v_212;
      _v_95 = _v_213;
      _v_96 = _v_214;
      _v_97 = _v_215;
      _v_98 = _v_216;
    }
  break;
  }
  o[0] = _v_80;
  o[1] = _v_81;
  o[2] = _v_82;
  o[3] = _v_83;
  o[4] = _v_84;
  o[5] = _v_85;
  o[6] = _v_86;
  o[7] = _v_87;
  o[8] = _v_88;
  o[9] = _v_89;
  o[10] = _v_90;
  o[11] = _v_91;
  o[12] = _v_92;
  o[13] = _v_93;
  o[14] = _v_94;
  o[15] = _v_95;
  o[16] = _v_96;
  o[17] = _v_97;
  o[18] = _v_98;
  return 1;
}

INLINE Term spin_44(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  u32 _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  Term _v_50 = 0;
  u32 _v_51 = 0;
  Term _v_52 = 0;
  u32 _v_53 = 0;
  Term _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  Term _rows_9 = r0;
  Term _rows_10 = r1;
  Term _rows_11 = r2;
  Term _rows_12 = r3;
  Term _rows_13 = r4;
  Term _rows_14 = r5;
  u32 _rows_15 = r6;
  Term _rows_16 = r7;
  u32 _rows_17 = r8;
  u32 _id_0 = r9;
  WL_SPIN
    u32 _v_57 = 0;
    u32 _v_58 = 0;
    u32 _v_59 = 0;
    Term _o_135[1];
    if (spin_23(e, _o_135, U32_BIN(_id_0, <=, _rows_15), U32_BIN(_id_0, <=, _rows_17)) == 0) {
      return 0;
    }
    _v_59 = _o_135[0];
    _v_58 = _v_59;
    u32 _v_60 = 0;
    Term _o_136[1];
    if (spin_23(e, _o_136, U32_BIN(0ull, <, _id_0), _v_58) == 0) {
      return 0;
    }
    _v_60 = _o_136[0];
    _v_57 = _v_60;
    Term _v_61 = 0;
    Term _v_62 = 0;
    Term _v_63 = 0;
    Term _v_64 = 0;
    Term _v_65 = 0;
    Term _v_66 = 0;
    u32 _v_67 = 0;
    Term _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    Term _v_73 = 0;
    u32 _v_74 = 0;
    Term _v_75 = 0;
    u32 _v_76 = 0;
    Term _v_77 = 0;
    u32 _v_78 = 0;
    u32 _v_79 = 0;
    Term _o_146[19];
    if (spin_45(e, _o_146, _v_57, _id_0, _rows_9, _rows_9 == h0 ? q0 : blk_loc(e.mem, _rows_9), _rows_10, _rows_10 == h1 ? q1 : blk_loc(e.mem, _rows_10), _rows_11, _rows_11 == h2 ? q2 : blk_loc(e.mem, _rows_11), _rows_12, _rows_12 == h3 ? q3 : blk_loc(e.mem, _rows_12), _rows_13, _rows_13 == h4 ? q4 : blk_loc(e.mem, _rows_13), _rows_14, _rows_14 == h5 ? q5 : blk_loc(e.mem, _rows_14), _rows_15, _rows_16, _rows_17) == 0) {
      return 0;
    }
    _v_61 = _o_146[0];
    _v_62 = _o_146[1];
    _v_63 = _o_146[2];
    _v_64 = _o_146[3];
    _v_65 = _o_146[4];
    _v_66 = _o_146[5];
    _v_67 = _o_146[6];
    _v_68 = _o_146[7];
    _v_69 = _o_146[8];
    _v_70 = _o_146[9];
    _v_71 = _o_146[10];
    _v_72 = _o_146[11];
    _v_73 = _o_146[12];
    _v_74 = _o_146[13];
    _v_75 = _o_146[14];
    _v_76 = _o_146[15];
    _v_77 = _o_146[16];
    _v_78 = _o_146[17];
    _v_79 = _o_146[18];
    _v_38 = _v_61;
    _v_39 = _v_62;
    _v_40 = _v_63;
    _v_41 = _v_64;
    _v_42 = _v_65;
    _v_43 = _v_66;
    _v_44 = _v_67;
    _v_45 = _v_68;
    _v_46 = _v_69;
    _v_47 = _v_70;
    _v_48 = _v_71;
    _v_49 = _v_72;
    _v_50 = _v_73;
    _v_51 = _v_74;
    _v_52 = _v_75;
    _v_53 = _v_76;
    _v_54 = _v_77;
    _v_55 = _v_78;
    _v_56 = _v_79;
  break;
  }
  o[0] = _v_38;
  o[1] = _v_39;
  o[2] = _v_40;
  o[3] = _v_41;
  o[4] = _v_42;
  o[5] = _v_43;
  o[6] = _v_44;
  o[7] = _v_45;
  o[8] = _v_46;
  o[9] = _v_47;
  o[10] = _v_48;
  o[11] = _v_49;
  o[12] = _v_50;
  o[13] = _v_51;
  o[14] = _v_52;
  o[15] = _v_53;
  o[16] = _v_54;
  o[17] = _v_55;
  o[18] = _v_56;
  return 1;
}

INLINE Term spin_58(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, Term r10, u64 q10, u32 r11, Term r12, u64 q12, Term r13, u64 q13, u32 r14, u32 r15, Term r16, u64 q16, u32 r17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h10 = r10;
  Term h12 = r12;
  Term h13 = r13;
  Term h16 = r16;
  u32 _v_796 = 0;
  u32 _v_797 = 0;
  Term _v_798 = 0;
  Term _v_799 = 0;
  Term _v_800 = 0;
  Term _v_801 = 0;
  Term _v_802 = 0;
  Term _v_803 = 0;
  u32 _v_804 = 0;
  Term _v_805 = 0;
  u32 _v_806 = 0;
  Term _v_807 = 0;
  u32 _v_808 = 0;
  Term _v_809 = 0;
  Term _v_810 = 0;
  u32 _namespace_2 = r0;
  u32 _next_2 = r1;
  Term _main_5 = r2;
  Term _aux_5 = r3;
  Term _flags_3 = r4;
  Term _added_3 = r5;
  Term _changed_3 = r6;
  u32 _capacity_6 = r7;
  Term _depth_6 = r8;
  u32 _high_6 = r9;
  Term _pending_2 = r10;
  u32 _ledger_4 = r11;
  Term _ledger_5 = r12;
  Term _mode_2 = r13;
  u32 _index_5 = r14;
  u32 _tick_3 = r15;
  Term _result_24 = r16;
  u32 _result_25 = r17;
  WL_SPIN
    if (_result_25 == 0) {
      _v_796 = _namespace_2;
      _v_797 = _next_2;
      _v_798 = _main_5;
      _v_799 = _aux_5;
      _v_800 = _result_24;
      _v_801 = _flags_3;
      _v_802 = _added_3;
      _v_803 = _changed_3;
      _v_804 = _capacity_6;
      _v_805 = _depth_6;
      _v_806 = _high_6;
      _v_807 = _pending_2;
      _v_808 = _ledger_4;
      _v_809 = _ledger_5;
      _v_810 = _mode_2;
    } else {
      Term _at_68 = _changed_3 == h6 ? q6 : blk_loc(e.mem, _changed_3);
      Term _at_69 = blk_at(_changed_3, _index_5, 0);
      u32 _c_41 = blk_read(e.mem, 0, _at_68, _at_69 + 0);
      blk_write(e.mem, 0, _at_68, _at_69 + 0, _tick_3);
      _v_796 = _namespace_2;
      _v_797 = _next_2;
      _v_798 = _main_5;
      _v_799 = _aux_5;
      _v_800 = _result_24;
      _v_801 = _flags_3;
      _v_802 = _added_3;
      _v_803 = _changed_3;
      _v_804 = _capacity_6;
      _v_805 = _depth_6;
      _v_806 = _high_6;
      _v_807 = _pending_2;
      _v_808 = _ledger_4;
      _v_809 = _ledger_5;
      _v_810 = _mode_2;
    }
  break;
  }
  o[0] = _v_796;
  o[1] = _v_797;
  o[2] = _v_798;
  o[3] = _v_799;
  o[4] = _v_800;
  o[5] = _v_801;
  o[6] = _v_802;
  o[7] = _v_803;
  o[8] = _v_804;
  o[9] = _v_805;
  o[10] = _v_806;
  o[11] = _v_807;
  o[12] = _v_808;
  o[13] = _v_809;
  o[14] = _v_810;
  return 1;
}

INLINE Term spin_57(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, u32 r16) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h11 = r11;
  Term h13 = r13;
  Term h14 = r14;
  u32 _v_766 = 0;
  u32 _v_767 = 0;
  Term _v_768 = 0;
  Term _v_769 = 0;
  Term _v_770 = 0;
  Term _v_771 = 0;
  Term _v_772 = 0;
  Term _v_773 = 0;
  u32 _v_774 = 0;
  Term _v_775 = 0;
  u32 _v_776 = 0;
  Term _v_777 = 0;
  u32 _v_778 = 0;
  Term _v_779 = 0;
  Term _v_780 = 0;
  u32 _namespace_1 = r0;
  u32 _next_1 = r1;
  Term _main_4 = r2;
  Term _aux_4 = r3;
  Term _metadata_16 = r4;
  Term _metadata_17 = r5;
  Term _metadata_18 = r6;
  Term _metadata_19 = r7;
  u32 _capacity_5 = r8;
  Term _depth_5 = r9;
  u32 _high_5 = r10;
  Term _pending_1 = r11;
  u32 _ledger_2 = r12;
  Term _ledger_3 = r13;
  Term _mode_1 = r14;
  u32 _index_4 = r15;
  u32 _tick_2 = r16;
  WL_SPIN
    Term _at_66 = _metadata_16 == h4 ? q4 : blk_loc(e.mem, _metadata_16);
    Term _at_67 = blk_at(_metadata_16, _index_4, 0);
    u32 _c_40 = blk_read(e.mem, 0, _at_66, _at_67 + 0);
    u32 _v_781 = 0;
    u32 _v_782 = 0;
    Term _v_783 = 0;
    Term _v_784 = 0;
    Term _v_785 = 0;
    Term _v_786 = 0;
    Term _v_787 = 0;
    Term _v_788 = 0;
    u32 _v_789 = 0;
    Term _v_790 = 0;
    u32 _v_791 = 0;
    Term _v_792 = 0;
    u32 _v_793 = 0;
    Term _v_794 = 0;
    Term _v_795 = 0;
    Term _o_339[15];
    if (spin_58(e, _o_339, _namespace_1, _next_1, _main_4, _main_4 == h2 ? q2 : blk_loc(e.mem, _main_4), _aux_4, _aux_4 == h3 ? q3 : blk_loc(e.mem, _aux_4), _metadata_17, _metadata_17 == h5 ? q5 : blk_loc(e.mem, _metadata_17), _metadata_18, _metadata_18 == h6 ? q6 : blk_loc(e.mem, _metadata_18), _metadata_19, _metadata_19 == h7 ? q7 : blk_loc(e.mem, _metadata_19), _capacity_5, _depth_5, _high_5, _pending_1, _pending_1 == h11 ? q11 : blk_loc(e.mem, _pending_1), _ledger_2, _ledger_3, _ledger_3 == h13 ? q13 : blk_loc(e.mem, _ledger_3), _mode_1, _mode_1 == h14 ? q14 : blk_loc(e.mem, _mode_1), _index_4, _tick_2, _metadata_16, _metadata_16 == h4 ? q4 : blk_loc(e.mem, _metadata_16), _c_40) == 0) {
      return 0;
    }
    _v_781 = _o_339[0];
    _v_782 = _o_339[1];
    _v_783 = _o_339[2];
    _v_784 = _o_339[3];
    _v_785 = _o_339[4];
    _v_786 = _o_339[5];
    _v_787 = _o_339[6];
    _v_788 = _o_339[7];
    _v_789 = _o_339[8];
    _v_790 = _o_339[9];
    _v_791 = _o_339[10];
    _v_792 = _o_339[11];
    _v_793 = _o_339[12];
    _v_794 = _o_339[13];
    _v_795 = _o_339[14];
    _v_766 = _v_781;
    _v_767 = _v_782;
    _v_768 = _v_783;
    _v_769 = _v_784;
    _v_770 = _v_785;
    _v_771 = _v_786;
    _v_772 = _v_787;
    _v_773 = _v_788;
    _v_774 = _v_789;
    _v_775 = _v_790;
    _v_776 = _v_791;
    _v_777 = _v_792;
    _v_778 = _v_793;
    _v_779 = _v_794;
    _v_780 = _v_795;
  break;
  }
  o[0] = _v_766;
  o[1] = _v_767;
  o[2] = _v_768;
  o[3] = _v_769;
  o[4] = _v_770;
  o[5] = _v_771;
  o[6] = _v_772;
  o[7] = _v_773;
  o[8] = _v_774;
  o[9] = _v_775;
  o[10] = _v_776;
  o[11] = _v_777;
  o[12] = _v_778;
  o[13] = _v_779;
  o[14] = _v_780;
  return 1;
}

INLINE Term spin_56(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, Term r10, u32 r11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, Term r15, u64 q15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h12 = r12;
  Term h14 = r14;
  Term h15 = r15;
  u32 _v_736 = 0;
  u32 _v_737 = 0;
  Term _v_738 = 0;
  Term _v_739 = 0;
  Term _v_740 = 0;
  Term _v_741 = 0;
  Term _v_742 = 0;
  Term _v_743 = 0;
  u32 _v_744 = 0;
  Term _v_745 = 0;
  u32 _v_746 = 0;
  Term _v_747 = 0;
  u32 _v_748 = 0;
  Term _v_749 = 0;
  Term _v_750 = 0;
  u32 _valid_1 = r0;
  u32 _namespace_0 = r1;
  u32 _next_0 = r2;
  Term _main_3 = r3;
  Term _aux_3 = r4;
  Term _metadata_12 = r5;
  Term _metadata_13 = r6;
  Term _metadata_14 = r7;
  Term _metadata_15 = r8;
  u32 _capacity_4 = r9;
  Term _depth_4 = r10;
  u32 _high_4 = r11;
  Term _pending_0 = r12;
  u32 _ledger_0 = r13;
  Term _ledger_1 = r14;
  Term _mode_0 = r15;
  u32 _id_6 = r16;
  u32 _tick_1 = r17;
  WL_SPIN
    if (_valid_1 == 0) {
      _v_736 = _namespace_0;
      _v_737 = _next_0;
      _v_738 = _main_3;
      _v_739 = _aux_3;
      _v_740 = _metadata_12;
      _v_741 = _metadata_13;
      _v_742 = _metadata_14;
      _v_743 = _metadata_15;
      _v_744 = _capacity_4;
      _v_745 = _depth_4;
      _v_746 = _high_4;
      _v_747 = _pending_0;
      _v_748 = _ledger_0;
      _v_749 = _ledger_1;
      _v_750 = _mode_0;
    } else {
      u32 _v_751 = 0;
      u32 _v_752 = 0;
      Term _v_753 = 0;
      Term _v_754 = 0;
      Term _v_755 = 0;
      Term _v_756 = 0;
      Term _v_757 = 0;
      Term _v_758 = 0;
      u32 _v_759 = 0;
      Term _v_760 = 0;
      u32 _v_761 = 0;
      Term _v_762 = 0;
      u32 _v_763 = 0;
      Term _v_764 = 0;
      Term _v_765 = 0;
      Term _o_340[15];
      if (spin_57(e, _o_340, _namespace_0, _next_0, _main_3, _main_3 == h3 ? q3 : blk_loc(e.mem, _main_3), _aux_3, _aux_3 == h4 ? q4 : blk_loc(e.mem, _aux_3), _metadata_12, _metadata_12 == h5 ? q5 : blk_loc(e.mem, _metadata_12), _metadata_13, _metadata_13 == h6 ? q6 : blk_loc(e.mem, _metadata_13), _metadata_14, _metadata_14 == h7 ? q7 : blk_loc(e.mem, _metadata_14), _metadata_15, _metadata_15 == h8 ? q8 : blk_loc(e.mem, _metadata_15), _capacity_4, _depth_4, _high_4, _pending_0, _pending_0 == h12 ? q12 : blk_loc(e.mem, _pending_0), _ledger_0, _ledger_1, _ledger_1 == h14 ? q14 : blk_loc(e.mem, _ledger_1), _mode_0, _mode_0 == h15 ? q15 : blk_loc(e.mem, _mode_0), U32_BIN(_id_6, -, 1ull), _tick_1) == 0) {
        return 0;
      }
      _v_751 = _o_340[0];
      _v_752 = _o_340[1];
      _v_753 = _o_340[2];
      _v_754 = _o_340[3];
      _v_755 = _o_340[4];
      _v_756 = _o_340[5];
      _v_757 = _o_340[6];
      _v_758 = _o_340[7];
      _v_759 = _o_340[8];
      _v_760 = _o_340[9];
      _v_761 = _o_340[10];
      _v_762 = _o_340[11];
      _v_763 = _o_340[12];
      _v_764 = _o_340[13];
      _v_765 = _o_340[14];
      _v_736 = _v_751;
      _v_737 = _v_752;
      _v_738 = _v_753;
      _v_739 = _v_754;
      _v_740 = _v_755;
      _v_741 = _v_756;
      _v_742 = _v_757;
      _v_743 = _v_758;
      _v_744 = _v_759;
      _v_745 = _v_760;
      _v_746 = _v_761;
      _v_747 = _v_762;
      _v_748 = _v_763;
      _v_749 = _v_764;
      _v_750 = _v_765;
    }
  break;
  }
  o[0] = _v_736;
  o[1] = _v_737;
  o[2] = _v_738;
  o[3] = _v_739;
  o[4] = _v_740;
  o[5] = _v_741;
  o[6] = _v_742;
  o[7] = _v_743;
  o[8] = _v_744;
  o[9] = _v_745;
  o[10] = _v_746;
  o[11] = _v_747;
  o[12] = _v_748;
  o[13] = _v_749;
  o[14] = _v_750;
  return 1;
}

INLINE Term spin_55(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h11 = r11;
  Term h13 = r13;
  Term h14 = r14;
  u32 _v_700 = 0;
  u32 _v_701 = 0;
  Term _v_702 = 0;
  Term _v_703 = 0;
  Term _v_704 = 0;
  Term _v_705 = 0;
  Term _v_706 = 0;
  Term _v_707 = 0;
  u32 _v_708 = 0;
  Term _v_709 = 0;
  u32 _v_710 = 0;
  Term _v_711 = 0;
  u32 _v_712 = 0;
  Term _v_713 = 0;
  Term _v_714 = 0;
  u32 _world_4 = r0;
  u32 _world_5 = r1;
  Term _world_6 = r2;
  Term _world_7 = r3;
  Term _world_8 = r4;
  Term _world_9 = r5;
  Term _world_10 = r6;
  Term _world_11 = r7;
  u32 _world_12 = r8;
  Term _world_13 = r9;
  u32 _world_14 = r10;
  Term _world_15 = r11;
  u32 _world_16 = r12;
  Term _world_17 = r13;
  Term _world_18 = r14;
  u32 _handle_0 = r15;
  u32 _handle_1 = r16;
  u32 _tick_0 = r17;
  WL_SPIN
    u32 _v_715 = 0;
    u32 _v_716 = 0;
    u32 _v_717 = 0;
    u32 _v_718 = 0;
    Term _o_336[1];
    if (spin_23(e, _o_336, U32_BIN(_handle_1, <=, _world_12), U32_BIN(_handle_1, <=, _world_14)) == 0) {
      return 0;
    }
    _v_718 = _o_336[0];
    _v_717 = _v_718;
    u32 _v_719 = 0;
    Term _o_337[1];
    if (spin_23(e, _o_337, U32_BIN(0ull, <, _handle_1), _v_717) == 0) {
      return 0;
    }
    _v_719 = _o_337[0];
    _v_716 = _v_719;
    u32 _v_720 = 0;
    Term _o_338[1];
    if (spin_23(e, _o_338, U32_BIN(_world_4, ==, _handle_0), _v_716) == 0) {
      return 0;
    }
    _v_720 = _o_338[0];
    _v_715 = _v_720;
    u32 _v_721 = 0;
    u32 _v_722 = 0;
    Term _v_723 = 0;
    Term _v_724 = 0;
    Term _v_725 = 0;
    Term _v_726 = 0;
    Term _v_727 = 0;
    Term _v_728 = 0;
    u32 _v_729 = 0;
    Term _v_730 = 0;
    u32 _v_731 = 0;
    Term _v_732 = 0;
    u32 _v_733 = 0;
    Term _v_734 = 0;
    Term _v_735 = 0;
    Term _o_341[15];
    if (spin_56(e, _o_341, _v_715, _world_4, _world_5, _world_6, _world_6 == h2 ? q2 : blk_loc(e.mem, _world_6), _world_7, _world_7 == h3 ? q3 : blk_loc(e.mem, _world_7), _world_8, _world_8 == h4 ? q4 : blk_loc(e.mem, _world_8), _world_9, _world_9 == h5 ? q5 : blk_loc(e.mem, _world_9), _world_10, _world_10 == h6 ? q6 : blk_loc(e.mem, _world_10), _world_11, _world_11 == h7 ? q7 : blk_loc(e.mem, _world_11), _world_12, _world_13, _world_14, _world_15, _world_15 == h11 ? q11 : blk_loc(e.mem, _world_15), _world_16, _world_17, _world_17 == h13 ? q13 : blk_loc(e.mem, _world_17), _world_18, _world_18 == h14 ? q14 : blk_loc(e.mem, _world_18), _handle_1, _tick_0) == 0) {
      return 0;
    }
    _v_721 = _o_341[0];
    _v_722 = _o_341[1];
    _v_723 = _o_341[2];
    _v_724 = _o_341[3];
    _v_725 = _o_341[4];
    _v_726 = _o_341[5];
    _v_727 = _o_341[6];
    _v_728 = _o_341[7];
    _v_729 = _o_341[8];
    _v_730 = _o_341[9];
    _v_731 = _o_341[10];
    _v_732 = _o_341[11];
    _v_733 = _o_341[12];
    _v_734 = _o_341[13];
    _v_735 = _o_341[14];
    _v_700 = _v_721;
    _v_701 = _v_722;
    _v_702 = _v_723;
    _v_703 = _v_724;
    _v_704 = _v_725;
    _v_705 = _v_726;
    _v_706 = _v_727;
    _v_707 = _v_728;
    _v_708 = _v_729;
    _v_709 = _v_730;
    _v_710 = _v_731;
    _v_711 = _v_732;
    _v_712 = _v_733;
    _v_713 = _v_734;
    _v_714 = _v_735;
  break;
  }
  o[0] = _v_700;
  o[1] = _v_701;
  o[2] = _v_702;
  o[3] = _v_703;
  o[4] = _v_704;
  o[5] = _v_705;
  o[6] = _v_706;
  o[7] = _v_707;
  o[8] = _v_708;
  o[9] = _v_709;
  o[10] = _v_710;
  o[11] = _v_711;
  o[12] = _v_712;
  o[13] = _v_713;
  o[14] = _v_714;
  return 1;
}

INLINE Term spin_59(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, Term r11, u64 q11, u32 r12) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h11 = r11;
  Term _v_829 = 0;
  Term _v_830 = 0;
  Term _v_831 = 0;
  Term _v_832 = 0;
  Term _v_833 = 0;
  Term _v_834 = 0;
  u32 _v_835 = 0;
  Term _v_836 = 0;
  u32 _v_837 = 0;
  u32 _world_19 = r0;
  u32 _world_20 = r1;
  Term _world_21 = r2;
  Term _world_22 = r3;
  Term _world_23 = r4;
  Term _world_24 = r5;
  Term _world_25 = r6;
  Term _world_26 = r7;
  u32 _world_27 = r8;
  Term _world_28 = r9;
  u32 _world_29 = r10;
  Term _world_30 = r11;
  u32 _world_31 = r12;
  WL_SPIN
    term_sink(e, _world_30);
    _v_829 = _world_21;
    _v_830 = _world_22;
    _v_831 = _world_23;
    _v_832 = _world_24;
    _v_833 = _world_25;
    _v_834 = _world_26;
    _v_835 = _world_27;
    _v_836 = _world_28;
    _v_837 = _world_29;
  break;
  }
  o[0] = _v_829;
  o[1] = _v_830;
  o[2] = _v_831;
  o[3] = _v_832;
  o[4] = _v_833;
  o[5] = _v_834;
  o[6] = _v_835;
  o[7] = _v_836;
  o[8] = _v_837;
  return 1;
}

INLINE Term spin_66(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, u32 r14, u32 r15, u32 r16, Term r17, u64 q17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h12 = r12;
  Term h17 = r17;
  Term _v_1114 = 0;
  Term _v_1115 = 0;
  Term _v_1116 = 0;
  Term _v_1117 = 0;
  Term _v_1118 = 0;
  Term _v_1119 = 0;
  u32 _v_1120 = 0;
  Term _v_1121 = 0;
  u32 _v_1122 = 0;
  u32 _v_1123 = 0;
  u32 _id_13 = r0;
  u32 _tick_10 = r1;
  Term _main_9 = r2;
  Term _aux_10 = r3;
  Term _metadata_32 = r4;
  Term _metadata_33 = r5;
  Term _metadata_34 = r6;
  Term _metadata_35 = r7;
  u32 _capacity_11 = r8;
  Term _depth_11 = r9;
  u32 _high_11 = r10;
  u32 _flag_4 = r11;
  Term _flag_5 = r12;
  u32 _added_6 = r13;
  u32 _changed_6 = r14;
  u32 _insert_1 = r15;
  u32 _old_0 = r16;
  Term _old_1 = r17;
  WL_SPIN
    if (_insert_1 == 0) {
      if (_old_0 == 0) {
        term_sink(e, _flag_5);
        _v_1114 = _main_9;
        _v_1115 = _aux_10;
        _v_1116 = _metadata_32;
        _v_1117 = _metadata_33;
        _v_1118 = _metadata_34;
        _v_1119 = _metadata_35;
        _v_1120 = _capacity_11;
        _v_1121 = _depth_11;
        _v_1122 = _high_11;
        _v_1123 = 4;
      } else {
        term_sink(e, _old_1);
        Term _v_1124 = 0;
        Term _v_1125 = 0;
        Term _v_1126 = 0;
        Term _v_1127 = 0;
        Term _v_1128 = 0;
        Term _v_1129 = 0;
        Term _v_1130 = 0;
        Term _v_1131 = 0;
        Term _o_486[4];
        if (spin_33(e, _o_486, _metadata_32, _metadata_32 == h4 ? q4 : blk_loc(e.mem, _metadata_32), _metadata_33, _metadata_33 == h5 ? q5 : blk_loc(e.mem, _metadata_33), _metadata_34, _metadata_34 == h6 ? q6 : blk_loc(e.mem, _metadata_34), _metadata_35, _metadata_35 == h7 ? q7 : blk_loc(e.mem, _metadata_35), U32_BIN(_id_13, -, 1ull), 1, _flag_4, _flag_5, _flag_5 == h12 ? q12 : blk_loc(e.mem, _flag_5), 0ull, 0ull) == 0) {
          return 0;
        }
        _v_1128 = _o_486[0];
        _v_1129 = _o_486[1];
        _v_1130 = _o_486[2];
        _v_1131 = _o_486[3];
        _v_1124 = _v_1128;
        _v_1125 = _v_1129;
        _v_1126 = _v_1130;
        _v_1127 = _v_1131;
        _v_1114 = _main_9;
        _v_1115 = _aux_10;
        _v_1116 = _v_1124;
        _v_1117 = _v_1125;
        _v_1118 = _v_1126;
        _v_1119 = _v_1127;
        _v_1120 = _capacity_11;
        _v_1121 = _depth_11;
        _v_1122 = _high_11;
        _v_1123 = 3;
      }
    } else {
      if (_old_0 == 0) {
        Term _v_1132 = 0;
        Term _v_1133 = 0;
        Term _v_1134 = 0;
        Term _v_1135 = 0;
        Term _v_1136 = 0;
        Term _v_1137 = 0;
        Term _v_1138 = 0;
        Term _v_1139 = 0;
        Term _o_487[4];
        if (spin_33(e, _o_487, _metadata_32, _metadata_32 == h4 ? q4 : blk_loc(e.mem, _metadata_32), _metadata_33, _metadata_33 == h5 ? q5 : blk_loc(e.mem, _metadata_33), _metadata_34, _metadata_34 == h6 ? q6 : blk_loc(e.mem, _metadata_34), _metadata_35, _metadata_35 == h7 ? q7 : blk_loc(e.mem, _metadata_35), U32_BIN(_id_13, -, 1ull), 1, _flag_4, _flag_5, _flag_5 == h12 ? q12 : blk_loc(e.mem, _flag_5), _tick_10, _tick_10) == 0) {
          return 0;
        }
        _v_1136 = _o_487[0];
        _v_1137 = _o_487[1];
        _v_1138 = _o_487[2];
        _v_1139 = _o_487[3];
        _v_1132 = _v_1136;
        _v_1133 = _v_1137;
        _v_1134 = _v_1138;
        _v_1135 = _v_1139;
        _v_1114 = _main_9;
        _v_1115 = _aux_10;
        _v_1116 = _v_1132;
        _v_1117 = _v_1133;
        _v_1118 = _v_1134;
        _v_1119 = _v_1135;
        _v_1120 = _capacity_11;
        _v_1121 = _depth_11;
        _v_1122 = _high_11;
        _v_1123 = 1;
      } else {
        term_sink(e, _old_1);
        Term _v_1140 = 0;
        Term _v_1141 = 0;
        Term _v_1142 = 0;
        Term _v_1143 = 0;
        Term _v_1144 = 0;
        Term _v_1145 = 0;
        Term _v_1146 = 0;
        Term _v_1147 = 0;
        Term _o_488[4];
        if (spin_33(e, _o_488, _metadata_32, _metadata_32 == h4 ? q4 : blk_loc(e.mem, _metadata_32), _metadata_33, _metadata_33 == h5 ? q5 : blk_loc(e.mem, _metadata_33), _metadata_34, _metadata_34 == h6 ? q6 : blk_loc(e.mem, _metadata_34), _metadata_35, _metadata_35 == h7 ? q7 : blk_loc(e.mem, _metadata_35), U32_BIN(_id_13, -, 1ull), 1, _flag_4, _flag_5, _flag_5 == h12 ? q12 : blk_loc(e.mem, _flag_5), _added_6, _tick_10) == 0) {
          return 0;
        }
        _v_1144 = _o_488[0];
        _v_1145 = _o_488[1];
        _v_1146 = _o_488[2];
        _v_1147 = _o_488[3];
        _v_1140 = _v_1144;
        _v_1141 = _v_1145;
        _v_1142 = _v_1146;
        _v_1143 = _v_1147;
        _v_1114 = _main_9;
        _v_1115 = _aux_10;
        _v_1116 = _v_1140;
        _v_1117 = _v_1141;
        _v_1118 = _v_1142;
        _v_1119 = _v_1143;
        _v_1120 = _capacity_11;
        _v_1121 = _depth_11;
        _v_1122 = _high_11;
        _v_1123 = 2;
      }
    }
  break;
  }
  o[0] = _v_1114;
  o[1] = _v_1115;
  o[2] = _v_1116;
  o[3] = _v_1117;
  o[4] = _v_1118;
  o[5] = _v_1119;
  o[6] = _v_1120;
  o[7] = _v_1121;
  o[8] = _v_1122;
  o[9] = _v_1123;
  return 1;
}

INLINE Term spin_65(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12, u32 r13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h11 = r11;
  Term h15 = r15;
  Term h17 = r17;
  Term _v_1094 = 0;
  Term _v_1095 = 0;
  Term _v_1096 = 0;
  Term _v_1097 = 0;
  Term _v_1098 = 0;
  Term _v_1099 = 0;
  u32 _v_1100 = 0;
  Term _v_1101 = 0;
  u32 _v_1102 = 0;
  u32 _v_1103 = 0;
  u32 _id_12 = r0;
  u32 _tick_9 = r1;
  Term _aux_9 = r2;
  Term _metadata_28 = r3;
  Term _metadata_29 = r4;
  Term _metadata_30 = r5;
  Term _metadata_31 = r6;
  u32 _capacity_10 = r7;
  Term _depth_10 = r8;
  u32 _high_10 = r9;
  u32 _flag_2 = r10;
  Term _flag_3 = r11;
  u32 _added_5 = r12;
  u32 _changed_5 = r13;
  u32 _insert_0 = r14;
  Term _result_35 = r15;
  u32 _result_36 = r16;
  Term _result_37 = r17;
  WL_SPIN
    Term _v_1104 = 0;
    Term _v_1105 = 0;
    Term _v_1106 = 0;
    Term _v_1107 = 0;
    Term _v_1108 = 0;
    Term _v_1109 = 0;
    u32 _v_1110 = 0;
    Term _v_1111 = 0;
    u32 _v_1112 = 0;
    u32 _v_1113 = 0;
    Term _o_489[10];
    if (spin_66(e, _o_489, _id_12, _tick_9, _result_35, _result_35 == h15 ? q15 : blk_loc(e.mem, _result_35), _aux_9, _aux_9 == h2 ? q2 : blk_loc(e.mem, _aux_9), _metadata_28, _metadata_28 == h3 ? q3 : blk_loc(e.mem, _metadata_28), _metadata_29, _metadata_29 == h4 ? q4 : blk_loc(e.mem, _metadata_29), _metadata_30, _metadata_30 == h5 ? q5 : blk_loc(e.mem, _metadata_30), _metadata_31, _metadata_31 == h6 ? q6 : blk_loc(e.mem, _metadata_31), _capacity_10, _depth_10, _high_10, _flag_2, _flag_3, _flag_3 == h11 ? q11 : blk_loc(e.mem, _flag_3), _added_5, _changed_5, _insert_0, _result_36, _result_37, _result_37 == h17 ? q17 : blk_loc(e.mem, _result_37)) == 0) {
      return 0;
    }
    _v_1104 = _o_489[0];
    _v_1105 = _o_489[1];
    _v_1106 = _o_489[2];
    _v_1107 = _o_489[3];
    _v_1108 = _o_489[4];
    _v_1109 = _o_489[5];
    _v_1110 = _o_489[6];
    _v_1111 = _o_489[7];
    _v_1112 = _o_489[8];
    _v_1113 = _o_489[9];
    _v_1094 = _v_1104;
    _v_1095 = _v_1105;
    _v_1096 = _v_1106;
    _v_1097 = _v_1107;
    _v_1098 = _v_1108;
    _v_1099 = _v_1109;
    _v_1100 = _v_1110;
    _v_1101 = _v_1111;
    _v_1102 = _v_1112;
    _v_1103 = _v_1113;
  break;
  }
  o[0] = _v_1094;
  o[1] = _v_1095;
  o[2] = _v_1096;
  o[3] = _v_1097;
  o[4] = _v_1098;
  o[5] = _v_1099;
  o[6] = _v_1100;
  o[7] = _v_1101;
  o[8] = _v_1102;
  o[9] = _v_1103;
  return 1;
}

INLINE Term spin_64(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, u32 r14, u32 r15, Term r16, u64 q16) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h12 = r12;
  Term h16 = r16;
  Term _v_1074 = 0;
  Term _v_1075 = 0;
  Term _v_1076 = 0;
  Term _v_1077 = 0;
  Term _v_1078 = 0;
  Term _v_1079 = 0;
  u32 _v_1080 = 0;
  Term _v_1081 = 0;
  u32 _v_1082 = 0;
  u32 _v_1083 = 0;
  u32 _id_11 = r0;
  u32 _tick_8 = r1;
  Term _main_8 = r2;
  Term _aux_8 = r3;
  Term _metadata_24 = r4;
  Term _metadata_25 = r5;
  Term _metadata_26 = r6;
  Term _metadata_27 = r7;
  u32 _capacity_9 = r8;
  Term _depth_9 = r9;
  u32 _high_9 = r10;
  u32 _flag_0 = r11;
  Term _flag_1 = r12;
  u32 _added_4 = r13;
  u32 _changed_4 = r14;
  u32 _replacement_8 = r15;
  Term _replacement_9 = r16;
  WL_SPIN
    if (_replacement_8 == 0) {
      Term _at_112 = _main_8 == h2 ? q2 : blk_loc(e.mem, _main_8);
      Term _at_113 = blk_at(_main_8, _id_11, 1);
      u32 _c_63 = blk_read(e.mem, 1, _at_112, _at_113 + 0);
      Term _c_64 = e.mem[_at_112 + _at_113 + 1];
      blk_write(e.mem, 1, _at_112, _at_113 + 0, 0);
      blk_write(e.mem, 1, _at_112, _at_113 + 1, 0);
      Term _v_1084 = 0;
      Term _v_1085 = 0;
      Term _v_1086 = 0;
      Term _v_1087 = 0;
      Term _v_1088 = 0;
      Term _v_1089 = 0;
      u32 _v_1090 = 0;
      Term _v_1091 = 0;
      u32 _v_1092 = 0;
      u32 _v_1093 = 0;
      Term _o_490[10];
      if (spin_65(e, _o_490, _id_11, _tick_8, _aux_8, _aux_8 == h3 ? q3 : blk_loc(e.mem, _aux_8), _metadata_24, _metadata_24 == h4 ? q4 : blk_loc(e.mem, _metadata_24), _metadata_25, _metadata_25 == h5 ? q5 : blk_loc(e.mem, _metadata_25), _metadata_26, _metadata_26 == h6 ? q6 : blk_loc(e.mem, _metadata_26), _metadata_27, _metadata_27 == h7 ? q7 : blk_loc(e.mem, _metadata_27), _capacity_9, _depth_9, _high_9, _flag_0, _flag_1, _flag_1 == h12 ? q12 : blk_loc(e.mem, _flag_1), _added_4, _changed_4, 0, _main_8, _main_8 == h2 ? q2 : blk_loc(e.mem, _main_8), _c_63, _c_64, _c_64 == h16 ? q16 : _c_64 == h12 ? q12 : _c_64 == h7 ? q7 : _c_64 == h6 ? q6 : _c_64 == h5 ? q5 : _c_64 == h4 ? q4 : _c_64 == h3 ? q3 : _c_64 == h2 ? q2 : blk_loc(e.mem, _c_64)) == 0) {
        return 0;
      }
      _v_1084 = _o_490[0];
      _v_1085 = _o_490[1];
      _v_1086 = _o_490[2];
      _v_1087 = _o_490[3];
      _v_1088 = _o_490[4];
      _v_1089 = _o_490[5];
      _v_1090 = _o_490[6];
      _v_1091 = _o_490[7];
      _v_1092 = _o_490[8];
      _v_1093 = _o_490[9];
      _v_1074 = _v_1084;
      _v_1075 = _v_1085;
      _v_1076 = _v_1086;
      _v_1077 = _v_1087;
      _v_1078 = _v_1088;
      _v_1079 = _v_1089;
      _v_1080 = _v_1090;
      _v_1081 = _v_1091;
      _v_1082 = _v_1092;
      _v_1083 = _v_1093;
    } else {
      Term _at_114 = _main_8 == h2 ? q2 : blk_loc(e.mem, _main_8);
      Term _at_115 = blk_at(_main_8, U32_BIN(_id_11, -, 1ull), 1);
      u32 _c_65 = blk_read(e.mem, 1, _at_114, _at_115 + 0);
      Term _c_66 = e.mem[_at_114 + _at_115 + 1];
      blk_write(e.mem, 1, _at_114, _at_115 + 0, 1);
      blk_write(e.mem, 1, _at_114, _at_115 + 1, _replacement_9);
      Term _v_1148 = 0;
      Term _v_1149 = 0;
      Term _v_1150 = 0;
      Term _v_1151 = 0;
      Term _v_1152 = 0;
      Term _v_1153 = 0;
      u32 _v_1154 = 0;
      Term _v_1155 = 0;
      u32 _v_1156 = 0;
      u32 _v_1157 = 0;
      Term _o_491[10];
      if (spin_65(e, _o_491, _id_11, _tick_8, _aux_8, _aux_8 == h3 ? q3 : blk_loc(e.mem, _aux_8), _metadata_24, _metadata_24 == h4 ? q4 : blk_loc(e.mem, _metadata_24), _metadata_25, _metadata_25 == h5 ? q5 : blk_loc(e.mem, _metadata_25), _metadata_26, _metadata_26 == h6 ? q6 : blk_loc(e.mem, _metadata_26), _metadata_27, _metadata_27 == h7 ? q7 : blk_loc(e.mem, _metadata_27), _capacity_9, _depth_9, _high_9, _flag_0, _flag_1, _flag_1 == h12 ? q12 : blk_loc(e.mem, _flag_1), _added_4, _changed_4, 1, _main_8, _main_8 == h2 ? q2 : blk_loc(e.mem, _main_8), _c_65, _c_66, _c_66 == h16 ? q16 : _c_66 == h12 ? q12 : _c_66 == h7 ? q7 : _c_66 == h6 ? q6 : _c_66 == h5 ? q5 : _c_66 == h4 ? q4 : _c_66 == h3 ? q3 : _c_66 == h2 ? q2 : blk_loc(e.mem, _c_66)) == 0) {
        return 0;
      }
      _v_1148 = _o_491[0];
      _v_1149 = _o_491[1];
      _v_1150 = _o_491[2];
      _v_1151 = _o_491[3];
      _v_1152 = _o_491[4];
      _v_1153 = _o_491[5];
      _v_1154 = _o_491[6];
      _v_1155 = _o_491[7];
      _v_1156 = _o_491[8];
      _v_1157 = _o_491[9];
      _v_1074 = _v_1148;
      _v_1075 = _v_1149;
      _v_1076 = _v_1150;
      _v_1077 = _v_1151;
      _v_1078 = _v_1152;
      _v_1079 = _v_1153;
      _v_1080 = _v_1154;
      _v_1081 = _v_1155;
      _v_1082 = _v_1156;
      _v_1083 = _v_1157;
    }
  break;
  }
  o[0] = _v_1074;
  o[1] = _v_1075;
  o[2] = _v_1076;
  o[3] = _v_1077;
  o[4] = _v_1078;
  o[5] = _v_1079;
  o[6] = _v_1080;
  o[7] = _v_1081;
  o[8] = _v_1082;
  o[9] = _v_1083;
  return 1;
}

INLINE Term spin_63(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h12 = r12;
  Term h15 = r15;
  Term _v_1054 = 0;
  Term _v_1055 = 0;
  Term _v_1056 = 0;
  Term _v_1057 = 0;
  Term _v_1058 = 0;
  Term _v_1059 = 0;
  u32 _v_1060 = 0;
  Term _v_1061 = 0;
  u32 _v_1062 = 0;
  u32 _v_1063 = 0;
  u32 _id_10 = r0;
  u32 _tick_7 = r1;
  Term _main_7 = r2;
  Term _aux_7 = r3;
  Term _metadata_20 = r4;
  Term _metadata_21 = r5;
  Term _metadata_22 = r6;
  Term _metadata_23 = r7;
  u32 _capacity_8 = r8;
  Term _depth_8 = r9;
  u32 _high_8 = r10;
  u32 _replacement_6 = r11;
  Term _replacement_7 = r12;
  u32 _meta_15 = r13;
  u32 _meta_16 = r14;
  Term _meta_17 = r15;
  u32 _meta_18 = r16;
  u32 _meta_19 = r17;
  WL_SPIN
    if (_meta_15 == 0) {
      term_sink(e, _replacement_7);
      term_sink(e, _meta_17);
      _v_1054 = _main_7;
      _v_1055 = _aux_7;
      _v_1056 = _metadata_20;
      _v_1057 = _metadata_21;
      _v_1058 = _metadata_22;
      _v_1059 = _metadata_23;
      _v_1060 = _capacity_8;
      _v_1061 = _depth_8;
      _v_1062 = _high_8;
      _v_1063 = 0;
    } else {
      Term _v_1064 = 0;
      Term _v_1065 = 0;
      Term _v_1066 = 0;
      Term _v_1067 = 0;
      Term _v_1068 = 0;
      Term _v_1069 = 0;
      u32 _v_1070 = 0;
      Term _v_1071 = 0;
      u32 _v_1072 = 0;
      u32 _v_1073 = 0;
      Term _o_492[10];
      if (spin_64(e, _o_492, _id_10, _tick_7, _main_7, _main_7 == h2 ? q2 : blk_loc(e.mem, _main_7), _aux_7, _aux_7 == h3 ? q3 : blk_loc(e.mem, _aux_7), _metadata_20, _metadata_20 == h4 ? q4 : blk_loc(e.mem, _metadata_20), _metadata_21, _metadata_21 == h5 ? q5 : blk_loc(e.mem, _metadata_21), _metadata_22, _metadata_22 == h6 ? q6 : blk_loc(e.mem, _metadata_22), _metadata_23, _metadata_23 == h7 ? q7 : blk_loc(e.mem, _metadata_23), _capacity_8, _depth_8, _high_8, _meta_16, _meta_17, _meta_17 == h15 ? q15 : blk_loc(e.mem, _meta_17), _meta_18, _meta_19, _replacement_6, _replacement_7, _replacement_7 == h12 ? q12 : blk_loc(e.mem, _replacement_7)) == 0) {
        return 0;
      }
      _v_1064 = _o_492[0];
      _v_1065 = _o_492[1];
      _v_1066 = _o_492[2];
      _v_1067 = _o_492[3];
      _v_1068 = _o_492[4];
      _v_1069 = _o_492[5];
      _v_1070 = _o_492[6];
      _v_1071 = _o_492[7];
      _v_1072 = _o_492[8];
      _v_1073 = _o_492[9];
      _v_1054 = _v_1064;
      _v_1055 = _v_1065;
      _v_1056 = _v_1066;
      _v_1057 = _v_1067;
      _v_1058 = _v_1068;
      _v_1059 = _v_1069;
      _v_1060 = _v_1070;
      _v_1061 = _v_1071;
      _v_1062 = _v_1072;
      _v_1063 = _v_1073;
    }
  break;
  }
  o[0] = _v_1054;
  o[1] = _v_1055;
  o[2] = _v_1056;
  o[3] = _v_1057;
  o[4] = _v_1058;
  o[5] = _v_1059;
  o[6] = _v_1060;
  o[7] = _v_1061;
  o[8] = _v_1062;
  o[9] = _v_1063;
  return 1;
}

INLINE Term spin_62(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, Term r5, u32 r6, u32 r7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, u32 r13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h15 = r15;
  Term _v_1034 = 0;
  Term _v_1035 = 0;
  Term _v_1036 = 0;
  Term _v_1037 = 0;
  Term _v_1038 = 0;
  Term _v_1039 = 0;
  u32 _v_1040 = 0;
  Term _v_1041 = 0;
  u32 _v_1042 = 0;
  u32 _v_1043 = 0;
  u32 _id_9 = r0;
  u32 _tick_6 = r1;
  Term _main_6 = r2;
  Term _aux_6 = r3;
  u32 _capacity_7 = r4;
  Term _depth_7 = r5;
  u32 _high_7 = r6;
  u32 _replacement_4 = r7;
  Term _replacement_5 = r8;
  Term _result_26 = r9;
  Term _result_27 = r10;
  Term _result_28 = r11;
  Term _result_29 = r12;
  u32 _result_30 = r13;
  u32 _result_31 = r14;
  Term _result_32 = r15;
  u32 _result_33 = r16;
  u32 _result_34 = r17;
  WL_SPIN
    Term _v_1044 = 0;
    Term _v_1045 = 0;
    Term _v_1046 = 0;
    Term _v_1047 = 0;
    Term _v_1048 = 0;
    Term _v_1049 = 0;
    u32 _v_1050 = 0;
    Term _v_1051 = 0;
    u32 _v_1052 = 0;
    u32 _v_1053 = 0;
    Term _o_493[10];
    if (spin_63(e, _o_493, _id_9, _tick_6, _main_6, _main_6 == h2 ? q2 : blk_loc(e.mem, _main_6), _aux_6, _aux_6 == h3 ? q3 : blk_loc(e.mem, _aux_6), _result_26, _result_26 == h9 ? q9 : blk_loc(e.mem, _result_26), _result_27, _result_27 == h10 ? q10 : blk_loc(e.mem, _result_27), _result_28, _result_28 == h11 ? q11 : blk_loc(e.mem, _result_28), _result_29, _result_29 == h12 ? q12 : blk_loc(e.mem, _result_29), _capacity_7, _depth_7, _high_7, _replacement_4, _replacement_5, _replacement_5 == h8 ? q8 : blk_loc(e.mem, _replacement_5), _result_30, _result_31, _result_32, _result_32 == h15 ? q15 : blk_loc(e.mem, _result_32), _result_33, _result_34) == 0) {
      return 0;
    }
    _v_1044 = _o_493[0];
    _v_1045 = _o_493[1];
    _v_1046 = _o_493[2];
    _v_1047 = _o_493[3];
    _v_1048 = _o_493[4];
    _v_1049 = _o_493[5];
    _v_1050 = _o_493[6];
    _v_1051 = _o_493[7];
    _v_1052 = _o_493[8];
    _v_1053 = _o_493[9];
    _v_1034 = _v_1044;
    _v_1035 = _v_1045;
    _v_1036 = _v_1046;
    _v_1037 = _v_1047;
    _v_1038 = _v_1048;
    _v_1039 = _v_1049;
    _v_1040 = _v_1050;
    _v_1041 = _v_1051;
    _v_1042 = _v_1052;
    _v_1043 = _v_1053;
  break;
  }
  o[0] = _v_1034;
  o[1] = _v_1035;
  o[2] = _v_1036;
  o[3] = _v_1037;
  o[4] = _v_1038;
  o[5] = _v_1039;
  o[6] = _v_1040;
  o[7] = _v_1041;
  o[8] = _v_1042;
  o[9] = _v_1043;
  return 1;
}

INLINE Term spin_61(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, Term r10, u32 r11, u32 r12, Term r13, u64 q13) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h13 = r13;
  Term _v_996 = 0;
  Term _v_997 = 0;
  Term _v_998 = 0;
  Term _v_999 = 0;
  Term _v_1000 = 0;
  Term _v_1001 = 0;
  u32 _v_1002 = 0;
  Term _v_1003 = 0;
  u32 _v_1004 = 0;
  u32 _v_1005 = 0;
  u32 _valid_2 = r0;
  u32 _id_8 = r1;
  u32 _tick_5 = r2;
  Term _rows_36 = r3;
  Term _rows_37 = r4;
  Term _rows_38 = r5;
  Term _rows_39 = r6;
  Term _rows_40 = r7;
  Term _rows_41 = r8;
  u32 _rows_42 = r9;
  Term _rows_43 = r10;
  u32 _rows_44 = r11;
  u32 _replacement_2 = r12;
  Term _replacement_3 = r13;
  WL_SPIN
    if (_valid_2 == 0) {
      term_sink(e, _replacement_3);
      _v_996 = _rows_36;
      _v_997 = _rows_37;
      _v_998 = _rows_38;
      _v_999 = _rows_39;
      _v_1000 = _rows_40;
      _v_1001 = _rows_41;
      _v_1002 = _rows_42;
      _v_1003 = _rows_43;
      _v_1004 = _rows_44;
      _v_1005 = 0;
    } else {
      Term _v_1006 = 0;
      Term _v_1007 = 0;
      Term _v_1008 = 0;
      Term _v_1009 = 0;
      u32 _v_1010 = 0;
      u32 _v_1011 = 0;
      Term _v_1012 = 0;
      u32 _v_1013 = 0;
      u32 _v_1014 = 0;
      Term _v_1015 = 0;
      Term _v_1016 = 0;
      Term _v_1017 = 0;
      Term _v_1018 = 0;
      u32 _v_1019 = 0;
      u32 _v_1020 = 0;
      Term _v_1021 = 0;
      u32 _v_1022 = 0;
      u32 _v_1023 = 0;
      Term _o_485[9];
      if (spin_46(e, _o_485, _rows_38, _rows_38 == h5 ? q5 : blk_loc(e.mem, _rows_38), _rows_39, _rows_39 == h6 ? q6 : blk_loc(e.mem, _rows_39), _rows_40, _rows_40 == h7 ? q7 : blk_loc(e.mem, _rows_40), _rows_41, _rows_41 == h8 ? q8 : blk_loc(e.mem, _rows_41), U32_BIN(_id_8, -, 1ull)) == 0) {
        return 0;
      }
      _v_1015 = _o_485[0];
      _v_1016 = _o_485[1];
      _v_1017 = _o_485[2];
      _v_1018 = _o_485[3];
      _v_1019 = _o_485[4];
      _v_1020 = _o_485[5];
      _v_1021 = _o_485[6];
      _v_1022 = _o_485[7];
      _v_1023 = _o_485[8];
      _v_1006 = _v_1015;
      _v_1007 = _v_1016;
      _v_1008 = _v_1017;
      _v_1009 = _v_1018;
      _v_1010 = _v_1019;
      _v_1011 = _v_1020;
      _v_1012 = _v_1021;
      _v_1013 = _v_1022;
      _v_1014 = _v_1023;
      Term _v_1024 = 0;
      Term _v_1025 = 0;
      Term _v_1026 = 0;
      Term _v_1027 = 0;
      Term _v_1028 = 0;
      Term _v_1029 = 0;
      u32 _v_1030 = 0;
      Term _v_1031 = 0;
      u32 _v_1032 = 0;
      u32 _v_1033 = 0;
      Term _o_494[10];
      if (spin_62(e, _o_494, _id_8, _tick_5, _rows_36, _rows_36 == h3 ? q3 : blk_loc(e.mem, _rows_36), _rows_37, _rows_37 == h4 ? q4 : blk_loc(e.mem, _rows_37), _rows_42, _rows_43, _rows_44, _replacement_2, _replacement_3, _replacement_3 == h13 ? q13 : blk_loc(e.mem, _replacement_3), _v_1006, _v_1006 == h13 ? q13 : _v_1006 == h8 ? q8 : _v_1006 == h7 ? q7 : _v_1006 == h6 ? q6 : _v_1006 == h5 ? q5 : _v_1006 == h4 ? q4 : _v_1006 == h3 ? q3 : blk_loc(e.mem, _v_1006), _v_1007, _v_1007 == h13 ? q13 : _v_1007 == h8 ? q8 : _v_1007 == h7 ? q7 : _v_1007 == h6 ? q6 : _v_1007 == h5 ? q5 : _v_1007 == h4 ? q4 : _v_1007 == h3 ? q3 : blk_loc(e.mem, _v_1007), _v_1008, _v_1008 == h13 ? q13 : _v_1008 == h8 ? q8 : _v_1008 == h7 ? q7 : _v_1008 == h6 ? q6 : _v_1008 == h5 ? q5 : _v_1008 == h4 ? q4 : _v_1008 == h3 ? q3 : blk_loc(e.mem, _v_1008), _v_1009, _v_1009 == h13 ? q13 : _v_1009 == h8 ? q8 : _v_1009 == h7 ? q7 : _v_1009 == h6 ? q6 : _v_1009 == h5 ? q5 : _v_1009 == h4 ? q4 : _v_1009 == h3 ? q3 : blk_loc(e.mem, _v_1009), _v_1010, _v_1011, _v_1012, _v_1012 == h13 ? q13 : _v_1012 == h8 ? q8 : _v_1012 == h7 ? q7 : _v_1012 == h6 ? q6 : _v_1012 == h5 ? q5 : _v_1012 == h4 ? q4 : _v_1012 == h3 ? q3 : blk_loc(e.mem, _v_1012), _v_1013, _v_1014) == 0) {
        return 0;
      }
      _v_1024 = _o_494[0];
      _v_1025 = _o_494[1];
      _v_1026 = _o_494[2];
      _v_1027 = _o_494[3];
      _v_1028 = _o_494[4];
      _v_1029 = _o_494[5];
      _v_1030 = _o_494[6];
      _v_1031 = _o_494[7];
      _v_1032 = _o_494[8];
      _v_1033 = _o_494[9];
      _v_996 = _v_1024;
      _v_997 = _v_1025;
      _v_998 = _v_1026;
      _v_999 = _v_1027;
      _v_1000 = _v_1028;
      _v_1001 = _v_1029;
      _v_1002 = _v_1030;
      _v_1003 = _v_1031;
      _v_1004 = _v_1032;
      _v_1005 = _v_1033;
    }
  break;
  }
  o[0] = _v_996;
  o[1] = _v_997;
  o[2] = _v_998;
  o[3] = _v_999;
  o[4] = _v_1000;
  o[5] = _v_1001;
  o[6] = _v_1002;
  o[7] = _v_1003;
  o[8] = _v_1004;
  o[9] = _v_1005;
  return 1;
}

INLINE Term spin_60(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9, u32 r10, Term r11, u64 q11, u32 r12) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h11 = r11;
  Term _v_972 = 0;
  Term _v_973 = 0;
  Term _v_974 = 0;
  Term _v_975 = 0;
  Term _v_976 = 0;
  Term _v_977 = 0;
  u32 _v_978 = 0;
  Term _v_979 = 0;
  u32 _v_980 = 0;
  u32 _v_981 = 0;
  Term _rows_27 = r0;
  Term _rows_28 = r1;
  Term _rows_29 = r2;
  Term _rows_30 = r3;
  Term _rows_31 = r4;
  Term _rows_32 = r5;
  u32 _rows_33 = r6;
  Term _rows_34 = r7;
  u32 _rows_35 = r8;
  u32 _id_7 = r9;
  u32 _replacement_0 = r10;
  Term _replacement_1 = r11;
  u32 _tick_4 = r12;
  WL_SPIN
    u32 _v_982 = 0;
    u32 _v_983 = 0;
    u32 _v_984 = 0;
    Term _o_483[1];
    if (spin_23(e, _o_483, U32_BIN(_id_7, <=, _rows_33), U32_BIN(_id_7, <=, _rows_35)) == 0) {
      return 0;
    }
    _v_984 = _o_483[0];
    _v_983 = _v_984;
    u32 _v_985 = 0;
    Term _o_484[1];
    if (spin_23(e, _o_484, U32_BIN(0ull, <, _id_7), _v_983) == 0) {
      return 0;
    }
    _v_985 = _o_484[0];
    _v_982 = _v_985;
    Term _v_986 = 0;
    Term _v_987 = 0;
    Term _v_988 = 0;
    Term _v_989 = 0;
    Term _v_990 = 0;
    Term _v_991 = 0;
    u32 _v_992 = 0;
    Term _v_993 = 0;
    u32 _v_994 = 0;
    u32 _v_995 = 0;
    Term _o_495[10];
    if (spin_61(e, _o_495, _v_982, _id_7, _tick_4, _rows_27, _rows_27 == h0 ? q0 : blk_loc(e.mem, _rows_27), _rows_28, _rows_28 == h1 ? q1 : blk_loc(e.mem, _rows_28), _rows_29, _rows_29 == h2 ? q2 : blk_loc(e.mem, _rows_29), _rows_30, _rows_30 == h3 ? q3 : blk_loc(e.mem, _rows_30), _rows_31, _rows_31 == h4 ? q4 : blk_loc(e.mem, _rows_31), _rows_32, _rows_32 == h5 ? q5 : blk_loc(e.mem, _rows_32), _rows_33, _rows_34, _rows_35, _replacement_0, _replacement_1, _replacement_1 == h11 ? q11 : blk_loc(e.mem, _replacement_1)) == 0) {
      return 0;
    }
    _v_986 = _o_495[0];
    _v_987 = _o_495[1];
    _v_988 = _o_495[2];
    _v_989 = _o_495[3];
    _v_990 = _o_495[4];
    _v_991 = _o_495[5];
    _v_992 = _o_495[6];
    _v_993 = _o_495[7];
    _v_994 = _o_495[8];
    _v_995 = _o_495[9];
    _v_972 = _v_986;
    _v_973 = _v_987;
    _v_974 = _v_988;
    _v_975 = _v_989;
    _v_976 = _v_990;
    _v_977 = _v_991;
    _v_978 = _v_992;
    _v_979 = _v_993;
    _v_980 = _v_994;
    _v_981 = _v_995;
  break;
  }
  o[0] = _v_972;
  o[1] = _v_973;
  o[2] = _v_974;
  o[3] = _v_975;
  o[4] = _v_976;
  o[5] = _v_977;
  o[6] = _v_978;
  o[7] = _v_979;
  o[8] = _v_980;
  o[9] = _v_981;
  return 1;
}

INLINE Term spin_68(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u32 r9, u32 r10, u32 r11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, Term r17, u64 q17, u32 r18, u32 r19) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h13 = r13;
  Term h15 = r15;
  Term h17 = r17;
  Term _v_1504 = 0;
  Term _v_1505 = 0;
  Term _v_1506 = 0;
  Term _v_1507 = 0;
  Term _v_1508 = 0;
  Term _v_1509 = 0;
  u32 _v_1510 = 0;
  Term _v_1511 = 0;
  u32 _v_1512 = 0;
  u32 _v_1513 = 0;
  u32 _v_1514 = 0;
  u32 _v_1515 = 0;
  Term _v_1516 = 0;
  u32 _v_1517 = 0;
  Term _v_1518 = 0;
  u32 _v_1519 = 0;
  Term _v_1520 = 0;
  u32 _v_1521 = 0;
  u32 _v_1522 = 0;
  u32 _id_15 = r0;
  Term _result_38 = r1;
  Term _result_39 = r2;
  Term _result_40 = r3;
  Term _result_41 = r4;
  Term _result_42 = r5;
  Term _result_43 = r6;
  u32 _result_44 = r7;
  Term _result_45 = r8;
  u32 _result_46 = r9;
  u32 _result_47 = r10;
  u32 _result_48 = r11;
  u32 _result_49 = r12;
  Term _result_50 = r13;
  u32 _result_51 = r14;
  Term _result_52 = r15;
  u32 _result_53 = r16;
  Term _result_54 = r17;
  u32 _result_55 = r18;
  u32 _result_56 = r19;
  WL_SPIN
    if (_result_47 == 0) {
      _v_1504 = _result_38;
      _v_1505 = _result_39;
      _v_1506 = _result_40;
      _v_1507 = _result_41;
      _v_1508 = _result_42;
      _v_1509 = _result_43;
      _v_1510 = _result_44;
      _v_1511 = _result_45;
      _v_1512 = _result_46;
      _v_1513 = 0;
      _v_1514 = 0;
      _v_1515 = 0;
      _v_1516 = 0;
      _v_1517 = 0;
      _v_1518 = 0;
      _v_1519 = 0;
      _v_1520 = 0;
      _v_1521 = 0;
      _v_1522 = 0;
    } else {
      Term _v_1523 = 0;
      Term _v_1524 = 0;
      Term _v_1525 = 0;
      Term _v_1526 = 0;
      Term _v_1527 = 0;
      Term _v_1528 = 0;
      Term _v_1529 = 0;
      Term _v_1530 = 0;
      Term _o_578[4];
      Term _a_26 = 0;
      if (spin_33(e, _o_578, _result_40, _result_40 == h3 ? q3 : blk_loc(e.mem, _result_40), _result_41, _result_41 == h4 ? q4 : blk_loc(e.mem, _result_41), _result_42, _result_42 == h5 ? q5 : blk_loc(e.mem, _result_42), _result_43, _result_43 == h6 ? q6 : blk_loc(e.mem, _result_43), U32_BIN(_id_15, -, 1ull), 0, 0, _a_26, _a_26 == h17 ? q17 : _a_26 == h15 ? q15 : _a_26 == h13 ? q13 : _a_26 == h6 ? q6 : _a_26 == h5 ? q5 : _a_26 == h4 ? q4 : _a_26 == h3 ? q3 : _a_26 == h2 ? q2 : _a_26 == h1 ? q1 : blk_loc(e.mem, _a_26), 0ull, 0ull) == 0) {
        return 0;
      }
      _v_1527 = _o_578[0];
      _v_1528 = _o_578[1];
      _v_1529 = _o_578[2];
      _v_1530 = _o_578[3];
      _v_1523 = _v_1527;
      _v_1524 = _v_1528;
      _v_1525 = _v_1529;
      _v_1526 = _v_1530;
      _v_1504 = _result_38;
      _v_1505 = _result_39;
      _v_1506 = _v_1523;
      _v_1507 = _v_1524;
      _v_1508 = _v_1525;
      _v_1509 = _v_1526;
      _v_1510 = _result_44;
      _v_1511 = _result_45;
      _v_1512 = _result_46;
      _v_1513 = 1;
      _v_1514 = _result_48;
      _v_1515 = _result_49;
      _v_1516 = _result_50;
      _v_1517 = _result_51;
      _v_1518 = _result_52;
      _v_1519 = _result_53;
      _v_1520 = _result_54;
      _v_1521 = _result_55;
      _v_1522 = _result_56;
    }
  break;
  }
  o[0] = _v_1504;
  o[1] = _v_1505;
  o[2] = _v_1506;
  o[3] = _v_1507;
  o[4] = _v_1508;
  o[5] = _v_1509;
  o[6] = _v_1510;
  o[7] = _v_1511;
  o[8] = _v_1512;
  o[9] = _v_1513;
  o[10] = _v_1514;
  o[11] = _v_1515;
  o[12] = _v_1516;
  o[13] = _v_1517;
  o[14] = _v_1518;
  o[15] = _v_1519;
  o[16] = _v_1520;
  o[17] = _v_1521;
  o[18] = _v_1522;
  return 1;
}

INLINE Term spin_67(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term _v_1428 = 0;
  Term _v_1429 = 0;
  Term _v_1430 = 0;
  Term _v_1431 = 0;
  Term _v_1432 = 0;
  Term _v_1433 = 0;
  u32 _v_1434 = 0;
  Term _v_1435 = 0;
  u32 _v_1436 = 0;
  u32 _v_1437 = 0;
  u32 _v_1438 = 0;
  u32 _v_1439 = 0;
  Term _v_1440 = 0;
  u32 _v_1441 = 0;
  Term _v_1442 = 0;
  u32 _v_1443 = 0;
  Term _v_1444 = 0;
  u32 _v_1445 = 0;
  u32 _v_1446 = 0;
  Term _rows_45 = r0;
  Term _rows_46 = r1;
  Term _rows_47 = r2;
  Term _rows_48 = r3;
  Term _rows_49 = r4;
  Term _rows_50 = r5;
  u32 _rows_51 = r6;
  Term _rows_52 = r7;
  u32 _rows_53 = r8;
  u32 _id_14 = r9;
  WL_SPIN
    Term _v_1447 = 0;
    Term _v_1448 = 0;
    Term _v_1449 = 0;
    Term _v_1450 = 0;
    Term _v_1451 = 0;
    Term _v_1452 = 0;
    u32 _v_1453 = 0;
    Term _v_1454 = 0;
    u32 _v_1455 = 0;
    u32 _v_1456 = 0;
    u32 _v_1457 = 0;
    u32 _v_1458 = 0;
    Term _v_1459 = 0;
    u32 _v_1460 = 0;
    Term _v_1461 = 0;
    u32 _v_1462 = 0;
    Term _v_1463 = 0;
    u32 _v_1464 = 0;
    u32 _v_1465 = 0;
    Term _v_1466 = 0;
    Term _v_1467 = 0;
    Term _v_1468 = 0;
    Term _v_1469 = 0;
    Term _v_1470 = 0;
    Term _v_1471 = 0;
    u32 _v_1472 = 0;
    Term _v_1473 = 0;
    u32 _v_1474 = 0;
    u32 _v_1475 = 0;
    u32 _v_1476 = 0;
    u32 _v_1477 = 0;
    Term _v_1478 = 0;
    u32 _v_1479 = 0;
    Term _v_1480 = 0;
    u32 _v_1481 = 0;
    Term _v_1482 = 0;
    u32 _v_1483 = 0;
    u32 _v_1484 = 0;
    Term _o_577[19];
    if (spin_44(e, _o_577, _rows_45, _rows_45 == h0 ? q0 : blk_loc(e.mem, _rows_45), _rows_46, _rows_46 == h1 ? q1 : blk_loc(e.mem, _rows_46), _rows_47, _rows_47 == h2 ? q2 : blk_loc(e.mem, _rows_47), _rows_48, _rows_48 == h3 ? q3 : blk_loc(e.mem, _rows_48), _rows_49, _rows_49 == h4 ? q4 : blk_loc(e.mem, _rows_49), _rows_50, _rows_50 == h5 ? q5 : blk_loc(e.mem, _rows_50), _rows_51, _rows_52, _rows_53, _id_14) == 0) {
      return 0;
    }
    _v_1466 = _o_577[0];
    _v_1467 = _o_577[1];
    _v_1468 = _o_577[2];
    _v_1469 = _o_577[3];
    _v_1470 = _o_577[4];
    _v_1471 = _o_577[5];
    _v_1472 = _o_577[6];
    _v_1473 = _o_577[7];
    _v_1474 = _o_577[8];
    _v_1475 = _o_577[9];
    _v_1476 = _o_577[10];
    _v_1477 = _o_577[11];
    _v_1478 = _o_577[12];
    _v_1479 = _o_577[13];
    _v_1480 = _o_577[14];
    _v_1481 = _o_577[15];
    _v_1482 = _o_577[16];
    _v_1483 = _o_577[17];
    _v_1484 = _o_577[18];
    _v_1447 = _v_1466;
    _v_1448 = _v_1467;
    _v_1449 = _v_1468;
    _v_1450 = _v_1469;
    _v_1451 = _v_1470;
    _v_1452 = _v_1471;
    _v_1453 = _v_1472;
    _v_1454 = _v_1473;
    _v_1455 = _v_1474;
    _v_1456 = _v_1475;
    _v_1457 = _v_1476;
    _v_1458 = _v_1477;
    _v_1459 = _v_1478;
    _v_1460 = _v_1479;
    _v_1461 = _v_1480;
    _v_1462 = _v_1481;
    _v_1463 = _v_1482;
    _v_1464 = _v_1483;
    _v_1465 = _v_1484;
    Term _v_1485 = 0;
    Term _v_1486 = 0;
    Term _v_1487 = 0;
    Term _v_1488 = 0;
    Term _v_1489 = 0;
    Term _v_1490 = 0;
    u32 _v_1491 = 0;
    Term _v_1492 = 0;
    u32 _v_1493 = 0;
    u32 _v_1494 = 0;
    u32 _v_1495 = 0;
    u32 _v_1496 = 0;
    Term _v_1497 = 0;
    u32 _v_1498 = 0;
    Term _v_1499 = 0;
    u32 _v_1500 = 0;
    Term _v_1501 = 0;
    u32 _v_1502 = 0;
    u32 _v_1503 = 0;
    Term _o_579[19];
    if (spin_68(e, _o_579, _id_14, _v_1447, _v_1447 == h5 ? q5 : _v_1447 == h4 ? q4 : _v_1447 == h3 ? q3 : _v_1447 == h2 ? q2 : _v_1447 == h1 ? q1 : _v_1447 == h0 ? q0 : blk_loc(e.mem, _v_1447), _v_1448, _v_1448 == h5 ? q5 : _v_1448 == h4 ? q4 : _v_1448 == h3 ? q3 : _v_1448 == h2 ? q2 : _v_1448 == h1 ? q1 : _v_1448 == h0 ? q0 : blk_loc(e.mem, _v_1448), _v_1449, _v_1449 == h5 ? q5 : _v_1449 == h4 ? q4 : _v_1449 == h3 ? q3 : _v_1449 == h2 ? q2 : _v_1449 == h1 ? q1 : _v_1449 == h0 ? q0 : blk_loc(e.mem, _v_1449), _v_1450, _v_1450 == h5 ? q5 : _v_1450 == h4 ? q4 : _v_1450 == h3 ? q3 : _v_1450 == h2 ? q2 : _v_1450 == h1 ? q1 : _v_1450 == h0 ? q0 : blk_loc(e.mem, _v_1450), _v_1451, _v_1451 == h5 ? q5 : _v_1451 == h4 ? q4 : _v_1451 == h3 ? q3 : _v_1451 == h2 ? q2 : _v_1451 == h1 ? q1 : _v_1451 == h0 ? q0 : blk_loc(e.mem, _v_1451), _v_1452, _v_1452 == h5 ? q5 : _v_1452 == h4 ? q4 : _v_1452 == h3 ? q3 : _v_1452 == h2 ? q2 : _v_1452 == h1 ? q1 : _v_1452 == h0 ? q0 : blk_loc(e.mem, _v_1452), _v_1453, _v_1454, _v_1455, _v_1456, _v_1457, _v_1458, _v_1459, _v_1459 == h5 ? q5 : _v_1459 == h4 ? q4 : _v_1459 == h3 ? q3 : _v_1459 == h2 ? q2 : _v_1459 == h1 ? q1 : _v_1459 == h0 ? q0 : blk_loc(e.mem, _v_1459), _v_1460, _v_1461, _v_1461 == h5 ? q5 : _v_1461 == h4 ? q4 : _v_1461 == h3 ? q3 : _v_1461 == h2 ? q2 : _v_1461 == h1 ? q1 : _v_1461 == h0 ? q0 : blk_loc(e.mem, _v_1461), _v_1462, _v_1463, _v_1463 == h5 ? q5 : _v_1463 == h4 ? q4 : _v_1463 == h3 ? q3 : _v_1463 == h2 ? q2 : _v_1463 == h1 ? q1 : _v_1463 == h0 ? q0 : blk_loc(e.mem, _v_1463), _v_1464, _v_1465) == 0) {
      return 0;
    }
    _v_1485 = _o_579[0];
    _v_1486 = _o_579[1];
    _v_1487 = _o_579[2];
    _v_1488 = _o_579[3];
    _v_1489 = _o_579[4];
    _v_1490 = _o_579[5];
    _v_1491 = _o_579[6];
    _v_1492 = _o_579[7];
    _v_1493 = _o_579[8];
    _v_1494 = _o_579[9];
    _v_1495 = _o_579[10];
    _v_1496 = _o_579[11];
    _v_1497 = _o_579[12];
    _v_1498 = _o_579[13];
    _v_1499 = _o_579[14];
    _v_1500 = _o_579[15];
    _v_1501 = _o_579[16];
    _v_1502 = _o_579[17];
    _v_1503 = _o_579[18];
    _v_1428 = _v_1485;
    _v_1429 = _v_1486;
    _v_1430 = _v_1487;
    _v_1431 = _v_1488;
    _v_1432 = _v_1489;
    _v_1433 = _v_1490;
    _v_1434 = _v_1491;
    _v_1435 = _v_1492;
    _v_1436 = _v_1493;
    _v_1437 = _v_1494;
    _v_1438 = _v_1495;
    _v_1439 = _v_1496;
    _v_1440 = _v_1497;
    _v_1441 = _v_1498;
    _v_1442 = _v_1499;
    _v_1443 = _v_1500;
    _v_1444 = _v_1501;
    _v_1445 = _v_1502;
    _v_1446 = _v_1503;
  break;
  }
  o[0] = _v_1428;
  o[1] = _v_1429;
  o[2] = _v_1430;
  o[3] = _v_1431;
  o[4] = _v_1432;
  o[5] = _v_1433;
  o[6] = _v_1434;
  o[7] = _v_1435;
  o[8] = _v_1436;
  o[9] = _v_1437;
  o[10] = _v_1438;
  o[11] = _v_1439;
  o[12] = _v_1440;
  o[13] = _v_1441;
  o[14] = _v_1442;
  o[15] = _v_1443;
  o[16] = _v_1444;
  o[17] = _v_1445;
  o[18] = _v_1446;
  return 1;
}

// Work
// ====

// A host self-jump is a tail call: as a loop, clang hoisted constants into
// symreg's entry (3.05 s against 2.51 s).
#if !DEVICE
#undef  WL_SPIN
#undef  WL_SPUN
#undef  WL_AGAIN
#define WL_SPIN
#define WL_SPUN
#define WL_AGAIN(F) __attribute__((musttail)) return WL_##F(WL_ALL)

typedef Term (PRESERVE(preserve_none) *WlFn)(WL_SIG);
#define WL_X(F) WL_FN WL_##F(WL_SIG);
WL_TABLE WL_X(FID_ENTER)
#undef WL_X
#define WL_X(F) WL_##F,
static const WlFn wl_tab[] = { WL_TABLE };
#undef WL_X
#endif

static Term work_loop(Env e, DEV Term* sp, Term t, u32 seq) {
  WL_BANK
  u32 rn = 0;
  r0 = t;
#if DEVICE
  u32 fid   = FID_ENTER;
  u32 wpoll = 0;
  for (;;) {
  if (err_spun(e.mem, &wpoll)) {
    return 0;
  }
  switch (fid) {
#else
  return WL_FID_ENTER(WL_ALL);
}
#endif

// Segments
// ========

// A task enters through its words: a continuation's results ride r0..
// and its parameters the stack; any other segment's parameters ride r0..

#if !DEVICE
  WL_CASE(FID_STORAGE_SLOTS_EMPTY)
  {
    Term _depth_0 = r0;
    WL_OPEN
    WL_SPIN
    if (_depth_0 == 0) {
      Term _fv_0[2];
      _fv_0[0] = 0;
      _fv_0[1] = 0;
      r0 = blk_new(e, 1, 0, 1, 2, _fv_0);
      WL_RETN(1);
    } else {
      Term _d_0 = (_depth_0 - 1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _d_0;
        STK(1) = FID_STORAGE_SLOTS_EMPTY_K44;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_STORAGE_SLOTS_EMPTY_K44, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _d_0;
        WL_CONT = term_tsk(FID_STORAGE_SLOTS_EMPTY_K44, _t_0);
        WL_IDX = 1;
      }
      r0 = _d_0;
      _depth_0 = r0;
      WL_AGAIN(FID_STORAGE_SLOTS_EMPTY);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_SLOTS_EMPTY_K44)
  {
    WL_POPN(1);
    Term _d_1 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_STORAGE_SLOTS_EMPTY_K45;
      WL_PUSHN(2);
    } else {
      u64 _t_1 = task_node(e, FID_STORAGE_SLOTS_EMPTY_K45, WL_CONT, WL_IDX, 1);
      e.mem[_t_1 + 0] = _h_0;
      WL_CONT = term_tsk(FID_STORAGE_SLOTS_EMPTY_K45, _t_1);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_SLOTS_EMPTY)) {
      u64 _t_2 = task_node(e, FID_STORAGE_SLOTS_EMPTY, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _d_1;
      return term_tsk(FID_STORAGE_SLOTS_EMPTY, _t_2);
    }
    r0 = _d_1;
    WL_JMP(FID_STORAGE_SLOTS_EMPTY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_SLOTS_EMPTY_K45)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    r0 = blk_node(e, _h_2, _h_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW_GO)
  {
    Term _f_0 = r0;
    u32 _n_0 = r1;
    Term _acc_0 = r2;
    WL_OPEN
    WL_SPIN
    if (_f_0 == 0) {
      r0 = _acc_0;
      WL_RETN(1);
    } else {
      Term _g_0 = (_f_0 - 1);
      u32 _s_0 = U32_BIN(_n_0, ==, 0);
      if (_s_0 == 1) {
        r0 = _acc_0;
        WL_RETN(1);
      } else {
        Term _a_0 = 10ull;
        Term _a_1 = 10ull;
        u64 _nd_0 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, U32_BIN(48ull, +, ((u32)(_a_1) == 0 ? _n_0 : U32_BIN(_n_0, -, U32_QUO((u32)(_n_0), (u32)(_a_1)) * _a_1))));
        e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
        r0 = _g_0;
        r1 = ((u32)(_a_0) == 0 ? 0 : (u64)U32_QUO((u32)(_n_0), (u32)(_a_0)));
        r2 = term_ctr(CID_SCON, _nd_0);
        _f_0 = r0;
        _n_0 = r1;
        _acc_0 = r2;
        WL_AGAIN(FID_U32_SHOW_GO);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE)
  {
    Term _m_0 = r0;
    u32 _m_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_0;
      STK(1) = _m_1;
      STK(2) = FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K80;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K80, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _m_0;
      e.mem[_t_0 + 1] = _m_1;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K80, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _m_1;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _m_1;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K80)
  {
    WL_POPN(2);
    Term _m_2 = STK(0);
    u32 _m_3 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_2;
      STK(1) = _m_3;
      STK(2) = FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K81;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K81, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _m_2;
      e.mem[_t_2 + 1] = _m_3;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K81, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = term_ctr(CID_SCON, STAT_OFF + 2);
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _h_0;
    r1 = term_ctr(CID_SCON, STAT_OFF + 2);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K81)
  {
    WL_POPN(2);
    Term _m_4 = STK(0);
    u32 _m_5 = STK(1);
    Term _h_1 = r0;
    WL_OPEN
    Term _at_0 = blk_loc(e.mem, _m_4);
    Term _at_1 = blk_at(_m_4, 0ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_5;
      STK(1) = _h_1;
      STK(2) = _m_4;
      STK(3) = FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K82;
      WL_PUSHN(4);
    } else {
      u64 _t_4 = task_node(e, FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K82, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _m_5;
      e.mem[_t_4 + 1] = _h_1;
      e.mem[_t_4 + 2] = _m_4;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K82, _t_4);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_5 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _c_0;
      return term_tsk(FID_U32_SHOW, _t_5);
    }
    r0 = _c_0;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K82)
  {
    WL_POPN(3);
    u32 _m_6 = STK(0);
    Term _h_3 = STK(1);
    Term _m_7 = STK(2);
    Term _h_2 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_6;
      STK(1) = _h_3;
      STK(2) = _m_7;
      STK(3) = FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K83;
      WL_PUSHN(4);
    } else {
      u64 _t_6 = task_node(e, FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K83, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _m_6;
      e.mem[_t_6 + 1] = _h_3;
      e.mem[_t_6 + 2] = _m_7;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K83, _t_6);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_2;
      e.mem[_t_7 + 1] = term_ctr(CID_SCON, STAT_OFF + 0);
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_2;
    r1 = term_ctr(CID_SCON, STAT_OFF + 0);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K83)
  {
    WL_POPN(3);
    u32 _m_8 = STK(0);
    Term _h_5 = STK(1);
    Term _m_9 = STK(2);
    Term _h_4 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_8;
      STK(1) = _m_9;
      STK(2) = FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K84;
      WL_PUSHN(3);
    } else {
      u64 _t_8 = task_node(e, FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K84, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _m_8;
      e.mem[_t_8 + 1] = _m_9;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K84, _t_8);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_5;
      e.mem[_t_9 + 1] = _h_4;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _h_5;
    r1 = _h_4;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K84)
  {
    WL_POPN(2);
    u32 _m_10 = STK(0);
    Term _m_11 = STK(1);
    Term _h_6 = r0;
    WL_OPEN
    Term _at_2 = blk_loc(e.mem, _m_11);
    Term _at_3 = blk_at(_m_11, 1ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_10;
      STK(1) = _h_6;
      STK(2) = _m_11;
      STK(3) = FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K85;
      WL_PUSHN(4);
    } else {
      u64 _t_10 = task_node(e, FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K85, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _m_10;
      e.mem[_t_10 + 1] = _h_6;
      e.mem[_t_10 + 2] = _m_11;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K85, _t_10);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_11 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _c_1;
      return term_tsk(FID_U32_SHOW, _t_11);
    }
    r0 = _c_1;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K85)
  {
    WL_POPN(3);
    u32 _m_12 = STK(0);
    Term _h_8 = STK(1);
    Term _m_13 = STK(2);
    Term _h_7 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_12;
      STK(1) = _h_8;
      STK(2) = _m_13;
      STK(3) = FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K86;
      WL_PUSHN(4);
    } else {
      u64 _t_12 = task_node(e, FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K86, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _m_12;
      e.mem[_t_12 + 1] = _h_8;
      e.mem[_t_12 + 2] = _m_13;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K86, _t_12);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _h_7;
      e.mem[_t_13 + 1] = term_ctr(CID_SCON, STAT_OFF + 0);
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = _h_7;
    r1 = term_ctr(CID_SCON, STAT_OFF + 0);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K86)
  {
    WL_POPN(3);
    u32 _m_14 = STK(0);
    Term _h_10 = STK(1);
    Term _m_15 = STK(2);
    Term _h_9 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_14;
      STK(1) = _m_15;
      STK(2) = FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K87;
      WL_PUSHN(3);
    } else {
      u64 _t_14 = task_node(e, FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K87, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _m_14;
      e.mem[_t_14 + 1] = _m_15;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K87, _t_14);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_15 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _h_10;
      e.mem[_t_15 + 1] = _h_9;
      return term_tsk(FID_STRING_APPEND, _t_15);
    }
    r0 = _h_10;
    r1 = _h_9;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K87)
  {
    WL_POPN(2);
    u32 _m_16 = STK(0);
    Term _m_17 = STK(1);
    Term _h_11 = r0;
    WL_OPEN
    Term _at_4 = blk_loc(e.mem, _m_17);
    Term _at_5 = blk_at(_m_17, 2ull, 0);
    u32 _c_2 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_16;
      STK(1) = _h_11;
      STK(2) = _m_17;
      STK(3) = FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K88;
      WL_PUSHN(4);
    } else {
      u64 _t_16 = task_node(e, FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K88, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _m_16;
      e.mem[_t_16 + 1] = _h_11;
      e.mem[_t_16 + 2] = _m_17;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K88, _t_16);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_17 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _c_2;
      return term_tsk(FID_U32_SHOW, _t_17);
    }
    r0 = _c_2;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K88)
  {
    WL_POPN(3);
    u32 _m_18 = STK(0);
    Term _h_13 = STK(1);
    Term _m_19 = STK(2);
    Term _h_12 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_18;
      STK(1) = _h_13;
      STK(2) = _m_19;
      STK(3) = FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K89;
      WL_PUSHN(4);
    } else {
      u64 _t_18 = task_node(e, FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K89, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _m_18;
      e.mem[_t_18 + 1] = _h_13;
      e.mem[_t_18 + 2] = _m_19;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K89, _t_18);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_19 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _h_12;
      e.mem[_t_19 + 1] = term_ctr(CID_SCON, STAT_OFF + 0);
      return term_tsk(FID_STRING_APPEND, _t_19);
    }
    r0 = _h_12;
    r1 = term_ctr(CID_SCON, STAT_OFF + 0);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K89)
  {
    WL_POPN(3);
    u32 _m_20 = STK(0);
    Term _h_15 = STK(1);
    Term _m_21 = STK(2);
    Term _h_14 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_20;
      STK(1) = _m_21;
      STK(2) = FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K90;
      WL_PUSHN(3);
    } else {
      u64 _t_20 = task_node(e, FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K90, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _m_20;
      e.mem[_t_20 + 1] = _m_21;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K90, _t_20);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_21 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = _h_15;
      e.mem[_t_21 + 1] = _h_14;
      return term_tsk(FID_STRING_APPEND, _t_21);
    }
    r0 = _h_15;
    r1 = _h_14;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K90)
  {
    WL_POPN(2);
    u32 _m_22 = STK(0);
    Term _m_23 = STK(1);
    Term _h_16 = r0;
    WL_OPEN
    Term _at_6 = blk_loc(e.mem, _m_23);
    Term _at_7 = blk_at(_m_23, 3ull, 0);
    u32 _c_3 = blk_read(e.mem, 0, _at_6, _at_7 + 0);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_22;
      STK(1) = _h_16;
      STK(2) = _m_23;
      STK(3) = FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K91;
      WL_PUSHN(4);
    } else {
      u64 _t_22 = task_node(e, FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K91, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _m_22;
      e.mem[_t_22 + 1] = _h_16;
      e.mem[_t_22 + 2] = _m_23;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K91, _t_22);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_23 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = _c_3;
      return term_tsk(FID_U32_SHOW, _t_23);
    }
    r0 = _c_3;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K91)
  {
    WL_POPN(3);
    u32 _m_24 = STK(0);
    Term _h_18 = STK(1);
    Term _m_25 = STK(2);
    Term _h_17 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_24;
      STK(1) = _m_25;
      STK(2) = FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K92;
      WL_PUSHN(3);
    } else {
      u64 _t_24 = task_node(e, FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K92, WL_CONT, WL_IDX, 1);
      e.mem[_t_24 + 0] = _m_24;
      e.mem[_t_24 + 1] = _m_25;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K92, _t_24);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_25 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = _h_18;
      e.mem[_t_25 + 1] = _h_17;
      return term_tsk(FID_STRING_APPEND, _t_25);
    }
    r0 = _h_18;
    r1 = _h_17;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE_K92)
  {
    WL_POPN(2);
    u32 _m_26 = STK(0);
    Term _m_27 = STK(1);
    Term _h_19 = r0;
    WL_OPEN
    r0 = _m_27;
    r1 = _m_26;
    r2 = _h_19;
    WL_RETN(3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NAT_SHOW_FIN)
  {
    Term _g_0 = r0;
    Term _acc_0 = r1;
    u32 _dq_0 = r2;
    Term _dq_1 = r3;
    WL_OPEN
    WL_SPIN
    if (_dq_1 == 0) {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _dq_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = term_ctr(CID_SCON, _nd_0);
      WL_RETN(1);
    } else {
      Term _p_0 = (_dq_1 - 1);
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _dq_0);
      e.mem[_nd_1 + 1] = rfc_seal(e, _acc_0);
      if (_g_0 == 0) {
        Term _n_0 = nat_chk(e, _p_0 + 1);
        Term _acc_1 = term_ctr(CID_SCON, _nd_1);
        r0 = _acc_1;
        WL_RETN(1);
      } else {
        Term _g_1 = (_g_0 - 1);
        Term _n_1 = nat_chk(e, _p_0 + 1);
        Term _acc_2 = term_ctr(CID_SCON, _nd_1);
        u32 _v_0 = 0;
        Term _v_1 = 0;
        Term _a_0 = 10ull;
        Term _a_1 = (_a_0 == 0 ? 0 : _n_1 / _a_0);
        Term _a_2 = (_a_0 == 0 ? _n_1 : _n_1 % _a_0);
        u32 _v_2 = 0;
        Term _v_3 = 0;
        Term _o_0[2];
        if (spin_15(e, _o_0, _a_1, _a_2) == 0) {
          return 0;
        }
        _v_2 = _o_0[0];
        _v_3 = _o_0[1];
        _v_0 = _v_2;
        _v_1 = _v_3;
        r0 = _g_1;
        r1 = _acc_2;
        r2 = _v_0;
        r3 = _v_1;
        _g_0 = r0;
        _acc_0 = r1;
        _dq_0 = r2;
        _dq_1 = r3;
        WL_AGAIN(FID_NAT_SHOW_FIN);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW)
  {
    Term _fuel_0 = r0;
    u32 _id_0 = r1;
    Term _rows_0 = r2;
    Term _rows_1 = r3;
    Term _rows_2 = r4;
    Term _rows_3 = r5;
    Term _rows_4 = r6;
    Term _rows_5 = r7;
    u32 _rows_6 = r8;
    Term _rows_7 = r9;
    u32 _rows_8 = r10;
    WL_OPEN
    if (_fuel_0 == 0) {
      r0 = _rows_0;
      r1 = _rows_1;
      r2 = _rows_2;
      r3 = _rows_3;
      r4 = _rows_4;
      r5 = _rows_5;
      r6 = _rows_6;
      r7 = _rows_7;
      r8 = _rows_8;
      WL_RETN(9);
    } else {
      Term _n_0 = (_fuel_0 - 1);
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      Term _o_0[1];
      if (spin_23(e, _o_0, U32_BIN(_rows_6, <, _id_0), U32_BIN(_rows_6, <=, 65536ull)) == 0) {
        return 0;
      }
      _v_1 = _o_0[0];
      _v_0 = _v_1;
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _n_0;
      e.mem[_nd_0 + 1] = _id_0;
      if (_v_0 == 0) {
        Term _recurse_0 = term_clo(FID_STORAGE_GROW_C117, _nd_0);
        term_sink(e, _recurse_0);
        r0 = _rows_0;
        r1 = _rows_1;
        r2 = _rows_2;
        r3 = _rows_3;
        r4 = _rows_4;
        r5 = _rows_5;
        r6 = _rows_6;
        r7 = _rows_7;
        r8 = _rows_8;
        WL_RETN(9);
      } else {
        Term _recurse_1 = term_clo(FID_STORAGE_GROW_C117, _nd_0);
        if (seq) {
          WL_ROOM(11);
          STK(0) = _rows_0;
          STK(1) = _rows_1;
          STK(2) = _rows_2;
          STK(3) = _rows_3;
          STK(4) = _rows_4;
          STK(5) = _rows_5;
          STK(6) = _rows_6;
          STK(7) = _rows_7;
          STK(8) = _rows_8;
          STK(9) = _recurse_1;
          STK(10) = FID_STORAGE_GROW_K119;
          WL_PUSHN(11);
        } else {
          u64 _t_2 = task_node(e, FID_STORAGE_GROW_K119, WL_CONT, WL_IDX, 1);
          e.mem[_t_2 + 0] = _rows_0;
          e.mem[_t_2 + 1] = _rows_1;
          e.mem[_t_2 + 2] = _rows_2;
          e.mem[_t_2 + 3] = _rows_3;
          e.mem[_t_2 + 4] = _rows_4;
          e.mem[_t_2 + 5] = _rows_5;
          e.mem[_t_2 + 6] = _rows_6;
          e.mem[_t_2 + 7] = _rows_7;
          e.mem[_t_2 + 8] = _rows_8;
          e.mem[_t_2 + 9] = _recurse_1;
          WL_CONT = term_tsk(FID_STORAGE_GROW_K119, _t_2);
          WL_IDX = 10;
        }
        if (!DEVICE && !seq && fid_nofk(FID_STORAGE_SLOTS_EMPTY)) {
          u64 _t_3 = task_node(e, FID_STORAGE_SLOTS_EMPTY, WL_CONT, WL_IDX, 0);
          e.mem[_t_3 + 0] = _rows_7;
          return term_tsk(FID_STORAGE_SLOTS_EMPTY, _t_3);
        }
        r0 = _rows_7;
        WL_JMP(FID_STORAGE_SLOTS_EMPTY);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW_C117)
  {
    Term _n_1 = r0;
    u32 _id_1 = r1;
    Term _x_0 = r2;
    WL_OPEN
    Term _fb_0[9];
    u64 _sp_0 = ctr_take(e, _x_0, 9, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    Term _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    Term _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    u32 _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    u32 _f_8 = _fb_0[8];
    spare_free(e, cls_fit(9), _sp_0);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_STORAGE_GROW_K118;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_STORAGE_GROW_K118, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_STORAGE_GROW_K118, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_GROW)) {
      u64 _t_1 = task_node(e, FID_STORAGE_GROW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _n_1;
      e.mem[_t_1 + 1] = _id_1;
      e.mem[_t_1 + 2] = _f_0;
      e.mem[_t_1 + 3] = _f_1;
      e.mem[_t_1 + 4] = _f_2;
      e.mem[_t_1 + 5] = _f_3;
      e.mem[_t_1 + 6] = _f_4;
      e.mem[_t_1 + 7] = _f_5;
      e.mem[_t_1 + 8] = _f_6;
      e.mem[_t_1 + 9] = _f_7;
      e.mem[_t_1 + 10] = _f_8;
      return term_tsk(FID_STORAGE_GROW, _t_1);
    }
    r0 = _n_1;
    r1 = _id_1;
    r2 = _f_0;
    r3 = _f_1;
    r4 = _f_2;
    r5 = _f_3;
    r6 = _f_4;
    r7 = _f_5;
    r8 = _f_6;
    r9 = _f_7;
    r10 = _f_8;
    WL_JMP(FID_STORAGE_GROW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW_K118)
  {
    Term _r_0 = r0;
    Term _r_1 = r1;
    Term _r_2 = r2;
    Term _r_3 = r3;
    Term _r_4 = r4;
    Term _r_5 = r5;
    u32 _r_6 = r6;
    Term _r_7 = r7;
    u32 _r_8 = r8;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_1 + 0] = rfc_seal(e, _r_0);
    e.mem[_nd_1 + 1] = rfc_seal(e, _r_1);
    e.mem[_nd_1 + 2] = rfc_seal(e, _r_2);
    e.mem[_nd_1 + 3] = rfc_seal(e, _r_3);
    e.mem[_nd_1 + 4] = rfc_seal(e, _r_4);
    e.mem[_nd_1 + 5] = rfc_seal(e, _r_5);
    e.mem[_nd_1 + 6] = rfc_seal(e, _r_6);
    e.mem[_nd_1 + 7] = rfc_seal(e, _r_7);
    e.mem[_nd_1 + 8] = rfc_seal(e, _r_8);
    r0 = term_ctr(CID_STORAGE_ROWS, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW_K119)
  {
    WL_POPN(10);
    Term _rows_9 = STK(0);
    Term _rows_10 = STK(1);
    Term _rows_11 = STK(2);
    Term _rows_12 = STK(3);
    Term _rows_13 = STK(4);
    Term _rows_14 = STK(5);
    u32 _rows_15 = STK(6);
    Term _rows_16 = STK(7);
    u32 _rows_17 = STK(8);
    Term _recurse_2 = STK(9);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _rows_9;
      STK(1) = _rows_10;
      STK(2) = _rows_11;
      STK(3) = _rows_12;
      STK(4) = _rows_13;
      STK(5) = _rows_14;
      STK(6) = _rows_15;
      STK(7) = _rows_16;
      STK(8) = _rows_17;
      STK(9) = _recurse_2;
      STK(10) = _h_0;
      STK(11) = FID_STORAGE_GROW_K120;
      WL_PUSHN(12);
    } else {
      u64 _t_4 = task_node(e, FID_STORAGE_GROW_K120, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _rows_9;
      e.mem[_t_4 + 1] = _rows_10;
      e.mem[_t_4 + 2] = _rows_11;
      e.mem[_t_4 + 3] = _rows_12;
      e.mem[_t_4 + 4] = _rows_13;
      e.mem[_t_4 + 5] = _rows_14;
      e.mem[_t_4 + 6] = _rows_15;
      e.mem[_t_4 + 7] = _rows_16;
      e.mem[_t_4 + 8] = _rows_17;
      e.mem[_t_4 + 9] = _recurse_2;
      e.mem[_t_4 + 10] = _h_0;
      WL_CONT = term_tsk(FID_STORAGE_GROW_K120, _t_4);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_SLOTS_EMPTY)) {
      u64 _t_5 = task_node(e, FID_STORAGE_SLOTS_EMPTY, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _rows_16;
      return term_tsk(FID_STORAGE_SLOTS_EMPTY, _t_5);
    }
    r0 = _rows_16;
    WL_JMP(FID_STORAGE_SLOTS_EMPTY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW_K120)
  {
    WL_POPN(11);
    Term _rows_18 = STK(0);
    Term _rows_19 = STK(1);
    Term _rows_20 = STK(2);
    Term _rows_21 = STK(3);
    Term _rows_22 = STK(4);
    Term _rows_23 = STK(5);
    u32 _rows_24 = STK(6);
    Term _rows_25 = STK(7);
    u32 _rows_26 = STK(8);
    Term _recurse_3 = STK(9);
    Term _h_2 = STK(10);
    Term _h_1 = r0;
    WL_OPEN
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _o_1[4];
    if (spin_16(e, _o_1, _rows_20, blk_loc(e.mem, _rows_20), _rows_21, blk_loc(e.mem, _rows_21), _rows_22, blk_loc(e.mem, _rows_22), _rows_23, blk_loc(e.mem, _rows_23), _rows_25) == 0) {
      return 0;
    }
    _v_7 = _o_1[0];
    _v_8 = _o_1[1];
    _v_9 = _o_1[2];
    _v_10 = _o_1[3];
    _v_3 = _v_7;
    _v_4 = _v_8;
    _v_5 = _v_9;
    _v_6 = _v_10;
    u64 _nd_2 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_2 + 0] = rfc_seal(e, blk_node(e, _rows_18, _h_2));
    e.mem[_nd_2 + 1] = rfc_seal(e, blk_node(e, _rows_19, _h_1));
    e.mem[_nd_2 + 2] = rfc_seal(e, _v_3);
    e.mem[_nd_2 + 3] = rfc_seal(e, _v_4);
    e.mem[_nd_2 + 4] = rfc_seal(e, _v_5);
    e.mem[_nd_2 + 5] = rfc_seal(e, _v_6);
    e.mem[_nd_2 + 6] = rfc_seal(e, U32_BIN(_rows_24, +, _rows_24));
    e.mem[_nd_2 + 7] = rfc_seal(e, nat_chk(e, _rows_25 + 1));
    e.mem[_nd_2 + 8] = rfc_seal(e, _rows_26);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_STORAGE_GROW_K121;
      WL_PUSHN(1);
    } else {
      u64 _t_6 = task_node(e, FID_STORAGE_GROW_K121, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_STORAGE_GROW_K121, _t_6);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_7 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _recurse_3;
      e.mem[_t_7 + 1] = term_ctr(CID_STORAGE_ROWS, _nd_2);
      return term_tsk(FID_CLO_APPLY, _t_7);
    }
    r0 = _recurse_3;
    r1 = term_ctr(CID_STORAGE_ROWS, _nd_2);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_GROW_K121)
  {
    Term _r_9 = r0;
    WL_OPEN
    Term _fb_1[9];
    u64 _sp_1 = ctr_take(e, _r_9, 9, _fb_1);
    Term _f_9 = _fb_1[0];
    Term _f_10 = _fb_1[1];
    Term _f_11 = _fb_1[2];
    Term _f_12 = _fb_1[3];
    Term _f_13 = _fb_1[4];
    Term _f_14 = _fb_1[5];
    u32 _f_15 = _fb_1[6];
    Term _f_16 = _fb_1[7];
    u32 _f_17 = _fb_1[8];
    spare_free(e, cls_fit(9), _sp_1);
    r0 = _f_9;
    r1 = _f_10;
    r2 = _f_11;
    r3 = _f_12;
    r4 = _f_13;
    r5 = _f_14;
    r6 = _f_15;
    r7 = _f_16;
    r8 = _f_17;
    WL_RETN(9);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_OBSERVE)
  {
    u32 _a_0 = r0;
    Term _a_1 = r1;
    u32 _a_2 = r2;
    WL_OPEN
    if (_a_0 == 0) {
      r0 = 0;
      r1 = 0;
      r2 = 0;
      r3 = term_ctr(CID_SCON, STAT_OFF + 30);
      WL_RETN(4);
    } else {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_HEALTH_OBSERVE_K124;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_HEALTH_OBSERVE_K124, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_HEALTH_OBSERVE_K124, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE)) {
        u64 _t_1 = task_node(e, FID____OWNED_INDEX_CORE_HEALTH_OBSERVE, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _a_1;
        e.mem[_t_1 + 1] = _a_2;
        return term_tsk(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE, _t_1);
      }
      r0 = _a_1;
      r1 = _a_2;
      WL_JMP(FID____OWNED_INDEX_CORE_HEALTH_OBSERVE);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEALTH_OBSERVE_K124)
  {
    Term _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _o_0[4];
    if (spin_25(e, _o_0, _h_0, blk_loc(e.mem, _h_0), _h_1, _h_2, blk_loc(e.mem, _h_2)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    WL_RETN(4);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MOTION_OBSERVE)
  {
    u32 _m_0 = r0;
    Term _m_1 = r1;
    u32 _m_2 = r2;
    WL_OPEN
    if (_m_0 == 0) {
      r0 = 0;
      r1 = 0;
      r2 = 0;
      r3 = term_ctr(CID_SCON, STAT_OFF + 30);
      WL_RETN(4);
    } else {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_MOTION_OBSERVE_K126;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_MOTION_OBSERVE_K126, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_MOTION_OBSERVE_K126, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE)) {
        u64 _t_1 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _m_1;
        e.mem[_t_1 + 1] = _m_2;
        return term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE, _t_1);
      }
      r0 = _m_1;
      r1 = _m_2;
      WL_JMP(FID____OWNED_INDEX_CORE_MOTION_OBSERVE);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MOTION_OBSERVE_K126)
  {
    Term _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _o_0[4];
    if (spin_26(e, _o_0, _h_0, blk_loc(e.mem, _h_0), _h_1, _h_2, blk_loc(e.mem, _h_2)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    WL_RETN(4);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NAT_SHOW)
  {
    Term _n_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    Term _a_0 = 10ull;
    Term _a_1 = (_a_0 == 0 ? 0 : _n_0 / _a_0);
    Term _a_2 = (_a_0 == 0 ? _n_0 : _n_0 % _a_0);
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _o_0[2];
    if (spin_15(e, _o_0, _a_1, _a_2) == 0) {
      return 0;
    }
    _v_2 = _o_0[0];
    _v_3 = _o_0[1];
    _v_0 = _v_2;
    _v_1 = _v_3;
    if (!DEVICE && !seq && fid_nofk(FID_NAT_SHOW_FIN)) {
      u64 _t_0 = task_node(e, FID_NAT_SHOW_FIN, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _n_0;
      e.mem[_t_0 + 1] = term_pak(CID_SNIL, 0);
      e.mem[_t_0 + 2] = _v_0;
      e.mem[_t_0 + 3] = _v_1;
      return term_tsk(FID_NAT_SHOW_FIN, _t_0);
    }
    r0 = _n_0;
    r1 = term_pak(CID_SNIL, 0);
    r2 = _v_0;
    r3 = _v_1;
    WL_JMP(FID_NAT_SHOW_FIN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW)
  {
    u32 _a_0 = r0;
    WL_OPEN
    u32 _s_0 = U32_BIN(_a_0, ==, 0);
    if (_s_0 == 1) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 22);
      WL_RETN(1);
    } else {
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW_GO)) {
        u64 _t_0 = task_node(e, FID_U32_SHOW_GO, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = 10ull;
        e.mem[_t_0 + 1] = _a_0;
        e.mem[_t_0 + 2] = term_pak(CID_SNIL, 0);
        return term_tsk(FID_U32_SHOW_GO, _t_0);
      }
      r0 = 10ull;
      r1 = _a_0;
      r2 = term_pak(CID_SNIL, 0);
      WL_JMP(FID_U32_SHOW_GO);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE)
  {
    u32 _row_0 = r0;
    u32 _row_1 = r1;
    Term _row_2 = r2;
    u32 _row_3 = r3;
    u32 _row_4 = r4;
    Term _row_5 = r5;
    u32 _row_6 = r6;
    u32 _row_7 = r7;
    u32 _row_8 = r8;
    u32 _row_9 = r9;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _row_0;
      STK(1) = _row_4;
      STK(2) = _row_5;
      STK(3) = _row_6;
      STK(4) = _row_7;
      STK(5) = _row_8;
      STK(6) = _row_9;
      STK(7) = FID_ROW_OBSERVE_K176;
      WL_PUSHN(8);
    } else {
      u64 _t_0 = task_node(e, FID_ROW_OBSERVE_K176, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _row_0;
      e.mem[_t_0 + 1] = _row_4;
      e.mem[_t_0 + 2] = _row_5;
      e.mem[_t_0 + 3] = _row_6;
      e.mem[_t_0 + 4] = _row_7;
      e.mem[_t_0 + 5] = _row_8;
      e.mem[_t_0 + 6] = _row_9;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K176, _t_0);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_MOTION_OBSERVE)) {
      u64 _t_1 = task_node(e, FID_MOTION_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _row_1;
      e.mem[_t_1 + 1] = _row_2;
      e.mem[_t_1 + 2] = _row_3;
      return term_tsk(FID_MOTION_OBSERVE, _t_1);
    }
    r0 = _row_1;
    r1 = _row_2;
    r2 = _row_3;
    WL_JMP(FID_MOTION_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K176)
  {
    WL_POPN(7);
    u32 _row_10 = STK(0);
    u32 _row_11 = STK(1);
    Term _row_12 = STK(2);
    u32 _row_13 = STK(3);
    u32 _row_14 = STK(4);
    u32 _row_15 = STK(5);
    u32 _row_16 = STK(6);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    WL_OPEN
    if (seq) {
      WL_ROOM(9);
      STK(0) = _row_10;
      STK(1) = _row_14;
      STK(2) = _row_15;
      STK(3) = _row_16;
      STK(4) = _h_0;
      STK(5) = _h_1;
      STK(6) = _h_2;
      STK(7) = _h_3;
      STK(8) = FID_ROW_OBSERVE_K177;
      WL_PUSHN(9);
    } else {
      u64 _t_2 = task_node(e, FID_ROW_OBSERVE_K177, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _row_10;
      e.mem[_t_2 + 1] = _row_14;
      e.mem[_t_2 + 2] = _row_15;
      e.mem[_t_2 + 3] = _row_16;
      e.mem[_t_2 + 4] = _h_0;
      e.mem[_t_2 + 5] = _h_1;
      e.mem[_t_2 + 6] = _h_2;
      e.mem[_t_2 + 7] = _h_3;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K177, _t_2);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HEALTH_OBSERVE)) {
      u64 _t_3 = task_node(e, FID_HEALTH_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _row_11;
      e.mem[_t_3 + 1] = _row_12;
      e.mem[_t_3 + 2] = _row_13;
      return term_tsk(FID_HEALTH_OBSERVE, _t_3);
    }
    r0 = _row_11;
    r1 = _row_12;
    r2 = _row_13;
    WL_JMP(FID_HEALTH_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K177)
  {
    WL_POPN(8);
    u32 _row_17 = STK(0);
    u32 _row_18 = STK(1);
    u32 _row_19 = STK(2);
    u32 _row_20 = STK(3);
    u32 _h_8 = STK(4);
    Term _h_9 = STK(5);
    u32 _h_10 = STK(6);
    Term _h_11 = STK(7);
    u32 _h_4 = r0;
    Term _h_5 = r1;
    u32 _h_6 = r2;
    Term _h_7 = r3;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _row_17;
      STK(1) = _row_18;
      STK(2) = _row_19;
      STK(3) = _row_20;
      STK(4) = _h_8;
      STK(5) = _h_9;
      STK(6) = _h_10;
      STK(7) = _h_11;
      STK(8) = _h_4;
      STK(9) = _h_5;
      STK(10) = _h_6;
      STK(11) = _h_7;
      STK(12) = FID_ROW_OBSERVE_K178;
      WL_PUSHN(13);
    } else {
      u64 _t_4 = task_node(e, FID_ROW_OBSERVE_K178, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _row_17;
      e.mem[_t_4 + 1] = _row_18;
      e.mem[_t_4 + 2] = _row_19;
      e.mem[_t_4 + 3] = _row_20;
      e.mem[_t_4 + 4] = _h_8;
      e.mem[_t_4 + 5] = _h_9;
      e.mem[_t_4 + 6] = _h_10;
      e.mem[_t_4 + 7] = _h_11;
      e.mem[_t_4 + 8] = _h_4;
      e.mem[_t_4 + 9] = _h_5;
      e.mem[_t_4 + 10] = _h_6;
      e.mem[_t_4 + 11] = _h_7;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K178, _t_4);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_5 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _row_19;
      return term_tsk(FID_U32_SHOW, _t_5);
    }
    r0 = _row_19;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K178)
  {
    WL_POPN(12);
    u32 _row_21 = STK(0);
    u32 _row_22 = STK(1);
    u32 _row_23 = STK(2);
    u32 _row_24 = STK(3);
    u32 _h_13 = STK(4);
    Term _h_14 = STK(5);
    u32 _h_15 = STK(6);
    Term _h_16 = STK(7);
    u32 _h_17 = STK(8);
    Term _h_18 = STK(9);
    u32 _h_19 = STK(10);
    Term _h_20 = STK(11);
    Term _h_12 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _row_21;
      STK(1) = _row_22;
      STK(2) = _row_23;
      STK(3) = _row_24;
      STK(4) = _h_13;
      STK(5) = _h_14;
      STK(6) = _h_15;
      STK(7) = _h_16;
      STK(8) = _h_17;
      STK(9) = _h_18;
      STK(10) = _h_19;
      STK(11) = _h_20;
      STK(12) = _h_12;
      STK(13) = FID_ROW_OBSERVE_K179;
      WL_PUSHN(14);
    } else {
      u64 _t_6 = task_node(e, FID_ROW_OBSERVE_K179, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _row_21;
      e.mem[_t_6 + 1] = _row_22;
      e.mem[_t_6 + 2] = _row_23;
      e.mem[_t_6 + 3] = _row_24;
      e.mem[_t_6 + 4] = _h_13;
      e.mem[_t_6 + 5] = _h_14;
      e.mem[_t_6 + 6] = _h_15;
      e.mem[_t_6 + 7] = _h_16;
      e.mem[_t_6 + 8] = _h_17;
      e.mem[_t_6 + 9] = _h_18;
      e.mem[_t_6 + 10] = _h_19;
      e.mem[_t_6 + 11] = _h_20;
      e.mem[_t_6 + 12] = _h_12;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K179, _t_6);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_7 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _row_24;
      return term_tsk(FID_U32_SHOW, _t_7);
    }
    r0 = _row_24;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K179)
  {
    WL_POPN(13);
    u32 _row_25 = STK(0);
    u32 _row_26 = STK(1);
    u32 _row_27 = STK(2);
    u32 _row_28 = STK(3);
    u32 _h_22 = STK(4);
    Term _h_23 = STK(5);
    u32 _h_24 = STK(6);
    Term _h_25 = STK(7);
    u32 _h_26 = STK(8);
    Term _h_27 = STK(9);
    u32 _h_28 = STK(10);
    Term _h_29 = STK(11);
    Term _h_30 = STK(12);
    Term _h_21 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _row_25;
      STK(1) = _row_26;
      STK(2) = _row_27;
      STK(3) = _row_28;
      STK(4) = _h_22;
      STK(5) = _h_23;
      STK(6) = _h_24;
      STK(7) = _h_25;
      STK(8) = _h_26;
      STK(9) = _h_27;
      STK(10) = _h_28;
      STK(11) = _h_29;
      STK(12) = _h_30;
      STK(13) = FID_ROW_OBSERVE_K180;
      WL_PUSHN(14);
    } else {
      u64 _t_8 = task_node(e, FID_ROW_OBSERVE_K180, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _row_25;
      e.mem[_t_8 + 1] = _row_26;
      e.mem[_t_8 + 2] = _row_27;
      e.mem[_t_8 + 3] = _row_28;
      e.mem[_t_8 + 4] = _h_22;
      e.mem[_t_8 + 5] = _h_23;
      e.mem[_t_8 + 6] = _h_24;
      e.mem[_t_8 + 7] = _h_25;
      e.mem[_t_8 + 8] = _h_26;
      e.mem[_t_8 + 9] = _h_27;
      e.mem[_t_8 + 10] = _h_28;
      e.mem[_t_8 + 11] = _h_29;
      e.mem[_t_8 + 12] = _h_30;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K180, _t_8);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = term_ctr(CID_SCON, STAT_OFF + 2);
      e.mem[_t_9 + 1] = _h_21;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 2);
    r1 = _h_21;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K180)
  {
    WL_POPN(13);
    u32 _row_29 = STK(0);
    u32 _row_30 = STK(1);
    u32 _row_31 = STK(2);
    u32 _row_32 = STK(3);
    u32 _h_32 = STK(4);
    Term _h_33 = STK(5);
    u32 _h_34 = STK(6);
    Term _h_35 = STK(7);
    u32 _h_36 = STK(8);
    Term _h_37 = STK(9);
    u32 _h_38 = STK(10);
    Term _h_39 = STK(11);
    Term _h_40 = STK(12);
    Term _h_31 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _row_29;
      STK(1) = _row_30;
      STK(2) = _row_31;
      STK(3) = _row_32;
      STK(4) = _h_32;
      STK(5) = _h_33;
      STK(6) = _h_34;
      STK(7) = _h_35;
      STK(8) = _h_36;
      STK(9) = _h_37;
      STK(10) = _h_38;
      STK(11) = _h_39;
      STK(12) = FID_ROW_OBSERVE_K181;
      WL_PUSHN(13);
    } else {
      u64 _t_10 = task_node(e, FID_ROW_OBSERVE_K181, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _row_29;
      e.mem[_t_10 + 1] = _row_30;
      e.mem[_t_10 + 2] = _row_31;
      e.mem[_t_10 + 3] = _row_32;
      e.mem[_t_10 + 4] = _h_32;
      e.mem[_t_10 + 5] = _h_33;
      e.mem[_t_10 + 6] = _h_34;
      e.mem[_t_10 + 7] = _h_35;
      e.mem[_t_10 + 8] = _h_36;
      e.mem[_t_10 + 9] = _h_37;
      e.mem[_t_10 + 10] = _h_38;
      e.mem[_t_10 + 11] = _h_39;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K181, _t_10);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _h_40;
      e.mem[_t_11 + 1] = _h_31;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = _h_40;
    r1 = _h_31;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K181)
  {
    WL_POPN(12);
    u32 _row_33 = STK(0);
    u32 _row_34 = STK(1);
    u32 _row_35 = STK(2);
    u32 _row_36 = STK(3);
    u32 _h_42 = STK(4);
    Term _h_43 = STK(5);
    u32 _h_44 = STK(6);
    Term _h_45 = STK(7);
    u32 _h_46 = STK(8);
    Term _h_47 = STK(9);
    u32 _h_48 = STK(10);
    Term _h_49 = STK(11);
    Term _h_41 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _row_33;
      STK(1) = _row_34;
      STK(2) = _row_35;
      STK(3) = _row_36;
      STK(4) = _h_42;
      STK(5) = _h_43;
      STK(6) = _h_44;
      STK(7) = _h_45;
      STK(8) = _h_46;
      STK(9) = _h_47;
      STK(10) = _h_48;
      STK(11) = _h_49;
      STK(12) = FID_ROW_OBSERVE_K182;
      WL_PUSHN(13);
    } else {
      u64 _t_12 = task_node(e, FID_ROW_OBSERVE_K182, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _row_33;
      e.mem[_t_12 + 1] = _row_34;
      e.mem[_t_12 + 2] = _row_35;
      e.mem[_t_12 + 3] = _row_36;
      e.mem[_t_12 + 4] = _h_42;
      e.mem[_t_12 + 5] = _h_43;
      e.mem[_t_12 + 6] = _h_44;
      e.mem[_t_12 + 7] = _h_45;
      e.mem[_t_12 + 8] = _h_46;
      e.mem[_t_12 + 9] = _h_47;
      e.mem[_t_12 + 10] = _h_48;
      e.mem[_t_12 + 11] = _h_49;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K182, _t_12);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_13 + 1] = _h_41;
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_41;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K182)
  {
    WL_POPN(12);
    u32 _row_37 = STK(0);
    u32 _row_38 = STK(1);
    u32 _row_39 = STK(2);
    u32 _row_40 = STK(3);
    u32 _h_51 = STK(4);
    Term _h_52 = STK(5);
    u32 _h_53 = STK(6);
    Term _h_54 = STK(7);
    u32 _h_55 = STK(8);
    Term _h_56 = STK(9);
    u32 _h_57 = STK(10);
    Term _h_58 = STK(11);
    Term _h_50 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_27(e, _o_0, _row_38) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (seq) {
      WL_ROOM(13);
      STK(0) = _row_37;
      STK(1) = _row_38;
      STK(2) = _row_39;
      STK(3) = _row_40;
      STK(4) = _h_51;
      STK(5) = _h_52;
      STK(6) = _h_53;
      STK(7) = _h_54;
      STK(8) = _h_55;
      STK(9) = _h_56;
      STK(10) = _h_57;
      STK(11) = _h_58;
      STK(12) = FID_ROW_OBSERVE_K183;
      WL_PUSHN(13);
    } else {
      u64 _t_14 = task_node(e, FID_ROW_OBSERVE_K183, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _row_37;
      e.mem[_t_14 + 1] = _row_38;
      e.mem[_t_14 + 2] = _row_39;
      e.mem[_t_14 + 3] = _row_40;
      e.mem[_t_14 + 4] = _h_51;
      e.mem[_t_14 + 5] = _h_52;
      e.mem[_t_14 + 6] = _h_53;
      e.mem[_t_14 + 7] = _h_54;
      e.mem[_t_14 + 8] = _h_55;
      e.mem[_t_14 + 9] = _h_56;
      e.mem[_t_14 + 10] = _h_57;
      e.mem[_t_14 + 11] = _h_58;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K183, _t_14);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_15 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _v_0;
      e.mem[_t_15 + 1] = _h_50;
      return term_tsk(FID_STRING_APPEND, _t_15);
    }
    r0 = _v_0;
    r1 = _h_50;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K183)
  {
    WL_POPN(12);
    u32 _row_41 = STK(0);
    u32 _row_42 = STK(1);
    u32 _row_43 = STK(2);
    u32 _row_44 = STK(3);
    u32 _h_60 = STK(4);
    Term _h_61 = STK(5);
    u32 _h_62 = STK(6);
    Term _h_63 = STK(7);
    u32 _h_64 = STK(8);
    Term _h_65 = STK(9);
    u32 _h_66 = STK(10);
    Term _h_67 = STK(11);
    Term _h_59 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _row_41;
      STK(1) = _row_42;
      STK(2) = _row_43;
      STK(3) = _row_44;
      STK(4) = _h_60;
      STK(5) = _h_61;
      STK(6) = _h_62;
      STK(7) = _h_63;
      STK(8) = _h_64;
      STK(9) = _h_65;
      STK(10) = _h_66;
      STK(11) = _h_67;
      STK(12) = FID_ROW_OBSERVE_K184;
      WL_PUSHN(13);
    } else {
      u64 _t_16 = task_node(e, FID_ROW_OBSERVE_K184, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _row_41;
      e.mem[_t_16 + 1] = _row_42;
      e.mem[_t_16 + 2] = _row_43;
      e.mem[_t_16 + 3] = _row_44;
      e.mem[_t_16 + 4] = _h_60;
      e.mem[_t_16 + 5] = _h_61;
      e.mem[_t_16 + 6] = _h_62;
      e.mem[_t_16 + 7] = _h_63;
      e.mem[_t_16 + 8] = _h_64;
      e.mem[_t_16 + 9] = _h_65;
      e.mem[_t_16 + 10] = _h_66;
      e.mem[_t_16 + 11] = _h_67;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K184, _t_16);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_17 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_17 + 1] = _h_59;
      return term_tsk(FID_STRING_APPEND, _t_17);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_59;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K184)
  {
    WL_POPN(12);
    u32 _row_45 = STK(0);
    u32 _row_46 = STK(1);
    u32 _row_47 = STK(2);
    u32 _row_48 = STK(3);
    u32 _h_69 = STK(4);
    Term _h_70 = STK(5);
    u32 _h_71 = STK(6);
    Term _h_72 = STK(7);
    u32 _h_73 = STK(8);
    Term _h_74 = STK(9);
    u32 _h_75 = STK(10);
    Term _h_76 = STK(11);
    Term _h_68 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _row_45;
      STK(1) = _row_46;
      STK(2) = _row_47;
      STK(3) = _row_48;
      STK(4) = _h_69;
      STK(5) = _h_70;
      STK(6) = _h_71;
      STK(7) = _h_72;
      STK(8) = _h_73;
      STK(9) = _h_74;
      STK(10) = _h_75;
      STK(11) = FID_ROW_OBSERVE_K185;
      WL_PUSHN(12);
    } else {
      u64 _t_18 = task_node(e, FID_ROW_OBSERVE_K185, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _row_45;
      e.mem[_t_18 + 1] = _row_46;
      e.mem[_t_18 + 2] = _row_47;
      e.mem[_t_18 + 3] = _row_48;
      e.mem[_t_18 + 4] = _h_69;
      e.mem[_t_18 + 5] = _h_70;
      e.mem[_t_18 + 6] = _h_71;
      e.mem[_t_18 + 7] = _h_72;
      e.mem[_t_18 + 8] = _h_73;
      e.mem[_t_18 + 9] = _h_74;
      e.mem[_t_18 + 10] = _h_75;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K185, _t_18);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_19 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _h_76;
      e.mem[_t_19 + 1] = _h_68;
      return term_tsk(FID_STRING_APPEND, _t_19);
    }
    r0 = _h_76;
    r1 = _h_68;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K185)
  {
    WL_POPN(11);
    u32 _row_49 = STK(0);
    u32 _row_50 = STK(1);
    u32 _row_51 = STK(2);
    u32 _row_52 = STK(3);
    u32 _h_78 = STK(4);
    Term _h_79 = STK(5);
    u32 _h_80 = STK(6);
    Term _h_81 = STK(7);
    u32 _h_82 = STK(8);
    Term _h_83 = STK(9);
    u32 _h_84 = STK(10);
    Term _h_77 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _row_49;
      STK(1) = _row_50;
      STK(2) = _row_51;
      STK(3) = _row_52;
      STK(4) = _h_78;
      STK(5) = _h_79;
      STK(6) = _h_80;
      STK(7) = _h_81;
      STK(8) = _h_82;
      STK(9) = _h_83;
      STK(10) = _h_84;
      STK(11) = FID_ROW_OBSERVE_K186;
      WL_PUSHN(12);
    } else {
      u64 _t_20 = task_node(e, FID_ROW_OBSERVE_K186, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _row_49;
      e.mem[_t_20 + 1] = _row_50;
      e.mem[_t_20 + 2] = _row_51;
      e.mem[_t_20 + 3] = _row_52;
      e.mem[_t_20 + 4] = _h_78;
      e.mem[_t_20 + 5] = _h_79;
      e.mem[_t_20 + 6] = _h_80;
      e.mem[_t_20 + 7] = _h_81;
      e.mem[_t_20 + 8] = _h_82;
      e.mem[_t_20 + 9] = _h_83;
      e.mem[_t_20 + 10] = _h_84;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K186, _t_20);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_21 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_21 + 1] = _h_77;
      return term_tsk(FID_STRING_APPEND, _t_21);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_77;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K186)
  {
    WL_POPN(11);
    u32 _row_53 = STK(0);
    u32 _row_54 = STK(1);
    u32 _row_55 = STK(2);
    u32 _row_56 = STK(3);
    u32 _h_86 = STK(4);
    Term _h_87 = STK(5);
    u32 _h_88 = STK(6);
    Term _h_89 = STK(7);
    u32 _h_90 = STK(8);
    Term _h_91 = STK(9);
    u32 _h_92 = STK(10);
    Term _h_85 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _row_53;
      STK(1) = _row_54;
      STK(2) = _row_55;
      STK(3) = _row_56;
      STK(4) = _h_86;
      STK(5) = _h_87;
      STK(6) = _h_88;
      STK(7) = _h_90;
      STK(8) = _h_91;
      STK(9) = _h_92;
      STK(10) = FID_ROW_OBSERVE_K187;
      WL_PUSHN(11);
    } else {
      u64 _t_22 = task_node(e, FID_ROW_OBSERVE_K187, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _row_53;
      e.mem[_t_22 + 1] = _row_54;
      e.mem[_t_22 + 2] = _row_55;
      e.mem[_t_22 + 3] = _row_56;
      e.mem[_t_22 + 4] = _h_86;
      e.mem[_t_22 + 5] = _h_87;
      e.mem[_t_22 + 6] = _h_88;
      e.mem[_t_22 + 7] = _h_90;
      e.mem[_t_22 + 8] = _h_91;
      e.mem[_t_22 + 9] = _h_92;
      WL_CONT = term_tsk(FID_ROW_OBSERVE_K187, _t_22);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_23 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = _h_89;
      e.mem[_t_23 + 1] = _h_85;
      return term_tsk(FID_STRING_APPEND, _t_23);
    }
    r0 = _h_89;
    r1 = _h_85;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ROW_OBSERVE_K187)
  {
    WL_POPN(10);
    u32 _row_57 = STK(0);
    u32 _row_58 = STK(1);
    u32 _row_59 = STK(2);
    u32 _row_60 = STK(3);
    u32 _h_94 = STK(4);
    Term _h_95 = STK(5);
    u32 _h_96 = STK(6);
    u32 _h_97 = STK(7);
    Term _h_98 = STK(8);
    u32 _h_99 = STK(9);
    Term _h_93 = r0;
    WL_OPEN
    r0 = _row_57;
    r1 = _h_94;
    r2 = _h_95;
    r3 = _h_96;
    r4 = _h_97;
    r5 = _h_98;
    r6 = _h_99;
    r7 = _row_58;
    r8 = _row_59;
    r9 = _row_60;
    r10 = _h_93;
    WL_RETN(11);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_a_0) == CID_SNIL) {
      r0 = _b_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _a_0, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_STRING_APPEND_K195;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_STRING_APPEND_K195, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_STRING_APPEND_K195, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _b_0;
      _a_0 = r0;
      _b_0 = r1;
      WL_AGAIN(FID_STRING_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND_K195)
  {
    WL_POPN(1);
    u32 _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_SCON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_PURE)
  {
    Term _x_0 = r0;
    Term _k_0 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_0 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _k_0;
      e.mem[_t_0 + 1] = _x_0;
      return term_tsk(FID_CLO_APPLY, _t_0);
    }
    r0 = _k_0;
    r1 = _x_0;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_REMOVE_PRINT)
  {
    Term _prefix_0 = r0;
    Term _result_0 = r1;
    Term _result_1 = r2;
    Term _result_2 = r3;
    Term _result_3 = r4;
    Term _result_4 = r5;
    Term _result_5 = r6;
    u32 _result_6 = r7;
    Term _result_7 = r8;
    u32 _result_8 = r9;
    u32 _result_9 = r10;
    u32 _result_10 = r11;
    u32 _result_11 = r12;
    Term _result_12 = r13;
    u32 _result_13 = r14;
    u32 _result_14 = r15;
    Term _result_15 = r16;
    u32 _result_16 = r17;
    u32 _result_17 = r18;
    u32 _result_18 = r19;
    u32 _result_19 = r20;
    WL_OPEN
    if (_result_9 == 0) {
      if (seq) {
        WL_ROOM(10);
        STK(0) = _result_0;
        STK(1) = _result_1;
        STK(2) = _result_2;
        STK(3) = _result_3;
        STK(4) = _result_4;
        STK(5) = _result_5;
        STK(6) = _result_6;
        STK(7) = _result_7;
        STK(8) = _result_8;
        STK(9) = FID_REMOVE_PRINT_K200;
        WL_PUSHN(10);
      } else {
        u64 _t_0 = task_node(e, FID_REMOVE_PRINT_K200, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _result_0;
        e.mem[_t_0 + 1] = _result_1;
        e.mem[_t_0 + 2] = _result_2;
        e.mem[_t_0 + 3] = _result_3;
        e.mem[_t_0 + 4] = _result_4;
        e.mem[_t_0 + 5] = _result_5;
        e.mem[_t_0 + 6] = _result_6;
        e.mem[_t_0 + 7] = _result_7;
        e.mem[_t_0 + 8] = _result_8;
        WL_CONT = term_tsk(FID_REMOVE_PRINT_K200, _t_0);
        WL_IDX = 9;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
        u64 _t_1 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _prefix_0;
        e.mem[_t_1 + 1] = term_ctr(CID_SCON, STAT_OFF + 46);
        return term_tsk(FID_STRING_APPEND, _t_1);
      }
      r0 = _prefix_0;
      r1 = term_ctr(CID_SCON, STAT_OFF + 46);
      WL_JMP(FID_STRING_APPEND);
    } else {
      if (seq) {
        WL_ROOM(11);
        STK(0) = _prefix_0;
        STK(1) = _result_0;
        STK(2) = _result_1;
        STK(3) = _result_2;
        STK(4) = _result_3;
        STK(5) = _result_4;
        STK(6) = _result_5;
        STK(7) = _result_6;
        STK(8) = _result_7;
        STK(9) = _result_8;
        STK(10) = FID_REMOVE_PRINT_K204;
        WL_PUSHN(11);
      } else {
        u64 _t_4 = task_node(e, FID_REMOVE_PRINT_K204, WL_CONT, WL_IDX, 1);
        e.mem[_t_4 + 0] = _prefix_0;
        e.mem[_t_4 + 1] = _result_0;
        e.mem[_t_4 + 2] = _result_1;
        e.mem[_t_4 + 3] = _result_2;
        e.mem[_t_4 + 4] = _result_3;
        e.mem[_t_4 + 5] = _result_4;
        e.mem[_t_4 + 6] = _result_5;
        e.mem[_t_4 + 7] = _result_6;
        e.mem[_t_4 + 8] = _result_7;
        e.mem[_t_4 + 9] = _result_8;
        WL_CONT = term_tsk(FID_REMOVE_PRINT_K204, _t_4);
        WL_IDX = 10;
      }
      if (!DEVICE && !seq && fid_nofk(FID_ROW_OBSERVE)) {
        u64 _t_5 = task_node(e, FID_ROW_OBSERVE, WL_CONT, WL_IDX, 0);
        e.mem[_t_5 + 0] = _result_10;
        e.mem[_t_5 + 1] = _result_11;
        e.mem[_t_5 + 2] = _result_12;
        e.mem[_t_5 + 3] = _result_13;
        e.mem[_t_5 + 4] = _result_14;
        e.mem[_t_5 + 5] = _result_15;
        e.mem[_t_5 + 6] = _result_16;
        e.mem[_t_5 + 7] = _result_17;
        e.mem[_t_5 + 8] = _result_18;
        e.mem[_t_5 + 9] = _result_19;
        return term_tsk(FID_ROW_OBSERVE, _t_5);
      }
      r0 = _result_10;
      r1 = _result_11;
      r2 = _result_12;
      r3 = _result_13;
      r4 = _result_14;
      r5 = _result_15;
      r6 = _result_16;
      r7 = _result_17;
      r8 = _result_18;
      r9 = _result_19;
      WL_JMP(FID_ROW_OBSERVE);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_REMOVE_PRINT_K200)
  {
    WL_POPN(9);
    Term _result_20 = STK(0);
    Term _result_21 = STK(1);
    Term _result_22 = STK(2);
    Term _result_23 = STK(3);
    Term _result_24 = STK(4);
    Term _result_25 = STK(5);
    u32 _result_26 = STK(6);
    Term _result_27 = STK(7);
    u32 _result_28 = STK(8);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(10));
    e.mem[_nd_0 + 0] = _result_20;
    e.mem[_nd_0 + 1] = _result_21;
    e.mem[_nd_0 + 2] = _result_22;
    e.mem[_nd_0 + 3] = _result_23;
    e.mem[_nd_0 + 4] = _result_24;
    e.mem[_nd_0 + 5] = _result_25;
    e.mem[_nd_0 + 6] = _result_26;
    e.mem[_nd_0 + 7] = _result_27;
    e.mem[_nd_0 + 8] = _result_28;
    e.mem[_nd_0 + 9] = _h_0;
    r0 = term_clo(FID_REMOVE_PRINT_C201, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_REMOVE_PRINT_C201)
  {
    Term _result_29 = r0;
    Term _result_30 = r1;
    Term _result_31 = r2;
    Term _result_32 = r3;
    Term _result_33 = r4;
    Term _result_34 = r5;
    u32 _result_35 = r6;
    Term _result_36 = r7;
    u32 _result_37 = r8;
    Term _h_1 = r9;
    Term _x_0 = r10;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = _h_1;
    u64 _nd_2 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_2 + 0] = _result_29;
    e.mem[_nd_2 + 1] = _result_30;
    e.mem[_nd_2 + 2] = _result_31;
    e.mem[_nd_2 + 3] = _result_32;
    e.mem[_nd_2 + 4] = _result_33;
    e.mem[_nd_2 + 5] = _result_34;
    e.mem[_nd_2 + 6] = _result_35;
    e.mem[_nd_2 + 7] = _result_36;
    e.mem[_nd_2 + 8] = _result_37;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_3 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_clo(FID_IO_PRINT, _nd_1);
      e.mem[_t_3 + 1] = term_clo(FID_REMOVE_PRINT_C202, _nd_2);
      e.mem[_t_3 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_3);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_1);
    r1 = term_clo(FID_REMOVE_PRINT_C202, _nd_2);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_REMOVE_PRINT_C202)
  {
    Term _result_38 = r0;
    Term _result_39 = r1;
    Term _result_40 = r2;
    Term _result_41 = r3;
    Term _result_42 = r4;
    Term _result_43 = r5;
    u32 _result_44 = r6;
    Term _result_45 = r7;
    u32 _result_46 = r8;
    Term _x_1 = r9;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_3 + 0] = _result_38;
    e.mem[_nd_3 + 1] = _result_39;
    e.mem[_nd_3 + 2] = _result_40;
    e.mem[_nd_3 + 3] = _result_41;
    e.mem[_nd_3 + 4] = _result_42;
    e.mem[_nd_3 + 5] = _result_43;
    e.mem[_nd_3 + 6] = _result_44;
    e.mem[_nd_3 + 7] = _result_45;
    e.mem[_nd_3 + 8] = _result_46;
    r0 = term_clo(FID_REMOVE_PRINT_C203, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_REMOVE_PRINT_C203)
  {
    Term _result_47 = r0;
    Term _result_48 = r1;
    Term _result_49 = r2;
    Term _result_50 = r3;
    Term _result_51 = r4;
    Term _result_52 = r5;
    u32 _result_53 = r6;
    Term _result_54 = r7;
    u32 _result_55 = r8;
    Term _x_2 = r9;
    WL_OPEN
    u64 _nd_4 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_4 + 0] = rfc_seal(e, _result_47);
    e.mem[_nd_4 + 1] = rfc_seal(e, _result_48);
    e.mem[_nd_4 + 2] = rfc_seal(e, _result_49);
    e.mem[_nd_4 + 3] = rfc_seal(e, _result_50);
    e.mem[_nd_4 + 4] = rfc_seal(e, _result_51);
    e.mem[_nd_4 + 5] = rfc_seal(e, _result_52);
    e.mem[_nd_4 + 6] = rfc_seal(e, _result_53);
    e.mem[_nd_4 + 7] = rfc_seal(e, _result_54);
    e.mem[_nd_4 + 8] = rfc_seal(e, _result_55);
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_2 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = term_ctr(CID_STORAGE_ROWS, _nd_4);
      e.mem[_t_2 + 1] = _x_2;
      return term_tsk(FID_IO_PURE, _t_2);
    }
    r0 = term_ctr(CID_STORAGE_ROWS, _nd_4);
    r1 = _x_2;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_REMOVE_PRINT_K204)
  {
    WL_POPN(10);
    Term _prefix_1 = STK(0);
    Term _result_56 = STK(1);
    Term _result_57 = STK(2);
    Term _result_58 = STK(3);
    Term _result_59 = STK(4);
    Term _result_60 = STK(5);
    Term _result_61 = STK(6);
    u32 _result_62 = STK(7);
    Term _result_63 = STK(8);
    u32 _result_64 = STK(9);
    u32 _h_2 = r0;
    u32 _h_3 = r1;
    Term _h_4 = r2;
    u32 _h_5 = r3;
    u32 _h_6 = r4;
    Term _h_7 = r5;
    u32 _h_8 = r6;
    u32 _h_9 = r7;
    u32 _h_10 = r8;
    u32 _h_11 = r9;
    Term _h_12 = r10;
    WL_OPEN
    term_sink(e, _h_4);
    term_sink(e, _h_7);
    if (seq) {
      WL_ROOM(10);
      STK(0) = _result_56;
      STK(1) = _result_57;
      STK(2) = _result_58;
      STK(3) = _result_59;
      STK(4) = _result_60;
      STK(5) = _result_61;
      STK(6) = _result_62;
      STK(7) = _result_63;
      STK(8) = _result_64;
      STK(9) = FID_REMOVE_PRINT_K205;
      WL_PUSHN(10);
    } else {
      u64 _t_6 = task_node(e, FID_REMOVE_PRINT_K205, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _result_56;
      e.mem[_t_6 + 1] = _result_57;
      e.mem[_t_6 + 2] = _result_58;
      e.mem[_t_6 + 3] = _result_59;
      e.mem[_t_6 + 4] = _result_60;
      e.mem[_t_6 + 5] = _result_61;
      e.mem[_t_6 + 6] = _result_62;
      e.mem[_t_6 + 7] = _result_63;
      e.mem[_t_6 + 8] = _result_64;
      WL_CONT = term_tsk(FID_REMOVE_PRINT_K205, _t_6);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _prefix_1;
      e.mem[_t_7 + 1] = _h_12;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _prefix_1;
    r1 = _h_12;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_REMOVE_PRINT_K205)
  {
    WL_POPN(9);
    Term _result_65 = STK(0);
    Term _result_66 = STK(1);
    Term _result_67 = STK(2);
    Term _result_68 = STK(3);
    Term _result_69 = STK(4);
    Term _result_70 = STK(5);
    u32 _result_71 = STK(6);
    Term _result_72 = STK(7);
    u32 _result_73 = STK(8);
    Term _h_13 = r0;
    WL_OPEN
    u64 _nd_5 = heap_alloc(e, cls_fit(10));
    e.mem[_nd_5 + 0] = _result_65;
    e.mem[_nd_5 + 1] = _result_66;
    e.mem[_nd_5 + 2] = _result_67;
    e.mem[_nd_5 + 3] = _result_68;
    e.mem[_nd_5 + 4] = _result_69;
    e.mem[_nd_5 + 5] = _result_70;
    e.mem[_nd_5 + 6] = _result_71;
    e.mem[_nd_5 + 7] = _result_72;
    e.mem[_nd_5 + 8] = _result_73;
    e.mem[_nd_5 + 9] = _h_13;
    r0 = term_clo(FID_REMOVE_PRINT_C206, _nd_5);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_REMOVE_PRINT_C206)
  {
    Term _result_74 = r0;
    Term _result_75 = r1;
    Term _result_76 = r2;
    Term _result_77 = r3;
    Term _result_78 = r4;
    Term _result_79 = r5;
    u32 _result_80 = r6;
    Term _result_81 = r7;
    u32 _result_82 = r8;
    Term _h_14 = r9;
    Term _x_3 = r10;
    WL_OPEN
    u64 _nd_6 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_6 + 0] = _h_14;
    u64 _nd_7 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_7 + 0] = _result_74;
    e.mem[_nd_7 + 1] = _result_75;
    e.mem[_nd_7 + 2] = _result_76;
    e.mem[_nd_7 + 3] = _result_77;
    e.mem[_nd_7 + 4] = _result_78;
    e.mem[_nd_7 + 5] = _result_79;
    e.mem[_nd_7 + 6] = _result_80;
    e.mem[_nd_7 + 7] = _result_81;
    e.mem[_nd_7 + 8] = _result_82;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_9 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = term_clo(FID_IO_PRINT, _nd_6);
      e.mem[_t_9 + 1] = term_clo(FID_REMOVE_PRINT_C207, _nd_7);
      e.mem[_t_9 + 2] = _x_3;
      return term_tsk(FID_IO_BIND, _t_9);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_6);
    r1 = term_clo(FID_REMOVE_PRINT_C207, _nd_7);
    r2 = _x_3;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_REMOVE_PRINT_C207)
  {
    Term _result_83 = r0;
    Term _result_84 = r1;
    Term _result_85 = r2;
    Term _result_86 = r3;
    Term _result_87 = r4;
    Term _result_88 = r5;
    u32 _result_89 = r6;
    Term _result_90 = r7;
    u32 _result_91 = r8;
    Term _x_4 = r9;
    WL_OPEN
    u64 _nd_8 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_8 + 0] = _result_83;
    e.mem[_nd_8 + 1] = _result_84;
    e.mem[_nd_8 + 2] = _result_85;
    e.mem[_nd_8 + 3] = _result_86;
    e.mem[_nd_8 + 4] = _result_87;
    e.mem[_nd_8 + 5] = _result_88;
    e.mem[_nd_8 + 6] = _result_89;
    e.mem[_nd_8 + 7] = _result_90;
    e.mem[_nd_8 + 8] = _result_91;
    r0 = term_clo(FID_REMOVE_PRINT_C208, _nd_8);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_REMOVE_PRINT_C208)
  {
    Term _result_92 = r0;
    Term _result_93 = r1;
    Term _result_94 = r2;
    Term _result_95 = r3;
    Term _result_96 = r4;
    Term _result_97 = r5;
    u32 _result_98 = r6;
    Term _result_99 = r7;
    u32 _result_100 = r8;
    Term _x_5 = r9;
    WL_OPEN
    u64 _nd_9 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_9 + 0] = rfc_seal(e, _result_92);
    e.mem[_nd_9 + 1] = rfc_seal(e, _result_93);
    e.mem[_nd_9 + 2] = rfc_seal(e, _result_94);
    e.mem[_nd_9 + 3] = rfc_seal(e, _result_95);
    e.mem[_nd_9 + 4] = rfc_seal(e, _result_96);
    e.mem[_nd_9 + 5] = rfc_seal(e, _result_97);
    e.mem[_nd_9 + 6] = rfc_seal(e, _result_98);
    e.mem[_nd_9 + 7] = rfc_seal(e, _result_99);
    e.mem[_nd_9 + 8] = rfc_seal(e, _result_100);
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_8 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = term_ctr(CID_STORAGE_ROWS, _nd_9);
      e.mem[_t_8 + 1] = _x_5;
      return term_tsk(FID_IO_PURE, _t_8);
    }
    r0 = term_ctr(CID_STORAGE_ROWS, _nd_9);
    r1 = _x_5;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_EFFECT_PRINT)
  {
    Term _prefix_0 = r0;
    Term _result_0 = r1;
    Term _result_1 = r2;
    Term _result_2 = r3;
    Term _result_3 = r4;
    Term _result_4 = r5;
    Term _result_5 = r6;
    u32 _result_6 = r7;
    Term _result_7 = r8;
    u32 _result_8 = r9;
    u32 _result_9 = r10;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_39(e, _o_0, _result_9) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (seq) {
      WL_ROOM(10);
      STK(0) = _result_0;
      STK(1) = _result_1;
      STK(2) = _result_2;
      STK(3) = _result_3;
      STK(4) = _result_4;
      STK(5) = _result_5;
      STK(6) = _result_6;
      STK(7) = _result_7;
      STK(8) = _result_8;
      STK(9) = FID_EFFECT_PRINT_K211;
      WL_PUSHN(10);
    } else {
      u64 _t_0 = task_node(e, FID_EFFECT_PRINT_K211, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _result_0;
      e.mem[_t_0 + 1] = _result_1;
      e.mem[_t_0 + 2] = _result_2;
      e.mem[_t_0 + 3] = _result_3;
      e.mem[_t_0 + 4] = _result_4;
      e.mem[_t_0 + 5] = _result_5;
      e.mem[_t_0 + 6] = _result_6;
      e.mem[_t_0 + 7] = _result_7;
      e.mem[_t_0 + 8] = _result_8;
      WL_CONT = term_tsk(FID_EFFECT_PRINT_K211, _t_0);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_1 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _prefix_0;
      e.mem[_t_1 + 1] = _v_0;
      return term_tsk(FID_STRING_APPEND, _t_1);
    }
    r0 = _prefix_0;
    r1 = _v_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_EFFECT_PRINT_K211)
  {
    WL_POPN(9);
    Term _result_10 = STK(0);
    Term _result_11 = STK(1);
    Term _result_12 = STK(2);
    Term _result_13 = STK(3);
    Term _result_14 = STK(4);
    Term _result_15 = STK(5);
    u32 _result_16 = STK(6);
    Term _result_17 = STK(7);
    u32 _result_18 = STK(8);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(10));
    e.mem[_nd_0 + 0] = _result_10;
    e.mem[_nd_0 + 1] = _result_11;
    e.mem[_nd_0 + 2] = _result_12;
    e.mem[_nd_0 + 3] = _result_13;
    e.mem[_nd_0 + 4] = _result_14;
    e.mem[_nd_0 + 5] = _result_15;
    e.mem[_nd_0 + 6] = _result_16;
    e.mem[_nd_0 + 7] = _result_17;
    e.mem[_nd_0 + 8] = _result_18;
    e.mem[_nd_0 + 9] = _h_0;
    r0 = term_clo(FID_EFFECT_PRINT_C212, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_EFFECT_PRINT_C212)
  {
    Term _result_19 = r0;
    Term _result_20 = r1;
    Term _result_21 = r2;
    Term _result_22 = r3;
    Term _result_23 = r4;
    Term _result_24 = r5;
    u32 _result_25 = r6;
    Term _result_26 = r7;
    u32 _result_27 = r8;
    Term _h_1 = r9;
    Term _x_0 = r10;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = _h_1;
    u64 _nd_2 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_2 + 0] = _result_19;
    e.mem[_nd_2 + 1] = _result_20;
    e.mem[_nd_2 + 2] = _result_21;
    e.mem[_nd_2 + 3] = _result_22;
    e.mem[_nd_2 + 4] = _result_23;
    e.mem[_nd_2 + 5] = _result_24;
    e.mem[_nd_2 + 6] = _result_25;
    e.mem[_nd_2 + 7] = _result_26;
    e.mem[_nd_2 + 8] = _result_27;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_3 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_clo(FID_IO_PRINT, _nd_1);
      e.mem[_t_3 + 1] = term_clo(FID_EFFECT_PRINT_C213, _nd_2);
      e.mem[_t_3 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_3);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_1);
    r1 = term_clo(FID_EFFECT_PRINT_C213, _nd_2);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_EFFECT_PRINT_C213)
  {
    Term _result_28 = r0;
    Term _result_29 = r1;
    Term _result_30 = r2;
    Term _result_31 = r3;
    Term _result_32 = r4;
    Term _result_33 = r5;
    u32 _result_34 = r6;
    Term _result_35 = r7;
    u32 _result_36 = r8;
    Term _x_1 = r9;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_3 + 0] = _result_28;
    e.mem[_nd_3 + 1] = _result_29;
    e.mem[_nd_3 + 2] = _result_30;
    e.mem[_nd_3 + 3] = _result_31;
    e.mem[_nd_3 + 4] = _result_32;
    e.mem[_nd_3 + 5] = _result_33;
    e.mem[_nd_3 + 6] = _result_34;
    e.mem[_nd_3 + 7] = _result_35;
    e.mem[_nd_3 + 8] = _result_36;
    r0 = term_clo(FID_EFFECT_PRINT_C214, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_EFFECT_PRINT_C214)
  {
    Term _result_37 = r0;
    Term _result_38 = r1;
    Term _result_39 = r2;
    Term _result_40 = r3;
    Term _result_41 = r4;
    Term _result_42 = r5;
    u32 _result_43 = r6;
    Term _result_44 = r7;
    u32 _result_45 = r8;
    Term _x_2 = r9;
    WL_OPEN
    u64 _nd_4 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_4 + 0] = rfc_seal(e, _result_37);
    e.mem[_nd_4 + 1] = rfc_seal(e, _result_38);
    e.mem[_nd_4 + 2] = rfc_seal(e, _result_39);
    e.mem[_nd_4 + 3] = rfc_seal(e, _result_40);
    e.mem[_nd_4 + 4] = rfc_seal(e, _result_41);
    e.mem[_nd_4 + 5] = rfc_seal(e, _result_42);
    e.mem[_nd_4 + 6] = rfc_seal(e, _result_43);
    e.mem[_nd_4 + 7] = rfc_seal(e, _result_44);
    e.mem[_nd_4 + 8] = rfc_seal(e, _result_45);
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_2 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = term_ctr(CID_STORAGE_ROWS, _nd_4);
      e.mem[_t_2 + 1] = _x_2;
      return term_tsk(FID_IO_PURE, _t_2);
    }
    r0 = term_ctr(CID_STORAGE_ROWS, _nd_4);
    r1 = _x_2;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_MOTION_OBSERVE)
  {
    Term _m_0 = r0;
    u32 _m_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_0;
      STK(1) = _m_1;
      STK(2) = FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K218;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K218, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _m_0;
      e.mem[_t_0 + 1] = _m_1;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K218, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _m_1;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _m_1;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K218)
  {
    WL_POPN(2);
    Term _m_2 = STK(0);
    u32 _m_3 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_2;
      STK(1) = _m_3;
      STK(2) = FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K219;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K219, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _m_2;
      e.mem[_t_2 + 1] = _m_3;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K219, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = term_ctr(CID_SCON, STAT_OFF + 2);
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _h_0;
    r1 = term_ctr(CID_SCON, STAT_OFF + 2);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K219)
  {
    WL_POPN(2);
    Term _m_4 = STK(0);
    u32 _m_5 = STK(1);
    Term _h_1 = r0;
    WL_OPEN
    Term _at_0 = blk_loc(e.mem, _m_4);
    Term _at_1 = blk_at(_m_4, 0ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_5;
      STK(1) = _h_1;
      STK(2) = _m_4;
      STK(3) = FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K220;
      WL_PUSHN(4);
    } else {
      u64 _t_4 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K220, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _m_5;
      e.mem[_t_4 + 1] = _h_1;
      e.mem[_t_4 + 2] = _m_4;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K220, _t_4);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_5 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _c_0;
      return term_tsk(FID_U32_SHOW, _t_5);
    }
    r0 = _c_0;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K220)
  {
    WL_POPN(3);
    u32 _m_6 = STK(0);
    Term _h_3 = STK(1);
    Term _m_7 = STK(2);
    Term _h_2 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_6;
      STK(1) = _h_3;
      STK(2) = _m_7;
      STK(3) = FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K221;
      WL_PUSHN(4);
    } else {
      u64 _t_6 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K221, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _m_6;
      e.mem[_t_6 + 1] = _h_3;
      e.mem[_t_6 + 2] = _m_7;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K221, _t_6);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_2;
      e.mem[_t_7 + 1] = term_ctr(CID_SCON, STAT_OFF + 0);
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_2;
    r1 = term_ctr(CID_SCON, STAT_OFF + 0);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K221)
  {
    WL_POPN(3);
    u32 _m_8 = STK(0);
    Term _h_5 = STK(1);
    Term _m_9 = STK(2);
    Term _h_4 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_8;
      STK(1) = _m_9;
      STK(2) = FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K222;
      WL_PUSHN(3);
    } else {
      u64 _t_8 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K222, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _m_8;
      e.mem[_t_8 + 1] = _m_9;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K222, _t_8);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_5;
      e.mem[_t_9 + 1] = _h_4;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _h_5;
    r1 = _h_4;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K222)
  {
    WL_POPN(2);
    u32 _m_10 = STK(0);
    Term _m_11 = STK(1);
    Term _h_6 = r0;
    WL_OPEN
    Term _at_2 = blk_loc(e.mem, _m_11);
    Term _at_3 = blk_at(_m_11, 1ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_10;
      STK(1) = _h_6;
      STK(2) = _m_11;
      STK(3) = FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K223;
      WL_PUSHN(4);
    } else {
      u64 _t_10 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K223, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _m_10;
      e.mem[_t_10 + 1] = _h_6;
      e.mem[_t_10 + 2] = _m_11;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K223, _t_10);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_11 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _c_1;
      return term_tsk(FID_U32_SHOW, _t_11);
    }
    r0 = _c_1;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K223)
  {
    WL_POPN(3);
    u32 _m_12 = STK(0);
    Term _h_8 = STK(1);
    Term _m_13 = STK(2);
    Term _h_7 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_12;
      STK(1) = _h_8;
      STK(2) = _m_13;
      STK(3) = FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K224;
      WL_PUSHN(4);
    } else {
      u64 _t_12 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K224, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _m_12;
      e.mem[_t_12 + 1] = _h_8;
      e.mem[_t_12 + 2] = _m_13;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K224, _t_12);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _h_7;
      e.mem[_t_13 + 1] = term_ctr(CID_SCON, STAT_OFF + 0);
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = _h_7;
    r1 = term_ctr(CID_SCON, STAT_OFF + 0);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K224)
  {
    WL_POPN(3);
    u32 _m_14 = STK(0);
    Term _h_10 = STK(1);
    Term _m_15 = STK(2);
    Term _h_9 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_14;
      STK(1) = _m_15;
      STK(2) = FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K225;
      WL_PUSHN(3);
    } else {
      u64 _t_14 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K225, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _m_14;
      e.mem[_t_14 + 1] = _m_15;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K225, _t_14);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_15 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _h_10;
      e.mem[_t_15 + 1] = _h_9;
      return term_tsk(FID_STRING_APPEND, _t_15);
    }
    r0 = _h_10;
    r1 = _h_9;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K225)
  {
    WL_POPN(2);
    u32 _m_16 = STK(0);
    Term _m_17 = STK(1);
    Term _h_11 = r0;
    WL_OPEN
    Term _at_4 = blk_loc(e.mem, _m_17);
    Term _at_5 = blk_at(_m_17, 2ull, 0);
    u32 _c_2 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_16;
      STK(1) = _h_11;
      STK(2) = _m_17;
      STK(3) = FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K226;
      WL_PUSHN(4);
    } else {
      u64 _t_16 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K226, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _m_16;
      e.mem[_t_16 + 1] = _h_11;
      e.mem[_t_16 + 2] = _m_17;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K226, _t_16);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_17 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _c_2;
      return term_tsk(FID_U32_SHOW, _t_17);
    }
    r0 = _c_2;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K226)
  {
    WL_POPN(3);
    u32 _m_18 = STK(0);
    Term _h_13 = STK(1);
    Term _m_19 = STK(2);
    Term _h_12 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_18;
      STK(1) = _h_13;
      STK(2) = _m_19;
      STK(3) = FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K227;
      WL_PUSHN(4);
    } else {
      u64 _t_18 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K227, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _m_18;
      e.mem[_t_18 + 1] = _h_13;
      e.mem[_t_18 + 2] = _m_19;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K227, _t_18);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_19 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _h_12;
      e.mem[_t_19 + 1] = term_ctr(CID_SCON, STAT_OFF + 0);
      return term_tsk(FID_STRING_APPEND, _t_19);
    }
    r0 = _h_12;
    r1 = term_ctr(CID_SCON, STAT_OFF + 0);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K227)
  {
    WL_POPN(3);
    u32 _m_20 = STK(0);
    Term _h_15 = STK(1);
    Term _m_21 = STK(2);
    Term _h_14 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_20;
      STK(1) = _m_21;
      STK(2) = FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K228;
      WL_PUSHN(3);
    } else {
      u64 _t_20 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K228, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _m_20;
      e.mem[_t_20 + 1] = _m_21;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K228, _t_20);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_21 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = _h_15;
      e.mem[_t_21 + 1] = _h_14;
      return term_tsk(FID_STRING_APPEND, _t_21);
    }
    r0 = _h_15;
    r1 = _h_14;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K228)
  {
    WL_POPN(2);
    u32 _m_22 = STK(0);
    Term _m_23 = STK(1);
    Term _h_16 = r0;
    WL_OPEN
    Term _at_6 = blk_loc(e.mem, _m_23);
    Term _at_7 = blk_at(_m_23, 3ull, 0);
    u32 _c_3 = blk_read(e.mem, 0, _at_6, _at_7 + 0);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _m_22;
      STK(1) = _h_16;
      STK(2) = _m_23;
      STK(3) = FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K229;
      WL_PUSHN(4);
    } else {
      u64 _t_22 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K229, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _m_22;
      e.mem[_t_22 + 1] = _h_16;
      e.mem[_t_22 + 2] = _m_23;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K229, _t_22);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_23 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = _c_3;
      return term_tsk(FID_U32_SHOW, _t_23);
    }
    r0 = _c_3;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K229)
  {
    WL_POPN(3);
    u32 _m_24 = STK(0);
    Term _h_18 = STK(1);
    Term _m_25 = STK(2);
    Term _h_17 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _m_24;
      STK(1) = _m_25;
      STK(2) = FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K230;
      WL_PUSHN(3);
    } else {
      u64 _t_24 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K230, WL_CONT, WL_IDX, 1);
      e.mem[_t_24 + 0] = _m_24;
      e.mem[_t_24 + 1] = _m_25;
      WL_CONT = term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K230, _t_24);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_25 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = _h_18;
      e.mem[_t_25 + 1] = _h_17;
      return term_tsk(FID_STRING_APPEND, _t_25);
    }
    r0 = _h_18;
    r1 = _h_17;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID____OWNED_INDEX_CORE_MOTION_OBSERVE_K230)
  {
    WL_POPN(2);
    u32 _m_26 = STK(0);
    Term _m_27 = STK(1);
    Term _h_19 = r0;
    WL_OPEN
    r0 = _m_27;
    r1 = _m_26;
    r2 = _h_19;
    WL_RETN(3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_WITH_MAIN)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    Term _world_2 = r2;
    Term _world_3 = r3;
    Term _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    u32 _world_8 = r8;
    Term _world_9 = r9;
    u32 _world_10 = r10;
    Term _world_11 = r11;
    u32 _world_12 = r12;
    Term _world_13 = r13;
    Term _world_14 = r14;
    u32 _handle_0 = r15;
    u32 _handle_1 = r16;
    Term _transform_0 = r17;
    WL_OPEN
    u32 _s_0 = U32_BIN(_world_0, ==, _handle_0);
    if (_s_0 == 0) {
      term_sink(e, _transform_0);
      r0 = _world_0;
      r1 = _world_1;
      r2 = _world_2;
      r3 = _world_3;
      r4 = _world_4;
      r5 = _world_5;
      r6 = _world_6;
      r7 = _world_7;
      r8 = _world_8;
      r9 = _world_9;
      r10 = _world_10;
      r11 = _world_11;
      r12 = _world_12;
      r13 = _world_13;
      r14 = _world_14;
      r15 = 2;
      r16 = 0;
      WL_RETN(17);
    } else {
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      u32 _v_2 = 0;
      Term _o_0[1];
      if (spin_23(e, _o_0, U32_BIN(_handle_1, <=, _world_8), U32_BIN(_handle_1, <=, _world_10)) == 0) {
        return 0;
      }
      _v_2 = _o_0[0];
      _v_1 = _v_2;
      u32 _v_3 = 0;
      Term _o_1[1];
      if (spin_23(e, _o_1, U32_BIN(0ull, <, _handle_1), _v_1) == 0) {
        return 0;
      }
      _v_3 = _o_1[0];
      _v_0 = _v_3;
      if (_v_0 == 0) {
        term_sink(e, _transform_0);
        r0 = _world_0;
        r1 = _world_1;
        r2 = _world_2;
        r3 = _world_3;
        r4 = _world_4;
        r5 = _world_5;
        r6 = _world_6;
        r7 = _world_7;
        r8 = _world_8;
        r9 = _world_9;
        r10 = _world_10;
        r11 = _world_11;
        r12 = _world_12;
        r13 = _world_13;
        r14 = _world_14;
        r15 = 2;
        r16 = 0;
        WL_RETN(17);
      } else {
        u32 _index_0 = U32_BIN(_handle_1, -, 1ull);
        Term _at_0 = blk_loc(e.mem, _world_4);
        Term _at_1 = blk_at(_world_4, _index_0, 0);
        u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
        if (_c_0 == 0) {
          term_sink(e, _transform_0);
          r0 = _world_0;
          r1 = _world_1;
          r2 = _world_2;
          r3 = _world_3;
          r4 = _world_4;
          r5 = _world_5;
          r6 = _world_6;
          r7 = _world_7;
          r8 = _world_8;
          r9 = _world_9;
          r10 = _world_10;
          r11 = _world_11;
          r12 = _world_12;
          r13 = _world_13;
          r14 = _world_14;
          r15 = 2;
          r16 = 0;
          WL_RETN(17);
        } else {
          Term _at_2 = blk_loc(e.mem, _world_2);
          Term _at_3 = blk_at(_world_2, _index_0, 1);
          u32 _c_1 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
          Term _c_2 = e.mem[_at_2 + _at_3 + 1];
          blk_write(e.mem, 1, _at_2, _at_3 + 0, 0);
          blk_write(e.mem, 1, _at_2, _at_3 + 1, 0);
          if (_c_1 == 0) {
            term_sink(e, _transform_0);
            r0 = _world_0;
            r1 = _world_1;
            r2 = _world_2;
            r3 = _world_3;
            r4 = _world_4;
            r5 = _world_5;
            r6 = _world_6;
            r7 = _world_7;
            r8 = _world_8;
            r9 = _world_9;
            r10 = _world_10;
            r11 = _world_11;
            r12 = _world_12;
            r13 = _world_13;
            r14 = _world_14;
            r15 = 1;
            r16 = 0;
            WL_RETN(17);
          } else {
            if (seq) {
              WL_ROOM(17);
              STK(0) = _world_0;
              STK(1) = _world_1;
              STK(2) = _world_3;
              STK(3) = _world_4;
              STK(4) = _world_5;
              STK(5) = _world_6;
              STK(6) = _world_7;
              STK(7) = _world_8;
              STK(8) = _world_9;
              STK(9) = _world_10;
              STK(10) = _world_11;
              STK(11) = _world_12;
              STK(12) = _world_13;
              STK(13) = _world_14;
              STK(14) = _index_0;
              STK(15) = _world_2;
              STK(16) = FID_STORAGE_WITH_MAIN_K233;
              WL_PUSHN(17);
            } else {
              u64 _t_0 = task_node(e, FID_STORAGE_WITH_MAIN_K233, WL_CONT, WL_IDX, 1);
              e.mem[_t_0 + 0] = _world_0;
              e.mem[_t_0 + 1] = _world_1;
              e.mem[_t_0 + 2] = _world_3;
              e.mem[_t_0 + 3] = _world_4;
              e.mem[_t_0 + 4] = _world_5;
              e.mem[_t_0 + 5] = _world_6;
              e.mem[_t_0 + 6] = _world_7;
              e.mem[_t_0 + 7] = _world_8;
              e.mem[_t_0 + 8] = _world_9;
              e.mem[_t_0 + 9] = _world_10;
              e.mem[_t_0 + 10] = _world_11;
              e.mem[_t_0 + 11] = _world_12;
              e.mem[_t_0 + 12] = _world_13;
              e.mem[_t_0 + 13] = _world_14;
              e.mem[_t_0 + 14] = _index_0;
              e.mem[_t_0 + 15] = _world_2;
              WL_CONT = term_tsk(FID_STORAGE_WITH_MAIN_K233, _t_0);
              WL_IDX = 16;
            }
            if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
              u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
              e.mem[_t_1 + 0] = _transform_0;
              e.mem[_t_1 + 1] = _c_2;
              return term_tsk(FID_CLO_APPLY, _t_1);
            }
            r0 = _transform_0;
            r1 = _c_2;
            WL_JMP(FID_CLO_APPLY);
          }
        }
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_WITH_MAIN_K233)
  {
    WL_POPN(16);
    u32 _world_15 = STK(0);
    u32 _world_16 = STK(1);
    Term _world_17 = STK(2);
    Term _world_18 = STK(3);
    Term _world_19 = STK(4);
    Term _world_20 = STK(5);
    Term _world_21 = STK(6);
    u32 _world_22 = STK(7);
    Term _world_23 = STK(8);
    u32 _world_24 = STK(9);
    Term _world_25 = STK(10);
    u32 _world_26 = STK(11);
    Term _world_27 = STK(12);
    Term _world_28 = STK(13);
    u32 _index_1 = STK(14);
    Term _world_29 = STK(15);
    Term _h_0 = r0;
    WL_OPEN
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _h_0, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    u32 _v_12 = 0;
    Term _v_13 = 0;
    u32 _v_14 = 0;
    Term _v_15 = 0;
    u32 _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    Term _v_20 = 0;
    Term _o_2[17];
    if (spin_2(e, _o_2, _world_15, _world_16, _world_17, blk_loc(e.mem, _world_17), _world_18, blk_loc(e.mem, _world_18), _world_19, blk_loc(e.mem, _world_19), _world_20, blk_loc(e.mem, _world_20), _world_21, blk_loc(e.mem, _world_21), _world_22, _world_23, _world_24, _world_25, blk_loc(e.mem, _world_25), _world_26, _world_27, blk_loc(e.mem, _world_27), _world_28, blk_loc(e.mem, _world_28), _world_29, blk_loc(e.mem, _world_29), _index_1, _f_0, blk_loc(e.mem, _f_0), _f_1, blk_loc(e.mem, _f_1)) == 0) {
      return 0;
    }
    _v_4 = _o_2[0];
    _v_5 = _o_2[1];
    _v_6 = _o_2[2];
    _v_7 = _o_2[3];
    _v_8 = _o_2[4];
    _v_9 = _o_2[5];
    _v_10 = _o_2[6];
    _v_11 = _o_2[7];
    _v_12 = _o_2[8];
    _v_13 = _o_2[9];
    _v_14 = _o_2[10];
    _v_15 = _o_2[11];
    _v_16 = _o_2[12];
    _v_17 = _o_2[13];
    _v_18 = _o_2[14];
    _v_19 = _o_2[15];
    _v_20 = _o_2[16];
    r0 = _v_4;
    r1 = _v_5;
    r2 = _v_6;
    r3 = _v_7;
    r4 = _v_8;
    r5 = _v_9;
    r6 = _v_10;
    r7 = _v_11;
    r8 = _v_12;
    r9 = _v_13;
    r10 = _v_14;
    r11 = _v_15;
    r12 = _v_16;
    r13 = _v_17;
    r14 = _v_18;
    r15 = _v_19;
    r16 = _v_20;
    WL_RETN(17);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_PRINT)
  {
    Term _prefix_0 = r0;
    u32 _result_0 = r1;
    u32 _result_1 = r2;
    Term _result_2 = r3;
    Term _result_3 = r4;
    Term _result_4 = r5;
    Term _result_5 = r6;
    Term _result_6 = r7;
    Term _result_7 = r8;
    u32 _result_8 = r9;
    Term _result_9 = r10;
    u32 _result_10 = r11;
    Term _result_11 = r12;
    u32 _result_12 = r13;
    u32 _result_13 = r14;
    Term _result_14 = r15;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_43(e, _o_0, _result_13, _result_14, blk_loc(e.mem, _result_14)) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (seq) {
      WL_ROOM(14);
      STK(0) = _result_0;
      STK(1) = _result_1;
      STK(2) = _result_2;
      STK(3) = _result_3;
      STK(4) = _result_4;
      STK(5) = _result_5;
      STK(6) = _result_6;
      STK(7) = _result_7;
      STK(8) = _result_8;
      STK(9) = _result_9;
      STK(10) = _result_10;
      STK(11) = _result_11;
      STK(12) = _result_12;
      STK(13) = FID_MAIN_PRINT_K235;
      WL_PUSHN(14);
    } else {
      u64 _t_0 = task_node(e, FID_MAIN_PRINT_K235, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _result_0;
      e.mem[_t_0 + 1] = _result_1;
      e.mem[_t_0 + 2] = _result_2;
      e.mem[_t_0 + 3] = _result_3;
      e.mem[_t_0 + 4] = _result_4;
      e.mem[_t_0 + 5] = _result_5;
      e.mem[_t_0 + 6] = _result_6;
      e.mem[_t_0 + 7] = _result_7;
      e.mem[_t_0 + 8] = _result_8;
      e.mem[_t_0 + 9] = _result_9;
      e.mem[_t_0 + 10] = _result_10;
      e.mem[_t_0 + 11] = _result_11;
      e.mem[_t_0 + 12] = _result_12;
      WL_CONT = term_tsk(FID_MAIN_PRINT_K235, _t_0);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_1 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _prefix_0;
      e.mem[_t_1 + 1] = _v_0;
      return term_tsk(FID_STRING_APPEND, _t_1);
    }
    r0 = _prefix_0;
    r1 = _v_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_PRINT_K235)
  {
    WL_POPN(13);
    u32 _result_17 = STK(0);
    u32 _result_18 = STK(1);
    Term _result_19 = STK(2);
    Term _result_20 = STK(3);
    Term _result_21 = STK(4);
    Term _result_22 = STK(5);
    Term _result_23 = STK(6);
    Term _result_24 = STK(7);
    u32 _result_25 = STK(8);
    Term _result_26 = STK(9);
    u32 _result_27 = STK(10);
    Term _result_28 = STK(11);
    u32 _result_29 = STK(12);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(14));
    e.mem[_nd_0 + 0] = _result_17;
    e.mem[_nd_0 + 1] = _result_18;
    e.mem[_nd_0 + 2] = _result_19;
    e.mem[_nd_0 + 3] = _result_20;
    e.mem[_nd_0 + 4] = _result_21;
    e.mem[_nd_0 + 5] = _result_22;
    e.mem[_nd_0 + 6] = _result_23;
    e.mem[_nd_0 + 7] = _result_24;
    e.mem[_nd_0 + 8] = _result_25;
    e.mem[_nd_0 + 9] = _result_26;
    e.mem[_nd_0 + 10] = _result_27;
    e.mem[_nd_0 + 11] = _result_28;
    e.mem[_nd_0 + 12] = _result_29;
    e.mem[_nd_0 + 13] = _h_0;
    r0 = term_clo(FID_MAIN_PRINT_C236, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_PRINT_C236)
  {
    u32 _result_30 = r0;
    u32 _result_31 = r1;
    Term _result_32 = r2;
    Term _result_33 = r3;
    Term _result_34 = r4;
    Term _result_35 = r5;
    Term _result_36 = r6;
    Term _result_37 = r7;
    u32 _result_38 = r8;
    Term _result_39 = r9;
    u32 _result_40 = r10;
    Term _result_41 = r11;
    u32 _result_42 = r12;
    Term _h_1 = r13;
    Term _x_0 = r14;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = _h_1;
    u64 _nd_2 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_2 + 0] = _result_30;
    e.mem[_nd_2 + 1] = _result_31;
    e.mem[_nd_2 + 2] = _result_32;
    e.mem[_nd_2 + 3] = _result_33;
    e.mem[_nd_2 + 4] = _result_34;
    e.mem[_nd_2 + 5] = _result_35;
    e.mem[_nd_2 + 6] = _result_36;
    e.mem[_nd_2 + 7] = _result_37;
    e.mem[_nd_2 + 8] = _result_38;
    e.mem[_nd_2 + 9] = _result_39;
    e.mem[_nd_2 + 10] = _result_40;
    e.mem[_nd_2 + 11] = _result_41;
    e.mem[_nd_2 + 12] = _result_42;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_3 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_clo(FID_IO_PRINT, _nd_1);
      e.mem[_t_3 + 1] = term_clo(FID_MAIN_PRINT_C237, _nd_2);
      e.mem[_t_3 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_3);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_1);
    r1 = term_clo(FID_MAIN_PRINT_C237, _nd_2);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_PRINT_C237)
  {
    u32 _result_43 = r0;
    u32 _result_44 = r1;
    Term _result_45 = r2;
    Term _result_46 = r3;
    Term _result_47 = r4;
    Term _result_48 = r5;
    Term _result_49 = r6;
    Term _result_50 = r7;
    u32 _result_51 = r8;
    Term _result_52 = r9;
    u32 _result_53 = r10;
    Term _result_54 = r11;
    u32 _result_55 = r12;
    Term _x_1 = r13;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_3 + 0] = _result_43;
    e.mem[_nd_3 + 1] = _result_44;
    e.mem[_nd_3 + 2] = _result_45;
    e.mem[_nd_3 + 3] = _result_46;
    e.mem[_nd_3 + 4] = _result_47;
    e.mem[_nd_3 + 5] = _result_48;
    e.mem[_nd_3 + 6] = _result_49;
    e.mem[_nd_3 + 7] = _result_50;
    e.mem[_nd_3 + 8] = _result_51;
    e.mem[_nd_3 + 9] = _result_52;
    e.mem[_nd_3 + 10] = _result_53;
    e.mem[_nd_3 + 11] = _result_54;
    e.mem[_nd_3 + 12] = _result_55;
    r0 = term_clo(FID_MAIN_PRINT_C238, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_PRINT_C238)
  {
    u32 _result_56 = r0;
    u32 _result_57 = r1;
    Term _result_58 = r2;
    Term _result_59 = r3;
    Term _result_60 = r4;
    Term _result_61 = r5;
    Term _result_62 = r6;
    Term _result_63 = r7;
    u32 _result_64 = r8;
    Term _result_65 = r9;
    u32 _result_66 = r10;
    Term _result_67 = r11;
    u32 _result_68 = r12;
    Term _x_2 = r13;
    WL_OPEN
    u32 _o_1 = 0;
    Term _o_2 = 0;
    if (_result_68 == 0) {
      _o_1 = 0;
    } else {
      _o_1 = 1;
      _o_2 = term_pak(CID_UNIT, 0);
    }
    u64 _nd_4 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_4 + 0] = rfc_seal(e, _result_56);
    e.mem[_nd_4 + 1] = rfc_seal(e, _result_57);
    e.mem[_nd_4 + 2] = rfc_seal(e, _result_58);
    e.mem[_nd_4 + 3] = rfc_seal(e, _result_59);
    e.mem[_nd_4 + 4] = rfc_seal(e, _result_60);
    e.mem[_nd_4 + 5] = rfc_seal(e, _result_61);
    e.mem[_nd_4 + 6] = rfc_seal(e, _result_62);
    e.mem[_nd_4 + 7] = rfc_seal(e, _result_63);
    e.mem[_nd_4 + 8] = rfc_seal(e, _result_64);
    e.mem[_nd_4 + 9] = rfc_seal(e, _result_65);
    e.mem[_nd_4 + 10] = rfc_seal(e, _result_66);
    e.mem[_nd_4 + 11] = rfc_seal(e, _result_67);
    e.mem[_nd_4 + 12] = rfc_seal(e, _o_1);
    e.mem[_nd_4 + 13] = rfc_seal(e, _o_2);
    e.mem[_nd_4 + 14] = rfc_seal(e, term_pak(CID_UNIT, 0));
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_2 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = term_ctr(CID_STORAGE_WORLD, _nd_4);
      e.mem[_t_2 + 1] = _x_2;
      return term_tsk(FID_IO_PURE, _t_2);
    }
    r0 = term_ctr(CID_STORAGE_WORLD, _nd_4);
    r1 = _x_2;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOOKUP_PRINT)
  {
    Term _prefix_0 = r0;
    Term _result_0 = r1;
    Term _result_1 = r2;
    Term _result_2 = r3;
    Term _result_3 = r4;
    Term _result_4 = r5;
    Term _result_5 = r6;
    u32 _result_6 = r7;
    Term _result_7 = r8;
    u32 _result_8 = r9;
    u32 _result_9 = r10;
    u32 _result_10 = r11;
    u32 _result_11 = r12;
    Term _result_12 = r13;
    u32 _result_13 = r14;
    u32 _result_14 = r15;
    Term _result_15 = r16;
    u32 _result_16 = r17;
    u32 _result_17 = r18;
    u32 _result_18 = r19;
    u32 _result_19 = r20;
    WL_OPEN
    if (_result_9 == 0) {
      if (seq) {
        WL_ROOM(10);
        STK(0) = _result_0;
        STK(1) = _result_1;
        STK(2) = _result_2;
        STK(3) = _result_3;
        STK(4) = _result_4;
        STK(5) = _result_5;
        STK(6) = _result_6;
        STK(7) = _result_7;
        STK(8) = _result_8;
        STK(9) = FID_LOOKUP_PRINT_K241;
        WL_PUSHN(10);
      } else {
        u64 _t_0 = task_node(e, FID_LOOKUP_PRINT_K241, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _result_0;
        e.mem[_t_0 + 1] = _result_1;
        e.mem[_t_0 + 2] = _result_2;
        e.mem[_t_0 + 3] = _result_3;
        e.mem[_t_0 + 4] = _result_4;
        e.mem[_t_0 + 5] = _result_5;
        e.mem[_t_0 + 6] = _result_6;
        e.mem[_t_0 + 7] = _result_7;
        e.mem[_t_0 + 8] = _result_8;
        WL_CONT = term_tsk(FID_LOOKUP_PRINT_K241, _t_0);
        WL_IDX = 9;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
        u64 _t_1 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _prefix_0;
        e.mem[_t_1 + 1] = term_ctr(CID_SCON, STAT_OFF + 46);
        return term_tsk(FID_STRING_APPEND, _t_1);
      }
      r0 = _prefix_0;
      r1 = term_ctr(CID_SCON, STAT_OFF + 46);
      WL_JMP(FID_STRING_APPEND);
    } else {
      if (seq) {
        WL_ROOM(11);
        STK(0) = _prefix_0;
        STK(1) = _result_0;
        STK(2) = _result_1;
        STK(3) = _result_2;
        STK(4) = _result_3;
        STK(5) = _result_4;
        STK(6) = _result_5;
        STK(7) = _result_6;
        STK(8) = _result_7;
        STK(9) = _result_8;
        STK(10) = FID_LOOKUP_PRINT_K245;
        WL_PUSHN(11);
      } else {
        u64 _t_4 = task_node(e, FID_LOOKUP_PRINT_K245, WL_CONT, WL_IDX, 1);
        e.mem[_t_4 + 0] = _prefix_0;
        e.mem[_t_4 + 1] = _result_0;
        e.mem[_t_4 + 2] = _result_1;
        e.mem[_t_4 + 3] = _result_2;
        e.mem[_t_4 + 4] = _result_3;
        e.mem[_t_4 + 5] = _result_4;
        e.mem[_t_4 + 6] = _result_5;
        e.mem[_t_4 + 7] = _result_6;
        e.mem[_t_4 + 8] = _result_7;
        e.mem[_t_4 + 9] = _result_8;
        WL_CONT = term_tsk(FID_LOOKUP_PRINT_K245, _t_4);
        WL_IDX = 10;
      }
      if (!DEVICE && !seq && fid_nofk(FID_ROW_OBSERVE)) {
        u64 _t_5 = task_node(e, FID_ROW_OBSERVE, WL_CONT, WL_IDX, 0);
        e.mem[_t_5 + 0] = _result_10;
        e.mem[_t_5 + 1] = _result_11;
        e.mem[_t_5 + 2] = _result_12;
        e.mem[_t_5 + 3] = _result_13;
        e.mem[_t_5 + 4] = _result_14;
        e.mem[_t_5 + 5] = _result_15;
        e.mem[_t_5 + 6] = _result_16;
        e.mem[_t_5 + 7] = _result_17;
        e.mem[_t_5 + 8] = _result_18;
        e.mem[_t_5 + 9] = _result_19;
        return term_tsk(FID_ROW_OBSERVE, _t_5);
      }
      r0 = _result_10;
      r1 = _result_11;
      r2 = _result_12;
      r3 = _result_13;
      r4 = _result_14;
      r5 = _result_15;
      r6 = _result_16;
      r7 = _result_17;
      r8 = _result_18;
      r9 = _result_19;
      WL_JMP(FID_ROW_OBSERVE);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOOKUP_PRINT_K241)
  {
    WL_POPN(9);
    Term _result_20 = STK(0);
    Term _result_21 = STK(1);
    Term _result_22 = STK(2);
    Term _result_23 = STK(3);
    Term _result_24 = STK(4);
    Term _result_25 = STK(5);
    u32 _result_26 = STK(6);
    Term _result_27 = STK(7);
    u32 _result_28 = STK(8);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(10));
    e.mem[_nd_0 + 0] = _result_20;
    e.mem[_nd_0 + 1] = _result_21;
    e.mem[_nd_0 + 2] = _result_22;
    e.mem[_nd_0 + 3] = _result_23;
    e.mem[_nd_0 + 4] = _result_24;
    e.mem[_nd_0 + 5] = _result_25;
    e.mem[_nd_0 + 6] = _result_26;
    e.mem[_nd_0 + 7] = _result_27;
    e.mem[_nd_0 + 8] = _result_28;
    e.mem[_nd_0 + 9] = _h_0;
    r0 = term_clo(FID_LOOKUP_PRINT_C242, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOOKUP_PRINT_C242)
  {
    Term _result_29 = r0;
    Term _result_30 = r1;
    Term _result_31 = r2;
    Term _result_32 = r3;
    Term _result_33 = r4;
    Term _result_34 = r5;
    u32 _result_35 = r6;
    Term _result_36 = r7;
    u32 _result_37 = r8;
    Term _h_1 = r9;
    Term _x_0 = r10;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = _h_1;
    u64 _nd_2 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_2 + 0] = _result_29;
    e.mem[_nd_2 + 1] = _result_30;
    e.mem[_nd_2 + 2] = _result_31;
    e.mem[_nd_2 + 3] = _result_32;
    e.mem[_nd_2 + 4] = _result_33;
    e.mem[_nd_2 + 5] = _result_34;
    e.mem[_nd_2 + 6] = _result_35;
    e.mem[_nd_2 + 7] = _result_36;
    e.mem[_nd_2 + 8] = _result_37;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_3 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_clo(FID_IO_PRINT, _nd_1);
      e.mem[_t_3 + 1] = term_clo(FID_LOOKUP_PRINT_C243, _nd_2);
      e.mem[_t_3 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_3);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_1);
    r1 = term_clo(FID_LOOKUP_PRINT_C243, _nd_2);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOOKUP_PRINT_C243)
  {
    Term _result_38 = r0;
    Term _result_39 = r1;
    Term _result_40 = r2;
    Term _result_41 = r3;
    Term _result_42 = r4;
    Term _result_43 = r5;
    u32 _result_44 = r6;
    Term _result_45 = r7;
    u32 _result_46 = r8;
    Term _x_1 = r9;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_3 + 0] = _result_38;
    e.mem[_nd_3 + 1] = _result_39;
    e.mem[_nd_3 + 2] = _result_40;
    e.mem[_nd_3 + 3] = _result_41;
    e.mem[_nd_3 + 4] = _result_42;
    e.mem[_nd_3 + 5] = _result_43;
    e.mem[_nd_3 + 6] = _result_44;
    e.mem[_nd_3 + 7] = _result_45;
    e.mem[_nd_3 + 8] = _result_46;
    r0 = term_clo(FID_LOOKUP_PRINT_C244, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOOKUP_PRINT_C244)
  {
    Term _result_47 = r0;
    Term _result_48 = r1;
    Term _result_49 = r2;
    Term _result_50 = r3;
    Term _result_51 = r4;
    Term _result_52 = r5;
    u32 _result_53 = r6;
    Term _result_54 = r7;
    u32 _result_55 = r8;
    Term _x_2 = r9;
    WL_OPEN
    u64 _nd_4 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_4 + 0] = rfc_seal(e, _result_47);
    e.mem[_nd_4 + 1] = rfc_seal(e, _result_48);
    e.mem[_nd_4 + 2] = rfc_seal(e, _result_49);
    e.mem[_nd_4 + 3] = rfc_seal(e, _result_50);
    e.mem[_nd_4 + 4] = rfc_seal(e, _result_51);
    e.mem[_nd_4 + 5] = rfc_seal(e, _result_52);
    e.mem[_nd_4 + 6] = rfc_seal(e, _result_53);
    e.mem[_nd_4 + 7] = rfc_seal(e, _result_54);
    e.mem[_nd_4 + 8] = rfc_seal(e, _result_55);
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_2 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = term_ctr(CID_STORAGE_ROWS, _nd_4);
      e.mem[_t_2 + 1] = _x_2;
      return term_tsk(FID_IO_PURE, _t_2);
    }
    r0 = term_ctr(CID_STORAGE_ROWS, _nd_4);
    r1 = _x_2;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOOKUP_PRINT_K245)
  {
    WL_POPN(10);
    Term _prefix_1 = STK(0);
    Term _result_56 = STK(1);
    Term _result_57 = STK(2);
    Term _result_58 = STK(3);
    Term _result_59 = STK(4);
    Term _result_60 = STK(5);
    Term _result_61 = STK(6);
    u32 _result_62 = STK(7);
    Term _result_63 = STK(8);
    u32 _result_64 = STK(9);
    u32 _h_2 = r0;
    u32 _h_3 = r1;
    Term _h_4 = r2;
    u32 _h_5 = r3;
    u32 _h_6 = r4;
    Term _h_7 = r5;
    u32 _h_8 = r6;
    u32 _h_9 = r7;
    u32 _h_10 = r8;
    u32 _h_11 = r9;
    Term _h_12 = r10;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _result_56;
      STK(1) = _result_57;
      STK(2) = _result_58;
      STK(3) = _result_59;
      STK(4) = _result_60;
      STK(5) = _result_61;
      STK(6) = _result_62;
      STK(7) = _result_63;
      STK(8) = _result_64;
      STK(9) = _h_2;
      STK(10) = _h_3;
      STK(11) = _h_4;
      STK(12) = _h_5;
      STK(13) = _h_6;
      STK(14) = _h_7;
      STK(15) = _h_8;
      STK(16) = _h_9;
      STK(17) = _h_10;
      STK(18) = _h_11;
      STK(19) = FID_LOOKUP_PRINT_K246;
      WL_PUSHN(20);
    } else {
      u64 _t_6 = task_node(e, FID_LOOKUP_PRINT_K246, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _result_56;
      e.mem[_t_6 + 1] = _result_57;
      e.mem[_t_6 + 2] = _result_58;
      e.mem[_t_6 + 3] = _result_59;
      e.mem[_t_6 + 4] = _result_60;
      e.mem[_t_6 + 5] = _result_61;
      e.mem[_t_6 + 6] = _result_62;
      e.mem[_t_6 + 7] = _result_63;
      e.mem[_t_6 + 8] = _result_64;
      e.mem[_t_6 + 9] = _h_2;
      e.mem[_t_6 + 10] = _h_3;
      e.mem[_t_6 + 11] = _h_4;
      e.mem[_t_6 + 12] = _h_5;
      e.mem[_t_6 + 13] = _h_6;
      e.mem[_t_6 + 14] = _h_7;
      e.mem[_t_6 + 15] = _h_8;
      e.mem[_t_6 + 16] = _h_9;
      e.mem[_t_6 + 17] = _h_10;
      e.mem[_t_6 + 18] = _h_11;
      WL_CONT = term_tsk(FID_LOOKUP_PRINT_K246, _t_6);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _prefix_1;
      e.mem[_t_7 + 1] = _h_12;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _prefix_1;
    r1 = _h_12;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOOKUP_PRINT_K246)
  {
    WL_POPN(19);
    Term _result_65 = STK(0);
    Term _result_66 = STK(1);
    Term _result_67 = STK(2);
    Term _result_68 = STK(3);
    Term _result_69 = STK(4);
    Term _result_70 = STK(5);
    u32 _result_71 = STK(6);
    Term _result_72 = STK(7);
    u32 _result_73 = STK(8);
    u32 _h_14 = STK(9);
    u32 _h_15 = STK(10);
    Term _h_16 = STK(11);
    u32 _h_17 = STK(12);
    u32 _h_18 = STK(13);
    Term _h_19 = STK(14);
    u32 _h_20 = STK(15);
    u32 _h_21 = STK(16);
    u32 _h_22 = STK(17);
    u32 _h_23 = STK(18);
    Term _h_13 = r0;
    WL_OPEN
    u64 _nd_5 = heap_alloc(e, cls_fit(20));
    e.mem[_nd_5 + 0] = _result_65;
    e.mem[_nd_5 + 1] = _result_66;
    e.mem[_nd_5 + 2] = _result_67;
    e.mem[_nd_5 + 3] = _result_68;
    e.mem[_nd_5 + 4] = _result_69;
    e.mem[_nd_5 + 5] = _result_70;
    e.mem[_nd_5 + 6] = _result_71;
    e.mem[_nd_5 + 7] = _result_72;
    e.mem[_nd_5 + 8] = _result_73;
    e.mem[_nd_5 + 9] = _h_14;
    e.mem[_nd_5 + 10] = _h_15;
    e.mem[_nd_5 + 11] = _h_16;
    e.mem[_nd_5 + 12] = _h_17;
    e.mem[_nd_5 + 13] = _h_18;
    e.mem[_nd_5 + 14] = _h_19;
    e.mem[_nd_5 + 15] = _h_20;
    e.mem[_nd_5 + 16] = _h_21;
    e.mem[_nd_5 + 17] = _h_22;
    e.mem[_nd_5 + 18] = _h_23;
    e.mem[_nd_5 + 19] = _h_13;
    r0 = term_clo(FID_LOOKUP_PRINT_C247, _nd_5);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOOKUP_PRINT_C247)
  {
    Term _result_74 = r0;
    Term _result_75 = r1;
    Term _result_76 = r2;
    Term _result_77 = r3;
    Term _result_78 = r4;
    Term _result_79 = r5;
    u32 _result_80 = r6;
    Term _result_81 = r7;
    u32 _result_82 = r8;
    u32 _h_24 = r9;
    u32 _h_25 = r10;
    Term _h_26 = r11;
    u32 _h_27 = r12;
    u32 _h_28 = r13;
    Term _h_29 = r14;
    u32 _h_30 = r15;
    u32 _h_31 = r16;
    u32 _h_32 = r17;
    u32 _h_33 = r18;
    Term _h_34 = r19;
    Term _x_3 = r20;
    WL_OPEN
    u64 _nd_6 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_6 + 0] = _h_34;
    u64 _nd_7 = heap_alloc(e, cls_fit(19));
    e.mem[_nd_7 + 0] = _result_74;
    e.mem[_nd_7 + 1] = _result_75;
    e.mem[_nd_7 + 2] = _result_76;
    e.mem[_nd_7 + 3] = _result_77;
    e.mem[_nd_7 + 4] = _result_78;
    e.mem[_nd_7 + 5] = _result_79;
    e.mem[_nd_7 + 6] = _result_80;
    e.mem[_nd_7 + 7] = _result_81;
    e.mem[_nd_7 + 8] = _result_82;
    e.mem[_nd_7 + 9] = _h_24;
    e.mem[_nd_7 + 10] = _h_25;
    e.mem[_nd_7 + 11] = _h_26;
    e.mem[_nd_7 + 12] = _h_27;
    e.mem[_nd_7 + 13] = _h_28;
    e.mem[_nd_7 + 14] = _h_29;
    e.mem[_nd_7 + 15] = _h_30;
    e.mem[_nd_7 + 16] = _h_31;
    e.mem[_nd_7 + 17] = _h_32;
    e.mem[_nd_7 + 18] = _h_33;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_9 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = term_clo(FID_IO_PRINT, _nd_6);
      e.mem[_t_9 + 1] = term_clo(FID_LOOKUP_PRINT_C248, _nd_7);
      e.mem[_t_9 + 2] = _x_3;
      return term_tsk(FID_IO_BIND, _t_9);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_6);
    r1 = term_clo(FID_LOOKUP_PRINT_C248, _nd_7);
    r2 = _x_3;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOOKUP_PRINT_C248)
  {
    Term _result_83 = r0;
    Term _result_84 = r1;
    Term _result_85 = r2;
    Term _result_86 = r3;
    Term _result_87 = r4;
    Term _result_88 = r5;
    u32 _result_89 = r6;
    Term _result_90 = r7;
    u32 _result_91 = r8;
    u32 _h_35 = r9;
    u32 _h_36 = r10;
    Term _h_37 = r11;
    u32 _h_38 = r12;
    u32 _h_39 = r13;
    Term _h_40 = r14;
    u32 _h_41 = r15;
    u32 _h_42 = r16;
    u32 _h_43 = r17;
    u32 _h_44 = r18;
    Term _x_4 = r19;
    WL_OPEN
    u64 _nd_8 = heap_alloc(e, cls_fit(19));
    e.mem[_nd_8 + 0] = _result_83;
    e.mem[_nd_8 + 1] = _result_84;
    e.mem[_nd_8 + 2] = _result_85;
    e.mem[_nd_8 + 3] = _result_86;
    e.mem[_nd_8 + 4] = _result_87;
    e.mem[_nd_8 + 5] = _result_88;
    e.mem[_nd_8 + 6] = _result_89;
    e.mem[_nd_8 + 7] = _result_90;
    e.mem[_nd_8 + 8] = _result_91;
    e.mem[_nd_8 + 9] = _h_35;
    e.mem[_nd_8 + 10] = _h_36;
    e.mem[_nd_8 + 11] = _h_37;
    e.mem[_nd_8 + 12] = _h_38;
    e.mem[_nd_8 + 13] = _h_39;
    e.mem[_nd_8 + 14] = _h_40;
    e.mem[_nd_8 + 15] = _h_41;
    e.mem[_nd_8 + 16] = _h_42;
    e.mem[_nd_8 + 17] = _h_43;
    e.mem[_nd_8 + 18] = _h_44;
    r0 = term_clo(FID_LOOKUP_PRINT_C249, _nd_8);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOOKUP_PRINT_C249)
  {
    Term _result_92 = r0;
    Term _result_93 = r1;
    Term _result_94 = r2;
    Term _result_95 = r3;
    Term _result_96 = r4;
    Term _result_97 = r5;
    u32 _result_98 = r6;
    Term _result_99 = r7;
    u32 _result_100 = r8;
    u32 _h_45 = r9;
    u32 _h_46 = r10;
    Term _h_47 = r11;
    u32 _h_48 = r12;
    u32 _h_49 = r13;
    Term _h_50 = r14;
    u32 _h_51 = r15;
    u32 _h_52 = r16;
    u32 _h_53 = r17;
    u32 _h_54 = r18;
    Term _x_5 = r19;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    u32 _o_0 = 0;
    Term _o_1 = 0;
    if (_h_46 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      u64 _nd_9 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_9 + 0] = rfc_seal(e, _h_47);
      e.mem[_nd_9 + 1] = rfc_seal(e, _h_48);
      _o_1 = term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_9);
    }
    u32 _o_2 = 0;
    Term _o_3 = 0;
    if (_h_49 == 0) {
      _o_2 = 0;
    } else {
      _o_2 = 1;
      u64 _nd_10 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_10 + 0] = rfc_seal(e, _h_50);
      e.mem[_nd_10 + 1] = rfc_seal(e, _h_51);
      _o_3 = term_ctr(CID____OWNED_INDEX_CORE_HEALTH, _nd_10);
    }
    u32 _o_4 = 0;
    Term _o_5 = 0;
    if (_h_52 == 0) {
      _o_4 = 0;
    } else {
      _o_4 = 1;
      _o_5 = term_pak(CID_UNIT, 0);
    }
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    Term _o_6[9];
    if (spin_32(e, _o_6, _result_92, blk_loc(e.mem, _result_92), _result_93, blk_loc(e.mem, _result_93), _result_94, blk_loc(e.mem, _result_94), _result_95, blk_loc(e.mem, _result_95), _result_96, blk_loc(e.mem, _result_96), _result_97, blk_loc(e.mem, _result_97), _result_98, _result_99, _result_100, _h_45, _o_0, _o_1, blk_loc(e.mem, _o_1), _o_2, _o_3, blk_loc(e.mem, _o_3), _o_4, _o_5, blk_loc(e.mem, _o_5), _h_53, _h_54) == 0) {
      return 0;
    }
    _v_9 = _o_6[0];
    _v_10 = _o_6[1];
    _v_11 = _o_6[2];
    _v_12 = _o_6[3];
    _v_13 = _o_6[4];
    _v_14 = _o_6[5];
    _v_15 = _o_6[6];
    _v_16 = _o_6[7];
    _v_17 = _o_6[8];
    _v_0 = _v_9;
    _v_1 = _v_10;
    _v_2 = _v_11;
    _v_3 = _v_12;
    _v_4 = _v_13;
    _v_5 = _v_14;
    _v_6 = _v_15;
    _v_7 = _v_16;
    _v_8 = _v_17;
    u64 _nd_11 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_11 + 0] = rfc_seal(e, _v_0);
    e.mem[_nd_11 + 1] = rfc_seal(e, _v_1);
    e.mem[_nd_11 + 2] = rfc_seal(e, _v_2);
    e.mem[_nd_11 + 3] = rfc_seal(e, _v_3);
    e.mem[_nd_11 + 4] = rfc_seal(e, _v_4);
    e.mem[_nd_11 + 5] = rfc_seal(e, _v_5);
    e.mem[_nd_11 + 6] = rfc_seal(e, _v_6);
    e.mem[_nd_11 + 7] = rfc_seal(e, _v_7);
    e.mem[_nd_11 + 8] = rfc_seal(e, _v_8);
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_8 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = term_ctr(CID_STORAGE_ROWS, _nd_11);
      e.mem[_t_8 + 1] = _x_5;
      return term_tsk(FID_IO_PURE, _t_8);
    }
    r0 = term_ctr(CID_STORAGE_ROWS, _nd_11);
    r1 = _x_5;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_METADATA_PRINT)
  {
    Term _rows_0 = r0;
    Term _rows_1 = r1;
    Term _rows_2 = r2;
    Term _rows_3 = r3;
    Term _rows_4 = r4;
    Term _rows_5 = r5;
    u32 _rows_6 = r6;
    Term _rows_7 = r7;
    u32 _rows_8 = r8;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _rows_0;
      STK(1) = _rows_1;
      STK(2) = _rows_2;
      STK(3) = _rows_3;
      STK(4) = _rows_4;
      STK(5) = _rows_5;
      STK(6) = _rows_6;
      STK(7) = _rows_7;
      STK(8) = _rows_8;
      STK(9) = FID_METADATA_PRINT_K251;
      WL_PUSHN(10);
    } else {
      u64 _t_0 = task_node(e, FID_METADATA_PRINT_K251, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _rows_0;
      e.mem[_t_0 + 1] = _rows_1;
      e.mem[_t_0 + 2] = _rows_2;
      e.mem[_t_0 + 3] = _rows_3;
      e.mem[_t_0 + 4] = _rows_4;
      e.mem[_t_0 + 5] = _rows_5;
      e.mem[_t_0 + 6] = _rows_6;
      e.mem[_t_0 + 7] = _rows_7;
      e.mem[_t_0 + 8] = _rows_8;
      WL_CONT = term_tsk(FID_METADATA_PRINT_K251, _t_0);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _rows_6;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _rows_6;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_METADATA_PRINT_K251)
  {
    WL_POPN(9);
    Term _rows_9 = STK(0);
    Term _rows_10 = STK(1);
    Term _rows_11 = STK(2);
    Term _rows_12 = STK(3);
    Term _rows_13 = STK(4);
    Term _rows_14 = STK(5);
    u32 _rows_15 = STK(6);
    Term _rows_16 = STK(7);
    u32 _rows_17 = STK(8);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _rows_9;
      STK(1) = _rows_10;
      STK(2) = _rows_11;
      STK(3) = _rows_12;
      STK(4) = _rows_13;
      STK(5) = _rows_14;
      STK(6) = _rows_15;
      STK(7) = _rows_16;
      STK(8) = _rows_17;
      STK(9) = _h_0;
      STK(10) = FID_METADATA_PRINT_K252;
      WL_PUSHN(11);
    } else {
      u64 _t_2 = task_node(e, FID_METADATA_PRINT_K252, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _rows_9;
      e.mem[_t_2 + 1] = _rows_10;
      e.mem[_t_2 + 2] = _rows_11;
      e.mem[_t_2 + 3] = _rows_12;
      e.mem[_t_2 + 4] = _rows_13;
      e.mem[_t_2 + 5] = _rows_14;
      e.mem[_t_2 + 6] = _rows_15;
      e.mem[_t_2 + 7] = _rows_16;
      e.mem[_t_2 + 8] = _rows_17;
      e.mem[_t_2 + 9] = _h_0;
      WL_CONT = term_tsk(FID_METADATA_PRINT_K252, _t_2);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_NAT_SHOW)) {
      u64 _t_3 = task_node(e, FID_NAT_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _rows_16;
      return term_tsk(FID_NAT_SHOW, _t_3);
    }
    r0 = _rows_16;
    WL_JMP(FID_NAT_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_METADATA_PRINT_K252)
  {
    WL_POPN(10);
    Term _rows_18 = STK(0);
    Term _rows_19 = STK(1);
    Term _rows_20 = STK(2);
    Term _rows_21 = STK(3);
    Term _rows_22 = STK(4);
    Term _rows_23 = STK(5);
    u32 _rows_24 = STK(6);
    Term _rows_25 = STK(7);
    u32 _rows_26 = STK(8);
    Term _h_2 = STK(9);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _rows_18;
      STK(1) = _rows_19;
      STK(2) = _rows_20;
      STK(3) = _rows_21;
      STK(4) = _rows_22;
      STK(5) = _rows_23;
      STK(6) = _rows_24;
      STK(7) = _rows_25;
      STK(8) = _rows_26;
      STK(9) = _h_2;
      STK(10) = _h_1;
      STK(11) = FID_METADATA_PRINT_K253;
      WL_PUSHN(12);
    } else {
      u64 _t_4 = task_node(e, FID_METADATA_PRINT_K253, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _rows_18;
      e.mem[_t_4 + 1] = _rows_19;
      e.mem[_t_4 + 2] = _rows_20;
      e.mem[_t_4 + 3] = _rows_21;
      e.mem[_t_4 + 4] = _rows_22;
      e.mem[_t_4 + 5] = _rows_23;
      e.mem[_t_4 + 6] = _rows_24;
      e.mem[_t_4 + 7] = _rows_25;
      e.mem[_t_4 + 8] = _rows_26;
      e.mem[_t_4 + 9] = _h_2;
      e.mem[_t_4 + 10] = _h_1;
      WL_CONT = term_tsk(FID_METADATA_PRINT_K253, _t_4);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_5 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _rows_26;
      return term_tsk(FID_U32_SHOW, _t_5);
    }
    r0 = _rows_26;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_METADATA_PRINT_K253)
  {
    WL_POPN(11);
    Term _rows_27 = STK(0);
    Term _rows_28 = STK(1);
    Term _rows_29 = STK(2);
    Term _rows_30 = STK(3);
    Term _rows_31 = STK(4);
    Term _rows_32 = STK(5);
    u32 _rows_33 = STK(6);
    Term _rows_34 = STK(7);
    u32 _rows_35 = STK(8);
    Term _h_4 = STK(9);
    Term _h_5 = STK(10);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _rows_27;
      STK(1) = _rows_28;
      STK(2) = _rows_29;
      STK(3) = _rows_30;
      STK(4) = _rows_31;
      STK(5) = _rows_32;
      STK(6) = _rows_33;
      STK(7) = _rows_34;
      STK(8) = _rows_35;
      STK(9) = _h_4;
      STK(10) = _h_5;
      STK(11) = FID_METADATA_PRINT_K254;
      WL_PUSHN(12);
    } else {
      u64 _t_6 = task_node(e, FID_METADATA_PRINT_K254, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _rows_27;
      e.mem[_t_6 + 1] = _rows_28;
      e.mem[_t_6 + 2] = _rows_29;
      e.mem[_t_6 + 3] = _rows_30;
      e.mem[_t_6 + 4] = _rows_31;
      e.mem[_t_6 + 5] = _rows_32;
      e.mem[_t_6 + 6] = _rows_33;
      e.mem[_t_6 + 7] = _rows_34;
      e.mem[_t_6 + 8] = _rows_35;
      e.mem[_t_6 + 9] = _h_4;
      e.mem[_t_6 + 10] = _h_5;
      WL_CONT = term_tsk(FID_METADATA_PRINT_K254, _t_6);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 2);
      e.mem[_t_7 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 2);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_METADATA_PRINT_K254)
  {
    WL_POPN(11);
    Term _rows_36 = STK(0);
    Term _rows_37 = STK(1);
    Term _rows_38 = STK(2);
    Term _rows_39 = STK(3);
    Term _rows_40 = STK(4);
    Term _rows_41 = STK(5);
    u32 _rows_42 = STK(6);
    Term _rows_43 = STK(7);
    u32 _rows_44 = STK(8);
    Term _h_7 = STK(9);
    Term _h_8 = STK(10);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _rows_36;
      STK(1) = _rows_37;
      STK(2) = _rows_38;
      STK(3) = _rows_39;
      STK(4) = _rows_40;
      STK(5) = _rows_41;
      STK(6) = _rows_42;
      STK(7) = _rows_43;
      STK(8) = _rows_44;
      STK(9) = _h_7;
      STK(10) = FID_METADATA_PRINT_K255;
      WL_PUSHN(11);
    } else {
      u64 _t_8 = task_node(e, FID_METADATA_PRINT_K255, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _rows_36;
      e.mem[_t_8 + 1] = _rows_37;
      e.mem[_t_8 + 2] = _rows_38;
      e.mem[_t_8 + 3] = _rows_39;
      e.mem[_t_8 + 4] = _rows_40;
      e.mem[_t_8 + 5] = _rows_41;
      e.mem[_t_8 + 6] = _rows_42;
      e.mem[_t_8 + 7] = _rows_43;
      e.mem[_t_8 + 8] = _rows_44;
      e.mem[_t_8 + 9] = _h_7;
      WL_CONT = term_tsk(FID_METADATA_PRINT_K255, _t_8);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_8;
      e.mem[_t_9 + 1] = _h_6;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _h_8;
    r1 = _h_6;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_METADATA_PRINT_K255)
  {
    WL_POPN(10);
    Term _rows_45 = STK(0);
    Term _rows_46 = STK(1);
    Term _rows_47 = STK(2);
    Term _rows_48 = STK(3);
    Term _rows_49 = STK(4);
    Term _rows_50 = STK(5);
    u32 _rows_51 = STK(6);
    Term _rows_52 = STK(7);
    u32 _rows_53 = STK(8);
    Term _h_10 = STK(9);
    Term _h_9 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _rows_45;
      STK(1) = _rows_46;
      STK(2) = _rows_47;
      STK(3) = _rows_48;
      STK(4) = _rows_49;
      STK(5) = _rows_50;
      STK(6) = _rows_51;
      STK(7) = _rows_52;
      STK(8) = _rows_53;
      STK(9) = _h_10;
      STK(10) = FID_METADATA_PRINT_K256;
      WL_PUSHN(11);
    } else {
      u64 _t_10 = task_node(e, FID_METADATA_PRINT_K256, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _rows_45;
      e.mem[_t_10 + 1] = _rows_46;
      e.mem[_t_10 + 2] = _rows_47;
      e.mem[_t_10 + 3] = _rows_48;
      e.mem[_t_10 + 4] = _rows_49;
      e.mem[_t_10 + 5] = _rows_50;
      e.mem[_t_10 + 6] = _rows_51;
      e.mem[_t_10 + 7] = _rows_52;
      e.mem[_t_10 + 8] = _rows_53;
      e.mem[_t_10 + 9] = _h_10;
      WL_CONT = term_tsk(FID_METADATA_PRINT_K256, _t_10);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 2);
      e.mem[_t_11 + 1] = _h_9;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 2);
    r1 = _h_9;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_METADATA_PRINT_K256)
  {
    WL_POPN(10);
    Term _rows_54 = STK(0);
    Term _rows_55 = STK(1);
    Term _rows_56 = STK(2);
    Term _rows_57 = STK(3);
    Term _rows_58 = STK(4);
    Term _rows_59 = STK(5);
    u32 _rows_60 = STK(6);
    Term _rows_61 = STK(7);
    u32 _rows_62 = STK(8);
    Term _h_12 = STK(9);
    Term _h_11 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _rows_54;
      STK(1) = _rows_55;
      STK(2) = _rows_56;
      STK(3) = _rows_57;
      STK(4) = _rows_58;
      STK(5) = _rows_59;
      STK(6) = _rows_60;
      STK(7) = _rows_61;
      STK(8) = _rows_62;
      STK(9) = FID_METADATA_PRINT_K257;
      WL_PUSHN(10);
    } else {
      u64 _t_12 = task_node(e, FID_METADATA_PRINT_K257, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _rows_54;
      e.mem[_t_12 + 1] = _rows_55;
      e.mem[_t_12 + 2] = _rows_56;
      e.mem[_t_12 + 3] = _rows_57;
      e.mem[_t_12 + 4] = _rows_58;
      e.mem[_t_12 + 5] = _rows_59;
      e.mem[_t_12 + 6] = _rows_60;
      e.mem[_t_12 + 7] = _rows_61;
      e.mem[_t_12 + 8] = _rows_62;
      WL_CONT = term_tsk(FID_METADATA_PRINT_K257, _t_12);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _h_12;
      e.mem[_t_13 + 1] = _h_11;
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = _h_12;
    r1 = _h_11;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_METADATA_PRINT_K257)
  {
    WL_POPN(9);
    Term _rows_63 = STK(0);
    Term _rows_64 = STK(1);
    Term _rows_65 = STK(2);
    Term _rows_66 = STK(3);
    Term _rows_67 = STK(4);
    Term _rows_68 = STK(5);
    u32 _rows_69 = STK(6);
    Term _rows_70 = STK(7);
    u32 _rows_71 = STK(8);
    Term _h_13 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _rows_63;
      STK(1) = _rows_64;
      STK(2) = _rows_65;
      STK(3) = _rows_66;
      STK(4) = _rows_67;
      STK(5) = _rows_68;
      STK(6) = _rows_69;
      STK(7) = _rows_70;
      STK(8) = _rows_71;
      STK(9) = FID_METADATA_PRINT_K258;
      WL_PUSHN(10);
    } else {
      u64 _t_14 = task_node(e, FID_METADATA_PRINT_K258, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _rows_63;
      e.mem[_t_14 + 1] = _rows_64;
      e.mem[_t_14 + 2] = _rows_65;
      e.mem[_t_14 + 3] = _rows_66;
      e.mem[_t_14 + 4] = _rows_67;
      e.mem[_t_14 + 5] = _rows_68;
      e.mem[_t_14 + 6] = _rows_69;
      e.mem[_t_14 + 7] = _rows_70;
      e.mem[_t_14 + 8] = _rows_71;
      WL_CONT = term_tsk(FID_METADATA_PRINT_K258, _t_14);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_15 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = term_ctr(CID_SCON, STAT_OFF + 122);
      e.mem[_t_15 + 1] = _h_13;
      return term_tsk(FID_STRING_APPEND, _t_15);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 122);
    r1 = _h_13;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_METADATA_PRINT_K258)
  {
    WL_POPN(9);
    Term _rows_72 = STK(0);
    Term _rows_73 = STK(1);
    Term _rows_74 = STK(2);
    Term _rows_75 = STK(3);
    Term _rows_76 = STK(4);
    Term _rows_77 = STK(5);
    u32 _rows_78 = STK(6);
    Term _rows_79 = STK(7);
    u32 _rows_80 = STK(8);
    Term _h_14 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(10));
    e.mem[_nd_0 + 0] = _rows_72;
    e.mem[_nd_0 + 1] = _rows_73;
    e.mem[_nd_0 + 2] = _rows_74;
    e.mem[_nd_0 + 3] = _rows_75;
    e.mem[_nd_0 + 4] = _rows_76;
    e.mem[_nd_0 + 5] = _rows_77;
    e.mem[_nd_0 + 6] = _rows_78;
    e.mem[_nd_0 + 7] = _rows_79;
    e.mem[_nd_0 + 8] = _rows_80;
    e.mem[_nd_0 + 9] = _h_14;
    r0 = term_clo(FID_METADATA_PRINT_C259, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_METADATA_PRINT_C259)
  {
    Term _rows_81 = r0;
    Term _rows_82 = r1;
    Term _rows_83 = r2;
    Term _rows_84 = r3;
    Term _rows_85 = r4;
    Term _rows_86 = r5;
    u32 _rows_87 = r6;
    Term _rows_88 = r7;
    u32 _rows_89 = r8;
    Term _h_15 = r9;
    Term _x_0 = r10;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = _h_15;
    u64 _nd_2 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_2 + 0] = _rows_81;
    e.mem[_nd_2 + 1] = _rows_82;
    e.mem[_nd_2 + 2] = _rows_83;
    e.mem[_nd_2 + 3] = _rows_84;
    e.mem[_nd_2 + 4] = _rows_85;
    e.mem[_nd_2 + 5] = _rows_86;
    e.mem[_nd_2 + 6] = _rows_87;
    e.mem[_nd_2 + 7] = _rows_88;
    e.mem[_nd_2 + 8] = _rows_89;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_17 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = term_clo(FID_IO_PRINT, _nd_1);
      e.mem[_t_17 + 1] = term_clo(FID_METADATA_PRINT_C260, _nd_2);
      e.mem[_t_17 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_17);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_1);
    r1 = term_clo(FID_METADATA_PRINT_C260, _nd_2);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_METADATA_PRINT_C260)
  {
    Term _rows_90 = r0;
    Term _rows_91 = r1;
    Term _rows_92 = r2;
    Term _rows_93 = r3;
    Term _rows_94 = r4;
    Term _rows_95 = r5;
    u32 _rows_96 = r6;
    Term _rows_97 = r7;
    u32 _rows_98 = r8;
    Term _x_1 = r9;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_3 + 0] = _rows_90;
    e.mem[_nd_3 + 1] = _rows_91;
    e.mem[_nd_3 + 2] = _rows_92;
    e.mem[_nd_3 + 3] = _rows_93;
    e.mem[_nd_3 + 4] = _rows_94;
    e.mem[_nd_3 + 5] = _rows_95;
    e.mem[_nd_3 + 6] = _rows_96;
    e.mem[_nd_3 + 7] = _rows_97;
    e.mem[_nd_3 + 8] = _rows_98;
    r0 = term_clo(FID_METADATA_PRINT_C261, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_METADATA_PRINT_C261)
  {
    Term _rows_99 = r0;
    Term _rows_100 = r1;
    Term _rows_101 = r2;
    Term _rows_102 = r3;
    Term _rows_103 = r4;
    Term _rows_104 = r5;
    u32 _rows_105 = r6;
    Term _rows_106 = r7;
    u32 _rows_107 = r8;
    Term _x_2 = r9;
    WL_OPEN
    u64 _nd_4 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_4 + 0] = rfc_seal(e, _rows_99);
    e.mem[_nd_4 + 1] = rfc_seal(e, _rows_100);
    e.mem[_nd_4 + 2] = rfc_seal(e, _rows_101);
    e.mem[_nd_4 + 3] = rfc_seal(e, _rows_102);
    e.mem[_nd_4 + 4] = rfc_seal(e, _rows_103);
    e.mem[_nd_4 + 5] = rfc_seal(e, _rows_104);
    e.mem[_nd_4 + 6] = rfc_seal(e, _rows_105);
    e.mem[_nd_4 + 7] = rfc_seal(e, _rows_106);
    e.mem[_nd_4 + 8] = rfc_seal(e, _rows_107);
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_16 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_16 + 0] = term_ctr(CID_STORAGE_ROWS, _nd_4);
      e.mem[_t_16 + 1] = _x_2;
      return term_tsk(FID_IO_PURE, _t_16);
    }
    r0 = term_ctr(CID_STORAGE_ROWS, _nd_4);
    r1 = _x_2;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_ROWS_PLACE)
  {
    Term _rows_0 = r0;
    Term _rows_1 = r1;
    Term _rows_2 = r2;
    Term _rows_3 = r3;
    Term _rows_4 = r4;
    Term _rows_5 = r5;
    u32 _rows_6 = r6;
    Term _rows_7 = r7;
    u32 _rows_8 = r8;
    u32 _row_0 = r9;
    u32 _row_1 = r10;
    Term _row_2 = r11;
    u32 _row_3 = r12;
    Term _row_4 = r13;
    u32 _row_5 = r14;
    Term _row_6 = r15;
    u32 _row_7 = r16;
    u32 _row_8 = r17;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _o_0[1];
    if (spin_23(e, _o_0, U32_BIN(0ull, <, _row_0), U32_BIN(_row_0, <=, 131072ull)) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (_v_0 == 0) {
      r0 = 1;
      r1 = _rows_0;
      r2 = _rows_1;
      r3 = _rows_2;
      r4 = _rows_3;
      r5 = _rows_4;
      r6 = _rows_5;
      r7 = _rows_6;
      r8 = _rows_7;
      r9 = _rows_8;
      r10 = _row_0;
      r11 = _row_1;
      r12 = _row_2;
      r13 = _row_3;
      r14 = _row_4;
      r15 = _row_5;
      r16 = _row_6;
      r17 = _row_7;
      r18 = _row_8;
      WL_RETN(19);
    } else {
      if (seq) {
        WL_ROOM(10);
        STK(0) = _row_0;
        STK(1) = _row_1;
        STK(2) = _row_2;
        STK(3) = _row_3;
        STK(4) = _row_4;
        STK(5) = _row_5;
        STK(6) = _row_6;
        STK(7) = _row_7;
        STK(8) = _row_8;
        STK(9) = FID_STORAGE_ROWS_PLACE_K265;
        WL_PUSHN(10);
      } else {
        u64 _t_0 = task_node(e, FID_STORAGE_ROWS_PLACE_K265, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _row_0;
        e.mem[_t_0 + 1] = _row_1;
        e.mem[_t_0 + 2] = _row_2;
        e.mem[_t_0 + 3] = _row_3;
        e.mem[_t_0 + 4] = _row_4;
        e.mem[_t_0 + 5] = _row_5;
        e.mem[_t_0 + 6] = _row_6;
        e.mem[_t_0 + 7] = _row_7;
        e.mem[_t_0 + 8] = _row_8;
        WL_CONT = term_tsk(FID_STORAGE_ROWS_PLACE_K265, _t_0);
        WL_IDX = 9;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STORAGE_GROW)) {
        u64 _t_1 = task_node(e, FID_STORAGE_GROW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = 17ull;
        e.mem[_t_1 + 1] = _row_0;
        e.mem[_t_1 + 2] = _rows_0;
        e.mem[_t_1 + 3] = _rows_1;
        e.mem[_t_1 + 4] = _rows_2;
        e.mem[_t_1 + 5] = _rows_3;
        e.mem[_t_1 + 6] = _rows_4;
        e.mem[_t_1 + 7] = _rows_5;
        e.mem[_t_1 + 8] = _rows_6;
        e.mem[_t_1 + 9] = _rows_7;
        e.mem[_t_1 + 10] = _rows_8;
        return term_tsk(FID_STORAGE_GROW, _t_1);
      }
      r0 = 17ull;
      r1 = _row_0;
      r2 = _rows_0;
      r3 = _rows_1;
      r4 = _rows_2;
      r5 = _rows_3;
      r6 = _rows_4;
      r7 = _rows_5;
      r8 = _rows_6;
      r9 = _rows_7;
      r10 = _rows_8;
      WL_JMP(FID_STORAGE_GROW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STORAGE_ROWS_PLACE_K265)
  {
    WL_POPN(9);
    u32 _row_9 = STK(0);
    u32 _row_10 = STK(1);
    Term _row_11 = STK(2);
    u32 _row_12 = STK(3);
    Term _row_13 = STK(4);
    u32 _row_14 = STK(5);
    Term _row_15 = STK(6);
    u32 _row_16 = STK(7);
    u32 _row_17 = STK(8);
    Term _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    u32 _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    WL_OPEN
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    Term _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    u32 _v_20 = 0;
    Term _o_1[19];
    if (spin_34(e, _o_1, _h_0, blk_loc(e.mem, _h_0), _h_1, blk_loc(e.mem, _h_1), _h_2, blk_loc(e.mem, _h_2), _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, blk_loc(e.mem, _h_5), _h_6, _h_7, _h_8, _row_9, _row_10, _row_11, blk_loc(e.mem, _row_11), _row_12, _row_13, blk_loc(e.mem, _row_13), _row_14, _row_15, blk_loc(e.mem, _row_15), _row_16, _row_17) == 0) {
      return 0;
    }
    _v_2 = _o_1[0];
    _v_3 = _o_1[1];
    _v_4 = _o_1[2];
    _v_5 = _o_1[3];
    _v_6 = _o_1[4];
    _v_7 = _o_1[5];
    _v_8 = _o_1[6];
    _v_9 = _o_1[7];
    _v_10 = _o_1[8];
    _v_11 = _o_1[9];
    _v_12 = _o_1[10];
    _v_13 = _o_1[11];
    _v_14 = _o_1[12];
    _v_15 = _o_1[13];
    _v_16 = _o_1[14];
    _v_17 = _o_1[15];
    _v_18 = _o_1[16];
    _v_19 = _o_1[17];
    _v_20 = _o_1[18];
    r0 = _v_2;
    r1 = _v_3;
    r2 = _v_4;
    r3 = _v_5;
    r4 = _v_6;
    r5 = _v_7;
    r6 = _v_8;
    r7 = _v_9;
    r8 = _v_10;
    r9 = _v_11;
    r10 = _v_12;
    r11 = _v_13;
    r12 = _v_14;
    r13 = _v_15;
    r14 = _v_16;
    r15 = _v_17;
    r16 = _v_18;
    r17 = _v_19;
    r18 = _v_20;
    WL_RETN(19);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_PLACEMENT_PRINT)
  {
    Term _prefix_0 = r0;
    u32 _result_0 = r1;
    Term _result_1 = r2;
    Term _result_2 = r3;
    Term _result_3 = r4;
    Term _result_4 = r5;
    Term _result_5 = r6;
    Term _result_6 = r7;
    u32 _result_7 = r8;
    Term _result_8 = r9;
    u32 _result_9 = r10;
    u32 _result_10 = r11;
    u32 _result_11 = r12;
    Term _result_12 = r13;
    u32 _result_13 = r14;
    u32 _result_14 = r15;
    Term _result_15 = r16;
    u32 _result_16 = r17;
    u32 _result_17 = r18;
    u32 _result_18 = r19;
    u32 _result_19 = r20;
    WL_OPEN
    if (_result_0 == 0) {
      if (seq) {
        WL_ROOM(10);
        STK(0) = _result_1;
        STK(1) = _result_2;
        STK(2) = _result_3;
        STK(3) = _result_4;
        STK(4) = _result_5;
        STK(5) = _result_6;
        STK(6) = _result_7;
        STK(7) = _result_8;
        STK(8) = _result_9;
        STK(9) = FID_PLACEMENT_PRINT_K267;
        WL_PUSHN(10);
      } else {
        u64 _t_0 = task_node(e, FID_PLACEMENT_PRINT_K267, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _result_1;
        e.mem[_t_0 + 1] = _result_2;
        e.mem[_t_0 + 2] = _result_3;
        e.mem[_t_0 + 3] = _result_4;
        e.mem[_t_0 + 4] = _result_5;
        e.mem[_t_0 + 5] = _result_6;
        e.mem[_t_0 + 6] = _result_7;
        e.mem[_t_0 + 7] = _result_8;
        e.mem[_t_0 + 8] = _result_9;
        WL_CONT = term_tsk(FID_PLACEMENT_PRINT_K267, _t_0);
        WL_IDX = 9;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
        u64 _t_1 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _prefix_0;
        e.mem[_t_1 + 1] = term_ctr(CID_SCON, STAT_OFF + 130);
        return term_tsk(FID_STRING_APPEND, _t_1);
      }
      r0 = _prefix_0;
      r1 = term_ctr(CID_SCON, STAT_OFF + 130);
      WL_JMP(FID_STRING_APPEND);
    } else {
      if (seq) {
        WL_ROOM(11);
        STK(0) = _prefix_0;
        STK(1) = _result_1;
        STK(2) = _result_2;
        STK(3) = _result_3;
        STK(4) = _result_4;
        STK(5) = _result_5;
        STK(6) = _result_6;
        STK(7) = _result_7;
        STK(8) = _result_8;
        STK(9) = _result_9;
        STK(10) = FID_PLACEMENT_PRINT_K271;
        WL_PUSHN(11);
      } else {
        u64 _t_4 = task_node(e, FID_PLACEMENT_PRINT_K271, WL_CONT, WL_IDX, 1);
        e.mem[_t_4 + 0] = _prefix_0;
        e.mem[_t_4 + 1] = _result_1;
        e.mem[_t_4 + 2] = _result_2;
        e.mem[_t_4 + 3] = _result_3;
        e.mem[_t_4 + 4] = _result_4;
        e.mem[_t_4 + 5] = _result_5;
        e.mem[_t_4 + 6] = _result_6;
        e.mem[_t_4 + 7] = _result_7;
        e.mem[_t_4 + 8] = _result_8;
        e.mem[_t_4 + 9] = _result_9;
        WL_CONT = term_tsk(FID_PLACEMENT_PRINT_K271, _t_4);
        WL_IDX = 10;
      }
      if (!DEVICE && !seq && fid_nofk(FID_ROW_OBSERVE)) {
        u64 _t_5 = task_node(e, FID_ROW_OBSERVE, WL_CONT, WL_IDX, 0);
        e.mem[_t_5 + 0] = _result_10;
        e.mem[_t_5 + 1] = _result_11;
        e.mem[_t_5 + 2] = _result_12;
        e.mem[_t_5 + 3] = _result_13;
        e.mem[_t_5 + 4] = _result_14;
        e.mem[_t_5 + 5] = _result_15;
        e.mem[_t_5 + 6] = _result_16;
        e.mem[_t_5 + 7] = _result_17;
        e.mem[_t_5 + 8] = _result_18;
        e.mem[_t_5 + 9] = _result_19;
        return term_tsk(FID_ROW_OBSERVE, _t_5);
      }
      r0 = _result_10;
      r1 = _result_11;
      r2 = _result_12;
      r3 = _result_13;
      r4 = _result_14;
      r5 = _result_15;
      r6 = _result_16;
      r7 = _result_17;
      r8 = _result_18;
      r9 = _result_19;
      WL_JMP(FID_ROW_OBSERVE);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_PLACEMENT_PRINT_K267)
  {
    WL_POPN(9);
    Term _result_20 = STK(0);
    Term _result_21 = STK(1);
    Term _result_22 = STK(2);
    Term _result_23 = STK(3);
    Term _result_24 = STK(4);
    Term _result_25 = STK(5);
    u32 _result_26 = STK(6);
    Term _result_27 = STK(7);
    u32 _result_28 = STK(8);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(10));
    e.mem[_nd_0 + 0] = _result_20;
    e.mem[_nd_0 + 1] = _result_21;
    e.mem[_nd_0 + 2] = _result_22;
    e.mem[_nd_0 + 3] = _result_23;
    e.mem[_nd_0 + 4] = _result_24;
    e.mem[_nd_0 + 5] = _result_25;
    e.mem[_nd_0 + 6] = _result_26;
    e.mem[_nd_0 + 7] = _result_27;
    e.mem[_nd_0 + 8] = _result_28;
    e.mem[_nd_0 + 9] = _h_0;
    r0 = term_clo(FID_PLACEMENT_PRINT_C268, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_PLACEMENT_PRINT_C268)
  {
    Term _result_29 = r0;
    Term _result_30 = r1;
    Term _result_31 = r2;
    Term _result_32 = r3;
    Term _result_33 = r4;
    Term _result_34 = r5;
    u32 _result_35 = r6;
    Term _result_36 = r7;
    u32 _result_37 = r8;
    Term _h_1 = r9;
    Term _x_0 = r10;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = _h_1;
    u64 _nd_2 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_2 + 0] = _result_29;
    e.mem[_nd_2 + 1] = _result_30;
    e.mem[_nd_2 + 2] = _result_31;
    e.mem[_nd_2 + 3] = _result_32;
    e.mem[_nd_2 + 4] = _result_33;
    e.mem[_nd_2 + 5] = _result_34;
    e.mem[_nd_2 + 6] = _result_35;
    e.mem[_nd_2 + 7] = _result_36;
    e.mem[_nd_2 + 8] = _result_37;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_3 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_clo(FID_IO_PRINT, _nd_1);
      e.mem[_t_3 + 1] = term_clo(FID_PLACEMENT_PRINT_C269, _nd_2);
      e.mem[_t_3 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_3);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_1);
    r1 = term_clo(FID_PLACEMENT_PRINT_C269, _nd_2);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_PLACEMENT_PRINT_C269)
  {
    Term _result_38 = r0;
    Term _result_39 = r1;
    Term _result_40 = r2;
    Term _result_41 = r3;
    Term _result_42 = r4;
    Term _result_43 = r5;
    u32 _result_44 = r6;
    Term _result_45 = r7;
    u32 _result_46 = r8;
    Term _x_1 = r9;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_3 + 0] = _result_38;
    e.mem[_nd_3 + 1] = _result_39;
    e.mem[_nd_3 + 2] = _result_40;
    e.mem[_nd_3 + 3] = _result_41;
    e.mem[_nd_3 + 4] = _result_42;
    e.mem[_nd_3 + 5] = _result_43;
    e.mem[_nd_3 + 6] = _result_44;
    e.mem[_nd_3 + 7] = _result_45;
    e.mem[_nd_3 + 8] = _result_46;
    r0 = term_clo(FID_PLACEMENT_PRINT_C270, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_PLACEMENT_PRINT_C270)
  {
    Term _result_47 = r0;
    Term _result_48 = r1;
    Term _result_49 = r2;
    Term _result_50 = r3;
    Term _result_51 = r4;
    Term _result_52 = r5;
    u32 _result_53 = r6;
    Term _result_54 = r7;
    u32 _result_55 = r8;
    Term _x_2 = r9;
    WL_OPEN
    u64 _nd_4 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_4 + 0] = rfc_seal(e, _result_47);
    e.mem[_nd_4 + 1] = rfc_seal(e, _result_48);
    e.mem[_nd_4 + 2] = rfc_seal(e, _result_49);
    e.mem[_nd_4 + 3] = rfc_seal(e, _result_50);
    e.mem[_nd_4 + 4] = rfc_seal(e, _result_51);
    e.mem[_nd_4 + 5] = rfc_seal(e, _result_52);
    e.mem[_nd_4 + 6] = rfc_seal(e, _result_53);
    e.mem[_nd_4 + 7] = rfc_seal(e, _result_54);
    e.mem[_nd_4 + 8] = rfc_seal(e, _result_55);
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_2 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = term_ctr(CID_STORAGE_ROWS, _nd_4);
      e.mem[_t_2 + 1] = _x_2;
      return term_tsk(FID_IO_PURE, _t_2);
    }
    r0 = term_ctr(CID_STORAGE_ROWS, _nd_4);
    r1 = _x_2;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_PLACEMENT_PRINT_K271)
  {
    WL_POPN(10);
    Term _prefix_1 = STK(0);
    Term _result_56 = STK(1);
    Term _result_57 = STK(2);
    Term _result_58 = STK(3);
    Term _result_59 = STK(4);
    Term _result_60 = STK(5);
    Term _result_61 = STK(6);
    u32 _result_62 = STK(7);
    Term _result_63 = STK(8);
    u32 _result_64 = STK(9);
    u32 _h_2 = r0;
    u32 _h_3 = r1;
    Term _h_4 = r2;
    u32 _h_5 = r3;
    u32 _h_6 = r4;
    Term _h_7 = r5;
    u32 _h_8 = r6;
    u32 _h_9 = r7;
    u32 _h_10 = r8;
    u32 _h_11 = r9;
    Term _h_12 = r10;
    WL_OPEN
    term_sink(e, _h_4);
    term_sink(e, _h_7);
    if (seq) {
      WL_ROOM(11);
      STK(0) = _prefix_1;
      STK(1) = _result_56;
      STK(2) = _result_57;
      STK(3) = _result_58;
      STK(4) = _result_59;
      STK(5) = _result_60;
      STK(6) = _result_61;
      STK(7) = _result_62;
      STK(8) = _result_63;
      STK(9) = _result_64;
      STK(10) = FID_PLACEMENT_PRINT_K272;
      WL_PUSHN(11);
    } else {
      u64 _t_6 = task_node(e, FID_PLACEMENT_PRINT_K272, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _prefix_1;
      e.mem[_t_6 + 1] = _result_56;
      e.mem[_t_6 + 2] = _result_57;
      e.mem[_t_6 + 3] = _result_58;
      e.mem[_t_6 + 4] = _result_59;
      e.mem[_t_6 + 5] = _result_60;
      e.mem[_t_6 + 6] = _result_61;
      e.mem[_t_6 + 7] = _result_62;
      e.mem[_t_6 + 8] = _result_63;
      e.mem[_t_6 + 9] = _result_64;
      WL_CONT = term_tsk(FID_PLACEMENT_PRINT_K272, _t_6);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 112);
      e.mem[_t_7 + 1] = _h_12;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 112);
    r1 = _h_12;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_PLACEMENT_PRINT_K272)
  {
    WL_POPN(10);
    Term _prefix_2 = STK(0);
    Term _result_65 = STK(1);
    Term _result_66 = STK(2);
    Term _result_67 = STK(3);
    Term _result_68 = STK(4);
    Term _result_69 = STK(5);
    Term _result_70 = STK(6);
    u32 _result_71 = STK(7);
    Term _result_72 = STK(8);
    u32 _result_73 = STK(9);
    Term _h_13 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _result_65;
      STK(1) = _result_66;
      STK(2) = _result_67;
      STK(3) = _result_68;
      STK(4) = _result_69;
      STK(5) = _result_70;
      STK(6) = _result_71;
      STK(7) = _result_72;
      STK(8) = _result_73;
      STK(9) = FID_PLACEMENT_PRINT_K273;
      WL_PUSHN(10);
    } else {
      u64 _t_8 = task_node(e, FID_PLACEMENT_PRINT_K273, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _result_65;
      e.mem[_t_8 + 1] = _result_66;
      e.mem[_t_8 + 2] = _result_67;
      e.mem[_t_8 + 3] = _result_68;
      e.mem[_t_8 + 4] = _result_69;
      e.mem[_t_8 + 5] = _result_70;
      e.mem[_t_8 + 6] = _result_71;
      e.mem[_t_8 + 7] = _result_72;
      e.mem[_t_8 + 8] = _result_73;
      WL_CONT = term_tsk(FID_PLACEMENT_PRINT_K273, _t_8);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _prefix_2;
      e.mem[_t_9 + 1] = _h_13;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _prefix_2;
    r1 = _h_13;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_PLACEMENT_PRINT_K273)
  {
    WL_POPN(9);
    Term _result_74 = STK(0);
    Term _result_75 = STK(1);
    Term _result_76 = STK(2);
    Term _result_77 = STK(3);
    Term _result_78 = STK(4);
    Term _result_79 = STK(5);
    u32 _result_80 = STK(6);
    Term _result_81 = STK(7);
    u32 _result_82 = STK(8);
    Term _h_14 = r0;
    WL_OPEN
    u64 _nd_5 = heap_alloc(e, cls_fit(10));
    e.mem[_nd_5 + 0] = _result_74;
    e.mem[_nd_5 + 1] = _result_75;
    e.mem[_nd_5 + 2] = _result_76;
    e.mem[_nd_5 + 3] = _result_77;
    e.mem[_nd_5 + 4] = _result_78;
    e.mem[_nd_5 + 5] = _result_79;
    e.mem[_nd_5 + 6] = _result_80;
    e.mem[_nd_5 + 7] = _result_81;
    e.mem[_nd_5 + 8] = _result_82;
    e.mem[_nd_5 + 9] = _h_14;
    r0 = term_clo(FID_PLACEMENT_PRINT_C274, _nd_5);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_PLACEMENT_PRINT_C274)
  {
    Term _result_83 = r0;
    Term _result_84 = r1;
    Term _result_85 = r2;
    Term _result_86 = r3;
    Term _result_87 = r4;
    Term _result_88 = r5;
    u32 _result_89 = r6;
    Term _result_90 = r7;
    u32 _result_91 = r8;
    Term _h_15 = r9;
    Term _x_3 = r10;
    WL_OPEN
    u64 _nd_6 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_6 + 0] = _h_15;
    u64 _nd_7 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_7 + 0] = _result_83;
    e.mem[_nd_7 + 1] = _result_84;
    e.mem[_nd_7 + 2] = _result_85;
    e.mem[_nd_7 + 3] = _result_86;
    e.mem[_nd_7 + 4] = _result_87;
    e.mem[_nd_7 + 5] = _result_88;
    e.mem[_nd_7 + 6] = _result_89;
    e.mem[_nd_7 + 7] = _result_90;
    e.mem[_nd_7 + 8] = _result_91;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_11 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_clo(FID_IO_PRINT, _nd_6);
      e.mem[_t_11 + 1] = term_clo(FID_PLACEMENT_PRINT_C275, _nd_7);
      e.mem[_t_11 + 2] = _x_3;
      return term_tsk(FID_IO_BIND, _t_11);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_6);
    r1 = term_clo(FID_PLACEMENT_PRINT_C275, _nd_7);
    r2 = _x_3;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_PLACEMENT_PRINT_C275)
  {
    Term _result_92 = r0;
    Term _result_93 = r1;
    Term _result_94 = r2;
    Term _result_95 = r3;
    Term _result_96 = r4;
    Term _result_97 = r5;
    u32 _result_98 = r6;
    Term _result_99 = r7;
    u32 _result_100 = r8;
    Term _x_4 = r9;
    WL_OPEN
    u64 _nd_8 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_8 + 0] = _result_92;
    e.mem[_nd_8 + 1] = _result_93;
    e.mem[_nd_8 + 2] = _result_94;
    e.mem[_nd_8 + 3] = _result_95;
    e.mem[_nd_8 + 4] = _result_96;
    e.mem[_nd_8 + 5] = _result_97;
    e.mem[_nd_8 + 6] = _result_98;
    e.mem[_nd_8 + 7] = _result_99;
    e.mem[_nd_8 + 8] = _result_100;
    r0 = term_clo(FID_PLACEMENT_PRINT_C276, _nd_8);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_PLACEMENT_PRINT_C276)
  {
    Term _result_101 = r0;
    Term _result_102 = r1;
    Term _result_103 = r2;
    Term _result_104 = r3;
    Term _result_105 = r4;
    Term _result_106 = r5;
    u32 _result_107 = r6;
    Term _result_108 = r7;
    u32 _result_109 = r8;
    Term _x_5 = r9;
    WL_OPEN
    u64 _nd_9 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_9 + 0] = rfc_seal(e, _result_101);
    e.mem[_nd_9 + 1] = rfc_seal(e, _result_102);
    e.mem[_nd_9 + 2] = rfc_seal(e, _result_103);
    e.mem[_nd_9 + 3] = rfc_seal(e, _result_104);
    e.mem[_nd_9 + 4] = rfc_seal(e, _result_105);
    e.mem[_nd_9 + 5] = rfc_seal(e, _result_106);
    e.mem[_nd_9 + 6] = rfc_seal(e, _result_107);
    e.mem[_nd_9 + 7] = rfc_seal(e, _result_108);
    e.mem[_nd_9 + 8] = rfc_seal(e, _result_109);
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_10 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = term_ctr(CID_STORAGE_ROWS, _nd_9);
      e.mem[_t_10 + 1] = _x_5;
      return term_tsk(FID_IO_PURE, _t_10);
    }
    r0 = term_ctr(CID_STORAGE_ROWS, _nd_9);
    r1 = _x_5;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND)
  {
    Term _m_0 = r0;
    Term _f_0 = r1;
    Term _k_0 = r2;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _f_0;
    e.mem[_nd_0 + 1] = _k_0;
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _m_0;
      e.mem[_t_3 + 1] = term_clo(FID_IO_BIND_C278, _nd_0);
      return term_tsk(FID_CLO_APPLY, _t_3);
    }
    r0 = _m_0;
    r1 = term_clo(FID_IO_BIND_C278, _nd_0);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND_C278)
  {
    Term _f_1 = r0;
    Term _k_1 = r1;
    Term _x_0 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _k_1;
      STK(1) = FID_IO_BIND_K279;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_IO_BIND_K279, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _k_1;
      WL_CONT = term_tsk(FID_IO_BIND_K279, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _f_1;
      e.mem[_t_1 + 1] = _x_0;
      return term_tsk(FID_CLO_APPLY, _t_1);
    }
    r0 = _f_1;
    r1 = _x_0;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND_K279)
  {
    WL_POPN(1);
    Term _k_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_2 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _k_2;
      return term_tsk(FID_CLO_APPLY, _t_2);
    }
    r0 = _h_0;
    r1 = _k_2;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN)
  {
    WL_OPEN
    Term _fv_0[2];
    _fv_0[0] = 0;
    _fv_0[1] = 0;
    Term _fv_1[2];
    _fv_1[0] = 0;
    _fv_1[1] = 0;
    Term _fv_2[1];
    _fv_2[0] = 0;
    Term _fv_3[2];
    _fv_3[0] = 0;
    _fv_3[1] = 0;
    Term _fv_4[1];
    _fv_4[0] = 0ull;
    Term _fv_5[1];
    _fv_5[0] = 0ull;
    Term _rows_0 = blk_new(e, 1, 0, 1, 2, _fv_0);
    Term _rows_1 = blk_new(e, 1, 0, 1, 2, _fv_1);
    Term _rows_2 = blk_new(e, 0, 0, 0, 1, _fv_2);
    Term _rows_3 = blk_new(e, 1, 0, 1, 2, _fv_3);
    Term _rows_4 = blk_new(e, 0, 0, 0, 1, _fv_4);
    Term _rows_5 = blk_new(e, 0, 0, 0, 1, _fv_5);
    u32 _rows_6 = 1ull;
    Term _rows_7 = 0;
    u32 _rows_8 = 0ull;
    Term _fv_6[1];
    _fv_6[0] = 10ull;
    Term _a_0 = blk_new(e, 0, 2ull, 0, 1, _fv_6);
    Term _at_0 = blk_loc(e.mem, _a_0);
    Term _at_1 = blk_at(_a_0, 1ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    blk_write(e.mem, 0, _at_0, _at_1 + 0, U32_BIN(10ull, +, 1ull));
    Term _at_2 = blk_loc(e.mem, _a_0);
    Term _at_3 = blk_at(_a_0, 2ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    blk_write(e.mem, 0, _at_2, _at_3 + 0, U32_BIN(10ull, +, 2ull));
    Term _at_4 = blk_loc(e.mem, _a_0);
    Term _at_5 = blk_at(_a_0, 3ull, 0);
    u32 _c_2 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    blk_write(e.mem, 0, _at_4, _at_5 + 0, U32_BIN(10ull, +, 3ull));
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _a_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, 10ull);
    Term _fv_7[1];
    _fv_7[0] = 110ull;
    Term _a_1 = blk_new(e, 0, 2ull, 0, 1, _fv_7);
    Term _at_6 = blk_loc(e.mem, _a_1);
    Term _at_7 = blk_at(_a_1, 1ull, 0);
    u32 _c_3 = blk_read(e.mem, 0, _at_6, _at_7 + 0);
    blk_write(e.mem, 0, _at_6, _at_7 + 0, U32_BIN(110ull, +, 1ull));
    Term _at_8 = blk_loc(e.mem, _a_1);
    Term _at_9 = blk_at(_a_1, 2ull, 0);
    u32 _c_4 = blk_read(e.mem, 0, _at_8, _at_9 + 0);
    blk_write(e.mem, 0, _at_8, _at_9 + 0, U32_BIN(110ull, +, 2ull));
    Term _at_10 = blk_loc(e.mem, _a_1);
    Term _at_11 = blk_at(_a_1, 3ull, 0);
    u32 _c_5 = blk_read(e.mem, 0, _at_10, _at_11 + 0);
    blk_write(e.mem, 0, _at_10, _at_11 + 0, U32_BIN(110ull, +, 3ull));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, _a_1);
    e.mem[_nd_1 + 1] = rfc_seal(e, 110ull);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K282;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_MAIN_K282, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K282, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_ROWS_PLACE)) {
      u64 _t_1 = task_node(e, FID_STORAGE_ROWS_PLACE, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _rows_0;
      e.mem[_t_1 + 1] = _rows_1;
      e.mem[_t_1 + 2] = _rows_2;
      e.mem[_t_1 + 3] = _rows_3;
      e.mem[_t_1 + 4] = _rows_4;
      e.mem[_t_1 + 5] = _rows_5;
      e.mem[_t_1 + 6] = _rows_6;
      e.mem[_t_1 + 7] = _rows_7;
      e.mem[_t_1 + 8] = _rows_8;
      e.mem[_t_1 + 9] = 1ull;
      e.mem[_t_1 + 10] = 1;
      e.mem[_t_1 + 11] = term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_0);
      e.mem[_t_1 + 12] = 1;
      e.mem[_t_1 + 13] = term_ctr(CID____OWNED_INDEX_CORE_HEALTH, _nd_1);
      e.mem[_t_1 + 14] = 1;
      e.mem[_t_1 + 15] = term_pak(CID_UNIT, 0);
      e.mem[_t_1 + 16] = 1ull;
      e.mem[_t_1 + 17] = 2ull;
      return term_tsk(FID_STORAGE_ROWS_PLACE, _t_1);
    }
    r0 = _rows_0;
    r1 = _rows_1;
    r2 = _rows_2;
    r3 = _rows_3;
    r4 = _rows_4;
    r5 = _rows_5;
    r6 = _rows_6;
    r7 = _rows_7;
    r8 = _rows_8;
    r9 = 1ull;
    r10 = 1;
    r11 = term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_0);
    r12 = 1;
    r13 = term_ctr(CID____OWNED_INDEX_CORE_HEALTH, _nd_1);
    r14 = 1;
    r15 = term_pak(CID_UNIT, 0);
    r16 = 1ull;
    r17 = 2ull;
    WL_JMP(FID_STORAGE_ROWS_PLACE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K282)
  {
    u32 _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    u32 _h_7 = r7;
    Term _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    Term _h_12 = r12;
    u32 _h_13 = r13;
    Term _h_14 = r14;
    u32 _h_15 = r15;
    Term _h_16 = r16;
    u32 _h_17 = r17;
    u32 _h_18 = r18;
    WL_OPEN
    u32 _o_0 = 0;
    Term _o_1 = 0;
    Term _o_2 = 0;
    Term _o_3 = 0;
    Term _o_4 = 0;
    Term _o_5 = 0;
    Term _o_6 = 0;
    u32 _o_7 = 0;
    Term _o_8 = 0;
    u32 _o_9 = 0;
    u32 _o_10 = 0;
    u32 _o_11 = 0;
    Term _o_12 = 0;
    u32 _o_13 = 0;
    u32 _o_14 = 0;
    Term _o_15 = 0;
    u32 _o_16 = 0;
    u32 _o_17 = 0;
    u32 _o_18 = 0;
    u32 _o_19 = 0;
    if (_h_0 == 0) {
      _o_0 = 0;
      _o_1 = _h_1;
      _o_2 = _h_2;
      _o_3 = _h_3;
      _o_4 = _h_4;
      _o_5 = _h_5;
      _o_6 = _h_6;
      _o_7 = _h_7;
      _o_8 = _h_8;
      _o_9 = _h_9;
    } else {
      _o_0 = 1;
      u32 _o_20 = 0;
      Term _o_21 = 0;
      u32 _o_22 = 0;
      if (_h_11 == 0) {
        _o_20 = 0;
      } else {
        _o_20 = 1;
        Term _fb_0[2];
        u64 _sp_0 = ctr_take(e, _h_12, 2, _fb_0);
        Term _f_0 = _fb_0[0];
        u32 _f_1 = _fb_0[1];
        spare_free(e, cls_fit(2), _sp_0);
        _o_21 = _f_0;
        _o_22 = _f_1;
      }
      u32 _o_23 = 0;
      Term _o_24 = 0;
      u32 _o_25 = 0;
      if (_h_13 == 0) {
        _o_23 = 0;
      } else {
        _o_23 = 1;
        Term _fb_1[2];
        u64 _sp_1 = ctr_take(e, _h_14, 2, _fb_1);
        Term _f_2 = _fb_1[0];
        u32 _f_3 = _fb_1[1];
        spare_free(e, cls_fit(2), _sp_1);
        _o_24 = _f_2;
        _o_25 = _f_3;
      }
      u32 _o_26 = 0;
      if (_h_15 == 0) {
        _o_26 = 0;
      } else {
        _o_26 = 1;
      }
      _o_1 = _h_1;
      _o_2 = _h_2;
      _o_3 = _h_3;
      _o_4 = _h_4;
      _o_5 = _h_5;
      _o_6 = _h_6;
      _o_7 = _h_7;
      _o_8 = _h_8;
      _o_9 = _h_9;
      _o_10 = _h_10;
      _o_11 = _o_20;
      _o_12 = _o_21;
      _o_13 = _o_22;
      _o_14 = _o_23;
      _o_15 = _o_24;
      _o_16 = _o_25;
      _o_17 = _o_26;
      _o_18 = _h_17;
      _o_19 = _h_18;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K283;
      WL_PUSHN(1);
    } else {
      u64 _t_2 = task_node(e, FID_MAIN_K283, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K283, _t_2);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_PLACEMENT_PRINT)) {
      u64 _t_3 = task_node(e, FID_PLACEMENT_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 144);
      e.mem[_t_3 + 1] = _o_0;
      e.mem[_t_3 + 2] = _o_1;
      e.mem[_t_3 + 3] = _o_2;
      e.mem[_t_3 + 4] = _o_3;
      e.mem[_t_3 + 5] = _o_4;
      e.mem[_t_3 + 6] = _o_5;
      e.mem[_t_3 + 7] = _o_6;
      e.mem[_t_3 + 8] = _o_7;
      e.mem[_t_3 + 9] = _o_8;
      e.mem[_t_3 + 10] = _o_9;
      e.mem[_t_3 + 11] = _o_10;
      e.mem[_t_3 + 12] = _o_11;
      e.mem[_t_3 + 13] = _o_12;
      e.mem[_t_3 + 14] = _o_13;
      e.mem[_t_3 + 15] = _o_14;
      e.mem[_t_3 + 16] = _o_15;
      e.mem[_t_3 + 17] = _o_16;
      e.mem[_t_3 + 18] = _o_17;
      e.mem[_t_3 + 19] = _o_18;
      e.mem[_t_3 + 20] = _o_19;
      return term_tsk(FID_PLACEMENT_PRINT, _t_3);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 144);
    r1 = _o_0;
    r2 = _o_1;
    r3 = _o_2;
    r4 = _o_3;
    r5 = _o_4;
    r6 = _o_5;
    r7 = _o_6;
    r8 = _o_7;
    r9 = _o_8;
    r10 = _o_9;
    r11 = _o_10;
    r12 = _o_11;
    r13 = _o_12;
    r14 = _o_13;
    r15 = _o_14;
    r16 = _o_15;
    r17 = _o_16;
    r18 = _o_17;
    r19 = _o_18;
    r20 = _o_19;
    WL_JMP(FID_PLACEMENT_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K283)
  {
    Term _h_19 = r0;
    WL_OPEN
    u64 _nd_2 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_2 + 0] = _h_19;
    r0 = term_clo(FID_MAIN_C284, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C284)
  {
    Term _h_20 = r0;
    Term _x_0 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_161 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_161 + 0] = _h_20;
      e.mem[_t_161 + 1] = term_clo(FID_MAIN_C285, 0);
      e.mem[_t_161 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_161);
    }
    r0 = _h_20;
    r1 = term_clo(FID_MAIN_C285, 0);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C285)
  {
    Term _x_1 = r0;
    WL_OPEN
    Term _fb_2[9];
    u64 _sp_2 = ctr_take(e, _x_1, 9, _fb_2);
    Term _f_4 = _fb_2[0];
    Term _f_5 = _fb_2[1];
    Term _f_6 = _fb_2[2];
    Term _f_7 = _fb_2[3];
    Term _f_8 = _fb_2[4];
    Term _f_9 = _fb_2[5];
    u32 _f_10 = _fb_2[6];
    Term _f_11 = _fb_2[7];
    u32 _f_12 = _fb_2[8];
    spare_free(e, cls_fit(9), _sp_2);
    Term _fv_8[1];
    _fv_8[0] = 120ull;
    Term _a_2 = blk_new(e, 0, 2ull, 0, 1, _fv_8);
    Term _at_12 = blk_loc(e.mem, _a_2);
    Term _at_13 = blk_at(_a_2, 1ull, 0);
    u32 _c_6 = blk_read(e.mem, 0, _at_12, _at_13 + 0);
    blk_write(e.mem, 0, _at_12, _at_13 + 0, U32_BIN(120ull, +, 1ull));
    Term _at_14 = blk_loc(e.mem, _a_2);
    Term _at_15 = blk_at(_a_2, 2ull, 0);
    u32 _c_7 = blk_read(e.mem, 0, _at_14, _at_15 + 0);
    blk_write(e.mem, 0, _at_14, _at_15 + 0, U32_BIN(120ull, +, 2ull));
    Term _at_16 = blk_loc(e.mem, _a_2);
    Term _at_17 = blk_at(_a_2, 3ull, 0);
    u32 _c_8 = blk_read(e.mem, 0, _at_16, _at_17 + 0);
    blk_write(e.mem, 0, _at_16, _at_17 + 0, U32_BIN(120ull, +, 3ull));
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, _a_2);
    e.mem[_nd_3 + 1] = rfc_seal(e, 120ull);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K286;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_MAIN_K286, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K286, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_ROWS_PLACE)) {
      u64 _t_5 = task_node(e, FID_STORAGE_ROWS_PLACE, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _f_4;
      e.mem[_t_5 + 1] = _f_5;
      e.mem[_t_5 + 2] = _f_6;
      e.mem[_t_5 + 3] = _f_7;
      e.mem[_t_5 + 4] = _f_8;
      e.mem[_t_5 + 5] = _f_9;
      e.mem[_t_5 + 6] = _f_10;
      e.mem[_t_5 + 7] = _f_11;
      e.mem[_t_5 + 8] = _f_12;
      e.mem[_t_5 + 9] = 2ull;
      e.mem[_t_5 + 10] = 0;
      e.mem[_t_5 + 11] = 0;
      e.mem[_t_5 + 12] = 1;
      e.mem[_t_5 + 13] = term_ctr(CID____OWNED_INDEX_CORE_HEALTH, _nd_3);
      e.mem[_t_5 + 14] = 0;
      e.mem[_t_5 + 15] = 0;
      e.mem[_t_5 + 16] = 3ull;
      e.mem[_t_5 + 17] = 4ull;
      return term_tsk(FID_STORAGE_ROWS_PLACE, _t_5);
    }
    r0 = _f_4;
    r1 = _f_5;
    r2 = _f_6;
    r3 = _f_7;
    r4 = _f_8;
    r5 = _f_9;
    r6 = _f_10;
    r7 = _f_11;
    r8 = _f_12;
    r9 = 2ull;
    r10 = 0;
    r11 = 0;
    r12 = 1;
    r13 = term_ctr(CID____OWNED_INDEX_CORE_HEALTH, _nd_3);
    r14 = 0;
    r15 = 0;
    r16 = 3ull;
    r17 = 4ull;
    WL_JMP(FID_STORAGE_ROWS_PLACE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K286)
  {
    u32 _h_21 = r0;
    Term _h_22 = r1;
    Term _h_23 = r2;
    Term _h_24 = r3;
    Term _h_25 = r4;
    Term _h_26 = r5;
    Term _h_27 = r6;
    u32 _h_28 = r7;
    Term _h_29 = r8;
    u32 _h_30 = r9;
    u32 _h_31 = r10;
    u32 _h_32 = r11;
    Term _h_33 = r12;
    u32 _h_34 = r13;
    Term _h_35 = r14;
    u32 _h_36 = r15;
    Term _h_37 = r16;
    u32 _h_38 = r17;
    u32 _h_39 = r18;
    WL_OPEN
    u32 _o_27 = 0;
    Term _o_28 = 0;
    Term _o_29 = 0;
    Term _o_30 = 0;
    Term _o_31 = 0;
    Term _o_32 = 0;
    Term _o_33 = 0;
    u32 _o_34 = 0;
    Term _o_35 = 0;
    u32 _o_36 = 0;
    u32 _o_37 = 0;
    u32 _o_38 = 0;
    Term _o_39 = 0;
    u32 _o_40 = 0;
    u32 _o_41 = 0;
    Term _o_42 = 0;
    u32 _o_43 = 0;
    u32 _o_44 = 0;
    u32 _o_45 = 0;
    u32 _o_46 = 0;
    if (_h_21 == 0) {
      _o_27 = 0;
      _o_28 = _h_22;
      _o_29 = _h_23;
      _o_30 = _h_24;
      _o_31 = _h_25;
      _o_32 = _h_26;
      _o_33 = _h_27;
      _o_34 = _h_28;
      _o_35 = _h_29;
      _o_36 = _h_30;
    } else {
      _o_27 = 1;
      u32 _o_47 = 0;
      Term _o_48 = 0;
      u32 _o_49 = 0;
      if (_h_32 == 0) {
        _o_47 = 0;
      } else {
        _o_47 = 1;
        Term _fb_3[2];
        u64 _sp_3 = ctr_take(e, _h_33, 2, _fb_3);
        Term _f_13 = _fb_3[0];
        u32 _f_14 = _fb_3[1];
        spare_free(e, cls_fit(2), _sp_3);
        _o_48 = _f_13;
        _o_49 = _f_14;
      }
      u32 _o_50 = 0;
      Term _o_51 = 0;
      u32 _o_52 = 0;
      if (_h_34 == 0) {
        _o_50 = 0;
      } else {
        _o_50 = 1;
        Term _fb_4[2];
        u64 _sp_4 = ctr_take(e, _h_35, 2, _fb_4);
        Term _f_15 = _fb_4[0];
        u32 _f_16 = _fb_4[1];
        spare_free(e, cls_fit(2), _sp_4);
        _o_51 = _f_15;
        _o_52 = _f_16;
      }
      u32 _o_53 = 0;
      if (_h_36 == 0) {
        _o_53 = 0;
      } else {
        _o_53 = 1;
      }
      _o_28 = _h_22;
      _o_29 = _h_23;
      _o_30 = _h_24;
      _o_31 = _h_25;
      _o_32 = _h_26;
      _o_33 = _h_27;
      _o_34 = _h_28;
      _o_35 = _h_29;
      _o_36 = _h_30;
      _o_37 = _h_31;
      _o_38 = _o_47;
      _o_39 = _o_48;
      _o_40 = _o_49;
      _o_41 = _o_50;
      _o_42 = _o_51;
      _o_43 = _o_52;
      _o_44 = _o_53;
      _o_45 = _h_38;
      _o_46 = _h_39;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K287;
      WL_PUSHN(1);
    } else {
      u64 _t_6 = task_node(e, FID_MAIN_K287, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K287, _t_6);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_PLACEMENT_PRINT)) {
      u64 _t_7 = task_node(e, FID_PLACEMENT_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 158);
      e.mem[_t_7 + 1] = _o_27;
      e.mem[_t_7 + 2] = _o_28;
      e.mem[_t_7 + 3] = _o_29;
      e.mem[_t_7 + 4] = _o_30;
      e.mem[_t_7 + 5] = _o_31;
      e.mem[_t_7 + 6] = _o_32;
      e.mem[_t_7 + 7] = _o_33;
      e.mem[_t_7 + 8] = _o_34;
      e.mem[_t_7 + 9] = _o_35;
      e.mem[_t_7 + 10] = _o_36;
      e.mem[_t_7 + 11] = _o_37;
      e.mem[_t_7 + 12] = _o_38;
      e.mem[_t_7 + 13] = _o_39;
      e.mem[_t_7 + 14] = _o_40;
      e.mem[_t_7 + 15] = _o_41;
      e.mem[_t_7 + 16] = _o_42;
      e.mem[_t_7 + 17] = _o_43;
      e.mem[_t_7 + 18] = _o_44;
      e.mem[_t_7 + 19] = _o_45;
      e.mem[_t_7 + 20] = _o_46;
      return term_tsk(FID_PLACEMENT_PRINT, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 158);
    r1 = _o_27;
    r2 = _o_28;
    r3 = _o_29;
    r4 = _o_30;
    r5 = _o_31;
    r6 = _o_32;
    r7 = _o_33;
    r8 = _o_34;
    r9 = _o_35;
    r10 = _o_36;
    r11 = _o_37;
    r12 = _o_38;
    r13 = _o_39;
    r14 = _o_40;
    r15 = _o_41;
    r16 = _o_42;
    r17 = _o_43;
    r18 = _o_44;
    r19 = _o_45;
    r20 = _o_46;
    WL_JMP(FID_PLACEMENT_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K287)
  {
    Term _h_40 = r0;
    WL_OPEN
    u64 _nd_4 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_4 + 0] = _h_40;
    r0 = term_clo(FID_MAIN_C288, _nd_4);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C288)
  {
    Term _h_41 = r0;
    Term _x_2 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_160 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_160 + 0] = _h_41;
      e.mem[_t_160 + 1] = term_clo(FID_MAIN_C289, 0);
      e.mem[_t_160 + 2] = _x_2;
      return term_tsk(FID_IO_BIND, _t_160);
    }
    r0 = _h_41;
    r1 = term_clo(FID_MAIN_C289, 0);
    r2 = _x_2;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C289)
  {
    Term _x_3 = r0;
    WL_OPEN
    Term _fb_5[9];
    u64 _sp_5 = ctr_take(e, _x_3, 9, _fb_5);
    Term _f_17 = _fb_5[0];
    Term _f_18 = _fb_5[1];
    Term _f_19 = _fb_5[2];
    Term _f_20 = _fb_5[3];
    Term _f_21 = _fb_5[4];
    Term _f_22 = _fb_5[5];
    u32 _f_23 = _fb_5[6];
    Term _f_24 = _fb_5[7];
    u32 _f_25 = _fb_5[8];
    spare_free(e, cls_fit(9), _sp_5);
    Term _fv_9[1];
    _fv_9[0] = 40ull;
    Term _a_3 = blk_new(e, 0, 2ull, 0, 1, _fv_9);
    Term _at_18 = blk_loc(e.mem, _a_3);
    Term _at_19 = blk_at(_a_3, 1ull, 0);
    u32 _c_9 = blk_read(e.mem, 0, _at_18, _at_19 + 0);
    blk_write(e.mem, 0, _at_18, _at_19 + 0, U32_BIN(40ull, +, 1ull));
    Term _at_20 = blk_loc(e.mem, _a_3);
    Term _at_21 = blk_at(_a_3, 2ull, 0);
    u32 _c_10 = blk_read(e.mem, 0, _at_20, _at_21 + 0);
    blk_write(e.mem, 0, _at_20, _at_21 + 0, U32_BIN(40ull, +, 2ull));
    Term _at_22 = blk_loc(e.mem, _a_3);
    Term _at_23 = blk_at(_a_3, 3ull, 0);
    u32 _c_11 = blk_read(e.mem, 0, _at_22, _at_23 + 0);
    blk_write(e.mem, 0, _at_22, _at_23 + 0, U32_BIN(40ull, +, 3ull));
    u64 _nd_5 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_5 + 0] = rfc_seal(e, _a_3);
    e.mem[_nd_5 + 1] = rfc_seal(e, 40ull);
    Term _fv_10[1];
    _fv_10[0] = 140ull;
    Term _a_4 = blk_new(e, 0, 2ull, 0, 1, _fv_10);
    Term _at_24 = blk_loc(e.mem, _a_4);
    Term _at_25 = blk_at(_a_4, 1ull, 0);
    u32 _c_12 = blk_read(e.mem, 0, _at_24, _at_25 + 0);
    blk_write(e.mem, 0, _at_24, _at_25 + 0, U32_BIN(140ull, +, 1ull));
    Term _at_26 = blk_loc(e.mem, _a_4);
    Term _at_27 = blk_at(_a_4, 2ull, 0);
    u32 _c_13 = blk_read(e.mem, 0, _at_26, _at_27 + 0);
    blk_write(e.mem, 0, _at_26, _at_27 + 0, U32_BIN(140ull, +, 2ull));
    Term _at_28 = blk_loc(e.mem, _a_4);
    Term _at_29 = blk_at(_a_4, 3ull, 0);
    u32 _c_14 = blk_read(e.mem, 0, _at_28, _at_29 + 0);
    blk_write(e.mem, 0, _at_28, _at_29 + 0, U32_BIN(140ull, +, 3ull));
    u64 _nd_6 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_6 + 0] = rfc_seal(e, _a_4);
    e.mem[_nd_6 + 1] = rfc_seal(e, 140ull);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K290;
      WL_PUSHN(1);
    } else {
      u64 _t_8 = task_node(e, FID_MAIN_K290, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K290, _t_8);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_ROWS_PLACE)) {
      u64 _t_9 = task_node(e, FID_STORAGE_ROWS_PLACE, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _f_17;
      e.mem[_t_9 + 1] = _f_18;
      e.mem[_t_9 + 2] = _f_19;
      e.mem[_t_9 + 3] = _f_20;
      e.mem[_t_9 + 4] = _f_21;
      e.mem[_t_9 + 5] = _f_22;
      e.mem[_t_9 + 6] = _f_23;
      e.mem[_t_9 + 7] = _f_24;
      e.mem[_t_9 + 8] = _f_25;
      e.mem[_t_9 + 9] = 4ull;
      e.mem[_t_9 + 10] = 1;
      e.mem[_t_9 + 11] = term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_5);
      e.mem[_t_9 + 12] = 1;
      e.mem[_t_9 + 13] = term_ctr(CID____OWNED_INDEX_CORE_HEALTH, _nd_6);
      e.mem[_t_9 + 14] = 0;
      e.mem[_t_9 + 15] = 0;
      e.mem[_t_9 + 16] = 5ull;
      e.mem[_t_9 + 17] = 6ull;
      return term_tsk(FID_STORAGE_ROWS_PLACE, _t_9);
    }
    r0 = _f_17;
    r1 = _f_18;
    r2 = _f_19;
    r3 = _f_20;
    r4 = _f_21;
    r5 = _f_22;
    r6 = _f_23;
    r7 = _f_24;
    r8 = _f_25;
    r9 = 4ull;
    r10 = 1;
    r11 = term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_5);
    r12 = 1;
    r13 = term_ctr(CID____OWNED_INDEX_CORE_HEALTH, _nd_6);
    r14 = 0;
    r15 = 0;
    r16 = 5ull;
    r17 = 6ull;
    WL_JMP(FID_STORAGE_ROWS_PLACE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K290)
  {
    u32 _h_42 = r0;
    Term _h_43 = r1;
    Term _h_44 = r2;
    Term _h_45 = r3;
    Term _h_46 = r4;
    Term _h_47 = r5;
    Term _h_48 = r6;
    u32 _h_49 = r7;
    Term _h_50 = r8;
    u32 _h_51 = r9;
    u32 _h_52 = r10;
    u32 _h_53 = r11;
    Term _h_54 = r12;
    u32 _h_55 = r13;
    Term _h_56 = r14;
    u32 _h_57 = r15;
    Term _h_58 = r16;
    u32 _h_59 = r17;
    u32 _h_60 = r18;
    WL_OPEN
    u32 _o_54 = 0;
    Term _o_55 = 0;
    Term _o_56 = 0;
    Term _o_57 = 0;
    Term _o_58 = 0;
    Term _o_59 = 0;
    Term _o_60 = 0;
    u32 _o_61 = 0;
    Term _o_62 = 0;
    u32 _o_63 = 0;
    u32 _o_64 = 0;
    u32 _o_65 = 0;
    Term _o_66 = 0;
    u32 _o_67 = 0;
    u32 _o_68 = 0;
    Term _o_69 = 0;
    u32 _o_70 = 0;
    u32 _o_71 = 0;
    u32 _o_72 = 0;
    u32 _o_73 = 0;
    if (_h_42 == 0) {
      _o_54 = 0;
      _o_55 = _h_43;
      _o_56 = _h_44;
      _o_57 = _h_45;
      _o_58 = _h_46;
      _o_59 = _h_47;
      _o_60 = _h_48;
      _o_61 = _h_49;
      _o_62 = _h_50;
      _o_63 = _h_51;
    } else {
      _o_54 = 1;
      u32 _o_74 = 0;
      Term _o_75 = 0;
      u32 _o_76 = 0;
      if (_h_53 == 0) {
        _o_74 = 0;
      } else {
        _o_74 = 1;
        Term _fb_6[2];
        u64 _sp_6 = ctr_take(e, _h_54, 2, _fb_6);
        Term _f_26 = _fb_6[0];
        u32 _f_27 = _fb_6[1];
        spare_free(e, cls_fit(2), _sp_6);
        _o_75 = _f_26;
        _o_76 = _f_27;
      }
      u32 _o_77 = 0;
      Term _o_78 = 0;
      u32 _o_79 = 0;
      if (_h_55 == 0) {
        _o_77 = 0;
      } else {
        _o_77 = 1;
        Term _fb_7[2];
        u64 _sp_7 = ctr_take(e, _h_56, 2, _fb_7);
        Term _f_28 = _fb_7[0];
        u32 _f_29 = _fb_7[1];
        spare_free(e, cls_fit(2), _sp_7);
        _o_78 = _f_28;
        _o_79 = _f_29;
      }
      u32 _o_80 = 0;
      if (_h_57 == 0) {
        _o_80 = 0;
      } else {
        _o_80 = 1;
      }
      _o_55 = _h_43;
      _o_56 = _h_44;
      _o_57 = _h_45;
      _o_58 = _h_46;
      _o_59 = _h_47;
      _o_60 = _h_48;
      _o_61 = _h_49;
      _o_62 = _h_50;
      _o_63 = _h_51;
      _o_64 = _h_52;
      _o_65 = _o_74;
      _o_66 = _o_75;
      _o_67 = _o_76;
      _o_68 = _o_77;
      _o_69 = _o_78;
      _o_70 = _o_79;
      _o_71 = _o_80;
      _o_72 = _h_59;
      _o_73 = _h_60;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K291;
      WL_PUSHN(1);
    } else {
      u64 _t_10 = task_node(e, FID_MAIN_K291, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K291, _t_10);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_PLACEMENT_PRINT)) {
      u64 _t_11 = task_node(e, FID_PLACEMENT_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 172);
      e.mem[_t_11 + 1] = _o_54;
      e.mem[_t_11 + 2] = _o_55;
      e.mem[_t_11 + 3] = _o_56;
      e.mem[_t_11 + 4] = _o_57;
      e.mem[_t_11 + 5] = _o_58;
      e.mem[_t_11 + 6] = _o_59;
      e.mem[_t_11 + 7] = _o_60;
      e.mem[_t_11 + 8] = _o_61;
      e.mem[_t_11 + 9] = _o_62;
      e.mem[_t_11 + 10] = _o_63;
      e.mem[_t_11 + 11] = _o_64;
      e.mem[_t_11 + 12] = _o_65;
      e.mem[_t_11 + 13] = _o_66;
      e.mem[_t_11 + 14] = _o_67;
      e.mem[_t_11 + 15] = _o_68;
      e.mem[_t_11 + 16] = _o_69;
      e.mem[_t_11 + 17] = _o_70;
      e.mem[_t_11 + 18] = _o_71;
      e.mem[_t_11 + 19] = _o_72;
      e.mem[_t_11 + 20] = _o_73;
      return term_tsk(FID_PLACEMENT_PRINT, _t_11);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 172);
    r1 = _o_54;
    r2 = _o_55;
    r3 = _o_56;
    r4 = _o_57;
    r5 = _o_58;
    r6 = _o_59;
    r7 = _o_60;
    r8 = _o_61;
    r9 = _o_62;
    r10 = _o_63;
    r11 = _o_64;
    r12 = _o_65;
    r13 = _o_66;
    r14 = _o_67;
    r15 = _o_68;
    r16 = _o_69;
    r17 = _o_70;
    r18 = _o_71;
    r19 = _o_72;
    r20 = _o_73;
    WL_JMP(FID_PLACEMENT_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K291)
  {
    Term _h_61 = r0;
    WL_OPEN
    u64 _nd_7 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_7 + 0] = _h_61;
    r0 = term_clo(FID_MAIN_C292, _nd_7);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C292)
  {
    Term _h_62 = r0;
    Term _x_4 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_159 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_159 + 0] = _h_62;
      e.mem[_t_159 + 1] = term_clo(FID_MAIN_C293, 0);
      e.mem[_t_159 + 2] = _x_4;
      return term_tsk(FID_IO_BIND, _t_159);
    }
    r0 = _h_62;
    r1 = term_clo(FID_MAIN_C293, 0);
    r2 = _x_4;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C293)
  {
    Term _x_5 = r0;
    WL_OPEN
    Term _fb_8[9];
    u64 _sp_8 = ctr_take(e, _x_5, 9, _fb_8);
    Term _f_30 = _fb_8[0];
    Term _f_31 = _fb_8[1];
    Term _f_32 = _fb_8[2];
    Term _f_33 = _fb_8[3];
    Term _f_34 = _fb_8[4];
    Term _f_35 = _fb_8[5];
    u32 _f_36 = _fb_8[6];
    Term _f_37 = _fb_8[7];
    u32 _f_38 = _fb_8[8];
    spare_free(e, cls_fit(9), _sp_8);
    Term _fv_11[1];
    _fv_11[0] = 80ull;
    Term _a_5 = blk_new(e, 0, 2ull, 0, 1, _fv_11);
    Term _at_30 = blk_loc(e.mem, _a_5);
    Term _at_31 = blk_at(_a_5, 1ull, 0);
    u32 _c_15 = blk_read(e.mem, 0, _at_30, _at_31 + 0);
    blk_write(e.mem, 0, _at_30, _at_31 + 0, U32_BIN(80ull, +, 1ull));
    Term _at_32 = blk_loc(e.mem, _a_5);
    Term _at_33 = blk_at(_a_5, 2ull, 0);
    u32 _c_16 = blk_read(e.mem, 0, _at_32, _at_33 + 0);
    blk_write(e.mem, 0, _at_32, _at_33 + 0, U32_BIN(80ull, +, 2ull));
    Term _at_34 = blk_loc(e.mem, _a_5);
    Term _at_35 = blk_at(_a_5, 3ull, 0);
    u32 _c_17 = blk_read(e.mem, 0, _at_34, _at_35 + 0);
    blk_write(e.mem, 0, _at_34, _at_35 + 0, U32_BIN(80ull, +, 3ull));
    u64 _nd_8 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_8 + 0] = rfc_seal(e, _a_5);
    e.mem[_nd_8 + 1] = rfc_seal(e, 80ull);
    Term _fv_12[1];
    _fv_12[0] = 180ull;
    Term _a_6 = blk_new(e, 0, 2ull, 0, 1, _fv_12);
    Term _at_36 = blk_loc(e.mem, _a_6);
    Term _at_37 = blk_at(_a_6, 1ull, 0);
    u32 _c_18 = blk_read(e.mem, 0, _at_36, _at_37 + 0);
    blk_write(e.mem, 0, _at_36, _at_37 + 0, U32_BIN(180ull, +, 1ull));
    Term _at_38 = blk_loc(e.mem, _a_6);
    Term _at_39 = blk_at(_a_6, 2ull, 0);
    u32 _c_19 = blk_read(e.mem, 0, _at_38, _at_39 + 0);
    blk_write(e.mem, 0, _at_38, _at_39 + 0, U32_BIN(180ull, +, 2ull));
    Term _at_40 = blk_loc(e.mem, _a_6);
    Term _at_41 = blk_at(_a_6, 3ull, 0);
    u32 _c_20 = blk_read(e.mem, 0, _at_40, _at_41 + 0);
    blk_write(e.mem, 0, _at_40, _at_41 + 0, U32_BIN(180ull, +, 3ull));
    u64 _nd_9 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_9 + 0] = rfc_seal(e, _a_6);
    e.mem[_nd_9 + 1] = rfc_seal(e, 180ull);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K294;
      WL_PUSHN(1);
    } else {
      u64 _t_12 = task_node(e, FID_MAIN_K294, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K294, _t_12);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_ROWS_PLACE)) {
      u64 _t_13 = task_node(e, FID_STORAGE_ROWS_PLACE, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _f_30;
      e.mem[_t_13 + 1] = _f_31;
      e.mem[_t_13 + 2] = _f_32;
      e.mem[_t_13 + 3] = _f_33;
      e.mem[_t_13 + 4] = _f_34;
      e.mem[_t_13 + 5] = _f_35;
      e.mem[_t_13 + 6] = _f_36;
      e.mem[_t_13 + 7] = _f_37;
      e.mem[_t_13 + 8] = _f_38;
      e.mem[_t_13 + 9] = 8ull;
      e.mem[_t_13 + 10] = 1;
      e.mem[_t_13 + 11] = term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_8);
      e.mem[_t_13 + 12] = 1;
      e.mem[_t_13 + 13] = term_ctr(CID____OWNED_INDEX_CORE_HEALTH, _nd_9);
      e.mem[_t_13 + 14] = 1;
      e.mem[_t_13 + 15] = term_pak(CID_UNIT, 0);
      e.mem[_t_13 + 16] = 7ull;
      e.mem[_t_13 + 17] = 8ull;
      return term_tsk(FID_STORAGE_ROWS_PLACE, _t_13);
    }
    r0 = _f_30;
    r1 = _f_31;
    r2 = _f_32;
    r3 = _f_33;
    r4 = _f_34;
    r5 = _f_35;
    r6 = _f_36;
    r7 = _f_37;
    r8 = _f_38;
    r9 = 8ull;
    r10 = 1;
    r11 = term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_8);
    r12 = 1;
    r13 = term_ctr(CID____OWNED_INDEX_CORE_HEALTH, _nd_9);
    r14 = 1;
    r15 = term_pak(CID_UNIT, 0);
    r16 = 7ull;
    r17 = 8ull;
    WL_JMP(FID_STORAGE_ROWS_PLACE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K294)
  {
    u32 _h_63 = r0;
    Term _h_64 = r1;
    Term _h_65 = r2;
    Term _h_66 = r3;
    Term _h_67 = r4;
    Term _h_68 = r5;
    Term _h_69 = r6;
    u32 _h_70 = r7;
    Term _h_71 = r8;
    u32 _h_72 = r9;
    u32 _h_73 = r10;
    u32 _h_74 = r11;
    Term _h_75 = r12;
    u32 _h_76 = r13;
    Term _h_77 = r14;
    u32 _h_78 = r15;
    Term _h_79 = r16;
    u32 _h_80 = r17;
    u32 _h_81 = r18;
    WL_OPEN
    u32 _o_81 = 0;
    Term _o_82 = 0;
    Term _o_83 = 0;
    Term _o_84 = 0;
    Term _o_85 = 0;
    Term _o_86 = 0;
    Term _o_87 = 0;
    u32 _o_88 = 0;
    Term _o_89 = 0;
    u32 _o_90 = 0;
    u32 _o_91 = 0;
    u32 _o_92 = 0;
    Term _o_93 = 0;
    u32 _o_94 = 0;
    u32 _o_95 = 0;
    Term _o_96 = 0;
    u32 _o_97 = 0;
    u32 _o_98 = 0;
    u32 _o_99 = 0;
    u32 _o_100 = 0;
    if (_h_63 == 0) {
      _o_81 = 0;
      _o_82 = _h_64;
      _o_83 = _h_65;
      _o_84 = _h_66;
      _o_85 = _h_67;
      _o_86 = _h_68;
      _o_87 = _h_69;
      _o_88 = _h_70;
      _o_89 = _h_71;
      _o_90 = _h_72;
    } else {
      _o_81 = 1;
      u32 _o_101 = 0;
      Term _o_102 = 0;
      u32 _o_103 = 0;
      if (_h_74 == 0) {
        _o_101 = 0;
      } else {
        _o_101 = 1;
        Term _fb_9[2];
        u64 _sp_9 = ctr_take(e, _h_75, 2, _fb_9);
        Term _f_39 = _fb_9[0];
        u32 _f_40 = _fb_9[1];
        spare_free(e, cls_fit(2), _sp_9);
        _o_102 = _f_39;
        _o_103 = _f_40;
      }
      u32 _o_104 = 0;
      Term _o_105 = 0;
      u32 _o_106 = 0;
      if (_h_76 == 0) {
        _o_104 = 0;
      } else {
        _o_104 = 1;
        Term _fb_10[2];
        u64 _sp_10 = ctr_take(e, _h_77, 2, _fb_10);
        Term _f_41 = _fb_10[0];
        u32 _f_42 = _fb_10[1];
        spare_free(e, cls_fit(2), _sp_10);
        _o_105 = _f_41;
        _o_106 = _f_42;
      }
      u32 _o_107 = 0;
      if (_h_78 == 0) {
        _o_107 = 0;
      } else {
        _o_107 = 1;
      }
      _o_82 = _h_64;
      _o_83 = _h_65;
      _o_84 = _h_66;
      _o_85 = _h_67;
      _o_86 = _h_68;
      _o_87 = _h_69;
      _o_88 = _h_70;
      _o_89 = _h_71;
      _o_90 = _h_72;
      _o_91 = _h_73;
      _o_92 = _o_101;
      _o_93 = _o_102;
      _o_94 = _o_103;
      _o_95 = _o_104;
      _o_96 = _o_105;
      _o_97 = _o_106;
      _o_98 = _o_107;
      _o_99 = _h_80;
      _o_100 = _h_81;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K295;
      WL_PUSHN(1);
    } else {
      u64 _t_14 = task_node(e, FID_MAIN_K295, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K295, _t_14);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_PLACEMENT_PRINT)) {
      u64 _t_15 = task_node(e, FID_PLACEMENT_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = term_ctr(CID_SCON, STAT_OFF + 186);
      e.mem[_t_15 + 1] = _o_81;
      e.mem[_t_15 + 2] = _o_82;
      e.mem[_t_15 + 3] = _o_83;
      e.mem[_t_15 + 4] = _o_84;
      e.mem[_t_15 + 5] = _o_85;
      e.mem[_t_15 + 6] = _o_86;
      e.mem[_t_15 + 7] = _o_87;
      e.mem[_t_15 + 8] = _o_88;
      e.mem[_t_15 + 9] = _o_89;
      e.mem[_t_15 + 10] = _o_90;
      e.mem[_t_15 + 11] = _o_91;
      e.mem[_t_15 + 12] = _o_92;
      e.mem[_t_15 + 13] = _o_93;
      e.mem[_t_15 + 14] = _o_94;
      e.mem[_t_15 + 15] = _o_95;
      e.mem[_t_15 + 16] = _o_96;
      e.mem[_t_15 + 17] = _o_97;
      e.mem[_t_15 + 18] = _o_98;
      e.mem[_t_15 + 19] = _o_99;
      e.mem[_t_15 + 20] = _o_100;
      return term_tsk(FID_PLACEMENT_PRINT, _t_15);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 186);
    r1 = _o_81;
    r2 = _o_82;
    r3 = _o_83;
    r4 = _o_84;
    r5 = _o_85;
    r6 = _o_86;
    r7 = _o_87;
    r8 = _o_88;
    r9 = _o_89;
    r10 = _o_90;
    r11 = _o_91;
    r12 = _o_92;
    r13 = _o_93;
    r14 = _o_94;
    r15 = _o_95;
    r16 = _o_96;
    r17 = _o_97;
    r18 = _o_98;
    r19 = _o_99;
    r20 = _o_100;
    WL_JMP(FID_PLACEMENT_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K295)
  {
    Term _h_82 = r0;
    WL_OPEN
    u64 _nd_10 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_10 + 0] = _h_82;
    r0 = term_clo(FID_MAIN_C296, _nd_10);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C296)
  {
    Term _h_83 = r0;
    Term _x_6 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_158 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_158 + 0] = _h_83;
      e.mem[_t_158 + 1] = term_clo(FID_MAIN_C297, 0);
      e.mem[_t_158 + 2] = _x_6;
      return term_tsk(FID_IO_BIND, _t_158);
    }
    r0 = _h_83;
    r1 = term_clo(FID_MAIN_C297, 0);
    r2 = _x_6;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C297)
  {
    Term _x_7 = r0;
    WL_OPEN
    Term _fb_11[9];
    u64 _sp_11 = ctr_take(e, _x_7, 9, _fb_11);
    Term _f_43 = _fb_11[0];
    Term _f_44 = _fb_11[1];
    Term _f_45 = _fb_11[2];
    Term _f_46 = _fb_11[3];
    Term _f_47 = _fb_11[4];
    Term _f_48 = _fb_11[5];
    u32 _f_49 = _fb_11[6];
    Term _f_50 = _fb_11[7];
    u32 _f_51 = _fb_11[8];
    spare_free(e, cls_fit(9), _sp_11);
    Term _fv_13[1];
    _fv_13[0] = 90ull;
    Term _a_7 = blk_new(e, 0, 2ull, 0, 1, _fv_13);
    Term _at_42 = blk_loc(e.mem, _a_7);
    Term _at_43 = blk_at(_a_7, 1ull, 0);
    u32 _c_21 = blk_read(e.mem, 0, _at_42, _at_43 + 0);
    blk_write(e.mem, 0, _at_42, _at_43 + 0, U32_BIN(90ull, +, 1ull));
    Term _at_44 = blk_loc(e.mem, _a_7);
    Term _at_45 = blk_at(_a_7, 2ull, 0);
    u32 _c_22 = blk_read(e.mem, 0, _at_44, _at_45 + 0);
    blk_write(e.mem, 0, _at_44, _at_45 + 0, U32_BIN(90ull, +, 2ull));
    Term _at_46 = blk_loc(e.mem, _a_7);
    Term _at_47 = blk_at(_a_7, 3ull, 0);
    u32 _c_23 = blk_read(e.mem, 0, _at_46, _at_47 + 0);
    blk_write(e.mem, 0, _at_46, _at_47 + 0, U32_BIN(90ull, +, 3ull));
    u64 _nd_11 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_11 + 0] = rfc_seal(e, _a_7);
    e.mem[_nd_11 + 1] = rfc_seal(e, 90ull);
    Term _fv_14[1];
    _fv_14[0] = 190ull;
    Term _a_8 = blk_new(e, 0, 2ull, 0, 1, _fv_14);
    Term _at_48 = blk_loc(e.mem, _a_8);
    Term _at_49 = blk_at(_a_8, 1ull, 0);
    u32 _c_24 = blk_read(e.mem, 0, _at_48, _at_49 + 0);
    blk_write(e.mem, 0, _at_48, _at_49 + 0, U32_BIN(190ull, +, 1ull));
    Term _at_50 = blk_loc(e.mem, _a_8);
    Term _at_51 = blk_at(_a_8, 2ull, 0);
    u32 _c_25 = blk_read(e.mem, 0, _at_50, _at_51 + 0);
    blk_write(e.mem, 0, _at_50, _at_51 + 0, U32_BIN(190ull, +, 2ull));
    Term _at_52 = blk_loc(e.mem, _a_8);
    Term _at_53 = blk_at(_a_8, 3ull, 0);
    u32 _c_26 = blk_read(e.mem, 0, _at_52, _at_53 + 0);
    blk_write(e.mem, 0, _at_52, _at_53 + 0, U32_BIN(190ull, +, 3ull));
    u64 _nd_12 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_12 + 0] = rfc_seal(e, _a_8);
    e.mem[_nd_12 + 1] = rfc_seal(e, 190ull);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K298;
      WL_PUSHN(1);
    } else {
      u64 _t_16 = task_node(e, FID_MAIN_K298, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K298, _t_16);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_ROWS_PLACE)) {
      u64 _t_17 = task_node(e, FID_STORAGE_ROWS_PLACE, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _f_43;
      e.mem[_t_17 + 1] = _f_44;
      e.mem[_t_17 + 2] = _f_45;
      e.mem[_t_17 + 3] = _f_46;
      e.mem[_t_17 + 4] = _f_47;
      e.mem[_t_17 + 5] = _f_48;
      e.mem[_t_17 + 6] = _f_49;
      e.mem[_t_17 + 7] = _f_50;
      e.mem[_t_17 + 8] = _f_51;
      e.mem[_t_17 + 9] = 65537ull;
      e.mem[_t_17 + 10] = 1;
      e.mem[_t_17 + 11] = term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_11);
      e.mem[_t_17 + 12] = 1;
      e.mem[_t_17 + 13] = term_ctr(CID____OWNED_INDEX_CORE_HEALTH, _nd_12);
      e.mem[_t_17 + 14] = 1;
      e.mem[_t_17 + 15] = term_pak(CID_UNIT, 0);
      e.mem[_t_17 + 16] = 9ull;
      e.mem[_t_17 + 17] = 10ull;
      return term_tsk(FID_STORAGE_ROWS_PLACE, _t_17);
    }
    r0 = _f_43;
    r1 = _f_44;
    r2 = _f_45;
    r3 = _f_46;
    r4 = _f_47;
    r5 = _f_48;
    r6 = _f_49;
    r7 = _f_50;
    r8 = _f_51;
    r9 = 65537ull;
    r10 = 1;
    r11 = term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_11);
    r12 = 1;
    r13 = term_ctr(CID____OWNED_INDEX_CORE_HEALTH, _nd_12);
    r14 = 1;
    r15 = term_pak(CID_UNIT, 0);
    r16 = 9ull;
    r17 = 10ull;
    WL_JMP(FID_STORAGE_ROWS_PLACE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K298)
  {
    u32 _h_84 = r0;
    Term _h_85 = r1;
    Term _h_86 = r2;
    Term _h_87 = r3;
    Term _h_88 = r4;
    Term _h_89 = r5;
    Term _h_90 = r6;
    u32 _h_91 = r7;
    Term _h_92 = r8;
    u32 _h_93 = r9;
    u32 _h_94 = r10;
    u32 _h_95 = r11;
    Term _h_96 = r12;
    u32 _h_97 = r13;
    Term _h_98 = r14;
    u32 _h_99 = r15;
    Term _h_100 = r16;
    u32 _h_101 = r17;
    u32 _h_102 = r18;
    WL_OPEN
    u32 _o_108 = 0;
    Term _o_109 = 0;
    Term _o_110 = 0;
    Term _o_111 = 0;
    Term _o_112 = 0;
    Term _o_113 = 0;
    Term _o_114 = 0;
    u32 _o_115 = 0;
    Term _o_116 = 0;
    u32 _o_117 = 0;
    u32 _o_118 = 0;
    u32 _o_119 = 0;
    Term _o_120 = 0;
    u32 _o_121 = 0;
    u32 _o_122 = 0;
    Term _o_123 = 0;
    u32 _o_124 = 0;
    u32 _o_125 = 0;
    u32 _o_126 = 0;
    u32 _o_127 = 0;
    if (_h_84 == 0) {
      _o_108 = 0;
      _o_109 = _h_85;
      _o_110 = _h_86;
      _o_111 = _h_87;
      _o_112 = _h_88;
      _o_113 = _h_89;
      _o_114 = _h_90;
      _o_115 = _h_91;
      _o_116 = _h_92;
      _o_117 = _h_93;
    } else {
      _o_108 = 1;
      u32 _o_128 = 0;
      Term _o_129 = 0;
      u32 _o_130 = 0;
      if (_h_95 == 0) {
        _o_128 = 0;
      } else {
        _o_128 = 1;
        Term _fb_12[2];
        u64 _sp_12 = ctr_take(e, _h_96, 2, _fb_12);
        Term _f_52 = _fb_12[0];
        u32 _f_53 = _fb_12[1];
        spare_free(e, cls_fit(2), _sp_12);
        _o_129 = _f_52;
        _o_130 = _f_53;
      }
      u32 _o_131 = 0;
      Term _o_132 = 0;
      u32 _o_133 = 0;
      if (_h_97 == 0) {
        _o_131 = 0;
      } else {
        _o_131 = 1;
        Term _fb_13[2];
        u64 _sp_13 = ctr_take(e, _h_98, 2, _fb_13);
        Term _f_54 = _fb_13[0];
        u32 _f_55 = _fb_13[1];
        spare_free(e, cls_fit(2), _sp_13);
        _o_132 = _f_54;
        _o_133 = _f_55;
      }
      u32 _o_134 = 0;
      if (_h_99 == 0) {
        _o_134 = 0;
      } else {
        _o_134 = 1;
      }
      _o_109 = _h_85;
      _o_110 = _h_86;
      _o_111 = _h_87;
      _o_112 = _h_88;
      _o_113 = _h_89;
      _o_114 = _h_90;
      _o_115 = _h_91;
      _o_116 = _h_92;
      _o_117 = _h_93;
      _o_118 = _h_94;
      _o_119 = _o_128;
      _o_120 = _o_129;
      _o_121 = _o_130;
      _o_122 = _o_131;
      _o_123 = _o_132;
      _o_124 = _o_133;
      _o_125 = _o_134;
      _o_126 = _h_101;
      _o_127 = _h_102;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K299;
      WL_PUSHN(1);
    } else {
      u64 _t_18 = task_node(e, FID_MAIN_K299, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K299, _t_18);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_PLACEMENT_PRINT)) {
      u64 _t_19 = task_node(e, FID_PLACEMENT_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = term_ctr(CID_SCON, STAT_OFF + 208);
      e.mem[_t_19 + 1] = _o_108;
      e.mem[_t_19 + 2] = _o_109;
      e.mem[_t_19 + 3] = _o_110;
      e.mem[_t_19 + 4] = _o_111;
      e.mem[_t_19 + 5] = _o_112;
      e.mem[_t_19 + 6] = _o_113;
      e.mem[_t_19 + 7] = _o_114;
      e.mem[_t_19 + 8] = _o_115;
      e.mem[_t_19 + 9] = _o_116;
      e.mem[_t_19 + 10] = _o_117;
      e.mem[_t_19 + 11] = _o_118;
      e.mem[_t_19 + 12] = _o_119;
      e.mem[_t_19 + 13] = _o_120;
      e.mem[_t_19 + 14] = _o_121;
      e.mem[_t_19 + 15] = _o_122;
      e.mem[_t_19 + 16] = _o_123;
      e.mem[_t_19 + 17] = _o_124;
      e.mem[_t_19 + 18] = _o_125;
      e.mem[_t_19 + 19] = _o_126;
      e.mem[_t_19 + 20] = _o_127;
      return term_tsk(FID_PLACEMENT_PRINT, _t_19);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 208);
    r1 = _o_108;
    r2 = _o_109;
    r3 = _o_110;
    r4 = _o_111;
    r5 = _o_112;
    r6 = _o_113;
    r7 = _o_114;
    r8 = _o_115;
    r9 = _o_116;
    r10 = _o_117;
    r11 = _o_118;
    r12 = _o_119;
    r13 = _o_120;
    r14 = _o_121;
    r15 = _o_122;
    r16 = _o_123;
    r17 = _o_124;
    r18 = _o_125;
    r19 = _o_126;
    r20 = _o_127;
    WL_JMP(FID_PLACEMENT_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K299)
  {
    Term _h_103 = r0;
    WL_OPEN
    u64 _nd_13 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_13 + 0] = _h_103;
    r0 = term_clo(FID_MAIN_C300, _nd_13);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C300)
  {
    Term _h_104 = r0;
    Term _x_8 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_157 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_157 + 0] = _h_104;
      e.mem[_t_157 + 1] = term_clo(FID_MAIN_C301, 0);
      e.mem[_t_157 + 2] = _x_8;
      return term_tsk(FID_IO_BIND, _t_157);
    }
    r0 = _h_104;
    r1 = term_clo(FID_MAIN_C301, 0);
    r2 = _x_8;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C301)
  {
    Term _x_9 = r0;
    WL_OPEN
    Term _fb_14[9];
    u64 _sp_14 = ctr_take(e, _x_9, 9, _fb_14);
    Term _f_56 = _fb_14[0];
    Term _f_57 = _fb_14[1];
    Term _f_58 = _fb_14[2];
    Term _f_59 = _fb_14[3];
    Term _f_60 = _fb_14[4];
    Term _f_61 = _fb_14[5];
    u32 _f_62 = _fb_14[6];
    Term _f_63 = _fb_14[7];
    u32 _f_64 = _fb_14[8];
    spare_free(e, cls_fit(9), _sp_14);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K302;
      WL_PUSHN(1);
    } else {
      u64 _t_20 = task_node(e, FID_MAIN_K302, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K302, _t_20);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_METADATA_PRINT)) {
      u64 _t_21 = task_node(e, FID_METADATA_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = _f_56;
      e.mem[_t_21 + 1] = _f_57;
      e.mem[_t_21 + 2] = _f_58;
      e.mem[_t_21 + 3] = _f_59;
      e.mem[_t_21 + 4] = _f_60;
      e.mem[_t_21 + 5] = _f_61;
      e.mem[_t_21 + 6] = _f_62;
      e.mem[_t_21 + 7] = _f_63;
      e.mem[_t_21 + 8] = _f_64;
      return term_tsk(FID_METADATA_PRINT, _t_21);
    }
    r0 = _f_56;
    r1 = _f_57;
    r2 = _f_58;
    r3 = _f_59;
    r4 = _f_60;
    r5 = _f_61;
    r6 = _f_62;
    r7 = _f_63;
    r8 = _f_64;
    WL_JMP(FID_METADATA_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K302)
  {
    Term _h_105 = r0;
    WL_OPEN
    u64 _nd_14 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_14 + 0] = _h_105;
    r0 = term_clo(FID_MAIN_C303, _nd_14);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C303)
  {
    Term _h_106 = r0;
    Term _x_10 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_156 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_156 + 0] = _h_106;
      e.mem[_t_156 + 1] = term_clo(FID_MAIN_C304, 0);
      e.mem[_t_156 + 2] = _x_10;
      return term_tsk(FID_IO_BIND, _t_156);
    }
    r0 = _h_106;
    r1 = term_clo(FID_MAIN_C304, 0);
    r2 = _x_10;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C304)
  {
    Term _x_11 = r0;
    WL_OPEN
    Term _fb_15[9];
    u64 _sp_15 = ctr_take(e, _x_11, 9, _fb_15);
    Term _f_65 = _fb_15[0];
    Term _f_66 = _fb_15[1];
    Term _f_67 = _fb_15[2];
    Term _f_68 = _fb_15[3];
    Term _f_69 = _fb_15[4];
    Term _f_70 = _fb_15[5];
    u32 _f_71 = _fb_15[6];
    Term _f_72 = _fb_15[7];
    u32 _f_73 = _fb_15[8];
    spare_free(e, cls_fit(9), _sp_15);
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    Term _v_12 = 0;
    u32 _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    u32 _v_25 = 0;
    Term _v_26 = 0;
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    Term _v_31 = 0;
    u32 _v_32 = 0;
    Term _v_33 = 0;
    u32 _v_34 = 0;
    Term _v_35 = 0;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    Term _o_147[19];
    if (spin_44(e, _o_147, _f_65, blk_loc(e.mem, _f_65), _f_66, blk_loc(e.mem, _f_66), _f_67, blk_loc(e.mem, _f_67), _f_68, blk_loc(e.mem, _f_68), _f_69, blk_loc(e.mem, _f_69), _f_70, blk_loc(e.mem, _f_70), _f_71, _f_72, _f_73, 1ull) == 0) {
      return 0;
    }
    _v_19 = _o_147[0];
    _v_20 = _o_147[1];
    _v_21 = _o_147[2];
    _v_22 = _o_147[3];
    _v_23 = _o_147[4];
    _v_24 = _o_147[5];
    _v_25 = _o_147[6];
    _v_26 = _o_147[7];
    _v_27 = _o_147[8];
    _v_28 = _o_147[9];
    _v_29 = _o_147[10];
    _v_30 = _o_147[11];
    _v_31 = _o_147[12];
    _v_32 = _o_147[13];
    _v_33 = _o_147[14];
    _v_34 = _o_147[15];
    _v_35 = _o_147[16];
    _v_36 = _o_147[17];
    _v_37 = _o_147[18];
    _v_0 = _v_19;
    _v_1 = _v_20;
    _v_2 = _v_21;
    _v_3 = _v_22;
    _v_4 = _v_23;
    _v_5 = _v_24;
    _v_6 = _v_25;
    _v_7 = _v_26;
    _v_8 = _v_27;
    _v_9 = _v_28;
    _v_10 = _v_29;
    _v_11 = _v_30;
    _v_12 = _v_31;
    _v_13 = _v_32;
    _v_14 = _v_33;
    _v_15 = _v_34;
    _v_16 = _v_35;
    _v_17 = _v_36;
    _v_18 = _v_37;
    u32 _o_148 = 0;
    u32 _o_149 = 0;
    u32 _o_150 = 0;
    Term _o_151 = 0;
    u32 _o_152 = 0;
    u32 _o_153 = 0;
    Term _o_154 = 0;
    u32 _o_155 = 0;
    u32 _o_156 = 0;
    u32 _o_157 = 0;
    u32 _o_158 = 0;
    if (_v_9 == 0) {
      _o_148 = 0;
    } else {
      _o_148 = 1;
      u32 _o_159 = 0;
      Term _o_160 = 0;
      u32 _o_161 = 0;
      if (_v_11 == 0) {
        _o_159 = 0;
      } else {
        _o_159 = 1;
        Term _fb_16[2];
        u64 _sp_16 = ctr_take(e, _v_12, 2, _fb_16);
        Term _f_78 = _fb_16[0];
        u32 _f_79 = _fb_16[1];
        spare_free(e, cls_fit(2), _sp_16);
        _o_160 = _f_78;
        _o_161 = _f_79;
      }
      u32 _o_162 = 0;
      Term _o_163 = 0;
      u32 _o_164 = 0;
      if (_v_13 == 0) {
        _o_162 = 0;
      } else {
        _o_162 = 1;
        Term _fb_17[2];
        u64 _sp_17 = ctr_take(e, _v_14, 2, _fb_17);
        Term _f_80 = _fb_17[0];
        u32 _f_81 = _fb_17[1];
        spare_free(e, cls_fit(2), _sp_17);
        _o_163 = _f_80;
        _o_164 = _f_81;
      }
      u32 _o_165 = 0;
      if (_v_15 == 0) {
        _o_165 = 0;
      } else {
        _o_165 = 1;
      }
      _o_149 = _v_10;
      _o_150 = _o_159;
      _o_151 = _o_160;
      _o_152 = _o_161;
      _o_153 = _o_162;
      _o_154 = _o_163;
      _o_155 = _o_164;
      _o_156 = _o_165;
      _o_157 = _v_17;
      _o_158 = _v_18;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K305;
      WL_PUSHN(1);
    } else {
      u64 _t_22 = task_node(e, FID_MAIN_K305, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K305, _t_22);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOOKUP_PRINT)) {
      u64 _t_23 = task_node(e, FID_LOOKUP_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = term_ctr(CID_SCON, STAT_OFF + 218);
      e.mem[_t_23 + 1] = _v_0;
      e.mem[_t_23 + 2] = _v_1;
      e.mem[_t_23 + 3] = _v_2;
      e.mem[_t_23 + 4] = _v_3;
      e.mem[_t_23 + 5] = _v_4;
      e.mem[_t_23 + 6] = _v_5;
      e.mem[_t_23 + 7] = _v_6;
      e.mem[_t_23 + 8] = _v_7;
      e.mem[_t_23 + 9] = _v_8;
      e.mem[_t_23 + 10] = _o_148;
      e.mem[_t_23 + 11] = _o_149;
      e.mem[_t_23 + 12] = _o_150;
      e.mem[_t_23 + 13] = _o_151;
      e.mem[_t_23 + 14] = _o_152;
      e.mem[_t_23 + 15] = _o_153;
      e.mem[_t_23 + 16] = _o_154;
      e.mem[_t_23 + 17] = _o_155;
      e.mem[_t_23 + 18] = _o_156;
      e.mem[_t_23 + 19] = _o_157;
      e.mem[_t_23 + 20] = _o_158;
      return term_tsk(FID_LOOKUP_PRINT, _t_23);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 218);
    r1 = _v_0;
    r2 = _v_1;
    r3 = _v_2;
    r4 = _v_3;
    r5 = _v_4;
    r6 = _v_5;
    r7 = _v_6;
    r8 = _v_7;
    r9 = _v_8;
    r10 = _o_148;
    r11 = _o_149;
    r12 = _o_150;
    r13 = _o_151;
    r14 = _o_152;
    r15 = _o_153;
    r16 = _o_154;
    r17 = _o_155;
    r18 = _o_156;
    r19 = _o_157;
    r20 = _o_158;
    WL_JMP(FID_LOOKUP_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K305)
  {
    Term _h_107 = r0;
    WL_OPEN
    u64 _nd_15 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_15 + 0] = _h_107;
    r0 = term_clo(FID_MAIN_C306, _nd_15);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C306)
  {
    Term _h_108 = r0;
    Term _x_12 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_155 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_155 + 0] = _h_108;
      e.mem[_t_155 + 1] = term_clo(FID_MAIN_C307, 0);
      e.mem[_t_155 + 2] = _x_12;
      return term_tsk(FID_IO_BIND, _t_155);
    }
    r0 = _h_108;
    r1 = term_clo(FID_MAIN_C307, 0);
    r2 = _x_12;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C307)
  {
    Term _x_13 = r0;
    WL_OPEN
    Term _fb_18[9];
    u64 _sp_18 = ctr_take(e, _x_13, 9, _fb_18);
    Term _f_82 = _fb_18[0];
    Term _f_83 = _fb_18[1];
    Term _f_84 = _fb_18[2];
    Term _f_85 = _fb_18[3];
    Term _f_86 = _fb_18[4];
    Term _f_87 = _fb_18[5];
    u32 _f_88 = _fb_18[6];
    Term _f_89 = _fb_18[7];
    u32 _f_90 = _fb_18[8];
    spare_free(e, cls_fit(9), _sp_18);
    Term _v_350 = 0;
    Term _v_351 = 0;
    Term _v_352 = 0;
    Term _v_353 = 0;
    Term _v_354 = 0;
    Term _v_355 = 0;
    u32 _v_356 = 0;
    Term _v_357 = 0;
    u32 _v_358 = 0;
    u32 _v_359 = 0;
    u32 _v_360 = 0;
    u32 _v_361 = 0;
    Term _v_362 = 0;
    u32 _v_363 = 0;
    Term _v_364 = 0;
    u32 _v_365 = 0;
    Term _v_366 = 0;
    u32 _v_367 = 0;
    u32 _v_368 = 0;
    Term _v_369 = 0;
    Term _v_370 = 0;
    Term _v_371 = 0;
    Term _v_372 = 0;
    Term _v_373 = 0;
    Term _v_374 = 0;
    u32 _v_375 = 0;
    Term _v_376 = 0;
    u32 _v_377 = 0;
    u32 _v_378 = 0;
    u32 _v_379 = 0;
    u32 _v_380 = 0;
    Term _v_381 = 0;
    u32 _v_382 = 0;
    Term _v_383 = 0;
    u32 _v_384 = 0;
    Term _v_385 = 0;
    u32 _v_386 = 0;
    u32 _v_387 = 0;
    Term _o_166[19];
    if (spin_44(e, _o_166, _f_82, blk_loc(e.mem, _f_82), _f_83, blk_loc(e.mem, _f_83), _f_84, blk_loc(e.mem, _f_84), _f_85, blk_loc(e.mem, _f_85), _f_86, blk_loc(e.mem, _f_86), _f_87, blk_loc(e.mem, _f_87), _f_88, _f_89, _f_90, 2ull) == 0) {
      return 0;
    }
    _v_369 = _o_166[0];
    _v_370 = _o_166[1];
    _v_371 = _o_166[2];
    _v_372 = _o_166[3];
    _v_373 = _o_166[4];
    _v_374 = _o_166[5];
    _v_375 = _o_166[6];
    _v_376 = _o_166[7];
    _v_377 = _o_166[8];
    _v_378 = _o_166[9];
    _v_379 = _o_166[10];
    _v_380 = _o_166[11];
    _v_381 = _o_166[12];
    _v_382 = _o_166[13];
    _v_383 = _o_166[14];
    _v_384 = _o_166[15];
    _v_385 = _o_166[16];
    _v_386 = _o_166[17];
    _v_387 = _o_166[18];
    _v_350 = _v_369;
    _v_351 = _v_370;
    _v_352 = _v_371;
    _v_353 = _v_372;
    _v_354 = _v_373;
    _v_355 = _v_374;
    _v_356 = _v_375;
    _v_357 = _v_376;
    _v_358 = _v_377;
    _v_359 = _v_378;
    _v_360 = _v_379;
    _v_361 = _v_380;
    _v_362 = _v_381;
    _v_363 = _v_382;
    _v_364 = _v_383;
    _v_365 = _v_384;
    _v_366 = _v_385;
    _v_367 = _v_386;
    _v_368 = _v_387;
    u32 _o_167 = 0;
    u32 _o_168 = 0;
    u32 _o_169 = 0;
    Term _o_170 = 0;
    u32 _o_171 = 0;
    u32 _o_172 = 0;
    Term _o_173 = 0;
    u32 _o_174 = 0;
    u32 _o_175 = 0;
    u32 _o_176 = 0;
    u32 _o_177 = 0;
    if (_v_359 == 0) {
      _o_167 = 0;
    } else {
      _o_167 = 1;
      u32 _o_178 = 0;
      Term _o_179 = 0;
      u32 _o_180 = 0;
      if (_v_361 == 0) {
        _o_178 = 0;
      } else {
        _o_178 = 1;
        Term _fb_19[2];
        u64 _sp_19 = ctr_take(e, _v_362, 2, _fb_19);
        Term _f_91 = _fb_19[0];
        u32 _f_92 = _fb_19[1];
        spare_free(e, cls_fit(2), _sp_19);
        _o_179 = _f_91;
        _o_180 = _f_92;
      }
      u32 _o_181 = 0;
      Term _o_182 = 0;
      u32 _o_183 = 0;
      if (_v_363 == 0) {
        _o_181 = 0;
      } else {
        _o_181 = 1;
        Term _fb_20[2];
        u64 _sp_20 = ctr_take(e, _v_364, 2, _fb_20);
        Term _f_93 = _fb_20[0];
        u32 _f_94 = _fb_20[1];
        spare_free(e, cls_fit(2), _sp_20);
        _o_182 = _f_93;
        _o_183 = _f_94;
      }
      u32 _o_184 = 0;
      if (_v_365 == 0) {
        _o_184 = 0;
      } else {
        _o_184 = 1;
      }
      _o_168 = _v_360;
      _o_169 = _o_178;
      _o_170 = _o_179;
      _o_171 = _o_180;
      _o_172 = _o_181;
      _o_173 = _o_182;
      _o_174 = _o_183;
      _o_175 = _o_184;
      _o_176 = _v_367;
      _o_177 = _v_368;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K308;
      WL_PUSHN(1);
    } else {
      u64 _t_24 = task_node(e, FID_MAIN_K308, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K308, _t_24);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOOKUP_PRINT)) {
      u64 _t_25 = task_node(e, FID_LOOKUP_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = term_ctr(CID_SCON, STAT_OFF + 232);
      e.mem[_t_25 + 1] = _v_350;
      e.mem[_t_25 + 2] = _v_351;
      e.mem[_t_25 + 3] = _v_352;
      e.mem[_t_25 + 4] = _v_353;
      e.mem[_t_25 + 5] = _v_354;
      e.mem[_t_25 + 6] = _v_355;
      e.mem[_t_25 + 7] = _v_356;
      e.mem[_t_25 + 8] = _v_357;
      e.mem[_t_25 + 9] = _v_358;
      e.mem[_t_25 + 10] = _o_167;
      e.mem[_t_25 + 11] = _o_168;
      e.mem[_t_25 + 12] = _o_169;
      e.mem[_t_25 + 13] = _o_170;
      e.mem[_t_25 + 14] = _o_171;
      e.mem[_t_25 + 15] = _o_172;
      e.mem[_t_25 + 16] = _o_173;
      e.mem[_t_25 + 17] = _o_174;
      e.mem[_t_25 + 18] = _o_175;
      e.mem[_t_25 + 19] = _o_176;
      e.mem[_t_25 + 20] = _o_177;
      return term_tsk(FID_LOOKUP_PRINT, _t_25);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 232);
    r1 = _v_350;
    r2 = _v_351;
    r3 = _v_352;
    r4 = _v_353;
    r5 = _v_354;
    r6 = _v_355;
    r7 = _v_356;
    r8 = _v_357;
    r9 = _v_358;
    r10 = _o_167;
    r11 = _o_168;
    r12 = _o_169;
    r13 = _o_170;
    r14 = _o_171;
    r15 = _o_172;
    r16 = _o_173;
    r17 = _o_174;
    r18 = _o_175;
    r19 = _o_176;
    r20 = _o_177;
    WL_JMP(FID_LOOKUP_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K308)
  {
    Term _h_109 = r0;
    WL_OPEN
    u64 _nd_16 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_16 + 0] = _h_109;
    r0 = term_clo(FID_MAIN_C309, _nd_16);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C309)
  {
    Term _h_110 = r0;
    Term _x_14 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_154 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_154 + 0] = _h_110;
      e.mem[_t_154 + 1] = term_clo(FID_MAIN_C310, 0);
      e.mem[_t_154 + 2] = _x_14;
      return term_tsk(FID_IO_BIND, _t_154);
    }
    r0 = _h_110;
    r1 = term_clo(FID_MAIN_C310, 0);
    r2 = _x_14;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C310)
  {
    Term _x_15 = r0;
    WL_OPEN
    Term _fb_21[9];
    u64 _sp_21 = ctr_take(e, _x_15, 9, _fb_21);
    Term _f_95 = _fb_21[0];
    Term _f_96 = _fb_21[1];
    Term _f_97 = _fb_21[2];
    Term _f_98 = _fb_21[3];
    Term _f_99 = _fb_21[4];
    Term _f_100 = _fb_21[5];
    u32 _f_101 = _fb_21[6];
    Term _f_102 = _fb_21[7];
    u32 _f_103 = _fb_21[8];
    spare_free(e, cls_fit(9), _sp_21);
    Term _v_388 = 0;
    Term _v_389 = 0;
    Term _v_390 = 0;
    Term _v_391 = 0;
    Term _v_392 = 0;
    Term _v_393 = 0;
    u32 _v_394 = 0;
    Term _v_395 = 0;
    u32 _v_396 = 0;
    u32 _v_397 = 0;
    u32 _v_398 = 0;
    u32 _v_399 = 0;
    Term _v_400 = 0;
    u32 _v_401 = 0;
    Term _v_402 = 0;
    u32 _v_403 = 0;
    Term _v_404 = 0;
    u32 _v_405 = 0;
    u32 _v_406 = 0;
    Term _v_407 = 0;
    Term _v_408 = 0;
    Term _v_409 = 0;
    Term _v_410 = 0;
    Term _v_411 = 0;
    Term _v_412 = 0;
    u32 _v_413 = 0;
    Term _v_414 = 0;
    u32 _v_415 = 0;
    u32 _v_416 = 0;
    u32 _v_417 = 0;
    u32 _v_418 = 0;
    Term _v_419 = 0;
    u32 _v_420 = 0;
    Term _v_421 = 0;
    u32 _v_422 = 0;
    Term _v_423 = 0;
    u32 _v_424 = 0;
    u32 _v_425 = 0;
    Term _o_185[19];
    if (spin_44(e, _o_185, _f_95, blk_loc(e.mem, _f_95), _f_96, blk_loc(e.mem, _f_96), _f_97, blk_loc(e.mem, _f_97), _f_98, blk_loc(e.mem, _f_98), _f_99, blk_loc(e.mem, _f_99), _f_100, blk_loc(e.mem, _f_100), _f_101, _f_102, _f_103, 4ull) == 0) {
      return 0;
    }
    _v_407 = _o_185[0];
    _v_408 = _o_185[1];
    _v_409 = _o_185[2];
    _v_410 = _o_185[3];
    _v_411 = _o_185[4];
    _v_412 = _o_185[5];
    _v_413 = _o_185[6];
    _v_414 = _o_185[7];
    _v_415 = _o_185[8];
    _v_416 = _o_185[9];
    _v_417 = _o_185[10];
    _v_418 = _o_185[11];
    _v_419 = _o_185[12];
    _v_420 = _o_185[13];
    _v_421 = _o_185[14];
    _v_422 = _o_185[15];
    _v_423 = _o_185[16];
    _v_424 = _o_185[17];
    _v_425 = _o_185[18];
    _v_388 = _v_407;
    _v_389 = _v_408;
    _v_390 = _v_409;
    _v_391 = _v_410;
    _v_392 = _v_411;
    _v_393 = _v_412;
    _v_394 = _v_413;
    _v_395 = _v_414;
    _v_396 = _v_415;
    _v_397 = _v_416;
    _v_398 = _v_417;
    _v_399 = _v_418;
    _v_400 = _v_419;
    _v_401 = _v_420;
    _v_402 = _v_421;
    _v_403 = _v_422;
    _v_404 = _v_423;
    _v_405 = _v_424;
    _v_406 = _v_425;
    u32 _o_186 = 0;
    u32 _o_187 = 0;
    u32 _o_188 = 0;
    Term _o_189 = 0;
    u32 _o_190 = 0;
    u32 _o_191 = 0;
    Term _o_192 = 0;
    u32 _o_193 = 0;
    u32 _o_194 = 0;
    u32 _o_195 = 0;
    u32 _o_196 = 0;
    if (_v_397 == 0) {
      _o_186 = 0;
    } else {
      _o_186 = 1;
      u32 _o_197 = 0;
      Term _o_198 = 0;
      u32 _o_199 = 0;
      if (_v_399 == 0) {
        _o_197 = 0;
      } else {
        _o_197 = 1;
        Term _fb_22[2];
        u64 _sp_22 = ctr_take(e, _v_400, 2, _fb_22);
        Term _f_104 = _fb_22[0];
        u32 _f_105 = _fb_22[1];
        spare_free(e, cls_fit(2), _sp_22);
        _o_198 = _f_104;
        _o_199 = _f_105;
      }
      u32 _o_200 = 0;
      Term _o_201 = 0;
      u32 _o_202 = 0;
      if (_v_401 == 0) {
        _o_200 = 0;
      } else {
        _o_200 = 1;
        Term _fb_23[2];
        u64 _sp_23 = ctr_take(e, _v_402, 2, _fb_23);
        Term _f_106 = _fb_23[0];
        u32 _f_107 = _fb_23[1];
        spare_free(e, cls_fit(2), _sp_23);
        _o_201 = _f_106;
        _o_202 = _f_107;
      }
      u32 _o_203 = 0;
      if (_v_403 == 0) {
        _o_203 = 0;
      } else {
        _o_203 = 1;
      }
      _o_187 = _v_398;
      _o_188 = _o_197;
      _o_189 = _o_198;
      _o_190 = _o_199;
      _o_191 = _o_200;
      _o_192 = _o_201;
      _o_193 = _o_202;
      _o_194 = _o_203;
      _o_195 = _v_405;
      _o_196 = _v_406;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K311;
      WL_PUSHN(1);
    } else {
      u64 _t_26 = task_node(e, FID_MAIN_K311, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K311, _t_26);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOOKUP_PRINT)) {
      u64 _t_27 = task_node(e, FID_LOOKUP_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_27 + 0] = term_ctr(CID_SCON, STAT_OFF + 242);
      e.mem[_t_27 + 1] = _v_388;
      e.mem[_t_27 + 2] = _v_389;
      e.mem[_t_27 + 3] = _v_390;
      e.mem[_t_27 + 4] = _v_391;
      e.mem[_t_27 + 5] = _v_392;
      e.mem[_t_27 + 6] = _v_393;
      e.mem[_t_27 + 7] = _v_394;
      e.mem[_t_27 + 8] = _v_395;
      e.mem[_t_27 + 9] = _v_396;
      e.mem[_t_27 + 10] = _o_186;
      e.mem[_t_27 + 11] = _o_187;
      e.mem[_t_27 + 12] = _o_188;
      e.mem[_t_27 + 13] = _o_189;
      e.mem[_t_27 + 14] = _o_190;
      e.mem[_t_27 + 15] = _o_191;
      e.mem[_t_27 + 16] = _o_192;
      e.mem[_t_27 + 17] = _o_193;
      e.mem[_t_27 + 18] = _o_194;
      e.mem[_t_27 + 19] = _o_195;
      e.mem[_t_27 + 20] = _o_196;
      return term_tsk(FID_LOOKUP_PRINT, _t_27);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 242);
    r1 = _v_388;
    r2 = _v_389;
    r3 = _v_390;
    r4 = _v_391;
    r5 = _v_392;
    r6 = _v_393;
    r7 = _v_394;
    r8 = _v_395;
    r9 = _v_396;
    r10 = _o_186;
    r11 = _o_187;
    r12 = _o_188;
    r13 = _o_189;
    r14 = _o_190;
    r15 = _o_191;
    r16 = _o_192;
    r17 = _o_193;
    r18 = _o_194;
    r19 = _o_195;
    r20 = _o_196;
    WL_JMP(FID_LOOKUP_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K311)
  {
    Term _h_111 = r0;
    WL_OPEN
    u64 _nd_17 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_17 + 0] = _h_111;
    r0 = term_clo(FID_MAIN_C312, _nd_17);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C312)
  {
    Term _h_112 = r0;
    Term _x_16 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_153 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_153 + 0] = _h_112;
      e.mem[_t_153 + 1] = term_clo(FID_MAIN_C313, 0);
      e.mem[_t_153 + 2] = _x_16;
      return term_tsk(FID_IO_BIND, _t_153);
    }
    r0 = _h_112;
    r1 = term_clo(FID_MAIN_C313, 0);
    r2 = _x_16;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C313)
  {
    Term _x_17 = r0;
    WL_OPEN
    Term _fb_24[9];
    u64 _sp_24 = ctr_take(e, _x_17, 9, _fb_24);
    Term _f_108 = _fb_24[0];
    Term _f_109 = _fb_24[1];
    Term _f_110 = _fb_24[2];
    Term _f_111 = _fb_24[3];
    Term _f_112 = _fb_24[4];
    Term _f_113 = _fb_24[5];
    u32 _f_114 = _fb_24[6];
    Term _f_115 = _fb_24[7];
    u32 _f_116 = _fb_24[8];
    spare_free(e, cls_fit(9), _sp_24);
    Term _v_426 = 0;
    Term _v_427 = 0;
    Term _v_428 = 0;
    Term _v_429 = 0;
    Term _v_430 = 0;
    Term _v_431 = 0;
    u32 _v_432 = 0;
    Term _v_433 = 0;
    u32 _v_434 = 0;
    u32 _v_435 = 0;
    u32 _v_436 = 0;
    u32 _v_437 = 0;
    Term _v_438 = 0;
    u32 _v_439 = 0;
    Term _v_440 = 0;
    u32 _v_441 = 0;
    Term _v_442 = 0;
    u32 _v_443 = 0;
    u32 _v_444 = 0;
    Term _v_445 = 0;
    Term _v_446 = 0;
    Term _v_447 = 0;
    Term _v_448 = 0;
    Term _v_449 = 0;
    Term _v_450 = 0;
    u32 _v_451 = 0;
    Term _v_452 = 0;
    u32 _v_453 = 0;
    u32 _v_454 = 0;
    u32 _v_455 = 0;
    u32 _v_456 = 0;
    Term _v_457 = 0;
    u32 _v_458 = 0;
    Term _v_459 = 0;
    u32 _v_460 = 0;
    Term _v_461 = 0;
    u32 _v_462 = 0;
    u32 _v_463 = 0;
    Term _o_204[19];
    if (spin_44(e, _o_204, _f_108, blk_loc(e.mem, _f_108), _f_109, blk_loc(e.mem, _f_109), _f_110, blk_loc(e.mem, _f_110), _f_111, blk_loc(e.mem, _f_111), _f_112, blk_loc(e.mem, _f_112), _f_113, blk_loc(e.mem, _f_113), _f_114, _f_115, _f_116, 8ull) == 0) {
      return 0;
    }
    _v_445 = _o_204[0];
    _v_446 = _o_204[1];
    _v_447 = _o_204[2];
    _v_448 = _o_204[3];
    _v_449 = _o_204[4];
    _v_450 = _o_204[5];
    _v_451 = _o_204[6];
    _v_452 = _o_204[7];
    _v_453 = _o_204[8];
    _v_454 = _o_204[9];
    _v_455 = _o_204[10];
    _v_456 = _o_204[11];
    _v_457 = _o_204[12];
    _v_458 = _o_204[13];
    _v_459 = _o_204[14];
    _v_460 = _o_204[15];
    _v_461 = _o_204[16];
    _v_462 = _o_204[17];
    _v_463 = _o_204[18];
    _v_426 = _v_445;
    _v_427 = _v_446;
    _v_428 = _v_447;
    _v_429 = _v_448;
    _v_430 = _v_449;
    _v_431 = _v_450;
    _v_432 = _v_451;
    _v_433 = _v_452;
    _v_434 = _v_453;
    _v_435 = _v_454;
    _v_436 = _v_455;
    _v_437 = _v_456;
    _v_438 = _v_457;
    _v_439 = _v_458;
    _v_440 = _v_459;
    _v_441 = _v_460;
    _v_442 = _v_461;
    _v_443 = _v_462;
    _v_444 = _v_463;
    u32 _o_205 = 0;
    u32 _o_206 = 0;
    u32 _o_207 = 0;
    Term _o_208 = 0;
    u32 _o_209 = 0;
    u32 _o_210 = 0;
    Term _o_211 = 0;
    u32 _o_212 = 0;
    u32 _o_213 = 0;
    u32 _o_214 = 0;
    u32 _o_215 = 0;
    if (_v_435 == 0) {
      _o_205 = 0;
    } else {
      _o_205 = 1;
      u32 _o_216 = 0;
      Term _o_217 = 0;
      u32 _o_218 = 0;
      if (_v_437 == 0) {
        _o_216 = 0;
      } else {
        _o_216 = 1;
        Term _fb_25[2];
        u64 _sp_25 = ctr_take(e, _v_438, 2, _fb_25);
        Term _f_117 = _fb_25[0];
        u32 _f_118 = _fb_25[1];
        spare_free(e, cls_fit(2), _sp_25);
        _o_217 = _f_117;
        _o_218 = _f_118;
      }
      u32 _o_219 = 0;
      Term _o_220 = 0;
      u32 _o_221 = 0;
      if (_v_439 == 0) {
        _o_219 = 0;
      } else {
        _o_219 = 1;
        Term _fb_26[2];
        u64 _sp_26 = ctr_take(e, _v_440, 2, _fb_26);
        Term _f_119 = _fb_26[0];
        u32 _f_120 = _fb_26[1];
        spare_free(e, cls_fit(2), _sp_26);
        _o_220 = _f_119;
        _o_221 = _f_120;
      }
      u32 _o_222 = 0;
      if (_v_441 == 0) {
        _o_222 = 0;
      } else {
        _o_222 = 1;
      }
      _o_206 = _v_436;
      _o_207 = _o_216;
      _o_208 = _o_217;
      _o_209 = _o_218;
      _o_210 = _o_219;
      _o_211 = _o_220;
      _o_212 = _o_221;
      _o_213 = _o_222;
      _o_214 = _v_443;
      _o_215 = _v_444;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K314;
      WL_PUSHN(1);
    } else {
      u64 _t_28 = task_node(e, FID_MAIN_K314, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K314, _t_28);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOOKUP_PRINT)) {
      u64 _t_29 = task_node(e, FID_LOOKUP_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_29 + 0] = term_ctr(CID_SCON, STAT_OFF + 252);
      e.mem[_t_29 + 1] = _v_426;
      e.mem[_t_29 + 2] = _v_427;
      e.mem[_t_29 + 3] = _v_428;
      e.mem[_t_29 + 4] = _v_429;
      e.mem[_t_29 + 5] = _v_430;
      e.mem[_t_29 + 6] = _v_431;
      e.mem[_t_29 + 7] = _v_432;
      e.mem[_t_29 + 8] = _v_433;
      e.mem[_t_29 + 9] = _v_434;
      e.mem[_t_29 + 10] = _o_205;
      e.mem[_t_29 + 11] = _o_206;
      e.mem[_t_29 + 12] = _o_207;
      e.mem[_t_29 + 13] = _o_208;
      e.mem[_t_29 + 14] = _o_209;
      e.mem[_t_29 + 15] = _o_210;
      e.mem[_t_29 + 16] = _o_211;
      e.mem[_t_29 + 17] = _o_212;
      e.mem[_t_29 + 18] = _o_213;
      e.mem[_t_29 + 19] = _o_214;
      e.mem[_t_29 + 20] = _o_215;
      return term_tsk(FID_LOOKUP_PRINT, _t_29);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 252);
    r1 = _v_426;
    r2 = _v_427;
    r3 = _v_428;
    r4 = _v_429;
    r5 = _v_430;
    r6 = _v_431;
    r7 = _v_432;
    r8 = _v_433;
    r9 = _v_434;
    r10 = _o_205;
    r11 = _o_206;
    r12 = _o_207;
    r13 = _o_208;
    r14 = _o_209;
    r15 = _o_210;
    r16 = _o_211;
    r17 = _o_212;
    r18 = _o_213;
    r19 = _o_214;
    r20 = _o_215;
    WL_JMP(FID_LOOKUP_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K314)
  {
    Term _h_113 = r0;
    WL_OPEN
    u64 _nd_18 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_18 + 0] = _h_113;
    r0 = term_clo(FID_MAIN_C315, _nd_18);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C315)
  {
    Term _h_114 = r0;
    Term _x_18 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_152 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_152 + 0] = _h_114;
      e.mem[_t_152 + 1] = term_clo(FID_MAIN_C316, 0);
      e.mem[_t_152 + 2] = _x_18;
      return term_tsk(FID_IO_BIND, _t_152);
    }
    r0 = _h_114;
    r1 = term_clo(FID_MAIN_C316, 0);
    r2 = _x_18;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C316)
  {
    Term _x_19 = r0;
    WL_OPEN
    Term _fb_27[9];
    u64 _sp_27 = ctr_take(e, _x_19, 9, _fb_27);
    Term _f_121 = _fb_27[0];
    Term _f_122 = _fb_27[1];
    Term _f_123 = _fb_27[2];
    Term _f_124 = _fb_27[3];
    Term _f_125 = _fb_27[4];
    Term _f_126 = _fb_27[5];
    u32 _f_127 = _fb_27[6];
    Term _f_128 = _fb_27[7];
    u32 _f_129 = _fb_27[8];
    spare_free(e, cls_fit(9), _sp_27);
    Term _v_464 = 0;
    Term _v_465 = 0;
    Term _v_466 = 0;
    Term _v_467 = 0;
    Term _v_468 = 0;
    Term _v_469 = 0;
    u32 _v_470 = 0;
    Term _v_471 = 0;
    u32 _v_472 = 0;
    u32 _v_473 = 0;
    u32 _v_474 = 0;
    u32 _v_475 = 0;
    Term _v_476 = 0;
    u32 _v_477 = 0;
    Term _v_478 = 0;
    u32 _v_479 = 0;
    Term _v_480 = 0;
    u32 _v_481 = 0;
    u32 _v_482 = 0;
    Term _v_483 = 0;
    Term _v_484 = 0;
    Term _v_485 = 0;
    Term _v_486 = 0;
    Term _v_487 = 0;
    Term _v_488 = 0;
    u32 _v_489 = 0;
    Term _v_490 = 0;
    u32 _v_491 = 0;
    u32 _v_492 = 0;
    u32 _v_493 = 0;
    u32 _v_494 = 0;
    Term _v_495 = 0;
    u32 _v_496 = 0;
    Term _v_497 = 0;
    u32 _v_498 = 0;
    Term _v_499 = 0;
    u32 _v_500 = 0;
    u32 _v_501 = 0;
    Term _o_223[19];
    if (spin_44(e, _o_223, _f_121, blk_loc(e.mem, _f_121), _f_122, blk_loc(e.mem, _f_122), _f_123, blk_loc(e.mem, _f_123), _f_124, blk_loc(e.mem, _f_124), _f_125, blk_loc(e.mem, _f_125), _f_126, blk_loc(e.mem, _f_126), _f_127, _f_128, _f_129, 65537ull) == 0) {
      return 0;
    }
    _v_483 = _o_223[0];
    _v_484 = _o_223[1];
    _v_485 = _o_223[2];
    _v_486 = _o_223[3];
    _v_487 = _o_223[4];
    _v_488 = _o_223[5];
    _v_489 = _o_223[6];
    _v_490 = _o_223[7];
    _v_491 = _o_223[8];
    _v_492 = _o_223[9];
    _v_493 = _o_223[10];
    _v_494 = _o_223[11];
    _v_495 = _o_223[12];
    _v_496 = _o_223[13];
    _v_497 = _o_223[14];
    _v_498 = _o_223[15];
    _v_499 = _o_223[16];
    _v_500 = _o_223[17];
    _v_501 = _o_223[18];
    _v_464 = _v_483;
    _v_465 = _v_484;
    _v_466 = _v_485;
    _v_467 = _v_486;
    _v_468 = _v_487;
    _v_469 = _v_488;
    _v_470 = _v_489;
    _v_471 = _v_490;
    _v_472 = _v_491;
    _v_473 = _v_492;
    _v_474 = _v_493;
    _v_475 = _v_494;
    _v_476 = _v_495;
    _v_477 = _v_496;
    _v_478 = _v_497;
    _v_479 = _v_498;
    _v_480 = _v_499;
    _v_481 = _v_500;
    _v_482 = _v_501;
    u32 _o_224 = 0;
    u32 _o_225 = 0;
    u32 _o_226 = 0;
    Term _o_227 = 0;
    u32 _o_228 = 0;
    u32 _o_229 = 0;
    Term _o_230 = 0;
    u32 _o_231 = 0;
    u32 _o_232 = 0;
    u32 _o_233 = 0;
    u32 _o_234 = 0;
    if (_v_473 == 0) {
      _o_224 = 0;
    } else {
      _o_224 = 1;
      u32 _o_235 = 0;
      Term _o_236 = 0;
      u32 _o_237 = 0;
      if (_v_475 == 0) {
        _o_235 = 0;
      } else {
        _o_235 = 1;
        Term _fb_28[2];
        u64 _sp_28 = ctr_take(e, _v_476, 2, _fb_28);
        Term _f_130 = _fb_28[0];
        u32 _f_131 = _fb_28[1];
        spare_free(e, cls_fit(2), _sp_28);
        _o_236 = _f_130;
        _o_237 = _f_131;
      }
      u32 _o_238 = 0;
      Term _o_239 = 0;
      u32 _o_240 = 0;
      if (_v_477 == 0) {
        _o_238 = 0;
      } else {
        _o_238 = 1;
        Term _fb_29[2];
        u64 _sp_29 = ctr_take(e, _v_478, 2, _fb_29);
        Term _f_132 = _fb_29[0];
        u32 _f_133 = _fb_29[1];
        spare_free(e, cls_fit(2), _sp_29);
        _o_239 = _f_132;
        _o_240 = _f_133;
      }
      u32 _o_241 = 0;
      if (_v_479 == 0) {
        _o_241 = 0;
      } else {
        _o_241 = 1;
      }
      _o_225 = _v_474;
      _o_226 = _o_235;
      _o_227 = _o_236;
      _o_228 = _o_237;
      _o_229 = _o_238;
      _o_230 = _o_239;
      _o_231 = _o_240;
      _o_232 = _o_241;
      _o_233 = _v_481;
      _o_234 = _v_482;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K317;
      WL_PUSHN(1);
    } else {
      u64 _t_30 = task_node(e, FID_MAIN_K317, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K317, _t_30);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOOKUP_PRINT)) {
      u64 _t_31 = task_node(e, FID_LOOKUP_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_31 + 0] = term_ctr(CID_SCON, STAT_OFF + 246);
      e.mem[_t_31 + 1] = _v_464;
      e.mem[_t_31 + 2] = _v_465;
      e.mem[_t_31 + 3] = _v_466;
      e.mem[_t_31 + 4] = _v_467;
      e.mem[_t_31 + 5] = _v_468;
      e.mem[_t_31 + 6] = _v_469;
      e.mem[_t_31 + 7] = _v_470;
      e.mem[_t_31 + 8] = _v_471;
      e.mem[_t_31 + 9] = _v_472;
      e.mem[_t_31 + 10] = _o_224;
      e.mem[_t_31 + 11] = _o_225;
      e.mem[_t_31 + 12] = _o_226;
      e.mem[_t_31 + 13] = _o_227;
      e.mem[_t_31 + 14] = _o_228;
      e.mem[_t_31 + 15] = _o_229;
      e.mem[_t_31 + 16] = _o_230;
      e.mem[_t_31 + 17] = _o_231;
      e.mem[_t_31 + 18] = _o_232;
      e.mem[_t_31 + 19] = _o_233;
      e.mem[_t_31 + 20] = _o_234;
      return term_tsk(FID_LOOKUP_PRINT, _t_31);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 246);
    r1 = _v_464;
    r2 = _v_465;
    r3 = _v_466;
    r4 = _v_467;
    r5 = _v_468;
    r6 = _v_469;
    r7 = _v_470;
    r8 = _v_471;
    r9 = _v_472;
    r10 = _o_224;
    r11 = _o_225;
    r12 = _o_226;
    r13 = _o_227;
    r14 = _o_228;
    r15 = _o_229;
    r16 = _o_230;
    r17 = _o_231;
    r18 = _o_232;
    r19 = _o_233;
    r20 = _o_234;
    WL_JMP(FID_LOOKUP_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K317)
  {
    Term _h_115 = r0;
    WL_OPEN
    u64 _nd_19 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_19 + 0] = _h_115;
    r0 = term_clo(FID_MAIN_C318, _nd_19);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C318)
  {
    Term _h_116 = r0;
    Term _x_20 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_151 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_151 + 0] = _h_116;
      e.mem[_t_151 + 1] = term_clo(FID_MAIN_C319, 0);
      e.mem[_t_151 + 2] = _x_20;
      return term_tsk(FID_IO_BIND, _t_151);
    }
    r0 = _h_116;
    r1 = term_clo(FID_MAIN_C319, 0);
    r2 = _x_20;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C319)
  {
    Term _x_21 = r0;
    WL_OPEN
    Term _fb_30[9];
    u64 _sp_30 = ctr_take(e, _x_21, 9, _fb_30);
    Term _f_134 = _fb_30[0];
    Term _f_135 = _fb_30[1];
    Term _f_136 = _fb_30[2];
    Term _f_137 = _fb_30[3];
    Term _f_138 = _fb_30[4];
    Term _f_139 = _fb_30[5];
    u32 _f_140 = _fb_30[6];
    Term _f_141 = _fb_30[7];
    u32 _f_142 = _fb_30[8];
    spare_free(e, cls_fit(9), _sp_30);
    Term _v_502 = 0;
    Term _v_503 = 0;
    Term _v_504 = 0;
    Term _v_505 = 0;
    Term _v_506 = 0;
    Term _v_507 = 0;
    u32 _v_508 = 0;
    Term _v_509 = 0;
    u32 _v_510 = 0;
    u32 _v_511 = 0;
    u32 _v_512 = 0;
    u32 _v_513 = 0;
    Term _v_514 = 0;
    u32 _v_515 = 0;
    Term _v_516 = 0;
    u32 _v_517 = 0;
    Term _v_518 = 0;
    u32 _v_519 = 0;
    u32 _v_520 = 0;
    Term _v_521 = 0;
    Term _v_522 = 0;
    Term _v_523 = 0;
    Term _v_524 = 0;
    Term _v_525 = 0;
    Term _v_526 = 0;
    u32 _v_527 = 0;
    Term _v_528 = 0;
    u32 _v_529 = 0;
    u32 _v_530 = 0;
    u32 _v_531 = 0;
    u32 _v_532 = 0;
    Term _v_533 = 0;
    u32 _v_534 = 0;
    Term _v_535 = 0;
    u32 _v_536 = 0;
    Term _v_537 = 0;
    u32 _v_538 = 0;
    u32 _v_539 = 0;
    Term _o_242[19];
    if (spin_44(e, _o_242, _f_134, blk_loc(e.mem, _f_134), _f_135, blk_loc(e.mem, _f_135), _f_136, blk_loc(e.mem, _f_136), _f_137, blk_loc(e.mem, _f_137), _f_138, blk_loc(e.mem, _f_138), _f_139, blk_loc(e.mem, _f_139), _f_140, _f_141, _f_142, 0ull) == 0) {
      return 0;
    }
    _v_521 = _o_242[0];
    _v_522 = _o_242[1];
    _v_523 = _o_242[2];
    _v_524 = _o_242[3];
    _v_525 = _o_242[4];
    _v_526 = _o_242[5];
    _v_527 = _o_242[6];
    _v_528 = _o_242[7];
    _v_529 = _o_242[8];
    _v_530 = _o_242[9];
    _v_531 = _o_242[10];
    _v_532 = _o_242[11];
    _v_533 = _o_242[12];
    _v_534 = _o_242[13];
    _v_535 = _o_242[14];
    _v_536 = _o_242[15];
    _v_537 = _o_242[16];
    _v_538 = _o_242[17];
    _v_539 = _o_242[18];
    _v_502 = _v_521;
    _v_503 = _v_522;
    _v_504 = _v_523;
    _v_505 = _v_524;
    _v_506 = _v_525;
    _v_507 = _v_526;
    _v_508 = _v_527;
    _v_509 = _v_528;
    _v_510 = _v_529;
    _v_511 = _v_530;
    _v_512 = _v_531;
    _v_513 = _v_532;
    _v_514 = _v_533;
    _v_515 = _v_534;
    _v_516 = _v_535;
    _v_517 = _v_536;
    _v_518 = _v_537;
    _v_519 = _v_538;
    _v_520 = _v_539;
    u32 _o_243 = 0;
    u32 _o_244 = 0;
    u32 _o_245 = 0;
    Term _o_246 = 0;
    u32 _o_247 = 0;
    u32 _o_248 = 0;
    Term _o_249 = 0;
    u32 _o_250 = 0;
    u32 _o_251 = 0;
    u32 _o_252 = 0;
    u32 _o_253 = 0;
    if (_v_511 == 0) {
      _o_243 = 0;
    } else {
      _o_243 = 1;
      u32 _o_254 = 0;
      Term _o_255 = 0;
      u32 _o_256 = 0;
      if (_v_513 == 0) {
        _o_254 = 0;
      } else {
        _o_254 = 1;
        Term _fb_31[2];
        u64 _sp_31 = ctr_take(e, _v_514, 2, _fb_31);
        Term _f_143 = _fb_31[0];
        u32 _f_144 = _fb_31[1];
        spare_free(e, cls_fit(2), _sp_31);
        _o_255 = _f_143;
        _o_256 = _f_144;
      }
      u32 _o_257 = 0;
      Term _o_258 = 0;
      u32 _o_259 = 0;
      if (_v_515 == 0) {
        _o_257 = 0;
      } else {
        _o_257 = 1;
        Term _fb_32[2];
        u64 _sp_32 = ctr_take(e, _v_516, 2, _fb_32);
        Term _f_145 = _fb_32[0];
        u32 _f_146 = _fb_32[1];
        spare_free(e, cls_fit(2), _sp_32);
        _o_258 = _f_145;
        _o_259 = _f_146;
      }
      u32 _o_260 = 0;
      if (_v_517 == 0) {
        _o_260 = 0;
      } else {
        _o_260 = 1;
      }
      _o_244 = _v_512;
      _o_245 = _o_254;
      _o_246 = _o_255;
      _o_247 = _o_256;
      _o_248 = _o_257;
      _o_249 = _o_258;
      _o_250 = _o_259;
      _o_251 = _o_260;
      _o_252 = _v_519;
      _o_253 = _v_520;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K320;
      WL_PUSHN(1);
    } else {
      u64 _t_32 = task_node(e, FID_MAIN_K320, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K320, _t_32);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOOKUP_PRINT)) {
      u64 _t_33 = task_node(e, FID_LOOKUP_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_33 + 0] = term_ctr(CID_SCON, STAT_OFF + 260);
      e.mem[_t_33 + 1] = _v_502;
      e.mem[_t_33 + 2] = _v_503;
      e.mem[_t_33 + 3] = _v_504;
      e.mem[_t_33 + 4] = _v_505;
      e.mem[_t_33 + 5] = _v_506;
      e.mem[_t_33 + 6] = _v_507;
      e.mem[_t_33 + 7] = _v_508;
      e.mem[_t_33 + 8] = _v_509;
      e.mem[_t_33 + 9] = _v_510;
      e.mem[_t_33 + 10] = _o_243;
      e.mem[_t_33 + 11] = _o_244;
      e.mem[_t_33 + 12] = _o_245;
      e.mem[_t_33 + 13] = _o_246;
      e.mem[_t_33 + 14] = _o_247;
      e.mem[_t_33 + 15] = _o_248;
      e.mem[_t_33 + 16] = _o_249;
      e.mem[_t_33 + 17] = _o_250;
      e.mem[_t_33 + 18] = _o_251;
      e.mem[_t_33 + 19] = _o_252;
      e.mem[_t_33 + 20] = _o_253;
      return term_tsk(FID_LOOKUP_PRINT, _t_33);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 260);
    r1 = _v_502;
    r2 = _v_503;
    r3 = _v_504;
    r4 = _v_505;
    r5 = _v_506;
    r6 = _v_507;
    r7 = _v_508;
    r8 = _v_509;
    r9 = _v_510;
    r10 = _o_243;
    r11 = _o_244;
    r12 = _o_245;
    r13 = _o_246;
    r14 = _o_247;
    r15 = _o_248;
    r16 = _o_249;
    r17 = _o_250;
    r18 = _o_251;
    r19 = _o_252;
    r20 = _o_253;
    WL_JMP(FID_LOOKUP_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K320)
  {
    Term _h_117 = r0;
    WL_OPEN
    u64 _nd_20 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_20 + 0] = _h_117;
    r0 = term_clo(FID_MAIN_C321, _nd_20);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C321)
  {
    Term _h_118 = r0;
    Term _x_22 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_150 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_150 + 0] = _h_118;
      e.mem[_t_150 + 1] = term_clo(FID_MAIN_C322, 0);
      e.mem[_t_150 + 2] = _x_22;
      return term_tsk(FID_IO_BIND, _t_150);
    }
    r0 = _h_118;
    r1 = term_clo(FID_MAIN_C322, 0);
    r2 = _x_22;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C322)
  {
    Term _x_23 = r0;
    WL_OPEN
    Term _fb_33[9];
    u64 _sp_33 = ctr_take(e, _x_23, 9, _fb_33);
    Term _f_147 = _fb_33[0];
    Term _f_148 = _fb_33[1];
    Term _f_149 = _fb_33[2];
    Term _f_150 = _fb_33[3];
    Term _f_151 = _fb_33[4];
    Term _f_152 = _fb_33[5];
    u32 _f_153 = _fb_33[6];
    Term _f_154 = _fb_33[7];
    u32 _f_155 = _fb_33[8];
    spare_free(e, cls_fit(9), _sp_33);
    Term _v_540 = 0;
    Term _v_541 = 0;
    Term _v_542 = 0;
    Term _v_543 = 0;
    Term _v_544 = 0;
    Term _v_545 = 0;
    u32 _v_546 = 0;
    Term _v_547 = 0;
    u32 _v_548 = 0;
    u32 _v_549 = 0;
    u32 _v_550 = 0;
    u32 _v_551 = 0;
    Term _v_552 = 0;
    u32 _v_553 = 0;
    Term _v_554 = 0;
    u32 _v_555 = 0;
    Term _v_556 = 0;
    u32 _v_557 = 0;
    u32 _v_558 = 0;
    Term _v_559 = 0;
    Term _v_560 = 0;
    Term _v_561 = 0;
    Term _v_562 = 0;
    Term _v_563 = 0;
    Term _v_564 = 0;
    u32 _v_565 = 0;
    Term _v_566 = 0;
    u32 _v_567 = 0;
    u32 _v_568 = 0;
    u32 _v_569 = 0;
    u32 _v_570 = 0;
    Term _v_571 = 0;
    u32 _v_572 = 0;
    Term _v_573 = 0;
    u32 _v_574 = 0;
    Term _v_575 = 0;
    u32 _v_576 = 0;
    u32 _v_577 = 0;
    Term _o_261[19];
    if (spin_44(e, _o_261, _f_147, blk_loc(e.mem, _f_147), _f_148, blk_loc(e.mem, _f_148), _f_149, blk_loc(e.mem, _f_149), _f_150, blk_loc(e.mem, _f_150), _f_151, blk_loc(e.mem, _f_151), _f_152, blk_loc(e.mem, _f_152), _f_153, _f_154, _f_155, 3ull) == 0) {
      return 0;
    }
    _v_559 = _o_261[0];
    _v_560 = _o_261[1];
    _v_561 = _o_261[2];
    _v_562 = _o_261[3];
    _v_563 = _o_261[4];
    _v_564 = _o_261[5];
    _v_565 = _o_261[6];
    _v_566 = _o_261[7];
    _v_567 = _o_261[8];
    _v_568 = _o_261[9];
    _v_569 = _o_261[10];
    _v_570 = _o_261[11];
    _v_571 = _o_261[12];
    _v_572 = _o_261[13];
    _v_573 = _o_261[14];
    _v_574 = _o_261[15];
    _v_575 = _o_261[16];
    _v_576 = _o_261[17];
    _v_577 = _o_261[18];
    _v_540 = _v_559;
    _v_541 = _v_560;
    _v_542 = _v_561;
    _v_543 = _v_562;
    _v_544 = _v_563;
    _v_545 = _v_564;
    _v_546 = _v_565;
    _v_547 = _v_566;
    _v_548 = _v_567;
    _v_549 = _v_568;
    _v_550 = _v_569;
    _v_551 = _v_570;
    _v_552 = _v_571;
    _v_553 = _v_572;
    _v_554 = _v_573;
    _v_555 = _v_574;
    _v_556 = _v_575;
    _v_557 = _v_576;
    _v_558 = _v_577;
    u32 _o_262 = 0;
    u32 _o_263 = 0;
    u32 _o_264 = 0;
    Term _o_265 = 0;
    u32 _o_266 = 0;
    u32 _o_267 = 0;
    Term _o_268 = 0;
    u32 _o_269 = 0;
    u32 _o_270 = 0;
    u32 _o_271 = 0;
    u32 _o_272 = 0;
    if (_v_549 == 0) {
      _o_262 = 0;
    } else {
      _o_262 = 1;
      u32 _o_273 = 0;
      Term _o_274 = 0;
      u32 _o_275 = 0;
      if (_v_551 == 0) {
        _o_273 = 0;
      } else {
        _o_273 = 1;
        Term _fb_34[2];
        u64 _sp_34 = ctr_take(e, _v_552, 2, _fb_34);
        Term _f_156 = _fb_34[0];
        u32 _f_157 = _fb_34[1];
        spare_free(e, cls_fit(2), _sp_34);
        _o_274 = _f_156;
        _o_275 = _f_157;
      }
      u32 _o_276 = 0;
      Term _o_277 = 0;
      u32 _o_278 = 0;
      if (_v_553 == 0) {
        _o_276 = 0;
      } else {
        _o_276 = 1;
        Term _fb_35[2];
        u64 _sp_35 = ctr_take(e, _v_554, 2, _fb_35);
        Term _f_158 = _fb_35[0];
        u32 _f_159 = _fb_35[1];
        spare_free(e, cls_fit(2), _sp_35);
        _o_277 = _f_158;
        _o_278 = _f_159;
      }
      u32 _o_279 = 0;
      if (_v_555 == 0) {
        _o_279 = 0;
      } else {
        _o_279 = 1;
      }
      _o_263 = _v_550;
      _o_264 = _o_273;
      _o_265 = _o_274;
      _o_266 = _o_275;
      _o_267 = _o_276;
      _o_268 = _o_277;
      _o_269 = _o_278;
      _o_270 = _o_279;
      _o_271 = _v_557;
      _o_272 = _v_558;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K323;
      WL_PUSHN(1);
    } else {
      u64 _t_34 = task_node(e, FID_MAIN_K323, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K323, _t_34);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOOKUP_PRINT)) {
      u64 _t_35 = task_node(e, FID_LOOKUP_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_35 + 0] = term_ctr(CID_SCON, STAT_OFF + 264);
      e.mem[_t_35 + 1] = _v_540;
      e.mem[_t_35 + 2] = _v_541;
      e.mem[_t_35 + 3] = _v_542;
      e.mem[_t_35 + 4] = _v_543;
      e.mem[_t_35 + 5] = _v_544;
      e.mem[_t_35 + 6] = _v_545;
      e.mem[_t_35 + 7] = _v_546;
      e.mem[_t_35 + 8] = _v_547;
      e.mem[_t_35 + 9] = _v_548;
      e.mem[_t_35 + 10] = _o_262;
      e.mem[_t_35 + 11] = _o_263;
      e.mem[_t_35 + 12] = _o_264;
      e.mem[_t_35 + 13] = _o_265;
      e.mem[_t_35 + 14] = _o_266;
      e.mem[_t_35 + 15] = _o_267;
      e.mem[_t_35 + 16] = _o_268;
      e.mem[_t_35 + 17] = _o_269;
      e.mem[_t_35 + 18] = _o_270;
      e.mem[_t_35 + 19] = _o_271;
      e.mem[_t_35 + 20] = _o_272;
      return term_tsk(FID_LOOKUP_PRINT, _t_35);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 264);
    r1 = _v_540;
    r2 = _v_541;
    r3 = _v_542;
    r4 = _v_543;
    r5 = _v_544;
    r6 = _v_545;
    r7 = _v_546;
    r8 = _v_547;
    r9 = _v_548;
    r10 = _o_262;
    r11 = _o_263;
    r12 = _o_264;
    r13 = _o_265;
    r14 = _o_266;
    r15 = _o_267;
    r16 = _o_268;
    r17 = _o_269;
    r18 = _o_270;
    r19 = _o_271;
    r20 = _o_272;
    WL_JMP(FID_LOOKUP_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K323)
  {
    Term _h_119 = r0;
    WL_OPEN
    u64 _nd_21 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_21 + 0] = _h_119;
    r0 = term_clo(FID_MAIN_C324, _nd_21);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C324)
  {
    Term _h_120 = r0;
    Term _x_24 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_149 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_149 + 0] = _h_120;
      e.mem[_t_149 + 1] = term_clo(FID_MAIN_C325, 0);
      e.mem[_t_149 + 2] = _x_24;
      return term_tsk(FID_IO_BIND, _t_149);
    }
    r0 = _h_120;
    r1 = term_clo(FID_MAIN_C325, 0);
    r2 = _x_24;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C325)
  {
    Term _x_25 = r0;
    WL_OPEN
    Term _fb_36[9];
    u64 _sp_36 = ctr_take(e, _x_25, 9, _fb_36);
    Term _f_160 = _fb_36[0];
    Term _f_161 = _fb_36[1];
    Term _f_162 = _fb_36[2];
    Term _f_163 = _fb_36[3];
    Term _f_164 = _fb_36[4];
    Term _f_165 = _fb_36[5];
    u32 _f_166 = _fb_36[6];
    Term _f_167 = _fb_36[7];
    u32 _f_168 = _fb_36[8];
    spare_free(e, cls_fit(9), _sp_36);
    Term _v_578 = 0;
    Term _v_579 = 0;
    Term _v_580 = 0;
    Term _v_581 = 0;
    Term _v_582 = 0;
    Term _v_583 = 0;
    u32 _v_584 = 0;
    Term _v_585 = 0;
    u32 _v_586 = 0;
    u32 _v_587 = 0;
    u32 _v_588 = 0;
    u32 _v_589 = 0;
    Term _v_590 = 0;
    u32 _v_591 = 0;
    Term _v_592 = 0;
    u32 _v_593 = 0;
    Term _v_594 = 0;
    u32 _v_595 = 0;
    u32 _v_596 = 0;
    Term _v_597 = 0;
    Term _v_598 = 0;
    Term _v_599 = 0;
    Term _v_600 = 0;
    Term _v_601 = 0;
    Term _v_602 = 0;
    u32 _v_603 = 0;
    Term _v_604 = 0;
    u32 _v_605 = 0;
    u32 _v_606 = 0;
    u32 _v_607 = 0;
    u32 _v_608 = 0;
    Term _v_609 = 0;
    u32 _v_610 = 0;
    Term _v_611 = 0;
    u32 _v_612 = 0;
    Term _v_613 = 0;
    u32 _v_614 = 0;
    u32 _v_615 = 0;
    Term _o_280[19];
    if (spin_44(e, _o_280, _f_160, blk_loc(e.mem, _f_160), _f_161, blk_loc(e.mem, _f_161), _f_162, blk_loc(e.mem, _f_162), _f_163, blk_loc(e.mem, _f_163), _f_164, blk_loc(e.mem, _f_164), _f_165, blk_loc(e.mem, _f_165), _f_166, _f_167, _f_168, 131073ull) == 0) {
      return 0;
    }
    _v_597 = _o_280[0];
    _v_598 = _o_280[1];
    _v_599 = _o_280[2];
    _v_600 = _o_280[3];
    _v_601 = _o_280[4];
    _v_602 = _o_280[5];
    _v_603 = _o_280[6];
    _v_604 = _o_280[7];
    _v_605 = _o_280[8];
    _v_606 = _o_280[9];
    _v_607 = _o_280[10];
    _v_608 = _o_280[11];
    _v_609 = _o_280[12];
    _v_610 = _o_280[13];
    _v_611 = _o_280[14];
    _v_612 = _o_280[15];
    _v_613 = _o_280[16];
    _v_614 = _o_280[17];
    _v_615 = _o_280[18];
    _v_578 = _v_597;
    _v_579 = _v_598;
    _v_580 = _v_599;
    _v_581 = _v_600;
    _v_582 = _v_601;
    _v_583 = _v_602;
    _v_584 = _v_603;
    _v_585 = _v_604;
    _v_586 = _v_605;
    _v_587 = _v_606;
    _v_588 = _v_607;
    _v_589 = _v_608;
    _v_590 = _v_609;
    _v_591 = _v_610;
    _v_592 = _v_611;
    _v_593 = _v_612;
    _v_594 = _v_613;
    _v_595 = _v_614;
    _v_596 = _v_615;
    u32 _o_281 = 0;
    u32 _o_282 = 0;
    u32 _o_283 = 0;
    Term _o_284 = 0;
    u32 _o_285 = 0;
    u32 _o_286 = 0;
    Term _o_287 = 0;
    u32 _o_288 = 0;
    u32 _o_289 = 0;
    u32 _o_290 = 0;
    u32 _o_291 = 0;
    if (_v_587 == 0) {
      _o_281 = 0;
    } else {
      _o_281 = 1;
      u32 _o_292 = 0;
      Term _o_293 = 0;
      u32 _o_294 = 0;
      if (_v_589 == 0) {
        _o_292 = 0;
      } else {
        _o_292 = 1;
        Term _fb_37[2];
        u64 _sp_37 = ctr_take(e, _v_590, 2, _fb_37);
        Term _f_169 = _fb_37[0];
        u32 _f_170 = _fb_37[1];
        spare_free(e, cls_fit(2), _sp_37);
        _o_293 = _f_169;
        _o_294 = _f_170;
      }
      u32 _o_295 = 0;
      Term _o_296 = 0;
      u32 _o_297 = 0;
      if (_v_591 == 0) {
        _o_295 = 0;
      } else {
        _o_295 = 1;
        Term _fb_38[2];
        u64 _sp_38 = ctr_take(e, _v_592, 2, _fb_38);
        Term _f_171 = _fb_38[0];
        u32 _f_172 = _fb_38[1];
        spare_free(e, cls_fit(2), _sp_38);
        _o_296 = _f_171;
        _o_297 = _f_172;
      }
      u32 _o_298 = 0;
      if (_v_593 == 0) {
        _o_298 = 0;
      } else {
        _o_298 = 1;
      }
      _o_282 = _v_588;
      _o_283 = _o_292;
      _o_284 = _o_293;
      _o_285 = _o_294;
      _o_286 = _o_295;
      _o_287 = _o_296;
      _o_288 = _o_297;
      _o_289 = _o_298;
      _o_290 = _v_595;
      _o_291 = _v_596;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K326;
      WL_PUSHN(1);
    } else {
      u64 _t_36 = task_node(e, FID_MAIN_K326, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K326, _t_36);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOOKUP_PRINT)) {
      u64 _t_37 = task_node(e, FID_LOOKUP_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_37 + 0] = term_ctr(CID_SCON, STAT_OFF + 268);
      e.mem[_t_37 + 1] = _v_578;
      e.mem[_t_37 + 2] = _v_579;
      e.mem[_t_37 + 3] = _v_580;
      e.mem[_t_37 + 4] = _v_581;
      e.mem[_t_37 + 5] = _v_582;
      e.mem[_t_37 + 6] = _v_583;
      e.mem[_t_37 + 7] = _v_584;
      e.mem[_t_37 + 8] = _v_585;
      e.mem[_t_37 + 9] = _v_586;
      e.mem[_t_37 + 10] = _o_281;
      e.mem[_t_37 + 11] = _o_282;
      e.mem[_t_37 + 12] = _o_283;
      e.mem[_t_37 + 13] = _o_284;
      e.mem[_t_37 + 14] = _o_285;
      e.mem[_t_37 + 15] = _o_286;
      e.mem[_t_37 + 16] = _o_287;
      e.mem[_t_37 + 17] = _o_288;
      e.mem[_t_37 + 18] = _o_289;
      e.mem[_t_37 + 19] = _o_290;
      e.mem[_t_37 + 20] = _o_291;
      return term_tsk(FID_LOOKUP_PRINT, _t_37);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 268);
    r1 = _v_578;
    r2 = _v_579;
    r3 = _v_580;
    r4 = _v_581;
    r5 = _v_582;
    r6 = _v_583;
    r7 = _v_584;
    r8 = _v_585;
    r9 = _v_586;
    r10 = _o_281;
    r11 = _o_282;
    r12 = _o_283;
    r13 = _o_284;
    r14 = _o_285;
    r15 = _o_286;
    r16 = _o_287;
    r17 = _o_288;
    r18 = _o_289;
    r19 = _o_290;
    r20 = _o_291;
    WL_JMP(FID_LOOKUP_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K326)
  {
    Term _h_121 = r0;
    WL_OPEN
    u64 _nd_22 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_22 + 0] = _h_121;
    r0 = term_clo(FID_MAIN_C327, _nd_22);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C327)
  {
    Term _h_122 = r0;
    Term _x_26 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_148 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_148 + 0] = _h_122;
      e.mem[_t_148 + 1] = term_clo(FID_MAIN_C328, 0);
      e.mem[_t_148 + 2] = _x_26;
      return term_tsk(FID_IO_BIND, _t_148);
    }
    r0 = _h_122;
    r1 = term_clo(FID_MAIN_C328, 0);
    r2 = _x_26;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C328)
  {
    Term _x_27 = r0;
    WL_OPEN
    Term _fb_39[9];
    u64 _sp_39 = ctr_take(e, _x_27, 9, _fb_39);
    Term _f_173 = _fb_39[0];
    Term _f_174 = _fb_39[1];
    Term _f_175 = _fb_39[2];
    Term _f_176 = _fb_39[3];
    Term _f_177 = _fb_39[4];
    Term _f_178 = _fb_39[5];
    u32 _f_179 = _fb_39[6];
    Term _f_180 = _fb_39[7];
    u32 _f_181 = _fb_39[8];
    spare_free(e, cls_fit(9), _sp_39);
    Term _v_616 = 0;
    Term _v_617 = 0;
    Term _v_618 = 0;
    Term _v_619 = 0;
    Term _v_620 = 0;
    Term _v_621 = 0;
    u32 _v_622 = 0;
    Term _v_623 = 0;
    u32 _v_624 = 0;
    u32 _v_625 = 0;
    u32 _v_626 = 0;
    u32 _v_627 = 0;
    Term _v_628 = 0;
    u32 _v_629 = 0;
    Term _v_630 = 0;
    u32 _v_631 = 0;
    Term _v_632 = 0;
    u32 _v_633 = 0;
    u32 _v_634 = 0;
    Term _v_635 = 0;
    Term _v_636 = 0;
    Term _v_637 = 0;
    Term _v_638 = 0;
    Term _v_639 = 0;
    Term _v_640 = 0;
    u32 _v_641 = 0;
    Term _v_642 = 0;
    u32 _v_643 = 0;
    u32 _v_644 = 0;
    u32 _v_645 = 0;
    u32 _v_646 = 0;
    Term _v_647 = 0;
    u32 _v_648 = 0;
    Term _v_649 = 0;
    u32 _v_650 = 0;
    Term _v_651 = 0;
    u32 _v_652 = 0;
    u32 _v_653 = 0;
    Term _o_299[19];
    if (spin_44(e, _o_299, _f_173, blk_loc(e.mem, _f_173), _f_174, blk_loc(e.mem, _f_174), _f_175, blk_loc(e.mem, _f_175), _f_176, blk_loc(e.mem, _f_176), _f_177, blk_loc(e.mem, _f_177), _f_178, blk_loc(e.mem, _f_178), _f_179, _f_180, _f_181, 4294967295ull) == 0) {
      return 0;
    }
    _v_635 = _o_299[0];
    _v_636 = _o_299[1];
    _v_637 = _o_299[2];
    _v_638 = _o_299[3];
    _v_639 = _o_299[4];
    _v_640 = _o_299[5];
    _v_641 = _o_299[6];
    _v_642 = _o_299[7];
    _v_643 = _o_299[8];
    _v_644 = _o_299[9];
    _v_645 = _o_299[10];
    _v_646 = _o_299[11];
    _v_647 = _o_299[12];
    _v_648 = _o_299[13];
    _v_649 = _o_299[14];
    _v_650 = _o_299[15];
    _v_651 = _o_299[16];
    _v_652 = _o_299[17];
    _v_653 = _o_299[18];
    _v_616 = _v_635;
    _v_617 = _v_636;
    _v_618 = _v_637;
    _v_619 = _v_638;
    _v_620 = _v_639;
    _v_621 = _v_640;
    _v_622 = _v_641;
    _v_623 = _v_642;
    _v_624 = _v_643;
    _v_625 = _v_644;
    _v_626 = _v_645;
    _v_627 = _v_646;
    _v_628 = _v_647;
    _v_629 = _v_648;
    _v_630 = _v_649;
    _v_631 = _v_650;
    _v_632 = _v_651;
    _v_633 = _v_652;
    _v_634 = _v_653;
    u32 _o_300 = 0;
    u32 _o_301 = 0;
    u32 _o_302 = 0;
    Term _o_303 = 0;
    u32 _o_304 = 0;
    u32 _o_305 = 0;
    Term _o_306 = 0;
    u32 _o_307 = 0;
    u32 _o_308 = 0;
    u32 _o_309 = 0;
    u32 _o_310 = 0;
    if (_v_625 == 0) {
      _o_300 = 0;
    } else {
      _o_300 = 1;
      u32 _o_311 = 0;
      Term _o_312 = 0;
      u32 _o_313 = 0;
      if (_v_627 == 0) {
        _o_311 = 0;
      } else {
        _o_311 = 1;
        Term _fb_40[2];
        u64 _sp_40 = ctr_take(e, _v_628, 2, _fb_40);
        Term _f_182 = _fb_40[0];
        u32 _f_183 = _fb_40[1];
        spare_free(e, cls_fit(2), _sp_40);
        _o_312 = _f_182;
        _o_313 = _f_183;
      }
      u32 _o_314 = 0;
      Term _o_315 = 0;
      u32 _o_316 = 0;
      if (_v_629 == 0) {
        _o_314 = 0;
      } else {
        _o_314 = 1;
        Term _fb_41[2];
        u64 _sp_41 = ctr_take(e, _v_630, 2, _fb_41);
        Term _f_184 = _fb_41[0];
        u32 _f_185 = _fb_41[1];
        spare_free(e, cls_fit(2), _sp_41);
        _o_315 = _f_184;
        _o_316 = _f_185;
      }
      u32 _o_317 = 0;
      if (_v_631 == 0) {
        _o_317 = 0;
      } else {
        _o_317 = 1;
      }
      _o_301 = _v_626;
      _o_302 = _o_311;
      _o_303 = _o_312;
      _o_304 = _o_313;
      _o_305 = _o_314;
      _o_306 = _o_315;
      _o_307 = _o_316;
      _o_308 = _o_317;
      _o_309 = _v_633;
      _o_310 = _v_634;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K329;
      WL_PUSHN(1);
    } else {
      u64 _t_38 = task_node(e, FID_MAIN_K329, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K329, _t_38);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOOKUP_PRINT)) {
      u64 _t_39 = task_node(e, FID_LOOKUP_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_39 + 0] = term_ctr(CID_SCON, STAT_OFF + 274);
      e.mem[_t_39 + 1] = _v_616;
      e.mem[_t_39 + 2] = _v_617;
      e.mem[_t_39 + 3] = _v_618;
      e.mem[_t_39 + 4] = _v_619;
      e.mem[_t_39 + 5] = _v_620;
      e.mem[_t_39 + 6] = _v_621;
      e.mem[_t_39 + 7] = _v_622;
      e.mem[_t_39 + 8] = _v_623;
      e.mem[_t_39 + 9] = _v_624;
      e.mem[_t_39 + 10] = _o_300;
      e.mem[_t_39 + 11] = _o_301;
      e.mem[_t_39 + 12] = _o_302;
      e.mem[_t_39 + 13] = _o_303;
      e.mem[_t_39 + 14] = _o_304;
      e.mem[_t_39 + 15] = _o_305;
      e.mem[_t_39 + 16] = _o_306;
      e.mem[_t_39 + 17] = _o_307;
      e.mem[_t_39 + 18] = _o_308;
      e.mem[_t_39 + 19] = _o_309;
      e.mem[_t_39 + 20] = _o_310;
      return term_tsk(FID_LOOKUP_PRINT, _t_39);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 274);
    r1 = _v_616;
    r2 = _v_617;
    r3 = _v_618;
    r4 = _v_619;
    r5 = _v_620;
    r6 = _v_621;
    r7 = _v_622;
    r8 = _v_623;
    r9 = _v_624;
    r10 = _o_300;
    r11 = _o_301;
    r12 = _o_302;
    r13 = _o_303;
    r14 = _o_304;
    r15 = _o_305;
    r16 = _o_306;
    r17 = _o_307;
    r18 = _o_308;
    r19 = _o_309;
    r20 = _o_310;
    WL_JMP(FID_LOOKUP_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K329)
  {
    Term _h_123 = r0;
    WL_OPEN
    u64 _nd_23 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_23 + 0] = _h_123;
    r0 = term_clo(FID_MAIN_C330, _nd_23);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C330)
  {
    Term _h_124 = r0;
    Term _x_28 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_147 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_147 + 0] = _h_124;
      e.mem[_t_147 + 1] = term_clo(FID_MAIN_C331, 0);
      e.mem[_t_147 + 2] = _x_28;
      return term_tsk(FID_IO_BIND, _t_147);
    }
    r0 = _h_124;
    r1 = term_clo(FID_MAIN_C331, 0);
    r2 = _x_28;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C331)
  {
    Term _x_29 = r0;
    WL_OPEN
    Term _fb_42[9];
    u64 _sp_42 = ctr_take(e, _x_29, 9, _fb_42);
    Term _f_186 = _fb_42[0];
    Term _f_187 = _fb_42[1];
    Term _f_188 = _fb_42[2];
    Term _f_189 = _fb_42[3];
    Term _f_190 = _fb_42[4];
    Term _f_191 = _fb_42[5];
    u32 _f_192 = _fb_42[6];
    Term _f_193 = _fb_42[7];
    u32 _f_194 = _fb_42[8];
    spare_free(e, cls_fit(9), _sp_42);
    u32 _world_0 = 7ull;
    u32 _world_1 = 65538ull;
    Term _world_2 = term_pak(CID_NIL, 0);
    u32 _world_3 = 0;
    u32 _o_322 = 0;
    Term _o_323 = 0;
    if (_world_3 == 0) {
      _o_322 = 0;
    } else {
      _o_322 = 1;
      _o_323 = term_pak(CID_UNIT, 0);
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K341;
      WL_PUSHN(1);
    } else {
      u64 _t_56 = task_node(e, FID_MAIN_K341, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K341, _t_56);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_WITH_MAIN)) {
      u64 _t_57 = task_node(e, FID_STORAGE_WITH_MAIN, WL_CONT, WL_IDX, 0);
      e.mem[_t_57 + 0] = _world_0;
      e.mem[_t_57 + 1] = _world_1;
      e.mem[_t_57 + 2] = _f_186;
      e.mem[_t_57 + 3] = _f_187;
      e.mem[_t_57 + 4] = _f_188;
      e.mem[_t_57 + 5] = _f_189;
      e.mem[_t_57 + 6] = _f_190;
      e.mem[_t_57 + 7] = _f_191;
      e.mem[_t_57 + 8] = _f_192;
      e.mem[_t_57 + 9] = _f_193;
      e.mem[_t_57 + 10] = _f_194;
      e.mem[_t_57 + 11] = _world_2;
      e.mem[_t_57 + 12] = _o_322;
      e.mem[_t_57 + 13] = _o_323;
      e.mem[_t_57 + 14] = term_pak(CID_UNIT, 0);
      e.mem[_t_57 + 15] = 7ull;
      e.mem[_t_57 + 16] = 4ull;
      e.mem[_t_57 + 17] = term_clo(FID_MAIN_C332, 0);
      return term_tsk(FID_STORAGE_WITH_MAIN, _t_57);
    }
    r0 = _world_0;
    r1 = _world_1;
    r2 = _f_186;
    r3 = _f_187;
    r4 = _f_188;
    r5 = _f_189;
    r6 = _f_190;
    r7 = _f_191;
    r8 = _f_192;
    r9 = _f_193;
    r10 = _f_194;
    r11 = _world_2;
    r12 = _o_322;
    r13 = _o_323;
    r14 = term_pak(CID_UNIT, 0);
    r15 = 7ull;
    r16 = 4ull;
    r17 = term_clo(FID_MAIN_C332, 0);
    WL_JMP(FID_STORAGE_WITH_MAIN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C332)
  {
    Term _x_30 = r0;
    WL_OPEN
    Term _fb_43[2];
    u64 _sp_43 = ctr_take(e, _x_30, 2, _fb_43);
    Term _f_195 = _fb_43[0];
    u32 _f_196 = _fb_43[1];
    spare_free(e, cls_fit(2), _sp_43);
    if (blk_cls(_f_195) != 0) {
      Term _h_125 = blk_half(e, _f_195, 0);
      Term _h_126 = blk_half(e, _f_195, 1);
      if (blk_cls(_h_125) != 0) {
        Term _h_127 = blk_half(e, _h_125, 0);
        Term _h_128 = blk_half(e, _h_125, 1);
        if (blk_cls(_h_127) == 0) {
          u32 _c_36 = blk_read(e.mem, 0, blk_loc(e.mem, _h_127), 0 + 0);
          blk_free(e, _h_127);
          if (blk_cls(_h_128) == 0) {
            u32 _c_37 = blk_read(e.mem, 0, blk_loc(e.mem, _h_128), 0 + 0);
            blk_free(e, _h_128);
            if (blk_cls(_h_126) != 0) {
              Term _h_129 = blk_half(e, _h_126, 0);
              Term _h_130 = blk_half(e, _h_126, 1);
              if (blk_cls(_h_129) == 0) {
                u32 _c_38 = blk_read(e.mem, 0, blk_loc(e.mem, _h_129), 0 + 0);
                blk_free(e, _h_129);
                if (blk_cls(_h_130) == 0) {
                  u32 _c_39 = blk_read(e.mem, 0, blk_loc(e.mem, _h_130), 0 + 0);
                  blk_free(e, _h_130);
                  Term _v_654 = 0;
                  u32 _v_655 = 0;
                  Term _v_656 = 0;
                  u32 _v_657 = 0;
                  Term _v_658 = 0;
                  u32 _v_659 = 0;
                  Term _v_660 = 0;
                  u32 _v_661 = 0;
                  Term _fv_15[1];
                  _fv_15[0] = _c_36;
                  Term _fv_16[1];
                  _fv_16[0] = _c_37;
                  Term _fv_17[1];
                  _fv_17[0] = _c_38;
                  Term _fv_18[1];
                  _fv_18[0] = _c_39;
                  Term _v_662 = 0;
                  u32 _v_663 = 0;
                  Term _o_318[2];
                  Term _a_10 = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_15), blk_new(e, 0, 0, 0, 1, _fv_16)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_17), blk_new(e, 0, 0, 0, 1, _fv_18)));
                  if (spin_41(e, _o_318, _a_10, blk_loc(e.mem, _a_10), _f_196, 19ull) == 0) {
                    return 0;
                  }
                  _v_662 = _o_318[0];
                  _v_663 = _o_318[1];
                  _v_660 = _v_662;
                  _v_661 = _v_663;
                  Term _v_664 = 0;
                  u32 _v_665 = 0;
                  Term _o_319[2];
                  if (spin_41(e, _o_319, _v_660, blk_loc(e.mem, _v_660), _v_661, 23ull) == 0) {
                    return 0;
                  }
                  _v_664 = _o_319[0];
                  _v_665 = _o_319[1];
                  _v_658 = _v_664;
                  _v_659 = _v_665;
                  Term _v_666 = 0;
                  u32 _v_667 = 0;
                  Term _o_320[2];
                  if (spin_41(e, _o_320, _v_658, blk_loc(e.mem, _v_658), _v_659, 19ull) == 0) {
                    return 0;
                  }
                  _v_666 = _o_320[0];
                  _v_667 = _o_320[1];
                  _v_656 = _v_666;
                  _v_657 = _v_667;
                  Term _v_668 = 0;
                  u32 _v_669 = 0;
                  Term _o_321[2];
                  if (spin_42(e, _o_321, _v_656, blk_loc(e.mem, _v_656), _v_657, _c_36, _c_37, _c_38, _c_39, _f_196) == 0) {
                    return 0;
                  }
                  _v_668 = _o_321[0];
                  _v_669 = _o_321[1];
                  _v_654 = _v_668;
                  _v_655 = _v_669;
                  if (seq) {
                    WL_ROOM(1);
                    STK(0) = FID_MAIN_K333;
                    WL_PUSHN(1);
                  } else {
                    u64 _t_40 = task_node(e, FID_MAIN_K333, WL_CONT, WL_IDX, 1);
                    WL_CONT = term_tsk(FID_MAIN_K333, _t_40);
                    WL_IDX = 0;
                  }
                  if (!DEVICE && !seq && fid_nofk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE)) {
                    u64 _t_41 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE, WL_CONT, WL_IDX, 0);
                    e.mem[_t_41 + 0] = _v_654;
                    e.mem[_t_41 + 1] = _v_655;
                    return term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE, _t_41);
                  }
                  r0 = _v_654;
                  r1 = _v_655;
                  WL_JMP(FID____OWNED_INDEX_CORE_MOTION_OBSERVE);
                } else {
                  Term _fv_19[1];
                  _fv_19[0] = _c_36;
                  Term _fv_20[1];
                  _fv_20[0] = _c_37;
                  Term _fv_21[1];
                  _fv_21[0] = _c_38;
                  if (seq) {
                    WL_ROOM(1);
                    STK(0) = FID_MAIN_K334;
                    WL_PUSHN(1);
                  } else {
                    u64 _t_42 = task_node(e, FID_MAIN_K334, WL_CONT, WL_IDX, 1);
                    WL_CONT = term_tsk(FID_MAIN_K334, _t_42);
                    WL_IDX = 0;
                  }
                  if (!DEVICE && !seq && fid_nofk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE)) {
                    u64 _t_43 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE, WL_CONT, WL_IDX, 0);
                    e.mem[_t_43 + 0] = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_19), blk_new(e, 0, 0, 0, 1, _fv_20)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_21), _h_130));
                    e.mem[_t_43 + 1] = _f_196;
                    return term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE, _t_43);
                  }
                  r0 = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_19), blk_new(e, 0, 0, 0, 1, _fv_20)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_21), _h_130));
                  r1 = _f_196;
                  WL_JMP(FID____OWNED_INDEX_CORE_MOTION_OBSERVE);
                }
              } else {
                Term _fv_22[1];
                _fv_22[0] = _c_36;
                Term _fv_23[1];
                _fv_23[0] = _c_37;
                if (seq) {
                  WL_ROOM(1);
                  STK(0) = FID_MAIN_K335;
                  WL_PUSHN(1);
                } else {
                  u64 _t_44 = task_node(e, FID_MAIN_K335, WL_CONT, WL_IDX, 1);
                  WL_CONT = term_tsk(FID_MAIN_K335, _t_44);
                  WL_IDX = 0;
                }
                if (!DEVICE && !seq && fid_nofk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE)) {
                  u64 _t_45 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE, WL_CONT, WL_IDX, 0);
                  e.mem[_t_45 + 0] = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_22), blk_new(e, 0, 0, 0, 1, _fv_23)), blk_node(e, _h_129, _h_130));
                  e.mem[_t_45 + 1] = _f_196;
                  return term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE, _t_45);
                }
                r0 = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_22), blk_new(e, 0, 0, 0, 1, _fv_23)), blk_node(e, _h_129, _h_130));
                r1 = _f_196;
                WL_JMP(FID____OWNED_INDEX_CORE_MOTION_OBSERVE);
              }
            } else {
              Term _fv_24[1];
              _fv_24[0] = _c_36;
              Term _fv_25[1];
              _fv_25[0] = _c_37;
              if (seq) {
                WL_ROOM(1);
                STK(0) = FID_MAIN_K336;
                WL_PUSHN(1);
              } else {
                u64 _t_46 = task_node(e, FID_MAIN_K336, WL_CONT, WL_IDX, 1);
                WL_CONT = term_tsk(FID_MAIN_K336, _t_46);
                WL_IDX = 0;
              }
              if (!DEVICE && !seq && fid_nofk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE)) {
                u64 _t_47 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE, WL_CONT, WL_IDX, 0);
                e.mem[_t_47 + 0] = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_24), blk_new(e, 0, 0, 0, 1, _fv_25)), _h_126);
                e.mem[_t_47 + 1] = _f_196;
                return term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE, _t_47);
              }
              r0 = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_24), blk_new(e, 0, 0, 0, 1, _fv_25)), _h_126);
              r1 = _f_196;
              WL_JMP(FID____OWNED_INDEX_CORE_MOTION_OBSERVE);
            }
          } else {
            Term _fv_26[1];
            _fv_26[0] = _c_36;
            if (seq) {
              WL_ROOM(1);
              STK(0) = FID_MAIN_K337;
              WL_PUSHN(1);
            } else {
              u64 _t_48 = task_node(e, FID_MAIN_K337, WL_CONT, WL_IDX, 1);
              WL_CONT = term_tsk(FID_MAIN_K337, _t_48);
              WL_IDX = 0;
            }
            if (!DEVICE && !seq && fid_nofk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE)) {
              u64 _t_49 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE, WL_CONT, WL_IDX, 0);
              e.mem[_t_49 + 0] = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_26), _h_128), _h_126);
              e.mem[_t_49 + 1] = _f_196;
              return term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE, _t_49);
            }
            r0 = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_26), _h_128), _h_126);
            r1 = _f_196;
            WL_JMP(FID____OWNED_INDEX_CORE_MOTION_OBSERVE);
          }
        } else {
          if (seq) {
            WL_ROOM(1);
            STK(0) = FID_MAIN_K338;
            WL_PUSHN(1);
          } else {
            u64 _t_50 = task_node(e, FID_MAIN_K338, WL_CONT, WL_IDX, 1);
            WL_CONT = term_tsk(FID_MAIN_K338, _t_50);
            WL_IDX = 0;
          }
          if (!DEVICE && !seq && fid_nofk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE)) {
            u64 _t_51 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE, WL_CONT, WL_IDX, 0);
            e.mem[_t_51 + 0] = blk_node(e, blk_node(e, _h_127, _h_128), _h_126);
            e.mem[_t_51 + 1] = _f_196;
            return term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE, _t_51);
          }
          r0 = blk_node(e, blk_node(e, _h_127, _h_128), _h_126);
          r1 = _f_196;
          WL_JMP(FID____OWNED_INDEX_CORE_MOTION_OBSERVE);
        }
      } else {
        if (seq) {
          WL_ROOM(1);
          STK(0) = FID_MAIN_K339;
          WL_PUSHN(1);
        } else {
          u64 _t_52 = task_node(e, FID_MAIN_K339, WL_CONT, WL_IDX, 1);
          WL_CONT = term_tsk(FID_MAIN_K339, _t_52);
          WL_IDX = 0;
        }
        if (!DEVICE && !seq && fid_nofk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE)) {
          u64 _t_53 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE, WL_CONT, WL_IDX, 0);
          e.mem[_t_53 + 0] = blk_node(e, _h_125, _h_126);
          e.mem[_t_53 + 1] = _f_196;
          return term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE, _t_53);
        }
        r0 = blk_node(e, _h_125, _h_126);
        r1 = _f_196;
        WL_JMP(FID____OWNED_INDEX_CORE_MOTION_OBSERVE);
      }
    } else {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_MAIN_K340;
        WL_PUSHN(1);
      } else {
        u64 _t_54 = task_node(e, FID_MAIN_K340, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_MAIN_K340, _t_54);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE)) {
        u64 _t_55 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE, WL_CONT, WL_IDX, 0);
        e.mem[_t_55 + 0] = _f_195;
        e.mem[_t_55 + 1] = _f_196;
        return term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE, _t_55);
      }
      r0 = _f_195;
      r1 = _f_196;
      WL_JMP(FID____OWNED_INDEX_CORE_MOTION_OBSERVE);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K333)
  {
    Term _r_0 = r0;
    u32 _r_1 = r1;
    Term _r_2 = r2;
    WL_OPEN
    u64 _nd_24 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_24 + 0] = rfc_seal(e, _r_0);
    e.mem[_nd_24 + 1] = rfc_seal(e, _r_1);
    u64 _nd_25 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_25 + 0] = rfc_seal(e, term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_24));
    e.mem[_nd_25 + 1] = rfc_seal(e, _r_2);
    r0 = term_ctr(CID_TUPLE, _nd_25);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K334)
  {
    Term _r_3 = r0;
    u32 _r_4 = r1;
    Term _r_5 = r2;
    WL_OPEN
    u64 _nd_26 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_26 + 0] = rfc_seal(e, _r_3);
    e.mem[_nd_26 + 1] = rfc_seal(e, _r_4);
    u64 _nd_27 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_27 + 0] = rfc_seal(e, term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_26));
    e.mem[_nd_27 + 1] = rfc_seal(e, _r_5);
    r0 = term_ctr(CID_TUPLE, _nd_27);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K335)
  {
    Term _r_6 = r0;
    u32 _r_7 = r1;
    Term _r_8 = r2;
    WL_OPEN
    u64 _nd_28 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_28 + 0] = rfc_seal(e, _r_6);
    e.mem[_nd_28 + 1] = rfc_seal(e, _r_7);
    u64 _nd_29 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_29 + 0] = rfc_seal(e, term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_28));
    e.mem[_nd_29 + 1] = rfc_seal(e, _r_8);
    r0 = term_ctr(CID_TUPLE, _nd_29);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K336)
  {
    Term _r_9 = r0;
    u32 _r_10 = r1;
    Term _r_11 = r2;
    WL_OPEN
    u64 _nd_30 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_30 + 0] = rfc_seal(e, _r_9);
    e.mem[_nd_30 + 1] = rfc_seal(e, _r_10);
    u64 _nd_31 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_31 + 0] = rfc_seal(e, term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_30));
    e.mem[_nd_31 + 1] = rfc_seal(e, _r_11);
    r0 = term_ctr(CID_TUPLE, _nd_31);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K337)
  {
    Term _r_12 = r0;
    u32 _r_13 = r1;
    Term _r_14 = r2;
    WL_OPEN
    u64 _nd_32 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_32 + 0] = rfc_seal(e, _r_12);
    e.mem[_nd_32 + 1] = rfc_seal(e, _r_13);
    u64 _nd_33 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_33 + 0] = rfc_seal(e, term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_32));
    e.mem[_nd_33 + 1] = rfc_seal(e, _r_14);
    r0 = term_ctr(CID_TUPLE, _nd_33);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K338)
  {
    Term _r_15 = r0;
    u32 _r_16 = r1;
    Term _r_17 = r2;
    WL_OPEN
    u64 _nd_34 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_34 + 0] = rfc_seal(e, _r_15);
    e.mem[_nd_34 + 1] = rfc_seal(e, _r_16);
    u64 _nd_35 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_35 + 0] = rfc_seal(e, term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_34));
    e.mem[_nd_35 + 1] = rfc_seal(e, _r_17);
    r0 = term_ctr(CID_TUPLE, _nd_35);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K339)
  {
    Term _r_18 = r0;
    u32 _r_19 = r1;
    Term _r_20 = r2;
    WL_OPEN
    u64 _nd_36 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_36 + 0] = rfc_seal(e, _r_18);
    e.mem[_nd_36 + 1] = rfc_seal(e, _r_19);
    u64 _nd_37 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_37 + 0] = rfc_seal(e, term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_36));
    e.mem[_nd_37 + 1] = rfc_seal(e, _r_20);
    r0 = term_ctr(CID_TUPLE, _nd_37);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K340)
  {
    Term _r_21 = r0;
    u32 _r_22 = r1;
    Term _r_23 = r2;
    WL_OPEN
    u64 _nd_38 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_38 + 0] = rfc_seal(e, _r_21);
    e.mem[_nd_38 + 1] = rfc_seal(e, _r_22);
    u64 _nd_39 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_39 + 0] = rfc_seal(e, term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_38));
    e.mem[_nd_39 + 1] = rfc_seal(e, _r_23);
    r0 = term_ctr(CID_TUPLE, _nd_39);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K341)
  {
    u32 _h_131 = r0;
    u32 _h_132 = r1;
    Term _h_133 = r2;
    Term _h_134 = r3;
    Term _h_135 = r4;
    Term _h_136 = r5;
    Term _h_137 = r6;
    Term _h_138 = r7;
    u32 _h_139 = r8;
    Term _h_140 = r9;
    u32 _h_141 = r10;
    Term _h_142 = r11;
    u32 _h_143 = r12;
    Term _h_144 = r13;
    Term _h_145 = r14;
    u32 _h_146 = r15;
    Term _h_147 = r16;
    WL_OPEN
    u32 _o_324 = 0;
    if (_h_143 == 0) {
      _o_324 = 0;
    } else {
      _o_324 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K342;
      WL_PUSHN(1);
    } else {
      u64 _t_58 = task_node(e, FID_MAIN_K342, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K342, _t_58);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_MAIN_PRINT)) {
      u64 _t_59 = task_node(e, FID_MAIN_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_59 + 0] = term_ctr(CID_SCON, STAT_OFF + 292);
      e.mem[_t_59 + 1] = _h_131;
      e.mem[_t_59 + 2] = _h_132;
      e.mem[_t_59 + 3] = _h_133;
      e.mem[_t_59 + 4] = _h_134;
      e.mem[_t_59 + 5] = _h_135;
      e.mem[_t_59 + 6] = _h_136;
      e.mem[_t_59 + 7] = _h_137;
      e.mem[_t_59 + 8] = _h_138;
      e.mem[_t_59 + 9] = _h_139;
      e.mem[_t_59 + 10] = _h_140;
      e.mem[_t_59 + 11] = _h_141;
      e.mem[_t_59 + 12] = _h_142;
      e.mem[_t_59 + 13] = _o_324;
      e.mem[_t_59 + 14] = _h_146;
      e.mem[_t_59 + 15] = _h_147;
      return term_tsk(FID_MAIN_PRINT, _t_59);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 292);
    r1 = _h_131;
    r2 = _h_132;
    r3 = _h_133;
    r4 = _h_134;
    r5 = _h_135;
    r6 = _h_136;
    r7 = _h_137;
    r8 = _h_138;
    r9 = _h_139;
    r10 = _h_140;
    r11 = _h_141;
    r12 = _h_142;
    r13 = _o_324;
    r14 = _h_146;
    r15 = _h_147;
    WL_JMP(FID_MAIN_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K342)
  {
    Term _h_148 = r0;
    WL_OPEN
    u64 _nd_40 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_40 + 0] = _h_148;
    r0 = term_clo(FID_MAIN_C343, _nd_40);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C343)
  {
    Term _h_149 = r0;
    Term _x_31 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_146 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_146 + 0] = _h_149;
      e.mem[_t_146 + 1] = term_clo(FID_MAIN_C344, 0);
      e.mem[_t_146 + 2] = _x_31;
      return term_tsk(FID_IO_BIND, _t_146);
    }
    r0 = _h_149;
    r1 = term_clo(FID_MAIN_C344, 0);
    r2 = _x_31;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C344)
  {
    Term _x_32 = r0;
    WL_OPEN
    Term _fb_44[15];
    u64 _sp_44 = ctr_take(e, _x_32, 15, _fb_44);
    u32 _f_197 = _fb_44[0];
    u32 _f_198 = _fb_44[1];
    Term _f_199 = _fb_44[2];
    Term _f_200 = _fb_44[3];
    Term _f_201 = _fb_44[4];
    Term _f_202 = _fb_44[5];
    Term _f_203 = _fb_44[6];
    Term _f_204 = _fb_44[7];
    u32 _f_205 = _fb_44[8];
    Term _f_206 = _fb_44[9];
    u32 _f_207 = _fb_44[10];
    Term _f_208 = _fb_44[11];
    u32 _f_209 = _fb_44[12];
    Term _f_210 = _fb_44[13];
    Term _f_211 = _fb_44[14];
    spare_free(e, cls_fit(15), _sp_44);
    u32 _o_325 = 0;
    if (_f_209 == 0) {
      _o_325 = 0;
    } else {
      _o_325 = 1;
    }
    u32 _o_326 = 0;
    Term _o_327 = 0;
    if (_o_325 == 0) {
      _o_326 = 0;
    } else {
      _o_326 = 1;
      _o_327 = term_pak(CID_UNIT, 0);
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K347;
      WL_PUSHN(1);
    } else {
      u64 _t_62 = task_node(e, FID_MAIN_K347, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K347, _t_62);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_WITH_MAIN)) {
      u64 _t_63 = task_node(e, FID_STORAGE_WITH_MAIN, WL_CONT, WL_IDX, 0);
      e.mem[_t_63 + 0] = _f_197;
      e.mem[_t_63 + 1] = _f_198;
      e.mem[_t_63 + 2] = _f_199;
      e.mem[_t_63 + 3] = _f_200;
      e.mem[_t_63 + 4] = _f_201;
      e.mem[_t_63 + 5] = _f_202;
      e.mem[_t_63 + 6] = _f_203;
      e.mem[_t_63 + 7] = _f_204;
      e.mem[_t_63 + 8] = _f_205;
      e.mem[_t_63 + 9] = _f_206;
      e.mem[_t_63 + 10] = _f_207;
      e.mem[_t_63 + 11] = _f_208;
      e.mem[_t_63 + 12] = _o_326;
      e.mem[_t_63 + 13] = _o_327;
      e.mem[_t_63 + 14] = term_pak(CID_UNIT, 0);
      e.mem[_t_63 + 15] = 7ull;
      e.mem[_t_63 + 16] = 2ull;
      e.mem[_t_63 + 17] = term_clo(FID_MAIN_C345, 0);
      return term_tsk(FID_STORAGE_WITH_MAIN, _t_63);
    }
    r0 = _f_197;
    r1 = _f_198;
    r2 = _f_199;
    r3 = _f_200;
    r4 = _f_201;
    r5 = _f_202;
    r6 = _f_203;
    r7 = _f_204;
    r8 = _f_205;
    r9 = _f_206;
    r10 = _f_207;
    r11 = _f_208;
    r12 = _o_326;
    r13 = _o_327;
    r14 = term_pak(CID_UNIT, 0);
    r15 = 7ull;
    r16 = 2ull;
    r17 = term_clo(FID_MAIN_C345, 0);
    WL_JMP(FID_STORAGE_WITH_MAIN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C345)
  {
    Term _x_33 = r0;
    WL_OPEN
    Term _fb_45[2];
    u64 _sp_45 = ctr_take(e, _x_33, 2, _fb_45);
    Term _f_212 = _fb_45[0];
    u32 _f_213 = _fb_45[1];
    spare_free(e, cls_fit(2), _sp_45);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K346;
      WL_PUSHN(1);
    } else {
      u64 _t_60 = task_node(e, FID_MAIN_K346, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K346, _t_60);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE)) {
      u64 _t_61 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_61 + 0] = _f_212;
      e.mem[_t_61 + 1] = _f_213;
      return term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE, _t_61);
    }
    r0 = _f_212;
    r1 = _f_213;
    WL_JMP(FID____OWNED_INDEX_CORE_MOTION_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K346)
  {
    Term _r_24 = r0;
    u32 _r_25 = r1;
    Term _r_26 = r2;
    WL_OPEN
    u64 _nd_41 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_41 + 0] = rfc_seal(e, _r_24);
    e.mem[_nd_41 + 1] = rfc_seal(e, _r_25);
    u64 _nd_42 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_42 + 0] = rfc_seal(e, term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_41));
    e.mem[_nd_42 + 1] = rfc_seal(e, _r_26);
    r0 = term_ctr(CID_TUPLE, _nd_42);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K347)
  {
    u32 _h_150 = r0;
    u32 _h_151 = r1;
    Term _h_152 = r2;
    Term _h_153 = r3;
    Term _h_154 = r4;
    Term _h_155 = r5;
    Term _h_156 = r6;
    Term _h_157 = r7;
    u32 _h_158 = r8;
    Term _h_159 = r9;
    u32 _h_160 = r10;
    Term _h_161 = r11;
    u32 _h_162 = r12;
    Term _h_163 = r13;
    Term _h_164 = r14;
    u32 _h_165 = r15;
    Term _h_166 = r16;
    WL_OPEN
    u32 _o_328 = 0;
    if (_h_162 == 0) {
      _o_328 = 0;
    } else {
      _o_328 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K348;
      WL_PUSHN(1);
    } else {
      u64 _t_64 = task_node(e, FID_MAIN_K348, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K348, _t_64);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_MAIN_PRINT)) {
      u64 _t_65 = task_node(e, FID_MAIN_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_65 + 0] = term_ctr(CID_SCON, STAT_OFF + 308);
      e.mem[_t_65 + 1] = _h_150;
      e.mem[_t_65 + 2] = _h_151;
      e.mem[_t_65 + 3] = _h_152;
      e.mem[_t_65 + 4] = _h_153;
      e.mem[_t_65 + 5] = _h_154;
      e.mem[_t_65 + 6] = _h_155;
      e.mem[_t_65 + 7] = _h_156;
      e.mem[_t_65 + 8] = _h_157;
      e.mem[_t_65 + 9] = _h_158;
      e.mem[_t_65 + 10] = _h_159;
      e.mem[_t_65 + 11] = _h_160;
      e.mem[_t_65 + 12] = _h_161;
      e.mem[_t_65 + 13] = _o_328;
      e.mem[_t_65 + 14] = _h_165;
      e.mem[_t_65 + 15] = _h_166;
      return term_tsk(FID_MAIN_PRINT, _t_65);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 308);
    r1 = _h_150;
    r2 = _h_151;
    r3 = _h_152;
    r4 = _h_153;
    r5 = _h_154;
    r6 = _h_155;
    r7 = _h_156;
    r8 = _h_157;
    r9 = _h_158;
    r10 = _h_159;
    r11 = _h_160;
    r12 = _h_161;
    r13 = _o_328;
    r14 = _h_165;
    r15 = _h_166;
    WL_JMP(FID_MAIN_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K348)
  {
    Term _h_167 = r0;
    WL_OPEN
    u64 _nd_43 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_43 + 0] = _h_167;
    r0 = term_clo(FID_MAIN_C349, _nd_43);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C349)
  {
    Term _h_168 = r0;
    Term _x_34 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_145 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_145 + 0] = _h_168;
      e.mem[_t_145 + 1] = term_clo(FID_MAIN_C350, 0);
      e.mem[_t_145 + 2] = _x_34;
      return term_tsk(FID_IO_BIND, _t_145);
    }
    r0 = _h_168;
    r1 = term_clo(FID_MAIN_C350, 0);
    r2 = _x_34;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C350)
  {
    Term _x_35 = r0;
    WL_OPEN
    Term _fb_46[15];
    u64 _sp_46 = ctr_take(e, _x_35, 15, _fb_46);
    u32 _f_214 = _fb_46[0];
    u32 _f_215 = _fb_46[1];
    Term _f_216 = _fb_46[2];
    Term _f_217 = _fb_46[3];
    Term _f_218 = _fb_46[4];
    Term _f_219 = _fb_46[5];
    Term _f_220 = _fb_46[6];
    Term _f_221 = _fb_46[7];
    u32 _f_222 = _fb_46[8];
    Term _f_223 = _fb_46[9];
    u32 _f_224 = _fb_46[10];
    Term _f_225 = _fb_46[11];
    u32 _f_226 = _fb_46[12];
    Term _f_227 = _fb_46[13];
    Term _f_228 = _fb_46[14];
    spare_free(e, cls_fit(15), _sp_46);
    u32 _o_329 = 0;
    if (_f_226 == 0) {
      _o_329 = 0;
    } else {
      _o_329 = 1;
    }
    u32 _o_330 = 0;
    Term _o_331 = 0;
    if (_o_329 == 0) {
      _o_330 = 0;
    } else {
      _o_330 = 1;
      _o_331 = term_pak(CID_UNIT, 0);
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K353;
      WL_PUSHN(1);
    } else {
      u64 _t_68 = task_node(e, FID_MAIN_K353, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K353, _t_68);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_WITH_MAIN)) {
      u64 _t_69 = task_node(e, FID_STORAGE_WITH_MAIN, WL_CONT, WL_IDX, 0);
      e.mem[_t_69 + 0] = _f_214;
      e.mem[_t_69 + 1] = _f_215;
      e.mem[_t_69 + 2] = _f_216;
      e.mem[_t_69 + 3] = _f_217;
      e.mem[_t_69 + 4] = _f_218;
      e.mem[_t_69 + 5] = _f_219;
      e.mem[_t_69 + 6] = _f_220;
      e.mem[_t_69 + 7] = _f_221;
      e.mem[_t_69 + 8] = _f_222;
      e.mem[_t_69 + 9] = _f_223;
      e.mem[_t_69 + 10] = _f_224;
      e.mem[_t_69 + 11] = _f_225;
      e.mem[_t_69 + 12] = _o_330;
      e.mem[_t_69 + 13] = _o_331;
      e.mem[_t_69 + 14] = term_pak(CID_UNIT, 0);
      e.mem[_t_69 + 15] = 8ull;
      e.mem[_t_69 + 16] = 1ull;
      e.mem[_t_69 + 17] = term_clo(FID_MAIN_C351, 0);
      return term_tsk(FID_STORAGE_WITH_MAIN, _t_69);
    }
    r0 = _f_214;
    r1 = _f_215;
    r2 = _f_216;
    r3 = _f_217;
    r4 = _f_218;
    r5 = _f_219;
    r6 = _f_220;
    r7 = _f_221;
    r8 = _f_222;
    r9 = _f_223;
    r10 = _f_224;
    r11 = _f_225;
    r12 = _o_330;
    r13 = _o_331;
    r14 = term_pak(CID_UNIT, 0);
    r15 = 8ull;
    r16 = 1ull;
    r17 = term_clo(FID_MAIN_C351, 0);
    WL_JMP(FID_STORAGE_WITH_MAIN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C351)
  {
    Term _x_36 = r0;
    WL_OPEN
    Term _fb_47[2];
    u64 _sp_47 = ctr_take(e, _x_36, 2, _fb_47);
    Term _f_229 = _fb_47[0];
    u32 _f_230 = _fb_47[1];
    spare_free(e, cls_fit(2), _sp_47);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K352;
      WL_PUSHN(1);
    } else {
      u64 _t_66 = task_node(e, FID_MAIN_K352, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K352, _t_66);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE)) {
      u64 _t_67 = task_node(e, FID____OWNED_INDEX_CORE_MOTION_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_67 + 0] = _f_229;
      e.mem[_t_67 + 1] = _f_230;
      return term_tsk(FID____OWNED_INDEX_CORE_MOTION_OBSERVE, _t_67);
    }
    r0 = _f_229;
    r1 = _f_230;
    WL_JMP(FID____OWNED_INDEX_CORE_MOTION_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K352)
  {
    Term _r_27 = r0;
    u32 _r_28 = r1;
    Term _r_29 = r2;
    WL_OPEN
    u64 _nd_44 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_44 + 0] = rfc_seal(e, _r_27);
    e.mem[_nd_44 + 1] = rfc_seal(e, _r_28);
    u64 _nd_45 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_45 + 0] = rfc_seal(e, term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_44));
    e.mem[_nd_45 + 1] = rfc_seal(e, _r_29);
    r0 = term_ctr(CID_TUPLE, _nd_45);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K353)
  {
    u32 _h_169 = r0;
    u32 _h_170 = r1;
    Term _h_171 = r2;
    Term _h_172 = r3;
    Term _h_173 = r4;
    Term _h_174 = r5;
    Term _h_175 = r6;
    Term _h_176 = r7;
    u32 _h_177 = r8;
    Term _h_178 = r9;
    u32 _h_179 = r10;
    Term _h_180 = r11;
    u32 _h_181 = r12;
    Term _h_182 = r13;
    Term _h_183 = r14;
    u32 _h_184 = r15;
    Term _h_185 = r16;
    WL_OPEN
    u32 _o_332 = 0;
    if (_h_181 == 0) {
      _o_332 = 0;
    } else {
      _o_332 = 1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K354;
      WL_PUSHN(1);
    } else {
      u64 _t_70 = task_node(e, FID_MAIN_K354, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K354, _t_70);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_MAIN_PRINT)) {
      u64 _t_71 = task_node(e, FID_MAIN_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_71 + 0] = term_ctr(CID_SCON, STAT_OFF + 320);
      e.mem[_t_71 + 1] = _h_169;
      e.mem[_t_71 + 2] = _h_170;
      e.mem[_t_71 + 3] = _h_171;
      e.mem[_t_71 + 4] = _h_172;
      e.mem[_t_71 + 5] = _h_173;
      e.mem[_t_71 + 6] = _h_174;
      e.mem[_t_71 + 7] = _h_175;
      e.mem[_t_71 + 8] = _h_176;
      e.mem[_t_71 + 9] = _h_177;
      e.mem[_t_71 + 10] = _h_178;
      e.mem[_t_71 + 11] = _h_179;
      e.mem[_t_71 + 12] = _h_180;
      e.mem[_t_71 + 13] = _o_332;
      e.mem[_t_71 + 14] = _h_184;
      e.mem[_t_71 + 15] = _h_185;
      return term_tsk(FID_MAIN_PRINT, _t_71);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 320);
    r1 = _h_169;
    r2 = _h_170;
    r3 = _h_171;
    r4 = _h_172;
    r5 = _h_173;
    r6 = _h_174;
    r7 = _h_175;
    r8 = _h_176;
    r9 = _h_177;
    r10 = _h_178;
    r11 = _h_179;
    r12 = _h_180;
    r13 = _o_332;
    r14 = _h_184;
    r15 = _h_185;
    WL_JMP(FID_MAIN_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K354)
  {
    Term _h_186 = r0;
    WL_OPEN
    u64 _nd_46 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_46 + 0] = _h_186;
    r0 = term_clo(FID_MAIN_C355, _nd_46);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C355)
  {
    Term _h_187 = r0;
    Term _x_37 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_144 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_144 + 0] = _h_187;
      e.mem[_t_144 + 1] = term_clo(FID_MAIN_C356, 0);
      e.mem[_t_144 + 2] = _x_37;
      return term_tsk(FID_IO_BIND, _t_144);
    }
    r0 = _h_187;
    r1 = term_clo(FID_MAIN_C356, 0);
    r2 = _x_37;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C356)
  {
    Term _x_38 = r0;
    WL_OPEN
    Term _fb_48[15];
    u64 _sp_48 = ctr_take(e, _x_38, 15, _fb_48);
    u32 _f_231 = _fb_48[0];
    u32 _f_232 = _fb_48[1];
    Term _f_233 = _fb_48[2];
    Term _f_234 = _fb_48[3];
    Term _f_235 = _fb_48[4];
    Term _f_236 = _fb_48[5];
    Term _f_237 = _fb_48[6];
    Term _f_238 = _fb_48[7];
    u32 _f_239 = _fb_48[8];
    Term _f_240 = _fb_48[9];
    u32 _f_241 = _fb_48[10];
    Term _f_242 = _fb_48[11];
    u32 _f_243 = _fb_48[12];
    Term _f_244 = _fb_48[13];
    Term _f_245 = _fb_48[14];
    spare_free(e, cls_fit(15), _sp_48);
    u32 _o_333 = 0;
    if (_f_243 == 0) {
      _o_333 = 0;
    } else {
      _o_333 = 1;
    }
    u32 _v_670 = 0;
    u32 _v_671 = 0;
    Term _v_672 = 0;
    Term _v_673 = 0;
    Term _v_674 = 0;
    Term _v_675 = 0;
    Term _v_676 = 0;
    Term _v_677 = 0;
    u32 _v_678 = 0;
    Term _v_679 = 0;
    u32 _v_680 = 0;
    Term _v_681 = 0;
    u32 _v_682 = 0;
    Term _v_683 = 0;
    Term _v_684 = 0;
    u32 _o_334 = 0;
    Term _o_335 = 0;
    if (_o_333 == 0) {
      _o_334 = 0;
    } else {
      _o_334 = 1;
      _o_335 = term_pak(CID_UNIT, 0);
    }
    u32 _v_685 = 0;
    u32 _v_686 = 0;
    Term _v_687 = 0;
    Term _v_688 = 0;
    Term _v_689 = 0;
    Term _v_690 = 0;
    Term _v_691 = 0;
    Term _v_692 = 0;
    u32 _v_693 = 0;
    Term _v_694 = 0;
    u32 _v_695 = 0;
    Term _v_696 = 0;
    u32 _v_697 = 0;
    Term _v_698 = 0;
    Term _v_699 = 0;
    Term _o_342[15];
    Term _a_11 = term_pak(CID_UNIT, 0);
    if (spin_55(e, _o_342, _f_231, _f_232, _f_233, blk_loc(e.mem, _f_233), _f_234, blk_loc(e.mem, _f_234), _f_235, blk_loc(e.mem, _f_235), _f_236, blk_loc(e.mem, _f_236), _f_237, blk_loc(e.mem, _f_237), _f_238, blk_loc(e.mem, _f_238), _f_239, _f_240, _f_241, _f_242, blk_loc(e.mem, _f_242), _o_334, _o_335, blk_loc(e.mem, _o_335), _a_11, blk_loc(e.mem, _a_11), 7ull, 4ull, 77ull) == 0) {
      return 0;
    }
    _v_685 = _o_342[0];
    _v_686 = _o_342[1];
    _v_687 = _o_342[2];
    _v_688 = _o_342[3];
    _v_689 = _o_342[4];
    _v_690 = _o_342[5];
    _v_691 = _o_342[6];
    _v_692 = _o_342[7];
    _v_693 = _o_342[8];
    _v_694 = _o_342[9];
    _v_695 = _o_342[10];
    _v_696 = _o_342[11];
    _v_697 = _o_342[12];
    _v_698 = _o_342[13];
    _v_699 = _o_342[14];
    _v_670 = _v_685;
    _v_671 = _v_686;
    _v_672 = _v_687;
    _v_673 = _v_688;
    _v_674 = _v_689;
    _v_675 = _v_690;
    _v_676 = _v_691;
    _v_677 = _v_692;
    _v_678 = _v_693;
    _v_679 = _v_694;
    _v_680 = _v_695;
    _v_681 = _v_696;
    _v_682 = _v_697;
    _v_683 = _v_698;
    _v_684 = _v_699;
    Term _v_811 = 0;
    Term _v_812 = 0;
    Term _v_813 = 0;
    Term _v_814 = 0;
    Term _v_815 = 0;
    Term _v_816 = 0;
    u32 _v_817 = 0;
    Term _v_818 = 0;
    u32 _v_819 = 0;
    u32 _o_343 = 0;
    if (_v_682 == 0) {
      _o_343 = 0;
    } else {
      _o_343 = 1;
    }
    Term _v_820 = 0;
    Term _v_821 = 0;
    Term _v_822 = 0;
    Term _v_823 = 0;
    Term _v_824 = 0;
    Term _v_825 = 0;
    u32 _v_826 = 0;
    Term _v_827 = 0;
    u32 _v_828 = 0;
    Term _o_344[9];
    if (spin_59(e, _o_344, _v_670, _v_671, _v_672, blk_loc(e.mem, _v_672), _v_673, blk_loc(e.mem, _v_673), _v_674, blk_loc(e.mem, _v_674), _v_675, blk_loc(e.mem, _v_675), _v_676, blk_loc(e.mem, _v_676), _v_677, blk_loc(e.mem, _v_677), _v_678, _v_679, _v_680, _v_681, blk_loc(e.mem, _v_681), _o_343) == 0) {
      return 0;
    }
    _v_820 = _o_344[0];
    _v_821 = _o_344[1];
    _v_822 = _o_344[2];
    _v_823 = _o_344[3];
    _v_824 = _o_344[4];
    _v_825 = _o_344[5];
    _v_826 = _o_344[6];
    _v_827 = _o_344[7];
    _v_828 = _o_344[8];
    _v_811 = _v_820;
    _v_812 = _v_821;
    _v_813 = _v_822;
    _v_814 = _v_823;
    _v_815 = _v_824;
    _v_816 = _v_825;
    _v_817 = _v_826;
    _v_818 = _v_827;
    _v_819 = _v_828;
    Term _v_838 = 0;
    Term _v_839 = 0;
    Term _v_840 = 0;
    Term _v_841 = 0;
    Term _v_842 = 0;
    Term _v_843 = 0;
    u32 _v_844 = 0;
    Term _v_845 = 0;
    u32 _v_846 = 0;
    u32 _v_847 = 0;
    u32 _v_848 = 0;
    u32 _v_849 = 0;
    Term _v_850 = 0;
    u32 _v_851 = 0;
    Term _v_852 = 0;
    u32 _v_853 = 0;
    Term _v_854 = 0;
    u32 _v_855 = 0;
    u32 _v_856 = 0;
    Term _v_857 = 0;
    Term _v_858 = 0;
    Term _v_859 = 0;
    Term _v_860 = 0;
    Term _v_861 = 0;
    Term _v_862 = 0;
    u32 _v_863 = 0;
    Term _v_864 = 0;
    u32 _v_865 = 0;
    u32 _v_866 = 0;
    u32 _v_867 = 0;
    u32 _v_868 = 0;
    Term _v_869 = 0;
    u32 _v_870 = 0;
    Term _v_871 = 0;
    u32 _v_872 = 0;
    Term _v_873 = 0;
    u32 _v_874 = 0;
    u32 _v_875 = 0;
    Term _o_345[19];
    if (spin_44(e, _o_345, _v_811, blk_loc(e.mem, _v_811), _v_812, blk_loc(e.mem, _v_812), _v_813, blk_loc(e.mem, _v_813), _v_814, blk_loc(e.mem, _v_814), _v_815, blk_loc(e.mem, _v_815), _v_816, blk_loc(e.mem, _v_816), _v_817, _v_818, _v_819, 4ull) == 0) {
      return 0;
    }
    _v_857 = _o_345[0];
    _v_858 = _o_345[1];
    _v_859 = _o_345[2];
    _v_860 = _o_345[3];
    _v_861 = _o_345[4];
    _v_862 = _o_345[5];
    _v_863 = _o_345[6];
    _v_864 = _o_345[7];
    _v_865 = _o_345[8];
    _v_866 = _o_345[9];
    _v_867 = _o_345[10];
    _v_868 = _o_345[11];
    _v_869 = _o_345[12];
    _v_870 = _o_345[13];
    _v_871 = _o_345[14];
    _v_872 = _o_345[15];
    _v_873 = _o_345[16];
    _v_874 = _o_345[17];
    _v_875 = _o_345[18];
    _v_838 = _v_857;
    _v_839 = _v_858;
    _v_840 = _v_859;
    _v_841 = _v_860;
    _v_842 = _v_861;
    _v_843 = _v_862;
    _v_844 = _v_863;
    _v_845 = _v_864;
    _v_846 = _v_865;
    _v_847 = _v_866;
    _v_848 = _v_867;
    _v_849 = _v_868;
    _v_850 = _v_869;
    _v_851 = _v_870;
    _v_852 = _v_871;
    _v_853 = _v_872;
    _v_854 = _v_873;
    _v_855 = _v_874;
    _v_856 = _v_875;
    u32 _o_346 = 0;
    u32 _o_347 = 0;
    u32 _o_348 = 0;
    Term _o_349 = 0;
    u32 _o_350 = 0;
    u32 _o_351 = 0;
    Term _o_352 = 0;
    u32 _o_353 = 0;
    u32 _o_354 = 0;
    u32 _o_355 = 0;
    u32 _o_356 = 0;
    if (_v_847 == 0) {
      _o_346 = 0;
    } else {
      _o_346 = 1;
      u32 _o_357 = 0;
      Term _o_358 = 0;
      u32 _o_359 = 0;
      if (_v_849 == 0) {
        _o_357 = 0;
      } else {
        _o_357 = 1;
        Term _fb_49[2];
        u64 _sp_49 = ctr_take(e, _v_850, 2, _fb_49);
        Term _f_246 = _fb_49[0];
        u32 _f_247 = _fb_49[1];
        spare_free(e, cls_fit(2), _sp_49);
        _o_358 = _f_246;
        _o_359 = _f_247;
      }
      u32 _o_360 = 0;
      Term _o_361 = 0;
      u32 _o_362 = 0;
      if (_v_851 == 0) {
        _o_360 = 0;
      } else {
        _o_360 = 1;
        Term _fb_50[2];
        u64 _sp_50 = ctr_take(e, _v_852, 2, _fb_50);
        Term _f_248 = _fb_50[0];
        u32 _f_249 = _fb_50[1];
        spare_free(e, cls_fit(2), _sp_50);
        _o_361 = _f_248;
        _o_362 = _f_249;
      }
      u32 _o_363 = 0;
      if (_v_853 == 0) {
        _o_363 = 0;
      } else {
        _o_363 = 1;
      }
      _o_347 = _v_848;
      _o_348 = _o_357;
      _o_349 = _o_358;
      _o_350 = _o_359;
      _o_351 = _o_360;
      _o_352 = _o_361;
      _o_353 = _o_362;
      _o_354 = _o_363;
      _o_355 = _v_855;
      _o_356 = _v_856;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K357;
      WL_PUSHN(1);
    } else {
      u64 _t_72 = task_node(e, FID_MAIN_K357, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K357, _t_72);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOOKUP_PRINT)) {
      u64 _t_73 = task_node(e, FID_LOOKUP_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_73 + 0] = term_ctr(CID_SCON, STAT_OFF + 328);
      e.mem[_t_73 + 1] = _v_838;
      e.mem[_t_73 + 2] = _v_839;
      e.mem[_t_73 + 3] = _v_840;
      e.mem[_t_73 + 4] = _v_841;
      e.mem[_t_73 + 5] = _v_842;
      e.mem[_t_73 + 6] = _v_843;
      e.mem[_t_73 + 7] = _v_844;
      e.mem[_t_73 + 8] = _v_845;
      e.mem[_t_73 + 9] = _v_846;
      e.mem[_t_73 + 10] = _o_346;
      e.mem[_t_73 + 11] = _o_347;
      e.mem[_t_73 + 12] = _o_348;
      e.mem[_t_73 + 13] = _o_349;
      e.mem[_t_73 + 14] = _o_350;
      e.mem[_t_73 + 15] = _o_351;
      e.mem[_t_73 + 16] = _o_352;
      e.mem[_t_73 + 17] = _o_353;
      e.mem[_t_73 + 18] = _o_354;
      e.mem[_t_73 + 19] = _o_355;
      e.mem[_t_73 + 20] = _o_356;
      return term_tsk(FID_LOOKUP_PRINT, _t_73);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 328);
    r1 = _v_838;
    r2 = _v_839;
    r3 = _v_840;
    r4 = _v_841;
    r5 = _v_842;
    r6 = _v_843;
    r7 = _v_844;
    r8 = _v_845;
    r9 = _v_846;
    r10 = _o_346;
    r11 = _o_347;
    r12 = _o_348;
    r13 = _o_349;
    r14 = _o_350;
    r15 = _o_351;
    r16 = _o_352;
    r17 = _o_353;
    r18 = _o_354;
    r19 = _o_355;
    r20 = _o_356;
    WL_JMP(FID_LOOKUP_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K357)
  {
    Term _h_188 = r0;
    WL_OPEN
    u64 _nd_47 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_47 + 0] = _h_188;
    r0 = term_clo(FID_MAIN_C358, _nd_47);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C358)
  {
    Term _h_189 = r0;
    Term _x_39 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_143 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_143 + 0] = _h_189;
      e.mem[_t_143 + 1] = term_clo(FID_MAIN_C359, 0);
      e.mem[_t_143 + 2] = _x_39;
      return term_tsk(FID_IO_BIND, _t_143);
    }
    r0 = _h_189;
    r1 = term_clo(FID_MAIN_C359, 0);
    r2 = _x_39;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C359)
  {
    Term _x_40 = r0;
    WL_OPEN
    Term _fb_51[9];
    u64 _sp_51 = ctr_take(e, _x_40, 9, _fb_51);
    Term _f_250 = _fb_51[0];
    Term _f_251 = _fb_51[1];
    Term _f_252 = _fb_51[2];
    Term _f_253 = _fb_51[3];
    Term _f_254 = _fb_51[4];
    Term _f_255 = _fb_51[5];
    u32 _f_256 = _fb_51[6];
    Term _f_257 = _fb_51[7];
    u32 _f_258 = _fb_51[8];
    spare_free(e, cls_fit(9), _sp_51);
    Term _fv_27[1];
    _fv_27[0] = 200ull;
    Term _a_12 = blk_new(e, 0, 2ull, 0, 1, _fv_27);
    Term _at_70 = blk_loc(e.mem, _a_12);
    Term _at_71 = blk_at(_a_12, 1ull, 0);
    u32 _c_42 = blk_read(e.mem, 0, _at_70, _at_71 + 0);
    blk_write(e.mem, 0, _at_70, _at_71 + 0, U32_BIN(200ull, +, 1ull));
    Term _at_72 = blk_loc(e.mem, _a_12);
    Term _at_73 = blk_at(_a_12, 2ull, 0);
    u32 _c_43 = blk_read(e.mem, 0, _at_72, _at_73 + 0);
    blk_write(e.mem, 0, _at_72, _at_73 + 0, U32_BIN(200ull, +, 2ull));
    Term _at_74 = blk_loc(e.mem, _a_12);
    Term _at_75 = blk_at(_a_12, 3ull, 0);
    u32 _c_44 = blk_read(e.mem, 0, _at_74, _at_75 + 0);
    blk_write(e.mem, 0, _at_74, _at_75 + 0, U32_BIN(200ull, +, 3ull));
    u64 _nd_48 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_48 + 0] = rfc_seal(e, _a_12);
    e.mem[_nd_48 + 1] = rfc_seal(e, 200ull);
    Term _fv_28[1];
    _fv_28[0] = 210ull;
    Term _a_13 = blk_new(e, 0, 2ull, 0, 1, _fv_28);
    Term _at_76 = blk_loc(e.mem, _a_13);
    Term _at_77 = blk_at(_a_13, 1ull, 0);
    u32 _c_45 = blk_read(e.mem, 0, _at_76, _at_77 + 0);
    blk_write(e.mem, 0, _at_76, _at_77 + 0, U32_BIN(210ull, +, 1ull));
    Term _at_78 = blk_loc(e.mem, _a_13);
    Term _at_79 = blk_at(_a_13, 2ull, 0);
    u32 _c_46 = blk_read(e.mem, 0, _at_78, _at_79 + 0);
    blk_write(e.mem, 0, _at_78, _at_79 + 0, U32_BIN(210ull, +, 2ull));
    Term _at_80 = blk_loc(e.mem, _a_13);
    Term _at_81 = blk_at(_a_13, 3ull, 0);
    u32 _c_47 = blk_read(e.mem, 0, _at_80, _at_81 + 0);
    blk_write(e.mem, 0, _at_80, _at_81 + 0, U32_BIN(210ull, +, 3ull));
    u64 _nd_49 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_49 + 0] = rfc_seal(e, _a_13);
    e.mem[_nd_49 + 1] = rfc_seal(e, 210ull);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K360;
      WL_PUSHN(1);
    } else {
      u64 _t_74 = task_node(e, FID_MAIN_K360, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K360, _t_74);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_ROWS_PLACE)) {
      u64 _t_75 = task_node(e, FID_STORAGE_ROWS_PLACE, WL_CONT, WL_IDX, 0);
      e.mem[_t_75 + 0] = _f_250;
      e.mem[_t_75 + 1] = _f_251;
      e.mem[_t_75 + 2] = _f_252;
      e.mem[_t_75 + 3] = _f_253;
      e.mem[_t_75 + 4] = _f_254;
      e.mem[_t_75 + 5] = _f_255;
      e.mem[_t_75 + 6] = _f_256;
      e.mem[_t_75 + 7] = _f_257;
      e.mem[_t_75 + 8] = _f_258;
      e.mem[_t_75 + 9] = 0ull;
      e.mem[_t_75 + 10] = 1;
      e.mem[_t_75 + 11] = term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_48);
      e.mem[_t_75 + 12] = 1;
      e.mem[_t_75 + 13] = term_ctr(CID____OWNED_INDEX_CORE_HEALTH, _nd_49);
      e.mem[_t_75 + 14] = 1;
      e.mem[_t_75 + 15] = term_pak(CID_UNIT, 0);
      e.mem[_t_75 + 16] = 11ull;
      e.mem[_t_75 + 17] = 12ull;
      return term_tsk(FID_STORAGE_ROWS_PLACE, _t_75);
    }
    r0 = _f_250;
    r1 = _f_251;
    r2 = _f_252;
    r3 = _f_253;
    r4 = _f_254;
    r5 = _f_255;
    r6 = _f_256;
    r7 = _f_257;
    r8 = _f_258;
    r9 = 0ull;
    r10 = 1;
    r11 = term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_48);
    r12 = 1;
    r13 = term_ctr(CID____OWNED_INDEX_CORE_HEALTH, _nd_49);
    r14 = 1;
    r15 = term_pak(CID_UNIT, 0);
    r16 = 11ull;
    r17 = 12ull;
    WL_JMP(FID_STORAGE_ROWS_PLACE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K360)
  {
    u32 _h_190 = r0;
    Term _h_191 = r1;
    Term _h_192 = r2;
    Term _h_193 = r3;
    Term _h_194 = r4;
    Term _h_195 = r5;
    Term _h_196 = r6;
    u32 _h_197 = r7;
    Term _h_198 = r8;
    u32 _h_199 = r9;
    u32 _h_200 = r10;
    u32 _h_201 = r11;
    Term _h_202 = r12;
    u32 _h_203 = r13;
    Term _h_204 = r14;
    u32 _h_205 = r15;
    Term _h_206 = r16;
    u32 _h_207 = r17;
    u32 _h_208 = r18;
    WL_OPEN
    u32 _o_364 = 0;
    Term _o_365 = 0;
    Term _o_366 = 0;
    Term _o_367 = 0;
    Term _o_368 = 0;
    Term _o_369 = 0;
    Term _o_370 = 0;
    u32 _o_371 = 0;
    Term _o_372 = 0;
    u32 _o_373 = 0;
    u32 _o_374 = 0;
    u32 _o_375 = 0;
    Term _o_376 = 0;
    u32 _o_377 = 0;
    u32 _o_378 = 0;
    Term _o_379 = 0;
    u32 _o_380 = 0;
    u32 _o_381 = 0;
    u32 _o_382 = 0;
    u32 _o_383 = 0;
    if (_h_190 == 0) {
      _o_364 = 0;
      _o_365 = _h_191;
      _o_366 = _h_192;
      _o_367 = _h_193;
      _o_368 = _h_194;
      _o_369 = _h_195;
      _o_370 = _h_196;
      _o_371 = _h_197;
      _o_372 = _h_198;
      _o_373 = _h_199;
    } else {
      _o_364 = 1;
      u32 _o_384 = 0;
      Term _o_385 = 0;
      u32 _o_386 = 0;
      if (_h_201 == 0) {
        _o_384 = 0;
      } else {
        _o_384 = 1;
        Term _fb_52[2];
        u64 _sp_52 = ctr_take(e, _h_202, 2, _fb_52);
        Term _f_259 = _fb_52[0];
        u32 _f_260 = _fb_52[1];
        spare_free(e, cls_fit(2), _sp_52);
        _o_385 = _f_259;
        _o_386 = _f_260;
      }
      u32 _o_387 = 0;
      Term _o_388 = 0;
      u32 _o_389 = 0;
      if (_h_203 == 0) {
        _o_387 = 0;
      } else {
        _o_387 = 1;
        Term _fb_53[2];
        u64 _sp_53 = ctr_take(e, _h_204, 2, _fb_53);
        Term _f_261 = _fb_53[0];
        u32 _f_262 = _fb_53[1];
        spare_free(e, cls_fit(2), _sp_53);
        _o_388 = _f_261;
        _o_389 = _f_262;
      }
      u32 _o_390 = 0;
      if (_h_205 == 0) {
        _o_390 = 0;
      } else {
        _o_390 = 1;
      }
      _o_365 = _h_191;
      _o_366 = _h_192;
      _o_367 = _h_193;
      _o_368 = _h_194;
      _o_369 = _h_195;
      _o_370 = _h_196;
      _o_371 = _h_197;
      _o_372 = _h_198;
      _o_373 = _h_199;
      _o_374 = _h_200;
      _o_375 = _o_384;
      _o_376 = _o_385;
      _o_377 = _o_386;
      _o_378 = _o_387;
      _o_379 = _o_388;
      _o_380 = _o_389;
      _o_381 = _o_390;
      _o_382 = _h_207;
      _o_383 = _h_208;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K361;
      WL_PUSHN(1);
    } else {
      u64 _t_76 = task_node(e, FID_MAIN_K361, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K361, _t_76);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_PLACEMENT_PRINT)) {
      u64 _t_77 = task_node(e, FID_PLACEMENT_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_77 + 0] = term_ctr(CID_SCON, STAT_OFF + 342);
      e.mem[_t_77 + 1] = _o_364;
      e.mem[_t_77 + 2] = _o_365;
      e.mem[_t_77 + 3] = _o_366;
      e.mem[_t_77 + 4] = _o_367;
      e.mem[_t_77 + 5] = _o_368;
      e.mem[_t_77 + 6] = _o_369;
      e.mem[_t_77 + 7] = _o_370;
      e.mem[_t_77 + 8] = _o_371;
      e.mem[_t_77 + 9] = _o_372;
      e.mem[_t_77 + 10] = _o_373;
      e.mem[_t_77 + 11] = _o_374;
      e.mem[_t_77 + 12] = _o_375;
      e.mem[_t_77 + 13] = _o_376;
      e.mem[_t_77 + 14] = _o_377;
      e.mem[_t_77 + 15] = _o_378;
      e.mem[_t_77 + 16] = _o_379;
      e.mem[_t_77 + 17] = _o_380;
      e.mem[_t_77 + 18] = _o_381;
      e.mem[_t_77 + 19] = _o_382;
      e.mem[_t_77 + 20] = _o_383;
      return term_tsk(FID_PLACEMENT_PRINT, _t_77);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 342);
    r1 = _o_364;
    r2 = _o_365;
    r3 = _o_366;
    r4 = _o_367;
    r5 = _o_368;
    r6 = _o_369;
    r7 = _o_370;
    r8 = _o_371;
    r9 = _o_372;
    r10 = _o_373;
    r11 = _o_374;
    r12 = _o_375;
    r13 = _o_376;
    r14 = _o_377;
    r15 = _o_378;
    r16 = _o_379;
    r17 = _o_380;
    r18 = _o_381;
    r19 = _o_382;
    r20 = _o_383;
    WL_JMP(FID_PLACEMENT_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K361)
  {
    Term _h_209 = r0;
    WL_OPEN
    u64 _nd_50 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_50 + 0] = _h_209;
    r0 = term_clo(FID_MAIN_C362, _nd_50);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C362)
  {
    Term _h_210 = r0;
    Term _x_41 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_142 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_142 + 0] = _h_210;
      e.mem[_t_142 + 1] = term_clo(FID_MAIN_C363, 0);
      e.mem[_t_142 + 2] = _x_41;
      return term_tsk(FID_IO_BIND, _t_142);
    }
    r0 = _h_210;
    r1 = term_clo(FID_MAIN_C363, 0);
    r2 = _x_41;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C363)
  {
    Term _x_42 = r0;
    WL_OPEN
    Term _fb_54[9];
    u64 _sp_54 = ctr_take(e, _x_42, 9, _fb_54);
    Term _f_263 = _fb_54[0];
    Term _f_264 = _fb_54[1];
    Term _f_265 = _fb_54[2];
    Term _f_266 = _fb_54[3];
    Term _f_267 = _fb_54[4];
    Term _f_268 = _fb_54[5];
    u32 _f_269 = _fb_54[6];
    Term _f_270 = _fb_54[7];
    u32 _f_271 = _fb_54[8];
    spare_free(e, cls_fit(9), _sp_54);
    Term _fv_29[1];
    _fv_29[0] = 220ull;
    Term _a_14 = blk_new(e, 0, 2ull, 0, 1, _fv_29);
    Term _at_82 = blk_loc(e.mem, _a_14);
    Term _at_83 = blk_at(_a_14, 1ull, 0);
    u32 _c_48 = blk_read(e.mem, 0, _at_82, _at_83 + 0);
    blk_write(e.mem, 0, _at_82, _at_83 + 0, U32_BIN(220ull, +, 1ull));
    Term _at_84 = blk_loc(e.mem, _a_14);
    Term _at_85 = blk_at(_a_14, 2ull, 0);
    u32 _c_49 = blk_read(e.mem, 0, _at_84, _at_85 + 0);
    blk_write(e.mem, 0, _at_84, _at_85 + 0, U32_BIN(220ull, +, 2ull));
    Term _at_86 = blk_loc(e.mem, _a_14);
    Term _at_87 = blk_at(_a_14, 3ull, 0);
    u32 _c_50 = blk_read(e.mem, 0, _at_86, _at_87 + 0);
    blk_write(e.mem, 0, _at_86, _at_87 + 0, U32_BIN(220ull, +, 3ull));
    u64 _nd_51 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_51 + 0] = rfc_seal(e, _a_14);
    e.mem[_nd_51 + 1] = rfc_seal(e, 220ull);
    Term _fv_30[1];
    _fv_30[0] = 230ull;
    Term _a_15 = blk_new(e, 0, 2ull, 0, 1, _fv_30);
    Term _at_88 = blk_loc(e.mem, _a_15);
    Term _at_89 = blk_at(_a_15, 1ull, 0);
    u32 _c_51 = blk_read(e.mem, 0, _at_88, _at_89 + 0);
    blk_write(e.mem, 0, _at_88, _at_89 + 0, U32_BIN(230ull, +, 1ull));
    Term _at_90 = blk_loc(e.mem, _a_15);
    Term _at_91 = blk_at(_a_15, 2ull, 0);
    u32 _c_52 = blk_read(e.mem, 0, _at_90, _at_91 + 0);
    blk_write(e.mem, 0, _at_90, _at_91 + 0, U32_BIN(230ull, +, 2ull));
    Term _at_92 = blk_loc(e.mem, _a_15);
    Term _at_93 = blk_at(_a_15, 3ull, 0);
    u32 _c_53 = blk_read(e.mem, 0, _at_92, _at_93 + 0);
    blk_write(e.mem, 0, _at_92, _at_93 + 0, U32_BIN(230ull, +, 3ull));
    u64 _nd_52 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_52 + 0] = rfc_seal(e, _a_15);
    e.mem[_nd_52 + 1] = rfc_seal(e, 230ull);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K364;
      WL_PUSHN(1);
    } else {
      u64 _t_78 = task_node(e, FID_MAIN_K364, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K364, _t_78);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_ROWS_PLACE)) {
      u64 _t_79 = task_node(e, FID_STORAGE_ROWS_PLACE, WL_CONT, WL_IDX, 0);
      e.mem[_t_79 + 0] = _f_263;
      e.mem[_t_79 + 1] = _f_264;
      e.mem[_t_79 + 2] = _f_265;
      e.mem[_t_79 + 3] = _f_266;
      e.mem[_t_79 + 4] = _f_267;
      e.mem[_t_79 + 5] = _f_268;
      e.mem[_t_79 + 6] = _f_269;
      e.mem[_t_79 + 7] = _f_270;
      e.mem[_t_79 + 8] = _f_271;
      e.mem[_t_79 + 9] = 4294967295ull;
      e.mem[_t_79 + 10] = 1;
      e.mem[_t_79 + 11] = term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_51);
      e.mem[_t_79 + 12] = 1;
      e.mem[_t_79 + 13] = term_ctr(CID____OWNED_INDEX_CORE_HEALTH, _nd_52);
      e.mem[_t_79 + 14] = 0;
      e.mem[_t_79 + 15] = 0;
      e.mem[_t_79 + 16] = 13ull;
      e.mem[_t_79 + 17] = 14ull;
      return term_tsk(FID_STORAGE_ROWS_PLACE, _t_79);
    }
    r0 = _f_263;
    r1 = _f_264;
    r2 = _f_265;
    r3 = _f_266;
    r4 = _f_267;
    r5 = _f_268;
    r6 = _f_269;
    r7 = _f_270;
    r8 = _f_271;
    r9 = 4294967295ull;
    r10 = 1;
    r11 = term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_51);
    r12 = 1;
    r13 = term_ctr(CID____OWNED_INDEX_CORE_HEALTH, _nd_52);
    r14 = 0;
    r15 = 0;
    r16 = 13ull;
    r17 = 14ull;
    WL_JMP(FID_STORAGE_ROWS_PLACE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K364)
  {
    u32 _h_211 = r0;
    Term _h_212 = r1;
    Term _h_213 = r2;
    Term _h_214 = r3;
    Term _h_215 = r4;
    Term _h_216 = r5;
    Term _h_217 = r6;
    u32 _h_218 = r7;
    Term _h_219 = r8;
    u32 _h_220 = r9;
    u32 _h_221 = r10;
    u32 _h_222 = r11;
    Term _h_223 = r12;
    u32 _h_224 = r13;
    Term _h_225 = r14;
    u32 _h_226 = r15;
    Term _h_227 = r16;
    u32 _h_228 = r17;
    u32 _h_229 = r18;
    WL_OPEN
    u32 _o_391 = 0;
    Term _o_392 = 0;
    Term _o_393 = 0;
    Term _o_394 = 0;
    Term _o_395 = 0;
    Term _o_396 = 0;
    Term _o_397 = 0;
    u32 _o_398 = 0;
    Term _o_399 = 0;
    u32 _o_400 = 0;
    u32 _o_401 = 0;
    u32 _o_402 = 0;
    Term _o_403 = 0;
    u32 _o_404 = 0;
    u32 _o_405 = 0;
    Term _o_406 = 0;
    u32 _o_407 = 0;
    u32 _o_408 = 0;
    u32 _o_409 = 0;
    u32 _o_410 = 0;
    if (_h_211 == 0) {
      _o_391 = 0;
      _o_392 = _h_212;
      _o_393 = _h_213;
      _o_394 = _h_214;
      _o_395 = _h_215;
      _o_396 = _h_216;
      _o_397 = _h_217;
      _o_398 = _h_218;
      _o_399 = _h_219;
      _o_400 = _h_220;
    } else {
      _o_391 = 1;
      u32 _o_411 = 0;
      Term _o_412 = 0;
      u32 _o_413 = 0;
      if (_h_222 == 0) {
        _o_411 = 0;
      } else {
        _o_411 = 1;
        Term _fb_55[2];
        u64 _sp_55 = ctr_take(e, _h_223, 2, _fb_55);
        Term _f_272 = _fb_55[0];
        u32 _f_273 = _fb_55[1];
        spare_free(e, cls_fit(2), _sp_55);
        _o_412 = _f_272;
        _o_413 = _f_273;
      }
      u32 _o_414 = 0;
      Term _o_415 = 0;
      u32 _o_416 = 0;
      if (_h_224 == 0) {
        _o_414 = 0;
      } else {
        _o_414 = 1;
        Term _fb_56[2];
        u64 _sp_56 = ctr_take(e, _h_225, 2, _fb_56);
        Term _f_274 = _fb_56[0];
        u32 _f_275 = _fb_56[1];
        spare_free(e, cls_fit(2), _sp_56);
        _o_415 = _f_274;
        _o_416 = _f_275;
      }
      u32 _o_417 = 0;
      if (_h_226 == 0) {
        _o_417 = 0;
      } else {
        _o_417 = 1;
      }
      _o_392 = _h_212;
      _o_393 = _h_213;
      _o_394 = _h_214;
      _o_395 = _h_215;
      _o_396 = _h_216;
      _o_397 = _h_217;
      _o_398 = _h_218;
      _o_399 = _h_219;
      _o_400 = _h_220;
      _o_401 = _h_221;
      _o_402 = _o_411;
      _o_403 = _o_412;
      _o_404 = _o_413;
      _o_405 = _o_414;
      _o_406 = _o_415;
      _o_407 = _o_416;
      _o_408 = _o_417;
      _o_409 = _h_228;
      _o_410 = _h_229;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K365;
      WL_PUSHN(1);
    } else {
      u64 _t_80 = task_node(e, FID_MAIN_K365, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K365, _t_80);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_PLACEMENT_PRINT)) {
      u64 _t_81 = task_node(e, FID_PLACEMENT_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_81 + 0] = term_ctr(CID_SCON, STAT_OFF + 354);
      e.mem[_t_81 + 1] = _o_391;
      e.mem[_t_81 + 2] = _o_392;
      e.mem[_t_81 + 3] = _o_393;
      e.mem[_t_81 + 4] = _o_394;
      e.mem[_t_81 + 5] = _o_395;
      e.mem[_t_81 + 6] = _o_396;
      e.mem[_t_81 + 7] = _o_397;
      e.mem[_t_81 + 8] = _o_398;
      e.mem[_t_81 + 9] = _o_399;
      e.mem[_t_81 + 10] = _o_400;
      e.mem[_t_81 + 11] = _o_401;
      e.mem[_t_81 + 12] = _o_402;
      e.mem[_t_81 + 13] = _o_403;
      e.mem[_t_81 + 14] = _o_404;
      e.mem[_t_81 + 15] = _o_405;
      e.mem[_t_81 + 16] = _o_406;
      e.mem[_t_81 + 17] = _o_407;
      e.mem[_t_81 + 18] = _o_408;
      e.mem[_t_81 + 19] = _o_409;
      e.mem[_t_81 + 20] = _o_410;
      return term_tsk(FID_PLACEMENT_PRINT, _t_81);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 354);
    r1 = _o_391;
    r2 = _o_392;
    r3 = _o_393;
    r4 = _o_394;
    r5 = _o_395;
    r6 = _o_396;
    r7 = _o_397;
    r8 = _o_398;
    r9 = _o_399;
    r10 = _o_400;
    r11 = _o_401;
    r12 = _o_402;
    r13 = _o_403;
    r14 = _o_404;
    r15 = _o_405;
    r16 = _o_406;
    r17 = _o_407;
    r18 = _o_408;
    r19 = _o_409;
    r20 = _o_410;
    WL_JMP(FID_PLACEMENT_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K365)
  {
    Term _h_230 = r0;
    WL_OPEN
    u64 _nd_53 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_53 + 0] = _h_230;
    r0 = term_clo(FID_MAIN_C366, _nd_53);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C366)
  {
    Term _h_231 = r0;
    Term _x_43 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_141 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_141 + 0] = _h_231;
      e.mem[_t_141 + 1] = term_clo(FID_MAIN_C367, 0);
      e.mem[_t_141 + 2] = _x_43;
      return term_tsk(FID_IO_BIND, _t_141);
    }
    r0 = _h_231;
    r1 = term_clo(FID_MAIN_C367, 0);
    r2 = _x_43;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C367)
  {
    Term _x_44 = r0;
    WL_OPEN
    Term _fb_57[9];
    u64 _sp_57 = ctr_take(e, _x_44, 9, _fb_57);
    Term _f_276 = _fb_57[0];
    Term _f_277 = _fb_57[1];
    Term _f_278 = _fb_57[2];
    Term _f_279 = _fb_57[3];
    Term _f_280 = _fb_57[4];
    Term _f_281 = _fb_57[5];
    u32 _f_282 = _fb_57[6];
    Term _f_283 = _fb_57[7];
    u32 _f_284 = _fb_57[8];
    spare_free(e, cls_fit(9), _sp_57);
    Term _fv_31[1];
    _fv_31[0] = 240ull;
    Term _a_16 = blk_new(e, 0, 2ull, 0, 1, _fv_31);
    Term _at_94 = blk_loc(e.mem, _a_16);
    Term _at_95 = blk_at(_a_16, 1ull, 0);
    u32 _c_54 = blk_read(e.mem, 0, _at_94, _at_95 + 0);
    blk_write(e.mem, 0, _at_94, _at_95 + 0, U32_BIN(240ull, +, 1ull));
    Term _at_96 = blk_loc(e.mem, _a_16);
    Term _at_97 = blk_at(_a_16, 2ull, 0);
    u32 _c_55 = blk_read(e.mem, 0, _at_96, _at_97 + 0);
    blk_write(e.mem, 0, _at_96, _at_97 + 0, U32_BIN(240ull, +, 2ull));
    Term _at_98 = blk_loc(e.mem, _a_16);
    Term _at_99 = blk_at(_a_16, 3ull, 0);
    u32 _c_56 = blk_read(e.mem, 0, _at_98, _at_99 + 0);
    blk_write(e.mem, 0, _at_98, _at_99 + 0, U32_BIN(240ull, +, 3ull));
    u64 _nd_54 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_54 + 0] = rfc_seal(e, _a_16);
    e.mem[_nd_54 + 1] = rfc_seal(e, 240ull);
    Term _fv_32[1];
    _fv_32[0] = 250ull;
    Term _a_17 = blk_new(e, 0, 2ull, 0, 1, _fv_32);
    Term _at_100 = blk_loc(e.mem, _a_17);
    Term _at_101 = blk_at(_a_17, 1ull, 0);
    u32 _c_57 = blk_read(e.mem, 0, _at_100, _at_101 + 0);
    blk_write(e.mem, 0, _at_100, _at_101 + 0, U32_BIN(250ull, +, 1ull));
    Term _at_102 = blk_loc(e.mem, _a_17);
    Term _at_103 = blk_at(_a_17, 2ull, 0);
    u32 _c_58 = blk_read(e.mem, 0, _at_102, _at_103 + 0);
    blk_write(e.mem, 0, _at_102, _at_103 + 0, U32_BIN(250ull, +, 2ull));
    Term _at_104 = blk_loc(e.mem, _a_17);
    Term _at_105 = blk_at(_a_17, 3ull, 0);
    u32 _c_59 = blk_read(e.mem, 0, _at_104, _at_105 + 0);
    blk_write(e.mem, 0, _at_104, _at_105 + 0, U32_BIN(250ull, +, 3ull));
    u64 _nd_55 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_55 + 0] = rfc_seal(e, _a_17);
    e.mem[_nd_55 + 1] = rfc_seal(e, 250ull);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K368;
      WL_PUSHN(1);
    } else {
      u64 _t_82 = task_node(e, FID_MAIN_K368, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K368, _t_82);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_ROWS_PLACE)) {
      u64 _t_83 = task_node(e, FID_STORAGE_ROWS_PLACE, WL_CONT, WL_IDX, 0);
      e.mem[_t_83 + 0] = _f_276;
      e.mem[_t_83 + 1] = _f_277;
      e.mem[_t_83 + 2] = _f_278;
      e.mem[_t_83 + 3] = _f_279;
      e.mem[_t_83 + 4] = _f_280;
      e.mem[_t_83 + 5] = _f_281;
      e.mem[_t_83 + 6] = _f_282;
      e.mem[_t_83 + 7] = _f_283;
      e.mem[_t_83 + 8] = _f_284;
      e.mem[_t_83 + 9] = 1ull;
      e.mem[_t_83 + 10] = 1;
      e.mem[_t_83 + 11] = term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_54);
      e.mem[_t_83 + 12] = 1;
      e.mem[_t_83 + 13] = term_ctr(CID____OWNED_INDEX_CORE_HEALTH, _nd_55);
      e.mem[_t_83 + 14] = 0;
      e.mem[_t_83 + 15] = 0;
      e.mem[_t_83 + 16] = 15ull;
      e.mem[_t_83 + 17] = 16ull;
      return term_tsk(FID_STORAGE_ROWS_PLACE, _t_83);
    }
    r0 = _f_276;
    r1 = _f_277;
    r2 = _f_278;
    r3 = _f_279;
    r4 = _f_280;
    r5 = _f_281;
    r6 = _f_282;
    r7 = _f_283;
    r8 = _f_284;
    r9 = 1ull;
    r10 = 1;
    r11 = term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_54);
    r12 = 1;
    r13 = term_ctr(CID____OWNED_INDEX_CORE_HEALTH, _nd_55);
    r14 = 0;
    r15 = 0;
    r16 = 15ull;
    r17 = 16ull;
    WL_JMP(FID_STORAGE_ROWS_PLACE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K368)
  {
    u32 _h_232 = r0;
    Term _h_233 = r1;
    Term _h_234 = r2;
    Term _h_235 = r3;
    Term _h_236 = r4;
    Term _h_237 = r5;
    Term _h_238 = r6;
    u32 _h_239 = r7;
    Term _h_240 = r8;
    u32 _h_241 = r9;
    u32 _h_242 = r10;
    u32 _h_243 = r11;
    Term _h_244 = r12;
    u32 _h_245 = r13;
    Term _h_246 = r14;
    u32 _h_247 = r15;
    Term _h_248 = r16;
    u32 _h_249 = r17;
    u32 _h_250 = r18;
    WL_OPEN
    u32 _o_418 = 0;
    Term _o_419 = 0;
    Term _o_420 = 0;
    Term _o_421 = 0;
    Term _o_422 = 0;
    Term _o_423 = 0;
    Term _o_424 = 0;
    u32 _o_425 = 0;
    Term _o_426 = 0;
    u32 _o_427 = 0;
    u32 _o_428 = 0;
    u32 _o_429 = 0;
    Term _o_430 = 0;
    u32 _o_431 = 0;
    u32 _o_432 = 0;
    Term _o_433 = 0;
    u32 _o_434 = 0;
    u32 _o_435 = 0;
    u32 _o_436 = 0;
    u32 _o_437 = 0;
    if (_h_232 == 0) {
      _o_418 = 0;
      _o_419 = _h_233;
      _o_420 = _h_234;
      _o_421 = _h_235;
      _o_422 = _h_236;
      _o_423 = _h_237;
      _o_424 = _h_238;
      _o_425 = _h_239;
      _o_426 = _h_240;
      _o_427 = _h_241;
    } else {
      _o_418 = 1;
      u32 _o_438 = 0;
      Term _o_439 = 0;
      u32 _o_440 = 0;
      if (_h_243 == 0) {
        _o_438 = 0;
      } else {
        _o_438 = 1;
        Term _fb_58[2];
        u64 _sp_58 = ctr_take(e, _h_244, 2, _fb_58);
        Term _f_285 = _fb_58[0];
        u32 _f_286 = _fb_58[1];
        spare_free(e, cls_fit(2), _sp_58);
        _o_439 = _f_285;
        _o_440 = _f_286;
      }
      u32 _o_441 = 0;
      Term _o_442 = 0;
      u32 _o_443 = 0;
      if (_h_245 == 0) {
        _o_441 = 0;
      } else {
        _o_441 = 1;
        Term _fb_59[2];
        u64 _sp_59 = ctr_take(e, _h_246, 2, _fb_59);
        Term _f_287 = _fb_59[0];
        u32 _f_288 = _fb_59[1];
        spare_free(e, cls_fit(2), _sp_59);
        _o_442 = _f_287;
        _o_443 = _f_288;
      }
      u32 _o_444 = 0;
      if (_h_247 == 0) {
        _o_444 = 0;
      } else {
        _o_444 = 1;
      }
      _o_419 = _h_233;
      _o_420 = _h_234;
      _o_421 = _h_235;
      _o_422 = _h_236;
      _o_423 = _h_237;
      _o_424 = _h_238;
      _o_425 = _h_239;
      _o_426 = _h_240;
      _o_427 = _h_241;
      _o_428 = _h_242;
      _o_429 = _o_438;
      _o_430 = _o_439;
      _o_431 = _o_440;
      _o_432 = _o_441;
      _o_433 = _o_442;
      _o_434 = _o_443;
      _o_435 = _o_444;
      _o_436 = _h_249;
      _o_437 = _h_250;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K369;
      WL_PUSHN(1);
    } else {
      u64 _t_84 = task_node(e, FID_MAIN_K369, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K369, _t_84);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_PLACEMENT_PRINT)) {
      u64 _t_85 = task_node(e, FID_PLACEMENT_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_85 + 0] = term_ctr(CID_SCON, STAT_OFF + 378);
      e.mem[_t_85 + 1] = _o_418;
      e.mem[_t_85 + 2] = _o_419;
      e.mem[_t_85 + 3] = _o_420;
      e.mem[_t_85 + 4] = _o_421;
      e.mem[_t_85 + 5] = _o_422;
      e.mem[_t_85 + 6] = _o_423;
      e.mem[_t_85 + 7] = _o_424;
      e.mem[_t_85 + 8] = _o_425;
      e.mem[_t_85 + 9] = _o_426;
      e.mem[_t_85 + 10] = _o_427;
      e.mem[_t_85 + 11] = _o_428;
      e.mem[_t_85 + 12] = _o_429;
      e.mem[_t_85 + 13] = _o_430;
      e.mem[_t_85 + 14] = _o_431;
      e.mem[_t_85 + 15] = _o_432;
      e.mem[_t_85 + 16] = _o_433;
      e.mem[_t_85 + 17] = _o_434;
      e.mem[_t_85 + 18] = _o_435;
      e.mem[_t_85 + 19] = _o_436;
      e.mem[_t_85 + 20] = _o_437;
      return term_tsk(FID_PLACEMENT_PRINT, _t_85);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 378);
    r1 = _o_418;
    r2 = _o_419;
    r3 = _o_420;
    r4 = _o_421;
    r5 = _o_422;
    r6 = _o_423;
    r7 = _o_424;
    r8 = _o_425;
    r9 = _o_426;
    r10 = _o_427;
    r11 = _o_428;
    r12 = _o_429;
    r13 = _o_430;
    r14 = _o_431;
    r15 = _o_432;
    r16 = _o_433;
    r17 = _o_434;
    r18 = _o_435;
    r19 = _o_436;
    r20 = _o_437;
    WL_JMP(FID_PLACEMENT_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K369)
  {
    Term _h_251 = r0;
    WL_OPEN
    u64 _nd_56 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_56 + 0] = _h_251;
    r0 = term_clo(FID_MAIN_C370, _nd_56);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C370)
  {
    Term _h_252 = r0;
    Term _x_45 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_140 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_140 + 0] = _h_252;
      e.mem[_t_140 + 1] = term_clo(FID_MAIN_C371, 0);
      e.mem[_t_140 + 2] = _x_45;
      return term_tsk(FID_IO_BIND, _t_140);
    }
    r0 = _h_252;
    r1 = term_clo(FID_MAIN_C371, 0);
    r2 = _x_45;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C371)
  {
    Term _x_46 = r0;
    WL_OPEN
    Term _fb_60[9];
    u64 _sp_60 = ctr_take(e, _x_46, 9, _fb_60);
    Term _f_289 = _fb_60[0];
    Term _f_290 = _fb_60[1];
    Term _f_291 = _fb_60[2];
    Term _f_292 = _fb_60[3];
    Term _f_293 = _fb_60[4];
    Term _f_294 = _fb_60[5];
    u32 _f_295 = _fb_60[6];
    Term _f_296 = _fb_60[7];
    u32 _f_297 = _fb_60[8];
    spare_free(e, cls_fit(9), _sp_60);
    Term _v_876 = 0;
    Term _v_877 = 0;
    Term _v_878 = 0;
    Term _v_879 = 0;
    Term _v_880 = 0;
    Term _v_881 = 0;
    u32 _v_882 = 0;
    Term _v_883 = 0;
    u32 _v_884 = 0;
    u32 _v_885 = 0;
    u32 _v_886 = 0;
    u32 _v_887 = 0;
    Term _v_888 = 0;
    u32 _v_889 = 0;
    Term _v_890 = 0;
    u32 _v_891 = 0;
    Term _v_892 = 0;
    u32 _v_893 = 0;
    u32 _v_894 = 0;
    Term _v_895 = 0;
    Term _v_896 = 0;
    Term _v_897 = 0;
    Term _v_898 = 0;
    Term _v_899 = 0;
    Term _v_900 = 0;
    u32 _v_901 = 0;
    Term _v_902 = 0;
    u32 _v_903 = 0;
    u32 _v_904 = 0;
    u32 _v_905 = 0;
    u32 _v_906 = 0;
    Term _v_907 = 0;
    u32 _v_908 = 0;
    Term _v_909 = 0;
    u32 _v_910 = 0;
    Term _v_911 = 0;
    u32 _v_912 = 0;
    u32 _v_913 = 0;
    Term _o_445[19];
    if (spin_44(e, _o_445, _f_289, blk_loc(e.mem, _f_289), _f_290, blk_loc(e.mem, _f_290), _f_291, blk_loc(e.mem, _f_291), _f_292, blk_loc(e.mem, _f_292), _f_293, blk_loc(e.mem, _f_293), _f_294, blk_loc(e.mem, _f_294), _f_295, _f_296, _f_297, 1ull) == 0) {
      return 0;
    }
    _v_895 = _o_445[0];
    _v_896 = _o_445[1];
    _v_897 = _o_445[2];
    _v_898 = _o_445[3];
    _v_899 = _o_445[4];
    _v_900 = _o_445[5];
    _v_901 = _o_445[6];
    _v_902 = _o_445[7];
    _v_903 = _o_445[8];
    _v_904 = _o_445[9];
    _v_905 = _o_445[10];
    _v_906 = _o_445[11];
    _v_907 = _o_445[12];
    _v_908 = _o_445[13];
    _v_909 = _o_445[14];
    _v_910 = _o_445[15];
    _v_911 = _o_445[16];
    _v_912 = _o_445[17];
    _v_913 = _o_445[18];
    _v_876 = _v_895;
    _v_877 = _v_896;
    _v_878 = _v_897;
    _v_879 = _v_898;
    _v_880 = _v_899;
    _v_881 = _v_900;
    _v_882 = _v_901;
    _v_883 = _v_902;
    _v_884 = _v_903;
    _v_885 = _v_904;
    _v_886 = _v_905;
    _v_887 = _v_906;
    _v_888 = _v_907;
    _v_889 = _v_908;
    _v_890 = _v_909;
    _v_891 = _v_910;
    _v_892 = _v_911;
    _v_893 = _v_912;
    _v_894 = _v_913;
    u32 _o_446 = 0;
    u32 _o_447 = 0;
    u32 _o_448 = 0;
    Term _o_449 = 0;
    u32 _o_450 = 0;
    u32 _o_451 = 0;
    Term _o_452 = 0;
    u32 _o_453 = 0;
    u32 _o_454 = 0;
    u32 _o_455 = 0;
    u32 _o_456 = 0;
    if (_v_885 == 0) {
      _o_446 = 0;
    } else {
      _o_446 = 1;
      u32 _o_457 = 0;
      Term _o_458 = 0;
      u32 _o_459 = 0;
      if (_v_887 == 0) {
        _o_457 = 0;
      } else {
        _o_457 = 1;
        Term _fb_61[2];
        u64 _sp_61 = ctr_take(e, _v_888, 2, _fb_61);
        Term _f_298 = _fb_61[0];
        u32 _f_299 = _fb_61[1];
        spare_free(e, cls_fit(2), _sp_61);
        _o_458 = _f_298;
        _o_459 = _f_299;
      }
      u32 _o_460 = 0;
      Term _o_461 = 0;
      u32 _o_462 = 0;
      if (_v_889 == 0) {
        _o_460 = 0;
      } else {
        _o_460 = 1;
        Term _fb_62[2];
        u64 _sp_62 = ctr_take(e, _v_890, 2, _fb_62);
        Term _f_300 = _fb_62[0];
        u32 _f_301 = _fb_62[1];
        spare_free(e, cls_fit(2), _sp_62);
        _o_461 = _f_300;
        _o_462 = _f_301;
      }
      u32 _o_463 = 0;
      if (_v_891 == 0) {
        _o_463 = 0;
      } else {
        _o_463 = 1;
      }
      _o_447 = _v_886;
      _o_448 = _o_457;
      _o_449 = _o_458;
      _o_450 = _o_459;
      _o_451 = _o_460;
      _o_452 = _o_461;
      _o_453 = _o_462;
      _o_454 = _o_463;
      _o_455 = _v_893;
      _o_456 = _v_894;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K372;
      WL_PUSHN(1);
    } else {
      u64 _t_86 = task_node(e, FID_MAIN_K372, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K372, _t_86);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOOKUP_PRINT)) {
      u64 _t_87 = task_node(e, FID_LOOKUP_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_87 + 0] = term_ctr(CID_SCON, STAT_OFF + 396);
      e.mem[_t_87 + 1] = _v_876;
      e.mem[_t_87 + 2] = _v_877;
      e.mem[_t_87 + 3] = _v_878;
      e.mem[_t_87 + 4] = _v_879;
      e.mem[_t_87 + 5] = _v_880;
      e.mem[_t_87 + 6] = _v_881;
      e.mem[_t_87 + 7] = _v_882;
      e.mem[_t_87 + 8] = _v_883;
      e.mem[_t_87 + 9] = _v_884;
      e.mem[_t_87 + 10] = _o_446;
      e.mem[_t_87 + 11] = _o_447;
      e.mem[_t_87 + 12] = _o_448;
      e.mem[_t_87 + 13] = _o_449;
      e.mem[_t_87 + 14] = _o_450;
      e.mem[_t_87 + 15] = _o_451;
      e.mem[_t_87 + 16] = _o_452;
      e.mem[_t_87 + 17] = _o_453;
      e.mem[_t_87 + 18] = _o_454;
      e.mem[_t_87 + 19] = _o_455;
      e.mem[_t_87 + 20] = _o_456;
      return term_tsk(FID_LOOKUP_PRINT, _t_87);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 396);
    r1 = _v_876;
    r2 = _v_877;
    r3 = _v_878;
    r4 = _v_879;
    r5 = _v_880;
    r6 = _v_881;
    r7 = _v_882;
    r8 = _v_883;
    r9 = _v_884;
    r10 = _o_446;
    r11 = _o_447;
    r12 = _o_448;
    r13 = _o_449;
    r14 = _o_450;
    r15 = _o_451;
    r16 = _o_452;
    r17 = _o_453;
    r18 = _o_454;
    r19 = _o_455;
    r20 = _o_456;
    WL_JMP(FID_LOOKUP_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K372)
  {
    Term _h_253 = r0;
    WL_OPEN
    u64 _nd_57 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_57 + 0] = _h_253;
    r0 = term_clo(FID_MAIN_C373, _nd_57);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C373)
  {
    Term _h_254 = r0;
    Term _x_47 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_139 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_139 + 0] = _h_254;
      e.mem[_t_139 + 1] = term_clo(FID_MAIN_C374, 0);
      e.mem[_t_139 + 2] = _x_47;
      return term_tsk(FID_IO_BIND, _t_139);
    }
    r0 = _h_254;
    r1 = term_clo(FID_MAIN_C374, 0);
    r2 = _x_47;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C374)
  {
    Term _x_48 = r0;
    WL_OPEN
    Term _fb_63[9];
    u64 _sp_63 = ctr_take(e, _x_48, 9, _fb_63);
    Term _f_302 = _fb_63[0];
    Term _f_303 = _fb_63[1];
    Term _f_304 = _fb_63[2];
    Term _f_305 = _fb_63[3];
    Term _f_306 = _fb_63[4];
    Term _f_307 = _fb_63[5];
    u32 _f_308 = _fb_63[6];
    Term _f_309 = _fb_63[7];
    u32 _f_310 = _fb_63[8];
    spare_free(e, cls_fit(9), _sp_63);
    Term _v_914 = 0;
    Term _v_915 = 0;
    Term _v_916 = 0;
    Term _v_917 = 0;
    Term _v_918 = 0;
    Term _v_919 = 0;
    u32 _v_920 = 0;
    Term _v_921 = 0;
    u32 _v_922 = 0;
    u32 _v_923 = 0;
    u32 _v_924 = 0;
    u32 _v_925 = 0;
    Term _v_926 = 0;
    u32 _v_927 = 0;
    Term _v_928 = 0;
    u32 _v_929 = 0;
    Term _v_930 = 0;
    u32 _v_931 = 0;
    u32 _v_932 = 0;
    Term _v_933 = 0;
    Term _v_934 = 0;
    Term _v_935 = 0;
    Term _v_936 = 0;
    Term _v_937 = 0;
    Term _v_938 = 0;
    u32 _v_939 = 0;
    Term _v_940 = 0;
    u32 _v_941 = 0;
    u32 _v_942 = 0;
    u32 _v_943 = 0;
    u32 _v_944 = 0;
    Term _v_945 = 0;
    u32 _v_946 = 0;
    Term _v_947 = 0;
    u32 _v_948 = 0;
    Term _v_949 = 0;
    u32 _v_950 = 0;
    u32 _v_951 = 0;
    Term _o_464[19];
    if (spin_44(e, _o_464, _f_302, blk_loc(e.mem, _f_302), _f_303, blk_loc(e.mem, _f_303), _f_304, blk_loc(e.mem, _f_304), _f_305, blk_loc(e.mem, _f_305), _f_306, blk_loc(e.mem, _f_306), _f_307, blk_loc(e.mem, _f_307), _f_308, _f_309, _f_310, 65537ull) == 0) {
      return 0;
    }
    _v_933 = _o_464[0];
    _v_934 = _o_464[1];
    _v_935 = _o_464[2];
    _v_936 = _o_464[3];
    _v_937 = _o_464[4];
    _v_938 = _o_464[5];
    _v_939 = _o_464[6];
    _v_940 = _o_464[7];
    _v_941 = _o_464[8];
    _v_942 = _o_464[9];
    _v_943 = _o_464[10];
    _v_944 = _o_464[11];
    _v_945 = _o_464[12];
    _v_946 = _o_464[13];
    _v_947 = _o_464[14];
    _v_948 = _o_464[15];
    _v_949 = _o_464[16];
    _v_950 = _o_464[17];
    _v_951 = _o_464[18];
    _v_914 = _v_933;
    _v_915 = _v_934;
    _v_916 = _v_935;
    _v_917 = _v_936;
    _v_918 = _v_937;
    _v_919 = _v_938;
    _v_920 = _v_939;
    _v_921 = _v_940;
    _v_922 = _v_941;
    _v_923 = _v_942;
    _v_924 = _v_943;
    _v_925 = _v_944;
    _v_926 = _v_945;
    _v_927 = _v_946;
    _v_928 = _v_947;
    _v_929 = _v_948;
    _v_930 = _v_949;
    _v_931 = _v_950;
    _v_932 = _v_951;
    u32 _o_465 = 0;
    u32 _o_466 = 0;
    u32 _o_467 = 0;
    Term _o_468 = 0;
    u32 _o_469 = 0;
    u32 _o_470 = 0;
    Term _o_471 = 0;
    u32 _o_472 = 0;
    u32 _o_473 = 0;
    u32 _o_474 = 0;
    u32 _o_475 = 0;
    if (_v_923 == 0) {
      _o_465 = 0;
    } else {
      _o_465 = 1;
      u32 _o_476 = 0;
      Term _o_477 = 0;
      u32 _o_478 = 0;
      if (_v_925 == 0) {
        _o_476 = 0;
      } else {
        _o_476 = 1;
        Term _fb_64[2];
        u64 _sp_64 = ctr_take(e, _v_926, 2, _fb_64);
        Term _f_311 = _fb_64[0];
        u32 _f_312 = _fb_64[1];
        spare_free(e, cls_fit(2), _sp_64);
        _o_477 = _f_311;
        _o_478 = _f_312;
      }
      u32 _o_479 = 0;
      Term _o_480 = 0;
      u32 _o_481 = 0;
      if (_v_927 == 0) {
        _o_479 = 0;
      } else {
        _o_479 = 1;
        Term _fb_65[2];
        u64 _sp_65 = ctr_take(e, _v_928, 2, _fb_65);
        Term _f_313 = _fb_65[0];
        u32 _f_314 = _fb_65[1];
        spare_free(e, cls_fit(2), _sp_65);
        _o_480 = _f_313;
        _o_481 = _f_314;
      }
      u32 _o_482 = 0;
      if (_v_929 == 0) {
        _o_482 = 0;
      } else {
        _o_482 = 1;
      }
      _o_466 = _v_924;
      _o_467 = _o_476;
      _o_468 = _o_477;
      _o_469 = _o_478;
      _o_470 = _o_479;
      _o_471 = _o_480;
      _o_472 = _o_481;
      _o_473 = _o_482;
      _o_474 = _v_931;
      _o_475 = _v_932;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K375;
      WL_PUSHN(1);
    } else {
      u64 _t_88 = task_node(e, FID_MAIN_K375, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K375, _t_88);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOOKUP_PRINT)) {
      u64 _t_89 = task_node(e, FID_LOOKUP_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_89 + 0] = term_ctr(CID_SCON, STAT_OFF + 414);
      e.mem[_t_89 + 1] = _v_914;
      e.mem[_t_89 + 2] = _v_915;
      e.mem[_t_89 + 3] = _v_916;
      e.mem[_t_89 + 4] = _v_917;
      e.mem[_t_89 + 5] = _v_918;
      e.mem[_t_89 + 6] = _v_919;
      e.mem[_t_89 + 7] = _v_920;
      e.mem[_t_89 + 8] = _v_921;
      e.mem[_t_89 + 9] = _v_922;
      e.mem[_t_89 + 10] = _o_465;
      e.mem[_t_89 + 11] = _o_466;
      e.mem[_t_89 + 12] = _o_467;
      e.mem[_t_89 + 13] = _o_468;
      e.mem[_t_89 + 14] = _o_469;
      e.mem[_t_89 + 15] = _o_470;
      e.mem[_t_89 + 16] = _o_471;
      e.mem[_t_89 + 17] = _o_472;
      e.mem[_t_89 + 18] = _o_473;
      e.mem[_t_89 + 19] = _o_474;
      e.mem[_t_89 + 20] = _o_475;
      return term_tsk(FID_LOOKUP_PRINT, _t_89);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 414);
    r1 = _v_914;
    r2 = _v_915;
    r3 = _v_916;
    r4 = _v_917;
    r5 = _v_918;
    r6 = _v_919;
    r7 = _v_920;
    r8 = _v_921;
    r9 = _v_922;
    r10 = _o_465;
    r11 = _o_466;
    r12 = _o_467;
    r13 = _o_468;
    r14 = _o_469;
    r15 = _o_470;
    r16 = _o_471;
    r17 = _o_472;
    r18 = _o_473;
    r19 = _o_474;
    r20 = _o_475;
    WL_JMP(FID_LOOKUP_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K375)
  {
    Term _h_255 = r0;
    WL_OPEN
    u64 _nd_58 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_58 + 0] = _h_255;
    r0 = term_clo(FID_MAIN_C376, _nd_58);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C376)
  {
    Term _h_256 = r0;
    Term _x_49 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_138 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_138 + 0] = _h_256;
      e.mem[_t_138 + 1] = term_clo(FID_MAIN_C377, 0);
      e.mem[_t_138 + 2] = _x_49;
      return term_tsk(FID_IO_BIND, _t_138);
    }
    r0 = _h_256;
    r1 = term_clo(FID_MAIN_C377, 0);
    r2 = _x_49;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C377)
  {
    Term _x_50 = r0;
    WL_OPEN
    Term _fb_66[9];
    u64 _sp_66 = ctr_take(e, _x_50, 9, _fb_66);
    Term _f_315 = _fb_66[0];
    Term _f_316 = _fb_66[1];
    Term _f_317 = _fb_66[2];
    Term _f_318 = _fb_66[3];
    Term _f_319 = _fb_66[4];
    Term _f_320 = _fb_66[5];
    u32 _f_321 = _fb_66[6];
    Term _f_322 = _fb_66[7];
    u32 _f_323 = _fb_66[8];
    spare_free(e, cls_fit(9), _sp_66);
    Term _v_952 = 0;
    Term _v_953 = 0;
    Term _v_954 = 0;
    Term _v_955 = 0;
    Term _v_956 = 0;
    Term _v_957 = 0;
    u32 _v_958 = 0;
    Term _v_959 = 0;
    u32 _v_960 = 0;
    u32 _v_961 = 0;
    Term _fv_33[1];
    _fv_33[0] = 20ull;
    Term _a_18 = blk_new(e, 0, 2ull, 0, 1, _fv_33);
    Term _at_106 = blk_loc(e.mem, _a_18);
    Term _at_107 = blk_at(_a_18, 1ull, 0);
    u32 _c_60 = blk_read(e.mem, 0, _at_106, _at_107 + 0);
    blk_write(e.mem, 0, _at_106, _at_107 + 0, U32_BIN(20ull, +, 1ull));
    Term _at_108 = blk_loc(e.mem, _a_18);
    Term _at_109 = blk_at(_a_18, 2ull, 0);
    u32 _c_61 = blk_read(e.mem, 0, _at_108, _at_109 + 0);
    blk_write(e.mem, 0, _at_108, _at_109 + 0, U32_BIN(20ull, +, 2ull));
    Term _at_110 = blk_loc(e.mem, _a_18);
    Term _at_111 = blk_at(_a_18, 3ull, 0);
    u32 _c_62 = blk_read(e.mem, 0, _at_110, _at_111 + 0);
    blk_write(e.mem, 0, _at_110, _at_111 + 0, U32_BIN(20ull, +, 3ull));
    u64 _nd_59 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_59 + 0] = rfc_seal(e, _a_18);
    e.mem[_nd_59 + 1] = rfc_seal(e, 20ull);
    Term _v_962 = 0;
    Term _v_963 = 0;
    Term _v_964 = 0;
    Term _v_965 = 0;
    Term _v_966 = 0;
    Term _v_967 = 0;
    u32 _v_968 = 0;
    Term _v_969 = 0;
    u32 _v_970 = 0;
    u32 _v_971 = 0;
    Term _o_496[10];
    Term _a_19 = term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_59);
    if (spin_60(e, _o_496, _f_315, blk_loc(e.mem, _f_315), _f_316, blk_loc(e.mem, _f_316), _f_317, blk_loc(e.mem, _f_317), _f_318, blk_loc(e.mem, _f_318), _f_319, blk_loc(e.mem, _f_319), _f_320, blk_loc(e.mem, _f_320), _f_321, _f_322, _f_323, 2ull, 1, _a_19, blk_loc(e.mem, _a_19), 50ull) == 0) {
      return 0;
    }
    _v_962 = _o_496[0];
    _v_963 = _o_496[1];
    _v_964 = _o_496[2];
    _v_965 = _o_496[3];
    _v_966 = _o_496[4];
    _v_967 = _o_496[5];
    _v_968 = _o_496[6];
    _v_969 = _o_496[7];
    _v_970 = _o_496[8];
    _v_971 = _o_496[9];
    _v_952 = _v_962;
    _v_953 = _v_963;
    _v_954 = _v_964;
    _v_955 = _v_965;
    _v_956 = _v_966;
    _v_957 = _v_967;
    _v_958 = _v_968;
    _v_959 = _v_969;
    _v_960 = _v_970;
    _v_961 = _v_971;
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K378;
      WL_PUSHN(1);
    } else {
      u64 _t_90 = task_node(e, FID_MAIN_K378, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K378, _t_90);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_EFFECT_PRINT)) {
      u64 _t_91 = task_node(e, FID_EFFECT_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_91 + 0] = term_ctr(CID_SCON, STAT_OFF + 428);
      e.mem[_t_91 + 1] = _v_952;
      e.mem[_t_91 + 2] = _v_953;
      e.mem[_t_91 + 3] = _v_954;
      e.mem[_t_91 + 4] = _v_955;
      e.mem[_t_91 + 5] = _v_956;
      e.mem[_t_91 + 6] = _v_957;
      e.mem[_t_91 + 7] = _v_958;
      e.mem[_t_91 + 8] = _v_959;
      e.mem[_t_91 + 9] = _v_960;
      e.mem[_t_91 + 10] = _v_961;
      return term_tsk(FID_EFFECT_PRINT, _t_91);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 428);
    r1 = _v_952;
    r2 = _v_953;
    r3 = _v_954;
    r4 = _v_955;
    r5 = _v_956;
    r6 = _v_957;
    r7 = _v_958;
    r8 = _v_959;
    r9 = _v_960;
    r10 = _v_961;
    WL_JMP(FID_EFFECT_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K378)
  {
    Term _h_257 = r0;
    WL_OPEN
    u64 _nd_60 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_60 + 0] = _h_257;
    r0 = term_clo(FID_MAIN_C379, _nd_60);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C379)
  {
    Term _h_258 = r0;
    Term _x_51 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_137 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_137 + 0] = _h_258;
      e.mem[_t_137 + 1] = term_clo(FID_MAIN_C380, 0);
      e.mem[_t_137 + 2] = _x_51;
      return term_tsk(FID_IO_BIND, _t_137);
    }
    r0 = _h_258;
    r1 = term_clo(FID_MAIN_C380, 0);
    r2 = _x_51;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C380)
  {
    Term _x_52 = r0;
    WL_OPEN
    Term _fb_67[9];
    u64 _sp_67 = ctr_take(e, _x_52, 9, _fb_67);
    Term _f_324 = _fb_67[0];
    Term _f_325 = _fb_67[1];
    Term _f_326 = _fb_67[2];
    Term _f_327 = _fb_67[3];
    Term _f_328 = _fb_67[4];
    Term _f_329 = _fb_67[5];
    u32 _f_330 = _fb_67[6];
    Term _f_331 = _fb_67[7];
    u32 _f_332 = _fb_67[8];
    spare_free(e, cls_fit(9), _sp_67);
    Term _v_1158 = 0;
    Term _v_1159 = 0;
    Term _v_1160 = 0;
    Term _v_1161 = 0;
    Term _v_1162 = 0;
    Term _v_1163 = 0;
    u32 _v_1164 = 0;
    Term _v_1165 = 0;
    u32 _v_1166 = 0;
    u32 _v_1167 = 0;
    u32 _v_1168 = 0;
    u32 _v_1169 = 0;
    Term _v_1170 = 0;
    u32 _v_1171 = 0;
    Term _v_1172 = 0;
    u32 _v_1173 = 0;
    Term _v_1174 = 0;
    u32 _v_1175 = 0;
    u32 _v_1176 = 0;
    Term _v_1177 = 0;
    Term _v_1178 = 0;
    Term _v_1179 = 0;
    Term _v_1180 = 0;
    Term _v_1181 = 0;
    Term _v_1182 = 0;
    u32 _v_1183 = 0;
    Term _v_1184 = 0;
    u32 _v_1185 = 0;
    u32 _v_1186 = 0;
    u32 _v_1187 = 0;
    u32 _v_1188 = 0;
    Term _v_1189 = 0;
    u32 _v_1190 = 0;
    Term _v_1191 = 0;
    u32 _v_1192 = 0;
    Term _v_1193 = 0;
    u32 _v_1194 = 0;
    u32 _v_1195 = 0;
    Term _o_497[19];
    if (spin_44(e, _o_497, _f_324, blk_loc(e.mem, _f_324), _f_325, blk_loc(e.mem, _f_325), _f_326, blk_loc(e.mem, _f_326), _f_327, blk_loc(e.mem, _f_327), _f_328, blk_loc(e.mem, _f_328), _f_329, blk_loc(e.mem, _f_329), _f_330, _f_331, _f_332, 2ull) == 0) {
      return 0;
    }
    _v_1177 = _o_497[0];
    _v_1178 = _o_497[1];
    _v_1179 = _o_497[2];
    _v_1180 = _o_497[3];
    _v_1181 = _o_497[4];
    _v_1182 = _o_497[5];
    _v_1183 = _o_497[6];
    _v_1184 = _o_497[7];
    _v_1185 = _o_497[8];
    _v_1186 = _o_497[9];
    _v_1187 = _o_497[10];
    _v_1188 = _o_497[11];
    _v_1189 = _o_497[12];
    _v_1190 = _o_497[13];
    _v_1191 = _o_497[14];
    _v_1192 = _o_497[15];
    _v_1193 = _o_497[16];
    _v_1194 = _o_497[17];
    _v_1195 = _o_497[18];
    _v_1158 = _v_1177;
    _v_1159 = _v_1178;
    _v_1160 = _v_1179;
    _v_1161 = _v_1180;
    _v_1162 = _v_1181;
    _v_1163 = _v_1182;
    _v_1164 = _v_1183;
    _v_1165 = _v_1184;
    _v_1166 = _v_1185;
    _v_1167 = _v_1186;
    _v_1168 = _v_1187;
    _v_1169 = _v_1188;
    _v_1170 = _v_1189;
    _v_1171 = _v_1190;
    _v_1172 = _v_1191;
    _v_1173 = _v_1192;
    _v_1174 = _v_1193;
    _v_1175 = _v_1194;
    _v_1176 = _v_1195;
    u32 _o_498 = 0;
    u32 _o_499 = 0;
    u32 _o_500 = 0;
    Term _o_501 = 0;
    u32 _o_502 = 0;
    u32 _o_503 = 0;
    Term _o_504 = 0;
    u32 _o_505 = 0;
    u32 _o_506 = 0;
    u32 _o_507 = 0;
    u32 _o_508 = 0;
    if (_v_1167 == 0) {
      _o_498 = 0;
    } else {
      _o_498 = 1;
      u32 _o_509 = 0;
      Term _o_510 = 0;
      u32 _o_511 = 0;
      if (_v_1169 == 0) {
        _o_509 = 0;
      } else {
        _o_509 = 1;
        Term _fb_68[2];
        u64 _sp_68 = ctr_take(e, _v_1170, 2, _fb_68);
        Term _f_333 = _fb_68[0];
        u32 _f_334 = _fb_68[1];
        spare_free(e, cls_fit(2), _sp_68);
        _o_510 = _f_333;
        _o_511 = _f_334;
      }
      u32 _o_512 = 0;
      Term _o_513 = 0;
      u32 _o_514 = 0;
      if (_v_1171 == 0) {
        _o_512 = 0;
      } else {
        _o_512 = 1;
        Term _fb_69[2];
        u64 _sp_69 = ctr_take(e, _v_1172, 2, _fb_69);
        Term _f_335 = _fb_69[0];
        u32 _f_336 = _fb_69[1];
        spare_free(e, cls_fit(2), _sp_69);
        _o_513 = _f_335;
        _o_514 = _f_336;
      }
      u32 _o_515 = 0;
      if (_v_1173 == 0) {
        _o_515 = 0;
      } else {
        _o_515 = 1;
      }
      _o_499 = _v_1168;
      _o_500 = _o_509;
      _o_501 = _o_510;
      _o_502 = _o_511;
      _o_503 = _o_512;
      _o_504 = _o_513;
      _o_505 = _o_514;
      _o_506 = _o_515;
      _o_507 = _v_1175;
      _o_508 = _v_1176;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K381;
      WL_PUSHN(1);
    } else {
      u64 _t_92 = task_node(e, FID_MAIN_K381, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K381, _t_92);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOOKUP_PRINT)) {
      u64 _t_93 = task_node(e, FID_LOOKUP_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_93 + 0] = term_ctr(CID_SCON, STAT_OFF + 444);
      e.mem[_t_93 + 1] = _v_1158;
      e.mem[_t_93 + 2] = _v_1159;
      e.mem[_t_93 + 3] = _v_1160;
      e.mem[_t_93 + 4] = _v_1161;
      e.mem[_t_93 + 5] = _v_1162;
      e.mem[_t_93 + 6] = _v_1163;
      e.mem[_t_93 + 7] = _v_1164;
      e.mem[_t_93 + 8] = _v_1165;
      e.mem[_t_93 + 9] = _v_1166;
      e.mem[_t_93 + 10] = _o_498;
      e.mem[_t_93 + 11] = _o_499;
      e.mem[_t_93 + 12] = _o_500;
      e.mem[_t_93 + 13] = _o_501;
      e.mem[_t_93 + 14] = _o_502;
      e.mem[_t_93 + 15] = _o_503;
      e.mem[_t_93 + 16] = _o_504;
      e.mem[_t_93 + 17] = _o_505;
      e.mem[_t_93 + 18] = _o_506;
      e.mem[_t_93 + 19] = _o_507;
      e.mem[_t_93 + 20] = _o_508;
      return term_tsk(FID_LOOKUP_PRINT, _t_93);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 444);
    r1 = _v_1158;
    r2 = _v_1159;
    r3 = _v_1160;
    r4 = _v_1161;
    r5 = _v_1162;
    r6 = _v_1163;
    r7 = _v_1164;
    r8 = _v_1165;
    r9 = _v_1166;
    r10 = _o_498;
    r11 = _o_499;
    r12 = _o_500;
    r13 = _o_501;
    r14 = _o_502;
    r15 = _o_503;
    r16 = _o_504;
    r17 = _o_505;
    r18 = _o_506;
    r19 = _o_507;
    r20 = _o_508;
    WL_JMP(FID_LOOKUP_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K381)
  {
    Term _h_259 = r0;
    WL_OPEN
    u64 _nd_61 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_61 + 0] = _h_259;
    r0 = term_clo(FID_MAIN_C382, _nd_61);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C382)
  {
    Term _h_260 = r0;
    Term _x_53 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_136 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_136 + 0] = _h_260;
      e.mem[_t_136 + 1] = term_clo(FID_MAIN_C383, 0);
      e.mem[_t_136 + 2] = _x_53;
      return term_tsk(FID_IO_BIND, _t_136);
    }
    r0 = _h_260;
    r1 = term_clo(FID_MAIN_C383, 0);
    r2 = _x_53;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C383)
  {
    Term _x_54 = r0;
    WL_OPEN
    Term _fb_70[9];
    u64 _sp_70 = ctr_take(e, _x_54, 9, _fb_70);
    Term _f_337 = _fb_70[0];
    Term _f_338 = _fb_70[1];
    Term _f_339 = _fb_70[2];
    Term _f_340 = _fb_70[3];
    Term _f_341 = _fb_70[4];
    Term _f_342 = _fb_70[5];
    u32 _f_343 = _fb_70[6];
    Term _f_344 = _fb_70[7];
    u32 _f_345 = _fb_70[8];
    spare_free(e, cls_fit(9), _sp_70);
    Term _v_1196 = 0;
    Term _v_1197 = 0;
    Term _v_1198 = 0;
    Term _v_1199 = 0;
    Term _v_1200 = 0;
    Term _v_1201 = 0;
    u32 _v_1202 = 0;
    Term _v_1203 = 0;
    u32 _v_1204 = 0;
    u32 _v_1205 = 0;
    Term _fv_34[1];
    _fv_34[0] = 21ull;
    Term _a_20 = blk_new(e, 0, 2ull, 0, 1, _fv_34);
    Term _at_116 = blk_loc(e.mem, _a_20);
    Term _at_117 = blk_at(_a_20, 1ull, 0);
    u32 _c_67 = blk_read(e.mem, 0, _at_116, _at_117 + 0);
    blk_write(e.mem, 0, _at_116, _at_117 + 0, U32_BIN(21ull, +, 1ull));
    Term _at_118 = blk_loc(e.mem, _a_20);
    Term _at_119 = blk_at(_a_20, 2ull, 0);
    u32 _c_68 = blk_read(e.mem, 0, _at_118, _at_119 + 0);
    blk_write(e.mem, 0, _at_118, _at_119 + 0, U32_BIN(21ull, +, 2ull));
    Term _at_120 = blk_loc(e.mem, _a_20);
    Term _at_121 = blk_at(_a_20, 3ull, 0);
    u32 _c_69 = blk_read(e.mem, 0, _at_120, _at_121 + 0);
    blk_write(e.mem, 0, _at_120, _at_121 + 0, U32_BIN(21ull, +, 3ull));
    u64 _nd_62 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_62 + 0] = rfc_seal(e, _a_20);
    e.mem[_nd_62 + 1] = rfc_seal(e, 21ull);
    Term _v_1206 = 0;
    Term _v_1207 = 0;
    Term _v_1208 = 0;
    Term _v_1209 = 0;
    Term _v_1210 = 0;
    Term _v_1211 = 0;
    u32 _v_1212 = 0;
    Term _v_1213 = 0;
    u32 _v_1214 = 0;
    u32 _v_1215 = 0;
    Term _o_516[10];
    Term _a_21 = term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_62);
    if (spin_60(e, _o_516, _f_337, blk_loc(e.mem, _f_337), _f_338, blk_loc(e.mem, _f_338), _f_339, blk_loc(e.mem, _f_339), _f_340, blk_loc(e.mem, _f_340), _f_341, blk_loc(e.mem, _f_341), _f_342, blk_loc(e.mem, _f_342), _f_343, _f_344, _f_345, 2ull, 1, _a_21, blk_loc(e.mem, _a_21), 51ull) == 0) {
      return 0;
    }
    _v_1206 = _o_516[0];
    _v_1207 = _o_516[1];
    _v_1208 = _o_516[2];
    _v_1209 = _o_516[3];
    _v_1210 = _o_516[4];
    _v_1211 = _o_516[5];
    _v_1212 = _o_516[6];
    _v_1213 = _o_516[7];
    _v_1214 = _o_516[8];
    _v_1215 = _o_516[9];
    _v_1196 = _v_1206;
    _v_1197 = _v_1207;
    _v_1198 = _v_1208;
    _v_1199 = _v_1209;
    _v_1200 = _v_1210;
    _v_1201 = _v_1211;
    _v_1202 = _v_1212;
    _v_1203 = _v_1213;
    _v_1204 = _v_1214;
    _v_1205 = _v_1215;
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K384;
      WL_PUSHN(1);
    } else {
      u64 _t_94 = task_node(e, FID_MAIN_K384, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K384, _t_94);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_EFFECT_PRINT)) {
      u64 _t_95 = task_node(e, FID_EFFECT_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_95 + 0] = term_ctr(CID_SCON, STAT_OFF + 464);
      e.mem[_t_95 + 1] = _v_1196;
      e.mem[_t_95 + 2] = _v_1197;
      e.mem[_t_95 + 3] = _v_1198;
      e.mem[_t_95 + 4] = _v_1199;
      e.mem[_t_95 + 5] = _v_1200;
      e.mem[_t_95 + 6] = _v_1201;
      e.mem[_t_95 + 7] = _v_1202;
      e.mem[_t_95 + 8] = _v_1203;
      e.mem[_t_95 + 9] = _v_1204;
      e.mem[_t_95 + 10] = _v_1205;
      return term_tsk(FID_EFFECT_PRINT, _t_95);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 464);
    r1 = _v_1196;
    r2 = _v_1197;
    r3 = _v_1198;
    r4 = _v_1199;
    r5 = _v_1200;
    r6 = _v_1201;
    r7 = _v_1202;
    r8 = _v_1203;
    r9 = _v_1204;
    r10 = _v_1205;
    WL_JMP(FID_EFFECT_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K384)
  {
    Term _h_261 = r0;
    WL_OPEN
    u64 _nd_63 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_63 + 0] = _h_261;
    r0 = term_clo(FID_MAIN_C385, _nd_63);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C385)
  {
    Term _h_262 = r0;
    Term _x_55 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_135 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_135 + 0] = _h_262;
      e.mem[_t_135 + 1] = term_clo(FID_MAIN_C386, 0);
      e.mem[_t_135 + 2] = _x_55;
      return term_tsk(FID_IO_BIND, _t_135);
    }
    r0 = _h_262;
    r1 = term_clo(FID_MAIN_C386, 0);
    r2 = _x_55;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C386)
  {
    Term _x_56 = r0;
    WL_OPEN
    Term _fb_71[9];
    u64 _sp_71 = ctr_take(e, _x_56, 9, _fb_71);
    Term _f_346 = _fb_71[0];
    Term _f_347 = _fb_71[1];
    Term _f_348 = _fb_71[2];
    Term _f_349 = _fb_71[3];
    Term _f_350 = _fb_71[4];
    Term _f_351 = _fb_71[5];
    u32 _f_352 = _fb_71[6];
    Term _f_353 = _fb_71[7];
    u32 _f_354 = _fb_71[8];
    spare_free(e, cls_fit(9), _sp_71);
    Term _v_1216 = 0;
    Term _v_1217 = 0;
    Term _v_1218 = 0;
    Term _v_1219 = 0;
    Term _v_1220 = 0;
    Term _v_1221 = 0;
    u32 _v_1222 = 0;
    Term _v_1223 = 0;
    u32 _v_1224 = 0;
    u32 _v_1225 = 0;
    u32 _v_1226 = 0;
    u32 _v_1227 = 0;
    Term _v_1228 = 0;
    u32 _v_1229 = 0;
    Term _v_1230 = 0;
    u32 _v_1231 = 0;
    Term _v_1232 = 0;
    u32 _v_1233 = 0;
    u32 _v_1234 = 0;
    Term _v_1235 = 0;
    Term _v_1236 = 0;
    Term _v_1237 = 0;
    Term _v_1238 = 0;
    Term _v_1239 = 0;
    Term _v_1240 = 0;
    u32 _v_1241 = 0;
    Term _v_1242 = 0;
    u32 _v_1243 = 0;
    u32 _v_1244 = 0;
    u32 _v_1245 = 0;
    u32 _v_1246 = 0;
    Term _v_1247 = 0;
    u32 _v_1248 = 0;
    Term _v_1249 = 0;
    u32 _v_1250 = 0;
    Term _v_1251 = 0;
    u32 _v_1252 = 0;
    u32 _v_1253 = 0;
    Term _o_517[19];
    if (spin_44(e, _o_517, _f_346, blk_loc(e.mem, _f_346), _f_347, blk_loc(e.mem, _f_347), _f_348, blk_loc(e.mem, _f_348), _f_349, blk_loc(e.mem, _f_349), _f_350, blk_loc(e.mem, _f_350), _f_351, blk_loc(e.mem, _f_351), _f_352, _f_353, _f_354, 2ull) == 0) {
      return 0;
    }
    _v_1235 = _o_517[0];
    _v_1236 = _o_517[1];
    _v_1237 = _o_517[2];
    _v_1238 = _o_517[3];
    _v_1239 = _o_517[4];
    _v_1240 = _o_517[5];
    _v_1241 = _o_517[6];
    _v_1242 = _o_517[7];
    _v_1243 = _o_517[8];
    _v_1244 = _o_517[9];
    _v_1245 = _o_517[10];
    _v_1246 = _o_517[11];
    _v_1247 = _o_517[12];
    _v_1248 = _o_517[13];
    _v_1249 = _o_517[14];
    _v_1250 = _o_517[15];
    _v_1251 = _o_517[16];
    _v_1252 = _o_517[17];
    _v_1253 = _o_517[18];
    _v_1216 = _v_1235;
    _v_1217 = _v_1236;
    _v_1218 = _v_1237;
    _v_1219 = _v_1238;
    _v_1220 = _v_1239;
    _v_1221 = _v_1240;
    _v_1222 = _v_1241;
    _v_1223 = _v_1242;
    _v_1224 = _v_1243;
    _v_1225 = _v_1244;
    _v_1226 = _v_1245;
    _v_1227 = _v_1246;
    _v_1228 = _v_1247;
    _v_1229 = _v_1248;
    _v_1230 = _v_1249;
    _v_1231 = _v_1250;
    _v_1232 = _v_1251;
    _v_1233 = _v_1252;
    _v_1234 = _v_1253;
    u32 _o_518 = 0;
    u32 _o_519 = 0;
    u32 _o_520 = 0;
    Term _o_521 = 0;
    u32 _o_522 = 0;
    u32 _o_523 = 0;
    Term _o_524 = 0;
    u32 _o_525 = 0;
    u32 _o_526 = 0;
    u32 _o_527 = 0;
    u32 _o_528 = 0;
    if (_v_1225 == 0) {
      _o_518 = 0;
    } else {
      _o_518 = 1;
      u32 _o_529 = 0;
      Term _o_530 = 0;
      u32 _o_531 = 0;
      if (_v_1227 == 0) {
        _o_529 = 0;
      } else {
        _o_529 = 1;
        Term _fb_72[2];
        u64 _sp_72 = ctr_take(e, _v_1228, 2, _fb_72);
        Term _f_355 = _fb_72[0];
        u32 _f_356 = _fb_72[1];
        spare_free(e, cls_fit(2), _sp_72);
        _o_530 = _f_355;
        _o_531 = _f_356;
      }
      u32 _o_532 = 0;
      Term _o_533 = 0;
      u32 _o_534 = 0;
      if (_v_1229 == 0) {
        _o_532 = 0;
      } else {
        _o_532 = 1;
        Term _fb_73[2];
        u64 _sp_73 = ctr_take(e, _v_1230, 2, _fb_73);
        Term _f_357 = _fb_73[0];
        u32 _f_358 = _fb_73[1];
        spare_free(e, cls_fit(2), _sp_73);
        _o_533 = _f_357;
        _o_534 = _f_358;
      }
      u32 _o_535 = 0;
      if (_v_1231 == 0) {
        _o_535 = 0;
      } else {
        _o_535 = 1;
      }
      _o_519 = _v_1226;
      _o_520 = _o_529;
      _o_521 = _o_530;
      _o_522 = _o_531;
      _o_523 = _o_532;
      _o_524 = _o_533;
      _o_525 = _o_534;
      _o_526 = _o_535;
      _o_527 = _v_1233;
      _o_528 = _v_1234;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K387;
      WL_PUSHN(1);
    } else {
      u64 _t_96 = task_node(e, FID_MAIN_K387, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K387, _t_96);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOOKUP_PRINT)) {
      u64 _t_97 = task_node(e, FID_LOOKUP_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_97 + 0] = term_ctr(CID_SCON, STAT_OFF + 484);
      e.mem[_t_97 + 1] = _v_1216;
      e.mem[_t_97 + 2] = _v_1217;
      e.mem[_t_97 + 3] = _v_1218;
      e.mem[_t_97 + 4] = _v_1219;
      e.mem[_t_97 + 5] = _v_1220;
      e.mem[_t_97 + 6] = _v_1221;
      e.mem[_t_97 + 7] = _v_1222;
      e.mem[_t_97 + 8] = _v_1223;
      e.mem[_t_97 + 9] = _v_1224;
      e.mem[_t_97 + 10] = _o_518;
      e.mem[_t_97 + 11] = _o_519;
      e.mem[_t_97 + 12] = _o_520;
      e.mem[_t_97 + 13] = _o_521;
      e.mem[_t_97 + 14] = _o_522;
      e.mem[_t_97 + 15] = _o_523;
      e.mem[_t_97 + 16] = _o_524;
      e.mem[_t_97 + 17] = _o_525;
      e.mem[_t_97 + 18] = _o_526;
      e.mem[_t_97 + 19] = _o_527;
      e.mem[_t_97 + 20] = _o_528;
      return term_tsk(FID_LOOKUP_PRINT, _t_97);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 484);
    r1 = _v_1216;
    r2 = _v_1217;
    r3 = _v_1218;
    r4 = _v_1219;
    r5 = _v_1220;
    r6 = _v_1221;
    r7 = _v_1222;
    r8 = _v_1223;
    r9 = _v_1224;
    r10 = _o_518;
    r11 = _o_519;
    r12 = _o_520;
    r13 = _o_521;
    r14 = _o_522;
    r15 = _o_523;
    r16 = _o_524;
    r17 = _o_525;
    r18 = _o_526;
    r19 = _o_527;
    r20 = _o_528;
    WL_JMP(FID_LOOKUP_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K387)
  {
    Term _h_263 = r0;
    WL_OPEN
    u64 _nd_64 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_64 + 0] = _h_263;
    r0 = term_clo(FID_MAIN_C388, _nd_64);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C388)
  {
    Term _h_264 = r0;
    Term _x_57 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_134 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_134 + 0] = _h_264;
      e.mem[_t_134 + 1] = term_clo(FID_MAIN_C389, 0);
      e.mem[_t_134 + 2] = _x_57;
      return term_tsk(FID_IO_BIND, _t_134);
    }
    r0 = _h_264;
    r1 = term_clo(FID_MAIN_C389, 0);
    r2 = _x_57;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C389)
  {
    Term _x_58 = r0;
    WL_OPEN
    Term _fb_74[9];
    u64 _sp_74 = ctr_take(e, _x_58, 9, _fb_74);
    Term _f_359 = _fb_74[0];
    Term _f_360 = _fb_74[1];
    Term _f_361 = _fb_74[2];
    Term _f_362 = _fb_74[3];
    Term _f_363 = _fb_74[4];
    Term _f_364 = _fb_74[5];
    u32 _f_365 = _fb_74[6];
    Term _f_366 = _fb_74[7];
    u32 _f_367 = _fb_74[8];
    spare_free(e, cls_fit(9), _sp_74);
    Term _v_1254 = 0;
    Term _v_1255 = 0;
    Term _v_1256 = 0;
    Term _v_1257 = 0;
    Term _v_1258 = 0;
    Term _v_1259 = 0;
    u32 _v_1260 = 0;
    Term _v_1261 = 0;
    u32 _v_1262 = 0;
    u32 _v_1263 = 0;
    Term _v_1264 = 0;
    Term _v_1265 = 0;
    Term _v_1266 = 0;
    Term _v_1267 = 0;
    Term _v_1268 = 0;
    Term _v_1269 = 0;
    u32 _v_1270 = 0;
    Term _v_1271 = 0;
    u32 _v_1272 = 0;
    u32 _v_1273 = 0;
    Term _o_536[10];
    Term _a_22 = 0;
    if (spin_60(e, _o_536, _f_359, blk_loc(e.mem, _f_359), _f_360, blk_loc(e.mem, _f_360), _f_361, blk_loc(e.mem, _f_361), _f_362, blk_loc(e.mem, _f_362), _f_363, blk_loc(e.mem, _f_363), _f_364, blk_loc(e.mem, _f_364), _f_365, _f_366, _f_367, 2ull, 0, _a_22, blk_loc(e.mem, _a_22), 52ull) == 0) {
      return 0;
    }
    _v_1264 = _o_536[0];
    _v_1265 = _o_536[1];
    _v_1266 = _o_536[2];
    _v_1267 = _o_536[3];
    _v_1268 = _o_536[4];
    _v_1269 = _o_536[5];
    _v_1270 = _o_536[6];
    _v_1271 = _o_536[7];
    _v_1272 = _o_536[8];
    _v_1273 = _o_536[9];
    _v_1254 = _v_1264;
    _v_1255 = _v_1265;
    _v_1256 = _v_1266;
    _v_1257 = _v_1267;
    _v_1258 = _v_1268;
    _v_1259 = _v_1269;
    _v_1260 = _v_1270;
    _v_1261 = _v_1271;
    _v_1262 = _v_1272;
    _v_1263 = _v_1273;
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K390;
      WL_PUSHN(1);
    } else {
      u64 _t_98 = task_node(e, FID_MAIN_K390, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K390, _t_98);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_EFFECT_PRINT)) {
      u64 _t_99 = task_node(e, FID_EFFECT_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_99 + 0] = term_ctr(CID_SCON, STAT_OFF + 504);
      e.mem[_t_99 + 1] = _v_1254;
      e.mem[_t_99 + 2] = _v_1255;
      e.mem[_t_99 + 3] = _v_1256;
      e.mem[_t_99 + 4] = _v_1257;
      e.mem[_t_99 + 5] = _v_1258;
      e.mem[_t_99 + 6] = _v_1259;
      e.mem[_t_99 + 7] = _v_1260;
      e.mem[_t_99 + 8] = _v_1261;
      e.mem[_t_99 + 9] = _v_1262;
      e.mem[_t_99 + 10] = _v_1263;
      return term_tsk(FID_EFFECT_PRINT, _t_99);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 504);
    r1 = _v_1254;
    r2 = _v_1255;
    r3 = _v_1256;
    r4 = _v_1257;
    r5 = _v_1258;
    r6 = _v_1259;
    r7 = _v_1260;
    r8 = _v_1261;
    r9 = _v_1262;
    r10 = _v_1263;
    WL_JMP(FID_EFFECT_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K390)
  {
    Term _h_265 = r0;
    WL_OPEN
    u64 _nd_65 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_65 + 0] = _h_265;
    r0 = term_clo(FID_MAIN_C391, _nd_65);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C391)
  {
    Term _h_266 = r0;
    Term _x_59 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_133 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_133 + 0] = _h_266;
      e.mem[_t_133 + 1] = term_clo(FID_MAIN_C392, 0);
      e.mem[_t_133 + 2] = _x_59;
      return term_tsk(FID_IO_BIND, _t_133);
    }
    r0 = _h_266;
    r1 = term_clo(FID_MAIN_C392, 0);
    r2 = _x_59;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C392)
  {
    Term _x_60 = r0;
    WL_OPEN
    Term _fb_75[9];
    u64 _sp_75 = ctr_take(e, _x_60, 9, _fb_75);
    Term _f_368 = _fb_75[0];
    Term _f_369 = _fb_75[1];
    Term _f_370 = _fb_75[2];
    Term _f_371 = _fb_75[3];
    Term _f_372 = _fb_75[4];
    Term _f_373 = _fb_75[5];
    u32 _f_374 = _fb_75[6];
    Term _f_375 = _fb_75[7];
    u32 _f_376 = _fb_75[8];
    spare_free(e, cls_fit(9), _sp_75);
    Term _v_1274 = 0;
    Term _v_1275 = 0;
    Term _v_1276 = 0;
    Term _v_1277 = 0;
    Term _v_1278 = 0;
    Term _v_1279 = 0;
    u32 _v_1280 = 0;
    Term _v_1281 = 0;
    u32 _v_1282 = 0;
    u32 _v_1283 = 0;
    u32 _v_1284 = 0;
    u32 _v_1285 = 0;
    Term _v_1286 = 0;
    u32 _v_1287 = 0;
    Term _v_1288 = 0;
    u32 _v_1289 = 0;
    Term _v_1290 = 0;
    u32 _v_1291 = 0;
    u32 _v_1292 = 0;
    Term _v_1293 = 0;
    Term _v_1294 = 0;
    Term _v_1295 = 0;
    Term _v_1296 = 0;
    Term _v_1297 = 0;
    Term _v_1298 = 0;
    u32 _v_1299 = 0;
    Term _v_1300 = 0;
    u32 _v_1301 = 0;
    u32 _v_1302 = 0;
    u32 _v_1303 = 0;
    u32 _v_1304 = 0;
    Term _v_1305 = 0;
    u32 _v_1306 = 0;
    Term _v_1307 = 0;
    u32 _v_1308 = 0;
    Term _v_1309 = 0;
    u32 _v_1310 = 0;
    u32 _v_1311 = 0;
    Term _o_537[19];
    if (spin_44(e, _o_537, _f_368, blk_loc(e.mem, _f_368), _f_369, blk_loc(e.mem, _f_369), _f_370, blk_loc(e.mem, _f_370), _f_371, blk_loc(e.mem, _f_371), _f_372, blk_loc(e.mem, _f_372), _f_373, blk_loc(e.mem, _f_373), _f_374, _f_375, _f_376, 2ull) == 0) {
      return 0;
    }
    _v_1293 = _o_537[0];
    _v_1294 = _o_537[1];
    _v_1295 = _o_537[2];
    _v_1296 = _o_537[3];
    _v_1297 = _o_537[4];
    _v_1298 = _o_537[5];
    _v_1299 = _o_537[6];
    _v_1300 = _o_537[7];
    _v_1301 = _o_537[8];
    _v_1302 = _o_537[9];
    _v_1303 = _o_537[10];
    _v_1304 = _o_537[11];
    _v_1305 = _o_537[12];
    _v_1306 = _o_537[13];
    _v_1307 = _o_537[14];
    _v_1308 = _o_537[15];
    _v_1309 = _o_537[16];
    _v_1310 = _o_537[17];
    _v_1311 = _o_537[18];
    _v_1274 = _v_1293;
    _v_1275 = _v_1294;
    _v_1276 = _v_1295;
    _v_1277 = _v_1296;
    _v_1278 = _v_1297;
    _v_1279 = _v_1298;
    _v_1280 = _v_1299;
    _v_1281 = _v_1300;
    _v_1282 = _v_1301;
    _v_1283 = _v_1302;
    _v_1284 = _v_1303;
    _v_1285 = _v_1304;
    _v_1286 = _v_1305;
    _v_1287 = _v_1306;
    _v_1288 = _v_1307;
    _v_1289 = _v_1308;
    _v_1290 = _v_1309;
    _v_1291 = _v_1310;
    _v_1292 = _v_1311;
    u32 _o_538 = 0;
    u32 _o_539 = 0;
    u32 _o_540 = 0;
    Term _o_541 = 0;
    u32 _o_542 = 0;
    u32 _o_543 = 0;
    Term _o_544 = 0;
    u32 _o_545 = 0;
    u32 _o_546 = 0;
    u32 _o_547 = 0;
    u32 _o_548 = 0;
    if (_v_1283 == 0) {
      _o_538 = 0;
    } else {
      _o_538 = 1;
      u32 _o_549 = 0;
      Term _o_550 = 0;
      u32 _o_551 = 0;
      if (_v_1285 == 0) {
        _o_549 = 0;
      } else {
        _o_549 = 1;
        Term _fb_76[2];
        u64 _sp_76 = ctr_take(e, _v_1286, 2, _fb_76);
        Term _f_377 = _fb_76[0];
        u32 _f_378 = _fb_76[1];
        spare_free(e, cls_fit(2), _sp_76);
        _o_550 = _f_377;
        _o_551 = _f_378;
      }
      u32 _o_552 = 0;
      Term _o_553 = 0;
      u32 _o_554 = 0;
      if (_v_1287 == 0) {
        _o_552 = 0;
      } else {
        _o_552 = 1;
        Term _fb_77[2];
        u64 _sp_77 = ctr_take(e, _v_1288, 2, _fb_77);
        Term _f_379 = _fb_77[0];
        u32 _f_380 = _fb_77[1];
        spare_free(e, cls_fit(2), _sp_77);
        _o_553 = _f_379;
        _o_554 = _f_380;
      }
      u32 _o_555 = 0;
      if (_v_1289 == 0) {
        _o_555 = 0;
      } else {
        _o_555 = 1;
      }
      _o_539 = _v_1284;
      _o_540 = _o_549;
      _o_541 = _o_550;
      _o_542 = _o_551;
      _o_543 = _o_552;
      _o_544 = _o_553;
      _o_545 = _o_554;
      _o_546 = _o_555;
      _o_547 = _v_1291;
      _o_548 = _v_1292;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K393;
      WL_PUSHN(1);
    } else {
      u64 _t_100 = task_node(e, FID_MAIN_K393, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K393, _t_100);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOOKUP_PRINT)) {
      u64 _t_101 = task_node(e, FID_LOOKUP_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_101 + 0] = term_ctr(CID_SCON, STAT_OFF + 524);
      e.mem[_t_101 + 1] = _v_1274;
      e.mem[_t_101 + 2] = _v_1275;
      e.mem[_t_101 + 3] = _v_1276;
      e.mem[_t_101 + 4] = _v_1277;
      e.mem[_t_101 + 5] = _v_1278;
      e.mem[_t_101 + 6] = _v_1279;
      e.mem[_t_101 + 7] = _v_1280;
      e.mem[_t_101 + 8] = _v_1281;
      e.mem[_t_101 + 9] = _v_1282;
      e.mem[_t_101 + 10] = _o_538;
      e.mem[_t_101 + 11] = _o_539;
      e.mem[_t_101 + 12] = _o_540;
      e.mem[_t_101 + 13] = _o_541;
      e.mem[_t_101 + 14] = _o_542;
      e.mem[_t_101 + 15] = _o_543;
      e.mem[_t_101 + 16] = _o_544;
      e.mem[_t_101 + 17] = _o_545;
      e.mem[_t_101 + 18] = _o_546;
      e.mem[_t_101 + 19] = _o_547;
      e.mem[_t_101 + 20] = _o_548;
      return term_tsk(FID_LOOKUP_PRINT, _t_101);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 524);
    r1 = _v_1274;
    r2 = _v_1275;
    r3 = _v_1276;
    r4 = _v_1277;
    r5 = _v_1278;
    r6 = _v_1279;
    r7 = _v_1280;
    r8 = _v_1281;
    r9 = _v_1282;
    r10 = _o_538;
    r11 = _o_539;
    r12 = _o_540;
    r13 = _o_541;
    r14 = _o_542;
    r15 = _o_543;
    r16 = _o_544;
    r17 = _o_545;
    r18 = _o_546;
    r19 = _o_547;
    r20 = _o_548;
    WL_JMP(FID_LOOKUP_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K393)
  {
    Term _h_267 = r0;
    WL_OPEN
    u64 _nd_66 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_66 + 0] = _h_267;
    r0 = term_clo(FID_MAIN_C394, _nd_66);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C394)
  {
    Term _h_268 = r0;
    Term _x_61 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_132 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_132 + 0] = _h_268;
      e.mem[_t_132 + 1] = term_clo(FID_MAIN_C395, 0);
      e.mem[_t_132 + 2] = _x_61;
      return term_tsk(FID_IO_BIND, _t_132);
    }
    r0 = _h_268;
    r1 = term_clo(FID_MAIN_C395, 0);
    r2 = _x_61;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C395)
  {
    Term _x_62 = r0;
    WL_OPEN
    Term _fb_78[9];
    u64 _sp_78 = ctr_take(e, _x_62, 9, _fb_78);
    Term _f_381 = _fb_78[0];
    Term _f_382 = _fb_78[1];
    Term _f_383 = _fb_78[2];
    Term _f_384 = _fb_78[3];
    Term _f_385 = _fb_78[4];
    Term _f_386 = _fb_78[5];
    u32 _f_387 = _fb_78[6];
    Term _f_388 = _fb_78[7];
    u32 _f_389 = _fb_78[8];
    spare_free(e, cls_fit(9), _sp_78);
    Term _v_1312 = 0;
    Term _v_1313 = 0;
    Term _v_1314 = 0;
    Term _v_1315 = 0;
    Term _v_1316 = 0;
    Term _v_1317 = 0;
    u32 _v_1318 = 0;
    Term _v_1319 = 0;
    u32 _v_1320 = 0;
    u32 _v_1321 = 0;
    Term _v_1322 = 0;
    Term _v_1323 = 0;
    Term _v_1324 = 0;
    Term _v_1325 = 0;
    Term _v_1326 = 0;
    Term _v_1327 = 0;
    u32 _v_1328 = 0;
    Term _v_1329 = 0;
    u32 _v_1330 = 0;
    u32 _v_1331 = 0;
    Term _o_556[10];
    Term _a_23 = 0;
    if (spin_60(e, _o_556, _f_381, blk_loc(e.mem, _f_381), _f_382, blk_loc(e.mem, _f_382), _f_383, blk_loc(e.mem, _f_383), _f_384, blk_loc(e.mem, _f_384), _f_385, blk_loc(e.mem, _f_385), _f_386, blk_loc(e.mem, _f_386), _f_387, _f_388, _f_389, 2ull, 0, _a_23, blk_loc(e.mem, _a_23), 53ull) == 0) {
      return 0;
    }
    _v_1322 = _o_556[0];
    _v_1323 = _o_556[1];
    _v_1324 = _o_556[2];
    _v_1325 = _o_556[3];
    _v_1326 = _o_556[4];
    _v_1327 = _o_556[5];
    _v_1328 = _o_556[6];
    _v_1329 = _o_556[7];
    _v_1330 = _o_556[8];
    _v_1331 = _o_556[9];
    _v_1312 = _v_1322;
    _v_1313 = _v_1323;
    _v_1314 = _v_1324;
    _v_1315 = _v_1325;
    _v_1316 = _v_1326;
    _v_1317 = _v_1327;
    _v_1318 = _v_1328;
    _v_1319 = _v_1329;
    _v_1320 = _v_1330;
    _v_1321 = _v_1331;
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K396;
      WL_PUSHN(1);
    } else {
      u64 _t_102 = task_node(e, FID_MAIN_K396, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K396, _t_102);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_EFFECT_PRINT)) {
      u64 _t_103 = task_node(e, FID_EFFECT_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_103 + 0] = term_ctr(CID_SCON, STAT_OFF + 538);
      e.mem[_t_103 + 1] = _v_1312;
      e.mem[_t_103 + 2] = _v_1313;
      e.mem[_t_103 + 3] = _v_1314;
      e.mem[_t_103 + 4] = _v_1315;
      e.mem[_t_103 + 5] = _v_1316;
      e.mem[_t_103 + 6] = _v_1317;
      e.mem[_t_103 + 7] = _v_1318;
      e.mem[_t_103 + 8] = _v_1319;
      e.mem[_t_103 + 9] = _v_1320;
      e.mem[_t_103 + 10] = _v_1321;
      return term_tsk(FID_EFFECT_PRINT, _t_103);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 538);
    r1 = _v_1312;
    r2 = _v_1313;
    r3 = _v_1314;
    r4 = _v_1315;
    r5 = _v_1316;
    r6 = _v_1317;
    r7 = _v_1318;
    r8 = _v_1319;
    r9 = _v_1320;
    r10 = _v_1321;
    WL_JMP(FID_EFFECT_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K396)
  {
    Term _h_269 = r0;
    WL_OPEN
    u64 _nd_67 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_67 + 0] = _h_269;
    r0 = term_clo(FID_MAIN_C397, _nd_67);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C397)
  {
    Term _h_270 = r0;
    Term _x_63 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_131 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_131 + 0] = _h_270;
      e.mem[_t_131 + 1] = term_clo(FID_MAIN_C398, 0);
      e.mem[_t_131 + 2] = _x_63;
      return term_tsk(FID_IO_BIND, _t_131);
    }
    r0 = _h_270;
    r1 = term_clo(FID_MAIN_C398, 0);
    r2 = _x_63;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C398)
  {
    Term _x_64 = r0;
    WL_OPEN
    Term _fb_79[9];
    u64 _sp_79 = ctr_take(e, _x_64, 9, _fb_79);
    Term _f_390 = _fb_79[0];
    Term _f_391 = _fb_79[1];
    Term _f_392 = _fb_79[2];
    Term _f_393 = _fb_79[3];
    Term _f_394 = _fb_79[4];
    Term _f_395 = _fb_79[5];
    u32 _f_396 = _fb_79[6];
    Term _f_397 = _fb_79[7];
    u32 _f_398 = _fb_79[8];
    spare_free(e, cls_fit(9), _sp_79);
    Term _v_1332 = 0;
    Term _v_1333 = 0;
    Term _v_1334 = 0;
    Term _v_1335 = 0;
    Term _v_1336 = 0;
    Term _v_1337 = 0;
    u32 _v_1338 = 0;
    Term _v_1339 = 0;
    u32 _v_1340 = 0;
    u32 _v_1341 = 0;
    u32 _v_1342 = 0;
    u32 _v_1343 = 0;
    Term _v_1344 = 0;
    u32 _v_1345 = 0;
    Term _v_1346 = 0;
    u32 _v_1347 = 0;
    Term _v_1348 = 0;
    u32 _v_1349 = 0;
    u32 _v_1350 = 0;
    Term _v_1351 = 0;
    Term _v_1352 = 0;
    Term _v_1353 = 0;
    Term _v_1354 = 0;
    Term _v_1355 = 0;
    Term _v_1356 = 0;
    u32 _v_1357 = 0;
    Term _v_1358 = 0;
    u32 _v_1359 = 0;
    u32 _v_1360 = 0;
    u32 _v_1361 = 0;
    u32 _v_1362 = 0;
    Term _v_1363 = 0;
    u32 _v_1364 = 0;
    Term _v_1365 = 0;
    u32 _v_1366 = 0;
    Term _v_1367 = 0;
    u32 _v_1368 = 0;
    u32 _v_1369 = 0;
    Term _o_557[19];
    if (spin_44(e, _o_557, _f_390, blk_loc(e.mem, _f_390), _f_391, blk_loc(e.mem, _f_391), _f_392, blk_loc(e.mem, _f_392), _f_393, blk_loc(e.mem, _f_393), _f_394, blk_loc(e.mem, _f_394), _f_395, blk_loc(e.mem, _f_395), _f_396, _f_397, _f_398, 2ull) == 0) {
      return 0;
    }
    _v_1351 = _o_557[0];
    _v_1352 = _o_557[1];
    _v_1353 = _o_557[2];
    _v_1354 = _o_557[3];
    _v_1355 = _o_557[4];
    _v_1356 = _o_557[5];
    _v_1357 = _o_557[6];
    _v_1358 = _o_557[7];
    _v_1359 = _o_557[8];
    _v_1360 = _o_557[9];
    _v_1361 = _o_557[10];
    _v_1362 = _o_557[11];
    _v_1363 = _o_557[12];
    _v_1364 = _o_557[13];
    _v_1365 = _o_557[14];
    _v_1366 = _o_557[15];
    _v_1367 = _o_557[16];
    _v_1368 = _o_557[17];
    _v_1369 = _o_557[18];
    _v_1332 = _v_1351;
    _v_1333 = _v_1352;
    _v_1334 = _v_1353;
    _v_1335 = _v_1354;
    _v_1336 = _v_1355;
    _v_1337 = _v_1356;
    _v_1338 = _v_1357;
    _v_1339 = _v_1358;
    _v_1340 = _v_1359;
    _v_1341 = _v_1360;
    _v_1342 = _v_1361;
    _v_1343 = _v_1362;
    _v_1344 = _v_1363;
    _v_1345 = _v_1364;
    _v_1346 = _v_1365;
    _v_1347 = _v_1366;
    _v_1348 = _v_1367;
    _v_1349 = _v_1368;
    _v_1350 = _v_1369;
    u32 _o_558 = 0;
    u32 _o_559 = 0;
    u32 _o_560 = 0;
    Term _o_561 = 0;
    u32 _o_562 = 0;
    u32 _o_563 = 0;
    Term _o_564 = 0;
    u32 _o_565 = 0;
    u32 _o_566 = 0;
    u32 _o_567 = 0;
    u32 _o_568 = 0;
    if (_v_1341 == 0) {
      _o_558 = 0;
    } else {
      _o_558 = 1;
      u32 _o_569 = 0;
      Term _o_570 = 0;
      u32 _o_571 = 0;
      if (_v_1343 == 0) {
        _o_569 = 0;
      } else {
        _o_569 = 1;
        Term _fb_80[2];
        u64 _sp_80 = ctr_take(e, _v_1344, 2, _fb_80);
        Term _f_399 = _fb_80[0];
        u32 _f_400 = _fb_80[1];
        spare_free(e, cls_fit(2), _sp_80);
        _o_570 = _f_399;
        _o_571 = _f_400;
      }
      u32 _o_572 = 0;
      Term _o_573 = 0;
      u32 _o_574 = 0;
      if (_v_1345 == 0) {
        _o_572 = 0;
      } else {
        _o_572 = 1;
        Term _fb_81[2];
        u64 _sp_81 = ctr_take(e, _v_1346, 2, _fb_81);
        Term _f_401 = _fb_81[0];
        u32 _f_402 = _fb_81[1];
        spare_free(e, cls_fit(2), _sp_81);
        _o_573 = _f_401;
        _o_574 = _f_402;
      }
      u32 _o_575 = 0;
      if (_v_1347 == 0) {
        _o_575 = 0;
      } else {
        _o_575 = 1;
      }
      _o_559 = _v_1342;
      _o_560 = _o_569;
      _o_561 = _o_570;
      _o_562 = _o_571;
      _o_563 = _o_572;
      _o_564 = _o_573;
      _o_565 = _o_574;
      _o_566 = _o_575;
      _o_567 = _v_1349;
      _o_568 = _v_1350;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K399;
      WL_PUSHN(1);
    } else {
      u64 _t_104 = task_node(e, FID_MAIN_K399, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K399, _t_104);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOOKUP_PRINT)) {
      u64 _t_105 = task_node(e, FID_LOOKUP_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_105 + 0] = term_ctr(CID_SCON, STAT_OFF + 552);
      e.mem[_t_105 + 1] = _v_1332;
      e.mem[_t_105 + 2] = _v_1333;
      e.mem[_t_105 + 3] = _v_1334;
      e.mem[_t_105 + 4] = _v_1335;
      e.mem[_t_105 + 5] = _v_1336;
      e.mem[_t_105 + 6] = _v_1337;
      e.mem[_t_105 + 7] = _v_1338;
      e.mem[_t_105 + 8] = _v_1339;
      e.mem[_t_105 + 9] = _v_1340;
      e.mem[_t_105 + 10] = _o_558;
      e.mem[_t_105 + 11] = _o_559;
      e.mem[_t_105 + 12] = _o_560;
      e.mem[_t_105 + 13] = _o_561;
      e.mem[_t_105 + 14] = _o_562;
      e.mem[_t_105 + 15] = _o_563;
      e.mem[_t_105 + 16] = _o_564;
      e.mem[_t_105 + 17] = _o_565;
      e.mem[_t_105 + 18] = _o_566;
      e.mem[_t_105 + 19] = _o_567;
      e.mem[_t_105 + 20] = _o_568;
      return term_tsk(FID_LOOKUP_PRINT, _t_105);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 552);
    r1 = _v_1332;
    r2 = _v_1333;
    r3 = _v_1334;
    r4 = _v_1335;
    r5 = _v_1336;
    r6 = _v_1337;
    r7 = _v_1338;
    r8 = _v_1339;
    r9 = _v_1340;
    r10 = _o_558;
    r11 = _o_559;
    r12 = _o_560;
    r13 = _o_561;
    r14 = _o_562;
    r15 = _o_563;
    r16 = _o_564;
    r17 = _o_565;
    r18 = _o_566;
    r19 = _o_567;
    r20 = _o_568;
    WL_JMP(FID_LOOKUP_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K399)
  {
    Term _h_271 = r0;
    WL_OPEN
    u64 _nd_68 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_68 + 0] = _h_271;
    r0 = term_clo(FID_MAIN_C400, _nd_68);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C400)
  {
    Term _h_272 = r0;
    Term _x_65 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_130 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_130 + 0] = _h_272;
      e.mem[_t_130 + 1] = term_clo(FID_MAIN_C401, 0);
      e.mem[_t_130 + 2] = _x_65;
      return term_tsk(FID_IO_BIND, _t_130);
    }
    r0 = _h_272;
    r1 = term_clo(FID_MAIN_C401, 0);
    r2 = _x_65;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C401)
  {
    Term _x_66 = r0;
    WL_OPEN
    Term _fb_82[9];
    u64 _sp_82 = ctr_take(e, _x_66, 9, _fb_82);
    Term _f_403 = _fb_82[0];
    Term _f_404 = _fb_82[1];
    Term _f_405 = _fb_82[2];
    Term _f_406 = _fb_82[3];
    Term _f_407 = _fb_82[4];
    Term _f_408 = _fb_82[5];
    u32 _f_409 = _fb_82[6];
    Term _f_410 = _fb_82[7];
    u32 _f_411 = _fb_82[8];
    spare_free(e, cls_fit(9), _sp_82);
    Term _v_1370 = 0;
    Term _v_1371 = 0;
    Term _v_1372 = 0;
    Term _v_1373 = 0;
    Term _v_1374 = 0;
    Term _v_1375 = 0;
    u32 _v_1376 = 0;
    Term _v_1377 = 0;
    u32 _v_1378 = 0;
    u32 _v_1379 = 0;
    Term _fv_35[1];
    _fv_35[0] = 99ull;
    Term _a_24 = blk_new(e, 0, 2ull, 0, 1, _fv_35);
    Term _at_122 = blk_loc(e.mem, _a_24);
    Term _at_123 = blk_at(_a_24, 1ull, 0);
    u32 _c_70 = blk_read(e.mem, 0, _at_122, _at_123 + 0);
    blk_write(e.mem, 0, _at_122, _at_123 + 0, U32_BIN(99ull, +, 1ull));
    Term _at_124 = blk_loc(e.mem, _a_24);
    Term _at_125 = blk_at(_a_24, 2ull, 0);
    u32 _c_71 = blk_read(e.mem, 0, _at_124, _at_125 + 0);
    blk_write(e.mem, 0, _at_124, _at_125 + 0, U32_BIN(99ull, +, 2ull));
    Term _at_126 = blk_loc(e.mem, _a_24);
    Term _at_127 = blk_at(_a_24, 3ull, 0);
    u32 _c_72 = blk_read(e.mem, 0, _at_126, _at_127 + 0);
    blk_write(e.mem, 0, _at_126, _at_127 + 0, U32_BIN(99ull, +, 3ull));
    u64 _nd_69 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_69 + 0] = rfc_seal(e, _a_24);
    e.mem[_nd_69 + 1] = rfc_seal(e, 99ull);
    Term _v_1380 = 0;
    Term _v_1381 = 0;
    Term _v_1382 = 0;
    Term _v_1383 = 0;
    Term _v_1384 = 0;
    Term _v_1385 = 0;
    u32 _v_1386 = 0;
    Term _v_1387 = 0;
    u32 _v_1388 = 0;
    u32 _v_1389 = 0;
    Term _o_576[10];
    Term _a_25 = term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_69);
    if (spin_60(e, _o_576, _f_403, blk_loc(e.mem, _f_403), _f_404, blk_loc(e.mem, _f_404), _f_405, blk_loc(e.mem, _f_405), _f_406, blk_loc(e.mem, _f_406), _f_407, blk_loc(e.mem, _f_407), _f_408, blk_loc(e.mem, _f_408), _f_409, _f_410, _f_411, 131073ull, 1, _a_25, blk_loc(e.mem, _a_25), 54ull) == 0) {
      return 0;
    }
    _v_1380 = _o_576[0];
    _v_1381 = _o_576[1];
    _v_1382 = _o_576[2];
    _v_1383 = _o_576[3];
    _v_1384 = _o_576[4];
    _v_1385 = _o_576[5];
    _v_1386 = _o_576[6];
    _v_1387 = _o_576[7];
    _v_1388 = _o_576[8];
    _v_1389 = _o_576[9];
    _v_1370 = _v_1380;
    _v_1371 = _v_1381;
    _v_1372 = _v_1382;
    _v_1373 = _v_1383;
    _v_1374 = _v_1384;
    _v_1375 = _v_1385;
    _v_1376 = _v_1386;
    _v_1377 = _v_1387;
    _v_1378 = _v_1388;
    _v_1379 = _v_1389;
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K402;
      WL_PUSHN(1);
    } else {
      u64 _t_106 = task_node(e, FID_MAIN_K402, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K402, _t_106);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_EFFECT_PRINT)) {
      u64 _t_107 = task_node(e, FID_EFFECT_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_107 + 0] = term_ctr(CID_SCON, STAT_OFF + 568);
      e.mem[_t_107 + 1] = _v_1370;
      e.mem[_t_107 + 2] = _v_1371;
      e.mem[_t_107 + 3] = _v_1372;
      e.mem[_t_107 + 4] = _v_1373;
      e.mem[_t_107 + 5] = _v_1374;
      e.mem[_t_107 + 6] = _v_1375;
      e.mem[_t_107 + 7] = _v_1376;
      e.mem[_t_107 + 8] = _v_1377;
      e.mem[_t_107 + 9] = _v_1378;
      e.mem[_t_107 + 10] = _v_1379;
      return term_tsk(FID_EFFECT_PRINT, _t_107);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 568);
    r1 = _v_1370;
    r2 = _v_1371;
    r3 = _v_1372;
    r4 = _v_1373;
    r5 = _v_1374;
    r6 = _v_1375;
    r7 = _v_1376;
    r8 = _v_1377;
    r9 = _v_1378;
    r10 = _v_1379;
    WL_JMP(FID_EFFECT_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K402)
  {
    Term _h_273 = r0;
    WL_OPEN
    u64 _nd_70 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_70 + 0] = _h_273;
    r0 = term_clo(FID_MAIN_C403, _nd_70);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C403)
  {
    Term _h_274 = r0;
    Term _x_67 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_129 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_129 + 0] = _h_274;
      e.mem[_t_129 + 1] = term_clo(FID_MAIN_C404, 0);
      e.mem[_t_129 + 2] = _x_67;
      return term_tsk(FID_IO_BIND, _t_129);
    }
    r0 = _h_274;
    r1 = term_clo(FID_MAIN_C404, 0);
    r2 = _x_67;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C404)
  {
    Term _x_68 = r0;
    WL_OPEN
    Term _fb_83[9];
    u64 _sp_83 = ctr_take(e, _x_68, 9, _fb_83);
    Term _f_412 = _fb_83[0];
    Term _f_413 = _fb_83[1];
    Term _f_414 = _fb_83[2];
    Term _f_415 = _fb_83[3];
    Term _f_416 = _fb_83[4];
    Term _f_417 = _fb_83[5];
    u32 _f_418 = _fb_83[6];
    Term _f_419 = _fb_83[7];
    u32 _f_420 = _fb_83[8];
    spare_free(e, cls_fit(9), _sp_83);
    Term _v_1390 = 0;
    Term _v_1391 = 0;
    Term _v_1392 = 0;
    Term _v_1393 = 0;
    Term _v_1394 = 0;
    Term _v_1395 = 0;
    u32 _v_1396 = 0;
    Term _v_1397 = 0;
    u32 _v_1398 = 0;
    u32 _v_1399 = 0;
    u32 _v_1400 = 0;
    u32 _v_1401 = 0;
    Term _v_1402 = 0;
    u32 _v_1403 = 0;
    Term _v_1404 = 0;
    u32 _v_1405 = 0;
    Term _v_1406 = 0;
    u32 _v_1407 = 0;
    u32 _v_1408 = 0;
    Term _v_1409 = 0;
    Term _v_1410 = 0;
    Term _v_1411 = 0;
    Term _v_1412 = 0;
    Term _v_1413 = 0;
    Term _v_1414 = 0;
    u32 _v_1415 = 0;
    Term _v_1416 = 0;
    u32 _v_1417 = 0;
    u32 _v_1418 = 0;
    u32 _v_1419 = 0;
    u32 _v_1420 = 0;
    Term _v_1421 = 0;
    u32 _v_1422 = 0;
    Term _v_1423 = 0;
    u32 _v_1424 = 0;
    Term _v_1425 = 0;
    u32 _v_1426 = 0;
    u32 _v_1427 = 0;
    Term _o_580[19];
    if (spin_67(e, _o_580, _f_412, blk_loc(e.mem, _f_412), _f_413, blk_loc(e.mem, _f_413), _f_414, blk_loc(e.mem, _f_414), _f_415, blk_loc(e.mem, _f_415), _f_416, blk_loc(e.mem, _f_416), _f_417, blk_loc(e.mem, _f_417), _f_418, _f_419, _f_420, 4ull) == 0) {
      return 0;
    }
    _v_1409 = _o_580[0];
    _v_1410 = _o_580[1];
    _v_1411 = _o_580[2];
    _v_1412 = _o_580[3];
    _v_1413 = _o_580[4];
    _v_1414 = _o_580[5];
    _v_1415 = _o_580[6];
    _v_1416 = _o_580[7];
    _v_1417 = _o_580[8];
    _v_1418 = _o_580[9];
    _v_1419 = _o_580[10];
    _v_1420 = _o_580[11];
    _v_1421 = _o_580[12];
    _v_1422 = _o_580[13];
    _v_1423 = _o_580[14];
    _v_1424 = _o_580[15];
    _v_1425 = _o_580[16];
    _v_1426 = _o_580[17];
    _v_1427 = _o_580[18];
    _v_1390 = _v_1409;
    _v_1391 = _v_1410;
    _v_1392 = _v_1411;
    _v_1393 = _v_1412;
    _v_1394 = _v_1413;
    _v_1395 = _v_1414;
    _v_1396 = _v_1415;
    _v_1397 = _v_1416;
    _v_1398 = _v_1417;
    _v_1399 = _v_1418;
    _v_1400 = _v_1419;
    _v_1401 = _v_1420;
    _v_1402 = _v_1421;
    _v_1403 = _v_1422;
    _v_1404 = _v_1423;
    _v_1405 = _v_1424;
    _v_1406 = _v_1425;
    _v_1407 = _v_1426;
    _v_1408 = _v_1427;
    u32 _o_581 = 0;
    u32 _o_582 = 0;
    u32 _o_583 = 0;
    Term _o_584 = 0;
    u32 _o_585 = 0;
    u32 _o_586 = 0;
    Term _o_587 = 0;
    u32 _o_588 = 0;
    u32 _o_589 = 0;
    u32 _o_590 = 0;
    u32 _o_591 = 0;
    if (_v_1399 == 0) {
      _o_581 = 0;
    } else {
      _o_581 = 1;
      u32 _o_592 = 0;
      Term _o_593 = 0;
      u32 _o_594 = 0;
      if (_v_1401 == 0) {
        _o_592 = 0;
      } else {
        _o_592 = 1;
        Term _fb_84[2];
        u64 _sp_84 = ctr_take(e, _v_1402, 2, _fb_84);
        Term _f_421 = _fb_84[0];
        u32 _f_422 = _fb_84[1];
        spare_free(e, cls_fit(2), _sp_84);
        _o_593 = _f_421;
        _o_594 = _f_422;
      }
      u32 _o_595 = 0;
      Term _o_596 = 0;
      u32 _o_597 = 0;
      if (_v_1403 == 0) {
        _o_595 = 0;
      } else {
        _o_595 = 1;
        Term _fb_85[2];
        u64 _sp_85 = ctr_take(e, _v_1404, 2, _fb_85);
        Term _f_423 = _fb_85[0];
        u32 _f_424 = _fb_85[1];
        spare_free(e, cls_fit(2), _sp_85);
        _o_596 = _f_423;
        _o_597 = _f_424;
      }
      u32 _o_598 = 0;
      if (_v_1405 == 0) {
        _o_598 = 0;
      } else {
        _o_598 = 1;
      }
      _o_582 = _v_1400;
      _o_583 = _o_592;
      _o_584 = _o_593;
      _o_585 = _o_594;
      _o_586 = _o_595;
      _o_587 = _o_596;
      _o_588 = _o_597;
      _o_589 = _o_598;
      _o_590 = _v_1407;
      _o_591 = _v_1408;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K405;
      WL_PUSHN(1);
    } else {
      u64 _t_108 = task_node(e, FID_MAIN_K405, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K405, _t_108);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_REMOVE_PRINT)) {
      u64 _t_109 = task_node(e, FID_REMOVE_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_109 + 0] = term_ctr(CID_SCON, STAT_OFF + 514);
      e.mem[_t_109 + 1] = _v_1390;
      e.mem[_t_109 + 2] = _v_1391;
      e.mem[_t_109 + 3] = _v_1392;
      e.mem[_t_109 + 4] = _v_1393;
      e.mem[_t_109 + 5] = _v_1394;
      e.mem[_t_109 + 6] = _v_1395;
      e.mem[_t_109 + 7] = _v_1396;
      e.mem[_t_109 + 8] = _v_1397;
      e.mem[_t_109 + 9] = _v_1398;
      e.mem[_t_109 + 10] = _o_581;
      e.mem[_t_109 + 11] = _o_582;
      e.mem[_t_109 + 12] = _o_583;
      e.mem[_t_109 + 13] = _o_584;
      e.mem[_t_109 + 14] = _o_585;
      e.mem[_t_109 + 15] = _o_586;
      e.mem[_t_109 + 16] = _o_587;
      e.mem[_t_109 + 17] = _o_588;
      e.mem[_t_109 + 18] = _o_589;
      e.mem[_t_109 + 19] = _o_590;
      e.mem[_t_109 + 20] = _o_591;
      return term_tsk(FID_REMOVE_PRINT, _t_109);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 514);
    r1 = _v_1390;
    r2 = _v_1391;
    r3 = _v_1392;
    r4 = _v_1393;
    r5 = _v_1394;
    r6 = _v_1395;
    r7 = _v_1396;
    r8 = _v_1397;
    r9 = _v_1398;
    r10 = _o_581;
    r11 = _o_582;
    r12 = _o_583;
    r13 = _o_584;
    r14 = _o_585;
    r15 = _o_586;
    r16 = _o_587;
    r17 = _o_588;
    r18 = _o_589;
    r19 = _o_590;
    r20 = _o_591;
    WL_JMP(FID_REMOVE_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K405)
  {
    Term _h_275 = r0;
    WL_OPEN
    u64 _nd_71 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_71 + 0] = _h_275;
    r0 = term_clo(FID_MAIN_C406, _nd_71);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C406)
  {
    Term _h_276 = r0;
    Term _x_69 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_128 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_128 + 0] = _h_276;
      e.mem[_t_128 + 1] = term_clo(FID_MAIN_C407, 0);
      e.mem[_t_128 + 2] = _x_69;
      return term_tsk(FID_IO_BIND, _t_128);
    }
    r0 = _h_276;
    r1 = term_clo(FID_MAIN_C407, 0);
    r2 = _x_69;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C407)
  {
    Term _x_70 = r0;
    WL_OPEN
    Term _fb_86[9];
    u64 _sp_86 = ctr_take(e, _x_70, 9, _fb_86);
    Term _f_425 = _fb_86[0];
    Term _f_426 = _fb_86[1];
    Term _f_427 = _fb_86[2];
    Term _f_428 = _fb_86[3];
    Term _f_429 = _fb_86[4];
    Term _f_430 = _fb_86[5];
    u32 _f_431 = _fb_86[6];
    Term _f_432 = _fb_86[7];
    u32 _f_433 = _fb_86[8];
    spare_free(e, cls_fit(9), _sp_86);
    Term _v_1531 = 0;
    Term _v_1532 = 0;
    Term _v_1533 = 0;
    Term _v_1534 = 0;
    Term _v_1535 = 0;
    Term _v_1536 = 0;
    u32 _v_1537 = 0;
    Term _v_1538 = 0;
    u32 _v_1539 = 0;
    u32 _v_1540 = 0;
    u32 _v_1541 = 0;
    u32 _v_1542 = 0;
    Term _v_1543 = 0;
    u32 _v_1544 = 0;
    Term _v_1545 = 0;
    u32 _v_1546 = 0;
    Term _v_1547 = 0;
    u32 _v_1548 = 0;
    u32 _v_1549 = 0;
    Term _v_1550 = 0;
    Term _v_1551 = 0;
    Term _v_1552 = 0;
    Term _v_1553 = 0;
    Term _v_1554 = 0;
    Term _v_1555 = 0;
    u32 _v_1556 = 0;
    Term _v_1557 = 0;
    u32 _v_1558 = 0;
    u32 _v_1559 = 0;
    u32 _v_1560 = 0;
    u32 _v_1561 = 0;
    Term _v_1562 = 0;
    u32 _v_1563 = 0;
    Term _v_1564 = 0;
    u32 _v_1565 = 0;
    Term _v_1566 = 0;
    u32 _v_1567 = 0;
    u32 _v_1568 = 0;
    Term _o_599[19];
    if (spin_44(e, _o_599, _f_425, blk_loc(e.mem, _f_425), _f_426, blk_loc(e.mem, _f_426), _f_427, blk_loc(e.mem, _f_427), _f_428, blk_loc(e.mem, _f_428), _f_429, blk_loc(e.mem, _f_429), _f_430, blk_loc(e.mem, _f_430), _f_431, _f_432, _f_433, 4ull) == 0) {
      return 0;
    }
    _v_1550 = _o_599[0];
    _v_1551 = _o_599[1];
    _v_1552 = _o_599[2];
    _v_1553 = _o_599[3];
    _v_1554 = _o_599[4];
    _v_1555 = _o_599[5];
    _v_1556 = _o_599[6];
    _v_1557 = _o_599[7];
    _v_1558 = _o_599[8];
    _v_1559 = _o_599[9];
    _v_1560 = _o_599[10];
    _v_1561 = _o_599[11];
    _v_1562 = _o_599[12];
    _v_1563 = _o_599[13];
    _v_1564 = _o_599[14];
    _v_1565 = _o_599[15];
    _v_1566 = _o_599[16];
    _v_1567 = _o_599[17];
    _v_1568 = _o_599[18];
    _v_1531 = _v_1550;
    _v_1532 = _v_1551;
    _v_1533 = _v_1552;
    _v_1534 = _v_1553;
    _v_1535 = _v_1554;
    _v_1536 = _v_1555;
    _v_1537 = _v_1556;
    _v_1538 = _v_1557;
    _v_1539 = _v_1558;
    _v_1540 = _v_1559;
    _v_1541 = _v_1560;
    _v_1542 = _v_1561;
    _v_1543 = _v_1562;
    _v_1544 = _v_1563;
    _v_1545 = _v_1564;
    _v_1546 = _v_1565;
    _v_1547 = _v_1566;
    _v_1548 = _v_1567;
    _v_1549 = _v_1568;
    u32 _o_600 = 0;
    u32 _o_601 = 0;
    u32 _o_602 = 0;
    Term _o_603 = 0;
    u32 _o_604 = 0;
    u32 _o_605 = 0;
    Term _o_606 = 0;
    u32 _o_607 = 0;
    u32 _o_608 = 0;
    u32 _o_609 = 0;
    u32 _o_610 = 0;
    if (_v_1540 == 0) {
      _o_600 = 0;
    } else {
      _o_600 = 1;
      u32 _o_611 = 0;
      Term _o_612 = 0;
      u32 _o_613 = 0;
      if (_v_1542 == 0) {
        _o_611 = 0;
      } else {
        _o_611 = 1;
        Term _fb_87[2];
        u64 _sp_87 = ctr_take(e, _v_1543, 2, _fb_87);
        Term _f_434 = _fb_87[0];
        u32 _f_435 = _fb_87[1];
        spare_free(e, cls_fit(2), _sp_87);
        _o_612 = _f_434;
        _o_613 = _f_435;
      }
      u32 _o_614 = 0;
      Term _o_615 = 0;
      u32 _o_616 = 0;
      if (_v_1544 == 0) {
        _o_614 = 0;
      } else {
        _o_614 = 1;
        Term _fb_88[2];
        u64 _sp_88 = ctr_take(e, _v_1545, 2, _fb_88);
        Term _f_436 = _fb_88[0];
        u32 _f_437 = _fb_88[1];
        spare_free(e, cls_fit(2), _sp_88);
        _o_615 = _f_436;
        _o_616 = _f_437;
      }
      u32 _o_617 = 0;
      if (_v_1546 == 0) {
        _o_617 = 0;
      } else {
        _o_617 = 1;
      }
      _o_601 = _v_1541;
      _o_602 = _o_611;
      _o_603 = _o_612;
      _o_604 = _o_613;
      _o_605 = _o_614;
      _o_606 = _o_615;
      _o_607 = _o_616;
      _o_608 = _o_617;
      _o_609 = _v_1548;
      _o_610 = _v_1549;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K408;
      WL_PUSHN(1);
    } else {
      u64 _t_110 = task_node(e, FID_MAIN_K408, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K408, _t_110);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOOKUP_PRINT)) {
      u64 _t_111 = task_node(e, FID_LOOKUP_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_111 + 0] = term_ctr(CID_SCON, STAT_OFF + 584);
      e.mem[_t_111 + 1] = _v_1531;
      e.mem[_t_111 + 2] = _v_1532;
      e.mem[_t_111 + 3] = _v_1533;
      e.mem[_t_111 + 4] = _v_1534;
      e.mem[_t_111 + 5] = _v_1535;
      e.mem[_t_111 + 6] = _v_1536;
      e.mem[_t_111 + 7] = _v_1537;
      e.mem[_t_111 + 8] = _v_1538;
      e.mem[_t_111 + 9] = _v_1539;
      e.mem[_t_111 + 10] = _o_600;
      e.mem[_t_111 + 11] = _o_601;
      e.mem[_t_111 + 12] = _o_602;
      e.mem[_t_111 + 13] = _o_603;
      e.mem[_t_111 + 14] = _o_604;
      e.mem[_t_111 + 15] = _o_605;
      e.mem[_t_111 + 16] = _o_606;
      e.mem[_t_111 + 17] = _o_607;
      e.mem[_t_111 + 18] = _o_608;
      e.mem[_t_111 + 19] = _o_609;
      e.mem[_t_111 + 20] = _o_610;
      return term_tsk(FID_LOOKUP_PRINT, _t_111);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 584);
    r1 = _v_1531;
    r2 = _v_1532;
    r3 = _v_1533;
    r4 = _v_1534;
    r5 = _v_1535;
    r6 = _v_1536;
    r7 = _v_1537;
    r8 = _v_1538;
    r9 = _v_1539;
    r10 = _o_600;
    r11 = _o_601;
    r12 = _o_602;
    r13 = _o_603;
    r14 = _o_604;
    r15 = _o_605;
    r16 = _o_606;
    r17 = _o_607;
    r18 = _o_608;
    r19 = _o_609;
    r20 = _o_610;
    WL_JMP(FID_LOOKUP_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K408)
  {
    Term _h_277 = r0;
    WL_OPEN
    u64 _nd_72 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_72 + 0] = _h_277;
    r0 = term_clo(FID_MAIN_C409, _nd_72);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C409)
  {
    Term _h_278 = r0;
    Term _x_71 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_127 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_127 + 0] = _h_278;
      e.mem[_t_127 + 1] = term_clo(FID_MAIN_C410, 0);
      e.mem[_t_127 + 2] = _x_71;
      return term_tsk(FID_IO_BIND, _t_127);
    }
    r0 = _h_278;
    r1 = term_clo(FID_MAIN_C410, 0);
    r2 = _x_71;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C410)
  {
    Term _x_72 = r0;
    WL_OPEN
    Term _fb_89[9];
    u64 _sp_89 = ctr_take(e, _x_72, 9, _fb_89);
    Term _f_438 = _fb_89[0];
    Term _f_439 = _fb_89[1];
    Term _f_440 = _fb_89[2];
    Term _f_441 = _fb_89[3];
    Term _f_442 = _fb_89[4];
    Term _f_443 = _fb_89[5];
    u32 _f_444 = _fb_89[6];
    Term _f_445 = _fb_89[7];
    u32 _f_446 = _fb_89[8];
    spare_free(e, cls_fit(9), _sp_89);
    Term _v_1569 = 0;
    Term _v_1570 = 0;
    Term _v_1571 = 0;
    Term _v_1572 = 0;
    Term _v_1573 = 0;
    Term _v_1574 = 0;
    u32 _v_1575 = 0;
    Term _v_1576 = 0;
    u32 _v_1577 = 0;
    u32 _v_1578 = 0;
    u32 _v_1579 = 0;
    u32 _v_1580 = 0;
    Term _v_1581 = 0;
    u32 _v_1582 = 0;
    Term _v_1583 = 0;
    u32 _v_1584 = 0;
    Term _v_1585 = 0;
    u32 _v_1586 = 0;
    u32 _v_1587 = 0;
    Term _v_1588 = 0;
    Term _v_1589 = 0;
    Term _v_1590 = 0;
    Term _v_1591 = 0;
    Term _v_1592 = 0;
    Term _v_1593 = 0;
    u32 _v_1594 = 0;
    Term _v_1595 = 0;
    u32 _v_1596 = 0;
    u32 _v_1597 = 0;
    u32 _v_1598 = 0;
    u32 _v_1599 = 0;
    Term _v_1600 = 0;
    u32 _v_1601 = 0;
    Term _v_1602 = 0;
    u32 _v_1603 = 0;
    Term _v_1604 = 0;
    u32 _v_1605 = 0;
    u32 _v_1606 = 0;
    Term _o_618[19];
    if (spin_67(e, _o_618, _f_438, blk_loc(e.mem, _f_438), _f_439, blk_loc(e.mem, _f_439), _f_440, blk_loc(e.mem, _f_440), _f_441, blk_loc(e.mem, _f_441), _f_442, blk_loc(e.mem, _f_442), _f_443, blk_loc(e.mem, _f_443), _f_444, _f_445, _f_446, 4ull) == 0) {
      return 0;
    }
    _v_1588 = _o_618[0];
    _v_1589 = _o_618[1];
    _v_1590 = _o_618[2];
    _v_1591 = _o_618[3];
    _v_1592 = _o_618[4];
    _v_1593 = _o_618[5];
    _v_1594 = _o_618[6];
    _v_1595 = _o_618[7];
    _v_1596 = _o_618[8];
    _v_1597 = _o_618[9];
    _v_1598 = _o_618[10];
    _v_1599 = _o_618[11];
    _v_1600 = _o_618[12];
    _v_1601 = _o_618[13];
    _v_1602 = _o_618[14];
    _v_1603 = _o_618[15];
    _v_1604 = _o_618[16];
    _v_1605 = _o_618[17];
    _v_1606 = _o_618[18];
    _v_1569 = _v_1588;
    _v_1570 = _v_1589;
    _v_1571 = _v_1590;
    _v_1572 = _v_1591;
    _v_1573 = _v_1592;
    _v_1574 = _v_1593;
    _v_1575 = _v_1594;
    _v_1576 = _v_1595;
    _v_1577 = _v_1596;
    _v_1578 = _v_1597;
    _v_1579 = _v_1598;
    _v_1580 = _v_1599;
    _v_1581 = _v_1600;
    _v_1582 = _v_1601;
    _v_1583 = _v_1602;
    _v_1584 = _v_1603;
    _v_1585 = _v_1604;
    _v_1586 = _v_1605;
    _v_1587 = _v_1606;
    u32 _o_619 = 0;
    u32 _o_620 = 0;
    u32 _o_621 = 0;
    Term _o_622 = 0;
    u32 _o_623 = 0;
    u32 _o_624 = 0;
    Term _o_625 = 0;
    u32 _o_626 = 0;
    u32 _o_627 = 0;
    u32 _o_628 = 0;
    u32 _o_629 = 0;
    if (_v_1578 == 0) {
      _o_619 = 0;
    } else {
      _o_619 = 1;
      u32 _o_630 = 0;
      Term _o_631 = 0;
      u32 _o_632 = 0;
      if (_v_1580 == 0) {
        _o_630 = 0;
      } else {
        _o_630 = 1;
        Term _fb_90[2];
        u64 _sp_90 = ctr_take(e, _v_1581, 2, _fb_90);
        Term _f_447 = _fb_90[0];
        u32 _f_448 = _fb_90[1];
        spare_free(e, cls_fit(2), _sp_90);
        _o_631 = _f_447;
        _o_632 = _f_448;
      }
      u32 _o_633 = 0;
      Term _o_634 = 0;
      u32 _o_635 = 0;
      if (_v_1582 == 0) {
        _o_633 = 0;
      } else {
        _o_633 = 1;
        Term _fb_91[2];
        u64 _sp_91 = ctr_take(e, _v_1583, 2, _fb_91);
        Term _f_449 = _fb_91[0];
        u32 _f_450 = _fb_91[1];
        spare_free(e, cls_fit(2), _sp_91);
        _o_634 = _f_449;
        _o_635 = _f_450;
      }
      u32 _o_636 = 0;
      if (_v_1584 == 0) {
        _o_636 = 0;
      } else {
        _o_636 = 1;
      }
      _o_620 = _v_1579;
      _o_621 = _o_630;
      _o_622 = _o_631;
      _o_623 = _o_632;
      _o_624 = _o_633;
      _o_625 = _o_634;
      _o_626 = _o_635;
      _o_627 = _o_636;
      _o_628 = _v_1586;
      _o_629 = _v_1587;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K411;
      WL_PUSHN(1);
    } else {
      u64 _t_112 = task_node(e, FID_MAIN_K411, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K411, _t_112);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_REMOVE_PRINT)) {
      u64 _t_113 = task_node(e, FID_REMOVE_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_113 + 0] = term_ctr(CID_SCON, STAT_OFF + 596);
      e.mem[_t_113 + 1] = _v_1569;
      e.mem[_t_113 + 2] = _v_1570;
      e.mem[_t_113 + 3] = _v_1571;
      e.mem[_t_113 + 4] = _v_1572;
      e.mem[_t_113 + 5] = _v_1573;
      e.mem[_t_113 + 6] = _v_1574;
      e.mem[_t_113 + 7] = _v_1575;
      e.mem[_t_113 + 8] = _v_1576;
      e.mem[_t_113 + 9] = _v_1577;
      e.mem[_t_113 + 10] = _o_619;
      e.mem[_t_113 + 11] = _o_620;
      e.mem[_t_113 + 12] = _o_621;
      e.mem[_t_113 + 13] = _o_622;
      e.mem[_t_113 + 14] = _o_623;
      e.mem[_t_113 + 15] = _o_624;
      e.mem[_t_113 + 16] = _o_625;
      e.mem[_t_113 + 17] = _o_626;
      e.mem[_t_113 + 18] = _o_627;
      e.mem[_t_113 + 19] = _o_628;
      e.mem[_t_113 + 20] = _o_629;
      return term_tsk(FID_REMOVE_PRINT, _t_113);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 596);
    r1 = _v_1569;
    r2 = _v_1570;
    r3 = _v_1571;
    r4 = _v_1572;
    r5 = _v_1573;
    r6 = _v_1574;
    r7 = _v_1575;
    r8 = _v_1576;
    r9 = _v_1577;
    r10 = _o_619;
    r11 = _o_620;
    r12 = _o_621;
    r13 = _o_622;
    r14 = _o_623;
    r15 = _o_624;
    r16 = _o_625;
    r17 = _o_626;
    r18 = _o_627;
    r19 = _o_628;
    r20 = _o_629;
    WL_JMP(FID_REMOVE_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K411)
  {
    Term _h_279 = r0;
    WL_OPEN
    u64 _nd_73 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_73 + 0] = _h_279;
    r0 = term_clo(FID_MAIN_C412, _nd_73);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C412)
  {
    Term _h_280 = r0;
    Term _x_73 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_126 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_126 + 0] = _h_280;
      e.mem[_t_126 + 1] = term_clo(FID_MAIN_C413, 0);
      e.mem[_t_126 + 2] = _x_73;
      return term_tsk(FID_IO_BIND, _t_126);
    }
    r0 = _h_280;
    r1 = term_clo(FID_MAIN_C413, 0);
    r2 = _x_73;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C413)
  {
    Term _x_74 = r0;
    WL_OPEN
    Term _fb_92[9];
    u64 _sp_92 = ctr_take(e, _x_74, 9, _fb_92);
    Term _f_451 = _fb_92[0];
    Term _f_452 = _fb_92[1];
    Term _f_453 = _fb_92[2];
    Term _f_454 = _fb_92[3];
    Term _f_455 = _fb_92[4];
    Term _f_456 = _fb_92[5];
    u32 _f_457 = _fb_92[6];
    Term _f_458 = _fb_92[7];
    u32 _f_459 = _fb_92[8];
    spare_free(e, cls_fit(9), _sp_92);
    Term _fv_36[1];
    _fv_36[0] = 400ull;
    Term _a_27 = blk_new(e, 0, 2ull, 0, 1, _fv_36);
    Term _at_128 = blk_loc(e.mem, _a_27);
    Term _at_129 = blk_at(_a_27, 1ull, 0);
    u32 _c_73 = blk_read(e.mem, 0, _at_128, _at_129 + 0);
    blk_write(e.mem, 0, _at_128, _at_129 + 0, U32_BIN(400ull, +, 1ull));
    Term _at_130 = blk_loc(e.mem, _a_27);
    Term _at_131 = blk_at(_a_27, 2ull, 0);
    u32 _c_74 = blk_read(e.mem, 0, _at_130, _at_131 + 0);
    blk_write(e.mem, 0, _at_130, _at_131 + 0, U32_BIN(400ull, +, 2ull));
    Term _at_132 = blk_loc(e.mem, _a_27);
    Term _at_133 = blk_at(_a_27, 3ull, 0);
    u32 _c_75 = blk_read(e.mem, 0, _at_132, _at_133 + 0);
    blk_write(e.mem, 0, _at_132, _at_133 + 0, U32_BIN(400ull, +, 3ull));
    u64 _nd_74 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_74 + 0] = rfc_seal(e, _a_27);
    e.mem[_nd_74 + 1] = rfc_seal(e, 400ull);
    Term _fv_37[1];
    _fv_37[0] = 410ull;
    Term _a_28 = blk_new(e, 0, 2ull, 0, 1, _fv_37);
    Term _at_134 = blk_loc(e.mem, _a_28);
    Term _at_135 = blk_at(_a_28, 1ull, 0);
    u32 _c_76 = blk_read(e.mem, 0, _at_134, _at_135 + 0);
    blk_write(e.mem, 0, _at_134, _at_135 + 0, U32_BIN(410ull, +, 1ull));
    Term _at_136 = blk_loc(e.mem, _a_28);
    Term _at_137 = blk_at(_a_28, 2ull, 0);
    u32 _c_77 = blk_read(e.mem, 0, _at_136, _at_137 + 0);
    blk_write(e.mem, 0, _at_136, _at_137 + 0, U32_BIN(410ull, +, 2ull));
    Term _at_138 = blk_loc(e.mem, _a_28);
    Term _at_139 = blk_at(_a_28, 3ull, 0);
    u32 _c_78 = blk_read(e.mem, 0, _at_138, _at_139 + 0);
    blk_write(e.mem, 0, _at_138, _at_139 + 0, U32_BIN(410ull, +, 3ull));
    u64 _nd_75 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_75 + 0] = rfc_seal(e, _a_28);
    e.mem[_nd_75 + 1] = rfc_seal(e, 410ull);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K414;
      WL_PUSHN(1);
    } else {
      u64 _t_114 = task_node(e, FID_MAIN_K414, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K414, _t_114);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STORAGE_ROWS_PLACE)) {
      u64 _t_115 = task_node(e, FID_STORAGE_ROWS_PLACE, WL_CONT, WL_IDX, 0);
      e.mem[_t_115 + 0] = _f_451;
      e.mem[_t_115 + 1] = _f_452;
      e.mem[_t_115 + 2] = _f_453;
      e.mem[_t_115 + 3] = _f_454;
      e.mem[_t_115 + 4] = _f_455;
      e.mem[_t_115 + 5] = _f_456;
      e.mem[_t_115 + 6] = _f_457;
      e.mem[_t_115 + 7] = _f_458;
      e.mem[_t_115 + 8] = _f_459;
      e.mem[_t_115 + 9] = 4ull;
      e.mem[_t_115 + 10] = 1;
      e.mem[_t_115 + 11] = term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_74);
      e.mem[_t_115 + 12] = 1;
      e.mem[_t_115 + 13] = term_ctr(CID____OWNED_INDEX_CORE_HEALTH, _nd_75);
      e.mem[_t_115 + 14] = 1;
      e.mem[_t_115 + 15] = term_pak(CID_UNIT, 0);
      e.mem[_t_115 + 16] = 81ull;
      e.mem[_t_115 + 17] = 82ull;
      return term_tsk(FID_STORAGE_ROWS_PLACE, _t_115);
    }
    r0 = _f_451;
    r1 = _f_452;
    r2 = _f_453;
    r3 = _f_454;
    r4 = _f_455;
    r5 = _f_456;
    r6 = _f_457;
    r7 = _f_458;
    r8 = _f_459;
    r9 = 4ull;
    r10 = 1;
    r11 = term_ctr(CID____OWNED_INDEX_CORE_MOTION, _nd_74);
    r12 = 1;
    r13 = term_ctr(CID____OWNED_INDEX_CORE_HEALTH, _nd_75);
    r14 = 1;
    r15 = term_pak(CID_UNIT, 0);
    r16 = 81ull;
    r17 = 82ull;
    WL_JMP(FID_STORAGE_ROWS_PLACE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K414)
  {
    u32 _h_281 = r0;
    Term _h_282 = r1;
    Term _h_283 = r2;
    Term _h_284 = r3;
    Term _h_285 = r4;
    Term _h_286 = r5;
    Term _h_287 = r6;
    u32 _h_288 = r7;
    Term _h_289 = r8;
    u32 _h_290 = r9;
    u32 _h_291 = r10;
    u32 _h_292 = r11;
    Term _h_293 = r12;
    u32 _h_294 = r13;
    Term _h_295 = r14;
    u32 _h_296 = r15;
    Term _h_297 = r16;
    u32 _h_298 = r17;
    u32 _h_299 = r18;
    WL_OPEN
    u32 _o_637 = 0;
    Term _o_638 = 0;
    Term _o_639 = 0;
    Term _o_640 = 0;
    Term _o_641 = 0;
    Term _o_642 = 0;
    Term _o_643 = 0;
    u32 _o_644 = 0;
    Term _o_645 = 0;
    u32 _o_646 = 0;
    u32 _o_647 = 0;
    u32 _o_648 = 0;
    Term _o_649 = 0;
    u32 _o_650 = 0;
    u32 _o_651 = 0;
    Term _o_652 = 0;
    u32 _o_653 = 0;
    u32 _o_654 = 0;
    u32 _o_655 = 0;
    u32 _o_656 = 0;
    if (_h_281 == 0) {
      _o_637 = 0;
      _o_638 = _h_282;
      _o_639 = _h_283;
      _o_640 = _h_284;
      _o_641 = _h_285;
      _o_642 = _h_286;
      _o_643 = _h_287;
      _o_644 = _h_288;
      _o_645 = _h_289;
      _o_646 = _h_290;
    } else {
      _o_637 = 1;
      u32 _o_657 = 0;
      Term _o_658 = 0;
      u32 _o_659 = 0;
      if (_h_292 == 0) {
        _o_657 = 0;
      } else {
        _o_657 = 1;
        Term _fb_93[2];
        u64 _sp_93 = ctr_take(e, _h_293, 2, _fb_93);
        Term _f_460 = _fb_93[0];
        u32 _f_461 = _fb_93[1];
        spare_free(e, cls_fit(2), _sp_93);
        _o_658 = _f_460;
        _o_659 = _f_461;
      }
      u32 _o_660 = 0;
      Term _o_661 = 0;
      u32 _o_662 = 0;
      if (_h_294 == 0) {
        _o_660 = 0;
      } else {
        _o_660 = 1;
        Term _fb_94[2];
        u64 _sp_94 = ctr_take(e, _h_295, 2, _fb_94);
        Term _f_462 = _fb_94[0];
        u32 _f_463 = _fb_94[1];
        spare_free(e, cls_fit(2), _sp_94);
        _o_661 = _f_462;
        _o_662 = _f_463;
      }
      u32 _o_663 = 0;
      if (_h_296 == 0) {
        _o_663 = 0;
      } else {
        _o_663 = 1;
      }
      _o_638 = _h_282;
      _o_639 = _h_283;
      _o_640 = _h_284;
      _o_641 = _h_285;
      _o_642 = _h_286;
      _o_643 = _h_287;
      _o_644 = _h_288;
      _o_645 = _h_289;
      _o_646 = _h_290;
      _o_647 = _h_291;
      _o_648 = _o_657;
      _o_649 = _o_658;
      _o_650 = _o_659;
      _o_651 = _o_660;
      _o_652 = _o_661;
      _o_653 = _o_662;
      _o_654 = _o_663;
      _o_655 = _h_298;
      _o_656 = _h_299;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K415;
      WL_PUSHN(1);
    } else {
      u64 _t_116 = task_node(e, FID_MAIN_K415, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K415, _t_116);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_PLACEMENT_PRINT)) {
      u64 _t_117 = task_node(e, FID_PLACEMENT_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_117 + 0] = term_ctr(CID_SCON, STAT_OFF + 614);
      e.mem[_t_117 + 1] = _o_637;
      e.mem[_t_117 + 2] = _o_638;
      e.mem[_t_117 + 3] = _o_639;
      e.mem[_t_117 + 4] = _o_640;
      e.mem[_t_117 + 5] = _o_641;
      e.mem[_t_117 + 6] = _o_642;
      e.mem[_t_117 + 7] = _o_643;
      e.mem[_t_117 + 8] = _o_644;
      e.mem[_t_117 + 9] = _o_645;
      e.mem[_t_117 + 10] = _o_646;
      e.mem[_t_117 + 11] = _o_647;
      e.mem[_t_117 + 12] = _o_648;
      e.mem[_t_117 + 13] = _o_649;
      e.mem[_t_117 + 14] = _o_650;
      e.mem[_t_117 + 15] = _o_651;
      e.mem[_t_117 + 16] = _o_652;
      e.mem[_t_117 + 17] = _o_653;
      e.mem[_t_117 + 18] = _o_654;
      e.mem[_t_117 + 19] = _o_655;
      e.mem[_t_117 + 20] = _o_656;
      return term_tsk(FID_PLACEMENT_PRINT, _t_117);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 614);
    r1 = _o_637;
    r2 = _o_638;
    r3 = _o_639;
    r4 = _o_640;
    r5 = _o_641;
    r6 = _o_642;
    r7 = _o_643;
    r8 = _o_644;
    r9 = _o_645;
    r10 = _o_646;
    r11 = _o_647;
    r12 = _o_648;
    r13 = _o_649;
    r14 = _o_650;
    r15 = _o_651;
    r16 = _o_652;
    r17 = _o_653;
    r18 = _o_654;
    r19 = _o_655;
    r20 = _o_656;
    WL_JMP(FID_PLACEMENT_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K415)
  {
    Term _h_300 = r0;
    WL_OPEN
    u64 _nd_76 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_76 + 0] = _h_300;
    r0 = term_clo(FID_MAIN_C416, _nd_76);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C416)
  {
    Term _h_301 = r0;
    Term _x_75 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_125 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_125 + 0] = _h_301;
      e.mem[_t_125 + 1] = term_clo(FID_MAIN_C417, 0);
      e.mem[_t_125 + 2] = _x_75;
      return term_tsk(FID_IO_BIND, _t_125);
    }
    r0 = _h_301;
    r1 = term_clo(FID_MAIN_C417, 0);
    r2 = _x_75;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C417)
  {
    Term _x_76 = r0;
    WL_OPEN
    Term _fb_95[9];
    u64 _sp_95 = ctr_take(e, _x_76, 9, _fb_95);
    Term _f_464 = _fb_95[0];
    Term _f_465 = _fb_95[1];
    Term _f_466 = _fb_95[2];
    Term _f_467 = _fb_95[3];
    Term _f_468 = _fb_95[4];
    Term _f_469 = _fb_95[5];
    u32 _f_470 = _fb_95[6];
    Term _f_471 = _fb_95[7];
    u32 _f_472 = _fb_95[8];
    spare_free(e, cls_fit(9), _sp_95);
    Term _v_1607 = 0;
    Term _v_1608 = 0;
    Term _v_1609 = 0;
    Term _v_1610 = 0;
    Term _v_1611 = 0;
    Term _v_1612 = 0;
    u32 _v_1613 = 0;
    Term _v_1614 = 0;
    u32 _v_1615 = 0;
    u32 _v_1616 = 0;
    u32 _v_1617 = 0;
    u32 _v_1618 = 0;
    Term _v_1619 = 0;
    u32 _v_1620 = 0;
    Term _v_1621 = 0;
    u32 _v_1622 = 0;
    Term _v_1623 = 0;
    u32 _v_1624 = 0;
    u32 _v_1625 = 0;
    Term _v_1626 = 0;
    Term _v_1627 = 0;
    Term _v_1628 = 0;
    Term _v_1629 = 0;
    Term _v_1630 = 0;
    Term _v_1631 = 0;
    u32 _v_1632 = 0;
    Term _v_1633 = 0;
    u32 _v_1634 = 0;
    u32 _v_1635 = 0;
    u32 _v_1636 = 0;
    u32 _v_1637 = 0;
    Term _v_1638 = 0;
    u32 _v_1639 = 0;
    Term _v_1640 = 0;
    u32 _v_1641 = 0;
    Term _v_1642 = 0;
    u32 _v_1643 = 0;
    u32 _v_1644 = 0;
    Term _o_664[19];
    if (spin_44(e, _o_664, _f_464, blk_loc(e.mem, _f_464), _f_465, blk_loc(e.mem, _f_465), _f_466, blk_loc(e.mem, _f_466), _f_467, blk_loc(e.mem, _f_467), _f_468, blk_loc(e.mem, _f_468), _f_469, blk_loc(e.mem, _f_469), _f_470, _f_471, _f_472, 4ull) == 0) {
      return 0;
    }
    _v_1626 = _o_664[0];
    _v_1627 = _o_664[1];
    _v_1628 = _o_664[2];
    _v_1629 = _o_664[3];
    _v_1630 = _o_664[4];
    _v_1631 = _o_664[5];
    _v_1632 = _o_664[6];
    _v_1633 = _o_664[7];
    _v_1634 = _o_664[8];
    _v_1635 = _o_664[9];
    _v_1636 = _o_664[10];
    _v_1637 = _o_664[11];
    _v_1638 = _o_664[12];
    _v_1639 = _o_664[13];
    _v_1640 = _o_664[14];
    _v_1641 = _o_664[15];
    _v_1642 = _o_664[16];
    _v_1643 = _o_664[17];
    _v_1644 = _o_664[18];
    _v_1607 = _v_1626;
    _v_1608 = _v_1627;
    _v_1609 = _v_1628;
    _v_1610 = _v_1629;
    _v_1611 = _v_1630;
    _v_1612 = _v_1631;
    _v_1613 = _v_1632;
    _v_1614 = _v_1633;
    _v_1615 = _v_1634;
    _v_1616 = _v_1635;
    _v_1617 = _v_1636;
    _v_1618 = _v_1637;
    _v_1619 = _v_1638;
    _v_1620 = _v_1639;
    _v_1621 = _v_1640;
    _v_1622 = _v_1641;
    _v_1623 = _v_1642;
    _v_1624 = _v_1643;
    _v_1625 = _v_1644;
    u32 _o_665 = 0;
    u32 _o_666 = 0;
    u32 _o_667 = 0;
    Term _o_668 = 0;
    u32 _o_669 = 0;
    u32 _o_670 = 0;
    Term _o_671 = 0;
    u32 _o_672 = 0;
    u32 _o_673 = 0;
    u32 _o_674 = 0;
    u32 _o_675 = 0;
    if (_v_1616 == 0) {
      _o_665 = 0;
    } else {
      _o_665 = 1;
      u32 _o_676 = 0;
      Term _o_677 = 0;
      u32 _o_678 = 0;
      if (_v_1618 == 0) {
        _o_676 = 0;
      } else {
        _o_676 = 1;
        Term _fb_96[2];
        u64 _sp_96 = ctr_take(e, _v_1619, 2, _fb_96);
        Term _f_473 = _fb_96[0];
        u32 _f_474 = _fb_96[1];
        spare_free(e, cls_fit(2), _sp_96);
        _o_677 = _f_473;
        _o_678 = _f_474;
      }
      u32 _o_679 = 0;
      Term _o_680 = 0;
      u32 _o_681 = 0;
      if (_v_1620 == 0) {
        _o_679 = 0;
      } else {
        _o_679 = 1;
        Term _fb_97[2];
        u64 _sp_97 = ctr_take(e, _v_1621, 2, _fb_97);
        Term _f_475 = _fb_97[0];
        u32 _f_476 = _fb_97[1];
        spare_free(e, cls_fit(2), _sp_97);
        _o_680 = _f_475;
        _o_681 = _f_476;
      }
      u32 _o_682 = 0;
      if (_v_1622 == 0) {
        _o_682 = 0;
      } else {
        _o_682 = 1;
      }
      _o_666 = _v_1617;
      _o_667 = _o_676;
      _o_668 = _o_677;
      _o_669 = _o_678;
      _o_670 = _o_679;
      _o_671 = _o_680;
      _o_672 = _o_681;
      _o_673 = _o_682;
      _o_674 = _v_1624;
      _o_675 = _v_1625;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K418;
      WL_PUSHN(1);
    } else {
      u64 _t_118 = task_node(e, FID_MAIN_K418, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K418, _t_118);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOOKUP_PRINT)) {
      u64 _t_119 = task_node(e, FID_LOOKUP_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_119 + 0] = term_ctr(CID_SCON, STAT_OFF + 632);
      e.mem[_t_119 + 1] = _v_1607;
      e.mem[_t_119 + 2] = _v_1608;
      e.mem[_t_119 + 3] = _v_1609;
      e.mem[_t_119 + 4] = _v_1610;
      e.mem[_t_119 + 5] = _v_1611;
      e.mem[_t_119 + 6] = _v_1612;
      e.mem[_t_119 + 7] = _v_1613;
      e.mem[_t_119 + 8] = _v_1614;
      e.mem[_t_119 + 9] = _v_1615;
      e.mem[_t_119 + 10] = _o_665;
      e.mem[_t_119 + 11] = _o_666;
      e.mem[_t_119 + 12] = _o_667;
      e.mem[_t_119 + 13] = _o_668;
      e.mem[_t_119 + 14] = _o_669;
      e.mem[_t_119 + 15] = _o_670;
      e.mem[_t_119 + 16] = _o_671;
      e.mem[_t_119 + 17] = _o_672;
      e.mem[_t_119 + 18] = _o_673;
      e.mem[_t_119 + 19] = _o_674;
      e.mem[_t_119 + 20] = _o_675;
      return term_tsk(FID_LOOKUP_PRINT, _t_119);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 632);
    r1 = _v_1607;
    r2 = _v_1608;
    r3 = _v_1609;
    r4 = _v_1610;
    r5 = _v_1611;
    r6 = _v_1612;
    r7 = _v_1613;
    r8 = _v_1614;
    r9 = _v_1615;
    r10 = _o_665;
    r11 = _o_666;
    r12 = _o_667;
    r13 = _o_668;
    r14 = _o_669;
    r15 = _o_670;
    r16 = _o_671;
    r17 = _o_672;
    r18 = _o_673;
    r19 = _o_674;
    r20 = _o_675;
    WL_JMP(FID_LOOKUP_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K418)
  {
    Term _h_302 = r0;
    WL_OPEN
    u64 _nd_77 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_77 + 0] = _h_302;
    r0 = term_clo(FID_MAIN_C419, _nd_77);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C419)
  {
    Term _h_303 = r0;
    Term _x_77 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_124 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_124 + 0] = _h_303;
      e.mem[_t_124 + 1] = term_clo(FID_MAIN_C420, 0);
      e.mem[_t_124 + 2] = _x_77;
      return term_tsk(FID_IO_BIND, _t_124);
    }
    r0 = _h_303;
    r1 = term_clo(FID_MAIN_C420, 0);
    r2 = _x_77;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C420)
  {
    Term _x_78 = r0;
    WL_OPEN
    Term _fb_98[9];
    u64 _sp_98 = ctr_take(e, _x_78, 9, _fb_98);
    Term _f_477 = _fb_98[0];
    Term _f_478 = _fb_98[1];
    Term _f_479 = _fb_98[2];
    Term _f_480 = _fb_98[3];
    Term _f_481 = _fb_98[4];
    Term _f_482 = _fb_98[5];
    u32 _f_483 = _fb_98[6];
    Term _f_484 = _fb_98[7];
    u32 _f_485 = _fb_98[8];
    spare_free(e, cls_fit(9), _sp_98);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K421;
      WL_PUSHN(1);
    } else {
      u64 _t_120 = task_node(e, FID_MAIN_K421, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K421, _t_120);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_METADATA_PRINT)) {
      u64 _t_121 = task_node(e, FID_METADATA_PRINT, WL_CONT, WL_IDX, 0);
      e.mem[_t_121 + 0] = _f_477;
      e.mem[_t_121 + 1] = _f_478;
      e.mem[_t_121 + 2] = _f_479;
      e.mem[_t_121 + 3] = _f_480;
      e.mem[_t_121 + 4] = _f_481;
      e.mem[_t_121 + 5] = _f_482;
      e.mem[_t_121 + 6] = _f_483;
      e.mem[_t_121 + 7] = _f_484;
      e.mem[_t_121 + 8] = _f_485;
      return term_tsk(FID_METADATA_PRINT, _t_121);
    }
    r0 = _f_477;
    r1 = _f_478;
    r2 = _f_479;
    r3 = _f_480;
    r4 = _f_481;
    r5 = _f_482;
    r6 = _f_483;
    r7 = _f_484;
    r8 = _f_485;
    WL_JMP(FID_METADATA_PRINT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K421)
  {
    Term _h_304 = r0;
    WL_OPEN
    u64 _nd_78 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_78 + 0] = _h_304;
    r0 = term_clo(FID_MAIN_C422, _nd_78);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C422)
  {
    Term _h_305 = r0;
    Term _x_79 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_123 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_123 + 0] = _h_305;
      e.mem[_t_123 + 1] = term_clo(FID_MAIN_C423, 0);
      e.mem[_t_123 + 2] = _x_79;
      return term_tsk(FID_IO_BIND, _t_123);
    }
    r0 = _h_305;
    r1 = term_clo(FID_MAIN_C423, 0);
    r2 = _x_79;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C423)
  {
    Term _x_80 = r0;
    WL_OPEN
    Term _fb_99[9];
    u64 _sp_99 = ctr_take(e, _x_80, 9, _fb_99);
    Term _f_486 = _fb_99[0];
    Term _f_487 = _fb_99[1];
    Term _f_488 = _fb_99[2];
    Term _f_489 = _fb_99[3];
    Term _f_490 = _fb_99[4];
    Term _f_491 = _fb_99[5];
    u32 _f_492 = _fb_99[6];
    Term _f_493 = _fb_99[7];
    u32 _f_494 = _fb_99[8];
    spare_free(e, cls_fit(9), _sp_99);
    term_sink(e, _f_486);
    term_sink(e, _f_487);
    term_sink(e, _f_488);
    term_sink(e, _f_489);
    term_sink(e, _f_490);
    term_sink(e, _f_491);
    r0 = term_clo(FID_MAIN_C424, 0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C424)
  {
    Term _x_81 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_122 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_122 + 0] = term_pak(CID_UNIT, 0);
      e.mem[_t_122 + 1] = _x_81;
      return term_tsk(FID_IO_PURE, _t_122);
    }
    r0 = term_pak(CID_UNIT, 0);
    r1 = _x_81;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_PRINT)
  {
    Term _text_2 = r0;
    Term _k_2 = r1;
    WL_OPEN
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = _text_2;
    e.mem[_nd_2 + 1] = _k_2;
    r0 = term_ctr(CID_IO_PRINT, _nd_2);
    WL_RETN(1);
  }}
#endif

  WL_CASE(FID_ENTER)
  {
    Term t = r0;
    WL_OPEN
    u32 f   = (u32)term_aux(t);
    u64 a   = term_loc(t);
    u32 war = fid_arity(f);
    WL_FRAME(t)
    seq |= fid_nofk(f) << 1;
    u32 rw = fid_resw(f);
    if (rw) {
      WL_LOAD(a + war - rw, rw)
      WL_ARGS(a, war - rw + 1)
    } else {
      WL_LOAD(a, war)
    }
    heap_free(e, cls_fit(war + 2), a);
    WL_DYN(f);
  }}

  WL_CASE(FID_IO_EMIT)
  {
    Term x = r0;
    WL_OPEN
    u64 l = heap_alloc(e, 0);
    e.mem[l] = x;
    r0 = term_ctr(CID_EMIT, l);
    WL_RETN(1);
  }}

  WL_CASE(FID_CLO_APPLY)
  {
    Term fun = r0;
    Term arg = r1;
    WL_OPEN
    u32 f    = (u32)term_aux(fun);
    u32 war  = fid_arity(f) - 1;
    u64 a    = term_loc(fun);
    WL_LOAD(a, war)
    spare_free(e, cls_fit(war), a);
    WL_LAST(arg)
    WL_DYN(f);
  }}

  WL_CASE(FID_EXIT)
  {
    u32  n = rn;
    Term rv[WL_RESW];
    WL_SAVE(rv)
    WL_OPEN
    if (err_seen(e.mem)) {
      return 0;
    }
    sp -= 2 * LANE_STEP;
    Term cont = STK(0);
    u32  idx  = (u32)STK(1);
    u32  wf   = (u32)term_aux(cont);
    if (cont != TERM_HOLE && fid_resw(wf)) {
      u64 wa = term_loc(cont);
      u32 wn = fid_arity(wf);
      WL_FRAME(cont)
      seq = (seq & 1) | fid_nofk(wf) << 1;
      WL_ARGS(wa, wn - n + 1)
      heap_free(e, cls_fit(wn + 2), wa);
      WL_TAKE(rv)
      WL_DYN(wf);
    }
    return task_deliver(e.mem, cont, idx, rv, n);
  }}

#if DEVICE
  default: {
    err_post(e.mem, ERR_FIDS);
    return 0;
  }
  }
  }
}
#endif

// Monk
// ====

// One turn on a ring: its head task below put0 runs (a growing
// lane skips a fork-free one). The host grows a row ring by
// ring and drains a ring; a device lane does both.
INLINE u32 monk_step(Env e, DEV Term* stk, u32 rg, u32 put0, u32 base, u32 stride,
  TG u32* cur) {
  DEV u64* H   = e.mem;
  bool     seq = stride == 0;
  DEV u32* get = ring_get(H, rg);
  if (*get == put0) {
    return 0;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, rg, *get);
  u32      hi = a32_load_acq(lo + 1);
  Term     t  = (((u64)hi << 32) | a32_load(lo)) & ~RFC_BIT;
  if ((hi >> 31) != ring_lap(*get) || (!seq && fid_nofk((u32)term_aux(t)))) {
    return 0;
  }
  a32_store(get, *get + 1);
  u32 spin = 0;
  for (;;) {
    Term r = work_loop(e, stk, t, seq);
    if (r == 0) {
      return 2;
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      if (err_spun(H, &spin)) {
        return 2;
      }
      if (stride != 0 && fid_nofk((u32)term_aux(r))) {
        ring_push(H, ring_pick(base, stride, cur), r);
        return 2;
      }
      t      = r;
      seq    = false;
      stride = 0;
      continue;
    }
    task_deal(H, r, base, stride, cur);
    return 1;
  }
}

// Dev
// ===

// One kernel: pass 0 grows the frontier, pass 1 drains each lane's ring,
// pass 2 packs the banks: in one group, each bank's [top, wr) slides onto
// rd, CUBE_T entries a step (loads, barrier, stores: rd <= top), off the
// host's pages. A grow pass ends when its group is full or nothing grew,
// so a spine of forks unrolls whole. TG_HOLD words of threadgroup memory
// hold one group per Apple core (bitonic 1.35x without).

#if DEVICE

INLINE void dev_cut(Env e) {
  if (err_seen(e.mem)) {
    return;
  }
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    u64 gen = (u64)KEEP(c) << c;
    while (ALC_LEN(e, c) >= gen) {
      u64 head = ALC_AT(e, c);
      u64 tail = head;
      for (u32 i = 1; i < KEEP(c); i += 1) {
        tail = e.mem[tail];
      }
      ALC_AT(e, c)    = e.mem[tail];
      ALC_LEN(e, c)  -= gen;
      e.mem[tail]     = 0;
      bank_push(e.mem, c, head);
    }
  }
}

INLINE void bank_pack(DEV u64* H, u32 lane) {
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    DEV Bank* b  = bank_at(H, c);
    u32       rd = b->rd;
    u32       n  = b->wr - b->top;
    for (u32 i = 0; i < n; i += CUBE_T) {
      Term v = i + lane < n ? H[b->off + b->top + i + lane] : 0;
      BAR();
      if (i + lane < n) {
        H[b->off + rd + i + lane] = v;
      }
    }
    BAR();
    if (lane == 0) {
      b->rd = b->wr = b->top = rd + n;
    }
  }
}

#ifdef __METAL_VERSION__
kernel void bend_dev(DEV u64* H [[buffer(0)]], constant u32& pass [[buffer(1)]],
  TG u32* vote [[threadgroup(0)]],
  u32 grids [[threadgroups_per_grid]],
  u32 row [[threadgroup_position_in_grid]],
  u32 lane [[thread_position_in_threadgroup]]) {
#else
extern "C" __global__ void bend_dev(DEV u64* H, u32 pass) {
  extern __shared__ u32 vote[];
  u32 grids = gridDim.x;
  u32 row   = blockIdx.x;
  u32 lane  = threadIdx.x;
#endif
  if (pass == 2) {
    bank_pack(H, lane);
    return;
  }
  u32  stride = grids == 1 ? CUBE_G : 1;
  u32  me     = row * CUBE_T + stride * lane;
  u32 rg     = pass ? ring_flip(me) : me;
  Env  e      = { H, H + ALC_OFF + me };
  DEV Term*  stk    = (DEV Term*)(H + STAK_OFF + me);
  if (lane == 0) {
    for (u32 i = 0; i < 3; i += 1) {
      a32_store(vote + i, 0);
    }
  }
  BAR();
  u32 put0      = a32_load(ring_put(H, rg));
  u32 seen_has  = 0;
  u32 seen_grew = 0;
  for (;;) {
    if (pass) {
      if (*ring_get(H, rg) == put0 || err_seen(H)) {
        break;
      }
    } else {
      put0 = a32_load(ring_put(H, rg));
      u32 has = put0 != a32_load(ring_get(H, rg));
      if (lane == 0 && (err_seen(H) || root_done(H))) {
        has = CUBE_T;
      }
      a32_add(vote + 2, has);
      BAR();
      has = a32_load(vote + 2);
      if (has - seen_has >= CUBE_T) {
        break;
      }
      seen_has = has;
    }
    u32 ran = monk_step(e, stk, rg, put0, row * CUBE_T, pass ? 0 : stride,
      vote);
    if (!pass) {
      if (ran == 1) {
        a32_add(vote + 1, 1);
      }
      BARD();
      u32 grew = a32_load(vote + 1);
      if (grew == seen_grew) {
        break;
      }
      seen_grew = grew;
    }
  }
  dev_cut(e);
}

#endif

// Window
// ======

// Linux's window fill (the Mac's is window_msl): an Image is a quadtree over
// 2^k x 2^k (Qua splits tl, tr, bl, br; Pix is 0xRRGGBB).
#if defined(__linux__) || defined(BEND_RTC)

INLINE u32 window_pix(DEV u64* H, Term t, u32 k, u32 x, u32 y) {
  for (u32 i = k; term_tag(t) == TAG_CTR;) {
    u32 j = 0;
    if (i > 0) {
      i -= 1;
      j = ((y >> i) & 1) * 2 + ((x >> i) & 1);
    }
    t = H[term_peek(H, t) + j];
  }
  return (u32)term_loc(t) & 0xFFFFFF;
}

#ifdef BEND_RTC
extern "C" __global__ void window_dev(DEV u64* H, Term root, u32 w, u32 h,
  u32 k, u32* out) {
  u32 x = blockIdx.x * blockDim.x + threadIdx.x;
  u32 y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x < w && y < h) {
    out[y * w + x] = window_pix(H, root, k, x, y);
  }
}
#endif

#endif

#if !DEVICE

// Row
// ===

static u32 row_grow(Env e, DEV Term* stk, u32 base, u32 stride, u32 want) {
  u64* H = e.mem;
  u32 cur = 0;
  for (;;) {
    u32 put0[CUBE_T];
    u32 has = 0;
    for (u32 i = 0; i < CUBE_T; i += 1) {
      put0[i] = *ring_put(H, base + i * stride);
      has += put0[i] != *ring_get(H, base + i * stride);
    }
    if (root_done(H) || has >= want) {
      return cur;
    }
    u32 grew = 0;
    u32 ran  = 0;
    for (u32 i = 0; i < CUBE_T && ran != 2; i += 1) {
      ran   = monk_step(e, stk, base + i * stride, put0[i], base, stride,
        &cur);
      grew += ran == 1;
    }
    if (grew == 0) {
      return cur;
    }
  }
}

// Pool
// ====

static void* pool_try(void* at, u64 bytes) {
  return mmap(at, bytes, PROT_READ | PROT_WRITE,
    MAP_PRIVATE | MAP_ANON | MAP_NORESERVE, -1, 0);
}

static void* pool_mmap(u64 bytes) {
  void* p = pool_try(NULL, bytes);
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static Term* pool_stack(void) {
  u64   len = 1ull << 31;
  char* p   = pool_mmap(len + 16384 + SIGSTKSZ);
  if (mprotect(p + len, 16384, PROT_NONE) != 0) {
    err_fail("stack guard failed");
  }
  stack_t ss = { .ss_sp = p + len + 16384, .ss_size = SIGSTKSZ };
  sigaltstack(&ss, NULL);
  struct sigaction sa = { .sa_handler = err_trap, .sa_flags = SA_ONSTACK };
  sigaction(SIGSEGV, &sa, NULL);
  sigaction(SIGBUS, &sa, NULL);
  return (Term*)p;
}

// A wait yields a while before it sleeps, so a turn that ends (or follows)
// within microseconds never pays a condvar wake.

#define POOL_WAIT(c, cv) \
  for (u32 s = 0; s < 128 && (c); s += 1) { \
    sched_yield(); \
  } \
  pthread_mutex_lock(&pool_lock); \
  while (c) { \
    pthread_cond_wait(&cv, &pool_lock); \
  } \
  pthread_mutex_unlock(&pool_lock);

static u32 pool_step(u32 rows) {
  u32 per = rows * CUBE_T / (32 * pool_size);
  return CUBE_T >> (31 - CLZ(per < LINE ? per | 1 : LINE));
}

static u32 pool_rows(Env e, DEV Term* stk) {
  u32 n = 0;
  for (;;) {
    u32 c    = a32_add(&pool_row, 1);
    u32 r    = c & 32767;
    u32 rows = c >> 15 & 255;
    u32 step = c >> 23 & 1 ? 1 : pool_step(rows);
    if (r >= rows * step) {
      if (n != 0 && a32_sub_rel(&pool_done, n) == n) {
        pthread_mutex_lock(&pool_lock);
        pthread_cond_signal(&pool_join);
        pthread_mutex_unlock(&pool_lock);
      }
      return c >> 24;
    }
    a32_acq(&pool_row);
    if (c >> 23 & 1) {
      row_grow(e, stk, r * CUBE_T, 1, CUBE_T);
    } else {
      u32 row = r / step * CUBE_T;
      for (u32 rg = row + r % step; rg < row + CUBE_T; rg += step) {
        u32 put0 = a32_load(ring_put(e.mem, rg));
        while (*ring_get(e.mem, rg) != put0 && !err_seen(e.mem)) {
          monk_step(e, stk, rg, put0, rg, 0, NULL);
        }
      }
    }
    n += 1;
  }
}

static void* pool_work(void* arg) {
  Term* stk  = pool_stack();
  u32   seen = 0;
  for (;;) {
    POOL_WAIT(a32_load(&pool_row) >> 24 == seen, pool_wake)
    seen = pool_rows((Env){ CORPUS, ALC[(uintptr_t)arg] }, stk);
  }
}

OUTLINE void pool_open(void) {
  static bool up;
  if (up) {
    return;
  }
  up = true;
  for (u32 w = 1; w < pool_size; w += 1) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, pool_work, (void*)(uintptr_t)w)) {
      err_fail("pthread_create");
    }
  }
}

static int cpu_read(const char* path, long* a, long* b) {
  FILE* f = fopen(path, "r");
  if (f == NULL) {
    return 0;
  }
  int n = fscanf(f, "%ld %ld", a, b);
  fclose(f);
  return n;
}

static long cpu_count(void) {
  long n = sysconf(_SC_NPROCESSORS_ONLN);
#ifdef __linux__
  cpu_set_t set;
  if (sched_getaffinity(0, sizeof set, &set) == 0) {
    n = CPU_COUNT(&set);
  }
  long q = 0;
  long p = 0;
  if (cpu_read("/sys/fs/cgroup/cpu.max", &q, &p) != 2) {
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_quota_us", &q, &p);
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_period_us", &p, &p);
  }
  if (q > 0 && p > 0 && (q + p - 1) / p < n) {
    n = (q + p - 1) / p;
  }
#endif
  return n;
}

OUTLINE void pool_turn(bool grow, u32 rows) {
  static u32 turn;
  u32 n = rows < CUBE_G ? rows : CUBE_G;
  turn += 1;
  a32_store(&pool_done, grow ? n : n * pool_step(n));
  pthread_mutex_lock(&pool_lock);
  a32_store_rel(&pool_row, turn << 24 | grow << 23 | n << 15);
  pthread_cond_broadcast(&pool_wake);
  pthread_mutex_unlock(&pool_lock);
  pool_rows((Env){ CORPUS, ALC[0] }, io_stk);
  POOL_WAIT(a32_load_acq(&pool_done) != 0, pool_join)
}

// Gpu
// ===

// gpu_make compiles the device program into <binary>.gpu
// (--gpu-build): Metal's binary archive, or CUDA's cubin behind a
// hash of the text. A launch loads it, else notes and compiles. CUDA
// shapes the bag by the device: a group of 128 lanes per 64 KB of
// L2, a power of two in 16..128 (Apple keeps the tuned 128). CUDA
// runs one stream: the default 8 cost about half of the startup.

static const char* gpu_path(void) {
  static char path[4096];
  u32 n = sizeof path - 8;
#ifdef __APPLE__
  _NSGetExecutablePath(path, &n);
#else
  path[readlink("/proc/self/exe", path, n)] = 0;
#endif
  return strcat(path, ".gpu");
}

static void gpu_note(const char* path) {
  fprintf(stderr, "bend: compiling the GPU program (%s is missing or"
    " stale)\n", path);
}

#if !BEND_CUDA
#define gpu_map pool_mmap
#endif

#if BEND_METAL || BEND_CUDA

static void gpu_kernel(u32 pass, u32 groups);

static void gpu_run(u32 f) {
  if (f < CUBE_T) {
    gpu_kernel(0, 1);
  }
  if (f < LANES) {
    gpu_kernel(0, CUBE_G);
  }
  gpu_kernel(1, CUBE_G);
  gpu_kernel(2, 1);
}

#endif

#if BEND_CUDA

static u64 gpu_hash(void) {
  u64 key = 14695981039346656037ull ^ CUBE_LOG;
  for (const char* p = BEND_SRC; *p != 0; p += 1) {
    key = (key ^ (u8)*p) * 1099511628211ull;
  }
  return key;
}

#endif

#if BEND_METAL

static void gpu_fail(NSError* err) {
  err_fail([[err localizedDescription] UTF8String]);
}

static bool gpu_probe(void) {
  return (gpu_dev = MTLCreateSystemDefaultDevice()) != nil;
}

static MTLComputePipelineDescriptor* gpu_desc(void) {
  NSError* err = nil;
  MTLCompileOptions* opts = [MTLCompileOptions new];
  opts.mathMode = MTLMathModeSafe;
  opts.preprocessorMacros = @{ @"CUBE_LOG": @(CUBE_LOG) };
  id<MTLLibrary> lib = [gpu_dev newLibraryWithSource:@(BEND_SRC) options:opts
    error:&err];
  if (!lib) {
    gpu_fail(err);
  }
  MTLComputePipelineDescriptor* d = [MTLComputePipelineDescriptor new];
  d.computeFunction = [lib newFunctionWithName:@"bend_dev"];
  return d;
}

static bool gpu_make(const char* path) {
  NSError* err = nil;
  id<MTLBinaryArchive> ar = [gpu_dev
    newBinaryArchiveWithDescriptor:[MTLBinaryArchiveDescriptor new] error:&err];
  if (![ar addComputePipelineFunctionsWithDescriptor:gpu_desc() error:&err]) {
    gpu_fail(err);
  }
  return [ar serializeToURL:[NSURL fileURLWithPath:@(path)] error:&err];
}

static id<MTLComputePipelineState> gpu_pipe(MTLComputePipelineDescriptor* d,
  id<MTLBinaryArchive> ar) {
  NSError* err = nil;
  d.binaryArchives = ar ? @[ar] : @[];
  id<MTLComputePipelineState> pso = [gpu_dev
    newComputePipelineStateWithDescriptor:d
    options:ar ? MTLPipelineOptionFailOnBinaryArchiveMiss : 0 reflection:nil
    error:&err];
  if (!pso && !ar) {
    gpu_fail(err);
  }
  return pso;
}

static u64 gpu_span(void) {
  u64 span = [gpu_dev recommendedMaxWorkingSetSize];
  u64 most = [gpu_dev maxBufferLength];
  span = span < most ? span : most;
  return span < (2ull << 30) ? span : 2ull << 30;
}

static void gpu_load(u64 bytes) {
  gpu_buf = [gpu_dev newBufferWithBytesNoCopy:CORPUS length:bytes
    options:MTLResourceStorageModeShared
      | MTLResourceHazardTrackingModeUntracked deallocator:nil];
  u64 most = [gpu_dev maxBufferLength];
  if (!gpu_buf && bytes > most) {
    char msg[96];
    snprintf(msg, sizeof msg, "--gpu %lluMB is over the device's %lluMB",
      (unsigned long long)(bytes >> 20), (unsigned long long)(most >> 20));
    err_fail(msg);
  }
  if (!gpu_buf) {
    err_fail("the GPU span is more than the device has");
  }
  @autoreleasepool {
    gpu_que = [gpu_dev newCommandQueue];
    const char* path = gpu_path();
    MTLBinaryArchiveDescriptor* ad = [MTLBinaryArchiveDescriptor new];
    ad.url = [NSURL fileURLWithPath:@(path)];
    MTLComputePipelineDescriptor* d = gpu_desc();
    id<MTLBinaryArchive> ar = [gpu_dev newBinaryArchiveWithDescriptor:ad
      error:nil];
    gpu_pso = ar ? gpu_pipe(d, ar) : nil;
    if (!gpu_pso) {
      gpu_note(path);
      gpu_pso = gpu_pipe(d, nil);
    }
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  [gpu_enc setComputePipelineState:gpu_pso];
  [gpu_enc setBuffer:gpu_buf offset:0 atIndex:0];
  [gpu_enc setBytes:&pass length:sizeof pass atIndex:1];
  [gpu_enc setThreadgroupMemoryLength:TG_HOLD * 8 atIndex:0];
  [gpu_enc dispatchThreadgroups:MTLSizeMake(groups, 1, 1)
    threadsPerThreadgroup:MTLSizeMake(CUBE_T, 1, 1)];
  [gpu_enc memoryBarrierWithScope:MTLBarrierScopeBuffers];
}

static void gpu_pass(u32 f) {
  @autoreleasepool {
    id<MTLCommandBuffer> cb = [gpu_que commandBuffer];
    gpu_enc = [cb computeCommandEncoder];
    gpu_run(f);
    [gpu_enc endEncoding];
    [cb commit];
    [cb waitUntilCompleted];
    if ([cb error]) {
      gpu_fail([cb error]);
    }
  }
}

#elif BEND_CUDA

static void gpu_shape(int units) {
  CUBE_LOG = 31 - CLZ(units < 16 ? 16 : units > 128 ? 128 : units);
}

static bool gpu_probe(void) {
  int       managed = 0;
  CUcontext ctx;
  setenv("CUDA_DEVICE_MAX_CONNECTIONS", "1", 0);
  if (cuInit(0) == CUDA_SUCCESS && cuDeviceGet(&gpu_dev, 0) == CUDA_SUCCESS) {
    cuDeviceGetAttribute(&managed,
      CU_DEVICE_ATTRIBUTE_CONCURRENT_MANAGED_ACCESS, gpu_dev);
  }
  int l2 = 1 << 23;
  cuDeviceGetAttribute(&l2, CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE, gpu_dev);
  gpu_shape(l2 >> 16);
  return managed != 0
    && cuDevicePrimaryCtxRetain(&ctx, gpu_dev) == CUDA_SUCCESS
    && cuCtxSetCurrent(ctx) == CUDA_SUCCESS;
}

static u64* gpu_map(u64 bytes) {
  CUdeviceptr p = 0;
  if (cuMemAllocManaged(&p, bytes, CU_MEM_ATTACH_GLOBAL) != CUDA_SUCCESS) {
    err_fail("corpus reservation failed");
  }
#if CUDA_VERSION >= 13000
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION,
    (CUmemLocation){ CU_MEM_LOCATION_TYPE_DEVICE, gpu_dev });
#else
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION, gpu_dev);
#endif
  return (u64*)(uintptr_t)p;
}

static bool gpu_make(const char* path) {
  int cc[2] = {0, 0};
  cuDeviceGetAttribute(cc,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR, gpu_dev);
  cuDeviceGetAttribute(cc + 1,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR, gpu_dev);
  char arch[40];
  char bag[24];
  snprintf(arch, sizeof arch, "--gpu-architecture=sm_%d%d", cc[0], cc[1]);
  snprintf(bag, sizeof bag, "-DCUBE_LOG=%u", CUBE_LOG);
  const char* opts[] = { arch, bag, "--fmad=false", "-default-device" };
  nvrtcProgram prog;
  if (nvrtcCreateProgram(&prog, BEND_SRC, "bend.cu", 0, NULL, NULL)
    != NVRTC_SUCCESS) {
    err_fail("cannot compile the CUDA library");
  }
  if (nvrtcCompileProgram(prog, 4, opts) != NVRTC_SUCCESS) {
    size_t n = 0;
    nvrtcGetProgramLogSize(prog, &n);
    char* log = calloc(n + 1, 1);
    if (log != NULL && nvrtcGetProgramLog(prog, log) == NVRTC_SUCCESS) {
      fprintf(stderr, "%s\n", log);
    }
    err_fail("cannot compile the CUDA library");
  }
  size_t len = 0;
  nvrtcGetCUBINSize(prog, &len);
  char* bin = malloc(len);
  if (bin == NULL || nvrtcGetCUBIN(prog, bin) != NVRTC_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  nvrtcDestroyProgram(&prog);
  u64   key = gpu_hash();
  FILE* out = path == NULL ? NULL : fopen(path, "wb");
  bool  ok  = out != NULL && fwrite(&key, 8, 1, out) == 1
    && fwrite(bin, 1, len, out) == len && fclose(out) == 0;
  if (cuModuleLoadData(&gpu_lib, bin) != CUDA_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  free(bin);
  return path == NULL || ok;
}

static u64 gpu_span(void) {
  size_t span = 0;
  cuDeviceTotalMem(&span, gpu_dev);
  return span;
}

static void gpu_load(u64 bytes) {
  const char* path = gpu_path();
  int         fd   = open(path, O_RDONLY);
  struct stat st   = { 0 };
  u64         key  = 0;
  char*       bin  = fd < 0 || fstat(fd, &st) != 0 || st.st_size <= 8 ? NULL
    : mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
  if (bin != NULL && bin != MAP_FAILED) {
    memcpy(&key, bin, 8);
  }
  if (key != gpu_hash()
    || cuModuleLoadData(&gpu_lib, bin + 8) != CUDA_SUCCESS) {
    gpu_note(path);
    gpu_make(path);
  }
  if (cuModuleGetFunction(&gpu_pso, gpu_lib, "bend_dev") != CUDA_SUCCESS) {
    err_fail("cannot load the GPU program");
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  void* args[] = { &CORPUS, &pass };
  if (cuLaunchKernel(gpu_pso, groups, 1, 1, CUBE_T, 1, 1, TG_HOLD * 8, NULL,
    args, NULL) != CUDA_SUCCESS) {
    err_fail("device launch failed");
  }
}

static void gpu_pass(u32 f) {
  gpu_run(f);
  if (cuCtxSynchronize() != CUDA_SUCCESS) {
    err_fail("device fault");
  }
}

#else

#define gpu_probe() false
#define gpu_make(p) true
#define gpu_span()  0
#define gpu_load(b)
#define gpu_pass(f)

#endif

// Cube
// ====

// The host's column grows to the rows that give a LINE of tasks a thread,
// no more: every task a grow starts early is live at once (tree-matmul's
// 2048 at 16 threads start 384 rounds: 15 MB -> 68 MB), and pool_step
// splits the few rows finely instead. A turn visits only the rows below
// its bound: a drain deals task g to ring_flip(g), whose row is at most g,
// a row grows into itself, and a column grow's cur tasks land in rows 0
// to cur - 1, so those rows hold every task.

// Between turns, each ring's pending tasks move back to slot 0.

static void ring_rewind(u64* H, u32 rows) {
  Term keep[RING_LEN];
  for (u32 r = 0; r < (rows < CUBE_G ? rows : CUBE_G) * CUBE_T; r += 1) {
    u32 g = *ring_get(H, r);
    u32 n = *ring_put(H, r) - g;
    if (g == 0 || n > RING_LEN) {
      continue;
    }
    for (u32 i = 0; i < n; i += 1) {
      keep[i] = *ring_slot(H, r, g + i) & ~RFC_BIT;
    }
    for (u32 i = n; i < g + n && i < RING_LEN; i += 1) {
      ((u32*)ring_slot(H, r, i))[1] = 0;
    }
    *ring_get(H, r) = *ring_put(H, r) = 0;
    for (u32 i = 0; i < n; i += 1) {
      ring_push(H, r, keep[i]);
    }
  }
}

static void cube_run(u64* H, bool gpu) {
  for (;;) {
    u32 f = a32_exch(a32_at(H, H_CURSOR), 0);
    if (root_done(H)) {
      return;
    }
    if (f == 0) {
      err_fail("frontier drained without a result");
    }
    if (gpu) {
      gpu_pass(f);
    } else {
      u32 rows = f;
      u32 want = (pool_size - 1) / (CUBE_T / LINE) + 1;
      if (f < want) {
        u32 cur = row_grow((Env){ H, ALC[0] }, io_stk, 0, CUBE_G, want);
        rows = cur > f ? cur : f;
      }
      if (f < CUBE) {
        pool_turn(true, rows);
      }
      f = a32_load(a32_at(H, H_CURSOR));
      pool_turn(false, f > rows ? f : rows);
      f = a32_load(a32_at(H, H_CURSOR));
      ring_rewind(H, f > rows ? f : rows);
    }
    u32 ec = a32_load(a32_at(H, H_ERROR_CODE));
    if (ec != 0) {
      err_post(H, ec);
    }
  }
}

// Corpus
// ======

// The cores map 8 GiB at a high base and double it in place, so one
// base holds every location; the banks move up past the pages. The GPU maps
// its whole span at once, and never grows it.

static u64 corpus_size;

static void* corpus_map(u64 size) {
  u64   hint = 1ull << 45;
  void* p    = pool_try((void*)hint, size);
  while (p != (void*)hint && hint > size) {
    if (p != MAP_FAILED) {
      munmap(p, size);
    }
    hint /= 2;
    p     = pool_try((void*)hint, size);
  }
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static void corpus_lay(u64* H, u64 size) {
  u64 span = size / 8;
  u64 cap  = span > HEAP_OFF ? (span - HEAP_OFF) / (PAGE_LEN + 10) : 0;
  if (cap <= CUBE) {
    err_fail("the GPU span is under the rings, stacks and a page per lane");
  }
  cap = cap < ~0u ? cap : ~0u - 1;
  u64 at = HEAP_OFF + (cap << PAGE_BITS);
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    Bank* b = bank_at(H, c);
    memcpy(H + at, H + b->off, b->wr * sizeof(u64));
    b->off  = at;
    at     += 2 * (cap >> ((c < NCLS ? NCLS : c) - PAGE_BITS));
  }
  corpus_size = size;
  a32_store_rel(a32_at(H, H_CAP), (u32)cap);
}

static bool corpus_grow(u64* H, u64 need) {
  bool ok = true;
  LOCK(bank_lock);
  while (ok && need > a32_load(a32_at(H, H_CAP))) {
    u64   more = corpus_size;
    char* at   = (char*)H + more;
    void* got  = io_gpu || more >= 1ull << 43 ? MAP_FAILED
      : pool_try(at, more);
    ok = got == at;
    if (ok) {
      corpus_lay(H, more * 2);
    } else if (got != MAP_FAILED) {
      munmap(got, more);
    }
  }
  UNLOCK(bank_lock);
  return ok;
}

static u64* corpus_setup(bool gpu, long threads, u64 bytes) {
  io_gpu     = gpu;
  KEEP_WORDS = gpu ? CHUNK : CAP_WORDS;
  u64 dflt   = gpu ? gpu_span() : 1ull << 33;
  u64 size   = (gpu && bytes != 0 ? bytes : dflt) & ~16383ull;
  CORPUS     = gpu ? gpu_map(size) : corpus_map(size);
  u64* H     = CORPUS;
#if BEND_CUDA
  if (gpu) {
    cuMemsetD8((CUdeviceptr)(uintptr_t)H, 0, STAK_OFF * 8);
    cuCtxSynchronize();
  }
#endif
  corpus_lay(H, size);
  memcpy(H + STAT_OFF, STAT_IMG, STAT_LEN * sizeof(u64));
  a32_store(a32_at(H, H_BUMP), 1);
  if (gpu) {
    gpu_load(size);
  }
  pool_size = threads < 1 ? 1 : threads < CUBE_T ? threads : CUBE_T;
  return H;
}

OUTLINE Term corpus_eval(u64* H, Term t) {
  Env  e = { H, ALC[0] };
  Term rv[WL_RESW];
  for (;;) {
    Term r = work_loop(e, io_stk, t, !BANGS && pool_size == 1);
    if (r == 0) {
      if (root_done(H)) {
        break;
      }
      err_fail("solo delivery lost");
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      t = r;
      if (io_gpu && fid_bangs((u32)term_aux(t))) {
        u64  tl   = task_tail(t);
        Term cont = H[tl];
        u32  idx  = (u32)(H[tl + 1] >> 32) & 0xFFFF;
        H[tl]     = TERM_HOLE;
        a32_store(a32_at(H, H_CURSOR), 1);
        ring_push(H, 0, t);
        cube_run(H, true);
        Term p = task_deliver(H, cont, idx, rv, root_take(H, rv));
        if (root_done(H)) {
          break;
        }
        if (p == 0) {
          err_fail("seam delivery lost");
        }
        t = p;
      }
      continue;
    }
    task_deal(H, r, 0, 0, NULL);
    pool_open();
    cube_run(H, false);
    break;
  }
  root_take(H, rv);
  return rv[0];
}

// Io
// ==

// Base's opaque, linear handles pack host fds or pointers into aux and loc:
// no forging, copying, reuse or host wrapper. A request's cont applied to
// its item is the next request. A parked request keeps its fd, deadline and
// readiness in word, time and evts; the loop then calls pack: a value
// resumes, IO_PARK parks again. The edge is UTF-8, decoded as WHATWG does: a
// broken sequence yields one U+FFFD and its breaking byte is read again as a
// lead. inet_aton reads a leading zero as octal, so io_sys_addr refuses it.
// macOS poll misses FIFO EOF, so io_wait selects, its sets sized to the
// highest fd (_DARWIN_UNLIMITED_SELECT allows fds past FD_SETSIZE).

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define IO_READ 1
#define IO_TIME 2
#define IO_PARK TERM_HOLE

#define io_hand(v)   term_make(TAG_PAK, (u64)(v) >> 40, (u64)(v) & LOC_MASK)
#define io_hand_v(t) (((u64)term_aux(t) << 40) | term_loc(t))

struct IoWork;
typedef void (*IoCall)(struct IoWork* w);
typedef Term (*IoPack)(Env e, struct IoWork* w);

typedef struct IoWork {
  intptr_t       hand;
  intptr_t       made;
  u32            word;
  u64            size;
  char*          data;
  char*          text;
  u32            code;
  IoCall         call;
  IoPack         pack;
  Term           cont;
  Term           item;
  u64            time;
  short          evts;
  struct IoWork* next;
} IoWork;

typedef Term (*Effect)(Env e, Term* f, IoWork* w);

typedef struct {
  Effect run;
  u32    ask;
} IoEff;

static IoEff io_eff_rows[1 << 16];
static u32   io_live;

static u64 io_tick(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}

OUTLINE void* io_mem(void* mem) {
  if (mem == NULL) {
    err_fail("host allocation failed");
  }
  return mem;
}

static int io_sys_addr(const char* host, u32 port, struct sockaddr_in* at) {
  memset(at, 0, sizeof(*at));
  at->sin_family = AF_INET;
  at->sin_port   = htons((uint16_t)port);
  for (const char* p = host; *p != 0; p += 1) {
    if ((p == host || p[-1] == '.') && *p == '0'
      && p[1] >= '0' && p[1] <= '9') {
      return -1;
    }
  }
  return port > 65535 || inet_pton(AF_INET, host, &at->sin_addr) != 1
    ? -1 : 0;
}

static int    io_argc;
static char** io_argv;

static void io_eff(u32 cid, Effect run, u32 need) {
  if (io_eff_rows[cid].run != NULL) {
    err_fail("two effects register one request");
  }
  io_eff_rows[cid] = (IoEff){ run, need };
}

static u64 io_sys_end(IoWork* w, ssize_t n) {
  w->code = n < 0 ? (u32)errno : 0;
  return n < 0 ? 0 : (u64)n;
}

static IoWork* io_runs;
static IoWork* io_park;
static IoWork* io_jobs;

static void io_push(IoWork** q, IoWork* a) {
  IoWork* l = *q != NULL ? *q : a;
  a->next = l->next;
  l->next = a;
  *q      = a;
}

static IoWork* io_pop(IoWork** q) {
  IoWork* a  = (*q)->next;
  (*q)->next = a->next;
  *q         = a != *q ? *q : NULL;
  return a;
}

static void io_spawn(Term m) {
  IoWork* a = io_mem(calloc(1, sizeof(IoWork)));
  a->cont  = m;
  a->item  = term_clo(FID_IO_EMIT, 0);
  io_push(&io_runs, a);
  io_live += 1;
}

// io_park stays in deadline order (time 0, none, sorts last; ties keep
// their park order), so io_wait wakes due timers in the order they expire.
static void io_park_add(IoWork* w) {
  IoWork* p = io_park;
  if (p == NULL || p->time - 1 <= w->time - 1) {
    io_push(&io_park, w);
    return;
  }
  while (p->next->time - 1 <= w->time - 1) {
    p = p->next;
  }
  io_push(&p, w);
}

static Term io_wait_on(IoWork* w, int fd, short evts, u64 time, IoPack more) {
  w->word = (u32)fd;
  w->pack = more;
  w->time = time;
  w->evts = evts;
  io_park_add(w);
  return IO_PARK;
}

OUTLINE void io_out(FILE* h, const char* data, u64 len) {
  if (fwrite(data, 1, len, h) != len) {
    err_fail("a short write on a standard stream");
  }
}

OUTLINE void io_sync(void) {
  if (fflush(stdout) != 0) {
    err_fail("a short write on a standard stream");
  }
}

static u64 io_utf8(char* buf, u64 c) {
  u64 k = c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
  for (u64 i = k; i > 1; i -= 1) {
    buf[i - 1] = (char)(0x80 | (c & 0x3F));
    c >>= 6;
  }
  buf[0] = (char)(k == 1 ? c : (0xF00 >> k) | c);
  return k;
}

// io_cbuf writes a String (cons SCon) as UTF-8, or a List (cons Con) as
// its bytes, with no UTF-8: NULL if a value is past 255.
OUTLINE char* io_cbuf(Env e, Term s, u64* len, u64 cons) {
  u64   cap = 64;
  u64   n   = 0;
  u64   bad = 0;
  char* buf = io_mem(malloc(cap));
  while (term_aux(s) == cons) {
    Term fb[2];
    spare_free(e, cls_fit(2), ctr_take(e, s, 2, fb));
    if (n + 5 > cap) {
      cap *= 2;
      buf = io_mem(realloc(buf, cap));
    }
    if (cons == CID_SCON) {
      n += io_utf8(buf + n, fb[0]);
    } else {
      bad |= fb[0] > 255;
      buf[n++] = (char)fb[0];
    }
    s = fb[1];
  }
  buf[n] = 0;
  *len = n;
  if (bad) {
    free(buf);
    return NULL;
  }
  return buf;
}

#define io_cstr(e, s, len) io_cbuf(e, s, len, CID_SCON)

OUTLINE void io_errs(Env e, Term s) {
  u64   n    = 0;
  char* text = io_cstr(e, s, &n);
  io_sync();
  io_out(stderr, text, n);
  io_out(stderr, "\n", 1);
  free(text);
}

#define io_nul(s, n) (strlen(s) != (n))

#define io_seal(e, t, cid) (cid_hot(cid) ? rfc_seal(e, t) : (t))

static Term io_node(Env e, u64 cid, Term a, Term b) {
  u64 l = heap_alloc(e, 1);
  e.mem[l]     = io_seal(e, a, cid);
  e.mem[l + 1] = io_seal(e, b, cid);
  return term_ctr(cid, l);
}

static Term io_str(Env e, const char* p, u64 n) {
  Term s    = term_pak(CID_SNIL, 0);
  u64  hole = 0;
  u64  c = 0, need = 0, lo = 0x80, hi = 0xBF;
  for (u64 i = 0; i < n || need > 0; i += 1) {
    u64 b = i < n ? (uint8_t)p[i] : 0x100;
    if (need > 0 && (b < lo || b > hi)) {
      need = 0;
      c    = 0xFFFD;
      i   -= 1;
    } else if (need > 0) {
      lo = 0x80;
      hi = 0xBF;
      c  = (c << 6) | (b & 0x3F);
      if (--need > 0) {
        continue;
      }
    } else if (b < 0x80) {
      c = b;
    } else if (b < 0xC2 || b > 0xF4) {
      c = 0xFFFD;
    } else {
      need = b < 0xE0 ? 1 : b < 0xF0 ? 2 : 3;
      lo   = b == 0xE0 ? 0xA0 : b == 0xF0 ? 0x90 : 0x80;
      hi   = b == 0xED ? 0x9F : b == 0xF4 ? 0x8F : 0xBF;
      c    = b & (0x3F >> need);
      continue;
    }
    u64  l = heap_alloc(e, 1);
    Term t = term_ctr(CID_SCON, l);
    e.mem[l] = c;
    if (hole == 0) {
      s = t;
    } else {
      e.mem[hole] = io_seal(e, t, CID_SCON);
    }
    hole = l + 1;
  }
  if (hole != 0) {
    e.mem[hole] = io_seal(e, term_pak(CID_SNIL, 0), CID_SCON);
  }
  return s;
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8.
#ifdef CID_CON

static Term io_list(Env e, const char* p, u64 n) {
  Term xs = term_pak(CID_NIL, 0);
  for (u64 i = n; i > 0; i -= 1) {
    xs = io_node(e, CID_CON, (uint8_t)p[i - 1], xs);
  }
  return xs;
}

#endif

#define io_tup(e, a, b) io_node(e, CID_TUPLE, a, b)
#define io_done(e, v)   io_box(e, CID_DONE, v)
#define io_res(e, w, v) ((w)->code ? io_fail(e, (w)->code, NULL) \
  : io_done(e, v))

static Term io_box(Env e, u64 cid, Term v) {
  u64 l = heap_alloc(e, 0);
  e.mem[l] = io_seal(e, v, cid);
  return term_ctr(cid, l);
}

static Term io_fail(Env e, u32 code, const char* text) {
  const char* s = text != NULL ? text : strerror((int)code);
  Term t = io_tup(e, code, io_str(e, s, strlen(s)));
  return io_box(e, CID_FAIL, t);
}

static pthread_mutex_t io_gate = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  io_bell = PTHREAD_COND_INITIALIZER;
static u32             io_busy;
static u32             io_size;
static int             io_wake_fd[2];

static void io_take(Env e) {
  IoWork* acts[64];
  ssize_t n;
  while ((n = read(io_wake_fd[0], acts, sizeof acts)) > 0) {
    for (u32 i = 0; i < (u32)n / sizeof(IoWork*); i += 1) {
      IoWork* a = acts[i];
      a->item   = a->pack(e, a);
      io_push(&io_runs, a);
      io_busy -= 1;
    }
  }
}

static void* io_help(void* arg) {
  for (;;) {
    pthread_mutex_lock(&io_gate);
    while (io_jobs == NULL) {
      pthread_cond_wait(&io_bell, &io_gate);
    }
    IoWork* a = io_pop(&io_jobs);
    pthread_mutex_unlock(&io_gate);
    a->call(a);
    while (write(io_wake_fd[1], &a, sizeof a) != sizeof a) {
    }
  }
}

static Term io_work(IoWork* w, IoCall call, IoPack pack) {
  w->call  = call;
  w->pack  = pack;
  io_busy += 1;
  if (io_busy > io_size && io_size < IO_HELP) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, io_help, NULL)) {
      err_fail("pthread_create");
    }
    pthread_detach(tid);
    io_size += 1;
  }
  pthread_mutex_lock(&io_gate);
  io_push(&io_jobs, w);
  pthread_cond_signal(&io_bell);
  pthread_mutex_unlock(&io_gate);
  return IO_PARK;
}

static Term io_exec(Env e, IoWork* w) {
  Term fs[256];
  u32  c = (u32)term_aux(w->cont);
  u32  n = cid_arity(c);
  spare_free(e, cls_fit(n), ctr_take(e, w->cont, n, fs));
  w->cont = fs[n - 1];
  return io_eff_rows[c].run(e, fs, w);
}

static bool io_bit(u8* set, int fd, bool put) {
  u8* at = set + fd / 8;
  *at |= put << fd % 8;
  return *at >> fd % 8 & 1;
}

static void io_wait(Env e, bool block) {
  int top  = io_wake_fd[0];
  u64 soon = io_park != NULL ? io_park->next->time : 0;
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0 && (int)a->word > top) {
      top = (int)a->word;
    }
  }
  u64 len = (u64)top / 64 * 8 + 8;
  u8* set[2] = { io_mem(calloc(2, len)), NULL };
  set[1] = set[0] + len;
  io_bit(set[0], io_wake_fd[0], true);
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0) {
      io_bit(set[a->evts == POLLOUT], (int)a->word, true);
    }
  }
  u64 tick = io_tick();
  u64 ms = soon > tick && block ? (soon - tick) / 1000000 + 1 : 0;
  struct timeval tv = { ms / 1000, ms % 1000 * 1000 };
  io_sync();
  if (select(top + 1, (fd_set*)set[0], (fd_set*)set[1], NULL,
    soon == 0 && block ? NULL : &tv) < 0) {
    if (errno != EINTR) {
      err_fail("the poller failed");
    }
    memset(set[0], 0, 2 * len);
  }
  if (io_bit(set[0], io_wake_fd[0], false)) {
    io_take(e);
  }
  u64     now  = io_tick();
  IoWork* todo = io_park;
  io_park = NULL;
  while (todo != NULL) {
    IoWork* a   = io_pop(&todo);
    bool    due = (a->evts != 0
        && io_bit(set[a->evts == POLLOUT], (int)a->word, false))
      || (a->time != 0 && a->time <= now);
    if (!due) {
      io_park_add(a);
      continue;
    }
    Term x = a->pack(e, a);
    if (x != IO_PARK) {
      a->item = x;
      io_push(&io_runs, a);
    }
  }
  free(set[0]);
}

static int f32_text(char* buf, f32 v) {
  int n = 0;
  int p = 0;
  if (v != v) {
    return sprintf(buf, "nan");
  }
  for (; p < 9; p += 1) {
    n = snprintf(buf, 40, "%.*e", p, (double)v);
    if (strtof(buf, NULL) == v) {
      break;
    }
  }
  char* ep = strchr(buf, 'e');
  if (ep == NULL) {
    return n;
  }
  int ex = atoi(ep + 1);
  if (ex >= 21 || ex <= -7) {
    n = (int)(ep - buf) + sprintf(ep, "e%c%d", ex < 0 ? '-' : '+', abs(ex));
  } else if (ex <= p) {
    n = snprintf(buf, 40, "%.*f", p - ex, (double)v);
  } else {
    int s = *buf == '-';
    memmove(buf + s + 1, buf + s + 2, p);
    memset(buf + s + 1 + p, '0', ex - p);
    n = s + 1 + ex;
  }
  return n;
}

static Term f32_show(Env e, Term x) {
  char buf[40];
  return io_str(e, buf, f32_text(buf, f32_unbox(x)));
}

static Term f32_read(Env e, Term s) {
  u64 n = 0;
  char* text = io_cstr(e, s, &n);
  char* end;
  f32 v = strtof(text, &end);
  Term out = n > 0 && (u64)(end - text) == n && strpbrk(text, "xX(") == NULL
    ? io_box(e, CID_SOME, f32_rewrap(v)) : term_pak(CID_NONE, 0);
  free(text);
  return out;
}


// Show
// ====

// show_val prints a pure main's value as term_show spells it: d
// is a SHOW_DESC node (see show_main), w its words, and chain the
// bracket of the [a, b] or (a, b) the value continues, or 0. Con
// or Nil spell a list, Tuple a tuple, and their tails continue
// it. show_chr escapes as char_show does; show_f32 prints the
// shortest text that reads back, with a point before an e.

#if MAIN_PURE

static void show_val(Env e, u32 d, const Term* w, char chain);

static void show_chr(u64 c, char q) {
  char b[4];
  int  k = c == 10 ? 'n' : c == 9 ? 't' : c == 13 ? 'r' : c == 0 ? '0'
    : c == 92 || c == (u64)q ? (int)c : 0;
  if (k != 0) {
    printf("\\%c", k);
  } else if (c < 32 || c == 127 || (c >= 0xD800 && c <= 0xDFFF)
    || c > 0x10FFFF) {
    printf("\\u{%llx}", (unsigned long long)c);
  } else {
    fwrite(b, 1, io_utf8(b, c), stdout);
  }
}

static void show_f32(u32 x) {
  char  buf[40];
  int   n  = f32_text(buf, f32_unbox(x));
  char* ep = memchr(buf, 'e', n);
  int   m  = ep == NULL ? n : (int)(ep - buf);
  buf[n] = 0;
  if (strpbrk(buf, ".ni") == NULL) {
    printf("%.*s.0%s", m, buf, buf + m);
  } else {
    fputs(buf, stdout);
  }
}

static void show_val(Env e, u32 d, const Term* w, char chain) {
  const u32* D = SHOW_DESC;
  Term one;
  char zs[4];
  u32  zn = 0;
  for (bool tail = true; tail;) switch (tail = false, D[d]) {
    case 0:
      printf("%u", (u32)w[0]);
      break;
    case 1:
      show_f32((u32)w[0]);
      break;
    case 2:
      printf("%llun", (unsigned long long)w[0]);
      break;
    case 3:
      putchar('\'');
      show_chr(D[d + 1] != 0 ? term_loc(w[0]) : w[0], '\'');
      putchar('\'');
      break;
    case 4:
      putchar('"');
      for (Term s = w[0]; term_aux(s) == CID_SCON;) {
        u64 l = term_peek(e.mem, s);
        show_chr(e.mem[l], '"');
        s = e.mem[l + 1];
      }
      putchar('"');
      break;
    case 5:
      fputs("{==}", stdout);
      break;
    case 6:
      putchar('[');
      for (u32 i = 0, g = D[d + 2]; i < 1u << (blk_cls(w[0]) - g); i += 1) {
        Term v[1u << g];
        for (u32 j = 0; j < 1u << g; j += 1) {
          v[j] = blk_read(e.mem, term_tag(w[0]) == TAG_ARR,
            term_peek(e.mem, w[0]), (i << g) + j);
        }
        fputs(i > 0 ? ", " : "", stdout);
        show_val(e, D[d + 1], v, 0);
      }
      putchar(']');
      break;
    default: {
      Term t   = w[0];
      bool box = D[d + 1] != 0;
      u32  key = box ? (u32)term_aux(t) : D[d + 2] > 1 ? (u32)t : 0;
      u32  a   = d + 3;
      for (u32 i = 0; box ? D[a + 1] != key : i != key; i += 1) {
        a += 4 + 2 * D[a + 2];
      }
      if (box) {
        one = term_loc(t);
        w   = term_tag(t) == TAG_PAK ? &one : e.mem + term_peek(e.mem, t);
      }
      char o = "{[("[D[a + 3]];
      if (o == '{') {
        printf("%s{", SHOW_NAMES[D[a]]);
      } else if (chain != o) {
        putchar(o);
      }
      if (o == '{' || chain != o) {
        zs[zn++] = "}])"[D[a + 3]];
      }
      for (u32 j = 0; j < D[a + 2]; j += 1) {
        if (o == '[' ? j == 0 && chain == o : j > 0) {
          fputs(", ", stdout);
        }
        if (j == 1 && o != '{') {
          tail  = true;
          chain = o;
          d     = D[a + 5 + 2 * j];
          w     = w + D[a + 4 + 2 * j];
        } else {
          show_val(e, D[a + 5 + 2 * j], w + D[a + 4 + 2 * j], 0);
        }
      }
    }
  }
  while (zn > 0) {
    putchar(zs[--zn]);
  }
}

#endif

// Run
// ===

static void io_step(Env e, IoWork* a) {
  for (;;) {
    u64  ap  = task_node(e, FID_CLO_APPLY, TERM_HOLE, 0, 0);
    e.mem[ap]     = a->cont;
    e.mem[ap + 1] = a->item;
    Term req = corpus_eval(e.mem, term_tsk(FID_CLO_APPLY, ap));
    u32  c   = (u32)term_aux(req);
    u64  at  = term_peek(e.mem, req);
    if (c == CID_EMIT) {
      term_drop(e, req);
      free(a);
      io_live -= 1;
      return;
    }
    if (c == CID_HALT) {
      io_errs(e, e.mem[at + 1]);
      exit((int)(u32)e.mem[at]);
    }
    if (io_eff_rows[c].run == NULL) {
      err_fail("an alien request");
    }
    u32 need = io_eff_rows[c].ask;
    u32 word = (u32)(need & IO_READ ? io_hand_v(e.mem[at]) : e.mem[at]);
    a->cont  = req;
    if (need != 0) {
      io_wait_on(a, (int)word, need & IO_READ ? POLLIN : 0,
        need & IO_TIME ? io_tick() + (u64)word * 1000000ull : 0, io_exec);
      return;
    }
    Term x = io_exec(e, a);
    if (x == IO_PARK) {
      return;
    }
    a->item = x;
  }
}

OUTLINE void io_loop(u64* H) {
  Env e = { H, ALC[0] };
  io_stk = pool_stack();
  signal(SIGPIPE, SIG_IGN);
  if (pipe(io_wake_fd) | fcntl(io_wake_fd[0], F_SETFL, O_NONBLOCK)) {
    err_fail("the event loop failed to open");
  }
  Term m = corpus_eval(H, term_tsk(MAIN_FID, task_node(e, MAIN_FID,
    TERM_HOLE, 0, 0)));
#if MAIN_PURE
  show_val(e, 0, H + H_ROOT_WORD, 0);
  putchar('\n');
  return;
#endif
  io_spawn(m);
  u64 look = 0;
  for (u32 n = 0;; n += 1) {
    if (io_runs == NULL) {
      if (io_live == 0) {
        return;
      }
      if (io_park == NULL && io_busy == 0) {
        io_sync();
        err_fail("deadlock: every computation waits on a channel");
      }
      io_wait(e, true);
      continue;
    }
    if ((n & 63) == 0 && io_busy != 0) {
      io_take(e);
    }
    // A busy loop still checks due timers, and fds periodically.
    if ((n & 63) == 0 && io_park != NULL) {
      u64 now = io_tick();
      if (now >= look || io_park->next->time - 1 < now) {
        look = now + 10000000;
        io_wait(e, false);
      }
    }
    io_step(e, io_pop(&io_runs));
  }
}

// Requests
// ========

// IO
// ==

Term io_print_run(Env e, Term* f, IoWork* w) {
  uint64_t n = 0;
  char* text = io_cstr(e, f[0], &n);
  io_out(stdout, text, n);
  io_out(stdout, "\n", 1);
  free(text);
  return term_pak(CID_UNIT, 0);
}

static void __attribute__((constructor)) io_print_use(void) {
  io_eff(CID_IO_PRINT, io_print_run, 0);
}


// Main
// ====

int main(int argc, char** argv) {
  long thr = 0;
  int  gpu = -1;
  u64  mem = 0;
  io_argv = argv;
  io_argc = 1;
  for (int i = 1; i < argc; i += 1) {
    const char* a = argv[i];
    const char* v = i + 1 < argc ? argv[i + 1] : NULL;
    if (strcmp(a, "--") == 0) {
      while (i + 1 < argc) {
        io_argv[io_argc++] = argv[++i];
      }
    } else if (strcmp(a, "--bend-help") == 0) {
      printf(CLI_HELP, argv[0]);
      return 0;
    } else if (strcmp(a, "--gpu-build") == 0) {
      if (gpu_probe() && !gpu_make(gpu_path())) {
        fprintf(stderr, "bend: cannot write %s\n", gpu_path());
        return 1;
      }
      return 0;
    } else if (strcmp(a, "--threads") == 0) {
      char* end = NULL;
      thr = v != NULL ? strtol(v, &end, 10) : 0;
      if (thr < 1 || *end != '\0') {
        err_fail("expected a thread count of 1 or more after --threads");
      }
      i += 1;
    } else if (strcmp(a, "--gpu") == 0) {
      char*  end = NULL;
      double n   = v != NULL ? strtod(v, &end) : 0;
      u64    mul = end == NULL ? 0 : strcmp(end, "GB") == 0 ? 1ull << 30
        : strcmp(end, "MB") == 0 ? 1ull << 20 : 0;
      if (v != NULL && strcmp(v, "off") == 0) {
        gpu = 0;
      } else if (v != NULL && (strcmp(v, "on") == 0 || (mul != 0 && n > 0))) {
        gpu = 1;
        mem = (u64)(n * (double)mul);
      } else {
        err_fail("expected on, off or a size like 4GB after --gpu");
      }
      i += 1;
    } else {
      io_argv[io_argc++] = argv[i];
    }
  }
  bool dev = gpu != 0 && BANGS != 0 && gpu_probe();
  if (gpu == 1 && BANGS != 0 && !dev) {
    err_fail("--gpu on, but this binary found no usable GPU (a CUDA GPU needs"
      " concurrent managed access, which WSL2's lack)");
  }
  io_loop(corpus_setup(dev, thr > 0 ? thr : cpu_count(), mem));
  io_sync();
  return 0;
}

#endif
