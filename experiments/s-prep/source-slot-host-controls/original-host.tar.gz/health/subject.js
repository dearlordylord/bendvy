function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

for (const k of ["IO.print"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return $host$045health$045body$058main_health$();
}

function $host$045health$045body$058main_health$() {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $IO$print$("{\"kind\":\"Lane\",\"schema\":\"Health\",\"style\":\"returned-owner\"}", _x_1), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $IO$bind$(($host$045health$045body$058health_execute$({$: "capture.Returned"}, ($host$045health$045body$058health_initial$({$: "capture.Returned"})))), run_clo((_x_4) => {
  return run_clo((_x_5) => {
  return $IO$bind$((_x_6) => $IO$print$("{\"kind\":\"Lane\",\"schema\":\"Health\",\"style\":\"regenerated-closure\"}", _x_6), run_clo((_x_7) => {
  return run_clo((_x_8) => {
  return $IO$bind$(($host$045health$045body$058health_execute$({$: "capture.Regenerated"}, ($host$045health$045body$058health_initial$({$: "capture.Regenerated"})))), run_clo((_x_9) => {
  return run_clo((_x_10) => {
  return $IO$pure$({$: "Unit"}, _x_10);
});
}), _x_8);
});
}), _x_5);
});
}), _x_3);
});
}), _x_0);
});
}

function $IO$bind$(_m_0, _f_0, _k_0) {
  return run_tail(_m_0, run_clo((_x_0) => {
  return run_tail(_f_0(_x_0), _k_0);
}));
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $host$045health$045body$058health_execute$(_style_0, _maybe_0) {
  if (_maybe_0.$ === "None") {
    return (_x_0) => $IO$print$("SETUP-REJECTED", _x_0);
  } else {
    const _lane_0 = _maybe_0["value"];
    return run_clo((_x_1) => {
  return $IO$bind$(($host$045health$045body$058health_run$(($host$045health$045body$058frames$()), _lane_0)), run_clo((_x_2) => {
  return $host$045health$045body$058health_finish_main$(_x_2);
}), _x_1);
});
  }
}

function $host$045health$045body$058health_initial$(_style_0) {
  return $host$045health$045body$058health_created_alpha$(_style_0, ($identity$058create$1260$(($identity$058factory$()), {$: "types.HealthOn"})));
}

function $IO$pure$(_x_0, _k_0) {
  return run_tail(_k_0, _x_0);
}

function $host$045health$045body$058health_run$(_plan_0, _lane_0) {
  if (_plan_0.$ === "Nil") {
    return run_clo((_x_0) => {
  return $IO$pure$(_lane_0, _x_0);
});
  } else {
    const _t_0 = _plan_0["head"];
    const _beta_0 = _t_0["beta"];
    const _tracked_0 = _t_0["tracked"];
    const _name_0 = _t_0["name"];
    const _snapshot_0 = _t_0["snapshot"];
    const _ops_0 = _t_0["operations"];
    const _tail_0 = _plan_0["tail"];
    return run_clo((_x_1) => {
  const _x_2 = ($String$eq$(_name_0, "E1-foreign-alpha"));
  const _x_3 = ($String$eq$(_name_0, "E1-foreign-beta"));
  return $IO$bind$(($host$045health$045body$058health_choose_foreign$((_x_2 || _x_3), _beta_0, _tracked_0, _name_0, _snapshot_0, _ops_0, _lane_0)), run_clo((_x_4) => {
  return $host$045health$045body$058health_run$(_tail_0, _x_4);
}), _x_1);
});
  }
}

function $host$045health$045body$058frames$() {
  return {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E0-empty", "snapshot": false, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E0-prime", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Call", "name": "Fast", "mode": {$: "schedule.Observe"}}, "tail": {$: "Con", "head": {$: "host-health-body.Call", "name": "B", "mode": {$: "schedule.Observe"}}, "tail": {$: "Nil"}}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E0-seed", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Call", "name": "SeedAlpha", "mode": {$: "schedule.Normal"}}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": true, "tracked": false, "name": "E0-seed.beta", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Call", "name": "SeedBeta", "mode": {$: "schedule.Normal"}}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": false, "name": "E0-pending", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": true, "tracked": false, "name": "E0-pending", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E1-empty", "snapshot": false, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": false, "name": "E1-before-D", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": true, "tracked": false, "name": "E1-before-D", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E1", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Deferred"}, "tail": {$: "Con", "head": {$: "host-health-body.Call", "name": "Fast", "mode": {$: "schedule.Observe"}}, "tail": {$: "Nil"}}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": true, "tracked": false, "name": "E1-D.beta", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Deferred"}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": false, "name": "E1", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": true, "tracked": false, "name": "E1", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": true, "tracked": false, "name": "E1-foreign-beta", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Call", "name": "ForeignLookup", "mode": {$: "schedule.Normal"}}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": false, "name": "E1-foreign-alpha", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Call", "name": "ForeignLookup", "mode": {$: "schedule.Normal"}}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E2", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Call", "name": "A", "mode": {$: "schedule.Normal"}}, "tail": {$: "Con", "head": {$: "host-health-body.Call", "name": "Fast", "mode": {$: "schedule.Observe"}}, "tail": {$: "Con", "head": {$: "host-health-body.Nested", "operations": {$: "Con", "head": {$: "host-health-body.Call", "name": "B", "mode": {$: "schedule.BFail"}}, "tail": {$: "Con", "head": {$: "host-health-body.Call", "name": "TailInner", "mode": {$: "schedule.Normal"}}, "tail": {$: "Nil"}}}}, "tail": {$: "Con", "head": {$: "host-health-body.Call", "name": "TailOuter", "mode": {$: "schedule.Normal"}}, "tail": {$: "Nil"}}}}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": false, "name": "E3-before-empty", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": true, "tracked": false, "name": "E3-before-empty", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E3-empty", "snapshot": false, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": false, "name": "E3-after-empty", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": true, "tracked": false, "name": "E3-after-empty", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E3", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Call", "name": "Fast", "mode": {$: "schedule.Observe"}}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E4-retry", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Nested", "operations": {$: "Con", "head": {$: "host-health-body.Call", "name": "B", "mode": {$: "schedule.Retry"}}, "tail": {$: "Con", "head": {$: "host-health-body.Call", "name": "TailInner", "mode": {$: "schedule.Normal"}}, "tail": {$: "Nil"}}}}, "tail": {$: "Con", "head": {$: "host-health-body.Call", "name": "TailOuter", "mode": {$: "schedule.Normal"}}, "tail": {$: "Nil"}}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": false, "name": "E4-before-empty", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": true, "tracked": false, "name": "E4-before-empty", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E4-empty", "snapshot": false, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": false, "name": "E4-after-empty", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": true, "tracked": false, "name": "E4-after-empty", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E4-read", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Call", "name": "Fast", "mode": {$: "schedule.Observe"}}, "tail": {$: "Con", "head": {$: "host-health-body.Call", "name": "B", "mode": {$: "schedule.Observe"}}, "tail": {$: "Nil"}}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E5", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Deferred"}, "tail": {$: "Con", "head": {$: "host-health-body.Call", "name": "Fast", "mode": {$: "schedule.Observe"}}, "tail": {$: "Con", "head": {$: "host-health-body.Call", "name": "B", "mode": {$: "schedule.Observe"}}, "tail": {$: "Nil"}}}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": false, "name": "E5", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": true, "tracked": false, "name": "E5", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E5-empty-D", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Deferred"}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": false, "name": "E5-after-empty-D", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": true, "tracked": false, "name": "E5-after-empty-D", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E6-off", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Call", "name": "SetOff", "mode": {$: "schedule.Normal"}}, "tail": {$: "Con", "head": {$: "host-health-body.Transition"}, "tail": {$: "Nil"}}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E6a", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Call", "name": "Cleanup", "mode": {$: "schedule.Normal"}}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": false, "name": "E6a", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": true, "tracked": false, "name": "E6a", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E6b", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Deferred"}, "tail": {$: "Con", "head": {$: "host-health-body.Call", "name": "Fast", "mode": {$: "schedule.Observe"}}, "tail": {$: "Nil"}}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E6-empty1", "snapshot": false, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E6-empty2", "snapshot": false, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E6-empty3", "snapshot": false, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E6-skip", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Call", "name": "B", "mode": {$: "schedule.Observe"}}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": false, "name": "E6b", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": true, "tracked": false, "name": "E6b", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E7-fail", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Call", "name": "SetOn", "mode": {$: "schedule.Normal"}}, "tail": {$: "Con", "head": {$: "host-health-body.Transition"}, "tail": {$: "Con", "head": {$: "host-health-body.Nested", "operations": {$: "Con", "head": {$: "host-health-body.Call", "name": "B", "mode": {$: "schedule.ObserveFail"}}, "tail": {$: "Con", "head": {$: "host-health-body.Call", "name": "TailInner", "mode": {$: "schedule.Normal"}}, "tail": {$: "Nil"}}}}, "tail": {$: "Con", "head": {$: "host-health-body.Call", "name": "TailOuter", "mode": {$: "schedule.Normal"}}, "tail": {$: "Nil"}}}}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E7-retry", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Nested", "operations": {$: "Con", "head": {$: "host-health-body.Call", "name": "B", "mode": {$: "schedule.Observe"}}, "tail": {$: "Con", "head": {$: "host-health-body.Call", "name": "TailInner", "mode": {$: "schedule.Normal"}}, "tail": {$: "Nil"}}}}, "tail": {$: "Con", "head": {$: "host-health-body.Call", "name": "TailOuter", "mode": {$: "schedule.Normal"}}, "tail": {$: "Con", "head": {$: "host-health-body.Call", "name": "Fast", "mode": {$: "schedule.Observe"}}, "tail": {$: "Nil"}}}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E8-pending", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Call", "name": "Inserts", "mode": {$: "schedule.Normal"}}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": false, "name": "E8-before-D", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": true, "tracked": false, "name": "E8-before-D", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E8", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Deferred"}, "tail": {$: "Con", "head": {$: "host-health-body.Call", "name": "Fast", "mode": {$: "schedule.Observe"}}, "tail": {$: "Con", "head": {$: "host-health-body.Call", "name": "B", "mode": {$: "schedule.Observe"}}, "tail": {$: "Nil"}}}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": false, "name": "E8", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": true, "tracked": false, "name": "E8", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E9-pending", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Call", "name": "Dispose", "mode": {$: "schedule.Normal"}}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": false, "name": "E9-before-D", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": true, "tracked": false, "name": "E9-before-D", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E9", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Deferred"}, "tail": {$: "Con", "head": {$: "host-health-body.Call", "name": "Fast", "mode": {$: "schedule.Observe"}}, "tail": {$: "Con", "head": {$: "host-health-body.Call", "name": "B", "mode": {$: "schedule.Observe"}}, "tail": {$: "Nil"}}}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": false, "name": "E9-empty", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": true, "tracked": false, "name": "E9-empty", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E9-empty-D", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Deferred"}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E9-spawn-s", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Call", "name": "SpawnS", "mode": {$: "schedule.Normal"}}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": false, "name": "E9-s-pending", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": true, "tracked": false, "name": "E9-s-pending", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": true, "name": "E9-s-live", "snapshot": false, "operations": {$: "Con", "head": {$: "host-health-body.Deferred"}, "tail": {$: "Nil"}}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": false, "tracked": false, "name": "E9-s", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Con", "head": {$: "host-health-body.Frame", "beta": true, "tracked": false, "name": "E9-s", "snapshot": true, "operations": {$: "Nil"}}, "tail": {$: "Nil"}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}};
}

function $host$045health$045body$058health_finish_main$(_lane_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($host$045health$045body$058health_e10$("resource", _lane_0)), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$bind$(($host$045health$045body$058health_e10$("service", _x_1)), run_clo((_x_3) => {
  return $host$045health$045body$058health_emit$(_x_3);
}), _x_2);
});
}), _x_0);
});
}

function $host$045health$045body$058health_created_alpha$(_style_0, _result_0) {
  if (_result_0.$ === "types.CreateRejected") {
    return {$: "None"};
  } else {
    const _factory_0 = _result_0["factory"];
    const _alpha_0 = _result_0["world"];
    return $host$045health$045body$058health_created_beta$(_alpha_0, _style_0, ($identity$058create$1260$(_factory_0, {$: "types.HealthOn"})));
  }
}

function $identity$058create$1260$(_factory_0, _mode_0) {
  const _namespace_0 = _factory_0["next"];
  return $identity$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _mode_0);
}

function $identity$058factory$() {
  return {$: "storage.Factory", "next": 1};
}

function $host$045health$045body$058health_choose_foreign$(_isForeign_0, _beta_0, _tracked_0, _name_0, _snapshot_0, _ops_0, _lane_0) {
  if (_isForeign_0) {
    return $host$045health$045body$058health_choose$(_beta_0, _tracked_0, _name_0, _snapshot_0, _ops_0, ($host$045health$045body$058health_foreign_prepare$(_beta_0, _lane_0)));
  } else {
    return $host$045health$045body$058health_choose$(_beta_0, _tracked_0, _name_0, _snapshot_0, _ops_0, _lane_0);
  }
}

function $String$eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(($String$order$(_a_0, _b_0)));
}

function $host$045health$045body$058health_e10$(_missing_0, _lane_0) {
  const _t_0 = _lane_0["alpha"];
  const _owner_0 = _t_0["world"];
  const _registry_0 = _t_0["registry"];
  const _readers_0 = _t_0["readers"];
  const _clock_0 = _t_0["clock"];
  const _audit_0 = _t_0["audit"];
  const _style_0 = _t_0["style"];
  const _escaped_0 = _t_0["escaped"];
  const _observations_0 = _t_0["observations"];
  const _nextMode_0 = _t_0["nextMode"];
  const _beta_0 = _lane_0["beta"];
  const _systems_0 = _lane_0["systems"];
  const _events_0 = _lane_0["events"];
  return $host$045health$045body$058health_e10_fresh$(_missing_0, {$: "host-health-body.HealthLane", "alpha": {$: "dispatcher.Runtime", "world": _owner_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0}, "beta": _beta_0, "systems": _systems_0, "events": _events_0}, ($host$045health$045body$058health_initial$(_style_0)));
}

function $host$045health$045body$058health_emit$(_lane_0) {
  const _events_0 = _lane_0["events"];
  return (_x_0) => $IO$print$(($host$045render$058render_list$12616$(_events_0)), _x_0);
}

function $host$045health$045body$058health_created_beta$(_alpha_0, _style_0, _result_0) {
  if (_result_0.$ === "types.CreateRejected") {
    return {$: "None"};
  } else {
    const _beta_0 = _result_0["world"];
    return {$: "Some", "value": ($host$045health$045body$058health_setup_alpha$(_beta_0, _style_0, _alpha_0, run_loop($host$045health$045body$058setup$(($host$045health$045body$058definitions$()), ($schedule$058initial$()), {$: "Nil"}))))};
  }
}

function $identity$058create_checked$1260$(_available_0, _namespace_0, _mode_0) {
  if (!_available_0) {
    return {$: "types.CreateRejected", "factory": {$: "storage.Factory", "next": _namespace_0}};
  } else {
    return {$: "types.Created", "factory": {$: "storage.Factory", "next": ((_namespace_0 + 1) >>> 0)}, "world": {$: "storage.World", "namespace": _namespace_0, "next": 1, "rows": ($storage$058rows_empty$()), "pending": {$: "Nil"}, "ledger": {$: "Some", "value": ($host$045health$045body$058health_ledger$({$: "Unit"}))}, "mode": _mode_0}};
  }
}

function $host$045health$045body$058health_choose$(_beta_0, _tracked_0, _name_0, _snapshot_0, _ops_0, _lane_0) {
  if (!_beta_0) {
    const _alpha_0 = _lane_0["alpha"];
    const _beta_1 = _lane_0["beta"];
    const _systems_0 = _lane_0["systems"];
    const _events_0 = _lane_0["events"];
    return run_clo((_x_0) => {
  return $IO$bind$(($host$045health$045body$058health_frame$(_snapshot_0, _tracked_0, _name_0, ($host$045health$045body$058nodes$(_systems_0, _ops_0)), _alpha_0)), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$pure$(($host$045health$045body$058health_collect$(false, _beta_1, _systems_0, _events_0, _x_1)), _x_2);
});
}), _x_0);
});
  } else {
    const _alpha_1 = _lane_0["alpha"];
    const _beta_2 = _lane_0["beta"];
    const _systems_1 = _lane_0["systems"];
    const _events_1 = _lane_0["events"];
    return run_clo((_x_3) => {
  return $IO$bind$(($host$045health$045body$058health_frame$(_snapshot_0, _tracked_0, _name_0, ($host$045health$045body$058nodes$(_systems_1, _ops_0)), _beta_2)), run_clo((_x_4) => {
  return run_clo((_x_5) => {
  return $IO$pure$(($host$045health$045body$058health_collect$(true, _alpha_1, _systems_1, _events_1, _x_4)), _x_5);
});
}), _x_3);
});
  }
}

function $host$045health$045body$058health_foreign_prepare$(_beta_0, _lane_0) {
  if (!_beta_0) {
    const _alpha_0 = _lane_0["alpha"];
    const _t_0 = _lane_0["beta"];
    const _t_1 = _t_0["world"];
    const _world_0 = _t_1["world"];
    const _logs_0 = _t_1["logs"];
    const _bindings_0 = _t_1["bindings"];
    const _worldName_0 = _t_1["worldName"];
    const _step_0 = _t_1["step"];
    const _prior_0 = _t_1["prior"];
    const _produced_0 = _t_1["events"];
    const _registry_0 = _t_0["registry"];
    const _readers_0 = _t_0["readers"];
    const _clock_0 = _t_0["clock"];
    const _audit_0 = _t_0["audit"];
    const _style_0 = _t_0["style"];
    const _escaped_0 = _t_0["escaped"];
    const _observations_0 = _t_0["observations"];
    const _nextMode_0 = _t_0["nextMode"];
    const _systems_0 = _lane_0["systems"];
    const _events_0 = _lane_0["events"];
    return {$: "host-health-body.HealthLane", "alpha": ($host$045health$045body$058health_foreign_put$("z", ($host$058binding_find$("z", _bindings_0)), _alpha_0)), "beta": {$: "dispatcher.Runtime", "world": {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _produced_0}, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0}, "systems": _systems_0, "events": _events_0};
  } else {
    const _t_2 = _lane_0["alpha"];
    const _t_3 = _t_2["world"];
    const _world_1 = _t_3["world"];
    const _logs_1 = _t_3["logs"];
    const _bindings_1 = _t_3["bindings"];
    const _worldName_1 = _t_3["worldName"];
    const _step_1 = _t_3["step"];
    const _prior_1 = _t_3["prior"];
    const _produced_1 = _t_3["events"];
    const _registry_1 = _t_2["registry"];
    const _readers_1 = _t_2["readers"];
    const _clock_1 = _t_2["clock"];
    const _audit_1 = _t_2["audit"];
    const _style_1 = _t_2["style"];
    const _escaped_1 = _t_2["escaped"];
    const _observations_1 = _t_2["observations"];
    const _nextMode_1 = _t_2["nextMode"];
    const _beta_1 = _lane_0["beta"];
    const _systems_1 = _lane_0["systems"];
    const _events_1 = _lane_0["events"];
    return {$: "host-health-body.HealthLane", "alpha": {$: "dispatcher.Runtime", "world": {$: "host.Host", "world": _world_1, "logs": _logs_1, "bindings": _bindings_1, "worldName": _worldName_1, "step": _step_1, "prior": _prior_1, "events": _produced_1}, "registry": _registry_1, "readers": _readers_1, "clock": _clock_1, "audit": _audit_1, "style": _style_1, "escaped": _escaped_1, "observations": _observations_1, "nextMode": _nextMode_1}, "beta": ($host$045health$045body$058health_foreign_put$("a", ($host$058binding_find$("a", _bindings_1)), _beta_1)), "systems": _systems_1, "events": _events_1};
  }
}

function $Cmp$is_eq$(_c_0) {
  if (_c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $String$order$(_a_0, _b_0) {
  return $Pair$snd$(($String$cmp$(_a_0, _b_0)));
}

function $host$045health$045body$058health_e10_fresh$(_missing_0, _lane_0, _fresh_0) {
  const _t_0 = _lane_0["alpha"];
  const _owner_0 = _t_0["world"];
  const _registry_0 = _t_0["registry"];
  const _readers_0 = _t_0["readers"];
  const _clock_0 = _t_0["clock"];
  const _audit_0 = _t_0["audit"];
  const _style_0 = _t_0["style"];
  const _escaped_0 = _t_0["escaped"];
  const _observations_0 = _t_0["observations"];
  const _nextMode_0 = _t_0["nextMode"];
  const _beta_0 = _lane_0["beta"];
  const _systems_0 = _lane_0["systems"];
  const _events_0 = _lane_0["events"];
  if (_fresh_0.$ === "Some") {
    const _t_1 = _fresh_0["value"];
    const _fresh_1 = _t_1["alpha"];
    return $host$045health$045body$058health_e10_exchange$(_missing_0, ($host$045health$045body$058health_fresh_remove$(($String$eq$(_missing_0, "resource")), _fresh_1)), _owner_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _beta_0, _systems_0, _events_0, ($host$045health$045body$058seen$(_registry_0)));
  } else {
    return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $IO$print$("SETUP-REJECTED:E10", _x_1), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $IO$pure$({$: "host-health-body.HealthLane", "alpha": {$: "dispatcher.Runtime", "world": _owner_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0}, "beta": _beta_0, "systems": _systems_0, "events": _events_0}, _x_3);
});
}), _x_0);
});
  }
}

function $host$045render$058render_list$12616$(_values_0) {
  return $host$045render$058render_concat$({$: "Con", "head": "[", "tail": {$: "Con", "head": ($host$045render$058render_concat$(($host$045render$058render_list_tail$12616$(_values_0, {$: "Nil"}, true)))), "tail": {$: "Con", "head": "]", "tail": {$: "Nil"}}}});
}

function $host$045health$045body$058health_setup_alpha$(_betaWorld_0, _style_0, _world_0, _result_0) {
  const _registry_0 = _result_0["registry"];
  const _systems_0 = _result_0["systems"];
  return $host$045health$045body$058health_setup_beta$({$: "dispatcher.Runtime", "world": ($host$058initial$("alpha", _world_0, 65536)), "registry": _registry_0, "readers": ($readers$058initial$()), "clock": ($readers$058clock$()), "audit": {$: "Some", "value": {$: "dispatcher.Console"}}, "style": _style_0, "escaped": {$: "Nil"}, "observations": {$: "Nil"}, "nextMode": {$: "None"}}, _betaWorld_0, _style_0, _systems_0, run_loop($host$045health$045body$058setup$(($host$045health$045body$058definitions$()), ($schedule$058initial$()), {$: "Nil"})));
}

function $host$045health$045body$058setup$(_defs_0, _registry_0, _systems_0) {
  if (_defs_0.$ === "Nil") {
    return {$: "host-health-body.Setup", "registry": _registry_0, "systems": _systems_0};
  } else {
    const _t_0 = _defs_0["head"];
    const _name_0 = _t_0["name"];
    const _kind_0 = _t_0["kind"];
    const _ledger_0 = _t_0["ledger"];
    const _audit_0 = _t_0["audit"];
    const _gated_0 = _t_0["gated"];
    const _reader_0 = _t_0["reader"];
    const _tail_0 = _defs_0["tail"];
    return $host$045health$045body$058setup_next$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $host$045health$045body$058setup$(_tail_0, _x_0, _x_1);
});
}), _systems_0, ($schedule$058register$(_registry_0, _name_0, _kind_0, _ledger_0, _audit_0, _gated_0, _reader_0)));
  }
}

function $host$045health$045body$058definitions$() {
  return {$: "Con", "head": {$: "host-health-body.Definition", "name": "ForeignLookup", "kind": {$: "schedule.ForeignLookup"}, "ledger": false, "audit": false, "gated": false, "reader": false}, "tail": {$: "Con", "head": {$: "host-health-body.Definition", "name": "A", "kind": {$: "schedule.A"}, "ledger": true, "audit": true, "gated": false, "reader": false}, "tail": {$: "Con", "head": {$: "host-health-body.Definition", "name": "B", "kind": {$: "schedule.B"}, "ledger": true, "audit": true, "gated": true, "reader": true}, "tail": {$: "Con", "head": {$: "host-health-body.Definition", "name": "Fast", "kind": {$: "schedule.Fast"}, "ledger": false, "audit": false, "gated": false, "reader": true}, "tail": {$: "Con", "head": {$: "host-health-body.Definition", "name": "TailInner", "kind": {$: "schedule.Tail"}, "ledger": false, "audit": false, "gated": false, "reader": false}, "tail": {$: "Con", "head": {$: "host-health-body.Definition", "name": "TailOuter", "kind": {$: "schedule.Tail"}, "ledger": false, "audit": false, "gated": false, "reader": false}, "tail": {$: "Con", "head": {$: "host-health-body.Definition", "name": "SeedAlpha", "kind": {$: "schedule.Seed"}, "ledger": false, "audit": false, "gated": false, "reader": false}, "tail": {$: "Con", "head": {$: "host-health-body.Definition", "name": "SeedBeta", "kind": {$: "schedule.SeedBeta"}, "ledger": false, "audit": false, "gated": false, "reader": false}, "tail": {$: "Con", "head": {$: "host-health-body.Definition", "name": "SetOn", "kind": {$: "schedule.SetOn"}, "ledger": false, "audit": false, "gated": false, "reader": false}, "tail": {$: "Con", "head": {$: "host-health-body.Definition", "name": "SetOff", "kind": {$: "schedule.SetOff"}, "ledger": false, "audit": false, "gated": false, "reader": false}, "tail": {$: "Con", "head": {$: "host-health-body.Definition", "name": "Cleanup", "kind": {$: "schedule.Cleanup"}, "ledger": false, "audit": false, "gated": false, "reader": false}, "tail": {$: "Con", "head": {$: "host-health-body.Definition", "name": "Inserts", "kind": {$: "schedule.Inserts"}, "ledger": false, "audit": false, "gated": false, "reader": false}, "tail": {$: "Con", "head": {$: "host-health-body.Definition", "name": "Dispose", "kind": {$: "schedule.Dispose"}, "ledger": false, "audit": false, "gated": false, "reader": false}, "tail": {$: "Con", "head": {$: "host-health-body.Definition", "name": "SpawnS", "kind": {$: "schedule.SpawnS"}, "ledger": false, "audit": false, "gated": false, "reader": false}, "tail": {$: "Nil"}}}}}}}}}}}}}}};
}

function $schedule$058initial$() {
  return {$: "schedule.Registry", "next": 1, "entries": {$: "Nil"}};
}

function $storage$058rows_empty$() {
  return {$: "storage.Rows", "main": [{$: "None"}], "aux": [{$: "None"}], "metadata": ($storage$058metadata_empty$(0)), "capacity": 1, "depth": 0, "high_water": 0};
}

function $host$045health$045body$058health_ledger$(_unit_0) {
  return $cached$045payload$058health_ledger_new$({$: "types.HealthLedger", "totals": ($systems$058quad$(100, 101, 102, 103)), "epoch": 4});
}

function $host$045health$045body$058health_frame$(_snapshot_0, _tracked_0, _name_0, _steps_0, _runtime_0) {
  if (!_snapshot_0) {
    return $host$058prototype_slot_host_health_dispatch$(_tracked_0, _name_0, _steps_0, _runtime_0);
  } else {
    const _owner_0 = _runtime_0["world"];
    const _registry_0 = _runtime_0["registry"];
    const _readers_0 = _runtime_0["readers"];
    const _clock_0 = _runtime_0["clock"];
    const _audit_0 = _runtime_0["audit"];
    const _style_0 = _runtime_0["style"];
    const _escaped_0 = _runtime_0["escaped"];
    const _observations_0 = _runtime_0["observations"];
    const _nextMode_0 = _runtime_0["nextMode"];
    return $host$045health$045body$058health_snapshot_registered$(_tracked_0, _name_0, _owner_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($schedule$058register$(_registry_0, "Snapshot", {$: "schedule.Snapshot"}, true, false, false, false)));
  }
}

function $host$045health$045body$058nodes$(_systems_0, _ops_0) {
  if (_ops_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _ops_0["head"];
    if (_t_0.$ === "host-health-body.Call") {
      const _name_0 = _t_0["name"];
      const _mode_0 = _t_0["mode"];
      const _tail_0 = _ops_0["tail"];
      return $host$045health$045body$058node_call$(_mode_0, ($host$045health$045body$058by_name$(_name_0, _systems_0)), ($host$045health$045body$058nodes$(_systems_0, _tail_0)));
    } else if (_t_0.$ === "host-health-body.Nested") {
      const _nested_0 = _t_0["operations"];
      const _tail_1 = _ops_0["tail"];
      return {$: "Con", "head": {$: "schedule.Nested", "steps": ($host$045health$045body$058nodes$(_systems_0, _nested_0))}, "tail": ($host$045health$045body$058nodes$(_systems_0, _tail_1))};
    } else if (_t_0.$ === "host-health-body.Deferred") {
      const _tail_2 = _ops_0["tail"];
      return {$: "Con", "head": {$: "schedule.Deferred"}, "tail": ($host$045health$045body$058nodes$(_systems_0, _tail_2))};
    } else {
      const _tail_3 = _ops_0["tail"];
      return {$: "Con", "head": {$: "schedule.StateTransition"}, "tail": ($host$045health$045body$058nodes$(_systems_0, _tail_3))};
    }
  }
}

function $host$045health$045body$058health_collect$(_beta_0, _other_0, _systems_0, _events_0, _result_0) {
  const _t_0 = _result_0["runtime"];
  const _t_1 = _t_0["world"];
  const _world_0 = _t_1["world"];
  const _logs_0 = _t_1["logs"];
  const _bindings_0 = _t_1["bindings"];
  const _worldName_0 = _t_1["worldName"];
  const _step_0 = _t_1["step"];
  const _prior_0 = _t_1["prior"];
  const _produced_0 = _t_1["events"];
  const _registry_0 = _t_0["registry"];
  const _readers_0 = _t_0["readers"];
  const _clock_0 = _t_0["clock"];
  const _audit_0 = _t_0["audit"];
  const _style_0 = _t_0["style"];
  const _escaped_0 = _t_0["escaped"];
  const _observations_0 = _t_0["observations"];
  const _nextMode_0 = _t_0["nextMode"];
  return $host$045health$045body$058health_collected$(_beta_0, _other_0, _systems_0, ($List$append$(_events_0, _produced_0)), {$: "dispatcher.Runtime", "world": {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": {$: "Nil"}}, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0});
}

function $host$045health$045body$058health_foreign_put$(_label_0, _found_0, _runtime_0) {
  if (_found_0.$ === "Some") {
    const _handle_0 = _found_0["value"];
    const _t_0 = _runtime_0["world"];
    const _world_0 = _t_0["world"];
    const _logs_0 = _t_0["logs"];
    const _bindings_0 = _t_0["bindings"];
    const _worldName_0 = _t_0["worldName"];
    const _step_0 = _t_0["step"];
    const _prior_0 = _t_0["prior"];
    const _events_0 = _t_0["events"];
    const _registry_0 = _runtime_0["registry"];
    const _readers_0 = _runtime_0["readers"];
    const _clock_0 = _runtime_0["clock"];
    const _audit_0 = _runtime_0["audit"];
    const _style_0 = _runtime_0["style"];
    const _escaped_0 = _runtime_0["escaped"];
    const _observations_0 = _runtime_0["observations"];
    const _nextMode_0 = _runtime_0["nextMode"];
    return {$: "dispatcher.Runtime", "world": {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": {$: "Con", "head": {$: "host-observations.Binding", "label": _label_0, "handle": _handle_0}, "tail": _bindings_0}, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0};
  } else {
    return _runtime_0;
  }
}

function $host$058binding_find$(_name_0, _values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _values_0["head"];
    const _label_0 = _t_0["label"];
    const _handle_0 = _t_0["handle"];
    const _tail_0 = _values_0["tail"];
    return $host$058binding_hit$(($String$eq$(_name_0, _label_0)), _handle_0, ($host$058binding_find$(_name_0, _tail_0)));
  }
}

function $Pair$snd$(_p_0) {
  const _b_0 = _p_0["snd"];
  return _b_0;
}

function $String$cmp$(_a_0, _b_0) {
  if (_a_0 === "") {
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": ""}, "snd": {$: "EQ"}};
    } else {
      const _h_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": (_h_0 + _t_0)}, "snd": {$: "LT"}};
    }
  } else {
    const _h_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
    const _t_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h_1 + _t_1), "snd": ""}, "snd": {$: "GT"}};
    } else {
      const _h2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return $String$cmp$fin$(_t_1, _t2_0, ($Char$cmp$(_h_1, _h2_0)));
    }
  }
}

function $host$045health$045body$058health_e10_exchange$(_missing_0, _fresh_0, _owner_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _beta_0, _systems_0, _events_0, _result_0) {
  const _registry_0 = _result_0["registry"];
  const _oldSystems_0 = _result_0["systems"];
  const _oldCounts_0 = _result_0["counts"];
  return run_clo((_x_0) => {
  return $IO$bind$(($host$045preflight$058health_exchange$(_missing_0, ($host$045health$045body$058nodes$(_systems_0, ($host$045health$045body$058preflight_operations$()))), {$: "dispatcher.Runtime", "world": _owner_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0}, _fresh_0)), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$pure$(($host$045health$045body$058health_e10_return$(_missing_0, _oldSystems_0, _oldCounts_0, _beta_0, _systems_0, _events_0, _x_1)), _x_2);
});
}), _x_0);
});
}

function $host$045health$045body$058health_fresh_remove$(_isResource_0, _runtime_0) {
  if (_isResource_0) {
    return $host$045preflight$058health_without_ledger$(_runtime_0);
  } else {
    return $host$045preflight$058health_without_audit$(_runtime_0);
  }
}

function $host$045health$045body$058seen$(_registry_0) {
  return $host$045health$045body$058seen_values$(($dispatcher$058registry_values$(_registry_0)));
}

function $host$045render$058render_concat$(_values_0) {
  return $host$045render$058render_chunks$(_values_0, "");
}

function $host$045render$058render_list_tail$12616$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($host$045render$058render_list_piece$(($host$045render$058render_health$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $host$045health$045body$058health_setup_beta$(_alpha_0, _world_0, _style_0, _systems_0, _result_0) {
  const _registry_0 = _result_0["registry"];
  return {$: "host-health-body.HealthLane", "alpha": _alpha_0, "beta": {$: "dispatcher.Runtime", "world": ($host$058initial$("beta", _world_0, 65536)), "registry": _registry_0, "readers": ($readers$058initial$()), "clock": ($readers$058clock$()), "audit": {$: "Some", "value": {$: "dispatcher.Console"}}, "style": _style_0, "escaped": {$: "Nil"}, "observations": {$: "Nil"}, "nextMode": {$: "None"}}, "systems": _systems_0, "events": {$: "Nil"}};
}

function $host$058initial$(_worldName_0, _world_0, _capacity_0) {
  return {$: "host.Host", "world": _world_0, "logs": ($reader$045host$058initial$(_capacity_0)), "bindings": {$: "Nil"}, "worldName": _worldName_0, "step": "", "prior": {$: "dispatcher.Complete"}, "events": {$: "Nil"}};
}

function $readers$058initial$() {
  return {$: "readers.Readers", "slots": {$: "Nil"}};
}

function $readers$058clock$() {
  return {$: "readers.Clock", "tick": 0, "frameStart": 0, "retainedAfter": 0, "frameNo": 0};
}

function $host$045health$045body$058setup_next$(_next_0, _systems_0, _registered_0) {
  const _registry_0 = _registered_0["registry"];
  const _system_0 = _registered_0["system"];
  return run_tail(_next_0(_registry_0), {$: "Con", "head": _system_0, "tail": _systems_0});
}

function $schedule$058register$(_registry_0, _name_0, _kind_0, _ledger_0, _audit_0, _gated_0, _reader_0) {
  const _next_0 = _registry_0["next"];
  const _entries_0 = _registry_0["entries"];
  const _system_0 = {$: "schedule.System", "base": _next_0, "name": _name_0, "kind": _kind_0, "ledger": _ledger_0, "audit": _audit_0, "gated": _gated_0, "reader": _reader_0};
  return {$: "schedule.Registered", "registry": {$: "schedule.Registry", "next": ((_next_0 + 1) >>> 0), "entries": {$: "Con", "head": {$: "schedule.Entry", "system": _system_0, "local": ($capture$058initial$())}, "tail": _entries_0}}, "system": _system_0};
}

function $storage$058metadata_empty$(_depth_0) {
  const _x_0 = {$: "None"};
  return {$: "storage.MetadataColumns", "live": array_new(_depth_0, false), "flags": array_new(_depth_0, _x_0), "added": array_new(_depth_0, 0), "changed": array_new(_depth_0, 0)};
}

function $cached$045payload$058health_ledger_new$(_raw_0) {
  return $cache$058static_init$1263$(_raw_0);
}

function $systems$058quad$(_a_0, _b_0, _c_0, _d_0) {
  const _x_0 = array_new(2, _a_0);
  const _x_1 = (_x_0[1 % _x_0.length] = _b_0, _x_0);
  const _x_2 = (_x_1[2 % _x_1.length] = _c_0, _x_1);
  return (_x_2[3 % _x_2.length] = _d_0, _x_2);
}

function $host$058prototype_slot_host_health_dispatch$(_tracked_0, _step_0, _nodes_0, _runtime_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($host$058prototype_slot_host_health_tick$(_nodes_0, ($host$058prototype_slot_host_health_label$(_step_0, _runtime_0)))), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$pure$(($host$058dispatched$(_tracked_0, _x_1)), _x_2);
});
}), _x_0);
});
}

function $host$045health$045body$058health_snapshot_registered$(_tracked_0, _name_0, _owner_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _registration_0) {
  const _registry_0 = _registration_0["registry"];
  const _system_0 = _registration_0["system"];
  return $host$058prototype_slot_host_health_dispatch$(_tracked_0, _name_0, {$: "Con", "head": {$: "schedule.Call", "system": _system_0, "mode": {$: "schedule.Normal"}}, "tail": {$: "Nil"}}, {$: "dispatcher.Runtime", "world": _owner_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0});
}

function $host$045health$045body$058node_call$(_mode_0, _found_0, _tail_0) {
  if (_found_0.$ === "Some") {
    const _system_0 = _found_0["value"];
    return {$: "Con", "head": {$: "schedule.Call", "system": _system_0, "mode": _mode_0}, "tail": _tail_0};
  } else {
    return {$: "Con", "head": {$: "schedule.Call", "system": {$: "schedule.System", "base": 4294967295, "name": "Unknown", "kind": {$: "schedule.Tail"}, "ledger": false, "audit": false, "gated": false, "reader": false}, "mode": _mode_0}, "tail": _tail_0};
  }
}

function $host$045health$045body$058by_name$(_name_0, _systems_0) {
  if (_systems_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _systems_0["head"];
    const _base_0 = _t_0["base"];
    const _label_0 = _t_0["name"];
    const _kind_0 = _t_0["kind"];
    const _ledger_0 = _t_0["ledger"];
    const _audit_0 = _t_0["audit"];
    const _gated_0 = _t_0["gated"];
    const _reader_0 = _t_0["reader"];
    const _tail_0 = _systems_0["tail"];
    return $host$045health$045body$058by_name_case$(($String$eq$(_name_0, _label_0)), {$: "schedule.System", "base": _base_0, "name": _label_0, "kind": _kind_0, "ledger": _ledger_0, "audit": _audit_0, "gated": _gated_0, "reader": _reader_0}, ($host$045health$045body$058by_name$(_name_0, _tail_0)));
  }
}

function $host$045health$045body$058health_collected$(_beta_0, _other_0, _systems_0, _events_0, _runtime_0) {
  if (_beta_0) {
    return {$: "host-health-body.HealthLane", "alpha": _other_0, "beta": _runtime_0, "systems": _systems_0, "events": _events_0};
  } else {
    return {$: "host-health-body.HealthLane", "alpha": _runtime_0, "beta": _other_0, "systems": _systems_0, "events": _events_0};
  }
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $host$058binding_hit$(_hit_0, _handle_0, _tail_0) {
  if (_hit_0) {
    return {$: "Some", "value": _handle_0};
  } else {
    return _tail_0;
  }
}

function $String$cmp$fin$(_t1_0, _t2_0, _hc_0) {
  const _t_0 = _hc_0["fst"];
  const _h1b_0 = _t_0["fst"];
  const _h2b_0 = _t_0["snd"];
  const _t_1 = _hc_0["snd"];
  if (_t_1.$ === "LT") {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "LT"}};
  } else if (_t_1.$ === "EQ") {
    return $String$cmp$rec$(_h1b_0, _h2b_0, ($String$cmp$(_t1_0, _t2_0)));
  } else {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "GT"}};
  }
}

function $Char$cmp$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _a_0, "snd": _b_0}, "snd": cmp_new(_x_0, _x_1)};
}

function $host$045preflight$058health_exchange$(_label_0, _nodes_0, _original_0, _fresh_0) {
  const _owner_0 = _original_0["world"];
  const _registry_0 = _original_0["registry"];
  const _readers_0 = _original_0["readers"];
  const _clock_0 = _original_0["clock"];
  const _audit_0 = _original_0["audit"];
  const _style_0 = _original_0["style"];
  const _escaped_0 = _original_0["escaped"];
  const _observations_0 = _original_0["observations"];
  const _nextMode_0 = _original_0["nextMode"];
  const _freshOwner_0 = _fresh_0["world"];
  const _unused_0 = _fresh_0["registry"];
  const _freshReaders_0 = _fresh_0["readers"];
  const _freshClock_0 = _fresh_0["clock"];
  const _freshAudit_0 = _fresh_0["audit"];
  const _freshStyle_0 = _fresh_0["style"];
  const _freshEscaped_0 = _fresh_0["escaped"];
  const _freshObservations_0 = _fresh_0["observations"];
  const _freshNextMode_0 = _fresh_0["nextMode"];
  return run_clo((_x_0) => {
  return $IO$bind$(($host$045preflight$058health_probe$(_label_0, _nodes_0, {$: "dispatcher.Runtime", "world": _freshOwner_0, "registry": _registry_0, "readers": _freshReaders_0, "clock": _freshClock_0, "audit": _freshAudit_0, "style": _freshStyle_0, "escaped": _freshEscaped_0, "observations": _freshObservations_0, "nextMode": _freshNextMode_0})), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$pure$(($host$045preflight$058health_exchange_done$({$: "dispatcher.Runtime", "world": _owner_0, "registry": _unused_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0}, _x_1)), _x_2);
});
}), _x_0);
});
}

function $host$045health$045body$058preflight_operations$() {
  return {$: "Con", "head": {$: "host-health-body.Call", "name": "A", "mode": {$: "schedule.Normal"}}, "tail": {$: "Con", "head": {$: "host-health-body.Call", "name": "Fast", "mode": {$: "schedule.Observe"}}, "tail": {$: "Con", "head": {$: "host-health-body.Nested", "operations": {$: "Con", "head": {$: "host-health-body.Call", "name": "B", "mode": {$: "schedule.BFail"}}, "tail": {$: "Con", "head": {$: "host-health-body.Call", "name": "TailInner", "mode": {$: "schedule.Normal"}}, "tail": {$: "Nil"}}}}, "tail": {$: "Con", "head": {$: "host-health-body.Call", "name": "TailOuter", "mode": {$: "schedule.Normal"}}, "tail": {$: "Nil"}}}}};
}

function $host$045health$045body$058health_e10_return$(_missing_0, _oldSystems_0, _oldCounts_0, _beta_0, _systems_0, _events_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _owner_0 = _t_0["world"];
  const _registry_0 = _t_0["registry"];
  const _readers_0 = _t_0["readers"];
  const _clock_0 = _t_0["clock"];
  const _audit_0 = _t_0["audit"];
  const _style_0 = _t_0["style"];
  const _escaped_0 = _t_0["escaped"];
  const _observations_0 = _t_0["observations"];
  const _nextMode_0 = _t_0["nextMode"];
  const _t_1 = _result_0["snd"];
  const _outcome_0 = _t_1["outcome"];
  return $host$045health$045body$058health_e10_record$(_missing_0, _oldSystems_0, _oldCounts_0, _outcome_0, _owner_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _beta_0, _systems_0, _events_0, ($host$045health$045body$058seen$(_registry_0)));
}

function $host$045preflight$058health_without_ledger$(_runtime_0) {
  const _t_0 = _runtime_0["world"];
  const _t_1 = _t_0["world"];
  const _ns_0 = _t_1["namespace"];
  const _next_0 = _t_1["next"];
  const _rows_0 = _t_1["rows"];
  const _pending_0 = _t_1["pending"];
  const _mode_0 = _t_1["mode"];
  const _logs_0 = _t_0["logs"];
  const _bindings_0 = _t_0["bindings"];
  const _name_0 = _t_0["worldName"];
  const _step_0 = _t_0["step"];
  const _prior_0 = _t_0["prior"];
  const _events_0 = _t_0["events"];
  const _registry_0 = _runtime_0["registry"];
  const _readers_0 = _runtime_0["readers"];
  const _clock_0 = _runtime_0["clock"];
  const _audit_0 = _runtime_0["audit"];
  const _sty_0 = _runtime_0["style"];
  const _escaped_0 = _runtime_0["escaped"];
  const _obs_0 = _runtime_0["observations"];
  const _desired_0 = _runtime_0["nextMode"];
  return {$: "dispatcher.Runtime", "world": {$: "host.Host", "world": {$: "storage.World", "namespace": _ns_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": {$: "None"}, "mode": _mode_0}, "logs": _logs_0, "bindings": _bindings_0, "worldName": _name_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _sty_0, "escaped": _escaped_0, "observations": _obs_0, "nextMode": _desired_0};
}

function $host$045preflight$058health_without_audit$(_runtime_0) {
  const _owner_0 = _runtime_0["world"];
  const _registry_0 = _runtime_0["registry"];
  const _readers_0 = _runtime_0["readers"];
  const _clock_0 = _runtime_0["clock"];
  const _sty_0 = _runtime_0["style"];
  const _escaped_0 = _runtime_0["escaped"];
  const _obs_0 = _runtime_0["observations"];
  const _desired_0 = _runtime_0["nextMode"];
  return {$: "dispatcher.Runtime", "world": _owner_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": {$: "None"}, "style": _sty_0, "escaped": _escaped_0, "observations": _obs_0, "nextMode": _desired_0};
}

function $host$045health$045body$058seen_values$(_result_0) {
  const _registry_0 = _result_0["fst"];
  const _systems_0 = _result_0["snd"];
  return $host$045health$045body$058seen_counts$(_systems_0, ($host$058count_registry$(_registry_0)));
}

function $dispatcher$058registry_values$(_registry_0) {
  const _next_0 = _registry_0["next"];
  const _entries_0 = _registry_0["entries"];
  return $dispatcher$058registry_return$(_next_0, ($dispatcher$058registry_entries$(_entries_0)));
}

function $host$045render$058render_chunks$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      if (_values_0.$ === "Nil") {
        return $String$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($host$045render$058render_push$(_head_0, _acc_0));
        continue;
      }
    }
  }
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $host$045render$058render_list_piece$(_value_0, _acc_0, _first_0) {
  if (_first_0) {
    return {$: "Con", "head": _value_0, "tail": _acc_0};
  } else {
    return {$: "Con", "head": _value_0, "tail": {$: "Con", "head": ",", "tail": _acc_0}};
  }
}

function $host$045render$058render_health$(_value_0) {
  return $host$045render$058render_event$1261$(_value_0);
}

function $reader$045host$058initial$(_capacity_0) {
  return {$: "reader-host.Logs", "ping": ($streams$058initial$(_capacity_0)), "removed": ($streams$058life_initial$(_capacity_0)), "despawned": ($streams$058life_initial$(_capacity_0))};
}

function $capture$058initial$() {
  return {$: "capture.Local", "count": array_new(2, 0)};
}

function $cache$058static_init$1263$(_raw_0) {
  return $cache$058static_init_done$(($uncached$045payload$058health_ledger_get$(_raw_0)));
}

function $host$058prototype_slot_host_health_tick$(_nodes_0, _runtime_0) {
  return $dispatcher$058tick$1263$(_nodes_0, "HealthLedger", "HealthMode", _runtime_0);
}

function $host$058prototype_slot_host_health_label$(_step_0, _runtime_0) {
  const _owner_0 = _runtime_0["world"];
  const _registry_0 = _runtime_0["registry"];
  const _readers_0 = _runtime_0["readers"];
  const _clock_0 = _runtime_0["clock"];
  const _audit_0 = _runtime_0["audit"];
  const _style_0 = _runtime_0["style"];
  const _escaped_0 = _runtime_0["escaped"];
  const _observations_0 = _runtime_0["observations"];
  const _nextMode_0 = _runtime_0["nextMode"];
  return {$: "dispatcher.Runtime", "world": ($host$058label$(_step_0, _owner_0)), "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0};
}

function $host$058dispatched$(_tracked_0, _result_0) {
  const _t_0 = _result_0["runtime"];
  const _t_1 = _t_0["world"];
  const _world_0 = _t_1["world"];
  const _logs_0 = _t_1["logs"];
  const _bindings_0 = _t_1["bindings"];
  const _worldName_0 = _t_1["worldName"];
  const _step_0 = _t_1["step"];
  const _events_0 = _t_1["events"];
  const _registry_0 = _t_0["registry"];
  const _readers_0 = _t_0["readers"];
  const _clock_0 = _t_0["clock"];
  const _audit_0 = _t_0["audit"];
  const _style_0 = _t_0["style"];
  const _escaped_0 = _t_0["escaped"];
  const _observations_0 = _t_0["observations"];
  const _nextMode_0 = _t_0["nextMode"];
  const _outcome_0 = _result_0["outcome"];
  return $host$058dispatched_counts$(_world_0, _logs_0, _bindings_0, _worldName_0, _step_0, _tracked_0, _events_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _outcome_0, ($host$058count_registry$(_registry_0)));
}

function $host$045health$045body$058by_name_case$(_found_0, _system_0, _tail_0) {
  if (_found_0) {
    return {$: "Some", "value": _system_0};
  } else {
    return _tail_0;
  }
}

function $String$cmp$rec$(_h1b_0, _h2b_0, _rr_0) {
  const _t_0 = _rr_0["fst"];
  const _t1b_0 = _t_0["fst"];
  const _t2b_0 = _t_0["snd"];
  const _r_0 = _rr_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1b_0), "snd": (_h2b_0 + _t2b_0)}, "snd": _r_0};
}

function $host$045preflight$058health_probe$(_label_0, _nodes_0, _runtime_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $IO$print$(("PREFLIGHT-BEGIN:health:" + _label_0), _x_1), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $IO$bind$(($host$045preflight$058health_tick$(_nodes_0, _runtime_0)), run_clo((_x_4) => {
  return $host$045preflight$058health_probe_done$(_label_0, _x_4);
}), _x_3);
});
}), _x_0);
});
}

function $host$045preflight$058health_exchange_done$(_original_0, _result_0) {
  const _owner_0 = _original_0["world"];
  const _unused_0 = _original_0["registry"];
  const _readers_0 = _original_0["readers"];
  const _clock_0 = _original_0["clock"];
  const _audit_0 = _original_0["audit"];
  const _style_0 = _original_0["style"];
  const _escaped_0 = _original_0["escaped"];
  const _observations_0 = _original_0["observations"];
  const _nextMode_0 = _original_0["nextMode"];
  const _t_0 = _result_0["runtime"];
  const _fresh_0 = _t_0["world"];
  const _registry_0 = _t_0["registry"];
  const _freshReaders_0 = _t_0["readers"];
  const _freshClock_0 = _t_0["clock"];
  const _freshAudit_0 = _t_0["audit"];
  const _freshStyle_0 = _t_0["style"];
  const _freshEscaped_0 = _t_0["escaped"];
  const _freshObservations_0 = _t_0["observations"];
  const _freshNextMode_0 = _t_0["nextMode"];
  const _outcome_0 = _result_0["outcome"];
  return {$: "Tuple", "fst": {$: "dispatcher.Runtime", "world": _owner_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0}, "snd": {$: "dispatcher.Dispatched", "runtime": {$: "dispatcher.Runtime", "world": _fresh_0, "registry": _unused_0, "readers": _freshReaders_0, "clock": _freshClock_0, "audit": _freshAudit_0, "style": _freshStyle_0, "escaped": _freshEscaped_0, "observations": _freshObservations_0, "nextMode": _freshNextMode_0}, "outcome": _outcome_0}};
}

function $host$045health$045body$058health_e10_record$(_missing_0, _oldSystems_0, _oldCounts_0, _outcome_0, _owner_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _beta_0, _systems_0, _events_0, _result_0) {
  const _registry_0 = _result_0["registry"];
  const _newSystems_0 = _result_0["systems"];
  const _newCounts_0 = _result_0["counts"];
  return {$: "host-health-body.HealthLane", "alpha": {$: "dispatcher.Runtime", "world": _owner_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0}, "beta": _beta_0, "systems": _systems_0, "events": ($List$append$(_events_0, {$: "Con", "head": {$: "host-observations.Provisioning", "missing": _missing_0, "result": _outcome_0, "invocations": {$: "Nil"}, "effects": {$: "Nil"}, "actualE2BaseInstances": ($Bool$and$(($host$045health$045body$058same_bases$(_oldSystems_0, _newSystems_0)), ($host$045health$045body$058same_counts$(_oldCounts_0, _newCounts_0))))}, "tail": {$: "Nil"}}))};
}

function $host$045health$045body$058seen_counts$(_systems_0, _result_0) {
  const _registry_0 = _result_0["fst"];
  const _counts_0 = _result_0["snd"];
  return {$: "host-health-body.Seen", "registry": _registry_0, "systems": _systems_0, "counts": _counts_0};
}

function $host$058count_registry$(_registry_0) {
  const _next_0 = _registry_0["next"];
  const _entries_0 = _registry_0["entries"];
  return $host$058count_registry_return$(_next_0, ($host$058count_entries$(_entries_0)));
}

function $dispatcher$058registry_return$(_next_0, _pair_0) {
  const _entries_0 = _pair_0["fst"];
  const _systems_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "schedule.Registry", "next": _next_0, "entries": _entries_0}, "snd": _systems_0};
}

function $dispatcher$058registry_entries$(_entries_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _system_0 = _t_0["system"];
    const _local_0 = _t_0["local"];
    const _tail_0 = _entries_0["tail"];
    return $dispatcher$058registry_join$(_system_0, _local_0, ($dispatcher$058registry_entries$(_tail_0)));
  }
}

function $String$reverse$(_s_0) {
  return $String$reverse$go$(_s_0, "");
}

function $host$045render$058render_push$($0, $1) {
  for (;;) {
    {
      const _value_0 = $0;
      const _acc_0 = $1;
      if (_value_0 === "") {
        return _acc_0;
      } else {
        const _head_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(0, 2) : _value_0[0]);
        const _tail_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(2) : _value_0.slice(1));
        $0 = _tail_0;
        $1 = (_head_0 + _acc_0);
        continue;
      }
    }
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $host$045render$058render_event$1261$(_value_0) {
  if (_value_0.$ === "host-observations.Provisioning") {
    const _missing_0 = _value_0["missing"];
    const _result_0 = _value_0["result"];
    const _invocations_0 = _value_0["invocations"];
    const _effects_0 = _value_0["effects"];
    const _actualE2BaseInstances_0 = _value_0["actualE2BaseInstances"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":\"Provisioning\",\"missing\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_missing_0)), "tail": {$: "Con", "head": ",\"result\":", "tail": {$: "Con", "head": ($host$045render$058render_dispatch_outcome$(_result_0)), "tail": {$: "Con", "head": ",\"invocations\":", "tail": {$: "Con", "head": ($host$045render$058render_list$1261$(_invocations_0)), "tail": {$: "Con", "head": ",\"effects\":", "tail": {$: "Con", "head": ($host$045render$058render_list$1261$(_effects_0)), "tail": {$: "Con", "head": ",\"actualE2BaseInstances\":", "tail": {$: "Con", "head": ($host$045render$058render_boolean$(_actualE2BaseInstances_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}}}}}});
  } else if (_value_0.$ === "host-observations.ForeignLookup") {
    const _step_0 = _value_0["step"];
    const _receiver_0 = _value_0["receiver"];
    const _source_0 = _value_0["source"];
    const _label_0 = _value_0["label"];
    const _handle_0 = _value_0["handle"];
    const _result_1 = _value_0["result"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":\"ForeignLookup\",\"step\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_step_0)), "tail": {$: "Con", "head": ",\"receiver\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_receiver_0)), "tail": {$: "Con", "head": ",\"source\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_source_0)), "tail": {$: "Con", "head": ",\"label\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_label_0)), "tail": {$: "Con", "head": ",\"handle\":", "tail": {$: "Con", "head": ($host$045render$058render_handle$(_handle_0)), "tail": {$: "Con", "head": ",\"result\":", "tail": {$: "Con", "head": ($host$045render$058render_access$1262$(_result_1)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}}}}}}}});
  } else if (_value_0.$ === "host-observations.Reserved") {
    const _step_1 = _value_0["step"];
    const _worldName_0 = _value_0["worldName"];
    const _label_1 = _value_0["label"];
    const _handle_1 = _value_0["handle"];
    const _components_0 = _value_0["components"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"Reserved\"", "tail": {$: "Con", "head": ",\"step\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_step_1)), "tail": {$: "Con", "head": ",\"worldName\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_worldName_0)), "tail": {$: "Con", "head": ",\"label\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_label_1)), "tail": {$: "Con", "head": ",\"handle\":", "tail": {$: "Con", "head": ($host$045render$058render_handle$(_handle_1)), "tail": {$: "Con", "head": ",\"components\":", "tail": {$: "Con", "head": ($host$045render$058render_bundle$1261$(_components_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}}}}}}}});
  } else if (_value_0.$ === "host-observations.Read") {
    const _step_2 = _value_0["step"];
    const _system_0 = _value_0["system"];
    const _count_0 = _value_0["count"];
    const _boundary_0 = _value_0["boundary"];
    const _query_0 = _value_0["query"];
    const _added_0 = _value_0["added"];
    const _changed_0 = _value_0["changed"];
    const _removed_0 = _value_0["removed"];
    const _despawned_0 = _value_0["despawned"];
    const _messages_0 = _value_0["messages"];
    const _messageLag_0 = _value_0["messageLag"];
    const _removedLag_0 = _value_0["removedLag"];
    const _despawnedLag_0 = _value_0["despawnedLag"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"Read\"", "tail": {$: "Con", "head": ",\"step\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_step_2)), "tail": {$: "Con", "head": ",\"system\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_system_0)), "tail": {$: "Con", "head": ",\"count\":", "tail": {$: "Con", "head": ($U32$show$(_count_0)), "tail": {$: "Con", "head": ",\"boundary\":", "tail": {$: "Con", "head": ($host$045render$058render_boundary$(_boundary_0)), "tail": {$: "Con", "head": ",\"query\":", "tail": {$: "Con", "head": ($host$045render$058render_list$12610$(_query_0)), "tail": {$: "Con", "head": ",\"added\":", "tail": {$: "Con", "head": ($host$045render$058render_list$12610$(_added_0)), "tail": {$: "Con", "head": ",\"changed\":", "tail": {$: "Con", "head": ($host$045render$058render_list$12610$(_changed_0)), "tail": {$: "Con", "head": ",\"removed\":", "tail": {$: "Con", "head": ($host$045render$058render_list$12611$(_removed_0)), "tail": {$: "Con", "head": ",\"despawned\":", "tail": {$: "Con", "head": ($host$045render$058render_list$12611$(_despawned_0)), "tail": {$: "Con", "head": ",\"messages\":", "tail": {$: "Con", "head": ($host$045render$058render_list$12612$(_messages_0)), "tail": {$: "Con", "head": ",\"messageLag\":", "tail": {$: "Con", "head": ($host$045render$058render_boolean$(_messageLag_0)), "tail": {$: "Con", "head": ",\"removedLag\":", "tail": {$: "Con", "head": ($host$045render$058render_boolean$(_removedLag_0)), "tail": {$: "Con", "head": ",\"despawnedLag\":", "tail": {$: "Con", "head": ($host$045render$058render_boolean$(_despawnedLag_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}}}}}}}}}}}}}}}}}}}}}}}});
  } else if (_value_0.$ === "host-observations.Snapshot") {
    const _step_3 = _value_0["step"];
    const _worldName_1 = _value_0["worldName"];
    const _prior_0 = _value_0["prior"];
    const _world_0 = _value_0["world"];
    const _query_1 = _value_0["query"];
    const _plus_0 = _value_0["plus"];
    const _minus_0 = _value_0["minus"];
    const _optional_0 = _value_0["optional"];
    const _lookups_0 = _value_0["lookups"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"Snapshot\"", "tail": {$: "Con", "head": ",\"step\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_step_3)), "tail": {$: "Con", "head": ",\"worldName\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_worldName_1)), "tail": {$: "Con", "head": ",\"prior\":", "tail": {$: "Con", "head": ($host$045render$058render_dispatch_outcome$(_prior_0)), "tail": {$: "Con", "head": ",\"world\":", "tail": {$: "Con", "head": ($host$045render$058render_world$1261$(_world_0)), "tail": {$: "Con", "head": ",\"query\":", "tail": {$: "Con", "head": ($host$045render$058render_list$12610$(_query_1)), "tail": {$: "Con", "head": ",\"plus\":", "tail": {$: "Con", "head": ($host$045render$058render_list$12610$(_plus_0)), "tail": {$: "Con", "head": ",\"minus\":", "tail": {$: "Con", "head": ($host$045render$058render_list$12610$(_minus_0)), "tail": {$: "Con", "head": ",\"optional\":", "tail": {$: "Con", "head": ($host$045render$058render_list$12610$(_optional_0)), "tail": {$: "Con", "head": ",\"lookups\":", "tail": {$: "Con", "head": ($host$045render$058render_list$12615$(_lookups_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}}}}}}}}}}}}}}}});
  } else if (_value_0.$ === "host-observations.Dispatch") {
    const _step_4 = _value_0["step"];
    const _worldName_2 = _value_0["worldName"];
    const _tracked_0 = _value_0["tracked"];
    const _outcome_0 = _value_0["outcome"];
    const _clockTick_0 = _value_0["clockTick"];
    const _frame_0 = _value_0["frame"];
    const _counts_0 = _value_0["counts"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"Dispatch\"", "tail": {$: "Con", "head": ",\"step\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_step_4)), "tail": {$: "Con", "head": ",\"worldName\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_worldName_2)), "tail": {$: "Con", "head": ",\"tracked\":", "tail": {$: "Con", "head": ($host$045render$058render_boolean$(_tracked_0)), "tail": {$: "Con", "head": ",\"outcome\":", "tail": {$: "Con", "head": ($host$045render$058render_dispatch_outcome$(_outcome_0)), "tail": {$: "Con", "head": ",\"clockTick\":", "tail": {$: "Con", "head": ($U32$show$(_clockTick_0)), "tail": {$: "Con", "head": ",\"frame\":", "tail": {$: "Con", "head": ($U32$show$(_frame_0)), "tail": {$: "Con", "head": ",\"counts\":", "tail": {$: "Con", "head": ($host$045render$058render_list$1268$(_counts_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}}}}}}}}}}}});
  } else if (_value_0.$ === "host-observations.ReadDone") {
    const _step_5 = _value_0["step"];
    const _system_1 = _value_0["system"];
    const _frame_1 = _value_0["frame"];
    const _tick_0 = _value_0["tick"];
    const _outcome_1 = _value_0["outcome"];
    const _messageLag_1 = _value_0["messageLag"];
    const _removedLag_1 = _value_0["removedLag"];
    const _despawnedLag_1 = _value_0["despawnedLag"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"ReadDone\"", "tail": {$: "Con", "head": ",\"step\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_step_5)), "tail": {$: "Con", "head": ",\"system\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_system_1)), "tail": {$: "Con", "head": ",\"frame\":", "tail": {$: "Con", "head": ($U32$show$(_frame_1)), "tail": {$: "Con", "head": ",\"tick\":", "tail": {$: "Con", "head": ($U32$show$(_tick_0)), "tail": {$: "Con", "head": ",\"outcome\":", "tail": {$: "Con", "head": ($host$045render$058render_outcome$(_outcome_1)), "tail": {$: "Con", "head": ",\"messageLag\":", "tail": {$: "Con", "head": ($host$045render$058render_boolean$(_messageLag_1)), "tail": {$: "Con", "head": ",\"removedLag\":", "tail": {$: "Con", "head": ($host$045render$058render_boolean$(_removedLag_1)), "tail": {$: "Con", "head": ",\"despawnedLag\":", "tail": {$: "Con", "head": ($host$045render$058render_boolean$(_despawnedLag_1)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}}}}}}}}}}}}}});
  } else {
    const _step_6 = _value_0["step"];
    const _system_2 = _value_0["system"];
    const _views_0 = _value_0["views"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"OwnWrites\"", "tail": {$: "Con", "head": ",\"step\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_step_6)), "tail": {$: "Con", "head": ",\"system\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_system_2)), "tail": {$: "Con", "head": ",\"views\":", "tail": {$: "Con", "head": ($host$045render$058render_list$1269$(_views_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}}}});
  }
}

function $streams$058initial$(_capacity_0) {
  return {$: "streams.PingLog", "buffer": {$: "streams.Buffer", "capacity": _capacity_0, "size": 0, "dropped": 0, "front": {$: "Nil"}, "rear": {$: "Nil"}}};
}

function $streams$058life_initial$(_capacity_0) {
  return {$: "streams.LifeLog", "buffer": {$: "streams.Buffer", "capacity": _capacity_0, "size": 0, "dropped": 0, "front": {$: "Nil"}, "rear": {$: "Nil"}}};
}

function $cache$058static_init_done$(_result_0) {
  const _raw_0 = _result_0["fst"];
  const _cached_0 = _result_0["snd"];
  return {$: "cache.Cache", "raw": _raw_0, "cached": _cached_0};
}

function $uncached$045payload$058health_ledger_get$(_owner_0) {
  const _array_0 = _owner_0["totals"];
  const _epoch_0 = _owner_0["epoch"];
  return $uncached$045payload$058health_ledger_observed$(_epoch_0, ($uncached$045payload$058four$(_array_0)));
}

function $dispatcher$058tick$1263$(_nodes_0, _ledgerName_0, _stateName_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _registry_0 = _runtime_0["registry"];
  const _readers_0 = _runtime_0["readers"];
  const _clock_0 = _runtime_0["clock"];
  const _audit_0 = _runtime_0["audit"];
  const _style_0 = _runtime_0["style"];
  const _escaped_0 = _runtime_0["escaped"];
  const _observations_0 = _runtime_0["observations"];
  const _nextMode_0 = _runtime_0["nextMode"];
  return $dispatcher$058tick_registry$1263$(_nodes_0, _ledgerName_0, _stateName_0, _world_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($dispatcher$058registry_values$(_registry_0)));
}

function $host$058label$(_step_0, _owner_0) {
  const _world_0 = _owner_0["world"];
  const _logs_0 = _owner_0["logs"];
  const _bindings_0 = _owner_0["bindings"];
  const _worldName_0 = _owner_0["worldName"];
  const _prior_0 = _owner_0["prior"];
  const _events_0 = _owner_0["events"];
  return {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0};
}

function $host$058dispatched_counts$(_world_0, _logs_0, _bindings_0, _worldName_0, _step_0, _tracked_0, _events_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _outcome_0, _pair_0) {
  const _registry_0 = _pair_0["fst"];
  const _counts_0 = _pair_0["snd"];
  return {$: "dispatcher.Dispatched", "runtime": {$: "dispatcher.Runtime", "world": {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _outcome_0, "events": ($List$append$(_events_0, {$: "Con", "head": {$: "host-observations.Dispatch", "step": _step_0, "worldName": _worldName_0, "tracked": _tracked_0, "outcome": _outcome_0, "clockTick": ($dispatcher$058clock_tick$(_clock_0)), "frame": ($host$058clock_frame$(_clock_0)), "counts": _counts_0}, "tail": {$: "Nil"}}))}, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0}, "outcome": _outcome_0};
}

function $host$045preflight$058health_tick$(_nodes_0, _runtime_0) {
  return $dispatcher$058tick$1265$(_nodes_0, "HealthLedger", "HealthMode", _runtime_0);
}

function $host$045preflight$058health_probe_done$(_label_0, _result_0) {
  const _runtime_0 = _result_0["runtime"];
  const _outcome_0 = _result_0["outcome"];
  return run_clo((_x_0) => {
  const _x_1 = ($host$045render$058render_dispatch_outcome$(_outcome_0));
  const _x_2 = (":" + _x_1);
  const _x_3 = (_label_0 + _x_2);
  return $IO$bind$((_x_4) => $IO$print$(("PREFLIGHT-RESULT:health:" + _x_3), _x_4), run_clo((_x_5) => {
  return run_clo((_x_6) => {
  return $IO$pure$({$: "dispatcher.Dispatched", "runtime": _runtime_0, "outcome": _outcome_0}, _x_6);
});
}), _x_0);
});
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $host$045health$045body$058same_bases$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const _t_0 = _left_0["head"];
    const _a_0 = _t_0["base"];
    const _an_0 = _t_0["name"];
    const _at_0 = _left_0["tail"];
    if (_right_0.$ === "Con") {
      const _t_1 = _right_0["head"];
      const _b_0 = _t_1["base"];
      const _bn_0 = _t_1["name"];
      const _bt_0 = _right_0["tail"];
      return $Bool$and$(($Bool$and$((_a_0 === _b_0), ($String$eq$(_an_0, _bn_0)))), ($host$045health$045body$058same_bases$(_at_0, _bt_0)));
    } else {
      return false;
    }
  }
}

function $host$045health$045body$058same_counts$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const _t_0 = _left_0["head"];
    const _a_0 = _t_0["system"];
    const _x_0 = _t_0["value"];
    const _at_0 = _left_0["tail"];
    if (_right_0.$ === "Con") {
      const _t_1 = _right_0["head"];
      const _b_0 = _t_1["system"];
      const _y_0 = _t_1["value"];
      const _bt_0 = _right_0["tail"];
      return $Bool$and$(($Bool$and$(($String$eq$(_a_0, _b_0)), ($host$045health$045body$058same_four$(_x_0, _y_0)))), ($host$045health$045body$058same_counts$(_at_0, _bt_0)));
    } else {
      return false;
    }
  }
}

function $host$058count_registry_return$(_next_0, _pair_0) {
  const _entries_0 = _pair_0["fst"];
  const _values_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "schedule.Registry", "next": _next_0, "entries": _entries_0}, "snd": _values_0};
}

function $host$058count_entries$(_entries_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _system_0 = _t_0["system"];
    const _owner_0 = _t_0["local"];
    const _tail_0 = _entries_0["tail"];
    return $host$058count_tail$(_system_0, _owner_0, ($host$058count_entries$(_tail_0)));
  }
}

function $dispatcher$058registry_join$(_system_0, _local_0, _tail_0) {
  const _entries_0 = _tail_0["fst"];
  const _systems_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": {$: "schedule.Entry", "system": _system_0, "local": _local_0}, "tail": _entries_0}, "snd": {$: "Con", "head": _system_0, "tail": _systems_0}};
}

function $String$reverse$go$($0, $1) {
  for (;;) {
    {
      const _s_0 = $0;
      const _acc_0 = $1;
      if (_s_0 === "") {
        return _acc_0;
      } else {
        const _h_0 = (_s_0.codePointAt(0) > 0xFFFF ? _s_0.slice(0, 2) : _s_0[0]);
        const _t_0 = (_s_0.codePointAt(0) > 0xFFFF ? _s_0.slice(2) : _s_0.slice(1));
        $0 = _t_0;
        $1 = (_h_0 + _acc_0);
        continue;
      }
    }
  }
}

function $host$045render$058render_string$(_value_0) {
  return $host$045render$058render_concat$({$: "Con", "head": "\"", "tail": {$: "Con", "head": ($host$045render$058render_escape$(_value_0)), "tail": {$: "Con", "head": "\"", "tail": {$: "Nil"}}}});
}

function $host$045render$058render_dispatch_outcome$(_value_0) {
  if (_value_0.$ === "dispatcher.SetupRejected") {
    const _reason_0 = _value_0["reason"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"SetupRejected\"", "tail": {$: "Con", "head": ",\"reason\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_reason_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
  } else if (_value_0.$ === "dispatcher.Complete") {
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"Complete\"", "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}});
  } else if (_value_0.$ === "dispatcher.SystemFailure") {
    const _system_0 = _value_0["system"];
    const _code_0 = _value_0["code"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"SystemFailure\"", "tail": {$: "Con", "head": ",\"system\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_system_0)), "tail": {$: "Con", "head": ",\"code\":", "tail": {$: "Con", "head": ($U32$show$(_code_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}});
  } else {
    const _requirements_0 = _value_0["requirements"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"MissingRuntimeRequirements\"", "tail": {$: "Con", "head": ",\"requirements\":", "tail": {$: "Con", "head": ($host$045render$058render_list$1260$(_requirements_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
  }
}

function $host$045render$058render_list$1261$(_values_0) {
  return $host$045render$058render_concat$({$: "Con", "head": "[", "tail": {$: "Con", "head": ($host$045render$058render_concat$(($host$045render$058render_list_tail$1261$(_values_0, {$: "Nil"}, true)))), "tail": {$: "Con", "head": "]", "tail": {$: "Nil"}}}});
}

function $host$045render$058render_boolean$(_value_0) {
  if (_value_0) {
    return "true";
  } else {
    return "false";
  }
}

function $host$045render$058render_handle$(_value_0) {
  const _namespace_0 = _value_0["namespace"];
  const _id_0 = _value_0["id"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"namespace\":", "tail": {$: "Con", "head": ($U32$show$(_namespace_0)), "tail": {$: "Con", "head": ",\"id\":", "tail": {$: "Con", "head": ($U32$show$(_id_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
}

function $host$045render$058render_access$1262$(_value_0) {
  if (_value_0.$ === "types.Found") {
    const _value_1 = _value_0["value"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"Found\"", "tail": {$: "Con", "head": ",\"value\":", "tail": {$: "Con", "head": ($host$045render$058render_query$1261$(_value_1)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
  } else if (_value_0.$ === "types.Mismatch") {
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"Mismatch\"", "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}});
  } else {
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"Missing\"", "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}});
  }
}

function $host$045render$058render_bundle$1261$(_value_0) {
  const _main_0 = _value_0["main"];
  const _aux_0 = _value_0["aux"];
  const _flag_0 = _value_0["flag"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"main\":", "tail": {$: "Con", "head": ($host$045render$058render_optional$1266$(_main_0)), "tail": {$: "Con", "head": ",\"aux\":", "tail": {$: "Con", "head": ($host$045render$058render_optional$1264$(_aux_0)), "tail": {$: "Con", "head": ",\"flag\":", "tail": {$: "Con", "head": ($host$045render$058render_optional$1265$(_flag_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}});
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $host$045render$058render_boundary$(_value_0) {
  const _since_0 = _value_0["since"];
  const _streamSince_0 = _value_0["streamSince"];
  const _thisRun_0 = _value_0["thisRun"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"since\":", "tail": {$: "Con", "head": ($U32$show$(_since_0)), "tail": {$: "Con", "head": ",\"streamSince\":", "tail": {$: "Con", "head": ($U32$show$(_streamSince_0)), "tail": {$: "Con", "head": ",\"thisRun\":", "tail": {$: "Con", "head": ($U32$show$(_thisRun_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}});
}

function $host$045render$058render_list$12610$(_values_0) {
  return $host$045render$058render_concat$({$: "Con", "head": "[", "tail": {$: "Con", "head": ($host$045render$058render_concat$(($host$045render$058render_list_tail$12610$(_values_0, {$: "Nil"}, true)))), "tail": {$: "Con", "head": "]", "tail": {$: "Nil"}}}});
}

function $host$045render$058render_list$12611$(_values_0) {
  return $host$045render$058render_concat$({$: "Con", "head": "[", "tail": {$: "Con", "head": ($host$045render$058render_concat$(($host$045render$058render_list_tail$12611$(_values_0, {$: "Nil"}, true)))), "tail": {$: "Con", "head": "]", "tail": {$: "Nil"}}}});
}

function $host$045render$058render_list$12612$(_values_0) {
  return $host$045render$058render_concat$({$: "Con", "head": "[", "tail": {$: "Con", "head": ($host$045render$058render_concat$(($host$045render$058render_list_tail$12612$(_values_0, {$: "Nil"}, true)))), "tail": {$: "Con", "head": "]", "tail": {$: "Nil"}}}});
}

function $host$045render$058render_world$1261$(_value_0) {
  const _namespace_0 = _value_0["namespace"];
  const _next_0 = _value_0["next"];
  const _rows_0 = _value_0["rows"];
  const _pending_0 = _value_0["pending"];
  const _ledger_0 = _value_0["ledger"];
  const _mode_0 = _value_0["mode"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"namespace\":", "tail": {$: "Con", "head": ($U32$show$(_namespace_0)), "tail": {$: "Con", "head": ",\"next\":", "tail": {$: "Con", "head": ($U32$show$(_next_0)), "tail": {$: "Con", "head": ",\"rows\":", "tail": {$: "Con", "head": ($host$045render$058render_list$12613$(_rows_0)), "tail": {$: "Con", "head": ",\"pending\":", "tail": {$: "Con", "head": ($host$045render$058render_list$12614$(_pending_0)), "tail": {$: "Con", "head": ",\"ledger\":", "tail": {$: "Con", "head": ($host$045render$058render_optional$1260$(_ledger_0)), "tail": {$: "Con", "head": ",\"mode\":", "tail": {$: "Con", "head": ($host$045render$058render_health_mode$(_mode_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}}}}}}}});
}

function $host$045render$058render_list$12615$(_values_0) {
  return $host$045render$058render_concat$({$: "Con", "head": "[", "tail": {$: "Con", "head": ($host$045render$058render_concat$(($host$045render$058render_list_tail$12615$(_values_0, {$: "Nil"}, true)))), "tail": {$: "Con", "head": "]", "tail": {$: "Nil"}}}});
}

function $host$045render$058render_list$1268$(_values_0) {
  return $host$045render$058render_concat$({$: "Con", "head": "[", "tail": {$: "Con", "head": ($host$045render$058render_concat$(($host$045render$058render_list_tail$1268$(_values_0, {$: "Nil"}, true)))), "tail": {$: "Con", "head": "]", "tail": {$: "Nil"}}}});
}

function $host$045render$058render_outcome$(_value_0) {
  if (_value_0.$ === "types.Success") {
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"Success\"", "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}});
  } else {
    const _code_0 = _value_0["code"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"Failure\"", "tail": {$: "Con", "head": ",\"code\":", "tail": {$: "Con", "head": ($U32$show$(_code_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
  }
}

function $host$045render$058render_list$1269$(_values_0) {
  return $host$045render$058render_concat$({$: "Con", "head": "[", "tail": {$: "Con", "head": ($host$045render$058render_concat$(($host$045render$058render_list_tail$1269$(_values_0, {$: "Nil"}, true)))), "tail": {$: "Con", "head": "]", "tail": {$: "Nil"}}}});
}

function $uncached$045payload$058health_ledger_observed$(_epoch_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "types.HealthLedger", "totals": _array_0, "epoch": _epoch_0}, "snd": {$: "types.LedgerView", "totals": _values_0, "epoch": _epoch_0}};
}

function $uncached$045payload$058four$(_array_0) {
  return $uncached$045payload$058original_four$(_array_0);
}

function $dispatcher$058tick_registry$1263$(_nodes_0, _ledgerName_0, _stateName_0, _world_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _scan_0) {
  const _registry_0 = _scan_0["fst"];
  const _systems_0 = _scan_0["snd"];
  return $dispatcher$058tick_canonical$1263$(_ledgerName_0, _stateName_0, ($dispatcher$058canonical$(_systems_0, _nodes_0)), {$: "dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0});
}

function $dispatcher$058clock_tick$(_clock_0) {
  const _tick_0 = _clock_0["tick"];
  return _tick_0;
}

function $host$058clock_frame$(_clock_0) {
  const _frame_0 = _clock_0["frameNo"];
  return _frame_0;
}

function $dispatcher$058tick$1265$(_nodes_0, _ledgerName_0, _stateName_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _registry_0 = _runtime_0["registry"];
  const _readers_0 = _runtime_0["readers"];
  const _clock_0 = _runtime_0["clock"];
  const _audit_0 = _runtime_0["audit"];
  const _style_0 = _runtime_0["style"];
  const _escaped_0 = _runtime_0["escaped"];
  const _observations_0 = _runtime_0["observations"];
  const _nextMode_0 = _runtime_0["nextMode"];
  return $dispatcher$058tick_registry$1265$(_nodes_0, _ledgerName_0, _stateName_0, _world_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($dispatcher$058registry_values$(_registry_0)));
}

function $host$045health$045body$058same_four$(_left_0, _right_0) {
  const _a_0 = _left_0["a"];
  const _b_0 = _left_0["b"];
  const _c_0 = _left_0["c"];
  const _d_0 = _left_0["d"];
  const _w_0 = _right_0["a"];
  const _x_0 = _right_0["b"];
  const _y_0 = _right_0["c"];
  const _z_0 = _right_0["d"];
  return $Bool$and$(($Bool$and$((_a_0 === _w_0), (_b_0 === _x_0))), ($Bool$and$((_c_0 === _y_0), (_d_0 === _z_0))));
}

function $host$058count_tail$(_system_0, _owner_0, _pair_0) {
  const _entries_0 = _pair_0["fst"];
  const _values_0 = _pair_0["snd"];
  return $host$058count_local$(_system_0, _entries_0, _values_0, ($capture$058observe$(_owner_0)));
}

function $host$045render$058render_escape$(_value_0) {
  return $host$045render$058render_escape_tail$(_value_0, "");
}

function $host$045render$058render_list$1260$(_values_0) {
  return $host$045render$058render_concat$({$: "Con", "head": "[", "tail": {$: "Con", "head": ($host$045render$058render_concat$(($host$045render$058render_list_tail$1260$(_values_0, {$: "Nil"}, true)))), "tail": {$: "Con", "head": "]", "tail": {$: "Nil"}}}});
}

function $host$045render$058render_list_tail$1261$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($host$045render$058render_list_piece$(($host$045render$058render_string$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $host$045render$058render_query$1261$(_value_0) {
  const _handle_0 = _value_0["handle"];
  const _main_0 = _value_0["main"];
  const _aux_0 = _value_0["aux"];
  const _flag_0 = _value_0["flag"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"handle\":", "tail": {$: "Con", "head": ($host$045render$058render_handle$(_handle_0)), "tail": {$: "Con", "head": ",\"main\":", "tail": {$: "Con", "head": ($host$045render$058render_vitals$(_main_0)), "tail": {$: "Con", "head": ",\"aux\":", "tail": {$: "Con", "head": ($host$045render$058render_optional$1264$(_aux_0)), "tail": {$: "Con", "head": ",\"flag\":", "tail": {$: "Con", "head": ($host$045render$058render_optional$1265$(_flag_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}}}});
}

function $host$045render$058render_optional$1266$(_value_0) {
  if (_value_0.$ === "None") {
    return "null";
  } else {
    const _value_1 = _value_0["value"];
    return $host$045render$058render_vitals$(_value_1);
  }
}

function $host$045render$058render_optional$1264$(_value_0) {
  if (_value_0.$ === "None") {
    return "null";
  } else {
    const _value_1 = _value_0["value"];
    return $host$045render$058render_armor$(_value_1);
  }
}

function $host$045render$058render_optional$1265$(_value_0) {
  if (_value_0.$ === "None") {
    return "null";
  } else {
    const _value_1 = _value_0["value"];
    return $host$045render$058render_tracked$(_value_1);
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $host$045render$058render_list_tail$12610$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($host$045render$058render_list_piece$(($host$045render$058render_query$1261$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $host$045render$058render_list_tail$12611$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($host$045render$058render_list_piece$(($host$045render$058render_handle$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $host$045render$058render_list_tail$12612$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($host$045render$058render_list_piece$(($host$045render$058render_health_ping$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $host$045render$058render_list$12613$(_values_0) {
  return $host$045render$058render_concat$({$: "Con", "head": "[", "tail": {$: "Con", "head": ($host$045render$058render_concat$(($host$045render$058render_list_tail$12613$(_values_0, {$: "Nil"}, true)))), "tail": {$: "Con", "head": "]", "tail": {$: "Nil"}}}});
}

function $host$045render$058render_list$12614$(_values_0) {
  return $host$045render$058render_concat$({$: "Con", "head": "[", "tail": {$: "Con", "head": ($host$045render$058render_concat$(($host$045render$058render_list_tail$12614$(_values_0, {$: "Nil"}, true)))), "tail": {$: "Con", "head": "]", "tail": {$: "Nil"}}}});
}

function $host$045render$058render_optional$1260$(_value_0) {
  if (_value_0.$ === "None") {
    return "null";
  } else {
    const _value_1 = _value_0["value"];
    return $host$045render$058render_ledger$(_value_1);
  }
}

function $host$045render$058render_health_mode$(_value_0) {
  if (_value_0.$ === "types.HealthOn") {
    return "\"HealthOn\"";
  } else {
    return "\"HealthOff\"";
  }
}

function $host$045render$058render_list_tail$12615$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($host$045render$058render_list_piece$(($host$045render$058render_lookup$1261$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $host$045render$058render_list_tail$1268$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($host$045render$058render_list_piece$(($host$045render$058render_count$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $host$045render$058render_list_tail$1269$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($host$045render$058render_list_piece$(($host$045render$058render_own_view$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $uncached$045payload$058original_four$(_array_0) {
  return $uncached$045payload$058four_a$({$: "Tuple", fst: _array_0, snd: _array_0[0 % _array_0.length]});
}

function $dispatcher$058tick_canonical$1263$(_ledgerName_0, _stateName_0, _checked_0, _runtime_0) {
  if (_checked_0.$ === "dispatcher.Unknown") {
    const _base_0 = _checked_0["base"];
    return run_clo((_x_0) => {
  const _x_1 = ($U32$show$(_base_0));
  return $IO$pure$({$: "dispatcher.Dispatched", "runtime": _runtime_0, "outcome": {$: "dispatcher.SetupRejected", "reason": ("unregistered base:" + _x_1)}}, _x_0);
});
  } else {
    const _nodes_0 = _checked_0["nodes"];
    const _world_0 = _runtime_0["world"];
    const _registry_0 = _runtime_0["registry"];
    const _readers_0 = _runtime_0["readers"];
    const _clock_0 = _runtime_0["clock"];
    const _audit_0 = _runtime_0["audit"];
    const _style_0 = _runtime_0["style"];
    const _escaped_0 = _runtime_0["escaped"];
    const _observations_0 = _runtime_0["observations"];
    const _nextMode_0 = _runtime_0["nextMode"];
    return $dispatcher$058tick_presence$1263$(_nodes_0, _ledgerName_0, _stateName_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($host$058prototype_slot_host_health_presence$(_world_0)));
  }
}

function $dispatcher$058canonical$(_systems_0, _nodes_0) {
  if (_nodes_0.$ === "Nil") {
    return {$: "dispatcher.Accepted", "nodes": {$: "Nil"}};
  } else {
    const _t_0 = _nodes_0["head"];
    if (_t_0.$ === "schedule.Call") {
      const _t_1 = _t_0["system"];
      const _base_0 = _t_1["base"];
      const _mode_0 = _t_0["mode"];
      const _tail_0 = _nodes_0["tail"];
      return $dispatcher$058canonical_call$(_base_0, _mode_0, ($dispatcher$058system_find$(_base_0, _systems_0)), ($dispatcher$058canonical$(_systems_0, _tail_0)));
    } else if (_t_0.$ === "schedule.Nested") {
      const _nested_0 = _t_0["steps"];
      const _tail_1 = _nodes_0["tail"];
      return $dispatcher$058canonical_nested$(($dispatcher$058canonical$(_systems_0, _nested_0)), ($dispatcher$058canonical$(_systems_0, _tail_1)));
    } else {
      const _tail_2 = _nodes_0["tail"];
      return $dispatcher$058canonical_cons$(_t_0, ($dispatcher$058canonical$(_systems_0, _tail_2)));
    }
  }
}

function $dispatcher$058tick_registry$1265$(_nodes_0, _ledgerName_0, _stateName_0, _world_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _scan_0) {
  const _registry_0 = _scan_0["fst"];
  const _systems_0 = _scan_0["snd"];
  return $dispatcher$058tick_canonical$1265$(_ledgerName_0, _stateName_0, ($dispatcher$058canonical$(_systems_0, _nodes_0)), {$: "dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0});
}

function $host$058count_local$(_system_0, _tail_0, _counts_0, _pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _view_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": {$: "schedule.Entry", "system": _system_0, "local": _owner_0}, "tail": _tail_0}, "snd": {$: "Con", "head": {$: "host-observations.Count", "system": ($host$058system_name$(_system_0)), "value": _view_0}, "tail": _counts_0}};
}

function $capture$058observe$(_local_0) {
  const _array_0 = _local_0["count"];
  return $capture$058observed$(($payload$058four$(_array_0)));
}

function $host$045render$058render_escape_tail$($0, $1) {
  for (;;) {
    {
      const _value_0 = $0;
      const _acc_0 = $1;
      if (_value_0 === "") {
        return $String$reverse$(_acc_0);
      } else {
        const _head_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(0, 2) : _value_0[0]);
        const _tail_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(2) : _value_0.slice(1));
        $0 = _tail_0;
        $1 = ($host$045render$058render_push$(($host$045render$058render_escaped_code$(($Char$to_u32$(_head_0)))), _acc_0));
        continue;
      }
    }
  }
}

function $host$045render$058render_list_tail$1260$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($host$045render$058render_list_piece$(($host$045render$058render_requirement$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $host$045render$058render_vitals$(_value_0) {
  const _levels_0 = _value_0["levels"];
  const _reserve_0 = _value_0["reserve"];
  const _class_0 = _value_0["class"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"levels\":", "tail": {$: "Con", "head": ($host$045render$058render_four$(_levels_0)), "tail": {$: "Con", "head": ",\"reserve\":", "tail": {$: "Con", "head": ($U32$show$(_reserve_0)), "tail": {$: "Con", "head": ",\"class\":", "tail": {$: "Con", "head": ($U32$show$(_class_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}});
}

function $host$045render$058render_armor$(_value_0) {
  const _layers_0 = _value_0["layers"];
  const _grade_0 = _value_0["grade"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"layers\":", "tail": {$: "Con", "head": ($host$045render$058render_four$(_layers_0)), "tail": {$: "Con", "head": ",\"grade\":", "tail": {$: "Con", "head": ($U32$show$(_grade_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
}

function $host$045render$058render_tracked$(_value_0) {
  const _group_0 = _value_0["group"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"group\":", "tail": {$: "Con", "head": ($U32$show$(_group_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}});
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $host$045render$058render_health_ping$(_value_0) {
  const _code_0 = _value_0["code"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"code\":", "tail": {$: "Con", "head": ($U32$show$(_code_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}});
}

function $host$045render$058render_list_tail$12613$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($host$045render$058render_list_piece$(($host$045render$058render_row$1261$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $host$045render$058render_list_tail$12614$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($host$045render$058render_list_piece$(($host$045render$058render_pending$1261$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $host$045render$058render_ledger$(_value_0) {
  const _totals_0 = _value_0["totals"];
  const _epoch_0 = _value_0["epoch"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"totals\":", "tail": {$: "Con", "head": ($host$045render$058render_four$(_totals_0)), "tail": {$: "Con", "head": ",\"epoch\":", "tail": {$: "Con", "head": ($U32$show$(_epoch_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
}

function $host$045render$058render_lookup$1261$(_value_0) {
  const _label_0 = _value_0["label"];
  const _handle_0 = _value_0["handle"];
  const _result_0 = _value_0["result"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"label\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_label_0)), "tail": {$: "Con", "head": ",\"handle\":", "tail": {$: "Con", "head": ($host$045render$058render_handle$(_handle_0)), "tail": {$: "Con", "head": ",\"result\":", "tail": {$: "Con", "head": ($host$045render$058render_access$1262$(_result_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}});
}

function $host$045render$058render_count$(_value_0) {
  const _system_0 = _value_0["system"];
  const _value_1 = _value_0["value"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"system\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_system_0)), "tail": {$: "Con", "head": ",\"value\":", "tail": {$: "Con", "head": ($host$045render$058render_four$(_value_1)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
}

function $host$045render$058render_own_view$(_value_0) {
  if (_value_0.$ === "host-observations.Main") {
    const _value_1 = _value_0["value"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"Main\"", "tail": {$: "Con", "head": ",\"value\":", "tail": {$: "Con", "head": ($host$045render$058render_access$1260$(_value_1)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
  } else if (_value_0.$ === "host-observations.ReservedLookup") {
    const _value_2 = _value_0["value"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"ReservedLookup\"", "tail": {$: "Con", "head": ",\"value\":", "tail": {$: "Con", "head": ($host$045render$058render_access$1260$(_value_2)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
  } else {
    const _value_3 = _value_0["value"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"Ledger\"", "tail": {$: "Con", "head": ",\"value\":", "tail": {$: "Con", "head": ($host$045render$058render_optional$1260$(_value_3)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
  }
}

function $uncached$045payload$058four_a$(_result_0) {
  const _array_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return $uncached$045payload$058four_b$(_a_0, {$: "Tuple", fst: _array_0, snd: _array_0[1 % _array_0.length]});
}

function $dispatcher$058tick_presence$1263$(_nodes_0, _ledgerName_0, _stateName_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _owners_0) {
  const _world_0 = _owners_0["fst"];
  const _t_0 = _owners_0["snd"];
  const _ledger_0 = _t_0["ledger"];
  return $dispatcher$058tick_audit$1263$(_nodes_0, _ledger_0, _ledgerName_0, _stateName_0, _world_0, _registry_0, _readers_0, _clock_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($dispatcher$058audit_present$(_audit_0)));
}

function $host$058prototype_slot_host_health_presence$(_owner_0) {
  const _t_0 = _owner_0["world"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["next"];
  const _rows_0 = _t_0["rows"];
  const _pending_0 = _t_0["pending"];
  const _ledger_0 = _t_0["ledger"];
  const _mode_0 = _t_0["mode"];
  const _logs_0 = _owner_0["logs"];
  const _bindings_0 = _owner_0["bindings"];
  const _worldName_0 = _owner_0["worldName"];
  const _step_0 = _owner_0["step"];
  const _prior_0 = _owner_0["prior"];
  const _events_0 = _owner_0["events"];
  return $host$058prototype_slot_host_health_presence_ledger$(_ns_0, _next_0, _rows_0, _pending_0, _mode_0, _logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, ($host$058ledger_presence$(_ledger_0)));
}

function $dispatcher$058canonical_call$(_base_0, _mode_0, _found_0, _tail_0) {
  if (_found_0.$ === "None") {
    return {$: "dispatcher.Unknown", "base": _base_0};
  } else {
    const _system_0 = _found_0["value"];
    return $dispatcher$058canonical_cons$({$: "schedule.Call", "system": _system_0, "mode": _mode_0}, _tail_0);
  }
}

function $dispatcher$058system_find$(_base_0, _systems_0) {
  if (_systems_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _systems_0["head"];
    const _key_0 = _t_0["base"];
    const _name_0 = _t_0["name"];
    const _kind_0 = _t_0["kind"];
    const _ledger_0 = _t_0["ledger"];
    const _audit_0 = _t_0["audit"];
    const _gated_0 = _t_0["gated"];
    const _reader_0 = _t_0["reader"];
    const _tail_0 = _systems_0["tail"];
    return $dispatcher$058system_hit$((_base_0 === _key_0), {$: "schedule.System", "base": _key_0, "name": _name_0, "kind": _kind_0, "ledger": _ledger_0, "audit": _audit_0, "gated": _gated_0, "reader": _reader_0}, ($dispatcher$058system_find$(_base_0, _tail_0)));
  }
}

function $dispatcher$058canonical_nested$(_nested_0, _tail_0) {
  if (_nested_0.$ === "dispatcher.Accepted") {
    const _nodes_0 = _nested_0["nodes"];
    return $dispatcher$058canonical_cons$({$: "schedule.Nested", "steps": _nodes_0}, _tail_0);
  } else {
    return _nested_0;
  }
}

function $dispatcher$058canonical_cons$(_node_0, _tail_0) {
  if (_tail_0.$ === "dispatcher.Accepted") {
    const _nodes_0 = _tail_0["nodes"];
    return {$: "dispatcher.Accepted", "nodes": {$: "Con", "head": _node_0, "tail": _nodes_0}};
  } else {
    return _tail_0;
  }
}

function $dispatcher$058tick_canonical$1265$(_ledgerName_0, _stateName_0, _checked_0, _runtime_0) {
  if (_checked_0.$ === "dispatcher.Unknown") {
    const _base_0 = _checked_0["base"];
    return run_clo((_x_0) => {
  const _x_1 = ($U32$show$(_base_0));
  return $IO$pure$({$: "dispatcher.Dispatched", "runtime": _runtime_0, "outcome": {$: "dispatcher.SetupRejected", "reason": ("unregistered base:" + _x_1)}}, _x_0);
});
  } else {
    const _nodes_0 = _checked_0["nodes"];
    const _world_0 = _runtime_0["world"];
    const _registry_0 = _runtime_0["registry"];
    const _readers_0 = _runtime_0["readers"];
    const _clock_0 = _runtime_0["clock"];
    const _audit_0 = _runtime_0["audit"];
    const _style_0 = _runtime_0["style"];
    const _escaped_0 = _runtime_0["escaped"];
    const _observations_0 = _runtime_0["observations"];
    const _nextMode_0 = _runtime_0["nextMode"];
    return $dispatcher$058tick_presence$1265$(_nodes_0, _ledgerName_0, _stateName_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($host$058prototype_slot_host_health_presence$(_world_0)));
  }
}

function $host$058system_name$(_system_0) {
  const _name_0 = _system_0["name"];
  return _name_0;
}

function $capture$058observed$(_result_0) {
  const _array_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "capture.Local", "count": _array_0}, "snd": _view_0};
}

function $payload$058four$(_array_0) {
  return $payload$058four_a$({$: "Tuple", fst: _array_0, snd: _array_0[0 % _array_0.length]});
}

function $host$045render$058render_escaped_code$(_code_0) {
  if (_code_0 == 34) {
    return "\\\"";
  } else if (_code_0 == 92) {
    return "\\\\";
  } else {
    const _9_0 = u32_to_word(_code_0)["head"];
    const _10_0 = u32_to_word(_code_0)["tail"];
    const _x_0 = word_to_u32({$: "WCon", "head": _9_0, "tail": _10_0});
    return $host$045render$058render_escaped_other$(word_to_u32({$: "WCon", "head": _9_0, "tail": _10_0}), (_x_0 < 32));
  }
}

function $Char$to_u32$(_c_0) {
  return _c_0.codePointAt(0);
}

function $host$045render$058render_requirement$(_value_0) {
  if (_value_0.$ === "dispatcher.ResourceRequired") {
    const _name_0 = _value_0["name"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"ResourceRequired\"", "tail": {$: "Con", "head": ",\"name\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_name_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
  } else if (_value_0.$ === "dispatcher.ServiceRequired") {
    const _name_1 = _value_0["name"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"ServiceRequired\"", "tail": {$: "Con", "head": ",\"name\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_name_1)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
  } else {
    const _name_2 = _value_0["name"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"StateRequired\"", "tail": {$: "Con", "head": ",\"name\":", "tail": {$: "Con", "head": ($host$045render$058render_string$(_name_2)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
  }
}

function $host$045render$058render_four$(_value_0) {
  const _a_0 = _value_0["a"];
  const _b_0 = _value_0["b"];
  const _c_0 = _value_0["c"];
  const _d_0 = _value_0["d"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"a\":", "tail": {$: "Con", "head": ($U32$show$(_a_0)), "tail": {$: "Con", "head": ",\"b\":", "tail": {$: "Con", "head": ($U32$show$(_b_0)), "tail": {$: "Con", "head": ",\"c\":", "tail": {$: "Con", "head": ($U32$show$(_c_0)), "tail": {$: "Con", "head": ",\"d\":", "tail": {$: "Con", "head": ($U32$show$(_d_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}}}});
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $host$045render$058render_row$1261$(_value_0) {
  const _id_0 = _value_0["id"];
  const _main_0 = _value_0["main"];
  const _aux_0 = _value_0["aux"];
  const _flag_0 = _value_0["flag"];
  const _added_0 = _value_0["added"];
  const _changed_0 = _value_0["changed"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"id\":", "tail": {$: "Con", "head": ($U32$show$(_id_0)), "tail": {$: "Con", "head": ",\"main\":", "tail": {$: "Con", "head": ($host$045render$058render_optional$1266$(_main_0)), "tail": {$: "Con", "head": ",\"aux\":", "tail": {$: "Con", "head": ($host$045render$058render_optional$1264$(_aux_0)), "tail": {$: "Con", "head": ",\"flag\":", "tail": {$: "Con", "head": ($host$045render$058render_optional$1265$(_flag_0)), "tail": {$: "Con", "head": ",\"added\":", "tail": {$: "Con", "head": ($U32$show$(_added_0)), "tail": {$: "Con", "head": ",\"changed\":", "tail": {$: "Con", "head": ($U32$show$(_changed_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}}}}}}}});
}

function $host$045render$058render_pending$1261$(_value_0) {
  if (_value_0.$ === "observations.SpawnView") {
    const _id_0 = _value_0["id"];
    const _bundle_0 = _value_0["bundle"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"SpawnView\"", "tail": {$: "Con", "head": ",\"id\":", "tail": {$: "Con", "head": ($U32$show$(_id_0)), "tail": {$: "Con", "head": ",\"bundle\":", "tail": {$: "Con", "head": ($host$045render$058render_bundle$1261$(_bundle_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}});
  } else if (_value_0.$ === "observations.MainView") {
    const _id_1 = _value_0["id"];
    const _main_0 = _value_0["main"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"MainView\"", "tail": {$: "Con", "head": ",\"id\":", "tail": {$: "Con", "head": ($U32$show$(_id_1)), "tail": {$: "Con", "head": ",\"main\":", "tail": {$: "Con", "head": ($host$045render$058render_vitals$(_main_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}});
  } else if (_value_0.$ === "observations.FlagView") {
    const _id_2 = _value_0["id"];
    const _flag_0 = _value_0["flag"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"FlagView\"", "tail": {$: "Con", "head": ",\"id\":", "tail": {$: "Con", "head": ($U32$show$(_id_2)), "tail": {$: "Con", "head": ",\"flag\":", "tail": {$: "Con", "head": ($host$045render$058render_tracked$(_flag_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}});
  } else if (_value_0.$ === "observations.RemoveMainView") {
    const _id_3 = _value_0["id"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"RemoveMainView\"", "tail": {$: "Con", "head": ",\"id\":", "tail": {$: "Con", "head": ($U32$show$(_id_3)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
  } else if (_value_0.$ === "observations.RemoveFlagView") {
    const _id_4 = _value_0["id"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"RemoveFlagView\"", "tail": {$: "Con", "head": ",\"id\":", "tail": {$: "Con", "head": ($U32$show$(_id_4)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
  } else {
    const _id_5 = _value_0["id"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"DespawnView\"", "tail": {$: "Con", "head": ",\"id\":", "tail": {$: "Con", "head": ($U32$show$(_id_5)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
  }
}

function $host$045render$058render_access$1260$(_value_0) {
  if (_value_0.$ === "types.Found") {
    const _value_1 = _value_0["value"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"Found\"", "tail": {$: "Con", "head": ",\"value\":", "tail": {$: "Con", "head": ($host$045render$058render_main_view$(_value_1)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
  } else if (_value_0.$ === "types.Mismatch") {
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"Mismatch\"", "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}});
  } else {
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"Missing\"", "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}});
  }
}

function $uncached$045payload$058four_b$(_a_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _b_0 = _result_0["snd"];
  return $uncached$045payload$058four_c$(_a_0, _b_0, {$: "Tuple", fst: _array_0, snd: _array_0[2 % _array_0.length]});
}

function $dispatcher$058tick_audit$1263$(_nodes_0, _ledger_0, _ledgerName_0, _stateName_0, _world_0, _registry_0, _readers_0, _clock_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _service_0) {
  const _audit_0 = _service_0["fst"];
  const _available_0 = _service_0["snd"];
  return $dispatcher$058tick_missing$1263$(_nodes_0, ($dispatcher$058preflight$(_nodes_0, _ledger_0, _available_0, true, _ledgerName_0, _stateName_0)), {$: "dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0});
}

function $dispatcher$058audit_present$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _audit_0 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _audit_0}, "snd": true};
  }
}

function $host$058prototype_slot_host_health_presence_ledger$(_ns_0, _next_0, _rows_0, _pending_0, _mode_0, _logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _pair_0) {
  const _ledger_0 = _pair_0["fst"];
  const _available_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "host.Host", "world": {$: "storage.World", "namespace": _ns_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, "snd": {$: "dispatcher.Presence", "ledger": _available_0, "modeOn": ($host$058prototype_slot_host_health_on$(_mode_0))}};
}

function $host$058ledger_presence$(_ledger_0) {
  if (_ledger_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_0 = _ledger_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_0}, "snd": true};
  }
}

function $dispatcher$058system_hit$(_equal_0, _system_0, _tail_0) {
  if (_equal_0) {
    return {$: "Some", "value": _system_0};
  } else {
    return _tail_0;
  }
}

function $dispatcher$058tick_presence$1265$(_nodes_0, _ledgerName_0, _stateName_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _owners_0) {
  const _world_0 = _owners_0["fst"];
  const _t_0 = _owners_0["snd"];
  const _ledger_0 = _t_0["ledger"];
  return $dispatcher$058tick_audit$1265$(_nodes_0, _ledger_0, _ledgerName_0, _stateName_0, _world_0, _registry_0, _readers_0, _clock_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($dispatcher$058audit_present$(_audit_0)));
}

function $payload$058four_a$(_result_0) {
  const _array_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return $payload$058four_b$(_a_0, {$: "Tuple", fst: _array_0, snd: _array_0[1 % _array_0.length]});
}

function $host$045render$058render_escaped_other$(_code_0, _control_0) {
  if (_control_0) {
    return $host$045render$058render_concat$({$: "Con", "head": "\\u00", "tail": {$: "Con", "head": ($host$045render$058render_hex$((16 === 0 ? 0 : (_code_0 / 16) >>> 0))), "tail": {$: "Con", "head": ($host$045render$058render_hex$((16 === 0 ? _code_0 : _code_0 % 16))), "tail": {$: "Nil"}}}});
  } else {
    return (($Char$from_u32$(_code_0)) + "");
  }
}

function $host$045render$058render_main_view$(_value_0) {
  if (_value_0.$ === "types.MotionMain") {
    const _position_0 = _value_0["position"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":\"MotionMain\",\"position\":", "tail": {$: "Con", "head": ($host$045render$058render_position$(_position_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}});
  } else {
    const _vitals_0 = _value_0["vitals"];
    return $host$045render$058render_concat$({$: "Con", "head": "{\"kind\":\"HealthMain\",\"vitals\":", "tail": {$: "Con", "head": ($host$045render$058render_vitals$(_vitals_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}});
  }
}

function $uncached$045payload$058four_c$(_a_0, _b_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _c_0 = _result_0["snd"];
  return $uncached$045payload$058four_done$(_a_0, _b_0, _c_0, {$: "Tuple", fst: _array_0, snd: _array_0[3 % _array_0.length]});
}

function $dispatcher$058tick_missing$1263$(_nodes_0, _missing_0, _runtime_0) {
  if (_missing_0.$ === "Nil") {
    const _world_0 = _runtime_0["world"];
    const _registry_0 = _runtime_0["registry"];
    const _readers_0 = _runtime_0["readers"];
    const _clock_0 = _runtime_0["clock"];
    const _audit_0 = _runtime_0["audit"];
    const _style_0 = _runtime_0["style"];
    const _escaped_0 = _runtime_0["escaped"];
    const _observations_0 = _runtime_0["observations"];
    const _nextMode_0 = _runtime_0["nextMode"];
    return $dispatcher$058tick_frame$1263$(_nodes_0, _registry_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($host$058prototype_slot_host_health_frame$(_world_0, _readers_0, ($readers$058frame$(_clock_0)))));
  } else {
    return run_clo((_x_0) => {
  return $IO$pure$({$: "dispatcher.Dispatched", "runtime": _runtime_0, "outcome": {$: "dispatcher.MissingRuntimeRequirements", "requirements": _missing_0}}, _x_0);
});
  }
}

function $dispatcher$058preflight$($0, $1, $2, $3, $4, $5) {
  for (;;) {
    {
      const _nodes_0 = $0;
      const _ledger_0 = $1;
      const _audit_0 = $2;
      const _state_0 = $3;
      const _ledgerName_0 = $4;
      const _stateName_0 = $5;
      if (_nodes_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _t_0 = _nodes_0["head"];
        if (_t_0.$ === "schedule.Call") {
          const _system_0 = _t_0["system"];
          const _tail_0 = _nodes_0["tail"];
          return $dispatcher$058union$(($dispatcher$058requirements$(_system_0, _ledger_0, _audit_0, _state_0, _ledgerName_0, _stateName_0)), ($dispatcher$058preflight$(_tail_0, _ledger_0, _audit_0, _state_0, _ledgerName_0, _stateName_0)));
        } else if (_t_0.$ === "schedule.Nested") {
          const _nested_0 = _t_0["steps"];
          const _tail_1 = _nodes_0["tail"];
          return $dispatcher$058union$(($dispatcher$058preflight$(_nested_0, _ledger_0, _audit_0, _state_0, _ledgerName_0, _stateName_0)), ($dispatcher$058preflight$(_tail_1, _ledger_0, _audit_0, _state_0, _ledgerName_0, _stateName_0)));
        } else if (_t_0.$ === "schedule.Deferred") {
          const _tail_2 = _nodes_0["tail"];
          $0 = _tail_2;
          $1 = _ledger_0;
          $2 = _audit_0;
          $3 = _state_0;
          $4 = _ledgerName_0;
          $5 = _stateName_0;
          continue;
        } else {
          const _tail_3 = _nodes_0["tail"];
          $0 = _tail_3;
          $1 = _ledger_0;
          $2 = _audit_0;
          $3 = _state_0;
          $4 = _ledgerName_0;
          $5 = _stateName_0;
          continue;
        }
      }
    }
  }
}

function $host$058prototype_slot_host_health_on$(_mode_0) {
  if (_mode_0.$ === "types.HealthOn") {
    return true;
  } else {
    return false;
  }
}

function $dispatcher$058tick_audit$1265$(_nodes_0, _ledger_0, _ledgerName_0, _stateName_0, _world_0, _registry_0, _readers_0, _clock_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _service_0) {
  const _audit_0 = _service_0["fst"];
  const _available_0 = _service_0["snd"];
  return $dispatcher$058tick_missing$1265$(_nodes_0, ($dispatcher$058preflight$(_nodes_0, _ledger_0, _available_0, true, _ledgerName_0, _stateName_0)), {$: "dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0});
}

function $payload$058four_b$(_a_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _b_0 = _result_0["snd"];
  return $payload$058four_c$(_a_0, _b_0, {$: "Tuple", fst: _array_0, snd: _array_0[2 % _array_0.length]});
}

function $host$045render$058render_hex$(_value_0) {
  if (_value_0 == 0) {
    return "0";
  } else if ((_value_0 & 15) == 0) {
    return "?";
  } else if (_value_0 == 8) {
    return "8";
  } else if ((_value_0 & 15) == 8) {
    return "?";
  } else if (_value_0 == 4) {
    return "4";
  } else if ((_value_0 & 15) == 4) {
    return "?";
  } else if (_value_0 == 12) {
    return "c";
  } else if ((_value_0 & 15) == 12) {
    return "?";
  } else if (_value_0 == 2) {
    return "2";
  } else if ((_value_0 & 15) == 2) {
    return "?";
  } else if (_value_0 == 10) {
    return "a";
  } else if ((_value_0 & 15) == 10) {
    return "?";
  } else if (_value_0 == 6) {
    return "6";
  } else if ((_value_0 & 15) == 6) {
    return "?";
  } else if (_value_0 == 14) {
    return "e";
  } else if ((_value_0 & 15) == 14) {
    return "?";
  } else if (_value_0 == 1) {
    return "1";
  } else if ((_value_0 & 15) == 1) {
    return "?";
  } else if (_value_0 == 9) {
    return "9";
  } else if ((_value_0 & 15) == 9) {
    return "?";
  } else if (_value_0 == 5) {
    return "5";
  } else if ((_value_0 & 15) == 5) {
    return "?";
  } else if (_value_0 == 13) {
    return "d";
  } else if ((_value_0 & 15) == 13) {
    return "?";
  } else if (_value_0 == 3) {
    return "3";
  } else if ((_value_0 & 15) == 3) {
    return "?";
  } else if (_value_0 == 11) {
    return "b";
  } else if ((_value_0 & 15) == 11) {
    return "?";
  } else if (_value_0 == 7) {
    return "7";
  } else if ((_value_0 & 15) == 7) {
    return "?";
  } else if (_value_0 == 15) {
    return "f";
  } else {
    return "?";
  }
}

function $Char$from_u32$(_x_0) {
  return char_new(_x_0);
}

function $host$045render$058render_position$(_value_0) {
  const _coordinates_0 = _value_0["coordinates"];
  const _frame_0 = _value_0["frame"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"coordinates\":", "tail": {$: "Con", "head": ($host$045render$058render_four$(_coordinates_0)), "tail": {$: "Con", "head": ",\"frame\":", "tail": {$: "Con", "head": ($U32$show$(_frame_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
}

function $uncached$045payload$058four_done$(_a_0, _b_0, _c_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _d_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _array_0, "snd": {$: "types.Four", "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0}};
}

function $dispatcher$058tick_frame$1263$(_nodes_0, _registry_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _owners_0) {
  const _world_0 = _owners_0["fst"];
  const _t_0 = _owners_0["snd"];
  const _readers_0 = _t_0["fst"];
  const _clock_0 = _t_0["snd"];
  return $dispatcher$058run$1263$(_nodes_0, {$: "dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0});
}

function $host$058prototype_slot_host_health_frame$(_owner_0, _readers_0, _boundary_0) {
  return $host$058frame$(_owner_0, _readers_0, _boundary_0);
}

function $readers$058frame$(_clock_0) {
  const _now_0 = _clock_0["tick"];
  const _start_0 = _clock_0["frameStart"];
  const _retained_0 = _clock_0["retainedAfter"];
  const _number_0 = _clock_0["frameNo"];
  return $readers$058frame_case$((_start_0 > 0), _now_0, _start_0, _retained_0, _number_0);
}

function $dispatcher$058union$(_values_0, _other_0) {
  return $dispatcher$058union_acc$(_other_0, _values_0);
}

function $dispatcher$058requirements$(_system_0, _ledger_0, _audit_0, _state_0, _ledgerName_0, _stateName_0) {
  const _needLedger_0 = _system_0["ledger"];
  const _needAudit_0 = _system_0["audit"];
  const _gated_0 = _system_0["gated"];
  return $dispatcher$058union$(($dispatcher$058union$(($dispatcher$058missing_case$(_needLedger_0, _ledger_0, {$: "dispatcher.ResourceRequired", "name": _ledgerName_0})), ($dispatcher$058missing_case$(_needAudit_0, _audit_0, {$: "dispatcher.ServiceRequired", "name": "Audit"})))), ($dispatcher$058missing_case$(_gated_0, _state_0, {$: "dispatcher.StateRequired", "name": _stateName_0})));
}

function $dispatcher$058tick_missing$1265$(_nodes_0, _missing_0, _runtime_0) {
  if (_missing_0.$ === "Nil") {
    const _world_0 = _runtime_0["world"];
    const _registry_0 = _runtime_0["registry"];
    const _readers_0 = _runtime_0["readers"];
    const _clock_0 = _runtime_0["clock"];
    const _audit_0 = _runtime_0["audit"];
    const _style_0 = _runtime_0["style"];
    const _escaped_0 = _runtime_0["escaped"];
    const _observations_0 = _runtime_0["observations"];
    const _nextMode_0 = _runtime_0["nextMode"];
    return $dispatcher$058tick_frame$1265$(_nodes_0, _registry_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($host$058prototype_slot_host_health_frame$(_world_0, _readers_0, ($readers$058frame$(_clock_0)))));
  } else {
    return run_clo((_x_0) => {
  return $IO$pure$({$: "dispatcher.Dispatched", "runtime": _runtime_0, "outcome": {$: "dispatcher.MissingRuntimeRequirements", "requirements": _missing_0}}, _x_0);
});
  }
}

function $payload$058four_c$(_a_0, _b_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _c_0 = _result_0["snd"];
  return $payload$058four_done$(_a_0, _b_0, _c_0, {$: "Tuple", fst: _array_0, snd: _array_0[3 % _array_0.length]});
}

function $dispatcher$058run$1263$(_nodes_0, _runtime_0) {
  if (_nodes_0.$ === "Nil") {
    return run_clo((_x_0) => {
  return $IO$pure$({$: "dispatcher.Dispatched", "runtime": _runtime_0, "outcome": {$: "dispatcher.Complete"}}, _x_0);
});
  } else {
    const _t_0 = _nodes_0["head"];
    if (_t_0.$ === "schedule.Nested") {
      const _nested_0 = _t_0["steps"];
      const _tail_0 = _nodes_0["tail"];
      return run_clo((_x_1) => {
  return $IO$bind$(($dispatcher$058run$1263$(_nested_0, _runtime_0)), run_clo((_x_2) => {
  return $dispatcher$058continue_case$(run_clo((_x_3) => {
  return $dispatcher$058run$1263$(_tail_0, _x_3);
}), _x_2);
}), _x_1);
});
    } else if (_t_0.$ === "schedule.Call") {
      const _system_0 = _t_0["system"];
      const _mode_0 = _t_0["mode"];
      const _tail_1 = _nodes_0["tail"];
      return run_clo((_x_4) => {
  return $IO$bind$(($dispatcher$058call$1263$(_system_0, _mode_0, _runtime_0)), run_clo((_x_5) => {
  return $dispatcher$058continue_case$(run_clo((_x_6) => {
  return $dispatcher$058run$1263$(_tail_1, _x_6);
}), _x_5);
}), _x_4);
});
    } else if (_t_0.$ === "schedule.Deferred") {
      const _tail_2 = _nodes_0["tail"];
      return run_clo((_x_7) => {
  return $IO$bind$(($dispatcher$058deferred$1263$(_runtime_0)), run_clo((_x_8) => {
  return $dispatcher$058run$1263$(_tail_2, _x_8);
}), _x_7);
});
    } else {
      const _tail_3 = _nodes_0["tail"];
      return run_clo((_x_9) => {
  return $IO$bind$(($dispatcher$058state_transition$1263$(_runtime_0)), run_clo((_x_10) => {
  return $dispatcher$058run$1263$(_tail_3, _x_10);
}), _x_9);
});
    }
  }
}

function $host$058frame$(_owner_0, _readers_0, _boundary_0) {
  const _world_0 = _owner_0["world"];
  const _logs_0 = _owner_0["logs"];
  const _bindings_0 = _owner_0["bindings"];
  const _worldName_0 = _owner_0["worldName"];
  const _step_0 = _owner_0["step"];
  const _prior_0 = _owner_0["prior"];
  const _events_0 = _owner_0["events"];
  return $host$058frame_return$(_world_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, ($reader$045host$058frame$(_logs_0, _readers_0, _boundary_0)));
}

function $readers$058frame_case$(_old_0, _now_0, _start_0, _retained_0, _number_0) {
  if (_old_0) {
    return {$: "readers.Frame", "clock": {$: "readers.Clock", "tick": _now_0, "frameStart": _now_0, "retainedAfter": _start_0, "frameNo": ((_number_0 + 1) >>> 0)}, "lifecycle": {$: "Some", "value": _start_0}, "messages": _start_0};
  } else {
    return {$: "readers.Frame", "clock": {$: "readers.Clock", "tick": _now_0, "frameStart": _now_0, "retainedAfter": _retained_0, "frameNo": ((_number_0 + 1) >>> 0)}, "lifecycle": {$: "None"}, "messages": _retained_0};
  }
}

function $dispatcher$058union_acc$($0, $1) {
  for (;;) {
    {
      const _other_0 = $0;
      const _values_0 = $1;
      if (_other_0.$ === "Nil") {
        return _values_0;
      } else {
        const _head_0 = _other_0["head"];
        const _tail_0 = _other_0["tail"];
        $0 = _tail_0;
        $1 = ($dispatcher$058unique_case$(($dispatcher$058contains$(_head_0, _values_0)), _head_0, _values_0));
        continue;
      }
    }
  }
}

function $dispatcher$058missing_case$(_wanted_0, _present_0, _value_0) {
  if (_wanted_0) {
    if (!_present_0) {
      return {$: "Con", "head": _value_0, "tail": {$: "Nil"}};
    } else {
      return {$: "Nil"};
    }
  } else {
    return {$: "Nil"};
  }
}

function $dispatcher$058tick_frame$1265$(_nodes_0, _registry_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _owners_0) {
  const _world_0 = _owners_0["fst"];
  const _t_0 = _owners_0["snd"];
  const _readers_0 = _t_0["fst"];
  const _clock_0 = _t_0["snd"];
  return $dispatcher$058run$1265$(_nodes_0, {$: "dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0});
}

function $payload$058four_done$(_a_0, _b_0, _c_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _d_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _array_0, "snd": {$: "types.Four", "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0}};
}

function $dispatcher$058continue_case$(_continuation_0, _result_0) {
  const _runtime_0 = _result_0["runtime"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "dispatcher.Complete") {
    return run_tail(_continuation_0, _runtime_0);
  } else {
    return run_clo((_x_0) => {
  return $IO$pure$({$: "dispatcher.Dispatched", "runtime": _runtime_0, "outcome": _t_0}, _x_0);
});
  }
}

function $dispatcher$058call$1263$(_system_0, _mode_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _registry_0 = _runtime_0["registry"];
  const _readers_0 = _runtime_0["readers"];
  const _clock_0 = _runtime_0["clock"];
  const _audit_0 = _runtime_0["audit"];
  const _style_0 = _runtime_0["style"];
  const _escaped_0 = _runtime_0["escaped"];
  const _observations_0 = _runtime_0["observations"];
  const _nextMode_0 = _runtime_0["nextMode"];
  return run_clo((_x_0) => {
  return $IO$bind$(($dispatcher$058call_presence$1263$(_system_0, _mode_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($host$058prototype_slot_host_health_presence$(_world_0)))), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$pure$(($dispatcher$058record_mode$(_system_0, _x_1)), _x_2);
});
}), _x_0);
});
}

function $dispatcher$058deferred$1263$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _registry_0 = _runtime_0["registry"];
  const _readers_0 = _runtime_0["readers"];
  const _clock_0 = _runtime_0["clock"];
  const _audit_0 = _runtime_0["audit"];
  const _style_0 = _runtime_0["style"];
  const _escaped_0 = _runtime_0["escaped"];
  const _observations_0 = _runtime_0["observations"];
  const _nextMode_0 = _runtime_0["nextMode"];
  return run_clo((_x_0) => {
  return $IO$bind$(($host$058prototype_slot_host_health_barrier$(_world_0, _clock_0)), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$pure$(($dispatcher$058marker_done$(_registry_0, _readers_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _x_1)), _x_2);
});
}), _x_0);
});
}

function $dispatcher$058state_transition$1263$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _registry_0 = _runtime_0["registry"];
  const _readers_0 = _runtime_0["readers"];
  const _clock_0 = _runtime_0["clock"];
  const _audit_0 = _runtime_0["audit"];
  const _style_0 = _runtime_0["style"];
  const _escaped_0 = _runtime_0["escaped"];
  const _observations_0 = _runtime_0["observations"];
  const _nextMode_0 = _runtime_0["nextMode"];
  return run_clo((_x_0) => {
  return $IO$bind$(($host$058prototype_slot_host_health_barrier$(_world_0, _clock_0)), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$pure$(($dispatcher$058marker_done$(_registry_0, _readers_0, _audit_0, _style_0, _escaped_0, _observations_0, {$: "None"}, ($dispatcher$058transition_after$1263$(_nextMode_0, _x_1)))), _x_2);
});
}), _x_0);
});
}

function $host$058frame_return$(_world_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _result_0) {
  const _logs_0 = _result_0["logs"];
  const _readers_0 = _result_0["readers"];
  const _clock_0 = _result_0["clock"];
  return {$: "Tuple", "fst": {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, "snd": {$: "Tuple", "fst": _readers_0, "snd": _clock_0}};
}

function $reader$045host$058frame$(_logs_0, _readers_0, _frame_0) {
  const _ping_0 = _logs_0["ping"];
  const _removed_0 = _logs_0["removed"];
  const _despawned_0 = _logs_0["despawned"];
  const _clock_0 = _frame_0["clock"];
  const _window_0 = _frame_0["lifecycle"];
  const _messageWindow_0 = _frame_0["messages"];
  return $reader$045host$058frame_ping$(_ping_0, _removed_0, _despawned_0, _clock_0, _window_0, _messageWindow_0, ($readers$058holders$(_readers_0, {$: "readers.Messages"})));
}

function $dispatcher$058unique_case$(_found_0, _value_0, _values_0) {
  if (_found_0) {
    return _values_0;
  } else {
    return $List$append$(_values_0, {$: "Con", "head": _value_0, "tail": {$: "Nil"}});
  }
}

function $dispatcher$058contains$(_value_0, _values_0) {
  if (_values_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _values_0["head"];
    const _tail_0 = _values_0["tail"];
    const _x_0 = ($dispatcher$058requirement_equal$(_value_0, _head_0));
    const _x_1 = ($dispatcher$058contains$(_value_0, _tail_0));
    return (_x_0 || _x_1);
  }
}

function $dispatcher$058run$1265$(_nodes_0, _runtime_0) {
  if (_nodes_0.$ === "Nil") {
    return run_clo((_x_0) => {
  return $IO$pure$({$: "dispatcher.Dispatched", "runtime": _runtime_0, "outcome": {$: "dispatcher.Complete"}}, _x_0);
});
  } else {
    const _t_0 = _nodes_0["head"];
    if (_t_0.$ === "schedule.Nested") {
      const _nested_0 = _t_0["steps"];
      const _tail_0 = _nodes_0["tail"];
      return run_clo((_x_1) => {
  return $IO$bind$(($dispatcher$058run$1265$(_nested_0, _runtime_0)), run_clo((_x_2) => {
  return $dispatcher$058continue_case$(run_clo((_x_3) => {
  return $dispatcher$058run$1265$(_tail_0, _x_3);
}), _x_2);
}), _x_1);
});
    } else if (_t_0.$ === "schedule.Call") {
      const _system_0 = _t_0["system"];
      const _mode_0 = _t_0["mode"];
      const _tail_1 = _nodes_0["tail"];
      return run_clo((_x_4) => {
  return $IO$bind$(($dispatcher$058call$1265$(_system_0, _mode_0, _runtime_0)), run_clo((_x_5) => {
  return $dispatcher$058continue_case$(run_clo((_x_6) => {
  return $dispatcher$058run$1265$(_tail_1, _x_6);
}), _x_5);
}), _x_4);
});
    } else if (_t_0.$ === "schedule.Deferred") {
      const _tail_2 = _nodes_0["tail"];
      return run_clo((_x_7) => {
  return $IO$bind$(($dispatcher$058deferred$1263$(_runtime_0)), run_clo((_x_8) => {
  return $dispatcher$058run$1265$(_tail_2, _x_8);
}), _x_7);
});
    } else {
      const _tail_3 = _nodes_0["tail"];
      return run_clo((_x_9) => {
  return $IO$bind$(($dispatcher$058state_transition$1263$(_runtime_0)), run_clo((_x_10) => {
  return $dispatcher$058run$1265$(_tail_3, _x_10);
}), _x_9);
});
    }
  }
}

function $dispatcher$058call_presence$1263$(_system_0, _mode_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _actual_0 = _pair_0["snd"];
  return $dispatcher$058call_actual$1263$(_system_0, _mode_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _world_0, _actual_0);
}

function $dispatcher$058record_mode$(_system_0, _result_0) {
  const _kind_0 = _system_0["kind"];
  const _t_0 = _result_0["runtime"];
  const _world_0 = _t_0["world"];
  const _registry_0 = _t_0["registry"];
  const _readers_0 = _t_0["readers"];
  const _clock_0 = _t_0["clock"];
  const _audit_0 = _t_0["audit"];
  const _style_0 = _t_0["style"];
  const _escaped_0 = _t_0["escaped"];
  const _observations_0 = _t_0["observations"];
  const _nextMode_0 = _t_0["nextMode"];
  const _t_1 = _result_0["outcome"];
  if (_t_1.$ === "dispatcher.Complete") {
    return {$: "dispatcher.Dispatched", "runtime": {$: "dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": ($dispatcher$058pending_kind$(_kind_0, _nextMode_0))}, "outcome": {$: "dispatcher.Complete"}};
  } else {
    return {$: "dispatcher.Dispatched", "runtime": {$: "dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0}, "outcome": _t_1};
  }
}

function $host$058prototype_slot_host_health_barrier$(_owner_0, _clock_0) {
  return $host$058barrier$(_owner_0, _clock_0);
}

function $dispatcher$058marker_done$(_registry_0, _readers_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _owners_0) {
  const _world_0 = _owners_0["fst"];
  const _clock_0 = _owners_0["snd"];
  return {$: "dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0};
}

function $dispatcher$058transition_after$1263$(_nextMode_0, _owners_0) {
  const _world_0 = _owners_0["fst"];
  const _clock_0 = _owners_0["snd"];
  return $host$058prototype_slot_host_health_transition$(_world_0, _nextMode_0, _clock_0);
}

function $reader$045host$058frame_ping$(_ping_0, _removed_0, _despawned_0, _clock_0, _window_0, _messageWindow_0, _result_0) {
  const _readers_0 = _result_0["fst"];
  const _holds_0 = _result_0["snd"];
  return $reader$045host$058frame_removed$(($streams$058trim$(_ping_0, _messageWindow_0, _holds_0)), _removed_0, _despawned_0, _clock_0, _window_0, ($readers$058holders$(_readers_0, {$: "readers.Removed", "component": 0})));
}

function $readers$058holders$(_readers_0, _kind_0) {
  const _slots_0 = _readers_0["slots"];
  return {$: "Tuple", "fst": {$: "readers.Readers", "slots": _slots_0}, "snd": ($readers$058collect$(_kind_0, _slots_0))};
}

function $dispatcher$058requirement_equal$(_left_0, _right_0) {
  if (_left_0.$ === "dispatcher.ResourceRequired") {
    const _a_0 = _left_0["name"];
    if (_right_0.$ === "dispatcher.ResourceRequired") {
      const _b_0 = _right_0["name"];
      return $String$eq$(_a_0, _b_0);
    } else {
      return false;
    }
  } else if (_left_0.$ === "dispatcher.ServiceRequired") {
    const _a_1 = _left_0["name"];
    if (_right_0.$ === "dispatcher.ServiceRequired") {
      const _b_1 = _right_0["name"];
      return $String$eq$(_a_1, _b_1);
    } else {
      return false;
    }
  } else {
    const _a_2 = _left_0["name"];
    if (_right_0.$ === "dispatcher.StateRequired") {
      const _b_2 = _right_0["name"];
      return $String$eq$(_a_2, _b_2);
    } else {
      return false;
    }
  }
}

function $dispatcher$058call$1265$(_system_0, _mode_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _registry_0 = _runtime_0["registry"];
  const _readers_0 = _runtime_0["readers"];
  const _clock_0 = _runtime_0["clock"];
  const _audit_0 = _runtime_0["audit"];
  const _style_0 = _runtime_0["style"];
  const _escaped_0 = _runtime_0["escaped"];
  const _observations_0 = _runtime_0["observations"];
  const _nextMode_0 = _runtime_0["nextMode"];
  return run_clo((_x_0) => {
  return $IO$bind$(($dispatcher$058call_presence$1265$(_system_0, _mode_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($host$058prototype_slot_host_health_presence$(_world_0)))), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$pure$(($dispatcher$058record_mode$(_system_0, _x_1)), _x_2);
});
}), _x_0);
});
}

function $dispatcher$058call_actual$1263$(_system_0, _mode_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _world_0, _actual_0) {
  const _base_0 = _system_0["base"];
  const _name_0 = _system_0["name"];
  const _kind_0 = _system_0["kind"];
  const _ledger_0 = _system_0["ledger"];
  const _service_0 = _system_0["audit"];
  const _gated_0 = _system_0["gated"];
  const _reader_0 = _system_0["reader"];
  const _on_0 = _actual_0["modeOn"];
  const _x_0 = ($Bool$not$(_gated_0));
  return $dispatcher$058leaf_condition$1263$((_x_0 || _on_0), {$: "schedule.System", "base": _base_0, "name": _name_0, "kind": _kind_0, "ledger": _ledger_0, "audit": _service_0, "gated": _gated_0, "reader": _reader_0}, _mode_0, {$: "dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0});
}

function $dispatcher$058pending_kind$(_kind_0, _previous_0) {
  if (_kind_0.$ === "schedule.SetOn") {
    return {$: "Some", "value": true};
  } else if (_kind_0.$ === "schedule.SetOff") {
    return {$: "Some", "value": false};
  } else {
    return _previous_0;
  }
}

function $host$058barrier$(_owner_0, _clock_0) {
  const _world_0 = _owner_0["world"];
  const _logs_0 = _owner_0["logs"];
  const _bindings_0 = _owner_0["bindings"];
  const _worldName_0 = _owner_0["worldName"];
  const _step_0 = _owner_0["step"];
  const _prior_0 = _owner_0["prior"];
  const _events_0 = _owner_0["events"];
  const _next_0 = ($readers$058advance$(_clock_0));
  return $host$058barrier_applied$(_logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _next_0, ($commands$058apply_checked$(_world_0, ($dispatcher$058clock_tick$(_next_0)))));
}

function $host$058prototype_slot_host_health_transition$(_owner_0, _pending_0, _clock_0) {
  const _t_0 = _owner_0["world"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["next"];
  const _rows_0 = _t_0["rows"];
  const _commands_0 = _t_0["pending"];
  const _ledger_0 = _t_0["ledger"];
  const __0 = _t_0["mode"];
  const _logs_0 = _owner_0["logs"];
  const _bindings_0 = _owner_0["bindings"];
  const _worldName_0 = _owner_0["worldName"];
  const _step_0 = _owner_0["step"];
  const _prior_0 = _owner_0["prior"];
  const _events_0 = _owner_0["events"];
  if (_pending_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "host.Host", "world": {$: "storage.World", "namespace": _ns_0, "next": _next_0, "rows": _rows_0, "pending": _commands_0, "ledger": _ledger_0, "mode": __0}, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, "snd": _clock_0};
  } else {
    const _value_0 = _pending_0["value"];
    return {$: "Tuple", "fst": {$: "host.Host", "world": {$: "storage.World", "namespace": _ns_0, "next": _next_0, "rows": _rows_0, "pending": _commands_0, "ledger": _ledger_0, "mode": ($host$058prototype_slot_host_health_desired$(_value_0))}, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, "snd": ($readers$058advance$(_clock_0))};
  }
}

function $reader$045host$058frame_removed$(_ping_0, _removed_0, _despawned_0, _clock_0, _window_0, _result_0) {
  const _readers_0 = _result_0["fst"];
  const _holds_0 = _result_0["snd"];
  return $reader$045host$058frame_despawned$(_ping_0, ($reader$045host$058life_trim$(_removed_0, _window_0, _holds_0)), _despawned_0, _clock_0, _window_0, ($readers$058holders$(_readers_0, {$: "readers.Despawned"})));
}

function $streams$058trim$(_log_0, _window_0, _holders_0) {
  const _buffer_0 = _log_0["buffer"];
  return {$: "streams.PingLog", "buffer": ($streams$058trim_buffer$(_buffer_0, _window_0, _holders_0))};
}

function $readers$058collect$(_kind_0, _slots_0) {
  if (_slots_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _slots_0["head"];
    const _interests_0 = _t_0["interests"];
    const _state_0 = _t_0["state"];
    const _tail_0 = _slots_0["tail"];
    return $readers$058held$(($readers$058interested$(_kind_0, _interests_0)), ($readers$058position$(_kind_0, _state_0)), ($readers$058collect$(_kind_0, _tail_0)));
  }
}

function $dispatcher$058call_presence$1265$(_system_0, _mode_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _actual_0 = _pair_0["snd"];
  return $dispatcher$058call_actual$1265$(_system_0, _mode_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _world_0, _actual_0);
}

function $dispatcher$058leaf_condition$1263$(_allowed_0, _system_0, _mode_0, _runtime_0) {
  if (!_allowed_0) {
    const _base_0 = _system_0["base"];
    const _world_0 = _runtime_0["world"];
    const _registry_0 = _runtime_0["registry"];
    const _readers_0 = _runtime_0["readers"];
    const _clock_0 = _runtime_0["clock"];
    const _audit_0 = _runtime_0["audit"];
    const _style_0 = _runtime_0["style"];
    const _escaped_0 = _runtime_0["escaped"];
    const _observations_0 = _runtime_0["observations"];
    const _nextMode_0 = _runtime_0["nextMode"];
    return run_clo((_x_0) => {
  return $IO$pure$({$: "dispatcher.Dispatched", "runtime": {$: "dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": ($readers$058skip$(_readers_0, _base_0, ($dispatcher$058clock_tick$(_clock_0)))), "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0}, "outcome": {$: "dispatcher.Complete"}}, _x_0);
});
  } else {
    const _base_1 = _system_0["base"];
    const _reader_0 = _system_0["reader"];
    return $dispatcher$058leaf_reader$1263$(_reader_0, _base_1, _mode_0, _runtime_0);
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $readers$058advance$(_clock_0) {
  const _now_0 = _clock_0["tick"];
  const _frame_0 = _clock_0["frameStart"];
  const _retained_0 = _clock_0["retainedAfter"];
  const _number_0 = _clock_0["frameNo"];
  return {$: "readers.Clock", "tick": ((_now_0 + 1) >>> 0), "frameStart": _frame_0, "retainedAfter": _retained_0, "frameNo": _number_0};
}

function $host$058barrier_applied$(_logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _clock_0, _result_0) {
  if (_result_0.$ === "commands.Applied") {
    const _world_0 = _result_0["world"];
    const _changes_0 = _result_0["changes"];
    return run_clo((_x_0) => {
  return $IO$pure$({$: "Tuple", "fst": {$: "host.Host", "world": _world_0, "logs": ($reader$045host$058append_changes$(_logs_0, ($dispatcher$058clock_tick$(_clock_0)), _changes_0)), "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, "snd": _clock_0}, _x_0);
});
  } else if (_result_0.$ === "commands.CapacityRejected") {
    return run_clo((_x_1) => {
  return $IO$die$(20, "indexed capacity capability rejected", _x_1);
});
  } else {
    return run_clo((_x_2) => {
  return $IO$die$(21, "indexed placement invariant failed", _x_2);
});
  }
}

function $commands$058apply_checked$(_world_0, _tick_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $commands$058preflight_world$(_namespace_0, _next_0, _ledger_0, _mode_0, _tick_0, ($commands$058preflight$(_pending_0, _rows_0)));
}

function $host$058prototype_slot_host_health_desired$(_value_0) {
  if (_value_0) {
    return {$: "types.HealthOn"};
  } else {
    return {$: "types.HealthOff"};
  }
}

function $reader$045host$058frame_despawned$(_ping_0, _removed_0, _despawned_0, _clock_0, _window_0, _result_0) {
  const _readers_0 = _result_0["fst"];
  const _holds_0 = _result_0["snd"];
  return {$: "reader-host.Framed", "logs": {$: "reader-host.Logs", "ping": _ping_0, "removed": _removed_0, "despawned": ($reader$045host$058life_trim$(_despawned_0, _window_0, _holds_0))}, "readers": _readers_0, "clock": _clock_0};
}

function $reader$045host$058life_trim$(_log_0, _window_0, _holds_0) {
  if (_window_0.$ === "None") {
    return _log_0;
  } else {
    const _tick_0 = _window_0["value"];
    return $streams$058trim_lifecycle$(_log_0, _tick_0, _holds_0);
  }
}

function $streams$058trim_buffer$(_buffer_0, _window_0, _holders_0) {
  const _capacity_0 = _buffer_0["capacity"];
  const _size_0 = _buffer_0["size"];
  const _dropped_0 = _buffer_0["dropped"];
  const _front_0 = _buffer_0["front"];
  const _rear_0 = _buffer_0["rear"];
  const _oldest_0 = ($streams$058boundary$(_holders_0, _window_0));
  return $streams$058trim_second$(_capacity_0, _oldest_0, _rear_0, run_loop($streams$058trim_front$(_front_0, _capacity_0, _oldest_0, _size_0, _dropped_0)));
}

function $readers$058held$(_yes_0, _value_0, _tail_0) {
  if (_yes_0) {
    return {$: "Con", "head": _value_0, "tail": _tail_0};
  } else {
    return _tail_0;
  }
}

function $readers$058interested$(_kind_0, _interests_0) {
  if (_kind_0.$ === "readers.Messages") {
    const _yes_0 = _interests_0["messages"];
    return _yes_0;
  } else if (_kind_0.$ === "readers.Removed") {
    const _component_0 = _kind_0["component"];
    const _components_0 = _interests_0["removed"];
    return $readers$058contains$(_component_0, _components_0);
  } else {
    const _yes_1 = _interests_0["despawned"];
    return _yes_1;
  }
}

function $readers$058position$(_kind_0, _state_0) {
  if (_kind_0.$ === "readers.Messages") {
    const _stream_0 = _state_0["streamLastRun"];
    return _stream_0;
  } else {
    const _last_0 = _state_0["lastRun"];
    return _last_0;
  }
}

function $dispatcher$058call_actual$1265$(_system_0, _mode_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _world_0, _actual_0) {
  const _base_0 = _system_0["base"];
  const _name_0 = _system_0["name"];
  const _kind_0 = _system_0["kind"];
  const _ledger_0 = _system_0["ledger"];
  const _service_0 = _system_0["audit"];
  const _gated_0 = _system_0["gated"];
  const _reader_0 = _system_0["reader"];
  const _on_0 = _actual_0["modeOn"];
  const _x_0 = ($Bool$not$(_gated_0));
  return $dispatcher$058leaf_condition$1265$((_x_0 || _on_0), {$: "schedule.System", "base": _base_0, "name": _name_0, "kind": _kind_0, "ledger": _ledger_0, "audit": _service_0, "gated": _gated_0, "reader": _reader_0}, _mode_0, {$: "dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0});
}

function $readers$058skip$(_readers_0, _key_0, _now_0) {
  const _slots_0 = _readers_0["slots"];
  return $readers$058skip_found$(_key_0, _now_0, _slots_0, ($readers$058find$(_key_0, _slots_0)));
}

function $dispatcher$058leaf_reader$1263$(_reader_0, _base_0, _mode_0, _runtime_0) {
  if (_reader_0) {
    const _world_0 = _runtime_0["world"];
    const _registry_0 = _runtime_0["registry"];
    const _readers_0 = _runtime_0["readers"];
    const _clock_0 = _runtime_0["clock"];
    const _audit_0 = _runtime_0["audit"];
    const _style_0 = _runtime_0["style"];
    const _escaped_0 = _runtime_0["escaped"];
    const _observations_0 = _runtime_0["observations"];
    const _nextMode_0 = _runtime_0["nextMode"];
    return $dispatcher$058leaf_started$1263$(_base_0, _mode_0, _world_0, _registry_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($readers$058begin$(_readers_0, _base_0, {$: "readers.Interests", "messages": true, "removed": {$: "Con", "head": 0, "tail": {$: "Nil"}}, "despawned": true}, _clock_0)));
  } else {
    const _world_1 = _runtime_0["world"];
    const _registry_1 = _runtime_0["registry"];
    const _readers_1 = _runtime_0["readers"];
    const _clock_1 = _runtime_0["clock"];
    const _audit_1 = _runtime_0["audit"];
    const _style_1 = _runtime_0["style"];
    const _escaped_1 = _runtime_0["escaped"];
    const _observations_1 = _runtime_0["observations"];
    const _nextMode_1 = _runtime_0["nextMode"];
    return $dispatcher$058leaf_unread$1263$(_base_0, _mode_0, _world_1, _registry_1, _readers_1, ($readers$058advance$(_clock_1)), _audit_1, _style_1, _escaped_1, _observations_1, _nextMode_1);
  }
}

function $reader$045host$058append_changes$(_logs_0, _tick_0, _changes_0) {
  return $reader$045host$058append_all$(_changes_0, _tick_0, _logs_0);
}

function $IO$die$(_code_0, _msg_0, _k_0) {
  return {$: "Halt", "code": _code_0, "message": _msg_0};
}

function $commands$058preflight_world$(_namespace_0, _next_0, _ledger_0, _mode_0, _tick_0, _result_0) {
  const _rows_0 = _result_0["rows"];
  const _pending_0 = _result_0["commands"];
  const _t_0 = _result_0["valid"];
  if (!_t_0) {
    return {$: "commands.CapacityRejected", "world": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}};
  } else {
    return $commands$058batch_world$(_namespace_0, _next_0, _ledger_0, _mode_0, ($commands$058batch$(($List$reverse$(_pending_0)), _namespace_0, _tick_0, {$: "commands.Running", "rows": _rows_0, "reverseChanges": {$: "Nil"}})));
  }
}

function $commands$058preflight$(_commands_0, _rows_0) {
  return $commands$058preflight_go$(_commands_0, {$: "commands.Preflight", "rows": _rows_0, "commands": {$: "Nil"}, "valid": true});
}

function $streams$058trim_lifecycle$(_log_0, _window_0, _holders_0) {
  const _buffer_0 = _log_0["buffer"];
  return {$: "streams.LifeLog", "buffer": ($streams$058trim_buffer$(_buffer_0, _window_0, _holders_0))};
}

function $streams$058boundary$($0, $1) {
  for (;;) {
    {
      const _holders_0 = $0;
      const _window_0 = $1;
      if (_holders_0.$ === "Nil") {
        return _window_0;
      } else {
        const _head_0 = _holders_0["head"];
        const _tail_0 = _holders_0["tail"];
        $0 = _tail_0;
        $1 = ($streams$058minimum$(_window_0, _head_0));
        continue;
      }
    }
  }
}

function $streams$058trim_second$(_capacity_0, _window_0, _rear_0, _cut_0) {
  const _t_0 = _cut_0["front"];
  if (_t_0.$ === "Nil") {
    const _size_0 = _cut_0["size"];
    const _dropped_0 = _cut_0["dropped"];
    return $streams$058finish_cut$(_capacity_0, run_loop($streams$058trim_front$(($List$reverse$(_rear_0)), _capacity_0, _window_0, _size_0, _dropped_0)));
  } else {
    const _head_0 = _t_0["head"];
    const _tail_0 = _t_0["tail"];
    const _size_1 = _cut_0["size"];
    const _dropped_1 = _cut_0["dropped"];
    return {$: "streams.Buffer", "capacity": _capacity_0, "size": _size_1, "dropped": _dropped_1, "front": {$: "Con", "head": _head_0, "tail": _tail_0}, "rear": _rear_0};
  }
}

function $streams$058trim_front$(_front_0, _capacity_0, _window_0, _size_0, _dropped_0) {
  if (_front_0.$ === "Nil") {
    return {$: "streams.Cut", "front": {$: "Nil"}, "size": _size_0, "dropped": _dropped_0};
  } else {
    const _t_0 = _front_0["head"];
    const _tick_0 = _t_0["tick"];
    const _n_0 = _t_0["count"];
    const _values_0 = _t_0["values"];
    const _tail_0 = _front_0["tail"];
    const _x_0 = (_tick_0 <= _window_0);
    const _x_1 = (_size_0 > _capacity_0);
    return $streams$058trim_decision$((_x_0 || _x_1), {$: "streams.Batch", "tick": _tick_0, "count": _n_0, "values": _values_0}, _tail_0, _size_0, _dropped_0, run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $streams$058trim_front$(_tail_0, _capacity_0, _window_0, _x_2, _x_3);
});
}));
  }
}

function $readers$058contains$(_key_0, _values_0) {
  if (_values_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _values_0["head"];
    const _tail_0 = _values_0["tail"];
    const _x_0 = (_key_0 === _head_0);
    const _x_1 = ($readers$058contains$(_key_0, _tail_0));
    return (_x_0 || _x_1);
  }
}

function $dispatcher$058leaf_condition$1265$(_allowed_0, _system_0, _mode_0, _runtime_0) {
  if (!_allowed_0) {
    const _base_0 = _system_0["base"];
    const _world_0 = _runtime_0["world"];
    const _registry_0 = _runtime_0["registry"];
    const _readers_0 = _runtime_0["readers"];
    const _clock_0 = _runtime_0["clock"];
    const _audit_0 = _runtime_0["audit"];
    const _style_0 = _runtime_0["style"];
    const _escaped_0 = _runtime_0["escaped"];
    const _observations_0 = _runtime_0["observations"];
    const _nextMode_0 = _runtime_0["nextMode"];
    return run_clo((_x_0) => {
  return $IO$pure$({$: "dispatcher.Dispatched", "runtime": {$: "dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": ($readers$058skip$(_readers_0, _base_0, ($dispatcher$058clock_tick$(_clock_0)))), "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0}, "outcome": {$: "dispatcher.Complete"}}, _x_0);
});
  } else {
    const _base_1 = _system_0["base"];
    const _reader_0 = _system_0["reader"];
    return $dispatcher$058leaf_reader$1265$(_reader_0, _base_1, _mode_0, _runtime_0);
  }
}

function $readers$058skip_found$(_key_0, _now_0, _slots_0, _found_0) {
  if (_found_0.$ === "None") {
    return {$: "readers.Readers", "slots": _slots_0};
  } else {
    const _t_0 = _found_0["value"];
    const _interests_0 = _t_0["interests"];
    const _t_1 = _t_0["state"];
    const _registered_0 = _t_1["registeredAt"];
    const _last_0 = _t_1["lastRun"];
    return {$: "readers.Readers", "slots": ($readers$058replace$(_key_0, {$: "readers.Slot", "key": _key_0, "interests": _interests_0, "state": {$: "types.ReaderState", "registeredAt": _registered_0, "lastRun": _last_0, "streamLastRun": _now_0}}, _slots_0))};
  }
}

function $readers$058find$(_key_0, _slots_0) {
  if (_slots_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _slots_0["head"];
    const _id_0 = _t_0["key"];
    const _interests_0 = _t_0["interests"];
    const _state_0 = _t_0["state"];
    const _tail_0 = _slots_0["tail"];
    return $readers$058find_case$((_key_0 === _id_0), {$: "readers.Slot", "key": _id_0, "interests": _interests_0, "state": _state_0}, ($readers$058find$(_key_0, _tail_0)));
  }
}

function $dispatcher$058leaf_started$1263$(_base_0, _mode_0, _world_0, _registry_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _started_0) {
  const _next_0 = _registry_0["next"];
  const _entries_0 = _registry_0["entries"];
  const _readers_0 = _started_0["readers"];
  const _clock_0 = _started_0["clock"];
  const _run_0 = _started_0["run"];
  return run_clo((_x_0) => {
  return $IO$bind$(($dispatcher$058visit$1263$(_next_0, _base_0, _mode_0, _clock_0, _style_0, _entries_0, _world_0, _audit_0, {$: "Some", "value": _run_0})), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$pure$(($dispatcher$058leaf_done$(_next_0, _readers_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _x_1)), _x_2);
});
}), _x_0);
});
}

function $readers$058begin$(_readers_0, _key_0, _interests_0, _clock_0) {
  return $readers$058begin_clock$(_readers_0, _key_0, _interests_0, _clock_0);
}

function $dispatcher$058leaf_unread$1263$(_base_0, _mode_0, _world_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0) {
  const _next_0 = _registry_0["next"];
  const _entries_0 = _registry_0["entries"];
  return run_clo((_x_0) => {
  return $IO$bind$(($dispatcher$058visit$1263$(_next_0, _base_0, _mode_0, _clock_0, _style_0, _entries_0, _world_0, _audit_0, {$: "None"})), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$pure$(($dispatcher$058leaf_done$(_next_0, _readers_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _x_1)), _x_2);
});
}), _x_0);
});
}

function $reader$045host$058append_all$($0, $1, $2) {
  for (;;) {
    {
      const _changes_0 = $0;
      const _tick_0 = $1;
      const _logs_0 = $2;
      if (_changes_0.$ === "Nil") {
        return _logs_0;
      } else {
        const _head_0 = _changes_0["head"];
        const _tail_0 = _changes_0["tail"];
        $0 = _tail_0;
        $1 = _tick_0;
        $2 = ($reader$045host$058append_change$(_logs_0, _tick_0, _head_0));
        continue;
      }
    }
  }
}

function $commands$058batch_world$(_namespace_0, _next_0, _ledger_0, _mode_0, _result_0) {
  if (_result_0.$ === "commands.Completed") {
    const _rows_0 = _result_0["rows"];
    const _changes_0 = _result_0["changes"];
    return {$: "commands.Applied", "world": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": {$: "Nil"}, "ledger": _ledger_0, "mode": _mode_0}, "changes": _changes_0};
  } else {
    const _rows_1 = _result_0["rows"];
    const _row_0 = _result_0["row"];
    const _remaining_0 = _result_0["remaining"];
    const _changes_1 = _result_0["changes"];
    return {$: "commands.InvariantFault", "world": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_1, "pending": ($List$reverse$(_remaining_0)), "ledger": _ledger_0, "mode": _mode_0}, "row": _row_0, "changes": _changes_1};
  }
}

function $commands$058batch$($0, $1, $2, $3) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _namespace_0 = $1;
      const _tick_0 = $2;
      const _state_0 = $3;
      if (_commands_0.$ === "Nil") {
        return $commands$058state_finish$(_state_0);
      } else {
        const _command_0 = _commands_0["head"];
        const _tail_0 = _commands_0["tail"];
        $0 = _tail_0;
        $1 = _namespace_0;
        $2 = _tick_0;
        $3 = ($commands$058state_command$(_namespace_0, _tick_0, _command_0, _state_0));
        continue;
      }
    }
  }
}

function $commands$058preflight_go$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _state_0 = $1;
      if (_commands_0.$ === "Nil") {
        const _rows_0 = _state_0["rows"];
        const _reverse_0 = _state_0["commands"];
        const _valid_0 = _state_0["valid"];
        return {$: "commands.Preflight", "rows": _rows_0, "commands": ($List$reverse$(_reverse_0)), "valid": _valid_0};
      } else {
        const _command_0 = _commands_0["head"];
        const _tail_0 = _commands_0["tail"];
        const _rows_1 = _state_0["rows"];
        const _reverse_1 = _state_0["commands"];
        const _valid_1 = _state_0["valid"];
        $0 = _tail_0;
        $1 = ($commands$058preflight_step$(_reverse_1, _valid_1, ($commands$058command_bound$(_rows_1, _command_0))));
        continue;
      }
    }
  }
}

function $streams$058minimum$(_a_0, _b_0) {
  return $streams$058choose_min$((_a_0 < _b_0), _a_0, _b_0);
}

function $streams$058finish_cut$(_capacity_0, _cut_0) {
  const _front_0 = _cut_0["front"];
  const _size_0 = _cut_0["size"];
  const _dropped_0 = _cut_0["dropped"];
  return {$: "streams.Buffer", "capacity": _capacity_0, "size": _size_0, "dropped": _dropped_0, "front": _front_0, "rear": {$: "Nil"}};
}

function $streams$058trim_decision$(_drop_0, _head_0, _tail_0, _size_0, _dropped_0, _ih_0) {
  if (!_drop_0) {
    return {$: "streams.Cut", "front": {$: "Con", "head": _head_0, "tail": _tail_0}, "size": _size_0, "dropped": _dropped_0};
  } else {
    const _tick_0 = _head_0["tick"];
    const _n_0 = _head_0["count"];
    return run_tail(_ih_0(((_size_0 - _n_0) >>> 0)), ($streams$058maximum$(_dropped_0, _tick_0)));
  }
}

function $dispatcher$058leaf_reader$1265$(_reader_0, _base_0, _mode_0, _runtime_0) {
  if (_reader_0) {
    const _world_0 = _runtime_0["world"];
    const _registry_0 = _runtime_0["registry"];
    const _readers_0 = _runtime_0["readers"];
    const _clock_0 = _runtime_0["clock"];
    const _audit_0 = _runtime_0["audit"];
    const _style_0 = _runtime_0["style"];
    const _escaped_0 = _runtime_0["escaped"];
    const _observations_0 = _runtime_0["observations"];
    const _nextMode_0 = _runtime_0["nextMode"];
    return $dispatcher$058leaf_started$1265$(_base_0, _mode_0, _world_0, _registry_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($readers$058begin$(_readers_0, _base_0, {$: "readers.Interests", "messages": true, "removed": {$: "Con", "head": 0, "tail": {$: "Nil"}}, "despawned": true}, _clock_0)));
  } else {
    const _world_1 = _runtime_0["world"];
    const _registry_1 = _runtime_0["registry"];
    const _readers_1 = _runtime_0["readers"];
    const _clock_1 = _runtime_0["clock"];
    const _audit_1 = _runtime_0["audit"];
    const _style_1 = _runtime_0["style"];
    const _escaped_1 = _runtime_0["escaped"];
    const _observations_1 = _runtime_0["observations"];
    const _nextMode_1 = _runtime_0["nextMode"];
    return $dispatcher$058leaf_unread$1265$(_base_0, _mode_0, _world_1, _registry_1, _readers_1, ($readers$058advance$(_clock_1)), _audit_1, _style_1, _escaped_1, _observations_1, _nextMode_1);
  }
}

function $readers$058replace$(_key_0, _value_0, _slots_0) {
  if (_slots_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _slots_0["head"];
    const _id_0 = _t_0["key"];
    const _interests_0 = _t_0["interests"];
    const _state_0 = _t_0["state"];
    const _tail_0 = _slots_0["tail"];
    return $readers$058replace_case$((_key_0 === _id_0), {$: "readers.Slot", "key": _id_0, "interests": _interests_0, "state": _state_0}, ($readers$058replace$(_key_0, _value_0, _tail_0)), _value_0);
  }
}

function $readers$058find_case$(_hit_0, _head_0, _rest_0) {
  if (_hit_0) {
    return {$: "Some", "value": _head_0};
  } else {
    return _rest_0;
  }
}

function $dispatcher$058visit$1263$(_fuel_0, _base_0, _mode_0, _clock_0, _style_0, _entries_0, _world_0, _audit_0, _run_0) {
  if (_fuel_0 === 0) {
    return run_clo((_x_0) => {
  return $IO$pure$({$: "dispatcher.Visit", "world": _world_0, "audit": _audit_0, "run": _run_0, "entries": _entries_0, "outcome": {$: "dispatcher.SetupRejected", "reason": "system-search bound"}, "clock": _clock_0, "escaped": {$: "None"}, "observations": {$: "Nil"}}, _x_0);
});
  } else {
    const _rest_0 = (_fuel_0 - 1);
    if (_entries_0.$ === "Nil") {
      return run_clo((_x_1) => {
  return $IO$pure$({$: "dispatcher.Visit", "world": _world_0, "audit": _audit_0, "run": _run_0, "entries": {$: "Nil"}, "outcome": {$: "dispatcher.SetupRejected", "reason": "unregistered base"}, "clock": _clock_0, "escaped": {$: "None"}, "observations": {$: "Nil"}}, _x_1);
});
    } else {
      const _t_0 = _entries_0["head"];
      const _t_1 = _t_0["system"];
      const _key_0 = _t_1["base"];
      const _name_0 = _t_1["name"];
      const _kind_0 = _t_1["kind"];
      const _ledger_0 = _t_1["ledger"];
      const _service_0 = _t_1["audit"];
      const _gated_0 = _t_1["gated"];
      const _reader_0 = _t_1["reader"];
      const _local_0 = _t_0["local"];
      const _tail_0 = _entries_0["tail"];
      return $dispatcher$058visit_decide$1263$(run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return run_clo((_x_4) => {
  return run_clo((_x_5) => {
  return $dispatcher$058visit$1263$(_rest_0, _base_0, _mode_0, _clock_0, _style_0, _x_2, _x_3, _x_4, _x_5);
});
});
});
}), (_base_0 === _key_0), _base_0, _mode_0, _clock_0, _style_0, {$: "schedule.System", "base": _key_0, "name": _name_0, "kind": _kind_0, "ledger": _ledger_0, "audit": _service_0, "gated": _gated_0, "reader": _reader_0}, _local_0, _tail_0, _world_0, _audit_0, _run_0);
    }
  }
}

function $dispatcher$058leaf_done$(_next_0, _readers_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _visit_0) {
  const _world_0 = _visit_0["world"];
  const _audit_0 = _visit_0["audit"];
  const _run_0 = _visit_0["run"];
  const _entries_0 = _visit_0["entries"];
  const _outcome_0 = _visit_0["outcome"];
  const _clock_0 = _visit_0["clock"];
  const _handle_0 = _visit_0["escaped"];
  const _seen_0 = _visit_0["observations"];
  return {$: "dispatcher.Dispatched", "runtime": {$: "dispatcher.Runtime", "world": _world_0, "registry": {$: "schedule.Registry", "next": _next_0, "entries": _entries_0}, "readers": ($dispatcher$058reader_finish$(_readers_0, _run_0, _outcome_0)), "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": ($dispatcher$058add_escape$(_escaped_0, _handle_0)), "observations": ($List$append$(_observations_0, _seen_0)), "nextMode": _nextMode_0}, "outcome": _outcome_0};
}

function $readers$058begin_clock$(_readers_0, _key_0, _interests_0, _clock_0) {
  const _slots_0 = _readers_0["slots"];
  const _now_0 = _clock_0["tick"];
  const _frame_0 = _clock_0["frameStart"];
  const _retained_0 = _clock_0["retainedAfter"];
  const _number_0 = _clock_0["frameNo"];
  return $readers$058begin_slot$(_key_0, _interests_0, _now_0, _slots_0, {$: "readers.Clock", "tick": _now_0, "frameStart": _frame_0, "retainedAfter": _retained_0, "frameNo": _number_0}, ($readers$058find$(_key_0, _slots_0)));
}

function $reader$045host$058append_change$(_logs_0, _tick_0, _change_0) {
  const _ping_0 = _logs_0["ping"];
  const _removed_0 = _logs_0["removed"];
  const _despawned_0 = _logs_0["despawned"];
  if (_change_0.$ === "storage.MainRemoved") {
    const _handle_0 = _change_0["handle"];
    return {$: "reader-host.Logs", "ping": _ping_0, "removed": ($streams$058append_lifecycle$(_removed_0, _tick_0, {$: "Con", "head": _handle_0, "tail": {$: "Nil"}})), "despawned": _despawned_0};
  } else if (_change_0.$ === "storage.Despawned") {
    const _handle_1 = _change_0["handle"];
    return {$: "reader-host.Logs", "ping": _ping_0, "removed": _removed_0, "despawned": ($streams$058append_lifecycle$(_despawned_0, _tick_0, {$: "Con", "head": _handle_1, "tail": {$: "Nil"}}))};
  } else {
    return {$: "reader-host.Logs", "ping": _ping_0, "removed": _removed_0, "despawned": _despawned_0};
  }
}

function $commands$058state_finish$(_state_0) {
  if (_state_0.$ === "commands.Running") {
    const _rows_0 = _state_0["rows"];
    const _changes_0 = _state_0["reverseChanges"];
    return {$: "commands.Completed", "rows": _rows_0, "changes": ($List$reverse$(_changes_0))};
  } else {
    const _rows_1 = _state_0["rows"];
    const _row_0 = _state_0["row"];
    const _remaining_0 = _state_0["reverseRemaining"];
    const _changes_1 = _state_0["changes"];
    return {$: "commands.BatchFault", "rows": _rows_1, "row": _row_0, "remaining": ($List$reverse$(_remaining_0)), "changes": _changes_1};
  }
}

function $commands$058state_command$(_namespace_0, _tick_0, _command_0, _state_0) {
  if (_state_0.$ === "commands.Running") {
    const _rows_0 = _state_0["rows"];
    const _changes_0 = _state_0["reverseChanges"];
    return $commands$058state_step$(_changes_0, ($commands$058step$(_namespace_0, _tick_0, _rows_0, _command_0)));
  } else {
    const _rows_1 = _state_0["rows"];
    const _row_0 = _state_0["row"];
    const _remaining_0 = _state_0["reverseRemaining"];
    const _changes_1 = _state_0["changes"];
    return {$: "commands.Faulted", "rows": _rows_1, "row": _row_0, "reverseRemaining": {$: "Con", "head": _command_0, "tail": _remaining_0}, "changes": _changes_1};
  }
}

function $commands$058preflight_step$(_reverse_0, _valid_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _command_0 = _t_0["fst"];
  const _bounded_0 = _t_0["snd"];
  return {$: "commands.Preflight", "rows": _rows_0, "commands": {$: "Con", "head": _command_0, "tail": _reverse_0}, "valid": ($Bool$and$(_valid_0, _bounded_0))};
}

function $commands$058command_bound$(_rows_0, _command_0) {
  if (_command_0.$ === "storage.Spawn") {
    const _id_0 = _command_0["id"];
    const _bundle_0 = _command_0["bundle"];
    return $commands$058bounded_spawn$(_id_0, _bundle_0, ($storage$058rows_can_place$(_rows_0, _id_0)));
  } else {
    return {$: "Tuple", "fst": _rows_0, "snd": {$: "Tuple", "fst": _command_0, "snd": true}};
  }
}

function $streams$058choose_min$(_smaller_0, _a_0, _b_0) {
  if (_smaller_0) {
    return _a_0;
  } else {
    return _b_0;
  }
}

function $streams$058maximum$(_a_0, _b_0) {
  return $streams$058choose_min$((_a_0 < _b_0), _b_0, _a_0);
}

function $dispatcher$058leaf_started$1265$(_base_0, _mode_0, _world_0, _registry_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _started_0) {
  const _next_0 = _registry_0["next"];
  const _entries_0 = _registry_0["entries"];
  const _readers_0 = _started_0["readers"];
  const _clock_0 = _started_0["clock"];
  const _run_0 = _started_0["run"];
  return run_clo((_x_0) => {
  return $IO$bind$(($dispatcher$058visit$1265$(_next_0, _base_0, _mode_0, _clock_0, _style_0, _entries_0, _world_0, _audit_0, {$: "Some", "value": _run_0})), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$pure$(($dispatcher$058leaf_done$(_next_0, _readers_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _x_1)), _x_2);
});
}), _x_0);
});
}

function $dispatcher$058leaf_unread$1265$(_base_0, _mode_0, _world_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0) {
  const _next_0 = _registry_0["next"];
  const _entries_0 = _registry_0["entries"];
  return run_clo((_x_0) => {
  return $IO$bind$(($dispatcher$058visit$1265$(_next_0, _base_0, _mode_0, _clock_0, _style_0, _entries_0, _world_0, _audit_0, {$: "None"})), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$pure$(($dispatcher$058leaf_done$(_next_0, _readers_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _x_1)), _x_2);
});
}), _x_0);
});
}

function $readers$058replace_case$(_hit_0, _head_0, _tail_0, _value_0) {
  if (_hit_0) {
    return {$: "Con", "head": _value_0, "tail": _tail_0};
  } else {
    return {$: "Con", "head": _head_0, "tail": _tail_0};
  }
}

function $dispatcher$058visit_decide$1263$(_ih_0, _hit_0, _base_0, _mode_0, _clock_0, _style_0, _system_0, _local_0, _tail_0, _world_0, _audit_0, _run_0) {
  if (_hit_0) {
    return $dispatcher$058visit_local$(_system_0, _mode_0, _clock_0, _tail_0, _world_0, _audit_0, _run_0, run_loop($capture$058invoke$(_style_0, _local_0)), run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return run_clo((_x_4) => {
  return run_clo((_x_5) => {
  return run_clo((_x_6) => {
  return $host$058prototype_slot_host_health_invoke$(_x_0, _x_1, _x_2, _x_3, _x_4, _x_5, _x_6);
});
});
});
});
});
});
}));
  } else {
    return run_clo((_x_7) => {
  return $IO$bind$(_ih_0(_tail_0)(_world_0)(_audit_0)(_run_0), run_clo((_x_8) => {
  return run_clo((_x_9) => {
  return $IO$pure$(($dispatcher$058visit_restore$({$: "schedule.Entry", "system": _system_0, "local": _local_0}, _x_8)), _x_9);
});
}), _x_7);
});
  }
}

function $dispatcher$058reader_finish$(_readers_0, _run_0, _outcome_0) {
  if (_run_0.$ === "None") {
    return _readers_0;
  } else {
    const _run_1 = _run_0["value"];
    if (_outcome_0.$ === "dispatcher.Complete") {
      return $readers$058complete$(_readers_0, _run_1, {$: "types.Success"});
    } else if (_outcome_0.$ === "dispatcher.SystemFailure") {
      const _code_0 = _outcome_0["code"];
      return $readers$058complete$(_readers_0, _run_1, {$: "types.Failure", "code": _code_0});
    } else {
      return $readers$058complete$(_readers_0, _run_1, {$: "types.Failure", "code": 7});
    }
  }
}

function $dispatcher$058add_escape$(_escaped_0, _handle_0) {
  if (_handle_0.$ === "None") {
    return _escaped_0;
  } else {
    const _h_0 = _handle_0["value"];
    return $List$append$(_escaped_0, {$: "Con", "head": _h_0, "tail": {$: "Nil"}});
  }
}

function $readers$058begin_slot$(_key_0, _interests_0, _now_0, _slots_0, _clock_0, _found_0) {
  if (_found_0.$ === "None") {
    const _entry_0 = {$: "readers.Slot", "key": _key_0, "interests": _interests_0, "state": {$: "types.ReaderState", "registeredAt": _now_0, "lastRun": 0, "streamLastRun": 0}};
    return $readers$058started$(_key_0, _interests_0, {$: "types.ReaderState", "registeredAt": _now_0, "lastRun": 0, "streamLastRun": 0}, {$: "Con", "head": _entry_0, "tail": _slots_0}, _clock_0);
  } else {
    const _t_0 = _found_0["value"];
    const _saved_0 = _t_0["interests"];
    const _state_0 = _t_0["state"];
    return $readers$058started$(_key_0, _saved_0, _state_0, _slots_0, _clock_0);
  }
}

function $streams$058append_lifecycle$(_log_0, _tick_0, _handles_0) {
  const _buffer_0 = _log_0["buffer"];
  return {$: "streams.LifeLog", "buffer": ($streams$058append_units$(_handles_0, _tick_0, _buffer_0))};
}

function $commands$058state_step$(_reverseChanges_0, _result_0) {
  if (_result_0.$ === "commands.Stepped") {
    const _rows_0 = _result_0["rows"];
    const _changes_0 = _result_0["changes"];
    return {$: "commands.Running", "rows": _rows_0, "reverseChanges": ($List$reverse$go$(_changes_0, _reverseChanges_0))};
  } else {
    const _rows_1 = _result_0["rows"];
    const _row_0 = _result_0["row"];
    return {$: "commands.Faulted", "rows": _rows_1, "row": _row_0, "reverseRemaining": {$: "Nil"}, "changes": ($List$reverse$(_reverseChanges_0))};
  }
}

function $commands$058step$(_namespace_0, _tick_0, _rows_0, _command_0) {
  if (_command_0.$ === "storage.Spawn") {
    const _id_0 = _command_0["id"];
    const _bundle_0 = _command_0["bundle"];
    return $commands$058spawn$(_namespace_0, _tick_0, _id_0, _rows_0, _bundle_0);
  } else if (_command_0.$ === "storage.InsertMain") {
    const _id_1 = _command_0["id"];
    const _main_0 = _command_0["main"];
    return $commands$058main_effect$(_namespace_0, _id_1, ($storage$058rows_replace_main$(_rows_0, _id_1, {$: "Some", "value": _main_0}, _tick_0)));
  } else if (_command_0.$ === "storage.RemoveMain") {
    const _id_2 = _command_0["id"];
    return $commands$058main_effect$(_namespace_0, _id_2, ($storage$058rows_replace_main$(_rows_0, _id_2, {$: "None"}, _tick_0)));
  } else {
    return $commands$058edit_target$(_namespace_0, _tick_0, _rows_0, ($commands$058targeted$(_command_0)));
  }
}

function $commands$058bounded_spawn$(_id_0, _bundle_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _valid_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _rows_0, "snd": {$: "Tuple", "fst": {$: "storage.Spawn", "id": _id_0, "bundle": _bundle_0}, "snd": _valid_0}};
}

function $storage$058rows_can_place$(_rows_0, _id_0) {
  return {$: "Tuple", "fst": _rows_0, "snd": ($Bool$and$((0 < _id_0), (_id_0 <= 131072)))};
}

function $dispatcher$058visit$1265$(_fuel_0, _base_0, _mode_0, _clock_0, _style_0, _entries_0, _world_0, _audit_0, _run_0) {
  if (_fuel_0 === 0) {
    return run_clo((_x_0) => {
  return $IO$pure$({$: "dispatcher.Visit", "world": _world_0, "audit": _audit_0, "run": _run_0, "entries": _entries_0, "outcome": {$: "dispatcher.SetupRejected", "reason": "system-search bound"}, "clock": _clock_0, "escaped": {$: "None"}, "observations": {$: "Nil"}}, _x_0);
});
  } else {
    const _rest_0 = (_fuel_0 - 1);
    if (_entries_0.$ === "Nil") {
      return run_clo((_x_1) => {
  return $IO$pure$({$: "dispatcher.Visit", "world": _world_0, "audit": _audit_0, "run": _run_0, "entries": {$: "Nil"}, "outcome": {$: "dispatcher.SetupRejected", "reason": "unregistered base"}, "clock": _clock_0, "escaped": {$: "None"}, "observations": {$: "Nil"}}, _x_1);
});
    } else {
      const _t_0 = _entries_0["head"];
      const _t_1 = _t_0["system"];
      const _key_0 = _t_1["base"];
      const _name_0 = _t_1["name"];
      const _kind_0 = _t_1["kind"];
      const _ledger_0 = _t_1["ledger"];
      const _service_0 = _t_1["audit"];
      const _gated_0 = _t_1["gated"];
      const _reader_0 = _t_1["reader"];
      const _local_0 = _t_0["local"];
      const _tail_0 = _entries_0["tail"];
      return $dispatcher$058visit_decide$1265$(run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return run_clo((_x_4) => {
  return run_clo((_x_5) => {
  return $dispatcher$058visit$1265$(_rest_0, _base_0, _mode_0, _clock_0, _style_0, _x_2, _x_3, _x_4, _x_5);
});
});
});
}), (_base_0 === _key_0), _base_0, _mode_0, _clock_0, _style_0, {$: "schedule.System", "base": _key_0, "name": _name_0, "kind": _kind_0, "ledger": _ledger_0, "audit": _service_0, "gated": _gated_0, "reader": _reader_0}, _local_0, _tail_0, _world_0, _audit_0, _run_0);
    }
  }
}

function $dispatcher$058visit_local$(_system_0, _mode_0, _clock_0, _tail_0, _world_0, _audit_0, _run_0, _pair_0, _invoke_0) {
  const _local_0 = _pair_0["fst"];
  const _count_0 = _pair_0["snd"];
  return run_clo((_x_0) => {
  return $IO$bind$(_invoke_0(_system_0)(_mode_0)(_count_0)(_clock_0)(_world_0)(_audit_0)(_run_0), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$pure$(($dispatcher$058visit_done$(_system_0, _local_0, _tail_0, _x_1)), _x_2);
});
}), _x_0);
});
}

function $capture$058invoke$(_style_0, _local_0) {
  if (_style_0.$ === "capture.Returned") {
    return $capture$058increment$(_local_0);
  } else {
    return $capture$058call$(run_clo((_x_0) => {
  return $capture$058closure$(_local_0, _x_0);
}));
  }
}

function $host$058prototype_slot_host_health_invoke$(_system_0, _mode_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0) {
  return $host$058prototype_slot_host_health_invoke_count$(_system_0, _mode_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0);
}

function $dispatcher$058visit_restore$(_head_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _audit_0 = _result_0["audit"];
  const _run_0 = _result_0["run"];
  const _entries_0 = _result_0["entries"];
  const _outcome_0 = _result_0["outcome"];
  const _clock_0 = _result_0["clock"];
  const _escaped_0 = _result_0["escaped"];
  const _observations_0 = _result_0["observations"];
  return {$: "dispatcher.Visit", "world": _world_0, "audit": _audit_0, "run": _run_0, "entries": {$: "Con", "head": _head_0, "tail": _entries_0}, "outcome": _outcome_0, "clock": _clock_0, "escaped": _escaped_0, "observations": _observations_0};
}

function $readers$058complete$(_readers_0, _run_0, _outcome_0) {
  if (_outcome_0.$ === "types.Failure") {
    return _readers_0;
  } else {
    return $readers$058completed$(_readers_0, _run_0);
  }
}

function $readers$058started$(_key_0, _interests_0, _state_0, _slots_0, _clock_0) {
  const _at_0 = _state_0["registeredAt"];
  const _last_0 = _state_0["lastRun"];
  const _stream_0 = _state_0["streamLastRun"];
  const _now_0 = _clock_0["tick"];
  const _frame_0 = _clock_0["frameStart"];
  const _retained_0 = _clock_0["retainedAfter"];
  const _number_0 = _clock_0["frameNo"];
  const _next_0 = ((_now_0 + 1) >>> 0);
  return {$: "readers.Started", "readers": {$: "readers.Readers", "slots": _slots_0}, "clock": {$: "readers.Clock", "tick": _next_0, "frameStart": _frame_0, "retainedAfter": _retained_0, "frameNo": _number_0}, "run": {$: "readers.Run", "key": _key_0, "interests": _interests_0, "state": {$: "types.ReaderState", "registeredAt": _at_0, "lastRun": _last_0, "streamLastRun": _stream_0}, "boundary": {$: "types.ReadBoundary", "since": _last_0, "streamSince": _stream_0, "thisRun": _next_0}}};
}

function $streams$058append_units$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _tick_0 = $1;
      const _buffer_0 = $2;
      if (_values_0.$ === "Nil") {
        return _buffer_0;
      } else {
        const _value_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = _tick_0;
        $2 = ($streams$058append_buffer$(_buffer_0, _tick_0, {$: "Con", "head": _value_0, "tail": {$: "Nil"}}));
        continue;
      }
    }
  }
}

function $commands$058spawn$(_namespace_0, _tick_0, _id_0, _rows_0, _bundle_0) {
  const _t_0 = _bundle_0["main"];
  if (_t_0.$ === "None") {
    const _aux_0 = _bundle_0["aux"];
    const _flag_0 = _bundle_0["flag"];
    return $commands$058placed$({$: "Nil"}, ($storage$058rows_place$(_rows_0, {$: "storage.Row", "id": _id_0, "main": {$: "None"}, "aux": _aux_0, "flag": _flag_0, "added": 0, "changed": 0})));
  } else {
    const _main_0 = _t_0["value"];
    const _aux_1 = _bundle_0["aux"];
    const _flag_1 = _bundle_0["flag"];
    return $commands$058placed$({$: "Con", "head": {$: "storage.MainAdded", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Con", "head": {$: "storage.MainChanged", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Nil"}}}, ($storage$058rows_place$(_rows_0, {$: "storage.Row", "id": _id_0, "main": {$: "Some", "value": _main_0}, "aux": _aux_1, "flag": _flag_1, "added": _tick_0, "changed": _tick_0})));
  }
}

function $commands$058main_effect$(_namespace_0, _id_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "storage.AddedMain") {
    return {$: "commands.Stepped", "rows": _rows_0, "changes": {$: "Con", "head": {$: "storage.MainAdded", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Con", "head": {$: "storage.MainChanged", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Nil"}}}};
  } else if (_t_0.$ === "storage.ChangedMain") {
    return {$: "commands.Stepped", "rows": _rows_0, "changes": {$: "Con", "head": {$: "storage.MainChanged", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Nil"}}};
  } else if (_t_0.$ === "storage.RemovedMain") {
    return {$: "commands.Stepped", "rows": _rows_0, "changes": {$: "Con", "head": {$: "storage.MainRemoved", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Nil"}}};
  } else if (_t_0.$ === "storage.MissingMainTarget") {
    return {$: "commands.Stepped", "rows": _rows_0, "changes": {$: "Nil"}};
  } else {
    return {$: "commands.Stepped", "rows": _rows_0, "changes": {$: "Nil"}};
  }
}

function $storage$058rows_replace_main$(_rows_0, _id_0, _replacement_0, _tick_0) {
  const _m_0 = _rows_0["main"];
  const _a_0 = _rows_0["aux"];
  const _f_0 = _rows_0["metadata"];
  const _c_0 = _rows_0["capacity"];
  const _d_0 = _rows_0["depth"];
  const _h_0 = _rows_0["high_water"];
  return $storage$058replace_main_checked$(($Bool$and$((0 < _id_0), ($Bool$and$((_id_0 <= _c_0), (_id_0 <= _h_0))))), _id_0, _tick_0, {$: "storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, _replacement_0);
}

function $commands$058edit_target$(_namespace_0, _tick_0, _rows_0, _result_0) {
  const _command_0 = _result_0["fst"];
  const _id_0 = _result_0["snd"];
  return $commands$058extracted$(_namespace_0, _tick_0, _id_0, _command_0, ($storage$058rows_extract$(_rows_0, _id_0)));
}

function $commands$058targeted$(_command_0) {
  if (_command_0.$ === "storage.Spawn") {
    const _id_0 = _command_0["id"];
    const _bundle_0 = _command_0["bundle"];
    return {$: "Tuple", "fst": {$: "storage.Spawn", "id": _id_0, "bundle": _bundle_0}, "snd": _id_0};
  } else if (_command_0.$ === "storage.InsertMain") {
    const _id_1 = _command_0["id"];
    const _main_0 = _command_0["main"];
    return {$: "Tuple", "fst": {$: "storage.InsertMain", "id": _id_1, "main": _main_0}, "snd": _id_1};
  } else if (_command_0.$ === "storage.InsertFlag") {
    const _id_2 = _command_0["id"];
    const _flag_0 = _command_0["flag"];
    return {$: "Tuple", "fst": {$: "storage.InsertFlag", "id": _id_2, "flag": _flag_0}, "snd": _id_2};
  } else if (_command_0.$ === "storage.RemoveMain") {
    const _id_3 = _command_0["id"];
    return {$: "Tuple", "fst": {$: "storage.RemoveMain", "id": _id_3}, "snd": _id_3};
  } else if (_command_0.$ === "storage.RemoveFlag") {
    const _id_4 = _command_0["id"];
    return {$: "Tuple", "fst": {$: "storage.RemoveFlag", "id": _id_4}, "snd": _id_4};
  } else {
    const _id_5 = _command_0["id"];
    return {$: "Tuple", "fst": {$: "storage.Despawn", "id": _id_5}, "snd": _id_5};
  }
}

function $dispatcher$058visit_decide$1265$(_ih_0, _hit_0, _base_0, _mode_0, _clock_0, _style_0, _system_0, _local_0, _tail_0, _world_0, _audit_0, _run_0) {
  if (_hit_0) {
    return $dispatcher$058visit_local$(_system_0, _mode_0, _clock_0, _tail_0, _world_0, _audit_0, _run_0, run_loop($capture$058invoke$(_style_0, _local_0)), run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return run_clo((_x_4) => {
  return run_clo((_x_5) => {
  return run_clo((_x_6) => {
  return $host$045preflight$058health_invoke$(_x_0, _x_1, _x_2, _x_3, _x_4, _x_5, _x_6);
});
});
});
});
});
});
}));
  } else {
    return run_clo((_x_7) => {
  return $IO$bind$(_ih_0(_tail_0)(_world_0)(_audit_0)(_run_0), run_clo((_x_8) => {
  return run_clo((_x_9) => {
  return $IO$pure$(($dispatcher$058visit_restore$({$: "schedule.Entry", "system": _system_0, "local": _local_0}, _x_8)), _x_9);
});
}), _x_7);
});
  }
}

function $dispatcher$058visit_done$(_system_0, _local_0, _tail_0, _result_0) {
  const _base_0 = _system_0["base"];
  const _name_0 = _system_0["name"];
  const _kind_0 = _system_0["kind"];
  const _ledger_0 = _system_0["ledger"];
  const _service_0 = _system_0["audit"];
  const _gated_0 = _system_0["gated"];
  const _reader_0 = _system_0["reader"];
  const _world_0 = _result_0["world"];
  const _audit_0 = _result_0["audit"];
  const _run_0 = _result_0["run"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "types.Success") {
    const _clock_0 = _result_0["clock"];
    const _escaped_0 = _result_0["escaped"];
    const _observations_0 = _result_0["observations"];
    return {$: "dispatcher.Visit", "world": _world_0, "audit": _audit_0, "run": _run_0, "entries": {$: "Con", "head": {$: "schedule.Entry", "system": {$: "schedule.System", "base": _base_0, "name": _name_0, "kind": _kind_0, "ledger": _ledger_0, "audit": _service_0, "gated": _gated_0, "reader": _reader_0}, "local": _local_0}, "tail": _tail_0}, "outcome": {$: "dispatcher.Complete"}, "clock": _clock_0, "escaped": _escaped_0, "observations": _observations_0};
  } else {
    const _code_0 = _t_0["code"];
    const _clock_1 = _result_0["clock"];
    const _escaped_1 = _result_0["escaped"];
    const _observations_1 = _result_0["observations"];
    return {$: "dispatcher.Visit", "world": _world_0, "audit": _audit_0, "run": _run_0, "entries": {$: "Con", "head": {$: "schedule.Entry", "system": {$: "schedule.System", "base": _base_0, "name": _name_0, "kind": _kind_0, "ledger": _ledger_0, "audit": _service_0, "gated": _gated_0, "reader": _reader_0}, "local": _local_0}, "tail": _tail_0}, "outcome": {$: "dispatcher.SystemFailure", "system": _name_0, "code": _code_0}, "clock": _clock_1, "escaped": _escaped_1, "observations": _observations_1};
  }
}

function $capture$058increment$(_local_0) {
  const _array_0 = _local_0["count"];
  return $capture$058incremented$({$: "Tuple", fst: _array_0, snd: _array_0[0 % _array_0.length]});
}

function $capture$058call$(_callback_0) {
  return run_tail(_callback_0, {$: "Unit"});
}

function $capture$058closure$(_local_0, __0) {
  return $capture$058increment$(_local_0);
}

function $host$058prototype_slot_host_health_invoke_count$(_system_0, _mode_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0) {
  const _name_0 = _system_0["name"];
  const _kind_0 = _system_0["kind"];
  if (_run_0.$ === "Some") {
    const _run_1 = _run_0["value"];
    return $host$058prototype_slot_host_health_read_done$(_kind_0, _mode_0, _name_0, _count_0, _clock_0, _audit_0, ($host$058prototype_slot_host_health_read$(_name_0, _count_0, _owner_0, _run_1)));
  } else {
    return $host$058prototype_slot_host_health_body$(_kind_0, _mode_0, _name_0, _count_0, _clock_0, _owner_0, _audit_0, {$: "None"});
  }
}

function $readers$058completed$(_readers_0, _run_0) {
  const _slots_0 = _readers_0["slots"];
  const _key_0 = _run_0["key"];
  const _interests_0 = _run_0["interests"];
  const _t_0 = _run_0["state"];
  const _registered_0 = _t_0["registeredAt"];
  const _t_1 = _run_0["boundary"];
  const _thisRun_0 = _t_1["thisRun"];
  return {$: "readers.Readers", "slots": ($readers$058replace$(_key_0, {$: "readers.Slot", "key": _key_0, "interests": _interests_0, "state": {$: "types.ReaderState", "registeredAt": _registered_0, "lastRun": _thisRun_0, "streamLastRun": _thisRun_0}}, _slots_0))};
}

function $streams$058append_buffer$(_buffer_0, _tick_0, _values_0) {
  const _capacity_0 = _buffer_0["capacity"];
  const _size_0 = _buffer_0["size"];
  const _dropped_0 = _buffer_0["dropped"];
  const _front_0 = _buffer_0["front"];
  const _rear_0 = _buffer_0["rear"];
  if (_values_0.$ === "Nil") {
    return {$: "streams.Buffer", "capacity": _capacity_0, "size": _size_0, "dropped": _dropped_0, "front": _front_0, "rear": _rear_0};
  } else {
    const _v_0 = _values_0["head"];
    const _vs_0 = _values_0["tail"];
    const _n_0 = ($streams$058count$({$: "Con", "head": _v_0, "tail": _vs_0}, 0));
    return {$: "streams.Buffer", "capacity": _capacity_0, "size": ((_size_0 + _n_0) >>> 0), "dropped": _dropped_0, "front": _front_0, "rear": {$: "Con", "head": {$: "streams.Batch", "tick": _tick_0, "count": _n_0, "values": {$: "Con", "head": _v_0, "tail": _vs_0}}, "tail": _rear_0}};
  }
}

function $commands$058placed$(_changes_0, _result_0) {
  if (_result_0.$ === "storage.Placed") {
    const _rows_0 = _result_0["rows"];
    return {$: "commands.Stepped", "rows": _rows_0, "changes": _changes_0};
  } else {
    const _rows_1 = _result_0["rows"];
    const _row_0 = _result_0["row"];
    return {$: "commands.PlacementFault", "rows": _rows_1, "row": _row_0};
  }
}

function $storage$058rows_place$(_rows_0, _row_0) {
  const _id_0 = _row_0["id"];
  const _m_0 = _row_0["main"];
  const _a_0 = _row_0["aux"];
  const _f_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  return $storage$058place_checked$(($Bool$and$((0 < _id_0), (_id_0 <= 131072))), _rows_0, {$: "storage.Row", "id": _id_0, "main": _m_0, "aux": _a_0, "flag": _f_0, "added": _added_0, "changed": _changed_0});
}

function $storage$058replace_main_checked$(_valid_0, _id_0, _tick_0, _rows_0, _replacement_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _rows_0, "snd": {$: "storage.MissingMainTarget"}};
  } else {
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    return $storage$058replace_main_meta_done$(_id_0, _tick_0, _m_0, _a_0, _c_0, _d_0, _h_0, _replacement_0, ($storage$058metadata_get$(_f_0, ((_id_0 - 1) >>> 0))));
  }
}

function $commands$058extracted$(_namespace_0, _tick_0, _id_0, _command_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "commands.Stepped", "rows": _rows_0, "changes": {$: "Nil"}};
  } else {
    const _row_0 = _t_0["value"];
    return $commands$058edited$(_rows_0, _id_0, ($commands$058edit_row$(_namespace_0, _tick_0, _command_0, _row_0)));
  }
}

function $storage$058rows_extract$(_rows_0, _id_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _metadata_0 = _rows_0["metadata"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $storage$058extract_checked$(($Bool$and$((0 < _id_0), ($Bool$and$((_id_0 <= _capacity_0), (_id_0 <= _high_0))))), _id_0, {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0});
}

function $host$045preflight$058health_invoke$(_system_0, _mode_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0) {
  return $host$045preflight$058health_invoke_copy$(_system_0, _mode_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0);
}

function $capture$058incremented$(_result_0) {
  const _array_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  const _x_0 = ((_count_0 + 1) >>> 0);
  return {$: "Tuple", "fst": {$: "capture.Local", "count": (_array_0[0 % _array_0.length] = _x_0, _array_0)}, "snd": ((_count_0 + 1) >>> 0)};
}

function $host$058prototype_slot_host_health_read_done$(_kind_0, _mode_0, _system_0, _count_0, _clock_0, _audit_0, _pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _run_0 = _pair_0["snd"];
  return $host$058prototype_slot_host_health_body$(_kind_0, _mode_0, _system_0, _count_0, _clock_0, _owner_0, _audit_0, {$: "Some", "value": _run_0});
}

function $host$058prototype_slot_host_health_read$(_system_0, _count_0, _owner_0, _run_0) {
  return $host$058read$1263$(_system_0, _count_0, _owner_0, _run_0);
}

function $host$058prototype_slot_host_health_body$(_kind_0, _mode_0, _system_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0) {
  if (_kind_0.$ === "schedule.A") {
    return $host$058prototype_slot_host_health_transaction$({$: "schedule.A"}, _mode_0, _system_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0);
  } else if (_kind_0.$ === "schedule.B") {
    return $host$058prototype_slot_host_health_b_choose$(($systems$058writes$(_mode_0)), _mode_0, _system_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0);
  } else {
    return $host$058prototype_slot_host_health_simple$(_kind_0, _mode_0, _system_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0);
  }
}

function $streams$058count$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      if (_values_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ((_acc_0 + 1) >>> 0);
        continue;
      }
    }
  }
}

function $storage$058place_checked$(_valid_0, _rows_0, _row_0) {
  if (!_valid_0) {
    return {$: "storage.Rejected", "rows": _rows_0, "row": _row_0};
  } else {
    const _id_0 = _row_0["id"];
    const _m_0 = _row_0["main"];
    const _a_0 = _row_0["aux"];
    const _f_0 = _row_0["flag"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    return $storage$058place_grown$(run_loop($storage$058grow$(17, _id_0, _rows_0)), {$: "storage.Row", "id": _id_0, "main": _m_0, "aux": _a_0, "flag": _f_0, "added": _added_0, "changed": _changed_0});
  }
}

function $storage$058replace_main_meta_done$(_id_0, _tick_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, _replacement_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _meta_0 = _result_0["snd"];
  return $storage$058replace_main_meta$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _replacement_0, _meta_0);
}

function $storage$058metadata_get$(_columns_0, _index_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  return $storage$058metadata_get_live$(_flags_0, _added_0, _changed_0, _index_0, {$: "Tuple", fst: _live_0, snd: _live_0[_index_0 % _live_0.length]});
}

function $commands$058edited$(_rows_0, _id_0, _result_0) {
  const _t_0 = _result_0["row"];
  if (_t_0.$ === "Some") {
    const _row_0 = _t_0["value"];
    const _changes_0 = _result_0["changes"];
    return {$: "commands.Stepped", "rows": ($storage$058rows_restore$(_rows_0, _row_0)), "changes": _changes_0};
  } else {
    const _changes_1 = _result_0["changes"];
    return $commands$058removed$(_changes_1, ($storage$058rows_remove$(_rows_0, _id_0)));
  }
}

function $commands$058edit_row$(_namespace_0, _tick_0, _command_0, _row_0) {
  if (_command_0.$ === "storage.InsertFlag") {
    const _flag_0 = _command_0["flag"];
    const _id_0 = _row_0["id"];
    const _main_0 = _row_0["main"];
    const _aux_0 = _row_0["aux"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    return {$: "commands.RowEdit", "row": {$: "Some", "value": {$: "storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": {$: "Some", "value": _flag_0}, "added": _added_0, "changed": _changed_0}}, "changes": {$: "Nil"}};
  } else if (_command_0.$ === "storage.RemoveFlag") {
    const _id_1 = _row_0["id"];
    const _main_1 = _row_0["main"];
    const _aux_1 = _row_0["aux"];
    const _added_1 = _row_0["added"];
    const _changed_1 = _row_0["changed"];
    return {$: "commands.RowEdit", "row": {$: "Some", "value": {$: "storage.Row", "id": _id_1, "main": _main_1, "aux": _aux_1, "flag": {$: "None"}, "added": _added_1, "changed": _changed_1}}, "changes": {$: "Nil"}};
  } else if (_command_0.$ === "storage.InsertMain") {
    return {$: "commands.RowEdit", "row": {$: "Some", "value": _row_0}, "changes": {$: "Nil"}};
  } else if (_command_0.$ === "storage.RemoveMain") {
    return {$: "commands.RowEdit", "row": {$: "Some", "value": _row_0}, "changes": {$: "Nil"}};
  } else if (_command_0.$ === "storage.Despawn") {
    const _id_2 = _row_0["id"];
    const _t_0 = _row_0["main"];
    if (_t_0.$ === "Some") {
      return {$: "commands.RowEdit", "row": {$: "None"}, "changes": {$: "Con", "head": {$: "storage.MainRemoved", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_2}}, "tail": {$: "Con", "head": {$: "storage.Despawned", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_2}}, "tail": {$: "Nil"}}}};
    } else {
      return {$: "commands.RowEdit", "row": {$: "None"}, "changes": {$: "Con", "head": {$: "storage.Despawned", "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_2}}, "tail": {$: "Nil"}}};
    }
  } else {
    return {$: "commands.RowEdit", "row": {$: "Some", "value": _row_0}, "changes": {$: "Nil"}};
  }
}

function $storage$058extract_checked$(_valid_0, _id_0, _rows_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _rows_0, "snd": {$: "None"}};
  } else {
    const _main_0 = _rows_0["main"];
    const _aux_0 = _rows_0["aux"];
    const _metadata_0 = _rows_0["metadata"];
    const _capacity_0 = _rows_0["capacity"];
    const _depth_0 = _rows_0["depth"];
    const _high_0 = _rows_0["high_water"];
    return $storage$058extract_meta$(_id_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, ($storage$058metadata_get$(_metadata_0, ((_id_0 - 1) >>> 0))));
  }
}

function $host$045preflight$058health_invoke_copy$(_system_0, _mode_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0) {
  return run_clo((_x_0) => {
  const _x_1 = ($U32$show$(_count_0));
  const _x_2 = ($host$058system_name$(_system_0));
  const _x_3 = (":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  return $IO$bind$((_x_5) => $IO$print$(("PREFLIGHT-INVOKE:health:" + _x_4), _x_5), run_clo((_x_6) => {
  return $host$058prototype_slot_host_health_invoke$(_system_0, _mode_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0);
}), _x_0);
});
}

function $host$058read$1263$(_system_0, _count_0, _owner_0, _run_0) {
  return $host$058read_query$1263$(_system_0, _count_0, _run_0, ($host$058query$1263$({$: "query.Required"}, _owner_0)));
}

function $host$058prototype_slot_host_health_transaction$(_kind_0, _mode_0, _system_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0) {
  const _world_0 = _owner_0["world"];
  const _logs_0 = _owner_0["logs"];
  const _bindings_0 = _owner_0["bindings"];
  const _worldName_0 = _owner_0["worldName"];
  const _step_0 = _owner_0["step"];
  const _prior_0 = _owner_0["prior"];
  const _events_0 = _owner_0["events"];
  return $host$058prototype_slot_host_health_transaction_found$(_kind_0, _mode_0, _system_0, _count_0, _clock_0, {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, _audit_0, _run_0, ($host$058binding_find$(($host$058selected_name$(_kind_0)), _bindings_0)));
}

function $host$058prototype_slot_host_health_b_choose$(_write_0, _mode_0, _system_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0) {
  if (_write_0) {
    return $host$058prototype_slot_host_health_transaction$({$: "schedule.B"}, _mode_0, _system_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0);
  } else {
    return $host$058prototype_slot_host_health_simple$({$: "schedule.B"}, _mode_0, _system_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0);
  }
}

function $systems$058writes$(_mode_0) {
  if (_mode_0.$ === "schedule.BFail") {
    return true;
  } else if (_mode_0.$ === "schedule.Retry") {
    return true;
  } else {
    return false;
  }
}

function $host$058prototype_slot_host_health_simple$(_kind_0, _mode_0, _system_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0) {
  if (_kind_0.$ === "schedule.Cleanup") {
    return $host$058prototype_slot_host_health_structural$({$: "schedule.Cleanup"}, _system_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0);
  } else if (_kind_0.$ === "schedule.Inserts") {
    return $host$058prototype_slot_host_health_structural$({$: "schedule.Inserts"}, _system_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0);
  } else if (_kind_0.$ === "schedule.Dispose") {
    return $host$058prototype_slot_host_health_structural$({$: "schedule.Dispose"}, _system_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0);
  } else if (_kind_0.$ === "schedule.ForeignLookup") {
    return run_clo((_x_0) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Success"}, {$: "None"}, {$: "Nil"}, ($host$058prototype_slot_host_health_foreign$(_owner_0)), _run_0)), _x_0);
});
  } else if (_kind_0.$ === "schedule.Snapshot") {
    return run_clo((_x_1) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Success"}, {$: "None"}, {$: "Nil"}, ($host$058prototype_slot_host_health_snapshot$(_owner_0)), _run_0)), _x_1);
});
  } else if (_kind_0.$ === "schedule.Seed") {
    return run_clo((_x_2) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Success"}, {$: "None"}, {$: "Nil"}, run_loop($systems$058prototype_slot_host_health_seed$(run_clo((_x_3) => {
  return run_clo((_x_4) => {
  return run_clo((_x_5) => {
  return $host$058prototype_slot_host_health_reserve$(_x_3, _x_4, _x_5);
});
});
}), run_clo((_x_6) => {
  return run_clo((_x_7) => {
  return run_clo((_x_8) => {
  return $host$058prototype_slot_host_health_reserve$(_x_6, _x_7, _x_8);
});
});
}), run_clo((_x_9) => {
  return run_clo((_x_10) => {
  return run_clo((_x_11) => {
  return $host$058prototype_slot_host_health_reserve$(_x_9, _x_10, _x_11);
});
});
}), _owner_0)), _run_0)), _x_2);
});
  } else if (_kind_0.$ === "schedule.SeedBeta") {
    return run_clo((_x_12) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Success"}, {$: "None"}, {$: "Nil"}, run_loop($systems$058prototype_slot_host_health_seed_beta$(run_clo((_x_13) => {
  return run_clo((_x_14) => {
  return run_clo((_x_15) => {
  return $host$058prototype_slot_host_health_reserve$(_x_13, _x_14, _x_15);
});
});
}), _owner_0)), _run_0)), _x_12);
});
  } else if (_kind_0.$ === "schedule.SpawnS") {
    return run_clo((_x_16) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Success"}, {$: "None"}, {$: "Nil"}, run_loop($systems$058prototype_slot_host_health_spawn_s$(run_clo((_x_17) => {
  return run_clo((_x_18) => {
  return run_clo((_x_19) => {
  return $host$058prototype_slot_host_health_reserve$(_x_17, _x_18, _x_19);
});
});
}), _owner_0)), _run_0)), _x_16);
});
  } else if (_kind_0.$ === "schedule.B") {
    return run_clo((_x_20) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, ($systems$058failed$(_mode_0)), {$: "None"}, {$: "Nil"}, _owner_0, _run_0)), _x_20);
});
  } else if (_kind_0.$ === "schedule.Fast") {
    return run_clo((_x_21) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Success"}, {$: "None"}, {$: "Nil"}, _owner_0, _run_0)), _x_21);
});
  } else if (_kind_0.$ === "schedule.ReadOnlyLate") {
    return run_clo((_x_22) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Success"}, {$: "None"}, {$: "Nil"}, _owner_0, _run_0)), _x_22);
});
  } else if (_kind_0.$ === "schedule.Tail") {
    return run_clo((_x_23) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Success"}, {$: "None"}, {$: "Nil"}, _owner_0, _run_0)), _x_23);
});
  } else if (_kind_0.$ === "schedule.SetOn") {
    return run_clo((_x_24) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Success"}, {$: "None"}, {$: "Nil"}, _owner_0, _run_0)), _x_24);
});
  } else if (_kind_0.$ === "schedule.SetOff") {
    return run_clo((_x_25) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Success"}, {$: "None"}, {$: "Nil"}, _owner_0, _run_0)), _x_25);
});
  } else {
    return run_clo((_x_26) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Failure", "code": 7}, {$: "None"}, {$: "Nil"}, _owner_0, _run_0)), _x_26);
});
  }
}

function $storage$058place_grown$(_rows_0, _row_0) {
  const _m_0 = _rows_0["main"];
  const _a_0 = _rows_0["aux"];
  const _f_0 = _rows_0["metadata"];
  const _c_0 = _rows_0["capacity"];
  const _d_0 = _rows_0["depth"];
  const _h_0 = _rows_0["high_water"];
  const _id_0 = _row_0["id"];
  const _main_0 = _row_0["main"];
  const _aux_0 = _row_0["aux"];
  const _flag_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  return $storage$058place_capacity$(($Bool$and$((0 < _id_0), (_id_0 <= _c_0))), {$: "storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, {$: "storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0});
}

function $storage$058grow$(_fuel_0, _id_0, _rows_0) {
  if (_fuel_0 === 0) {
    return _rows_0;
  } else {
    const _n_0 = (_fuel_0 - 1);
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    return $storage$058grow_decide$(($Bool$and$((_c_0 < _id_0), (_c_0 <= 65536))), {$: "storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, run_clo((_x_0) => {
  return $storage$058grow$(_n_0, _id_0, _x_0);
}));
  }
}

function $storage$058replace_main_meta$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _replacement_0, _meta_0) {
  const _t_0 = _meta_0["live"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "storage.MissingMainTarget"}};
  } else {
    const __3 = _meta_0["flag"];
    const __4 = _meta_0["added"];
    const __5 = _meta_0["changed"];
    return $storage$058replace_main_slot$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, __3, __4, __5, _replacement_0);
  }
}

function $storage$058metadata_get_live$(_flags_0, _added_0, _changed_0, _index_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _l_0 = _result_0["snd"];
  return $storage$058metadata_get_flags$(_live_0, _added_0, _changed_0, _index_0, _l_0, {$: "Tuple", fst: _flags_0, snd: _flags_0[_index_0 % _flags_0.length]});
}

function $storage$058rows_restore$(_rows_0, _row_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _metadata_0 = _rows_0["metadata"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  const _id_0 = _row_0["id"];
  const _m_0 = _row_0["main"];
  const _a_0 = _row_0["aux"];
  const _f_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = ((_id_0 - 1) >>> 0);
  return {$: "storage.Rows", "main": (_main_0[_x_0 % _main_0.length] = _m_0, _main_0), "aux": (_aux_0[_x_1 % _aux_0.length] = _a_0, _aux_0), "metadata": ($storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": true, "flag": _f_0, "added": _added_0, "changed": _changed_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0};
}

function $commands$058removed$(_changes_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  return {$: "commands.Stepped", "rows": _rows_0, "changes": _changes_0};
}

function $storage$058rows_remove$(_rows_0, _id_0) {
  return $storage$058remove_done$(_id_0, ($storage$058rows_extract$(_rows_0, _id_0)));
}

function $storage$058extract_meta$(_id_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _t_1 = _t_0["live"];
  if (!_t_1) {
    return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "None"}};
  } else {
    const _flag_1 = _t_0["flag"];
    const _added_1 = _t_0["added"];
    const _changed_1 = _t_0["changed"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $storage$058extract_main$(_id_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, {$: "storage.Metadata", "live": true, "flag": _flag_1, "added": _added_1, "changed": _changed_1}, array_rmw(_main_0, _x_0, () => _x_1));
  }
}

function $host$058read_query$1263$(_system_0, _count_0, _run_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _logs_0 = _t_0["logs"];
  const _bindings_0 = _t_0["bindings"];
  const _worldName_0 = _t_0["worldName"];
  const _step_0 = _t_0["step"];
  const _prior_0 = _t_0["prior"];
  const _events_0 = _t_0["events"];
  const _query_0 = _result_0["snd"];
  return $host$058read_world$1263$(_system_0, _count_0, _logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _query_0, _run_0, ($observations$058world$1263$(_world_0)));
}

function $host$058query$1263$(_selection_0, _owner_0) {
  const _world_0 = _owner_0["world"];
  const _logs_0 = _owner_0["logs"];
  const _bindings_0 = _owner_0["bindings"];
  const _worldName_0 = _owner_0["worldName"];
  const _step_0 = _owner_0["step"];
  const _prior_0 = _owner_0["prior"];
  const _events_0 = _owner_0["events"];
  return $host$058query_return$(_logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, ($query$058each$1263$(_selection_0, _world_0)));
}

function $host$058prototype_slot_host_health_transaction_found$(_kind_0, _mode_0, _system_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0, _selected_0) {
  if (_kind_0.$ === "schedule.A") {
    const _world_0 = _owner_0["world"];
    const _logs_0 = _owner_0["logs"];
    const _bindings_0 = _owner_0["bindings"];
    const _worldName_0 = _owner_0["worldName"];
    const _step_0 = _owner_0["step"];
    const _prior_0 = _owner_0["prior"];
    const _events_0 = _owner_0["events"];
    if (_audit_0.$ === "Some") {
      const _audit_1 = _audit_0["value"];
      if (_selected_0.$ === "Some") {
        const _handle_0 = _selected_0["value"];
        return run_clo((_x_0) => {
  return $IO$bind$(($audited$045invoker$058prototype_slot_host_health_a$(_count_0, {$: "types.Failure", "code": 7}, ($dispatcher$058clock_tick$(_clock_0)), _world_0, _handle_0, _audit_1)), run_clo((_x_1) => {
  return $host$058prototype_slot_host_health_service$({$: "schedule.A"}, _mode_0, _system_0, _count_0, _clock_0, _logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _run_0, _x_1);
}), _x_0);
});
      } else {
        return run_clo((_x_2) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, {$: "Some", "value": _audit_1}, {$: "types.Failure", "code": 7}, {$: "None"}, {$: "Nil"}, {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, _run_0)), _x_2);
});
      }
    } else {
      return run_clo((_x_3) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Failure", "code": 7}, {$: "None"}, {$: "Nil"}, {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, _run_0)), _x_3);
});
    }
  } else if (_kind_0.$ === "schedule.B") {
    const _world_1 = _owner_0["world"];
    const _logs_1 = _owner_0["logs"];
    const _bindings_1 = _owner_0["bindings"];
    const _worldName_1 = _owner_0["worldName"];
    const _step_1 = _owner_0["step"];
    const _prior_1 = _owner_0["prior"];
    const _events_1 = _owner_0["events"];
    if (_audit_0.$ === "Some") {
      const _audit_2 = _audit_0["value"];
      if (_selected_0.$ === "Some") {
        const _handle_1 = _selected_0["value"];
        return run_clo((_x_4) => {
  return $IO$bind$(($audited$045invoker$058prototype_slot_host_health_b$(_mode_0, _count_0, ($dispatcher$058clock_tick$(_clock_0)), _world_1, _handle_1, _audit_2)), run_clo((_x_5) => {
  return $host$058prototype_slot_host_health_service$({$: "schedule.B"}, _mode_0, _system_0, _count_0, _clock_0, _logs_1, _bindings_1, _worldName_1, _step_1, _prior_1, _events_1, _run_0, _x_5);
}), _x_4);
});
      } else {
        return run_clo((_x_6) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, {$: "Some", "value": _audit_2}, {$: "types.Failure", "code": 7}, {$: "None"}, {$: "Nil"}, {$: "host.Host", "world": _world_1, "logs": _logs_1, "bindings": _bindings_1, "worldName": _worldName_1, "step": _step_1, "prior": _prior_1, "events": _events_1}, _run_0)), _x_6);
});
      }
    } else {
      return run_clo((_x_7) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Failure", "code": 7}, {$: "None"}, {$: "Nil"}, {$: "host.Host", "world": _world_1, "logs": _logs_1, "bindings": _bindings_1, "worldName": _worldName_1, "step": _step_1, "prior": _prior_1, "events": _events_1}, _run_0)), _x_7);
});
    }
  } else {
    return run_clo((_x_8) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Failure", "code": 7}, {$: "None"}, {$: "Nil"}, _owner_0, _run_0)), _x_8);
});
  }
}

function $host$058selected_name$(_kind_0) {
  if (_kind_0.$ === "schedule.A") {
    return "a";
  } else {
    return "b";
  }
}

function $host$058prototype_slot_host_health_structural$(_kind_0, _system_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0) {
  const _world_0 = _owner_0["world"];
  const _logs_0 = _owner_0["logs"];
  const _bindings_0 = _owner_0["bindings"];
  const _worldName_0 = _owner_0["worldName"];
  const _step_0 = _owner_0["step"];
  const _prior_0 = _owner_0["prior"];
  const _events_0 = _owner_0["events"];
  return $host$058prototype_slot_host_health_structural_found$(_kind_0, _system_0, _count_0, _clock_0, {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, _audit_0, _run_0, ($host$058binding_find$("a", _bindings_0)), ($host$058binding_find$("b", _bindings_0)), ($host$058binding_find$("c", _bindings_0)), ($host$058binding_find$("p", _bindings_0)), ($host$058binding_find$("r", _bindings_0)));
}

function $host$058done$(_system_0, _count_0, _clock_0, _audit_0, _outcome_0, _escaped_0, _observations_0, _owner_0, _run_0) {
  if (_run_0.$ === "None") {
    return {$: "dispatcher.Invoked", "world": _owner_0, "audit": _audit_0, "run": {$: "None"}, "outcome": _outcome_0, "clock": _clock_0, "escaped": _escaped_0, "observations": _observations_0};
  } else {
    const _run_1 = _run_0["value"];
    return $host$058done_run$(_system_0, _count_0, _clock_0, _audit_0, _outcome_0, _escaped_0, _observations_0, _owner_0, ($readers$058project$(_run_1)));
  }
}

function $host$058prototype_slot_host_health_foreign$(_owner_0) {
  const _world_0 = _owner_0["world"];
  const _logs_0 = _owner_0["logs"];
  const _t_0 = _owner_0["bindings"];
  if (_t_0.$ === "Con") {
    const _binding_0 = _t_0["head"];
    const _tail_0 = _t_0["tail"];
    const _worldName_0 = _owner_0["worldName"];
    const _step_0 = _owner_0["step"];
    const _prior_0 = _owner_0["prior"];
    const _events_0 = _owner_0["events"];
    return $host$058foreign_result$1263$(_logs_0, _tail_0, _worldName_0, _step_0, _prior_0, _events_0, ($host$058lookups$1263$({$: "Con", "head": _binding_0, "tail": {$: "Nil"}}, _world_0)));
  } else {
    const _worldName_1 = _owner_0["worldName"];
    const _step_1 = _owner_0["step"];
    const _prior_1 = _owner_0["prior"];
    const _events_1 = _owner_0["events"];
    return {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": {$: "Nil"}, "worldName": _worldName_1, "step": _step_1, "prior": _prior_1, "events": _events_1};
  }
}

function $host$058prototype_slot_host_health_snapshot$(_owner_0) {
  return $host$058snapshot$1263$(_owner_0);
}

function $systems$058prototype_slot_host_health_seed$(_first_0, _second_0, _third_0, _owner_0) {
  return run_tail(_third_0(_second_0(_first_0(_owner_0)("a")({$: "storage.Bundle", "main": {$: "Some", "value": ($cached$045payload$058prototype_slot_vitals_new$({$: "types.Vitals", "levels": ($systems$058quad$(10, 11, 12, 13)), "reserve": 9, "class": 2}))}, "aux": {$: "Some", "value": {$: "types.Armor", "layers": ($systems$058quad$(1, 2, 3, 4)), "grade": 3}}, "flag": {$: "Some", "value": {$: "types.Tracked", "group": 8}}}))("b")({$: "storage.Bundle", "main": {$: "Some", "value": ($cached$045payload$058prototype_slot_vitals_new$({$: "types.Vitals", "levels": ($systems$058quad$(20, 21, 22, 23)), "reserve": 9, "class": 2}))}, "aux": {$: "None"}, "flag": {$: "None"}}))("c"), {$: "storage.Bundle", "main": {$: "None"}, "aux": {$: "Some", "value": {$: "types.Armor", "layers": ($systems$058quad$(1, 2, 3, 4)), "grade": 3}}, "flag": {$: "Some", "value": {$: "types.Tracked", "group": 8}}});
}

function $host$058prototype_slot_host_health_reserve$(_owner_0, _label_0, _bundle_0) {
  const _world_0 = _owner_0["world"];
  const _logs_0 = _owner_0["logs"];
  const _bindings_0 = _owner_0["bindings"];
  const _worldName_0 = _owner_0["worldName"];
  const _step_0 = _owner_0["step"];
  const _prior_0 = _owner_0["prior"];
  const _events_0 = _owner_0["events"];
  return $host$058prototype_slot_host_health_reserve_view$(_label_0, _world_0, _logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, ($observations$058bundle$1263$(_bundle_0)));
}

function $systems$058prototype_slot_host_health_seed_beta$(_reserve_0, _owner_0) {
  return run_tail(_reserve_0(_owner_0)("z"), {$: "storage.Bundle", "main": {$: "Some", "value": ($cached$045payload$058prototype_slot_vitals_new$({$: "types.Vitals", "levels": ($systems$058quad$(90, 91, 92, 93)), "reserve": 9, "class": 2}))}, "aux": {$: "None"}, "flag": {$: "Some", "value": {$: "types.Tracked", "group": 8}}});
}

function $systems$058prototype_slot_host_health_spawn_s$(_reserve_0, _owner_0) {
  return run_tail(_reserve_0(_owner_0)("s"), {$: "storage.Bundle", "main": {$: "Some", "value": ($cached$045payload$058prototype_slot_vitals_new$({$: "types.Vitals", "levels": ($systems$058quad$(70, 71, 72, 73)), "reserve": 9, "class": 2}))}, "aux": {$: "None"}, "flag": {$: "None"}});
}

function $systems$058failed$(_mode_0) {
  if (_mode_0.$ === "schedule.BFail") {
    return {$: "types.Failure", "code": 7};
  } else if (_mode_0.$ === "schedule.ObserveFail") {
    return {$: "types.Failure", "code": 7};
  } else {
    return {$: "types.Success"};
  }
}

function $storage$058place_capacity$(_valid_0, _rows_0, _row_0) {
  if (!_valid_0) {
    return {$: "storage.Rejected", "rows": _rows_0, "row": _row_0};
  } else {
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    const _id_0 = _row_0["id"];
    const _main_0 = _row_0["main"];
    const _aux_0 = _row_0["aux"];
    const _flag_0 = _row_0["flag"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    return $storage$058place_meta$(_m_0, _a_0, _c_0, _d_0, _h_0, {$: "storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}, ($storage$058metadata_live$(_f_0, ((_id_0 - 1) >>> 0))));
  }
}

function $storage$058grow_decide$(_needed_0, _rows_0, _recurse_0) {
  if (!_needed_0) {
    return _rows_0;
  } else {
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    return run_tail(_recurse_0, {$: "storage.Rows", "main": array_node(_m_0, ($storage$058slots_empty$(_d_0))), "aux": array_node(_a_0, ($storage$058slots_empty$(_d_0))), "metadata": ($storage$058metadata_grow$(_f_0, _d_0)), "capacity": ((_c_0 + _c_0) >>> 0), "depth": nat_chk(_d_0 + 1), "high_water": _h_0});
  }
}

function $storage$058replace_main_slot$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _replacement_0) {
  if (_replacement_0.$ === "None") {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $storage$058replace_main_done$(_id_0, _tick_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, false, array_rmw(_main_0, _x_0, () => _x_1));
  } else {
    const _value_0 = _replacement_0["value"];
    const _x_2 = ((_id_0 - 1) >>> 0);
    const _x_3 = {$: "Some", "value": _value_0};
    return $storage$058replace_main_done$(_id_0, _tick_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, true, array_rmw(_main_0, _x_2, () => _x_3));
  }
}

function $storage$058metadata_get_flags$(_live_0, _added_0, _changed_0, _index_0, _l_0, _result_0) {
  const _flags_0 = _result_0["fst"];
  const _f_0 = _result_0["snd"];
  return $storage$058metadata_get_added$(_live_0, _flags_0, _changed_0, _index_0, _l_0, _f_0, {$: "Tuple", fst: _added_0, snd: _added_0[_index_0 % _added_0.length]});
}

function $storage$058metadata_set$(_columns_0, _index_0, _meta_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  const _l_0 = _meta_0["live"];
  const _f_0 = _meta_0["flag"];
  const _a_0 = _meta_0["added"];
  const _c_0 = _meta_0["changed"];
  return {$: "storage.MetadataColumns", "live": (_live_0[_index_0 % _live_0.length] = _l_0, _live_0), "flags": (_flags_0[_index_0 % _flags_0.length] = _f_0, _flags_0), "added": (_added_0[_index_0 % _added_0.length] = _a_0, _added_0), "changed": (_changed_0[_index_0 % _changed_0.length] = _c_0, _changed_0)};
}

function $storage$058remove_done$(_id_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _m_0 = _t_0["main"];
  const _a_0 = _t_0["aux"];
  const _f_0 = _t_0["metadata"];
  const _c_0 = _t_0["capacity"];
  const _d_0 = _t_0["depth"];
  const _h_0 = _t_0["high_water"];
  const _t_1 = _result_0["snd"];
  if (_t_1.$ === "None") {
    return {$: "Tuple", "fst": {$: "storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, "snd": {$: "None"}};
  } else {
    const _row_0 = _t_1["value"];
    return {$: "Tuple", "fst": {$: "storage.Rows", "main": _m_0, "aux": _a_0, "metadata": ($storage$058metadata_set$(_f_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": false, "flag": {$: "None"}, "added": 0, "changed": 0})), "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, "snd": {$: "Some", "value": _row_0}};
  }
}

function $storage$058extract_main$(_id_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _mv_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "None"};
  return $storage$058extract_aux$(_id_0, _main_0, _mv_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, array_rmw(_aux_0, _x_0, () => _x_1));
}

function $host$058read_world$1263$(_system_0, _count_0, _logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _query_0, _run_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _rows_0 = _t_0["rows"];
  return $host$058read_delivery$(_system_0, _count_0, _world_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _query_0, _rows_0, ($reader$045host$058read$(_logs_0, _run_0)));
}

function $observations$058world$1263$(_owner_0) {
  const _namespace_0 = _owner_0["namespace"];
  const _next_0 = _owner_0["next"];
  const _owners_0 = _owner_0["rows"];
  const _pending_0 = _owner_0["pending"];
  const _ledger_0 = _owner_0["ledger"];
  const _mode_0 = _owner_0["mode"];
  return $observations$058world_rows$1263$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, ($observations$058rows$1263$(_owners_0)));
}

function $host$058query_return$(_logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, "snd": _values_0};
}

function $query$058each$1263$(_selection_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $query$058each_return$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, ($query$058read_rows$1263$(_rows_0, _selection_0, _namespace_0)));
}

function $audited$045invoker$058prototype_slot_host_health_a$(_count_0, _rejected_0, _tick_0, _world_0, _selected_0, _audit_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($systems$058prototype_slot_host_health_a$(_count_0, _rejected_0, run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $audited$045invoker$058prototype_slot_host_health_set_main0$(_x_1, _x_2, _x_3);
});
});
}), run_clo((_x_4) => {
  return run_clo((_x_5) => {
  return run_clo((_x_6) => {
  return $audited$045invoker$058prototype_slot_host_health_set_ledger0$(_x_4, _x_5, _x_6);
});
});
}), run_clo((_x_7) => {
  return run_clo((_x_8) => {
  return $audited$045invoker$058prototype_slot_host_health_read_main$(_x_7, _x_8);
});
}), run_clo((_x_9) => {
  return run_clo((_x_10) => {
  return $audited$045invoker$058prototype_slot_host_health_read_ledger$(_x_9, _x_10);
});
}), run_clo((_x_11) => {
  return run_clo((_x_12) => {
  return $audited$045invoker$058prototype_slot_host_health_spawn_flagged$(_x_11, _x_12);
});
}), run_clo((_x_13) => {
  return $audited$045invoker$058prototype_slot_host_health_remove_flag$(_x_13);
}), run_clo((_x_14) => {
  return run_clo((_x_15) => {
  return $audited$045invoker$058prototype_slot_host_health_emit$(_x_14, _x_15);
});
}), run_clo((_x_16) => {
  return run_clo((_x_17) => {
  return $audited$045invoker$058prototype_slot_host_health_log$(_x_16, _x_17);
});
}), {$: "audited-invoker.Wrapped", "transaction": ($transaction$058tx_begin$(_world_0, _selected_0)), "audit": _audit_0})), run_clo((_x_18) => {
  return $audited$045invoker$058prototype_slot_host_health_finished$(_tick_0, true, _x_18);
}), _x_0);
});
}

function $host$058prototype_slot_host_health_service$(_kind_0, _mode_0, _system_0, _count_0, _clock_0, _logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _run_0, _result_0) {
  const _t_0 = _result_0["result"];
  const _world_0 = _t_0["world"];
  const _outcome_0 = _t_0["outcome"];
  const _escaped_0 = _t_0["escaped"];
  const _views_0 = _t_0["observations"];
  const _pings_0 = _t_0["pings"];
  const _audit_0 = _result_0["audit"];
  const _reservation_0 = _result_0["reservation"];
  return $host$058prototype_slot_host_health_published$(_system_0, _count_0, _audit_0, _outcome_0, _escaped_0, _views_0, _run_0, ($host$058publish$(($host$058own_record$(($host$058own_writes$(_kind_0, _mode_0)), _system_0, _views_0, ($host$058reserve_record$(($host$058reservation_name$(_kind_0, _mode_0)), _escaped_0, _reservation_0, {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0})))), _clock_0, ($host$058prototype_slot_host_health_pings$(_pings_0)))));
}

function $audited$045invoker$058prototype_slot_host_health_b$(_mode_0, _count_0, _tick_0, _world_0, _selected_0, _audit_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($systems$058prototype_slot_host_health_b$(_mode_0, _count_0, run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $audited$045invoker$058prototype_slot_host_health_read_main$(_x_1, _x_2);
});
}), run_clo((_x_3) => {
  return run_clo((_x_4) => {
  return run_clo((_x_5) => {
  return $audited$045invoker$058prototype_slot_host_health_set_main0$(_x_3, _x_4, _x_5);
});
});
}), run_clo((_x_6) => {
  return run_clo((_x_7) => {
  return $audited$045invoker$058prototype_slot_host_health_read_main$(_x_6, _x_7);
});
}), run_clo((_x_8) => {
  return run_clo((_x_9) => {
  return run_clo((_x_10) => {
  return $audited$045invoker$058prototype_slot_host_health_set_main0$(_x_8, _x_9, _x_10);
});
});
}), run_clo((_x_11) => {
  return run_clo((_x_12) => {
  return $audited$045invoker$058prototype_slot_host_health_read_main$(_x_11, _x_12);
});
}), run_clo((_x_13) => {
  return run_clo((_x_14) => {
  return $audited$045invoker$058prototype_slot_host_health_read_ledger$(_x_13, _x_14);
});
}), run_clo((_x_15) => {
  return run_clo((_x_16) => {
  return run_clo((_x_17) => {
  return $audited$045invoker$058prototype_slot_host_health_set_ledger0$(_x_15, _x_16, _x_17);
});
});
}), run_clo((_x_18) => {
  return run_clo((_x_19) => {
  return $audited$045invoker$058prototype_slot_host_health_spawn_main$(_x_18, _x_19);
});
}), run_clo((_x_20) => {
  return run_clo((_x_21) => {
  return $audited$045invoker$058prototype_slot_host_health_insert_flag$(_x_20, _x_21);
});
}), run_clo((_x_22) => {
  return run_clo((_x_23) => {
  return $audited$045invoker$058prototype_slot_host_health_emit$(_x_22, _x_23);
});
}), run_clo((_x_24) => {
  return run_clo((_x_25) => {
  return $audited$045invoker$058prototype_slot_host_health_log$(_x_24, _x_25);
});
}), {$: "audited-invoker.Wrapped", "transaction": ($transaction$058tx_begin$(_world_0, _selected_0)), "audit": _audit_0})), run_clo((_x_26) => {
  return $audited$045invoker$058prototype_slot_host_health_finished$(_tick_0, true, _x_26);
}), _x_0);
});
}

function $host$058prototype_slot_host_health_structural_found$(_kind_0, _system_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0, _ha_0, _hb_0, _hc_0, _hp_0, _hr_0) {
  if (_kind_0.$ === "schedule.Cleanup") {
    const _world_0 = _owner_0["world"];
    const _logs_0 = _owner_0["logs"];
    const _bindings_0 = _owner_0["bindings"];
    const _worldName_0 = _owner_0["worldName"];
    const _step_0 = _owner_0["step"];
    const _prior_0 = _owner_0["prior"];
    const _events_0 = _owner_0["events"];
    if (_ha_0.$ === "Some") {
      const _a_0 = _ha_0["value"];
      if (_hb_0.$ === "Some") {
        const _b_0 = _hb_0["value"];
        if (_hp_0.$ === "Some") {
          const _p_0 = _hp_0["value"];
          return $host$058prototype_slot_host_health_cleanup_done$(_system_0, _count_0, _clock_0, _logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _audit_0, _run_0, ($structural$045invoker$058prototype_slot_host_health_cleanup$(_world_0, _p_0, _a_0, _b_0, ($dispatcher$058clock_tick$(_clock_0)))));
        } else {
          return run_clo((_x_0) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Failure", "code": 7}, {$: "None"}, {$: "Nil"}, {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, _run_0)), _x_0);
});
        }
      } else {
        return run_clo((_x_1) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Failure", "code": 7}, {$: "None"}, {$: "Nil"}, {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, _run_0)), _x_1);
});
      }
    } else {
      return run_clo((_x_2) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Failure", "code": 7}, {$: "None"}, {$: "Nil"}, {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, _run_0)), _x_2);
});
    }
  } else if (_kind_0.$ === "schedule.Inserts") {
    const _world_1 = _owner_0["world"];
    const _logs_1 = _owner_0["logs"];
    const _bindings_1 = _owner_0["bindings"];
    const _worldName_1 = _owner_0["worldName"];
    const _step_1 = _owner_0["step"];
    const _prior_1 = _owner_0["prior"];
    const _events_1 = _owner_0["events"];
    if (_ha_0.$ === "Some") {
      const _a_1 = _ha_0["value"];
      if (_hb_0.$ === "Some") {
        const _b_1 = _hb_0["value"];
        if (_hc_0.$ === "Some") {
          const _c_0 = _hc_0["value"];
          if (_hp_0.$ === "Some") {
            const _p_1 = _hp_0["value"];
            return $host$058prototype_slot_host_health_batch_done$(_system_0, _count_0, _clock_0, _logs_1, _bindings_1, _worldName_1, _step_1, _prior_1, _events_1, _audit_0, _run_0, ($structural$045invoker$058prototype_slot_host_health_inserts$(_world_1, _p_1, _a_1, _c_0, _b_1, ($cached$045payload$058prototype_slot_vitals_new$({$: "types.Vitals", "levels": ($systems$058quad$(71, 72, 73, 74)), "reserve": 9, "class": 2})), ($cached$045payload$058prototype_slot_vitals_new$({$: "types.Vitals", "levels": ($systems$058quad$(80, 81, 82, 83)), "reserve": 9, "class": 2})), ($cached$045payload$058prototype_slot_vitals_new$({$: "types.Vitals", "levels": ($systems$058quad$(30, 31, 32, 33)), "reserve": 9, "class": 2})), ($cached$045payload$058prototype_slot_vitals_new$({$: "types.Vitals", "levels": ($systems$058quad$(81, 82, 83, 84)), "reserve": 9, "class": 2})), ($cached$045payload$058prototype_slot_vitals_new$({$: "types.Vitals", "levels": ($systems$058quad$(90, 91, 92, 93)), "reserve": 9, "class": 2})))));
          } else {
            return run_clo((_x_3) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Failure", "code": 7}, {$: "None"}, {$: "Nil"}, {$: "host.Host", "world": _world_1, "logs": _logs_1, "bindings": _bindings_1, "worldName": _worldName_1, "step": _step_1, "prior": _prior_1, "events": _events_1}, _run_0)), _x_3);
});
          }
        } else {
          return run_clo((_x_4) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Failure", "code": 7}, {$: "None"}, {$: "Nil"}, {$: "host.Host", "world": _world_1, "logs": _logs_1, "bindings": _bindings_1, "worldName": _worldName_1, "step": _step_1, "prior": _prior_1, "events": _events_1}, _run_0)), _x_4);
});
        }
      } else {
        return run_clo((_x_5) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Failure", "code": 7}, {$: "None"}, {$: "Nil"}, {$: "host.Host", "world": _world_1, "logs": _logs_1, "bindings": _bindings_1, "worldName": _worldName_1, "step": _step_1, "prior": _prior_1, "events": _events_1}, _run_0)), _x_5);
});
      }
    } else {
      return run_clo((_x_6) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Failure", "code": 7}, {$: "None"}, {$: "Nil"}, {$: "host.Host", "world": _world_1, "logs": _logs_1, "bindings": _bindings_1, "worldName": _worldName_1, "step": _step_1, "prior": _prior_1, "events": _events_1}, _run_0)), _x_6);
});
    }
  } else if (_kind_0.$ === "schedule.Dispose") {
    const _world_2 = _owner_0["world"];
    const _logs_2 = _owner_0["logs"];
    const _bindings_2 = _owner_0["bindings"];
    const _worldName_2 = _owner_0["worldName"];
    const _step_2 = _owner_0["step"];
    const _prior_2 = _owner_0["prior"];
    const _events_2 = _owner_0["events"];
    if (_ha_0.$ === "Some") {
      const _a_2 = _ha_0["value"];
      if (_hc_0.$ === "Some") {
        const _c_1 = _hc_0["value"];
        if (_hp_0.$ === "Some") {
          const _p_2 = _hp_0["value"];
          if (_hr_0.$ === "Some") {
            const _r_0 = _hr_0["value"];
            return $host$058prototype_slot_host_health_batch_done$(_system_0, _count_0, _clock_0, _logs_2, _bindings_2, _worldName_2, _step_2, _prior_2, _events_2, _audit_0, _run_0, ($structural$045invoker$058prototype_slot_host_health_dispose$(_world_2, _c_1, _a_2, _p_2, _r_0)));
          } else {
            return run_clo((_x_7) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Failure", "code": 7}, {$: "None"}, {$: "Nil"}, {$: "host.Host", "world": _world_2, "logs": _logs_2, "bindings": _bindings_2, "worldName": _worldName_2, "step": _step_2, "prior": _prior_2, "events": _events_2}, _run_0)), _x_7);
});
          }
        } else {
          return run_clo((_x_8) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Failure", "code": 7}, {$: "None"}, {$: "Nil"}, {$: "host.Host", "world": _world_2, "logs": _logs_2, "bindings": _bindings_2, "worldName": _worldName_2, "step": _step_2, "prior": _prior_2, "events": _events_2}, _run_0)), _x_8);
});
        }
      } else {
        return run_clo((_x_9) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Failure", "code": 7}, {$: "None"}, {$: "Nil"}, {$: "host.Host", "world": _world_2, "logs": _logs_2, "bindings": _bindings_2, "worldName": _worldName_2, "step": _step_2, "prior": _prior_2, "events": _events_2}, _run_0)), _x_9);
});
      }
    } else {
      return run_clo((_x_10) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Failure", "code": 7}, {$: "None"}, {$: "Nil"}, {$: "host.Host", "world": _world_2, "logs": _logs_2, "bindings": _bindings_2, "worldName": _worldName_2, "step": _step_2, "prior": _prior_2, "events": _events_2}, _run_0)), _x_10);
});
    }
  } else {
    return run_clo((_x_11) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Failure", "code": 7}, {$: "None"}, {$: "Nil"}, _owner_0, _run_0)), _x_11);
});
  }
}

function $host$058done_run$(_system_0, _count_0, _clock_0, _audit_0, _outcome_0, _escaped_0, _observations_0, _owner_0, _info_0) {
  const _world_0 = _owner_0["world"];
  const _logs_0 = _owner_0["logs"];
  const _bindings_0 = _owner_0["bindings"];
  const _worldName_0 = _owner_0["worldName"];
  const _step_0 = _owner_0["step"];
  const _prior_0 = _owner_0["prior"];
  const _events_0 = _owner_0["events"];
  const _run_0 = _info_0["run"];
  const _boundary_0 = _info_0["boundary"];
  return {$: "dispatcher.Invoked", "world": {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": ($host$058diag_event$(_system_0, _count_0, _clock_0, _outcome_0, _boundary_0, _events_0, _step_0, ($host$058lag_find$(_system_0, _count_0, _events_0))))}, "audit": _audit_0, "run": {$: "Some", "value": _run_0}, "outcome": _outcome_0, "clock": _clock_0, "escaped": _escaped_0, "observations": _observations_0};
}

function $readers$058project$(_run_0) {
  const _key_0 = _run_0["key"];
  const _interests_0 = _run_0["interests"];
  const _state_0 = _run_0["state"];
  const _boundary_0 = _run_0["boundary"];
  return {$: "readers.RunInfo", "run": {$: "readers.Run", "key": _key_0, "interests": _interests_0, "state": _state_0, "boundary": _boundary_0}, "state": _state_0, "boundary": _boundary_0};
}

function $host$058foreign_result$1263$(_logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Con") {
    const _t_1 = _t_0["head"];
    const _label_0 = _t_1["label"];
    const _handle_0 = _t_1["handle"];
    const _value_0 = _t_1["result"];
    return {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": ($List$append$(_events_0, {$: "Con", "head": {$: "host-observations.ForeignLookup", "step": _step_0, "receiver": _worldName_0, "source": ($host$058foreign_source$(_worldName_0)), "label": _label_0, "handle": _handle_0, "result": _value_0}, "tail": {$: "Nil"}}))};
  } else {
    return {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0};
  }
}

function $host$058lookups$1263$(_bindings_0, _world_0) {
  if (_bindings_0.$ === "Nil") {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Nil"}};
  } else {
    const _t_0 = _bindings_0["head"];
    const _label_0 = _t_0["label"];
    const _handle_0 = _t_0["handle"];
    const _tail_0 = _bindings_0["tail"];
    return $host$058lookup_join$1263$(_label_0, _handle_0, ($host$058lookups$1263$(_tail_0, _world_0)));
  }
}

function $host$058snapshot$1263$(_owner_0) {
  return $host$058snapshot_required$1263$(($host$058query$1263$({$: "query.Required"}, _owner_0)));
}

function $cached$045payload$058prototype_slot_vitals_new$(_raw_0) {
  return $cached$045payload$058prototype_slot_vitals_result$(($uncached$045payload$058vitals_get$(_raw_0)));
}

function $host$058prototype_slot_host_health_reserve_view$(_label_0, _world_0, _logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _result_0) {
  const _bundle_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return $host$058prototype_slot_host_health_reserved$(_label_0, _logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _view_0, ($commands$058reserve$(_world_0, _bundle_0)));
}

function $observations$058bundle$1263$(_owner_0) {
  const _main_0 = _owner_0["main"];
  const _aux_0 = _owner_0["aux"];
  const _flag_0 = _owner_0["flag"];
  return $observations$058bundle_main$1263$(_aux_0, _flag_0, ($observations$058maybe_get$1265$(_main_0)));
}

function $storage$058place_meta$(_main_0, _aux_0, _capacity_0, _depth_0, _high_0, _row_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _meta_0 = _result_0["snd"];
  return $storage$058place_metadata$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _row_0, _meta_0);
}

function $storage$058metadata_live$(_columns_0, _index_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  return $storage$058metadata_live_done$(_flags_0, _added_0, _changed_0, {$: "Tuple", fst: _live_0, snd: _live_0[_index_0 % _live_0.length]});
}

function $storage$058slots_empty$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _d_0 = (_depth_0 - 1);
    return array_node(($storage$058slots_empty$(_d_0)), ($storage$058slots_empty$(_d_0)));
  }
}

function $storage$058metadata_grow$(_columns_0, _depth_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  const _x_0 = {$: "None"};
  return {$: "storage.MetadataColumns", "live": array_node(_live_0, array_new(_depth_0, false)), "flags": array_node(_flags_0, array_new(_depth_0, _x_0)), "added": array_node(_added_0, array_new(_depth_0, 0)), "changed": array_node(_changed_0, array_new(_depth_0, 0))};
}

function $storage$058replace_main_done$(_id_0, _tick_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _insert_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return $storage$058replace_main_effect$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _insert_0, _old_0);
}

function $storage$058metadata_get_added$(_live_0, _flags_0, _changed_0, _index_0, _l_0, _f_0, _result_0) {
  const _added_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return $storage$058metadata_get_changed$(_live_0, _flags_0, _added_0, _l_0, _f_0, _a_0, {$: "Tuple", fst: _changed_0, snd: _changed_0[_index_0 % _changed_0.length]});
}

function $storage$058extract_aux$(_id_0, _main_0, _value_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _av_0 = _result_0["snd"];
  return $storage$058extract_row$(_id_0, _main_0, _value_0, _aux_0, _av_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0);
}

function $host$058read_delivery$(_system_0, _count_0, _world_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _query_0, _rows_0, _result_0) {
  const _logs_0 = _result_0["logs"];
  const _run_0 = _result_0["run"];
  const _t_0 = _result_0["delivery"];
  const _boundary_0 = _t_0["boundary"];
  const _messages_0 = _t_0["messages"];
  const _removed_0 = _t_0["removed"];
  const _despawned_0 = _t_0["despawned"];
  const _messageLag_0 = _t_0["messageLag"];
  const _removedLag_0 = _t_0["removedLag"];
  const _despawnedLag_0 = _t_0["despawnedLag"];
  return {$: "Tuple", "fst": {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": ($List$append$(_events_0, {$: "Con", "head": {$: "host-observations.Read", "step": _step_0, "system": _system_0, "count": _count_0, "boundary": _boundary_0, "query": _query_0, "added": run_loop($host$058filter_mark$(_rows_0, false, ($host$058read_since$(_boundary_0)), ($host$058read_now$(_boundary_0)), _query_0)), "changed": run_loop($host$058filter_mark$(_rows_0, true, ($host$058read_since$(_boundary_0)), ($host$058read_now$(_boundary_0)), _query_0)), "removed": _removed_0, "despawned": _despawned_0, "messages": _messages_0, "messageLag": _messageLag_0, "removedLag": _removedLag_0, "despawnedLag": _despawnedLag_0}, "tail": {$: "Nil"}}))}, "snd": _run_0};
}

function $reader$045host$058read$(_logs_0, _run_0) {
  return $reader$045host$058read_info$(_logs_0, ($readers$058project$(_run_0)));
}

function $observations$058world_rows$1263$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return $observations$058world_commands$1263$(_namespace_0, _next_0, _owners_0, _values_0, _ledger_0, _mode_0, ($observations$058commands$1263$(_pending_0)));
}

function $observations$058rows$1263$(_owners_0) {
  return $observations$058rows_start$1263$(($storage$058rows_high_water$(_owners_0)));
}

function $query$058each_return$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _observations_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": _observations_0};
}

function $query$058read_rows$1263$(_rows_0, _selection_0, _namespace_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _t_0 = _rows_0["metadata"];
  const _live_0 = _t_0["live"];
  const _flags_0 = _t_0["flags"];
  const _added_0 = _t_0["added"];
  const _changed_0 = _t_0["changed"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $query$058struct_idx_go$1263$(_high_0, 1, _capacity_0, _depth_0, _high_0, _selection_0, _namespace_0, {$: "query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": {$: "Nil"}});
}

function $systems$058prototype_slot_host_health_a$(_count_0, _rejected_0, _set_main_0, _set_ledger_0, _read_main_0, _read_ledger_0, _spawn_flagged_0, _remove_0, _ping_0, _log_0, _owner_0) {
  return $systems$058prototype_slot_host_health_a_main$(_count_0, _rejected_0, _read_ledger_0, _spawn_flagged_0, _remove_0, _ping_0, _log_0, _read_main_0(_set_ledger_0(_set_main_0(_owner_0)({$: "types.VitalsToken"})(11))({$: "types.HealthLedgerToken"})(101))({$: "types.VitalsToken"}));
}

function $audited$045invoker$058prototype_slot_host_health_set_main0$(_owner_0, _token_0, _value_0) {
  const _transaction_0 = _owner_0["transaction"];
  const _audit_0 = _owner_0["audit"];
  return {$: "audited-invoker.Wrapped", "transaction": ($transaction$045dispatch$045adapters$058prototype_packed_health_set_main0$(_transaction_0, _token_0, _value_0)), "audit": _audit_0};
}

function $audited$045invoker$058prototype_slot_host_health_set_ledger0$(_owner_0, _token_0, _value_0) {
  const _transaction_0 = _owner_0["transaction"];
  const _audit_0 = _owner_0["audit"];
  return {$: "audited-invoker.Wrapped", "transaction": ($transaction$045dispatch$045adapters$058prototype_packed_health_set_ledger0$(_transaction_0, _token_0, _value_0)), "audit": _audit_0};
}

function $audited$045invoker$058prototype_slot_host_health_read_main$(_owner_0, _token_0) {
  const _transaction_0 = _owner_0["transaction"];
  const _audit_0 = _owner_0["audit"];
  return $audited$045invoker$058prototype_slot_host_health_read_main_pair$(_audit_0, ($transaction$045dispatch$045adapters$058prototype_packed_health_read_main$(_transaction_0, _token_0)));
}

function $audited$045invoker$058prototype_slot_host_health_read_ledger$(_owner_0, _token_0) {
  const _transaction_0 = _owner_0["transaction"];
  const _audit_0 = _owner_0["audit"];
  return $audited$045invoker$058prototype_slot_host_health_read_ledger_pair$(_audit_0, ($transaction$045dispatch$045adapters$058prototype_packed_health_read_ledger$(_transaction_0, _token_0)));
}

function $audited$045invoker$058prototype_slot_host_health_spawn_flagged$(_owner_0, _payload_0) {
  const _transaction_0 = _owner_0["transaction"];
  const _audit_0 = _owner_0["audit"];
  return $audited$045invoker$058prototype_slot_host_health_spawn_flagged_result$(_audit_0, ($transaction$045dispatch$045adapters$058prototype_packed_health_spawn_flagged$(_transaction_0, _payload_0)));
}

function $audited$045invoker$058prototype_slot_host_health_remove_flag$(_owner_0) {
  const _transaction_0 = _owner_0["transaction"];
  const _audit_0 = _owner_0["audit"];
  return {$: "audited-invoker.Wrapped", "transaction": ($transaction$045dispatch$045adapters$058prototype_packed_health_remove_flag$(_transaction_0)), "audit": _audit_0};
}

function $audited$045invoker$058prototype_slot_host_health_emit$(_owner_0, _token_0) {
  const _transaction_0 = _owner_0["transaction"];
  const _audit_0 = _owner_0["audit"];
  return {$: "audited-invoker.Wrapped", "transaction": ($transaction$045dispatch$045adapters$058prototype_packed_health_emit$(_transaction_0, _token_0)), "audit": _audit_0};
}

function $audited$045invoker$058prototype_slot_host_health_log$(_owner_0, _text_0) {
  return $audited$045invoker$058log$(_owner_0, _text_0);
}

function $transaction$058tx_begin$(_world_0, _selected_0) {
  return {$: "transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "pings": {$: "Nil"}, "marks": {$: "Nil"}};
}

function $audited$045invoker$058prototype_slot_host_health_finished$(_tick_0, _lookup_0, _result_0) {
  const _t_0 = _result_0["transaction"];
  const _t_1 = _t_0["transaction"];
  const _world_0 = _t_1["world"];
  const _selected_0 = _t_1["selected"];
  const _undo_0 = _t_1["undo"];
  const _commands_0 = _t_1["commands"];
  const _pings_0 = _t_1["pings"];
  const _marks_0 = _t_1["marks"];
  const _audit_0 = _t_0["audit"];
  const _outcome_0 = _result_0["outcome"];
  const _escaped_0 = _result_0["escaped"];
  const _observations_0 = _result_0["observations"];
  return $audited$045invoker$058prototype_slot_host_health_inspected$(_tick_0, _lookup_0, _audit_0, _world_0, _selected_0, _undo_0, _pings_0, _marks_0, _outcome_0, _escaped_0, _observations_0, ($observations$058commands$1263$(_commands_0)));
}

function $host$058prototype_slot_host_health_published$(_system_0, _count_0, _audit_0, _outcome_0, _escaped_0, _views_0, _run_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _clock_0 = _result_0["snd"];
  return run_clo((_x_0) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, {$: "Some", "value": _audit_0}, _outcome_0, _escaped_0, _views_0, _owner_0, _run_0)), _x_0);
});
}

function $host$058publish$(_owner_0, _clock_0, _values_0) {
  const _world_0 = _owner_0["world"];
  const _logs_0 = _owner_0["logs"];
  const _bindings_0 = _owner_0["bindings"];
  const _worldName_0 = _owner_0["worldName"];
  const _step_0 = _owner_0["step"];
  const _prior_0 = _owner_0["prior"];
  const _events_0 = _owner_0["events"];
  if (_values_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, "snd": _clock_0};
  } else {
    const _head_0 = _values_0["head"];
    const _tail_0 = _values_0["tail"];
    const _next_0 = ($readers$058advance$(_clock_0));
    return {$: "Tuple", "fst": {$: "host.Host", "world": _world_0, "logs": ($reader$045host$058append_ping$(_logs_0, ($dispatcher$058clock_tick$(_next_0)), {$: "Con", "head": _head_0, "tail": _tail_0})), "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, "snd": _next_0};
  }
}

function $host$058own_record$(_write_0, _system_0, _views_0, _owner_0) {
  if (!_write_0) {
    return _owner_0;
  } else {
    const _world_0 = _owner_0["world"];
    const _logs_0 = _owner_0["logs"];
    const _bindings_0 = _owner_0["bindings"];
    const _worldName_0 = _owner_0["worldName"];
    const _step_0 = _owner_0["step"];
    const _prior_0 = _owner_0["prior"];
    const _events_0 = _owner_0["events"];
    return {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": ($List$append$(_events_0, {$: "Con", "head": {$: "host-observations.OwnWrites", "step": _step_0, "system": _system_0, "views": ($host$058own_values$(_views_0))}, "tail": {$: "Nil"}}))};
  }
}

function $host$058own_writes$(_kind_0, _mode_0) {
  if (_kind_0.$ === "schedule.A") {
    return true;
  } else if (_kind_0.$ === "schedule.B") {
    return $systems$058writes$(_mode_0);
  } else {
    return false;
  }
}

function $host$058reserve_record$(_label_0, _escaped_0, _components_0, _owner_0) {
  if (_escaped_0.$ === "Some") {
    const _handle_0 = _escaped_0["value"];
    if (_components_0.$ === "Some") {
      const _values_0 = _components_0["value"];
      const _world_0 = _owner_0["world"];
      const _logs_0 = _owner_0["logs"];
      const _bindings_0 = _owner_0["bindings"];
      const _worldName_0 = _owner_0["worldName"];
      const _step_0 = _owner_0["step"];
      const _prior_0 = _owner_0["prior"];
      const _events_0 = _owner_0["events"];
      return {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": ($List$append$(_bindings_0, {$: "Con", "head": {$: "host-observations.Binding", "label": _label_0, "handle": _handle_0}, "tail": {$: "Nil"}})), "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": ($List$append$(_events_0, {$: "Con", "head": {$: "host-observations.Reserved", "step": _step_0, "worldName": _worldName_0, "label": _label_0, "handle": _handle_0, "components": _values_0}, "tail": {$: "Nil"}}))};
    } else {
      return _owner_0;
    }
  } else {
    return _owner_0;
  }
}

function $host$058reservation_name$(_kind_0, _mode_0) {
  if (_kind_0.$ === "schedule.A") {
    return "p";
  } else if (_kind_0.$ === "schedule.B") {
    if (_mode_0.$ === "schedule.BFail") {
      return "q";
    } else {
      return "r";
    }
  } else {
    return "";
  }
}

function $host$058prototype_slot_host_health_pings$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _value_0 = _values_0["head"];
    const _tail_0 = _values_0["tail"];
    return {$: "Con", "head": {$: "types.HealthPing", "code": _value_0}, "tail": ($host$058prototype_slot_host_health_pings$(_tail_0))};
  }
}

function $systems$058prototype_slot_host_health_b$(_mode_0, _count_0, _before_0, _first_0, _between_0, _second_0, _after_0, _ledger_0, _set_ledger_0, _spawn_0, _flag_0, _ping_0, _log_0, _owner_0) {
  return $systems$058prototype_slot_host_health_before$(_mode_0, _count_0, _first_0, _between_0, _second_0, _after_0, _ledger_0, _set_ledger_0, _spawn_0, _flag_0, _ping_0, _log_0, _before_0(_owner_0)({$: "types.VitalsToken"}));
}

function $audited$045invoker$058prototype_slot_host_health_spawn_main$(_owner_0, _payload_0) {
  const _transaction_0 = _owner_0["transaction"];
  const _audit_0 = _owner_0["audit"];
  return $audited$045invoker$058prototype_slot_host_health_spawn_main_result$(_audit_0, ($transaction$045dispatch$045adapters$058prototype_packed_health_spawn_main$(_transaction_0, _payload_0)));
}

function $audited$045invoker$058prototype_slot_host_health_insert_flag$(_owner_0, _token_0) {
  const _transaction_0 = _owner_0["transaction"];
  const _audit_0 = _owner_0["audit"];
  return {$: "audited-invoker.Wrapped", "transaction": ($transaction$045dispatch$045adapters$058prototype_packed_health_insert_flag$(_transaction_0, _token_0)), "audit": _audit_0};
}

function $host$058prototype_slot_host_health_cleanup_done$(_system_0, _count_0, _clock_0, _logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _audit_0, _run_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _outcome_0 = _result_0["outcome"];
  const _pings_0 = _result_0["pings"];
  return $host$058prototype_slot_host_health_structural_published$(_system_0, _count_0, _audit_0, _outcome_0, _run_0, ($host$058publish$({$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, _clock_0, ($host$058prototype_slot_host_health_pings$(_pings_0)))));
}

function $structural$045invoker$058prototype_slot_host_health_cleanup$(_world_0, _p_0, _a_0, _b_0, _tick_0) {
  return $structural$045invoker$058prototype_slot_host_health_cleanup_result$(_tick_0, ($structural$045invoker$058prototype_slot_host_health_cleanup_body$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $transaction$045dispatch$045adapters$058prototype_packed_health_set_main0$(_x_0, _x_1, _x_2);
});
});
}), run_clo((_x_3) => {
  return $structural$045invoker$058prototype_slot_host_health_stage_remove$(_x_3, _a_0);
}), run_clo((_x_4) => {
  return $structural$045invoker$058prototype_slot_host_health_stage_despawn$(_x_4, _b_0);
}), run_clo((_x_5) => {
  return run_clo((_x_6) => {
  return $transaction$045dispatch$045adapters$058prototype_packed_health_emit$(_x_5, _x_6);
});
}), ($transaction$058tx_begin$(_world_0, _p_0)))));
}

function $host$058prototype_slot_host_health_batch_done$(_system_0, _count_0, _clock_0, _logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _audit_0, _run_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["rejected"];
  if (_t_0.$ === "Nil") {
    return run_clo((_x_0) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Success"}, {$: "None"}, {$: "Nil"}, {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, _run_0)), _x_0);
});
  } else {
    return run_clo((_x_1) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, {$: "types.Failure", "code": 7}, {$: "None"}, {$: "Nil"}, {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, _run_0)), _x_1);
});
  }
}

function $structural$045invoker$058prototype_slot_host_health_inserts$(_world_0, _p_0, _a_0, _c_0, _b_0, _p71_0, _a80_0, _c30_0, _a81_0, _b90_0) {
  return $structural$045invoker$058prototype_slot_host_health_insert$(($structural$045invoker$058prototype_slot_host_health_insert$(($structural$045invoker$058prototype_slot_host_health_insert$(($structural$045invoker$058prototype_slot_host_health_insert$(($structural$045invoker$058prototype_slot_host_health_insert$({$: "structural-invoker.Batch", "world": _world_0, "rejected": {$: "Nil"}}, _p_0, _p71_0)), _a_0, _a80_0)), _c_0, _c30_0)), _a_0, _a81_0)), _b_0, _b90_0);
}

function $structural$045invoker$058prototype_slot_host_health_dispose$(_world_0, _c_0, _a_0, _p_0, _r_0) {
  return $structural$045invoker$058prototype_slot_host_health_despawn$(($structural$045invoker$058prototype_slot_host_health_despawn$(($structural$045invoker$058prototype_slot_host_health_despawn$(($structural$045invoker$058prototype_slot_host_health_despawn$(($structural$045invoker$058prototype_slot_host_health_remove$({$: "structural-invoker.Batch", "world": _world_0, "rejected": {$: "Nil"}}, _c_0)), _a_0)), _p_0)), _r_0)), _c_0);
}

function $host$058diag_event$(_system_0, _count_0, _clock_0, _outcome_0, _boundary_0, _events_0, _step_0, _lag_0) {
  if (_lag_0.$ === "None") {
    return _events_0;
  } else {
    const _t_0 = _lag_0["value"];
    const _m_0 = _t_0["message"];
    const _r_0 = _t_0["removed"];
    const _d_0 = _t_0["despawned"];
    return $List$append$(_events_0, {$: "Con", "head": {$: "host-observations.ReadDone", "step": _step_0, "system": _system_0, "frame": ($host$058clock_frame$(_clock_0)), "tick": ($host$058read_now$(_boundary_0)), "outcome": _outcome_0, "messageLag": _m_0, "removedLag": _r_0, "despawnedLag": _d_0}, "tail": {$: "Nil"}});
  }
}

function $host$058lag_find$($0, $1, $2) {
  for (;;) {
    {
      const _system_0 = $0;
      const _count_0 = $1;
      const _events_0 = $2;
      if (_events_0.$ === "Nil") {
        return {$: "None"};
      } else {
        const _t_0 = _events_0["head"];
        if (_t_0.$ === "host-observations.Read") {
          const _name_0 = _t_0["system"];
          const _key_0 = _t_0["count"];
          const _m_0 = _t_0["messageLag"];
          const _r_0 = _t_0["removedLag"];
          const _d_0 = _t_0["despawnedLag"];
          const _tail_0 = _events_0["tail"];
          return $host$058lag_keep$(($host$058lag_find$(_system_0, _count_0, _tail_0)), ($host$058lag_match$(($Bool$and$(($String$eq$(_system_0, _name_0)), (_count_0 === _key_0))), {$: "host.Lag", "message": _m_0, "removed": _r_0, "despawned": _d_0})));
        } else {
          const _tail_1 = _events_0["tail"];
          $0 = _system_0;
          $1 = _count_0;
          $2 = _tail_1;
          continue;
        }
      }
    }
  }
}

function $host$058foreign_source$(_receiver_0) {
  return $host$058foreign_source_case$(($String$eq$(_receiver_0, "alpha")));
}

function $host$058lookup_join$1263$(_label_0, _handle_0, _tail_0) {
  const _world_0 = _tail_0["fst"];
  const _values_0 = _tail_0["snd"];
  return $host$058lookup_result$1263$(_label_0, _handle_0, _values_0, ($query$058lookup$1267$({$: "query.Required"}, _world_0, _handle_0)));
}

function $host$058snapshot_required$1263$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _required_0 = _result_0["snd"];
  return $host$058snapshot_plus$1263$(_required_0, ($host$058query$1263$({$: "query.Present"}, _owner_0)));
}

function $cached$045payload$058prototype_slot_vitals_result$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _levels_0 = _t_0["levels"];
  const _rawreserve_0 = _t_0["reserve"];
  const _rawclass_0 = _t_0["class"];
  const _t_1 = _result_0["snd"];
  const _t_2 = _t_1["levels"];
  const _a_0 = _t_2["a"];
  const _b_0 = _t_2["b"];
  const _c_0 = _t_2["c"];
  const _d_0 = _t_2["d"];
  const _cachedreserve_0 = _t_1["reserve"];
  const _cachedclass_0 = _t_1["class"];
  return {$: "cached-payload.PrototypeHealthMainSlot", "levels": _levels_0, "rawreserve": _rawreserve_0, "rawclass": _rawclass_0, "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0, "cachedreserve": _cachedreserve_0, "cachedclass": _cachedclass_0};
}

function $uncached$045payload$058vitals_get$(_owner_0) {
  const _array_0 = _owner_0["levels"];
  const _reserve_0 = _owner_0["reserve"];
  const _class_0 = _owner_0["class"];
  return $uncached$045payload$058vitals_observed$(_reserve_0, _class_0, ($uncached$045payload$058four$(_array_0)));
}

function $host$058prototype_slot_host_health_reserved$(_label_0, _logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _view_0, _result_0) {
  if (_result_0.$ === "types.Reserved") {
    const _world_0 = _result_0["world"];
    const _handle_0 = _result_0["handle"];
    return $host$058reserve_record$(_label_0, {$: "Some", "value": _handle_0}, {$: "Some", "value": _view_0}, {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0});
  } else {
    const _world_1 = _result_0["world"];
    return {$: "host.Host", "world": _world_1, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": {$: "dispatcher.SetupRejected", "reason": "reservation bound"}, "events": _events_0};
  }
}

function $commands$058reserve$(_world_0, _bundle_0) {
  return $commands$058reserved$(_bundle_0, ($identity$058reserve_id$(_world_0)));
}

function $observations$058bundle_main$1263$(_aux_0, _flag_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $observations$058bundle_aux$(_main_0, _value_0, _flag_0, ($observations$058maybe_get$1262$(_aux_0)));
}

function $observations$058maybe_get$1265$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}};
  } else {
    const _owner_1 = _owner_0["value"];
    return $observations$058maybe_present$(($cached$045payload$058prototype_slot_vitals_get$(_owner_1)));
  }
}

function $storage$058place_metadata$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _row_0, _meta_0) {
  return $storage$058place_status$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, _row_0);
}

function $storage$058metadata_live_done$(_flags_0, _added_0, _changed_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "snd": _value_0};
}

function $storage$058replace_main_effect$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _insert_0, _old_0) {
  if (!_insert_0) {
    if (_old_0.$ === "None") {
      return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "storage.NoMainChange"}};
    } else {
      return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": ($storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": true, "flag": _flag_0, "added": 0, "changed": 0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "storage.RemovedMain"}};
    }
  } else {
    if (_old_0.$ === "None") {
      return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": ($storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": true, "flag": _flag_0, "added": _tick_0, "changed": _tick_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "storage.AddedMain"}};
    } else {
      return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": ($storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": true, "flag": _flag_0, "added": _added_0, "changed": _tick_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "storage.ChangedMain"}};
    }
  }
}

function $storage$058metadata_get_changed$(_live_0, _flags_0, _added_0, _l_0, _f_0, _a_0, _result_0) {
  const _changed_0 = _result_0["fst"];
  const _c_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "snd": {$: "storage.Metadata", "live": _l_0, "flag": _f_0, "added": _a_0, "changed": _c_0}};
}

function $storage$058extract_row$(_id_0, _main_0, _value_0, _aux_0, _av_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0) {
  const _flag_0 = _meta_0["flag"];
  const _added_0 = _meta_0["added"];
  const _changed_0 = _meta_0["changed"];
  return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "Some", "value": {$: "storage.Row", "id": _id_0, "main": _value_0, "aux": _av_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}}};
}

function $host$058filter_mark$(_rows_0, _changed_0, _since_0, _thisRun_0, _values_0) {
  return $host$058filter_mark_go$(_values_0, _rows_0, _changed_0, _since_0, _thisRun_0, {$: "Nil"});
}

function $host$058read_since$(_boundary_0) {
  const _since_0 = _boundary_0["since"];
  return _since_0;
}

function $host$058read_now$(_boundary_0) {
  const _thisRun_0 = _boundary_0["thisRun"];
  return _thisRun_0;
}

function $reader$045host$058read_info$(_logs_0, _info_0) {
  const _ping_0 = _logs_0["ping"];
  const _removed_0 = _logs_0["removed"];
  const _despawned_0 = _logs_0["despawned"];
  const _run_0 = _info_0["run"];
  const _boundary_0 = _info_0["boundary"];
  return $reader$045host$058read_ping$(_removed_0, _despawned_0, _boundary_0, ($streams$058read_ping$(_ping_0, _run_0)));
}

function $observations$058world_commands$1263$(_namespace_0, _next_0, _rows_0, _rowViews_0, _ledger_0, _mode_0, _result_0) {
  const _pending_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return $observations$058world_ledger$(_namespace_0, _next_0, _rows_0, _rowViews_0, _pending_0, _values_0, _mode_0, ($observations$058maybe_get$1267$(_ledger_0)));
}

function $observations$058commands$1263$(_owners_0) {
  if (_owners_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _owners_0["head"];
    const _tail_0 = _owners_0["tail"];
    return $observations$058commands_head$(($observations$058command$1263$(_head_0)), ($observations$058commands$1263$(_tail_0)));
  }
}

function $observations$058rows_start$1263$(_result_0) {
  const _owners_0 = _result_0["fst"];
  const _high_0 = _result_0["snd"];
  return $observations$058rows_go$1263$(_high_0, 1, {$: "Tuple", "fst": _owners_0, "snd": {$: "Nil"}});
}

function $storage$058rows_high_water$(_rows_0) {
  const _m_0 = _rows_0["main"];
  const _a_0 = _rows_0["aux"];
  const _f_0 = _rows_0["metadata"];
  const _c_0 = _rows_0["capacity"];
  const _d_0 = _rows_0["depth"];
  const _h_0 = _rows_0["high_water"];
  return {$: "Tuple", "fst": {$: "storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, "snd": _h_0};
}

function $query$058struct_idx_go$1263$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _id_0 = $1;
      const _capacity_0 = $2;
      const _depth_0 = $3;
      const _high_0 = $4;
      const _selection_0 = $5;
      const _namespace_0 = $6;
      const _state_0 = $7;
      if (_remaining_0 === 0) {
        return $query$058struct_cols_finish$(_capacity_0, _depth_0, _high_0, _state_0);
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = ((_id_0 + 1) >>> 0);
        $2 = _capacity_0;
        $3 = _depth_0;
        $4 = _high_0;
        $5 = _selection_0;
        $6 = _namespace_0;
        $7 = ($query$058struct_idx_advance$1263$(($Bool$and$((0 < _id_0), (_id_0 <= _capacity_0))), _id_0, _namespace_0, _selection_0, _state_0));
        continue;
      }
    }
  }
}

function $systems$058prototype_slot_host_health_a_main$(_count_0, _rejected_0, _ledger_0, _spawn_0, _remove_0, _ping_0, _log_0, _pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _view_0 = _pair_0["snd"];
  return $systems$058prototype_slot_host_health_a_ledger$(_count_0, _rejected_0, {$: "Con", "head": {$: "systems.MainObserved", "view": ($systems$058prototype_slot_host_health_view$(_view_0))}, "tail": {$: "Nil"}}, _spawn_0, _remove_0, _ping_0, _log_0, _ledger_0(_owner_0)({$: "types.HealthLedgerToken"}));
}

function $transaction$045dispatch$045adapters$058prototype_packed_health_set_main0$(_t_0, _token_0, _value_0) {
  return $transaction$058tx_set_main0$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $transaction$045dispatch$045adapters$058prototype_packed_health_world_write$(_x_0, _x_1, _x_2);
});
});
}), _t_0, _value_0);
}

function $transaction$045dispatch$045adapters$058prototype_packed_health_set_ledger0$(_t_0, _token_0, _value_0) {
  return $transaction$058tx_set_ledger0$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $transaction$045dispatch$045adapters$058prototype_packed_health_world_ledger_write$(_x_0, _x_1);
});
}), _t_0, _value_0);
}

function $audited$045invoker$058prototype_slot_host_health_read_main_pair$(_audit_0, _pair_0) {
  const _transaction_0 = _pair_0["fst"];
  const _value_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "audited-invoker.Wrapped", "transaction": _transaction_0, "audit": _audit_0}, "snd": _value_0};
}

function $transaction$045dispatch$045adapters$058prototype_packed_health_read_main$(_t_0, _token_0) {
  return $transaction$058tx_read_main$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $transaction$045dispatch$045adapters$058prototype_packed_health_world_read$(_x_0, _x_1);
});
}), _t_0);
}

function $audited$045invoker$058prototype_slot_host_health_read_ledger_pair$(_audit_0, _pair_0) {
  const _transaction_0 = _pair_0["fst"];
  const _value_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "audited-invoker.Wrapped", "transaction": _transaction_0, "audit": _audit_0}, "snd": _value_0};
}

function $transaction$045dispatch$045adapters$058prototype_packed_health_read_ledger$(_t_0, _token_0) {
  return $transaction$058tx_read_ledger$(run_clo((_x_0) => {
  return $transaction$045dispatch$045adapters$058prototype_packed_health_world_ledger_read$(_x_0);
}), _t_0);
}

function $audited$045invoker$058prototype_slot_host_health_spawn_flagged_result$(_audit_0, _result_0) {
  if (_result_0.$ === "types.Reserved") {
    const _transaction_0 = _result_0["world"];
    const _handle_0 = _result_0["handle"];
    return {$: "types.Reserved", "world": {$: "audited-invoker.Wrapped", "transaction": _transaction_0, "audit": _audit_0}, "handle": _handle_0};
  } else {
    const _transaction_1 = _result_0["world"];
    const _payload_0 = _result_0["payload"];
    return {$: "types.ReserveRejected", "world": {$: "audited-invoker.Wrapped", "transaction": _transaction_1, "audit": _audit_0}, "payload": _payload_0};
  }
}

function $transaction$045dispatch$045adapters$058prototype_packed_health_spawn_flagged$(_t_0, _main_0) {
  return $transaction$045dispatch$045adapters$058prototype_packed_health_spawn_main_finish$(_main_0, {$: "Some", "value": {$: "types.Tracked", "group": 8}}, ($transaction$058tx_reserve$(run_clo((_x_0) => {
  return $transaction$045dispatch$045adapters$058prototype_packed_health_world_reserve$(_x_0);
}), _t_0)));
}

function $transaction$045dispatch$045adapters$058prototype_packed_health_remove_flag$(_t_0) {
  const _world_0 = _t_0["world"];
  const _t_1 = _t_0["selected"];
  const _namespace_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return $transaction$058tx_stage_command$({$: "transaction.Tx", "world": _world_0, "selected": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}, {$: "storage.RemoveFlag", "id": _id_0});
}

function $transaction$045dispatch$045adapters$058prototype_packed_health_emit$(_t_0, _ping_0) {
  const _code_0 = _ping_0["code"];
  return $transaction$058tx_stage_ping$(_t_0, _code_0);
}

function $audited$045invoker$058log$(_owner_0, _text_0) {
  const _transaction_0 = _owner_0["transaction"];
  const _audit_0 = _owner_0["audit"];
  return run_clo((_x_0) => {
  return $IO$bind$(($dispatcher$058audit_log$(_audit_0, _text_0)), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$pure$({$: "audited-invoker.Wrapped", "transaction": _transaction_0, "audit": _x_1}, _x_2);
});
}), _x_0);
});
}

function $audited$045invoker$058prototype_slot_host_health_inspected$(_tick_0, _lookup_0, _audit_0, _world_0, _selected_0, _undo_0, _pings_0, _marks_0, _outcome_0, _escaped_0, _observations_0, _pair_0) {
  const _commands_0 = _pair_0["fst"];
  const _values_0 = _pair_0["snd"];
  return $audited$045invoker$058prototype_slot_host_health_inspected_world$(_tick_0, _lookup_0, _audit_0, _world_0, _selected_0, _undo_0, _pings_0, _marks_0, _outcome_0, _escaped_0, _observations_0, _commands_0, _values_0);
}

function $reader$045host$058append_ping$(_logs_0, _tick_0, _values_0) {
  const _ping_0 = _logs_0["ping"];
  const _removed_0 = _logs_0["removed"];
  const _despawned_0 = _logs_0["despawned"];
  return {$: "reader-host.Logs", "ping": ($streams$058append$(_ping_0, _tick_0, _values_0)), "removed": _removed_0, "despawned": _despawned_0};
}

function $host$058own_values$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _values_0["head"];
    if (_t_0.$ === "systems.MainObserved") {
      const _view_0 = _t_0["view"];
      const _tail_0 = _values_0["tail"];
      return {$: "Con", "head": {$: "host-observations.Main", "value": _view_0}, "tail": ($host$058own_values$(_tail_0))};
    } else if (_t_0.$ === "systems.LedgerObserved") {
      const _view_1 = _t_0["view"];
      const _tail_1 = _values_0["tail"];
      return {$: "Con", "head": {$: "host-observations.Ledger", "value": _view_1}, "tail": ($host$058own_values$(_tail_1))};
    } else {
      const _view_2 = _t_0["view"];
      const _tail_2 = _values_0["tail"];
      return {$: "Con", "head": {$: "host-observations.ReservedLookup", "value": _view_2}, "tail": ($host$058own_values$(_tail_2))};
    }
  }
}

function $systems$058prototype_slot_host_health_before$(_mode_0, _count_0, _first_0, _between_0, _second_0, _after_0, _ledger_0, _set_ledger_0, _spawn_0, _flag_0, _ping_0, _log_0, _pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _view_0 = _pair_0["snd"];
  return $systems$058prototype_slot_host_health_choose$(($systems$058writes$(_mode_0)), _mode_0, _count_0, _first_0, _between_0, _second_0, _after_0, _ledger_0, _set_ledger_0, _spawn_0, _flag_0, _ping_0, _log_0, _owner_0, {$: "Con", "head": {$: "systems.MainObserved", "view": ($systems$058prototype_slot_host_health_view$(_view_0))}, "tail": {$: "Nil"}});
}

function $audited$045invoker$058prototype_slot_host_health_spawn_main_result$(_audit_0, _result_0) {
  if (_result_0.$ === "types.Reserved") {
    const _transaction_0 = _result_0["world"];
    const _handle_0 = _result_0["handle"];
    return {$: "types.Reserved", "world": {$: "audited-invoker.Wrapped", "transaction": _transaction_0, "audit": _audit_0}, "handle": _handle_0};
  } else {
    const _transaction_1 = _result_0["world"];
    const _payload_0 = _result_0["payload"];
    return {$: "types.ReserveRejected", "world": {$: "audited-invoker.Wrapped", "transaction": _transaction_1, "audit": _audit_0}, "payload": _payload_0};
  }
}

function $transaction$045dispatch$045adapters$058prototype_packed_health_spawn_main$(_t_0, _main_0) {
  return $transaction$045dispatch$045adapters$058prototype_packed_health_spawn_main_finish$(_main_0, {$: "None"}, ($transaction$058tx_reserve$(run_clo((_x_0) => {
  return $transaction$045dispatch$045adapters$058prototype_packed_health_world_reserve$(_x_0);
}), _t_0)));
}

function $transaction$045dispatch$045adapters$058prototype_packed_health_insert_flag$(_t_0, _flag_0) {
  const _world_0 = _t_0["world"];
  const _t_1 = _t_0["selected"];
  const _namespace_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return $transaction$058tx_stage_command$({$: "transaction.Tx", "world": _world_0, "selected": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}, {$: "storage.InsertFlag", "id": _id_0, "flag": _flag_0});
}

function $host$058prototype_slot_host_health_structural_published$(_system_0, _count_0, _audit_0, _outcome_0, _run_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _clock_0 = _result_0["snd"];
  return run_clo((_x_0) => {
  return $IO$pure$(($host$058done$(_system_0, _count_0, _clock_0, _audit_0, _outcome_0, {$: "None"}, {$: "Nil"}, _owner_0, _run_0)), _x_0);
});
}

function $structural$045invoker$058prototype_slot_host_health_cleanup_result$(_tick_0, _result_0) {
  const _owner_0 = _result_0["transaction"];
  const _outcome_0 = _result_0["outcome"];
  const _observations_0 = _result_0["observations"];
  return $transaction$045dispatch$045adapters$058prototype_packed_health_finished$({$: "systems.BodyResult", "transaction": _owner_0, "outcome": _outcome_0, "escaped": {$: "None"}, "observations": _observations_0}, _tick_0);
}

function $structural$045invoker$058prototype_slot_host_health_cleanup_body$(_set_0, _remove_0, _despawn_0, _ping_0, _owner_0) {
  return {$: "systems.BodyResult", "transaction": _ping_0(_despawn_0(_remove_0(_set_0(_owner_0)({$: "types.VitalsToken"})(51))))({$: "types.HealthPing", "code": 3}), "outcome": {$: "types.Success"}, "escaped": {$: "None"}, "observations": {$: "Nil"}};
}

function $structural$045invoker$058prototype_slot_host_health_stage_remove$(_owner_0, _handle_0) {
  const _id_0 = _handle_0["id"];
  return $transaction$058tx_stage_command$(_owner_0, {$: "storage.RemoveMain", "id": _id_0});
}

function $structural$045invoker$058prototype_slot_host_health_stage_despawn$(_owner_0, _handle_0) {
  const _id_0 = _handle_0["id"];
  return $transaction$058tx_stage_command$(_owner_0, {$: "storage.Despawn", "id": _id_0});
}

function $structural$045invoker$058prototype_slot_host_health_insert$(_owner_0, _handle_0, _payload_0) {
  const _world_0 = _owner_0["world"];
  const _rejected_0 = _owner_0["rejected"];
  return $structural$045invoker$058queued$(_rejected_0, ($commands$058insert_main$(_world_0, _handle_0, _payload_0)));
}

function $structural$045invoker$058prototype_slot_host_health_despawn$(_owner_0, _handle_0) {
  const _world_0 = _owner_0["world"];
  const _rejected_0 = _owner_0["rejected"];
  return $structural$045invoker$058queued$(_rejected_0, ($commands$058despawn$(_world_0, _handle_0)));
}

function $structural$045invoker$058prototype_slot_host_health_remove$(_owner_0, _handle_0) {
  const _world_0 = _owner_0["world"];
  const _rejected_0 = _owner_0["rejected"];
  return $structural$045invoker$058queued$(_rejected_0, ($commands$058remove_main$(_world_0, _handle_0)));
}

function $host$058lag_keep$(_tail_0, _head_0) {
  if (_tail_0.$ === "Some") {
    const _value_0 = _tail_0["value"];
    return {$: "Some", "value": _value_0};
  } else {
    return _head_0;
  }
}

function $host$058lag_match$(_hit_0, _value_0) {
  if (_hit_0) {
    return {$: "Some", "value": _value_0};
  } else {
    return {$: "None"};
  }
}

function $host$058foreign_source_case$(_isAlpha_0) {
  if (_isAlpha_0) {
    return "beta";
  } else {
    return "alpha";
  }
}

function $host$058lookup_result$1263$(_label_0, _handle_0, _tail_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": {$: "host-observations.Lookup", "label": _label_0, "handle": _handle_0, "result": _value_0}, "tail": _tail_0}};
}

function $query$058lookup$1267$(_selection_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  const _foreign_0 = _handle_0["namespace"];
  const _target_0 = _handle_0["id"];
  return $query$058lookup_checked$1267$((_namespace_0 === _foreign_0), _selection_0, {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, _target_0);
}

function $host$058snapshot_plus$1263$(_required_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _plus_0 = _result_0["snd"];
  return $host$058snapshot_minus$1263$(_required_0, _plus_0, ($host$058query$1263$({$: "query.Absent"}, _owner_0)));
}

function $uncached$045payload$058vitals_observed$(_reserve_0, _class_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "types.Vitals", "levels": _array_0, "reserve": _reserve_0, "class": _class_0}, "snd": {$: "types.VitalsView", "levels": _values_0, "reserve": _reserve_0, "class": _class_0}};
}

function $commands$058reserved$(_bundle_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "types.ReserveRejected", "world": _world_0, "payload": _bundle_0};
  } else {
    const _t_1 = _t_0["value"];
    const _namespace_0 = _t_1["namespace"];
    const _id_0 = _t_1["id"];
    return {$: "types.Reserved", "world": ($storage$058publish$(_world_0, {$: "Con", "head": {$: "storage.Spawn", "id": _id_0, "bundle": _bundle_0}, "tail": {$: "Nil"}})), "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}};
  }
}

function $identity$058reserve_id$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $identity$058reserve_checked$((_next_0 < 4294967295), _namespace_0, _next_0, _rows_0, _pending_0, _ledger_0, _mode_0);
}

function $observations$058bundle_aux$(_main_0, _value_0, _flag_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _auxView_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.Bundle", "main": _main_0, "aux": _aux_0, "flag": _flag_0}, "snd": {$: "observations.BundleView", "main": _value_0, "aux": _auxView_0, "flag": _flag_0}};
}

function $observations$058maybe_get$1262$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}};
  } else {
    const _owner_1 = _owner_0["value"];
    return $observations$058maybe_present$(($payload$058armor_get$(_owner_1)));
  }
}

function $observations$058maybe_present$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": _owner_0}, "snd": {$: "Some", "value": _value_0}};
}

function $cached$045payload$058prototype_slot_vitals_get$(_owner_0) {
  const _levels_0 = _owner_0["levels"];
  const _rawreserve_0 = _owner_0["rawreserve"];
  const _rawclass_0 = _owner_0["rawclass"];
  const _a_0 = _owner_0["a"];
  const _b_0 = _owner_0["b"];
  const _c_0 = _owner_0["c"];
  const _d_0 = _owner_0["d"];
  const _cachedreserve_0 = _owner_0["cachedreserve"];
  const _cachedclass_0 = _owner_0["cachedclass"];
  return {$: "Tuple", "fst": {$: "cached-payload.PrototypeHealthMainSlot", "levels": _levels_0, "rawreserve": _rawreserve_0, "rawclass": _rawclass_0, "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0, "cachedreserve": _cachedreserve_0, "cachedclass": _cachedclass_0}, "snd": {$: "types.VitalsView", "levels": {$: "types.Four", "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0}, "reserve": _cachedreserve_0, "class": _cachedclass_0}};
}

function $storage$058place_status$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _live_0, _row_0) {
  if (_live_0) {
    return {$: "storage.Rejected", "rows": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "row": _row_0};
  } else {
    const _id_0 = _row_0["id"];
    const _m_0 = _row_0["main"];
    const _a_0 = _row_0["aux"];
    const _f_0 = _row_0["flag"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = ((_id_0 - 1) >>> 0);
    return {$: "storage.Placed", "rows": {$: "storage.Rows", "main": (_main_0[_x_0 % _main_0.length] = _m_0, _main_0), "aux": (_aux_0[_x_1 % _aux_0.length] = _a_0, _aux_0), "metadata": ($storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "storage.Metadata", "live": true, "flag": _f_0, "added": _added_0, "changed": _changed_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": ($U32$max$(_high_0, _id_0))}};
  }
}

function $host$058filter_mark_go$(_values_0, _rows_0, _changed_0, _since_0, _thisRun_0, _reverse_0) {
  if (_values_0.$ === "Nil") {
    return $List$reverse$(_reverse_0);
  } else {
    const _value_0 = _values_0["head"];
    const _tail_0 = _values_0["tail"];
    return $host$058filter_mark_head$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $host$058filter_mark_go$(_tail_0, _x_0, _changed_0, _since_0, _thisRun_0, _x_1);
});
}), _changed_0, _since_0, _thisRun_0, _rows_0, _reverse_0, _value_0);
  }
}

function $reader$045host$058read_ping$(_removed_0, _despawned_0, _boundary_0, _result_0) {
  const _ping_0 = _result_0["log"];
  const _run_0 = _result_0["run"];
  const _messages_0 = _result_0["values"];
  const _lag_0 = _result_0["lagged"];
  return $reader$045host$058read_removed_missed$(_ping_0, _despawned_0, _boundary_0, _messages_0, _lag_0, ($streams$058missed$(_removed_0, _run_0)));
}

function $streams$058read_ping$(_log_0, _run_0) {
  return $streams$058ping_info$(_log_0, ($readers$058project$(_run_0)));
}

function $observations$058world_ledger$(_namespace_0, _next_0, _rows_0, _rowViews_0, _pending_0, _pendingViews_0, _mode_0, _result_0) {
  const _ledger_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "observations.WorldView", "namespace": _namespace_0, "next": _next_0, "rows": _rowViews_0, "pending": ($List$reverse$(_pendingViews_0)), "ledger": _value_0, "mode": _mode_0}};
}

function $observations$058maybe_get$1267$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}};
  } else {
    const _owner_1 = _owner_0["value"];
    return $observations$058maybe_present$(($cached$045payload$058health_ledger_get$(_owner_1)));
  }
}

function $observations$058commands_head$(_head_0, _tail_0) {
  const _owner_0 = _head_0["fst"];
  const _value_0 = _head_0["snd"];
  return $observations$058commands_tail$(_owner_0, _value_0, _tail_0);
}

function $observations$058command$1263$(_owner_0) {
  if (_owner_0.$ === "storage.Spawn") {
    const _id_0 = _owner_0["id"];
    const _value_0 = _owner_0["bundle"];
    return $observations$058command_spawn$(_id_0, ($observations$058bundle$1263$(_value_0)));
  } else if (_owner_0.$ === "storage.InsertMain") {
    const _id_1 = _owner_0["id"];
    const _value_1 = _owner_0["main"];
    return $observations$058command_main$(_id_1, ($cached$045payload$058prototype_slot_vitals_get$(_value_1)));
  } else if (_owner_0.$ === "storage.InsertFlag") {
    const _id_2 = _owner_0["id"];
    const _value_2 = _owner_0["flag"];
    return {$: "Tuple", "fst": {$: "storage.InsertFlag", "id": _id_2, "flag": _value_2}, "snd": {$: "observations.FlagView", "id": _id_2, "flag": _value_2}};
  } else if (_owner_0.$ === "storage.RemoveMain") {
    const _id_3 = _owner_0["id"];
    return {$: "Tuple", "fst": {$: "storage.RemoveMain", "id": _id_3}, "snd": {$: "observations.RemoveMainView", "id": _id_3}};
  } else if (_owner_0.$ === "storage.RemoveFlag") {
    const _id_4 = _owner_0["id"];
    return {$: "Tuple", "fst": {$: "storage.RemoveFlag", "id": _id_4}, "snd": {$: "observations.RemoveFlagView", "id": _id_4}};
  } else {
    const _id_5 = _owner_0["id"];
    return {$: "Tuple", "fst": {$: "storage.Despawn", "id": _id_5}, "snd": {$: "observations.DespawnView", "id": _id_5}};
  }
}

function $observations$058rows_go$1263$($0, $1, $2) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _id_0 = $1;
      const _state_0 = $2;
      if (_remaining_0 === 0) {
        return $observations$058rows_finish$(_state_0);
      } else {
        const _remaining_1 = (_remaining_0 - 1);
        $0 = _remaining_1;
        $1 = ((_id_0 + 1) >>> 0);
        $2 = ($observations$058rows_advance$1263$(_id_0, _state_0));
        continue;
      }
    }
  }
}

function $query$058struct_cols_finish$(_capacity_0, _depth_0, _high_0, _state_0) {
  const _main_0 = _state_0["main"];
  const _aux_0 = _state_0["aux"];
  const _live_0 = _state_0["live"];
  const _flags_0 = _state_0["flags"];
  const _added_0 = _state_0["added"];
  const _changed_0 = _state_0["changed"];
  const _values_0 = _state_0["values"];
  return $query$058struct_idx_finish$(_capacity_0, _depth_0, _high_0, {$: "query.StructIdxState", "main": _main_0, "aux": _aux_0, "metadata": {$: "storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "values": _values_0});
}

function $query$058struct_idx_advance$1263$(_valid_0, _id_0, _namespace_0, _selection_0, _state_0) {
  if (!_valid_0) {
    return _state_0;
  } else {
    const _main_0 = _state_0["main"];
    const _aux_0 = _state_0["aux"];
    const _live_0 = _state_0["live"];
    const _flags_0 = _state_0["flags"];
    const _added_0 = _state_0["added"];
    const _changed_0 = _state_0["changed"];
    const _values_0 = _state_0["values"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $query$058struct_cols_live$1263$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, {$: "Tuple", fst: _live_0, snd: _live_0[_x_0 % _live_0.length]});
  }
}

function $systems$058prototype_slot_host_health_a_ledger$(_count_0, _rejected_0, _observations_0, _spawn_0, _remove_0, _ping_0, _log_0, _pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _view_0 = _pair_0["snd"];
  return $systems$058prototype_slot_host_health_a_reserved$(_count_0, _rejected_0, ($List$append$(_observations_0, {$: "Con", "head": {$: "systems.LedgerObserved", "view": _view_0}, "tail": {$: "Nil"}})), _remove_0, _ping_0, _log_0, _spawn_0(_owner_0)(($cached$045payload$058prototype_slot_vitals_new$({$: "types.Vitals", "levels": ($systems$058quad$(50, 51, 52, 53)), "reserve": 9, "class": 2}))));
}

function $systems$058prototype_slot_host_health_view$(_access_0) {
  if (_access_0.$ === "types.Found") {
    const _view_0 = _access_0["value"];
    return {$: "types.Found", "value": {$: "types.HealthMain", "vitals": _view_0}};
  } else if (_access_0.$ === "types.Mismatch") {
    return {$: "types.Mismatch"};
  } else {
    return {$: "types.Missing"};
  }
}

function $transaction$058tx_set_main0$(_write_0, _t_0, _value_0) {
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return $transaction$058record_main$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _write_0(_world_0)(_selected_0)(_value_0));
}

function $transaction$045dispatch$045adapters$058prototype_packed_health_world_write$(_world_0, _handle_0, _value_0) {
  return $transaction$058storage_set_main0$1263$(_world_0, _handle_0, _value_0);
}

function $transaction$058tx_set_ledger0$(_write_0, _t_0, _value_0) {
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return $transaction$058record_ledger$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _write_0(_world_0)(_value_0));
}

function $transaction$045dispatch$045adapters$058prototype_packed_health_world_ledger_write$(_world_0, _value_0) {
  return $transaction$058storage_set_ledger0$1263$(_world_0, _value_0);
}

function $transaction$058tx_read_main$(_read_0, _t_0) {
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return $transaction$058read_main_finish$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _read_0(_world_0)(_selected_0));
}

function $transaction$045dispatch$045adapters$058prototype_packed_health_world_read$(_world_0, _handle_0) {
  return $storage$058with_main$(_world_0, _handle_0, run_clo((_x_0) => {
  return $cached$045payload$058prototype_slot_vitals_get$(_x_0);
}));
}

function $transaction$058tx_read_ledger$(_read_0, _t_0) {
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return $transaction$058read_ledger_finish$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _read_0(_world_0));
}

function $transaction$045dispatch$045adapters$058prototype_packed_health_world_ledger_read$(_world_0) {
  return $storage$058with_ledger$(_world_0, run_clo((_x_0) => {
  return $cached$045payload$058health_ledger_get$(_x_0);
}));
}

function $transaction$045dispatch$045adapters$058prototype_packed_health_spawn_main_finish$(_main_0, _flag_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _t_1 = _result_0["snd"];
  if (_t_1.$ === "None") {
    return {$: "types.ReserveRejected", "world": _t_0, "payload": _main_0};
  } else {
    const _t_2 = _t_1["value"];
    const _namespace_0 = _t_2["namespace"];
    const _id_0 = _t_2["id"];
    return {$: "types.Reserved", "world": ($transaction$058tx_stage_command$(_t_0, {$: "storage.Spawn", "id": _id_0, "bundle": {$: "storage.Bundle", "main": {$: "Some", "value": _main_0}, "aux": {$: "None"}, "flag": _flag_0}})), "handle": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}};
  }
}

function $transaction$058tx_reserve$(_reserve_0, _t_0) {
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return $transaction$058reserve_finish$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _reserve_0(_world_0));
}

function $transaction$045dispatch$045adapters$058prototype_packed_health_world_reserve$(_world_0) {
  return $identity$058reserve_id$(_world_0);
}

function $transaction$058tx_stage_command$(_t_0, _command_0) {
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return {$: "transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "pings": _pings_0, "marks": _marks_0};
}

function $transaction$058tx_stage_ping$(_t_0, _code_0) {
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return {$: "transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": {$: "Con", "head": _code_0, "tail": _pings_0}, "marks": _marks_0};
}

function $dispatcher$058audit_log$(_owner_0, _text_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $IO$print$(_text_0, _x_1), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $IO$pure$({$: "dispatcher.Console"}, _x_3);
});
}), _x_0);
});
}

function $audited$045invoker$058prototype_slot_host_health_inspected_world$(_tick_0, _lookup_0, _audit_0, _world_0, _selected_0, _undo_0, _pings_0, _marks_0, _outcome_0, _escaped_0, _observations_0, _commands_0, _values_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $audited$045invoker$058prototype_slot_host_health_inspected_values$(_tick_0, _lookup_0, _namespace_0, _audit_0, {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, _selected_0, _undo_0, _pings_0, _marks_0, _outcome_0, _escaped_0, _observations_0, _commands_0, _values_0);
}

function $streams$058append$(_log_0, _tick_0, _values_0) {
  const _buffer_0 = _log_0["buffer"];
  return {$: "streams.PingLog", "buffer": ($streams$058append_buffer$(_buffer_0, _tick_0, _values_0))};
}

function $systems$058prototype_slot_host_health_choose$(_write_0, _mode_0, _count_0, _first_0, _between_0, _second_0, _after_0, _ledger_0, _set_ledger_0, _spawn_0, _flag_0, _ping_0, _log_0, _owner_0, _observations_0) {
  if (!_write_0) {
    return run_clo((_x_0) => {
  return $IO$pure$({$: "systems.BodyResult", "transaction": _owner_0, "outcome": ($systems$058failed$(_mode_0)), "escaped": {$: "None"}, "observations": _observations_0}, _x_0);
});
  } else {
    return $systems$058prototype_slot_host_health_between$(_mode_0, _count_0, _observations_0, _second_0, _after_0, _ledger_0, _set_ledger_0, _spawn_0, _flag_0, _ping_0, _log_0, _between_0(_first_0(_owner_0)({$: "types.VitalsToken"})(30))({$: "types.VitalsToken"}));
  }
}

function $transaction$045dispatch$045adapters$058prototype_packed_health_finished$(_result_0, _tick_0) {
  const _owner_0 = _result_0["transaction"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "types.Success") {
    const _escaped_0 = _result_0["escaped"];
    const _observations_0 = _result_0["observations"];
    return $transaction$045dispatch$045adapters$058returned_run$({$: "types.Success"}, _escaped_0, _observations_0, ($transaction$058storage_commit$(($transaction$058tx_finish_success$(_owner_0)), _tick_0)));
  } else {
    const _code_0 = _t_0["code"];
    const _escaped_1 = _result_0["escaped"];
    const _observations_1 = _result_0["observations"];
    return $transaction$045dispatch$045adapters$058returned_run$({$: "types.Failure", "code": _code_0}, _escaped_1, _observations_1, ($transaction$058storage_commit$(($transaction$045dispatch$045adapters$058prototype_packed_health_finish_failure$(_owner_0)), _tick_0)));
  }
}

function $structural$045invoker$058queued$(_rejected_0, _result_0) {
  if (_result_0.$ === "types.CommandQueued") {
    const _world_0 = _result_0["world"];
    return {$: "structural-invoker.Batch", "world": _world_0, "rejected": _rejected_0};
  } else {
    const _world_1 = _result_0["world"];
    const _payload_0 = _result_0["payload"];
    return {$: "structural-invoker.Batch", "world": _world_1, "rejected": {$: "Con", "head": _payload_0, "tail": _rejected_0}};
  }
}

function $commands$058insert_main$(_world_0, _handle_0, _main_0) {
  return $commands$058queue_owned$(_world_0, _handle_0, _main_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $commands$058build_main$(_x_0, _x_1);
});
}));
}

function $commands$058despawn$(_world_0, _handle_0) {
  return $commands$058queue_owned$(_world_0, _handle_0, {$: "Unit"}, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $commands$058build_despawn$(_x_0, _x_1);
});
}));
}

function $commands$058remove_main$(_world_0, _handle_0) {
  return $commands$058queue_owned$(_world_0, _handle_0, {$: "Unit"}, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $commands$058build_remove_main$(_x_0, _x_1);
});
}));
}

function $query$058lookup_checked$1267$(_valid_0, _selection_0, _world_0, _target_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "types.Missing"}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _rows_0 = _world_0["rows"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return $query$058lookup_return$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, ($query$058lookup_rows$1267$(_rows_0, _selection_0, _namespace_0, _target_0)));
  }
}

function $host$058snapshot_minus$1263$(_required_0, _plus_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _minus_0 = _result_0["snd"];
  return $host$058snapshot_optional$1263$(_required_0, _plus_0, _minus_0, ($host$058query$1263$({$: "query.Optional"}, _owner_0)));
}

function $storage$058publish$(_world_0, _staged_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": ($List$reverse$go$(($List$reverse$(_staged_0)), _pending_0)), "ledger": _ledger_0, "mode": _mode_0};
}

function $identity$058reserve_checked$(_available_0, _namespace_0, _next_0, _rows_0, _pending_0, _ledger_0, _mode_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "None"}};
  } else {
    return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": ((_next_0 + 1) >>> 0), "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "Some", "value": {$: "storage.Handle", "namespace": _namespace_0, "id": _next_0}}};
  }
}

function $payload$058armor_get$(_owner_0) {
  const _array_0 = _owner_0["layers"];
  const _grade_0 = _owner_0["grade"];
  return $payload$058armor_observed$(_grade_0, ($payload$058four$(_array_0)));
}

function $U32$max$(_a_0, _b_0) {
  return $Bool$pick$((_a_0 < _b_0), _b_0, _a_0);
}

function $host$058filter_mark_head$(_ih_0, _changed_0, _since_0, _thisRun_0, _rows_0, _reverse_0, _value_0) {
  const _t_0 = _value_0["handle"];
  const _ns_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _main_0 = _value_0["main"];
  const _aux_0 = _value_0["aux"];
  const _flag_0 = _value_0["flag"];
  return $host$058filter_mark_resume$(_ih_0, _since_0, _thisRun_0, {$: "observations.QueryRow", "handle": {$: "storage.Handle", "namespace": _ns_0, "id": _id_0}, "main": _main_0, "aux": _aux_0, "flag": _flag_0}, _reverse_0, run_loop($host$058mark_seek$(_id_0, _changed_0, _rows_0)));
}

function $reader$045host$058read_removed_missed$(_ping_0, _despawned_0, _boundary_0, _messages_0, _messageLag_0, _result_0) {
  const _removed_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _run_0 = _t_0["fst"];
  const _lag_0 = _t_0["snd"];
  return $reader$045host$058read_removed$(_ping_0, _despawned_0, _boundary_0, _messages_0, _messageLag_0, _lag_0, ($streams$058read_lifecycle$(_removed_0, _run_0)));
}

function $streams$058missed$(_log_0, _run_0) {
  return $streams$058missed_info$(_log_0, ($readers$058project$(_run_0)));
}

function $streams$058ping_info$(_log_0, _info_0) {
  const _buffer_0 = _log_0["buffer"];
  const _run_0 = _info_0["run"];
  const _t_0 = _info_0["state"];
  const _registered_0 = _t_0["registeredAt"];
  const _t_1 = _info_0["boundary"];
  const _since_0 = _t_1["streamSince"];
  return $streams$058ping_result$(_run_0, ($streams$058read_buffer$(_buffer_0, _since_0, _registered_0)));
}

function $cached$045payload$058health_ledger_get$(_owner_0) {
  const _raw_0 = _owner_0["raw"];
  const _cached_0 = _owner_0["cached"];
  return {$: "Tuple", "fst": {$: "cache.Cache", "raw": _raw_0, "cached": _cached_0}, "snd": _cached_0};
}

function $observations$058commands_tail$(_owner_0, _value_0, _result_0) {
  const _tail_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _owner_0, "tail": _tail_0}, "snd": {$: "Con", "head": _value_0, "tail": _values_0}};
}

function $observations$058command_spawn$(_id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.Spawn", "id": _id_0, "bundle": _owner_0}, "snd": {$: "observations.SpawnView", "id": _id_0, "bundle": _value_0}};
}

function $observations$058command_main$(_id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.InsertMain", "id": _id_0, "main": _owner_0}, "snd": {$: "observations.MainView", "id": _id_0, "main": _value_0}};
}

function $observations$058rows_finish$(_state_0) {
  const _owners_0 = _state_0["fst"];
  const _values_0 = _state_0["snd"];
  return {$: "Tuple", "fst": _owners_0, "snd": ($List$reverse$(_values_0))};
}

function $observations$058rows_advance$1263$(_id_0, _state_0) {
  const _owners_0 = _state_0["fst"];
  const _values_0 = _state_0["snd"];
  return $observations$058rows_slot$1263$(_values_0, ($storage$058rows_extract$(_owners_0, _id_0)));
}

function $query$058struct_idx_finish$(_capacity_0, _depth_0, _high_0, _state_0) {
  const _main_0 = _state_0["main"];
  const _aux_0 = _state_0["aux"];
  const _metadata_0 = _state_0["metadata"];
  const _values_0 = _state_0["values"];
  return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": ($List$reverse$(_values_0))};
}

function $query$058struct_cols_live$1263$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return {$: "query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $query$058struct_idx_metadata$1263$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, true, {$: "Tuple", fst: _flags_0, snd: _flags_0[_x_0 % _flags_0.length]});
  }
}

function $systems$058prototype_slot_host_health_a_reserved$(_count_0, _rejected_0, _observations_0, _remove_0, _ping_0, _log_0, _result_0) {
  if (_result_0.$ === "types.Reserved") {
    const _owner_0 = _result_0["world"];
    const _handle_0 = _result_0["handle"];
    return run_clo((_x_0) => {
  const _x_1 = ($U32$show$(_count_0));
  return $IO$bind$(_log_0(_ping_0(_remove_0(_owner_0))({$: "types.HealthPing", "code": 1}))(("A:attempt:" + _x_1)), run_clo((_x_2) => {
  return $systems$058a_logged$(_handle_0, _observations_0, _x_2);
}), _x_0);
});
  } else {
    const _owner_1 = _result_0["world"];
    return run_clo((_x_3) => {
  return $IO$pure$({$: "systems.BodyResult", "transaction": _owner_1, "outcome": _rejected_0, "escaped": {$: "None"}, "observations": _observations_0}, _x_3);
});
  }
}

function $transaction$058record_main$(_handle_0, _undo_0, _commands_0, _pings_0, _marks_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "types.Found") {
    const _old_0 = _t_0["value"];
    return {$: "transaction.Tx", "world": _world_0, "selected": _handle_0, "undo": {$: "Con", "head": {$: "transaction.MainInverse", "handle": _handle_0, "old": _old_0}, "tail": _undo_0}, "commands": _commands_0, "pings": _pings_0, "marks": {$: "Con", "head": _handle_0, "tail": _marks_0}};
  } else {
    return {$: "transaction.Tx", "world": _world_0, "selected": _handle_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0};
  }
}

function $transaction$058storage_set_main0$1263$(_world_0, _handle_0, _value_0) {
  return $storage$058with_main$(_world_0, _handle_0, run_clo((_x_0) => {
  return $cached$045payload$058prototype_slot_vitals_swap$(_x_0, _value_0);
}));
}

function $transaction$058record_ledger$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Some") {
    const _old_0 = _t_0["value"];
    return {$: "transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": {$: "Con", "head": {$: "transaction.LedgerInverse", "old": _old_0}, "tail": _undo_0}, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0};
  } else {
    return {$: "transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0};
  }
}

function $transaction$058storage_set_ledger0$1263$(_world_0, _value_0) {
  return $storage$058with_ledger$(_world_0, run_clo((_x_0) => {
  return $cached$045payload$058health_ledger_swap$(_x_0, _value_0);
}));
}

function $transaction$058read_main_finish$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}, "snd": _view_0};
}

function $storage$058with_main$(_world_0, _handle_0, _transform_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  const _foreign_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $storage$058hook_checked$((_namespace_0 === _foreign_0), {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, _id_0, _transform_0);
}

function $transaction$058read_ledger_finish$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}, "snd": _view_0};
}

function $storage$058with_ledger$(_world_0, _transform_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _t_0 = _world_0["ledger"];
  if (_t_0.$ === "None") {
    const _mode_0 = _world_0["mode"];
    return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": {$: "None"}, "mode": _mode_0}, "snd": {$: "None"}};
  } else {
    const _ledger_0 = _t_0["value"];
    const _mode_1 = _world_0["mode"];
    return $storage$058ledger_return$(_namespace_0, _next_0, _rows_0, _pending_0, _mode_1, _transform_0(_ledger_0));
  }
}

function $transaction$058reserve_finish$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _handle_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}, "snd": _handle_0};
}

function $audited$045invoker$058prototype_slot_host_health_inspected_values$(_tick_0, _lookup_0, _worldnamespace_0, _audit_0, _world_0, _selected_0, _undo_0, _pings_0, _marks_0, _outcome_0, _escaped_0, _observations_0, _commands_0, _values_0) {
  if (_escaped_0.$ === "None") {
    return $audited$045invoker$058prototype_slot_host_health_complete$(_tick_0, _audit_0, {$: "None"}, {$: "systems.BodyResult", "transaction": {$: "transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}, "outcome": _outcome_0, "escaped": {$: "None"}, "observations": _observations_0});
  } else {
    const _t_0 = _escaped_0["value"];
    const _namespace_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    return $audited$045invoker$058prototype_slot_host_health_lookup_decide$(_tick_0, _lookup_0, _worldnamespace_0, _audit_0, _world_0, _selected_0, _undo_0, _pings_0, _marks_0, _outcome_0, _namespace_0, _id_0, _observations_0, _commands_0, _values_0);
  }
}

function $systems$058prototype_slot_host_health_between$(_mode_0, _count_0, _observations_0, _second_0, _after_0, _ledger_0, _set_ledger_0, _spawn_0, _flag_0, _ping_0, _log_0, _pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _view_0 = _pair_0["snd"];
  return $systems$058prototype_slot_host_health_after$(_mode_0, _count_0, ($List$append$(_observations_0, {$: "Con", "head": {$: "systems.MainObserved", "view": ($systems$058prototype_slot_host_health_view$(_view_0))}, "tail": {$: "Nil"}})), _ledger_0, _set_ledger_0, _spawn_0, _flag_0, _ping_0, _log_0, _after_0(_second_0(_owner_0)({$: "types.VitalsToken"})(50))({$: "types.VitalsToken"}));
}

function $transaction$045dispatch$045adapters$058returned_run$(_outcome_0, _escaped_0, _observations_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _pings_0 = _result_0["snd"];
  return {$: "transaction-dispatch-adapters.RunResult", "world": _world_0, "outcome": _outcome_0, "escaped": _escaped_0, "observations": _observations_0, "pings": _pings_0};
}

function $transaction$058storage_commit$(_result_0, _tick_0) {
  if (_result_0.$ === "transaction.Committed") {
    const _world_0 = _result_0["world"];
    const _commands_0 = _result_0["commands"];
    const _pings_0 = _result_0["pings"];
    const _marks_0 = _result_0["marks"];
    return {$: "Tuple", "fst": ($storage$058publish$(($transaction$058storage_mark_all$(_marks_0, _world_0, _tick_0)), ($List$reverse$(_commands_0)))), "snd": _pings_0};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "Tuple", "fst": _world_1, "snd": {$: "Nil"}};
  }
}

function $transaction$058tx_finish_success$(_t_0) {
  const _world_0 = _t_0["world"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return {$: "transaction.Committed", "world": _world_0, "commands": ($List$reverse$(_commands_0)), "pings": ($List$reverse$(_pings_0)), "marks": _marks_0};
}

function $transaction$045dispatch$045adapters$058prototype_packed_health_finish_failure$(_t_0) {
  return $transaction$058tx_finish_failure$1263$(_t_0);
}

function $commands$058queue_owned$(_world_0, _handle_0, _payload_0, _build_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  const _foreign_0 = _handle_0["namespace"];
  const _target_0 = _handle_0["id"];
  return $commands$058queue_checked$((_namespace_0 === _foreign_0), {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, _target_0, _payload_0, _build_0);
}

function $commands$058build_main$(_id_0, _main_0) {
  return {$: "storage.InsertMain", "id": _id_0, "main": _main_0};
}

function $commands$058build_despawn$(_id_0, _unit_0) {
  return {$: "storage.Despawn", "id": _id_0};
}

function $commands$058build_remove_main$(_id_0, _unit_0) {
  return {$: "storage.RemoveMain", "id": _id_0};
}

function $query$058lookup_return$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _observation_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": _observation_0};
}

function $query$058lookup_rows$1267$(_rows_0, _selection_0, _namespace_0, _target_0) {
  return $query$058lookup_slot$1267$(_selection_0, _namespace_0, ($storage$058rows_extract$(_rows_0, _target_0)));
}

function $host$058snapshot_optional$1263$(_query_0, _plus_0, _minus_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _logs_0 = _t_0["logs"];
  const _bindings_0 = _t_0["bindings"];
  const _worldName_0 = _t_0["worldName"];
  const _step_0 = _t_0["step"];
  const _prior_0 = _t_0["prior"];
  const _events_0 = _t_0["events"];
  const _optional_0 = _result_0["snd"];
  return $host$058snapshot_world$1263$(_logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _query_0, _plus_0, _minus_0, _optional_0, ($observations$058world$1263$(_world_0)));
}

function $payload$058armor_observed$(_grade_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "types.Armor", "layers": _array_0, "grade": _grade_0}, "snd": {$: "types.ArmorView", "layers": _values_0, "grade": _grade_0}};
}

function $Bool$pick$(_c_0, _a_0, _b_0) {
  if (!_c_0) {
    return _b_0;
  } else {
    return _a_0;
  }
}

function $host$058filter_mark_resume$(_ih_0, _since_0, _thisRun_0, _value_0, _reverse_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _tick_0 = _result_0["snd"];
  return run_tail(_ih_0(_rows_0), ($host$058filter_mark_case$(($Bool$and$((_tick_0 > _since_0), (_tick_0 <= _thisRun_0))), _value_0, _reverse_0)));
}

function $host$058mark_seek$(_target_0, _changed_0, _rows_0) {
  if (_rows_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _t_0 = _rows_0["head"];
    const _key_0 = _t_0["id"];
    const _main_0 = _t_0["main"];
    const _aux_0 = _t_0["aux"];
    const _flag_0 = _t_0["flag"];
    const _added_0 = _t_0["added"];
    const _last_0 = _t_0["changed"];
    const _tail_0 = _rows_0["tail"];
    return $host$058mark_seek_decide$(run_clo((_x_0) => {
  return $host$058mark_seek$(_target_0, _changed_0, _tail_0);
}), (_key_0 < _target_0), (_key_0 === _target_0), _changed_0, _added_0, _last_0, {$: "observations.RowView", "id": _key_0, "main": _main_0, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _last_0}, _tail_0);
  }
}

function $reader$045host$058read_removed$(_ping_0, _despawned_0, _boundary_0, _messages_0, _messageLag_0, _removedLag_0, _result_0) {
  const _removed_0 = _result_0["log"];
  const _run_0 = _result_0["run"];
  const _values_0 = _result_0["values"];
  return $reader$045host$058read_despawned_missed$(_ping_0, _removed_0, _boundary_0, _messages_0, _values_0, _messageLag_0, _removedLag_0, ($streams$058missed$(_despawned_0, _run_0)));
}

function $streams$058read_lifecycle$(_log_0, _run_0) {
  return $streams$058life_info$(_log_0, ($readers$058project$(_run_0)));
}

function $streams$058missed_info$(_log_0, _info_0) {
  const _t_0 = _log_0["buffer"];
  const _capacity_0 = _t_0["capacity"];
  const _size_0 = _t_0["size"];
  const _dropped_0 = _t_0["dropped"];
  const _front_0 = _t_0["front"];
  const _rear_0 = _t_0["rear"];
  const _run_0 = _info_0["run"];
  const _t_1 = _info_0["state"];
  const _registered_0 = _t_1["registeredAt"];
  const _t_2 = _info_0["boundary"];
  const _since_0 = _t_2["since"];
  const _x_0 = ($streams$058maximum$(_since_0, _registered_0));
  return {$: "Tuple", "fst": {$: "streams.LifeLog", "buffer": {$: "streams.Buffer", "capacity": _capacity_0, "size": _size_0, "dropped": _dropped_0, "front": _front_0, "rear": _rear_0}}, "snd": {$: "Tuple", "fst": _run_0, "snd": (_dropped_0 > _x_0)}};
}

function $streams$058ping_result$(_run_0, _result_0) {
  const _buffer_0 = _result_0["buffer"];
  const _values_0 = _result_0["values"];
  const _lagged_0 = _result_0["lagged"];
  return {$: "streams.PingRead", "log": {$: "streams.PingLog", "buffer": _buffer_0}, "run": _run_0, "values": _values_0, "lagged": _lagged_0};
}

function $streams$058read_buffer$(_buffer_0, _since_0, _registered_0) {
  const _capacity_0 = _buffer_0["capacity"];
  const _size_0 = _buffer_0["size"];
  const _dropped_0 = _buffer_0["dropped"];
  const _front_0 = _buffer_0["front"];
  const _rear_0 = _buffer_0["rear"];
  const _x_0 = ($streams$058maximum$(_since_0, _registered_0));
  return {$: "streams.Values", "buffer": {$: "streams.Buffer", "capacity": _capacity_0, "size": _size_0, "dropped": _dropped_0, "front": _front_0, "rear": _rear_0}, "values": ($List$reverse$(($streams$058read_batches$(($List$reverse$(_rear_0)), _since_0, ($streams$058read_batches$(_front_0, _since_0, {$: "Nil"})))))), "lagged": (_dropped_0 > _x_0)};
}

function $observations$058rows_slot$1263$(_values_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": _owners_0, "snd": _values_0};
  } else {
    const _owner_0 = _t_0["value"];
    return $observations$058rows_observed$(_owners_0, _values_0, ($observations$058row$1263$(_owner_0)));
  }
}

function $query$058struct_idx_metadata$1263$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, _value_0, _result_0) {
  if (!_value_0) {
    const _flags_0 = _result_0["fst"];
    return {$: "query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _flags_1 = _result_0["fst"];
    const _flag_0 = _result_0["snd"];
    return $query$058struct_idx_selected$1263$(($query$058selected$(_selection_0, _flag_0)), _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_1, _added_0, _changed_0, _values_0, _flag_0);
  }
}

function $systems$058a_logged$(_handle_0, _observations_0, _owner_0) {
  return run_clo((_x_0) => {
  return $IO$pure$({$: "systems.BodyResult", "transaction": _owner_0, "outcome": {$: "types.Success"}, "escaped": {$: "Some", "value": _handle_0}, "observations": _observations_0}, _x_0);
});
}

function $cached$045payload$058prototype_slot_vitals_swap$(_owner_0, _value_0) {
  const _levels_0 = _owner_0["levels"];
  const _rawreserve_0 = _owner_0["rawreserve"];
  const _rawclass_0 = _owner_0["rawclass"];
  const _b_0 = _owner_0["b"];
  const _c_0 = _owner_0["c"];
  const _d_0 = _owner_0["d"];
  const _cachedreserve_0 = _owner_0["cachedreserve"];
  const _cachedclass_0 = _owner_0["cachedclass"];
  return $cached$045payload$058prototype_slot_vitals_swap_done$(_rawreserve_0, _rawclass_0, _b_0, _c_0, _d_0, _cachedreserve_0, _cachedclass_0, _value_0, {$: "Tuple", fst: _levels_0, snd: _levels_0[0 % _levels_0.length]});
}

function $cached$045payload$058health_ledger_swap$(_owner_0, _value_0) {
  return $cache$058static_swap$1263$(_owner_0, _value_0);
}

function $storage$058hook_checked$(_valid_0, _world_0, _target_0, _transform_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "types.Missing"}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _t_0 = _world_0["rows"];
    const _main_0 = _t_0["main"];
    const _aux_0 = _t_0["aux"];
    const _metadata_0 = _t_0["metadata"];
    const _capacity_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _high_0 = _t_0["high_water"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return $storage$058fuse_bounds$(($Bool$and$((0 < _target_0), ($Bool$and$((_target_0 <= _capacity_0), (_target_0 <= _high_0))))), {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, _target_0, _transform_0);
  }
}

function $storage$058ledger_return$(_namespace_0, _next_0, _rows_0, _pending_0, _mode_0, _result_0) {
  const _ledger_0 = _result_0["fst"];
  const _observation_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": {$: "Some", "value": _ledger_0}, "mode": _mode_0}, "snd": {$: "Some", "value": _observation_0}};
}

function $audited$045invoker$058prototype_slot_host_health_complete$(_tick_0, _audit_0, _reservation_0, _result_0) {
  return run_clo((_x_0) => {
  return $IO$pure$({$: "audited-invoker.ServiceResult", "result": ($transaction$045dispatch$045adapters$058prototype_packed_health_finished$(_result_0, _tick_0)), "audit": _audit_0, "reservation": _reservation_0}, _x_0);
});
}

function $audited$045invoker$058prototype_slot_host_health_lookup_decide$(_tick_0, _lookup_0, _worldnamespace_0, _audit_0, _world_0, _selected_0, _undo_0, _pings_0, _marks_0, _outcome_0, _namespace_0, _id_0, _observations_0, _commands_0, _values_0) {
  if (!_lookup_0) {
    return $audited$045invoker$058prototype_slot_host_health_complete$(_tick_0, _audit_0, ($audited$045invoker$058prototype_slot_host_health_find_namespace$((_worldnamespace_0 === _namespace_0), _id_0, _values_0)), {$: "systems.BodyResult", "transaction": {$: "transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}, "outcome": _outcome_0, "escaped": {$: "Some", "value": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "observations": _observations_0});
  } else {
    return $audited$045invoker$058prototype_slot_host_health_looked$(_tick_0, _audit_0, ($audited$045invoker$058prototype_slot_host_health_find_namespace$((_worldnamespace_0 === _namespace_0), _id_0, _values_0)), _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _outcome_0, {$: "Some", "value": {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}}, _observations_0, ($query$058lookup$1263$({$: "query.Required"}, _world_0, {$: "storage.Handle", "namespace": _namespace_0, "id": _id_0})));
  }
}

function $systems$058prototype_slot_host_health_after$(_mode_0, _count_0, _observations_0, _ledger_0, _set_ledger_0, _spawn_0, _flag_0, _ping_0, _log_0, _pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _view_0 = _pair_0["snd"];
  return $systems$058prototype_slot_host_health_ledger$(_mode_0, _count_0, ($List$append$(_observations_0, {$: "Con", "head": {$: "systems.MainObserved", "view": ($systems$058prototype_slot_host_health_view$(_view_0))}, "tail": {$: "Nil"}})), _spawn_0, _flag_0, _ping_0, _log_0, _ledger_0(_set_ledger_0(_owner_0)({$: "types.HealthLedgerToken"})(201))({$: "types.HealthLedgerToken"}));
}

function $transaction$058storage_mark_all$(_marks_0, _world_0, _tick_0) {
  if (_marks_0.$ === "Nil") {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _t_0 = _world_0["rows"];
    const _main_0 = _t_0["main"];
    const _aux_0 = _t_0["aux"];
    const _t_1 = _t_0["metadata"];
    const _live_0 = _t_1["live"];
    const _flags_0 = _t_1["flags"];
    const _added_0 = _t_1["added"];
    const _changed_0 = _t_1["changed"];
    const _capacity_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _high_0 = _t_0["high_water"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": {$: "storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0};
  } else {
    const _namespace_1 = _world_0["namespace"];
    const _next_1 = _world_0["next"];
    const _t_2 = _world_0["rows"];
    const _main_1 = _t_2["main"];
    const _aux_1 = _t_2["aux"];
    const _t_3 = _t_2["metadata"];
    const _live_1 = _t_3["live"];
    const _flags_1 = _t_3["flags"];
    const _added_1 = _t_3["added"];
    const _changed_1 = _t_3["changed"];
    const _capacity_1 = _t_2["capacity"];
    const _depth_1 = _t_2["depth"];
    const _high_1 = _t_2["high_water"];
    const _pending_1 = _world_0["pending"];
    const _ledger_1 = _world_0["ledger"];
    const _mode_1 = _world_0["mode"];
    return $transaction$058prototype_storage_mark_loop$(_marks_0, _namespace_1, _next_1, _main_1, _aux_1, _flags_1, _added_1, {$: "Tuple", "fst": _live_1, "snd": _changed_1}, _capacity_1, _depth_1, _high_1, _pending_1, _ledger_1, _mode_1, _tick_0);
  }
}

function $transaction$058tx_finish_failure$1263$(_t_0) {
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  return {$: "transaction.Reverted", "world": ($transaction$058unwind$1263$(_undo_0, _world_0))};
}

function $commands$058queue_checked$(_valid_0, _world_0, _target_0, _payload_0, _build_0) {
  if (!_valid_0) {
    return {$: "types.CommandMissing", "world": _world_0, "payload": _payload_0};
  } else {
    return {$: "types.CommandQueued", "world": ($storage$058publish$(_world_0, {$: "Con", "head": _build_0(_target_0)(_payload_0), "tail": {$: "Nil"}}))};
  }
}

function $query$058lookup_slot$1267$(_selection_0, _namespace_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": _owners_0, "snd": {$: "types.Missing"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $query$058lookup_read$(_owners_0, ($query$058read_row$1267$(_selection_0, _namespace_0, _owner_0)));
  }
}

function $host$058snapshot_world$1263$(_logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _query_0, _plus_0, _minus_0, _optional_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return $host$058snapshot_end$1263$(_logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _view_0, _query_0, _plus_0, _minus_0, _optional_0, ($host$058lookups$1263$(_bindings_0, _world_0)));
}

function $host$058filter_mark_case$(_included_0, _value_0, _tail_0) {
  if (_included_0) {
    return {$: "Con", "head": _value_0, "tail": _tail_0};
  } else {
    return _tail_0;
  }
}

function $host$058mark_seek_decide$(_ih_0, _lower_0, _equal_0, _changed_0, _added_0, _last_0, _row_0, _tail_0) {
  if (_lower_0) {
    return run_tail(_ih_0, {$: "Unit"});
  } else {
    return {$: "Tuple", "fst": {$: "Con", "head": _row_0, "tail": _tail_0}, "snd": ($host$058marked_case$(_equal_0, _changed_0, _added_0, _last_0, 0))};
  }
}

function $reader$045host$058read_despawned_missed$(_ping_0, _removed_0, _boundary_0, _messages_0, _removedValues_0, _messageLag_0, _removedLag_0, _result_0) {
  const _despawned_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _run_0 = _t_0["fst"];
  const _lag_0 = _t_0["snd"];
  return $reader$045host$058read_despawned$(_ping_0, _removed_0, _boundary_0, _messages_0, _removedValues_0, _messageLag_0, _removedLag_0, _lag_0, ($streams$058read_lifecycle$(_despawned_0, _run_0)));
}

function $streams$058life_info$(_log_0, _info_0) {
  const _buffer_0 = _log_0["buffer"];
  const _run_0 = _info_0["run"];
  const _t_0 = _info_0["state"];
  const _registered_0 = _t_0["registeredAt"];
  const _t_1 = _info_0["boundary"];
  const _since_0 = _t_1["since"];
  return $streams$058life_result$(_run_0, ($streams$058read_buffer$(_buffer_0, _since_0, _registered_0)));
}

function $streams$058read_batches$($0, $1, $2) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _since_0 = $1;
      const _acc_0 = $2;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _tick_0 = _t_0["tick"];
        const _values_0 = _t_0["values"];
        const _tail_0 = _batches_0["tail"];
        $0 = _tail_0;
        $1 = _since_0;
        $2 = ($streams$058read_choose$((_tick_0 > _since_0), _values_0, _acc_0));
        continue;
      }
    }
  }
}

function $observations$058rows_observed$(_owners_0, _values_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($storage$058rows_restore$(_owners_0, _owner_0)), "snd": {$: "Con", "head": _value_0, "tail": _values_0}};
}

function $observations$058row$1263$(_owner_0) {
  const _id_0 = _owner_0["id"];
  const _main_0 = _owner_0["main"];
  const _aux_0 = _owner_0["aux"];
  const _flag_0 = _owner_0["flag"];
  const _added_0 = _owner_0["added"];
  const _changed_0 = _owner_0["changed"];
  return $observations$058row_main$1263$(_id_0, _aux_0, _flag_0, _added_0, _changed_0, ($observations$058maybe_get$1265$(_main_0)));
}

function $query$058struct_idx_selected$1263$(_include_0, _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0) {
  if (!_include_0) {
    return {$: "query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $query$058struct_idx_main$1263$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, array_rmw(_main_0, _x_0, () => _x_1));
  }
}

function $query$058selected$(_selection_0, _flag_0) {
  if (_selection_0.$ === "query.Present") {
    if (_flag_0.$ === "None") {
      return false;
    } else {
      return true;
    }
  } else if (_selection_0.$ === "query.Absent") {
    if (_flag_0.$ === "Some") {
      return false;
    } else {
      return true;
    }
  } else {
    return true;
  }
}

function $cached$045payload$058prototype_slot_vitals_swap_done$(_rawreserve_0, _rawclass_0, _b_0, _c_0, _d_0, _cachedreserve_0, _cachedclass_0, _value_0, _result_0) {
  const _levels_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "cached-payload.PrototypeHealthMainSlot", "levels": (_levels_0[0 % _levels_0.length] = _value_0, _levels_0), "rawreserve": _rawreserve_0, "rawclass": _rawclass_0, "a": _value_0, "b": _b_0, "c": _c_0, "d": _d_0, "cachedreserve": _cachedreserve_0, "cachedclass": _cachedclass_0}, "snd": _old_0};
}

function $cache$058static_swap$1263$(_owner_0, _value_0) {
  const _raw_0 = _owner_0["raw"];
  const _cached_0 = _owner_0["cached"];
  return $cache$058static_swap_done$1263$(_cached_0, _value_0, ($uncached$045payload$058health_ledger_swap$(_raw_0, _value_0)));
}

function $storage$058fuse_bounds$(_valid_0, _world_0, _target_0, _transform_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "types.Missing"}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _t_0 = _world_0["rows"];
    const _main_0 = _t_0["main"];
    const _aux_0 = _t_0["aux"];
    const _metadata_0 = _t_0["metadata"];
    const _capacity_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _high_0 = _t_0["high_water"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return $storage$058prototype_fuse_columns$(_namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, ((_target_0 - 1) >>> 0), _transform_0);
  }
}

function $audited$045invoker$058prototype_slot_host_health_find_namespace$(_equal_0, _id_0, _values_0) {
  if (_equal_0) {
    return $audited$045invoker$058prototype_slot_host_health_find_spawn$(_id_0, _values_0);
  } else {
    return {$: "None"};
  }
}

function $audited$045invoker$058prototype_slot_host_health_looked$(_tick_0, _audit_0, _reservation_0, _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _outcome_0, _escaped_0, _observations_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _view_0 = _pair_0["snd"];
  return $audited$045invoker$058prototype_slot_host_health_complete$(_tick_0, _audit_0, _reservation_0, {$: "systems.BodyResult", "transaction": {$: "transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}, "outcome": _outcome_0, "escaped": _escaped_0, "observations": ($List$append$(_observations_0, {$: "Con", "head": {$: "systems.ReservedObserved", "view": _view_0}, "tail": {$: "Nil"}}))});
}

function $query$058lookup$1263$(_selection_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  const _foreign_0 = _handle_0["namespace"];
  const _target_0 = _handle_0["id"];
  return $query$058lookup_checked$1263$((_namespace_0 === _foreign_0), _selection_0, {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, _target_0);
}

function $systems$058prototype_slot_host_health_ledger$(_mode_0, _count_0, _observations_0, _spawn_0, _flag_0, _ping_0, _log_0, _pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _view_0 = _pair_0["snd"];
  return $systems$058prototype_slot_host_health_reserved$(_mode_0, _count_0, ($List$append$(_observations_0, {$: "Con", "head": {$: "systems.LedgerObserved", "view": _view_0}, "tail": {$: "Nil"}})), _flag_0, _ping_0, _log_0, _spawn_0(_owner_0)(($cached$045payload$058prototype_slot_vitals_new$({$: "types.Vitals", "levels": ($systems$058quad$(60, 61, 62, 63)), "reserve": 9, "class": 2}))));
}

function $transaction$058prototype_storage_mark_loop$($0, $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14) {
  for (;;) {
    {
      const _marks_0 = $0;
      const _namespace_0 = $1;
      const _next_0 = $2;
      const _main_0 = $3;
      const _aux_0 = $4;
      const _flags_0 = $5;
      const _added_0 = $6;
      const _transport_0 = $7;
      const _capacity_0 = $8;
      const _depth_0 = $9;
      const _high_0 = $10;
      const _pending_0 = $11;
      const _ledger_0 = $12;
      const _mode_0 = $13;
      const _tick_0 = $14;
      if (_marks_0.$ === "Nil") {
        const _live_0 = _transport_0["fst"];
        const _changed_0 = _transport_0["snd"];
        return {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": {$: "storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0};
      } else {
        const _t_0 = _marks_0["head"];
        const _foreign_0 = _t_0["namespace"];
        const _id_0 = _t_0["id"];
        const _rest_0 = _marks_0["tail"];
        const _live_1 = _transport_0["fst"];
        const _changed_1 = _transport_0["snd"];
        $0 = _rest_0;
        $1 = _namespace_0;
        $2 = _next_0;
        $3 = _main_0;
        $4 = _aux_0;
        $5 = _flags_0;
        $6 = _added_0;
        $7 = ($transaction$058prototype_storage_mark_guard$(($Bool$and$((_namespace_0 === _foreign_0), ($Bool$and$((0 < _id_0), ($Bool$and$((_id_0 <= _capacity_0), (_id_0 <= _high_0))))))), _live_1, _changed_1, _id_0, _tick_0));
        $8 = _capacity_0;
        $9 = _depth_0;
        $10 = _high_0;
        $11 = _pending_0;
        $12 = _ledger_0;
        $13 = _mode_0;
        $14 = _tick_0;
        continue;
      }
    }
  }
}

function $transaction$058unwind$1263$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _t_0 = _undo_0["head"];
        if (_t_0.$ === "transaction.MainInverse") {
          const _handle_0 = _t_0["handle"];
          const _old_0 = _t_0["old"];
          const _rest_0 = _undo_0["tail"];
          $0 = _rest_0;
          $1 = ($transaction$045dispatch$045adapters$058prototype_packed_health_world_restore$(_world_0, _handle_0, _old_0));
          continue;
        } else {
          const _old_1 = _t_0["old"];
          const _rest_1 = _undo_0["tail"];
          $0 = _rest_1;
          $1 = ($transaction$045dispatch$045adapters$058prototype_packed_health_world_ledger_restore$(_world_0, _old_1));
          continue;
        }
      }
    }
  }
}

function $query$058lookup_read$(_owners_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($storage$058rows_restore$(_owners_0, _owner_0)), "snd": {$: "types.Mismatch"}};
  } else {
    const _value_0 = _t_0["value"];
    return {$: "Tuple", "fst": ($storage$058rows_restore$(_owners_0, _owner_0)), "snd": {$: "types.Found", "value": _value_0}};
  }
}

function $query$058read_row$1267$(_selection_0, _namespace_0, _row_0) {
  const _id_0 = _row_0["id"];
  const _main_0 = _row_0["main"];
  const _aux_0 = _row_0["aux"];
  const _flag_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  return $query$058read_selected$1267$(($query$058selected$(_selection_0, _flag_0)), _namespace_0, {$: "storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0});
}

function $host$058snapshot_end$1263$(_logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _view_0, _query_0, _plus_0, _minus_0, _optional_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return {$: "host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": ($List$append$(_events_0, {$: "Con", "head": {$: "host-observations.Snapshot", "step": _step_0, "worldName": _worldName_0, "prior": _prior_0, "world": _view_0, "query": _query_0, "plus": _plus_0, "minus": _minus_0, "optional": _optional_0, "lookups": _values_0}, "tail": {$: "Nil"}}))};
}

function $host$058marked_case$(_hit_0, _changed_0, _added_0, _last_0, _tail_0) {
  if (_hit_0) {
    return $host$058marked_value$(_changed_0, _added_0, _last_0);
  } else {
    return _tail_0;
  }
}

function $reader$045host$058read_despawned$(_ping_0, _removed_0, _boundary_0, _messages_0, _removedValues_0, _messageLag_0, _removedLag_0, _despawnedLag_0, _result_0) {
  const _despawned_0 = _result_0["log"];
  const _run_0 = _result_0["run"];
  const _values_0 = _result_0["values"];
  return {$: "reader-host.Read", "logs": {$: "reader-host.Logs", "ping": _ping_0, "removed": _removed_0, "despawned": _despawned_0}, "run": _run_0, "delivery": {$: "reader-host.Delivery", "boundary": _boundary_0, "messages": _messages_0, "removed": _removedValues_0, "despawned": _values_0, "messageLag": _messageLag_0, "removedLag": _removedLag_0, "despawnedLag": _despawnedLag_0}};
}

function $streams$058life_result$(_run_0, _result_0) {
  const _buffer_0 = _result_0["buffer"];
  const _values_0 = _result_0["values"];
  return {$: "streams.LifeRead", "log": {$: "streams.LifeLog", "buffer": _buffer_0}, "run": _run_0, "values": _values_0};
}

function $streams$058read_choose$(_include_0, _values_0, _acc_0) {
  if (_include_0) {
    return $streams$058push_values$(_values_0, _acc_0);
  } else {
    return _acc_0;
  }
}

function $observations$058row_main$1263$(_id_0, _aux_0, _flag_0, _added_0, _changed_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $observations$058row_aux$(_id_0, _main_0, _value_0, _flag_0, _added_0, _changed_0, ($observations$058maybe_get$1262$(_aux_0)));
}

function $query$058struct_idx_main$1263$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _owner_0 = _t_0["value"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $query$058struct_idx_aux$1263$(_id_0, _namespace_0, _main_0, _owner_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, array_rmw(_aux_0, _x_0, () => _x_1));
  }
}

function $cache$058static_swap_done$1263$(_cached_0, _value_0, _result_0) {
  const _raw_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "cache.Cache", "raw": _raw_0, "cached": ($cached$045payload$058health_ledger_patch$(_cached_0, _value_0))}, "snd": _old_0};
}

function $uncached$045payload$058health_ledger_swap$(_owner_0, _value_0) {
  const _array_0 = _owner_0["totals"];
  const _epoch_0 = _owner_0["epoch"];
  return $uncached$045payload$058prototype_direct_health_ledger_swap$(_epoch_0, _value_0, {$: "Tuple", fst: _array_0, snd: _array_0[0 % _array_0.length]});
}

function $storage$058prototype_fuse_columns$(_namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0) {
  const _live_0 = _metadata_0["live"];
  const _flags_0 = _metadata_0["flags"];
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  return $storage$058prototype_fuse_live_result$(_namespace_0, _next_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, {$: "Tuple", fst: _live_0, snd: _live_0[_index_0 % _live_0.length]});
}

function $audited$045invoker$058prototype_slot_host_health_find_spawn$($0, $1) {
  for (;;) {
    {
      const _target_0 = $0;
      const _values_0 = $1;
      if (_values_0.$ === "Nil") {
        return {$: "None"};
      } else {
        const _t_0 = _values_0["head"];
        if (_t_0.$ === "observations.SpawnView") {
          const _id_0 = _t_0["id"];
          const _bundle_0 = _t_0["bundle"];
          const _tail_0 = _values_0["tail"];
          return $audited$045invoker$058prototype_slot_host_health_find_match$((_target_0 === _id_0), _bundle_0, ($audited$045invoker$058prototype_slot_host_health_find_spawn$(_target_0, _tail_0)));
        } else {
          const _tail_1 = _values_0["tail"];
          $0 = _target_0;
          $1 = _tail_1;
          continue;
        }
      }
    }
  }
}

function $query$058lookup_checked$1263$(_valid_0, _selection_0, _world_0, _target_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "types.Missing"}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _rows_0 = _world_0["rows"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return $query$058lookup_return$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, ($query$058lookup_rows$1263$(_rows_0, _selection_0, _namespace_0, _target_0)));
  }
}

function $systems$058prototype_slot_host_health_reserved$(_mode_0, _count_0, _observations_0, _flag_0, _ping_0, _log_0, _result_0) {
  if (_result_0.$ === "types.Reserved") {
    const _owner_0 = _result_0["world"];
    const _handle_0 = _result_0["handle"];
    return $systems$058audit$(_mode_0, _count_0, {$: "Some", "value": _handle_0}, _observations_0, _ping_0(_flag_0(_owner_0)({$: "types.Tracked", "group": 8}))({$: "types.HealthPing", "code": ($systems$058code$(_mode_0))}), _log_0);
  } else {
    const _owner_1 = _result_0["world"];
    return $systems$058audit$(_mode_0, _count_0, {$: "None"}, _observations_0, _ping_0(_flag_0(_owner_1)({$: "types.Tracked", "group": 8}))({$: "types.HealthPing", "code": ($systems$058code$(_mode_0))}), _log_0);
  }
}

function $transaction$058prototype_storage_mark_guard$(_valid_0, _live_0, _changed_0, _id_0, _tick_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _live_0, "snd": _changed_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $transaction$058prototype_storage_mark_live$(_changed_0, ((_id_0 - 1) >>> 0), _tick_0, {$: "Tuple", fst: _live_0, snd: _live_0[_x_0 % _live_0.length]});
  }
}

function $transaction$045dispatch$045adapters$058prototype_packed_health_world_restore$(_world_0, _handle_0, _old_0) {
  return $transaction$058storage_restore_main0$1263$(_world_0, _handle_0, _old_0);
}

function $transaction$045dispatch$045adapters$058prototype_packed_health_world_ledger_restore$(_world_0, _old_0) {
  return $transaction$058storage_restore_ledger0$1263$(_world_0, _old_0);
}

function $query$058read_selected$1267$(_include_0, _namespace_0, _row_0) {
  if (!_include_0) {
    return {$: "Tuple", "fst": _row_0, "snd": {$: "None"}};
  } else {
    const _id_0 = _row_0["id"];
    const _t_0 = _row_0["main"];
    if (_t_0.$ === "None") {
      const _aux_0 = _row_0["aux"];
      const _flag_0 = _row_0["flag"];
      const _added_0 = _row_0["added"];
      const _changed_0 = _row_0["changed"];
      return {$: "Tuple", "fst": {$: "storage.Row", "id": _id_0, "main": {$: "None"}, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}, "snd": {$: "None"}};
    } else {
      const _main_0 = _t_0["value"];
      const _aux_1 = _row_0["aux"];
      const _flag_1 = _row_0["flag"];
      const _added_1 = _row_0["added"];
      const _changed_1 = _row_0["changed"];
      return $query$058included$(($query$058read_main$1267$(_namespace_0, _id_0, _main_0, _aux_1, _flag_1, _added_1, _changed_1)));
    }
  }
}

function $host$058marked_value$(_changed_0, _added_0, _last_0) {
  if (_changed_0) {
    return _last_0;
  } else {
    return _added_0;
  }
}

function $streams$058push_values$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      if (_values_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = {$: "Con", "head": _head_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $observations$058row_aux$(_id_0, _main_0, _mainView_0, _flag_0, _added_0, _changed_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _auxView_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}, "snd": {$: "observations.RowView", "id": _id_0, "main": _mainView_0, "aux": _auxView_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}};
}

function $query$058struct_idx_aux$1263$(_id_0, _namespace_0, _main_0, _owner_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return $query$058struct_idx_return$(((_id_0 - 1) >>> 0), _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, ($observations$058client$1263$({$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}, _flag_0, _owner_0, _a_0)));
}

function $cached$045payload$058health_ledger_patch$(_view_0, _value_0) {
  const _t_0 = _view_0["totals"];
  const _b_0 = _t_0["b"];
  const _c_0 = _t_0["c"];
  const _d_0 = _t_0["d"];
  const _epoch_0 = _view_0["epoch"];
  return {$: "types.LedgerView", "totals": {$: "types.Four", "a": _value_0, "b": _b_0, "c": _c_0, "d": _d_0}, "epoch": _epoch_0};
}

function $uncached$045payload$058prototype_direct_health_ledger_swap$(_epoch_0, _value_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "types.HealthLedger", "totals": (_array_0[0 % _array_0.length] = _value_0, _array_0), "epoch": _epoch_0}, "snd": _old_0};
}

function $storage$058prototype_fuse_live_result$(_namespace_0, _next_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $storage$058fuse_live$(_namespace_0, _next_0, _aux_0, {$: "storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0, _value_0);
}

function $audited$045invoker$058prototype_slot_host_health_find_match$(_equal_0, _bundle_0, _fallback_0) {
  if (_equal_0) {
    return {$: "Some", "value": _bundle_0};
  } else {
    return _fallback_0;
  }
}

function $query$058lookup_rows$1263$(_rows_0, _selection_0, _namespace_0, _target_0) {
  return $query$058lookup_slot$1263$(_selection_0, _namespace_0, ($storage$058rows_extract$(_rows_0, _target_0)));
}

function $systems$058audit$(_mode_0, _count_0, _escaped_0, _observations_0, _owner_0, _log_0) {
  return run_clo((_x_0) => {
  const _x_1 = ($U32$show$(_count_0));
  return $IO$bind$(_log_0(_owner_0)(("B:attempt:" + _x_1)), run_clo((_x_2) => {
  return $systems$058audit_result$(($systems$058failed$(_mode_0)), _escaped_0, _observations_0, _x_2);
}), _x_0);
});
}

function $systems$058code$(_mode_0) {
  if (_mode_0.$ === "schedule.BFail") {
    return 9;
  } else {
    return 2;
  }
}

function $transaction$058prototype_storage_mark_live$(_changed_0, _index_0, _tick_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _live_0, "snd": _changed_0};
  } else {
    return {$: "Tuple", "fst": _live_0, "snd": (_changed_0[_index_0 % _changed_0.length] = _tick_0, _changed_0)};
  }
}

function $transaction$058storage_restore_main0$1263$(_world_0, _handle_0, _value_0) {
  return $transaction$058discard_access$(($transaction$058storage_set_main0$1263$(_world_0, _handle_0, _value_0)));
}

function $transaction$058storage_restore_ledger0$1263$(_world_0, _value_0) {
  return $transaction$058discard_optional$(($transaction$058storage_set_ledger0$1263$(_world_0, _value_0)));
}

function $query$058included$(_result_0) {
  const _row_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _row_0, "snd": {$: "Some", "value": _value_0}};
}

function $query$058read_main$1267$(_namespace_0, _id_0, _main_0, _aux_0, _flag_0, _added_0, _changed_0) {
  return $query$058restored$(_id_0, _flag_0, _added_0, _changed_0, ($observations$058client$1263$({$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}, _flag_0, _main_0, _aux_0)));
}

function $query$058struct_idx_return$(_index_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _result_0) {
  const _m_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _a_0 = _t_0["fst"];
  const _value_0 = _t_0["snd"];
  const _x_0 = {$: "Some", "value": _m_0};
  return {$: "query.StructColsState", "main": (_main_0[_index_0 % _main_0.length] = _x_0, _main_0), "aux": (_aux_0[_index_0 % _aux_0.length] = _a_0, _aux_0), "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": {$: "Con", "head": _value_0, "tail": _values_0}};
}

function $observations$058client$1263$(_handle_0, _flag_0, _main_0, _aux_0) {
  return $observations$058client_main$1263$(_handle_0, _flag_0, _aux_0, ($query$058main_read$1263$(_main_0, {$: "types.VitalsToken"})));
}

function $storage$058fuse_live$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0, _meta_0) {
  if (!_meta_0) {
    return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "types.Missing"}};
  } else {
    const _x_0 = {$: "None"};
    return $storage$058fuse_taken$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, array_rmw(_main_0, _index_0, () => _x_0));
  }
}

function $query$058lookup_slot$1263$(_selection_0, _namespace_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": _owners_0, "snd": {$: "types.Missing"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $query$058lookup_read$(_owners_0, ($query$058read_row$1263$(_selection_0, _namespace_0, _owner_0)));
  }
}

function $systems$058audit_result$(_outcome_0, _escaped_0, _observations_0, _owner_0) {
  return run_clo((_x_0) => {
  return $IO$pure$({$: "systems.BodyResult", "transaction": _owner_0, "outcome": _outcome_0, "escaped": _escaped_0, "observations": _observations_0}, _x_0);
});
}

function $transaction$058discard_access$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $transaction$058discard_optional$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $query$058restored$(_id_0, _flag_0, _added_0, _changed_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _aux_0 = _t_0["fst"];
  const _observation_0 = _t_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.Row", "id": _id_0, "main": {$: "Some", "value": _main_0}, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}, "snd": _observation_0};
}

function $observations$058client_main$1263$(_handle_0, _flag_0, _aux_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $observations$058client_aux$(_handle_0, _flag_0, _owner_0, _value_0, ($query$058aux_read$1261$(_aux_0)));
}

function $query$058main_read$1263$(_owner_0, _token_0) {
  return $cached$045payload$058prototype_slot_vitals_get$(_owner_0);
}

function $storage$058fuse_taken$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "types.Mismatch"}};
  } else {
    const _value_0 = _t_0["value"];
    return $storage$058fuse_return$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0(_value_0));
  }
}

function $query$058read_row$1263$(_selection_0, _namespace_0, _row_0) {
  const _id_0 = _row_0["id"];
  const _main_0 = _row_0["main"];
  const _aux_0 = _row_0["aux"];
  const _flag_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  return $query$058read_selected$1263$(($query$058selected$(_selection_0, _flag_0)), _namespace_0, {$: "storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0});
}

function $observations$058client_aux$(_handle_0, _flag_0, _owner_0, _main_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Tuple", "fst": _aux_0, "snd": {$: "observations.QueryRow", "handle": _handle_0, "main": _main_0, "aux": _value_0, "flag": _flag_0}}};
}

function $query$058aux_read$1261$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}};
  } else {
    const _owner_1 = _owner_0["value"];
    return $query$058aux_return$(($payload$058armor_get$(_owner_1)));
  }
}

function $storage$058fuse_return$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _result_0) {
  const _value_0 = _result_0["fst"];
  const _observation_0 = _result_0["snd"];
  const _x_0 = {$: "Some", "value": _value_0};
  return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "storage.Rows", "main": (_main_0[_index_0 % _main_0.length] = _x_0, _main_0), "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "types.Found", "value": _observation_0}};
}

function $query$058read_selected$1263$(_include_0, _namespace_0, _row_0) {
  if (!_include_0) {
    return {$: "Tuple", "fst": _row_0, "snd": {$: "None"}};
  } else {
    const _id_0 = _row_0["id"];
    const _t_0 = _row_0["main"];
    if (_t_0.$ === "None") {
      const _aux_0 = _row_0["aux"];
      const _flag_0 = _row_0["flag"];
      const _added_0 = _row_0["added"];
      const _changed_0 = _row_0["changed"];
      return {$: "Tuple", "fst": {$: "storage.Row", "id": _id_0, "main": {$: "None"}, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}, "snd": {$: "None"}};
    } else {
      const _main_0 = _t_0["value"];
      const _aux_1 = _row_0["aux"];
      const _flag_1 = _row_0["flag"];
      const _added_1 = _row_0["added"];
      const _changed_1 = _row_0["changed"];
      return $query$058included$(($query$058read_main$1263$(_namespace_0, _id_0, _main_0, _aux_1, _flag_1, _added_1, _changed_1)));
    }
  }
}

function $query$058aux_return$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": _owner_0}, "snd": {$: "Some", "value": _value_0}};
}

function $query$058read_main$1263$(_namespace_0, _id_0, _main_0, _aux_0, _flag_0, _added_0, _changed_0) {
  return $query$058restored$(_id_0, _flag_0, _added_0, _changed_0, ($audited$045invoker$058prototype_slot_host_health_lookup_client$1260$({$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}, _flag_0, _main_0, _aux_0)));
}

function $audited$045invoker$058prototype_slot_host_health_lookup_client$1260$(_handle_0, _flag_0, _main_0, _aux_0) {
  return $audited$045invoker$058prototype_slot_host_health_lookup_read$(_aux_0, ($query$058main_read$1263$(_main_0, {$: "types.VitalsToken"})));
}

function $audited$045invoker$058prototype_slot_host_health_lookup_read$(_aux_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _main_0, "snd": {$: "Tuple", "fst": _aux_0, "snd": {$: "types.HealthMain", "vitals": _value_0}}};
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);