function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}
function receive(pair,tail){const a=pair.fst;const old=pair.snd;return {a,old,tail};}
function swap(a,i,tail){const value=9;try{}catch(tail){}return receive(array_rmw(a,i,()=>value),tail);}
console.log(JSON.stringify(swap([1,2],0,7)));
