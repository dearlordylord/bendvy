function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}
const log=[];
function before(a){log.push('before');a[0]={kind:'Type',a:41,b:42,c:43,d:44,stamp:45};return 7;}
function receive(prefix,pair,tail,scalar,flag){const array=pair.fst;const old=pair.snd;log.push('receiver');return {prefix,array,old,tail,scalar,flag};}
function firstReceive(pair,tail,scalar,flag){const array=pair.fst;const old=pair.snd;log.push('first');return {array,old,tail,scalar,flag};}
function swap(a,i,tail){const value={kind:'Type',a:91,b:92,c:93,d:94,stamp:95};const scalar=17;return receive__swap_split_1(before(a),(a), (i), (value),tail,scalar,true);}
function firstSwap(a,i,tail){const value={kind:'Type',a:61,b:62,c:63,d:64,stamp:65};const scalar=18;return firstReceive__swap_split_0((a), (i), (value),tail,scalar,false);}
function stop(){log.push('throw');throw Error('expected');}
function stopped(a,i,tail){const value={kind:'Type',a:1,b:2,c:3,d:4,stamp:5};const scalar=19;return receive__swap_split_1(stop(),(a), (i), (value),tail,scalar,true);}
const raw={kind:'Type',a:11,b:12,c:13,d:14,stamp:15};const snapshot=Object.freeze({...raw,kind:'Data'});const a=[raw,raw,raw];const one=swap(a,3,a),two=firstSwap(a,4,a);const empty=[];const three=firstSwap(empty,3,empty);const untouched=[raw];try{stopped(untouched,0,untouched)}catch(e){if(e.message!=='expected')throw e;}
console.log(JSON.stringify({one,two,emptyOld:three.old===undefined,emptyWritten:empty.NaN,sameTail:one.tail===a&&two.tail===a,untouched:untouched[0]===raw,raw,snapshot,log}));


function receive__swap_split_1(prefix, __swap_fst, __swap_index, __swap_value, tail, scalar, flag) {
 const __swap_at = __swap_index % __swap_fst.length;
 const __swap_snd = __swap_fst[__swap_at];
 __swap_fst[__swap_at] = __swap_value;
const array=__swap_fst;const old=__swap_snd;log.push('receiver');return {prefix,array,old,tail,scalar,flag};}

function firstReceive__swap_split_0(__swap_fst, __swap_index, __swap_value, tail, scalar, flag) {
 const __swap_at = __swap_index % __swap_fst.length;
 const __swap_snd = __swap_fst[__swap_at];
 __swap_fst[__swap_at] = __swap_value;
const array=__swap_fst;const old=__swap_snd;log.push('first');return {array,old,tail,scalar,flag};}
