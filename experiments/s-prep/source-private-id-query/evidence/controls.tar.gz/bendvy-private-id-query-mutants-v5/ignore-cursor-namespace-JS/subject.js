function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

for (const k of ["IO.print"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return run_clo((_x_0) => {
  return $IO$bind$(($run$({$: "query.PrototypeIdCursor", "namespace": 7, "ids": {$: "Con", "head": 3, "tail": {$: "Nil"}}})), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$bind$(($run$({$: "query.PrototypeIdCursor", "namespace": 8, "ids": {$: "Con", "head": 3, "tail": {$: "Nil"}}})), run_clo((_x_3) => {
  return run_clo((_x_4) => {
  return $IO$bind$(($run$({$: "query.PrototypeIdCursor", "namespace": 7, "ids": {$: "Con", "head": 0, "tail": {$: "Con", "head": 2, "tail": {$: "Con", "head": 5, "tail": {$: "Nil"}}}}})), run_clo((_x_5) => {
  return run_clo((_x_6) => {
  return $IO$bind$(($run$({$: "query.PrototypeIdCursor", "namespace": 7, "ids": {$: "Nil"}})), run_clo((_x_7) => {
  return run_clo((_x_8) => {
  return $IO$bind$(($run$({$: "query.PrototypeIdCursor", "namespace": 7, "ids": {$: "Con", "head": 3, "tail": {$: "Con", "head": 3, "tail": {$: "Nil"}}}})), run_clo((_x_9) => {
  return run_clo((_x_10) => {
  return $IO$bind$(($queried$(($query$058prototype_cursor_each$1260$({$: "query.Required"}, ($world$()))))), run_clo((_x_11) => {
  return run_clo((_x_12) => {
  return $IO$pure$({$: "Unit"}, _x_12);
});
}), _x_10);
});
}), _x_8);
});
}), _x_6);
});
}), _x_4);
});
}), _x_2);
});
}), _x_0);
});
}

function $IO$bind$(_m_0, _f_0, _k_0) {
  return run_tail(_m_0, run_clo((_x_0) => {
  return run_tail(_f_0(_x_0), _k_0);
}));
}

function $run$(_cursor_0) {
  return $observed$(($held$045adapter$058prototype_cursor_flatfold_motion$1260$(_cursor_0, ($transaction$058prototype_flat_pack$1264$(($transaction$058tx_begin$(($world$()), {$: "storage.Handle", "namespace": 0, "id": 0})))), 0)));
}

function $queried$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _ns_0 = _t_0["namespace"];
  const _ids_0 = _t_0["ids"];
  return run_clo((_x_0) => {
  const _x_1 = ($host$045render$058render_list$12616$(_ids_0));
  const _x_2 = ($U32$show$(_ns_0));
  const _x_3 = (":" + _x_1);
  return $IO$bind$((_x_4) => $IO$print$((_x_2 + _x_3), _x_4), run_clo((_x_5) => {
  return run_clo((_x_6) => {
  return $IO$bind$(($finished$(4, {$: "types.PositionView", "coordinates": {$: "types.Four", "a": 999, "b": 200, "c": 300, "d": 400}, "frame": 77}, {$: "transaction.Reverted", "world": _world_0})), run_clo((_x_7) => {
  return run_clo((_x_8) => {
  return $IO$pure$({$: "Unit"}, _x_8);
});
}), _x_6);
});
}), _x_0);
});
}

function $query$058prototype_cursor_each$1260$(_selection_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $query$058prototype_cursor_return$(_namespace_0, ($query$058prototype_cursor_ids$1260$(_selection_0, {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0})));
}

function $world$() {
  const _x_0 = array_new(2, 100);
  const _x_1 = (_x_0[1 % _x_0.length] = 101, _x_0);
  const _x_2 = (_x_1[2 % _x_1.length] = 102, _x_1);
  const _x_3 = ($storage$058slots_empty$(2));
  const _x_4 = {$: "Some", "value": {$: "cached-payload.PrototypeMotionMainSlot", "coordinates": (_x_2[3 % _x_2.length] = 103, _x_2), "rawframe": 4, "a": 999, "b": 200, "c": 300, "d": 400, "cachedframe": 77}};
  const _x_5 = array_new(2, false);
  const _x_6 = {$: "None"};
  const _x_7 = array_new(2, _x_6);
  const _x_8 = {$: "Some", "value": {$: "types.Selected", "group": 55}};
  const _x_9 = array_new(2, 10);
  const _x_10 = (_x_9[1 % _x_9.length] = 11, _x_9);
  const _x_11 = (_x_10[2 % _x_10.length] = 12, _x_10);
  return {$: "storage.World", "namespace": 7, "next": 9, "rows": {$: "storage.Rows", "main": (_x_3[2 % _x_3.length] = _x_4, _x_3), "aux": ($storage$058slots_empty$(2)), "metadata": {$: "storage.MetadataColumns", "live": (_x_5[2 % _x_5.length] = true, _x_5), "flags": (_x_7[2 % _x_7.length] = _x_8, _x_7), "added": array_new(2, 11), "changed": array_new(2, 22)}, "capacity": 4, "depth": 2, "high_water": 3}, "pending": {$: "Con", "head": {$: "storage.Despawn", "id": 2}, "tail": {$: "Nil"}}, "ledger": {$: "Some", "value": {$: "cache.Cache", "raw": {$: "types.MotionLedger", "totals": (_x_11[3 % _x_11.length] = 13, _x_11), "epoch": 6}, "cached": {$: "types.LedgerView", "totals": {$: "types.Four", "a": 900, "b": 901, "c": 902, "d": 903}, "epoch": 88}}}, "mode": {$: "types.MotionOn"}};
}

function $IO$pure$(_x_0, _k_0) {
  return run_tail(_k_0, _x_0);
}

function $observed$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _total_0 = _result_0["snd"];
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $IO$print$(($U32$show$(_total_0)), _x_1), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $IO$bind$(($finished$(4, {$: "types.PositionView", "coordinates": {$: "types.Four", "a": 999, "b": 200, "c": 300, "d": 400}, "frame": 77}, ($transaction$045dispatch$045adapters$058prototype_packed_motion_finish_failure$(($transaction$058prototype_flat_unpack$1260$(_owner_0)))))), run_clo((_x_4) => {
  return run_clo((_x_5) => {
  return $IO$pure$({$: "Unit"}, _x_5);
});
}), _x_3);
});
}), _x_0);
});
}

function $held$045adapter$058prototype_cursor_flatfold_motion$1260$(_cursor_0, _owner_0, _total_0) {
  const _namespace_0 = _cursor_0["namespace"];
  const _handles_0 = _cursor_0["ids"];
  return $held$045adapter$058prototype_packed_prototype_flatfold_motion_finish$(($held$045adapter$058prototype_cursor_flatfold_motion_loop$1260$(_namespace_0, _handles_0, ($held$045adapter$058prototype_packed_prototype_flatfold_motion_pack$(_owner_0, _total_0)))));
}

function $transaction$058prototype_flat_pack$1264$(_owner_0) {
  const _world_0 = _owner_0["world"];
  const _selected_0 = _owner_0["selected"];
  const _undo_0 = _owner_0["undo"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  return {$: "transaction.PrototypeFlatTx", "world": _world_0, "selected": _selected_0, "undo": ($transaction$058prototype_flat_inverse_pack$1260$(_undo_0)), "commands": _commands_0, "pings": _pings_0, "marks": ($transaction$058prototype_flat_mark_pack$1260$(_marks_0))};
}

function $transaction$058tx_begin$(_world_0, _selected_0) {
  return {$: "transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "pings": {$: "Nil"}, "marks": {$: "Nil"}};
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $host$045render$058render_list$12616$(_values_0) {
  return $host$045render$058render_concat$({$: "Con", "head": "[", "tail": {$: "Con", "head": ($host$045render$058render_concat$(($host$045render$058render_list_tail$12616$(_values_0, {$: "Nil"}, true)))), "tail": {$: "Con", "head": "]", "tail": {$: "Nil"}}}});
}

function $finished$(_label_0, _retained_0, _result_0) {
  if (_result_0.$ === "transaction.Reverted") {
    const _t_0 = _result_0["world"];
    const _ns_0 = _t_0["namespace"];
    const _next_0 = _t_0["next"];
    const _t_1 = _t_0["rows"];
    const _t_2 = _t_1["main"];
    if (_t_2.length !== 1) {
      const _t_3 = _t_2.slice(0, _t_2.length >> 1);
      if (_t_3.length !== 1) {
        const _t_4 = _t_3.slice(0, _t_3.length >> 1);
        if (_t_4.length === 1) {
          const _t_5 = _t_4[0];
          if (_t_5.$ === "None") {
            const _t_6 = _t_3.slice(_t_3.length >> 1);
            if (_t_6.length === 1) {
              const _t_7 = _t_6[0];
              if (_t_7.$ === "None") {
                const _t_8 = _t_2.slice(_t_2.length >> 1);
                if (_t_8.length !== 1) {
                  const _t_9 = _t_8.slice(0, _t_8.length >> 1);
                  if (_t_9.length === 1) {
                    const _t_10 = _t_9[0];
                    if (_t_10.$ === "Some") {
                      const _t_11 = _t_10["value"];
                      const _array_0 = _t_11["coordinates"];
                      const _frame_0 = _t_11["rawframe"];
                      const _a_0 = _t_11["a"];
                      const _b_0 = _t_11["b"];
                      const _c_0 = _t_11["c"];
                      const _d_0 = _t_11["d"];
                      const _cf_0 = _t_11["cachedframe"];
                      const _t_12 = _t_8.slice(_t_8.length >> 1);
                      if (_t_12.length === 1) {
                        const _t_13 = _t_12[0];
                        if (_t_13.$ === "None") {
                          const _t_14 = _t_1["aux"];
                          if (_t_14.length !== 1) {
                            const _t_15 = _t_14.slice(0, _t_14.length >> 1);
                            if (_t_15.length !== 1) {
                              const _t_16 = _t_15.slice(0, _t_15.length >> 1);
                              if (_t_16.length === 1) {
                                const _t_17 = _t_16[0];
                                if (_t_17.$ === "None") {
                                  const _t_18 = _t_15.slice(_t_15.length >> 1);
                                  if (_t_18.length === 1) {
                                    const _t_19 = _t_18[0];
                                    if (_t_19.$ === "None") {
                                      const _t_20 = _t_14.slice(_t_14.length >> 1);
                                      if (_t_20.length !== 1) {
                                        const _t_21 = _t_20.slice(0, _t_20.length >> 1);
                                        if (_t_21.length === 1) {
                                          const _t_22 = _t_21[0];
                                          if (_t_22.$ === "None") {
                                            const _t_23 = _t_20.slice(_t_20.length >> 1);
                                            if (_t_23.length === 1) {
                                              const _t_24 = _t_23[0];
                                              if (_t_24.$ === "None") {
                                                const _t_25 = _t_1["metadata"];
                                                const _t_26 = _t_25["live"];
                                                if (_t_26.length !== 1) {
                                                  const _t_27 = _t_26.slice(0, _t_26.length >> 1);
                                                  if (_t_27.length !== 1) {
                                                    const _t_28 = _t_27.slice(0, _t_27.length >> 1);
                                                    if (_t_28.length === 1) {
                                                      const _t_29 = _t_28[0];
                                                      if (!_t_29) {
                                                        const _t_30 = _t_27.slice(_t_27.length >> 1);
                                                        if (_t_30.length === 1) {
                                                          const _t_31 = _t_30[0];
                                                          if (!_t_31) {
                                                            const _t_32 = _t_26.slice(_t_26.length >> 1);
                                                            if (_t_32.length !== 1) {
                                                              const _t_33 = _t_32.slice(0, _t_32.length >> 1);
                                                              if (_t_33.length === 1) {
                                                                const _t_34 = _t_33[0];
                                                                if (_t_34) {
                                                                  const _t_35 = _t_32.slice(_t_32.length >> 1);
                                                                  if (_t_35.length === 1) {
                                                                    const _t_36 = _t_35[0];
                                                                    if (!_t_36) {
                                                                      const _t_37 = _t_25["flags"];
                                                                      if (_t_37.length !== 1) {
                                                                        const _t_38 = _t_37.slice(0, _t_37.length >> 1);
                                                                        if (_t_38.length !== 1) {
                                                                          const _t_39 = _t_38.slice(0, _t_38.length >> 1);
                                                                          if (_t_39.length === 1) {
                                                                            const _t_40 = _t_39[0];
                                                                            if (_t_40.$ === "None") {
                                                                              const _t_41 = _t_38.slice(_t_38.length >> 1);
                                                                              if (_t_41.length === 1) {
                                                                                const _t_42 = _t_41[0];
                                                                                if (_t_42.$ === "None") {
                                                                                  const _t_43 = _t_37.slice(_t_37.length >> 1);
                                                                                  if (_t_43.length !== 1) {
                                                                                    const _t_44 = _t_43.slice(0, _t_43.length >> 1);
                                                                                    if (_t_44.length === 1) {
                                                                                      const _t_45 = _t_44[0];
                                                                                      if (_t_45.$ === "Some") {
                                                                                        const _t_46 = _t_45["value"];
                                                                                        const _t_47 = _t_46["group"];
                                                                                        if (_t_47 == 55) {
                                                                                          const _t_48 = _t_43.slice(_t_43.length >> 1);
                                                                                          if (_t_48.length === 1) {
                                                                                            const _t_49 = _t_48[0];
                                                                                            if (_t_49.$ === "None") {
                                                                                              const _added_0 = _t_25["added"];
                                                                                              const _changed_0 = _t_25["changed"];
                                                                                              const _capacity_0 = _t_1["capacity"];
                                                                                              const _depth_0 = _t_1["depth"];
                                                                                              const _high_0 = _t_1["high_water"];
                                                                                              const _t_50 = _t_0["pending"];
                                                                                              if (_t_50.$ === "Con") {
                                                                                                const _t_51 = _t_50["head"];
                                                                                                if (_t_51.$ === "storage.Despawn") {
                                                                                                  const _pending_0 = _t_51["id"];
                                                                                                  const _t_52 = _t_50["tail"];
                                                                                                  if (_t_52.$ === "Nil") {
                                                                                                    const _t_53 = _t_0["ledger"];
                                                                                                    if (_t_53.$ === "Some") {
                                                                                                      const _t_54 = _t_53["value"];
                                                                                                      const _t_55 = _t_54["raw"];
                                                                                                      const _totals_0 = _t_55["totals"];
                                                                                                      const _epoch_0 = _t_55["epoch"];
                                                                                                      const _lc_0 = _t_54["cached"];
                                                                                                      const _t_56 = _t_0["mode"];
                                                                                                      if (_t_56.$ === "types.MotionOn") {
                                                                                                        const _x_0 = ($host$045render$058render_ledger$(_lc_0));
                                                                                                        const _x_1 = (_x_0 + "}");
                                                                                                        const _x_2 = ($U32$show$(_epoch_0));
                                                                                                        const _x_3 = (",\"ledgerCached\":" + _x_1);
                                                                                                        const _x_4 = (_x_2 + _x_3);
                                                                                                        const _x_5 = ($host$045render$058render_list$12616$(($data$(($Array$to_list$1260$(_totals_0))))));
                                                                                                        const _x_6 = (",\"epoch\":" + _x_4);
                                                                                                        const _x_7 = (_x_5 + _x_6);
                                                                                                        const _x_8 = ($host$045render$058render_list$12616$(($data$(($Array$to_list$1260$(_changed_0))))));
                                                                                                        const _x_9 = (",\"ledger\":" + _x_7);
                                                                                                        const _x_10 = (_x_8 + _x_9);
                                                                                                        const _x_11 = ($host$045render$058render_list$12616$(($data$(($Array$to_list$1260$(_added_0))))));
                                                                                                        const _x_12 = (",\"changed\":" + _x_10);
                                                                                                        const _x_13 = (_x_11 + _x_12);
                                                                                                        const _x_14 = ($U32$show$(_pending_0));
                                                                                                        const _x_15 = (",\"added\":" + _x_13);
                                                                                                        const _x_16 = (_x_14 + _x_15);
                                                                                                        const _x_17 = ($U32$show$(_high_0));
                                                                                                        const _x_18 = (",\"pending\":" + _x_16);
                                                                                                        const _x_19 = (_x_17 + _x_18);
                                                                                                        const _x_20 = ($Nat$show$(_depth_0));
                                                                                                        const _x_21 = (",\"high\":" + _x_19);
                                                                                                        const _x_22 = (_x_20 + _x_21);
                                                                                                        const _x_23 = ($U32$show$(_capacity_0));
                                                                                                        const _x_24 = (",\"depth\":" + _x_22);
                                                                                                        const _x_25 = (_x_23 + _x_24);
                                                                                                        const _x_26 = ($U32$show$(_next_0));
                                                                                                        const _x_27 = (",\"capacity\":" + _x_25);
                                                                                                        const _x_28 = (_x_26 + _x_27);
                                                                                                        const _x_29 = ($U32$show$(_ns_0));
                                                                                                        const _x_30 = (",\"next\":" + _x_28);
                                                                                                        const _x_31 = (_x_29 + _x_30);
                                                                                                        const _x_32 = ($host$045render$058render_position$(_retained_0));
                                                                                                        const _x_33 = (",\"namespace\":" + _x_31);
                                                                                                        const _x_34 = (_x_32 + _x_33);
                                                                                                        const _x_35 = ($host$045render$058render_position$({$: "types.PositionView", "coordinates": {$: "types.Four", "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0}, "frame": _cf_0}));
                                                                                                        const _x_36 = (",\"retained\":" + _x_34);
                                                                                                        const _x_37 = (_x_35 + _x_36);
                                                                                                        const _x_38 = ($U32$show$(_frame_0));
                                                                                                        const _x_39 = (",\"cached\":" + _x_37);
                                                                                                        const _x_40 = (_x_38 + _x_39);
                                                                                                        const _x_41 = ($host$045render$058render_list$12616$(($data$(($Array$to_list$1260$(_array_0))))));
                                                                                                        const _x_42 = (",\"rawFrame\":" + _x_40);
                                                                                                        const _x_43 = (_x_41 + _x_42);
                                                                                                        const _x_44 = ($U32$show$(_label_0));
                                                                                                        const _x_45 = (",\"array\":" + _x_43);
                                                                                                        const _x_46 = (_x_44 + _x_45);
                                                                                                        return (_x_47) => $IO$print$(("{\"length\":" + _x_46), _x_47);
                                                                                                      } else {
                                                                                                        return (_x_48) => $IO$print$("unexpected-reverted-world", _x_48);
                                                                                                      }
                                                                                                    } else {
                                                                                                      return (_x_49) => $IO$print$("unexpected-reverted-world", _x_49);
                                                                                                    }
                                                                                                  } else {
                                                                                                    return (_x_50) => $IO$print$("unexpected-reverted-world", _x_50);
                                                                                                  }
                                                                                                } else {
                                                                                                  return (_x_51) => $IO$print$("unexpected-reverted-world", _x_51);
                                                                                                }
                                                                                              } else {
                                                                                                return (_x_52) => $IO$print$("unexpected-reverted-world", _x_52);
                                                                                              }
                                                                                            } else {
                                                                                              return (_x_53) => $IO$print$("unexpected-reverted-world", _x_53);
                                                                                            }
                                                                                          } else {
                                                                                            return (_x_54) => $IO$print$("unexpected-reverted-world", _x_54);
                                                                                          }
                                                                                        } else {
                                                                                          return (_x_55) => $IO$print$("unexpected-reverted-world", _x_55);
                                                                                        }
                                                                                      } else {
                                                                                        return (_x_56) => $IO$print$("unexpected-reverted-world", _x_56);
                                                                                      }
                                                                                    } else {
                                                                                      return (_x_57) => $IO$print$("unexpected-reverted-world", _x_57);
                                                                                    }
                                                                                  } else {
                                                                                    return (_x_58) => $IO$print$("unexpected-reverted-world", _x_58);
                                                                                  }
                                                                                } else {
                                                                                  return (_x_59) => $IO$print$("unexpected-reverted-world", _x_59);
                                                                                }
                                                                              } else {
                                                                                return (_x_60) => $IO$print$("unexpected-reverted-world", _x_60);
                                                                              }
                                                                            } else {
                                                                              return (_x_61) => $IO$print$("unexpected-reverted-world", _x_61);
                                                                            }
                                                                          } else {
                                                                            return (_x_62) => $IO$print$("unexpected-reverted-world", _x_62);
                                                                          }
                                                                        } else {
                                                                          return (_x_63) => $IO$print$("unexpected-reverted-world", _x_63);
                                                                        }
                                                                      } else {
                                                                        return (_x_64) => $IO$print$("unexpected-reverted-world", _x_64);
                                                                      }
                                                                    } else {
                                                                      return (_x_65) => $IO$print$("unexpected-reverted-world", _x_65);
                                                                    }
                                                                  } else {
                                                                    return (_x_66) => $IO$print$("unexpected-reverted-world", _x_66);
                                                                  }
                                                                } else {
                                                                  return (_x_67) => $IO$print$("unexpected-reverted-world", _x_67);
                                                                }
                                                              } else {
                                                                return (_x_68) => $IO$print$("unexpected-reverted-world", _x_68);
                                                              }
                                                            } else {
                                                              return (_x_69) => $IO$print$("unexpected-reverted-world", _x_69);
                                                            }
                                                          } else {
                                                            return (_x_70) => $IO$print$("unexpected-reverted-world", _x_70);
                                                          }
                                                        } else {
                                                          return (_x_71) => $IO$print$("unexpected-reverted-world", _x_71);
                                                        }
                                                      } else {
                                                        return (_x_72) => $IO$print$("unexpected-reverted-world", _x_72);
                                                      }
                                                    } else {
                                                      return (_x_73) => $IO$print$("unexpected-reverted-world", _x_73);
                                                    }
                                                  } else {
                                                    return (_x_74) => $IO$print$("unexpected-reverted-world", _x_74);
                                                  }
                                                } else {
                                                  return (_x_75) => $IO$print$("unexpected-reverted-world", _x_75);
                                                }
                                              } else {
                                                return (_x_76) => $IO$print$("unexpected-reverted-world", _x_76);
                                              }
                                            } else {
                                              return (_x_77) => $IO$print$("unexpected-reverted-world", _x_77);
                                            }
                                          } else {
                                            return (_x_78) => $IO$print$("unexpected-reverted-world", _x_78);
                                          }
                                        } else {
                                          return (_x_79) => $IO$print$("unexpected-reverted-world", _x_79);
                                        }
                                      } else {
                                        return (_x_80) => $IO$print$("unexpected-reverted-world", _x_80);
                                      }
                                    } else {
                                      return (_x_81) => $IO$print$("unexpected-reverted-world", _x_81);
                                    }
                                  } else {
                                    return (_x_82) => $IO$print$("unexpected-reverted-world", _x_82);
                                  }
                                } else {
                                  return (_x_83) => $IO$print$("unexpected-reverted-world", _x_83);
                                }
                              } else {
                                return (_x_84) => $IO$print$("unexpected-reverted-world", _x_84);
                              }
                            } else {
                              return (_x_85) => $IO$print$("unexpected-reverted-world", _x_85);
                            }
                          } else {
                            return (_x_86) => $IO$print$("unexpected-reverted-world", _x_86);
                          }
                        } else {
                          return (_x_87) => $IO$print$("unexpected-reverted-world", _x_87);
                        }
                      } else {
                        return (_x_88) => $IO$print$("unexpected-reverted-world", _x_88);
                      }
                    } else {
                      return (_x_89) => $IO$print$("unexpected-reverted-world", _x_89);
                    }
                  } else {
                    return (_x_90) => $IO$print$("unexpected-reverted-world", _x_90);
                  }
                } else {
                  return (_x_91) => $IO$print$("unexpected-reverted-world", _x_91);
                }
              } else {
                return (_x_92) => $IO$print$("unexpected-reverted-world", _x_92);
              }
            } else {
              return (_x_93) => $IO$print$("unexpected-reverted-world", _x_93);
            }
          } else {
            return (_x_94) => $IO$print$("unexpected-reverted-world", _x_94);
          }
        } else {
          return (_x_95) => $IO$print$("unexpected-reverted-world", _x_95);
        }
      } else {
        return (_x_96) => $IO$print$("unexpected-reverted-world", _x_96);
      }
    } else {
      return (_x_97) => $IO$print$("unexpected-reverted-world", _x_97);
    }
  } else {
    return (_x_98) => $IO$print$("unexpected-reverted-world", _x_98);
  }
}

function $query$058prototype_cursor_return$(_namespace_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _ids_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "query.PrototypeIdCursor", "namespace": _namespace_0, "ids": _ids_0}};
}

function $query$058prototype_cursor_ids$1260$(_selection_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $query$058each_return$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, ($query$058prototype_cursor_read_rows$1260$(_rows_0, _selection_0, _namespace_0)));
}

function $storage$058slots_empty$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _d_0 = (_depth_0 - 1);
    return array_node(($storage$058slots_empty$(_d_0)), ($storage$058slots_empty$(_d_0)));
  }
}

function $transaction$045dispatch$045adapters$058prototype_packed_motion_finish_failure$(_t_0) {
  return $transaction$058tx_finish_failure$1262$(_t_0);
}

function $transaction$058prototype_flat_unpack$1260$(_owner_0) {
  const _world_0 = _owner_0["world"];
  const _selected_0 = _owner_0["selected"];
  const _undo_0 = _owner_0["undo"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  return {$: "transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": ($transaction$058prototype_flat_inverse_unpack$1260$(_undo_0)), "commands": _commands_0, "pings": _pings_0, "marks": ($transaction$058prototype_flat_mark_unpack$1260$(_marks_0))};
}

function $held$045adapter$058prototype_packed_prototype_flatfold_motion_finish$(_state_0) {
  const _ns_0 = _state_0["namespace"];
  const _next_0 = _state_0["next"];
  const _columns_0 = _state_0["columns"];
  const _aux_0 = _state_0["aux"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _depth_0 = _state_0["depth"];
  const _high_0 = _state_0["high"];
  const _pending_0 = _state_0["pending"];
  const _ledger_0 = _state_0["ledger"];
  const _mode_0 = _state_0["mode"];
  const _selected_0 = _state_0["selected"];
  const _undo_0 = _state_0["undo"];
  const _commands_0 = _state_0["commands"];
  const _pings_0 = _state_0["pings"];
  const _marks_0 = _state_0["marks"];
  const _total_0 = _state_0["total"];
  return {$: "Tuple", "fst": {$: "transaction.PrototypeFlatTx", "world": {$: "storage.World", "namespace": _ns_0, "next": _next_0, "rows": {$: "storage.Rows", "main": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}, "snd": _total_0};
}

function $held$045adapter$058prototype_cursor_flatfold_motion_loop$1260$($0, $1, $2) {
  for (;;) {
    {
      const _namespace_0 = $0;
      const _handles_0 = $1;
      const _state_0 = $2;
      if (_handles_0.$ === "Nil") {
        return _state_0;
      } else {
        const _handle_0 = _handles_0["head"];
        const _rest_0 = _handles_0["tail"];
        $0 = _namespace_0;
        $1 = _rest_0;
        $2 = ($held$045adapter$058prototype_packed_prototype_flatfold_motion_step$1260$({$: "storage.Handle", "namespace": 7, "id": _handle_0}, _state_0));
        continue;
      }
    }
  }
}

function $held$045adapter$058prototype_packed_prototype_flatfold_motion_pack$(_owner_0, _total_0) {
  const _t_0 = _owner_0["world"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["next"];
  const _t_1 = _t_0["rows"];
  const _columns_0 = _t_1["main"];
  const _aux_0 = _t_1["aux"];
  const _metadata_0 = _t_1["metadata"];
  const _capacity_0 = _t_1["capacity"];
  const _depth_0 = _t_1["depth"];
  const _high_0 = _t_1["high_water"];
  const _pending_0 = _t_0["pending"];
  const _ledger_0 = _t_0["ledger"];
  const _mode_0 = _t_0["mode"];
  const _selected_0 = _owner_0["selected"];
  const _undo_0 = _owner_0["undo"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  return {$: "held-adapter.PrototypeFlatFold", "namespace": _ns_0, "next": _next_0, "columns": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high": _high_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0, "total": _total_0};
}

function $transaction$058prototype_flat_inverse_pack$1260$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "transaction.PrototypeFlatEnd"};
  } else {
    const _t_0 = _values_0["head"];
    if (_t_0.$ === "transaction.MainInverse") {
      const _t_1 = _t_0["handle"];
      const _space_0 = _t_1["namespace"];
      const _id_0 = _t_1["id"];
      const _old_0 = _t_0["old"];
      const _tail_0 = _values_0["tail"];
      return {$: "transaction.PrototypeFlatMain", "namespace": _space_0, "id": _id_0, "old": _old_0, "tail": ($transaction$058prototype_flat_inverse_pack$1260$(_tail_0))};
    } else {
      const _old_1 = _t_0["old"];
      const _tail_1 = _values_0["tail"];
      return {$: "transaction.PrototypeFlatLedger", "old": _old_1, "tail": ($transaction$058prototype_flat_inverse_pack$1260$(_tail_1))};
    }
  }
}

function $transaction$058prototype_flat_mark_pack$1260$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "transaction.PrototypeFlatMarksEnd"};
  } else {
    const _t_0 = _values_0["head"];
    const _space_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _tail_0 = _values_0["tail"];
    return {$: "transaction.PrototypeFlatMark", "namespace": _space_0, "id": _id_0, "tail": ($transaction$058prototype_flat_mark_pack$1260$(_tail_0))};
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $host$045render$058render_concat$(_values_0) {
  return $host$045render$058render_chunks$(_values_0, "");
}

function $host$045render$058render_list_tail$12616$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($host$045render$058render_list_piece$(($U32$show$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $data$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _values_0["head"];
    const _tail_0 = _values_0["tail"];
    return {$: "Con", "head": _head_0, "tail": ($data$(_tail_0))};
  }
}

function $Array$to_list$1260$(_a_0) {
  return $Array$to_list$go$1260$(_a_0, {$: "Nil"});
}

function $host$045render$058render_position$(_value_0) {
  const _coordinates_0 = _value_0["coordinates"];
  const _frame_0 = _value_0["frame"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"coordinates\":", "tail": {$: "Con", "head": ($host$045render$058render_four$(_coordinates_0)), "tail": {$: "Con", "head": ",\"frame\":", "tail": {$: "Con", "head": ($U32$show$(_frame_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $host$045render$058render_ledger$(_value_0) {
  const _totals_0 = _value_0["totals"];
  const _epoch_0 = _value_0["epoch"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"totals\":", "tail": {$: "Con", "head": ($host$045render$058render_four$(_totals_0)), "tail": {$: "Con", "head": ",\"epoch\":", "tail": {$: "Con", "head": ($U32$show$(_epoch_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
}

function $query$058each_return$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _observations_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": _observations_0};
}

function $query$058prototype_cursor_read_rows$1260$(_rows_0, _selection_0, _namespace_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _t_0 = _rows_0["metadata"];
  const _live_0 = _t_0["live"];
  const _flags_0 = _t_0["flags"];
  const _added_0 = _t_0["added"];
  const _changed_0 = _t_0["changed"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $query$058prototype_cursor_struct_idx_go$1260$(_high_0, 1, _capacity_0, _depth_0, _high_0, _selection_0, _namespace_0, {$: "query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": {$: "Nil"}});
}

function $transaction$058tx_finish_failure$1262$(_t_0) {
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  return {$: "transaction.Reverted", "world": ($transaction$058unwind$1262$(_undo_0, _world_0))};
}

function $transaction$058prototype_flat_inverse_unpack$1260$(_values_0) {
  if (_values_0.$ === "transaction.PrototypeFlatEnd") {
    return {$: "Nil"};
  } else if (_values_0.$ === "transaction.PrototypeFlatMain") {
    const _space_0 = _values_0["namespace"];
    const _id_0 = _values_0["id"];
    const _old_0 = _values_0["old"];
    const _tail_0 = _values_0["tail"];
    return {$: "Con", "head": {$: "transaction.MainInverse", "handle": {$: "storage.Handle", "namespace": _space_0, "id": _id_0}, "old": _old_0}, "tail": ($transaction$058prototype_flat_inverse_unpack$1260$(_tail_0))};
  } else if (_values_0.$ === "transaction.PrototypeFlatLedger") {
    const _old_1 = _values_0["old"];
    const _tail_1 = _values_0["tail"];
    return {$: "Con", "head": {$: "transaction.LedgerInverse", "old": _old_1}, "tail": ($transaction$058prototype_flat_inverse_unpack$1260$(_tail_1))};
  } else {
    const _space_1 = _values_0["namespace"];
    const _id_1 = _values_0["id"];
    const _main_old_0 = _values_0["main_old"];
    const _ledger_old_0 = _values_0["ledger_old"];
    const _tail_2 = _values_0["tail"];
    return {$: "Con", "head": {$: "transaction.LedgerInverse", "old": _ledger_old_0}, "tail": {$: "Con", "head": {$: "transaction.MainInverse", "handle": {$: "storage.Handle", "namespace": _space_1, "id": _id_1}, "old": _main_old_0}, "tail": ($transaction$058prototype_flat_inverse_unpack$1260$(_tail_2))}};
  }
}

function $transaction$058prototype_flat_mark_unpack$1260$(_values_0) {
  if (_values_0.$ === "transaction.PrototypeFlatMarksEnd") {
    return {$: "Nil"};
  } else {
    const _space_0 = _values_0["namespace"];
    const _id_0 = _values_0["id"];
    const _tail_0 = _values_0["tail"];
    return {$: "Con", "head": {$: "storage.Handle", "namespace": _space_0, "id": _id_0}, "tail": ($transaction$058prototype_flat_mark_unpack$1260$(_tail_0))};
  }
}

function $held$045adapter$058prototype_packed_prototype_flatfold_motion_step$1260$(_handle_0, _state_0) {
  const _space_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  const _ns_0 = _state_0["namespace"];
  const _next_0 = _state_0["next"];
  const _columns_0 = _state_0["columns"];
  const _aux_0 = _state_0["aux"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _depth_0 = _state_0["depth"];
  const _high_0 = _state_0["high"];
  const _pending_0 = _state_0["pending"];
  const _ledger_0 = _state_0["ledger"];
  const _mode_0 = _state_0["mode"];
  const _undo_0 = _state_0["undo"];
  const _commands_0 = _state_0["commands"];
  const _pings_0 = _state_0["pings"];
  const _marks_0 = _state_0["marks"];
  const _total_0 = _state_0["total"];
  return $held$045adapter$058prototype_packed_prototype_flatfold_motion_guard$1260$(($Bool$and$((_ns_0 === _space_0), ($Bool$and$((0 < _id_0), ($Bool$and$((_id_0 <= _capacity_0), (_id_0 <= _high_0))))))), _id_0, _ns_0, _next_0, _columns_0, _aux_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, {$: "storage.Handle", "namespace": _space_0, "id": _id_0}, _undo_0, _commands_0, _pings_0, _marks_0, _total_0, _metadata_0, _ledger_0);
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $host$045render$058render_chunks$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      if (_values_0.$ === "Nil") {
        return $String$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($host$045render$058render_push$(_head_0, _acc_0));
        continue;
      }
    }
  }
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $host$045render$058render_list_piece$(_value_0, _acc_0, _first_0) {
  if (_first_0) {
    return {$: "Con", "head": _value_0, "tail": _acc_0};
  } else {
    return {$: "Con", "head": _value_0, "tail": {$: "Con", "head": ",", "tail": _acc_0}};
  }
}

function $Array$to_list$go$1260$($0, $1) {
  for (;;) {
    {
      const _a_0 = $0;
      const _acc_0 = $1;
      if (_a_0.length === 1) {
        const _x_0 = _a_0[0];
        return {$: "Con", "head": _x_0, "tail": _acc_0};
      } else {
        const _xs_0 = _a_0.slice(0, _a_0.length >> 1);
        const _ys_0 = _a_0.slice(_a_0.length >> 1);
        $0 = _xs_0;
        $1 = ($Array$to_list$go$1260$(_ys_0, _acc_0));
        continue;
      }
    }
  }
}

function $host$045render$058render_four$(_value_0) {
  const _a_0 = _value_0["a"];
  const _b_0 = _value_0["b"];
  const _c_0 = _value_0["c"];
  const _d_0 = _value_0["d"];
  return $host$045render$058render_concat$({$: "Con", "head": "{\"a\":", "tail": {$: "Con", "head": ($U32$show$(_a_0)), "tail": {$: "Con", "head": ",\"b\":", "tail": {$: "Con", "head": ($U32$show$(_b_0)), "tail": {$: "Con", "head": ",\"c\":", "tail": {$: "Con", "head": ($U32$show$(_c_0)), "tail": {$: "Con", "head": ",\"d\":", "tail": {$: "Con", "head": ($U32$show$(_d_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}}}});
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $query$058prototype_cursor_struct_idx_go$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _id_0 = $1;
      const _capacity_0 = $2;
      const _depth_0 = $3;
      const _high_0 = $4;
      const _selection_0 = $5;
      const _namespace_0 = $6;
      const _state_0 = $7;
      if (_remaining_0 === 0) {
        return $query$058struct_cols_finish$(_capacity_0, _depth_0, _high_0, _state_0);
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = ((_id_0 + 1) >>> 0);
        $2 = _capacity_0;
        $3 = _depth_0;
        $4 = _high_0;
        $5 = _selection_0;
        $6 = _namespace_0;
        $7 = ($query$058prototype_cursor_struct_idx_advance$1260$(($Bool$and$((0 < _id_0), (_id_0 <= _capacity_0))), _id_0, _namespace_0, _selection_0, _state_0));
        continue;
      }
    }
  }
}

function $transaction$058unwind$1262$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _t_0 = _undo_0["head"];
        if (_t_0.$ === "transaction.MainInverse") {
          const _handle_0 = _t_0["handle"];
          const _old_0 = _t_0["old"];
          const _rest_0 = _undo_0["tail"];
          $0 = _rest_0;
          $1 = ($transaction$045dispatch$045adapters$058prototype_packed_motion_world_restore$(_world_0, _handle_0, _old_0));
          continue;
        } else {
          const _old_1 = _t_0["old"];
          const _rest_1 = _undo_0["tail"];
          $0 = _rest_1;
          $1 = ($transaction$045dispatch$045adapters$058prototype_packed_motion_world_ledger_restore$(_world_0, _old_1));
          continue;
        }
      }
    }
  }
}

function $held$045adapter$058prototype_packed_prototype_flatfold_motion_guard$1260$(_valid_0, _id_0, _ns_0, _next_0, _columns_0, _aux_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0, _metadata_0, _ledger_0) {
  if (_valid_0) {
    if (_ledger_0.$ === "Some") {
      const _ledger_1 = _ledger_0["value"];
      return $held$045adapter$058prototype_packed_prototype_flatfold_motion_live$1260$(($storage$058metadata_live$(_metadata_0, ((_id_0 - 1) >>> 0))), _ledger_1, _ns_0, _next_0, _columns_0, _aux_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0, _id_0);
    } else {
      return $held$045adapter$058prototype_packed_prototype_flatfold_motion_fallback$(($client$1260$(($transaction$058prototype_flat_unpack$1261$({$: "transaction.PrototypeFlatTx", "world": {$: "storage.World", "namespace": _ns_0, "next": _next_0, "rows": {$: "storage.Rows", "main": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})))), _total_0);
    }
  } else {
    return $held$045adapter$058prototype_packed_prototype_flatfold_motion_fallback$(($client$1260$(($transaction$058prototype_flat_unpack$1261$({$: "transaction.PrototypeFlatTx", "world": {$: "storage.World", "namespace": _ns_0, "next": _next_0, "rows": {$: "storage.Rows", "main": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})))), _total_0);
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $String$reverse$(_s_0) {
  return $String$reverse$go$(_s_0, "");
}

function $host$045render$058render_push$($0, $1) {
  for (;;) {
    {
      const _value_0 = $0;
      const _acc_0 = $1;
      if (_value_0 === "") {
        return _acc_0;
      } else {
        const _head_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(0, 2) : _value_0[0]);
        const _tail_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(2) : _value_0.slice(1));
        $0 = _tail_0;
        $1 = (_head_0 + _acc_0);
        continue;
      }
    }
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $query$058struct_cols_finish$(_capacity_0, _depth_0, _high_0, _state_0) {
  const _main_0 = _state_0["main"];
  const _aux_0 = _state_0["aux"];
  const _live_0 = _state_0["live"];
  const _flags_0 = _state_0["flags"];
  const _added_0 = _state_0["added"];
  const _changed_0 = _state_0["changed"];
  const _values_0 = _state_0["values"];
  return $query$058struct_idx_finish$(_capacity_0, _depth_0, _high_0, {$: "query.StructIdxState", "main": _main_0, "aux": _aux_0, "metadata": {$: "storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "values": _values_0});
}

function $query$058prototype_cursor_struct_idx_advance$1260$(_valid_0, _id_0, _namespace_0, _selection_0, _state_0) {
  if (!_valid_0) {
    return _state_0;
  } else {
    const _main_0 = _state_0["main"];
    const _aux_0 = _state_0["aux"];
    const _live_0 = _state_0["live"];
    const _flags_0 = _state_0["flags"];
    const _added_0 = _state_0["added"];
    const _changed_0 = _state_0["changed"];
    const _values_0 = _state_0["values"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $query$058prototype_cursor_struct_cols_live$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, {$: "Tuple", fst: _live_0, snd: _live_0[_x_0 % _live_0.length]});
  }
}

function $transaction$045dispatch$045adapters$058prototype_packed_motion_world_restore$(_world_0, _handle_0, _old_0) {
  return $transaction$058storage_restore_main0$1262$(_world_0, _handle_0, _old_0);
}

function $transaction$045dispatch$045adapters$058prototype_packed_motion_world_ledger_restore$(_world_0, _old_0) {
  return $transaction$058storage_restore_ledger0$1262$(_world_0, _old_0);
}

function $held$045adapter$058prototype_packed_prototype_flatfold_motion_live$1260$(_result_0, _ledger_0, _ns_0, _next_0, _columns_0, _aux_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0, _id_0) {
  const _metadata_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return $held$045adapter$058prototype_packed_prototype_flatfold_motion_fallback$(($client$1260$(($transaction$058prototype_flat_unpack$1261$({$: "transaction.PrototypeFlatTx", "world": {$: "storage.World", "namespace": _ns_0, "next": _next_0, "rows": {$: "storage.Rows", "main": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": {$: "Some", "value": _ledger_0}, "mode": _mode_0}, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})))), _total_0);
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $held$045adapter$058prototype_packed_prototype_flatfold_motion_taken$1260$(array_rmw(_columns_0, _x_0, () => _x_1), _ledger_0, _ns_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0);
  }
}

function $storage$058metadata_live$(_columns_0, _index_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  return $storage$058metadata_live_done$(_flags_0, _added_0, _changed_0, {$: "Tuple", fst: _live_0, snd: _live_0[_index_0 % _live_0.length]});
}

function $held$045adapter$058prototype_packed_prototype_flatfold_motion_fallback$(_result_0, _total_0) {
  return $held$045adapter$058prototype_packed_prototype_flatfold_motion_unpack$(($held$045adapter$058prototype_packed_prototype_flatfold_motion_converted$(_result_0)), _total_0);
}

function $client$1260$(_owner_0) {
  return $client_observed$1260$(($transaction$045dispatch$045adapters$058prototype_packed_motion_read_main$(($transaction$045dispatch$045adapters$058prototype_packed_motion_set_main0$(($transaction$045dispatch$045adapters$058prototype_packed_motion_set_main0$(_owner_0, {$: "types.PositionToken"}, 500)), {$: "types.PositionToken"}, 700)), {$: "types.PositionToken"})));
}

function $transaction$058prototype_flat_unpack$1261$(_owner_0) {
  const _world_0 = _owner_0["world"];
  const _selected_0 = _owner_0["selected"];
  const _undo_0 = _owner_0["undo"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  return {$: "transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": ($transaction$058prototype_flat_inverse_unpack$1260$(_undo_0)), "commands": _commands_0, "pings": _pings_0, "marks": ($transaction$058prototype_flat_mark_unpack$1260$(_marks_0))};
}

function $String$reverse$go$($0, $1) {
  for (;;) {
    {
      const _s_0 = $0;
      const _acc_0 = $1;
      if (_s_0 === "") {
        return _acc_0;
      } else {
        const _h_0 = (_s_0.codePointAt(0) > 0xFFFF ? _s_0.slice(0, 2) : _s_0[0]);
        const _t_0 = (_s_0.codePointAt(0) > 0xFFFF ? _s_0.slice(2) : _s_0.slice(1));
        $0 = _t_0;
        $1 = (_h_0 + _acc_0);
        continue;
      }
    }
  }
}

function $query$058struct_idx_finish$(_capacity_0, _depth_0, _high_0, _state_0) {
  const _main_0 = _state_0["main"];
  const _aux_0 = _state_0["aux"];
  const _metadata_0 = _state_0["metadata"];
  const _values_0 = _state_0["values"];
  return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": ($List$reverse$(_values_0))};
}

function $query$058prototype_cursor_struct_cols_live$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return {$: "query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $query$058prototype_cursor_struct_idx_metadata$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, true, {$: "Tuple", fst: _flags_0, snd: _flags_0[_x_0 % _flags_0.length]});
  }
}

function $transaction$058storage_restore_main0$1262$(_world_0, _handle_0, _value_0) {
  return $transaction$058discard_access$(($transaction$058storage_set_main0$1262$(_world_0, _handle_0, _value_0)));
}

function $transaction$058storage_restore_ledger0$1262$(_world_0, _value_0) {
  return $transaction$058discard_optional$(($transaction$058storage_set_ledger0$1262$(_world_0, _value_0)));
}

function $held$045adapter$058prototype_packed_prototype_flatfold_motion_taken$1260$(_result_0, _ledger_0, _ns_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0) {
  const _columns_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Some") {
    const _t_1 = _t_0["value"];
    const _coordinates_0 = _t_1["coordinates"];
    const _rawframe_0 = _t_1["rawframe"];
    const _a_0 = _t_1["a"];
    const _b_0 = _t_1["b"];
    const _c_0 = _t_1["c"];
    const _d_0 = _t_1["d"];
    const _cachedframe_0 = _t_1["cachedframe"];
    const _ledger_raw_0 = _ledger_0["raw"];
    const _ledger_cached_0 = _ledger_0["cached"];
    return $held$045adapter$058prototype_packed_prototype_flatfold_motion_returned$(($held$045adapter$058prototype_packed_row_invoke$1260$({$: "held-adapter.PrototypePackedMotionRowOwner", "coordinates": _coordinates_0, "rawframe": _rawframe_0, "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0, "cachedframe": _cachedframe_0, "ledger_raw": _ledger_raw_0, "ledger_cached": _ledger_cached_0, "handle": _selected_0, "undo": {$: "held-adapter.PrototypePendingUndo", "pending": false, "namespace": 0, "id": 0, "old": 0, "tail": _undo_0}, "marks": _marks_0})), _ns_0, _next_0, _columns_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, _commands_0, _pings_0, _total_0);
  } else {
    return $held$045adapter$058prototype_packed_prototype_flatfold_motion_fallback$(($client$1260$(($transaction$058prototype_flat_unpack$1261$({$: "transaction.PrototypeFlatTx", "world": {$: "storage.World", "namespace": _ns_0, "next": _next_0, "rows": {$: "storage.Rows", "main": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": {$: "Some", "value": _ledger_0}, "mode": _mode_0}, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})))), _total_0);
  }
}

function $storage$058metadata_live_done$(_flags_0, _added_0, _changed_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "snd": _value_0};
}

function $held$045adapter$058prototype_packed_prototype_flatfold_motion_unpack$(_result_0, _total_0) {
  const _t_0 = _result_0["fst"];
  const _t_1 = _t_0["world"];
  const _ns_0 = _t_1["namespace"];
  const _next_0 = _t_1["next"];
  const _t_2 = _t_1["rows"];
  const _columns_0 = _t_2["main"];
  const _aux_0 = _t_2["aux"];
  const _metadata_0 = _t_2["metadata"];
  const _capacity_0 = _t_2["capacity"];
  const _depth_0 = _t_2["depth"];
  const _high_0 = _t_2["high_water"];
  const _pending_0 = _t_1["pending"];
  const _ledger_0 = _t_1["ledger"];
  const _mode_0 = _t_1["mode"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  const _value_0 = _result_0["snd"];
  return {$: "held-adapter.PrototypeFlatFold", "namespace": _ns_0, "next": _next_0, "columns": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high": _high_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0, "total": ((_total_0 + _value_0) >>> 0)};
}

function $held$045adapter$058prototype_packed_prototype_flatfold_motion_converted$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($transaction$058prototype_flat_pack$1262$(_owner_0)), "snd": _value_0};
}

function $client_observed$1260$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return $client_after$1260$(_owner_0, _view_0);
}

function $transaction$045dispatch$045adapters$058prototype_packed_motion_read_main$(_t_0, _token_0) {
  return $transaction$058tx_read_main$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $transaction$045dispatch$045adapters$058prototype_packed_motion_world_read$(_x_0, _x_1);
});
}), _t_0);
}

function $transaction$045dispatch$045adapters$058prototype_packed_motion_set_main0$(_t_0, _token_0, _value_0) {
  return $transaction$058tx_set_main0$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $transaction$045dispatch$045adapters$058prototype_packed_motion_world_write$(_x_0, _x_1, _x_2);
});
});
}), _t_0, _value_0);
}

function $query$058prototype_cursor_struct_idx_metadata$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, _value_0, _result_0) {
  if (!_value_0) {
    const _flags_0 = _result_0["fst"];
    return {$: "query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _flags_1 = _result_0["fst"];
    const _flag_0 = _result_0["snd"];
    return $query$058prototype_cursor_struct_idx_selected$1260$(($query$058selected$(_selection_0, _flag_0)), _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_1, _added_0, _changed_0, _values_0, _flag_0);
  }
}

function $transaction$058discard_access$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $transaction$058storage_set_main0$1262$(_world_0, _handle_0, _value_0) {
  return $storage$058with_main$(_world_0, _handle_0, run_clo((_x_0) => {
  return $cached$045payload$058prototype_slot_position_swap$(_x_0, _value_0);
}));
}

function $transaction$058discard_optional$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $transaction$058storage_set_ledger0$1262$(_world_0, _value_0) {
  return $storage$058with_ledger$(_world_0, run_clo((_x_0) => {
  return $cached$045payload$058motion_ledger_swap$(_x_0, _value_0);
}));
}

function $held$045adapter$058prototype_packed_prototype_flatfold_motion_returned$(_result_0, _ns_0, _next_0, _columns_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, _commands_0, _pings_0, _total_0) {
  const _t_0 = _result_0["fst"];
  const _coordinates_0 = _t_0["coordinates"];
  const _rawframe_0 = _t_0["rawframe"];
  const _a_0 = _t_0["a"];
  const _b_0 = _t_0["b"];
  const _c_0 = _t_0["c"];
  const _d_0 = _t_0["d"];
  const _cachedframe_0 = _t_0["cachedframe"];
  const _ledger_raw_0 = _t_0["ledger_raw"];
  const _ledger_cached_0 = _t_0["ledger_cached"];
  const _t_1 = _t_0["handle"];
  const _space_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _undo_0 = _t_0["undo"];
  const _marks_0 = _t_0["marks"];
  const _value_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": {$: "cached-payload.PrototypeMotionMainSlot", "coordinates": _coordinates_0, "rawframe": _rawframe_0, "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0, "cachedframe": _cachedframe_0}};
  return {$: "held-adapter.PrototypeFlatFold", "namespace": _ns_0, "next": _next_0, "columns": (_columns_0[_x_0 % _columns_0.length] = _x_1, _columns_0), "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high": _high_0, "pending": _pending_0, "ledger": {$: "Some", "value": {$: "cache.Cache", "raw": _ledger_raw_0, "cached": _ledger_cached_0}}, "mode": _mode_0, "selected": {$: "storage.Handle", "namespace": _space_0, "id": _id_0}, "undo": ($held$045adapter$058prototype_pending_flush$1260$(_undo_0)), "commands": _commands_0, "pings": _pings_0, "marks": _marks_0, "total": ((_total_0 + _value_0) >>> 0)};
}

function $held$045adapter$058prototype_packed_row_invoke$1260$(_owner_0) {
  return $client$1261$(_owner_0);
}

function $transaction$058prototype_flat_pack$1262$(_owner_0) {
  const _world_0 = _owner_0["world"];
  const _selected_0 = _owner_0["selected"];
  const _undo_0 = _owner_0["undo"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  return {$: "transaction.PrototypeFlatTx", "world": _world_0, "selected": _selected_0, "undo": ($transaction$058prototype_flat_inverse_pack$1260$(_undo_0)), "commands": _commands_0, "pings": _pings_0, "marks": ($transaction$058prototype_flat_mark_pack$1260$(_marks_0))};
}

function $client_after$1260$(_owner_0, _result_0) {
  if (_result_0.$ === "types.Found") {
    const _view_0 = _result_0["value"];
    return {$: "Tuple", "fst": _owner_0, "snd": ($view_sum$(_view_0))};
  } else {
    return {$: "Tuple", "fst": _owner_0, "snd": 0};
  }
}

function $transaction$058tx_read_main$(_read_0, _t_0) {
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return $transaction$058read_main_finish$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _read_0(_world_0)(_selected_0));
}

function $transaction$045dispatch$045adapters$058prototype_packed_motion_world_read$(_world_0, _handle_0) {
  return $storage$058with_main$(_world_0, _handle_0, run_clo((_x_0) => {
  return $cached$045payload$058prototype_slot_position_get$(_x_0);
}));
}

function $transaction$058tx_set_main0$(_write_0, _t_0, _value_0) {
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return $transaction$058record_main$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _write_0(_world_0)(_selected_0)(_value_0));
}

function $transaction$045dispatch$045adapters$058prototype_packed_motion_world_write$(_world_0, _handle_0, _value_0) {
  return $transaction$058storage_set_main0$1262$(_world_0, _handle_0, _value_0);
}

function $query$058prototype_cursor_struct_idx_selected$1260$(_include_0, _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0) {
  if (!_include_0) {
    return {$: "query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    return $query$058prototype_cursor_inspect_state$(_id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0);
  }
}

function $query$058selected$(_selection_0, _flag_0) {
  if (_selection_0.$ === "query.Present") {
    if (_flag_0.$ === "None") {
      return false;
    } else {
      return true;
    }
  } else if (_selection_0.$ === "query.Absent") {
    if (_flag_0.$ === "Some") {
      return false;
    } else {
      return true;
    }
  } else {
    return true;
  }
}

function $storage$058with_main$(_world_0, _handle_0, _transform_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  const _foreign_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $storage$058hook_checked$((_namespace_0 === _foreign_0), {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, _id_0, _transform_0);
}

function $cached$045payload$058prototype_slot_position_swap$(_owner_0, _value_0) {
  const _coordinates_0 = _owner_0["coordinates"];
  const _rawframe_0 = _owner_0["rawframe"];
  const _b_0 = _owner_0["b"];
  const _c_0 = _owner_0["c"];
  const _d_0 = _owner_0["d"];
  const _cachedframe_0 = _owner_0["cachedframe"];
  return $cached$045payload$058prototype_slot_position_swap_done$(_rawframe_0, _b_0, _c_0, _d_0, _cachedframe_0, _value_0, {$: "Tuple", fst: _coordinates_0, snd: _coordinates_0[0 % _coordinates_0.length]});
}

function $storage$058with_ledger$(_world_0, _transform_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _t_0 = _world_0["ledger"];
  if (_t_0.$ === "None") {
    const _mode_0 = _world_0["mode"];
    return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": {$: "None"}, "mode": _mode_0}, "snd": {$: "None"}};
  } else {
    const _ledger_0 = _t_0["value"];
    const _mode_1 = _world_0["mode"];
    return $storage$058ledger_return$(_namespace_0, _next_0, _rows_0, _pending_0, _mode_1, _transform_0(_ledger_0));
  }
}

function $cached$045payload$058motion_ledger_swap$(_owner_0, _value_0) {
  return $cache$058static_swap$1262$(_owner_0, _value_0);
}

function $held$045adapter$058prototype_pending_flush$1260$(_state_0) {
  const _t_0 = _state_0["pending"];
  if (!_t_0) {
    const _tail_0 = _state_0["tail"];
    return _tail_0;
  } else {
    const __3 = _state_0["namespace"];
    const __4 = _state_0["id"];
    const __5 = _state_0["old"];
    const _tail_1 = _state_0["tail"];
    return {$: "transaction.PrototypeFlatMain", "namespace": __3, "id": __4, "old": __5, "tail": _tail_1};
  }
}

function $client$1261$(_owner_0) {
  return $client_observed$1261$(($held$045adapter$058prototype_packed_row_get$(($held$045adapter$058prototype_packed_row_set$(($held$045adapter$058prototype_packed_row_set$(_owner_0, {$: "types.PositionToken"}, 500)), {$: "types.PositionToken"}, 700)), {$: "types.PositionToken"})));
}

function $view_sum$(_view_0) {
  const _t_0 = _view_0["coordinates"];
  const _a_0 = _t_0["a"];
  const _b_0 = _t_0["b"];
  const _c_0 = _t_0["c"];
  const _d_0 = _t_0["d"];
  const _frame_0 = _view_0["frame"];
  const _x_0 = ((_c_0 + _d_0) >>> 0);
  const _x_1 = ((_a_0 + _b_0) >>> 0);
  const _x_2 = ((_x_0 + _frame_0) >>> 0);
  return ((_x_1 + _x_2) >>> 0);
}

function $transaction$058read_main_finish$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}, "snd": _view_0};
}

function $cached$045payload$058prototype_slot_position_get$(_owner_0) {
  const _coordinates_0 = _owner_0["coordinates"];
  const _rawframe_0 = _owner_0["rawframe"];
  const _a_0 = _owner_0["a"];
  const _b_0 = _owner_0["b"];
  const _c_0 = _owner_0["c"];
  const _d_0 = _owner_0["d"];
  const _cachedframe_0 = _owner_0["cachedframe"];
  return {$: "Tuple", "fst": {$: "cached-payload.PrototypeMotionMainSlot", "coordinates": _coordinates_0, "rawframe": _rawframe_0, "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0, "cachedframe": _cachedframe_0}, "snd": {$: "types.PositionView", "coordinates": {$: "types.Four", "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0}, "frame": _cachedframe_0}};
}

function $transaction$058record_main$(_handle_0, _undo_0, _commands_0, _pings_0, _marks_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "types.Found") {
    const _old_0 = _t_0["value"];
    return {$: "transaction.Tx", "world": _world_0, "selected": _handle_0, "undo": {$: "Con", "head": {$: "transaction.MainInverse", "handle": _handle_0, "old": _old_0}, "tail": _undo_0}, "commands": _commands_0, "pings": _pings_0, "marks": {$: "Con", "head": _handle_0, "tail": _marks_0}};
  } else {
    return {$: "transaction.Tx", "world": _world_0, "selected": _handle_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0};
  }
}

function $query$058prototype_cursor_inspect_state$(_id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0) {
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "None"};
  return $query$058prototype_cursor_restore_state$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, array_rmw(_main_0, _x_0, () => _x_1));
}

function $storage$058hook_checked$(_valid_0, _world_0, _target_0, _transform_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "types.Missing"}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _t_0 = _world_0["rows"];
    const _main_0 = _t_0["main"];
    const _aux_0 = _t_0["aux"];
    const _metadata_0 = _t_0["metadata"];
    const _capacity_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _high_0 = _t_0["high_water"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return $storage$058fuse_bounds$(($Bool$and$((0 < _target_0), ($Bool$and$((_target_0 <= _capacity_0), (_target_0 <= _high_0))))), {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, _target_0, _transform_0);
  }
}

function $cached$045payload$058prototype_slot_position_swap_done$(_rawframe_0, _b_0, _c_0, _d_0, _cachedframe_0, _value_0, _result_0) {
  const _coordinates_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "cached-payload.PrototypeMotionMainSlot", "coordinates": (_coordinates_0[0 % _coordinates_0.length] = _value_0, _coordinates_0), "rawframe": _rawframe_0, "a": _value_0, "b": _b_0, "c": _c_0, "d": _d_0, "cachedframe": _cachedframe_0}, "snd": _old_0};
}

function $storage$058ledger_return$(_namespace_0, _next_0, _rows_0, _pending_0, _mode_0, _result_0) {
  const _ledger_0 = _result_0["fst"];
  const _observation_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": {$: "Some", "value": _ledger_0}, "mode": _mode_0}, "snd": {$: "Some", "value": _observation_0}};
}

function $cache$058static_swap$1262$(_owner_0, _value_0) {
  const _raw_0 = _owner_0["raw"];
  const _cached_0 = _owner_0["cached"];
  return $cache$058static_swap_done$1262$(_cached_0, _value_0, ($uncached$045payload$058motion_ledger_swap$(_raw_0, _value_0)));
}

function $client_observed$1261$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return $client_after$1261$(_owner_0, _view_0);
}

function $held$045adapter$058prototype_packed_row_get$(_owner_0, _token_0) {
  const _coordinates_0 = _owner_0["coordinates"];
  const _rawframe_0 = _owner_0["rawframe"];
  const _a_0 = _owner_0["a"];
  const _b_0 = _owner_0["b"];
  const _c_0 = _owner_0["c"];
  const _d_0 = _owner_0["d"];
  const _cachedframe_0 = _owner_0["cachedframe"];
  const _ledger_raw_0 = _owner_0["ledger_raw"];
  const _ledger_cached_0 = _owner_0["ledger_cached"];
  const _handle_0 = _owner_0["handle"];
  const _undo_0 = _owner_0["undo"];
  const _marks_0 = _owner_0["marks"];
  return {$: "Tuple", "fst": {$: "held-adapter.PrototypePackedMotionRowOwner", "coordinates": _coordinates_0, "rawframe": _rawframe_0, "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0, "cachedframe": _cachedframe_0, "ledger_raw": _ledger_raw_0, "ledger_cached": _ledger_cached_0, "handle": _handle_0, "undo": _undo_0, "marks": _marks_0}, "snd": {$: "types.Found", "value": {$: "types.PositionView", "coordinates": {$: "types.Four", "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0}, "frame": _cachedframe_0}}};
}

function $held$045adapter$058prototype_packed_row_set$(_owner_0, _token_0, _value_0) {
  const _coordinates_0 = _owner_0["coordinates"];
  const _rawframe_0 = _owner_0["rawframe"];
  const _b_0 = _owner_0["b"];
  const _c_0 = _owner_0["c"];
  const _d_0 = _owner_0["d"];
  const _cachedframe_0 = _owner_0["cachedframe"];
  const _ledger_raw_0 = _owner_0["ledger_raw"];
  const _ledger_cached_0 = _owner_0["ledger_cached"];
  const _handle_0 = _owner_0["handle"];
  const _undo_0 = _owner_0["undo"];
  const _marks_0 = _owner_0["marks"];
  return $held$045adapter$058prototype_packed_row_set_done$(_rawframe_0, _b_0, _c_0, _d_0, _cachedframe_0, _ledger_raw_0, _ledger_cached_0, _handle_0, _undo_0, _marks_0, _value_0, {$: "Tuple", fst: _coordinates_0, snd: _coordinates_0[0 % _coordinates_0.length]});
}

function $query$058prototype_cursor_restore_state$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _owner_0 = _t_0["value"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return {$: "query.StructColsState", "main": (_main_0[_x_0 % _main_0.length] = _x_1, _main_0), "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": {$: "Con", "head": _id_0, "tail": _values_0}};
  }
}

function $storage$058fuse_bounds$(_valid_0, _world_0, _target_0, _transform_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "types.Missing"}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _t_0 = _world_0["rows"];
    const _main_0 = _t_0["main"];
    const _aux_0 = _t_0["aux"];
    const _metadata_0 = _t_0["metadata"];
    const _capacity_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _high_0 = _t_0["high_water"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return $storage$058prototype_fuse_columns$(_namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, ((_target_0 - 1) >>> 0), _transform_0);
  }
}

function $cache$058static_swap_done$1262$(_cached_0, _value_0, _result_0) {
  const _raw_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "cache.Cache", "raw": _raw_0, "cached": ($cached$045payload$058motion_ledger_patch$(_cached_0, _value_0))}, "snd": _old_0};
}

function $uncached$045payload$058motion_ledger_swap$(_owner_0, _value_0) {
  const _array_0 = _owner_0["totals"];
  const _epoch_0 = _owner_0["epoch"];
  return $uncached$045payload$058prototype_direct_motion_ledger_swap$(_epoch_0, _value_0, {$: "Tuple", fst: _array_0, snd: _array_0[0 % _array_0.length]});
}

function $client_after$1261$(_owner_0, _result_0) {
  if (_result_0.$ === "types.Found") {
    const _view_0 = _result_0["value"];
    return {$: "Tuple", "fst": _owner_0, "snd": ($view_sum$(_view_0))};
  } else {
    return {$: "Tuple", "fst": _owner_0, "snd": 0};
  }
}

function $held$045adapter$058prototype_packed_row_set_done$(_rawframe_0, _b_0, _c_0, _d_0, _cachedframe_0, _ledger_raw_0, _ledger_cached_0, _handle_0, _undo_0, _marks_0, _value_0, _result_0) {
  const _space_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  const _coordinates_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return {$: "held-adapter.PrototypePackedMotionRowOwner", "coordinates": (_coordinates_0[0 % _coordinates_0.length] = _value_0, _coordinates_0), "rawframe": _rawframe_0, "a": _value_0, "b": _b_0, "c": _c_0, "d": _d_0, "cachedframe": _cachedframe_0, "ledger_raw": _ledger_raw_0, "ledger_cached": _ledger_cached_0, "handle": {$: "storage.Handle", "namespace": _space_0, "id": _id_0}, "undo": ($held$045adapter$058prototype_pending_main$1260$(_space_0, _id_0, _old_0, _undo_0)), "marks": {$: "transaction.PrototypeFlatMark", "namespace": _space_0, "id": _id_0, "tail": _marks_0}};
}

function $storage$058prototype_fuse_columns$(_namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0) {
  const _live_0 = _metadata_0["live"];
  const _flags_0 = _metadata_0["flags"];
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  return $storage$058prototype_fuse_live_result$(_namespace_0, _next_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, {$: "Tuple", fst: _live_0, snd: _live_0[_index_0 % _live_0.length]});
}

function $cached$045payload$058motion_ledger_patch$(_view_0, _value_0) {
  const _t_0 = _view_0["totals"];
  const _b_0 = _t_0["b"];
  const _c_0 = _t_0["c"];
  const _d_0 = _t_0["d"];
  const _epoch_0 = _view_0["epoch"];
  return {$: "types.LedgerView", "totals": {$: "types.Four", "a": _value_0, "b": _b_0, "c": _c_0, "d": _d_0}, "epoch": _epoch_0};
}

function $uncached$045payload$058prototype_direct_motion_ledger_swap$(_epoch_0, _value_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "types.MotionLedger", "totals": (_array_0[0 % _array_0.length] = _value_0, _array_0), "epoch": _epoch_0}, "snd": _old_0};
}

function $held$045adapter$058prototype_pending_main$1260$(_space_0, _id_0, _old_0, _state_0) {
  return {$: "held-adapter.PrototypePendingUndo", "pending": true, "namespace": _space_0, "id": _id_0, "old": _old_0, "tail": ($held$045adapter$058prototype_pending_flush$1260$(_state_0))};
}

function $storage$058prototype_fuse_live_result$(_namespace_0, _next_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $storage$058fuse_live$(_namespace_0, _next_0, _aux_0, {$: "storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0, _value_0);
}

function $storage$058fuse_live$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0, _meta_0) {
  if (!_meta_0) {
    return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "types.Missing"}};
  } else {
    const _x_0 = {$: "None"};
    return $storage$058fuse_taken$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, array_rmw(_main_0, _index_0, () => _x_0));
  }
}

function $storage$058fuse_taken$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "types.Mismatch"}};
  } else {
    const _value_0 = _t_0["value"];
    return $storage$058fuse_return$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0(_value_0));
  }
}

function $storage$058fuse_return$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _result_0) {
  const _value_0 = _result_0["fst"];
  const _observation_0 = _result_0["snd"];
  const _x_0 = {$: "Some", "value": _value_0};
  return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "storage.Rows", "main": (_main_0[_index_0 % _main_0.length] = _x_0, _main_0), "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "types.Found", "value": _observation_0}};
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);