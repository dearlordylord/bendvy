const __pool_token_0 = Object.freeze({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.PositionToken"});
const __pool_token_1 = Object.freeze({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.MotionLedgerToken"});
function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// IO
// ==

function io_now() {
  return BigInt(Math.floor(performance.now()));
}

io_eff("IO.now", io_now);

})();

(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

for (const k of ["IO.now","IO.print"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return $motion_batch$(256, 64);
}

function $motion_batch$(_count_0, _batch_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($measurement$045bend$058motion_start$(_count_0, false)), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$bind$(($motion_prepared$(_batch_0, _count_0, {$: "Nil"})), run_clo((_x_3) => {
  return $motion_timed$(_x_3);
}), _x_2);
});
}), _x_0);
});
}

function $IO$bind$(_m_0, _f_0, _k_0) {
  return run_tail(_m_0, run_clo((_x_0) => {
  return run_tail(_f_0(_x_0), _k_0);
}));
}

function $measurement$045bend$058motion_start$(_count_0, _sparse_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($measurement$045bend$058motion_created$(_count_0, _sparse_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047raw$045boundaries$058motion_create$1260$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047identity$058factory$()), {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.MotionOn"})))), run_clo((_x_1) => {
  return $measurement$045bend$058motion_measured$(_x_1);
}), _x_0);
});
}

function $motion_prepared$(_fuel_0, _count_0, _owners_0) {
  if (_fuel_0 === 0) {
    return run_clo((_x_0) => {
  return $IO$pure$(($List$reverse$(_owners_0)), _x_0);
});
  } else {
    const _rest_0 = (_fuel_0 - 1);
    return run_clo((_x_1) => {
  return $IO$bind$(($measurement$045bend$058motion_fresh$(_count_0)), run_clo((_x_2) => {
  return $motion_prepared$(_rest_0, _count_0, {$: "Con", "head": _x_2, "tail": _owners_0});
}), _x_1);
});
  }
}

function $motion_timed$(_owners_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $IO$now$(_x_1), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $IO$bind$(($motion_execute$(_owners_0, {$: "Nil"})), run_clo((_x_4) => {
  return run_clo((_x_5) => {
  return $IO$bind$((_x_6) => $IO$now$(_x_6), run_clo((_x_7) => {
  return run_clo((_x_8) => {
  const _x_9 = ($Nat$show$((_x_7 < _x_2 ? 0 : _x_7 - _x_2)));
  return $IO$bind$((_x_10) => $IO$print$(("BATCH-MILLISECONDS:" + _x_9), _x_10), run_clo((_x_11) => {
  return $motion_dump$(_x_4);
}), _x_8);
});
}), _x_5);
});
}), _x_3);
});
}), _x_0);
});
}

function $measurement$045bend$058motion_created$(_count_0, _sparse_0, _result_0) {
  if (_result_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Created") {
    const _world_0 = _result_0["world"];
    return $measurement$045bend$058motion_registered$(_count_0, _sparse_0, _world_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047schedule$058register$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047schedule$058initial$()), "BenchUpdate", {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Snapshot"}, true, false, false, false)));
  } else {
    return run_clo((_x_0) => {
  return $IO$die$(4, "factory rejected", _x_0);
});
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047raw$045boundaries$058motion_create$1260$(_factory_0, _mode_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047identity$058create$1260$(_factory_0, _mode_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047identity$058factory$() {
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Factory", "next": 1};
}

function $measurement$045bend$058motion_measured$(_pair_0) {
  const _state_0 = _pair_0["fst"];
  const _system_0 = _pair_0["snd"];
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $IO$now$(_x_1), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $IO$bind$(($measurement$045bend$058motion_loops$(64, _system_0, _state_0)), run_clo((_x_4) => {
  return $measurement$045bend$058motion_stop$(_x_2, _x_4);
}), _x_3);
});
}), _x_0);
});
}

function $IO$pure$(_x_0, _k_0) {
  return run_tail(_k_0, _x_0);
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $measurement$045bend$058motion_fresh$(_count_0) {
  return $measurement$045bend$058motion_created$(_count_0, false, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047raw$045boundaries$058motion_create$1260$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047identity$058factory$()), {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.MotionOn"})));
}

function $IO$now$(_k_0) {
  return { $: "$FFI", run: $0eff["IO.now"].run, need: $0eff["IO.now"].need, args: [], kont: ((f) => (x) => (f(nat_host(x))))(_k_0) };
}
function $motion_execute$(_owners_0, _done_0) {
  if (_owners_0.$ === "Nil") {
    return run_clo((_x_0) => {
  return $IO$pure$(($List$reverse$(_done_0)), _x_0);
});
  } else {
    const _t_0 = _owners_0["head"];
    const _owner_0 = _t_0["fst"];
    const _system_0 = _t_0["snd"];
    const _rest_0 = _owners_0["tail"];
    return run_clo((_x_1) => {
  return $IO$bind$(($measurement$045bend$058motion_loops$(64, _system_0, _owner_0)), run_clo((_x_2) => {
  return $motion_returned$(run_clo((_x_3) => {
  return $motion_execute$(_rest_0, _x_3);
}), _done_0, _x_2);
}), _x_1);
});
  }
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $motion_dump$(_owners_0) {
  if (_owners_0.$ === "Nil") {
    return run_clo((_x_0) => {
  return $IO$pure$({$: "Unit"}, _x_0);
});
  } else {
    const _owner_0 = _owners_0["head"];
    const _rest_0 = _owners_0["tail"];
    return run_clo((_x_1) => {
  return $IO$bind$(($measurement$045bend$058motion_dump$(0, _owner_0)), run_clo((_x_2) => {
  return $motion_dump$(_rest_0);
}), _x_1);
});
  }
}

function $measurement$045bend$058motion_registered$(_count_0, _sparse_0, _world_0, _registered_0) {
  const _registry_0 = _registered_0["registry"];
  const _system_0 = _registered_0["system"];
  return run_clo((_x_0) => {
  return $IO$bind$(($measurement$045bend$058motion_tick$({$: "Con", "head": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Deferred"}, "tail": {$: "Nil"}}, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Runtime", "world": {$: "measurement-bend.MotionBench", "host": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$058initial$("motion", ($measurement$045bend$058motion_seed$(_count_0, 0, _sparse_0, _world_0)), 65536)), "sparse": _sparse_0, "readsum": 0, "calls": 0}, "registry": _registry_0, "readers": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058initial$()), "clock": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058clock$()), "audit": {$: "None"}, "style": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/capture.Returned"}, "escaped": {$: "Nil"}, "observations": {$: "Nil"}, "nextMode": {$: "None"}})), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$bind$(run_loop($measurement$045bend$058motion_continue$(run_clo((_x_3) => {
  return run_clo((_x_4) => {
  return $IO$pure$(_x_3, _x_4);
});
}), _x_1)), run_clo((_x_5) => {
  return run_clo((_x_6) => {
  return $IO$pure$({$: "Tuple", "fst": _x_5, "snd": _system_0}, _x_6);
});
}), _x_2);
});
}), _x_0);
});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047schedule$058register$(_registry_0, _name_0, _kind_0, _ledger_0, _audit_0, _gated_0, _reader_0) {
  const _next_0 = _registry_0["next"];
  const _entries_0 = _registry_0["entries"];
  const _system_0 = {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.System", "base": _next_0, "name": _name_0, "kind": _kind_0, "ledger": _ledger_0, "audit": _audit_0, "gated": _gated_0, "reader": _reader_0};
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Registered", "registry": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Registry", "next": ((_next_0 + 1) >>> 0), "entries": {$: "Con", "head": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Entry", "system": _system_0, "local": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047capture$058initial$())}, "tail": _entries_0}}, "system": _system_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047schedule$058initial$() {
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Registry", "next": 1, "entries": {$: "Nil"}};
}

function $IO$die$(_code_0, _msg_0, _k_0) {
  return {$: "Halt", "code": _code_0, "message": _msg_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047identity$058create$1260$(_factory_0, _mode_0) {
  const _namespace_0 = _factory_0["next"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047identity$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _mode_0);
}

function $measurement$045bend$058motion_loops$(_fuel_0, _system_0, _runtime_0) {
  if (_fuel_0 === 0) {
    return run_clo((_x_0) => {
  return $IO$pure$(_runtime_0, _x_0);
});
  } else {
    const _rest_0 = (_fuel_0 - 1);
    return run_clo((_x_1) => {
  return $IO$bind$(($measurement$045bend$058motion_tick$({$: "Con", "head": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Call", "system": _system_0, "mode": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Normal"}}, "tail": {$: "Nil"}}, _runtime_0)), run_clo((_x_2) => {
  return $measurement$045bend$058motion_continue$(run_clo((_x_3) => {
  return $measurement$045bend$058motion_loops$(_rest_0, _system_0, _x_3);
}), _x_2);
}), _x_1);
});
  }
}

function $measurement$045bend$058motion_stop$(_start_0, _state_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $IO$now$(_x_1), run_clo((_x_2) => {
  return $measurement$045bend$058motion_dump$((_x_2 < _start_0 ? 0 : _x_2 - _start_0), _state_0);
}), _x_0);
});
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $motion_returned$(_next_0, _done_0, _owner_0) {
  return run_tail(_next_0, {$: "Con", "head": _owner_0, "tail": _done_0});
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $measurement$045bend$058motion_dump$(_elapsed_0, _state_0) {
  const _t_0 = _state_0["world"];
  const _t_1 = _t_0["host"];
  const _world_0 = _t_1["world"];
  const _total_0 = _t_0["readsum"];
  const _calls_0 = _t_0["calls"];
  const _clock_0 = _state_0["clock"];
  return $measurement$045bend$058motion_print$(_elapsed_0, _total_0, _calls_0, _clock_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058world$1260$(_world_0)));
}

function $measurement$045bend$058motion_tick$(_nodes_0, _runtime_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058tick$1262$(_nodes_0, "MotionLedger", "Mode", _runtime_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$058initial$(_worldName_0, _world_0, _capacity_0) {
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/host.Host", "world": _world_0, "logs": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047reader$045host$058initial$(_capacity_0)), "bindings": {$: "Nil"}, "worldName": _worldName_0, "step": "", "prior": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Complete"}, "events": {$: "Nil"}};
}

function $measurement$045bend$058motion_seed$($0, $1, $2, $3) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _j_0 = $1;
      const _sparse_0 = $2;
      const _world_0 = $3;
      if (_fuel_0 === 0) {
        return _world_0;
      } else {
        const _rest_0 = (_fuel_0 - 1);
        $0 = _rest_0;
        $1 = ((_j_0 + 1) >>> 0);
        $2 = _sparse_0;
        $3 = ($measurement$045bend$058motion_reserved$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047raw$045boundaries$058motion_reserve$(_world_0, ($measurement$045bend$058motion_bundle$(_j_0, _sparse_0))))));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058initial$() {
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Readers", "slots": {$: "Nil"}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058clock$() {
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Clock", "tick": 0, "frameStart": 0, "retainedAfter": 0, "frameNo": 0};
}

function $measurement$045bend$058motion_continue$(_next_0, _result_0) {
  const _runtime_0 = _result_0["runtime"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Complete") {
    return run_tail(_next_0, _runtime_0);
  } else {
    return run_clo((_x_0) => {
  return $IO$die$(3, "dispatch failure", _x_0);
});
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047capture$058initial$() {
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/capture.Local", "count": array_new(2, 0)};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047identity$058create_checked$1260$(_available_0, _namespace_0, _mode_0) {
  if (!_available_0) {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.CreateRejected", "factory": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Factory", "next": _namespace_0}};
  } else {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Created", "factory": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Factory", "next": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": 1, "rows": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058rows_empty$()), "pending": {$: "Nil"}, "ledger": {$: "Some", "value": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047raw$045boundaries$058motion_ledger$1260$({$: "Unit"}))}, "mode": _mode_0}};
  }
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $measurement$045bend$058motion_print$(_elapsed_0, _total_0, _calls_0, _clock_0, _pair_0) {
  const _view_0 = _pair_0["snd"];
  const _x_0 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_world$1260$(_view_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($U32$show$(($measurement$045bend$058clock_frame$(_clock_0))));
  const _x_3 = (",\"world\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($U32$show$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058clock_tick$(_clock_0))));
  const _x_6 = (",\"frames\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($U32$show$(_calls_0));
  const _x_9 = (",\"tick\":" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($U32$show$(_total_0));
  const _x_12 = (",\"calls\":" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = ($Nat$show$(_elapsed_0));
  const _x_15 = (",\"readsum\":" + _x_13);
  const _x_16 = (_x_14 + _x_15);
  return (_x_17) => $IO$print$(("{\"milliseconds\":" + _x_16), _x_17);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058world$1260$(_owner_0) {
  const _namespace_0 = _owner_0["namespace"];
  const _next_0 = _owner_0["next"];
  const _owners_0 = _owner_0["rows"];
  const _pending_0 = _owner_0["pending"];
  const _ledger_0 = _owner_0["ledger"];
  const _mode_0 = _owner_0["mode"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058world_rows$1260$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058rows$1260$(_owners_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058tick$1262$(_nodes_0, _ledgerName_0, _stateName_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _registry_0 = _runtime_0["registry"];
  const _readers_0 = _runtime_0["readers"];
  const _clock_0 = _runtime_0["clock"];
  const _audit_0 = _runtime_0["audit"];
  const _style_0 = _runtime_0["style"];
  const _escaped_0 = _runtime_0["escaped"];
  const _observations_0 = _runtime_0["observations"];
  const _nextMode_0 = _runtime_0["nextMode"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058tick_registry$1262$(_nodes_0, _ledgerName_0, _stateName_0, _world_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058registry_values$(_registry_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047reader$045host$058initial$(_capacity_0) {
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/reader-host.Logs", "ping": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058initial$(_capacity_0)), "removed": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058life_initial$(_capacity_0)), "despawned": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058life_initial$(_capacity_0))};
}

function $measurement$045bend$058motion_reserved$(_result_0) {
  if (_result_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Reserved") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    return _world_1;
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047raw$045boundaries$058motion_reserve$(_world_0, _raw_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047raw$045boundaries$058motion_reserve_return$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058reserve$(_world_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047raw$045boundaries$058motion_bundle$(_raw_0)))));
}

function $measurement$045bend$058motion_bundle$(_j_0, _sparse_0) {
  const _x_0 = (8 === 0 ? _j_0 : _j_0 % 8);
  const _x_1 = ($Bool$not$(_sparse_0));
  const _x_2 = (_x_0 === 0);
  const _x_3 = (3 === 0 ? _j_0 : _j_0 % 3);
  const _x_4 = (3 === 0 ? _j_0 : _j_0 % 3);
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Bundle", "main": ($measurement$045bend$058motion_main$(_j_0, (_x_1 || _x_2))), "aux": ($measurement$045bend$058motion_aux$((_x_3 === 0))), "flag": ($measurement$045bend$058motion_flag$((_x_4 === 1)))};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058rows_empty$() {
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": [{$: "None"}], "aux": [{$: "None"}], "metadata": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058metadata_empty$(0)), "capacity": 1, "depth": 0, "high_water": 0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047raw$045boundaries$058motion_ledger$1260$(_unit_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058motion_ledger_new$(($measurement$045bend$058motion_ledger$(_unit_0)));
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058clock_tick$(_clock_0) {
  const _tick_0 = _clock_0["tick"];
  return _tick_0;
}

function $measurement$045bend$058clock_frame$(_clock_0) {
  const _frames_0 = _clock_0["frameNo"];
  return _frames_0;
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_world$1260$(_value_0) {
  const _namespace_0 = _value_0["namespace"];
  const _next_0 = _value_0["next"];
  const _rows_0 = _value_0["rows"];
  const _pending_0 = _value_0["pending"];
  const _ledger_0 = _value_0["ledger"];
  const _mode_0 = _value_0["mode"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"namespace\":", "tail": {$: "Con", "head": ($U32$show$(_namespace_0)), "tail": {$: "Con", "head": ",\"next\":", "tail": {$: "Con", "head": ($U32$show$(_next_0)), "tail": {$: "Con", "head": ",\"rows\":", "tail": {$: "Con", "head": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_list$1265$(_rows_0)), "tail": {$: "Con", "head": ",\"pending\":", "tail": {$: "Con", "head": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_list$1266$(_pending_0)), "tail": {$: "Con", "head": ",\"ledger\":", "tail": {$: "Con", "head": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_optional$1260$(_ledger_0)), "tail": {$: "Con", "head": ",\"mode\":", "tail": {$: "Con", "head": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_motion_mode$(_mode_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}}}}}}}});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058world_rows$1260$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058world_commands$1260$(_namespace_0, _next_0, _owners_0, _values_0, _ledger_0, _mode_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058commands$1260$(_pending_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058rows$1260$(_owners_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058rows_start$1260$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058rows_high_water$(_owners_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058tick_registry$1262$(_nodes_0, _ledgerName_0, _stateName_0, _world_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _scan_0) {
  const _registry_0 = _scan_0["fst"];
  const _systems_0 = _scan_0["snd"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058tick_canonical$1262$(_ledgerName_0, _stateName_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058canonical$(_systems_0, _nodes_0)), {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058registry_values$(_registry_0) {
  const _next_0 = _registry_0["next"];
  const _entries_0 = _registry_0["entries"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058registry_return$(_next_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058registry_entries$(_entries_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058initial$(_capacity_0) {
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/streams.PingLog", "buffer": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/streams.Buffer", "capacity": _capacity_0, "size": 0, "dropped": 0, "front": {$: "Nil"}, "rear": {$: "Nil"}}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058life_initial$(_capacity_0) {
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/streams.LifeLog", "buffer": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/streams.Buffer", "capacity": _capacity_0, "size": 0, "dropped": 0, "front": {$: "Nil"}, "rear": {$: "Nil"}}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047raw$045boundaries$058motion_reserve_return$(_result_0) {
  if (_result_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Reserved") {
    const _world_0 = _result_0["world"];
    const _handle_0 = _result_0["handle"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Reserved", "world": _world_0, "handle": _handle_0};
  } else {
    const _world_1 = _result_0["world"];
    const _bundle_0 = _result_0["payload"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.ReserveRejected", "world": _world_1, "payload": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047raw$045boundaries$058motion_raw_bundle$(_bundle_0))};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058reserve$(_world_0, _bundle_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058reserved$(_bundle_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047identity$058reserve_id$(_world_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047raw$045boundaries$058motion_bundle$(_raw_0) {
  const _main_0 = _raw_0["main"];
  const _aux_0 = _raw_0["aux"];
  const _flag_0 = _raw_0["flag"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Bundle", "main": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047raw$045boundaries$058motion_main$(_main_0)), "aux": _aux_0, "flag": _flag_0};
}

function $measurement$045bend$058motion_main$(_j_0, _present_0) {
  if (!_present_0) {
    return {$: "None"};
  } else {
    return {$: "Some", "value": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Position", "coordinates": ($measurement$045bend$058quad$(_j_0, ((_j_0 + 1) >>> 0), ((_j_0 + 2) >>> 0), ((_j_0 + 3) >>> 0))), "frame": 7}};
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $measurement$045bend$058motion_aux$(_present_0) {
  if (!_present_0) {
    return {$: "None"};
  } else {
    return {$: "Some", "value": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Velocity", "rates": ($measurement$045bend$058quad$(1, 2, 3, 4)), "moving": true}};
  }
}

function $measurement$045bend$058motion_flag$(_present_0) {
  if (!_present_0) {
    return {$: "None"};
  } else {
    return {$: "Some", "value": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Selected", "group": 8}};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058metadata_empty$(_depth_0) {
  const _x_0 = {$: "None"};
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.MetadataColumns", "live": array_new(_depth_0, false), "flags": array_new(_depth_0, _x_0), "added": array_new(_depth_0, 0), "changed": array_new(_depth_0, 0)};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058motion_ledger_new$(_raw_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cache$058static_init$1262$(_raw_0);
}

function $measurement$045bend$058motion_ledger$(_unit_0) {
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.MotionLedger", "totals": ($measurement$045bend$058quad$(0, 101, 102, 103)), "epoch": 4};
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$(_values_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_chunks$(_values_0, "");
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_list$1265$(_values_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "[", "tail": {$: "Con", "head": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_list_tail$1265$(_values_0, {$: "Nil"}, true)))), "tail": {$: "Con", "head": "]", "tail": {$: "Nil"}}}});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_list$1266$(_values_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "[", "tail": {$: "Con", "head": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_list_tail$1266$(_values_0, {$: "Nil"}, true)))), "tail": {$: "Con", "head": "]", "tail": {$: "Nil"}}}});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_optional$1260$(_value_0) {
  if (_value_0.$ === "None") {
    return "null";
  } else {
    const _value_1 = _value_0["value"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_ledger$(_value_1);
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_motion_mode$(_value_0) {
  if (_value_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.MotionOn") {
    return "\"MotionOn\"";
  } else {
    return "\"MotionOff\"";
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058world_commands$1260$(_namespace_0, _next_0, _rows_0, _rowViews_0, _ledger_0, _mode_0, _result_0) {
  const _pending_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058world_ledger$(_namespace_0, _next_0, _rows_0, _rowViews_0, _pending_0, _values_0, _mode_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058maybe_get$1264$(_ledger_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058commands$1260$(_owners_0) {
  if (_owners_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _owners_0["head"];
    const _tail_0 = _owners_0["tail"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058commands_head$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058command$1260$(_head_0)), ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058commands$1260$(_tail_0)));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058rows_start$1260$(_result_0) {
  const _owners_0 = _result_0["fst"];
  const _high_0 = _result_0["snd"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058rows_go$1260$(_high_0, 1, {$: "Tuple", "fst": _owners_0, "snd": {$: "Nil"}});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058rows_high_water$(_rows_0) {
  const _m_0 = _rows_0["main"];
  const _a_0 = _rows_0["aux"];
  const _f_0 = _rows_0["metadata"];
  const _c_0 = _rows_0["capacity"];
  const _d_0 = _rows_0["depth"];
  const _h_0 = _rows_0["high_water"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, "snd": _h_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058tick_canonical$1262$(_ledgerName_0, _stateName_0, _checked_0, _runtime_0) {
  if (_checked_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Unknown") {
    const _base_0 = _checked_0["base"];
    return run_clo((_x_0) => {
  const _x_1 = ($U32$show$(_base_0));
  return $IO$pure$({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Dispatched", "runtime": _runtime_0, "outcome": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.SetupRejected", "reason": ("unregistered base:" + _x_1)}}, _x_0);
});
  } else {
    const _nodes_0 = _checked_0["nodes"];
    const _world_0 = _runtime_0["world"];
    const _registry_0 = _runtime_0["registry"];
    const _readers_0 = _runtime_0["readers"];
    const _clock_0 = _runtime_0["clock"];
    const _audit_0 = _runtime_0["audit"];
    const _style_0 = _runtime_0["style"];
    const _escaped_0 = _runtime_0["escaped"];
    const _observations_0 = _runtime_0["observations"];
    const _nextMode_0 = _runtime_0["nextMode"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058tick_presence$1262$(_nodes_0, _ledgerName_0, _stateName_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($measurement$045bend$058motion_presence$(_world_0)));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058canonical$(_systems_0, _nodes_0) {
  if (_nodes_0.$ === "Nil") {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Accepted", "nodes": {$: "Nil"}};
  } else {
    const _t_0 = _nodes_0["head"];
    if (_t_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Call") {
      const _t_1 = _t_0["system"];
      const _base_0 = _t_1["base"];
      const _mode_0 = _t_0["mode"];
      const _tail_0 = _nodes_0["tail"];
      return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058canonical_call$(_base_0, _mode_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058system_find$(_base_0, _systems_0)), ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058canonical$(_systems_0, _tail_0)));
    } else if (_t_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Nested") {
      const _nested_0 = _t_0["steps"];
      const _tail_1 = _nodes_0["tail"];
      return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058canonical_nested$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058canonical$(_systems_0, _nested_0)), ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058canonical$(_systems_0, _tail_1)));
    } else {
      const _tail_2 = _nodes_0["tail"];
      return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058canonical_cons$(_t_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058canonical$(_systems_0, _tail_2)));
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058registry_return$(_next_0, _pair_0) {
  const _entries_0 = _pair_0["fst"];
  const _systems_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Registry", "next": _next_0, "entries": _entries_0}, "snd": _systems_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058registry_entries$(_entries_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _system_0 = _t_0["system"];
    const _local_0 = _t_0["local"];
    const _tail_0 = _entries_0["tail"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058registry_join$(_system_0, _local_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058registry_entries$(_tail_0)));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047raw$045boundaries$058motion_raw_bundle$(_owner_0) {
  const _main_0 = _owner_0["main"];
  const _aux_0 = _owner_0["aux"];
  const _flag_0 = _owner_0["flag"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Bundle", "main": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047raw$045boundaries$058motion_raw_main$(_main_0)), "aux": _aux_0, "flag": _flag_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058reserved$(_bundle_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.ReserveRejected", "world": _world_0, "payload": _bundle_0};
  } else {
    const _t_1 = _t_0["value"];
    const _namespace_0 = _t_1["namespace"];
    const _id_0 = _t_1["id"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Reserved", "world": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058publish$(_world_0, {$: "Con", "head": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Spawn", "id": _id_0, "bundle": _bundle_0}, "tail": {$: "Nil"}})), "handle": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_0}};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047identity$058reserve_id$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047identity$058reserve_checked$((_next_0 < 4294967295), _namespace_0, _next_0, _rows_0, _pending_0, _ledger_0, _mode_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047raw$045boundaries$058motion_main$(_raw_0) {
  if (_raw_0.$ === "None") {
    return {$: "None"};
  } else {
    const _raw_1 = _raw_0["value"];
    return {$: "Some", "value": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058position_new$(_raw_1))};
  }
}

function $measurement$045bend$058quad$(_a_0, _b_0, _c_0, _d_0) {
  const _x_0 = array_new(2, _a_0);
  const _x_1 = (_x_0[1 % _x_0.length] = _b_0, _x_0);
  const _x_2 = (_x_1[2 % _x_1.length] = _c_0, _x_1);
  return (_x_2[3 % _x_2.length] = _d_0, _x_2);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cache$058static_init$1262$(_raw_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cache$058static_init_done$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058motion_ledger_get$(_raw_0)));
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_chunks$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      if (_values_0.$ === "Nil") {
        return $String$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_push$(_head_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_list_tail$1265$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_list_piece$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_row$1260$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_list_tail$1266$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      const _first_0 = $2;
      if (_values_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _head_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_list_piece$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_pending$1260$(_head_0)), _acc_0, _first_0));
        $2 = false;
        continue;
      }
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_ledger$(_value_0) {
  const _totals_0 = _value_0["totals"];
  const _epoch_0 = _value_0["epoch"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"totals\":", "tail": {$: "Con", "head": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_four$(_totals_0)), "tail": {$: "Con", "head": ",\"epoch\":", "tail": {$: "Con", "head": ($U32$show$(_epoch_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058world_ledger$(_namespace_0, _next_0, _rows_0, _rowViews_0, _pending_0, _pendingViews_0, _mode_0, _result_0) {
  const _ledger_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/observations.WorldView", "namespace": _namespace_0, "next": _next_0, "rows": _rowViews_0, "pending": ($List$reverse$(_pendingViews_0)), "ledger": _value_0, "mode": _mode_0}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058maybe_get$1264$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}};
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058maybe_present$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058motion_ledger_get$(_owner_1)));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058commands_head$(_head_0, _tail_0) {
  const _owner_0 = _head_0["fst"];
  const _value_0 = _head_0["snd"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058commands_tail$(_owner_0, _value_0, _tail_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058command$1260$(_owner_0) {
  if (_owner_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Spawn") {
    const _id_0 = _owner_0["id"];
    const _value_0 = _owner_0["bundle"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058command_spawn$(_id_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058bundle$1260$(_value_0)));
  } else if (_owner_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.InsertMain") {
    const _id_1 = _owner_0["id"];
    const _value_1 = _owner_0["main"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058command_main$(_id_1, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058position_get$(_value_1)));
  } else if (_owner_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.InsertFlag") {
    const _id_2 = _owner_0["id"];
    const _value_2 = _owner_0["flag"];
    return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.InsertFlag", "id": _id_2, "flag": _value_2}, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/observations.FlagView", "id": _id_2, "flag": _value_2}};
  } else if (_owner_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.RemoveMain") {
    const _id_3 = _owner_0["id"];
    return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.RemoveMain", "id": _id_3}, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/observations.RemoveMainView", "id": _id_3}};
  } else if (_owner_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.RemoveFlag") {
    const _id_4 = _owner_0["id"];
    return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.RemoveFlag", "id": _id_4}, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/observations.RemoveFlagView", "id": _id_4}};
  } else {
    const _id_5 = _owner_0["id"];
    return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Despawn", "id": _id_5}, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/observations.DespawnView", "id": _id_5}};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058rows_go$1260$($0, $1, $2) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _id_0 = $1;
      const _state_0 = $2;
      if (_remaining_0 === 0) {
        return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058rows_finish$(_state_0);
      } else {
        const _remaining_1 = (_remaining_0 - 1);
        $0 = _remaining_1;
        $1 = ((_id_0 + 1) >>> 0);
        $2 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058rows_advance$1260$(_id_0, _state_0));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058tick_presence$1262$(_nodes_0, _ledgerName_0, _stateName_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _owners_0) {
  const _world_0 = _owners_0["fst"];
  const _t_0 = _owners_0["snd"];
  const _ledger_0 = _t_0["ledger"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058tick_audit$1262$(_nodes_0, _ledger_0, _ledgerName_0, _stateName_0, _world_0, _registry_0, _readers_0, _clock_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058audit_present$(_audit_0)));
}

function $measurement$045bend$058motion_presence$(_owner_0) {
  const _host_0 = _owner_0["host"];
  const _sparse_0 = _owner_0["sparse"];
  const _total_0 = _owner_0["readsum"];
  const _calls_0 = _owner_0["calls"];
  return $measurement$045bend$058motion_presence_return$(_sparse_0, _total_0, _calls_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$058motion_presence$(_host_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058canonical_call$(_base_0, _mode_0, _found_0, _tail_0) {
  if (_found_0.$ === "None") {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Unknown", "base": _base_0};
  } else {
    const _system_0 = _found_0["value"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058canonical_cons$({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Call", "system": _system_0, "mode": _mode_0}, _tail_0);
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058system_find$(_base_0, _systems_0) {
  if (_systems_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _systems_0["head"];
    const _key_0 = _t_0["base"];
    const _name_0 = _t_0["name"];
    const _kind_0 = _t_0["kind"];
    const _ledger_0 = _t_0["ledger"];
    const _audit_0 = _t_0["audit"];
    const _gated_0 = _t_0["gated"];
    const _reader_0 = _t_0["reader"];
    const _tail_0 = _systems_0["tail"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058system_hit$((_base_0 === _key_0), {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.System", "base": _key_0, "name": _name_0, "kind": _kind_0, "ledger": _ledger_0, "audit": _audit_0, "gated": _gated_0, "reader": _reader_0}, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058system_find$(_base_0, _tail_0)));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058canonical_nested$(_nested_0, _tail_0) {
  if (_nested_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Accepted") {
    const _nodes_0 = _nested_0["nodes"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058canonical_cons$({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Nested", "steps": _nodes_0}, _tail_0);
  } else {
    return _nested_0;
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058canonical_cons$(_node_0, _tail_0) {
  if (_tail_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Accepted") {
    const _nodes_0 = _tail_0["nodes"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Accepted", "nodes": {$: "Con", "head": _node_0, "tail": _nodes_0}};
  } else {
    return _tail_0;
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058registry_join$(_system_0, _local_0, _tail_0) {
  const _entries_0 = _tail_0["fst"];
  const _systems_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Entry", "system": _system_0, "local": _local_0}, "tail": _entries_0}, "snd": {$: "Con", "head": _system_0, "tail": _systems_0}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047raw$045boundaries$058motion_raw_main$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "None"};
  } else {
    const _t_0 = _owner_0["value"];
    const _raw_0 = _t_0["raw"];
    return {$: "Some", "value": _raw_0};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058publish$(_world_0, _staged_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": ($List$reverse$go$(($List$reverse$(_staged_0)), _pending_0)), "ledger": _ledger_0, "mode": _mode_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047identity$058reserve_checked$(_available_0, _namespace_0, _next_0, _rows_0, _pending_0, _ledger_0, _mode_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "None"}};
  } else {
    return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": ((_next_0 + 1) >>> 0), "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "Some", "value": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _next_0}}};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058position_new$(_raw_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cache$058static_init$1260$(_raw_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cache$058static_init_done$(_result_0) {
  const _raw_0 = _result_0["fst"];
  const _cached_0 = _result_0["snd"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/cache.Cache", "raw": _raw_0, "cached": _cached_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058motion_ledger_get$(_owner_0) {
  const _array_0 = _owner_0["totals"];
  const _epoch_0 = _owner_0["epoch"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058motion_ledger_observed$(_epoch_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058four$(_array_0)));
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $String$reverse$(_s_0) {
  return $String$reverse$go$(_s_0, "");
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_push$($0, $1) {
  for (;;) {
    {
      const _value_0 = $0;
      const _acc_0 = $1;
      if (_value_0 === "") {
        return _acc_0;
      } else {
        const _head_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(0, 2) : _value_0[0]);
        const _tail_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(2) : _value_0.slice(1));
        $0 = _tail_0;
        $1 = (_head_0 + _acc_0);
        continue;
      }
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_list_piece$(_value_0, _acc_0, _first_0) {
  if (_first_0) {
    return {$: "Con", "head": _value_0, "tail": _acc_0};
  } else {
    return {$: "Con", "head": _value_0, "tail": {$: "Con", "head": ",", "tail": _acc_0}};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_row$1260$(_value_0) {
  const _id_0 = _value_0["id"];
  const _main_0 = _value_0["main"];
  const _aux_0 = _value_0["aux"];
  const _flag_0 = _value_0["flag"];
  const _added_0 = _value_0["added"];
  const _changed_0 = _value_0["changed"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"id\":", "tail": {$: "Con", "head": ($U32$show$(_id_0)), "tail": {$: "Con", "head": ",\"main\":", "tail": {$: "Con", "head": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_optional$1263$(_main_0)), "tail": {$: "Con", "head": ",\"aux\":", "tail": {$: "Con", "head": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_optional$1261$(_aux_0)), "tail": {$: "Con", "head": ",\"flag\":", "tail": {$: "Con", "head": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_optional$1262$(_flag_0)), "tail": {$: "Con", "head": ",\"added\":", "tail": {$: "Con", "head": ($U32$show$(_added_0)), "tail": {$: "Con", "head": ",\"changed\":", "tail": {$: "Con", "head": ($U32$show$(_changed_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}}}}}}}});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_pending$1260$(_value_0) {
  if (_value_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/observations.SpawnView") {
    const _id_0 = _value_0["id"];
    const _bundle_0 = _value_0["bundle"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"SpawnView\"", "tail": {$: "Con", "head": ",\"id\":", "tail": {$: "Con", "head": ($U32$show$(_id_0)), "tail": {$: "Con", "head": ",\"bundle\":", "tail": {$: "Con", "head": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_bundle$1260$(_bundle_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}});
  } else if (_value_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/observations.MainView") {
    const _id_1 = _value_0["id"];
    const _main_0 = _value_0["main"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"MainView\"", "tail": {$: "Con", "head": ",\"id\":", "tail": {$: "Con", "head": ($U32$show$(_id_1)), "tail": {$: "Con", "head": ",\"main\":", "tail": {$: "Con", "head": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_position$(_main_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}});
  } else if (_value_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/observations.FlagView") {
    const _id_2 = _value_0["id"];
    const _flag_0 = _value_0["flag"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"FlagView\"", "tail": {$: "Con", "head": ",\"id\":", "tail": {$: "Con", "head": ($U32$show$(_id_2)), "tail": {$: "Con", "head": ",\"flag\":", "tail": {$: "Con", "head": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_selected$(_flag_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}});
  } else if (_value_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/observations.RemoveMainView") {
    const _id_3 = _value_0["id"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"RemoveMainView\"", "tail": {$: "Con", "head": ",\"id\":", "tail": {$: "Con", "head": ($U32$show$(_id_3)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
  } else if (_value_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/observations.RemoveFlagView") {
    const _id_4 = _value_0["id"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"RemoveFlagView\"", "tail": {$: "Con", "head": ",\"id\":", "tail": {$: "Con", "head": ($U32$show$(_id_4)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
  } else {
    const _id_5 = _value_0["id"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"kind\":", "tail": {$: "Con", "head": "\"DespawnView\"", "tail": {$: "Con", "head": ",\"id\":", "tail": {$: "Con", "head": ($U32$show$(_id_5)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_four$(_value_0) {
  const _a_0 = _value_0["a"];
  const _b_0 = _value_0["b"];
  const _c_0 = _value_0["c"];
  const _d_0 = _value_0["d"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"a\":", "tail": {$: "Con", "head": ($U32$show$(_a_0)), "tail": {$: "Con", "head": ",\"b\":", "tail": {$: "Con", "head": ($U32$show$(_b_0)), "tail": {$: "Con", "head": ",\"c\":", "tail": {$: "Con", "head": ($U32$show$(_c_0)), "tail": {$: "Con", "head": ",\"d\":", "tail": {$: "Con", "head": ($U32$show$(_d_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}}}});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058maybe_present$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": _owner_0}, "snd": {$: "Some", "value": _value_0}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058motion_ledger_get$(_owner_0) {
  const _raw_0 = _owner_0["raw"];
  const _cached_0 = _owner_0["cached"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/cache.Cache", "raw": _raw_0, "cached": _cached_0}, "snd": _cached_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058commands_tail$(_owner_0, _value_0, _result_0) {
  const _tail_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _owner_0, "tail": _tail_0}, "snd": {$: "Con", "head": _value_0, "tail": _values_0}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058command_spawn$(_id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Spawn", "id": _id_0, "bundle": _owner_0}, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/observations.SpawnView", "id": _id_0, "bundle": _value_0}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058bundle$1260$(_owner_0) {
  const _main_0 = _owner_0["main"];
  const _aux_0 = _owner_0["aux"];
  const _flag_0 = _owner_0["flag"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058bundle_main$1260$(_aux_0, _flag_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058maybe_get$1261$(_main_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058command_main$(_id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.InsertMain", "id": _id_0, "main": _owner_0}, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/observations.MainView", "id": _id_0, "main": _value_0}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058position_get$(_owner_0) {
  const _raw_0 = _owner_0["raw"];
  const _cached_0 = _owner_0["cached"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/cache.Cache", "raw": _raw_0, "cached": _cached_0}, "snd": _cached_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058rows_finish$(_state_0) {
  const _owners_0 = _state_0["fst"];
  const _values_0 = _state_0["snd"];
  return {$: "Tuple", "fst": _owners_0, "snd": ($List$reverse$(_values_0))};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058rows_advance$1260$(_id_0, _state_0) {
  const _owners_0 = _state_0["fst"];
  const _values_0 = _state_0["snd"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058rows_slot$1260$(_values_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058rows_extract$(_owners_0, _id_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058tick_audit$1262$(_nodes_0, _ledger_0, _ledgerName_0, _stateName_0, _world_0, _registry_0, _readers_0, _clock_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _service_0) {
  const _audit_0 = _service_0["fst"];
  const _available_0 = _service_0["snd"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058tick_missing$1262$(_nodes_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058preflight$(_nodes_0, _ledger_0, _available_0, true, _ledgerName_0, _stateName_0)), {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058audit_present$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _audit_0 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _audit_0}, "snd": true};
  }
}

function $measurement$045bend$058motion_presence_return$(_sparse_0, _total_0, _calls_0, _pair_0) {
  const _host_0 = _pair_0["fst"];
  const _view_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "measurement-bend.MotionBench", "host": _host_0, "sparse": _sparse_0, "readsum": _total_0, "calls": _calls_0}, "snd": _view_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$058motion_presence$(_owner_0) {
  const _t_0 = _owner_0["world"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["next"];
  const _rows_0 = _t_0["rows"];
  const _pending_0 = _t_0["pending"];
  const _ledger_0 = _t_0["ledger"];
  const _mode_0 = _t_0["mode"];
  const _logs_0 = _owner_0["logs"];
  const _bindings_0 = _owner_0["bindings"];
  const _worldName_0 = _owner_0["worldName"];
  const _step_0 = _owner_0["step"];
  const _prior_0 = _owner_0["prior"];
  const _events_0 = _owner_0["events"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$058motion_presence_ledger$(_ns_0, _next_0, _rows_0, _pending_0, _mode_0, _logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$058ledger_presence$(_ledger_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058system_hit$(_equal_0, _system_0, _tail_0) {
  if (_equal_0) {
    return {$: "Some", "value": _system_0};
  } else {
    return _tail_0;
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cache$058static_init$1260$(_raw_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cache$058static_init_done$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058position_get$(_raw_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058motion_ledger_observed$(_epoch_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.MotionLedger", "totals": _array_0, "epoch": _epoch_0}, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.LedgerView", "totals": _values_0, "epoch": _epoch_0}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058four$(_array_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058original_four$(_array_0);
}

function $String$reverse$go$($0, $1) {
  for (;;) {
    {
      const _s_0 = $0;
      const _acc_0 = $1;
      if (_s_0 === "") {
        return _acc_0;
      } else {
        const _h_0 = (_s_0.codePointAt(0) > 0xFFFF ? _s_0.slice(0, 2) : _s_0[0]);
        const _t_0 = (_s_0.codePointAt(0) > 0xFFFF ? _s_0.slice(2) : _s_0.slice(1));
        $0 = _t_0;
        $1 = (_h_0 + _acc_0);
        continue;
      }
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_optional$1263$(_value_0) {
  if (_value_0.$ === "None") {
    return "null";
  } else {
    const _value_1 = _value_0["value"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_position$(_value_1);
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_optional$1261$(_value_0) {
  if (_value_0.$ === "None") {
    return "null";
  } else {
    const _value_1 = _value_0["value"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_velocity$(_value_1);
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_optional$1262$(_value_0) {
  if (_value_0.$ === "None") {
    return "null";
  } else {
    const _value_1 = _value_0["value"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_selected$(_value_1);
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_bundle$1260$(_value_0) {
  const _main_0 = _value_0["main"];
  const _aux_0 = _value_0["aux"];
  const _flag_0 = _value_0["flag"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"main\":", "tail": {$: "Con", "head": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_optional$1263$(_main_0)), "tail": {$: "Con", "head": ",\"aux\":", "tail": {$: "Con", "head": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_optional$1261$(_aux_0)), "tail": {$: "Con", "head": ",\"flag\":", "tail": {$: "Con", "head": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_optional$1262$(_flag_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}}}});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_position$(_value_0) {
  const _coordinates_0 = _value_0["coordinates"];
  const _frame_0 = _value_0["frame"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"coordinates\":", "tail": {$: "Con", "head": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_four$(_coordinates_0)), "tail": {$: "Con", "head": ",\"frame\":", "tail": {$: "Con", "head": ($U32$show$(_frame_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_selected$(_value_0) {
  const _group_0 = _value_0["group"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"group\":", "tail": {$: "Con", "head": ($U32$show$(_group_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058bundle_main$1260$(_aux_0, _flag_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058bundle_aux$(_main_0, _value_0, _flag_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058maybe_get$1260$(_aux_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058maybe_get$1261$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}};
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058maybe_present$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058position_get$(_owner_1)));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058rows_slot$1260$(_values_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": _owners_0, "snd": _values_0};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058rows_observed$(_owners_0, _values_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058row$1260$(_owner_0)));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058rows_extract$(_rows_0, _id_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _metadata_0 = _rows_0["metadata"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058extract_checked$(($Bool$and$((0 < _id_0), ($Bool$and$((_id_0 <= _capacity_0), (_id_0 <= _high_0))))), _id_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058tick_missing$1262$(_nodes_0, _missing_0, _runtime_0) {
  if (_missing_0.$ === "Nil") {
    const _world_0 = _runtime_0["world"];
    const _registry_0 = _runtime_0["registry"];
    const _readers_0 = _runtime_0["readers"];
    const _clock_0 = _runtime_0["clock"];
    const _audit_0 = _runtime_0["audit"];
    const _style_0 = _runtime_0["style"];
    const _escaped_0 = _runtime_0["escaped"];
    const _observations_0 = _runtime_0["observations"];
    const _nextMode_0 = _runtime_0["nextMode"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058tick_frame$1262$(_nodes_0, _registry_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($measurement$045bend$058motion_frame$(_world_0, _readers_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058frame$(_clock_0)))));
  } else {
    return run_clo((_x_0) => {
  return $IO$pure$({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Dispatched", "runtime": _runtime_0, "outcome": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.MissingRuntimeRequirements", "requirements": _missing_0}}, _x_0);
});
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058preflight$($0, $1, $2, $3, $4, $5) {
  for (;;) {
    {
      const _nodes_0 = $0;
      const _ledger_0 = $1;
      const _audit_0 = $2;
      const _state_0 = $3;
      const _ledgerName_0 = $4;
      const _stateName_0 = $5;
      if (_nodes_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _t_0 = _nodes_0["head"];
        if (_t_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Call") {
          const _system_0 = _t_0["system"];
          const _tail_0 = _nodes_0["tail"];
          return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058union$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058requirements$(_system_0, _ledger_0, _audit_0, _state_0, _ledgerName_0, _stateName_0)), ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058preflight$(_tail_0, _ledger_0, _audit_0, _state_0, _ledgerName_0, _stateName_0)));
        } else if (_t_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Nested") {
          const _nested_0 = _t_0["steps"];
          const _tail_1 = _nodes_0["tail"];
          return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058union$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058preflight$(_nested_0, _ledger_0, _audit_0, _state_0, _ledgerName_0, _stateName_0)), ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058preflight$(_tail_1, _ledger_0, _audit_0, _state_0, _ledgerName_0, _stateName_0)));
        } else if (_t_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Deferred") {
          const _tail_2 = _nodes_0["tail"];
          $0 = _tail_2;
          $1 = _ledger_0;
          $2 = _audit_0;
          $3 = _state_0;
          $4 = _ledgerName_0;
          $5 = _stateName_0;
          continue;
        } else {
          const _tail_3 = _nodes_0["tail"];
          $0 = _tail_3;
          $1 = _ledger_0;
          $2 = _audit_0;
          $3 = _state_0;
          $4 = _ledgerName_0;
          $5 = _stateName_0;
          continue;
        }
      }
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$058motion_presence_ledger$(_ns_0, _next_0, _rows_0, _pending_0, _mode_0, _logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _pair_0) {
  const _ledger_0 = _pair_0["fst"];
  const _available_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/host.Host", "world": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Presence", "ledger": _available_0, "modeOn": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$058motion_on$(_mode_0))}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$058ledger_presence$(_ledger_0) {
  if (_ledger_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_0 = _ledger_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_0}, "snd": true};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058position_get$(_owner_0) {
  const _array_0 = _owner_0["coordinates"];
  const _frame_0 = _owner_0["frame"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058position_observed$(_frame_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058four$(_array_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058original_four$(_array_0) {
  return __direct_tuple_helper_0((_array_0), (_array_0[0 % _array_0.length]));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_velocity$(_value_0) {
  const _rates_0 = _value_0["rates"];
  const _moving_0 = _value_0["moving"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_concat$({$: "Con", "head": "{\"rates\":", "tail": {$: "Con", "head": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_four$(_rates_0)), "tail": {$: "Con", "head": ",\"moving\":", "tail": {$: "Con", "head": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_boolean$(_moving_0)), "tail": {$: "Con", "head": "}", "tail": {$: "Nil"}}}}}});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058bundle_aux$(_main_0, _value_0, _flag_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _auxView_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Bundle", "main": _main_0, "aux": _aux_0, "flag": _flag_0}, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/observations.BundleView", "main": _value_0, "aux": _auxView_0, "flag": _flag_0}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058maybe_get$1260$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}};
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058maybe_present$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047payload$058velocity_get$(_owner_1)));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058rows_observed$(_owners_0, _values_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058rows_restore$(_owners_0, _owner_0)), "snd": {$: "Con", "head": _value_0, "tail": _values_0}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058row$1260$(_owner_0) {
  const _id_0 = _owner_0["id"];
  const _main_0 = _owner_0["main"];
  const _aux_0 = _owner_0["aux"];
  const _flag_0 = _owner_0["flag"];
  const _added_0 = _owner_0["added"];
  const _changed_0 = _owner_0["changed"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058row_main$1260$(_id_0, _aux_0, _flag_0, _added_0, _changed_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058maybe_get$1261$(_main_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058extract_checked$(_valid_0, _id_0, _rows_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _rows_0, "snd": {$: "None"}};
  } else {
    const _main_0 = _rows_0["main"];
    const _aux_0 = _rows_0["aux"];
    const _metadata_0 = _rows_0["metadata"];
    const _capacity_0 = _rows_0["capacity"];
    const _depth_0 = _rows_0["depth"];
    const _high_0 = _rows_0["high_water"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058extract_meta$(_id_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058metadata_get$(_metadata_0, ((_id_0 - 1) >>> 0))));
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058tick_frame$1262$(_nodes_0, _registry_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _owners_0) {
  const _world_0 = _owners_0["fst"];
  const _t_0 = _owners_0["snd"];
  const _readers_0 = _t_0["fst"];
  const _clock_0 = _t_0["snd"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058run$1262$(_nodes_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0});
}

function $measurement$045bend$058motion_frame$(_owner_0, _readers_0, _boundary_0) {
  const _host_0 = _owner_0["host"];
  const _sparse_0 = _owner_0["sparse"];
  const _total_0 = _owner_0["readsum"];
  const _calls_0 = _owner_0["calls"];
  return $measurement$045bend$058motion_frame_return$(_sparse_0, _total_0, _calls_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$058frame$(_host_0, _readers_0, _boundary_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058frame$(_clock_0) {
  const _now_0 = _clock_0["tick"];
  const _start_0 = _clock_0["frameStart"];
  const _retained_0 = _clock_0["retainedAfter"];
  const _number_0 = _clock_0["frameNo"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058frame_case$((_start_0 > 0), _now_0, _start_0, _retained_0, _number_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058union$(_values_0, _other_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058union_acc$(_other_0, _values_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058requirements$(_system_0, _ledger_0, _audit_0, _state_0, _ledgerName_0, _stateName_0) {
  const _needLedger_0 = _system_0["ledger"];
  const _needAudit_0 = _system_0["audit"];
  const _gated_0 = _system_0["gated"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058union$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058union$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058missing_case$(_needLedger_0, _ledger_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.ResourceRequired", "name": _ledgerName_0})), ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058missing_case$(_needAudit_0, _audit_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.ServiceRequired", "name": "Audit"})))), ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058missing_case$(_gated_0, _state_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.StateRequired", "name": _stateName_0})));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$058motion_on$(_mode_0) {
  if (_mode_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.MotionOn") {
    return true;
  } else {
    return false;
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058position_observed$(_frame_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Position", "coordinates": _array_0, "frame": _frame_0}, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.PositionView", "coordinates": _values_0, "frame": _frame_0}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058four_a$(_result_0) {
  const _array_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return __direct_tuple_helper_1(_a_0, (_array_0), (_array_0[1 % _array_0.length]));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$045render$058render_boolean$(_value_0) {
  if (_value_0) {
    return "true";
  } else {
    return "false";
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047payload$058velocity_get$(_owner_0) {
  const _array_0 = _owner_0["rates"];
  const _moving_0 = _owner_0["moving"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047payload$058velocity_observed$(_moving_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047payload$058four$(_array_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058rows_restore$(_rows_0, _row_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _metadata_0 = _rows_0["metadata"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  const _id_0 = _row_0["id"];
  const _m_0 = _row_0["main"];
  const _a_0 = _row_0["aux"];
  const _f_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = ((_id_0 - 1) >>> 0);
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": (_main_0[_x_0 % _main_0.length] = _m_0, _main_0), "aux": (_aux_0[_x_1 % _aux_0.length] = _a_0, _aux_0), "metadata": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Metadata", "live": true, "flag": _f_0, "added": _added_0, "changed": _changed_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058row_main$1260$(_id_0, _aux_0, _flag_0, _added_0, _changed_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058row_aux$(_id_0, _main_0, _value_0, _flag_0, _added_0, _changed_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058maybe_get$1260$(_aux_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058extract_meta$(_id_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _t_1 = _t_0["live"];
  if (!_t_1) {
    return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "None"}};
  } else {
    const _flag_1 = _t_0["flag"];
    const _added_1 = _t_0["added"];
    const _changed_1 = _t_0["changed"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058extract_main$(_id_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Metadata", "live": true, "flag": _flag_1, "added": _added_1, "changed": _changed_1}, array_rmw(_main_0, _x_0, () => _x_1));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058metadata_get$(_columns_0, _index_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  return __direct_tuple_helper_2(_flags_0, _added_0, _changed_0, _index_0, (_live_0), (_live_0[_index_0 % _live_0.length]));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058run$1262$(_nodes_0, _runtime_0) {
  if (_nodes_0.$ === "Nil") {
    return run_clo((_x_0) => {
  return $IO$pure$({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Dispatched", "runtime": _runtime_0, "outcome": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Complete"}}, _x_0);
});
  } else {
    const _t_0 = _nodes_0["head"];
    if (_t_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Nested") {
      const _nested_0 = _t_0["steps"];
      const _tail_0 = _nodes_0["tail"];
      return run_clo((_x_1) => {
  return $IO$bind$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058run$1262$(_nested_0, _runtime_0)), run_clo((_x_2) => {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058continue_case$(run_clo((_x_3) => {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058run$1262$(_tail_0, _x_3);
}), _x_2);
}), _x_1);
});
    } else if (_t_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Call") {
      const _system_0 = _t_0["system"];
      const _mode_0 = _t_0["mode"];
      const _tail_1 = _nodes_0["tail"];
      return run_clo((_x_4) => {
  return $IO$bind$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058call$1262$(_system_0, _mode_0, _runtime_0)), run_clo((_x_5) => {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058continue_case$(run_clo((_x_6) => {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058run$1262$(_tail_1, _x_6);
}), _x_5);
}), _x_4);
});
    } else if (_t_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Deferred") {
      const _tail_2 = _nodes_0["tail"];
      return run_clo((_x_7) => {
  return $IO$bind$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058deferred$1262$(_runtime_0)), run_clo((_x_8) => {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058run$1262$(_tail_2, _x_8);
}), _x_7);
});
    } else {
      const _tail_3 = _nodes_0["tail"];
      return run_clo((_x_9) => {
  return $IO$bind$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058state_transition$1262$(_runtime_0)), run_clo((_x_10) => {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058run$1262$(_tail_3, _x_10);
}), _x_9);
});
    }
  }
}

function $measurement$045bend$058motion_frame_return$(_sparse_0, _total_0, _calls_0, _pair_0) {
  const _host_0 = _pair_0["fst"];
  const _rest_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "measurement-bend.MotionBench", "host": _host_0, "sparse": _sparse_0, "readsum": _total_0, "calls": _calls_0}, "snd": _rest_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$058frame$(_owner_0, _readers_0, _boundary_0) {
  const _world_0 = _owner_0["world"];
  const _logs_0 = _owner_0["logs"];
  const _bindings_0 = _owner_0["bindings"];
  const _worldName_0 = _owner_0["worldName"];
  const _step_0 = _owner_0["step"];
  const _prior_0 = _owner_0["prior"];
  const _events_0 = _owner_0["events"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$058frame_return$(_world_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047reader$045host$058frame$(_logs_0, _readers_0, _boundary_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058frame_case$(_old_0, _now_0, _start_0, _retained_0, _number_0) {
  if (_old_0) {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Frame", "clock": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Clock", "tick": _now_0, "frameStart": _now_0, "retainedAfter": _start_0, "frameNo": ((_number_0 + 1) >>> 0)}, "lifecycle": {$: "Some", "value": _start_0}, "messages": _start_0};
  } else {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Frame", "clock": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Clock", "tick": _now_0, "frameStart": _now_0, "retainedAfter": _retained_0, "frameNo": ((_number_0 + 1) >>> 0)}, "lifecycle": {$: "None"}, "messages": _retained_0};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058union_acc$($0, $1) {
  for (;;) {
    {
      const _other_0 = $0;
      const _values_0 = $1;
      if (_other_0.$ === "Nil") {
        return _values_0;
      } else {
        const _head_0 = _other_0["head"];
        const _tail_0 = _other_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058unique_case$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058contains$(_head_0, _values_0)), _head_0, _values_0));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058missing_case$(_wanted_0, _present_0, _value_0) {
  if (_wanted_0) {
    if (!_present_0) {
      return {$: "Con", "head": _value_0, "tail": {$: "Nil"}};
    } else {
      return {$: "Nil"};
    }
  } else {
    return {$: "Nil"};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058four_b$(_a_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _b_0 = _result_0["snd"];
  return __direct_tuple_helper_3(_a_0, _b_0, (_array_0), (_array_0[2 % _array_0.length]));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047payload$058velocity_observed$(_moving_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Velocity", "rates": _array_0, "moving": _moving_0}, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.VelocityView", "rates": _values_0, "moving": _moving_0}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047payload$058four$(_array_0) {
  return __direct_tuple_helper_4((_array_0), (_array_0[0 % _array_0.length]));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058metadata_set$(_columns_0, _index_0, _meta_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  const _l_0 = _meta_0["live"];
  const _f_0 = _meta_0["flag"];
  const _a_0 = _meta_0["added"];
  const _c_0 = _meta_0["changed"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.MetadataColumns", "live": (_live_0[_index_0 % _live_0.length] = _l_0, _live_0), "flags": (_flags_0[_index_0 % _flags_0.length] = _f_0, _flags_0), "added": (_added_0[_index_0 % _added_0.length] = _a_0, _added_0), "changed": (_changed_0[_index_0 % _changed_0.length] = _c_0, _changed_0)};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058row_aux$(_id_0, _main_0, _mainView_0, _flag_0, _added_0, _changed_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _auxView_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/observations.RowView", "id": _id_0, "main": _mainView_0, "aux": _auxView_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058extract_main$(_id_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _mv_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "None"};
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058extract_aux$(_id_0, _main_0, _mv_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, array_rmw(_aux_0, _x_0, () => _x_1));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058metadata_get_live$(_flags_0, _added_0, _changed_0, _index_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _l_0 = _result_0["snd"];
  return __direct_tuple_helper_5(_live_0, _added_0, _changed_0, _index_0, _l_0, (_flags_0), (_flags_0[_index_0 % _flags_0.length]));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058continue_case$(_continuation_0, _result_0) {
  const _runtime_0 = _result_0["runtime"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Complete") {
    return run_tail(_continuation_0, _runtime_0);
  } else {
    return run_clo((_x_0) => {
  return $IO$pure$({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Dispatched", "runtime": _runtime_0, "outcome": _t_0}, _x_0);
});
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058call$1262$(_system_0, _mode_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _registry_0 = _runtime_0["registry"];
  const _readers_0 = _runtime_0["readers"];
  const _clock_0 = _runtime_0["clock"];
  const _audit_0 = _runtime_0["audit"];
  const _style_0 = _runtime_0["style"];
  const _escaped_0 = _runtime_0["escaped"];
  const _observations_0 = _runtime_0["observations"];
  const _nextMode_0 = _runtime_0["nextMode"];
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058call_presence$1262$(_system_0, _mode_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($measurement$045bend$058motion_presence$(_world_0)))), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$pure$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058record_mode$(_system_0, _x_1)), _x_2);
});
}), _x_0);
});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058deferred$1262$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _registry_0 = _runtime_0["registry"];
  const _readers_0 = _runtime_0["readers"];
  const _clock_0 = _runtime_0["clock"];
  const _audit_0 = _runtime_0["audit"];
  const _style_0 = _runtime_0["style"];
  const _escaped_0 = _runtime_0["escaped"];
  const _observations_0 = _runtime_0["observations"];
  const _nextMode_0 = _runtime_0["nextMode"];
  return run_clo((_x_0) => {
  return $IO$bind$(($measurement$045bend$058motion_barrier$(_world_0, _clock_0)), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$pure$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058marker_done$(_registry_0, _readers_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _x_1)), _x_2);
});
}), _x_0);
});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058state_transition$1262$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _registry_0 = _runtime_0["registry"];
  const _readers_0 = _runtime_0["readers"];
  const _clock_0 = _runtime_0["clock"];
  const _audit_0 = _runtime_0["audit"];
  const _style_0 = _runtime_0["style"];
  const _escaped_0 = _runtime_0["escaped"];
  const _observations_0 = _runtime_0["observations"];
  const _nextMode_0 = _runtime_0["nextMode"];
  return run_clo((_x_0) => {
  return $IO$bind$(($measurement$045bend$058motion_barrier$(_world_0, _clock_0)), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$pure$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058marker_done$(_registry_0, _readers_0, _audit_0, _style_0, _escaped_0, _observations_0, {$: "None"}, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058transition_after$1262$(_nextMode_0, _x_1)))), _x_2);
});
}), _x_0);
});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$058frame_return$(_world_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _result_0) {
  const _logs_0 = _result_0["logs"];
  const _readers_0 = _result_0["readers"];
  const _clock_0 = _result_0["clock"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, "snd": {$: "Tuple", "fst": _readers_0, "snd": _clock_0}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047reader$045host$058frame$(_logs_0, _readers_0, _frame_0) {
  const _ping_0 = _logs_0["ping"];
  const _removed_0 = _logs_0["removed"];
  const _despawned_0 = _logs_0["despawned"];
  const _clock_0 = _frame_0["clock"];
  const _window_0 = _frame_0["lifecycle"];
  const _messageWindow_0 = _frame_0["messages"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047reader$045host$058frame_ping$(_ping_0, _removed_0, _despawned_0, _clock_0, _window_0, _messageWindow_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058holders$(_readers_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Messages"})));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058unique_case$(_found_0, _value_0, _values_0) {
  if (_found_0) {
    return _values_0;
  } else {
    return $List$append$(_values_0, {$: "Con", "head": _value_0, "tail": {$: "Nil"}});
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058contains$(_value_0, _values_0) {
  if (_values_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _values_0["head"];
    const _tail_0 = _values_0["tail"];
    const _x_0 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058requirement_equal$(_value_0, _head_0));
    const _x_1 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058contains$(_value_0, _tail_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058four_c$(_a_0, _b_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _c_0 = _result_0["snd"];
  return __direct_tuple_helper_6(_a_0, _b_0, _c_0, (_array_0), (_array_0[3 % _array_0.length]));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047payload$058four_a$(_result_0) {
  const _array_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return __direct_tuple_helper_7(_a_0, (_array_0), (_array_0[1 % _array_0.length]));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058extract_aux$(_id_0, _main_0, _value_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _av_0 = _result_0["snd"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058extract_row$(_id_0, _main_0, _value_0, _aux_0, _av_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058metadata_get_flags$(_live_0, _added_0, _changed_0, _index_0, _l_0, _result_0) {
  const _flags_0 = _result_0["fst"];
  const _f_0 = _result_0["snd"];
  return __direct_tuple_helper_8(_live_0, _flags_0, _changed_0, _index_0, _l_0, _f_0, (_added_0), (_added_0[_index_0 % _added_0.length]));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058call_presence$1262$(_system_0, _mode_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _actual_0 = _pair_0["snd"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058call_actual$1262$(_system_0, _mode_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _world_0, _actual_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058record_mode$(_system_0, _result_0) {
  const _kind_0 = _system_0["kind"];
  const _t_0 = _result_0["runtime"];
  const _world_0 = _t_0["world"];
  const _registry_0 = _t_0["registry"];
  const _readers_0 = _t_0["readers"];
  const _clock_0 = _t_0["clock"];
  const _audit_0 = _t_0["audit"];
  const _style_0 = _t_0["style"];
  const _escaped_0 = _t_0["escaped"];
  const _observations_0 = _t_0["observations"];
  const _nextMode_0 = _t_0["nextMode"];
  const _t_1 = _result_0["outcome"];
  if (_t_1.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Complete") {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Dispatched", "runtime": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058pending_kind$(_kind_0, _nextMode_0))}, "outcome": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Complete"}};
  } else {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Dispatched", "runtime": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0}, "outcome": _t_1};
  }
}

function $measurement$045bend$058motion_barrier$(_owner_0, _clock_0) {
  const _host_0 = _owner_0["host"];
  const _sparse_0 = _owner_0["sparse"];
  const _total_0 = _owner_0["readsum"];
  const _calls_0 = _owner_0["calls"];
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$058barrier$(_host_0, _clock_0)), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$pure$(($measurement$045bend$058motion_clock_return$(_sparse_0, _total_0, _calls_0, _x_1)), _x_2);
});
}), _x_0);
});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058marker_done$(_registry_0, _readers_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _owners_0) {
  const _world_0 = _owners_0["fst"];
  const _clock_0 = _owners_0["snd"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058transition_after$1262$(_nextMode_0, _owners_0) {
  const _world_0 = _owners_0["fst"];
  const _clock_0 = _owners_0["snd"];
  return $measurement$045bend$058motion_transition$(_world_0, _nextMode_0, _clock_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047reader$045host$058frame_ping$(_ping_0, _removed_0, _despawned_0, _clock_0, _window_0, _messageWindow_0, _result_0) {
  const _readers_0 = _result_0["fst"];
  const _holds_0 = _result_0["snd"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047reader$045host$058frame_removed$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058trim$(_ping_0, _messageWindow_0, _holds_0)), _removed_0, _despawned_0, _clock_0, _window_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058holders$(_readers_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Removed", "component": 0})));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058holders$(_readers_0, _kind_0) {
  const _slots_0 = _readers_0["slots"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Readers", "slots": _slots_0}, "snd": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058collect$(_kind_0, _slots_0))};
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058requirement_equal$(_left_0, _right_0) {
  if (_left_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.ResourceRequired") {
    const _a_0 = _left_0["name"];
    if (_right_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.ResourceRequired") {
      const _b_0 = _right_0["name"];
      return $String$eq$(_a_0, _b_0);
    } else {
      return false;
    }
  } else if (_left_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.ServiceRequired") {
    const _a_1 = _left_0["name"];
    if (_right_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.ServiceRequired") {
      const _b_1 = _right_0["name"];
      return $String$eq$(_a_1, _b_1);
    } else {
      return false;
    }
  } else {
    const _a_2 = _left_0["name"];
    if (_right_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.StateRequired") {
      const _b_2 = _right_0["name"];
      return $String$eq$(_a_2, _b_2);
    } else {
      return false;
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058four_done$(_a_0, _b_0, _c_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _d_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _array_0, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Four", "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047payload$058four_b$(_a_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _b_0 = _result_0["snd"];
  return __direct_tuple_helper_9(_a_0, _b_0, (_array_0), (_array_0[2 % _array_0.length]));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058extract_row$(_id_0, _main_0, _value_0, _aux_0, _av_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0) {
  const _flag_0 = _meta_0["flag"];
  const _added_0 = _meta_0["added"];
  const _changed_0 = _meta_0["changed"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "Some", "value": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Row", "id": _id_0, "main": _value_0, "aux": _av_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058metadata_get_added$(_live_0, _flags_0, _changed_0, _index_0, _l_0, _f_0, _result_0) {
  const _added_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return __direct_tuple_helper_10(_live_0, _flags_0, _added_0, _l_0, _f_0, _a_0, (_changed_0), (_changed_0[_index_0 % _changed_0.length]));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058call_actual$1262$(_system_0, _mode_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _world_0, _actual_0) {
  const _base_0 = _system_0["base"];
  const _name_0 = _system_0["name"];
  const _kind_0 = _system_0["kind"];
  const _ledger_0 = _system_0["ledger"];
  const _service_0 = _system_0["audit"];
  const _gated_0 = _system_0["gated"];
  const _reader_0 = _system_0["reader"];
  const _on_0 = _actual_0["modeOn"];
  const _x_0 = ($Bool$not$(_gated_0));
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058leaf_condition$1262$((_x_0 || _on_0), {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.System", "base": _base_0, "name": _name_0, "kind": _kind_0, "ledger": _ledger_0, "audit": _service_0, "gated": _gated_0, "reader": _reader_0}, _mode_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": _readers_0, "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058pending_kind$(_kind_0, _previous_0) {
  if (_kind_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.SetOn") {
    return {$: "Some", "value": true};
  } else if (_kind_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.SetOff") {
    return {$: "Some", "value": false};
  } else {
    return _previous_0;
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$058barrier$(_owner_0, _clock_0) {
  const _world_0 = _owner_0["world"];
  const _logs_0 = _owner_0["logs"];
  const _bindings_0 = _owner_0["bindings"];
  const _worldName_0 = _owner_0["worldName"];
  const _step_0 = _owner_0["step"];
  const _prior_0 = _owner_0["prior"];
  const _events_0 = _owner_0["events"];
  const _next_0 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058advance$(_clock_0));
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$058barrier_applied$(_logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _next_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058apply_checked$(_world_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058clock_tick$(_next_0)))));
}

function $measurement$045bend$058motion_clock_return$(_sparse_0, _total_0, _calls_0, _pair_0) {
  const _host_0 = _pair_0["fst"];
  const _clock_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": {$: "measurement-bend.MotionBench", "host": _host_0, "sparse": _sparse_0, "readsum": _total_0, "calls": _calls_0}, "snd": _clock_0};
}

function $measurement$045bend$058motion_transition$(_owner_0, _pending_0, _clock_0) {
  const _host_0 = _owner_0["host"];
  const _sparse_0 = _owner_0["sparse"];
  const _total_0 = _owner_0["readsum"];
  const _calls_0 = _owner_0["calls"];
  return $measurement$045bend$058motion_clock_return$(_sparse_0, _total_0, _calls_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$058motion_transition$(_host_0, _pending_0, _clock_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047reader$045host$058frame_removed$(_ping_0, _removed_0, _despawned_0, _clock_0, _window_0, _result_0) {
  const _readers_0 = _result_0["fst"];
  const _holds_0 = _result_0["snd"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047reader$045host$058frame_despawned$(_ping_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047reader$045host$058life_trim$(_removed_0, _window_0, _holds_0)), _despawned_0, _clock_0, _window_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058holders$(_readers_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Despawned"})));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058trim$(_log_0, _window_0, _holders_0) {
  const _buffer_0 = _log_0["buffer"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/streams.PingLog", "buffer": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058trim_buffer$(_buffer_0, _window_0, _holders_0))};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058collect$(_kind_0, _slots_0) {
  if (_slots_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _slots_0["head"];
    const _interests_0 = _t_0["interests"];
    const _state_0 = _t_0["state"];
    const _tail_0 = _slots_0["tail"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058held$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058interested$(_kind_0, _interests_0)), ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058position$(_kind_0, _state_0)), ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058collect$(_kind_0, _tail_0)));
  }
}

function $String$eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(($String$order$(_a_0, _b_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047payload$058four_c$(_a_0, _b_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _c_0 = _result_0["snd"];
  return __direct_tuple_helper_11(_a_0, _b_0, _c_0, (_array_0), (_array_0[3 % _array_0.length]));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058metadata_get_changed$(_live_0, _flags_0, _added_0, _l_0, _f_0, _a_0, _result_0) {
  const _changed_0 = _result_0["fst"];
  const _c_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Metadata", "live": _l_0, "flag": _f_0, "added": _a_0, "changed": _c_0}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058leaf_condition$1262$(_allowed_0, _system_0, _mode_0, _runtime_0) {
  if (!_allowed_0) {
    const _base_0 = _system_0["base"];
    const _world_0 = _runtime_0["world"];
    const _registry_0 = _runtime_0["registry"];
    const _readers_0 = _runtime_0["readers"];
    const _clock_0 = _runtime_0["clock"];
    const _audit_0 = _runtime_0["audit"];
    const _style_0 = _runtime_0["style"];
    const _escaped_0 = _runtime_0["escaped"];
    const _observations_0 = _runtime_0["observations"];
    const _nextMode_0 = _runtime_0["nextMode"];
    return run_clo((_x_0) => {
  return $IO$pure$({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Dispatched", "runtime": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Runtime", "world": _world_0, "registry": _registry_0, "readers": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058skip$(_readers_0, _base_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058clock_tick$(_clock_0)))), "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": _escaped_0, "observations": _observations_0, "nextMode": _nextMode_0}, "outcome": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Complete"}}, _x_0);
});
  } else {
    const _base_1 = _system_0["base"];
    const _reader_0 = _system_0["reader"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058leaf_reader$1262$(_reader_0, _base_1, _mode_0, _runtime_0);
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058advance$(_clock_0) {
  const _now_0 = _clock_0["tick"];
  const _frame_0 = _clock_0["frameStart"];
  const _retained_0 = _clock_0["retainedAfter"];
  const _number_0 = _clock_0["frameNo"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Clock", "tick": ((_now_0 + 1) >>> 0), "frameStart": _frame_0, "retainedAfter": _retained_0, "frameNo": _number_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$058barrier_applied$(_logs_0, _bindings_0, _worldName_0, _step_0, _prior_0, _events_0, _clock_0, _result_0) {
  if (_result_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.Applied") {
    const _world_0 = _result_0["world"];
    const _changes_0 = _result_0["changes"];
    return run_clo((_x_0) => {
  return $IO$pure$({$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/host.Host", "world": _world_0, "logs": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047reader$045host$058append_changes$(_logs_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058clock_tick$(_clock_0)), _changes_0)), "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, "snd": _clock_0}, _x_0);
});
  } else if (_result_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.CapacityRejected") {
    return run_clo((_x_1) => {
  return $IO$die$(20, "indexed capacity capability rejected", _x_1);
});
  } else {
    return run_clo((_x_2) => {
  return $IO$die$(21, "indexed placement invariant failed", _x_2);
});
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058apply_checked$(_world_0, _tick_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058preflight_world$(_namespace_0, _next_0, _ledger_0, _mode_0, _tick_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058preflight$(_pending_0, _rows_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$058motion_transition$(_owner_0, _pending_0, _clock_0) {
  const _t_0 = _owner_0["world"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["next"];
  const _rows_0 = _t_0["rows"];
  const _commands_0 = _t_0["pending"];
  const _ledger_0 = _t_0["ledger"];
  const __0 = _t_0["mode"];
  const _logs_0 = _owner_0["logs"];
  const _bindings_0 = _owner_0["bindings"];
  const _worldName_0 = _owner_0["worldName"];
  const _step_0 = _owner_0["step"];
  const _prior_0 = _owner_0["prior"];
  const _events_0 = _owner_0["events"];
  if (_pending_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/host.Host", "world": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": _rows_0, "pending": _commands_0, "ledger": _ledger_0, "mode": __0}, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, "snd": _clock_0};
  } else {
    const _value_0 = _pending_0["value"];
    return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/host.Host", "world": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": _rows_0, "pending": _commands_0, "ledger": _ledger_0, "mode": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$058motion_desired$(_value_0))}, "logs": _logs_0, "bindings": _bindings_0, "worldName": _worldName_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, "snd": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058advance$(_clock_0))};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047reader$045host$058frame_despawned$(_ping_0, _removed_0, _despawned_0, _clock_0, _window_0, _result_0) {
  const _readers_0 = _result_0["fst"];
  const _holds_0 = _result_0["snd"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/reader-host.Framed", "logs": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/reader-host.Logs", "ping": _ping_0, "removed": _removed_0, "despawned": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047reader$045host$058life_trim$(_despawned_0, _window_0, _holds_0))}, "readers": _readers_0, "clock": _clock_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047reader$045host$058life_trim$(_log_0, _window_0, _holds_0) {
  if (_window_0.$ === "None") {
    return _log_0;
  } else {
    const _tick_0 = _window_0["value"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058trim_lifecycle$(_log_0, _tick_0, _holds_0);
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058trim_buffer$(_buffer_0, _window_0, _holders_0) {
  const _capacity_0 = _buffer_0["capacity"];
  const _size_0 = _buffer_0["size"];
  const _dropped_0 = _buffer_0["dropped"];
  const _front_0 = _buffer_0["front"];
  const _rear_0 = _buffer_0["rear"];
  const _oldest_0 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058boundary$(_holders_0, _window_0));
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058trim_second$(_capacity_0, _oldest_0, _rear_0, run_loop($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058trim_front$(_front_0, _capacity_0, _oldest_0, _size_0, _dropped_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058held$(_yes_0, _value_0, _tail_0) {
  if (_yes_0) {
    return {$: "Con", "head": _value_0, "tail": _tail_0};
  } else {
    return _tail_0;
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058interested$(_kind_0, _interests_0) {
  if (_kind_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Messages") {
    const _yes_0 = _interests_0["messages"];
    return _yes_0;
  } else if (_kind_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Removed") {
    const _component_0 = _kind_0["component"];
    const _components_0 = _interests_0["removed"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058contains$(_component_0, _components_0);
  } else {
    const _yes_1 = _interests_0["despawned"];
    return _yes_1;
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058position$(_kind_0, _state_0) {
  if (_kind_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Messages") {
    const _stream_0 = _state_0["streamLastRun"];
    return _stream_0;
  } else {
    const _last_0 = _state_0["lastRun"];
    return _last_0;
  }
}

function $Cmp$is_eq$(_c_0) {
  if (_c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $String$order$(_a_0, _b_0) {
  return $Pair$snd$(($String$cmp$(_a_0, _b_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047payload$058four_done$(_a_0, _b_0, _c_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _d_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _array_0, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Four", "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058skip$(_readers_0, _key_0, _now_0) {
  const _slots_0 = _readers_0["slots"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058skip_found$(_key_0, _now_0, _slots_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058find$(_key_0, _slots_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058leaf_reader$1262$(_reader_0, _base_0, _mode_0, _runtime_0) {
  if (_reader_0) {
    const _world_0 = _runtime_0["world"];
    const _registry_0 = _runtime_0["registry"];
    const _readers_0 = _runtime_0["readers"];
    const _clock_0 = _runtime_0["clock"];
    const _audit_0 = _runtime_0["audit"];
    const _style_0 = _runtime_0["style"];
    const _escaped_0 = _runtime_0["escaped"];
    const _observations_0 = _runtime_0["observations"];
    const _nextMode_0 = _runtime_0["nextMode"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058leaf_started$1262$(_base_0, _mode_0, _world_0, _registry_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058begin$(_readers_0, _base_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Interests", "messages": true, "removed": {$: "Con", "head": 0, "tail": {$: "Nil"}}, "despawned": true}, _clock_0)));
  } else {
    const _world_1 = _runtime_0["world"];
    const _registry_1 = _runtime_0["registry"];
    const _readers_1 = _runtime_0["readers"];
    const _clock_1 = _runtime_0["clock"];
    const _audit_1 = _runtime_0["audit"];
    const _style_1 = _runtime_0["style"];
    const _escaped_1 = _runtime_0["escaped"];
    const _observations_1 = _runtime_0["observations"];
    const _nextMode_1 = _runtime_0["nextMode"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058leaf_unread$1262$(_base_0, _mode_0, _world_1, _registry_1, _readers_1, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058advance$(_clock_1)), _audit_1, _style_1, _escaped_1, _observations_1, _nextMode_1);
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047reader$045host$058append_changes$(_logs_0, _tick_0, _changes_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047reader$045host$058append_all$(_changes_0, _tick_0, _logs_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058preflight_world$(_namespace_0, _next_0, _ledger_0, _mode_0, _tick_0, _result_0) {
  const _rows_0 = _result_0["rows"];
  const _pending_0 = _result_0["commands"];
  const _t_0 = _result_0["valid"];
  if (!_t_0) {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.CapacityRejected", "world": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}};
  } else {
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058batch_world$(_namespace_0, _next_0, _ledger_0, _mode_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058batch$(($List$reverse$(_pending_0)), _namespace_0, _tick_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.Running", "rows": _rows_0, "reverseChanges": {$: "Nil"}})));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058preflight$(_commands_0, _rows_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058preflight_go$(_commands_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.Preflight", "rows": _rows_0, "commands": {$: "Nil"}, "valid": true});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047host$058motion_desired$(_value_0) {
  if (_value_0) {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.MotionOn"};
  } else {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.MotionOff"};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058trim_lifecycle$(_log_0, _window_0, _holders_0) {
  const _buffer_0 = _log_0["buffer"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/streams.LifeLog", "buffer": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058trim_buffer$(_buffer_0, _window_0, _holders_0))};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058boundary$($0, $1) {
  for (;;) {
    {
      const _holders_0 = $0;
      const _window_0 = $1;
      if (_holders_0.$ === "Nil") {
        return _window_0;
      } else {
        const _head_0 = _holders_0["head"];
        const _tail_0 = _holders_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058minimum$(_window_0, _head_0));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058trim_second$(_capacity_0, _window_0, _rear_0, _cut_0) {
  const _t_0 = _cut_0["front"];
  if (_t_0.$ === "Nil") {
    const _size_0 = _cut_0["size"];
    const _dropped_0 = _cut_0["dropped"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058finish_cut$(_capacity_0, run_loop($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058trim_front$(($List$reverse$(_rear_0)), _capacity_0, _window_0, _size_0, _dropped_0)));
  } else {
    const _head_0 = _t_0["head"];
    const _tail_0 = _t_0["tail"];
    const _size_1 = _cut_0["size"];
    const _dropped_1 = _cut_0["dropped"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/streams.Buffer", "capacity": _capacity_0, "size": _size_1, "dropped": _dropped_1, "front": {$: "Con", "head": _head_0, "tail": _tail_0}, "rear": _rear_0};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058trim_front$(_front_0, _capacity_0, _window_0, _size_0, _dropped_0) {
  if (_front_0.$ === "Nil") {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/streams.Cut", "front": {$: "Nil"}, "size": _size_0, "dropped": _dropped_0};
  } else {
    const _t_0 = _front_0["head"];
    const _tick_0 = _t_0["tick"];
    const _n_0 = _t_0["count"];
    const _values_0 = _t_0["values"];
    const _tail_0 = _front_0["tail"];
    const _x_0 = (_tick_0 <= _window_0);
    const _x_1 = (_size_0 > _capacity_0);
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058trim_decision$((_x_0 || _x_1), {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/streams.Batch", "tick": _tick_0, "count": _n_0, "values": _values_0}, _tail_0, _size_0, _dropped_0, run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058trim_front$(_tail_0, _capacity_0, _window_0, _x_2, _x_3);
});
}));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058contains$(_key_0, _values_0) {
  if (_values_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _values_0["head"];
    const _tail_0 = _values_0["tail"];
    const _x_0 = (_key_0 === _head_0);
    const _x_1 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058contains$(_key_0, _tail_0));
    return (_x_0 || _x_1);
  }
}

function $Pair$snd$(_p_0) {
  const _b_0 = _p_0["snd"];
  return _b_0;
}

function $String$cmp$(_a_0, _b_0) {
  if (_a_0 === "") {
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": ""}, "snd": {$: "EQ"}};
    } else {
      const _h_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": (_h_0 + _t_0)}, "snd": {$: "LT"}};
    }
  } else {
    const _h_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
    const _t_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h_1 + _t_1), "snd": ""}, "snd": {$: "GT"}};
    } else {
      const _h2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return $String$cmp$fin$(_t_1, _t2_0, ($Char$cmp$(_h_1, _h2_0)));
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058skip_found$(_key_0, _now_0, _slots_0, _found_0) {
  if (_found_0.$ === "None") {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Readers", "slots": _slots_0};
  } else {
    const _t_0 = _found_0["value"];
    const _interests_0 = _t_0["interests"];
    const _t_1 = _t_0["state"];
    const _registered_0 = _t_1["registeredAt"];
    const _last_0 = _t_1["lastRun"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Readers", "slots": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058replace$(_key_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Slot", "key": _key_0, "interests": _interests_0, "state": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.ReaderState", "registeredAt": _registered_0, "lastRun": _last_0, "streamLastRun": _now_0}}, _slots_0))};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058find$(_key_0, _slots_0) {
  if (_slots_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _slots_0["head"];
    const _id_0 = _t_0["key"];
    const _interests_0 = _t_0["interests"];
    const _state_0 = _t_0["state"];
    const _tail_0 = _slots_0["tail"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058find_case$((_key_0 === _id_0), {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Slot", "key": _id_0, "interests": _interests_0, "state": _state_0}, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058find$(_key_0, _tail_0)));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058leaf_started$1262$(_base_0, _mode_0, _world_0, _registry_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _started_0) {
  const _next_0 = _registry_0["next"];
  const _entries_0 = _registry_0["entries"];
  const _readers_0 = _started_0["readers"];
  const _clock_0 = _started_0["clock"];
  const _run_0 = _started_0["run"];
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058visit$1262$(_next_0, _base_0, _mode_0, _clock_0, _style_0, _entries_0, _world_0, _audit_0, {$: "Some", "value": _run_0})), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$pure$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058leaf_done$(_next_0, _readers_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _x_1)), _x_2);
});
}), _x_0);
});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058begin$(_readers_0, _key_0, _interests_0, _clock_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058begin_clock$(_readers_0, _key_0, _interests_0, _clock_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058leaf_unread$1262$(_base_0, _mode_0, _world_0, _registry_0, _readers_0, _clock_0, _audit_0, _style_0, _escaped_0, _observations_0, _nextMode_0) {
  const _next_0 = _registry_0["next"];
  const _entries_0 = _registry_0["entries"];
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058visit$1262$(_next_0, _base_0, _mode_0, _clock_0, _style_0, _entries_0, _world_0, _audit_0, {$: "None"})), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$pure$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058leaf_done$(_next_0, _readers_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _x_1)), _x_2);
});
}), _x_0);
});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047reader$045host$058append_all$($0, $1, $2) {
  for (;;) {
    {
      const _changes_0 = $0;
      const _tick_0 = $1;
      const _logs_0 = $2;
      if (_changes_0.$ === "Nil") {
        return _logs_0;
      } else {
        const _head_0 = _changes_0["head"];
        const _tail_0 = _changes_0["tail"];
        $0 = _tail_0;
        $1 = _tick_0;
        $2 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047reader$045host$058append_change$(_logs_0, _tick_0, _head_0));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058batch_world$(_namespace_0, _next_0, _ledger_0, _mode_0, _result_0) {
  if (_result_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.Completed") {
    const _rows_0 = _result_0["rows"];
    const _changes_0 = _result_0["changes"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.Applied", "world": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": {$: "Nil"}, "ledger": _ledger_0, "mode": _mode_0}, "changes": _changes_0};
  } else {
    const _rows_1 = _result_0["rows"];
    const _row_0 = _result_0["row"];
    const _remaining_0 = _result_0["remaining"];
    const _changes_1 = _result_0["changes"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.InvariantFault", "world": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_1, "pending": ($List$reverse$(_remaining_0)), "ledger": _ledger_0, "mode": _mode_0}, "row": _row_0, "changes": _changes_1};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058batch$($0, $1, $2, $3) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _namespace_0 = $1;
      const _tick_0 = $2;
      const _state_0 = $3;
      if (_commands_0.$ === "Nil") {
        return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058state_finish$(_state_0);
      } else {
        const _command_0 = _commands_0["head"];
        const _tail_0 = _commands_0["tail"];
        $0 = _tail_0;
        $1 = _namespace_0;
        $2 = _tick_0;
        $3 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058state_command$(_namespace_0, _tick_0, _command_0, _state_0));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058preflight_go$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _state_0 = $1;
      if (_commands_0.$ === "Nil") {
        const _rows_0 = _state_0["rows"];
        const _reverse_0 = _state_0["commands"];
        const _valid_0 = _state_0["valid"];
        return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.Preflight", "rows": _rows_0, "commands": ($List$reverse$(_reverse_0)), "valid": _valid_0};
      } else {
        const _command_0 = _commands_0["head"];
        const _tail_0 = _commands_0["tail"];
        const _rows_1 = _state_0["rows"];
        const _reverse_1 = _state_0["commands"];
        const _valid_1 = _state_0["valid"];
        $0 = _tail_0;
        $1 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058preflight_step$(_reverse_1, _valid_1, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058command_bound$(_rows_1, _command_0))));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058minimum$(_a_0, _b_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058choose_min$((_a_0 < _b_0), _a_0, _b_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058finish_cut$(_capacity_0, _cut_0) {
  const _front_0 = _cut_0["front"];
  const _size_0 = _cut_0["size"];
  const _dropped_0 = _cut_0["dropped"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/streams.Buffer", "capacity": _capacity_0, "size": _size_0, "dropped": _dropped_0, "front": _front_0, "rear": {$: "Nil"}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058trim_decision$(_drop_0, _head_0, _tail_0, _size_0, _dropped_0, _ih_0) {
  if (!_drop_0) {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/streams.Cut", "front": {$: "Con", "head": _head_0, "tail": _tail_0}, "size": _size_0, "dropped": _dropped_0};
  } else {
    const _tick_0 = _head_0["tick"];
    const _n_0 = _head_0["count"];
    return run_tail(_ih_0(((_size_0 - _n_0) >>> 0)), ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058maximum$(_dropped_0, _tick_0)));
  }
}

function $String$cmp$fin$(_t1_0, _t2_0, _hc_0) {
  const _t_0 = _hc_0["fst"];
  const _h1b_0 = _t_0["fst"];
  const _h2b_0 = _t_0["snd"];
  const _t_1 = _hc_0["snd"];
  if (_t_1.$ === "LT") {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "LT"}};
  } else if (_t_1.$ === "EQ") {
    return $String$cmp$rec$(_h1b_0, _h2b_0, ($String$cmp$(_t1_0, _t2_0)));
  } else {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "GT"}};
  }
}

function $Char$cmp$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _a_0, "snd": _b_0}, "snd": cmp_new(_x_0, _x_1)};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058replace$(_key_0, _value_0, _slots_0) {
  if (_slots_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _slots_0["head"];
    const _id_0 = _t_0["key"];
    const _interests_0 = _t_0["interests"];
    const _state_0 = _t_0["state"];
    const _tail_0 = _slots_0["tail"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058replace_case$((_key_0 === _id_0), {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Slot", "key": _id_0, "interests": _interests_0, "state": _state_0}, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058replace$(_key_0, _value_0, _tail_0)), _value_0);
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058find_case$(_hit_0, _head_0, _rest_0) {
  if (_hit_0) {
    return {$: "Some", "value": _head_0};
  } else {
    return _rest_0;
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058visit$1262$(_fuel_0, _base_0, _mode_0, _clock_0, _style_0, _entries_0, _world_0, _audit_0, _run_0) {
  if (_fuel_0 === 0) {
    return run_clo((_x_0) => {
  return $IO$pure$({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Visit", "world": _world_0, "audit": _audit_0, "run": _run_0, "entries": _entries_0, "outcome": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.SetupRejected", "reason": "system-search bound"}, "clock": _clock_0, "escaped": {$: "None"}, "observations": {$: "Nil"}}, _x_0);
});
  } else {
    const _rest_0 = (_fuel_0 - 1);
    if (_entries_0.$ === "Nil") {
      return run_clo((_x_1) => {
  return $IO$pure$({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Visit", "world": _world_0, "audit": _audit_0, "run": _run_0, "entries": {$: "Nil"}, "outcome": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.SetupRejected", "reason": "unregistered base"}, "clock": _clock_0, "escaped": {$: "None"}, "observations": {$: "Nil"}}, _x_1);
});
    } else {
      const _t_0 = _entries_0["head"];
      const _t_1 = _t_0["system"];
      const _key_0 = _t_1["base"];
      const _name_0 = _t_1["name"];
      const _kind_0 = _t_1["kind"];
      const _ledger_0 = _t_1["ledger"];
      const _service_0 = _t_1["audit"];
      const _gated_0 = _t_1["gated"];
      const _reader_0 = _t_1["reader"];
      const _local_0 = _t_0["local"];
      const _tail_0 = _entries_0["tail"];
      return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058visit_decide$1262$(run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return run_clo((_x_4) => {
  return run_clo((_x_5) => {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058visit$1262$(_rest_0, _base_0, _mode_0, _clock_0, _style_0, _x_2, _x_3, _x_4, _x_5);
});
});
});
}), (_base_0 === _key_0), _base_0, _mode_0, _clock_0, _style_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.System", "base": _key_0, "name": _name_0, "kind": _kind_0, "ledger": _ledger_0, "audit": _service_0, "gated": _gated_0, "reader": _reader_0}, _local_0, _tail_0, _world_0, _audit_0, _run_0);
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058leaf_done$(_next_0, _readers_0, _style_0, _escaped_0, _observations_0, _nextMode_0, _visit_0) {
  const _world_0 = _visit_0["world"];
  const _audit_0 = _visit_0["audit"];
  const _run_0 = _visit_0["run"];
  const _entries_0 = _visit_0["entries"];
  const _outcome_0 = _visit_0["outcome"];
  const _clock_0 = _visit_0["clock"];
  const _handle_0 = _visit_0["escaped"];
  const _seen_0 = _visit_0["observations"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Dispatched", "runtime": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Runtime", "world": _world_0, "registry": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Registry", "next": _next_0, "entries": _entries_0}, "readers": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058reader_finish$(_readers_0, _run_0, _outcome_0)), "clock": _clock_0, "audit": _audit_0, "style": _style_0, "escaped": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058add_escape$(_escaped_0, _handle_0)), "observations": ($List$append$(_observations_0, _seen_0)), "nextMode": _nextMode_0}, "outcome": _outcome_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058begin_clock$(_readers_0, _key_0, _interests_0, _clock_0) {
  const _slots_0 = _readers_0["slots"];
  const _now_0 = _clock_0["tick"];
  const _frame_0 = _clock_0["frameStart"];
  const _retained_0 = _clock_0["retainedAfter"];
  const _number_0 = _clock_0["frameNo"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058begin_slot$(_key_0, _interests_0, _now_0, _slots_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Clock", "tick": _now_0, "frameStart": _frame_0, "retainedAfter": _retained_0, "frameNo": _number_0}, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058find$(_key_0, _slots_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047reader$045host$058append_change$(_logs_0, _tick_0, _change_0) {
  const _ping_0 = _logs_0["ping"];
  const _removed_0 = _logs_0["removed"];
  const _despawned_0 = _logs_0["despawned"];
  if (_change_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.MainRemoved") {
    const _handle_0 = _change_0["handle"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/reader-host.Logs", "ping": _ping_0, "removed": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058append_lifecycle$(_removed_0, _tick_0, {$: "Con", "head": _handle_0, "tail": {$: "Nil"}})), "despawned": _despawned_0};
  } else if (_change_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Despawned") {
    const _handle_1 = _change_0["handle"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/reader-host.Logs", "ping": _ping_0, "removed": _removed_0, "despawned": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058append_lifecycle$(_despawned_0, _tick_0, {$: "Con", "head": _handle_1, "tail": {$: "Nil"}}))};
  } else {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/reader-host.Logs", "ping": _ping_0, "removed": _removed_0, "despawned": _despawned_0};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058state_finish$(_state_0) {
  if (_state_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.Running") {
    const _rows_0 = _state_0["rows"];
    const _changes_0 = _state_0["reverseChanges"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.Completed", "rows": _rows_0, "changes": ($List$reverse$(_changes_0))};
  } else {
    const _rows_1 = _state_0["rows"];
    const _row_0 = _state_0["row"];
    const _remaining_0 = _state_0["reverseRemaining"];
    const _changes_1 = _state_0["changes"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.BatchFault", "rows": _rows_1, "row": _row_0, "remaining": ($List$reverse$(_remaining_0)), "changes": _changes_1};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058state_command$(_namespace_0, _tick_0, _command_0, _state_0) {
  if (_state_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.Running") {
    const _rows_0 = _state_0["rows"];
    const _changes_0 = _state_0["reverseChanges"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058state_step$(_changes_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058step$(_namespace_0, _tick_0, _rows_0, _command_0)));
  } else {
    const _rows_1 = _state_0["rows"];
    const _row_0 = _state_0["row"];
    const _remaining_0 = _state_0["reverseRemaining"];
    const _changes_1 = _state_0["changes"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.Faulted", "rows": _rows_1, "row": _row_0, "reverseRemaining": {$: "Con", "head": _command_0, "tail": _remaining_0}, "changes": _changes_1};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058preflight_step$(_reverse_0, _valid_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _command_0 = _t_0["fst"];
  const _bounded_0 = _t_0["snd"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.Preflight", "rows": _rows_0, "commands": {$: "Con", "head": _command_0, "tail": _reverse_0}, "valid": ($Bool$and$(_valid_0, _bounded_0))};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058command_bound$(_rows_0, _command_0) {
  if (_command_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Spawn") {
    const _id_0 = _command_0["id"];
    const _bundle_0 = _command_0["bundle"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058bounded_spawn$(_id_0, _bundle_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058rows_can_place$(_rows_0, _id_0)));
  } else {
    return {$: "Tuple", "fst": _rows_0, "snd": {$: "Tuple", "fst": _command_0, "snd": true}};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058choose_min$(_smaller_0, _a_0, _b_0) {
  if (_smaller_0) {
    return _a_0;
  } else {
    return _b_0;
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058maximum$(_a_0, _b_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058choose_min$((_a_0 < _b_0), _b_0, _a_0);
}

function $String$cmp$rec$(_h1b_0, _h2b_0, _rr_0) {
  const _t_0 = _rr_0["fst"];
  const _t1b_0 = _t_0["fst"];
  const _t2b_0 = _t_0["snd"];
  const _r_0 = _rr_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1b_0), "snd": (_h2b_0 + _t2b_0)}, "snd": _r_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058replace_case$(_hit_0, _head_0, _tail_0, _value_0) {
  if (_hit_0) {
    return {$: "Con", "head": _value_0, "tail": _tail_0};
  } else {
    return {$: "Con", "head": _head_0, "tail": _tail_0};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058visit_decide$1262$(_ih_0, _hit_0, _base_0, _mode_0, _clock_0, _style_0, _system_0, _local_0, _tail_0, _world_0, _audit_0, _run_0) {
  if (_hit_0) {
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058visit_local$(_system_0, _mode_0, _clock_0, _tail_0, _world_0, _audit_0, _run_0, run_loop($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047capture$058invoke$(_style_0, _local_0)), run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return run_clo((_x_4) => {
  return run_clo((_x_5) => {
  return run_clo((_x_6) => {
  return $measurement$045bend$058motion_invoke$(_x_0, _x_1, _x_2, _x_3, _x_4, _x_5, _x_6);
});
});
});
});
});
});
}));
  } else {
    return run_clo((_x_7) => {
  return $IO$bind$(_ih_0(_tail_0)(_world_0)(_audit_0)(_run_0), run_clo((_x_8) => {
  return run_clo((_x_9) => {
  return $IO$pure$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058visit_restore$({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Entry", "system": _system_0, "local": _local_0}, _x_8)), _x_9);
});
}), _x_7);
});
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058reader_finish$(_readers_0, _run_0, _outcome_0) {
  if (_run_0.$ === "None") {
    return _readers_0;
  } else {
    const _run_1 = _run_0["value"];
    if (_outcome_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Complete") {
      return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058complete$(_readers_0, _run_1, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Success"});
    } else if (_outcome_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.SystemFailure") {
      const _code_0 = _outcome_0["code"];
      return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058complete$(_readers_0, _run_1, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Failure", "code": _code_0});
    } else {
      return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058complete$(_readers_0, _run_1, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Failure", "code": 7});
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058add_escape$(_escaped_0, _handle_0) {
  if (_handle_0.$ === "None") {
    return _escaped_0;
  } else {
    const _h_0 = _handle_0["value"];
    return $List$append$(_escaped_0, {$: "Con", "head": _h_0, "tail": {$: "Nil"}});
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058begin_slot$(_key_0, _interests_0, _now_0, _slots_0, _clock_0, _found_0) {
  if (_found_0.$ === "None") {
    const _entry_0 = {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Slot", "key": _key_0, "interests": _interests_0, "state": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.ReaderState", "registeredAt": _now_0, "lastRun": 0, "streamLastRun": 0}};
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058started$(_key_0, _interests_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.ReaderState", "registeredAt": _now_0, "lastRun": 0, "streamLastRun": 0}, {$: "Con", "head": _entry_0, "tail": _slots_0}, _clock_0);
  } else {
    const _t_0 = _found_0["value"];
    const _saved_0 = _t_0["interests"];
    const _state_0 = _t_0["state"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058started$(_key_0, _saved_0, _state_0, _slots_0, _clock_0);
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058append_lifecycle$(_log_0, _tick_0, _handles_0) {
  const _buffer_0 = _log_0["buffer"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/streams.LifeLog", "buffer": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058append_units$(_handles_0, _tick_0, _buffer_0))};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058state_step$(_reverseChanges_0, _result_0) {
  if (_result_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.Stepped") {
    const _rows_0 = _result_0["rows"];
    const _changes_0 = _result_0["changes"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.Running", "rows": _rows_0, "reverseChanges": ($List$reverse$go$(_changes_0, _reverseChanges_0))};
  } else {
    const _rows_1 = _result_0["rows"];
    const _row_0 = _result_0["row"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.Faulted", "rows": _rows_1, "row": _row_0, "reverseRemaining": {$: "Nil"}, "changes": ($List$reverse$(_reverseChanges_0))};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058step$(_namespace_0, _tick_0, _rows_0, _command_0) {
  if (_command_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Spawn") {
    const _id_0 = _command_0["id"];
    const _bundle_0 = _command_0["bundle"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058spawn$(_namespace_0, _tick_0, _id_0, _rows_0, _bundle_0);
  } else if (_command_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.InsertMain") {
    const _id_1 = _command_0["id"];
    const _main_0 = _command_0["main"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058main_effect$(_namespace_0, _id_1, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058rows_replace_main$(_rows_0, _id_1, {$: "Some", "value": _main_0}, _tick_0)));
  } else if (_command_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.RemoveMain") {
    const _id_2 = _command_0["id"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058main_effect$(_namespace_0, _id_2, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058rows_replace_main$(_rows_0, _id_2, {$: "None"}, _tick_0)));
  } else {
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058edit_target$(_namespace_0, _tick_0, _rows_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058targeted$(_command_0)));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058bounded_spawn$(_id_0, _bundle_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _valid_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _rows_0, "snd": {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Spawn", "id": _id_0, "bundle": _bundle_0}, "snd": _valid_0}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058rows_can_place$(_rows_0, _id_0) {
  return {$: "Tuple", "fst": _rows_0, "snd": ($Bool$and$((0 < _id_0), (_id_0 <= 131072)))};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058visit_local$(_system_0, _mode_0, _clock_0, _tail_0, _world_0, _audit_0, _run_0, _pair_0, _invoke_0) {
  const _local_0 = _pair_0["fst"];
  const _count_0 = _pair_0["snd"];
  return run_clo((_x_0) => {
  return $IO$bind$(_invoke_0(_system_0)(_mode_0)(_count_0)(_clock_0)(_world_0)(_audit_0)(_run_0), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$pure$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058visit_done$(_system_0, _local_0, _tail_0, _x_1)), _x_2);
});
}), _x_0);
});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047capture$058invoke$(_style_0, _local_0) {
  if (_style_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/capture.Returned") {
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047capture$058increment$(_local_0);
  } else {
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047capture$058call$(run_clo((_x_0) => {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047capture$058closure$(_local_0, _x_0);
}));
  }
}

function $measurement$045bend$058motion_invoke$(_system_0, _mode_0, _count_0, _clock_0, _owner_0, _audit_0, _run_0) {
  const _t_0 = _owner_0["host"];
  const _world_0 = _t_0["world"];
  const _logs_0 = _t_0["logs"];
  const _bindings_0 = _t_0["bindings"];
  const _name_0 = _t_0["worldName"];
  const _step_0 = _t_0["step"];
  const _prior_0 = _t_0["prior"];
  const _events_0 = _t_0["events"];
  const _sparse_0 = _owner_0["sparse"];
  const _total_0 = _owner_0["readsum"];
  return $measurement$045bend$058prototype_flat_motion_queried$(_sparse_0, _total_0, _count_0, _logs_0, _bindings_0, _name_0, _step_0, _prior_0, _events_0, _audit_0, _run_0, _clock_0, ($measurement$045bend$058motion_handles$(_world_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058visit_restore$(_head_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _audit_0 = _result_0["audit"];
  const _run_0 = _result_0["run"];
  const _entries_0 = _result_0["entries"];
  const _outcome_0 = _result_0["outcome"];
  const _clock_0 = _result_0["clock"];
  const _escaped_0 = _result_0["escaped"];
  const _observations_0 = _result_0["observations"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Visit", "world": _world_0, "audit": _audit_0, "run": _run_0, "entries": {$: "Con", "head": _head_0, "tail": _entries_0}, "outcome": _outcome_0, "clock": _clock_0, "escaped": _escaped_0, "observations": _observations_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058complete$(_readers_0, _run_0, _outcome_0) {
  if (_outcome_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Failure") {
    return _readers_0;
  } else {
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058completed$(_readers_0, _run_0);
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058started$(_key_0, _interests_0, _state_0, _slots_0, _clock_0) {
  const _at_0 = _state_0["registeredAt"];
  const _last_0 = _state_0["lastRun"];
  const _stream_0 = _state_0["streamLastRun"];
  const _now_0 = _clock_0["tick"];
  const _frame_0 = _clock_0["frameStart"];
  const _retained_0 = _clock_0["retainedAfter"];
  const _number_0 = _clock_0["frameNo"];
  const _next_0 = ((_now_0 + 1) >>> 0);
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Started", "readers": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Readers", "slots": _slots_0}, "clock": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Clock", "tick": _next_0, "frameStart": _frame_0, "retainedAfter": _retained_0, "frameNo": _number_0}, "run": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Run", "key": _key_0, "interests": _interests_0, "state": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.ReaderState", "registeredAt": _at_0, "lastRun": _last_0, "streamLastRun": _stream_0}, "boundary": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.ReadBoundary", "since": _last_0, "streamSince": _stream_0, "thisRun": _next_0}}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058append_units$($0, $1, $2) {
  for (;;) {
    {
      const _values_0 = $0;
      const _tick_0 = $1;
      const _buffer_0 = $2;
      if (_values_0.$ === "Nil") {
        return _buffer_0;
      } else {
        const _value_0 = _values_0["head"];
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = _tick_0;
        $2 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058append_buffer$(_buffer_0, _tick_0, {$: "Con", "head": _value_0, "tail": {$: "Nil"}}));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058spawn$(_namespace_0, _tick_0, _id_0, _rows_0, _bundle_0) {
  const _t_0 = _bundle_0["main"];
  if (_t_0.$ === "None") {
    const _aux_0 = _bundle_0["aux"];
    const _flag_0 = _bundle_0["flag"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058placed$({$: "Nil"}, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058rows_place$(_rows_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Row", "id": _id_0, "main": {$: "None"}, "aux": _aux_0, "flag": _flag_0, "added": 0, "changed": 0})));
  } else {
    const _main_0 = _t_0["value"];
    const _aux_1 = _bundle_0["aux"];
    const _flag_1 = _bundle_0["flag"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058placed$({$: "Con", "head": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.MainAdded", "handle": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Con", "head": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.MainChanged", "handle": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Nil"}}}, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058rows_place$(_rows_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Row", "id": _id_0, "main": {$: "Some", "value": _main_0}, "aux": _aux_1, "flag": _flag_1, "added": _tick_0, "changed": _tick_0})));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058main_effect$(_namespace_0, _id_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.AddedMain") {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.Stepped", "rows": _rows_0, "changes": {$: "Con", "head": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.MainAdded", "handle": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Con", "head": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.MainChanged", "handle": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Nil"}}}};
  } else if (_t_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.ChangedMain") {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.Stepped", "rows": _rows_0, "changes": {$: "Con", "head": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.MainChanged", "handle": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Nil"}}};
  } else if (_t_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.RemovedMain") {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.Stepped", "rows": _rows_0, "changes": {$: "Con", "head": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.MainRemoved", "handle": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_0}}, "tail": {$: "Nil"}}};
  } else if (_t_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.MissingMainTarget") {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.Stepped", "rows": _rows_0, "changes": {$: "Nil"}};
  } else {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.Stepped", "rows": _rows_0, "changes": {$: "Nil"}};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058rows_replace_main$(_rows_0, _id_0, _replacement_0, _tick_0) {
  const _m_0 = _rows_0["main"];
  const _a_0 = _rows_0["aux"];
  const _f_0 = _rows_0["metadata"];
  const _c_0 = _rows_0["capacity"];
  const _d_0 = _rows_0["depth"];
  const _h_0 = _rows_0["high_water"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058replace_main_checked$(($Bool$and$((0 < _id_0), ($Bool$and$((_id_0 <= _c_0), (_id_0 <= _h_0))))), _id_0, _tick_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, _replacement_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058edit_target$(_namespace_0, _tick_0, _rows_0, _result_0) {
  const _command_0 = _result_0["fst"];
  const _id_0 = _result_0["snd"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058extracted$(_namespace_0, _tick_0, _id_0, _command_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058rows_extract$(_rows_0, _id_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058targeted$(_command_0) {
  if (_command_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Spawn") {
    const _id_0 = _command_0["id"];
    const _bundle_0 = _command_0["bundle"];
    return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Spawn", "id": _id_0, "bundle": _bundle_0}, "snd": _id_0};
  } else if (_command_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.InsertMain") {
    const _id_1 = _command_0["id"];
    const _main_0 = _command_0["main"];
    return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.InsertMain", "id": _id_1, "main": _main_0}, "snd": _id_1};
  } else if (_command_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.InsertFlag") {
    const _id_2 = _command_0["id"];
    const _flag_0 = _command_0["flag"];
    return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.InsertFlag", "id": _id_2, "flag": _flag_0}, "snd": _id_2};
  } else if (_command_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.RemoveMain") {
    const _id_3 = _command_0["id"];
    return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.RemoveMain", "id": _id_3}, "snd": _id_3};
  } else if (_command_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.RemoveFlag") {
    const _id_4 = _command_0["id"];
    return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.RemoveFlag", "id": _id_4}, "snd": _id_4};
  } else {
    const _id_5 = _command_0["id"];
    return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Despawn", "id": _id_5}, "snd": _id_5};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058visit_done$(_system_0, _local_0, _tail_0, _result_0) {
  const _base_0 = _system_0["base"];
  const _name_0 = _system_0["name"];
  const _kind_0 = _system_0["kind"];
  const _ledger_0 = _system_0["ledger"];
  const _service_0 = _system_0["audit"];
  const _gated_0 = _system_0["gated"];
  const _reader_0 = _system_0["reader"];
  const _world_0 = _result_0["world"];
  const _audit_0 = _result_0["audit"];
  const _run_0 = _result_0["run"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Success") {
    const _clock_0 = _result_0["clock"];
    const _escaped_0 = _result_0["escaped"];
    const _observations_0 = _result_0["observations"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Visit", "world": _world_0, "audit": _audit_0, "run": _run_0, "entries": {$: "Con", "head": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Entry", "system": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.System", "base": _base_0, "name": _name_0, "kind": _kind_0, "ledger": _ledger_0, "audit": _service_0, "gated": _gated_0, "reader": _reader_0}, "local": _local_0}, "tail": _tail_0}, "outcome": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Complete"}, "clock": _clock_0, "escaped": _escaped_0, "observations": _observations_0};
  } else {
    const _code_0 = _t_0["code"];
    const _clock_1 = _result_0["clock"];
    const _escaped_1 = _result_0["escaped"];
    const _observations_1 = _result_0["observations"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Visit", "world": _world_0, "audit": _audit_0, "run": _run_0, "entries": {$: "Con", "head": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.Entry", "system": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/schedule.System", "base": _base_0, "name": _name_0, "kind": _kind_0, "ledger": _ledger_0, "audit": _service_0, "gated": _gated_0, "reader": _reader_0}, "local": _local_0}, "tail": _tail_0}, "outcome": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.SystemFailure", "system": _name_0, "code": _code_0}, "clock": _clock_1, "escaped": _escaped_1, "observations": _observations_1};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047capture$058increment$(_local_0) {
  const _array_0 = _local_0["count"];
  return __direct_tuple_helper_12((_array_0), (_array_0[0 % _array_0.length]));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047capture$058call$(_callback_0) {
  return run_tail(_callback_0, {$: "Unit"});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047capture$058closure$(_local_0, __0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047capture$058increment$(_local_0);
}

function $measurement$045bend$058prototype_flat_motion_queried$(_sparse_0, _total_0, _count_0, _logs_0, _bindings_0, _name_0, _step_0, _prior_0, _events_0, _audit_0, _run_0, _clock_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _handles_0 = _pair_0["snd"];
  return $measurement$045bend$058prototype_flat_motion_updated$(_sparse_0, _count_0, _logs_0, _bindings_0, _name_0, _step_0, _prior_0, _events_0, _audit_0, _run_0, _clock_0, ($measurement$045bend$058prototype_flat_motion_rows$(_handles_0, {$: "measurement-bend.PrototypeFlatMotionRows", "owner": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_pack$1260$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058tx_begin$(_world_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Handle", "namespace": 0, "id": 0})))), "total": _total_0})));
}

function $measurement$045bend$058motion_handles$(_world_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058prototype_identity_each$1260$({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/query.Required"}, _world_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058completed$(_readers_0, _run_0) {
  const _slots_0 = _readers_0["slots"];
  const _key_0 = _run_0["key"];
  const _interests_0 = _run_0["interests"];
  const _t_0 = _run_0["state"];
  const _registered_0 = _t_0["registeredAt"];
  const _t_1 = _run_0["boundary"];
  const _thisRun_0 = _t_1["thisRun"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Readers", "slots": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047readers$058replace$(_key_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/readers.Slot", "key": _key_0, "interests": _interests_0, "state": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.ReaderState", "registeredAt": _registered_0, "lastRun": _thisRun_0, "streamLastRun": _thisRun_0}}, _slots_0))};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058append_buffer$(_buffer_0, _tick_0, _values_0) {
  const _capacity_0 = _buffer_0["capacity"];
  const _size_0 = _buffer_0["size"];
  const _dropped_0 = _buffer_0["dropped"];
  const _front_0 = _buffer_0["front"];
  const _rear_0 = _buffer_0["rear"];
  if (_values_0.$ === "Nil") {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/streams.Buffer", "capacity": _capacity_0, "size": _size_0, "dropped": _dropped_0, "front": _front_0, "rear": _rear_0};
  } else {
    const _v_0 = _values_0["head"];
    const _vs_0 = _values_0["tail"];
    const _n_0 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058count$({$: "Con", "head": _v_0, "tail": _vs_0}, 0));
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/streams.Buffer", "capacity": _capacity_0, "size": ((_size_0 + _n_0) >>> 0), "dropped": _dropped_0, "front": _front_0, "rear": {$: "Con", "head": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/streams.Batch", "tick": _tick_0, "count": _n_0, "values": {$: "Con", "head": _v_0, "tail": _vs_0}}, "tail": _rear_0}};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058placed$(_changes_0, _result_0) {
  if (_result_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Placed") {
    const _rows_0 = _result_0["rows"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.Stepped", "rows": _rows_0, "changes": _changes_0};
  } else {
    const _rows_1 = _result_0["rows"];
    const _row_0 = _result_0["row"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.PlacementFault", "rows": _rows_1, "row": _row_0};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058rows_place$(_rows_0, _row_0) {
  const _id_0 = _row_0["id"];
  const _m_0 = _row_0["main"];
  const _a_0 = _row_0["aux"];
  const _f_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058place_checked$(($Bool$and$((0 < _id_0), (_id_0 <= 131072))), _rows_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Row", "id": _id_0, "main": _m_0, "aux": _a_0, "flag": _f_0, "added": _added_0, "changed": _changed_0});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058replace_main_checked$(_valid_0, _id_0, _tick_0, _rows_0, _replacement_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _rows_0, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.MissingMainTarget"}};
  } else {
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058replace_main_meta_done$(_id_0, _tick_0, _m_0, _a_0, _c_0, _d_0, _h_0, _replacement_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058metadata_get$(_f_0, ((_id_0 - 1) >>> 0))));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058extracted$(_namespace_0, _tick_0, _id_0, _command_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.Stepped", "rows": _rows_0, "changes": {$: "Nil"}};
  } else {
    const _row_0 = _t_0["value"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058edited$(_rows_0, _id_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058edit_row$(_namespace_0, _tick_0, _command_0, _row_0)));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047capture$058incremented$(_result_0) {
  const _array_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  const _x_0 = ((_count_0 + 1) >>> 0);
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/capture.Local", "count": (_array_0[0 % _array_0.length] = _x_0, _array_0)}, "snd": ((_count_0 + 1) >>> 0)};
}

function $measurement$045bend$058prototype_flat_motion_updated$(_sparse_0, _count_0, _logs_0, _bindings_0, _name_0, _step_0, _prior_0, _events_0, _audit_0, _run_0, _clock_0, _result_0) {
  const _owner_0 = _result_0["owner"];
  const _total_0 = _result_0["total"];
  return $measurement$045bend$058motion_committed$(_sparse_0, _total_0, _count_0, _logs_0, _bindings_0, _name_0, _step_0, _prior_0, _events_0, _audit_0, _run_0, _clock_0, ($measurement$045bend$058motion_committed_queries$(_sparse_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_storage_commit$1260$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_finish_success$1260$(_owner_0)), ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047dispatcher$058clock_tick$(_clock_0)))))));
}

function $measurement$045bend$058prototype_flat_motion_rows$(_handles_0, _state_0) {
  const _owner_0 = _state_0["owner"];
  const _total_0 = _state_0["total"];
  return $measurement$045bend$058prototype_flat_motion_rows_next$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion$1260$(_handles_0, _owner_0, _total_0)), 0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_pack$1260$(_owner_0) {
  const _world_0 = _owner_0["world"];
  const _selected_0 = _owner_0["selected"];
  const _undo_0 = _owner_0["undo"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.PrototypeFlatTx", "world": _world_0, "selected": _selected_0, "undo": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_inverse_pack$1260$(_undo_0)), "commands": _commands_0, "pings": _pings_0, "marks": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_mark_pack$1260$(_marks_0))};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058tx_begin$(_world_0, _selected_0) {
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "pings": {$: "Nil"}, "marks": {$: "Nil"}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058prototype_identity_each$1260$(_selection_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058each_return$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058prototype_identity_read_rows$1260$(_rows_0, _selection_0, _namespace_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047streams$058count$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      if (_values_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _tail_0 = _values_0["tail"];
        $0 = _tail_0;
        $1 = ((_acc_0 + 1) >>> 0);
        continue;
      }
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058place_checked$(_valid_0, _rows_0, _row_0) {
  if (!_valid_0) {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rejected", "rows": _rows_0, "row": _row_0};
  } else {
    const _id_0 = _row_0["id"];
    const _m_0 = _row_0["main"];
    const _a_0 = _row_0["aux"];
    const _f_0 = _row_0["flag"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058place_grown$(run_loop($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058grow$(17, _id_0, _rows_0)), {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Row", "id": _id_0, "main": _m_0, "aux": _a_0, "flag": _f_0, "added": _added_0, "changed": _changed_0});
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058replace_main_meta_done$(_id_0, _tick_0, _main_0, _aux_0, _capacity_0, _depth_0, _high_0, _replacement_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _meta_0 = _result_0["snd"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058replace_main_meta$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _replacement_0, _meta_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058edited$(_rows_0, _id_0, _result_0) {
  const _t_0 = _result_0["row"];
  if (_t_0.$ === "Some") {
    const _row_0 = _t_0["value"];
    const _changes_0 = _result_0["changes"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.Stepped", "rows": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058rows_restore$(_rows_0, _row_0)), "changes": _changes_0};
  } else {
    const _changes_1 = _result_0["changes"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058removed$(_changes_1, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058rows_remove$(_rows_0, _id_0)));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058edit_row$(_namespace_0, _tick_0, _command_0, _row_0) {
  if (_command_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.InsertFlag") {
    const _flag_0 = _command_0["flag"];
    const _id_0 = _row_0["id"];
    const _main_0 = _row_0["main"];
    const _aux_0 = _row_0["aux"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.RowEdit", "row": {$: "Some", "value": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": {$: "Some", "value": _flag_0}, "added": _added_0, "changed": _changed_0}}, "changes": {$: "Nil"}};
  } else if (_command_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.RemoveFlag") {
    const _id_1 = _row_0["id"];
    const _main_1 = _row_0["main"];
    const _aux_1 = _row_0["aux"];
    const _added_1 = _row_0["added"];
    const _changed_1 = _row_0["changed"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.RowEdit", "row": {$: "Some", "value": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Row", "id": _id_1, "main": _main_1, "aux": _aux_1, "flag": {$: "None"}, "added": _added_1, "changed": _changed_1}}, "changes": {$: "Nil"}};
  } else if (_command_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.InsertMain") {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.RowEdit", "row": {$: "Some", "value": _row_0}, "changes": {$: "Nil"}};
  } else if (_command_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.RemoveMain") {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.RowEdit", "row": {$: "Some", "value": _row_0}, "changes": {$: "Nil"}};
  } else if (_command_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Despawn") {
    const _id_2 = _row_0["id"];
    const _t_0 = _row_0["main"];
    if (_t_0.$ === "Some") {
      return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.RowEdit", "row": {$: "None"}, "changes": {$: "Con", "head": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.MainRemoved", "handle": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_2}}, "tail": {$: "Con", "head": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Despawned", "handle": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_2}}, "tail": {$: "Nil"}}}};
    } else {
      return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.RowEdit", "row": {$: "None"}, "changes": {$: "Con", "head": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Despawned", "handle": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_2}}, "tail": {$: "Nil"}}};
    }
  } else {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.RowEdit", "row": {$: "Some", "value": _row_0}, "changes": {$: "Nil"}};
  }
}

function $measurement$045bend$058motion_committed$(_sparse_0, _total_0, _count_0, _logs_0, _bindings_0, _name_0, _step_0, _prior_0, _events_0, _audit_0, _run_0, _clock_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _querysum_0 = _pair_0["snd"];
  return run_clo((_x_0) => {
  return $IO$pure$({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/dispatcher.Invoked", "world": {$: "measurement-bend.MotionBench", "host": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/host.Host", "world": _world_0, "logs": _logs_0, "bindings": _bindings_0, "worldName": _name_0, "step": _step_0, "prior": _prior_0, "events": _events_0}, "sparse": _sparse_0, "readsum": ((_total_0 + _querysum_0) >>> 0), "calls": _count_0}, "audit": _audit_0, "run": _run_0, "outcome": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Success"}, "clock": _clock_0, "escaped": {$: "None"}, "observations": {$: "Nil"}}, _x_0);
});
}

function $measurement$045bend$058motion_committed_queries$(_sparse_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  return $measurement$045bend$058motion_queries$(_sparse_0, _world_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_storage_commit$1260$(_result_0, _tick_0) {
  if (_result_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.PrototypeFlatCommitted") {
    const _world_0 = _result_0["world"];
    const _commands_0 = _result_0["commands"];
    const _pings_0 = _result_0["pings"];
    const _marks_0 = _result_0["marks"];
    return {$: "Tuple", "fst": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058publish$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_storage_mark_all$1260$(_marks_0, _world_0, _tick_0)), ($List$reverse$(_commands_0)))), "snd": _pings_0};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "Tuple", "fst": _world_1, "snd": {$: "Nil"}};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_finish_success$1260$(_owner_0) {
  const _world_0 = _owner_0["world"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.PrototypeFlatCommitted", "world": _world_0, "commands": ($List$reverse$(_commands_0)), "pings": ($List$reverse$(_pings_0)), "marks": _marks_0};
}

function $measurement$045bend$058prototype_flat_motion_rows_next$(_result_0, _total_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "measurement-bend.PrototypeFlatMotionRows", "owner": _owner_0, "total": ((_total_0 + _value_0) >>> 0)};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion$1260$(_handles_0, _owner_0, _total_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_finish$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_loop$1260$(_handles_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_pack$(_owner_0, _total_0)))));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_inverse_pack$1260$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.PrototypeFlatEnd"};
  } else {
    const _t_0 = _values_0["head"];
    if (_t_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.MainInverse") {
      const _t_1 = _t_0["handle"];
      const _space_0 = _t_1["namespace"];
      const _id_0 = _t_1["id"];
      const _old_0 = _t_0["old"];
      const _tail_0 = _values_0["tail"];
      return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.PrototypeFlatMain", "namespace": _space_0, "id": _id_0, "old": _old_0, "tail": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_inverse_pack$1260$(_tail_0))};
    } else {
      const _old_1 = _t_0["old"];
      const _tail_1 = _values_0["tail"];
      return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.PrototypeFlatLedger", "old": _old_1, "tail": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_inverse_pack$1260$(_tail_1))};
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_mark_pack$1260$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.PrototypeFlatMarksEnd"};
  } else {
    const _t_0 = _values_0["head"];
    const _space_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _tail_0 = _values_0["tail"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.PrototypeFlatMark", "namespace": _space_0, "id": _id_0, "tail": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_mark_pack$1260$(_tail_0))};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058each_return$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _observations_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": _observations_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058prototype_identity_read_rows$1260$(_rows_0, _selection_0, _namespace_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _t_0 = _rows_0["metadata"];
  const _live_0 = _t_0["live"];
  const _flags_0 = _t_0["flags"];
  const _added_0 = _t_0["added"];
  const _changed_0 = _t_0["changed"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058prototype_identity_struct_idx_go$1260$(_high_0, 1, _capacity_0, _depth_0, _high_0, _selection_0, _namespace_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": {$: "Nil"}});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058place_grown$(_rows_0, _row_0) {
  const _m_0 = _rows_0["main"];
  const _a_0 = _rows_0["aux"];
  const _f_0 = _rows_0["metadata"];
  const _c_0 = _rows_0["capacity"];
  const _d_0 = _rows_0["depth"];
  const _h_0 = _rows_0["high_water"];
  const _id_0 = _row_0["id"];
  const _main_0 = _row_0["main"];
  const _aux_0 = _row_0["aux"];
  const _flag_0 = _row_0["flag"];
  const _added_0 = _row_0["added"];
  const _changed_0 = _row_0["changed"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058place_capacity$(($Bool$and$((0 < _id_0), (_id_0 <= _c_0))), {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058grow$(_fuel_0, _id_0, _rows_0) {
  if (_fuel_0 === 0) {
    return _rows_0;
  } else {
    const _n_0 = (_fuel_0 - 1);
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058grow_decide$(($Bool$and$((_c_0 < _id_0), (_c_0 <= 65536))), {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, run_clo((_x_0) => {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058grow$(_n_0, _id_0, _x_0);
}));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058replace_main_meta$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _replacement_0, _meta_0) {
  const _t_0 = _meta_0["live"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.MissingMainTarget"}};
  } else {
    const __3 = _meta_0["flag"];
    const __4 = _meta_0["added"];
    const __5 = _meta_0["changed"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058replace_main_slot$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, __3, __4, __5, _replacement_0);
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047commands$058removed$(_changes_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/commands.Stepped", "rows": _rows_0, "changes": _changes_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058rows_remove$(_rows_0, _id_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058remove_done$(_id_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058rows_extract$(_rows_0, _id_0)));
}

function $measurement$045bend$058motion_queries$(_sparse_0, _world_0) {
  if (!_sparse_0) {
    return {$: "Tuple", "fst": _world_0, "snd": 0};
  } else {
    return $measurement$045bend$058motion_query1$(($measurement$045bend$058motion_views$(_world_0)));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_storage_mark_all$1260$(_marks_0, _world_0, _tick_0) {
  if (_marks_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.PrototypeFlatMarksEnd") {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _t_0 = _world_0["rows"];
    const _main_0 = _t_0["main"];
    const _aux_0 = _t_0["aux"];
    const _t_1 = _t_0["metadata"];
    const _live_0 = _t_1["live"];
    const _flags_0 = _t_1["flags"];
    const _added_0 = _t_1["added"];
    const _changed_0 = _t_1["changed"];
    const _capacity_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _high_0 = _t_0["high_water"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0};
  } else {
    const _namespace_1 = _world_0["namespace"];
    const _next_1 = _world_0["next"];
    const _t_2 = _world_0["rows"];
    const _main_1 = _t_2["main"];
    const _aux_1 = _t_2["aux"];
    const _t_3 = _t_2["metadata"];
    const _live_1 = _t_3["live"];
    const _flags_1 = _t_3["flags"];
    const _added_1 = _t_3["added"];
    const _changed_1 = _t_3["changed"];
    const _capacity_1 = _t_2["capacity"];
    const _depth_1 = _t_2["depth"];
    const _high_1 = _t_2["high_water"];
    const _pending_1 = _world_0["pending"];
    const _ledger_1 = _world_0["ledger"];
    const _mode_1 = _world_0["mode"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_storage_mark_loop$1260$(_marks_0, _namespace_1, _next_1, _main_1, _aux_1, _flags_1, _added_1, {$: "Tuple", "fst": _live_1, "snd": _changed_1}, _capacity_1, _depth_1, _high_1, _pending_1, _ledger_1, _mode_1, _tick_0);
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_finish$(_state_0) {
  const _ns_0 = _state_0["namespace"];
  const _next_0 = _state_0["next"];
  const _columns_0 = _state_0["columns"];
  const _aux_0 = _state_0["aux"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _depth_0 = _state_0["depth"];
  const _high_0 = _state_0["high"];
  const _pending_0 = _state_0["pending"];
  const _ledger_0 = _state_0["ledger"];
  const _mode_0 = _state_0["mode"];
  const _selected_0 = _state_0["selected"];
  const _undo_0 = _state_0["undo"];
  const _commands_0 = _state_0["commands"];
  const _pings_0 = _state_0["pings"];
  const _marks_0 = _state_0["marks"];
  const _total_0 = _state_0["total"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.PrototypeFlatTx", "world": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}, "snd": _total_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_loop$1260$($0, $1) {
  for (;;) {
    {
      const _handles_0 = $0;
      const _state_0 = $1;
      if (_handles_0.$ === "Nil") {
        return _state_0;
      } else {
        const _handle_0 = _handles_0["head"];
        const _rest_0 = _handles_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_step$1260$(_handle_0, _state_0));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_pack$(_owner_0, _total_0) {
  const _t_0 = _owner_0["world"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["next"];
  const _t_1 = _t_0["rows"];
  const _columns_0 = _t_1["main"];
  const _aux_0 = _t_1["aux"];
  const _metadata_0 = _t_1["metadata"];
  const _capacity_0 = _t_1["capacity"];
  const _depth_0 = _t_1["depth"];
  const _high_0 = _t_1["high_water"];
  const _pending_0 = _t_0["pending"];
  const _ledger_0 = _t_0["ledger"];
  const _mode_0 = _t_0["mode"];
  const _selected_0 = _owner_0["selected"];
  const _undo_0 = _owner_0["undo"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/held-adapter.PrototypeFlatFold", "namespace": _ns_0, "next": _next_0, "columns": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high": _high_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0, "total": _total_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058prototype_identity_struct_idx_go$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _id_0 = $1;
      const _capacity_0 = $2;
      const _depth_0 = $3;
      const _high_0 = $4;
      const _selection_0 = $5;
      const _namespace_0 = $6;
      const _state_0 = $7;
      if (_remaining_0 === 0) {
        return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058struct_cols_finish$(_capacity_0, _depth_0, _high_0, _state_0);
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = ((_id_0 + 1) >>> 0);
        $2 = _capacity_0;
        $3 = _depth_0;
        $4 = _high_0;
        $5 = _selection_0;
        $6 = _namespace_0;
        $7 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058prototype_identity_struct_idx_advance$1260$(($Bool$and$((0 < _id_0), (_id_0 <= _capacity_0))), _id_0, _namespace_0, _selection_0, _state_0));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058place_capacity$(_valid_0, _rows_0, _row_0) {
  if (!_valid_0) {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rejected", "rows": _rows_0, "row": _row_0};
  } else {
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    const _id_0 = _row_0["id"];
    const _main_0 = _row_0["main"];
    const _aux_0 = _row_0["aux"];
    const _flag_0 = _row_0["flag"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058place_meta$(_m_0, _a_0, _c_0, _d_0, _h_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Row", "id": _id_0, "main": _main_0, "aux": _aux_0, "flag": _flag_0, "added": _added_0, "changed": _changed_0}, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058metadata_live$(_f_0, ((_id_0 - 1) >>> 0))));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058grow_decide$(_needed_0, _rows_0, _recurse_0) {
  if (!_needed_0) {
    return _rows_0;
  } else {
    const _m_0 = _rows_0["main"];
    const _a_0 = _rows_0["aux"];
    const _f_0 = _rows_0["metadata"];
    const _c_0 = _rows_0["capacity"];
    const _d_0 = _rows_0["depth"];
    const _h_0 = _rows_0["high_water"];
    return run_tail(_recurse_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": array_node(_m_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058slots_empty$(_d_0))), "aux": array_node(_a_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058slots_empty$(_d_0))), "metadata": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058metadata_grow$(_f_0, _d_0)), "capacity": ((_c_0 + _c_0) >>> 0), "depth": nat_chk(_d_0 + 1), "high_water": _h_0});
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058replace_main_slot$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _replacement_0) {
  if (_replacement_0.$ === "None") {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058replace_main_done$(_id_0, _tick_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, false, array_rmw(_main_0, _x_0, () => _x_1));
  } else {
    const _value_0 = _replacement_0["value"];
    const _x_2 = ((_id_0 - 1) >>> 0);
    const _x_3 = {$: "Some", "value": _value_0};
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058replace_main_done$(_id_0, _tick_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, true, array_rmw(_main_0, _x_2, () => _x_3));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058remove_done$(_id_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _m_0 = _t_0["main"];
  const _a_0 = _t_0["aux"];
  const _f_0 = _t_0["metadata"];
  const _c_0 = _t_0["capacity"];
  const _d_0 = _t_0["depth"];
  const _h_0 = _t_0["high_water"];
  const _t_1 = _result_0["snd"];
  if (_t_1.$ === "None") {
    return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _m_0, "aux": _a_0, "metadata": _f_0, "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, "snd": {$: "None"}};
  } else {
    const _row_0 = _t_1["value"];
    return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _m_0, "aux": _a_0, "metadata": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058metadata_set$(_f_0, ((_id_0 - 1) >>> 0), {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Metadata", "live": false, "flag": {$: "None"}, "added": 0, "changed": 0})), "capacity": _c_0, "depth": _d_0, "high_water": _h_0}, "snd": {$: "Some", "value": _row_0}};
  }
}

function $measurement$045bend$058motion_query1$(_pair_0) {
  const _world_0 = _pair_0["fst"];
  const _values_0 = _pair_0["snd"];
  return $measurement$045bend$058motion_query2$(run_loop($measurement$045bend$058motion_sum_go$(_values_0, 0, 1, 0)), ($measurement$045bend$058motion_views$(_world_0)));
}

function $measurement$045bend$058motion_views$(_world_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058each$1260$({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/query.Optional"}, _world_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_storage_mark_loop$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14) {
  for (;;) {
    {
      const _marks_0 = $0;
      const _namespace_0 = $1;
      const _next_0 = $2;
      const _main_0 = $3;
      const _aux_0 = $4;
      const _flags_0 = $5;
      const _added_0 = $6;
      const _transport_0 = $7;
      const _capacity_0 = $8;
      const _depth_0 = $9;
      const _high_0 = $10;
      const _pending_0 = $11;
      const _ledger_0 = $12;
      const _mode_0 = $13;
      const _tick_0 = $14;
      if (_marks_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.PrototypeFlatMarksEnd") {
        const _live_0 = _transport_0["fst"];
        const _changed_0 = _transport_0["snd"];
        return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0};
      } else {
        const _foreign_0 = _marks_0["namespace"];
        const _id_0 = _marks_0["id"];
        const _rest_0 = _marks_0["tail"];
        const _live_1 = _transport_0["fst"];
        const _changed_1 = _transport_0["snd"];
        $0 = _rest_0;
        $1 = _namespace_0;
        $2 = _next_0;
        $3 = _main_0;
        $4 = _aux_0;
        $5 = _flags_0;
        $6 = _added_0;
        $7 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_storage_mark_guard$(($Bool$and$((_namespace_0 === _foreign_0), ($Bool$and$((0 < _id_0), ($Bool$and$((_id_0 <= _capacity_0), (_id_0 <= _high_0))))))), _live_1, _changed_1, _id_0, _tick_0));
        $8 = _capacity_0;
        $9 = _depth_0;
        $10 = _high_0;
        $11 = _pending_0;
        $12 = _ledger_0;
        $13 = _mode_0;
        $14 = _tick_0;
        continue;
      }
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_step$1260$(_handle_0, _state_0) {
  const _space_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  const _ns_0 = _state_0["namespace"];
  const _next_0 = _state_0["next"];
  const _columns_0 = _state_0["columns"];
  const _aux_0 = _state_0["aux"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _depth_0 = _state_0["depth"];
  const _high_0 = _state_0["high"];
  const _pending_0 = _state_0["pending"];
  const _ledger_0 = _state_0["ledger"];
  const _mode_0 = _state_0["mode"];
  const _undo_0 = _state_0["undo"];
  const _commands_0 = _state_0["commands"];
  const _pings_0 = _state_0["pings"];
  const _marks_0 = _state_0["marks"];
  const _total_0 = _state_0["total"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_guard$1260$(($Bool$and$((_ns_0 === _space_0), ($Bool$and$((0 < _id_0), ($Bool$and$((_id_0 <= _capacity_0), (_id_0 <= _high_0))))))), _id_0, _ns_0, _next_0, _columns_0, _aux_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Handle", "namespace": _space_0, "id": _id_0}, _undo_0, _commands_0, _pings_0, _marks_0, _total_0, _metadata_0, _ledger_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058struct_cols_finish$(_capacity_0, _depth_0, _high_0, _state_0) {
  const _main_0 = _state_0["main"];
  const _aux_0 = _state_0["aux"];
  const _live_0 = _state_0["live"];
  const _flags_0 = _state_0["flags"];
  const _added_0 = _state_0["added"];
  const _changed_0 = _state_0["changed"];
  const _values_0 = _state_0["values"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058struct_idx_finish$(_capacity_0, _depth_0, _high_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/query.StructIdxState", "main": _main_0, "aux": _aux_0, "metadata": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "values": _values_0});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058prototype_identity_struct_idx_advance$1260$(_valid_0, _id_0, _namespace_0, _selection_0, _state_0) {
  if (!_valid_0) {
    return _state_0;
  } else {
    const _main_0 = _state_0["main"];
    const _aux_0 = _state_0["aux"];
    const _live_0 = _state_0["live"];
    const _flags_0 = _state_0["flags"];
    const _added_0 = _state_0["added"];
    const _changed_0 = _state_0["changed"];
    const _values_0 = _state_0["values"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    return __direct_tuple_helper_13(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, (_live_0), (_live_0[_x_0 % _live_0.length]));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058place_meta$(_main_0, _aux_0, _capacity_0, _depth_0, _high_0, _row_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _meta_0 = _result_0["snd"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058place_metadata$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _row_0, _meta_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058metadata_live$(_columns_0, _index_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  return __direct_tuple_helper_14(_flags_0, _added_0, _changed_0, (_live_0), (_live_0[_index_0 % _live_0.length]));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058slots_empty$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _d_0 = (_depth_0 - 1);
    return array_node(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058slots_empty$(_d_0)), ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058slots_empty$(_d_0)));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058metadata_grow$(_columns_0, _depth_0) {
  const _live_0 = _columns_0["live"];
  const _flags_0 = _columns_0["flags"];
  const _added_0 = _columns_0["added"];
  const _changed_0 = _columns_0["changed"];
  const _x_0 = {$: "None"};
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.MetadataColumns", "live": array_node(_live_0, array_new(_depth_0, false)), "flags": array_node(_flags_0, array_new(_depth_0, _x_0)), "added": array_node(_added_0, array_new(_depth_0, 0)), "changed": array_node(_changed_0, array_new(_depth_0, 0))};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058replace_main_done$(_id_0, _tick_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _insert_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058replace_main_effect$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _insert_0, _old_0);
}

function $measurement$045bend$058motion_query2$(_total_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _values_0 = _pair_0["snd"];
  const _x_0 = run_loop($measurement$045bend$058motion_sum_go$(_values_0, 1, 1, 0));
  const _x_1 = (Math.imul(3, _x_0) >>> 0);
  return $measurement$045bend$058motion_query3$(((_total_0 + _x_1) >>> 0), ($measurement$045bend$058motion_views$(_world_0)));
}

function $measurement$045bend$058motion_sum_go$(_values_0, _kind_0, _index_0, _total_0) {
  if (_values_0.$ === "Nil") {
    return ((_total_0 + _index_0) >>> 0);
  } else {
    const _head_0 = _values_0["head"];
    const _tail_0 = _values_0["tail"];
    return $measurement$045bend$058motion_sum_next$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $measurement$045bend$058motion_sum_go$(_tail_0, _kind_0, _x_0, _x_1);
});
}), ($measurement$045bend$058motion_score$(($measurement$045bend$058motion_included$(_kind_0, _head_0)), _head_0, _index_0, _total_0)));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058each$1260$(_selection_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058each_return$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058read_rows$1260$(_rows_0, _selection_0, _namespace_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_storage_mark_guard$(_valid_0, _live_0, _changed_0, _id_0, _tick_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _live_0, "snd": _changed_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return __direct_tuple_helper_15(_changed_0, ((_id_0 - 1) >>> 0), _tick_0, (_live_0), (_live_0[_x_0 % _live_0.length]));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_guard$1260$(_valid_0, _id_0, _ns_0, _next_0, _columns_0, _aux_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0, _metadata_0, _ledger_0) {
  if (_valid_0) {
    if (_ledger_0.$ === "Some") {
      const _ledger_1 = _ledger_0["value"];
      return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_live$1260$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058metadata_live$(_metadata_0, ((_id_0 - 1) >>> 0))), _ledger_1, _ns_0, _next_0, _columns_0, _aux_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0, _id_0);
    } else {
      return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_fallback$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body$1260$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_unpack$1260$({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.PrototypeFlatTx", "world": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})))), _total_0);
    }
  } else {
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_fallback$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body$1260$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_unpack$1260$({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.PrototypeFlatTx", "world": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})))), _total_0);
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058struct_idx_finish$(_capacity_0, _depth_0, _high_0, _state_0) {
  const _main_0 = _state_0["main"];
  const _aux_0 = _state_0["aux"];
  const _metadata_0 = _state_0["metadata"];
  const _values_0 = _state_0["values"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": ($List$reverse$(_values_0))};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058prototype_identity_struct_cols_live$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return __direct_tuple_helper_16(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, true, (_flags_0), (_flags_0[_x_0 % _flags_0.length]));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058place_metadata$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _row_0, _meta_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058place_status$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _meta_0, _row_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058metadata_live_done$(_flags_0, _added_0, _changed_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "snd": _value_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058replace_main_effect$(_id_0, _tick_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _flag_0, _added_0, _changed_0, _insert_0, _old_0) {
  if (!_insert_0) {
    if (_old_0.$ === "None") {
      return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.NoMainChange"}};
    } else {
      return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Metadata", "live": true, "flag": _flag_0, "added": 0, "changed": 0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.RemovedMain"}};
    }
  } else {
    if (_old_0.$ === "None") {
      return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Metadata", "live": true, "flag": _flag_0, "added": _tick_0, "changed": _tick_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.AddedMain"}};
    } else {
      return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Metadata", "live": true, "flag": _flag_0, "added": _added_0, "changed": _tick_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.ChangedMain"}};
    }
  }
}

function $measurement$045bend$058motion_query3$(_total_0, _pair_0) {
  const _world_0 = _pair_0["fst"];
  const _values_0 = _pair_0["snd"];
  const _x_0 = run_loop($measurement$045bend$058motion_sum_go$(_values_0, 2, 1, 0));
  const _x_1 = (Math.imul(5, _x_0) >>> 0);
  return {$: "Tuple", "fst": _world_0, "snd": ((_total_0 + _x_1) >>> 0)};
}

function $measurement$045bend$058motion_sum_next$(_ih_0, _pair_0) {
  const _index_0 = _pair_0["fst"];
  const _total_0 = _pair_0["snd"];
  return run_tail(_ih_0(_index_0), _total_0);
}

function $measurement$045bend$058motion_score$(_included_0, _value_0, _index_0, _total_0) {
  if (!_included_0) {
    return {$: "Tuple", "fst": _index_0, "snd": _total_0};
  } else {
    const _x_0 = ($measurement$045bend$058motion_row_sum$(_value_0));
    const _x_1 = (Math.imul(_index_0, _x_0) >>> 0);
    return {$: "Tuple", "fst": ((_index_0 + 1) >>> 0), "snd": ((_total_0 + _x_1) >>> 0)};
  }
}

function $measurement$045bend$058motion_included$(_kind_0, _value_0) {
  if (_kind_0 == 1) {
    const _aux_0 = _value_0["aux"];
    return $measurement$045bend$058motion_has_aux$(_aux_0);
  } else if ((_kind_0 & 1) == 1) {
    return true;
  } else if (_kind_0 == 2) {
    const _aux_1 = _value_0["aux"];
    return $Bool$not$(($measurement$045bend$058motion_has_aux$(_aux_1)));
  } else {
    return true;
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058read_rows$1260$(_rows_0, _selection_0, _namespace_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _t_0 = _rows_0["metadata"];
  const _live_0 = _t_0["live"];
  const _flags_0 = _t_0["flags"];
  const _added_0 = _t_0["added"];
  const _changed_0 = _t_0["changed"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058struct_idx_go$1260$(_high_0, 1, _capacity_0, _depth_0, _high_0, _selection_0, _namespace_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": {$: "Nil"}});
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_storage_mark_live$(_changed_0, _index_0, _tick_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _live_0, "snd": _changed_0};
  } else {
    return {$: "Tuple", "fst": _live_0, "snd": (_changed_0[_index_0 % _changed_0.length] = _tick_0, _changed_0)};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_live$1260$(_result_0, _ledger_0, _ns_0, _next_0, _columns_0, _aux_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0, _id_0) {
  const _metadata_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_fallback$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body$1260$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_unpack$1260$({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.PrototypeFlatTx", "world": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": {$: "Some", "value": _ledger_0}, "mode": _mode_0}, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})))), _total_0);
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_taken$1260$(array_rmw(_columns_0, _x_0, () => _x_1), _ledger_0, _ns_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0);
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_fallback$(_result_0, _total_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_unpack$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_converted$(_result_0)), _total_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body$1260$(_owner_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body_read$1260$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_read_main$(_owner_0, __pool_token_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_unpack$1260$(_owner_0) {
  const _world_0 = _owner_0["world"];
  const _selected_0 = _owner_0["selected"];
  const _undo_0 = _owner_0["undo"];
  const _commands_0 = _owner_0["commands"];
  const _pings_0 = _owner_0["pings"];
  const _marks_0 = _owner_0["marks"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_inverse_unpack$1260$(_undo_0)), "commands": _commands_0, "pings": _pings_0, "marks": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_mark_unpack$1260$(_marks_0))};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058prototype_identity_struct_idx_metadata$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, _value_0, _result_0) {
  if (!_value_0) {
    const _flags_0 = _result_0["fst"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _flags_1 = _result_0["fst"];
    const _flag_0 = _result_0["snd"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058prototype_identity_struct_idx_selected$1260$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058selected$(_selection_0, _flag_0)), _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_1, _added_0, _changed_0, _values_0, _flag_0);
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058place_status$(_main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _live_0, _row_0) {
  if (_live_0) {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rejected", "rows": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "row": _row_0};
  } else {
    const _id_0 = _row_0["id"];
    const _m_0 = _row_0["main"];
    const _a_0 = _row_0["aux"];
    const _f_0 = _row_0["flag"];
    const _added_0 = _row_0["added"];
    const _changed_0 = _row_0["changed"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = ((_id_0 - 1) >>> 0);
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Placed", "rows": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": (_main_0[_x_0 % _main_0.length] = _m_0, _main_0), "aux": (_aux_0[_x_1 % _aux_0.length] = _a_0, _aux_0), "metadata": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058metadata_set$(_metadata_0, ((_id_0 - 1) >>> 0), {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Metadata", "live": true, "flag": _f_0, "added": _added_0, "changed": _changed_0})), "capacity": _capacity_0, "depth": _depth_0, "high_water": ($U32$max$(_high_0, _id_0))}};
  }
}

function $measurement$045bend$058motion_row_sum$(_value_0) {
  const _t_0 = _value_0["handle"];
  const _namespace_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _main_0 = _value_0["main"];
  const _aux_0 = _value_0["aux"];
  const _flag_0 = _value_0["flag"];
  const _x_0 = ($measurement$045bend$058motion_aux_sum$(_aux_0));
  const _x_1 = ($measurement$045bend$058motion_flag_sum$(_flag_0));
  const _x_2 = ($measurement$045bend$058motion_main_sum$(_main_0));
  const _x_3 = ((_x_0 + _x_1) >>> 0);
  const _x_4 = ((_namespace_0 + _id_0) >>> 0);
  const _x_5 = ((_x_2 + _x_3) >>> 0);
  return ((_x_4 + _x_5) >>> 0);
}

function $measurement$045bend$058motion_has_aux$(_value_0) {
  if (_value_0.$ === "None") {
    return false;
  } else {
    return true;
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058struct_idx_go$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _id_0 = $1;
      const _capacity_0 = $2;
      const _depth_0 = $3;
      const _high_0 = $4;
      const _selection_0 = $5;
      const _namespace_0 = $6;
      const _state_0 = $7;
      if (_remaining_0 === 0) {
        return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058struct_cols_finish$(_capacity_0, _depth_0, _high_0, _state_0);
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = ((_id_0 + 1) >>> 0);
        $2 = _capacity_0;
        $3 = _depth_0;
        $4 = _high_0;
        $5 = _selection_0;
        $6 = _namespace_0;
        $7 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058struct_idx_advance$1260$(($Bool$and$((0 < _id_0), (_id_0 <= _capacity_0))), _id_0, _namespace_0, _selection_0, _state_0));
        continue;
      }
    }
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_taken$1260$(_result_0, _ledger_0, _ns_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, _selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _total_0) {
  const _columns_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Some") {
    const _t_1 = _t_0["value"];
    const _main_raw_0 = _t_1["raw"];
    const _main_cached_0 = _t_1["cached"];
    const _ledger_raw_0 = _ledger_0["raw"];
    const _ledger_cached_0 = _ledger_0["cached"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_returned$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatrows_motion_invoke$1260$({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/held-adapter.PrototypeFlatRowOwner", "main_raw": _main_raw_0, "main_cached": _main_cached_0, "ledger_raw": _ledger_raw_0, "ledger_cached": _ledger_cached_0, "handle": _selected_0, "undo": _undo_0, "marks": _marks_0})), _ns_0, _next_0, _columns_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, _commands_0, _pings_0, _total_0);
  } else {
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_fallback$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body$1260$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_unpack$1260$({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.PrototypeFlatTx", "world": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _ns_0, "next": _next_0, "rows": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": {$: "Some", "value": _ledger_0}, "mode": _mode_0}, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0})))), _total_0);
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_unpack$(_result_0, _total_0) {
  const _t_0 = _result_0["fst"];
  const _t_1 = _t_0["world"];
  const _ns_0 = _t_1["namespace"];
  const _next_0 = _t_1["next"];
  const _t_2 = _t_1["rows"];
  const _columns_0 = _t_2["main"];
  const _aux_0 = _t_2["aux"];
  const _metadata_0 = _t_2["metadata"];
  const _capacity_0 = _t_2["capacity"];
  const _depth_0 = _t_2["depth"];
  const _high_0 = _t_2["high_water"];
  const _pending_0 = _t_1["pending"];
  const _ledger_0 = _t_1["ledger"];
  const _mode_0 = _t_1["mode"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  const _value_0 = _result_0["snd"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/held-adapter.PrototypeFlatFold", "namespace": _ns_0, "next": _next_0, "columns": _columns_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high": _high_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0, "total": ((_total_0 + _value_0) >>> 0)};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_converted$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_pack$1260$(_owner_0)), "snd": _value_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body_read$1260$(_pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Found") {
    const _t_1 = _t_0["value"];
    const _values_0 = _t_1["coordinates"];
    const _x_0 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047prototype$045static$045client$058first$(_values_0));
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body_ledger$1260$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047prototype$045static$045client$058sum$(_values_0)), ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_read_ledger$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_set_main0$(_owner_0, __pool_token_0, ((_x_0 + 1) >>> 0))), __pool_token_1)));
  } else {
    return {$: "Tuple", "fst": _owner_0, "snd": 4294967295};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_read_main$(_t_0, _token_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058tx_read_main$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_world_read$(_x_0, _x_1);
});
}), _t_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_inverse_unpack$1260$(_values_0) {
  if (_values_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.PrototypeFlatEnd") {
    return {$: "Nil"};
  } else if (_values_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.PrototypeFlatMain") {
    const _space_0 = _values_0["namespace"];
    const _id_0 = _values_0["id"];
    const _old_0 = _values_0["old"];
    const _tail_0 = _values_0["tail"];
    return {$: "Con", "head": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.MainInverse", "handle": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Handle", "namespace": _space_0, "id": _id_0}, "old": _old_0}, "tail": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_inverse_unpack$1260$(_tail_0))};
  } else {
    const _old_1 = _values_0["old"];
    const _tail_1 = _values_0["tail"];
    return {$: "Con", "head": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.LedgerInverse", "old": _old_1}, "tail": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_inverse_unpack$1260$(_tail_1))};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_mark_unpack$1260$(_values_0) {
  if (_values_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.PrototypeFlatMarksEnd") {
    return {$: "Nil"};
  } else {
    const _space_0 = _values_0["namespace"];
    const _id_0 = _values_0["id"];
    const _tail_0 = _values_0["tail"];
    return {$: "Con", "head": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Handle", "namespace": _space_0, "id": _id_0}, "tail": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058prototype_flat_mark_unpack$1260$(_tail_0))};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058prototype_identity_struct_idx_selected$1260$(_include_0, _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0) {
  if (!_include_0) {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058prototype_identity_inspect_state$(_id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0);
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058selected$(_selection_0, _flag_0) {
  if (_selection_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/query.Present") {
    if (_flag_0.$ === "None") {
      return false;
    } else {
      return true;
    }
  } else if (_selection_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/query.Absent") {
    if (_flag_0.$ === "Some") {
      return false;
    } else {
      return true;
    }
  } else {
    return true;
  }
}

function $U32$max$(_a_0, _b_0) {
  return $Bool$pick$((_a_0 < _b_0), _b_0, _a_0);
}

function $measurement$045bend$058motion_main_sum$(_value_0) {
  const _values_0 = _value_0["coordinates"];
  const _meta_0 = _value_0["frame"];
  const _x_0 = ($measurement$045bend$058sum$(_values_0));
  return ((_x_0 + _meta_0) >>> 0);
}

function $measurement$045bend$058motion_aux_sum$(_value_0) {
  if (_value_0.$ === "None") {
    return 0;
  } else {
    const _t_0 = _value_0["value"];
    const _values_0 = _t_0["rates"];
    const _moving_0 = _t_0["moving"];
    const _x_0 = ($measurement$045bend$058boolnum$(_moving_0));
    const _x_1 = ($measurement$045bend$058sum$(_values_0));
    const _x_2 = ((_x_0 + 1) >>> 0);
    return ((_x_1 + _x_2) >>> 0);
  }
}

function $measurement$045bend$058motion_flag_sum$(_value_0) {
  if (_value_0.$ === "None") {
    return 0;
  } else {
    const _t_0 = _value_0["value"];
    const _group_0 = _t_0["group"];
    return ((_group_0 + 1) >>> 0);
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058struct_idx_advance$1260$(_valid_0, _id_0, _namespace_0, _selection_0, _state_0) {
  if (!_valid_0) {
    return _state_0;
  } else {
    const _main_0 = _state_0["main"];
    const _aux_0 = _state_0["aux"];
    const _live_0 = _state_0["live"];
    const _flags_0 = _state_0["flags"];
    const _added_0 = _state_0["added"];
    const _changed_0 = _state_0["changed"];
    const _values_0 = _state_0["values"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    return __direct_tuple_helper_17(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, (_live_0), (_live_0[_x_0 % _live_0.length]));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatfold_motion_returned$(_result_0, _ns_0, _next_0, _columns_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _mode_0, _commands_0, _pings_0, _total_0) {
  const _t_0 = _result_0["fst"];
  const _main_raw_0 = _t_0["main_raw"];
  const _main_cached_0 = _t_0["main_cached"];
  const _ledger_raw_0 = _t_0["ledger_raw"];
  const _ledger_cached_0 = _t_0["ledger_cached"];
  const _t_1 = _t_0["handle"];
  const _space_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _undo_0 = _t_0["undo"];
  const _marks_0 = _t_0["marks"];
  const _value_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/cache.Cache", "raw": _main_raw_0, "cached": _main_cached_0}};
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/held-adapter.PrototypeFlatFold", "namespace": _ns_0, "next": _next_0, "columns": (_columns_0[_x_0 % _columns_0.length] = _x_1, _columns_0), "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high": _high_0, "pending": _pending_0, "ledger": {$: "Some", "value": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/cache.Cache", "raw": _ledger_raw_0, "cached": _ledger_cached_0}}, "mode": _mode_0, "selected": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Handle", "namespace": _space_0, "id": _id_0}, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0, "total": ((_total_0 + _value_0) >>> 0)};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatrows_motion_invoke$1260$(_owner_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body$1262$(_owner_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body_ledger$1260$(_readsum_0, _pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "Some") {
    const _t_1 = _t_0["value"];
    const _values_0 = _t_1["totals"];
    const _x_0 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047prototype$045static$045client$058first$(_values_0));
    return {$: "Tuple", "fst": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_set_ledger0$(_owner_0, __pool_token_1, ((_x_0 + 1) >>> 0))), "snd": _readsum_0};
  } else {
    return {$: "Tuple", "fst": _owner_0, "snd": 4294967295};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047prototype$045static$045client$058sum$(_value_0) {
  const _a_0 = _value_0["a"];
  const _b_0 = _value_0["b"];
  const _c_0 = _value_0["c"];
  const _d_0 = _value_0["d"];
  const _x_0 = ((_a_0 + _b_0) >>> 0);
  const _x_1 = ((_c_0 + _d_0) >>> 0);
  return ((_x_0 + _x_1) >>> 0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_read_ledger$(_t_0, _token_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058tx_read_ledger$(run_clo((_x_0) => {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_world_ledger_read$(_x_0);
}), _t_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_set_main0$(_t_0, _token_0, _value_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058tx_set_main0$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_world_write$(_x_0, _x_1, _x_2);
});
});
}), _t_0, _value_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047prototype$045static$045client$058first$(_value_0) {
  const _a_0 = _value_0["a"];
  return _a_0;
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058tx_read_main$(_read_0, _t_0) {
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058read_main_finish$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _read_0(_world_0)(_selected_0));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_world_read$(_world_0, _handle_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058with_main$(_world_0, _handle_0, run_clo((_x_0) => {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058position_get$(_x_0);
}));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058prototype_identity_inspect_state$(_id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0) {
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "None"};
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058prototype_identity_restore_state$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, array_rmw(_main_0, _x_0, () => _x_1));
}

function $Bool$pick$(_c_0, _a_0, _b_0) {
  if (!_c_0) {
    return _b_0;
  } else {
    return _a_0;
  }
}

function $measurement$045bend$058sum$(_value_0) {
  const _a_0 = _value_0["a"];
  const _b_0 = _value_0["b"];
  const _c_0 = _value_0["c"];
  const _d_0 = _value_0["d"];
  const _x_0 = ((_a_0 + _b_0) >>> 0);
  const _x_1 = ((_c_0 + _d_0) >>> 0);
  return ((_x_0 + _x_1) >>> 0);
}

function $measurement$045bend$058boolnum$(_value_0) {
  if (_value_0) {
    return 1;
  } else {
    return 0;
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058struct_cols_live$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return __direct_tuple_helper_18(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, true, (_flags_0), (_flags_0[_x_0 % _flags_0.length]));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body$1262$(_owner_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body_read$1262$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatrows_motion_get$(_owner_0, __pool_token_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_set_ledger0$(_t_0, _token_0, _value_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058tx_set_ledger0$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_world_ledger_write$(_x_0, _x_1);
});
}), _t_0, _value_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058tx_read_ledger$(_read_0, _t_0) {
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058read_ledger_finish$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _read_0(_world_0));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_world_ledger_read$(_world_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058with_ledger$(_world_0, run_clo((_x_0) => {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058motion_ledger_get$(_x_0);
}));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058tx_set_main0$(_write_0, _t_0, _value_0) {
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058record_main$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _write_0(_world_0)(_selected_0)(_value_0));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_world_write$(_world_0, _handle_0, _value_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058storage_set_main0$1260$(_world_0, _handle_0, _value_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058read_main_finish$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}, "snd": _view_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058with_main$(_world_0, _handle_0, _transform_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  const _foreign_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058hook_checked$((_namespace_0 === _foreign_0), {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, _id_0, _transform_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058prototype_identity_restore_state$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _owner_0 = _t_0["value"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/query.StructColsState", "main": (_main_0[_x_0 % _main_0.length] = _x_1, _main_0), "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": {$: "Con", "head": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _values_0}};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058struct_idx_metadata$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, _value_0, _result_0) {
  if (!_value_0) {
    const _flags_0 = _result_0["fst"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _flags_1 = _result_0["fst"];
    const _flag_0 = _result_0["snd"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058struct_idx_selected$1260$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058selected$(_selection_0, _flag_0)), _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_1, _added_0, _changed_0, _values_0, _flag_0);
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body_read$1262$(_pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Found") {
    const _t_1 = _t_0["value"];
    const _values_0 = _t_1["coordinates"];
    const _x_0 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047prototype$045static$045client$058first$(_values_0));
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body_ledger$1262$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047prototype$045static$045client$058sum$(_values_0)), ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatrows_motion_ledger$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatrows_motion_set$(_owner_0, __pool_token_0, ((_x_0 + 1) >>> 0))), __pool_token_1)));
  } else {
    return {$: "Tuple", "fst": _owner_0, "snd": 4294967295};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatrows_motion_get$(_owner_0, _token_0) {
  const _raw_0 = _owner_0["main_raw"];
  const _cached_0 = _owner_0["main_cached"];
  const _ledger_raw_0 = _owner_0["ledger_raw"];
  const _ledger_cached_0 = _owner_0["ledger_cached"];
  const _handle_0 = _owner_0["handle"];
  const _undo_0 = _owner_0["undo"];
  const _marks_0 = _owner_0["marks"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Found", "value": _cached_0}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058tx_set_ledger0$(_write_0, _t_0, _value_0) {
  const _world_0 = _t_0["world"];
  const _selected_0 = _t_0["selected"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _pings_0 = _t_0["pings"];
  const _marks_0 = _t_0["marks"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058record_ledger$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _write_0(_world_0)(_value_0));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$045dispatch$045adapters$058motion_world_ledger_write$(_world_0, _value_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058storage_set_ledger0$1260$(_world_0, _value_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058read_ledger_finish$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0}, "snd": _view_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058with_ledger$(_world_0, _transform_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _t_0 = _world_0["ledger"];
  if (_t_0.$ === "None") {
    const _mode_0 = _world_0["mode"];
    return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": {$: "None"}, "mode": _mode_0}, "snd": {$: "None"}};
  } else {
    const _ledger_0 = _t_0["value"];
    const _mode_1 = _world_0["mode"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058ledger_return$(_namespace_0, _next_0, _rows_0, _pending_0, _mode_1, _transform_0(_ledger_0));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058record_main$(_handle_0, _undo_0, _commands_0, _pings_0, _marks_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Found") {
    const _old_0 = _t_0["value"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _handle_0, "undo": {$: "Con", "head": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.MainInverse", "handle": _handle_0, "old": _old_0}, "tail": _undo_0}, "commands": _commands_0, "pings": _pings_0, "marks": {$: "Con", "head": _handle_0, "tail": _marks_0}};
  } else {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _handle_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058storage_set_main0$1260$(_world_0, _handle_0, _value_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058with_main$(_world_0, _handle_0, run_clo((_x_0) => {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058position_swap$(_x_0, _value_0);
}));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058hook_checked$(_valid_0, _world_0, _target_0, _transform_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Missing"}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _t_0 = _world_0["rows"];
    const _main_0 = _t_0["main"];
    const _aux_0 = _t_0["aux"];
    const _metadata_0 = _t_0["metadata"];
    const _capacity_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _high_0 = _t_0["high_water"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058fuse_bounds$(($Bool$and$((0 < _target_0), ($Bool$and$((_target_0 <= _capacity_0), (_target_0 <= _high_0))))), {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, _target_0, _transform_0);
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058struct_idx_selected$1260$(_include_0, _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0) {
  if (!_include_0) {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058struct_idx_main$1260$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, array_rmw(_main_0, _x_0, () => _x_1));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047prototype$045static$045client$058motion_body_ledger$1262$(_readsum_0, _pair_0) {
  const _owner_0 = _pair_0["fst"];
  const _t_0 = _pair_0["snd"];
  if (_t_0.$ === "Some") {
    const _t_1 = _t_0["value"];
    const _values_0 = _t_1["totals"];
    const _x_0 = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047prototype$045static$045client$058first$(_values_0));
    return {$: "Tuple", "fst": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatrows_motion_setledger$(_owner_0, __pool_token_1, ((_x_0 + 1) >>> 0))), "snd": _readsum_0};
  } else {
    return {$: "Tuple", "fst": _owner_0, "snd": 4294967295};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatrows_motion_ledger$(_owner_0, _token_0) {
  const _main_raw_0 = _owner_0["main_raw"];
  const _main_cached_0 = _owner_0["main_cached"];
  const _raw_0 = _owner_0["ledger_raw"];
  const _cached_0 = _owner_0["ledger_cached"];
  const _handle_0 = _owner_0["handle"];
  const _undo_0 = _owner_0["undo"];
  const _marks_0 = _owner_0["marks"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Some", "value": _cached_0}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatrows_motion_set$(_owner_0, _token_0, _value_0) {
  const _raw_0 = _owner_0["main_raw"];
  const _cached_0 = _owner_0["main_cached"];
  const _ledger_raw_0 = _owner_0["ledger_raw"];
  const _ledger_cached_0 = _owner_0["ledger_cached"];
  const _handle_0 = _owner_0["handle"];
  const _undo_0 = _owner_0["undo"];
  const _marks_0 = _owner_0["marks"];
  const _value_1 = _value_0;
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatrows_motion_set_fused_done$(_ledger_raw_0, _ledger_cached_0, _handle_0, _undo_0, _marks_0, _cached_0, _value_1, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058prototype_position_raw_swap$(_raw_0, _value_1)), _owner_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058record_ledger$(_selected_0, _undo_0, _commands_0, _pings_0, _marks_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Some") {
    const _old_0 = _t_0["value"];
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": {$: "Con", "head": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.LedgerInverse", "old": _old_0}, "tail": _undo_0}, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0};
  } else {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.Tx", "world": _world_0, "selected": _selected_0, "undo": _undo_0, "commands": _commands_0, "pings": _pings_0, "marks": _marks_0};
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047transaction$058storage_set_ledger0$1260$(_world_0, _value_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058with_ledger$(_world_0, run_clo((_x_0) => {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058motion_ledger_swap$(_x_0, _value_0);
}));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058ledger_return$(_namespace_0, _next_0, _rows_0, _pending_0, _mode_0, _result_0) {
  const _ledger_0 = _result_0["fst"];
  const _observation_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": {$: "Some", "value": _ledger_0}, "mode": _mode_0}, "snd": {$: "Some", "value": _observation_0}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058position_swap$(_owner_0, _value_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cache$058static_swap$1260$(_owner_0, _value_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058fuse_bounds$(_valid_0, _world_0, _target_0, _transform_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Missing"}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _next_0 = _world_0["next"];
    const _t_0 = _world_0["rows"];
    const _main_0 = _t_0["main"];
    const _aux_0 = _t_0["aux"];
    const _metadata_0 = _t_0["metadata"];
    const _capacity_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _high_0 = _t_0["high_water"];
    const _pending_0 = _world_0["pending"];
    const _ledger_0 = _world_0["ledger"];
    const _mode_0 = _world_0["mode"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058prototype_fuse_columns$(_namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, ((_target_0 - 1) >>> 0), _transform_0);
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058struct_idx_main$1260$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _owner_0 = _t_0["value"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058struct_idx_aux$1260$(_id_0, _namespace_0, _main_0, _owner_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, array_rmw(_aux_0, _x_0, () => _x_1));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatrows_motion_setledger$(_owner_0, _token_0, _value_0) {
  const _main_raw_0 = _owner_0["main_raw"];
  const _main_cached_0 = _owner_0["main_cached"];
  const _raw_0 = _owner_0["ledger_raw"];
  const _cached_0 = _owner_0["ledger_cached"];
  const _handle_0 = _owner_0["handle"];
  const _undo_0 = _owner_0["undo"];
  const _marks_0 = _owner_0["marks"];
  const _value_1 = _value_0;
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatrows_motion_setledger_fused_done$(_main_raw_0, _main_cached_0, _handle_0, _undo_0, _marks_0, _cached_0, _value_1, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058prototype_motion_ledger_raw_swap$(_raw_0, _value_1)), _owner_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatrows_motion_set_fused_done$(_ledger_raw_0, _ledger_cached_0, _handle_0, _undo_0, _marks_0, _cached_0, _value_0, _result_0, __row_reuse_owner) {
  const _space_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  const _raw_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  const __row_reuse_main_raw = (_raw_0);
const __row_reuse_main_cached = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058position_patch$(_cached_0, _value_0));
const __row_reuse_ledger_raw = (_ledger_raw_0);
const __row_reuse_ledger_cached = (_ledger_cached_0);
const __row_reuse_handle = ({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Handle", "namespace": _space_0, "id": _id_0});
const __row_reuse_undo = ({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.PrototypeFlatMain", "namespace": _space_0, "id": _id_0, "old": _old_0, "tail": _undo_0});
const __row_reuse_marks = ({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.PrototypeFlatMark", "namespace": _space_0, "id": _id_0, "tail": _marks_0});
__row_reuse_owner["main_raw"] = __row_reuse_main_raw;
__row_reuse_owner["main_cached"] = __row_reuse_main_cached;
__row_reuse_owner["handle"] = __row_reuse_handle;
__row_reuse_owner["undo"] = __row_reuse_undo;
__row_reuse_owner["marks"] = __row_reuse_marks;
return __row_reuse_owner;
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058prototype_position_raw_swap$(_owner_0, _value_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058position_swap$(_owner_0, _value_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058motion_ledger_swap$(_owner_0, _value_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cache$058static_swap$1262$(_owner_0, _value_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cache$058static_swap$1260$(_owner_0, _value_0) {
  const _raw_0 = _owner_0["raw"];
  const _cached_0 = _owner_0["cached"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cache$058static_swap_done$1260$(_cached_0, _value_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058position_swap$(_raw_0, _value_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058prototype_fuse_columns$(_namespace_0, _next_0, _main_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0) {
  const _live_0 = _metadata_0["live"];
  const _flags_0 = _metadata_0["flags"];
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  return __direct_tuple_helper_19(_namespace_0, _next_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, (_live_0), (_live_0[_index_0 % _live_0.length]));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058struct_idx_aux$1260$(_id_0, _namespace_0, _main_0, _owner_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058struct_idx_return$(((_id_0 - 1) >>> 0), _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058client$1260$({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Handle", "namespace": _namespace_0, "id": _id_0}, _flag_0, _owner_0, _a_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047held$045adapter$058prototype_flatrows_motion_setledger_fused_done$(_main_raw_0, _main_cached_0, _handle_0, _undo_0, _marks_0, _cached_0, _value_0, _result_0, __row_reuse_owner) {
  const _raw_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  const __row_reuse_main_raw = (_main_raw_0);
const __row_reuse_main_cached = (_main_cached_0);
const __row_reuse_ledger_raw = (_raw_0);
const __row_reuse_ledger_cached = ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058motion_ledger_patch$(_cached_0, _value_0));
const __row_reuse_handle = (_handle_0);
const __row_reuse_undo = ({$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/transaction.PrototypeFlatLedger", "old": _old_0, "tail": _undo_0});
const __row_reuse_marks = (_marks_0);
__row_reuse_owner["ledger_raw"] = __row_reuse_ledger_raw;
__row_reuse_owner["ledger_cached"] = __row_reuse_ledger_cached;
__row_reuse_owner["undo"] = __row_reuse_undo;
return __row_reuse_owner;
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058prototype_motion_ledger_raw_swap$(_owner_0, _value_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058motion_ledger_swap$(_owner_0, _value_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058position_patch$(_view_0, _value_0) {
  const _t_0 = _view_0["coordinates"];
  const _b_0 = _t_0["b"];
  const _c_0 = _t_0["c"];
  const _d_0 = _t_0["d"];
  const _frame_0 = _view_0["frame"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.PositionView", "coordinates": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Four", "a": _value_0, "b": _b_0, "c": _c_0, "d": _d_0}, "frame": _frame_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058position_swap$(_owner_0, _value_0) {
  const _array_0 = _owner_0["coordinates"];
  const _frame_0 = _owner_0["frame"];
  return __direct_tuple_helper_20(_frame_0, _value_0, (_array_0), (_array_0[0 % _array_0.length]));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cache$058static_swap$1262$(_owner_0, _value_0) {
  const _raw_0 = _owner_0["raw"];
  const _cached_0 = _owner_0["cached"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cache$058static_swap_done$1262$(_cached_0, _value_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058motion_ledger_swap$(_raw_0, _value_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cache$058static_swap_done$1260$(_cached_0, _value_0, _result_0) {
  const _raw_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/cache.Cache", "raw": _raw_0, "cached": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058position_patch$(_cached_0, _value_0))}, "snd": _old_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058prototype_fuse_live_result$(_namespace_0, _next_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058fuse_live$(_namespace_0, _next_0, _aux_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0, _value_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058struct_idx_return$(_index_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _result_0) {
  const _m_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _a_0 = _t_0["fst"];
  const _value_0 = _t_0["snd"];
  const _x_0 = {$: "Some", "value": _m_0};
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/query.StructColsState", "main": (_main_0[_index_0 % _main_0.length] = _x_0, _main_0), "aux": (_aux_0[_index_0 % _aux_0.length] = _a_0, _aux_0), "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": {$: "Con", "head": _value_0, "tail": _values_0}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058client$1260$(_handle_0, _flag_0, _main_0, _aux_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058client_main$1260$(_handle_0, _flag_0, _aux_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058main_read$1260$(_main_0, __pool_token_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058motion_ledger_patch$(_view_0, _value_0) {
  const _t_0 = _view_0["totals"];
  const _b_0 = _t_0["b"];
  const _c_0 = _t_0["c"];
  const _d_0 = _t_0["d"];
  const _epoch_0 = _view_0["epoch"];
  return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.LedgerView", "totals": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Four", "a": _value_0, "b": _b_0, "c": _c_0, "d": _d_0}, "epoch": _epoch_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058motion_ledger_swap$(_owner_0, _value_0) {
  const _array_0 = _owner_0["totals"];
  const _epoch_0 = _owner_0["epoch"];
  return __direct_tuple_helper_21(_epoch_0, _value_0, (_array_0), (_array_0[0 % _array_0.length]));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058prototype_direct_position_swap$(_frame_0, _value_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Position", "coordinates": (_array_0[0 % _array_0.length] = _value_0, _array_0), "frame": _frame_0}, "snd": _old_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cache$058static_swap_done$1262$(_cached_0, _value_0, _result_0) {
  const _raw_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/cache.Cache", "raw": _raw_0, "cached": ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058motion_ledger_patch$(_cached_0, _value_0))}, "snd": _old_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058fuse_live$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0, _meta_0) {
  if (!_meta_0) {
    return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Missing"}};
  } else {
    const _x_0 = {$: "None"};
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058fuse_taken$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, array_rmw(_main_0, _index_0, () => _x_0));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058client_main$1260$(_handle_0, _flag_0, _aux_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058client_aux$(_handle_0, _flag_0, _owner_0, _value_0, ($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058aux_read$1260$(_aux_0)));
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058main_read$1260$(_owner_0, _token_0) {
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047cached$045payload$058position_get$(_owner_0);
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047uncached$045payload$058prototype_direct_motion_ledger_swap$(_epoch_0, _value_0, _result_0) {
  const _array_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.MotionLedger", "totals": (_array_0[0 % _array_0.length] = _value_0, _array_0), "epoch": _epoch_0}, "snd": _old_0};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058fuse_taken$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Mismatch"}};
  } else {
    const _value_0 = _t_0["value"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058fuse_return$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0(_value_0));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047observations$058client_aux$(_handle_0, _flag_0, _owner_0, _main_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Tuple", "fst": _aux_0, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/observations.QueryRow", "handle": _handle_0, "main": _main_0, "aux": _value_0, "flag": _flag_0}}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058aux_read$1260$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}};
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058aux_return$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047payload$058velocity_get$(_owner_1)));
  }
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058fuse_return$(_namespace_0, _next_0, _aux_0, _metadata_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _result_0) {
  const _value_0 = _result_0["fst"];
  const _observation_0 = _result_0["snd"];
  const _x_0 = {$: "Some", "value": _value_0};
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.World", "namespace": _namespace_0, "next": _next_0, "rows": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Rows", "main": (_main_0[_index_0 % _main_0.length] = _x_0, _main_0), "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Found", "value": _observation_0}};
}

function $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058aux_return$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": _owner_0}, "snd": {$: "Some", "value": _value_0}};
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);
// Private scalar receivers for exact direct Tuple edges only.

function __direct_tuple_helper_0(__direct_tuple_fst_0, __direct_tuple_snd_0) {
  const _array_0 = __direct_tuple_fst_0;
  const _a_0 = __direct_tuple_snd_0;
  return __direct_tuple_helper_1(_a_0, (_array_0), (_array_0[1 % _array_0.length]));
}

function __direct_tuple_helper_1(_a_0, __direct_tuple_fst_1, __direct_tuple_snd_1) {
  const _array_0 = __direct_tuple_fst_1;
  const _b_0 = __direct_tuple_snd_1;
  return __direct_tuple_helper_3(_a_0, _b_0, (_array_0), (_array_0[2 % _array_0.length]));
}

function __direct_tuple_helper_2(_flags_0, _added_0, _changed_0, _index_0, __direct_tuple_fst_2, __direct_tuple_snd_2) {
  const _live_0 = __direct_tuple_fst_2;
  const _l_0 = __direct_tuple_snd_2;
  return __direct_tuple_helper_5(_live_0, _added_0, _changed_0, _index_0, _l_0, (_flags_0), (_flags_0[_index_0 % _flags_0.length]));
}

function __direct_tuple_helper_3(_a_0, _b_0, __direct_tuple_fst_3, __direct_tuple_snd_3) {
  const _array_0 = __direct_tuple_fst_3;
  const _c_0 = __direct_tuple_snd_3;
  return __direct_tuple_helper_6(_a_0, _b_0, _c_0, (_array_0), (_array_0[3 % _array_0.length]));
}

function __direct_tuple_helper_4(__direct_tuple_fst_4, __direct_tuple_snd_4) {
  const _array_0 = __direct_tuple_fst_4;
  const _a_0 = __direct_tuple_snd_4;
  return __direct_tuple_helper_7(_a_0, (_array_0), (_array_0[1 % _array_0.length]));
}

function __direct_tuple_helper_5(_live_0, _added_0, _changed_0, _index_0, _l_0, __direct_tuple_fst_5, __direct_tuple_snd_5) {
  const _flags_0 = __direct_tuple_fst_5;
  const _f_0 = __direct_tuple_snd_5;
  return __direct_tuple_helper_8(_live_0, _flags_0, _changed_0, _index_0, _l_0, _f_0, (_added_0), (_added_0[_index_0 % _added_0.length]));
}

function __direct_tuple_helper_6(_a_0, _b_0, _c_0, __direct_tuple_fst_6, __direct_tuple_snd_6) {
  const _array_0 = __direct_tuple_fst_6;
  const _d_0 = __direct_tuple_snd_6;
  return {$: "Tuple", "fst": _array_0, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Four", "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0}};
}

function __direct_tuple_helper_7(_a_0, __direct_tuple_fst_7, __direct_tuple_snd_7) {
  const _array_0 = __direct_tuple_fst_7;
  const _b_0 = __direct_tuple_snd_7;
  return __direct_tuple_helper_9(_a_0, _b_0, (_array_0), (_array_0[2 % _array_0.length]));
}

function __direct_tuple_helper_8(_live_0, _flags_0, _changed_0, _index_0, _l_0, _f_0, __direct_tuple_fst_8, __direct_tuple_snd_8) {
  const _added_0 = __direct_tuple_fst_8;
  const _a_0 = __direct_tuple_snd_8;
  return __direct_tuple_helper_10(_live_0, _flags_0, _added_0, _l_0, _f_0, _a_0, (_changed_0), (_changed_0[_index_0 % _changed_0.length]));
}

function __direct_tuple_helper_9(_a_0, _b_0, __direct_tuple_fst_9, __direct_tuple_snd_9) {
  const _array_0 = __direct_tuple_fst_9;
  const _c_0 = __direct_tuple_snd_9;
  return __direct_tuple_helper_11(_a_0, _b_0, _c_0, (_array_0), (_array_0[3 % _array_0.length]));
}

function __direct_tuple_helper_10(_live_0, _flags_0, _added_0, _l_0, _f_0, _a_0, __direct_tuple_fst_10, __direct_tuple_snd_10) {
  const _changed_0 = __direct_tuple_fst_10;
  const _c_0 = __direct_tuple_snd_10;
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.Metadata", "live": _l_0, "flag": _f_0, "added": _a_0, "changed": _c_0}};
}

function __direct_tuple_helper_11(_a_0, _b_0, _c_0, __direct_tuple_fst_11, __direct_tuple_snd_11) {
  const _array_0 = __direct_tuple_fst_11;
  const _d_0 = __direct_tuple_snd_11;
  return {$: "Tuple", "fst": _array_0, "snd": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Four", "a": _a_0, "b": _b_0, "c": _c_0, "d": _d_0}};
}

function __direct_tuple_helper_12(__direct_tuple_fst_12, __direct_tuple_snd_12) {
  const _array_0 = __direct_tuple_fst_12;
  const _count_0 = __direct_tuple_snd_12;
  const _x_0 = ((_count_0 + 1) >>> 0);
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/capture.Local", "count": (_array_0[0 % _array_0.length] = _x_0, _array_0)}, "snd": ((_count_0 + 1) >>> 0)};
}

function __direct_tuple_helper_13(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, __direct_tuple_fst_13, __direct_tuple_snd_13) {
  const _live_0 = __direct_tuple_fst_13;
  const _t_0 = __direct_tuple_snd_13;
  if (!_t_0) {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return __direct_tuple_helper_16(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, true, (_flags_0), (_flags_0[_x_0 % _flags_0.length]));
  }
}

function __direct_tuple_helper_14(_flags_0, _added_0, _changed_0, __direct_tuple_fst_14, __direct_tuple_snd_14) {
  const _live_0 = __direct_tuple_fst_14;
  const _value_0 = __direct_tuple_snd_14;
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "snd": _value_0};
}

function __direct_tuple_helper_15(_changed_0, _index_0, _tick_0, __direct_tuple_fst_15, __direct_tuple_snd_15) {
  const _live_0 = __direct_tuple_fst_15;
  const _t_0 = __direct_tuple_snd_15;
  if (!_t_0) {
    return {$: "Tuple", "fst": _live_0, "snd": _changed_0};
  } else {
    return {$: "Tuple", "fst": _live_0, "snd": (_changed_0[_index_0 % _changed_0.length] = _tick_0, _changed_0)};
  }
}

function __direct_tuple_helper_16(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, _value_0, __direct_tuple_fst_16, __direct_tuple_snd_16) {
  if (!_value_0) {
    const _flags_0 = __direct_tuple_fst_16;
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _flags_1 = __direct_tuple_fst_16;
    const _flag_0 = __direct_tuple_snd_16;
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058prototype_identity_struct_idx_selected$1260$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058selected$(_selection_0, _flag_0)), _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_1, _added_0, _changed_0, _values_0, _flag_0);
  }
}

function __direct_tuple_helper_17(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, __direct_tuple_fst_17, __direct_tuple_snd_17) {
  const _live_0 = __direct_tuple_fst_17;
  const _t_0 = __direct_tuple_snd_17;
  if (!_t_0) {
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return __direct_tuple_helper_18(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, true, (_flags_0), (_flags_0[_x_0 % _flags_0.length]));
  }
}

function __direct_tuple_helper_18(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, _value_0, __direct_tuple_fst_18, __direct_tuple_snd_18) {
  if (!_value_0) {
    const _flags_0 = __direct_tuple_fst_18;
    return {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _flags_1 = __direct_tuple_fst_18;
    const _flag_0 = __direct_tuple_snd_18;
    return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058struct_idx_selected$1260$(($$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047query$058selected$(_selection_0, _flag_0)), _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_1, _added_0, _changed_0, _values_0, _flag_0);
  }
}

function __direct_tuple_helper_19(_namespace_0, _next_0, _main_0, _aux_0, _flags_0, _added_0, _changed_0, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _index_0, _transform_0, __direct_tuple_fst_19, __direct_tuple_snd_19) {
  const _live_0 = __direct_tuple_fst_19;
  const _value_0 = __direct_tuple_snd_19;
  return $$$$047bendvy$045identity$045handle$045query$045v3$047experiments$047s$045integrate$047storage$058fuse_live$(_namespace_0, _next_0, _aux_0, {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, _capacity_0, _depth_0, _high_0, _pending_0, _ledger_0, _mode_0, _main_0, _index_0, _transform_0, _value_0);
}

function __direct_tuple_helper_20(_frame_0, _value_0, __direct_tuple_fst_20, __direct_tuple_snd_20) {
  const _array_0 = __direct_tuple_fst_20;
  const _old_0 = __direct_tuple_snd_20;
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.Position", "coordinates": (_array_0[0 % _array_0.length] = _value_0, _array_0), "frame": _frame_0}, "snd": _old_0};
}

function __direct_tuple_helper_21(_epoch_0, _value_0, __direct_tuple_fst_21, __direct_tuple_snd_21) {
  const _array_0 = __direct_tuple_fst_21;
  const _old_0 = __direct_tuple_snd_21;
  return {$: "Tuple", "fst": {$: "../bendvy-identity-handle-query-v3/experiments/s-integrate/types.MotionLedger", "totals": (_array_0[0 % _array_0.length] = _value_0, _array_0), "epoch": _epoch_0}, "snd": _old_0};
}

// __nested_direct_tuple_: existing verified scalar targets only.
