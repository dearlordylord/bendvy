import {pathToFileURL} from 'node:url';
const reference="/workspace/formal-proofs/bendvy/experiments/s-integrate/measurement-reference.mjs";
process.argv=[process.execPath,reference,...process.argv.slice(2)];
await import(pathToFileURL(reference).href+'?slot_readiness_warmup');
await import(pathToFileURL(reference).href+'?slot_readiness_fresh');
