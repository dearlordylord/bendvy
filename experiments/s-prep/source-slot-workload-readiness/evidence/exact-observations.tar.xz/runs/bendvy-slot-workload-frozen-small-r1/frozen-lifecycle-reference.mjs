import {pathToFileURL} from 'node:url';
const reference="/workspace/formal-proofs/bendvy/experiments/s-integrate/measurement-lifecycle-timing-reference.mjs";
process.argv=[process.execPath,reference,...process.argv.slice(2),'1'];
console.log('READINESS-WARMUP-BEGIN');
await import(pathToFileURL(reference).href+'?slot_readiness_warmup');
console.log('READINESS-WARMUP-END');
await import(pathToFileURL(reference).href+'?slot_readiness_fresh');
console.log('READINESS-FRESH-END');
