
// Imports
// =======

// The Objective-C headers take #include, not #import: a build
// (-o) reads an #import as the framework of an effect.

#pragma clang fp contract(off)

#if defined(__CUDACC_RTC__)
#define BEND_RTC 1
#endif

#ifdef __METAL_VERSION__
#include <metal_stdlib>
using namespace metal;
#elif !defined(BEND_RTC)
#ifdef __APPLE__
#define _DARWIN_UNLIMITED_SELECT
#else
#define _GNU_SOURCE
#endif
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <unistd.h>
#include <signal.h>
#include <sys/mman.h>
#include <time.h>
#include <poll.h>
#include <sys/select.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif
#ifdef __OBJC__
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#elif BEND_CUDA
#include <cuda.h>
#include <nvrtc.h>
#include <fcntl.h>
#include <sys/stat.h>
#endif
#endif

// Dialect
// =======

// Metal needs coherent(device) (MSL 3.2), or M1-class parts lose stores
// across the threadgroups of a dispatch. CUDA keeps plain data cacheable
// in L1: lanes hand off through a32 and FENCE. Only clang 19+ has both
// preserve_none and preserve_most, and compiles preserve_most soundly; at
// -O0 its register allocator cannot place a preserve_none segment, so an
// unoptimized build takes neither. A segment is a case of the device's
// switch; on the host, a preserve_none function (WL_SIG) entered by
// musttail, its words fresh at WL_OPEN.

#ifdef __METAL_VERSION__
#if __METAL_VERSION__ >= 320
#define DEV     coherent(device) device
#else
#define DEV     device
#endif
#define THR     thread
#define TG      threadgroup
#define INLINE  inline
#define OUTLINE static
#define CONSTV  constant
#define DEVICE  1
#define CLZ(x)  clz(x)
#define FENCE() atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst)
#define BAR()   threadgroup_barrier(mem_flags::mem_threadgroup)
#define BARD()  threadgroup_barrier(mem_flags::mem_device \
  | mem_flags::mem_threadgroup)
#else
#define DEV
#define THR
#define TG
#define INLINE  static inline
#define CONSTV  static const
#ifdef BEND_RTC
#define OUTLINE static __attribute__((noinline))
#define DEVICE  1
#define CLZ(x)  (u32)__clz((int)(x))
#define FENCE() __threadfence()
#define BAR()   __syncthreads()
#define BARD()  \
  { __threadfence(); __syncthreads(); }
#else
#if __has_attribute(preserve_none) && __has_attribute(preserve_most) \
  && defined(__OPTIMIZE__)
#define PRESERVE(A) __attribute__((A))
#else
#define PRESERVE(A)
#endif
#define OUTLINE static __attribute__((noinline, cold)) PRESERVE(preserve_most)
#define DEVICE  0
#define CLZ(x)  (u32)__builtin_clz(x)
#define FENCE() ((void)0)
#endif
#endif
#define FAR static __attribute__((noinline))

#if DEVICE
#define LOCK(l)
#define UNLOCK(l)
#define WL_CASE(F) case F:
#define WL_OPEN    {
#define WL_JMP(F)  { fid = (F); break; }
#define WL_DYN     WL_JMP
#else
#define LOCK(l)    while (__atomic_exchange_n(&(l), 1, __ATOMIC_ACQUIRE)) {}
#define UNLOCK(l)  __atomic_store_n(&(l), 0, __ATOMIC_RELEASE)
#define WL_FN      static PRESERVE(preserve_none) __attribute__((noinline)) Term
#define WL_CASE(F) WL_FN WL_##F(WL_SIG)
#define WL_OPEN    { WL_BANK u32 rn;
#define WL_JMP(F)  __attribute__((musttail)) return WL_##F(WL_ALL)
#define WL_DYN(F)  __attribute__((musttail)) return wl_tab[F](WL_ALL)
#endif
#define WL_SPIN     for (;;) { if (err_spun(e.mem, &wpoll)) { return 0; }
#define WL_SPUN     } break;
#define WL_AGAIN(F) continue

#define LANE_STEP (DEVICE ? (long)CUBE : 1)
#define STK(I)    sp[(long)(I) * LANE_STEP]

#define WL_RETN(N)  { rn = (N); sp -= LANE_STEP; WL_DYN((u32)STK(0)); }
#define WL_CONT     STK(-3)
#define WL_IDX      STK(-2)
#define WL_POPN(N)  sp -= N * LANE_STEP
#define WL_PUSHN(N) sp += N * LANE_STEP
#define WL_FRAME(T) \
  u64 wtl = task_tail(T); \
  u64 wtw = e.mem[wtl + 1]; \
  STK(0) = e.mem[wtl]; \
  STK(1) = (wtw >> 32) & 0xFFFF; \
  STK(2) = FID_EXIT; \
  sp += 3 * LANE_STEP;
#define WL_ARGS(A, N) \
  for (u32 wi = 0; wi + 1 < N; wi += 1) { \
    STK(wi) = e.mem[A + wi]; \
  } \
  sp += (N - 1) * LANE_STEP;
#define WL_ROOM(N) \
  if (DEVICE && sp + (N) * CUBE >= e.mem + STAT_OFF + CUBE) { \
    err_post(e.mem, ERR_DEEP); \
    return 0; \
  }

// Types
// =====

#ifdef __METAL_VERSION__
typedef ulong u64;
typedef uint  u32;
typedef uchar u8;
#elif defined(BEND_RTC)
typedef unsigned long long u64;
typedef unsigned int       u32;
typedef unsigned char      u8;
#else
typedef uint64_t u64;
typedef uint32_t u32;
typedef uint8_t  u8;
#endif
typedef float f32;

typedef u64 Term;

typedef struct {
  DEV u64* mem;
  DEV u64* alc;
} Env;

typedef struct {
  u64 off;
  u32 rd;
  u32 wr;
  u32 top;
} Bank;

#if DEVICE
typedef u32 u32a;
#else
typedef u32 __attribute__((may_alias)) u32a;
#endif

// Constants
// =========

#define TAG_PAK 1ull
#define TAG_CTR 2ull
#define TAG_CLO 3ull
#define TAG_BUF 4ull
#define TAG_TSK 5ull
#define TAG_ARR 6ull

#define TERM_HOLE (~0ull)
#define LOC_MASK  ((1ull << 40) - 1)
#define RFC_BIT   (1ull << 63)
#define RFC_CNT   ((1u << 24) - 1)
#define NAT_IMM   ((1ull << 48) - 1)

#define ERR_RING 1
#define ERR_TAGS 2
#define ERR_HEAP 3
#define ERR_FIDS 4
#define ERR_NATS 5
#define ERR_RFCS 6
#define ERR_DEEP 7
#define ERR_ARRS 8

#define LINE      16
#define PAGE_BITS 7
#define PAGE_LEN  (1ull << PAGE_BITS)
#define CUBE_T    128
#define CUBE      ((u64)CUBE_T * CUBE_T)
#define CUBE_G    (1u << CUBE_LOG)
#define LANES     ((u64)CUBE_T << CUBE_LOG)
#define RING_LOG  (17 - CUBE_LOG)
#define RING_LEN  (1ull << RING_LOG)
#define STAK_LEN  (1ull << 11)
#define NCLS      8
#define NCLS_ALL  32
#define IO_HELP   64

#define TG_HOLD   2304
#define CHUNK     256
#define CAP_WORDS 32768
#define QUANTUM   (DEVICE ? PAGE_LEN \
  : KEEP_WORDS < 32 * PAGE_LEN ? KEEP_WORDS : 32 * PAGE_LEN)
#if DEVICE
#define KEEP_WORDS CHUNK
#endif
#define RING_WORDS ((1ull << 10) + 2)

#define H_BUMP       0
#define H_CAP        1
#define H_CURSOR     LINE
#define H_ROOT_DONE  (2 * LINE)
#define H_ERROR_CODE (3 * LINE)
#define H_ROOT_WORD  (4 * LINE)
#define H_BANK       (H_ROOT_WORD + WL_RESW)

#define PAGE_UP(n) (((n) + PAGE_LEN - 1) & ~(PAGE_LEN - 1))
#define ALC_OFF  PAGE_UP(H_BANK + 3 * NCLS_ALL)
#define RING_OFF (ALC_OFF + CUBE * 2 * NCLS_ALL)
#define STAK_OFF (RING_OFF + CUBE * RING_WORDS)
#define STAT_OFF (STAK_OFF + CUBE * STAK_LEN)
#define HEAP_OFF (STAT_OFF + PAGE_UP(STAT_LEN))

// Globals
// =======

// The bag is 2^CUBE_LOG groups of CUBE_T lanes (a -D constant on the
// device). The device program compiles from the binary's own text.

#if !DEVICE

static u64*    CORPUS;
static u64    ALC[CUBE_T + 1][3 * NCLS_ALL] __attribute__((aligned(128)));
static u32    KEEP_WORDS;
static u32    CUBE_LOG = 7;
static u32    bank_lock;

static u32             pool_size;
static u32             pool_row;
static u32             pool_done;
static pthread_mutex_t pool_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  pool_wake = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  pool_join = PTHREAD_COND_INITIALIZER;

#if BEND_METAL || BEND_CUDA
#pragma clang diagnostic ignored "-Wc23-extensions"
static const char BEND_SRC[] = {
#embed __FILE__
, 0 };
#endif

#ifdef __OBJC__
static id<MTLDevice>               gpu_dev;
static id<MTLCommandQueue>         gpu_que;
static id<MTLComputePipelineState> gpu_pso;
static id<MTLBuffer>               gpu_buf;
static id<MTLComputeCommandEncoder> gpu_enc;
#elif BEND_CUDA
static CUdevice   gpu_dev;
static CUmodule   gpu_lib;
static CUfunction gpu_pso;
#endif
static bool io_gpu;
static DEV Term*  io_stk;

static const char* CLI_HELP =
  "usage: %s [options] [arguments]\n"
  "  --threads N       worker threads, 1 to 128 (default: the CPU count)\n"
  "  --gpu on|off|4GB  run ! calls on the GPU, over this much of its memory\n"
  "                    (default: on if present, over 2GB on Metal)\n"
  "  --gpu-build       write the GPU program and exit\n"
  "  --bend-help       show this text\n"
  "  --                the rest are the program's arguments (IO.args)\n";

#endif

// Tables
// ======

#define CID_TUPLE 0
#define CID_SNIL 1
#define CID_SCON 2
#define CID_WCON 3
#define CID_EMIT 4
#define CID_HALT 5
#define CID_FAIL 6
#define CID_DONE 7
#define CID_NONE 8
#define CID_SOME 9
#define CID_FALSE 10
#define CID_TRUE 11
#define CID_UNIT 12
#define CID_STORAGE_WORLD 13
#define CID_SCHEMA 14
#define CID_OWNED 15
#define CID_NIL 16
#define CID_CON 17
#define CID_STORAGE_HANDLE 18
#define CID_QUERY_REQUIRED 19
#define CID_QUERY_PRESENT 20
#define CID_QUERY_ABSENT 21
#define CID_QUERY_OPTIONAL 22
#define CID_CHR 23
#define CID_STORAGE_ROWS 24
#define CID_STORAGE_SPAWN 25
#define CID_STORAGE_INSERTMAIN 26
#define CID_STORAGE_INSERTFLAG 27
#define CID_STORAGE_REMOVEMAIN 28
#define CID_STORAGE_REMOVEFLAG 29
#define CID_STORAGE_DESPAWN 30
#define CID_STORAGE_METADATACOLUMNS 31
#define CID_STORAGE_BUNDLE 32
#define CID_QUERY_STRUCTCOLSSTATE 33
#define CID_QUERY_STRUCTIDXSTATE 34
#define CID_IO_PRINT 35
#define FID_U32_SHOW_GO 0
#define FID_NAT_SHOW_FIN 1
#define FID_HANDLES 2
#define FID_HANDLES_K36 3
#define FID_HANDLES_K37 4
#define FID_HANDLES_K38 5
#define FID_HANDLES_K39 6
#define FID_HANDLES_K40 7
#define FID_HANDLES_K41 8
#define FID_WORDS 9
#define FID_WORDS_K43 10
#define FID_WORDS_K44 11
#define FID_WORDS_K45 12
#define FID_WORDS_K46 13
#define FID_WORDS_K47 14
#define FID_WORDS_K48 15
#define FID_WORDS_K49 16
#define FID_FLAGS 17
#define FID_FLAGS_K52 18
#define FID_FLAGS_K53 19
#define FID_FLAGS_K54 20
#define FID_FLAGS_K55 21
#define FID_FLAGS_K56 22
#define FID_BOOLS 23
#define FID_BOOLS_K58 24
#define FID_BOOLS_K59 25
#define FID_BOOLS_K60 26
#define FID_BOOLS_K61 27
#define FID_BOOLS_K62 28
#define FID_NAT_SHOW 29
#define FID_U32_SHOW 30
#define FID_OWNED 31
#define FID_OWNED_K67 32
#define FID_OWNED_K68 33
#define FID_OWNED_K69 34
#define FID_OWNED_K70 35
#define FID_OWNERS 36
#define FID_OWNERS_K72 37
#define FID_OWNERS_K73 38
#define FID_OWNERS_K74 39
#define FID_OWNERS_K75 40
#define FID_OWNERS_K76 41
#define FID_OWNERS_K77 42
#define FID_OWNERS_K78 43
#define FID_SNAPSHOT 44
#define FID_SNAPSHOT_K166 45
#define FID_SNAPSHOT_K167 46
#define FID_SNAPSHOT_K168 47
#define FID_SNAPSHOT_K169 48
#define FID_SNAPSHOT_K170 49
#define FID_SNAPSHOT_K171 50
#define FID_SNAPSHOT_K172 51
#define FID_SNAPSHOT_K173 52
#define FID_SNAPSHOT_K174 53
#define FID_SNAPSHOT_K175 54
#define FID_SNAPSHOT_K176 55
#define FID_SNAPSHOT_K177 56
#define FID_SNAPSHOT_K178 57
#define FID_SNAPSHOT_K179 58
#define FID_SNAPSHOT_K180 59
#define FID_SNAPSHOT_K181 60
#define FID_SNAPSHOT_K182 61
#define FID_SNAPSHOT_K183 62
#define FID_SNAPSHOT_K184 63
#define FID_SNAPSHOT_K185 64
#define FID_SNAPSHOT_K186 65
#define FID_SNAPSHOT_K187 66
#define FID_SNAPSHOT_K188 67
#define FID_SNAPSHOT_K189 68
#define FID_SNAPSHOT_K190 69
#define FID_SNAPSHOT_K191 70
#define FID_SNAPSHOT_K192 71
#define FID_SNAPSHOT_K193 72
#define FID_SNAPSHOT_K194 73
#define FID_SNAPSHOT_K195 74
#define FID_SNAPSHOT_K196 75
#define FID_SNAPSHOT_K197 76
#define FID_SNAPSHOT_K198 77
#define FID_SNAPSHOT_K199 78
#define FID_SNAPSHOT_K200 79
#define FID_SNAPSHOT_K201 80
#define FID_SNAPSHOT_K202 81
#define FID_SNAPSHOT_K203 82
#define FID_SNAPSHOT_K204 83
#define FID_STRING_APPEND 84
#define FID_STRING_APPEND_K206 85
#define FID_IO_BIND 86
#define FID_IO_BIND_C208 87
#define FID_IO_BIND_K209 88
#define FID_MAIN 89
#define FID_MAIN_K211 90
#define FID_MAIN_K212 91
#define FID_MAIN_C213 92
#define FID_MAIN_C214 93
#define FID_MAIN_K215 94
#define FID_MAIN_K216 95
#define FID_MAIN_C217 96
#define FID_MAIN_C218 97
#define FID_MAIN_K219 98
#define FID_MAIN_K220 99
#define FID_MAIN_C221 100
#define FID_MAIN_C222 101
#define FID_MAIN_K223 102
#define FID_MAIN_K224 103
#define FID_MAIN_C225 104
#define FID_MAIN_C226 105
#define FID_MAIN_K227 106
#define FID_MAIN_K228 107
#define FID_MAIN_C229 108
#define FID_MAIN_C230 109
#define FID_MAIN_K231 110
#define FID_MAIN_K232 111
#define FID_MAIN_C233 112
#define FID_MAIN_C234 113
#define FID_MAIN_K235 114
#define FID_MAIN_K236 115
#define FID_MAIN_C237 116
#define FID_MAIN_C238 117
#define FID_MAIN_K239 118
#define FID_MAIN_K240 119
#define FID_MAIN_C241 120
#define FID_MAIN_C242 121
#define FID_MAIN_K243 122
#define FID_MAIN_K244 123
#define FID_MAIN_C245 124
#define FID_MAIN_C246 125
#define FID_MAIN_K247 126
#define FID_MAIN_K248 127
#define FID_MAIN_C249 128
#define FID_MAIN_C250 129
#define FID_MAIN_K251 130
#define FID_MAIN_K252 131
#define FID_MAIN_C253 132
#define FID_MAIN_C254 133
#define FID_MAIN_K255 134
#define FID_MAIN_K256 135
#define FID_MAIN_C257 136
#define FID_MAIN_C258 137
#define FID_MAIN_K259 138
#define FID_MAIN_K260 139
#define FID_MAIN_C261 140
#define FID_MAIN_C262 141
#define FID_MAIN_K263 142
#define FID_MAIN_K264 143
#define FID_MAIN_C265 144
#define FID_MAIN_C266 145
#define FID_MAIN_K267 146
#define FID_MAIN_K268 147
#define FID_MAIN_C269 148
#define FID_MAIN_C270 149
#define FID_MAIN_K271 150
#define FID_MAIN_K272 151
#define FID_MAIN_C273 152
#define FID_MAIN_C274 153
#define FID_MAIN_K275 154
#define FID_MAIN_K276 155
#define FID_MAIN_C277 156
#define FID_MAIN_C278 157
#define FID_MAIN_K279 158
#define FID_MAIN_K280 159
#define FID_MAIN_C281 160
#define FID_MAIN_C282 161
#define FID_MAIN_K283 162
#define FID_MAIN_K284 163
#define FID_MAIN_C285 164
#define FID_MAIN_C286 165
#define FID_MAIN_K287 166
#define FID_MAIN_K288 167
#define FID_MAIN_C289 168
#define FID_MAIN_C290 169
#define FID_MAIN_C291 170
#define FID_IO_PRINT 171
#define FID_IO_EMIT 172
#define FID_CLO_APPLY 173
#define FID_EXIT 174
#define FID_ENTER 175
CONSTV u8 FID_T[][3] = { { 3, 0, 2 }, { 4, 0, 2 }, { 1, 0, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 3, 2, 2 }, { 4, 2, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 3, 2, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 1, 0, 2 }, { 3, 3, 2 }, { 3, 2, 2 }, { 4, 2, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 17, 0, 2 }, { 16, 2, 2 }, { 17, 2, 2 }, { 18, 3, 2 }, { 14, 1, 2 }, { 14, 1, 2 }, { 14, 1, 2 }, { 14, 1, 2 }, { 14, 1, 2 }, { 14, 1, 2 }, { 14, 1, 2 }, { 15, 2, 2 }, { 16, 2, 2 }, { 16, 1, 2 }, { 16, 1, 2 }, { 16, 1, 2 }, { 15, 1, 2 }, { 15, 1, 2 }, { 14, 1, 2 }, { 14, 1, 2 }, { 12, 1, 2 }, { 12, 1, 2 }, { 10, 1, 2 }, { 10, 1, 2 }, { 9, 1, 2 }, { 9, 1, 2 }, { 8, 1, 2 }, { 8, 1, 2 }, { 7, 1, 2 }, { 7, 1, 2 }, { 6, 1, 2 }, { 6, 1, 2 }, { 5, 1, 2 }, { 5, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 3, 0, 2 }, { 3, 0, 2 }, { 2, 1, 2 }, { 0, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 } };
CONSTV u8 CID_T[][2] = { { 2, 0 }, { 0, 0 }, { 2, 0 }, { 2, 1 }, { 1, 0 }, { 2, 0 }, { 1, 0 }, { 1, 0 }, { 0, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 15, 0 }, { 0, 0 }, { 2, 1 }, { 0, 0 }, { 2, 0 }, { 2, 0 }, { 0, 0 }, { 0, 0 }, { 0, 0 }, { 0, 0 }, { 1, 0 }, { 9, 0 }, { 7, 0 }, { 2, 0 }, { 2, 0 }, { 1, 0 }, { 1, 0 }, { 1, 0 }, { 4, 0 }, { 6, 0 }, { 7, 0 }, { 7, 0 }, { 2, 0 } };
#define STAT_LEN 206

#define WL_RESW 3
#define BANGS   0

#define WL_BANK Term r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16;

#define WL_LOAD(A, N) \
  do { \
    if ((N) <= 0) break; r0 = e.mem[(A) + 0]; \
    if ((N) <= 1) break; r1 = e.mem[(A) + 1]; \
    if ((N) <= 2) break; r2 = e.mem[(A) + 2]; \
    if ((N) <= 3) break; r3 = e.mem[(A) + 3]; \
    if ((N) <= 4) break; r4 = e.mem[(A) + 4]; \
    if ((N) <= 5) break; r5 = e.mem[(A) + 5]; \
    if ((N) <= 6) break; r6 = e.mem[(A) + 6]; \
    if ((N) <= 7) break; r7 = e.mem[(A) + 7]; \
    if ((N) <= 8) break; r8 = e.mem[(A) + 8]; \
    if ((N) <= 9) break; r9 = e.mem[(A) + 9]; \
    if ((N) <= 10) break; r10 = e.mem[(A) + 10]; \
    if ((N) <= 11) break; r11 = e.mem[(A) + 11]; \
    if ((N) <= 12) break; r12 = e.mem[(A) + 12]; \
    if ((N) <= 13) break; r13 = e.mem[(A) + 13]; \
    if ((N) <= 14) break; r14 = e.mem[(A) + 14]; \
    if ((N) <= 15) break; r15 = e.mem[(A) + 15]; \
    if ((N) <= 16) break; r16 = e.mem[(A) + 16]; \
  } while (0);

#define WL_LAST(X) \
  switch (war) { \
    case 0: r0 = (X); \
      break; \
    case 1: r1 = (X); \
      break; \
    case 2: r2 = (X); \
      break; \
    case 3: r3 = (X); \
      break; \
    case 4: r4 = (X); \
      break; \
    case 5: r5 = (X); \
      break; \
    case 6: r6 = (X); \
      break; \
    case 7: r7 = (X); \
      break; \
    case 8: r8 = (X); \
      break; \
    case 9: r9 = (X); \
      break; \
    case 10: r10 = (X); \
      break; \
    case 11: r11 = (X); \
      break; \
    case 12: r12 = (X); \
      break; \
    case 13: r13 = (X); \
      break; \
    case 14: r14 = (X); \
      break; \
    case 15: r15 = (X); \
      break; \
    case 16: r16 = (X); \
      break; \
  }

#define WL_SAVE(V) (V)[0] = r0; (V)[1] = r1; (V)[2] = r2;

#define WL_TAKE(V) r0 = (V)[0]; r1 = (V)[1]; r2 = (V)[2];

#define WL_SIG Env e, DEV Term* sp, u32 seq, u32 rn, Term r0, Term r1, Term r2, Term r3, Term r4, Term r5, Term rp, Term r6, Term r7, Term r8, Term r9, Term r10, Term r11, Term r12, Term r13, Term r14, Term r15, Term r16

#define WL_ALL e, sp, seq, rn, r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16

#define WL_TABLE WL_X(FID_U32_SHOW_GO) WL_X(FID_NAT_SHOW_FIN) WL_X(FID_HANDLES) WL_X(FID_HANDLES_K36) WL_X(FID_HANDLES_K37) WL_X(FID_HANDLES_K38) WL_X(FID_HANDLES_K39) WL_X(FID_HANDLES_K40) WL_X(FID_HANDLES_K41) WL_X(FID_WORDS) WL_X(FID_WORDS_K43) WL_X(FID_WORDS_K44) WL_X(FID_WORDS_K45) WL_X(FID_WORDS_K46) WL_X(FID_WORDS_K47) WL_X(FID_WORDS_K48) WL_X(FID_WORDS_K49) WL_X(FID_FLAGS) WL_X(FID_FLAGS_K52) WL_X(FID_FLAGS_K53) WL_X(FID_FLAGS_K54) WL_X(FID_FLAGS_K55) WL_X(FID_FLAGS_K56) WL_X(FID_BOOLS) WL_X(FID_BOOLS_K58) WL_X(FID_BOOLS_K59) WL_X(FID_BOOLS_K60) WL_X(FID_BOOLS_K61) WL_X(FID_BOOLS_K62) WL_X(FID_NAT_SHOW) WL_X(FID_U32_SHOW) WL_X(FID_OWNED) WL_X(FID_OWNED_K67) WL_X(FID_OWNED_K68) WL_X(FID_OWNED_K69) WL_X(FID_OWNED_K70) WL_X(FID_OWNERS) WL_X(FID_OWNERS_K72) WL_X(FID_OWNERS_K73) WL_X(FID_OWNERS_K74) WL_X(FID_OWNERS_K75) WL_X(FID_OWNERS_K76) WL_X(FID_OWNERS_K77) WL_X(FID_OWNERS_K78) WL_X(FID_SNAPSHOT) WL_X(FID_SNAPSHOT_K166) WL_X(FID_SNAPSHOT_K167) WL_X(FID_SNAPSHOT_K168) WL_X(FID_SNAPSHOT_K169) WL_X(FID_SNAPSHOT_K170) WL_X(FID_SNAPSHOT_K171) WL_X(FID_SNAPSHOT_K172) WL_X(FID_SNAPSHOT_K173) WL_X(FID_SNAPSHOT_K174) WL_X(FID_SNAPSHOT_K175) WL_X(FID_SNAPSHOT_K176) WL_X(FID_SNAPSHOT_K177) WL_X(FID_SNAPSHOT_K178) WL_X(FID_SNAPSHOT_K179) WL_X(FID_SNAPSHOT_K180) WL_X(FID_SNAPSHOT_K181) WL_X(FID_SNAPSHOT_K182) WL_X(FID_SNAPSHOT_K183) WL_X(FID_SNAPSHOT_K184) WL_X(FID_SNAPSHOT_K185) WL_X(FID_SNAPSHOT_K186) WL_X(FID_SNAPSHOT_K187) WL_X(FID_SNAPSHOT_K188) WL_X(FID_SNAPSHOT_K189) WL_X(FID_SNAPSHOT_K190) WL_X(FID_SNAPSHOT_K191) WL_X(FID_SNAPSHOT_K192) WL_X(FID_SNAPSHOT_K193) WL_X(FID_SNAPSHOT_K194) WL_X(FID_SNAPSHOT_K195) WL_X(FID_SNAPSHOT_K196) WL_X(FID_SNAPSHOT_K197) WL_X(FID_SNAPSHOT_K198) WL_X(FID_SNAPSHOT_K199) WL_X(FID_SNAPSHOT_K200) WL_X(FID_SNAPSHOT_K201) WL_X(FID_SNAPSHOT_K202) WL_X(FID_SNAPSHOT_K203) WL_X(FID_SNAPSHOT_K204) WL_X(FID_STRING_APPEND) WL_X(FID_STRING_APPEND_K206) WL_X(FID_IO_BIND) WL_X(FID_IO_BIND_C208) WL_X(FID_IO_BIND_K209) WL_X(FID_MAIN) WL_X(FID_MAIN_K211) WL_X(FID_MAIN_K212) WL_X(FID_MAIN_C213) WL_X(FID_MAIN_C214) WL_X(FID_MAIN_K215) WL_X(FID_MAIN_K216) WL_X(FID_MAIN_C217) WL_X(FID_MAIN_C218) WL_X(FID_MAIN_K219) WL_X(FID_MAIN_K220) WL_X(FID_MAIN_C221) WL_X(FID_MAIN_C222) WL_X(FID_MAIN_K223) WL_X(FID_MAIN_K224) WL_X(FID_MAIN_C225) WL_X(FID_MAIN_C226) WL_X(FID_MAIN_K227) WL_X(FID_MAIN_K228) WL_X(FID_MAIN_C229) WL_X(FID_MAIN_C230) WL_X(FID_MAIN_K231) WL_X(FID_MAIN_K232) WL_X(FID_MAIN_C233) WL_X(FID_MAIN_C234) WL_X(FID_MAIN_K235) WL_X(FID_MAIN_K236) WL_X(FID_MAIN_C237) WL_X(FID_MAIN_C238) WL_X(FID_MAIN_K239) WL_X(FID_MAIN_K240) WL_X(FID_MAIN_C241) WL_X(FID_MAIN_C242) WL_X(FID_MAIN_K243) WL_X(FID_MAIN_K244) WL_X(FID_MAIN_C245) WL_X(FID_MAIN_C246) WL_X(FID_MAIN_K247) WL_X(FID_MAIN_K248) WL_X(FID_MAIN_C249) WL_X(FID_MAIN_C250) WL_X(FID_MAIN_K251) WL_X(FID_MAIN_K252) WL_X(FID_MAIN_C253) WL_X(FID_MAIN_C254) WL_X(FID_MAIN_K255) WL_X(FID_MAIN_K256) WL_X(FID_MAIN_C257) WL_X(FID_MAIN_C258) WL_X(FID_MAIN_K259) WL_X(FID_MAIN_K260) WL_X(FID_MAIN_C261) WL_X(FID_MAIN_C262) WL_X(FID_MAIN_K263) WL_X(FID_MAIN_K264) WL_X(FID_MAIN_C265) WL_X(FID_MAIN_C266) WL_X(FID_MAIN_K267) WL_X(FID_MAIN_K268) WL_X(FID_MAIN_C269) WL_X(FID_MAIN_C270) WL_X(FID_MAIN_K271) WL_X(FID_MAIN_K272) WL_X(FID_MAIN_C273) WL_X(FID_MAIN_C274) WL_X(FID_MAIN_K275) WL_X(FID_MAIN_K276) WL_X(FID_MAIN_C277) WL_X(FID_MAIN_C278) WL_X(FID_MAIN_K279) WL_X(FID_MAIN_K280) WL_X(FID_MAIN_C281) WL_X(FID_MAIN_C282) WL_X(FID_MAIN_K283) WL_X(FID_MAIN_K284) WL_X(FID_MAIN_C285) WL_X(FID_MAIN_C286) WL_X(FID_MAIN_K287) WL_X(FID_MAIN_K288) WL_X(FID_MAIN_C289) WL_X(FID_MAIN_C290) WL_X(FID_MAIN_C291) WL_X(FID_IO_PRINT) WL_X(FID_IO_EMIT) WL_X(FID_CLO_APPLY) WL_X(FID_EXIT)
#define MAIN_FID FID_MAIN
#define MAIN_PURE 0
#define BLK_SHR 1

#define TAB_AT(T, S, I) T[S < I ? S : I]

#define fid_arity(x) ((u32)FID_T[x][0])
#define fid_resw(x)  ((u32)FID_T[x][1])
#define fid_bangs(x) ((bool)(FID_T[x][2] & 1))
#define fid_nofk(x)  ((bool)(FID_T[x][2] & 2))
#define cid_arity(x) ((u32)CID_T[x][0])
#define cid_hot(x)   ((bool)CID_T[x][1])

// A32
// ===

// C11's atomics on every lane; a device FENCE releases or acquires.
// Metal's loads read through a volatile local, or the M1 and M2 pipeline
// builds die. A weak CAS may fail with the cell still x: a32_cmpx loops.

#define A32_LOOP(k, x) \
  INLINE u32 a32_##k(DEV u32* p, u32 v) { \
    u32 o = a32_load(p); \
    while (!a32_cas(p, &o, x)) { \
    } \
    return o; \
  }

#ifdef __METAL_VERSION__

INLINE DEV atomic_uint* A32(DEV u32* p) {
  return (DEV atomic_uint*)p;
}

INLINE TG atomic_uint* A32(TG u32* p) {
  return (TG atomic_uint*)p;
}

#define a32_load(p) \
  ({ volatile thread u32 _a32v = atomic_load_explicit(A32(p), RLX); _a32v; })

#else

#define a32_load(p) atomic_load_explicit(A32(p), RLX)

#ifdef BEND_RTC

#define A32(p) (p)
#define atomic_load_explicit(p, o)     (*(volatile u32*)(p))
#define atomic_store_explicit(p, v, o) (*(volatile u32*)(p) = (v))
#define atomic_fetch_add_explicit(p, v, o) atomicAdd((u32*)(p), v)
#define atomic_fetch_sub_explicit(p, v, o) atomicSub((u32*)(p), v)
#define atomic_fetch_and_explicit(p, v, o) atomicAnd((u32*)(p), v)
#define atomic_fetch_or_explicit(p, v, o) atomicOr((u32*)(p), v)
#define atomic_fetch_xor_explicit(p, v, o) atomicXor((u32*)(p), v)
#define atomic_fetch_min_explicit(p, v, o) atomicMin((u32*)(p), v)
#define atomic_fetch_max_explicit(p, v, o) atomicMax((u32*)(p), v)
#define atomic_compare_exchange_weak_explicit(p, e, v, s, f) a32_swp(p, e, v)

INLINE bool a32_swp(DEV u32* p, u32* e, u32 v) {
  u32 x = *e;
  *e = atomicCAS((u32*)p, x, v);
  return *e == x;
}

#else

#define A32(p) ((_Atomic u32*)(p))
#define atomic_fetch_min_explicit __c11_atomic_fetch_min
#define atomic_fetch_max_explicit __c11_atomic_fetch_max

#endif

#endif

#define RLX memory_order_relaxed

#if DEVICE
#define REL RLX
#define ACQ RLX
#define ACR RLX
#define a32_acq(p) FENCE()
#define w64_load(p) (*(p))
#else
#define REL memory_order_release
#define ACQ memory_order_acquire
#define ACR memory_order_acq_rel
#define a32_acq(p) ((void)a32_load_acq(p))
#define w64_load(p) atomic_load_explicit((_Atomic u64*)(p), RLX)
#endif

#define a32_store(p, v)     atomic_store_explicit(A32(p), v, RLX)
#define a32_add(p, v) atomic_fetch_add_explicit(A32(p), v, RLX)
#define a32_sub(p, v) atomic_fetch_sub_explicit(A32(p), v, RLX)
#define a32_and(p, v) atomic_fetch_and_explicit(A32(p), v, RLX)
#define a32_or(p, v) atomic_fetch_or_explicit(A32(p), v, RLX)
#define a32_xor(p, v) atomic_fetch_xor_explicit(A32(p), v, RLX)
#define a32_min(p, v) atomic_fetch_min_explicit(A32(p), v, RLX)
#define a32_max(p, v) atomic_fetch_max_explicit(A32(p), v, RLX)
#define a32_sub_rel(p, v)   (FENCE(), atomic_fetch_sub_explicit(A32(p), v, REL))
#define a32_store_rel(p, v) (FENCE(), atomic_store_explicit(A32(p), v, REL))
#define a32_at(H, word)     ((DEV u32*)&(H)[word])

INLINE u32 a32_load_acq(DEV u32* p) {
  u32 v = DEVICE ? a32_load(p) : atomic_load_explicit(A32(p), ACQ);
  FENCE();
  return v;
}

INLINE bool a32_cas(DEV u32* p, THR u32* e, u32 v) {
  FENCE();
  bool ok = atomic_compare_exchange_weak_explicit(A32(p), e, v, ACR, ACQ);
  FENCE();
  return ok;
}

A32_LOOP(exch, v)

INLINE u32 a32_cmpx(DEV u32* p, u32 x, u32 v) {
  u32 o = x;
  while (!a32_cas(p, &o, v) && o == x) {
  }
  return o;
}

// Err
// ===

#if DEVICE

INLINE void err_post(DEV u64* H, u32 code) {
  a32_cmpx(a32_at(H, H_ERROR_CODE), 0, code);
}

#else

static const char* ERR_TEXT[] = { "",
  "runtime fail-stop",
  "runtime fail-stop",
  "out of memory: run again with a bigger span, as in --gpu 8GB",
  "a function the device does not hold",
  "a Nat past the largest immediate 2^48-1",
  "runtime fail-stop",
  "memory fault (machine stack overflow?)",
  "an array past the deepest block class 31" };

static void err_fail(const char* msg) {
  fflush(stdout);
  fprintf(stderr, "bend: %s\n", msg);
  _exit(1);
}

static void err_post(u64* H, u32 code) {
  err_fail(ERR_TEXT[code]);
}

static void err_trap(int sig) {
  err_post(NULL, ERR_DEEP);
}

#endif

#define err_seen(H)    (DEVICE && a32_load(a32_at(H, H_ERROR_CODE)) != 0)
#define err_spun(H, n) ((++*(n) & 4095) == 0 && err_seen(H))

#ifdef __METAL_VERSION__
INLINE f32 atan2_c99(f32 y, f32 x) {
  return y == 0.0f && x == x
    ? copysign(signbit(x) ? M_PI_F : 0.0f, y) : atan2(y, x);
}
#define sqrt  precise::sqrt
#define exp   precise::exp
#define log   precise::log
#define log2  precise::log2
#define log10 precise::log10
#define sin   fast::sin
#define cos   fast::cos
#define tan   fast::tan
#define pow   precise::pow
#define fmod  precise::fmod
#define atan2 atan2_c99
#define U32_QUO(a, b) \
  ((a) / 2 / (b) * 2 + ((a) - (a) / 2 / (b) * 2 * (b) >= (b)))
#else
#define U32_QUO(a, b) ((a) / (b))
#endif

#define U32_BIN(a, o, b) ((u64)((u32)(a) o (u32)(b)))

INLINE f32 f32_unbox(u64 x) {
  union { u32 u; f32 f; } p = { (u32)x };
  return p.f;
}

INLINE u64 f32_rewrap(f32 x) {
  union { f32 f; u32 u; } p = { x };
  return p.u;
}

INLINE u64 f32_to_u32(u64 a) {
  f32 v = f32_unbox(a);
  return v >= 0.0f && v < 4294967296.0f ? (u32)v : 0;
}

INLINE u64 nat_chk(Env e, u64 n) {
  if (n > NAT_IMM) {
    err_post(e.mem, ERR_NATS);
    return NAT_IMM;
  }
  return n;
}

INLINE u64 nat_mul(Env e, u64 a, u64 b) {
  return nat_chk(e, b != 0 && a > NAT_IMM / b ? NAT_IMM + 1 : a * b);
}

#if DEVICE

#define f32_show(e, x) (err_post(e.mem, ERR_FIDS), 0)
#define f32_read(e, s) (err_post(e.mem, ERR_FIDS), 0)

#else

static Term f32_show(Env e, Term x);
static Term f32_read(Env e, Term s);

#endif

A32_LOOP(fadd, f32_rewrap(f32_unbox(o) + f32_unbox(v)))

// Bank
// ====

// A stack of exact generations per class. The host pops and pushes at rd;
// a device pass pops below rd and pushes above top, compacted after it.

#define bank_at(H, c) ((DEV Bank*)((H) + H_BANK) + (c))

INLINE u64 bank_pop(DEV u64* H, u32 c) {
  DEV Bank* b = bank_at(H, c);
  u64 got = 0;
  LOCK(bank_lock);
  u32 t = a32_sub(&b->rd, 1);
  if ((int)t > 0) {
    got = H[b->off + t - 1];
  } else {
    a32_add(&b->rd, 1);
  }
  if (!DEVICE) {
    b->wr = b->top = b->rd;
  }
  UNLOCK(bank_lock);
  return got;
}

INLINE void bank_push(DEV u64* H, u32 c, u64 head) {
  DEV Bank* b = bank_at(H, c);
  LOCK(bank_lock);
  H[b->off + a32_add(&b->wr, 1)] = head;
  if (!DEVICE) {
    b->rd = b->top = b->wr;
  }
  UNLOCK(bank_lock);
}

// Heap
// ====

// Per lane and class: HOT, a LIFO free chain; LEN, its length in words;
// on the host COLD, one parked generation. A host free reaching KEEP_WORDS
// parks HOT as COLD and banks the old COLD. A miss takes COLD, a bank entry
// or a fresh quantum. A device lane banks its complete generations at the
// kernel end (dev_cut). The bump grows only when all of these are empty.

#define ALC_AT(e, i)   (e).alc[(i) * LANE_STEP]
#define ALC_LEN(e, c)  ALC_AT(e, NCLS_ALL + (c))
#define ALC_COLD(e, c) ALC_AT(e, 2 * NCLS_ALL + (c))
#define KEEP(c)        (KEEP_WORDS >> (c) ? KEEP_WORDS >> (c) : 1)

INLINE u32 cls_fit(u32 words) {
  return words > 1 ? 32 - CLZ(words - 1) : 0;
}

OUTLINE void heap_hand(Env e, u32 cls) {
  u64 cold = ALC_COLD(e, cls);
  if (cold) {
    bank_push(e.mem, cls, cold);
  }
  ALC_COLD(e, cls) = ALC_AT(e, cls);
  ALC_AT(e, cls)   = 0;
  ALC_LEN(e, cls)  = 0;
}

#if DEVICE
#define corpus_grow(H, n) false
#else
static bool corpus_grow(u64* H, u64 need);
#endif

OUTLINE u64 heap_alloc_miss(Env e, u32 cls) {
  DEV u64* H = e.mem;
  u64  got = 0;
  if (!DEVICE) {
    got = ALC_COLD(e, cls);
    ALC_COLD(e, cls) = 0;
  }
  if (!got) {
    got = bank_pop(H, cls);
  }
  u32 n = got ? KEEP(cls) : cls < NCLS ? QUANTUM >> cls : 1;
  if (!got) {
    u32 pages = (n << cls) >> PAGE_BITS;
    u32 p     = a32_add(a32_at(H, H_BUMP), pages);
    if ((u64)p + pages > a32_load_acq(a32_at(H, H_CAP))
      && !corpus_grow(H, (u64)p + pages)) {
      err_post(H, ERR_HEAP);
      return HEAP_OFF;
    }
    got = HEAP_OFF + ((u64)p << PAGE_BITS);
    for (u32 i = 1; i <= n; i += 1) {
      H[got + ((u64)(i - 1) << cls)] = i < n ? got + ((u64)i << cls) : 0;
    }
  }
  ALC_AT(e, cls)  = H[got];
  ALC_LEN(e, cls) = (u64)(n - 1) << cls;
  return got;
}

INLINE u64 heap_alloc(Env e, u32 cls) {
  u64 h = ALC_AT(e, cls);
  if (h) {
    ALC_AT(e, cls)   = e.mem[h];
    ALC_LEN(e, cls) -= 1ull << cls;
    return h;
  }
  return heap_alloc_miss(e, cls);
}

INLINE void heap_free(Env e, u32 cls, u64 loc) {
  if (err_seen(e.mem)) {
    return;
  }
  e.mem[loc]       = ALC_AT(e, cls);
  ALC_AT(e, cls)   = loc;
  ALC_LEN(e, cls) += 1ull << cls;
  if (!DEVICE && ALC_LEN(e, cls) >= KEEP_WORDS) {
    heap_hand(e, cls);
  }
}

INLINE void spare_free(Env e, u32 cls, u64 loc) {
  if (loc >= HEAP_OFF) {
    heap_free(e, cls, loc);
  }
}

// Term
// ====

#define term_make(tag, aux, loc) \
  (((u64)(tag) << 56) | ((u64)(aux) << 40) | (u64)(loc))

#define term_ctr(cid, loc) term_make(TAG_CTR, cid, loc)
#define term_pak(cid, loc) term_make(TAG_PAK, cid, loc)
#define term_clo(fid, loc) term_make(TAG_CLO, fid, loc)
#define term_buf(cls, loc) term_make(TAG_BUF, cls, loc)
#define term_tsk(fid, loc) term_make(TAG_TSK, fid, loc)

INLINE Term term_blk(bool arr, u32 cls, u64 loc) {
  return term_buf(cls, loc) | ((u64)arr << 57);
}

INLINE u64 term_tag(Term t) {
  return (t >> 56) & 0x7f;
}

INLINE bool term_rfc(Term t) {
  return (t & RFC_BIT) != 0;
}

INLINE u64 term_aux(Term t) {
  return (t >> 40) & 0xFFFF;
}

INLINE u64 term_loc(Term t) {
  return t & LOC_MASK;
}

INLINE bool term_triv(Term t) {
  return term_tag(t) <= TAG_PAK || t == TERM_HOLE || term_loc(t) < HEAP_OFF;
}

OUTLINE Term rfc_wrap(Env e, Term t, u32 cnt) {
  if (term_tag(t) == TAG_CLO || term_tag(t) == TAG_TSK) {
    err_post(e.mem, ERR_RFCS);
    return t;
  }
  u64 r = heap_alloc(e, 0);
  e.mem[r] = ((u64)term_loc(t) << 24) | cnt;
  return (t & ~LOC_MASK) | RFC_BIT | r;
}

INLINE Term rfc_seal(Env e, Term t) {
  if (term_tag(t) != TAG_CTR || term_rfc(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1);
}

// A redirect cell holds its target's loc over a 24-bit count, which
// changes by atomic adds on the low half, so a host never reads it as one
// plain word.
INLINE u64 rfc_view(DEV u64* H, u64 r) {
  DEV u32* w = a32_at(H, r);
  u64 cell = ((u64)a32_load(w + 1) << 32) | a32_load(w);
  if ((cell & RFC_CNT) == 1) {
    a32_acq(w);
  }
  return cell;
}

INLINE void rfc_bump(Env e, u64 r, u32 k) {
  u32 c = a32_add(a32_at(e.mem, r), k);
  if ((c & RFC_CNT) >= RFC_CNT - k) {
    err_post(e.mem, ERR_RFCS);
  }
}

INLINE Term term_keep(Env e, Term t, u32 k) {
  if (term_rfc(t)) {
    rfc_bump(e, term_loc(t), k);
    return t;
  }
  if (term_triv(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1 + k);
}

INLINE u64 term_peek(DEV u64* H, Term t) {
  if (term_rfc(t)) {
    return rfc_view(H, term_loc(t)) >> 24;
  }
  return term_loc(t);
}

#define blk_shr(t) (BLK_SHR && term_rfc(t))

INLINE u64 blk_loc(DEV u64* H, Term a) {
  return blk_shr(a) ? w64_load(&H[term_loc(a)]) >> 24 : term_loc(a);
}

INLINE u32 blk_cls(Term t) {
  return (u32)term_aux(t) & 31;
}

#define buf_wcls(c) ((c) == 0 ? 0 : (c) - 1)

INLINE u32 blk_span(Term t) {
  u32 c = blk_cls(t);
  return term_tag(t) == TAG_ARR ? c : buf_wcls(c);
}

FAR void term_drop(Env e, Term t) {
  DEV u64* H = e.mem;
  u64  cur = 0;
  Term c0  = 0;
  u32  step = 0;
  for (;;) {
    if (!term_triv(t) && term_rfc(t)) {
      u64      r = term_loc(t);
      DEV u32* p = a32_at(H, r);
      if ((a32_sub_rel(p, 1) & RFC_CNT) != 1) {
        t = 0;
      } else {
        a32_acq(p);
        t = (t & ~(RFC_BIT | LOC_MASK)) | (H[r] >> 24);
        heap_free(e, 0, r);
      }
    }
    if (!term_triv(t)) {
      u64 tag = term_tag(t);
      if (tag == TAG_BUF) {
        heap_free(e, blk_span(t), term_loc(t));
      } else {
        u32 aux = (u32)term_aux(t);
        u64 loc = term_loc(t);
        u32 n   = tag == TAG_ARR ? 0 : tag == TAG_CTR ? cid_arity(aux)
          : fid_arity(aux) - (tag == TAG_CLO);
        u32 cls = tag == TAG_ARR ? 64 | blk_cls(t)
          : n > 247 ? 64 | (n - 240)
          : cls_fit(tag == TAG_TSK ? n + 2 : n);
        c0 = H[loc];
        H[loc] = cur;
        cur = loc | ((u64)n << 48) | ((u64)cls << 56);
      }
    }
    for (;;) {
      if (err_spun(H, &step) || cur == 0) {
        return;
      }
      u64  loc = cur & LOC_MASK;
      u32  i   = (u8)(cur >> 40);
      u32  n   = (u8)(cur >> 48);
      u32  cls = (u32)(cur >> 56);
      bool arr = cls > 63;
      u32  j   = i;
      if (arr) {
        cls &= 63;
        n   = 1u << cls;
        if (i == 2) {
          j = (u32)H[loc + 1];
        }
      }
      if (j < n) {
        Term c = j == 0 ? c0 : H[loc + j];
        if (arr && j > 0) {
          H[loc + 1] = j + 1;
        }
        if (!arr || i < 2) {
          cur += 1ull << 40;
        }
        if (!term_triv(c)) {
          t = c;
          break;
        }
      } else {
        u64 up = H[loc];
        heap_free(e, cls, loc);
        cur = up;
      }
    }
  }
}

INLINE void term_sink(Env e, Term t) {
  if (!term_triv(t)) {
    term_drop(e, t);
  }
}

OUTLINE void span_fade(Env e, Term t, u64 src, u32 n) {
  for (u32 j = 0; j < n; j += 1) {
    Term f = e.mem[src + j];
    if (term_rfc(f)) {
      rfc_bump(e, term_loc(f), 1);
    } else if (!term_triv(f)) {
      err_post(e.mem, ERR_RFCS);
    }
  }
  term_drop(e, t);
}

INLINE u64 ctr_take(Env e, Term t, u32 n, THR Term* out) {
  DEV u64* H = e.mem;
  if (!term_rfc(t)) {
    for (u32 j = 0; j < n; j += 1) {
      out[j] = H[term_loc(t) + j];
    }
    return term_loc(t);
  }
  u64 r    = term_loc(t);
  u64 cell = rfc_view(H, r);
  u64 src  = cell >> 24;
  for (u32 j = 0; j < n; j += 1) {
    out[j] = H[src + j];
  }
  if ((cell & RFC_CNT) == 1) {
    heap_free(e, 0, r);
    return src;
  }
  span_fade(e, t, src, n);
  return 0;
}

INLINE Term term_word(Env e, Term w) {
  u32 x = 0;
  Term t = w;
  for (u32 i = 0; i < 32 && term_aux(t) == CID_WCON; i += 1) {
    u64 l = term_peek(e.mem, t);
    x |= (u32)(e.mem[l] & 1) << i;
    t = e.mem[l + 1];
  }
  term_sink(e, w);
  return x;
}

// Blk
// ===

// A block owns one allocation in its class (an ARR 2^c Terms, a BUF 2^c
// u32). Matching ANode is blk_half twice (the high call frees the source);
// ANode{l, r} is blk_node; Array.clone is blk_copy.

#define BLK_ALLOC(n, w) \
  u64 n = heap_alloc(e, w); \
  if (err_seen(e.mem)) { \
    return term_buf(0, n); \
  }

INLINE DEV u32a* blk_ptr(DEV u64* H, u64 loc, u32 i) {
  return (DEV u32a*)(H + loc) + i;
}

INLINE Term blk_read(DEV u64* H, bool arr, u64 loc, u32 i) {
  if (arr) {
    return H[loc + i];
  }
  return (u64)*blk_ptr(H, loc, i);
}

INLINE void blk_write(DEV u64* H, bool arr, u64 loc, u32 i, Term v) {
  if (arr) {
    H[loc + i] = v;
  } else {
    *blk_ptr(H, loc, i) = (u32)v;
  }
}

INLINE u32 blk_at(Term a, u64 i, u32 lgs) {
  return ((u32)i & (u32)((1ull << (blk_cls(a) - lgs)) - 1)) << lgs;
}

INLINE Term blk_keep(Env e, u64 at) {
  Term w = e.mem[at];
  Term v = term_keep(e, w, 1);
  if (v != w) {
    e.mem[at] = v;
  }
  return v;
}

INLINE void blk_fill(Env e, u64 dst, u64 src, u64 n, bool keep) {
  for (u64 j = 0; j < n; j += 1) {
    e.mem[dst + j] = keep ? blk_keep(e, src + j) : e.mem[src + j];
  }
}

INLINE void blk_free(Env e, Term t) {
  blk_shr(t) ? term_drop(e, t) : heap_free(e, blk_span(t), term_loc(t));
}

OUTLINE Term blk_copy(Env e, Term a) {
  bool arr = term_tag(a) == TAG_ARR;
  u32 cls = blk_span(a);
  BLK_ALLOC(dst, cls)
  blk_fill(e, dst, blk_loc(e.mem, a), 1ull << cls, arr);
  return term_blk(arr, blk_cls(a), dst);
}

INLINE Term blk_node(Env e, Term l, Term r) {
  DEV u64* H = e.mem;
  bool arr = term_tag(l) == TAG_ARR;
  u32 c = blk_cls(l);
  if (c != blk_cls(r) || c + 1 >= NCLS_ALL) {
    err_post(H, ERR_TAGS);
    return l;
  }
  u64 pl = blk_loc(H, l);
  u64 pr = blk_loc(H, r);
  BLK_ALLOC(n, arr ? c + 1 : c)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, pl, 0) | ((u64)*blk_ptr(H, pr, 0) << 32);
  } else {
    u64 cw = 1ull << blk_span(l);
    blk_fill(e, n, pl, cw, arr && blk_shr(l));
    blk_fill(e, n + cw, pr, cw, arr && blk_shr(r));
  }
  blk_free(e, l);
  blk_free(e, r);
  return term_blk(arr, c + 1, n);
}

INLINE Term blk_half(Env e, Term a, u32 hi) {
  DEV u64* H = e.mem;
  bool arr = term_tag(a) == TAG_ARR;
  u32 c = blk_cls(a);
  if (c == 0) {
    err_post(H, ERR_TAGS);
    return a;
  }
  c -= 1;
  u32 cw = arr ? c : buf_wcls(c);
  u64 src = blk_loc(H, a);
  BLK_ALLOC(n, cw)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, src, hi);
  } else {
    blk_fill(e, n, src + ((u64)hi << cw), 1ull << cw, arr && blk_shr(a));
  }
  if (hi) {
    blk_free(e, a);
  }
  return term_blk(arr, c, n);
}

INLINE Term blk_new(Env e, bool arr, u64 d, u32 lgs, u32 n, THR Term* v) {
  DEV u64* H = e.mem;
  if (d + lgs > 31) {
    err_post(H, ERR_ARRS);
    d = 0;
  }
  u32 c = (u32)d + lgs;
  BLK_ALLOC(l, arr ? c : buf_wcls(c))
  for (u32 j = 0; arr && d > 0 && j < n; j += 1) {
    if (d >= 24 && !term_triv(v[j])) {
      err_post(H, ERR_RFCS);
    }
    v[j] = term_keep(e, v[j], (1u << d) - 1);
  }
  for (u64 i = 0; i < (1ull << c); i += 1) {
    blk_write(H, arr, l, (u32)i, i % (1u << lgs) < n ? v[i % (1u << lgs)] : 0);
  }
  return term_blk(arr, c, l);
}

// Ring
// ====

#define ring_word(H, r, w) ((H) + RING_OFF + (w) * LANES + (r))
#define ring_slot(H, r, p) ring_word(H, r, (p) & (RING_LEN - 1))
#define ring_get(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN))
#define ring_put(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN + 1))

INLINE u32 ring_lap(u32 pos) {
  return ~(u32)(pos / RING_LEN) & 1;
}

INLINE void ring_push(DEV u64* H, u32 r, Term tsk) {
  u32 pos = a32_add(ring_put(H, r), 1);
  if (pos - a32_load(ring_get(H, r)) >= RING_LEN) {
    err_post(H, ERR_RING);
    return;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, r, pos);
  a32_store(lo, (u32)tsk);
  a32_store_rel(lo + 1, (u32)(tsk >> 32) | (ring_lap(pos) << 31));
}

INLINE u32 ring_flip(u32 i) {
  return (i % CUBE_T << CUBE_LOG) + i / CUBE_T;
}

#define ring_pick(b, s, c) ((b) + (s) * (a32_add(c, 1) & (CUBE_T - 1)))

// Task
// ====

INLINE u64 task_node(Env e, u32 fid, Term cont, u32 idx, u32 rem) {
  u32 ar  = fid_arity(fid);
  u64 loc = heap_alloc(e, cls_fit(ar + 2));
  for (u32 i = 0; rem && i < ar; i += 1) {
    e.mem[loc + i] = TERM_HOLE;
  }
  e.mem[loc + ar]     = cont;
  e.mem[loc + ar + 1] = ((u64)idx << 32) | rem;
  return loc;
}

INLINE u64 task_tail(Term t) {
  return term_loc(t) + fid_arity((u32)term_aux(t));
}

INLINE Term task_deliver(DEV u64* H, Term cont, u32 idx, THR Term* v, u32 n) {
  u64 at = cont == TERM_HOLE ? H_ROOT_WORD : term_loc(cont) + idx;
  for (u32 j = 0; j < WL_RESW; j += 1) {
    if (j < n) {
      H[at + j] = v[j];
    }
  }
  if (cont == TERM_HOLE) {
    a32_store_rel(a32_at(H, H_ROOT_DONE), n + 1);
    return 0;
  }
  u64 tl = task_tail(cont);
  if (a32_sub_rel(a32_at(H, tl + 1), 1) == 1) {
    a32_acq(a32_at(H, tl + 1));
    return cont;
  }
  return 0;
}

INLINE void task_deal(DEV u64* H, Term join, u32 base, u32 stride, TG u32* cur) {
  u64 loc = term_loc(join);
  u32 ar  = fid_arity((u32)term_aux(join));
  u32 g   = 0;
  if (stride == 0) {
    u32 rem = (u32)H[loc + ar + 1];
    g = a32_add(a32_at(H, H_CURSOR), rem);
  }
  for (u32 i = 0; i < ar; i += 1) {
    Term k = H[loc + i];
    if (term_tag(k) == TAG_TSK) {
      H[loc + i] = TERM_HOLE;
      u32 to;
      if (stride != 0) {
        to = ring_pick(base, stride, cur);
      } else {
        to = ring_flip(g & (u32)(LANES - 1));
        g += 1;
      }
      ring_push(H, to, k);
    }
  }
}

// Root
// ====

INLINE bool root_done(DEV u64* H) {
  return a32_load_acq(a32_at(H, H_ROOT_DONE)) != 0;
}

static u32 root_take(DEV u64* H, THR Term* v) {
  u32 n = a32_load_acq(a32_at(H, H_ROOT_DONE)) - 1;
  for (u32 j = 0; j < n; j += 1) {
    v[j] = H[H_ROOT_WORD + j];
  }
  a32_store(a32_at(H, H_ROOT_DONE), 0);
  return n;
}

// Spins
// =====

CONSTV u64 STAT_IMG[] = { 41ull, term_pak(CID_SNIL, 0), 44ull, term_pak(CID_SNIL, 0), 40ull, term_pak(CID_SNIL, 0), 48ull, term_pak(CID_SNIL, 0), 64ull, term_pak(CID_SNIL, 0), 100ull, term_pak(CID_SNIL, 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 10), 101ull, term_ctr(CID_SCON, STAT_OFF + 12), 59ull, term_pak(CID_SNIL, 0), 58ull, term_pak(CID_SNIL, 0), 49ull, term_pak(CID_SNIL, 0), 101ull, term_pak(CID_SNIL, 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 22), 111ull, term_ctr(CID_SCON, STAT_OFF + 24), 110ull, term_ctr(CID_SCON, STAT_OFF + 26), 124ull, term_pak(CID_SNIL, 0), 116ull, term_pak(CID_SNIL, 0), 120ull, term_ctr(CID_SCON, STAT_OFF + 32), 101ull, term_ctr(CID_SCON, STAT_OFF + 34), 116ull, term_ctr(CID_SCON, STAT_OFF + 36), 110ull, term_ctr(CID_SCON, STAT_OFF + 38), 111ull, term_ctr(CID_SCON, STAT_OFF + 40), 99ull, term_ctr(CID_SCON, STAT_OFF + 42), 45ull, term_ctr(CID_SCON, STAT_OFF + 44), 100ull, term_ctr(CID_SCON, STAT_OFF + 46), 101ull, term_ctr(CID_SCON, STAT_OFF + 48), 116ull, term_ctr(CID_SCON, STAT_OFF + 50), 99ull, term_ctr(CID_SCON, STAT_OFF + 52), 101ull, term_ctr(CID_SCON, STAT_OFF + 54), 112ull, term_ctr(CID_SCON, STAT_OFF + 56), 120ull, term_ctr(CID_SCON, STAT_OFF + 58), 101ull, term_ctr(CID_SCON, STAT_OFF + 60), 110ull, term_ctr(CID_SCON, STAT_OFF + 62), 117ull, term_ctr(CID_SCON, STAT_OFF + 64), 100ull, term_ctr(CID_SCON, STAT_OFF + 18), 101ull, term_ctr(CID_SCON, STAT_OFF + 68), 114ull, term_ctr(CID_SCON, STAT_OFF + 70), 105ull, term_ctr(CID_SCON, STAT_OFF + 72), 117ull, term_ctr(CID_SCON, STAT_OFF + 74), 113ull, term_ctr(CID_SCON, STAT_OFF + 76), 101ull, term_ctr(CID_SCON, STAT_OFF + 78), 82ull, term_ctr(CID_SCON, STAT_OFF + 80), 45ull, term_ctr(CID_SCON, STAT_OFF + 82), 48ull, term_ctr(CID_SCON, STAT_OFF + 84), 100ull, term_ctr(CID_SCON, STAT_OFF + 86), 116ull, term_ctr(CID_SCON, STAT_OFF + 18), 110ull, term_ctr(CID_SCON, STAT_OFF + 90), 101ull, term_ctr(CID_SCON, STAT_OFF + 92), 115ull, term_ctr(CID_SCON, STAT_OFF + 94), 101ull, term_ctr(CID_SCON, STAT_OFF + 96), 114ull, term_ctr(CID_SCON, STAT_OFF + 98), 80ull, term_ctr(CID_SCON, STAT_OFF + 100), 45ull, term_ctr(CID_SCON, STAT_OFF + 102), 48ull, term_ctr(CID_SCON, STAT_OFF + 104), 100ull, term_ctr(CID_SCON, STAT_OFF + 106), 98ull, term_ctr(CID_SCON, STAT_OFF + 96), 65ull, term_ctr(CID_SCON, STAT_OFF + 110), 45ull, term_ctr(CID_SCON, STAT_OFF + 112), 48ull, term_ctr(CID_SCON, STAT_OFF + 114), 100ull, term_ctr(CID_SCON, STAT_OFF + 116), 108ull, term_ctr(CID_SCON, STAT_OFF + 18), 97ull, term_ctr(CID_SCON, STAT_OFF + 120), 110ull, term_ctr(CID_SCON, STAT_OFF + 122), 111ull, term_ctr(CID_SCON, STAT_OFF + 124), 105ull, term_ctr(CID_SCON, STAT_OFF + 126), 116ull, term_ctr(CID_SCON, STAT_OFF + 128), 112ull, term_ctr(CID_SCON, STAT_OFF + 130), 79ull, term_ctr(CID_SCON, STAT_OFF + 132), 45ull, term_ctr(CID_SCON, STAT_OFF + 134), 48ull, term_ctr(CID_SCON, STAT_OFF + 136), 100ull, term_ctr(CID_SCON, STAT_OFF + 138), 49ull, term_ctr(CID_SCON, STAT_OFF + 84), 100ull, term_ctr(CID_SCON, STAT_OFF + 142), 49ull, term_ctr(CID_SCON, STAT_OFF + 104), 100ull, term_ctr(CID_SCON, STAT_OFF + 146), 49ull, term_ctr(CID_SCON, STAT_OFF + 114), 100ull, term_ctr(CID_SCON, STAT_OFF + 150), 49ull, term_ctr(CID_SCON, STAT_OFF + 136), 100ull, term_ctr(CID_SCON, STAT_OFF + 154), 50ull, term_ctr(CID_SCON, STAT_OFF + 84), 100ull, term_ctr(CID_SCON, STAT_OFF + 158), 50ull, term_ctr(CID_SCON, STAT_OFF + 104), 100ull, term_ctr(CID_SCON, STAT_OFF + 162), 50ull, term_ctr(CID_SCON, STAT_OFF + 114), 100ull, term_ctr(CID_SCON, STAT_OFF + 166), 50ull, term_ctr(CID_SCON, STAT_OFF + 136), 100ull, term_ctr(CID_SCON, STAT_OFF + 170), 51ull, term_ctr(CID_SCON, STAT_OFF + 84), 100ull, term_ctr(CID_SCON, STAT_OFF + 174), 51ull, term_ctr(CID_SCON, STAT_OFF + 104), 100ull, term_ctr(CID_SCON, STAT_OFF + 178), 51ull, term_ctr(CID_SCON, STAT_OFF + 114), 100ull, term_ctr(CID_SCON, STAT_OFF + 182), 51ull, term_ctr(CID_SCON, STAT_OFF + 136), 100ull, term_ctr(CID_SCON, STAT_OFF + 186), 52ull, term_ctr(CID_SCON, STAT_OFF + 84), 100ull, term_ctr(CID_SCON, STAT_OFF + 190), 52ull, term_ctr(CID_SCON, STAT_OFF + 104), 100ull, term_ctr(CID_SCON, STAT_OFF + 194), 52ull, term_ctr(CID_SCON, STAT_OFF + 114), 100ull, term_ctr(CID_SCON, STAT_OFF + 198), 52ull, term_ctr(CID_SCON, STAT_OFF + 136), 100ull, term_ctr(CID_SCON, STAT_OFF + 202) };

INLINE Term spin_2(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, Term r10, u64 q10) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h10 = r10;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  u32 _id_2 = r0;
  u32 _namespace_2 = r1;
  Term _aux_2 = r2;
  Term _live_2 = r3;
  Term _flags_2 = r4;
  Term _added_2 = r5;
  Term _changed_2 = r6;
  Term _values_2 = r7;
  Term _result_0 = r8;
  u32 _result_1 = r9;
  Term _result_2 = r10;
  WL_SPIN
    if (_result_1 == 0) {
      _v_21 = _result_0;
      _v_22 = _aux_2;
      _v_23 = _live_2;
      _v_24 = _flags_2;
      _v_25 = _added_2;
      _v_26 = _changed_2;
      _v_27 = _values_2;
    } else {
      term_sink(e, _result_2);
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _namespace_2;
      e.mem[_nd_0 + 1] = _id_2;
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = term_ctr(CID_STORAGE_HANDLE, _nd_0);
      e.mem[_nd_1 + 1] = _values_2;
      _v_21 = _result_0;
      _v_22 = _aux_2;
      _v_23 = _live_2;
      _v_24 = _flags_2;
      _v_25 = _added_2;
      _v_26 = _changed_2;
      _v_27 = term_ctr(CID_CON, _nd_1);
    }
  break;
  }
  o[0] = _v_21;
  o[1] = _v_22;
  o[2] = _v_23;
  o[3] = _v_24;
  o[4] = _v_25;
  o[5] = _v_26;
  o[6] = _v_27;
  return 1;
}

INLINE Term spin_1(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term _v_7 = 0;
  Term _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  u32 _id_1 = r0;
  u32 _namespace_1 = r1;
  Term _main_1 = r2;
  Term _aux_1 = r3;
  Term _live_1 = r4;
  Term _flags_1 = r5;
  Term _added_1 = r6;
  Term _changed_1 = r7;
  Term _values_1 = r8;
  WL_SPIN
    Term _at_0 = _main_1 == h2 ? q2 : blk_loc(e.mem, _main_1);
    Term _at_1 = blk_at(_main_1, U32_BIN(_id_1, -, 1ull), 1);
    u32 _c_0 = blk_read(e.mem, 1, _at_0, _at_1 + 0);
    Term _c_1 = e.mem[_at_0 + _at_1 + 1];
    blk_write(e.mem, 1, _at_0, _at_1 + 0, 0);
    blk_write(e.mem, 1, _at_0, _at_1 + 1, 0);
    Term _v_14 = 0;
    Term _v_15 = 0;
    Term _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _o_0[7];
    if (spin_2(e, _o_0, _id_1, _namespace_1, _aux_1, _aux_1 == h3 ? q3 : blk_loc(e.mem, _aux_1), _live_1, _live_1 == h4 ? q4 : blk_loc(e.mem, _live_1), _flags_1, _flags_1 == h5 ? q5 : blk_loc(e.mem, _flags_1), _added_1, _added_1 == h6 ? q6 : blk_loc(e.mem, _added_1), _changed_1, _changed_1 == h7 ? q7 : blk_loc(e.mem, _changed_1), _values_1, _values_1 == h8 ? q8 : blk_loc(e.mem, _values_1), _main_1, _main_1 == h2 ? q2 : blk_loc(e.mem, _main_1), _c_0, _c_1, _c_1 == h8 ? q8 : _c_1 == h7 ? q7 : _c_1 == h6 ? q6 : _c_1 == h5 ? q5 : _c_1 == h4 ? q4 : _c_1 == h3 ? q3 : _c_1 == h2 ? q2 : blk_loc(e.mem, _c_1)) == 0) {
      return 0;
    }
    _v_14 = _o_0[0];
    _v_15 = _o_0[1];
    _v_16 = _o_0[2];
    _v_17 = _o_0[3];
    _v_18 = _o_0[4];
    _v_19 = _o_0[5];
    _v_20 = _o_0[6];
    _v_7 = _v_14;
    _v_8 = _v_15;
    _v_9 = _v_16;
    _v_10 = _v_17;
    _v_11 = _v_18;
    _v_12 = _v_19;
    _v_13 = _v_20;
  break;
  }
  o[0] = _v_7;
  o[1] = _v_8;
  o[2] = _v_9;
  o[3] = _v_10;
  o[4] = _v_11;
  o[5] = _v_12;
  o[6] = _v_13;
  return 1;
}

INLINE Term spin_3(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h2 = r2;
  u32 _v_2 = 0;
  u32 _selection_1 = r0;
  u32 _flag_0 = r1;
  Term _flag_1 = r2;
  WL_SPIN
    if (_selection_1 == 1) {
      if (_flag_0 == 0) {
        _v_2 = 0;
      } else {
        term_sink(e, _flag_1);
        _v_2 = 1;
      }
    } else if (_selection_1 == 2) {
      if (_flag_0 == 1) {
        term_sink(e, _flag_1);
        _v_2 = 0;
      } else {
        term_sink(e, _flag_1);
        _v_2 = 1;
      }
    } else {
      term_sink(e, _flag_1);
      _v_2 = 1;
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_4(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  Term _v_16 = 0;
  u32 _include_0 = r0;
  u32 _id_1 = r1;
  u32 _namespace_1 = r2;
  Term _main_1 = r3;
  Term _aux_1 = r4;
  Term _live_1 = r5;
  Term _flags_0 = r6;
  Term _added_1 = r7;
  Term _changed_1 = r8;
  Term _values_1 = r9;
  u32 _flag_2 = r10;
  WL_SPIN
    if (_include_0 == 0) {
      _v_10 = _main_1;
      _v_11 = _aux_1;
      _v_12 = _live_1;
      _v_13 = _flags_0;
      _v_14 = _added_1;
      _v_15 = _changed_1;
      _v_16 = _values_1;
    } else {
      Term _v_17 = 0;
      Term _v_18 = 0;
      Term _v_19 = 0;
      Term _v_20 = 0;
      Term _v_21 = 0;
      Term _v_22 = 0;
      Term _v_23 = 0;
      Term _o_3[7];
      if (spin_1(e, _o_3, _id_1, _namespace_1, _main_1, _main_1 == h3 ? q3 : blk_loc(e.mem, _main_1), _aux_1, _aux_1 == h4 ? q4 : blk_loc(e.mem, _aux_1), _live_1, _live_1 == h5 ? q5 : blk_loc(e.mem, _live_1), _flags_0, _flags_0 == h6 ? q6 : blk_loc(e.mem, _flags_0), _added_1, _added_1 == h7 ? q7 : blk_loc(e.mem, _added_1), _changed_1, _changed_1 == h8 ? q8 : blk_loc(e.mem, _changed_1), _values_1, _values_1 == h9 ? q9 : blk_loc(e.mem, _values_1)) == 0) {
        return 0;
      }
      _v_17 = _o_3[0];
      _v_18 = _o_3[1];
      _v_19 = _o_3[2];
      _v_20 = _o_3[3];
      _v_21 = _o_3[4];
      _v_22 = _o_3[5];
      _v_23 = _o_3[6];
      _v_10 = _v_17;
      _v_11 = _v_18;
      _v_12 = _v_19;
      _v_13 = _v_20;
      _v_14 = _v_21;
      _v_15 = _v_22;
      _v_16 = _v_23;
    }
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  return 1;
}

INLINE Term spin_6(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  u32 _v_4 = 0;
  Term _v_5 = 0;
  Term _qr_0 = r0;
  Term _qr_1 = r1;
  WL_SPIN
    _v_4 = ((u64)(u32)(nat_chk(e, 48ull + _qr_1)));
    _v_5 = _qr_0;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  return 1;
}

INLINE Term spin_7(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, Term r10, u64 q10, u32 r11) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h10 = r10;
  Term _v_7 = 0;
  Term _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  u32 _id_1 = r0;
  u32 _namespace_1 = r1;
  u32 _selection_1 = r2;
  Term _main_1 = r3;
  Term _aux_1 = r4;
  Term _values_1 = r5;
  Term _live_0 = r6;
  Term _added_1 = r7;
  Term _changed_1 = r8;
  u32 _value_0 = r9;
  Term _result_2 = r10;
  u32 _result_3 = r11;
  WL_SPIN
    if (_value_0 == 0) {
      _v_7 = _main_1;
      _v_8 = _aux_1;
      _v_9 = _live_0;
      _v_10 = _result_2;
      _v_11 = _added_1;
      _v_12 = _changed_1;
      _v_13 = _values_1;
    } else {
      u32 _v_14 = 0;
      u32 _o_1 = 0;
      Term _o_2 = 0;
      if (_result_3 == 0) {
        _o_1 = 0;
      } else {
        _o_1 = 1;
        _o_2 = term_pak(CID_UNIT, 0);
      }
      u32 _v_15 = 0;
      Term _o_3[1];
      if (spin_3(e, _o_3, _selection_1, _o_1, _o_2, _o_2 == h10 ? q10 : _o_2 == h8 ? q8 : _o_2 == h7 ? q7 : _o_2 == h6 ? q6 : _o_2 == h5 ? q5 : _o_2 == h4 ? q4 : _o_2 == h3 ? q3 : blk_loc(e.mem, _o_2)) == 0) {
        return 0;
      }
      _v_15 = _o_3[0];
      _v_14 = _v_15;
      Term _v_16 = 0;
      Term _v_17 = 0;
      Term _v_18 = 0;
      Term _v_19 = 0;
      Term _v_20 = 0;
      Term _v_21 = 0;
      Term _v_22 = 0;
      Term _o_4[7];
      if (spin_4(e, _o_4, _v_14, _id_1, _namespace_1, _main_1, _main_1 == h3 ? q3 : blk_loc(e.mem, _main_1), _aux_1, _aux_1 == h4 ? q4 : blk_loc(e.mem, _aux_1), _live_0, _live_0 == h6 ? q6 : blk_loc(e.mem, _live_0), _result_2, _result_2 == h10 ? q10 : blk_loc(e.mem, _result_2), _added_1, _added_1 == h7 ? q7 : blk_loc(e.mem, _added_1), _changed_1, _changed_1 == h8 ? q8 : blk_loc(e.mem, _changed_1), _values_1, _values_1 == h5 ? q5 : blk_loc(e.mem, _values_1), _result_3) == 0) {
        return 0;
      }
      _v_16 = _o_4[0];
      _v_17 = _o_4[1];
      _v_18 = _o_4[2];
      _v_19 = _o_4[3];
      _v_20 = _o_4[4];
      _v_21 = _o_4[5];
      _v_22 = _o_4[6];
      _v_7 = _v_16;
      _v_8 = _v_17;
      _v_9 = _v_18;
      _v_10 = _v_19;
      _v_11 = _v_20;
      _v_12 = _v_21;
      _v_13 = _v_22;
    }
  break;
  }
  o[0] = _v_7;
  o[1] = _v_8;
  o[2] = _v_9;
  o[3] = _v_10;
  o[4] = _v_11;
  o[5] = _v_12;
  o[6] = _v_13;
  return 1;
}

INLINE Term spin_9(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term _v_7 = 0;
  Term _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  u32 _id_1 = r0;
  u32 _namespace_1 = r1;
  u32 _selection_1 = r2;
  Term _main_0 = r3;
  Term _aux_0 = r4;
  Term _values_0 = r5;
  Term _flags_0 = r6;
  Term _added_0 = r7;
  Term _changed_0 = r8;
  Term _result_0 = r9;
  u32 _result_1 = r10;
  WL_SPIN
    if (_result_1 == 0) {
      _v_7 = _main_0;
      _v_8 = _aux_0;
      _v_9 = _result_0;
      _v_10 = _flags_0;
      _v_11 = _added_0;
      _v_12 = _changed_0;
      _v_13 = _values_0;
    } else {
      Term _at_2 = _flags_0 == h6 ? q6 : blk_loc(e.mem, _flags_0);
      Term _at_3 = blk_at(_flags_0, U32_BIN(_id_1, -, 1ull), 1);
      u32 _c_1 = blk_read(e.mem, 1, _at_2, _at_3 + 0);
      Term _c_2 = blk_keep(e, _at_2 + _at_3 + 1);
      u32 _o_0 = 0;
      if (_c_1 == 0) {
        _o_0 = 0;
      } else {
        _o_0 = 1;
      }
      Term _v_14 = 0;
      Term _v_15 = 0;
      Term _v_16 = 0;
      Term _v_17 = 0;
      Term _v_18 = 0;
      Term _v_19 = 0;
      Term _v_20 = 0;
      Term _o_1[7];
      if (spin_7(e, _o_1, _id_1, _namespace_1, _selection_1, _main_0, _main_0 == h3 ? q3 : blk_loc(e.mem, _main_0), _aux_0, _aux_0 == h4 ? q4 : blk_loc(e.mem, _aux_0), _values_0, _values_0 == h5 ? q5 : blk_loc(e.mem, _values_0), _result_0, _result_0 == h9 ? q9 : blk_loc(e.mem, _result_0), _added_0, _added_0 == h7 ? q7 : blk_loc(e.mem, _added_0), _changed_0, _changed_0 == h8 ? q8 : blk_loc(e.mem, _changed_0), 1, _flags_0, _flags_0 == h6 ? q6 : blk_loc(e.mem, _flags_0), _o_0) == 0) {
        return 0;
      }
      _v_14 = _o_1[0];
      _v_15 = _o_1[1];
      _v_16 = _o_1[2];
      _v_17 = _o_1[3];
      _v_18 = _o_1[4];
      _v_19 = _o_1[5];
      _v_20 = _o_1[6];
      _v_7 = _v_14;
      _v_8 = _v_15;
      _v_9 = _v_16;
      _v_10 = _v_17;
      _v_11 = _v_18;
      _v_12 = _v_19;
      _v_13 = _v_20;
    }
  break;
  }
  o[0] = _v_7;
  o[1] = _v_8;
  o[2] = _v_9;
  o[3] = _v_10;
  o[4] = _v_11;
  o[5] = _v_12;
  o[6] = _v_13;
  return 1;
}

INLINE Term spin_14(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_44 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_44 = _acc_0;
    } else {
      u64 _sp_0 = term_loc(_xs_1);
      Term _f_0 = e.mem[_sp_0 + 0];
      Term _f_1 = e.mem[_sp_0 + 1];
      u64 _nd_0 = _sp_0;
      e.mem[_nd_0 + 0] = _f_0;
      e.mem[_nd_0 + 1] = _acc_0;
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_14);
    }
  break;
  }
  o[0] = _v_44;
  return 1;
}

INLINE Term spin_13(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_42 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_43 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_14(e, _o_0, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_43 = _o_0[0];
    _v_42 = _v_43;
  break;
  }
  o[0] = _v_42;
  return 1;
}

INLINE Term spin_12(Env e, THR Term* o, u32 r0, Term r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  Term _v_37 = 0;
  u32 _v_38 = 0;
  Term _v_39 = 0;
  u32 _capacity_2 = r0;
  Term _depth_2 = r1;
  u32 _high_2 = r2;
  Term _state_14 = r3;
  Term _state_15 = r4;
  Term _state_16 = r5;
  Term _state_17 = r6;
  Term _state_18 = r7;
  Term _state_19 = r8;
  Term _state_20 = r9;
  WL_SPIN
    Term _v_40 = 0;
    Term _v_41 = 0;
    Term _o_1[1];
    if (spin_13(e, _o_1, _state_20, _state_20 == h9 ? q9 : blk_loc(e.mem, _state_20)) == 0) {
      return 0;
    }
    _v_41 = _o_1[0];
    _v_40 = _v_41;
    _v_30 = _state_14;
    _v_31 = _state_15;
    _v_32 = _state_16;
    _v_33 = _state_17;
    _v_34 = _state_18;
    _v_35 = _state_19;
    _v_36 = _capacity_2;
    _v_37 = _depth_2;
    _v_38 = _high_2;
    _v_39 = _v_40;
  break;
  }
  o[0] = _v_30;
  o[1] = _v_31;
  o[2] = _v_32;
  o[3] = _v_33;
  o[4] = _v_34;
  o[5] = _v_35;
  o[6] = _v_36;
  o[7] = _v_37;
  o[8] = _v_38;
  o[9] = _v_39;
  return 1;
}

INLINE Term spin_11(Env e, THR Term* o, u32 r0, Term r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  u32 _capacity_1 = r0;
  Term _depth_1 = r1;
  u32 _high_1 = r2;
  Term _state_7 = r3;
  Term _state_8 = r4;
  Term _state_9 = r5;
  Term _state_10 = r6;
  Term _state_11 = r7;
  Term _state_12 = r8;
  Term _state_13 = r9;
  WL_SPIN
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    u32 _v_26 = 0;
    Term _v_27 = 0;
    u32 _v_28 = 0;
    Term _v_29 = 0;
    Term _o_2[10];
    if (spin_12(e, _o_2, _capacity_1, _depth_1, _high_1, _state_7, _state_7 == h3 ? q3 : blk_loc(e.mem, _state_7), _state_8, _state_8 == h4 ? q4 : blk_loc(e.mem, _state_8), _state_9, _state_9 == h5 ? q5 : blk_loc(e.mem, _state_9), _state_10, _state_10 == h6 ? q6 : blk_loc(e.mem, _state_10), _state_11, _state_11 == h7 ? q7 : blk_loc(e.mem, _state_11), _state_12, _state_12 == h8 ? q8 : blk_loc(e.mem, _state_12), _state_13, _state_13 == h9 ? q9 : blk_loc(e.mem, _state_13)) == 0) {
      return 0;
    }
    _v_20 = _o_2[0];
    _v_21 = _o_2[1];
    _v_22 = _o_2[2];
    _v_23 = _o_2[3];
    _v_24 = _o_2[4];
    _v_25 = _o_2[5];
    _v_26 = _o_2[6];
    _v_27 = _o_2[7];
    _v_28 = _o_2[8];
    _v_29 = _o_2[9];
    _v_10 = _v_20;
    _v_11 = _v_21;
    _v_12 = _v_22;
    _v_13 = _v_23;
    _v_14 = _v_24;
    _v_15 = _v_25;
    _v_16 = _v_26;
    _v_17 = _v_27;
    _v_18 = _v_28;
    _v_19 = _v_29;
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  o[7] = _v_17;
  o[8] = _v_18;
  o[9] = _v_19;
  return 1;
}

INLINE Term spin_15(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_54 = 0;
  u32 _a_1 = r0;
  u32 _b_0 = r1;
  WL_SPIN
    if (_a_1 == 0) {
      _v_54 = 0;
    } else {
      _v_54 = _b_0;
    }
  break;
  }
  o[0] = _v_54;
  return 1;
}

INLINE Term spin_16(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10) {
  u32 wpoll = 0;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term _v_62 = 0;
  Term _v_63 = 0;
  Term _v_64 = 0;
  Term _v_65 = 0;
  Term _v_66 = 0;
  Term _v_67 = 0;
  Term _v_68 = 0;
  u32 _valid_0 = r0;
  u32 _id_1 = r1;
  u32 _namespace_1 = r2;
  u32 _selection_1 = r3;
  Term _state_21 = r4;
  Term _state_22 = r5;
  Term _state_23 = r6;
  Term _state_24 = r7;
  Term _state_25 = r8;
  Term _state_26 = r9;
  Term _state_27 = r10;
  WL_SPIN
    if (_valid_0 == 0) {
      _v_62 = _state_21;
      _v_63 = _state_22;
      _v_64 = _state_23;
      _v_65 = _state_24;
      _v_66 = _state_25;
      _v_67 = _state_26;
      _v_68 = _state_27;
    } else {
      Term _at_0 = _state_23 == h6 ? q6 : blk_loc(e.mem, _state_23);
      Term _at_1 = blk_at(_state_23, U32_BIN(_id_1, -, 1ull), 0);
      u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
      Term _v_69 = 0;
      Term _v_70 = 0;
      Term _v_71 = 0;
      Term _v_72 = 0;
      Term _v_73 = 0;
      Term _v_74 = 0;
      Term _v_75 = 0;
      Term _o_5[7];
      if (spin_9(e, _o_5, _id_1, _namespace_1, _selection_1, _state_21, _state_21 == h4 ? q4 : blk_loc(e.mem, _state_21), _state_22, _state_22 == h5 ? q5 : blk_loc(e.mem, _state_22), _state_27, _state_27 == h10 ? q10 : blk_loc(e.mem, _state_27), _state_24, _state_24 == h7 ? q7 : blk_loc(e.mem, _state_24), _state_25, _state_25 == h8 ? q8 : blk_loc(e.mem, _state_25), _state_26, _state_26 == h9 ? q9 : blk_loc(e.mem, _state_26), _state_23, _state_23 == h6 ? q6 : blk_loc(e.mem, _state_23), _c_0) == 0) {
        return 0;
      }
      _v_69 = _o_5[0];
      _v_70 = _o_5[1];
      _v_71 = _o_5[2];
      _v_72 = _o_5[3];
      _v_73 = _o_5[4];
      _v_74 = _o_5[5];
      _v_75 = _o_5[6];
      _v_62 = _v_69;
      _v_63 = _v_70;
      _v_64 = _v_71;
      _v_65 = _v_72;
      _v_66 = _v_73;
      _v_67 = _v_74;
      _v_68 = _v_75;
    }
  break;
  }
  o[0] = _v_62;
  o[1] = _v_63;
  o[2] = _v_64;
  o[3] = _v_65;
  o[4] = _v_66;
  o[5] = _v_67;
  o[6] = _v_68;
  return 1;
}

INLINE Term spin_17(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term _v_2 = 0;
  Term _v_3 = 0;
  Term _result_0 = r0;
  u32 _result_1 = r1;
  Term _result_2 = r2;
  WL_SPIN
    u32 _o_5 = 0;
    Term _o_6 = 0;
    Term _t_3 = 1;
    if (_t_3 == 0) {
      _o_5 = 0;
    } else {
      _o_5 = 1;
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _result_0);
      e.mem[_nd_1 + 1] = rfc_seal(e, _result_1);
      _o_6 = term_ctr(CID_OWNED, _nd_1);
    }
    Term _fv_1[2];
    _fv_1[0] = _o_5;
    _fv_1[1] = _o_6;
    _v_2 = blk_new(e, 1, 0, 1, 2, _fv_1);
    _v_3 = _result_2;
  break;
  }
  o[0] = _v_2;
  o[1] = _v_3;
  return 1;
}

INLINE Term spin_18(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_2 = 0;
  Term _result_0 = r0;
  Term _result_1 = r1;
  WL_SPIN
    term_sink(e, _result_0);
    _v_2 = _result_1;
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_19(Env e, THR Term* o, Term r0, u32 r1, u32 r2, Term r3, u32 r4, u32 r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13) {
  u32 wpoll = 0;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  Term _remaining_0 = r0;
  u32 _id_0 = r1;
  u32 _capacity_0 = r2;
  Term _depth_0 = r3;
  u32 _high_0 = r4;
  u32 _selection_1 = r5;
  u32 _namespace_1 = r6;
  Term _state_0 = r7;
  Term _state_1 = r8;
  Term _state_2 = r9;
  Term _state_3 = r10;
  Term _state_4 = r11;
  Term _state_5 = r12;
  Term _state_6 = r13;
  WL_SPIN
    if (_remaining_0 == 0) {
      Term _v_20 = 0;
      Term _v_21 = 0;
      Term _v_22 = 0;
      Term _v_23 = 0;
      Term _v_24 = 0;
      Term _v_25 = 0;
      u32 _v_26 = 0;
      Term _v_27 = 0;
      u32 _v_28 = 0;
      Term _v_29 = 0;
      Term _o_0[10];
      if (spin_11(e, _o_0, _capacity_0, _depth_0, _high_0, _state_0, _state_0 == h7 ? q7 : blk_loc(e.mem, _state_0), _state_1, _state_1 == h8 ? q8 : blk_loc(e.mem, _state_1), _state_2, _state_2 == h9 ? q9 : blk_loc(e.mem, _state_2), _state_3, _state_3 == h10 ? q10 : blk_loc(e.mem, _state_3), _state_4, _state_4 == h11 ? q11 : blk_loc(e.mem, _state_4), _state_5, _state_5 == h12 ? q12 : blk_loc(e.mem, _state_5), _state_6, _state_6 == h13 ? q13 : blk_loc(e.mem, _state_6)) == 0) {
        return 0;
      }
      _v_20 = _o_0[0];
      _v_21 = _o_0[1];
      _v_22 = _o_0[2];
      _v_23 = _o_0[3];
      _v_24 = _o_0[4];
      _v_25 = _o_0[5];
      _v_26 = _o_0[6];
      _v_27 = _o_0[7];
      _v_28 = _o_0[8];
      _v_29 = _o_0[9];
      _v_10 = _v_20;
      _v_11 = _v_21;
      _v_12 = _v_22;
      _v_13 = _v_23;
      _v_14 = _v_24;
      _v_15 = _v_25;
      _v_16 = _v_26;
      _v_17 = _v_27;
      _v_18 = _v_28;
      _v_19 = _v_29;
    } else {
      Term _rest_0 = (_remaining_0 - 1);
      Term _v_30 = 0;
      Term _v_31 = 0;
      Term _v_32 = 0;
      Term _v_33 = 0;
      Term _v_34 = 0;
      Term _v_35 = 0;
      Term _v_36 = 0;
      u32 _v_37 = 0;
      u32 _v_38 = 0;
      Term _o_1[1];
      if (spin_15(e, _o_1, U32_BIN(0ull, <, _id_0), U32_BIN(_id_0, <=, _capacity_0)) == 0) {
        return 0;
      }
      _v_38 = _o_1[0];
      _v_37 = _v_38;
      Term _v_39 = 0;
      Term _v_40 = 0;
      Term _v_41 = 0;
      Term _v_42 = 0;
      Term _v_43 = 0;
      Term _v_44 = 0;
      Term _v_45 = 0;
      Term _o_2[7];
      if (spin_16(e, _o_2, _v_37, _id_0, _namespace_1, _selection_1, _state_0, _state_0 == h7 ? q7 : blk_loc(e.mem, _state_0), _state_1, _state_1 == h8 ? q8 : blk_loc(e.mem, _state_1), _state_2, _state_2 == h9 ? q9 : blk_loc(e.mem, _state_2), _state_3, _state_3 == h10 ? q10 : blk_loc(e.mem, _state_3), _state_4, _state_4 == h11 ? q11 : blk_loc(e.mem, _state_4), _state_5, _state_5 == h12 ? q12 : blk_loc(e.mem, _state_5), _state_6, _state_6 == h13 ? q13 : blk_loc(e.mem, _state_6)) == 0) {
        return 0;
      }
      _v_39 = _o_2[0];
      _v_40 = _o_2[1];
      _v_41 = _o_2[2];
      _v_42 = _o_2[3];
      _v_43 = _o_2[4];
      _v_44 = _o_2[5];
      _v_45 = _o_2[6];
      _v_30 = _v_39;
      _v_31 = _v_40;
      _v_32 = _v_41;
      _v_33 = _v_42;
      _v_34 = _v_43;
      _v_35 = _v_44;
      _v_36 = _v_45;
      r0 = _rest_0;
      r1 = U32_BIN(_id_0, +, 1ull);
      r2 = _capacity_0;
      r3 = _depth_0;
      r4 = _high_0;
      r5 = _selection_1;
      r6 = _namespace_1;
      r7 = _v_30;
      r8 = _v_31;
      r9 = _v_32;
      r10 = _v_33;
      r11 = _v_34;
      r12 = _v_35;
      r13 = _v_36;
      _remaining_0 = r0;
      _id_0 = r1;
      _capacity_0 = r2;
      _depth_0 = r3;
      _high_0 = r4;
      _selection_1 = r5;
      _namespace_1 = r6;
      _state_0 = r7;
      _state_1 = r8;
      _state_2 = r9;
      _state_3 = r10;
      _state_4 = r11;
      _state_5 = r12;
      _state_6 = r13;
      WL_AGAIN(spin_19);
    }
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  o[7] = _v_17;
  o[8] = _v_18;
  o[9] = _v_19;
  return 1;
}

INLINE Term spin_21(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, u32 r3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, u32 r12, Term r13, u32 r14, Term r15, u64 q15) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h15 = r15;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  Term _v_58 = 0;
  Term _v_59 = 0;
  Term _v_60 = 0;
  Term _v_61 = 0;
  Term _v_62 = 0;
  Term _v_63 = 0;
  u32 _v_64 = 0;
  Term _v_65 = 0;
  u32 _v_66 = 0;
  Term _v_67 = 0;
  u32 _v_68 = 0;
  Term _v_69 = 0;
  Term _v_70 = 0;
  Term _v_71 = 0;
  u32 _namespace_1 = r0;
  u32 _next_0 = r1;
  Term _pending_0 = r2;
  u32 _ledger_0 = r3;
  Term _ledger_1 = r4;
  Term _mode_0 = r5;
  Term _result_0 = r6;
  Term _result_1 = r7;
  Term _result_2 = r8;
  Term _result_3 = r9;
  Term _result_4 = r10;
  Term _result_5 = r11;
  u32 _result_6 = r12;
  Term _result_7 = r13;
  u32 _result_8 = r14;
  Term _result_9 = r15;
  WL_SPIN
    _v_56 = _namespace_1;
    _v_57 = _next_0;
    _v_58 = _result_0;
    _v_59 = _result_1;
    _v_60 = _result_2;
    _v_61 = _result_3;
    _v_62 = _result_4;
    _v_63 = _result_5;
    _v_64 = _result_6;
    _v_65 = _result_7;
    _v_66 = _result_8;
    _v_67 = _pending_0;
    _v_68 = _ledger_0;
    _v_69 = _ledger_1;
    _v_70 = _mode_0;
    _v_71 = _result_9;
  break;
  }
  o[0] = _v_56;
  o[1] = _v_57;
  o[2] = _v_58;
  o[3] = _v_59;
  o[4] = _v_60;
  o[5] = _v_61;
  o[6] = _v_62;
  o[7] = _v_63;
  o[8] = _v_64;
  o[9] = _v_65;
  o[10] = _v_66;
  o[11] = _v_67;
  o[12] = _v_68;
  o[13] = _v_69;
  o[14] = _v_70;
  o[15] = _v_71;
  return 1;
}

// Work
// ====

// A host self-jump is a tail call: as a loop, clang hoisted constants into
// symreg's entry (3.05 s against 2.51 s).
#if !DEVICE
#undef  WL_SPIN
#undef  WL_SPUN
#undef  WL_AGAIN
#define WL_SPIN
#define WL_SPUN
#define WL_AGAIN(F) __attribute__((musttail)) return WL_##F(WL_ALL)

typedef Term (PRESERVE(preserve_none) *WlFn)(WL_SIG);
#define WL_X(F) WL_FN WL_##F(WL_SIG);
WL_TABLE WL_X(FID_ENTER)
#undef WL_X
#define WL_X(F) WL_##F,
static const WlFn wl_tab[] = { WL_TABLE };
#undef WL_X
#endif

static Term work_loop(Env e, DEV Term* sp, Term t, u32 seq) {
  WL_BANK
  u32 rn = 0;
  r0 = t;
#if DEVICE
  u32 fid   = FID_ENTER;
  u32 wpoll = 0;
  for (;;) {
  if (err_spun(e.mem, &wpoll)) {
    return 0;
  }
  switch (fid) {
#else
  return WL_FID_ENTER(WL_ALL);
}
#endif

// Segments
// ========

// A task enters through its words: a continuation's results ride r0..
// and its parameters the stack; any other segment's parameters ride r0..

#if !DEVICE
  WL_CASE(FID_U32_SHOW_GO)
  {
    Term _f_0 = r0;
    u32 _n_0 = r1;
    Term _acc_0 = r2;
    WL_OPEN
    WL_SPIN
    if (_f_0 == 0) {
      r0 = _acc_0;
      WL_RETN(1);
    } else {
      Term _g_0 = (_f_0 - 1);
      u32 _s_0 = U32_BIN(_n_0, ==, 0);
      if (_s_0 == 1) {
        r0 = _acc_0;
        WL_RETN(1);
      } else {
        Term _a_0 = 10ull;
        Term _a_1 = 10ull;
        u64 _nd_0 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = U32_BIN(48ull, +, ((u32)(_a_1) == 0 ? _n_0 : U32_BIN(_n_0, -, U32_QUO((u32)(_n_0), (u32)(_a_1)) * _a_1)));
        e.mem[_nd_0 + 1] = _acc_0;
        r0 = _g_0;
        r1 = ((u32)(_a_0) == 0 ? 0 : (u64)U32_QUO((u32)(_n_0), (u32)(_a_0)));
        r2 = term_ctr(CID_SCON, _nd_0);
        _f_0 = r0;
        _n_0 = r1;
        _acc_0 = r2;
        WL_AGAIN(FID_U32_SHOW_GO);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NAT_SHOW_FIN)
  {
    Term _g_0 = r0;
    Term _acc_0 = r1;
    u32 _dq_0 = r2;
    Term _dq_1 = r3;
    WL_OPEN
    WL_SPIN
    if (_dq_1 == 0) {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _dq_0;
      e.mem[_nd_0 + 1] = _acc_0;
      r0 = term_ctr(CID_SCON, _nd_0);
      WL_RETN(1);
    } else {
      Term _p_0 = (_dq_1 - 1);
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = _dq_0;
      e.mem[_nd_1 + 1] = _acc_0;
      if (_g_0 == 0) {
        Term _n_0 = nat_chk(e, _p_0 + 1);
        Term _acc_1 = term_ctr(CID_SCON, _nd_1);
        r0 = _acc_1;
        WL_RETN(1);
      } else {
        Term _g_1 = (_g_0 - 1);
        Term _n_1 = nat_chk(e, _p_0 + 1);
        Term _acc_2 = term_ctr(CID_SCON, _nd_1);
        u32 _v_0 = 0;
        Term _v_1 = 0;
        Term _a_0 = 10ull;
        Term _a_1 = (_a_0 == 0 ? 0 : _n_1 / _a_0);
        Term _a_2 = (_a_0 == 0 ? _n_1 : _n_1 % _a_0);
        u32 _v_2 = 0;
        Term _v_3 = 0;
        Term _o_0[2];
        if (spin_6(e, _o_0, _a_1, _a_2) == 0) {
          return 0;
        }
        _v_2 = _o_0[0];
        _v_3 = _o_0[1];
        _v_0 = _v_2;
        _v_1 = _v_3;
        r0 = _g_1;
        r1 = _acc_2;
        r2 = _v_0;
        r3 = _v_1;
        _g_0 = r0;
        _acc_0 = r1;
        _dq_0 = r2;
        _dq_1 = r3;
        WL_AGAIN(FID_NAT_SHOW_FIN);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HANDLES)
  {
    Term _values_0 = r0;
    WL_OPEN
    if (term_aux(_values_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 14);
      WL_RETN(1);
    } else {
      u64 _sp_0 = term_loc(_values_0);
      Term _f_0 = e.mem[_sp_0 + 0];
      Term _f_1 = e.mem[_sp_0 + 1];
      u64 _sp_1 = term_loc(_f_0);
      u32 _f_2 = e.mem[_sp_1 + 0];
      u32 _f_3 = e.mem[_sp_1 + 1];
      heap_free(e, cls_fit(2), _sp_1);
      heap_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(3);
        STK(0) = _f_3;
        STK(1) = _f_1;
        STK(2) = FID_HANDLES_K36;
        WL_PUSHN(3);
      } else {
        u64 _t_0 = task_node(e, FID_HANDLES_K36, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_3;
        e.mem[_t_0 + 1] = _f_1;
        WL_CONT = term_tsk(FID_HANDLES_K36, _t_0);
        WL_IDX = 2;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_2;
        return term_tsk(FID_U32_SHOW, _t_1);
      }
      r0 = _f_2;
      WL_JMP(FID_U32_SHOW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HANDLES_K36)
  {
    WL_POPN(2);
    u32 _f_4 = STK(0);
    Term _f_5 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _f_5;
      STK(1) = _h_0;
      STK(2) = FID_HANDLES_K37;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID_HANDLES_K37, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _f_5;
      e.mem[_t_2 + 1] = _h_0;
      WL_CONT = term_tsk(FID_HANDLES_K37, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_4;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _f_4;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HANDLES_K37)
  {
    WL_POPN(2);
    Term _f_6 = STK(0);
    Term _h_2 = STK(1);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_2;
      STK(1) = _h_1;
      STK(2) = FID_HANDLES_K38;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_HANDLES_K38, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      e.mem[_t_4 + 1] = _h_1;
      WL_CONT = term_tsk(FID_HANDLES_K38, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HANDLES)) {
      u64 _t_5 = task_node(e, FID_HANDLES, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _f_6;
      return term_tsk(FID_HANDLES, _t_5);
    }
    r0 = _f_6;
    WL_JMP(FID_HANDLES);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HANDLES_K38)
  {
    WL_POPN(2);
    Term _h_4 = STK(0);
    Term _h_5 = STK(1);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_4;
      STK(1) = _h_5;
      STK(2) = FID_HANDLES_K39;
      WL_PUSHN(3);
    } else {
      u64 _t_6 = task_node(e, FID_HANDLES_K39, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_4;
      e.mem[_t_6 + 1] = _h_5;
      WL_CONT = term_tsk(FID_HANDLES_K39, _t_6);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 16);
      e.mem[_t_7 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 16);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HANDLES_K39)
  {
    WL_POPN(2);
    Term _h_7 = STK(0);
    Term _h_8 = STK(1);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_7;
      STK(1) = FID_HANDLES_K40;
      WL_PUSHN(2);
    } else {
      u64 _t_8 = task_node(e, FID_HANDLES_K40, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_7;
      WL_CONT = term_tsk(FID_HANDLES_K40, _t_8);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_8;
      e.mem[_t_9 + 1] = _h_6;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _h_8;
    r1 = _h_6;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HANDLES_K40)
  {
    WL_POPN(1);
    Term _h_10 = STK(0);
    Term _h_9 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_10;
      STK(1) = FID_HANDLES_K41;
      WL_PUSHN(2);
    } else {
      u64 _t_10 = task_node(e, FID_HANDLES_K41, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_10;
      WL_CONT = term_tsk(FID_HANDLES_K41, _t_10);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 18);
      e.mem[_t_11 + 1] = _h_9;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 18);
    r1 = _h_9;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HANDLES_K41)
  {
    WL_POPN(1);
    Term _h_12 = STK(0);
    Term _h_11 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_12 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = _h_12;
      e.mem[_t_12 + 1] = _h_11;
      return term_tsk(FID_STRING_APPEND, _t_12);
    }
    r0 = _h_12;
    r1 = _h_11;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_WORDS)
  {
    Term _array_0 = r0;
    WL_OPEN
    WL_SPIN
    if (blk_cls(_array_0) == 0) {
      u32 _c_0 = blk_read(e.mem, 0, blk_loc(e.mem, _array_0), 0 + 0);
      blk_free(e, _array_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _c_0;
        STK(1) = FID_WORDS_K43;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_WORDS_K43, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _c_0;
        WL_CONT = term_tsk(FID_WORDS_K43, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _c_0;
        return term_tsk(FID_U32_SHOW, _t_1);
      }
      r0 = _c_0;
      WL_JMP(FID_U32_SHOW);
    } else {
      Term _h_1 = blk_half(e, _array_0, 0);
      Term _h_2 = blk_half(e, _array_0, 1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _h_2;
        STK(1) = FID_WORDS_K44;
        WL_PUSHN(2);
      } else {
        u64 _t_2 = task_node(e, FID_WORDS_K44, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _h_2;
        WL_CONT = term_tsk(FID_WORDS_K44, _t_2);
        WL_IDX = 1;
      }
      r0 = _h_1;
      _array_0 = r0;
      WL_AGAIN(FID_WORDS);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_WORDS_K43)
  {
    WL_POPN(1);
    u32 _c_1 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    Term _fv_0[1];
    _fv_0[0] = _c_1;
    r0 = blk_new(e, 0, 0, 0, 1, _fv_0);
    r1 = _h_0;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_WORDS_K44)
  {
    WL_POPN(1);
    Term _h_5 = STK(0);
    Term _h_3 = r0;
    Term _h_4 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_3;
      STK(1) = _h_4;
      STK(2) = FID_WORDS_K45;
      WL_PUSHN(3);
    } else {
      u64 _t_3 = task_node(e, FID_WORDS_K45, WL_CONT, WL_IDX, 1);
      e.mem[_t_3 + 0] = _h_3;
      e.mem[_t_3 + 1] = _h_4;
      WL_CONT = term_tsk(FID_WORDS_K45, _t_3);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_WORDS)) {
      u64 _t_4 = task_node(e, FID_WORDS, WL_CONT, WL_IDX, 0);
      e.mem[_t_4 + 0] = _h_5;
      return term_tsk(FID_WORDS, _t_4);
    }
    r0 = _h_5;
    WL_JMP(FID_WORDS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_WORDS_K45)
  {
    WL_POPN(2);
    Term _h_8 = STK(0);
    Term _h_9 = STK(1);
    Term _h_6 = r0;
    Term _h_7 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_8;
      STK(1) = _h_9;
      STK(2) = _h_6;
      STK(3) = FID_WORDS_K46;
      WL_PUSHN(4);
    } else {
      u64 _t_5 = task_node(e, FID_WORDS_K46, WL_CONT, WL_IDX, 1);
      e.mem[_t_5 + 0] = _h_8;
      e.mem[_t_5 + 1] = _h_9;
      e.mem[_t_5 + 2] = _h_6;
      WL_CONT = term_tsk(FID_WORDS_K46, _t_5);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _h_7;
      e.mem[_t_6 + 1] = term_ctr(CID_SCON, STAT_OFF + 0);
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = _h_7;
    r1 = term_ctr(CID_SCON, STAT_OFF + 0);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_WORDS_K46)
  {
    WL_POPN(3);
    Term _h_11 = STK(0);
    Term _h_12 = STK(1);
    Term _h_13 = STK(2);
    Term _h_10 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_11;
      STK(1) = _h_12;
      STK(2) = _h_13;
      STK(3) = FID_WORDS_K47;
      WL_PUSHN(4);
    } else {
      u64 _t_7 = task_node(e, FID_WORDS_K47, WL_CONT, WL_IDX, 1);
      e.mem[_t_7 + 0] = _h_11;
      e.mem[_t_7 + 1] = _h_12;
      e.mem[_t_7 + 2] = _h_13;
      WL_CONT = term_tsk(FID_WORDS_K47, _t_7);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_8 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = term_ctr(CID_SCON, STAT_OFF + 2);
      e.mem[_t_8 + 1] = _h_10;
      return term_tsk(FID_STRING_APPEND, _t_8);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 2);
    r1 = _h_10;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_WORDS_K47)
  {
    WL_POPN(3);
    Term _h_15 = STK(0);
    Term _h_16 = STK(1);
    Term _h_17 = STK(2);
    Term _h_14 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_15;
      STK(1) = _h_17;
      STK(2) = FID_WORDS_K48;
      WL_PUSHN(3);
    } else {
      u64 _t_9 = task_node(e, FID_WORDS_K48, WL_CONT, WL_IDX, 1);
      e.mem[_t_9 + 0] = _h_15;
      e.mem[_t_9 + 1] = _h_17;
      WL_CONT = term_tsk(FID_WORDS_K48, _t_9);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_10 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = _h_16;
      e.mem[_t_10 + 1] = _h_14;
      return term_tsk(FID_STRING_APPEND, _t_10);
    }
    r0 = _h_16;
    r1 = _h_14;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_WORDS_K48)
  {
    WL_POPN(2);
    Term _h_19 = STK(0);
    Term _h_20 = STK(1);
    Term _h_18 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_19;
      STK(1) = _h_20;
      STK(2) = FID_WORDS_K49;
      WL_PUSHN(3);
    } else {
      u64 _t_11 = task_node(e, FID_WORDS_K49, WL_CONT, WL_IDX, 1);
      e.mem[_t_11 + 0] = _h_19;
      e.mem[_t_11 + 1] = _h_20;
      WL_CONT = term_tsk(FID_WORDS_K49, _t_11);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_12 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = term_ctr(CID_SCON, STAT_OFF + 4);
      e.mem[_t_12 + 1] = _h_18;
      return term_tsk(FID_STRING_APPEND, _t_12);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 4);
    r1 = _h_18;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_WORDS_K49)
  {
    WL_POPN(2);
    Term _h_22 = STK(0);
    Term _h_23 = STK(1);
    Term _h_21 = r0;
    WL_OPEN
    r0 = blk_node(e, _h_22, _h_23);
    r1 = _h_21;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_FLAGS)
  {
    Term _values_0 = r0;
    WL_OPEN
    WL_SPIN
    if (blk_cls(_values_0) == 1) {
      u32 _c_0 = blk_read(e.mem, 1, blk_loc(e.mem, _values_0), 0 + 0);
      Term _c_1 = blk_shr(_values_0) ? blk_keep(e, blk_loc(e.mem, _values_0) + 0 + 1) : e.mem[blk_loc(e.mem, _values_0) + 0 + 1];
      blk_free(e, _values_0);
      u32 _o_0 = 0;
      if (_c_0 == 0) {
        _o_0 = 0;
      } else {
        _o_0 = 1;
      }
      if (_o_0 == 0) {
        r0 = term_ctr(CID_SCON, STAT_OFF + 6);
        WL_RETN(1);
      } else {
        r0 = term_ctr(CID_SCON, STAT_OFF + 20);
        WL_RETN(1);
      }
    } else {
      Term _h_0 = blk_half(e, _values_0, 0);
      Term _h_1 = blk_half(e, _values_0, 1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _h_1;
        STK(1) = FID_FLAGS_K52;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_FLAGS_K52, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _h_1;
        WL_CONT = term_tsk(FID_FLAGS_K52, _t_0);
        WL_IDX = 1;
      }
      r0 = _h_0;
      _values_0 = r0;
      WL_AGAIN(FID_FLAGS);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_FLAGS_K52)
  {
    WL_POPN(1);
    Term _h_3 = STK(0);
    Term _h_2 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_2;
      STK(1) = FID_FLAGS_K53;
      WL_PUSHN(2);
    } else {
      u64 _t_1 = task_node(e, FID_FLAGS_K53, WL_CONT, WL_IDX, 1);
      e.mem[_t_1 + 0] = _h_2;
      WL_CONT = term_tsk(FID_FLAGS_K53, _t_1);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_FLAGS)) {
      u64 _t_2 = task_node(e, FID_FLAGS, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _h_3;
      return term_tsk(FID_FLAGS, _t_2);
    }
    r0 = _h_3;
    WL_JMP(FID_FLAGS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_FLAGS_K53)
  {
    WL_POPN(1);
    Term _h_5 = STK(0);
    Term _h_4 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_5;
      STK(1) = FID_FLAGS_K54;
      WL_PUSHN(2);
    } else {
      u64 _t_3 = task_node(e, FID_FLAGS_K54, WL_CONT, WL_IDX, 1);
      e.mem[_t_3 + 0] = _h_5;
      WL_CONT = term_tsk(FID_FLAGS_K54, _t_3);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_4 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_4 + 0] = _h_4;
      e.mem[_t_4 + 1] = term_ctr(CID_SCON, STAT_OFF + 0);
      return term_tsk(FID_STRING_APPEND, _t_4);
    }
    r0 = _h_4;
    r1 = term_ctr(CID_SCON, STAT_OFF + 0);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_FLAGS_K54)
  {
    WL_POPN(1);
    Term _h_7 = STK(0);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_7;
      STK(1) = FID_FLAGS_K55;
      WL_PUSHN(2);
    } else {
      u64 _t_5 = task_node(e, FID_FLAGS_K55, WL_CONT, WL_IDX, 1);
      e.mem[_t_5 + 0] = _h_7;
      WL_CONT = term_tsk(FID_FLAGS_K55, _t_5);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 2);
      e.mem[_t_6 + 1] = _h_6;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 2);
    r1 = _h_6;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_FLAGS_K55)
  {
    WL_POPN(1);
    Term _h_9 = STK(0);
    Term _h_8 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_FLAGS_K56;
      WL_PUSHN(1);
    } else {
      u64 _t_7 = task_node(e, FID_FLAGS_K56, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_FLAGS_K56, _t_7);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_8 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _h_9;
      e.mem[_t_8 + 1] = _h_8;
      return term_tsk(FID_STRING_APPEND, _t_8);
    }
    r0 = _h_9;
    r1 = _h_8;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_FLAGS_K56)
  {
    Term _h_10 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = term_ctr(CID_SCON, STAT_OFF + 4);
      e.mem[_t_9 + 1] = _h_10;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 4);
    r1 = _h_10;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_BOOLS)
  {
    Term _values_0 = r0;
    WL_OPEN
    WL_SPIN
    if (blk_cls(_values_0) == 0) {
      u32 _c_0 = blk_read(e.mem, 0, blk_loc(e.mem, _values_0), 0 + 0);
      blk_free(e, _values_0);
      if (_c_0 == 0) {
        r0 = term_ctr(CID_SCON, STAT_OFF + 6);
        WL_RETN(1);
      } else {
        r0 = term_ctr(CID_SCON, STAT_OFF + 20);
        WL_RETN(1);
      }
    } else {
      Term _h_0 = blk_half(e, _values_0, 0);
      Term _h_1 = blk_half(e, _values_0, 1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _h_1;
        STK(1) = FID_BOOLS_K58;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_BOOLS_K58, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _h_1;
        WL_CONT = term_tsk(FID_BOOLS_K58, _t_0);
        WL_IDX = 1;
      }
      r0 = _h_0;
      _values_0 = r0;
      WL_AGAIN(FID_BOOLS);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_BOOLS_K58)
  {
    WL_POPN(1);
    Term _h_3 = STK(0);
    Term _h_2 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_2;
      STK(1) = FID_BOOLS_K59;
      WL_PUSHN(2);
    } else {
      u64 _t_1 = task_node(e, FID_BOOLS_K59, WL_CONT, WL_IDX, 1);
      e.mem[_t_1 + 0] = _h_2;
      WL_CONT = term_tsk(FID_BOOLS_K59, _t_1);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_BOOLS)) {
      u64 _t_2 = task_node(e, FID_BOOLS, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _h_3;
      return term_tsk(FID_BOOLS, _t_2);
    }
    r0 = _h_3;
    WL_JMP(FID_BOOLS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_BOOLS_K59)
  {
    WL_POPN(1);
    Term _h_5 = STK(0);
    Term _h_4 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_5;
      STK(1) = FID_BOOLS_K60;
      WL_PUSHN(2);
    } else {
      u64 _t_3 = task_node(e, FID_BOOLS_K60, WL_CONT, WL_IDX, 1);
      e.mem[_t_3 + 0] = _h_5;
      WL_CONT = term_tsk(FID_BOOLS_K60, _t_3);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_4 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_4 + 0] = _h_4;
      e.mem[_t_4 + 1] = term_ctr(CID_SCON, STAT_OFF + 0);
      return term_tsk(FID_STRING_APPEND, _t_4);
    }
    r0 = _h_4;
    r1 = term_ctr(CID_SCON, STAT_OFF + 0);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_BOOLS_K60)
  {
    WL_POPN(1);
    Term _h_7 = STK(0);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_7;
      STK(1) = FID_BOOLS_K61;
      WL_PUSHN(2);
    } else {
      u64 _t_5 = task_node(e, FID_BOOLS_K61, WL_CONT, WL_IDX, 1);
      e.mem[_t_5 + 0] = _h_7;
      WL_CONT = term_tsk(FID_BOOLS_K61, _t_5);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 2);
      e.mem[_t_6 + 1] = _h_6;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 2);
    r1 = _h_6;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_BOOLS_K61)
  {
    WL_POPN(1);
    Term _h_9 = STK(0);
    Term _h_8 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_BOOLS_K62;
      WL_PUSHN(1);
    } else {
      u64 _t_7 = task_node(e, FID_BOOLS_K62, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_BOOLS_K62, _t_7);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_8 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _h_9;
      e.mem[_t_8 + 1] = _h_8;
      return term_tsk(FID_STRING_APPEND, _t_8);
    }
    r0 = _h_9;
    r1 = _h_8;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_BOOLS_K62)
  {
    Term _h_10 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = term_ctr(CID_SCON, STAT_OFF + 4);
      e.mem[_t_9 + 1] = _h_10;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 4);
    r1 = _h_10;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NAT_SHOW)
  {
    Term _n_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    Term _a_0 = 10ull;
    Term _a_1 = (_a_0 == 0 ? 0 : _n_0 / _a_0);
    Term _a_2 = (_a_0 == 0 ? _n_0 : _n_0 % _a_0);
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _o_0[2];
    if (spin_6(e, _o_0, _a_1, _a_2) == 0) {
      return 0;
    }
    _v_2 = _o_0[0];
    _v_3 = _o_0[1];
    _v_0 = _v_2;
    _v_1 = _v_3;
    if (!DEVICE && !seq && fid_nofk(FID_NAT_SHOW_FIN)) {
      u64 _t_0 = task_node(e, FID_NAT_SHOW_FIN, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _n_0;
      e.mem[_t_0 + 1] = term_pak(CID_SNIL, 0);
      e.mem[_t_0 + 2] = _v_0;
      e.mem[_t_0 + 3] = _v_1;
      return term_tsk(FID_NAT_SHOW_FIN, _t_0);
    }
    r0 = _n_0;
    r1 = term_pak(CID_SNIL, 0);
    r2 = _v_0;
    r3 = _v_1;
    WL_JMP(FID_NAT_SHOW_FIN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW)
  {
    u32 _a_0 = r0;
    WL_OPEN
    u32 _s_0 = U32_BIN(_a_0, ==, 0);
    if (_s_0 == 1) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 6);
      WL_RETN(1);
    } else {
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW_GO)) {
        u64 _t_0 = task_node(e, FID_U32_SHOW_GO, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = 10ull;
        e.mem[_t_0 + 1] = _a_0;
        e.mem[_t_0 + 2] = term_pak(CID_SNIL, 0);
        return term_tsk(FID_U32_SHOW_GO, _t_0);
      }
      r0 = 10ull;
      r1 = _a_0;
      r2 = term_pak(CID_SNIL, 0);
      WL_JMP(FID_U32_SHOW_GO);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNED)
  {
    Term _owner_0 = r0;
    u32 _owner_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _owner_1;
      STK(1) = FID_OWNED_K67;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_OWNED_K67, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _owner_1;
      WL_CONT = term_tsk(FID_OWNED_K67, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_WORDS)) {
      u64 _t_1 = task_node(e, FID_WORDS, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _owner_0;
      return term_tsk(FID_WORDS, _t_1);
    }
    r0 = _owner_0;
    WL_JMP(FID_WORDS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNED_K67)
  {
    WL_POPN(1);
    u32 _owner_2 = STK(0);
    Term _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _owner_2;
      STK(1) = _h_0;
      STK(2) = _h_1;
      STK(3) = FID_OWNED_K68;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID_OWNED_K68, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _owner_2;
      e.mem[_t_2 + 1] = _h_0;
      e.mem[_t_2 + 2] = _h_1;
      WL_CONT = term_tsk(FID_OWNED_K68, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _owner_2;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _owner_2;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNED_K68)
  {
    WL_POPN(3);
    u32 _owner_3 = STK(0);
    Term _h_3 = STK(1);
    Term _h_4 = STK(2);
    Term _h_2 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _owner_3;
      STK(1) = _h_3;
      STK(2) = _h_4;
      STK(3) = FID_OWNED_K69;
      WL_PUSHN(4);
    } else {
      u64 _t_4 = task_node(e, FID_OWNED_K69, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _owner_3;
      e.mem[_t_4 + 1] = _h_3;
      e.mem[_t_4 + 2] = _h_4;
      WL_CONT = term_tsk(FID_OWNED_K69, _t_4);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 8);
      e.mem[_t_5 + 1] = _h_2;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 8);
    r1 = _h_2;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNED_K69)
  {
    WL_POPN(3);
    u32 _owner_4 = STK(0);
    Term _h_6 = STK(1);
    Term _h_7 = STK(2);
    Term _h_5 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _owner_4;
      STK(1) = _h_6;
      STK(2) = FID_OWNED_K70;
      WL_PUSHN(3);
    } else {
      u64 _t_6 = task_node(e, FID_OWNED_K70, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _owner_4;
      e.mem[_t_6 + 1] = _h_6;
      WL_CONT = term_tsk(FID_OWNED_K70, _t_6);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_7;
      e.mem[_t_7 + 1] = _h_5;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_7;
    r1 = _h_5;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNED_K70)
  {
    WL_POPN(2);
    u32 _owner_5 = STK(0);
    Term _h_9 = STK(1);
    Term _h_8 = r0;
    WL_OPEN
    r0 = _h_9;
    r1 = _owner_5;
    r2 = _h_8;
    WL_RETN(3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS)
  {
    Term _array_0 = r0;
    WL_OPEN
    WL_SPIN
    if (blk_cls(_array_0) == 1) {
      u32 _c_0 = blk_read(e.mem, 1, blk_loc(e.mem, _array_0), 0 + 0);
      Term _c_1 = blk_shr(_array_0) ? blk_keep(e, blk_loc(e.mem, _array_0) + 0 + 1) : e.mem[blk_loc(e.mem, _array_0) + 0 + 1];
      blk_free(e, _array_0);
      u32 _o_0 = 0;
      Term _o_1 = 0;
      u32 _o_2 = 0;
      if (_c_0 == 0) {
        _o_0 = 0;
      } else {
        _o_0 = 1;
        Term _fb_0[2];
        u64 _sp_0 = ctr_take(e, _c_1, 2, _fb_0);
        Term _f_0 = _fb_0[0];
        u32 _f_1 = _fb_0[1];
        spare_free(e, cls_fit(2), _sp_0);
        _o_1 = _f_0;
        _o_2 = _f_1;
      }
      if (_o_0 == 0) {
        u32 _o_3 = 0;
        Term _o_4 = 0;
        Term _t_0 = 0;
        if (_t_0 == 0) {
          _o_3 = 0;
        } else {
          _o_3 = 1;
          u64 _nd_0 = heap_alloc(e, cls_fit(2));
          e.mem[_nd_0 + 0] = rfc_seal(e, 0);
          e.mem[_nd_0 + 1] = rfc_seal(e, 0);
          _o_4 = term_ctr(CID_OWNED, _nd_0);
        }
        Term _fv_0[2];
        _fv_0[0] = _o_3;
        _fv_0[1] = _o_4;
        r0 = blk_new(e, 1, 0, 1, 2, _fv_0);
        r1 = term_ctr(CID_SCON, STAT_OFF + 28);
        WL_RETN(2);
      } else {
        if (seq) {
          WL_ROOM(1);
          STK(0) = FID_OWNERS_K72;
          WL_PUSHN(1);
        } else {
          u64 _t_1 = task_node(e, FID_OWNERS_K72, WL_CONT, WL_IDX, 1);
          WL_CONT = term_tsk(FID_OWNERS_K72, _t_1);
          WL_IDX = 0;
        }
        if (!DEVICE && !seq && fid_nofk(FID_OWNED)) {
          u64 _t_2 = task_node(e, FID_OWNED, WL_CONT, WL_IDX, 0);
          e.mem[_t_2 + 0] = _o_1;
          e.mem[_t_2 + 1] = _o_2;
          return term_tsk(FID_OWNED, _t_2);
        }
        r0 = _o_1;
        r1 = _o_2;
        WL_JMP(FID_OWNED);
      }
    } else {
      Term _h_3 = blk_half(e, _array_0, 0);
      Term _h_4 = blk_half(e, _array_0, 1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _h_4;
        STK(1) = FID_OWNERS_K73;
        WL_PUSHN(2);
      } else {
        u64 _t_4 = task_node(e, FID_OWNERS_K73, WL_CONT, WL_IDX, 1);
        e.mem[_t_4 + 0] = _h_4;
        WL_CONT = term_tsk(FID_OWNERS_K73, _t_4);
        WL_IDX = 1;
      }
      r0 = _h_3;
      _array_0 = r0;
      WL_AGAIN(FID_OWNERS);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_K72)
  {
    Term _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_7[2];
    if (spin_17(e, _o_7, _h_0, blk_loc(e.mem, _h_0), _h_1, _h_2, blk_loc(e.mem, _h_2)) == 0) {
      return 0;
    }
    _v_0 = _o_7[0];
    _v_1 = _o_7[1];
    r0 = _v_0;
    r1 = _v_1;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_K73)
  {
    WL_POPN(1);
    Term _h_7 = STK(0);
    Term _h_5 = r0;
    Term _h_6 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_5;
      STK(1) = _h_6;
      STK(2) = FID_OWNERS_K74;
      WL_PUSHN(3);
    } else {
      u64 _t_5 = task_node(e, FID_OWNERS_K74, WL_CONT, WL_IDX, 1);
      e.mem[_t_5 + 0] = _h_5;
      e.mem[_t_5 + 1] = _h_6;
      WL_CONT = term_tsk(FID_OWNERS_K74, _t_5);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OWNERS)) {
      u64 _t_6 = task_node(e, FID_OWNERS, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _h_7;
      return term_tsk(FID_OWNERS, _t_6);
    }
    r0 = _h_7;
    WL_JMP(FID_OWNERS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_K74)
  {
    WL_POPN(2);
    Term _h_10 = STK(0);
    Term _h_11 = STK(1);
    Term _h_8 = r0;
    Term _h_9 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_10;
      STK(1) = _h_11;
      STK(2) = _h_8;
      STK(3) = FID_OWNERS_K75;
      WL_PUSHN(4);
    } else {
      u64 _t_7 = task_node(e, FID_OWNERS_K75, WL_CONT, WL_IDX, 1);
      e.mem[_t_7 + 0] = _h_10;
      e.mem[_t_7 + 1] = _h_11;
      e.mem[_t_7 + 2] = _h_8;
      WL_CONT = term_tsk(FID_OWNERS_K75, _t_7);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_8 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _h_9;
      e.mem[_t_8 + 1] = term_ctr(CID_SCON, STAT_OFF + 0);
      return term_tsk(FID_STRING_APPEND, _t_8);
    }
    r0 = _h_9;
    r1 = term_ctr(CID_SCON, STAT_OFF + 0);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_K75)
  {
    WL_POPN(3);
    Term _h_13 = STK(0);
    Term _h_14 = STK(1);
    Term _h_15 = STK(2);
    Term _h_12 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_13;
      STK(1) = _h_14;
      STK(2) = _h_15;
      STK(3) = FID_OWNERS_K76;
      WL_PUSHN(4);
    } else {
      u64 _t_9 = task_node(e, FID_OWNERS_K76, WL_CONT, WL_IDX, 1);
      e.mem[_t_9 + 0] = _h_13;
      e.mem[_t_9 + 1] = _h_14;
      e.mem[_t_9 + 2] = _h_15;
      WL_CONT = term_tsk(FID_OWNERS_K76, _t_9);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_10 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = term_ctr(CID_SCON, STAT_OFF + 2);
      e.mem[_t_10 + 1] = _h_12;
      return term_tsk(FID_STRING_APPEND, _t_10);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 2);
    r1 = _h_12;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_K76)
  {
    WL_POPN(3);
    Term _h_17 = STK(0);
    Term _h_18 = STK(1);
    Term _h_19 = STK(2);
    Term _h_16 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_17;
      STK(1) = _h_19;
      STK(2) = FID_OWNERS_K77;
      WL_PUSHN(3);
    } else {
      u64 _t_11 = task_node(e, FID_OWNERS_K77, WL_CONT, WL_IDX, 1);
      e.mem[_t_11 + 0] = _h_17;
      e.mem[_t_11 + 1] = _h_19;
      WL_CONT = term_tsk(FID_OWNERS_K77, _t_11);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_12 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = _h_18;
      e.mem[_t_12 + 1] = _h_16;
      return term_tsk(FID_STRING_APPEND, _t_12);
    }
    r0 = _h_18;
    r1 = _h_16;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_K77)
  {
    WL_POPN(2);
    Term _h_21 = STK(0);
    Term _h_22 = STK(1);
    Term _h_20 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_21;
      STK(1) = _h_22;
      STK(2) = FID_OWNERS_K78;
      WL_PUSHN(3);
    } else {
      u64 _t_13 = task_node(e, FID_OWNERS_K78, WL_CONT, WL_IDX, 1);
      e.mem[_t_13 + 0] = _h_21;
      e.mem[_t_13 + 1] = _h_22;
      WL_CONT = term_tsk(FID_OWNERS_K78, _t_13);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_14 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_14 + 0] = term_ctr(CID_SCON, STAT_OFF + 4);
      e.mem[_t_14 + 1] = _h_20;
      return term_tsk(FID_STRING_APPEND, _t_14);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 4);
    r1 = _h_20;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OWNERS_K78)
  {
    WL_POPN(2);
    Term _h_24 = STK(0);
    Term _h_25 = STK(1);
    Term _h_23 = r0;
    WL_OPEN
    r0 = blk_node(e, _h_24, _h_25);
    r1 = _h_23;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT)
  {
    u32 _result_0 = r0;
    u32 _result_1 = r1;
    Term _result_2 = r2;
    Term _result_3 = r3;
    Term _result_4 = r4;
    Term _result_5 = r5;
    Term _result_6 = r6;
    Term _result_7 = r7;
    u32 _result_8 = r8;
    Term _result_9 = r9;
    u32 _result_10 = r10;
    Term _result_11 = r11;
    u32 _result_12 = r12;
    Term _result_13 = r13;
    u32 _result_14 = r14;
    u32 _result_15 = r15;
    Term _result_16 = r16;
    WL_OPEN
    if (term_aux(_result_11) == CID_NIL) {
      if (_result_12 == 1) {
        if (seq) {
          WL_ROOM(15);
          STK(0) = _result_0;
          STK(1) = _result_1;
          STK(2) = _result_13;
          STK(3) = _result_14;
          STK(4) = _result_15;
          STK(5) = _result_16;
          STK(6) = _result_3;
          STK(7) = _result_4;
          STK(8) = _result_5;
          STK(9) = _result_6;
          STK(10) = _result_7;
          STK(11) = _result_8;
          STK(12) = _result_9;
          STK(13) = _result_10;
          STK(14) = FID_SNAPSHOT_K166;
          WL_PUSHN(15);
        } else {
          u64 _t_0 = task_node(e, FID_SNAPSHOT_K166, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _result_0;
          e.mem[_t_0 + 1] = _result_1;
          e.mem[_t_0 + 2] = _result_13;
          e.mem[_t_0 + 3] = _result_14;
          e.mem[_t_0 + 4] = _result_15;
          e.mem[_t_0 + 5] = _result_16;
          e.mem[_t_0 + 6] = _result_3;
          e.mem[_t_0 + 7] = _result_4;
          e.mem[_t_0 + 8] = _result_5;
          e.mem[_t_0 + 9] = _result_6;
          e.mem[_t_0 + 10] = _result_7;
          e.mem[_t_0 + 11] = _result_8;
          e.mem[_t_0 + 12] = _result_9;
          e.mem[_t_0 + 13] = _result_10;
          WL_CONT = term_tsk(FID_SNAPSHOT_K166, _t_0);
          WL_IDX = 14;
        }
        if (!DEVICE && !seq && fid_nofk(FID_OWNERS)) {
          u64 _t_1 = task_node(e, FID_OWNERS, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _result_2;
          return term_tsk(FID_OWNERS, _t_1);
        }
        r0 = _result_2;
        WL_JMP(FID_OWNERS);
      } else {
        term_sink(e, _result_2);
        term_sink(e, _result_3);
        term_sink(e, _result_4);
        term_sink(e, _result_5);
        term_sink(e, _result_6);
        term_sink(e, _result_7);
        term_sink(e, _result_13);
        term_sink(e, _result_16);
        r0 = term_ctr(CID_SCON, STAT_OFF + 66);
        WL_RETN(1);
      }
    } else {
      term_sink(e, _result_2);
      term_sink(e, _result_3);
      term_sink(e, _result_4);
      term_sink(e, _result_5);
      term_sink(e, _result_6);
      term_sink(e, _result_7);
      term_sink(e, _result_11);
      term_sink(e, _result_13);
      term_sink(e, _result_16);
      r0 = term_ctr(CID_SCON, STAT_OFF + 66);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K166)
  {
    WL_POPN(14);
    u32 _result_17 = STK(0);
    u32 _result_18 = STK(1);
    Term _result_19 = STK(2);
    u32 _result_20 = STK(3);
    u32 _result_21 = STK(4);
    Term _result_22 = STK(5);
    Term _result_23 = STK(6);
    Term _result_24 = STK(7);
    Term _result_25 = STK(8);
    Term _result_26 = STK(9);
    Term _result_27 = STK(10);
    u32 _result_28 = STK(11);
    Term _result_29 = STK(12);
    u32 _result_30 = STK(13);
    Term _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _result_17;
      STK(1) = _result_18;
      STK(2) = _result_19;
      STK(3) = _result_20;
      STK(4) = _result_21;
      STK(5) = _result_22;
      STK(6) = _result_24;
      STK(7) = _result_25;
      STK(8) = _result_26;
      STK(9) = _result_27;
      STK(10) = _result_28;
      STK(11) = _result_29;
      STK(12) = _result_30;
      STK(13) = _h_0;
      STK(14) = _h_1;
      STK(15) = FID_SNAPSHOT_K167;
      WL_PUSHN(16);
    } else {
      u64 _t_2 = task_node(e, FID_SNAPSHOT_K167, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _result_17;
      e.mem[_t_2 + 1] = _result_18;
      e.mem[_t_2 + 2] = _result_19;
      e.mem[_t_2 + 3] = _result_20;
      e.mem[_t_2 + 4] = _result_21;
      e.mem[_t_2 + 5] = _result_22;
      e.mem[_t_2 + 6] = _result_24;
      e.mem[_t_2 + 7] = _result_25;
      e.mem[_t_2 + 8] = _result_26;
      e.mem[_t_2 + 9] = _result_27;
      e.mem[_t_2 + 10] = _result_28;
      e.mem[_t_2 + 11] = _result_29;
      e.mem[_t_2 + 12] = _result_30;
      e.mem[_t_2 + 13] = _h_0;
      e.mem[_t_2 + 14] = _h_1;
      WL_CONT = term_tsk(FID_SNAPSHOT_K167, _t_2);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OWNERS)) {
      u64 _t_3 = task_node(e, FID_OWNERS, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _result_23;
      return term_tsk(FID_OWNERS, _t_3);
    }
    r0 = _result_23;
    WL_JMP(FID_OWNERS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K167)
  {
    WL_POPN(15);
    u32 _result_31 = STK(0);
    u32 _result_32 = STK(1);
    Term _result_33 = STK(2);
    u32 _result_34 = STK(3);
    u32 _result_35 = STK(4);
    Term _result_36 = STK(5);
    Term _result_37 = STK(6);
    Term _result_38 = STK(7);
    Term _result_39 = STK(8);
    Term _result_40 = STK(9);
    u32 _result_41 = STK(10);
    Term _result_42 = STK(11);
    u32 _result_43 = STK(12);
    Term _h_4 = STK(13);
    Term _h_5 = STK(14);
    Term _h_2 = r0;
    Term _h_3 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _result_31;
      STK(1) = _result_32;
      STK(2) = _result_35;
      STK(3) = _result_36;
      STK(4) = _result_37;
      STK(5) = _result_38;
      STK(6) = _result_39;
      STK(7) = _result_40;
      STK(8) = _result_41;
      STK(9) = _result_42;
      STK(10) = _result_43;
      STK(11) = _h_4;
      STK(12) = _h_5;
      STK(13) = _h_2;
      STK(14) = _h_3;
      STK(15) = FID_SNAPSHOT_K168;
      WL_PUSHN(16);
    } else {
      u64 _t_4 = task_node(e, FID_SNAPSHOT_K168, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _result_31;
      e.mem[_t_4 + 1] = _result_32;
      e.mem[_t_4 + 2] = _result_35;
      e.mem[_t_4 + 3] = _result_36;
      e.mem[_t_4 + 4] = _result_37;
      e.mem[_t_4 + 5] = _result_38;
      e.mem[_t_4 + 6] = _result_39;
      e.mem[_t_4 + 7] = _result_40;
      e.mem[_t_4 + 8] = _result_41;
      e.mem[_t_4 + 9] = _result_42;
      e.mem[_t_4 + 10] = _result_43;
      e.mem[_t_4 + 11] = _h_4;
      e.mem[_t_4 + 12] = _h_5;
      e.mem[_t_4 + 13] = _h_2;
      e.mem[_t_4 + 14] = _h_3;
      WL_CONT = term_tsk(FID_SNAPSHOT_K168, _t_4);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OWNED)) {
      u64 _t_5 = task_node(e, FID_OWNED, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _result_33;
      e.mem[_t_5 + 1] = _result_34;
      return term_tsk(FID_OWNED, _t_5);
    }
    r0 = _result_33;
    r1 = _result_34;
    WL_JMP(FID_OWNED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K168)
  {
    WL_POPN(15);
    u32 _result_44 = STK(0);
    u32 _result_45 = STK(1);
    u32 _result_46 = STK(2);
    Term _result_47 = STK(3);
    Term _result_48 = STK(4);
    Term _result_49 = STK(5);
    Term _result_50 = STK(6);
    Term _result_51 = STK(7);
    u32 _result_52 = STK(8);
    Term _result_53 = STK(9);
    u32 _result_54 = STK(10);
    Term _h_9 = STK(11);
    Term _h_10 = STK(12);
    Term _h_11 = STK(13);
    Term _h_12 = STK(14);
    Term _h_6 = r0;
    u32 _h_7 = r1;
    Term _h_8 = r2;
    WL_OPEN
    term_sink(e, _h_9);
    term_sink(e, _h_11);
    term_sink(e, _h_6);
    if (seq) {
      WL_ROOM(14);
      STK(0) = _result_45;
      STK(1) = _result_52;
      STK(2) = _result_53;
      STK(3) = _result_54;
      STK(4) = _result_48;
      STK(5) = _result_49;
      STK(6) = _result_50;
      STK(7) = _result_51;
      STK(8) = _result_46;
      STK(9) = _result_47;
      STK(10) = _h_10;
      STK(11) = _h_12;
      STK(12) = _h_8;
      STK(13) = FID_SNAPSHOT_K169;
      WL_PUSHN(14);
    } else {
      u64 _t_6 = task_node(e, FID_SNAPSHOT_K169, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _result_45;
      e.mem[_t_6 + 1] = _result_52;
      e.mem[_t_6 + 2] = _result_53;
      e.mem[_t_6 + 3] = _result_54;
      e.mem[_t_6 + 4] = _result_48;
      e.mem[_t_6 + 5] = _result_49;
      e.mem[_t_6 + 6] = _result_50;
      e.mem[_t_6 + 7] = _result_51;
      e.mem[_t_6 + 8] = _result_46;
      e.mem[_t_6 + 9] = _result_47;
      e.mem[_t_6 + 10] = _h_10;
      e.mem[_t_6 + 11] = _h_12;
      e.mem[_t_6 + 12] = _h_8;
      WL_CONT = term_tsk(FID_SNAPSHOT_K169, _t_6);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_7 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _result_44;
      return term_tsk(FID_U32_SHOW, _t_7);
    }
    r0 = _result_44;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K169)
  {
    WL_POPN(13);
    u32 _result_55 = STK(0);
    u32 _result_56 = STK(1);
    Term _result_57 = STK(2);
    u32 _result_58 = STK(3);
    Term _result_59 = STK(4);
    Term _result_60 = STK(5);
    Term _result_61 = STK(6);
    Term _result_62 = STK(7);
    u32 _result_63 = STK(8);
    Term _result_64 = STK(9);
    Term _h_14 = STK(10);
    Term _h_15 = STK(11);
    Term _h_16 = STK(12);
    Term _h_13 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _result_56;
      STK(1) = _result_57;
      STK(2) = _result_58;
      STK(3) = _result_59;
      STK(4) = _result_60;
      STK(5) = _result_61;
      STK(6) = _result_62;
      STK(7) = _result_63;
      STK(8) = _result_64;
      STK(9) = _h_14;
      STK(10) = _h_15;
      STK(11) = _h_16;
      STK(12) = _h_13;
      STK(13) = FID_SNAPSHOT_K170;
      WL_PUSHN(14);
    } else {
      u64 _t_8 = task_node(e, FID_SNAPSHOT_K170, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _result_56;
      e.mem[_t_8 + 1] = _result_57;
      e.mem[_t_8 + 2] = _result_58;
      e.mem[_t_8 + 3] = _result_59;
      e.mem[_t_8 + 4] = _result_60;
      e.mem[_t_8 + 5] = _result_61;
      e.mem[_t_8 + 6] = _result_62;
      e.mem[_t_8 + 7] = _result_63;
      e.mem[_t_8 + 8] = _result_64;
      e.mem[_t_8 + 9] = _h_14;
      e.mem[_t_8 + 10] = _h_15;
      e.mem[_t_8 + 11] = _h_16;
      e.mem[_t_8 + 12] = _h_13;
      WL_CONT = term_tsk(FID_SNAPSHOT_K170, _t_8);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_9 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _result_55;
      return term_tsk(FID_U32_SHOW, _t_9);
    }
    r0 = _result_55;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K170)
  {
    WL_POPN(13);
    u32 _result_65 = STK(0);
    Term _result_66 = STK(1);
    u32 _result_67 = STK(2);
    Term _result_68 = STK(3);
    Term _result_69 = STK(4);
    Term _result_70 = STK(5);
    Term _result_71 = STK(6);
    u32 _result_72 = STK(7);
    Term _result_73 = STK(8);
    Term _h_18 = STK(9);
    Term _h_19 = STK(10);
    Term _h_20 = STK(11);
    Term _h_21 = STK(12);
    Term _h_17 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _result_66;
      STK(1) = _result_67;
      STK(2) = _result_68;
      STK(3) = _result_69;
      STK(4) = _result_70;
      STK(5) = _result_71;
      STK(6) = _result_72;
      STK(7) = _result_73;
      STK(8) = _h_18;
      STK(9) = _h_19;
      STK(10) = _h_20;
      STK(11) = _h_21;
      STK(12) = _h_17;
      STK(13) = FID_SNAPSHOT_K171;
      WL_PUSHN(14);
    } else {
      u64 _t_10 = task_node(e, FID_SNAPSHOT_K171, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _result_66;
      e.mem[_t_10 + 1] = _result_67;
      e.mem[_t_10 + 2] = _result_68;
      e.mem[_t_10 + 3] = _result_69;
      e.mem[_t_10 + 4] = _result_70;
      e.mem[_t_10 + 5] = _result_71;
      e.mem[_t_10 + 6] = _result_72;
      e.mem[_t_10 + 7] = _result_73;
      e.mem[_t_10 + 8] = _h_18;
      e.mem[_t_10 + 9] = _h_19;
      e.mem[_t_10 + 10] = _h_20;
      e.mem[_t_10 + 11] = _h_21;
      e.mem[_t_10 + 12] = _h_17;
      WL_CONT = term_tsk(FID_SNAPSHOT_K171, _t_10);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_11 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _result_65;
      return term_tsk(FID_U32_SHOW, _t_11);
    }
    r0 = _result_65;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K171)
  {
    WL_POPN(13);
    Term _result_74 = STK(0);
    u32 _result_75 = STK(1);
    Term _result_76 = STK(2);
    Term _result_77 = STK(3);
    Term _result_78 = STK(4);
    Term _result_79 = STK(5);
    u32 _result_80 = STK(6);
    Term _result_81 = STK(7);
    Term _h_23 = STK(8);
    Term _h_24 = STK(9);
    Term _h_25 = STK(10);
    Term _h_26 = STK(11);
    Term _h_27 = STK(12);
    Term _h_22 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _result_75;
      STK(1) = _result_76;
      STK(2) = _result_77;
      STK(3) = _result_78;
      STK(4) = _result_79;
      STK(5) = _result_80;
      STK(6) = _result_81;
      STK(7) = _h_23;
      STK(8) = _h_24;
      STK(9) = _h_25;
      STK(10) = _h_26;
      STK(11) = _h_27;
      STK(12) = _h_22;
      STK(13) = FID_SNAPSHOT_K172;
      WL_PUSHN(14);
    } else {
      u64 _t_12 = task_node(e, FID_SNAPSHOT_K172, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _result_75;
      e.mem[_t_12 + 1] = _result_76;
      e.mem[_t_12 + 2] = _result_77;
      e.mem[_t_12 + 3] = _result_78;
      e.mem[_t_12 + 4] = _result_79;
      e.mem[_t_12 + 5] = _result_80;
      e.mem[_t_12 + 6] = _result_81;
      e.mem[_t_12 + 7] = _h_23;
      e.mem[_t_12 + 8] = _h_24;
      e.mem[_t_12 + 9] = _h_25;
      e.mem[_t_12 + 10] = _h_26;
      e.mem[_t_12 + 11] = _h_27;
      e.mem[_t_12 + 12] = _h_22;
      WL_CONT = term_tsk(FID_SNAPSHOT_K172, _t_12);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_NAT_SHOW)) {
      u64 _t_13 = task_node(e, FID_NAT_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _result_74;
      return term_tsk(FID_NAT_SHOW, _t_13);
    }
    r0 = _result_74;
    WL_JMP(FID_NAT_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K172)
  {
    WL_POPN(13);
    u32 _result_82 = STK(0);
    Term _result_83 = STK(1);
    Term _result_84 = STK(2);
    Term _result_85 = STK(3);
    Term _result_86 = STK(4);
    u32 _result_87 = STK(5);
    Term _result_88 = STK(6);
    Term _h_29 = STK(7);
    Term _h_30 = STK(8);
    Term _h_31 = STK(9);
    Term _h_32 = STK(10);
    Term _h_33 = STK(11);
    Term _h_34 = STK(12);
    Term _h_28 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _result_83;
      STK(1) = _result_84;
      STK(2) = _result_85;
      STK(3) = _result_86;
      STK(4) = _result_87;
      STK(5) = _result_88;
      STK(6) = _h_29;
      STK(7) = _h_30;
      STK(8) = _h_31;
      STK(9) = _h_32;
      STK(10) = _h_33;
      STK(11) = _h_34;
      STK(12) = _h_28;
      STK(13) = FID_SNAPSHOT_K173;
      WL_PUSHN(14);
    } else {
      u64 _t_14 = task_node(e, FID_SNAPSHOT_K173, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _result_83;
      e.mem[_t_14 + 1] = _result_84;
      e.mem[_t_14 + 2] = _result_85;
      e.mem[_t_14 + 3] = _result_86;
      e.mem[_t_14 + 4] = _result_87;
      e.mem[_t_14 + 5] = _result_88;
      e.mem[_t_14 + 6] = _h_29;
      e.mem[_t_14 + 7] = _h_30;
      e.mem[_t_14 + 8] = _h_31;
      e.mem[_t_14 + 9] = _h_32;
      e.mem[_t_14 + 10] = _h_33;
      e.mem[_t_14 + 11] = _h_34;
      e.mem[_t_14 + 12] = _h_28;
      WL_CONT = term_tsk(FID_SNAPSHOT_K173, _t_14);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_15 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _result_82;
      return term_tsk(FID_U32_SHOW, _t_15);
    }
    r0 = _result_82;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K173)
  {
    WL_POPN(13);
    Term _result_89 = STK(0);
    Term _result_90 = STK(1);
    Term _result_91 = STK(2);
    Term _result_92 = STK(3);
    u32 _result_93 = STK(4);
    Term _result_94 = STK(5);
    Term _h_36 = STK(6);
    Term _h_37 = STK(7);
    Term _h_38 = STK(8);
    Term _h_39 = STK(9);
    Term _h_40 = STK(10);
    Term _h_41 = STK(11);
    Term _h_42 = STK(12);
    Term _h_35 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _result_90;
      STK(1) = _result_91;
      STK(2) = _result_92;
      STK(3) = _result_93;
      STK(4) = _result_94;
      STK(5) = _h_36;
      STK(6) = _h_37;
      STK(7) = _h_38;
      STK(8) = _h_39;
      STK(9) = _h_40;
      STK(10) = _h_41;
      STK(11) = _h_42;
      STK(12) = _h_35;
      STK(13) = FID_SNAPSHOT_K174;
      WL_PUSHN(14);
    } else {
      u64 _t_16 = task_node(e, FID_SNAPSHOT_K174, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _result_90;
      e.mem[_t_16 + 1] = _result_91;
      e.mem[_t_16 + 2] = _result_92;
      e.mem[_t_16 + 3] = _result_93;
      e.mem[_t_16 + 4] = _result_94;
      e.mem[_t_16 + 5] = _h_36;
      e.mem[_t_16 + 6] = _h_37;
      e.mem[_t_16 + 7] = _h_38;
      e.mem[_t_16 + 8] = _h_39;
      e.mem[_t_16 + 9] = _h_40;
      e.mem[_t_16 + 10] = _h_41;
      e.mem[_t_16 + 11] = _h_42;
      e.mem[_t_16 + 12] = _h_35;
      WL_CONT = term_tsk(FID_SNAPSHOT_K174, _t_16);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_BOOLS)) {
      u64 _t_17 = task_node(e, FID_BOOLS, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _result_89;
      return term_tsk(FID_BOOLS, _t_17);
    }
    r0 = _result_89;
    WL_JMP(FID_BOOLS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K174)
  {
    WL_POPN(13);
    Term _result_95 = STK(0);
    Term _result_96 = STK(1);
    Term _result_97 = STK(2);
    u32 _result_98 = STK(3);
    Term _result_99 = STK(4);
    Term _h_44 = STK(5);
    Term _h_45 = STK(6);
    Term _h_46 = STK(7);
    Term _h_47 = STK(8);
    Term _h_48 = STK(9);
    Term _h_49 = STK(10);
    Term _h_50 = STK(11);
    Term _h_51 = STK(12);
    Term _h_43 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _result_96;
      STK(1) = _result_97;
      STK(2) = _result_98;
      STK(3) = _result_99;
      STK(4) = _h_44;
      STK(5) = _h_45;
      STK(6) = _h_46;
      STK(7) = _h_47;
      STK(8) = _h_48;
      STK(9) = _h_49;
      STK(10) = _h_50;
      STK(11) = _h_51;
      STK(12) = _h_43;
      STK(13) = FID_SNAPSHOT_K175;
      WL_PUSHN(14);
    } else {
      u64 _t_18 = task_node(e, FID_SNAPSHOT_K175, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _result_96;
      e.mem[_t_18 + 1] = _result_97;
      e.mem[_t_18 + 2] = _result_98;
      e.mem[_t_18 + 3] = _result_99;
      e.mem[_t_18 + 4] = _h_44;
      e.mem[_t_18 + 5] = _h_45;
      e.mem[_t_18 + 6] = _h_46;
      e.mem[_t_18 + 7] = _h_47;
      e.mem[_t_18 + 8] = _h_48;
      e.mem[_t_18 + 9] = _h_49;
      e.mem[_t_18 + 10] = _h_50;
      e.mem[_t_18 + 11] = _h_51;
      e.mem[_t_18 + 12] = _h_43;
      WL_CONT = term_tsk(FID_SNAPSHOT_K175, _t_18);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_FLAGS)) {
      u64 _t_19 = task_node(e, FID_FLAGS, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _result_95;
      return term_tsk(FID_FLAGS, _t_19);
    }
    r0 = _result_95;
    WL_JMP(FID_FLAGS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K175)
  {
    WL_POPN(13);
    Term _result_100 = STK(0);
    Term _result_101 = STK(1);
    u32 _result_102 = STK(2);
    Term _result_103 = STK(3);
    Term _h_53 = STK(4);
    Term _h_54 = STK(5);
    Term _h_55 = STK(6);
    Term _h_56 = STK(7);
    Term _h_57 = STK(8);
    Term _h_58 = STK(9);
    Term _h_59 = STK(10);
    Term _h_60 = STK(11);
    Term _h_61 = STK(12);
    Term _h_52 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _result_101;
      STK(1) = _result_102;
      STK(2) = _result_103;
      STK(3) = _h_53;
      STK(4) = _h_54;
      STK(5) = _h_55;
      STK(6) = _h_56;
      STK(7) = _h_57;
      STK(8) = _h_58;
      STK(9) = _h_59;
      STK(10) = _h_60;
      STK(11) = _h_61;
      STK(12) = _h_52;
      STK(13) = FID_SNAPSHOT_K176;
      WL_PUSHN(14);
    } else {
      u64 _t_20 = task_node(e, FID_SNAPSHOT_K176, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _result_101;
      e.mem[_t_20 + 1] = _result_102;
      e.mem[_t_20 + 2] = _result_103;
      e.mem[_t_20 + 3] = _h_53;
      e.mem[_t_20 + 4] = _h_54;
      e.mem[_t_20 + 5] = _h_55;
      e.mem[_t_20 + 6] = _h_56;
      e.mem[_t_20 + 7] = _h_57;
      e.mem[_t_20 + 8] = _h_58;
      e.mem[_t_20 + 9] = _h_59;
      e.mem[_t_20 + 10] = _h_60;
      e.mem[_t_20 + 11] = _h_61;
      e.mem[_t_20 + 12] = _h_52;
      WL_CONT = term_tsk(FID_SNAPSHOT_K176, _t_20);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_WORDS)) {
      u64 _t_21 = task_node(e, FID_WORDS, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = _result_100;
      return term_tsk(FID_WORDS, _t_21);
    }
    r0 = _result_100;
    WL_JMP(FID_WORDS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K176)
  {
    WL_POPN(13);
    Term _result_104 = STK(0);
    u32 _result_105 = STK(1);
    Term _result_106 = STK(2);
    Term _h_64 = STK(3);
    Term _h_65 = STK(4);
    Term _h_66 = STK(5);
    Term _h_67 = STK(6);
    Term _h_68 = STK(7);
    Term _h_69 = STK(8);
    Term _h_70 = STK(9);
    Term _h_71 = STK(10);
    Term _h_72 = STK(11);
    Term _h_73 = STK(12);
    Term _h_62 = r0;
    Term _h_63 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _result_105;
      STK(1) = _result_106;
      STK(2) = _h_64;
      STK(3) = _h_65;
      STK(4) = _h_66;
      STK(5) = _h_67;
      STK(6) = _h_68;
      STK(7) = _h_69;
      STK(8) = _h_70;
      STK(9) = _h_71;
      STK(10) = _h_72;
      STK(11) = _h_73;
      STK(12) = _h_62;
      STK(13) = _h_63;
      STK(14) = FID_SNAPSHOT_K177;
      WL_PUSHN(15);
    } else {
      u64 _t_22 = task_node(e, FID_SNAPSHOT_K177, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _result_105;
      e.mem[_t_22 + 1] = _result_106;
      e.mem[_t_22 + 2] = _h_64;
      e.mem[_t_22 + 3] = _h_65;
      e.mem[_t_22 + 4] = _h_66;
      e.mem[_t_22 + 5] = _h_67;
      e.mem[_t_22 + 6] = _h_68;
      e.mem[_t_22 + 7] = _h_69;
      e.mem[_t_22 + 8] = _h_70;
      e.mem[_t_22 + 9] = _h_71;
      e.mem[_t_22 + 10] = _h_72;
      e.mem[_t_22 + 11] = _h_73;
      e.mem[_t_22 + 12] = _h_62;
      e.mem[_t_22 + 13] = _h_63;
      WL_CONT = term_tsk(FID_SNAPSHOT_K177, _t_22);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_WORDS)) {
      u64 _t_23 = task_node(e, FID_WORDS, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = _result_104;
      return term_tsk(FID_WORDS, _t_23);
    }
    r0 = _result_104;
    WL_JMP(FID_WORDS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K177)
  {
    WL_POPN(14);
    u32 _result_107 = STK(0);
    Term _result_108 = STK(1);
    Term _h_76 = STK(2);
    Term _h_77 = STK(3);
    Term _h_78 = STK(4);
    Term _h_79 = STK(5);
    Term _h_80 = STK(6);
    Term _h_81 = STK(7);
    Term _h_82 = STK(8);
    Term _h_83 = STK(9);
    Term _h_84 = STK(10);
    Term _h_85 = STK(11);
    Term _h_86 = STK(12);
    Term _h_87 = STK(13);
    Term _h_74 = r0;
    Term _h_75 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _result_108;
      STK(1) = _h_76;
      STK(2) = _h_77;
      STK(3) = _h_78;
      STK(4) = _h_79;
      STK(5) = _h_80;
      STK(6) = _h_81;
      STK(7) = _h_82;
      STK(8) = _h_83;
      STK(9) = _h_84;
      STK(10) = _h_85;
      STK(11) = _h_86;
      STK(12) = _h_87;
      STK(13) = _h_74;
      STK(14) = _h_75;
      STK(15) = FID_SNAPSHOT_K178;
      WL_PUSHN(16);
    } else {
      u64 _t_24 = task_node(e, FID_SNAPSHOT_K178, WL_CONT, WL_IDX, 1);
      e.mem[_t_24 + 0] = _result_108;
      e.mem[_t_24 + 1] = _h_76;
      e.mem[_t_24 + 2] = _h_77;
      e.mem[_t_24 + 3] = _h_78;
      e.mem[_t_24 + 4] = _h_79;
      e.mem[_t_24 + 5] = _h_80;
      e.mem[_t_24 + 6] = _h_81;
      e.mem[_t_24 + 7] = _h_82;
      e.mem[_t_24 + 8] = _h_83;
      e.mem[_t_24 + 9] = _h_84;
      e.mem[_t_24 + 10] = _h_85;
      e.mem[_t_24 + 11] = _h_86;
      e.mem[_t_24 + 12] = _h_87;
      e.mem[_t_24 + 13] = _h_74;
      e.mem[_t_24 + 14] = _h_75;
      WL_CONT = term_tsk(FID_SNAPSHOT_K178, _t_24);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_25 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = _result_107;
      return term_tsk(FID_U32_SHOW, _t_25);
    }
    r0 = _result_107;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K178)
  {
    WL_POPN(15);
    Term _result_109 = STK(0);
    Term _h_89 = STK(1);
    Term _h_90 = STK(2);
    Term _h_91 = STK(3);
    Term _h_92 = STK(4);
    Term _h_93 = STK(5);
    Term _h_94 = STK(6);
    Term _h_95 = STK(7);
    Term _h_96 = STK(8);
    Term _h_97 = STK(9);
    Term _h_98 = STK(10);
    Term _h_99 = STK(11);
    Term _h_100 = STK(12);
    Term _h_101 = STK(13);
    Term _h_102 = STK(14);
    Term _h_88 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _h_89;
      STK(1) = _h_90;
      STK(2) = _h_91;
      STK(3) = _h_92;
      STK(4) = _h_93;
      STK(5) = _h_94;
      STK(6) = _h_95;
      STK(7) = _h_96;
      STK(8) = _h_97;
      STK(9) = _h_98;
      STK(10) = _h_99;
      STK(11) = _h_100;
      STK(12) = _h_101;
      STK(13) = _h_102;
      STK(14) = _h_88;
      STK(15) = FID_SNAPSHOT_K179;
      WL_PUSHN(16);
    } else {
      u64 _t_26 = task_node(e, FID_SNAPSHOT_K179, WL_CONT, WL_IDX, 1);
      e.mem[_t_26 + 0] = _h_89;
      e.mem[_t_26 + 1] = _h_90;
      e.mem[_t_26 + 2] = _h_91;
      e.mem[_t_26 + 3] = _h_92;
      e.mem[_t_26 + 4] = _h_93;
      e.mem[_t_26 + 5] = _h_94;
      e.mem[_t_26 + 6] = _h_95;
      e.mem[_t_26 + 7] = _h_96;
      e.mem[_t_26 + 8] = _h_97;
      e.mem[_t_26 + 9] = _h_98;
      e.mem[_t_26 + 10] = _h_99;
      e.mem[_t_26 + 11] = _h_100;
      e.mem[_t_26 + 12] = _h_101;
      e.mem[_t_26 + 13] = _h_102;
      e.mem[_t_26 + 14] = _h_88;
      WL_CONT = term_tsk(FID_SNAPSHOT_K179, _t_26);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HANDLES)) {
      u64 _t_27 = task_node(e, FID_HANDLES, WL_CONT, WL_IDX, 0);
      e.mem[_t_27 + 0] = _result_109;
      return term_tsk(FID_HANDLES, _t_27);
    }
    r0 = _result_109;
    WL_JMP(FID_HANDLES);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K179)
  {
    WL_POPN(15);
    Term _h_104 = STK(0);
    Term _h_105 = STK(1);
    Term _h_106 = STK(2);
    Term _h_107 = STK(3);
    Term _h_108 = STK(4);
    Term _h_109 = STK(5);
    Term _h_110 = STK(6);
    Term _h_111 = STK(7);
    Term _h_112 = STK(8);
    Term _h_113 = STK(9);
    Term _h_114 = STK(10);
    Term _h_115 = STK(11);
    Term _h_116 = STK(12);
    Term _h_117 = STK(13);
    Term _h_118 = STK(14);
    Term _h_103 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _h_104;
      STK(1) = _h_105;
      STK(2) = _h_106;
      STK(3) = _h_107;
      STK(4) = _h_108;
      STK(5) = _h_109;
      STK(6) = _h_110;
      STK(7) = _h_111;
      STK(8) = _h_112;
      STK(9) = _h_113;
      STK(10) = _h_114;
      STK(11) = _h_115;
      STK(12) = _h_116;
      STK(13) = _h_117;
      STK(14) = _h_118;
      STK(15) = FID_SNAPSHOT_K180;
      WL_PUSHN(16);
    } else {
      u64 _t_28 = task_node(e, FID_SNAPSHOT_K180, WL_CONT, WL_IDX, 1);
      e.mem[_t_28 + 0] = _h_104;
      e.mem[_t_28 + 1] = _h_105;
      e.mem[_t_28 + 2] = _h_106;
      e.mem[_t_28 + 3] = _h_107;
      e.mem[_t_28 + 4] = _h_108;
      e.mem[_t_28 + 5] = _h_109;
      e.mem[_t_28 + 6] = _h_110;
      e.mem[_t_28 + 7] = _h_111;
      e.mem[_t_28 + 8] = _h_112;
      e.mem[_t_28 + 9] = _h_113;
      e.mem[_t_28 + 10] = _h_114;
      e.mem[_t_28 + 11] = _h_115;
      e.mem[_t_28 + 12] = _h_116;
      e.mem[_t_28 + 13] = _h_117;
      e.mem[_t_28 + 14] = _h_118;
      WL_CONT = term_tsk(FID_SNAPSHOT_K180, _t_28);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_29 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_29 + 0] = term_ctr(CID_SCON, STAT_OFF + 30);
      e.mem[_t_29 + 1] = _h_103;
      return term_tsk(FID_STRING_APPEND, _t_29);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 30);
    r1 = _h_103;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K180)
  {
    WL_POPN(15);
    Term _h_120 = STK(0);
    Term _h_121 = STK(1);
    Term _h_122 = STK(2);
    Term _h_123 = STK(3);
    Term _h_124 = STK(4);
    Term _h_125 = STK(5);
    Term _h_126 = STK(6);
    Term _h_127 = STK(7);
    Term _h_128 = STK(8);
    Term _h_129 = STK(9);
    Term _h_130 = STK(10);
    Term _h_131 = STK(11);
    Term _h_132 = STK(12);
    Term _h_133 = STK(13);
    Term _h_134 = STK(14);
    Term _h_119 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _h_120;
      STK(1) = _h_121;
      STK(2) = _h_122;
      STK(3) = _h_123;
      STK(4) = _h_124;
      STK(5) = _h_125;
      STK(6) = _h_126;
      STK(7) = _h_127;
      STK(8) = _h_128;
      STK(9) = _h_129;
      STK(10) = _h_130;
      STK(11) = _h_131;
      STK(12) = _h_132;
      STK(13) = _h_133;
      STK(14) = FID_SNAPSHOT_K181;
      WL_PUSHN(15);
    } else {
      u64 _t_30 = task_node(e, FID_SNAPSHOT_K181, WL_CONT, WL_IDX, 1);
      e.mem[_t_30 + 0] = _h_120;
      e.mem[_t_30 + 1] = _h_121;
      e.mem[_t_30 + 2] = _h_122;
      e.mem[_t_30 + 3] = _h_123;
      e.mem[_t_30 + 4] = _h_124;
      e.mem[_t_30 + 5] = _h_125;
      e.mem[_t_30 + 6] = _h_126;
      e.mem[_t_30 + 7] = _h_127;
      e.mem[_t_30 + 8] = _h_128;
      e.mem[_t_30 + 9] = _h_129;
      e.mem[_t_30 + 10] = _h_130;
      e.mem[_t_30 + 11] = _h_131;
      e.mem[_t_30 + 12] = _h_132;
      e.mem[_t_30 + 13] = _h_133;
      WL_CONT = term_tsk(FID_SNAPSHOT_K181, _t_30);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_31 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_31 + 0] = _h_134;
      e.mem[_t_31 + 1] = _h_119;
      return term_tsk(FID_STRING_APPEND, _t_31);
    }
    r0 = _h_134;
    r1 = _h_119;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K181)
  {
    WL_POPN(14);
    Term _h_136 = STK(0);
    Term _h_137 = STK(1);
    Term _h_138 = STK(2);
    Term _h_139 = STK(3);
    Term _h_140 = STK(4);
    Term _h_141 = STK(5);
    Term _h_142 = STK(6);
    Term _h_143 = STK(7);
    Term _h_144 = STK(8);
    Term _h_145 = STK(9);
    Term _h_146 = STK(10);
    Term _h_147 = STK(11);
    Term _h_148 = STK(12);
    Term _h_149 = STK(13);
    Term _h_135 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _h_136;
      STK(1) = _h_137;
      STK(2) = _h_138;
      STK(3) = _h_139;
      STK(4) = _h_140;
      STK(5) = _h_141;
      STK(6) = _h_142;
      STK(7) = _h_143;
      STK(8) = _h_144;
      STK(9) = _h_145;
      STK(10) = _h_146;
      STK(11) = _h_147;
      STK(12) = _h_148;
      STK(13) = _h_149;
      STK(14) = FID_SNAPSHOT_K182;
      WL_PUSHN(15);
    } else {
      u64 _t_32 = task_node(e, FID_SNAPSHOT_K182, WL_CONT, WL_IDX, 1);
      e.mem[_t_32 + 0] = _h_136;
      e.mem[_t_32 + 1] = _h_137;
      e.mem[_t_32 + 2] = _h_138;
      e.mem[_t_32 + 3] = _h_139;
      e.mem[_t_32 + 4] = _h_140;
      e.mem[_t_32 + 5] = _h_141;
      e.mem[_t_32 + 6] = _h_142;
      e.mem[_t_32 + 7] = _h_143;
      e.mem[_t_32 + 8] = _h_144;
      e.mem[_t_32 + 9] = _h_145;
      e.mem[_t_32 + 10] = _h_146;
      e.mem[_t_32 + 11] = _h_147;
      e.mem[_t_32 + 12] = _h_148;
      e.mem[_t_32 + 13] = _h_149;
      WL_CONT = term_tsk(FID_SNAPSHOT_K182, _t_32);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_33 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_33 + 0] = term_ctr(CID_SCON, STAT_OFF + 30);
      e.mem[_t_33 + 1] = _h_135;
      return term_tsk(FID_STRING_APPEND, _t_33);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 30);
    r1 = _h_135;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K182)
  {
    WL_POPN(14);
    Term _h_151 = STK(0);
    Term _h_152 = STK(1);
    Term _h_153 = STK(2);
    Term _h_154 = STK(3);
    Term _h_155 = STK(4);
    Term _h_156 = STK(5);
    Term _h_157 = STK(6);
    Term _h_158 = STK(7);
    Term _h_159 = STK(8);
    Term _h_160 = STK(9);
    Term _h_161 = STK(10);
    Term _h_162 = STK(11);
    Term _h_163 = STK(12);
    Term _h_164 = STK(13);
    Term _h_150 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _h_151;
      STK(1) = _h_152;
      STK(2) = _h_154;
      STK(3) = _h_155;
      STK(4) = _h_156;
      STK(5) = _h_157;
      STK(6) = _h_158;
      STK(7) = _h_159;
      STK(8) = _h_160;
      STK(9) = _h_161;
      STK(10) = _h_162;
      STK(11) = _h_163;
      STK(12) = _h_164;
      STK(13) = FID_SNAPSHOT_K183;
      WL_PUSHN(14);
    } else {
      u64 _t_34 = task_node(e, FID_SNAPSHOT_K183, WL_CONT, WL_IDX, 1);
      e.mem[_t_34 + 0] = _h_151;
      e.mem[_t_34 + 1] = _h_152;
      e.mem[_t_34 + 2] = _h_154;
      e.mem[_t_34 + 3] = _h_155;
      e.mem[_t_34 + 4] = _h_156;
      e.mem[_t_34 + 5] = _h_157;
      e.mem[_t_34 + 6] = _h_158;
      e.mem[_t_34 + 7] = _h_159;
      e.mem[_t_34 + 8] = _h_160;
      e.mem[_t_34 + 9] = _h_161;
      e.mem[_t_34 + 10] = _h_162;
      e.mem[_t_34 + 11] = _h_163;
      e.mem[_t_34 + 12] = _h_164;
      WL_CONT = term_tsk(FID_SNAPSHOT_K183, _t_34);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_35 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_35 + 0] = _h_153;
      e.mem[_t_35 + 1] = _h_150;
      return term_tsk(FID_STRING_APPEND, _t_35);
    }
    r0 = _h_153;
    r1 = _h_150;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K183)
  {
    WL_POPN(13);
    Term _h_166 = STK(0);
    Term _h_167 = STK(1);
    Term _h_168 = STK(2);
    Term _h_169 = STK(3);
    Term _h_170 = STK(4);
    Term _h_171 = STK(5);
    Term _h_172 = STK(6);
    Term _h_173 = STK(7);
    Term _h_174 = STK(8);
    Term _h_175 = STK(9);
    Term _h_176 = STK(10);
    Term _h_177 = STK(11);
    Term _h_178 = STK(12);
    Term _h_165 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _h_166;
      STK(1) = _h_167;
      STK(2) = _h_168;
      STK(3) = _h_169;
      STK(4) = _h_170;
      STK(5) = _h_171;
      STK(6) = _h_172;
      STK(7) = _h_173;
      STK(8) = _h_174;
      STK(9) = _h_175;
      STK(10) = _h_176;
      STK(11) = _h_177;
      STK(12) = _h_178;
      STK(13) = FID_SNAPSHOT_K184;
      WL_PUSHN(14);
    } else {
      u64 _t_36 = task_node(e, FID_SNAPSHOT_K184, WL_CONT, WL_IDX, 1);
      e.mem[_t_36 + 0] = _h_166;
      e.mem[_t_36 + 1] = _h_167;
      e.mem[_t_36 + 2] = _h_168;
      e.mem[_t_36 + 3] = _h_169;
      e.mem[_t_36 + 4] = _h_170;
      e.mem[_t_36 + 5] = _h_171;
      e.mem[_t_36 + 6] = _h_172;
      e.mem[_t_36 + 7] = _h_173;
      e.mem[_t_36 + 8] = _h_174;
      e.mem[_t_36 + 9] = _h_175;
      e.mem[_t_36 + 10] = _h_176;
      e.mem[_t_36 + 11] = _h_177;
      e.mem[_t_36 + 12] = _h_178;
      WL_CONT = term_tsk(FID_SNAPSHOT_K184, _t_36);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_37 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_37 + 0] = term_ctr(CID_SCON, STAT_OFF + 30);
      e.mem[_t_37 + 1] = _h_165;
      return term_tsk(FID_STRING_APPEND, _t_37);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 30);
    r1 = _h_165;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K184)
  {
    WL_POPN(13);
    Term _h_180 = STK(0);
    Term _h_181 = STK(1);
    Term _h_182 = STK(2);
    Term _h_183 = STK(3);
    Term _h_184 = STK(4);
    Term _h_185 = STK(5);
    Term _h_186 = STK(6);
    Term _h_187 = STK(7);
    Term _h_188 = STK(8);
    Term _h_189 = STK(9);
    Term _h_190 = STK(10);
    Term _h_191 = STK(11);
    Term _h_192 = STK(12);
    Term _h_179 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_18(e, _o_0, _h_191, blk_loc(e.mem, _h_191), _h_192, blk_loc(e.mem, _h_192)) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (seq) {
      WL_ROOM(12);
      STK(0) = _h_180;
      STK(1) = _h_181;
      STK(2) = _h_182;
      STK(3) = _h_183;
      STK(4) = _h_184;
      STK(5) = _h_185;
      STK(6) = _h_186;
      STK(7) = _h_187;
      STK(8) = _h_188;
      STK(9) = _h_189;
      STK(10) = _h_190;
      STK(11) = FID_SNAPSHOT_K185;
      WL_PUSHN(12);
    } else {
      u64 _t_38 = task_node(e, FID_SNAPSHOT_K185, WL_CONT, WL_IDX, 1);
      e.mem[_t_38 + 0] = _h_180;
      e.mem[_t_38 + 1] = _h_181;
      e.mem[_t_38 + 2] = _h_182;
      e.mem[_t_38 + 3] = _h_183;
      e.mem[_t_38 + 4] = _h_184;
      e.mem[_t_38 + 5] = _h_185;
      e.mem[_t_38 + 6] = _h_186;
      e.mem[_t_38 + 7] = _h_187;
      e.mem[_t_38 + 8] = _h_188;
      e.mem[_t_38 + 9] = _h_189;
      e.mem[_t_38 + 10] = _h_190;
      WL_CONT = term_tsk(FID_SNAPSHOT_K185, _t_38);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_39 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_39 + 0] = _v_0;
      e.mem[_t_39 + 1] = _h_179;
      return term_tsk(FID_STRING_APPEND, _t_39);
    }
    r0 = _v_0;
    r1 = _h_179;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K185)
  {
    WL_POPN(11);
    Term _h_194 = STK(0);
    Term _h_195 = STK(1);
    Term _h_196 = STK(2);
    Term _h_197 = STK(3);
    Term _h_198 = STK(4);
    Term _h_199 = STK(5);
    Term _h_200 = STK(6);
    Term _h_201 = STK(7);
    Term _h_202 = STK(8);
    Term _h_203 = STK(9);
    Term _h_204 = STK(10);
    Term _h_193 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _h_194;
      STK(1) = _h_195;
      STK(2) = _h_196;
      STK(3) = _h_197;
      STK(4) = _h_198;
      STK(5) = _h_199;
      STK(6) = _h_200;
      STK(7) = _h_201;
      STK(8) = _h_202;
      STK(9) = _h_203;
      STK(10) = _h_204;
      STK(11) = FID_SNAPSHOT_K186;
      WL_PUSHN(12);
    } else {
      u64 _t_40 = task_node(e, FID_SNAPSHOT_K186, WL_CONT, WL_IDX, 1);
      e.mem[_t_40 + 0] = _h_194;
      e.mem[_t_40 + 1] = _h_195;
      e.mem[_t_40 + 2] = _h_196;
      e.mem[_t_40 + 3] = _h_197;
      e.mem[_t_40 + 4] = _h_198;
      e.mem[_t_40 + 5] = _h_199;
      e.mem[_t_40 + 6] = _h_200;
      e.mem[_t_40 + 7] = _h_201;
      e.mem[_t_40 + 8] = _h_202;
      e.mem[_t_40 + 9] = _h_203;
      e.mem[_t_40 + 10] = _h_204;
      WL_CONT = term_tsk(FID_SNAPSHOT_K186, _t_40);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_41 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_41 + 0] = term_ctr(CID_SCON, STAT_OFF + 30);
      e.mem[_t_41 + 1] = _h_193;
      return term_tsk(FID_STRING_APPEND, _t_41);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 30);
    r1 = _h_193;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K186)
  {
    WL_POPN(11);
    Term _h_206 = STK(0);
    Term _h_207 = STK(1);
    Term _h_208 = STK(2);
    Term _h_209 = STK(3);
    Term _h_210 = STK(4);
    Term _h_211 = STK(5);
    Term _h_212 = STK(6);
    Term _h_213 = STK(7);
    Term _h_214 = STK(8);
    Term _h_215 = STK(9);
    Term _h_216 = STK(10);
    Term _h_205 = r0;
    WL_OPEN
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _o_1[1];
    if (spin_18(e, _o_1, _h_215, blk_loc(e.mem, _h_215), _h_216, blk_loc(e.mem, _h_216)) == 0) {
      return 0;
    }
    _v_3 = _o_1[0];
    _v_2 = _v_3;
    if (seq) {
      WL_ROOM(10);
      STK(0) = _h_206;
      STK(1) = _h_207;
      STK(2) = _h_208;
      STK(3) = _h_209;
      STK(4) = _h_210;
      STK(5) = _h_211;
      STK(6) = _h_212;
      STK(7) = _h_213;
      STK(8) = _h_214;
      STK(9) = FID_SNAPSHOT_K187;
      WL_PUSHN(10);
    } else {
      u64 _t_42 = task_node(e, FID_SNAPSHOT_K187, WL_CONT, WL_IDX, 1);
      e.mem[_t_42 + 0] = _h_206;
      e.mem[_t_42 + 1] = _h_207;
      e.mem[_t_42 + 2] = _h_208;
      e.mem[_t_42 + 3] = _h_209;
      e.mem[_t_42 + 4] = _h_210;
      e.mem[_t_42 + 5] = _h_211;
      e.mem[_t_42 + 6] = _h_212;
      e.mem[_t_42 + 7] = _h_213;
      e.mem[_t_42 + 8] = _h_214;
      WL_CONT = term_tsk(FID_SNAPSHOT_K187, _t_42);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_43 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_43 + 0] = _v_2;
      e.mem[_t_43 + 1] = _h_205;
      return term_tsk(FID_STRING_APPEND, _t_43);
    }
    r0 = _v_2;
    r1 = _h_205;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K187)
  {
    WL_POPN(9);
    Term _h_218 = STK(0);
    Term _h_219 = STK(1);
    Term _h_220 = STK(2);
    Term _h_221 = STK(3);
    Term _h_222 = STK(4);
    Term _h_223 = STK(5);
    Term _h_224 = STK(6);
    Term _h_225 = STK(7);
    Term _h_226 = STK(8);
    Term _h_217 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _h_218;
      STK(1) = _h_219;
      STK(2) = _h_220;
      STK(3) = _h_221;
      STK(4) = _h_222;
      STK(5) = _h_223;
      STK(6) = _h_224;
      STK(7) = _h_225;
      STK(8) = _h_226;
      STK(9) = FID_SNAPSHOT_K188;
      WL_PUSHN(10);
    } else {
      u64 _t_44 = task_node(e, FID_SNAPSHOT_K188, WL_CONT, WL_IDX, 1);
      e.mem[_t_44 + 0] = _h_218;
      e.mem[_t_44 + 1] = _h_219;
      e.mem[_t_44 + 2] = _h_220;
      e.mem[_t_44 + 3] = _h_221;
      e.mem[_t_44 + 4] = _h_222;
      e.mem[_t_44 + 5] = _h_223;
      e.mem[_t_44 + 6] = _h_224;
      e.mem[_t_44 + 7] = _h_225;
      e.mem[_t_44 + 8] = _h_226;
      WL_CONT = term_tsk(FID_SNAPSHOT_K188, _t_44);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_45 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_45 + 0] = term_ctr(CID_SCON, STAT_OFF + 30);
      e.mem[_t_45 + 1] = _h_217;
      return term_tsk(FID_STRING_APPEND, _t_45);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 30);
    r1 = _h_217;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K188)
  {
    WL_POPN(9);
    Term _h_228 = STK(0);
    Term _h_229 = STK(1);
    Term _h_230 = STK(2);
    Term _h_231 = STK(3);
    Term _h_232 = STK(4);
    Term _h_233 = STK(5);
    Term _h_234 = STK(6);
    Term _h_235 = STK(7);
    Term _h_236 = STK(8);
    Term _h_227 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(9);
      STK(0) = _h_228;
      STK(1) = _h_229;
      STK(2) = _h_230;
      STK(3) = _h_231;
      STK(4) = _h_232;
      STK(5) = _h_233;
      STK(6) = _h_234;
      STK(7) = _h_235;
      STK(8) = FID_SNAPSHOT_K189;
      WL_PUSHN(9);
    } else {
      u64 _t_46 = task_node(e, FID_SNAPSHOT_K189, WL_CONT, WL_IDX, 1);
      e.mem[_t_46 + 0] = _h_228;
      e.mem[_t_46 + 1] = _h_229;
      e.mem[_t_46 + 2] = _h_230;
      e.mem[_t_46 + 3] = _h_231;
      e.mem[_t_46 + 4] = _h_232;
      e.mem[_t_46 + 5] = _h_233;
      e.mem[_t_46 + 6] = _h_234;
      e.mem[_t_46 + 7] = _h_235;
      WL_CONT = term_tsk(FID_SNAPSHOT_K189, _t_46);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_47 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_47 + 0] = _h_236;
      e.mem[_t_47 + 1] = _h_227;
      return term_tsk(FID_STRING_APPEND, _t_47);
    }
    r0 = _h_236;
    r1 = _h_227;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K189)
  {
    WL_POPN(8);
    Term _h_238 = STK(0);
    Term _h_239 = STK(1);
    Term _h_240 = STK(2);
    Term _h_241 = STK(3);
    Term _h_242 = STK(4);
    Term _h_243 = STK(5);
    Term _h_244 = STK(6);
    Term _h_245 = STK(7);
    Term _h_237 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(9);
      STK(0) = _h_238;
      STK(1) = _h_239;
      STK(2) = _h_240;
      STK(3) = _h_241;
      STK(4) = _h_242;
      STK(5) = _h_243;
      STK(6) = _h_244;
      STK(7) = _h_245;
      STK(8) = FID_SNAPSHOT_K190;
      WL_PUSHN(9);
    } else {
      u64 _t_48 = task_node(e, FID_SNAPSHOT_K190, WL_CONT, WL_IDX, 1);
      e.mem[_t_48 + 0] = _h_238;
      e.mem[_t_48 + 1] = _h_239;
      e.mem[_t_48 + 2] = _h_240;
      e.mem[_t_48 + 3] = _h_241;
      e.mem[_t_48 + 4] = _h_242;
      e.mem[_t_48 + 5] = _h_243;
      e.mem[_t_48 + 6] = _h_244;
      e.mem[_t_48 + 7] = _h_245;
      WL_CONT = term_tsk(FID_SNAPSHOT_K190, _t_48);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_49 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_49 + 0] = term_ctr(CID_SCON, STAT_OFF + 30);
      e.mem[_t_49 + 1] = _h_237;
      return term_tsk(FID_STRING_APPEND, _t_49);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 30);
    r1 = _h_237;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K190)
  {
    WL_POPN(8);
    Term _h_247 = STK(0);
    Term _h_248 = STK(1);
    Term _h_249 = STK(2);
    Term _h_250 = STK(3);
    Term _h_251 = STK(4);
    Term _h_252 = STK(5);
    Term _h_253 = STK(6);
    Term _h_254 = STK(7);
    Term _h_246 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _h_247;
      STK(1) = _h_248;
      STK(2) = _h_249;
      STK(3) = _h_250;
      STK(4) = _h_251;
      STK(5) = _h_252;
      STK(6) = _h_253;
      STK(7) = FID_SNAPSHOT_K191;
      WL_PUSHN(8);
    } else {
      u64 _t_50 = task_node(e, FID_SNAPSHOT_K191, WL_CONT, WL_IDX, 1);
      e.mem[_t_50 + 0] = _h_247;
      e.mem[_t_50 + 1] = _h_248;
      e.mem[_t_50 + 2] = _h_249;
      e.mem[_t_50 + 3] = _h_250;
      e.mem[_t_50 + 4] = _h_251;
      e.mem[_t_50 + 5] = _h_252;
      e.mem[_t_50 + 6] = _h_253;
      WL_CONT = term_tsk(FID_SNAPSHOT_K191, _t_50);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_51 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_51 + 0] = _h_254;
      e.mem[_t_51 + 1] = _h_246;
      return term_tsk(FID_STRING_APPEND, _t_51);
    }
    r0 = _h_254;
    r1 = _h_246;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K191)
  {
    WL_POPN(7);
    Term _h_256 = STK(0);
    Term _h_257 = STK(1);
    Term _h_258 = STK(2);
    Term _h_259 = STK(3);
    Term _h_260 = STK(4);
    Term _h_261 = STK(5);
    Term _h_262 = STK(6);
    Term _h_255 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _h_256;
      STK(1) = _h_257;
      STK(2) = _h_258;
      STK(3) = _h_259;
      STK(4) = _h_260;
      STK(5) = _h_261;
      STK(6) = _h_262;
      STK(7) = FID_SNAPSHOT_K192;
      WL_PUSHN(8);
    } else {
      u64 _t_52 = task_node(e, FID_SNAPSHOT_K192, WL_CONT, WL_IDX, 1);
      e.mem[_t_52 + 0] = _h_256;
      e.mem[_t_52 + 1] = _h_257;
      e.mem[_t_52 + 2] = _h_258;
      e.mem[_t_52 + 3] = _h_259;
      e.mem[_t_52 + 4] = _h_260;
      e.mem[_t_52 + 5] = _h_261;
      e.mem[_t_52 + 6] = _h_262;
      WL_CONT = term_tsk(FID_SNAPSHOT_K192, _t_52);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_53 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_53 + 0] = term_ctr(CID_SCON, STAT_OFF + 30);
      e.mem[_t_53 + 1] = _h_255;
      return term_tsk(FID_STRING_APPEND, _t_53);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 30);
    r1 = _h_255;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K192)
  {
    WL_POPN(7);
    Term _h_264 = STK(0);
    Term _h_265 = STK(1);
    Term _h_266 = STK(2);
    Term _h_267 = STK(3);
    Term _h_268 = STK(4);
    Term _h_269 = STK(5);
    Term _h_270 = STK(6);
    Term _h_263 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _h_264;
      STK(1) = _h_266;
      STK(2) = _h_267;
      STK(3) = _h_268;
      STK(4) = _h_269;
      STK(5) = _h_270;
      STK(6) = FID_SNAPSHOT_K193;
      WL_PUSHN(7);
    } else {
      u64 _t_54 = task_node(e, FID_SNAPSHOT_K193, WL_CONT, WL_IDX, 1);
      e.mem[_t_54 + 0] = _h_264;
      e.mem[_t_54 + 1] = _h_266;
      e.mem[_t_54 + 2] = _h_267;
      e.mem[_t_54 + 3] = _h_268;
      e.mem[_t_54 + 4] = _h_269;
      e.mem[_t_54 + 5] = _h_270;
      WL_CONT = term_tsk(FID_SNAPSHOT_K193, _t_54);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_55 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_55 + 0] = _h_265;
      e.mem[_t_55 + 1] = _h_263;
      return term_tsk(FID_STRING_APPEND, _t_55);
    }
    r0 = _h_265;
    r1 = _h_263;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K193)
  {
    WL_POPN(6);
    Term _h_272 = STK(0);
    Term _h_273 = STK(1);
    Term _h_274 = STK(2);
    Term _h_275 = STK(3);
    Term _h_276 = STK(4);
    Term _h_277 = STK(5);
    Term _h_271 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _h_272;
      STK(1) = _h_273;
      STK(2) = _h_274;
      STK(3) = _h_275;
      STK(4) = _h_276;
      STK(5) = _h_277;
      STK(6) = FID_SNAPSHOT_K194;
      WL_PUSHN(7);
    } else {
      u64 _t_56 = task_node(e, FID_SNAPSHOT_K194, WL_CONT, WL_IDX, 1);
      e.mem[_t_56 + 0] = _h_272;
      e.mem[_t_56 + 1] = _h_273;
      e.mem[_t_56 + 2] = _h_274;
      e.mem[_t_56 + 3] = _h_275;
      e.mem[_t_56 + 4] = _h_276;
      e.mem[_t_56 + 5] = _h_277;
      WL_CONT = term_tsk(FID_SNAPSHOT_K194, _t_56);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_57 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_57 + 0] = term_ctr(CID_SCON, STAT_OFF + 30);
      e.mem[_t_57 + 1] = _h_271;
      return term_tsk(FID_STRING_APPEND, _t_57);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 30);
    r1 = _h_271;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K194)
  {
    WL_POPN(6);
    Term _h_279 = STK(0);
    Term _h_280 = STK(1);
    Term _h_281 = STK(2);
    Term _h_282 = STK(3);
    Term _h_283 = STK(4);
    Term _h_284 = STK(5);
    Term _h_278 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _h_280;
      STK(1) = _h_281;
      STK(2) = _h_282;
      STK(3) = _h_283;
      STK(4) = _h_284;
      STK(5) = FID_SNAPSHOT_K195;
      WL_PUSHN(6);
    } else {
      u64 _t_58 = task_node(e, FID_SNAPSHOT_K195, WL_CONT, WL_IDX, 1);
      e.mem[_t_58 + 0] = _h_280;
      e.mem[_t_58 + 1] = _h_281;
      e.mem[_t_58 + 2] = _h_282;
      e.mem[_t_58 + 3] = _h_283;
      e.mem[_t_58 + 4] = _h_284;
      WL_CONT = term_tsk(FID_SNAPSHOT_K195, _t_58);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_59 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_59 + 0] = _h_279;
      e.mem[_t_59 + 1] = _h_278;
      return term_tsk(FID_STRING_APPEND, _t_59);
    }
    r0 = _h_279;
    r1 = _h_278;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K195)
  {
    WL_POPN(5);
    Term _h_286 = STK(0);
    Term _h_287 = STK(1);
    Term _h_288 = STK(2);
    Term _h_289 = STK(3);
    Term _h_290 = STK(4);
    Term _h_285 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _h_286;
      STK(1) = _h_287;
      STK(2) = _h_288;
      STK(3) = _h_289;
      STK(4) = _h_290;
      STK(5) = FID_SNAPSHOT_K196;
      WL_PUSHN(6);
    } else {
      u64 _t_60 = task_node(e, FID_SNAPSHOT_K196, WL_CONT, WL_IDX, 1);
      e.mem[_t_60 + 0] = _h_286;
      e.mem[_t_60 + 1] = _h_287;
      e.mem[_t_60 + 2] = _h_288;
      e.mem[_t_60 + 3] = _h_289;
      e.mem[_t_60 + 4] = _h_290;
      WL_CONT = term_tsk(FID_SNAPSHOT_K196, _t_60);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_61 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_61 + 0] = term_ctr(CID_SCON, STAT_OFF + 30);
      e.mem[_t_61 + 1] = _h_285;
      return term_tsk(FID_STRING_APPEND, _t_61);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 30);
    r1 = _h_285;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K196)
  {
    WL_POPN(5);
    Term _h_292 = STK(0);
    Term _h_293 = STK(1);
    Term _h_294 = STK(2);
    Term _h_295 = STK(3);
    Term _h_296 = STK(4);
    Term _h_291 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_292;
      STK(1) = _h_293;
      STK(2) = _h_294;
      STK(3) = _h_295;
      STK(4) = FID_SNAPSHOT_K197;
      WL_PUSHN(5);
    } else {
      u64 _t_62 = task_node(e, FID_SNAPSHOT_K197, WL_CONT, WL_IDX, 1);
      e.mem[_t_62 + 0] = _h_292;
      e.mem[_t_62 + 1] = _h_293;
      e.mem[_t_62 + 2] = _h_294;
      e.mem[_t_62 + 3] = _h_295;
      WL_CONT = term_tsk(FID_SNAPSHOT_K197, _t_62);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_63 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_63 + 0] = _h_296;
      e.mem[_t_63 + 1] = _h_291;
      return term_tsk(FID_STRING_APPEND, _t_63);
    }
    r0 = _h_296;
    r1 = _h_291;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K197)
  {
    WL_POPN(4);
    Term _h_298 = STK(0);
    Term _h_299 = STK(1);
    Term _h_300 = STK(2);
    Term _h_301 = STK(3);
    Term _h_297 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_298;
      STK(1) = _h_299;
      STK(2) = _h_300;
      STK(3) = _h_301;
      STK(4) = FID_SNAPSHOT_K198;
      WL_PUSHN(5);
    } else {
      u64 _t_64 = task_node(e, FID_SNAPSHOT_K198, WL_CONT, WL_IDX, 1);
      e.mem[_t_64 + 0] = _h_298;
      e.mem[_t_64 + 1] = _h_299;
      e.mem[_t_64 + 2] = _h_300;
      e.mem[_t_64 + 3] = _h_301;
      WL_CONT = term_tsk(FID_SNAPSHOT_K198, _t_64);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_65 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_65 + 0] = term_ctr(CID_SCON, STAT_OFF + 18);
      e.mem[_t_65 + 1] = _h_297;
      return term_tsk(FID_STRING_APPEND, _t_65);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 18);
    r1 = _h_297;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K198)
  {
    WL_POPN(4);
    Term _h_303 = STK(0);
    Term _h_304 = STK(1);
    Term _h_305 = STK(2);
    Term _h_306 = STK(3);
    Term _h_302 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_303;
      STK(1) = _h_304;
      STK(2) = _h_305;
      STK(3) = FID_SNAPSHOT_K199;
      WL_PUSHN(4);
    } else {
      u64 _t_66 = task_node(e, FID_SNAPSHOT_K199, WL_CONT, WL_IDX, 1);
      e.mem[_t_66 + 0] = _h_303;
      e.mem[_t_66 + 1] = _h_304;
      e.mem[_t_66 + 2] = _h_305;
      WL_CONT = term_tsk(FID_SNAPSHOT_K199, _t_66);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_67 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_67 + 0] = _h_306;
      e.mem[_t_67 + 1] = _h_302;
      return term_tsk(FID_STRING_APPEND, _t_67);
    }
    r0 = _h_306;
    r1 = _h_302;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K199)
  {
    WL_POPN(3);
    Term _h_308 = STK(0);
    Term _h_309 = STK(1);
    Term _h_310 = STK(2);
    Term _h_307 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_308;
      STK(1) = _h_309;
      STK(2) = _h_310;
      STK(3) = FID_SNAPSHOT_K200;
      WL_PUSHN(4);
    } else {
      u64 _t_68 = task_node(e, FID_SNAPSHOT_K200, WL_CONT, WL_IDX, 1);
      e.mem[_t_68 + 0] = _h_308;
      e.mem[_t_68 + 1] = _h_309;
      e.mem[_t_68 + 2] = _h_310;
      WL_CONT = term_tsk(FID_SNAPSHOT_K200, _t_68);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_69 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_69 + 0] = term_ctr(CID_SCON, STAT_OFF + 18);
      e.mem[_t_69 + 1] = _h_307;
      return term_tsk(FID_STRING_APPEND, _t_69);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 18);
    r1 = _h_307;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K200)
  {
    WL_POPN(3);
    Term _h_312 = STK(0);
    Term _h_313 = STK(1);
    Term _h_314 = STK(2);
    Term _h_311 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_312;
      STK(1) = _h_313;
      STK(2) = FID_SNAPSHOT_K201;
      WL_PUSHN(3);
    } else {
      u64 _t_70 = task_node(e, FID_SNAPSHOT_K201, WL_CONT, WL_IDX, 1);
      e.mem[_t_70 + 0] = _h_312;
      e.mem[_t_70 + 1] = _h_313;
      WL_CONT = term_tsk(FID_SNAPSHOT_K201, _t_70);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_71 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_71 + 0] = _h_314;
      e.mem[_t_71 + 1] = _h_311;
      return term_tsk(FID_STRING_APPEND, _t_71);
    }
    r0 = _h_314;
    r1 = _h_311;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K201)
  {
    WL_POPN(2);
    Term _h_316 = STK(0);
    Term _h_317 = STK(1);
    Term _h_315 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_316;
      STK(1) = _h_317;
      STK(2) = FID_SNAPSHOT_K202;
      WL_PUSHN(3);
    } else {
      u64 _t_72 = task_node(e, FID_SNAPSHOT_K202, WL_CONT, WL_IDX, 1);
      e.mem[_t_72 + 0] = _h_316;
      e.mem[_t_72 + 1] = _h_317;
      WL_CONT = term_tsk(FID_SNAPSHOT_K202, _t_72);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_73 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_73 + 0] = term_ctr(CID_SCON, STAT_OFF + 30);
      e.mem[_t_73 + 1] = _h_315;
      return term_tsk(FID_STRING_APPEND, _t_73);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 30);
    r1 = _h_315;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K202)
  {
    WL_POPN(2);
    Term _h_319 = STK(0);
    Term _h_320 = STK(1);
    Term _h_318 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_319;
      STK(1) = FID_SNAPSHOT_K203;
      WL_PUSHN(2);
    } else {
      u64 _t_74 = task_node(e, FID_SNAPSHOT_K203, WL_CONT, WL_IDX, 1);
      e.mem[_t_74 + 0] = _h_319;
      WL_CONT = term_tsk(FID_SNAPSHOT_K203, _t_74);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_75 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_75 + 0] = _h_320;
      e.mem[_t_75 + 1] = _h_318;
      return term_tsk(FID_STRING_APPEND, _t_75);
    }
    r0 = _h_320;
    r1 = _h_318;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K203)
  {
    WL_POPN(1);
    Term _h_322 = STK(0);
    Term _h_321 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_322;
      STK(1) = FID_SNAPSHOT_K204;
      WL_PUSHN(2);
    } else {
      u64 _t_76 = task_node(e, FID_SNAPSHOT_K204, WL_CONT, WL_IDX, 1);
      e.mem[_t_76 + 0] = _h_322;
      WL_CONT = term_tsk(FID_SNAPSHOT_K204, _t_76);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_77 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_77 + 0] = term_ctr(CID_SCON, STAT_OFF + 18);
      e.mem[_t_77 + 1] = _h_321;
      return term_tsk(FID_STRING_APPEND, _t_77);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 18);
    r1 = _h_321;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SNAPSHOT_K204)
  {
    WL_POPN(1);
    Term _h_324 = STK(0);
    Term _h_323 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_78 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_78 + 0] = _h_324;
      e.mem[_t_78 + 1] = _h_323;
      return term_tsk(FID_STRING_APPEND, _t_78);
    }
    r0 = _h_324;
    r1 = _h_323;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_a_0) == CID_SNIL) {
      r0 = _b_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _a_0, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_STRING_APPEND_K206;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_STRING_APPEND_K206, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_STRING_APPEND_K206, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _b_0;
      _a_0 = r0;
      _b_0 = r1;
      WL_AGAIN(FID_STRING_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND_K206)
  {
    WL_POPN(1);
    u32 _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _f_2;
    e.mem[_nd_0 + 1] = _h_0;
    r0 = term_ctr(CID_SCON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND)
  {
    Term _m_0 = r0;
    Term _f_0 = r1;
    Term _k_0 = r2;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _f_0;
    e.mem[_nd_0 + 1] = _k_0;
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _m_0;
      e.mem[_t_3 + 1] = term_clo(FID_IO_BIND_C208, _nd_0);
      return term_tsk(FID_CLO_APPLY, _t_3);
    }
    r0 = _m_0;
    r1 = term_clo(FID_IO_BIND_C208, _nd_0);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND_C208)
  {
    Term _f_1 = r0;
    Term _k_1 = r1;
    Term _x_0 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _k_1;
      STK(1) = FID_IO_BIND_K209;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_IO_BIND_K209, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _k_1;
      WL_CONT = term_tsk(FID_IO_BIND_K209, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _f_1;
      e.mem[_t_1 + 1] = _x_0;
      return term_tsk(FID_CLO_APPLY, _t_1);
    }
    r0 = _f_1;
    r1 = _x_0;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND_K209)
  {
    WL_POPN(1);
    Term _k_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_2 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _k_2;
      return term_tsk(FID_CLO_APPLY, _t_2);
    }
    r0 = _h_0;
    r1 = _k_2;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN)
  {
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    Term _v_11 = 0;
    u32 _v_12 = 0;
    Term _v_13 = 0;
    Term _v_14 = 0;
    Term _v_15 = 0;
    Term _fv_0[1];
    _fv_0[0] = 999000ull;
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, blk_new(e, 0, 0, 0, 1, _fv_0));
    e.mem[_nd_0 + 1] = rfc_seal(e, 999ull);
    Term _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    u32 _v_22 = 0;
    Term _v_23 = 0;
    u32 _v_24 = 0;
    Term _v_25 = 0;
    Term _fv_1[1];
    _fv_1[0] = 1000ull;
    u32 _o_0 = 0;
    Term _o_1 = 0;
    Term _t_0 = 1;
    if (_t_0 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, blk_new(e, 0, 0, 0, 1, _fv_1));
      e.mem[_nd_1 + 1] = rfc_seal(e, 1ull);
      _o_1 = term_ctr(CID_OWNED, _nd_1);
    }
    Term _fv_2[2];
    _fv_2[0] = _o_0;
    _fv_2[1] = _o_1;
    Term _fv_3[1];
    _fv_3[0] = 101000ull;
    u32 _o_2 = 0;
    Term _o_3 = 0;
    Term _t_1 = 1;
    if (_t_1 == 0) {
      _o_2 = 0;
    } else {
      _o_2 = 1;
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, blk_new(e, 0, 0, 0, 1, _fv_3));
      e.mem[_nd_2 + 1] = rfc_seal(e, 101ull);
      _o_3 = term_ctr(CID_OWNED, _nd_2);
    }
    Term _fv_4[2];
    _fv_4[0] = _o_2;
    _fv_4[1] = _o_3;
    Term _fv_5[1];
    _fv_5[0] = 1;
    u32 _o_4 = 0;
    Term _o_5 = 0;
    Term _t_2 = 1;
    if (_t_2 == 0) {
      _o_4 = 0;
    } else {
      _o_4 = 1;
      _o_5 = term_pak(CID_UNIT, 0);
    }
    Term _fv_6[2];
    _fv_6[0] = _o_4;
    _fv_6[1] = _o_5;
    Term _fv_7[1];
    _fv_7[0] = 100ull;
    Term _fv_8[1];
    _fv_8[0] = 200ull;
    Term _v_26 = 0;
    Term _v_27 = 0;
    Term _v_28 = 0;
    Term _v_29 = 0;
    Term _v_30 = 0;
    Term _v_31 = 0;
    u32 _v_32 = 0;
    Term _v_33 = 0;
    u32 _v_34 = 0;
    Term _v_35 = 0;
    Term _o_6[10];
    Term _a_0 = blk_new(e, 1, 0, 1, 2, _fv_2);
    Term _a_1 = blk_new(e, 1, 0, 1, 2, _fv_4);
    Term _a_2 = blk_new(e, 0, 0, 0, 1, _fv_5);
    Term _a_3 = blk_new(e, 1, 0, 1, 2, _fv_6);
    Term _a_4 = blk_new(e, 0, 0, 0, 1, _fv_7);
    Term _a_5 = blk_new(e, 0, 0, 0, 1, _fv_8);
    Term _a_6 = term_pak(CID_NIL, 0);
    if (spin_19(e, _o_6, ((u64)1ull), 1ull, 1ull, 0, 1ull, 0, 7ull, _a_0, blk_loc(e.mem, _a_0), _a_1, blk_loc(e.mem, _a_1), _a_2, blk_loc(e.mem, _a_2), _a_3, blk_loc(e.mem, _a_3), _a_4, blk_loc(e.mem, _a_4), _a_5, blk_loc(e.mem, _a_5), _a_6, blk_loc(e.mem, _a_6)) == 0) {
      return 0;
    }
    _v_26 = _o_6[0];
    _v_27 = _o_6[1];
    _v_28 = _o_6[2];
    _v_29 = _o_6[3];
    _v_30 = _o_6[4];
    _v_31 = _o_6[5];
    _v_32 = _o_6[6];
    _v_33 = _o_6[7];
    _v_34 = _o_6[8];
    _v_35 = _o_6[9];
    _v_16 = _v_26;
    _v_17 = _v_27;
    _v_18 = _v_28;
    _v_19 = _v_29;
    _v_20 = _v_30;
    _v_21 = _v_31;
    _v_22 = _v_32;
    _v_23 = _v_33;
    _v_24 = _v_34;
    _v_25 = _v_35;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    Term _v_38 = 0;
    Term _v_39 = 0;
    Term _v_40 = 0;
    Term _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    u32 _v_44 = 0;
    Term _v_45 = 0;
    u32 _v_46 = 0;
    Term _v_47 = 0;
    u32 _v_48 = 0;
    Term _v_49 = 0;
    Term _v_50 = 0;
    Term _v_51 = 0;
    Term _o_7[16];
    Term _a_7 = term_pak(CID_NIL, 0);
    Term _a_8 = term_ctr(CID_OWNED, _nd_0);
    Term _a_9 = 123ull;
    if (spin_21(e, _o_7, 7ull, 999ull, _a_7, blk_loc(e.mem, _a_7), 1, _a_8, blk_loc(e.mem, _a_8), _a_9, blk_loc(e.mem, _a_9), _v_16, blk_loc(e.mem, _v_16), _v_17, blk_loc(e.mem, _v_17), _v_18, blk_loc(e.mem, _v_18), _v_19, blk_loc(e.mem, _v_19), _v_20, blk_loc(e.mem, _v_20), _v_21, blk_loc(e.mem, _v_21), _v_22, _v_23, _v_24, _v_25, blk_loc(e.mem, _v_25)) == 0) {
      return 0;
    }
    _v_36 = _o_7[0];
    _v_37 = _o_7[1];
    _v_38 = _o_7[2];
    _v_39 = _o_7[3];
    _v_40 = _o_7[4];
    _v_41 = _o_7[5];
    _v_42 = _o_7[6];
    _v_43 = _o_7[7];
    _v_44 = _o_7[8];
    _v_45 = _o_7[9];
    _v_46 = _o_7[10];
    _v_47 = _o_7[11];
    _v_48 = _o_7[12];
    _v_49 = _o_7[13];
    _v_50 = _o_7[14];
    _v_51 = _o_7[15];
    _v_0 = _v_36;
    _v_1 = _v_37;
    _v_2 = _v_38;
    _v_3 = _v_39;
    _v_4 = _v_40;
    _v_5 = _v_41;
    _v_6 = _v_42;
    _v_7 = _v_43;
    _v_8 = _v_44;
    _v_9 = _v_45;
    _v_10 = _v_46;
    _v_11 = _v_47;
    _v_12 = _v_48;
    _v_13 = _v_49;
    _v_14 = _v_50;
    _v_15 = _v_51;
    u32 _o_8 = 0;
    Term _o_9 = 0;
    u32 _o_10 = 0;
    if (_v_12 == 0) {
      _o_8 = 0;
    } else {
      _o_8 = 1;
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _v_13, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      u32 _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      _o_9 = _f_0;
      _o_10 = _f_1;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K211;
      WL_PUSHN(1);
    } else {
      u64 _t_3 = task_node(e, FID_MAIN_K211, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K211, _t_3);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_4 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_4 + 0] = _v_0;
      e.mem[_t_4 + 1] = _v_1;
      e.mem[_t_4 + 2] = _v_2;
      e.mem[_t_4 + 3] = _v_3;
      e.mem[_t_4 + 4] = _v_4;
      e.mem[_t_4 + 5] = _v_5;
      e.mem[_t_4 + 6] = _v_6;
      e.mem[_t_4 + 7] = _v_7;
      e.mem[_t_4 + 8] = _v_8;
      e.mem[_t_4 + 9] = _v_9;
      e.mem[_t_4 + 10] = _v_10;
      e.mem[_t_4 + 11] = _v_11;
      e.mem[_t_4 + 12] = _o_8;
      e.mem[_t_4 + 13] = _o_9;
      e.mem[_t_4 + 14] = _o_10;
      e.mem[_t_4 + 15] = _v_14;
      e.mem[_t_4 + 16] = _v_15;
      return term_tsk(FID_SNAPSHOT, _t_4);
    }
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _o_8;
    r13 = _o_9;
    r14 = _o_10;
    r15 = _v_14;
    r16 = _v_15;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K211)
  {
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K212;
      WL_PUSHN(1);
    } else {
      u64 _t_5 = task_node(e, FID_MAIN_K212, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K212, _t_5);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 88);
      e.mem[_t_6 + 1] = _h_0;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 88);
    r1 = _h_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K212)
  {
    Term _h_1 = r0;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_3 + 0] = _h_1;
    r0 = term_clo(FID_MAIN_C213, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C213)
  {
    Term _h_2 = r0;
    Term _x_0 = r1;
    WL_OPEN
    u64 _nd_4 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_4 + 0] = _h_2;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_472 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_472 + 0] = term_clo(FID_IO_PRINT, _nd_4);
      e.mem[_t_472 + 1] = term_clo(FID_MAIN_C214, 0);
      e.mem[_t_472 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_472);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_4);
    r1 = term_clo(FID_MAIN_C214, 0);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C214)
  {
    Term _x_1 = r0;
    WL_OPEN
    u32 _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    Term _v_55 = 0;
    Term _v_56 = 0;
    Term _v_57 = 0;
    Term _v_58 = 0;
    Term _v_59 = 0;
    u32 _v_60 = 0;
    Term _v_61 = 0;
    u32 _v_62 = 0;
    Term _v_63 = 0;
    u32 _v_64 = 0;
    Term _v_65 = 0;
    Term _v_66 = 0;
    Term _v_67 = 0;
    Term _fv_9[1];
    _fv_9[0] = 999000ull;
    u64 _nd_5 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_5 + 0] = rfc_seal(e, blk_new(e, 0, 0, 0, 1, _fv_9));
    e.mem[_nd_5 + 1] = rfc_seal(e, 999ull);
    Term _v_68 = 0;
    Term _v_69 = 0;
    Term _v_70 = 0;
    Term _v_71 = 0;
    Term _v_72 = 0;
    Term _v_73 = 0;
    u32 _v_74 = 0;
    Term _v_75 = 0;
    u32 _v_76 = 0;
    Term _v_77 = 0;
    Term _fv_10[1];
    _fv_10[0] = 1000ull;
    u32 _o_11 = 0;
    Term _o_12 = 0;
    Term _t_7 = 1;
    if (_t_7 == 0) {
      _o_11 = 0;
    } else {
      _o_11 = 1;
      u64 _nd_6 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_6 + 0] = rfc_seal(e, blk_new(e, 0, 0, 0, 1, _fv_10));
      e.mem[_nd_6 + 1] = rfc_seal(e, 1ull);
      _o_12 = term_ctr(CID_OWNED, _nd_6);
    }
    Term _fv_11[2];
    _fv_11[0] = _o_11;
    _fv_11[1] = _o_12;
    Term _fv_12[1];
    _fv_12[0] = 101000ull;
    u32 _o_13 = 0;
    Term _o_14 = 0;
    Term _t_8 = 1;
    if (_t_8 == 0) {
      _o_13 = 0;
    } else {
      _o_13 = 1;
      u64 _nd_7 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_7 + 0] = rfc_seal(e, blk_new(e, 0, 0, 0, 1, _fv_12));
      e.mem[_nd_7 + 1] = rfc_seal(e, 101ull);
      _o_14 = term_ctr(CID_OWNED, _nd_7);
    }
    Term _fv_13[2];
    _fv_13[0] = _o_13;
    _fv_13[1] = _o_14;
    Term _fv_14[1];
    _fv_14[0] = 1;
    u32 _o_15 = 0;
    Term _o_16 = 0;
    Term _t_9 = 1;
    if (_t_9 == 0) {
      _o_15 = 0;
    } else {
      _o_15 = 1;
      _o_16 = term_pak(CID_UNIT, 0);
    }
    Term _fv_15[2];
    _fv_15[0] = _o_15;
    _fv_15[1] = _o_16;
    Term _fv_16[1];
    _fv_16[0] = 100ull;
    Term _fv_17[1];
    _fv_17[0] = 200ull;
    Term _v_78 = 0;
    Term _v_79 = 0;
    Term _v_80 = 0;
    Term _v_81 = 0;
    Term _v_82 = 0;
    Term _v_83 = 0;
    u32 _v_84 = 0;
    Term _v_85 = 0;
    u32 _v_86 = 0;
    Term _v_87 = 0;
    Term _o_17[10];
    Term _a_10 = blk_new(e, 1, 0, 1, 2, _fv_11);
    Term _a_11 = blk_new(e, 1, 0, 1, 2, _fv_13);
    Term _a_12 = blk_new(e, 0, 0, 0, 1, _fv_14);
    Term _a_13 = blk_new(e, 1, 0, 1, 2, _fv_15);
    Term _a_14 = blk_new(e, 0, 0, 0, 1, _fv_16);
    Term _a_15 = blk_new(e, 0, 0, 0, 1, _fv_17);
    Term _a_16 = term_pak(CID_NIL, 0);
    if (spin_19(e, _o_17, ((u64)1ull), 1ull, 1ull, 0, 1ull, 1, 7ull, _a_10, blk_loc(e.mem, _a_10), _a_11, blk_loc(e.mem, _a_11), _a_12, blk_loc(e.mem, _a_12), _a_13, blk_loc(e.mem, _a_13), _a_14, blk_loc(e.mem, _a_14), _a_15, blk_loc(e.mem, _a_15), _a_16, blk_loc(e.mem, _a_16)) == 0) {
      return 0;
    }
    _v_78 = _o_17[0];
    _v_79 = _o_17[1];
    _v_80 = _o_17[2];
    _v_81 = _o_17[3];
    _v_82 = _o_17[4];
    _v_83 = _o_17[5];
    _v_84 = _o_17[6];
    _v_85 = _o_17[7];
    _v_86 = _o_17[8];
    _v_87 = _o_17[9];
    _v_68 = _v_78;
    _v_69 = _v_79;
    _v_70 = _v_80;
    _v_71 = _v_81;
    _v_72 = _v_82;
    _v_73 = _v_83;
    _v_74 = _v_84;
    _v_75 = _v_85;
    _v_76 = _v_86;
    _v_77 = _v_87;
    u32 _v_88 = 0;
    u32 _v_89 = 0;
    Term _v_90 = 0;
    Term _v_91 = 0;
    Term _v_92 = 0;
    Term _v_93 = 0;
    Term _v_94 = 0;
    Term _v_95 = 0;
    u32 _v_96 = 0;
    Term _v_97 = 0;
    u32 _v_98 = 0;
    Term _v_99 = 0;
    u32 _v_100 = 0;
    Term _v_101 = 0;
    Term _v_102 = 0;
    Term _v_103 = 0;
    Term _o_18[16];
    Term _a_17 = term_pak(CID_NIL, 0);
    Term _a_18 = term_ctr(CID_OWNED, _nd_5);
    Term _a_19 = 123ull;
    if (spin_21(e, _o_18, 7ull, 999ull, _a_17, blk_loc(e.mem, _a_17), 1, _a_18, blk_loc(e.mem, _a_18), _a_19, blk_loc(e.mem, _a_19), _v_68, blk_loc(e.mem, _v_68), _v_69, blk_loc(e.mem, _v_69), _v_70, blk_loc(e.mem, _v_70), _v_71, blk_loc(e.mem, _v_71), _v_72, blk_loc(e.mem, _v_72), _v_73, blk_loc(e.mem, _v_73), _v_74, _v_75, _v_76, _v_77, blk_loc(e.mem, _v_77)) == 0) {
      return 0;
    }
    _v_88 = _o_18[0];
    _v_89 = _o_18[1];
    _v_90 = _o_18[2];
    _v_91 = _o_18[3];
    _v_92 = _o_18[4];
    _v_93 = _o_18[5];
    _v_94 = _o_18[6];
    _v_95 = _o_18[7];
    _v_96 = _o_18[8];
    _v_97 = _o_18[9];
    _v_98 = _o_18[10];
    _v_99 = _o_18[11];
    _v_100 = _o_18[12];
    _v_101 = _o_18[13];
    _v_102 = _o_18[14];
    _v_103 = _o_18[15];
    _v_52 = _v_88;
    _v_53 = _v_89;
    _v_54 = _v_90;
    _v_55 = _v_91;
    _v_56 = _v_92;
    _v_57 = _v_93;
    _v_58 = _v_94;
    _v_59 = _v_95;
    _v_60 = _v_96;
    _v_61 = _v_97;
    _v_62 = _v_98;
    _v_63 = _v_99;
    _v_64 = _v_100;
    _v_65 = _v_101;
    _v_66 = _v_102;
    _v_67 = _v_103;
    u32 _o_19 = 0;
    Term _o_20 = 0;
    u32 _o_21 = 0;
    if (_v_64 == 0) {
      _o_19 = 0;
    } else {
      _o_19 = 1;
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _v_65, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      u32 _f_3 = _fb_1[1];
      spare_free(e, cls_fit(2), _sp_1);
      _o_20 = _f_2;
      _o_21 = _f_3;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K215;
      WL_PUSHN(1);
    } else {
      u64 _t_10 = task_node(e, FID_MAIN_K215, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K215, _t_10);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_11 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _v_52;
      e.mem[_t_11 + 1] = _v_53;
      e.mem[_t_11 + 2] = _v_54;
      e.mem[_t_11 + 3] = _v_55;
      e.mem[_t_11 + 4] = _v_56;
      e.mem[_t_11 + 5] = _v_57;
      e.mem[_t_11 + 6] = _v_58;
      e.mem[_t_11 + 7] = _v_59;
      e.mem[_t_11 + 8] = _v_60;
      e.mem[_t_11 + 9] = _v_61;
      e.mem[_t_11 + 10] = _v_62;
      e.mem[_t_11 + 11] = _v_63;
      e.mem[_t_11 + 12] = _o_19;
      e.mem[_t_11 + 13] = _o_20;
      e.mem[_t_11 + 14] = _o_21;
      e.mem[_t_11 + 15] = _v_66;
      e.mem[_t_11 + 16] = _v_67;
      return term_tsk(FID_SNAPSHOT, _t_11);
    }
    r0 = _v_52;
    r1 = _v_53;
    r2 = _v_54;
    r3 = _v_55;
    r4 = _v_56;
    r5 = _v_57;
    r6 = _v_58;
    r7 = _v_59;
    r8 = _v_60;
    r9 = _v_61;
    r10 = _v_62;
    r11 = _v_63;
    r12 = _o_19;
    r13 = _o_20;
    r14 = _o_21;
    r15 = _v_66;
    r16 = _v_67;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K215)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K216;
      WL_PUSHN(1);
    } else {
      u64 _t_12 = task_node(e, FID_MAIN_K216, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K216, _t_12);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = term_ctr(CID_SCON, STAT_OFF + 108);
      e.mem[_t_13 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 108);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K216)
  {
    Term _h_4 = r0;
    WL_OPEN
    u64 _nd_8 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_8 + 0] = _h_4;
    r0 = term_clo(FID_MAIN_C217, _nd_8);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C217)
  {
    Term _h_5 = r0;
    Term _x_2 = r1;
    WL_OPEN
    u64 _nd_9 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_9 + 0] = _h_5;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_471 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_471 + 0] = term_clo(FID_IO_PRINT, _nd_9);
      e.mem[_t_471 + 1] = term_clo(FID_MAIN_C218, 0);
      e.mem[_t_471 + 2] = _x_2;
      return term_tsk(FID_IO_BIND, _t_471);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_9);
    r1 = term_clo(FID_MAIN_C218, 0);
    r2 = _x_2;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C218)
  {
    Term _x_3 = r0;
    WL_OPEN
    u32 _v_104 = 0;
    u32 _v_105 = 0;
    Term _v_106 = 0;
    Term _v_107 = 0;
    Term _v_108 = 0;
    Term _v_109 = 0;
    Term _v_110 = 0;
    Term _v_111 = 0;
    u32 _v_112 = 0;
    Term _v_113 = 0;
    u32 _v_114 = 0;
    Term _v_115 = 0;
    u32 _v_116 = 0;
    Term _v_117 = 0;
    Term _v_118 = 0;
    Term _v_119 = 0;
    Term _fv_18[1];
    _fv_18[0] = 999000ull;
    u64 _nd_10 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_10 + 0] = rfc_seal(e, blk_new(e, 0, 0, 0, 1, _fv_18));
    e.mem[_nd_10 + 1] = rfc_seal(e, 999ull);
    Term _v_120 = 0;
    Term _v_121 = 0;
    Term _v_122 = 0;
    Term _v_123 = 0;
    Term _v_124 = 0;
    Term _v_125 = 0;
    u32 _v_126 = 0;
    Term _v_127 = 0;
    u32 _v_128 = 0;
    Term _v_129 = 0;
    Term _fv_19[1];
    _fv_19[0] = 1000ull;
    u32 _o_22 = 0;
    Term _o_23 = 0;
    Term _t_14 = 1;
    if (_t_14 == 0) {
      _o_22 = 0;
    } else {
      _o_22 = 1;
      u64 _nd_11 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_11 + 0] = rfc_seal(e, blk_new(e, 0, 0, 0, 1, _fv_19));
      e.mem[_nd_11 + 1] = rfc_seal(e, 1ull);
      _o_23 = term_ctr(CID_OWNED, _nd_11);
    }
    Term _fv_20[2];
    _fv_20[0] = _o_22;
    _fv_20[1] = _o_23;
    Term _fv_21[1];
    _fv_21[0] = 101000ull;
    u32 _o_24 = 0;
    Term _o_25 = 0;
    Term _t_15 = 1;
    if (_t_15 == 0) {
      _o_24 = 0;
    } else {
      _o_24 = 1;
      u64 _nd_12 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_12 + 0] = rfc_seal(e, blk_new(e, 0, 0, 0, 1, _fv_21));
      e.mem[_nd_12 + 1] = rfc_seal(e, 101ull);
      _o_25 = term_ctr(CID_OWNED, _nd_12);
    }
    Term _fv_22[2];
    _fv_22[0] = _o_24;
    _fv_22[1] = _o_25;
    Term _fv_23[1];
    _fv_23[0] = 1;
    u32 _o_26 = 0;
    Term _o_27 = 0;
    Term _t_16 = 1;
    if (_t_16 == 0) {
      _o_26 = 0;
    } else {
      _o_26 = 1;
      _o_27 = term_pak(CID_UNIT, 0);
    }
    Term _fv_24[2];
    _fv_24[0] = _o_26;
    _fv_24[1] = _o_27;
    Term _fv_25[1];
    _fv_25[0] = 100ull;
    Term _fv_26[1];
    _fv_26[0] = 200ull;
    Term _v_130 = 0;
    Term _v_131 = 0;
    Term _v_132 = 0;
    Term _v_133 = 0;
    Term _v_134 = 0;
    Term _v_135 = 0;
    u32 _v_136 = 0;
    Term _v_137 = 0;
    u32 _v_138 = 0;
    Term _v_139 = 0;
    Term _o_28[10];
    Term _a_20 = blk_new(e, 1, 0, 1, 2, _fv_20);
    Term _a_21 = blk_new(e, 1, 0, 1, 2, _fv_22);
    Term _a_22 = blk_new(e, 0, 0, 0, 1, _fv_23);
    Term _a_23 = blk_new(e, 1, 0, 1, 2, _fv_24);
    Term _a_24 = blk_new(e, 0, 0, 0, 1, _fv_25);
    Term _a_25 = blk_new(e, 0, 0, 0, 1, _fv_26);
    Term _a_26 = term_pak(CID_NIL, 0);
    if (spin_19(e, _o_28, ((u64)1ull), 1ull, 1ull, 0, 1ull, 2, 7ull, _a_20, blk_loc(e.mem, _a_20), _a_21, blk_loc(e.mem, _a_21), _a_22, blk_loc(e.mem, _a_22), _a_23, blk_loc(e.mem, _a_23), _a_24, blk_loc(e.mem, _a_24), _a_25, blk_loc(e.mem, _a_25), _a_26, blk_loc(e.mem, _a_26)) == 0) {
      return 0;
    }
    _v_130 = _o_28[0];
    _v_131 = _o_28[1];
    _v_132 = _o_28[2];
    _v_133 = _o_28[3];
    _v_134 = _o_28[4];
    _v_135 = _o_28[5];
    _v_136 = _o_28[6];
    _v_137 = _o_28[7];
    _v_138 = _o_28[8];
    _v_139 = _o_28[9];
    _v_120 = _v_130;
    _v_121 = _v_131;
    _v_122 = _v_132;
    _v_123 = _v_133;
    _v_124 = _v_134;
    _v_125 = _v_135;
    _v_126 = _v_136;
    _v_127 = _v_137;
    _v_128 = _v_138;
    _v_129 = _v_139;
    u32 _v_140 = 0;
    u32 _v_141 = 0;
    Term _v_142 = 0;
    Term _v_143 = 0;
    Term _v_144 = 0;
    Term _v_145 = 0;
    Term _v_146 = 0;
    Term _v_147 = 0;
    u32 _v_148 = 0;
    Term _v_149 = 0;
    u32 _v_150 = 0;
    Term _v_151 = 0;
    u32 _v_152 = 0;
    Term _v_153 = 0;
    Term _v_154 = 0;
    Term _v_155 = 0;
    Term _o_29[16];
    Term _a_27 = term_pak(CID_NIL, 0);
    Term _a_28 = term_ctr(CID_OWNED, _nd_10);
    Term _a_29 = 123ull;
    if (spin_21(e, _o_29, 7ull, 999ull, _a_27, blk_loc(e.mem, _a_27), 1, _a_28, blk_loc(e.mem, _a_28), _a_29, blk_loc(e.mem, _a_29), _v_120, blk_loc(e.mem, _v_120), _v_121, blk_loc(e.mem, _v_121), _v_122, blk_loc(e.mem, _v_122), _v_123, blk_loc(e.mem, _v_123), _v_124, blk_loc(e.mem, _v_124), _v_125, blk_loc(e.mem, _v_125), _v_126, _v_127, _v_128, _v_129, blk_loc(e.mem, _v_129)) == 0) {
      return 0;
    }
    _v_140 = _o_29[0];
    _v_141 = _o_29[1];
    _v_142 = _o_29[2];
    _v_143 = _o_29[3];
    _v_144 = _o_29[4];
    _v_145 = _o_29[5];
    _v_146 = _o_29[6];
    _v_147 = _o_29[7];
    _v_148 = _o_29[8];
    _v_149 = _o_29[9];
    _v_150 = _o_29[10];
    _v_151 = _o_29[11];
    _v_152 = _o_29[12];
    _v_153 = _o_29[13];
    _v_154 = _o_29[14];
    _v_155 = _o_29[15];
    _v_104 = _v_140;
    _v_105 = _v_141;
    _v_106 = _v_142;
    _v_107 = _v_143;
    _v_108 = _v_144;
    _v_109 = _v_145;
    _v_110 = _v_146;
    _v_111 = _v_147;
    _v_112 = _v_148;
    _v_113 = _v_149;
    _v_114 = _v_150;
    _v_115 = _v_151;
    _v_116 = _v_152;
    _v_117 = _v_153;
    _v_118 = _v_154;
    _v_119 = _v_155;
    u32 _o_30 = 0;
    Term _o_31 = 0;
    u32 _o_32 = 0;
    if (_v_116 == 0) {
      _o_30 = 0;
    } else {
      _o_30 = 1;
      Term _fb_2[2];
      u64 _sp_2 = ctr_take(e, _v_117, 2, _fb_2);
      Term _f_4 = _fb_2[0];
      u32 _f_5 = _fb_2[1];
      spare_free(e, cls_fit(2), _sp_2);
      _o_31 = _f_4;
      _o_32 = _f_5;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K219;
      WL_PUSHN(1);
    } else {
      u64 _t_17 = task_node(e, FID_MAIN_K219, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K219, _t_17);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_18 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_18 + 0] = _v_104;
      e.mem[_t_18 + 1] = _v_105;
      e.mem[_t_18 + 2] = _v_106;
      e.mem[_t_18 + 3] = _v_107;
      e.mem[_t_18 + 4] = _v_108;
      e.mem[_t_18 + 5] = _v_109;
      e.mem[_t_18 + 6] = _v_110;
      e.mem[_t_18 + 7] = _v_111;
      e.mem[_t_18 + 8] = _v_112;
      e.mem[_t_18 + 9] = _v_113;
      e.mem[_t_18 + 10] = _v_114;
      e.mem[_t_18 + 11] = _v_115;
      e.mem[_t_18 + 12] = _o_30;
      e.mem[_t_18 + 13] = _o_31;
      e.mem[_t_18 + 14] = _o_32;
      e.mem[_t_18 + 15] = _v_118;
      e.mem[_t_18 + 16] = _v_119;
      return term_tsk(FID_SNAPSHOT, _t_18);
    }
    r0 = _v_104;
    r1 = _v_105;
    r2 = _v_106;
    r3 = _v_107;
    r4 = _v_108;
    r5 = _v_109;
    r6 = _v_110;
    r7 = _v_111;
    r8 = _v_112;
    r9 = _v_113;
    r10 = _v_114;
    r11 = _v_115;
    r12 = _o_30;
    r13 = _o_31;
    r14 = _o_32;
    r15 = _v_118;
    r16 = _v_119;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K219)
  {
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K220;
      WL_PUSHN(1);
    } else {
      u64 _t_19 = task_node(e, FID_MAIN_K220, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K220, _t_19);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_20 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_20 + 0] = term_ctr(CID_SCON, STAT_OFF + 118);
      e.mem[_t_20 + 1] = _h_6;
      return term_tsk(FID_STRING_APPEND, _t_20);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 118);
    r1 = _h_6;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K220)
  {
    Term _h_7 = r0;
    WL_OPEN
    u64 _nd_13 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_13 + 0] = _h_7;
    r0 = term_clo(FID_MAIN_C221, _nd_13);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C221)
  {
    Term _h_8 = r0;
    Term _x_4 = r1;
    WL_OPEN
    u64 _nd_14 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_14 + 0] = _h_8;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_470 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_470 + 0] = term_clo(FID_IO_PRINT, _nd_14);
      e.mem[_t_470 + 1] = term_clo(FID_MAIN_C222, 0);
      e.mem[_t_470 + 2] = _x_4;
      return term_tsk(FID_IO_BIND, _t_470);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_14);
    r1 = term_clo(FID_MAIN_C222, 0);
    r2 = _x_4;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C222)
  {
    Term _x_5 = r0;
    WL_OPEN
    u32 _v_156 = 0;
    u32 _v_157 = 0;
    Term _v_158 = 0;
    Term _v_159 = 0;
    Term _v_160 = 0;
    Term _v_161 = 0;
    Term _v_162 = 0;
    Term _v_163 = 0;
    u32 _v_164 = 0;
    Term _v_165 = 0;
    u32 _v_166 = 0;
    Term _v_167 = 0;
    u32 _v_168 = 0;
    Term _v_169 = 0;
    Term _v_170 = 0;
    Term _v_171 = 0;
    Term _fv_27[1];
    _fv_27[0] = 999000ull;
    u64 _nd_15 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_15 + 0] = rfc_seal(e, blk_new(e, 0, 0, 0, 1, _fv_27));
    e.mem[_nd_15 + 1] = rfc_seal(e, 999ull);
    Term _v_172 = 0;
    Term _v_173 = 0;
    Term _v_174 = 0;
    Term _v_175 = 0;
    Term _v_176 = 0;
    Term _v_177 = 0;
    u32 _v_178 = 0;
    Term _v_179 = 0;
    u32 _v_180 = 0;
    Term _v_181 = 0;
    Term _fv_28[1];
    _fv_28[0] = 1000ull;
    u32 _o_33 = 0;
    Term _o_34 = 0;
    Term _t_21 = 1;
    if (_t_21 == 0) {
      _o_33 = 0;
    } else {
      _o_33 = 1;
      u64 _nd_16 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_16 + 0] = rfc_seal(e, blk_new(e, 0, 0, 0, 1, _fv_28));
      e.mem[_nd_16 + 1] = rfc_seal(e, 1ull);
      _o_34 = term_ctr(CID_OWNED, _nd_16);
    }
    Term _fv_29[2];
    _fv_29[0] = _o_33;
    _fv_29[1] = _o_34;
    Term _fv_30[1];
    _fv_30[0] = 101000ull;
    u32 _o_35 = 0;
    Term _o_36 = 0;
    Term _t_22 = 1;
    if (_t_22 == 0) {
      _o_35 = 0;
    } else {
      _o_35 = 1;
      u64 _nd_17 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_17 + 0] = rfc_seal(e, blk_new(e, 0, 0, 0, 1, _fv_30));
      e.mem[_nd_17 + 1] = rfc_seal(e, 101ull);
      _o_36 = term_ctr(CID_OWNED, _nd_17);
    }
    Term _fv_31[2];
    _fv_31[0] = _o_35;
    _fv_31[1] = _o_36;
    Term _fv_32[1];
    _fv_32[0] = 1;
    u32 _o_37 = 0;
    Term _o_38 = 0;
    Term _t_23 = 1;
    if (_t_23 == 0) {
      _o_37 = 0;
    } else {
      _o_37 = 1;
      _o_38 = term_pak(CID_UNIT, 0);
    }
    Term _fv_33[2];
    _fv_33[0] = _o_37;
    _fv_33[1] = _o_38;
    Term _fv_34[1];
    _fv_34[0] = 100ull;
    Term _fv_35[1];
    _fv_35[0] = 200ull;
    Term _v_182 = 0;
    Term _v_183 = 0;
    Term _v_184 = 0;
    Term _v_185 = 0;
    Term _v_186 = 0;
    Term _v_187 = 0;
    u32 _v_188 = 0;
    Term _v_189 = 0;
    u32 _v_190 = 0;
    Term _v_191 = 0;
    Term _o_39[10];
    Term _a_30 = blk_new(e, 1, 0, 1, 2, _fv_29);
    Term _a_31 = blk_new(e, 1, 0, 1, 2, _fv_31);
    Term _a_32 = blk_new(e, 0, 0, 0, 1, _fv_32);
    Term _a_33 = blk_new(e, 1, 0, 1, 2, _fv_33);
    Term _a_34 = blk_new(e, 0, 0, 0, 1, _fv_34);
    Term _a_35 = blk_new(e, 0, 0, 0, 1, _fv_35);
    Term _a_36 = term_pak(CID_NIL, 0);
    if (spin_19(e, _o_39, ((u64)1ull), 1ull, 1ull, 0, 1ull, 3, 7ull, _a_30, blk_loc(e.mem, _a_30), _a_31, blk_loc(e.mem, _a_31), _a_32, blk_loc(e.mem, _a_32), _a_33, blk_loc(e.mem, _a_33), _a_34, blk_loc(e.mem, _a_34), _a_35, blk_loc(e.mem, _a_35), _a_36, blk_loc(e.mem, _a_36)) == 0) {
      return 0;
    }
    _v_182 = _o_39[0];
    _v_183 = _o_39[1];
    _v_184 = _o_39[2];
    _v_185 = _o_39[3];
    _v_186 = _o_39[4];
    _v_187 = _o_39[5];
    _v_188 = _o_39[6];
    _v_189 = _o_39[7];
    _v_190 = _o_39[8];
    _v_191 = _o_39[9];
    _v_172 = _v_182;
    _v_173 = _v_183;
    _v_174 = _v_184;
    _v_175 = _v_185;
    _v_176 = _v_186;
    _v_177 = _v_187;
    _v_178 = _v_188;
    _v_179 = _v_189;
    _v_180 = _v_190;
    _v_181 = _v_191;
    u32 _v_192 = 0;
    u32 _v_193 = 0;
    Term _v_194 = 0;
    Term _v_195 = 0;
    Term _v_196 = 0;
    Term _v_197 = 0;
    Term _v_198 = 0;
    Term _v_199 = 0;
    u32 _v_200 = 0;
    Term _v_201 = 0;
    u32 _v_202 = 0;
    Term _v_203 = 0;
    u32 _v_204 = 0;
    Term _v_205 = 0;
    Term _v_206 = 0;
    Term _v_207 = 0;
    Term _o_40[16];
    Term _a_37 = term_pak(CID_NIL, 0);
    Term _a_38 = term_ctr(CID_OWNED, _nd_15);
    Term _a_39 = 123ull;
    if (spin_21(e, _o_40, 7ull, 999ull, _a_37, blk_loc(e.mem, _a_37), 1, _a_38, blk_loc(e.mem, _a_38), _a_39, blk_loc(e.mem, _a_39), _v_172, blk_loc(e.mem, _v_172), _v_173, blk_loc(e.mem, _v_173), _v_174, blk_loc(e.mem, _v_174), _v_175, blk_loc(e.mem, _v_175), _v_176, blk_loc(e.mem, _v_176), _v_177, blk_loc(e.mem, _v_177), _v_178, _v_179, _v_180, _v_181, blk_loc(e.mem, _v_181)) == 0) {
      return 0;
    }
    _v_192 = _o_40[0];
    _v_193 = _o_40[1];
    _v_194 = _o_40[2];
    _v_195 = _o_40[3];
    _v_196 = _o_40[4];
    _v_197 = _o_40[5];
    _v_198 = _o_40[6];
    _v_199 = _o_40[7];
    _v_200 = _o_40[8];
    _v_201 = _o_40[9];
    _v_202 = _o_40[10];
    _v_203 = _o_40[11];
    _v_204 = _o_40[12];
    _v_205 = _o_40[13];
    _v_206 = _o_40[14];
    _v_207 = _o_40[15];
    _v_156 = _v_192;
    _v_157 = _v_193;
    _v_158 = _v_194;
    _v_159 = _v_195;
    _v_160 = _v_196;
    _v_161 = _v_197;
    _v_162 = _v_198;
    _v_163 = _v_199;
    _v_164 = _v_200;
    _v_165 = _v_201;
    _v_166 = _v_202;
    _v_167 = _v_203;
    _v_168 = _v_204;
    _v_169 = _v_205;
    _v_170 = _v_206;
    _v_171 = _v_207;
    u32 _o_41 = 0;
    Term _o_42 = 0;
    u32 _o_43 = 0;
    if (_v_168 == 0) {
      _o_41 = 0;
    } else {
      _o_41 = 1;
      Term _fb_3[2];
      u64 _sp_3 = ctr_take(e, _v_169, 2, _fb_3);
      Term _f_6 = _fb_3[0];
      u32 _f_7 = _fb_3[1];
      spare_free(e, cls_fit(2), _sp_3);
      _o_42 = _f_6;
      _o_43 = _f_7;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K223;
      WL_PUSHN(1);
    } else {
      u64 _t_24 = task_node(e, FID_MAIN_K223, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K223, _t_24);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_25 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = _v_156;
      e.mem[_t_25 + 1] = _v_157;
      e.mem[_t_25 + 2] = _v_158;
      e.mem[_t_25 + 3] = _v_159;
      e.mem[_t_25 + 4] = _v_160;
      e.mem[_t_25 + 5] = _v_161;
      e.mem[_t_25 + 6] = _v_162;
      e.mem[_t_25 + 7] = _v_163;
      e.mem[_t_25 + 8] = _v_164;
      e.mem[_t_25 + 9] = _v_165;
      e.mem[_t_25 + 10] = _v_166;
      e.mem[_t_25 + 11] = _v_167;
      e.mem[_t_25 + 12] = _o_41;
      e.mem[_t_25 + 13] = _o_42;
      e.mem[_t_25 + 14] = _o_43;
      e.mem[_t_25 + 15] = _v_170;
      e.mem[_t_25 + 16] = _v_171;
      return term_tsk(FID_SNAPSHOT, _t_25);
    }
    r0 = _v_156;
    r1 = _v_157;
    r2 = _v_158;
    r3 = _v_159;
    r4 = _v_160;
    r5 = _v_161;
    r6 = _v_162;
    r7 = _v_163;
    r8 = _v_164;
    r9 = _v_165;
    r10 = _v_166;
    r11 = _v_167;
    r12 = _o_41;
    r13 = _o_42;
    r14 = _o_43;
    r15 = _v_170;
    r16 = _v_171;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K223)
  {
    Term _h_9 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K224;
      WL_PUSHN(1);
    } else {
      u64 _t_26 = task_node(e, FID_MAIN_K224, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K224, _t_26);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_27 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_27 + 0] = term_ctr(CID_SCON, STAT_OFF + 140);
      e.mem[_t_27 + 1] = _h_9;
      return term_tsk(FID_STRING_APPEND, _t_27);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 140);
    r1 = _h_9;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K224)
  {
    Term _h_10 = r0;
    WL_OPEN
    u64 _nd_18 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_18 + 0] = _h_10;
    r0 = term_clo(FID_MAIN_C225, _nd_18);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C225)
  {
    Term _h_11 = r0;
    Term _x_6 = r1;
    WL_OPEN
    u64 _nd_19 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_19 + 0] = _h_11;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_469 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_469 + 0] = term_clo(FID_IO_PRINT, _nd_19);
      e.mem[_t_469 + 1] = term_clo(FID_MAIN_C226, 0);
      e.mem[_t_469 + 2] = _x_6;
      return term_tsk(FID_IO_BIND, _t_469);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_19);
    r1 = term_clo(FID_MAIN_C226, 0);
    r2 = _x_6;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C226)
  {
    Term _x_7 = r0;
    WL_OPEN
    u32 _v_208 = 0;
    u32 _v_209 = 0;
    Term _v_210 = 0;
    Term _v_211 = 0;
    Term _v_212 = 0;
    Term _v_213 = 0;
    Term _v_214 = 0;
    Term _v_215 = 0;
    u32 _v_216 = 0;
    Term _v_217 = 0;
    u32 _v_218 = 0;
    Term _v_219 = 0;
    u32 _v_220 = 0;
    Term _v_221 = 0;
    Term _v_222 = 0;
    Term _v_223 = 0;
    Term _fv_36[1];
    _fv_36[0] = 999000ull;
    Term _fv_37[1];
    _fv_37[0] = 999001ull;
    u64 _nd_20 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_20 + 0] = rfc_seal(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_36), blk_new(e, 0, 0, 0, 1, _fv_37)));
    e.mem[_nd_20 + 1] = rfc_seal(e, 999ull);
    Term _v_224 = 0;
    Term _v_225 = 0;
    Term _v_226 = 0;
    Term _v_227 = 0;
    Term _v_228 = 0;
    Term _v_229 = 0;
    u32 _v_230 = 0;
    Term _v_231 = 0;
    u32 _v_232 = 0;
    Term _v_233 = 0;
    Term _fv_38[1];
    _fv_38[0] = 1000ull;
    Term _fv_39[1];
    _fv_39[0] = 1001ull;
    u32 _o_44 = 0;
    Term _o_45 = 0;
    Term _t_28 = 1;
    if (_t_28 == 0) {
      _o_44 = 0;
    } else {
      _o_44 = 1;
      u64 _nd_21 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_21 + 0] = rfc_seal(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_38), blk_new(e, 0, 0, 0, 1, _fv_39)));
      e.mem[_nd_21 + 1] = rfc_seal(e, 1ull);
      _o_45 = term_ctr(CID_OWNED, _nd_21);
    }
    Term _fv_40[2];
    _fv_40[0] = _o_44;
    _fv_40[1] = _o_45;
    u32 _o_46 = 0;
    Term _o_47 = 0;
    Term _t_29 = 0;
    if (_t_29 == 0) {
      _o_46 = 0;
    } else {
      _o_46 = 1;
      u64 _nd_22 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_22 + 0] = rfc_seal(e, 0);
      e.mem[_nd_22 + 1] = rfc_seal(e, 0);
      _o_47 = term_ctr(CID_OWNED, _nd_22);
    }
    Term _fv_41[2];
    _fv_41[0] = _o_46;
    _fv_41[1] = _o_47;
    Term _fv_42[1];
    _fv_42[0] = 101000ull;
    Term _fv_43[1];
    _fv_43[0] = 101001ull;
    u32 _o_48 = 0;
    Term _o_49 = 0;
    Term _t_30 = 1;
    if (_t_30 == 0) {
      _o_48 = 0;
    } else {
      _o_48 = 1;
      u64 _nd_23 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_23 + 0] = rfc_seal(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_42), blk_new(e, 0, 0, 0, 1, _fv_43)));
      e.mem[_nd_23 + 1] = rfc_seal(e, 101ull);
      _o_49 = term_ctr(CID_OWNED, _nd_23);
    }
    Term _fv_44[2];
    _fv_44[0] = _o_48;
    _fv_44[1] = _o_49;
    Term _fv_45[1];
    _fv_45[0] = 102000ull;
    Term _fv_46[1];
    _fv_46[0] = 102001ull;
    u32 _o_50 = 0;
    Term _o_51 = 0;
    Term _t_31 = 1;
    if (_t_31 == 0) {
      _o_50 = 0;
    } else {
      _o_50 = 1;
      u64 _nd_24 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_24 + 0] = rfc_seal(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_45), blk_new(e, 0, 0, 0, 1, _fv_46)));
      e.mem[_nd_24 + 1] = rfc_seal(e, 102ull);
      _o_51 = term_ctr(CID_OWNED, _nd_24);
    }
    Term _fv_47[2];
    _fv_47[0] = _o_50;
    _fv_47[1] = _o_51;
    Term _fv_48[1];
    _fv_48[0] = 1;
    Term _fv_49[1];
    _fv_49[0] = 1;
    u32 _o_52 = 0;
    Term _o_53 = 0;
    Term _t_32 = 1;
    if (_t_32 == 0) {
      _o_52 = 0;
    } else {
      _o_52 = 1;
      _o_53 = term_pak(CID_UNIT, 0);
    }
    Term _fv_50[2];
    _fv_50[0] = _o_52;
    _fv_50[1] = _o_53;
    u32 _o_54 = 0;
    Term _o_55 = 0;
    Term _t_33 = 0;
    if (_t_33 == 0) {
      _o_54 = 0;
    } else {
      _o_54 = 1;
      _o_55 = term_pak(CID_UNIT, 0);
    }
    Term _fv_51[2];
    _fv_51[0] = _o_54;
    _fv_51[1] = _o_55;
    Term _fv_52[1];
    _fv_52[0] = 100ull;
    Term _fv_53[1];
    _fv_53[0] = 101ull;
    Term _fv_54[1];
    _fv_54[0] = 200ull;
    Term _fv_55[1];
    _fv_55[0] = 201ull;
    Term _v_234 = 0;
    Term _v_235 = 0;
    Term _v_236 = 0;
    Term _v_237 = 0;
    Term _v_238 = 0;
    Term _v_239 = 0;
    u32 _v_240 = 0;
    Term _v_241 = 0;
    u32 _v_242 = 0;
    Term _v_243 = 0;
    Term _o_56[10];
    Term _a_40 = blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_40), blk_new(e, 1, 0, 1, 2, _fv_41));
    Term _a_41 = blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_44), blk_new(e, 1, 0, 1, 2, _fv_47));
    Term _a_42 = blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_48), blk_new(e, 0, 0, 0, 1, _fv_49));
    Term _a_43 = blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_50), blk_new(e, 1, 0, 1, 2, _fv_51));
    Term _a_44 = blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_52), blk_new(e, 0, 0, 0, 1, _fv_53));
    Term _a_45 = blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_54), blk_new(e, 0, 0, 0, 1, _fv_55));
    Term _a_46 = term_pak(CID_NIL, 0);
    if (spin_19(e, _o_56, ((u64)1ull), 1ull, 2ull, 1ull, 1ull, 0, 7ull, _a_40, blk_loc(e.mem, _a_40), _a_41, blk_loc(e.mem, _a_41), _a_42, blk_loc(e.mem, _a_42), _a_43, blk_loc(e.mem, _a_43), _a_44, blk_loc(e.mem, _a_44), _a_45, blk_loc(e.mem, _a_45), _a_46, blk_loc(e.mem, _a_46)) == 0) {
      return 0;
    }
    _v_234 = _o_56[0];
    _v_235 = _o_56[1];
    _v_236 = _o_56[2];
    _v_237 = _o_56[3];
    _v_238 = _o_56[4];
    _v_239 = _o_56[5];
    _v_240 = _o_56[6];
    _v_241 = _o_56[7];
    _v_242 = _o_56[8];
    _v_243 = _o_56[9];
    _v_224 = _v_234;
    _v_225 = _v_235;
    _v_226 = _v_236;
    _v_227 = _v_237;
    _v_228 = _v_238;
    _v_229 = _v_239;
    _v_230 = _v_240;
    _v_231 = _v_241;
    _v_232 = _v_242;
    _v_233 = _v_243;
    u32 _v_244 = 0;
    u32 _v_245 = 0;
    Term _v_246 = 0;
    Term _v_247 = 0;
    Term _v_248 = 0;
    Term _v_249 = 0;
    Term _v_250 = 0;
    Term _v_251 = 0;
    u32 _v_252 = 0;
    Term _v_253 = 0;
    u32 _v_254 = 0;
    Term _v_255 = 0;
    u32 _v_256 = 0;
    Term _v_257 = 0;
    Term _v_258 = 0;
    Term _v_259 = 0;
    Term _o_57[16];
    Term _a_47 = term_pak(CID_NIL, 0);
    Term _a_48 = term_ctr(CID_OWNED, _nd_20);
    Term _a_49 = 123ull;
    if (spin_21(e, _o_57, 7ull, 999ull, _a_47, blk_loc(e.mem, _a_47), 1, _a_48, blk_loc(e.mem, _a_48), _a_49, blk_loc(e.mem, _a_49), _v_224, blk_loc(e.mem, _v_224), _v_225, blk_loc(e.mem, _v_225), _v_226, blk_loc(e.mem, _v_226), _v_227, blk_loc(e.mem, _v_227), _v_228, blk_loc(e.mem, _v_228), _v_229, blk_loc(e.mem, _v_229), _v_230, _v_231, _v_232, _v_233, blk_loc(e.mem, _v_233)) == 0) {
      return 0;
    }
    _v_244 = _o_57[0];
    _v_245 = _o_57[1];
    _v_246 = _o_57[2];
    _v_247 = _o_57[3];
    _v_248 = _o_57[4];
    _v_249 = _o_57[5];
    _v_250 = _o_57[6];
    _v_251 = _o_57[7];
    _v_252 = _o_57[8];
    _v_253 = _o_57[9];
    _v_254 = _o_57[10];
    _v_255 = _o_57[11];
    _v_256 = _o_57[12];
    _v_257 = _o_57[13];
    _v_258 = _o_57[14];
    _v_259 = _o_57[15];
    _v_208 = _v_244;
    _v_209 = _v_245;
    _v_210 = _v_246;
    _v_211 = _v_247;
    _v_212 = _v_248;
    _v_213 = _v_249;
    _v_214 = _v_250;
    _v_215 = _v_251;
    _v_216 = _v_252;
    _v_217 = _v_253;
    _v_218 = _v_254;
    _v_219 = _v_255;
    _v_220 = _v_256;
    _v_221 = _v_257;
    _v_222 = _v_258;
    _v_223 = _v_259;
    u32 _o_58 = 0;
    Term _o_59 = 0;
    u32 _o_60 = 0;
    if (_v_220 == 0) {
      _o_58 = 0;
    } else {
      _o_58 = 1;
      Term _fb_4[2];
      u64 _sp_4 = ctr_take(e, _v_221, 2, _fb_4);
      Term _f_8 = _fb_4[0];
      u32 _f_9 = _fb_4[1];
      spare_free(e, cls_fit(2), _sp_4);
      _o_59 = _f_8;
      _o_60 = _f_9;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K227;
      WL_PUSHN(1);
    } else {
      u64 _t_34 = task_node(e, FID_MAIN_K227, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K227, _t_34);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_35 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_35 + 0] = _v_208;
      e.mem[_t_35 + 1] = _v_209;
      e.mem[_t_35 + 2] = _v_210;
      e.mem[_t_35 + 3] = _v_211;
      e.mem[_t_35 + 4] = _v_212;
      e.mem[_t_35 + 5] = _v_213;
      e.mem[_t_35 + 6] = _v_214;
      e.mem[_t_35 + 7] = _v_215;
      e.mem[_t_35 + 8] = _v_216;
      e.mem[_t_35 + 9] = _v_217;
      e.mem[_t_35 + 10] = _v_218;
      e.mem[_t_35 + 11] = _v_219;
      e.mem[_t_35 + 12] = _o_58;
      e.mem[_t_35 + 13] = _o_59;
      e.mem[_t_35 + 14] = _o_60;
      e.mem[_t_35 + 15] = _v_222;
      e.mem[_t_35 + 16] = _v_223;
      return term_tsk(FID_SNAPSHOT, _t_35);
    }
    r0 = _v_208;
    r1 = _v_209;
    r2 = _v_210;
    r3 = _v_211;
    r4 = _v_212;
    r5 = _v_213;
    r6 = _v_214;
    r7 = _v_215;
    r8 = _v_216;
    r9 = _v_217;
    r10 = _v_218;
    r11 = _v_219;
    r12 = _o_58;
    r13 = _o_59;
    r14 = _o_60;
    r15 = _v_222;
    r16 = _v_223;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K227)
  {
    Term _h_12 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K228;
      WL_PUSHN(1);
    } else {
      u64 _t_36 = task_node(e, FID_MAIN_K228, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K228, _t_36);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_37 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_37 + 0] = term_ctr(CID_SCON, STAT_OFF + 144);
      e.mem[_t_37 + 1] = _h_12;
      return term_tsk(FID_STRING_APPEND, _t_37);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 144);
    r1 = _h_12;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K228)
  {
    Term _h_13 = r0;
    WL_OPEN
    u64 _nd_25 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_25 + 0] = _h_13;
    r0 = term_clo(FID_MAIN_C229, _nd_25);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C229)
  {
    Term _h_14 = r0;
    Term _x_8 = r1;
    WL_OPEN
    u64 _nd_26 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_26 + 0] = _h_14;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_468 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_468 + 0] = term_clo(FID_IO_PRINT, _nd_26);
      e.mem[_t_468 + 1] = term_clo(FID_MAIN_C230, 0);
      e.mem[_t_468 + 2] = _x_8;
      return term_tsk(FID_IO_BIND, _t_468);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_26);
    r1 = term_clo(FID_MAIN_C230, 0);
    r2 = _x_8;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C230)
  {
    Term _x_9 = r0;
    WL_OPEN
    u32 _v_260 = 0;
    u32 _v_261 = 0;
    Term _v_262 = 0;
    Term _v_263 = 0;
    Term _v_264 = 0;
    Term _v_265 = 0;
    Term _v_266 = 0;
    Term _v_267 = 0;
    u32 _v_268 = 0;
    Term _v_269 = 0;
    u32 _v_270 = 0;
    Term _v_271 = 0;
    u32 _v_272 = 0;
    Term _v_273 = 0;
    Term _v_274 = 0;
    Term _v_275 = 0;
    Term _fv_56[1];
    _fv_56[0] = 999000ull;
    Term _fv_57[1];
    _fv_57[0] = 999001ull;
    u64 _nd_27 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_27 + 0] = rfc_seal(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_56), blk_new(e, 0, 0, 0, 1, _fv_57)));
    e.mem[_nd_27 + 1] = rfc_seal(e, 999ull);
    Term _v_276 = 0;
    Term _v_277 = 0;
    Term _v_278 = 0;
    Term _v_279 = 0;
    Term _v_280 = 0;
    Term _v_281 = 0;
    u32 _v_282 = 0;
    Term _v_283 = 0;
    u32 _v_284 = 0;
    Term _v_285 = 0;
    Term _fv_58[1];
    _fv_58[0] = 1000ull;
    Term _fv_59[1];
    _fv_59[0] = 1001ull;
    u32 _o_61 = 0;
    Term _o_62 = 0;
    Term _t_38 = 1;
    if (_t_38 == 0) {
      _o_61 = 0;
    } else {
      _o_61 = 1;
      u64 _nd_28 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_28 + 0] = rfc_seal(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_58), blk_new(e, 0, 0, 0, 1, _fv_59)));
      e.mem[_nd_28 + 1] = rfc_seal(e, 1ull);
      _o_62 = term_ctr(CID_OWNED, _nd_28);
    }
    Term _fv_60[2];
    _fv_60[0] = _o_61;
    _fv_60[1] = _o_62;
    u32 _o_63 = 0;
    Term _o_64 = 0;
    Term _t_39 = 0;
    if (_t_39 == 0) {
      _o_63 = 0;
    } else {
      _o_63 = 1;
      u64 _nd_29 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_29 + 0] = rfc_seal(e, 0);
      e.mem[_nd_29 + 1] = rfc_seal(e, 0);
      _o_64 = term_ctr(CID_OWNED, _nd_29);
    }
    Term _fv_61[2];
    _fv_61[0] = _o_63;
    _fv_61[1] = _o_64;
    Term _fv_62[1];
    _fv_62[0] = 101000ull;
    Term _fv_63[1];
    _fv_63[0] = 101001ull;
    u32 _o_65 = 0;
    Term _o_66 = 0;
    Term _t_40 = 1;
    if (_t_40 == 0) {
      _o_65 = 0;
    } else {
      _o_65 = 1;
      u64 _nd_30 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_30 + 0] = rfc_seal(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_62), blk_new(e, 0, 0, 0, 1, _fv_63)));
      e.mem[_nd_30 + 1] = rfc_seal(e, 101ull);
      _o_66 = term_ctr(CID_OWNED, _nd_30);
    }
    Term _fv_64[2];
    _fv_64[0] = _o_65;
    _fv_64[1] = _o_66;
    Term _fv_65[1];
    _fv_65[0] = 102000ull;
    Term _fv_66[1];
    _fv_66[0] = 102001ull;
    u32 _o_67 = 0;
    Term _o_68 = 0;
    Term _t_41 = 1;
    if (_t_41 == 0) {
      _o_67 = 0;
    } else {
      _o_67 = 1;
      u64 _nd_31 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_31 + 0] = rfc_seal(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_65), blk_new(e, 0, 0, 0, 1, _fv_66)));
      e.mem[_nd_31 + 1] = rfc_seal(e, 102ull);
      _o_68 = term_ctr(CID_OWNED, _nd_31);
    }
    Term _fv_67[2];
    _fv_67[0] = _o_67;
    _fv_67[1] = _o_68;
    Term _fv_68[1];
    _fv_68[0] = 1;
    Term _fv_69[1];
    _fv_69[0] = 1;
    u32 _o_69 = 0;
    Term _o_70 = 0;
    Term _t_42 = 1;
    if (_t_42 == 0) {
      _o_69 = 0;
    } else {
      _o_69 = 1;
      _o_70 = term_pak(CID_UNIT, 0);
    }
    Term _fv_70[2];
    _fv_70[0] = _o_69;
    _fv_70[1] = _o_70;
    u32 _o_71 = 0;
    Term _o_72 = 0;
    Term _t_43 = 0;
    if (_t_43 == 0) {
      _o_71 = 0;
    } else {
      _o_71 = 1;
      _o_72 = term_pak(CID_UNIT, 0);
    }
    Term _fv_71[2];
    _fv_71[0] = _o_71;
    _fv_71[1] = _o_72;
    Term _fv_72[1];
    _fv_72[0] = 100ull;
    Term _fv_73[1];
    _fv_73[0] = 101ull;
    Term _fv_74[1];
    _fv_74[0] = 200ull;
    Term _fv_75[1];
    _fv_75[0] = 201ull;
    Term _v_286 = 0;
    Term _v_287 = 0;
    Term _v_288 = 0;
    Term _v_289 = 0;
    Term _v_290 = 0;
    Term _v_291 = 0;
    u32 _v_292 = 0;
    Term _v_293 = 0;
    u32 _v_294 = 0;
    Term _v_295 = 0;
    Term _o_73[10];
    Term _a_50 = blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_60), blk_new(e, 1, 0, 1, 2, _fv_61));
    Term _a_51 = blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_64), blk_new(e, 1, 0, 1, 2, _fv_67));
    Term _a_52 = blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_68), blk_new(e, 0, 0, 0, 1, _fv_69));
    Term _a_53 = blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_70), blk_new(e, 1, 0, 1, 2, _fv_71));
    Term _a_54 = blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_72), blk_new(e, 0, 0, 0, 1, _fv_73));
    Term _a_55 = blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_74), blk_new(e, 0, 0, 0, 1, _fv_75));
    Term _a_56 = term_pak(CID_NIL, 0);
    if (spin_19(e, _o_73, ((u64)1ull), 1ull, 2ull, 1ull, 1ull, 1, 7ull, _a_50, blk_loc(e.mem, _a_50), _a_51, blk_loc(e.mem, _a_51), _a_52, blk_loc(e.mem, _a_52), _a_53, blk_loc(e.mem, _a_53), _a_54, blk_loc(e.mem, _a_54), _a_55, blk_loc(e.mem, _a_55), _a_56, blk_loc(e.mem, _a_56)) == 0) {
      return 0;
    }
    _v_286 = _o_73[0];
    _v_287 = _o_73[1];
    _v_288 = _o_73[2];
    _v_289 = _o_73[3];
    _v_290 = _o_73[4];
    _v_291 = _o_73[5];
    _v_292 = _o_73[6];
    _v_293 = _o_73[7];
    _v_294 = _o_73[8];
    _v_295 = _o_73[9];
    _v_276 = _v_286;
    _v_277 = _v_287;
    _v_278 = _v_288;
    _v_279 = _v_289;
    _v_280 = _v_290;
    _v_281 = _v_291;
    _v_282 = _v_292;
    _v_283 = _v_293;
    _v_284 = _v_294;
    _v_285 = _v_295;
    u32 _v_296 = 0;
    u32 _v_297 = 0;
    Term _v_298 = 0;
    Term _v_299 = 0;
    Term _v_300 = 0;
    Term _v_301 = 0;
    Term _v_302 = 0;
    Term _v_303 = 0;
    u32 _v_304 = 0;
    Term _v_305 = 0;
    u32 _v_306 = 0;
    Term _v_307 = 0;
    u32 _v_308 = 0;
    Term _v_309 = 0;
    Term _v_310 = 0;
    Term _v_311 = 0;
    Term _o_74[16];
    Term _a_57 = term_pak(CID_NIL, 0);
    Term _a_58 = term_ctr(CID_OWNED, _nd_27);
    Term _a_59 = 123ull;
    if (spin_21(e, _o_74, 7ull, 999ull, _a_57, blk_loc(e.mem, _a_57), 1, _a_58, blk_loc(e.mem, _a_58), _a_59, blk_loc(e.mem, _a_59), _v_276, blk_loc(e.mem, _v_276), _v_277, blk_loc(e.mem, _v_277), _v_278, blk_loc(e.mem, _v_278), _v_279, blk_loc(e.mem, _v_279), _v_280, blk_loc(e.mem, _v_280), _v_281, blk_loc(e.mem, _v_281), _v_282, _v_283, _v_284, _v_285, blk_loc(e.mem, _v_285)) == 0) {
      return 0;
    }
    _v_296 = _o_74[0];
    _v_297 = _o_74[1];
    _v_298 = _o_74[2];
    _v_299 = _o_74[3];
    _v_300 = _o_74[4];
    _v_301 = _o_74[5];
    _v_302 = _o_74[6];
    _v_303 = _o_74[7];
    _v_304 = _o_74[8];
    _v_305 = _o_74[9];
    _v_306 = _o_74[10];
    _v_307 = _o_74[11];
    _v_308 = _o_74[12];
    _v_309 = _o_74[13];
    _v_310 = _o_74[14];
    _v_311 = _o_74[15];
    _v_260 = _v_296;
    _v_261 = _v_297;
    _v_262 = _v_298;
    _v_263 = _v_299;
    _v_264 = _v_300;
    _v_265 = _v_301;
    _v_266 = _v_302;
    _v_267 = _v_303;
    _v_268 = _v_304;
    _v_269 = _v_305;
    _v_270 = _v_306;
    _v_271 = _v_307;
    _v_272 = _v_308;
    _v_273 = _v_309;
    _v_274 = _v_310;
    _v_275 = _v_311;
    u32 _o_75 = 0;
    Term _o_76 = 0;
    u32 _o_77 = 0;
    if (_v_272 == 0) {
      _o_75 = 0;
    } else {
      _o_75 = 1;
      Term _fb_5[2];
      u64 _sp_5 = ctr_take(e, _v_273, 2, _fb_5);
      Term _f_10 = _fb_5[0];
      u32 _f_11 = _fb_5[1];
      spare_free(e, cls_fit(2), _sp_5);
      _o_76 = _f_10;
      _o_77 = _f_11;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K231;
      WL_PUSHN(1);
    } else {
      u64 _t_44 = task_node(e, FID_MAIN_K231, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K231, _t_44);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_45 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_45 + 0] = _v_260;
      e.mem[_t_45 + 1] = _v_261;
      e.mem[_t_45 + 2] = _v_262;
      e.mem[_t_45 + 3] = _v_263;
      e.mem[_t_45 + 4] = _v_264;
      e.mem[_t_45 + 5] = _v_265;
      e.mem[_t_45 + 6] = _v_266;
      e.mem[_t_45 + 7] = _v_267;
      e.mem[_t_45 + 8] = _v_268;
      e.mem[_t_45 + 9] = _v_269;
      e.mem[_t_45 + 10] = _v_270;
      e.mem[_t_45 + 11] = _v_271;
      e.mem[_t_45 + 12] = _o_75;
      e.mem[_t_45 + 13] = _o_76;
      e.mem[_t_45 + 14] = _o_77;
      e.mem[_t_45 + 15] = _v_274;
      e.mem[_t_45 + 16] = _v_275;
      return term_tsk(FID_SNAPSHOT, _t_45);
    }
    r0 = _v_260;
    r1 = _v_261;
    r2 = _v_262;
    r3 = _v_263;
    r4 = _v_264;
    r5 = _v_265;
    r6 = _v_266;
    r7 = _v_267;
    r8 = _v_268;
    r9 = _v_269;
    r10 = _v_270;
    r11 = _v_271;
    r12 = _o_75;
    r13 = _o_76;
    r14 = _o_77;
    r15 = _v_274;
    r16 = _v_275;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K231)
  {
    Term _h_15 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K232;
      WL_PUSHN(1);
    } else {
      u64 _t_46 = task_node(e, FID_MAIN_K232, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K232, _t_46);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_47 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_47 + 0] = term_ctr(CID_SCON, STAT_OFF + 148);
      e.mem[_t_47 + 1] = _h_15;
      return term_tsk(FID_STRING_APPEND, _t_47);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 148);
    r1 = _h_15;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K232)
  {
    Term _h_16 = r0;
    WL_OPEN
    u64 _nd_32 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_32 + 0] = _h_16;
    r0 = term_clo(FID_MAIN_C233, _nd_32);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C233)
  {
    Term _h_17 = r0;
    Term _x_10 = r1;
    WL_OPEN
    u64 _nd_33 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_33 + 0] = _h_17;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_467 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_467 + 0] = term_clo(FID_IO_PRINT, _nd_33);
      e.mem[_t_467 + 1] = term_clo(FID_MAIN_C234, 0);
      e.mem[_t_467 + 2] = _x_10;
      return term_tsk(FID_IO_BIND, _t_467);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_33);
    r1 = term_clo(FID_MAIN_C234, 0);
    r2 = _x_10;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C234)
  {
    Term _x_11 = r0;
    WL_OPEN
    u32 _v_312 = 0;
    u32 _v_313 = 0;
    Term _v_314 = 0;
    Term _v_315 = 0;
    Term _v_316 = 0;
    Term _v_317 = 0;
    Term _v_318 = 0;
    Term _v_319 = 0;
    u32 _v_320 = 0;
    Term _v_321 = 0;
    u32 _v_322 = 0;
    Term _v_323 = 0;
    u32 _v_324 = 0;
    Term _v_325 = 0;
    Term _v_326 = 0;
    Term _v_327 = 0;
    Term _fv_76[1];
    _fv_76[0] = 999000ull;
    Term _fv_77[1];
    _fv_77[0] = 999001ull;
    u64 _nd_34 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_34 + 0] = rfc_seal(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_76), blk_new(e, 0, 0, 0, 1, _fv_77)));
    e.mem[_nd_34 + 1] = rfc_seal(e, 999ull);
    Term _v_328 = 0;
    Term _v_329 = 0;
    Term _v_330 = 0;
    Term _v_331 = 0;
    Term _v_332 = 0;
    Term _v_333 = 0;
    u32 _v_334 = 0;
    Term _v_335 = 0;
    u32 _v_336 = 0;
    Term _v_337 = 0;
    Term _fv_78[1];
    _fv_78[0] = 1000ull;
    Term _fv_79[1];
    _fv_79[0] = 1001ull;
    u32 _o_78 = 0;
    Term _o_79 = 0;
    Term _t_48 = 1;
    if (_t_48 == 0) {
      _o_78 = 0;
    } else {
      _o_78 = 1;
      u64 _nd_35 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_35 + 0] = rfc_seal(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_78), blk_new(e, 0, 0, 0, 1, _fv_79)));
      e.mem[_nd_35 + 1] = rfc_seal(e, 1ull);
      _o_79 = term_ctr(CID_OWNED, _nd_35);
    }
    Term _fv_80[2];
    _fv_80[0] = _o_78;
    _fv_80[1] = _o_79;
    u32 _o_80 = 0;
    Term _o_81 = 0;
    Term _t_49 = 0;
    if (_t_49 == 0) {
      _o_80 = 0;
    } else {
      _o_80 = 1;
      u64 _nd_36 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_36 + 0] = rfc_seal(e, 0);
      e.mem[_nd_36 + 1] = rfc_seal(e, 0);
      _o_81 = term_ctr(CID_OWNED, _nd_36);
    }
    Term _fv_81[2];
    _fv_81[0] = _o_80;
    _fv_81[1] = _o_81;
    Term _fv_82[1];
    _fv_82[0] = 101000ull;
    Term _fv_83[1];
    _fv_83[0] = 101001ull;
    u32 _o_82 = 0;
    Term _o_83 = 0;
    Term _t_50 = 1;
    if (_t_50 == 0) {
      _o_82 = 0;
    } else {
      _o_82 = 1;
      u64 _nd_37 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_37 + 0] = rfc_seal(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_82), blk_new(e, 0, 0, 0, 1, _fv_83)));
      e.mem[_nd_37 + 1] = rfc_seal(e, 101ull);
      _o_83 = term_ctr(CID_OWNED, _nd_37);
    }
    Term _fv_84[2];
    _fv_84[0] = _o_82;
    _fv_84[1] = _o_83;
    Term _fv_85[1];
    _fv_85[0] = 102000ull;
    Term _fv_86[1];
    _fv_86[0] = 102001ull;
    u32 _o_84 = 0;
    Term _o_85 = 0;
    Term _t_51 = 1;
    if (_t_51 == 0) {
      _o_84 = 0;
    } else {
      _o_84 = 1;
      u64 _nd_38 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_38 + 0] = rfc_seal(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_85), blk_new(e, 0, 0, 0, 1, _fv_86)));
      e.mem[_nd_38 + 1] = rfc_seal(e, 102ull);
      _o_85 = term_ctr(CID_OWNED, _nd_38);
    }
    Term _fv_87[2];
    _fv_87[0] = _o_84;
    _fv_87[1] = _o_85;
    Term _fv_88[1];
    _fv_88[0] = 1;
    Term _fv_89[1];
    _fv_89[0] = 1;
    u32 _o_86 = 0;
    Term _o_87 = 0;
    Term _t_52 = 1;
    if (_t_52 == 0) {
      _o_86 = 0;
    } else {
      _o_86 = 1;
      _o_87 = term_pak(CID_UNIT, 0);
    }
    Term _fv_90[2];
    _fv_90[0] = _o_86;
    _fv_90[1] = _o_87;
    u32 _o_88 = 0;
    Term _o_89 = 0;
    Term _t_53 = 0;
    if (_t_53 == 0) {
      _o_88 = 0;
    } else {
      _o_88 = 1;
      _o_89 = term_pak(CID_UNIT, 0);
    }
    Term _fv_91[2];
    _fv_91[0] = _o_88;
    _fv_91[1] = _o_89;
    Term _fv_92[1];
    _fv_92[0] = 100ull;
    Term _fv_93[1];
    _fv_93[0] = 101ull;
    Term _fv_94[1];
    _fv_94[0] = 200ull;
    Term _fv_95[1];
    _fv_95[0] = 201ull;
    Term _v_338 = 0;
    Term _v_339 = 0;
    Term _v_340 = 0;
    Term _v_341 = 0;
    Term _v_342 = 0;
    Term _v_343 = 0;
    u32 _v_344 = 0;
    Term _v_345 = 0;
    u32 _v_346 = 0;
    Term _v_347 = 0;
    Term _o_90[10];
    Term _a_60 = blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_80), blk_new(e, 1, 0, 1, 2, _fv_81));
    Term _a_61 = blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_84), blk_new(e, 1, 0, 1, 2, _fv_87));
    Term _a_62 = blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_88), blk_new(e, 0, 0, 0, 1, _fv_89));
    Term _a_63 = blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_90), blk_new(e, 1, 0, 1, 2, _fv_91));
    Term _a_64 = blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_92), blk_new(e, 0, 0, 0, 1, _fv_93));
    Term _a_65 = blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_94), blk_new(e, 0, 0, 0, 1, _fv_95));
    Term _a_66 = term_pak(CID_NIL, 0);
    if (spin_19(e, _o_90, ((u64)1ull), 1ull, 2ull, 1ull, 1ull, 2, 7ull, _a_60, blk_loc(e.mem, _a_60), _a_61, blk_loc(e.mem, _a_61), _a_62, blk_loc(e.mem, _a_62), _a_63, blk_loc(e.mem, _a_63), _a_64, blk_loc(e.mem, _a_64), _a_65, blk_loc(e.mem, _a_65), _a_66, blk_loc(e.mem, _a_66)) == 0) {
      return 0;
    }
    _v_338 = _o_90[0];
    _v_339 = _o_90[1];
    _v_340 = _o_90[2];
    _v_341 = _o_90[3];
    _v_342 = _o_90[4];
    _v_343 = _o_90[5];
    _v_344 = _o_90[6];
    _v_345 = _o_90[7];
    _v_346 = _o_90[8];
    _v_347 = _o_90[9];
    _v_328 = _v_338;
    _v_329 = _v_339;
    _v_330 = _v_340;
    _v_331 = _v_341;
    _v_332 = _v_342;
    _v_333 = _v_343;
    _v_334 = _v_344;
    _v_335 = _v_345;
    _v_336 = _v_346;
    _v_337 = _v_347;
    u32 _v_348 = 0;
    u32 _v_349 = 0;
    Term _v_350 = 0;
    Term _v_351 = 0;
    Term _v_352 = 0;
    Term _v_353 = 0;
    Term _v_354 = 0;
    Term _v_355 = 0;
    u32 _v_356 = 0;
    Term _v_357 = 0;
    u32 _v_358 = 0;
    Term _v_359 = 0;
    u32 _v_360 = 0;
    Term _v_361 = 0;
    Term _v_362 = 0;
    Term _v_363 = 0;
    Term _o_91[16];
    Term _a_67 = term_pak(CID_NIL, 0);
    Term _a_68 = term_ctr(CID_OWNED, _nd_34);
    Term _a_69 = 123ull;
    if (spin_21(e, _o_91, 7ull, 999ull, _a_67, blk_loc(e.mem, _a_67), 1, _a_68, blk_loc(e.mem, _a_68), _a_69, blk_loc(e.mem, _a_69), _v_328, blk_loc(e.mem, _v_328), _v_329, blk_loc(e.mem, _v_329), _v_330, blk_loc(e.mem, _v_330), _v_331, blk_loc(e.mem, _v_331), _v_332, blk_loc(e.mem, _v_332), _v_333, blk_loc(e.mem, _v_333), _v_334, _v_335, _v_336, _v_337, blk_loc(e.mem, _v_337)) == 0) {
      return 0;
    }
    _v_348 = _o_91[0];
    _v_349 = _o_91[1];
    _v_350 = _o_91[2];
    _v_351 = _o_91[3];
    _v_352 = _o_91[4];
    _v_353 = _o_91[5];
    _v_354 = _o_91[6];
    _v_355 = _o_91[7];
    _v_356 = _o_91[8];
    _v_357 = _o_91[9];
    _v_358 = _o_91[10];
    _v_359 = _o_91[11];
    _v_360 = _o_91[12];
    _v_361 = _o_91[13];
    _v_362 = _o_91[14];
    _v_363 = _o_91[15];
    _v_312 = _v_348;
    _v_313 = _v_349;
    _v_314 = _v_350;
    _v_315 = _v_351;
    _v_316 = _v_352;
    _v_317 = _v_353;
    _v_318 = _v_354;
    _v_319 = _v_355;
    _v_320 = _v_356;
    _v_321 = _v_357;
    _v_322 = _v_358;
    _v_323 = _v_359;
    _v_324 = _v_360;
    _v_325 = _v_361;
    _v_326 = _v_362;
    _v_327 = _v_363;
    u32 _o_92 = 0;
    Term _o_93 = 0;
    u32 _o_94 = 0;
    if (_v_324 == 0) {
      _o_92 = 0;
    } else {
      _o_92 = 1;
      Term _fb_6[2];
      u64 _sp_6 = ctr_take(e, _v_325, 2, _fb_6);
      Term _f_12 = _fb_6[0];
      u32 _f_13 = _fb_6[1];
      spare_free(e, cls_fit(2), _sp_6);
      _o_93 = _f_12;
      _o_94 = _f_13;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K235;
      WL_PUSHN(1);
    } else {
      u64 _t_54 = task_node(e, FID_MAIN_K235, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K235, _t_54);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_55 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_55 + 0] = _v_312;
      e.mem[_t_55 + 1] = _v_313;
      e.mem[_t_55 + 2] = _v_314;
      e.mem[_t_55 + 3] = _v_315;
      e.mem[_t_55 + 4] = _v_316;
      e.mem[_t_55 + 5] = _v_317;
      e.mem[_t_55 + 6] = _v_318;
      e.mem[_t_55 + 7] = _v_319;
      e.mem[_t_55 + 8] = _v_320;
      e.mem[_t_55 + 9] = _v_321;
      e.mem[_t_55 + 10] = _v_322;
      e.mem[_t_55 + 11] = _v_323;
      e.mem[_t_55 + 12] = _o_92;
      e.mem[_t_55 + 13] = _o_93;
      e.mem[_t_55 + 14] = _o_94;
      e.mem[_t_55 + 15] = _v_326;
      e.mem[_t_55 + 16] = _v_327;
      return term_tsk(FID_SNAPSHOT, _t_55);
    }
    r0 = _v_312;
    r1 = _v_313;
    r2 = _v_314;
    r3 = _v_315;
    r4 = _v_316;
    r5 = _v_317;
    r6 = _v_318;
    r7 = _v_319;
    r8 = _v_320;
    r9 = _v_321;
    r10 = _v_322;
    r11 = _v_323;
    r12 = _o_92;
    r13 = _o_93;
    r14 = _o_94;
    r15 = _v_326;
    r16 = _v_327;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K235)
  {
    Term _h_18 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K236;
      WL_PUSHN(1);
    } else {
      u64 _t_56 = task_node(e, FID_MAIN_K236, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K236, _t_56);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_57 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_57 + 0] = term_ctr(CID_SCON, STAT_OFF + 152);
      e.mem[_t_57 + 1] = _h_18;
      return term_tsk(FID_STRING_APPEND, _t_57);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 152);
    r1 = _h_18;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K236)
  {
    Term _h_19 = r0;
    WL_OPEN
    u64 _nd_39 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_39 + 0] = _h_19;
    r0 = term_clo(FID_MAIN_C237, _nd_39);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C237)
  {
    Term _h_20 = r0;
    Term _x_12 = r1;
    WL_OPEN
    u64 _nd_40 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_40 + 0] = _h_20;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_466 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_466 + 0] = term_clo(FID_IO_PRINT, _nd_40);
      e.mem[_t_466 + 1] = term_clo(FID_MAIN_C238, 0);
      e.mem[_t_466 + 2] = _x_12;
      return term_tsk(FID_IO_BIND, _t_466);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_40);
    r1 = term_clo(FID_MAIN_C238, 0);
    r2 = _x_12;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C238)
  {
    Term _x_13 = r0;
    WL_OPEN
    u32 _v_364 = 0;
    u32 _v_365 = 0;
    Term _v_366 = 0;
    Term _v_367 = 0;
    Term _v_368 = 0;
    Term _v_369 = 0;
    Term _v_370 = 0;
    Term _v_371 = 0;
    u32 _v_372 = 0;
    Term _v_373 = 0;
    u32 _v_374 = 0;
    Term _v_375 = 0;
    u32 _v_376 = 0;
    Term _v_377 = 0;
    Term _v_378 = 0;
    Term _v_379 = 0;
    Term _fv_96[1];
    _fv_96[0] = 999000ull;
    Term _fv_97[1];
    _fv_97[0] = 999001ull;
    u64 _nd_41 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_41 + 0] = rfc_seal(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_96), blk_new(e, 0, 0, 0, 1, _fv_97)));
    e.mem[_nd_41 + 1] = rfc_seal(e, 999ull);
    Term _v_380 = 0;
    Term _v_381 = 0;
    Term _v_382 = 0;
    Term _v_383 = 0;
    Term _v_384 = 0;
    Term _v_385 = 0;
    u32 _v_386 = 0;
    Term _v_387 = 0;
    u32 _v_388 = 0;
    Term _v_389 = 0;
    Term _fv_98[1];
    _fv_98[0] = 1000ull;
    Term _fv_99[1];
    _fv_99[0] = 1001ull;
    u32 _o_95 = 0;
    Term _o_96 = 0;
    Term _t_58 = 1;
    if (_t_58 == 0) {
      _o_95 = 0;
    } else {
      _o_95 = 1;
      u64 _nd_42 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_42 + 0] = rfc_seal(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_98), blk_new(e, 0, 0, 0, 1, _fv_99)));
      e.mem[_nd_42 + 1] = rfc_seal(e, 1ull);
      _o_96 = term_ctr(CID_OWNED, _nd_42);
    }
    Term _fv_100[2];
    _fv_100[0] = _o_95;
    _fv_100[1] = _o_96;
    u32 _o_97 = 0;
    Term _o_98 = 0;
    Term _t_59 = 0;
    if (_t_59 == 0) {
      _o_97 = 0;
    } else {
      _o_97 = 1;
      u64 _nd_43 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_43 + 0] = rfc_seal(e, 0);
      e.mem[_nd_43 + 1] = rfc_seal(e, 0);
      _o_98 = term_ctr(CID_OWNED, _nd_43);
    }
    Term _fv_101[2];
    _fv_101[0] = _o_97;
    _fv_101[1] = _o_98;
    Term _fv_102[1];
    _fv_102[0] = 101000ull;
    Term _fv_103[1];
    _fv_103[0] = 101001ull;
    u32 _o_99 = 0;
    Term _o_100 = 0;
    Term _t_60 = 1;
    if (_t_60 == 0) {
      _o_99 = 0;
    } else {
      _o_99 = 1;
      u64 _nd_44 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_44 + 0] = rfc_seal(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_102), blk_new(e, 0, 0, 0, 1, _fv_103)));
      e.mem[_nd_44 + 1] = rfc_seal(e, 101ull);
      _o_100 = term_ctr(CID_OWNED, _nd_44);
    }
    Term _fv_104[2];
    _fv_104[0] = _o_99;
    _fv_104[1] = _o_100;
    Term _fv_105[1];
    _fv_105[0] = 102000ull;
    Term _fv_106[1];
    _fv_106[0] = 102001ull;
    u32 _o_101 = 0;
    Term _o_102 = 0;
    Term _t_61 = 1;
    if (_t_61 == 0) {
      _o_101 = 0;
    } else {
      _o_101 = 1;
      u64 _nd_45 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_45 + 0] = rfc_seal(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_105), blk_new(e, 0, 0, 0, 1, _fv_106)));
      e.mem[_nd_45 + 1] = rfc_seal(e, 102ull);
      _o_102 = term_ctr(CID_OWNED, _nd_45);
    }
    Term _fv_107[2];
    _fv_107[0] = _o_101;
    _fv_107[1] = _o_102;
    Term _fv_108[1];
    _fv_108[0] = 1;
    Term _fv_109[1];
    _fv_109[0] = 1;
    u32 _o_103 = 0;
    Term _o_104 = 0;
    Term _t_62 = 1;
    if (_t_62 == 0) {
      _o_103 = 0;
    } else {
      _o_103 = 1;
      _o_104 = term_pak(CID_UNIT, 0);
    }
    Term _fv_110[2];
    _fv_110[0] = _o_103;
    _fv_110[1] = _o_104;
    u32 _o_105 = 0;
    Term _o_106 = 0;
    Term _t_63 = 0;
    if (_t_63 == 0) {
      _o_105 = 0;
    } else {
      _o_105 = 1;
      _o_106 = term_pak(CID_UNIT, 0);
    }
    Term _fv_111[2];
    _fv_111[0] = _o_105;
    _fv_111[1] = _o_106;
    Term _fv_112[1];
    _fv_112[0] = 100ull;
    Term _fv_113[1];
    _fv_113[0] = 101ull;
    Term _fv_114[1];
    _fv_114[0] = 200ull;
    Term _fv_115[1];
    _fv_115[0] = 201ull;
    Term _v_390 = 0;
    Term _v_391 = 0;
    Term _v_392 = 0;
    Term _v_393 = 0;
    Term _v_394 = 0;
    Term _v_395 = 0;
    u32 _v_396 = 0;
    Term _v_397 = 0;
    u32 _v_398 = 0;
    Term _v_399 = 0;
    Term _o_107[10];
    Term _a_70 = blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_100), blk_new(e, 1, 0, 1, 2, _fv_101));
    Term _a_71 = blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_104), blk_new(e, 1, 0, 1, 2, _fv_107));
    Term _a_72 = blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_108), blk_new(e, 0, 0, 0, 1, _fv_109));
    Term _a_73 = blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_110), blk_new(e, 1, 0, 1, 2, _fv_111));
    Term _a_74 = blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_112), blk_new(e, 0, 0, 0, 1, _fv_113));
    Term _a_75 = blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_114), blk_new(e, 0, 0, 0, 1, _fv_115));
    Term _a_76 = term_pak(CID_NIL, 0);
    if (spin_19(e, _o_107, ((u64)1ull), 1ull, 2ull, 1ull, 1ull, 3, 7ull, _a_70, blk_loc(e.mem, _a_70), _a_71, blk_loc(e.mem, _a_71), _a_72, blk_loc(e.mem, _a_72), _a_73, blk_loc(e.mem, _a_73), _a_74, blk_loc(e.mem, _a_74), _a_75, blk_loc(e.mem, _a_75), _a_76, blk_loc(e.mem, _a_76)) == 0) {
      return 0;
    }
    _v_390 = _o_107[0];
    _v_391 = _o_107[1];
    _v_392 = _o_107[2];
    _v_393 = _o_107[3];
    _v_394 = _o_107[4];
    _v_395 = _o_107[5];
    _v_396 = _o_107[6];
    _v_397 = _o_107[7];
    _v_398 = _o_107[8];
    _v_399 = _o_107[9];
    _v_380 = _v_390;
    _v_381 = _v_391;
    _v_382 = _v_392;
    _v_383 = _v_393;
    _v_384 = _v_394;
    _v_385 = _v_395;
    _v_386 = _v_396;
    _v_387 = _v_397;
    _v_388 = _v_398;
    _v_389 = _v_399;
    u32 _v_400 = 0;
    u32 _v_401 = 0;
    Term _v_402 = 0;
    Term _v_403 = 0;
    Term _v_404 = 0;
    Term _v_405 = 0;
    Term _v_406 = 0;
    Term _v_407 = 0;
    u32 _v_408 = 0;
    Term _v_409 = 0;
    u32 _v_410 = 0;
    Term _v_411 = 0;
    u32 _v_412 = 0;
    Term _v_413 = 0;
    Term _v_414 = 0;
    Term _v_415 = 0;
    Term _o_108[16];
    Term _a_77 = term_pak(CID_NIL, 0);
    Term _a_78 = term_ctr(CID_OWNED, _nd_41);
    Term _a_79 = 123ull;
    if (spin_21(e, _o_108, 7ull, 999ull, _a_77, blk_loc(e.mem, _a_77), 1, _a_78, blk_loc(e.mem, _a_78), _a_79, blk_loc(e.mem, _a_79), _v_380, blk_loc(e.mem, _v_380), _v_381, blk_loc(e.mem, _v_381), _v_382, blk_loc(e.mem, _v_382), _v_383, blk_loc(e.mem, _v_383), _v_384, blk_loc(e.mem, _v_384), _v_385, blk_loc(e.mem, _v_385), _v_386, _v_387, _v_388, _v_389, blk_loc(e.mem, _v_389)) == 0) {
      return 0;
    }
    _v_400 = _o_108[0];
    _v_401 = _o_108[1];
    _v_402 = _o_108[2];
    _v_403 = _o_108[3];
    _v_404 = _o_108[4];
    _v_405 = _o_108[5];
    _v_406 = _o_108[6];
    _v_407 = _o_108[7];
    _v_408 = _o_108[8];
    _v_409 = _o_108[9];
    _v_410 = _o_108[10];
    _v_411 = _o_108[11];
    _v_412 = _o_108[12];
    _v_413 = _o_108[13];
    _v_414 = _o_108[14];
    _v_415 = _o_108[15];
    _v_364 = _v_400;
    _v_365 = _v_401;
    _v_366 = _v_402;
    _v_367 = _v_403;
    _v_368 = _v_404;
    _v_369 = _v_405;
    _v_370 = _v_406;
    _v_371 = _v_407;
    _v_372 = _v_408;
    _v_373 = _v_409;
    _v_374 = _v_410;
    _v_375 = _v_411;
    _v_376 = _v_412;
    _v_377 = _v_413;
    _v_378 = _v_414;
    _v_379 = _v_415;
    u32 _o_109 = 0;
    Term _o_110 = 0;
    u32 _o_111 = 0;
    if (_v_376 == 0) {
      _o_109 = 0;
    } else {
      _o_109 = 1;
      Term _fb_7[2];
      u64 _sp_7 = ctr_take(e, _v_377, 2, _fb_7);
      Term _f_14 = _fb_7[0];
      u32 _f_15 = _fb_7[1];
      spare_free(e, cls_fit(2), _sp_7);
      _o_110 = _f_14;
      _o_111 = _f_15;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K239;
      WL_PUSHN(1);
    } else {
      u64 _t_64 = task_node(e, FID_MAIN_K239, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K239, _t_64);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_65 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_65 + 0] = _v_364;
      e.mem[_t_65 + 1] = _v_365;
      e.mem[_t_65 + 2] = _v_366;
      e.mem[_t_65 + 3] = _v_367;
      e.mem[_t_65 + 4] = _v_368;
      e.mem[_t_65 + 5] = _v_369;
      e.mem[_t_65 + 6] = _v_370;
      e.mem[_t_65 + 7] = _v_371;
      e.mem[_t_65 + 8] = _v_372;
      e.mem[_t_65 + 9] = _v_373;
      e.mem[_t_65 + 10] = _v_374;
      e.mem[_t_65 + 11] = _v_375;
      e.mem[_t_65 + 12] = _o_109;
      e.mem[_t_65 + 13] = _o_110;
      e.mem[_t_65 + 14] = _o_111;
      e.mem[_t_65 + 15] = _v_378;
      e.mem[_t_65 + 16] = _v_379;
      return term_tsk(FID_SNAPSHOT, _t_65);
    }
    r0 = _v_364;
    r1 = _v_365;
    r2 = _v_366;
    r3 = _v_367;
    r4 = _v_368;
    r5 = _v_369;
    r6 = _v_370;
    r7 = _v_371;
    r8 = _v_372;
    r9 = _v_373;
    r10 = _v_374;
    r11 = _v_375;
    r12 = _o_109;
    r13 = _o_110;
    r14 = _o_111;
    r15 = _v_378;
    r16 = _v_379;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K239)
  {
    Term _h_21 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K240;
      WL_PUSHN(1);
    } else {
      u64 _t_66 = task_node(e, FID_MAIN_K240, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K240, _t_66);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_67 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_67 + 0] = term_ctr(CID_SCON, STAT_OFF + 156);
      e.mem[_t_67 + 1] = _h_21;
      return term_tsk(FID_STRING_APPEND, _t_67);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 156);
    r1 = _h_21;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K240)
  {
    Term _h_22 = r0;
    WL_OPEN
    u64 _nd_46 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_46 + 0] = _h_22;
    r0 = term_clo(FID_MAIN_C241, _nd_46);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C241)
  {
    Term _h_23 = r0;
    Term _x_14 = r1;
    WL_OPEN
    u64 _nd_47 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_47 + 0] = _h_23;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_465 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_465 + 0] = term_clo(FID_IO_PRINT, _nd_47);
      e.mem[_t_465 + 1] = term_clo(FID_MAIN_C242, 0);
      e.mem[_t_465 + 2] = _x_14;
      return term_tsk(FID_IO_BIND, _t_465);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_47);
    r1 = term_clo(FID_MAIN_C242, 0);
    r2 = _x_14;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C242)
  {
    Term _x_15 = r0;
    WL_OPEN
    u32 _v_416 = 0;
    u32 _v_417 = 0;
    Term _v_418 = 0;
    Term _v_419 = 0;
    Term _v_420 = 0;
    Term _v_421 = 0;
    Term _v_422 = 0;
    Term _v_423 = 0;
    u32 _v_424 = 0;
    Term _v_425 = 0;
    u32 _v_426 = 0;
    Term _v_427 = 0;
    u32 _v_428 = 0;
    Term _v_429 = 0;
    Term _v_430 = 0;
    Term _v_431 = 0;
    Term _fv_116[1];
    _fv_116[0] = 999000ull;
    Term _fv_117[1];
    _fv_117[0] = 999001ull;
    Term _fv_118[1];
    _fv_118[0] = 999002ull;
    Term _fv_119[1];
    _fv_119[0] = 999003ull;
    u64 _nd_48 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_48 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_116), blk_new(e, 0, 0, 0, 1, _fv_117)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_118), blk_new(e, 0, 0, 0, 1, _fv_119))));
    e.mem[_nd_48 + 1] = rfc_seal(e, 999ull);
    Term _v_432 = 0;
    Term _v_433 = 0;
    Term _v_434 = 0;
    Term _v_435 = 0;
    Term _v_436 = 0;
    Term _v_437 = 0;
    u32 _v_438 = 0;
    Term _v_439 = 0;
    u32 _v_440 = 0;
    Term _v_441 = 0;
    Term _fv_120[1];
    _fv_120[0] = 1000ull;
    Term _fv_121[1];
    _fv_121[0] = 1001ull;
    Term _fv_122[1];
    _fv_122[0] = 1002ull;
    Term _fv_123[1];
    _fv_123[0] = 1003ull;
    u32 _o_112 = 0;
    Term _o_113 = 0;
    Term _t_68 = 1;
    if (_t_68 == 0) {
      _o_112 = 0;
    } else {
      _o_112 = 1;
      u64 _nd_49 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_49 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_120), blk_new(e, 0, 0, 0, 1, _fv_121)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_122), blk_new(e, 0, 0, 0, 1, _fv_123))));
      e.mem[_nd_49 + 1] = rfc_seal(e, 1ull);
      _o_113 = term_ctr(CID_OWNED, _nd_49);
    }
    Term _fv_124[2];
    _fv_124[0] = _o_112;
    _fv_124[1] = _o_113;
    u32 _o_114 = 0;
    Term _o_115 = 0;
    Term _t_69 = 0;
    if (_t_69 == 0) {
      _o_114 = 0;
    } else {
      _o_114 = 1;
      u64 _nd_50 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_50 + 0] = rfc_seal(e, 0);
      e.mem[_nd_50 + 1] = rfc_seal(e, 0);
      _o_115 = term_ctr(CID_OWNED, _nd_50);
    }
    Term _fv_125[2];
    _fv_125[0] = _o_114;
    _fv_125[1] = _o_115;
    Term _fv_126[1];
    _fv_126[0] = 3000ull;
    Term _fv_127[1];
    _fv_127[0] = 3001ull;
    Term _fv_128[1];
    _fv_128[0] = 3002ull;
    Term _fv_129[1];
    _fv_129[0] = 3003ull;
    u32 _o_116 = 0;
    Term _o_117 = 0;
    Term _t_70 = 1;
    if (_t_70 == 0) {
      _o_116 = 0;
    } else {
      _o_116 = 1;
      u64 _nd_51 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_51 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_126), blk_new(e, 0, 0, 0, 1, _fv_127)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_128), blk_new(e, 0, 0, 0, 1, _fv_129))));
      e.mem[_nd_51 + 1] = rfc_seal(e, 3ull);
      _o_117 = term_ctr(CID_OWNED, _nd_51);
    }
    Term _fv_130[2];
    _fv_130[0] = _o_116;
    _fv_130[1] = _o_117;
    Term _fv_131[1];
    _fv_131[0] = 4000ull;
    Term _fv_132[1];
    _fv_132[0] = 4001ull;
    Term _fv_133[1];
    _fv_133[0] = 4002ull;
    Term _fv_134[1];
    _fv_134[0] = 4003ull;
    u32 _o_118 = 0;
    Term _o_119 = 0;
    Term _t_71 = 1;
    if (_t_71 == 0) {
      _o_118 = 0;
    } else {
      _o_118 = 1;
      u64 _nd_52 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_52 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_131), blk_new(e, 0, 0, 0, 1, _fv_132)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_133), blk_new(e, 0, 0, 0, 1, _fv_134))));
      e.mem[_nd_52 + 1] = rfc_seal(e, 4ull);
      _o_119 = term_ctr(CID_OWNED, _nd_52);
    }
    Term _fv_135[2];
    _fv_135[0] = _o_118;
    _fv_135[1] = _o_119;
    Term _fv_136[1];
    _fv_136[0] = 101000ull;
    Term _fv_137[1];
    _fv_137[0] = 101001ull;
    Term _fv_138[1];
    _fv_138[0] = 101002ull;
    Term _fv_139[1];
    _fv_139[0] = 101003ull;
    u32 _o_120 = 0;
    Term _o_121 = 0;
    Term _t_72 = 1;
    if (_t_72 == 0) {
      _o_120 = 0;
    } else {
      _o_120 = 1;
      u64 _nd_53 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_53 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_136), blk_new(e, 0, 0, 0, 1, _fv_137)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_138), blk_new(e, 0, 0, 0, 1, _fv_139))));
      e.mem[_nd_53 + 1] = rfc_seal(e, 101ull);
      _o_121 = term_ctr(CID_OWNED, _nd_53);
    }
    Term _fv_140[2];
    _fv_140[0] = _o_120;
    _fv_140[1] = _o_121;
    Term _fv_141[1];
    _fv_141[0] = 102000ull;
    Term _fv_142[1];
    _fv_142[0] = 102001ull;
    Term _fv_143[1];
    _fv_143[0] = 102002ull;
    Term _fv_144[1];
    _fv_144[0] = 102003ull;
    u32 _o_122 = 0;
    Term _o_123 = 0;
    Term _t_73 = 1;
    if (_t_73 == 0) {
      _o_122 = 0;
    } else {
      _o_122 = 1;
      u64 _nd_54 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_54 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_141), blk_new(e, 0, 0, 0, 1, _fv_142)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_143), blk_new(e, 0, 0, 0, 1, _fv_144))));
      e.mem[_nd_54 + 1] = rfc_seal(e, 102ull);
      _o_123 = term_ctr(CID_OWNED, _nd_54);
    }
    Term _fv_145[2];
    _fv_145[0] = _o_122;
    _fv_145[1] = _o_123;
    Term _fv_146[1];
    _fv_146[0] = 103000ull;
    Term _fv_147[1];
    _fv_147[0] = 103001ull;
    Term _fv_148[1];
    _fv_148[0] = 103002ull;
    Term _fv_149[1];
    _fv_149[0] = 103003ull;
    u32 _o_124 = 0;
    Term _o_125 = 0;
    Term _t_74 = 1;
    if (_t_74 == 0) {
      _o_124 = 0;
    } else {
      _o_124 = 1;
      u64 _nd_55 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_55 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_146), blk_new(e, 0, 0, 0, 1, _fv_147)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_148), blk_new(e, 0, 0, 0, 1, _fv_149))));
      e.mem[_nd_55 + 1] = rfc_seal(e, 103ull);
      _o_125 = term_ctr(CID_OWNED, _nd_55);
    }
    Term _fv_150[2];
    _fv_150[0] = _o_124;
    _fv_150[1] = _o_125;
    Term _fv_151[1];
    _fv_151[0] = 104000ull;
    Term _fv_152[1];
    _fv_152[0] = 104001ull;
    Term _fv_153[1];
    _fv_153[0] = 104002ull;
    Term _fv_154[1];
    _fv_154[0] = 104003ull;
    u32 _o_126 = 0;
    Term _o_127 = 0;
    Term _t_75 = 1;
    if (_t_75 == 0) {
      _o_126 = 0;
    } else {
      _o_126 = 1;
      u64 _nd_56 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_56 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_151), blk_new(e, 0, 0, 0, 1, _fv_152)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_153), blk_new(e, 0, 0, 0, 1, _fv_154))));
      e.mem[_nd_56 + 1] = rfc_seal(e, 104ull);
      _o_127 = term_ctr(CID_OWNED, _nd_56);
    }
    Term _fv_155[2];
    _fv_155[0] = _o_126;
    _fv_155[1] = _o_127;
    Term _fv_156[1];
    _fv_156[0] = 1;
    Term _fv_157[1];
    _fv_157[0] = 1;
    Term _fv_158[1];
    _fv_158[0] = 0;
    Term _fv_159[1];
    _fv_159[0] = 1;
    u32 _o_128 = 0;
    Term _o_129 = 0;
    Term _t_76 = 1;
    if (_t_76 == 0) {
      _o_128 = 0;
    } else {
      _o_128 = 1;
      _o_129 = term_pak(CID_UNIT, 0);
    }
    Term _fv_160[2];
    _fv_160[0] = _o_128;
    _fv_160[1] = _o_129;
    u32 _o_130 = 0;
    Term _o_131 = 0;
    Term _t_77 = 0;
    if (_t_77 == 0) {
      _o_130 = 0;
    } else {
      _o_130 = 1;
      _o_131 = term_pak(CID_UNIT, 0);
    }
    Term _fv_161[2];
    _fv_161[0] = _o_130;
    _fv_161[1] = _o_131;
    u32 _o_132 = 0;
    Term _o_133 = 0;
    Term _t_78 = 1;
    if (_t_78 == 0) {
      _o_132 = 0;
    } else {
      _o_132 = 1;
      _o_133 = term_pak(CID_UNIT, 0);
    }
    Term _fv_162[2];
    _fv_162[0] = _o_132;
    _fv_162[1] = _o_133;
    u32 _o_134 = 0;
    Term _o_135 = 0;
    Term _t_79 = 0;
    if (_t_79 == 0) {
      _o_134 = 0;
    } else {
      _o_134 = 1;
      _o_135 = term_pak(CID_UNIT, 0);
    }
    Term _fv_163[2];
    _fv_163[0] = _o_134;
    _fv_163[1] = _o_135;
    Term _fv_164[1];
    _fv_164[0] = 100ull;
    Term _fv_165[1];
    _fv_165[0] = 101ull;
    Term _fv_166[1];
    _fv_166[0] = 102ull;
    Term _fv_167[1];
    _fv_167[0] = 103ull;
    Term _fv_168[1];
    _fv_168[0] = 200ull;
    Term _fv_169[1];
    _fv_169[0] = 201ull;
    Term _fv_170[1];
    _fv_170[0] = 202ull;
    Term _fv_171[1];
    _fv_171[0] = 203ull;
    Term _v_442 = 0;
    Term _v_443 = 0;
    Term _v_444 = 0;
    Term _v_445 = 0;
    Term _v_446 = 0;
    Term _v_447 = 0;
    u32 _v_448 = 0;
    Term _v_449 = 0;
    u32 _v_450 = 0;
    Term _v_451 = 0;
    Term _o_136[10];
    Term _a_80 = blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_124), blk_new(e, 1, 0, 1, 2, _fv_125)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_130), blk_new(e, 1, 0, 1, 2, _fv_135)));
    Term _a_81 = blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_140), blk_new(e, 1, 0, 1, 2, _fv_145)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_150), blk_new(e, 1, 0, 1, 2, _fv_155)));
    Term _a_82 = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_156), blk_new(e, 0, 0, 0, 1, _fv_157)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_158), blk_new(e, 0, 0, 0, 1, _fv_159)));
    Term _a_83 = blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_160), blk_new(e, 1, 0, 1, 2, _fv_161)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_162), blk_new(e, 1, 0, 1, 2, _fv_163)));
    Term _a_84 = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_164), blk_new(e, 0, 0, 0, 1, _fv_165)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_166), blk_new(e, 0, 0, 0, 1, _fv_167)));
    Term _a_85 = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_168), blk_new(e, 0, 0, 0, 1, _fv_169)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_170), blk_new(e, 0, 0, 0, 1, _fv_171)));
    Term _a_86 = term_pak(CID_NIL, 0);
    if (spin_19(e, _o_136, ((u64)3ull), 1ull, 4ull, 2ull, 3ull, 0, 7ull, _a_80, blk_loc(e.mem, _a_80), _a_81, blk_loc(e.mem, _a_81), _a_82, blk_loc(e.mem, _a_82), _a_83, blk_loc(e.mem, _a_83), _a_84, blk_loc(e.mem, _a_84), _a_85, blk_loc(e.mem, _a_85), _a_86, blk_loc(e.mem, _a_86)) == 0) {
      return 0;
    }
    _v_442 = _o_136[0];
    _v_443 = _o_136[1];
    _v_444 = _o_136[2];
    _v_445 = _o_136[3];
    _v_446 = _o_136[4];
    _v_447 = _o_136[5];
    _v_448 = _o_136[6];
    _v_449 = _o_136[7];
    _v_450 = _o_136[8];
    _v_451 = _o_136[9];
    _v_432 = _v_442;
    _v_433 = _v_443;
    _v_434 = _v_444;
    _v_435 = _v_445;
    _v_436 = _v_446;
    _v_437 = _v_447;
    _v_438 = _v_448;
    _v_439 = _v_449;
    _v_440 = _v_450;
    _v_441 = _v_451;
    u32 _v_452 = 0;
    u32 _v_453 = 0;
    Term _v_454 = 0;
    Term _v_455 = 0;
    Term _v_456 = 0;
    Term _v_457 = 0;
    Term _v_458 = 0;
    Term _v_459 = 0;
    u32 _v_460 = 0;
    Term _v_461 = 0;
    u32 _v_462 = 0;
    Term _v_463 = 0;
    u32 _v_464 = 0;
    Term _v_465 = 0;
    Term _v_466 = 0;
    Term _v_467 = 0;
    Term _o_137[16];
    Term _a_87 = term_pak(CID_NIL, 0);
    Term _a_88 = term_ctr(CID_OWNED, _nd_48);
    Term _a_89 = 123ull;
    if (spin_21(e, _o_137, 7ull, 999ull, _a_87, blk_loc(e.mem, _a_87), 1, _a_88, blk_loc(e.mem, _a_88), _a_89, blk_loc(e.mem, _a_89), _v_432, blk_loc(e.mem, _v_432), _v_433, blk_loc(e.mem, _v_433), _v_434, blk_loc(e.mem, _v_434), _v_435, blk_loc(e.mem, _v_435), _v_436, blk_loc(e.mem, _v_436), _v_437, blk_loc(e.mem, _v_437), _v_438, _v_439, _v_440, _v_441, blk_loc(e.mem, _v_441)) == 0) {
      return 0;
    }
    _v_452 = _o_137[0];
    _v_453 = _o_137[1];
    _v_454 = _o_137[2];
    _v_455 = _o_137[3];
    _v_456 = _o_137[4];
    _v_457 = _o_137[5];
    _v_458 = _o_137[6];
    _v_459 = _o_137[7];
    _v_460 = _o_137[8];
    _v_461 = _o_137[9];
    _v_462 = _o_137[10];
    _v_463 = _o_137[11];
    _v_464 = _o_137[12];
    _v_465 = _o_137[13];
    _v_466 = _o_137[14];
    _v_467 = _o_137[15];
    _v_416 = _v_452;
    _v_417 = _v_453;
    _v_418 = _v_454;
    _v_419 = _v_455;
    _v_420 = _v_456;
    _v_421 = _v_457;
    _v_422 = _v_458;
    _v_423 = _v_459;
    _v_424 = _v_460;
    _v_425 = _v_461;
    _v_426 = _v_462;
    _v_427 = _v_463;
    _v_428 = _v_464;
    _v_429 = _v_465;
    _v_430 = _v_466;
    _v_431 = _v_467;
    u32 _o_138 = 0;
    Term _o_139 = 0;
    u32 _o_140 = 0;
    if (_v_428 == 0) {
      _o_138 = 0;
    } else {
      _o_138 = 1;
      Term _fb_8[2];
      u64 _sp_8 = ctr_take(e, _v_429, 2, _fb_8);
      Term _f_16 = _fb_8[0];
      u32 _f_17 = _fb_8[1];
      spare_free(e, cls_fit(2), _sp_8);
      _o_139 = _f_16;
      _o_140 = _f_17;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K243;
      WL_PUSHN(1);
    } else {
      u64 _t_80 = task_node(e, FID_MAIN_K243, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K243, _t_80);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_81 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_81 + 0] = _v_416;
      e.mem[_t_81 + 1] = _v_417;
      e.mem[_t_81 + 2] = _v_418;
      e.mem[_t_81 + 3] = _v_419;
      e.mem[_t_81 + 4] = _v_420;
      e.mem[_t_81 + 5] = _v_421;
      e.mem[_t_81 + 6] = _v_422;
      e.mem[_t_81 + 7] = _v_423;
      e.mem[_t_81 + 8] = _v_424;
      e.mem[_t_81 + 9] = _v_425;
      e.mem[_t_81 + 10] = _v_426;
      e.mem[_t_81 + 11] = _v_427;
      e.mem[_t_81 + 12] = _o_138;
      e.mem[_t_81 + 13] = _o_139;
      e.mem[_t_81 + 14] = _o_140;
      e.mem[_t_81 + 15] = _v_430;
      e.mem[_t_81 + 16] = _v_431;
      return term_tsk(FID_SNAPSHOT, _t_81);
    }
    r0 = _v_416;
    r1 = _v_417;
    r2 = _v_418;
    r3 = _v_419;
    r4 = _v_420;
    r5 = _v_421;
    r6 = _v_422;
    r7 = _v_423;
    r8 = _v_424;
    r9 = _v_425;
    r10 = _v_426;
    r11 = _v_427;
    r12 = _o_138;
    r13 = _o_139;
    r14 = _o_140;
    r15 = _v_430;
    r16 = _v_431;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K243)
  {
    Term _h_24 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K244;
      WL_PUSHN(1);
    } else {
      u64 _t_82 = task_node(e, FID_MAIN_K244, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K244, _t_82);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_83 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_83 + 0] = term_ctr(CID_SCON, STAT_OFF + 160);
      e.mem[_t_83 + 1] = _h_24;
      return term_tsk(FID_STRING_APPEND, _t_83);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 160);
    r1 = _h_24;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K244)
  {
    Term _h_25 = r0;
    WL_OPEN
    u64 _nd_57 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_57 + 0] = _h_25;
    r0 = term_clo(FID_MAIN_C245, _nd_57);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C245)
  {
    Term _h_26 = r0;
    Term _x_16 = r1;
    WL_OPEN
    u64 _nd_58 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_58 + 0] = _h_26;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_464 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_464 + 0] = term_clo(FID_IO_PRINT, _nd_58);
      e.mem[_t_464 + 1] = term_clo(FID_MAIN_C246, 0);
      e.mem[_t_464 + 2] = _x_16;
      return term_tsk(FID_IO_BIND, _t_464);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_58);
    r1 = term_clo(FID_MAIN_C246, 0);
    r2 = _x_16;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C246)
  {
    Term _x_17 = r0;
    WL_OPEN
    u32 _v_468 = 0;
    u32 _v_469 = 0;
    Term _v_470 = 0;
    Term _v_471 = 0;
    Term _v_472 = 0;
    Term _v_473 = 0;
    Term _v_474 = 0;
    Term _v_475 = 0;
    u32 _v_476 = 0;
    Term _v_477 = 0;
    u32 _v_478 = 0;
    Term _v_479 = 0;
    u32 _v_480 = 0;
    Term _v_481 = 0;
    Term _v_482 = 0;
    Term _v_483 = 0;
    Term _fv_172[1];
    _fv_172[0] = 999000ull;
    Term _fv_173[1];
    _fv_173[0] = 999001ull;
    Term _fv_174[1];
    _fv_174[0] = 999002ull;
    Term _fv_175[1];
    _fv_175[0] = 999003ull;
    u64 _nd_59 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_59 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_172), blk_new(e, 0, 0, 0, 1, _fv_173)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_174), blk_new(e, 0, 0, 0, 1, _fv_175))));
    e.mem[_nd_59 + 1] = rfc_seal(e, 999ull);
    Term _v_484 = 0;
    Term _v_485 = 0;
    Term _v_486 = 0;
    Term _v_487 = 0;
    Term _v_488 = 0;
    Term _v_489 = 0;
    u32 _v_490 = 0;
    Term _v_491 = 0;
    u32 _v_492 = 0;
    Term _v_493 = 0;
    Term _fv_176[1];
    _fv_176[0] = 1000ull;
    Term _fv_177[1];
    _fv_177[0] = 1001ull;
    Term _fv_178[1];
    _fv_178[0] = 1002ull;
    Term _fv_179[1];
    _fv_179[0] = 1003ull;
    u32 _o_141 = 0;
    Term _o_142 = 0;
    Term _t_84 = 1;
    if (_t_84 == 0) {
      _o_141 = 0;
    } else {
      _o_141 = 1;
      u64 _nd_60 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_60 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_176), blk_new(e, 0, 0, 0, 1, _fv_177)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_178), blk_new(e, 0, 0, 0, 1, _fv_179))));
      e.mem[_nd_60 + 1] = rfc_seal(e, 1ull);
      _o_142 = term_ctr(CID_OWNED, _nd_60);
    }
    Term _fv_180[2];
    _fv_180[0] = _o_141;
    _fv_180[1] = _o_142;
    u32 _o_143 = 0;
    Term _o_144 = 0;
    Term _t_85 = 0;
    if (_t_85 == 0) {
      _o_143 = 0;
    } else {
      _o_143 = 1;
      u64 _nd_61 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_61 + 0] = rfc_seal(e, 0);
      e.mem[_nd_61 + 1] = rfc_seal(e, 0);
      _o_144 = term_ctr(CID_OWNED, _nd_61);
    }
    Term _fv_181[2];
    _fv_181[0] = _o_143;
    _fv_181[1] = _o_144;
    Term _fv_182[1];
    _fv_182[0] = 3000ull;
    Term _fv_183[1];
    _fv_183[0] = 3001ull;
    Term _fv_184[1];
    _fv_184[0] = 3002ull;
    Term _fv_185[1];
    _fv_185[0] = 3003ull;
    u32 _o_145 = 0;
    Term _o_146 = 0;
    Term _t_86 = 1;
    if (_t_86 == 0) {
      _o_145 = 0;
    } else {
      _o_145 = 1;
      u64 _nd_62 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_62 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_182), blk_new(e, 0, 0, 0, 1, _fv_183)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_184), blk_new(e, 0, 0, 0, 1, _fv_185))));
      e.mem[_nd_62 + 1] = rfc_seal(e, 3ull);
      _o_146 = term_ctr(CID_OWNED, _nd_62);
    }
    Term _fv_186[2];
    _fv_186[0] = _o_145;
    _fv_186[1] = _o_146;
    Term _fv_187[1];
    _fv_187[0] = 4000ull;
    Term _fv_188[1];
    _fv_188[0] = 4001ull;
    Term _fv_189[1];
    _fv_189[0] = 4002ull;
    Term _fv_190[1];
    _fv_190[0] = 4003ull;
    u32 _o_147 = 0;
    Term _o_148 = 0;
    Term _t_87 = 1;
    if (_t_87 == 0) {
      _o_147 = 0;
    } else {
      _o_147 = 1;
      u64 _nd_63 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_63 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_187), blk_new(e, 0, 0, 0, 1, _fv_188)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_189), blk_new(e, 0, 0, 0, 1, _fv_190))));
      e.mem[_nd_63 + 1] = rfc_seal(e, 4ull);
      _o_148 = term_ctr(CID_OWNED, _nd_63);
    }
    Term _fv_191[2];
    _fv_191[0] = _o_147;
    _fv_191[1] = _o_148;
    Term _fv_192[1];
    _fv_192[0] = 101000ull;
    Term _fv_193[1];
    _fv_193[0] = 101001ull;
    Term _fv_194[1];
    _fv_194[0] = 101002ull;
    Term _fv_195[1];
    _fv_195[0] = 101003ull;
    u32 _o_149 = 0;
    Term _o_150 = 0;
    Term _t_88 = 1;
    if (_t_88 == 0) {
      _o_149 = 0;
    } else {
      _o_149 = 1;
      u64 _nd_64 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_64 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_192), blk_new(e, 0, 0, 0, 1, _fv_193)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_194), blk_new(e, 0, 0, 0, 1, _fv_195))));
      e.mem[_nd_64 + 1] = rfc_seal(e, 101ull);
      _o_150 = term_ctr(CID_OWNED, _nd_64);
    }
    Term _fv_196[2];
    _fv_196[0] = _o_149;
    _fv_196[1] = _o_150;
    Term _fv_197[1];
    _fv_197[0] = 102000ull;
    Term _fv_198[1];
    _fv_198[0] = 102001ull;
    Term _fv_199[1];
    _fv_199[0] = 102002ull;
    Term _fv_200[1];
    _fv_200[0] = 102003ull;
    u32 _o_151 = 0;
    Term _o_152 = 0;
    Term _t_89 = 1;
    if (_t_89 == 0) {
      _o_151 = 0;
    } else {
      _o_151 = 1;
      u64 _nd_65 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_65 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_197), blk_new(e, 0, 0, 0, 1, _fv_198)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_199), blk_new(e, 0, 0, 0, 1, _fv_200))));
      e.mem[_nd_65 + 1] = rfc_seal(e, 102ull);
      _o_152 = term_ctr(CID_OWNED, _nd_65);
    }
    Term _fv_201[2];
    _fv_201[0] = _o_151;
    _fv_201[1] = _o_152;
    Term _fv_202[1];
    _fv_202[0] = 103000ull;
    Term _fv_203[1];
    _fv_203[0] = 103001ull;
    Term _fv_204[1];
    _fv_204[0] = 103002ull;
    Term _fv_205[1];
    _fv_205[0] = 103003ull;
    u32 _o_153 = 0;
    Term _o_154 = 0;
    Term _t_90 = 1;
    if (_t_90 == 0) {
      _o_153 = 0;
    } else {
      _o_153 = 1;
      u64 _nd_66 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_66 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_202), blk_new(e, 0, 0, 0, 1, _fv_203)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_204), blk_new(e, 0, 0, 0, 1, _fv_205))));
      e.mem[_nd_66 + 1] = rfc_seal(e, 103ull);
      _o_154 = term_ctr(CID_OWNED, _nd_66);
    }
    Term _fv_206[2];
    _fv_206[0] = _o_153;
    _fv_206[1] = _o_154;
    Term _fv_207[1];
    _fv_207[0] = 104000ull;
    Term _fv_208[1];
    _fv_208[0] = 104001ull;
    Term _fv_209[1];
    _fv_209[0] = 104002ull;
    Term _fv_210[1];
    _fv_210[0] = 104003ull;
    u32 _o_155 = 0;
    Term _o_156 = 0;
    Term _t_91 = 1;
    if (_t_91 == 0) {
      _o_155 = 0;
    } else {
      _o_155 = 1;
      u64 _nd_67 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_67 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_207), blk_new(e, 0, 0, 0, 1, _fv_208)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_209), blk_new(e, 0, 0, 0, 1, _fv_210))));
      e.mem[_nd_67 + 1] = rfc_seal(e, 104ull);
      _o_156 = term_ctr(CID_OWNED, _nd_67);
    }
    Term _fv_211[2];
    _fv_211[0] = _o_155;
    _fv_211[1] = _o_156;
    Term _fv_212[1];
    _fv_212[0] = 1;
    Term _fv_213[1];
    _fv_213[0] = 1;
    Term _fv_214[1];
    _fv_214[0] = 0;
    Term _fv_215[1];
    _fv_215[0] = 1;
    u32 _o_157 = 0;
    Term _o_158 = 0;
    Term _t_92 = 1;
    if (_t_92 == 0) {
      _o_157 = 0;
    } else {
      _o_157 = 1;
      _o_158 = term_pak(CID_UNIT, 0);
    }
    Term _fv_216[2];
    _fv_216[0] = _o_157;
    _fv_216[1] = _o_158;
    u32 _o_159 = 0;
    Term _o_160 = 0;
    Term _t_93 = 0;
    if (_t_93 == 0) {
      _o_159 = 0;
    } else {
      _o_159 = 1;
      _o_160 = term_pak(CID_UNIT, 0);
    }
    Term _fv_217[2];
    _fv_217[0] = _o_159;
    _fv_217[1] = _o_160;
    u32 _o_161 = 0;
    Term _o_162 = 0;
    Term _t_94 = 1;
    if (_t_94 == 0) {
      _o_161 = 0;
    } else {
      _o_161 = 1;
      _o_162 = term_pak(CID_UNIT, 0);
    }
    Term _fv_218[2];
    _fv_218[0] = _o_161;
    _fv_218[1] = _o_162;
    u32 _o_163 = 0;
    Term _o_164 = 0;
    Term _t_95 = 0;
    if (_t_95 == 0) {
      _o_163 = 0;
    } else {
      _o_163 = 1;
      _o_164 = term_pak(CID_UNIT, 0);
    }
    Term _fv_219[2];
    _fv_219[0] = _o_163;
    _fv_219[1] = _o_164;
    Term _fv_220[1];
    _fv_220[0] = 100ull;
    Term _fv_221[1];
    _fv_221[0] = 101ull;
    Term _fv_222[1];
    _fv_222[0] = 102ull;
    Term _fv_223[1];
    _fv_223[0] = 103ull;
    Term _fv_224[1];
    _fv_224[0] = 200ull;
    Term _fv_225[1];
    _fv_225[0] = 201ull;
    Term _fv_226[1];
    _fv_226[0] = 202ull;
    Term _fv_227[1];
    _fv_227[0] = 203ull;
    Term _v_494 = 0;
    Term _v_495 = 0;
    Term _v_496 = 0;
    Term _v_497 = 0;
    Term _v_498 = 0;
    Term _v_499 = 0;
    u32 _v_500 = 0;
    Term _v_501 = 0;
    u32 _v_502 = 0;
    Term _v_503 = 0;
    Term _o_165[10];
    Term _a_90 = blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_180), blk_new(e, 1, 0, 1, 2, _fv_181)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_186), blk_new(e, 1, 0, 1, 2, _fv_191)));
    Term _a_91 = blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_196), blk_new(e, 1, 0, 1, 2, _fv_201)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_206), blk_new(e, 1, 0, 1, 2, _fv_211)));
    Term _a_92 = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_212), blk_new(e, 0, 0, 0, 1, _fv_213)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_214), blk_new(e, 0, 0, 0, 1, _fv_215)));
    Term _a_93 = blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_216), blk_new(e, 1, 0, 1, 2, _fv_217)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_218), blk_new(e, 1, 0, 1, 2, _fv_219)));
    Term _a_94 = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_220), blk_new(e, 0, 0, 0, 1, _fv_221)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_222), blk_new(e, 0, 0, 0, 1, _fv_223)));
    Term _a_95 = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_224), blk_new(e, 0, 0, 0, 1, _fv_225)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_226), blk_new(e, 0, 0, 0, 1, _fv_227)));
    Term _a_96 = term_pak(CID_NIL, 0);
    if (spin_19(e, _o_165, ((u64)3ull), 1ull, 4ull, 2ull, 3ull, 1, 7ull, _a_90, blk_loc(e.mem, _a_90), _a_91, blk_loc(e.mem, _a_91), _a_92, blk_loc(e.mem, _a_92), _a_93, blk_loc(e.mem, _a_93), _a_94, blk_loc(e.mem, _a_94), _a_95, blk_loc(e.mem, _a_95), _a_96, blk_loc(e.mem, _a_96)) == 0) {
      return 0;
    }
    _v_494 = _o_165[0];
    _v_495 = _o_165[1];
    _v_496 = _o_165[2];
    _v_497 = _o_165[3];
    _v_498 = _o_165[4];
    _v_499 = _o_165[5];
    _v_500 = _o_165[6];
    _v_501 = _o_165[7];
    _v_502 = _o_165[8];
    _v_503 = _o_165[9];
    _v_484 = _v_494;
    _v_485 = _v_495;
    _v_486 = _v_496;
    _v_487 = _v_497;
    _v_488 = _v_498;
    _v_489 = _v_499;
    _v_490 = _v_500;
    _v_491 = _v_501;
    _v_492 = _v_502;
    _v_493 = _v_503;
    u32 _v_504 = 0;
    u32 _v_505 = 0;
    Term _v_506 = 0;
    Term _v_507 = 0;
    Term _v_508 = 0;
    Term _v_509 = 0;
    Term _v_510 = 0;
    Term _v_511 = 0;
    u32 _v_512 = 0;
    Term _v_513 = 0;
    u32 _v_514 = 0;
    Term _v_515 = 0;
    u32 _v_516 = 0;
    Term _v_517 = 0;
    Term _v_518 = 0;
    Term _v_519 = 0;
    Term _o_166[16];
    Term _a_97 = term_pak(CID_NIL, 0);
    Term _a_98 = term_ctr(CID_OWNED, _nd_59);
    Term _a_99 = 123ull;
    if (spin_21(e, _o_166, 7ull, 999ull, _a_97, blk_loc(e.mem, _a_97), 1, _a_98, blk_loc(e.mem, _a_98), _a_99, blk_loc(e.mem, _a_99), _v_484, blk_loc(e.mem, _v_484), _v_485, blk_loc(e.mem, _v_485), _v_486, blk_loc(e.mem, _v_486), _v_487, blk_loc(e.mem, _v_487), _v_488, blk_loc(e.mem, _v_488), _v_489, blk_loc(e.mem, _v_489), _v_490, _v_491, _v_492, _v_493, blk_loc(e.mem, _v_493)) == 0) {
      return 0;
    }
    _v_504 = _o_166[0];
    _v_505 = _o_166[1];
    _v_506 = _o_166[2];
    _v_507 = _o_166[3];
    _v_508 = _o_166[4];
    _v_509 = _o_166[5];
    _v_510 = _o_166[6];
    _v_511 = _o_166[7];
    _v_512 = _o_166[8];
    _v_513 = _o_166[9];
    _v_514 = _o_166[10];
    _v_515 = _o_166[11];
    _v_516 = _o_166[12];
    _v_517 = _o_166[13];
    _v_518 = _o_166[14];
    _v_519 = _o_166[15];
    _v_468 = _v_504;
    _v_469 = _v_505;
    _v_470 = _v_506;
    _v_471 = _v_507;
    _v_472 = _v_508;
    _v_473 = _v_509;
    _v_474 = _v_510;
    _v_475 = _v_511;
    _v_476 = _v_512;
    _v_477 = _v_513;
    _v_478 = _v_514;
    _v_479 = _v_515;
    _v_480 = _v_516;
    _v_481 = _v_517;
    _v_482 = _v_518;
    _v_483 = _v_519;
    u32 _o_167 = 0;
    Term _o_168 = 0;
    u32 _o_169 = 0;
    if (_v_480 == 0) {
      _o_167 = 0;
    } else {
      _o_167 = 1;
      Term _fb_9[2];
      u64 _sp_9 = ctr_take(e, _v_481, 2, _fb_9);
      Term _f_18 = _fb_9[0];
      u32 _f_19 = _fb_9[1];
      spare_free(e, cls_fit(2), _sp_9);
      _o_168 = _f_18;
      _o_169 = _f_19;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K247;
      WL_PUSHN(1);
    } else {
      u64 _t_96 = task_node(e, FID_MAIN_K247, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K247, _t_96);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_97 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_97 + 0] = _v_468;
      e.mem[_t_97 + 1] = _v_469;
      e.mem[_t_97 + 2] = _v_470;
      e.mem[_t_97 + 3] = _v_471;
      e.mem[_t_97 + 4] = _v_472;
      e.mem[_t_97 + 5] = _v_473;
      e.mem[_t_97 + 6] = _v_474;
      e.mem[_t_97 + 7] = _v_475;
      e.mem[_t_97 + 8] = _v_476;
      e.mem[_t_97 + 9] = _v_477;
      e.mem[_t_97 + 10] = _v_478;
      e.mem[_t_97 + 11] = _v_479;
      e.mem[_t_97 + 12] = _o_167;
      e.mem[_t_97 + 13] = _o_168;
      e.mem[_t_97 + 14] = _o_169;
      e.mem[_t_97 + 15] = _v_482;
      e.mem[_t_97 + 16] = _v_483;
      return term_tsk(FID_SNAPSHOT, _t_97);
    }
    r0 = _v_468;
    r1 = _v_469;
    r2 = _v_470;
    r3 = _v_471;
    r4 = _v_472;
    r5 = _v_473;
    r6 = _v_474;
    r7 = _v_475;
    r8 = _v_476;
    r9 = _v_477;
    r10 = _v_478;
    r11 = _v_479;
    r12 = _o_167;
    r13 = _o_168;
    r14 = _o_169;
    r15 = _v_482;
    r16 = _v_483;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K247)
  {
    Term _h_27 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K248;
      WL_PUSHN(1);
    } else {
      u64 _t_98 = task_node(e, FID_MAIN_K248, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K248, _t_98);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_99 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_99 + 0] = term_ctr(CID_SCON, STAT_OFF + 164);
      e.mem[_t_99 + 1] = _h_27;
      return term_tsk(FID_STRING_APPEND, _t_99);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 164);
    r1 = _h_27;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K248)
  {
    Term _h_28 = r0;
    WL_OPEN
    u64 _nd_68 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_68 + 0] = _h_28;
    r0 = term_clo(FID_MAIN_C249, _nd_68);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C249)
  {
    Term _h_29 = r0;
    Term _x_18 = r1;
    WL_OPEN
    u64 _nd_69 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_69 + 0] = _h_29;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_463 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_463 + 0] = term_clo(FID_IO_PRINT, _nd_69);
      e.mem[_t_463 + 1] = term_clo(FID_MAIN_C250, 0);
      e.mem[_t_463 + 2] = _x_18;
      return term_tsk(FID_IO_BIND, _t_463);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_69);
    r1 = term_clo(FID_MAIN_C250, 0);
    r2 = _x_18;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C250)
  {
    Term _x_19 = r0;
    WL_OPEN
    u32 _v_520 = 0;
    u32 _v_521 = 0;
    Term _v_522 = 0;
    Term _v_523 = 0;
    Term _v_524 = 0;
    Term _v_525 = 0;
    Term _v_526 = 0;
    Term _v_527 = 0;
    u32 _v_528 = 0;
    Term _v_529 = 0;
    u32 _v_530 = 0;
    Term _v_531 = 0;
    u32 _v_532 = 0;
    Term _v_533 = 0;
    Term _v_534 = 0;
    Term _v_535 = 0;
    Term _fv_228[1];
    _fv_228[0] = 999000ull;
    Term _fv_229[1];
    _fv_229[0] = 999001ull;
    Term _fv_230[1];
    _fv_230[0] = 999002ull;
    Term _fv_231[1];
    _fv_231[0] = 999003ull;
    u64 _nd_70 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_70 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_228), blk_new(e, 0, 0, 0, 1, _fv_229)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_230), blk_new(e, 0, 0, 0, 1, _fv_231))));
    e.mem[_nd_70 + 1] = rfc_seal(e, 999ull);
    Term _v_536 = 0;
    Term _v_537 = 0;
    Term _v_538 = 0;
    Term _v_539 = 0;
    Term _v_540 = 0;
    Term _v_541 = 0;
    u32 _v_542 = 0;
    Term _v_543 = 0;
    u32 _v_544 = 0;
    Term _v_545 = 0;
    Term _fv_232[1];
    _fv_232[0] = 1000ull;
    Term _fv_233[1];
    _fv_233[0] = 1001ull;
    Term _fv_234[1];
    _fv_234[0] = 1002ull;
    Term _fv_235[1];
    _fv_235[0] = 1003ull;
    u32 _o_170 = 0;
    Term _o_171 = 0;
    Term _t_100 = 1;
    if (_t_100 == 0) {
      _o_170 = 0;
    } else {
      _o_170 = 1;
      u64 _nd_71 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_71 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_232), blk_new(e, 0, 0, 0, 1, _fv_233)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_234), blk_new(e, 0, 0, 0, 1, _fv_235))));
      e.mem[_nd_71 + 1] = rfc_seal(e, 1ull);
      _o_171 = term_ctr(CID_OWNED, _nd_71);
    }
    Term _fv_236[2];
    _fv_236[0] = _o_170;
    _fv_236[1] = _o_171;
    u32 _o_172 = 0;
    Term _o_173 = 0;
    Term _t_101 = 0;
    if (_t_101 == 0) {
      _o_172 = 0;
    } else {
      _o_172 = 1;
      u64 _nd_72 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_72 + 0] = rfc_seal(e, 0);
      e.mem[_nd_72 + 1] = rfc_seal(e, 0);
      _o_173 = term_ctr(CID_OWNED, _nd_72);
    }
    Term _fv_237[2];
    _fv_237[0] = _o_172;
    _fv_237[1] = _o_173;
    Term _fv_238[1];
    _fv_238[0] = 3000ull;
    Term _fv_239[1];
    _fv_239[0] = 3001ull;
    Term _fv_240[1];
    _fv_240[0] = 3002ull;
    Term _fv_241[1];
    _fv_241[0] = 3003ull;
    u32 _o_174 = 0;
    Term _o_175 = 0;
    Term _t_102 = 1;
    if (_t_102 == 0) {
      _o_174 = 0;
    } else {
      _o_174 = 1;
      u64 _nd_73 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_73 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_238), blk_new(e, 0, 0, 0, 1, _fv_239)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_240), blk_new(e, 0, 0, 0, 1, _fv_241))));
      e.mem[_nd_73 + 1] = rfc_seal(e, 3ull);
      _o_175 = term_ctr(CID_OWNED, _nd_73);
    }
    Term _fv_242[2];
    _fv_242[0] = _o_174;
    _fv_242[1] = _o_175;
    Term _fv_243[1];
    _fv_243[0] = 4000ull;
    Term _fv_244[1];
    _fv_244[0] = 4001ull;
    Term _fv_245[1];
    _fv_245[0] = 4002ull;
    Term _fv_246[1];
    _fv_246[0] = 4003ull;
    u32 _o_176 = 0;
    Term _o_177 = 0;
    Term _t_103 = 1;
    if (_t_103 == 0) {
      _o_176 = 0;
    } else {
      _o_176 = 1;
      u64 _nd_74 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_74 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_243), blk_new(e, 0, 0, 0, 1, _fv_244)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_245), blk_new(e, 0, 0, 0, 1, _fv_246))));
      e.mem[_nd_74 + 1] = rfc_seal(e, 4ull);
      _o_177 = term_ctr(CID_OWNED, _nd_74);
    }
    Term _fv_247[2];
    _fv_247[0] = _o_176;
    _fv_247[1] = _o_177;
    Term _fv_248[1];
    _fv_248[0] = 101000ull;
    Term _fv_249[1];
    _fv_249[0] = 101001ull;
    Term _fv_250[1];
    _fv_250[0] = 101002ull;
    Term _fv_251[1];
    _fv_251[0] = 101003ull;
    u32 _o_178 = 0;
    Term _o_179 = 0;
    Term _t_104 = 1;
    if (_t_104 == 0) {
      _o_178 = 0;
    } else {
      _o_178 = 1;
      u64 _nd_75 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_75 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_248), blk_new(e, 0, 0, 0, 1, _fv_249)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_250), blk_new(e, 0, 0, 0, 1, _fv_251))));
      e.mem[_nd_75 + 1] = rfc_seal(e, 101ull);
      _o_179 = term_ctr(CID_OWNED, _nd_75);
    }
    Term _fv_252[2];
    _fv_252[0] = _o_178;
    _fv_252[1] = _o_179;
    Term _fv_253[1];
    _fv_253[0] = 102000ull;
    Term _fv_254[1];
    _fv_254[0] = 102001ull;
    Term _fv_255[1];
    _fv_255[0] = 102002ull;
    Term _fv_256[1];
    _fv_256[0] = 102003ull;
    u32 _o_180 = 0;
    Term _o_181 = 0;
    Term _t_105 = 1;
    if (_t_105 == 0) {
      _o_180 = 0;
    } else {
      _o_180 = 1;
      u64 _nd_76 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_76 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_253), blk_new(e, 0, 0, 0, 1, _fv_254)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_255), blk_new(e, 0, 0, 0, 1, _fv_256))));
      e.mem[_nd_76 + 1] = rfc_seal(e, 102ull);
      _o_181 = term_ctr(CID_OWNED, _nd_76);
    }
    Term _fv_257[2];
    _fv_257[0] = _o_180;
    _fv_257[1] = _o_181;
    Term _fv_258[1];
    _fv_258[0] = 103000ull;
    Term _fv_259[1];
    _fv_259[0] = 103001ull;
    Term _fv_260[1];
    _fv_260[0] = 103002ull;
    Term _fv_261[1];
    _fv_261[0] = 103003ull;
    u32 _o_182 = 0;
    Term _o_183 = 0;
    Term _t_106 = 1;
    if (_t_106 == 0) {
      _o_182 = 0;
    } else {
      _o_182 = 1;
      u64 _nd_77 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_77 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_258), blk_new(e, 0, 0, 0, 1, _fv_259)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_260), blk_new(e, 0, 0, 0, 1, _fv_261))));
      e.mem[_nd_77 + 1] = rfc_seal(e, 103ull);
      _o_183 = term_ctr(CID_OWNED, _nd_77);
    }
    Term _fv_262[2];
    _fv_262[0] = _o_182;
    _fv_262[1] = _o_183;
    Term _fv_263[1];
    _fv_263[0] = 104000ull;
    Term _fv_264[1];
    _fv_264[0] = 104001ull;
    Term _fv_265[1];
    _fv_265[0] = 104002ull;
    Term _fv_266[1];
    _fv_266[0] = 104003ull;
    u32 _o_184 = 0;
    Term _o_185 = 0;
    Term _t_107 = 1;
    if (_t_107 == 0) {
      _o_184 = 0;
    } else {
      _o_184 = 1;
      u64 _nd_78 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_78 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_263), blk_new(e, 0, 0, 0, 1, _fv_264)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_265), blk_new(e, 0, 0, 0, 1, _fv_266))));
      e.mem[_nd_78 + 1] = rfc_seal(e, 104ull);
      _o_185 = term_ctr(CID_OWNED, _nd_78);
    }
    Term _fv_267[2];
    _fv_267[0] = _o_184;
    _fv_267[1] = _o_185;
    Term _fv_268[1];
    _fv_268[0] = 1;
    Term _fv_269[1];
    _fv_269[0] = 1;
    Term _fv_270[1];
    _fv_270[0] = 0;
    Term _fv_271[1];
    _fv_271[0] = 1;
    u32 _o_186 = 0;
    Term _o_187 = 0;
    Term _t_108 = 1;
    if (_t_108 == 0) {
      _o_186 = 0;
    } else {
      _o_186 = 1;
      _o_187 = term_pak(CID_UNIT, 0);
    }
    Term _fv_272[2];
    _fv_272[0] = _o_186;
    _fv_272[1] = _o_187;
    u32 _o_188 = 0;
    Term _o_189 = 0;
    Term _t_109 = 0;
    if (_t_109 == 0) {
      _o_188 = 0;
    } else {
      _o_188 = 1;
      _o_189 = term_pak(CID_UNIT, 0);
    }
    Term _fv_273[2];
    _fv_273[0] = _o_188;
    _fv_273[1] = _o_189;
    u32 _o_190 = 0;
    Term _o_191 = 0;
    Term _t_110 = 1;
    if (_t_110 == 0) {
      _o_190 = 0;
    } else {
      _o_190 = 1;
      _o_191 = term_pak(CID_UNIT, 0);
    }
    Term _fv_274[2];
    _fv_274[0] = _o_190;
    _fv_274[1] = _o_191;
    u32 _o_192 = 0;
    Term _o_193 = 0;
    Term _t_111 = 0;
    if (_t_111 == 0) {
      _o_192 = 0;
    } else {
      _o_192 = 1;
      _o_193 = term_pak(CID_UNIT, 0);
    }
    Term _fv_275[2];
    _fv_275[0] = _o_192;
    _fv_275[1] = _o_193;
    Term _fv_276[1];
    _fv_276[0] = 100ull;
    Term _fv_277[1];
    _fv_277[0] = 101ull;
    Term _fv_278[1];
    _fv_278[0] = 102ull;
    Term _fv_279[1];
    _fv_279[0] = 103ull;
    Term _fv_280[1];
    _fv_280[0] = 200ull;
    Term _fv_281[1];
    _fv_281[0] = 201ull;
    Term _fv_282[1];
    _fv_282[0] = 202ull;
    Term _fv_283[1];
    _fv_283[0] = 203ull;
    Term _v_546 = 0;
    Term _v_547 = 0;
    Term _v_548 = 0;
    Term _v_549 = 0;
    Term _v_550 = 0;
    Term _v_551 = 0;
    u32 _v_552 = 0;
    Term _v_553 = 0;
    u32 _v_554 = 0;
    Term _v_555 = 0;
    Term _o_194[10];
    Term _a_100 = blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_236), blk_new(e, 1, 0, 1, 2, _fv_237)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_242), blk_new(e, 1, 0, 1, 2, _fv_247)));
    Term _a_101 = blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_252), blk_new(e, 1, 0, 1, 2, _fv_257)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_262), blk_new(e, 1, 0, 1, 2, _fv_267)));
    Term _a_102 = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_268), blk_new(e, 0, 0, 0, 1, _fv_269)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_270), blk_new(e, 0, 0, 0, 1, _fv_271)));
    Term _a_103 = blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_272), blk_new(e, 1, 0, 1, 2, _fv_273)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_274), blk_new(e, 1, 0, 1, 2, _fv_275)));
    Term _a_104 = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_276), blk_new(e, 0, 0, 0, 1, _fv_277)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_278), blk_new(e, 0, 0, 0, 1, _fv_279)));
    Term _a_105 = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_280), blk_new(e, 0, 0, 0, 1, _fv_281)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_282), blk_new(e, 0, 0, 0, 1, _fv_283)));
    Term _a_106 = term_pak(CID_NIL, 0);
    if (spin_19(e, _o_194, ((u64)3ull), 1ull, 4ull, 2ull, 3ull, 2, 7ull, _a_100, blk_loc(e.mem, _a_100), _a_101, blk_loc(e.mem, _a_101), _a_102, blk_loc(e.mem, _a_102), _a_103, blk_loc(e.mem, _a_103), _a_104, blk_loc(e.mem, _a_104), _a_105, blk_loc(e.mem, _a_105), _a_106, blk_loc(e.mem, _a_106)) == 0) {
      return 0;
    }
    _v_546 = _o_194[0];
    _v_547 = _o_194[1];
    _v_548 = _o_194[2];
    _v_549 = _o_194[3];
    _v_550 = _o_194[4];
    _v_551 = _o_194[5];
    _v_552 = _o_194[6];
    _v_553 = _o_194[7];
    _v_554 = _o_194[8];
    _v_555 = _o_194[9];
    _v_536 = _v_546;
    _v_537 = _v_547;
    _v_538 = _v_548;
    _v_539 = _v_549;
    _v_540 = _v_550;
    _v_541 = _v_551;
    _v_542 = _v_552;
    _v_543 = _v_553;
    _v_544 = _v_554;
    _v_545 = _v_555;
    u32 _v_556 = 0;
    u32 _v_557 = 0;
    Term _v_558 = 0;
    Term _v_559 = 0;
    Term _v_560 = 0;
    Term _v_561 = 0;
    Term _v_562 = 0;
    Term _v_563 = 0;
    u32 _v_564 = 0;
    Term _v_565 = 0;
    u32 _v_566 = 0;
    Term _v_567 = 0;
    u32 _v_568 = 0;
    Term _v_569 = 0;
    Term _v_570 = 0;
    Term _v_571 = 0;
    Term _o_195[16];
    Term _a_107 = term_pak(CID_NIL, 0);
    Term _a_108 = term_ctr(CID_OWNED, _nd_70);
    Term _a_109 = 123ull;
    if (spin_21(e, _o_195, 7ull, 999ull, _a_107, blk_loc(e.mem, _a_107), 1, _a_108, blk_loc(e.mem, _a_108), _a_109, blk_loc(e.mem, _a_109), _v_536, blk_loc(e.mem, _v_536), _v_537, blk_loc(e.mem, _v_537), _v_538, blk_loc(e.mem, _v_538), _v_539, blk_loc(e.mem, _v_539), _v_540, blk_loc(e.mem, _v_540), _v_541, blk_loc(e.mem, _v_541), _v_542, _v_543, _v_544, _v_545, blk_loc(e.mem, _v_545)) == 0) {
      return 0;
    }
    _v_556 = _o_195[0];
    _v_557 = _o_195[1];
    _v_558 = _o_195[2];
    _v_559 = _o_195[3];
    _v_560 = _o_195[4];
    _v_561 = _o_195[5];
    _v_562 = _o_195[6];
    _v_563 = _o_195[7];
    _v_564 = _o_195[8];
    _v_565 = _o_195[9];
    _v_566 = _o_195[10];
    _v_567 = _o_195[11];
    _v_568 = _o_195[12];
    _v_569 = _o_195[13];
    _v_570 = _o_195[14];
    _v_571 = _o_195[15];
    _v_520 = _v_556;
    _v_521 = _v_557;
    _v_522 = _v_558;
    _v_523 = _v_559;
    _v_524 = _v_560;
    _v_525 = _v_561;
    _v_526 = _v_562;
    _v_527 = _v_563;
    _v_528 = _v_564;
    _v_529 = _v_565;
    _v_530 = _v_566;
    _v_531 = _v_567;
    _v_532 = _v_568;
    _v_533 = _v_569;
    _v_534 = _v_570;
    _v_535 = _v_571;
    u32 _o_196 = 0;
    Term _o_197 = 0;
    u32 _o_198 = 0;
    if (_v_532 == 0) {
      _o_196 = 0;
    } else {
      _o_196 = 1;
      Term _fb_10[2];
      u64 _sp_10 = ctr_take(e, _v_533, 2, _fb_10);
      Term _f_20 = _fb_10[0];
      u32 _f_21 = _fb_10[1];
      spare_free(e, cls_fit(2), _sp_10);
      _o_197 = _f_20;
      _o_198 = _f_21;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K251;
      WL_PUSHN(1);
    } else {
      u64 _t_112 = task_node(e, FID_MAIN_K251, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K251, _t_112);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_113 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_113 + 0] = _v_520;
      e.mem[_t_113 + 1] = _v_521;
      e.mem[_t_113 + 2] = _v_522;
      e.mem[_t_113 + 3] = _v_523;
      e.mem[_t_113 + 4] = _v_524;
      e.mem[_t_113 + 5] = _v_525;
      e.mem[_t_113 + 6] = _v_526;
      e.mem[_t_113 + 7] = _v_527;
      e.mem[_t_113 + 8] = _v_528;
      e.mem[_t_113 + 9] = _v_529;
      e.mem[_t_113 + 10] = _v_530;
      e.mem[_t_113 + 11] = _v_531;
      e.mem[_t_113 + 12] = _o_196;
      e.mem[_t_113 + 13] = _o_197;
      e.mem[_t_113 + 14] = _o_198;
      e.mem[_t_113 + 15] = _v_534;
      e.mem[_t_113 + 16] = _v_535;
      return term_tsk(FID_SNAPSHOT, _t_113);
    }
    r0 = _v_520;
    r1 = _v_521;
    r2 = _v_522;
    r3 = _v_523;
    r4 = _v_524;
    r5 = _v_525;
    r6 = _v_526;
    r7 = _v_527;
    r8 = _v_528;
    r9 = _v_529;
    r10 = _v_530;
    r11 = _v_531;
    r12 = _o_196;
    r13 = _o_197;
    r14 = _o_198;
    r15 = _v_534;
    r16 = _v_535;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K251)
  {
    Term _h_30 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K252;
      WL_PUSHN(1);
    } else {
      u64 _t_114 = task_node(e, FID_MAIN_K252, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K252, _t_114);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_115 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_115 + 0] = term_ctr(CID_SCON, STAT_OFF + 168);
      e.mem[_t_115 + 1] = _h_30;
      return term_tsk(FID_STRING_APPEND, _t_115);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 168);
    r1 = _h_30;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K252)
  {
    Term _h_31 = r0;
    WL_OPEN
    u64 _nd_79 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_79 + 0] = _h_31;
    r0 = term_clo(FID_MAIN_C253, _nd_79);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C253)
  {
    Term _h_32 = r0;
    Term _x_20 = r1;
    WL_OPEN
    u64 _nd_80 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_80 + 0] = _h_32;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_462 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_462 + 0] = term_clo(FID_IO_PRINT, _nd_80);
      e.mem[_t_462 + 1] = term_clo(FID_MAIN_C254, 0);
      e.mem[_t_462 + 2] = _x_20;
      return term_tsk(FID_IO_BIND, _t_462);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_80);
    r1 = term_clo(FID_MAIN_C254, 0);
    r2 = _x_20;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C254)
  {
    Term _x_21 = r0;
    WL_OPEN
    u32 _v_572 = 0;
    u32 _v_573 = 0;
    Term _v_574 = 0;
    Term _v_575 = 0;
    Term _v_576 = 0;
    Term _v_577 = 0;
    Term _v_578 = 0;
    Term _v_579 = 0;
    u32 _v_580 = 0;
    Term _v_581 = 0;
    u32 _v_582 = 0;
    Term _v_583 = 0;
    u32 _v_584 = 0;
    Term _v_585 = 0;
    Term _v_586 = 0;
    Term _v_587 = 0;
    Term _fv_284[1];
    _fv_284[0] = 999000ull;
    Term _fv_285[1];
    _fv_285[0] = 999001ull;
    Term _fv_286[1];
    _fv_286[0] = 999002ull;
    Term _fv_287[1];
    _fv_287[0] = 999003ull;
    u64 _nd_81 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_81 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_284), blk_new(e, 0, 0, 0, 1, _fv_285)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_286), blk_new(e, 0, 0, 0, 1, _fv_287))));
    e.mem[_nd_81 + 1] = rfc_seal(e, 999ull);
    Term _v_588 = 0;
    Term _v_589 = 0;
    Term _v_590 = 0;
    Term _v_591 = 0;
    Term _v_592 = 0;
    Term _v_593 = 0;
    u32 _v_594 = 0;
    Term _v_595 = 0;
    u32 _v_596 = 0;
    Term _v_597 = 0;
    Term _fv_288[1];
    _fv_288[0] = 1000ull;
    Term _fv_289[1];
    _fv_289[0] = 1001ull;
    Term _fv_290[1];
    _fv_290[0] = 1002ull;
    Term _fv_291[1];
    _fv_291[0] = 1003ull;
    u32 _o_199 = 0;
    Term _o_200 = 0;
    Term _t_116 = 1;
    if (_t_116 == 0) {
      _o_199 = 0;
    } else {
      _o_199 = 1;
      u64 _nd_82 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_82 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_288), blk_new(e, 0, 0, 0, 1, _fv_289)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_290), blk_new(e, 0, 0, 0, 1, _fv_291))));
      e.mem[_nd_82 + 1] = rfc_seal(e, 1ull);
      _o_200 = term_ctr(CID_OWNED, _nd_82);
    }
    Term _fv_292[2];
    _fv_292[0] = _o_199;
    _fv_292[1] = _o_200;
    u32 _o_201 = 0;
    Term _o_202 = 0;
    Term _t_117 = 0;
    if (_t_117 == 0) {
      _o_201 = 0;
    } else {
      _o_201 = 1;
      u64 _nd_83 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_83 + 0] = rfc_seal(e, 0);
      e.mem[_nd_83 + 1] = rfc_seal(e, 0);
      _o_202 = term_ctr(CID_OWNED, _nd_83);
    }
    Term _fv_293[2];
    _fv_293[0] = _o_201;
    _fv_293[1] = _o_202;
    Term _fv_294[1];
    _fv_294[0] = 3000ull;
    Term _fv_295[1];
    _fv_295[0] = 3001ull;
    Term _fv_296[1];
    _fv_296[0] = 3002ull;
    Term _fv_297[1];
    _fv_297[0] = 3003ull;
    u32 _o_203 = 0;
    Term _o_204 = 0;
    Term _t_118 = 1;
    if (_t_118 == 0) {
      _o_203 = 0;
    } else {
      _o_203 = 1;
      u64 _nd_84 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_84 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_294), blk_new(e, 0, 0, 0, 1, _fv_295)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_296), blk_new(e, 0, 0, 0, 1, _fv_297))));
      e.mem[_nd_84 + 1] = rfc_seal(e, 3ull);
      _o_204 = term_ctr(CID_OWNED, _nd_84);
    }
    Term _fv_298[2];
    _fv_298[0] = _o_203;
    _fv_298[1] = _o_204;
    Term _fv_299[1];
    _fv_299[0] = 4000ull;
    Term _fv_300[1];
    _fv_300[0] = 4001ull;
    Term _fv_301[1];
    _fv_301[0] = 4002ull;
    Term _fv_302[1];
    _fv_302[0] = 4003ull;
    u32 _o_205 = 0;
    Term _o_206 = 0;
    Term _t_119 = 1;
    if (_t_119 == 0) {
      _o_205 = 0;
    } else {
      _o_205 = 1;
      u64 _nd_85 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_85 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_299), blk_new(e, 0, 0, 0, 1, _fv_300)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_301), blk_new(e, 0, 0, 0, 1, _fv_302))));
      e.mem[_nd_85 + 1] = rfc_seal(e, 4ull);
      _o_206 = term_ctr(CID_OWNED, _nd_85);
    }
    Term _fv_303[2];
    _fv_303[0] = _o_205;
    _fv_303[1] = _o_206;
    Term _fv_304[1];
    _fv_304[0] = 101000ull;
    Term _fv_305[1];
    _fv_305[0] = 101001ull;
    Term _fv_306[1];
    _fv_306[0] = 101002ull;
    Term _fv_307[1];
    _fv_307[0] = 101003ull;
    u32 _o_207 = 0;
    Term _o_208 = 0;
    Term _t_120 = 1;
    if (_t_120 == 0) {
      _o_207 = 0;
    } else {
      _o_207 = 1;
      u64 _nd_86 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_86 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_304), blk_new(e, 0, 0, 0, 1, _fv_305)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_306), blk_new(e, 0, 0, 0, 1, _fv_307))));
      e.mem[_nd_86 + 1] = rfc_seal(e, 101ull);
      _o_208 = term_ctr(CID_OWNED, _nd_86);
    }
    Term _fv_308[2];
    _fv_308[0] = _o_207;
    _fv_308[1] = _o_208;
    Term _fv_309[1];
    _fv_309[0] = 102000ull;
    Term _fv_310[1];
    _fv_310[0] = 102001ull;
    Term _fv_311[1];
    _fv_311[0] = 102002ull;
    Term _fv_312[1];
    _fv_312[0] = 102003ull;
    u32 _o_209 = 0;
    Term _o_210 = 0;
    Term _t_121 = 1;
    if (_t_121 == 0) {
      _o_209 = 0;
    } else {
      _o_209 = 1;
      u64 _nd_87 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_87 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_309), blk_new(e, 0, 0, 0, 1, _fv_310)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_311), blk_new(e, 0, 0, 0, 1, _fv_312))));
      e.mem[_nd_87 + 1] = rfc_seal(e, 102ull);
      _o_210 = term_ctr(CID_OWNED, _nd_87);
    }
    Term _fv_313[2];
    _fv_313[0] = _o_209;
    _fv_313[1] = _o_210;
    Term _fv_314[1];
    _fv_314[0] = 103000ull;
    Term _fv_315[1];
    _fv_315[0] = 103001ull;
    Term _fv_316[1];
    _fv_316[0] = 103002ull;
    Term _fv_317[1];
    _fv_317[0] = 103003ull;
    u32 _o_211 = 0;
    Term _o_212 = 0;
    Term _t_122 = 1;
    if (_t_122 == 0) {
      _o_211 = 0;
    } else {
      _o_211 = 1;
      u64 _nd_88 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_88 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_314), blk_new(e, 0, 0, 0, 1, _fv_315)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_316), blk_new(e, 0, 0, 0, 1, _fv_317))));
      e.mem[_nd_88 + 1] = rfc_seal(e, 103ull);
      _o_212 = term_ctr(CID_OWNED, _nd_88);
    }
    Term _fv_318[2];
    _fv_318[0] = _o_211;
    _fv_318[1] = _o_212;
    Term _fv_319[1];
    _fv_319[0] = 104000ull;
    Term _fv_320[1];
    _fv_320[0] = 104001ull;
    Term _fv_321[1];
    _fv_321[0] = 104002ull;
    Term _fv_322[1];
    _fv_322[0] = 104003ull;
    u32 _o_213 = 0;
    Term _o_214 = 0;
    Term _t_123 = 1;
    if (_t_123 == 0) {
      _o_213 = 0;
    } else {
      _o_213 = 1;
      u64 _nd_89 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_89 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_319), blk_new(e, 0, 0, 0, 1, _fv_320)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_321), blk_new(e, 0, 0, 0, 1, _fv_322))));
      e.mem[_nd_89 + 1] = rfc_seal(e, 104ull);
      _o_214 = term_ctr(CID_OWNED, _nd_89);
    }
    Term _fv_323[2];
    _fv_323[0] = _o_213;
    _fv_323[1] = _o_214;
    Term _fv_324[1];
    _fv_324[0] = 1;
    Term _fv_325[1];
    _fv_325[0] = 1;
    Term _fv_326[1];
    _fv_326[0] = 0;
    Term _fv_327[1];
    _fv_327[0] = 1;
    u32 _o_215 = 0;
    Term _o_216 = 0;
    Term _t_124 = 1;
    if (_t_124 == 0) {
      _o_215 = 0;
    } else {
      _o_215 = 1;
      _o_216 = term_pak(CID_UNIT, 0);
    }
    Term _fv_328[2];
    _fv_328[0] = _o_215;
    _fv_328[1] = _o_216;
    u32 _o_217 = 0;
    Term _o_218 = 0;
    Term _t_125 = 0;
    if (_t_125 == 0) {
      _o_217 = 0;
    } else {
      _o_217 = 1;
      _o_218 = term_pak(CID_UNIT, 0);
    }
    Term _fv_329[2];
    _fv_329[0] = _o_217;
    _fv_329[1] = _o_218;
    u32 _o_219 = 0;
    Term _o_220 = 0;
    Term _t_126 = 1;
    if (_t_126 == 0) {
      _o_219 = 0;
    } else {
      _o_219 = 1;
      _o_220 = term_pak(CID_UNIT, 0);
    }
    Term _fv_330[2];
    _fv_330[0] = _o_219;
    _fv_330[1] = _o_220;
    u32 _o_221 = 0;
    Term _o_222 = 0;
    Term _t_127 = 0;
    if (_t_127 == 0) {
      _o_221 = 0;
    } else {
      _o_221 = 1;
      _o_222 = term_pak(CID_UNIT, 0);
    }
    Term _fv_331[2];
    _fv_331[0] = _o_221;
    _fv_331[1] = _o_222;
    Term _fv_332[1];
    _fv_332[0] = 100ull;
    Term _fv_333[1];
    _fv_333[0] = 101ull;
    Term _fv_334[1];
    _fv_334[0] = 102ull;
    Term _fv_335[1];
    _fv_335[0] = 103ull;
    Term _fv_336[1];
    _fv_336[0] = 200ull;
    Term _fv_337[1];
    _fv_337[0] = 201ull;
    Term _fv_338[1];
    _fv_338[0] = 202ull;
    Term _fv_339[1];
    _fv_339[0] = 203ull;
    Term _v_598 = 0;
    Term _v_599 = 0;
    Term _v_600 = 0;
    Term _v_601 = 0;
    Term _v_602 = 0;
    Term _v_603 = 0;
    u32 _v_604 = 0;
    Term _v_605 = 0;
    u32 _v_606 = 0;
    Term _v_607 = 0;
    Term _o_223[10];
    Term _a_110 = blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_292), blk_new(e, 1, 0, 1, 2, _fv_293)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_298), blk_new(e, 1, 0, 1, 2, _fv_303)));
    Term _a_111 = blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_308), blk_new(e, 1, 0, 1, 2, _fv_313)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_318), blk_new(e, 1, 0, 1, 2, _fv_323)));
    Term _a_112 = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_324), blk_new(e, 0, 0, 0, 1, _fv_325)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_326), blk_new(e, 0, 0, 0, 1, _fv_327)));
    Term _a_113 = blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_328), blk_new(e, 1, 0, 1, 2, _fv_329)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_330), blk_new(e, 1, 0, 1, 2, _fv_331)));
    Term _a_114 = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_332), blk_new(e, 0, 0, 0, 1, _fv_333)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_334), blk_new(e, 0, 0, 0, 1, _fv_335)));
    Term _a_115 = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_336), blk_new(e, 0, 0, 0, 1, _fv_337)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_338), blk_new(e, 0, 0, 0, 1, _fv_339)));
    Term _a_116 = term_pak(CID_NIL, 0);
    if (spin_19(e, _o_223, ((u64)3ull), 1ull, 4ull, 2ull, 3ull, 3, 7ull, _a_110, blk_loc(e.mem, _a_110), _a_111, blk_loc(e.mem, _a_111), _a_112, blk_loc(e.mem, _a_112), _a_113, blk_loc(e.mem, _a_113), _a_114, blk_loc(e.mem, _a_114), _a_115, blk_loc(e.mem, _a_115), _a_116, blk_loc(e.mem, _a_116)) == 0) {
      return 0;
    }
    _v_598 = _o_223[0];
    _v_599 = _o_223[1];
    _v_600 = _o_223[2];
    _v_601 = _o_223[3];
    _v_602 = _o_223[4];
    _v_603 = _o_223[5];
    _v_604 = _o_223[6];
    _v_605 = _o_223[7];
    _v_606 = _o_223[8];
    _v_607 = _o_223[9];
    _v_588 = _v_598;
    _v_589 = _v_599;
    _v_590 = _v_600;
    _v_591 = _v_601;
    _v_592 = _v_602;
    _v_593 = _v_603;
    _v_594 = _v_604;
    _v_595 = _v_605;
    _v_596 = _v_606;
    _v_597 = _v_607;
    u32 _v_608 = 0;
    u32 _v_609 = 0;
    Term _v_610 = 0;
    Term _v_611 = 0;
    Term _v_612 = 0;
    Term _v_613 = 0;
    Term _v_614 = 0;
    Term _v_615 = 0;
    u32 _v_616 = 0;
    Term _v_617 = 0;
    u32 _v_618 = 0;
    Term _v_619 = 0;
    u32 _v_620 = 0;
    Term _v_621 = 0;
    Term _v_622 = 0;
    Term _v_623 = 0;
    Term _o_224[16];
    Term _a_117 = term_pak(CID_NIL, 0);
    Term _a_118 = term_ctr(CID_OWNED, _nd_81);
    Term _a_119 = 123ull;
    if (spin_21(e, _o_224, 7ull, 999ull, _a_117, blk_loc(e.mem, _a_117), 1, _a_118, blk_loc(e.mem, _a_118), _a_119, blk_loc(e.mem, _a_119), _v_588, blk_loc(e.mem, _v_588), _v_589, blk_loc(e.mem, _v_589), _v_590, blk_loc(e.mem, _v_590), _v_591, blk_loc(e.mem, _v_591), _v_592, blk_loc(e.mem, _v_592), _v_593, blk_loc(e.mem, _v_593), _v_594, _v_595, _v_596, _v_597, blk_loc(e.mem, _v_597)) == 0) {
      return 0;
    }
    _v_608 = _o_224[0];
    _v_609 = _o_224[1];
    _v_610 = _o_224[2];
    _v_611 = _o_224[3];
    _v_612 = _o_224[4];
    _v_613 = _o_224[5];
    _v_614 = _o_224[6];
    _v_615 = _o_224[7];
    _v_616 = _o_224[8];
    _v_617 = _o_224[9];
    _v_618 = _o_224[10];
    _v_619 = _o_224[11];
    _v_620 = _o_224[12];
    _v_621 = _o_224[13];
    _v_622 = _o_224[14];
    _v_623 = _o_224[15];
    _v_572 = _v_608;
    _v_573 = _v_609;
    _v_574 = _v_610;
    _v_575 = _v_611;
    _v_576 = _v_612;
    _v_577 = _v_613;
    _v_578 = _v_614;
    _v_579 = _v_615;
    _v_580 = _v_616;
    _v_581 = _v_617;
    _v_582 = _v_618;
    _v_583 = _v_619;
    _v_584 = _v_620;
    _v_585 = _v_621;
    _v_586 = _v_622;
    _v_587 = _v_623;
    u32 _o_225 = 0;
    Term _o_226 = 0;
    u32 _o_227 = 0;
    if (_v_584 == 0) {
      _o_225 = 0;
    } else {
      _o_225 = 1;
      Term _fb_11[2];
      u64 _sp_11 = ctr_take(e, _v_585, 2, _fb_11);
      Term _f_22 = _fb_11[0];
      u32 _f_23 = _fb_11[1];
      spare_free(e, cls_fit(2), _sp_11);
      _o_226 = _f_22;
      _o_227 = _f_23;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K255;
      WL_PUSHN(1);
    } else {
      u64 _t_128 = task_node(e, FID_MAIN_K255, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K255, _t_128);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_129 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_129 + 0] = _v_572;
      e.mem[_t_129 + 1] = _v_573;
      e.mem[_t_129 + 2] = _v_574;
      e.mem[_t_129 + 3] = _v_575;
      e.mem[_t_129 + 4] = _v_576;
      e.mem[_t_129 + 5] = _v_577;
      e.mem[_t_129 + 6] = _v_578;
      e.mem[_t_129 + 7] = _v_579;
      e.mem[_t_129 + 8] = _v_580;
      e.mem[_t_129 + 9] = _v_581;
      e.mem[_t_129 + 10] = _v_582;
      e.mem[_t_129 + 11] = _v_583;
      e.mem[_t_129 + 12] = _o_225;
      e.mem[_t_129 + 13] = _o_226;
      e.mem[_t_129 + 14] = _o_227;
      e.mem[_t_129 + 15] = _v_586;
      e.mem[_t_129 + 16] = _v_587;
      return term_tsk(FID_SNAPSHOT, _t_129);
    }
    r0 = _v_572;
    r1 = _v_573;
    r2 = _v_574;
    r3 = _v_575;
    r4 = _v_576;
    r5 = _v_577;
    r6 = _v_578;
    r7 = _v_579;
    r8 = _v_580;
    r9 = _v_581;
    r10 = _v_582;
    r11 = _v_583;
    r12 = _o_225;
    r13 = _o_226;
    r14 = _o_227;
    r15 = _v_586;
    r16 = _v_587;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K255)
  {
    Term _h_33 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K256;
      WL_PUSHN(1);
    } else {
      u64 _t_130 = task_node(e, FID_MAIN_K256, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K256, _t_130);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_131 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_131 + 0] = term_ctr(CID_SCON, STAT_OFF + 172);
      e.mem[_t_131 + 1] = _h_33;
      return term_tsk(FID_STRING_APPEND, _t_131);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 172);
    r1 = _h_33;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K256)
  {
    Term _h_34 = r0;
    WL_OPEN
    u64 _nd_90 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_90 + 0] = _h_34;
    r0 = term_clo(FID_MAIN_C257, _nd_90);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C257)
  {
    Term _h_35 = r0;
    Term _x_22 = r1;
    WL_OPEN
    u64 _nd_91 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_91 + 0] = _h_35;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_461 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_461 + 0] = term_clo(FID_IO_PRINT, _nd_91);
      e.mem[_t_461 + 1] = term_clo(FID_MAIN_C258, 0);
      e.mem[_t_461 + 2] = _x_22;
      return term_tsk(FID_IO_BIND, _t_461);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_91);
    r1 = term_clo(FID_MAIN_C258, 0);
    r2 = _x_22;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C258)
  {
    Term _x_23 = r0;
    WL_OPEN
    u32 _v_624 = 0;
    u32 _v_625 = 0;
    Term _v_626 = 0;
    Term _v_627 = 0;
    Term _v_628 = 0;
    Term _v_629 = 0;
    Term _v_630 = 0;
    Term _v_631 = 0;
    u32 _v_632 = 0;
    Term _v_633 = 0;
    u32 _v_634 = 0;
    Term _v_635 = 0;
    u32 _v_636 = 0;
    Term _v_637 = 0;
    Term _v_638 = 0;
    Term _v_639 = 0;
    Term _fv_340[1];
    _fv_340[0] = 999000ull;
    Term _fv_341[1];
    _fv_341[0] = 999001ull;
    Term _fv_342[1];
    _fv_342[0] = 999002ull;
    Term _fv_343[1];
    _fv_343[0] = 999003ull;
    Term _fv_344[1];
    _fv_344[0] = 999004ull;
    Term _fv_345[1];
    _fv_345[0] = 999005ull;
    Term _fv_346[1];
    _fv_346[0] = 999006ull;
    Term _fv_347[1];
    _fv_347[0] = 999007ull;
    u64 _nd_92 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_92 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_340), blk_new(e, 0, 0, 0, 1, _fv_341)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_342), blk_new(e, 0, 0, 0, 1, _fv_343))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_344), blk_new(e, 0, 0, 0, 1, _fv_345)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_346), blk_new(e, 0, 0, 0, 1, _fv_347)))));
    e.mem[_nd_92 + 1] = rfc_seal(e, 999ull);
    Term _v_640 = 0;
    Term _v_641 = 0;
    Term _v_642 = 0;
    Term _v_643 = 0;
    Term _v_644 = 0;
    Term _v_645 = 0;
    u32 _v_646 = 0;
    Term _v_647 = 0;
    u32 _v_648 = 0;
    Term _v_649 = 0;
    Term _fv_348[1];
    _fv_348[0] = 1000ull;
    Term _fv_349[1];
    _fv_349[0] = 1001ull;
    Term _fv_350[1];
    _fv_350[0] = 1002ull;
    Term _fv_351[1];
    _fv_351[0] = 1003ull;
    Term _fv_352[1];
    _fv_352[0] = 1004ull;
    Term _fv_353[1];
    _fv_353[0] = 1005ull;
    Term _fv_354[1];
    _fv_354[0] = 1006ull;
    Term _fv_355[1];
    _fv_355[0] = 1007ull;
    u32 _o_228 = 0;
    Term _o_229 = 0;
    Term _t_132 = 1;
    if (_t_132 == 0) {
      _o_228 = 0;
    } else {
      _o_228 = 1;
      u64 _nd_93 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_93 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_348), blk_new(e, 0, 0, 0, 1, _fv_349)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_350), blk_new(e, 0, 0, 0, 1, _fv_351))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_352), blk_new(e, 0, 0, 0, 1, _fv_353)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_354), blk_new(e, 0, 0, 0, 1, _fv_355)))));
      e.mem[_nd_93 + 1] = rfc_seal(e, 1ull);
      _o_229 = term_ctr(CID_OWNED, _nd_93);
    }
    Term _fv_356[2];
    _fv_356[0] = _o_228;
    _fv_356[1] = _o_229;
    u32 _o_230 = 0;
    Term _o_231 = 0;
    Term _t_133 = 0;
    if (_t_133 == 0) {
      _o_230 = 0;
    } else {
      _o_230 = 1;
      u64 _nd_94 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_94 + 0] = rfc_seal(e, 0);
      e.mem[_nd_94 + 1] = rfc_seal(e, 0);
      _o_231 = term_ctr(CID_OWNED, _nd_94);
    }
    Term _fv_357[2];
    _fv_357[0] = _o_230;
    _fv_357[1] = _o_231;
    Term _fv_358[1];
    _fv_358[0] = 3000ull;
    Term _fv_359[1];
    _fv_359[0] = 3001ull;
    Term _fv_360[1];
    _fv_360[0] = 3002ull;
    Term _fv_361[1];
    _fv_361[0] = 3003ull;
    Term _fv_362[1];
    _fv_362[0] = 3004ull;
    Term _fv_363[1];
    _fv_363[0] = 3005ull;
    Term _fv_364[1];
    _fv_364[0] = 3006ull;
    Term _fv_365[1];
    _fv_365[0] = 3007ull;
    u32 _o_232 = 0;
    Term _o_233 = 0;
    Term _t_134 = 1;
    if (_t_134 == 0) {
      _o_232 = 0;
    } else {
      _o_232 = 1;
      u64 _nd_95 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_95 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_358), blk_new(e, 0, 0, 0, 1, _fv_359)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_360), blk_new(e, 0, 0, 0, 1, _fv_361))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_362), blk_new(e, 0, 0, 0, 1, _fv_363)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_364), blk_new(e, 0, 0, 0, 1, _fv_365)))));
      e.mem[_nd_95 + 1] = rfc_seal(e, 3ull);
      _o_233 = term_ctr(CID_OWNED, _nd_95);
    }
    Term _fv_366[2];
    _fv_366[0] = _o_232;
    _fv_366[1] = _o_233;
    Term _fv_367[1];
    _fv_367[0] = 4000ull;
    Term _fv_368[1];
    _fv_368[0] = 4001ull;
    Term _fv_369[1];
    _fv_369[0] = 4002ull;
    Term _fv_370[1];
    _fv_370[0] = 4003ull;
    Term _fv_371[1];
    _fv_371[0] = 4004ull;
    Term _fv_372[1];
    _fv_372[0] = 4005ull;
    Term _fv_373[1];
    _fv_373[0] = 4006ull;
    Term _fv_374[1];
    _fv_374[0] = 4007ull;
    u32 _o_234 = 0;
    Term _o_235 = 0;
    Term _t_135 = 1;
    if (_t_135 == 0) {
      _o_234 = 0;
    } else {
      _o_234 = 1;
      u64 _nd_96 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_96 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_367), blk_new(e, 0, 0, 0, 1, _fv_368)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_369), blk_new(e, 0, 0, 0, 1, _fv_370))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_371), blk_new(e, 0, 0, 0, 1, _fv_372)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_373), blk_new(e, 0, 0, 0, 1, _fv_374)))));
      e.mem[_nd_96 + 1] = rfc_seal(e, 4ull);
      _o_235 = term_ctr(CID_OWNED, _nd_96);
    }
    Term _fv_375[2];
    _fv_375[0] = _o_234;
    _fv_375[1] = _o_235;
    Term _fv_376[1];
    _fv_376[0] = 5000ull;
    Term _fv_377[1];
    _fv_377[0] = 5001ull;
    Term _fv_378[1];
    _fv_378[0] = 5002ull;
    Term _fv_379[1];
    _fv_379[0] = 5003ull;
    Term _fv_380[1];
    _fv_380[0] = 5004ull;
    Term _fv_381[1];
    _fv_381[0] = 5005ull;
    Term _fv_382[1];
    _fv_382[0] = 5006ull;
    Term _fv_383[1];
    _fv_383[0] = 5007ull;
    u32 _o_236 = 0;
    Term _o_237 = 0;
    Term _t_136 = 1;
    if (_t_136 == 0) {
      _o_236 = 0;
    } else {
      _o_236 = 1;
      u64 _nd_97 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_97 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_376), blk_new(e, 0, 0, 0, 1, _fv_377)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_378), blk_new(e, 0, 0, 0, 1, _fv_379))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_380), blk_new(e, 0, 0, 0, 1, _fv_381)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_382), blk_new(e, 0, 0, 0, 1, _fv_383)))));
      e.mem[_nd_97 + 1] = rfc_seal(e, 5ull);
      _o_237 = term_ctr(CID_OWNED, _nd_97);
    }
    Term _fv_384[2];
    _fv_384[0] = _o_236;
    _fv_384[1] = _o_237;
    Term _fv_385[1];
    _fv_385[0] = 6000ull;
    Term _fv_386[1];
    _fv_386[0] = 6001ull;
    Term _fv_387[1];
    _fv_387[0] = 6002ull;
    Term _fv_388[1];
    _fv_388[0] = 6003ull;
    Term _fv_389[1];
    _fv_389[0] = 6004ull;
    Term _fv_390[1];
    _fv_390[0] = 6005ull;
    Term _fv_391[1];
    _fv_391[0] = 6006ull;
    Term _fv_392[1];
    _fv_392[0] = 6007ull;
    u32 _o_238 = 0;
    Term _o_239 = 0;
    Term _t_137 = 1;
    if (_t_137 == 0) {
      _o_238 = 0;
    } else {
      _o_238 = 1;
      u64 _nd_98 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_98 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_385), blk_new(e, 0, 0, 0, 1, _fv_386)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_387), blk_new(e, 0, 0, 0, 1, _fv_388))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_389), blk_new(e, 0, 0, 0, 1, _fv_390)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_391), blk_new(e, 0, 0, 0, 1, _fv_392)))));
      e.mem[_nd_98 + 1] = rfc_seal(e, 6ull);
      _o_239 = term_ctr(CID_OWNED, _nd_98);
    }
    Term _fv_393[2];
    _fv_393[0] = _o_238;
    _fv_393[1] = _o_239;
    Term _fv_394[1];
    _fv_394[0] = 7000ull;
    Term _fv_395[1];
    _fv_395[0] = 7001ull;
    Term _fv_396[1];
    _fv_396[0] = 7002ull;
    Term _fv_397[1];
    _fv_397[0] = 7003ull;
    Term _fv_398[1];
    _fv_398[0] = 7004ull;
    Term _fv_399[1];
    _fv_399[0] = 7005ull;
    Term _fv_400[1];
    _fv_400[0] = 7006ull;
    Term _fv_401[1];
    _fv_401[0] = 7007ull;
    u32 _o_240 = 0;
    Term _o_241 = 0;
    Term _t_138 = 1;
    if (_t_138 == 0) {
      _o_240 = 0;
    } else {
      _o_240 = 1;
      u64 _nd_99 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_99 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_394), blk_new(e, 0, 0, 0, 1, _fv_395)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_396), blk_new(e, 0, 0, 0, 1, _fv_397))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_398), blk_new(e, 0, 0, 0, 1, _fv_399)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_400), blk_new(e, 0, 0, 0, 1, _fv_401)))));
      e.mem[_nd_99 + 1] = rfc_seal(e, 7ull);
      _o_241 = term_ctr(CID_OWNED, _nd_99);
    }
    Term _fv_402[2];
    _fv_402[0] = _o_240;
    _fv_402[1] = _o_241;
    Term _fv_403[1];
    _fv_403[0] = 8000ull;
    Term _fv_404[1];
    _fv_404[0] = 8001ull;
    Term _fv_405[1];
    _fv_405[0] = 8002ull;
    Term _fv_406[1];
    _fv_406[0] = 8003ull;
    Term _fv_407[1];
    _fv_407[0] = 8004ull;
    Term _fv_408[1];
    _fv_408[0] = 8005ull;
    Term _fv_409[1];
    _fv_409[0] = 8006ull;
    Term _fv_410[1];
    _fv_410[0] = 8007ull;
    u32 _o_242 = 0;
    Term _o_243 = 0;
    Term _t_139 = 1;
    if (_t_139 == 0) {
      _o_242 = 0;
    } else {
      _o_242 = 1;
      u64 _nd_100 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_100 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_403), blk_new(e, 0, 0, 0, 1, _fv_404)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_405), blk_new(e, 0, 0, 0, 1, _fv_406))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_407), blk_new(e, 0, 0, 0, 1, _fv_408)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_409), blk_new(e, 0, 0, 0, 1, _fv_410)))));
      e.mem[_nd_100 + 1] = rfc_seal(e, 8ull);
      _o_243 = term_ctr(CID_OWNED, _nd_100);
    }
    Term _fv_411[2];
    _fv_411[0] = _o_242;
    _fv_411[1] = _o_243;
    Term _fv_412[1];
    _fv_412[0] = 101000ull;
    Term _fv_413[1];
    _fv_413[0] = 101001ull;
    Term _fv_414[1];
    _fv_414[0] = 101002ull;
    Term _fv_415[1];
    _fv_415[0] = 101003ull;
    Term _fv_416[1];
    _fv_416[0] = 101004ull;
    Term _fv_417[1];
    _fv_417[0] = 101005ull;
    Term _fv_418[1];
    _fv_418[0] = 101006ull;
    Term _fv_419[1];
    _fv_419[0] = 101007ull;
    u32 _o_244 = 0;
    Term _o_245 = 0;
    Term _t_140 = 1;
    if (_t_140 == 0) {
      _o_244 = 0;
    } else {
      _o_244 = 1;
      u64 _nd_101 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_101 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_412), blk_new(e, 0, 0, 0, 1, _fv_413)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_414), blk_new(e, 0, 0, 0, 1, _fv_415))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_416), blk_new(e, 0, 0, 0, 1, _fv_417)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_418), blk_new(e, 0, 0, 0, 1, _fv_419)))));
      e.mem[_nd_101 + 1] = rfc_seal(e, 101ull);
      _o_245 = term_ctr(CID_OWNED, _nd_101);
    }
    Term _fv_420[2];
    _fv_420[0] = _o_244;
    _fv_420[1] = _o_245;
    Term _fv_421[1];
    _fv_421[0] = 102000ull;
    Term _fv_422[1];
    _fv_422[0] = 102001ull;
    Term _fv_423[1];
    _fv_423[0] = 102002ull;
    Term _fv_424[1];
    _fv_424[0] = 102003ull;
    Term _fv_425[1];
    _fv_425[0] = 102004ull;
    Term _fv_426[1];
    _fv_426[0] = 102005ull;
    Term _fv_427[1];
    _fv_427[0] = 102006ull;
    Term _fv_428[1];
    _fv_428[0] = 102007ull;
    u32 _o_246 = 0;
    Term _o_247 = 0;
    Term _t_141 = 1;
    if (_t_141 == 0) {
      _o_246 = 0;
    } else {
      _o_246 = 1;
      u64 _nd_102 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_102 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_421), blk_new(e, 0, 0, 0, 1, _fv_422)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_423), blk_new(e, 0, 0, 0, 1, _fv_424))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_425), blk_new(e, 0, 0, 0, 1, _fv_426)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_427), blk_new(e, 0, 0, 0, 1, _fv_428)))));
      e.mem[_nd_102 + 1] = rfc_seal(e, 102ull);
      _o_247 = term_ctr(CID_OWNED, _nd_102);
    }
    Term _fv_429[2];
    _fv_429[0] = _o_246;
    _fv_429[1] = _o_247;
    Term _fv_430[1];
    _fv_430[0] = 103000ull;
    Term _fv_431[1];
    _fv_431[0] = 103001ull;
    Term _fv_432[1];
    _fv_432[0] = 103002ull;
    Term _fv_433[1];
    _fv_433[0] = 103003ull;
    Term _fv_434[1];
    _fv_434[0] = 103004ull;
    Term _fv_435[1];
    _fv_435[0] = 103005ull;
    Term _fv_436[1];
    _fv_436[0] = 103006ull;
    Term _fv_437[1];
    _fv_437[0] = 103007ull;
    u32 _o_248 = 0;
    Term _o_249 = 0;
    Term _t_142 = 1;
    if (_t_142 == 0) {
      _o_248 = 0;
    } else {
      _o_248 = 1;
      u64 _nd_103 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_103 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_430), blk_new(e, 0, 0, 0, 1, _fv_431)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_432), blk_new(e, 0, 0, 0, 1, _fv_433))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_434), blk_new(e, 0, 0, 0, 1, _fv_435)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_436), blk_new(e, 0, 0, 0, 1, _fv_437)))));
      e.mem[_nd_103 + 1] = rfc_seal(e, 103ull);
      _o_249 = term_ctr(CID_OWNED, _nd_103);
    }
    Term _fv_438[2];
    _fv_438[0] = _o_248;
    _fv_438[1] = _o_249;
    Term _fv_439[1];
    _fv_439[0] = 104000ull;
    Term _fv_440[1];
    _fv_440[0] = 104001ull;
    Term _fv_441[1];
    _fv_441[0] = 104002ull;
    Term _fv_442[1];
    _fv_442[0] = 104003ull;
    Term _fv_443[1];
    _fv_443[0] = 104004ull;
    Term _fv_444[1];
    _fv_444[0] = 104005ull;
    Term _fv_445[1];
    _fv_445[0] = 104006ull;
    Term _fv_446[1];
    _fv_446[0] = 104007ull;
    u32 _o_250 = 0;
    Term _o_251 = 0;
    Term _t_143 = 1;
    if (_t_143 == 0) {
      _o_250 = 0;
    } else {
      _o_250 = 1;
      u64 _nd_104 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_104 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_439), blk_new(e, 0, 0, 0, 1, _fv_440)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_441), blk_new(e, 0, 0, 0, 1, _fv_442))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_443), blk_new(e, 0, 0, 0, 1, _fv_444)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_445), blk_new(e, 0, 0, 0, 1, _fv_446)))));
      e.mem[_nd_104 + 1] = rfc_seal(e, 104ull);
      _o_251 = term_ctr(CID_OWNED, _nd_104);
    }
    Term _fv_447[2];
    _fv_447[0] = _o_250;
    _fv_447[1] = _o_251;
    Term _fv_448[1];
    _fv_448[0] = 105000ull;
    Term _fv_449[1];
    _fv_449[0] = 105001ull;
    Term _fv_450[1];
    _fv_450[0] = 105002ull;
    Term _fv_451[1];
    _fv_451[0] = 105003ull;
    Term _fv_452[1];
    _fv_452[0] = 105004ull;
    Term _fv_453[1];
    _fv_453[0] = 105005ull;
    Term _fv_454[1];
    _fv_454[0] = 105006ull;
    Term _fv_455[1];
    _fv_455[0] = 105007ull;
    u32 _o_252 = 0;
    Term _o_253 = 0;
    Term _t_144 = 1;
    if (_t_144 == 0) {
      _o_252 = 0;
    } else {
      _o_252 = 1;
      u64 _nd_105 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_105 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_448), blk_new(e, 0, 0, 0, 1, _fv_449)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_450), blk_new(e, 0, 0, 0, 1, _fv_451))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_452), blk_new(e, 0, 0, 0, 1, _fv_453)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_454), blk_new(e, 0, 0, 0, 1, _fv_455)))));
      e.mem[_nd_105 + 1] = rfc_seal(e, 105ull);
      _o_253 = term_ctr(CID_OWNED, _nd_105);
    }
    Term _fv_456[2];
    _fv_456[0] = _o_252;
    _fv_456[1] = _o_253;
    Term _fv_457[1];
    _fv_457[0] = 106000ull;
    Term _fv_458[1];
    _fv_458[0] = 106001ull;
    Term _fv_459[1];
    _fv_459[0] = 106002ull;
    Term _fv_460[1];
    _fv_460[0] = 106003ull;
    Term _fv_461[1];
    _fv_461[0] = 106004ull;
    Term _fv_462[1];
    _fv_462[0] = 106005ull;
    Term _fv_463[1];
    _fv_463[0] = 106006ull;
    Term _fv_464[1];
    _fv_464[0] = 106007ull;
    u32 _o_254 = 0;
    Term _o_255 = 0;
    Term _t_145 = 1;
    if (_t_145 == 0) {
      _o_254 = 0;
    } else {
      _o_254 = 1;
      u64 _nd_106 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_106 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_457), blk_new(e, 0, 0, 0, 1, _fv_458)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_459), blk_new(e, 0, 0, 0, 1, _fv_460))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_461), blk_new(e, 0, 0, 0, 1, _fv_462)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_463), blk_new(e, 0, 0, 0, 1, _fv_464)))));
      e.mem[_nd_106 + 1] = rfc_seal(e, 106ull);
      _o_255 = term_ctr(CID_OWNED, _nd_106);
    }
    Term _fv_465[2];
    _fv_465[0] = _o_254;
    _fv_465[1] = _o_255;
    Term _fv_466[1];
    _fv_466[0] = 107000ull;
    Term _fv_467[1];
    _fv_467[0] = 107001ull;
    Term _fv_468[1];
    _fv_468[0] = 107002ull;
    Term _fv_469[1];
    _fv_469[0] = 107003ull;
    Term _fv_470[1];
    _fv_470[0] = 107004ull;
    Term _fv_471[1];
    _fv_471[0] = 107005ull;
    Term _fv_472[1];
    _fv_472[0] = 107006ull;
    Term _fv_473[1];
    _fv_473[0] = 107007ull;
    u32 _o_256 = 0;
    Term _o_257 = 0;
    Term _t_146 = 1;
    if (_t_146 == 0) {
      _o_256 = 0;
    } else {
      _o_256 = 1;
      u64 _nd_107 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_107 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_466), blk_new(e, 0, 0, 0, 1, _fv_467)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_468), blk_new(e, 0, 0, 0, 1, _fv_469))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_470), blk_new(e, 0, 0, 0, 1, _fv_471)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_472), blk_new(e, 0, 0, 0, 1, _fv_473)))));
      e.mem[_nd_107 + 1] = rfc_seal(e, 107ull);
      _o_257 = term_ctr(CID_OWNED, _nd_107);
    }
    Term _fv_474[2];
    _fv_474[0] = _o_256;
    _fv_474[1] = _o_257;
    Term _fv_475[1];
    _fv_475[0] = 108000ull;
    Term _fv_476[1];
    _fv_476[0] = 108001ull;
    Term _fv_477[1];
    _fv_477[0] = 108002ull;
    Term _fv_478[1];
    _fv_478[0] = 108003ull;
    Term _fv_479[1];
    _fv_479[0] = 108004ull;
    Term _fv_480[1];
    _fv_480[0] = 108005ull;
    Term _fv_481[1];
    _fv_481[0] = 108006ull;
    Term _fv_482[1];
    _fv_482[0] = 108007ull;
    u32 _o_258 = 0;
    Term _o_259 = 0;
    Term _t_147 = 1;
    if (_t_147 == 0) {
      _o_258 = 0;
    } else {
      _o_258 = 1;
      u64 _nd_108 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_108 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_475), blk_new(e, 0, 0, 0, 1, _fv_476)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_477), blk_new(e, 0, 0, 0, 1, _fv_478))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_479), blk_new(e, 0, 0, 0, 1, _fv_480)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_481), blk_new(e, 0, 0, 0, 1, _fv_482)))));
      e.mem[_nd_108 + 1] = rfc_seal(e, 108ull);
      _o_259 = term_ctr(CID_OWNED, _nd_108);
    }
    Term _fv_483[2];
    _fv_483[0] = _o_258;
    _fv_483[1] = _o_259;
    Term _fv_484[1];
    _fv_484[0] = 1;
    Term _fv_485[1];
    _fv_485[0] = 1;
    Term _fv_486[1];
    _fv_486[0] = 0;
    Term _fv_487[1];
    _fv_487[0] = 1;
    Term _fv_488[1];
    _fv_488[0] = 1;
    Term _fv_489[1];
    _fv_489[0] = 1;
    Term _fv_490[1];
    _fv_490[0] = 1;
    Term _fv_491[1];
    _fv_491[0] = 1;
    u32 _o_260 = 0;
    Term _o_261 = 0;
    Term _t_148 = 1;
    if (_t_148 == 0) {
      _o_260 = 0;
    } else {
      _o_260 = 1;
      _o_261 = term_pak(CID_UNIT, 0);
    }
    Term _fv_492[2];
    _fv_492[0] = _o_260;
    _fv_492[1] = _o_261;
    u32 _o_262 = 0;
    Term _o_263 = 0;
    Term _t_149 = 0;
    if (_t_149 == 0) {
      _o_262 = 0;
    } else {
      _o_262 = 1;
      _o_263 = term_pak(CID_UNIT, 0);
    }
    Term _fv_493[2];
    _fv_493[0] = _o_262;
    _fv_493[1] = _o_263;
    u32 _o_264 = 0;
    Term _o_265 = 0;
    Term _t_150 = 1;
    if (_t_150 == 0) {
      _o_264 = 0;
    } else {
      _o_264 = 1;
      _o_265 = term_pak(CID_UNIT, 0);
    }
    Term _fv_494[2];
    _fv_494[0] = _o_264;
    _fv_494[1] = _o_265;
    u32 _o_266 = 0;
    Term _o_267 = 0;
    Term _t_151 = 0;
    if (_t_151 == 0) {
      _o_266 = 0;
    } else {
      _o_266 = 1;
      _o_267 = term_pak(CID_UNIT, 0);
    }
    Term _fv_495[2];
    _fv_495[0] = _o_266;
    _fv_495[1] = _o_267;
    u32 _o_268 = 0;
    Term _o_269 = 0;
    Term _t_152 = 1;
    if (_t_152 == 0) {
      _o_268 = 0;
    } else {
      _o_268 = 1;
      _o_269 = term_pak(CID_UNIT, 0);
    }
    Term _fv_496[2];
    _fv_496[0] = _o_268;
    _fv_496[1] = _o_269;
    u32 _o_270 = 0;
    Term _o_271 = 0;
    Term _t_153 = 0;
    if (_t_153 == 0) {
      _o_270 = 0;
    } else {
      _o_270 = 1;
      _o_271 = term_pak(CID_UNIT, 0);
    }
    Term _fv_497[2];
    _fv_497[0] = _o_270;
    _fv_497[1] = _o_271;
    u32 _o_272 = 0;
    Term _o_273 = 0;
    Term _t_154 = 1;
    if (_t_154 == 0) {
      _o_272 = 0;
    } else {
      _o_272 = 1;
      _o_273 = term_pak(CID_UNIT, 0);
    }
    Term _fv_498[2];
    _fv_498[0] = _o_272;
    _fv_498[1] = _o_273;
    u32 _o_274 = 0;
    Term _o_275 = 0;
    Term _t_155 = 0;
    if (_t_155 == 0) {
      _o_274 = 0;
    } else {
      _o_274 = 1;
      _o_275 = term_pak(CID_UNIT, 0);
    }
    Term _fv_499[2];
    _fv_499[0] = _o_274;
    _fv_499[1] = _o_275;
    Term _fv_500[1];
    _fv_500[0] = 100ull;
    Term _fv_501[1];
    _fv_501[0] = 101ull;
    Term _fv_502[1];
    _fv_502[0] = 102ull;
    Term _fv_503[1];
    _fv_503[0] = 103ull;
    Term _fv_504[1];
    _fv_504[0] = 104ull;
    Term _fv_505[1];
    _fv_505[0] = 105ull;
    Term _fv_506[1];
    _fv_506[0] = 106ull;
    Term _fv_507[1];
    _fv_507[0] = 107ull;
    Term _fv_508[1];
    _fv_508[0] = 200ull;
    Term _fv_509[1];
    _fv_509[0] = 201ull;
    Term _fv_510[1];
    _fv_510[0] = 202ull;
    Term _fv_511[1];
    _fv_511[0] = 203ull;
    Term _fv_512[1];
    _fv_512[0] = 204ull;
    Term _fv_513[1];
    _fv_513[0] = 205ull;
    Term _fv_514[1];
    _fv_514[0] = 206ull;
    Term _fv_515[1];
    _fv_515[0] = 207ull;
    Term _v_650 = 0;
    Term _v_651 = 0;
    Term _v_652 = 0;
    Term _v_653 = 0;
    Term _v_654 = 0;
    Term _v_655 = 0;
    u32 _v_656 = 0;
    Term _v_657 = 0;
    u32 _v_658 = 0;
    Term _v_659 = 0;
    Term _o_276[10];
    Term _a_120 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_356), blk_new(e, 1, 0, 1, 2, _fv_357)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_366), blk_new(e, 1, 0, 1, 2, _fv_375))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_384), blk_new(e, 1, 0, 1, 2, _fv_393)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_402), blk_new(e, 1, 0, 1, 2, _fv_411))));
    Term _a_121 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_420), blk_new(e, 1, 0, 1, 2, _fv_429)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_438), blk_new(e, 1, 0, 1, 2, _fv_447))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_456), blk_new(e, 1, 0, 1, 2, _fv_465)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_474), blk_new(e, 1, 0, 1, 2, _fv_483))));
    Term _a_122 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_484), blk_new(e, 0, 0, 0, 1, _fv_485)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_486), blk_new(e, 0, 0, 0, 1, _fv_487))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_488), blk_new(e, 0, 0, 0, 1, _fv_489)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_490), blk_new(e, 0, 0, 0, 1, _fv_491))));
    Term _a_123 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_492), blk_new(e, 1, 0, 1, 2, _fv_493)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_494), blk_new(e, 1, 0, 1, 2, _fv_495))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_496), blk_new(e, 1, 0, 1, 2, _fv_497)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_498), blk_new(e, 1, 0, 1, 2, _fv_499))));
    Term _a_124 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_500), blk_new(e, 0, 0, 0, 1, _fv_501)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_502), blk_new(e, 0, 0, 0, 1, _fv_503))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_504), blk_new(e, 0, 0, 0, 1, _fv_505)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_506), blk_new(e, 0, 0, 0, 1, _fv_507))));
    Term _a_125 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_508), blk_new(e, 0, 0, 0, 1, _fv_509)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_510), blk_new(e, 0, 0, 0, 1, _fv_511))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_512), blk_new(e, 0, 0, 0, 1, _fv_513)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_514), blk_new(e, 0, 0, 0, 1, _fv_515))));
    Term _a_126 = term_pak(CID_NIL, 0);
    if (spin_19(e, _o_276, ((u64)7ull), 1ull, 8ull, 3ull, 7ull, 0, 7ull, _a_120, blk_loc(e.mem, _a_120), _a_121, blk_loc(e.mem, _a_121), _a_122, blk_loc(e.mem, _a_122), _a_123, blk_loc(e.mem, _a_123), _a_124, blk_loc(e.mem, _a_124), _a_125, blk_loc(e.mem, _a_125), _a_126, blk_loc(e.mem, _a_126)) == 0) {
      return 0;
    }
    _v_650 = _o_276[0];
    _v_651 = _o_276[1];
    _v_652 = _o_276[2];
    _v_653 = _o_276[3];
    _v_654 = _o_276[4];
    _v_655 = _o_276[5];
    _v_656 = _o_276[6];
    _v_657 = _o_276[7];
    _v_658 = _o_276[8];
    _v_659 = _o_276[9];
    _v_640 = _v_650;
    _v_641 = _v_651;
    _v_642 = _v_652;
    _v_643 = _v_653;
    _v_644 = _v_654;
    _v_645 = _v_655;
    _v_646 = _v_656;
    _v_647 = _v_657;
    _v_648 = _v_658;
    _v_649 = _v_659;
    u32 _v_660 = 0;
    u32 _v_661 = 0;
    Term _v_662 = 0;
    Term _v_663 = 0;
    Term _v_664 = 0;
    Term _v_665 = 0;
    Term _v_666 = 0;
    Term _v_667 = 0;
    u32 _v_668 = 0;
    Term _v_669 = 0;
    u32 _v_670 = 0;
    Term _v_671 = 0;
    u32 _v_672 = 0;
    Term _v_673 = 0;
    Term _v_674 = 0;
    Term _v_675 = 0;
    Term _o_277[16];
    Term _a_127 = term_pak(CID_NIL, 0);
    Term _a_128 = term_ctr(CID_OWNED, _nd_92);
    Term _a_129 = 123ull;
    if (spin_21(e, _o_277, 7ull, 999ull, _a_127, blk_loc(e.mem, _a_127), 1, _a_128, blk_loc(e.mem, _a_128), _a_129, blk_loc(e.mem, _a_129), _v_640, blk_loc(e.mem, _v_640), _v_641, blk_loc(e.mem, _v_641), _v_642, blk_loc(e.mem, _v_642), _v_643, blk_loc(e.mem, _v_643), _v_644, blk_loc(e.mem, _v_644), _v_645, blk_loc(e.mem, _v_645), _v_646, _v_647, _v_648, _v_649, blk_loc(e.mem, _v_649)) == 0) {
      return 0;
    }
    _v_660 = _o_277[0];
    _v_661 = _o_277[1];
    _v_662 = _o_277[2];
    _v_663 = _o_277[3];
    _v_664 = _o_277[4];
    _v_665 = _o_277[5];
    _v_666 = _o_277[6];
    _v_667 = _o_277[7];
    _v_668 = _o_277[8];
    _v_669 = _o_277[9];
    _v_670 = _o_277[10];
    _v_671 = _o_277[11];
    _v_672 = _o_277[12];
    _v_673 = _o_277[13];
    _v_674 = _o_277[14];
    _v_675 = _o_277[15];
    _v_624 = _v_660;
    _v_625 = _v_661;
    _v_626 = _v_662;
    _v_627 = _v_663;
    _v_628 = _v_664;
    _v_629 = _v_665;
    _v_630 = _v_666;
    _v_631 = _v_667;
    _v_632 = _v_668;
    _v_633 = _v_669;
    _v_634 = _v_670;
    _v_635 = _v_671;
    _v_636 = _v_672;
    _v_637 = _v_673;
    _v_638 = _v_674;
    _v_639 = _v_675;
    u32 _o_278 = 0;
    Term _o_279 = 0;
    u32 _o_280 = 0;
    if (_v_636 == 0) {
      _o_278 = 0;
    } else {
      _o_278 = 1;
      Term _fb_12[2];
      u64 _sp_12 = ctr_take(e, _v_637, 2, _fb_12);
      Term _f_24 = _fb_12[0];
      u32 _f_25 = _fb_12[1];
      spare_free(e, cls_fit(2), _sp_12);
      _o_279 = _f_24;
      _o_280 = _f_25;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K259;
      WL_PUSHN(1);
    } else {
      u64 _t_156 = task_node(e, FID_MAIN_K259, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K259, _t_156);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_157 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_157 + 0] = _v_624;
      e.mem[_t_157 + 1] = _v_625;
      e.mem[_t_157 + 2] = _v_626;
      e.mem[_t_157 + 3] = _v_627;
      e.mem[_t_157 + 4] = _v_628;
      e.mem[_t_157 + 5] = _v_629;
      e.mem[_t_157 + 6] = _v_630;
      e.mem[_t_157 + 7] = _v_631;
      e.mem[_t_157 + 8] = _v_632;
      e.mem[_t_157 + 9] = _v_633;
      e.mem[_t_157 + 10] = _v_634;
      e.mem[_t_157 + 11] = _v_635;
      e.mem[_t_157 + 12] = _o_278;
      e.mem[_t_157 + 13] = _o_279;
      e.mem[_t_157 + 14] = _o_280;
      e.mem[_t_157 + 15] = _v_638;
      e.mem[_t_157 + 16] = _v_639;
      return term_tsk(FID_SNAPSHOT, _t_157);
    }
    r0 = _v_624;
    r1 = _v_625;
    r2 = _v_626;
    r3 = _v_627;
    r4 = _v_628;
    r5 = _v_629;
    r6 = _v_630;
    r7 = _v_631;
    r8 = _v_632;
    r9 = _v_633;
    r10 = _v_634;
    r11 = _v_635;
    r12 = _o_278;
    r13 = _o_279;
    r14 = _o_280;
    r15 = _v_638;
    r16 = _v_639;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K259)
  {
    Term _h_36 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K260;
      WL_PUSHN(1);
    } else {
      u64 _t_158 = task_node(e, FID_MAIN_K260, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K260, _t_158);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_159 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_159 + 0] = term_ctr(CID_SCON, STAT_OFF + 176);
      e.mem[_t_159 + 1] = _h_36;
      return term_tsk(FID_STRING_APPEND, _t_159);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 176);
    r1 = _h_36;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K260)
  {
    Term _h_37 = r0;
    WL_OPEN
    u64 _nd_109 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_109 + 0] = _h_37;
    r0 = term_clo(FID_MAIN_C261, _nd_109);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C261)
  {
    Term _h_38 = r0;
    Term _x_24 = r1;
    WL_OPEN
    u64 _nd_110 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_110 + 0] = _h_38;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_460 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_460 + 0] = term_clo(FID_IO_PRINT, _nd_110);
      e.mem[_t_460 + 1] = term_clo(FID_MAIN_C262, 0);
      e.mem[_t_460 + 2] = _x_24;
      return term_tsk(FID_IO_BIND, _t_460);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_110);
    r1 = term_clo(FID_MAIN_C262, 0);
    r2 = _x_24;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C262)
  {
    Term _x_25 = r0;
    WL_OPEN
    u32 _v_676 = 0;
    u32 _v_677 = 0;
    Term _v_678 = 0;
    Term _v_679 = 0;
    Term _v_680 = 0;
    Term _v_681 = 0;
    Term _v_682 = 0;
    Term _v_683 = 0;
    u32 _v_684 = 0;
    Term _v_685 = 0;
    u32 _v_686 = 0;
    Term _v_687 = 0;
    u32 _v_688 = 0;
    Term _v_689 = 0;
    Term _v_690 = 0;
    Term _v_691 = 0;
    Term _fv_516[1];
    _fv_516[0] = 999000ull;
    Term _fv_517[1];
    _fv_517[0] = 999001ull;
    Term _fv_518[1];
    _fv_518[0] = 999002ull;
    Term _fv_519[1];
    _fv_519[0] = 999003ull;
    Term _fv_520[1];
    _fv_520[0] = 999004ull;
    Term _fv_521[1];
    _fv_521[0] = 999005ull;
    Term _fv_522[1];
    _fv_522[0] = 999006ull;
    Term _fv_523[1];
    _fv_523[0] = 999007ull;
    u64 _nd_111 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_111 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_516), blk_new(e, 0, 0, 0, 1, _fv_517)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_518), blk_new(e, 0, 0, 0, 1, _fv_519))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_520), blk_new(e, 0, 0, 0, 1, _fv_521)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_522), blk_new(e, 0, 0, 0, 1, _fv_523)))));
    e.mem[_nd_111 + 1] = rfc_seal(e, 999ull);
    Term _v_692 = 0;
    Term _v_693 = 0;
    Term _v_694 = 0;
    Term _v_695 = 0;
    Term _v_696 = 0;
    Term _v_697 = 0;
    u32 _v_698 = 0;
    Term _v_699 = 0;
    u32 _v_700 = 0;
    Term _v_701 = 0;
    Term _fv_524[1];
    _fv_524[0] = 1000ull;
    Term _fv_525[1];
    _fv_525[0] = 1001ull;
    Term _fv_526[1];
    _fv_526[0] = 1002ull;
    Term _fv_527[1];
    _fv_527[0] = 1003ull;
    Term _fv_528[1];
    _fv_528[0] = 1004ull;
    Term _fv_529[1];
    _fv_529[0] = 1005ull;
    Term _fv_530[1];
    _fv_530[0] = 1006ull;
    Term _fv_531[1];
    _fv_531[0] = 1007ull;
    u32 _o_281 = 0;
    Term _o_282 = 0;
    Term _t_160 = 1;
    if (_t_160 == 0) {
      _o_281 = 0;
    } else {
      _o_281 = 1;
      u64 _nd_112 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_112 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_524), blk_new(e, 0, 0, 0, 1, _fv_525)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_526), blk_new(e, 0, 0, 0, 1, _fv_527))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_528), blk_new(e, 0, 0, 0, 1, _fv_529)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_530), blk_new(e, 0, 0, 0, 1, _fv_531)))));
      e.mem[_nd_112 + 1] = rfc_seal(e, 1ull);
      _o_282 = term_ctr(CID_OWNED, _nd_112);
    }
    Term _fv_532[2];
    _fv_532[0] = _o_281;
    _fv_532[1] = _o_282;
    u32 _o_283 = 0;
    Term _o_284 = 0;
    Term _t_161 = 0;
    if (_t_161 == 0) {
      _o_283 = 0;
    } else {
      _o_283 = 1;
      u64 _nd_113 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_113 + 0] = rfc_seal(e, 0);
      e.mem[_nd_113 + 1] = rfc_seal(e, 0);
      _o_284 = term_ctr(CID_OWNED, _nd_113);
    }
    Term _fv_533[2];
    _fv_533[0] = _o_283;
    _fv_533[1] = _o_284;
    Term _fv_534[1];
    _fv_534[0] = 3000ull;
    Term _fv_535[1];
    _fv_535[0] = 3001ull;
    Term _fv_536[1];
    _fv_536[0] = 3002ull;
    Term _fv_537[1];
    _fv_537[0] = 3003ull;
    Term _fv_538[1];
    _fv_538[0] = 3004ull;
    Term _fv_539[1];
    _fv_539[0] = 3005ull;
    Term _fv_540[1];
    _fv_540[0] = 3006ull;
    Term _fv_541[1];
    _fv_541[0] = 3007ull;
    u32 _o_285 = 0;
    Term _o_286 = 0;
    Term _t_162 = 1;
    if (_t_162 == 0) {
      _o_285 = 0;
    } else {
      _o_285 = 1;
      u64 _nd_114 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_114 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_534), blk_new(e, 0, 0, 0, 1, _fv_535)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_536), blk_new(e, 0, 0, 0, 1, _fv_537))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_538), blk_new(e, 0, 0, 0, 1, _fv_539)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_540), blk_new(e, 0, 0, 0, 1, _fv_541)))));
      e.mem[_nd_114 + 1] = rfc_seal(e, 3ull);
      _o_286 = term_ctr(CID_OWNED, _nd_114);
    }
    Term _fv_542[2];
    _fv_542[0] = _o_285;
    _fv_542[1] = _o_286;
    Term _fv_543[1];
    _fv_543[0] = 4000ull;
    Term _fv_544[1];
    _fv_544[0] = 4001ull;
    Term _fv_545[1];
    _fv_545[0] = 4002ull;
    Term _fv_546[1];
    _fv_546[0] = 4003ull;
    Term _fv_547[1];
    _fv_547[0] = 4004ull;
    Term _fv_548[1];
    _fv_548[0] = 4005ull;
    Term _fv_549[1];
    _fv_549[0] = 4006ull;
    Term _fv_550[1];
    _fv_550[0] = 4007ull;
    u32 _o_287 = 0;
    Term _o_288 = 0;
    Term _t_163 = 1;
    if (_t_163 == 0) {
      _o_287 = 0;
    } else {
      _o_287 = 1;
      u64 _nd_115 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_115 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_543), blk_new(e, 0, 0, 0, 1, _fv_544)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_545), blk_new(e, 0, 0, 0, 1, _fv_546))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_547), blk_new(e, 0, 0, 0, 1, _fv_548)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_549), blk_new(e, 0, 0, 0, 1, _fv_550)))));
      e.mem[_nd_115 + 1] = rfc_seal(e, 4ull);
      _o_288 = term_ctr(CID_OWNED, _nd_115);
    }
    Term _fv_551[2];
    _fv_551[0] = _o_287;
    _fv_551[1] = _o_288;
    Term _fv_552[1];
    _fv_552[0] = 5000ull;
    Term _fv_553[1];
    _fv_553[0] = 5001ull;
    Term _fv_554[1];
    _fv_554[0] = 5002ull;
    Term _fv_555[1];
    _fv_555[0] = 5003ull;
    Term _fv_556[1];
    _fv_556[0] = 5004ull;
    Term _fv_557[1];
    _fv_557[0] = 5005ull;
    Term _fv_558[1];
    _fv_558[0] = 5006ull;
    Term _fv_559[1];
    _fv_559[0] = 5007ull;
    u32 _o_289 = 0;
    Term _o_290 = 0;
    Term _t_164 = 1;
    if (_t_164 == 0) {
      _o_289 = 0;
    } else {
      _o_289 = 1;
      u64 _nd_116 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_116 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_552), blk_new(e, 0, 0, 0, 1, _fv_553)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_554), blk_new(e, 0, 0, 0, 1, _fv_555))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_556), blk_new(e, 0, 0, 0, 1, _fv_557)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_558), blk_new(e, 0, 0, 0, 1, _fv_559)))));
      e.mem[_nd_116 + 1] = rfc_seal(e, 5ull);
      _o_290 = term_ctr(CID_OWNED, _nd_116);
    }
    Term _fv_560[2];
    _fv_560[0] = _o_289;
    _fv_560[1] = _o_290;
    Term _fv_561[1];
    _fv_561[0] = 6000ull;
    Term _fv_562[1];
    _fv_562[0] = 6001ull;
    Term _fv_563[1];
    _fv_563[0] = 6002ull;
    Term _fv_564[1];
    _fv_564[0] = 6003ull;
    Term _fv_565[1];
    _fv_565[0] = 6004ull;
    Term _fv_566[1];
    _fv_566[0] = 6005ull;
    Term _fv_567[1];
    _fv_567[0] = 6006ull;
    Term _fv_568[1];
    _fv_568[0] = 6007ull;
    u32 _o_291 = 0;
    Term _o_292 = 0;
    Term _t_165 = 1;
    if (_t_165 == 0) {
      _o_291 = 0;
    } else {
      _o_291 = 1;
      u64 _nd_117 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_117 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_561), blk_new(e, 0, 0, 0, 1, _fv_562)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_563), blk_new(e, 0, 0, 0, 1, _fv_564))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_565), blk_new(e, 0, 0, 0, 1, _fv_566)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_567), blk_new(e, 0, 0, 0, 1, _fv_568)))));
      e.mem[_nd_117 + 1] = rfc_seal(e, 6ull);
      _o_292 = term_ctr(CID_OWNED, _nd_117);
    }
    Term _fv_569[2];
    _fv_569[0] = _o_291;
    _fv_569[1] = _o_292;
    Term _fv_570[1];
    _fv_570[0] = 7000ull;
    Term _fv_571[1];
    _fv_571[0] = 7001ull;
    Term _fv_572[1];
    _fv_572[0] = 7002ull;
    Term _fv_573[1];
    _fv_573[0] = 7003ull;
    Term _fv_574[1];
    _fv_574[0] = 7004ull;
    Term _fv_575[1];
    _fv_575[0] = 7005ull;
    Term _fv_576[1];
    _fv_576[0] = 7006ull;
    Term _fv_577[1];
    _fv_577[0] = 7007ull;
    u32 _o_293 = 0;
    Term _o_294 = 0;
    Term _t_166 = 1;
    if (_t_166 == 0) {
      _o_293 = 0;
    } else {
      _o_293 = 1;
      u64 _nd_118 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_118 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_570), blk_new(e, 0, 0, 0, 1, _fv_571)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_572), blk_new(e, 0, 0, 0, 1, _fv_573))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_574), blk_new(e, 0, 0, 0, 1, _fv_575)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_576), blk_new(e, 0, 0, 0, 1, _fv_577)))));
      e.mem[_nd_118 + 1] = rfc_seal(e, 7ull);
      _o_294 = term_ctr(CID_OWNED, _nd_118);
    }
    Term _fv_578[2];
    _fv_578[0] = _o_293;
    _fv_578[1] = _o_294;
    Term _fv_579[1];
    _fv_579[0] = 8000ull;
    Term _fv_580[1];
    _fv_580[0] = 8001ull;
    Term _fv_581[1];
    _fv_581[0] = 8002ull;
    Term _fv_582[1];
    _fv_582[0] = 8003ull;
    Term _fv_583[1];
    _fv_583[0] = 8004ull;
    Term _fv_584[1];
    _fv_584[0] = 8005ull;
    Term _fv_585[1];
    _fv_585[0] = 8006ull;
    Term _fv_586[1];
    _fv_586[0] = 8007ull;
    u32 _o_295 = 0;
    Term _o_296 = 0;
    Term _t_167 = 1;
    if (_t_167 == 0) {
      _o_295 = 0;
    } else {
      _o_295 = 1;
      u64 _nd_119 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_119 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_579), blk_new(e, 0, 0, 0, 1, _fv_580)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_581), blk_new(e, 0, 0, 0, 1, _fv_582))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_583), blk_new(e, 0, 0, 0, 1, _fv_584)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_585), blk_new(e, 0, 0, 0, 1, _fv_586)))));
      e.mem[_nd_119 + 1] = rfc_seal(e, 8ull);
      _o_296 = term_ctr(CID_OWNED, _nd_119);
    }
    Term _fv_587[2];
    _fv_587[0] = _o_295;
    _fv_587[1] = _o_296;
    Term _fv_588[1];
    _fv_588[0] = 101000ull;
    Term _fv_589[1];
    _fv_589[0] = 101001ull;
    Term _fv_590[1];
    _fv_590[0] = 101002ull;
    Term _fv_591[1];
    _fv_591[0] = 101003ull;
    Term _fv_592[1];
    _fv_592[0] = 101004ull;
    Term _fv_593[1];
    _fv_593[0] = 101005ull;
    Term _fv_594[1];
    _fv_594[0] = 101006ull;
    Term _fv_595[1];
    _fv_595[0] = 101007ull;
    u32 _o_297 = 0;
    Term _o_298 = 0;
    Term _t_168 = 1;
    if (_t_168 == 0) {
      _o_297 = 0;
    } else {
      _o_297 = 1;
      u64 _nd_120 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_120 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_588), blk_new(e, 0, 0, 0, 1, _fv_589)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_590), blk_new(e, 0, 0, 0, 1, _fv_591))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_592), blk_new(e, 0, 0, 0, 1, _fv_593)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_594), blk_new(e, 0, 0, 0, 1, _fv_595)))));
      e.mem[_nd_120 + 1] = rfc_seal(e, 101ull);
      _o_298 = term_ctr(CID_OWNED, _nd_120);
    }
    Term _fv_596[2];
    _fv_596[0] = _o_297;
    _fv_596[1] = _o_298;
    Term _fv_597[1];
    _fv_597[0] = 102000ull;
    Term _fv_598[1];
    _fv_598[0] = 102001ull;
    Term _fv_599[1];
    _fv_599[0] = 102002ull;
    Term _fv_600[1];
    _fv_600[0] = 102003ull;
    Term _fv_601[1];
    _fv_601[0] = 102004ull;
    Term _fv_602[1];
    _fv_602[0] = 102005ull;
    Term _fv_603[1];
    _fv_603[0] = 102006ull;
    Term _fv_604[1];
    _fv_604[0] = 102007ull;
    u32 _o_299 = 0;
    Term _o_300 = 0;
    Term _t_169 = 1;
    if (_t_169 == 0) {
      _o_299 = 0;
    } else {
      _o_299 = 1;
      u64 _nd_121 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_121 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_597), blk_new(e, 0, 0, 0, 1, _fv_598)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_599), blk_new(e, 0, 0, 0, 1, _fv_600))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_601), blk_new(e, 0, 0, 0, 1, _fv_602)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_603), blk_new(e, 0, 0, 0, 1, _fv_604)))));
      e.mem[_nd_121 + 1] = rfc_seal(e, 102ull);
      _o_300 = term_ctr(CID_OWNED, _nd_121);
    }
    Term _fv_605[2];
    _fv_605[0] = _o_299;
    _fv_605[1] = _o_300;
    Term _fv_606[1];
    _fv_606[0] = 103000ull;
    Term _fv_607[1];
    _fv_607[0] = 103001ull;
    Term _fv_608[1];
    _fv_608[0] = 103002ull;
    Term _fv_609[1];
    _fv_609[0] = 103003ull;
    Term _fv_610[1];
    _fv_610[0] = 103004ull;
    Term _fv_611[1];
    _fv_611[0] = 103005ull;
    Term _fv_612[1];
    _fv_612[0] = 103006ull;
    Term _fv_613[1];
    _fv_613[0] = 103007ull;
    u32 _o_301 = 0;
    Term _o_302 = 0;
    Term _t_170 = 1;
    if (_t_170 == 0) {
      _o_301 = 0;
    } else {
      _o_301 = 1;
      u64 _nd_122 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_122 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_606), blk_new(e, 0, 0, 0, 1, _fv_607)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_608), blk_new(e, 0, 0, 0, 1, _fv_609))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_610), blk_new(e, 0, 0, 0, 1, _fv_611)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_612), blk_new(e, 0, 0, 0, 1, _fv_613)))));
      e.mem[_nd_122 + 1] = rfc_seal(e, 103ull);
      _o_302 = term_ctr(CID_OWNED, _nd_122);
    }
    Term _fv_614[2];
    _fv_614[0] = _o_301;
    _fv_614[1] = _o_302;
    Term _fv_615[1];
    _fv_615[0] = 104000ull;
    Term _fv_616[1];
    _fv_616[0] = 104001ull;
    Term _fv_617[1];
    _fv_617[0] = 104002ull;
    Term _fv_618[1];
    _fv_618[0] = 104003ull;
    Term _fv_619[1];
    _fv_619[0] = 104004ull;
    Term _fv_620[1];
    _fv_620[0] = 104005ull;
    Term _fv_621[1];
    _fv_621[0] = 104006ull;
    Term _fv_622[1];
    _fv_622[0] = 104007ull;
    u32 _o_303 = 0;
    Term _o_304 = 0;
    Term _t_171 = 1;
    if (_t_171 == 0) {
      _o_303 = 0;
    } else {
      _o_303 = 1;
      u64 _nd_123 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_123 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_615), blk_new(e, 0, 0, 0, 1, _fv_616)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_617), blk_new(e, 0, 0, 0, 1, _fv_618))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_619), blk_new(e, 0, 0, 0, 1, _fv_620)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_621), blk_new(e, 0, 0, 0, 1, _fv_622)))));
      e.mem[_nd_123 + 1] = rfc_seal(e, 104ull);
      _o_304 = term_ctr(CID_OWNED, _nd_123);
    }
    Term _fv_623[2];
    _fv_623[0] = _o_303;
    _fv_623[1] = _o_304;
    Term _fv_624[1];
    _fv_624[0] = 105000ull;
    Term _fv_625[1];
    _fv_625[0] = 105001ull;
    Term _fv_626[1];
    _fv_626[0] = 105002ull;
    Term _fv_627[1];
    _fv_627[0] = 105003ull;
    Term _fv_628[1];
    _fv_628[0] = 105004ull;
    Term _fv_629[1];
    _fv_629[0] = 105005ull;
    Term _fv_630[1];
    _fv_630[0] = 105006ull;
    Term _fv_631[1];
    _fv_631[0] = 105007ull;
    u32 _o_305 = 0;
    Term _o_306 = 0;
    Term _t_172 = 1;
    if (_t_172 == 0) {
      _o_305 = 0;
    } else {
      _o_305 = 1;
      u64 _nd_124 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_124 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_624), blk_new(e, 0, 0, 0, 1, _fv_625)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_626), blk_new(e, 0, 0, 0, 1, _fv_627))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_628), blk_new(e, 0, 0, 0, 1, _fv_629)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_630), blk_new(e, 0, 0, 0, 1, _fv_631)))));
      e.mem[_nd_124 + 1] = rfc_seal(e, 105ull);
      _o_306 = term_ctr(CID_OWNED, _nd_124);
    }
    Term _fv_632[2];
    _fv_632[0] = _o_305;
    _fv_632[1] = _o_306;
    Term _fv_633[1];
    _fv_633[0] = 106000ull;
    Term _fv_634[1];
    _fv_634[0] = 106001ull;
    Term _fv_635[1];
    _fv_635[0] = 106002ull;
    Term _fv_636[1];
    _fv_636[0] = 106003ull;
    Term _fv_637[1];
    _fv_637[0] = 106004ull;
    Term _fv_638[1];
    _fv_638[0] = 106005ull;
    Term _fv_639[1];
    _fv_639[0] = 106006ull;
    Term _fv_640[1];
    _fv_640[0] = 106007ull;
    u32 _o_307 = 0;
    Term _o_308 = 0;
    Term _t_173 = 1;
    if (_t_173 == 0) {
      _o_307 = 0;
    } else {
      _o_307 = 1;
      u64 _nd_125 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_125 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_633), blk_new(e, 0, 0, 0, 1, _fv_634)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_635), blk_new(e, 0, 0, 0, 1, _fv_636))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_637), blk_new(e, 0, 0, 0, 1, _fv_638)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_639), blk_new(e, 0, 0, 0, 1, _fv_640)))));
      e.mem[_nd_125 + 1] = rfc_seal(e, 106ull);
      _o_308 = term_ctr(CID_OWNED, _nd_125);
    }
    Term _fv_641[2];
    _fv_641[0] = _o_307;
    _fv_641[1] = _o_308;
    Term _fv_642[1];
    _fv_642[0] = 107000ull;
    Term _fv_643[1];
    _fv_643[0] = 107001ull;
    Term _fv_644[1];
    _fv_644[0] = 107002ull;
    Term _fv_645[1];
    _fv_645[0] = 107003ull;
    Term _fv_646[1];
    _fv_646[0] = 107004ull;
    Term _fv_647[1];
    _fv_647[0] = 107005ull;
    Term _fv_648[1];
    _fv_648[0] = 107006ull;
    Term _fv_649[1];
    _fv_649[0] = 107007ull;
    u32 _o_309 = 0;
    Term _o_310 = 0;
    Term _t_174 = 1;
    if (_t_174 == 0) {
      _o_309 = 0;
    } else {
      _o_309 = 1;
      u64 _nd_126 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_126 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_642), blk_new(e, 0, 0, 0, 1, _fv_643)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_644), blk_new(e, 0, 0, 0, 1, _fv_645))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_646), blk_new(e, 0, 0, 0, 1, _fv_647)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_648), blk_new(e, 0, 0, 0, 1, _fv_649)))));
      e.mem[_nd_126 + 1] = rfc_seal(e, 107ull);
      _o_310 = term_ctr(CID_OWNED, _nd_126);
    }
    Term _fv_650[2];
    _fv_650[0] = _o_309;
    _fv_650[1] = _o_310;
    Term _fv_651[1];
    _fv_651[0] = 108000ull;
    Term _fv_652[1];
    _fv_652[0] = 108001ull;
    Term _fv_653[1];
    _fv_653[0] = 108002ull;
    Term _fv_654[1];
    _fv_654[0] = 108003ull;
    Term _fv_655[1];
    _fv_655[0] = 108004ull;
    Term _fv_656[1];
    _fv_656[0] = 108005ull;
    Term _fv_657[1];
    _fv_657[0] = 108006ull;
    Term _fv_658[1];
    _fv_658[0] = 108007ull;
    u32 _o_311 = 0;
    Term _o_312 = 0;
    Term _t_175 = 1;
    if (_t_175 == 0) {
      _o_311 = 0;
    } else {
      _o_311 = 1;
      u64 _nd_127 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_127 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_651), blk_new(e, 0, 0, 0, 1, _fv_652)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_653), blk_new(e, 0, 0, 0, 1, _fv_654))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_655), blk_new(e, 0, 0, 0, 1, _fv_656)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_657), blk_new(e, 0, 0, 0, 1, _fv_658)))));
      e.mem[_nd_127 + 1] = rfc_seal(e, 108ull);
      _o_312 = term_ctr(CID_OWNED, _nd_127);
    }
    Term _fv_659[2];
    _fv_659[0] = _o_311;
    _fv_659[1] = _o_312;
    Term _fv_660[1];
    _fv_660[0] = 1;
    Term _fv_661[1];
    _fv_661[0] = 1;
    Term _fv_662[1];
    _fv_662[0] = 0;
    Term _fv_663[1];
    _fv_663[0] = 1;
    Term _fv_664[1];
    _fv_664[0] = 1;
    Term _fv_665[1];
    _fv_665[0] = 1;
    Term _fv_666[1];
    _fv_666[0] = 1;
    Term _fv_667[1];
    _fv_667[0] = 1;
    u32 _o_313 = 0;
    Term _o_314 = 0;
    Term _t_176 = 1;
    if (_t_176 == 0) {
      _o_313 = 0;
    } else {
      _o_313 = 1;
      _o_314 = term_pak(CID_UNIT, 0);
    }
    Term _fv_668[2];
    _fv_668[0] = _o_313;
    _fv_668[1] = _o_314;
    u32 _o_315 = 0;
    Term _o_316 = 0;
    Term _t_177 = 0;
    if (_t_177 == 0) {
      _o_315 = 0;
    } else {
      _o_315 = 1;
      _o_316 = term_pak(CID_UNIT, 0);
    }
    Term _fv_669[2];
    _fv_669[0] = _o_315;
    _fv_669[1] = _o_316;
    u32 _o_317 = 0;
    Term _o_318 = 0;
    Term _t_178 = 1;
    if (_t_178 == 0) {
      _o_317 = 0;
    } else {
      _o_317 = 1;
      _o_318 = term_pak(CID_UNIT, 0);
    }
    Term _fv_670[2];
    _fv_670[0] = _o_317;
    _fv_670[1] = _o_318;
    u32 _o_319 = 0;
    Term _o_320 = 0;
    Term _t_179 = 0;
    if (_t_179 == 0) {
      _o_319 = 0;
    } else {
      _o_319 = 1;
      _o_320 = term_pak(CID_UNIT, 0);
    }
    Term _fv_671[2];
    _fv_671[0] = _o_319;
    _fv_671[1] = _o_320;
    u32 _o_321 = 0;
    Term _o_322 = 0;
    Term _t_180 = 1;
    if (_t_180 == 0) {
      _o_321 = 0;
    } else {
      _o_321 = 1;
      _o_322 = term_pak(CID_UNIT, 0);
    }
    Term _fv_672[2];
    _fv_672[0] = _o_321;
    _fv_672[1] = _o_322;
    u32 _o_323 = 0;
    Term _o_324 = 0;
    Term _t_181 = 0;
    if (_t_181 == 0) {
      _o_323 = 0;
    } else {
      _o_323 = 1;
      _o_324 = term_pak(CID_UNIT, 0);
    }
    Term _fv_673[2];
    _fv_673[0] = _o_323;
    _fv_673[1] = _o_324;
    u32 _o_325 = 0;
    Term _o_326 = 0;
    Term _t_182 = 1;
    if (_t_182 == 0) {
      _o_325 = 0;
    } else {
      _o_325 = 1;
      _o_326 = term_pak(CID_UNIT, 0);
    }
    Term _fv_674[2];
    _fv_674[0] = _o_325;
    _fv_674[1] = _o_326;
    u32 _o_327 = 0;
    Term _o_328 = 0;
    Term _t_183 = 0;
    if (_t_183 == 0) {
      _o_327 = 0;
    } else {
      _o_327 = 1;
      _o_328 = term_pak(CID_UNIT, 0);
    }
    Term _fv_675[2];
    _fv_675[0] = _o_327;
    _fv_675[1] = _o_328;
    Term _fv_676[1];
    _fv_676[0] = 100ull;
    Term _fv_677[1];
    _fv_677[0] = 101ull;
    Term _fv_678[1];
    _fv_678[0] = 102ull;
    Term _fv_679[1];
    _fv_679[0] = 103ull;
    Term _fv_680[1];
    _fv_680[0] = 104ull;
    Term _fv_681[1];
    _fv_681[0] = 105ull;
    Term _fv_682[1];
    _fv_682[0] = 106ull;
    Term _fv_683[1];
    _fv_683[0] = 107ull;
    Term _fv_684[1];
    _fv_684[0] = 200ull;
    Term _fv_685[1];
    _fv_685[0] = 201ull;
    Term _fv_686[1];
    _fv_686[0] = 202ull;
    Term _fv_687[1];
    _fv_687[0] = 203ull;
    Term _fv_688[1];
    _fv_688[0] = 204ull;
    Term _fv_689[1];
    _fv_689[0] = 205ull;
    Term _fv_690[1];
    _fv_690[0] = 206ull;
    Term _fv_691[1];
    _fv_691[0] = 207ull;
    Term _v_702 = 0;
    Term _v_703 = 0;
    Term _v_704 = 0;
    Term _v_705 = 0;
    Term _v_706 = 0;
    Term _v_707 = 0;
    u32 _v_708 = 0;
    Term _v_709 = 0;
    u32 _v_710 = 0;
    Term _v_711 = 0;
    Term _o_329[10];
    Term _a_130 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_532), blk_new(e, 1, 0, 1, 2, _fv_533)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_542), blk_new(e, 1, 0, 1, 2, _fv_551))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_560), blk_new(e, 1, 0, 1, 2, _fv_569)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_578), blk_new(e, 1, 0, 1, 2, _fv_587))));
    Term _a_131 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_596), blk_new(e, 1, 0, 1, 2, _fv_605)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_614), blk_new(e, 1, 0, 1, 2, _fv_623))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_632), blk_new(e, 1, 0, 1, 2, _fv_641)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_650), blk_new(e, 1, 0, 1, 2, _fv_659))));
    Term _a_132 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_660), blk_new(e, 0, 0, 0, 1, _fv_661)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_662), blk_new(e, 0, 0, 0, 1, _fv_663))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_664), blk_new(e, 0, 0, 0, 1, _fv_665)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_666), blk_new(e, 0, 0, 0, 1, _fv_667))));
    Term _a_133 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_668), blk_new(e, 1, 0, 1, 2, _fv_669)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_670), blk_new(e, 1, 0, 1, 2, _fv_671))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_672), blk_new(e, 1, 0, 1, 2, _fv_673)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_674), blk_new(e, 1, 0, 1, 2, _fv_675))));
    Term _a_134 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_676), blk_new(e, 0, 0, 0, 1, _fv_677)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_678), blk_new(e, 0, 0, 0, 1, _fv_679))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_680), blk_new(e, 0, 0, 0, 1, _fv_681)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_682), blk_new(e, 0, 0, 0, 1, _fv_683))));
    Term _a_135 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_684), blk_new(e, 0, 0, 0, 1, _fv_685)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_686), blk_new(e, 0, 0, 0, 1, _fv_687))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_688), blk_new(e, 0, 0, 0, 1, _fv_689)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_690), blk_new(e, 0, 0, 0, 1, _fv_691))));
    Term _a_136 = term_pak(CID_NIL, 0);
    if (spin_19(e, _o_329, ((u64)7ull), 1ull, 8ull, 3ull, 7ull, 1, 7ull, _a_130, blk_loc(e.mem, _a_130), _a_131, blk_loc(e.mem, _a_131), _a_132, blk_loc(e.mem, _a_132), _a_133, blk_loc(e.mem, _a_133), _a_134, blk_loc(e.mem, _a_134), _a_135, blk_loc(e.mem, _a_135), _a_136, blk_loc(e.mem, _a_136)) == 0) {
      return 0;
    }
    _v_702 = _o_329[0];
    _v_703 = _o_329[1];
    _v_704 = _o_329[2];
    _v_705 = _o_329[3];
    _v_706 = _o_329[4];
    _v_707 = _o_329[5];
    _v_708 = _o_329[6];
    _v_709 = _o_329[7];
    _v_710 = _o_329[8];
    _v_711 = _o_329[9];
    _v_692 = _v_702;
    _v_693 = _v_703;
    _v_694 = _v_704;
    _v_695 = _v_705;
    _v_696 = _v_706;
    _v_697 = _v_707;
    _v_698 = _v_708;
    _v_699 = _v_709;
    _v_700 = _v_710;
    _v_701 = _v_711;
    u32 _v_712 = 0;
    u32 _v_713 = 0;
    Term _v_714 = 0;
    Term _v_715 = 0;
    Term _v_716 = 0;
    Term _v_717 = 0;
    Term _v_718 = 0;
    Term _v_719 = 0;
    u32 _v_720 = 0;
    Term _v_721 = 0;
    u32 _v_722 = 0;
    Term _v_723 = 0;
    u32 _v_724 = 0;
    Term _v_725 = 0;
    Term _v_726 = 0;
    Term _v_727 = 0;
    Term _o_330[16];
    Term _a_137 = term_pak(CID_NIL, 0);
    Term _a_138 = term_ctr(CID_OWNED, _nd_111);
    Term _a_139 = 123ull;
    if (spin_21(e, _o_330, 7ull, 999ull, _a_137, blk_loc(e.mem, _a_137), 1, _a_138, blk_loc(e.mem, _a_138), _a_139, blk_loc(e.mem, _a_139), _v_692, blk_loc(e.mem, _v_692), _v_693, blk_loc(e.mem, _v_693), _v_694, blk_loc(e.mem, _v_694), _v_695, blk_loc(e.mem, _v_695), _v_696, blk_loc(e.mem, _v_696), _v_697, blk_loc(e.mem, _v_697), _v_698, _v_699, _v_700, _v_701, blk_loc(e.mem, _v_701)) == 0) {
      return 0;
    }
    _v_712 = _o_330[0];
    _v_713 = _o_330[1];
    _v_714 = _o_330[2];
    _v_715 = _o_330[3];
    _v_716 = _o_330[4];
    _v_717 = _o_330[5];
    _v_718 = _o_330[6];
    _v_719 = _o_330[7];
    _v_720 = _o_330[8];
    _v_721 = _o_330[9];
    _v_722 = _o_330[10];
    _v_723 = _o_330[11];
    _v_724 = _o_330[12];
    _v_725 = _o_330[13];
    _v_726 = _o_330[14];
    _v_727 = _o_330[15];
    _v_676 = _v_712;
    _v_677 = _v_713;
    _v_678 = _v_714;
    _v_679 = _v_715;
    _v_680 = _v_716;
    _v_681 = _v_717;
    _v_682 = _v_718;
    _v_683 = _v_719;
    _v_684 = _v_720;
    _v_685 = _v_721;
    _v_686 = _v_722;
    _v_687 = _v_723;
    _v_688 = _v_724;
    _v_689 = _v_725;
    _v_690 = _v_726;
    _v_691 = _v_727;
    u32 _o_331 = 0;
    Term _o_332 = 0;
    u32 _o_333 = 0;
    if (_v_688 == 0) {
      _o_331 = 0;
    } else {
      _o_331 = 1;
      Term _fb_13[2];
      u64 _sp_13 = ctr_take(e, _v_689, 2, _fb_13);
      Term _f_26 = _fb_13[0];
      u32 _f_27 = _fb_13[1];
      spare_free(e, cls_fit(2), _sp_13);
      _o_332 = _f_26;
      _o_333 = _f_27;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K263;
      WL_PUSHN(1);
    } else {
      u64 _t_184 = task_node(e, FID_MAIN_K263, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K263, _t_184);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_185 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_185 + 0] = _v_676;
      e.mem[_t_185 + 1] = _v_677;
      e.mem[_t_185 + 2] = _v_678;
      e.mem[_t_185 + 3] = _v_679;
      e.mem[_t_185 + 4] = _v_680;
      e.mem[_t_185 + 5] = _v_681;
      e.mem[_t_185 + 6] = _v_682;
      e.mem[_t_185 + 7] = _v_683;
      e.mem[_t_185 + 8] = _v_684;
      e.mem[_t_185 + 9] = _v_685;
      e.mem[_t_185 + 10] = _v_686;
      e.mem[_t_185 + 11] = _v_687;
      e.mem[_t_185 + 12] = _o_331;
      e.mem[_t_185 + 13] = _o_332;
      e.mem[_t_185 + 14] = _o_333;
      e.mem[_t_185 + 15] = _v_690;
      e.mem[_t_185 + 16] = _v_691;
      return term_tsk(FID_SNAPSHOT, _t_185);
    }
    r0 = _v_676;
    r1 = _v_677;
    r2 = _v_678;
    r3 = _v_679;
    r4 = _v_680;
    r5 = _v_681;
    r6 = _v_682;
    r7 = _v_683;
    r8 = _v_684;
    r9 = _v_685;
    r10 = _v_686;
    r11 = _v_687;
    r12 = _o_331;
    r13 = _o_332;
    r14 = _o_333;
    r15 = _v_690;
    r16 = _v_691;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K263)
  {
    Term _h_39 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K264;
      WL_PUSHN(1);
    } else {
      u64 _t_186 = task_node(e, FID_MAIN_K264, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K264, _t_186);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_187 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_187 + 0] = term_ctr(CID_SCON, STAT_OFF + 180);
      e.mem[_t_187 + 1] = _h_39;
      return term_tsk(FID_STRING_APPEND, _t_187);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 180);
    r1 = _h_39;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K264)
  {
    Term _h_40 = r0;
    WL_OPEN
    u64 _nd_128 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_128 + 0] = _h_40;
    r0 = term_clo(FID_MAIN_C265, _nd_128);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C265)
  {
    Term _h_41 = r0;
    Term _x_26 = r1;
    WL_OPEN
    u64 _nd_129 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_129 + 0] = _h_41;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_459 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_459 + 0] = term_clo(FID_IO_PRINT, _nd_129);
      e.mem[_t_459 + 1] = term_clo(FID_MAIN_C266, 0);
      e.mem[_t_459 + 2] = _x_26;
      return term_tsk(FID_IO_BIND, _t_459);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_129);
    r1 = term_clo(FID_MAIN_C266, 0);
    r2 = _x_26;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C266)
  {
    Term _x_27 = r0;
    WL_OPEN
    u32 _v_728 = 0;
    u32 _v_729 = 0;
    Term _v_730 = 0;
    Term _v_731 = 0;
    Term _v_732 = 0;
    Term _v_733 = 0;
    Term _v_734 = 0;
    Term _v_735 = 0;
    u32 _v_736 = 0;
    Term _v_737 = 0;
    u32 _v_738 = 0;
    Term _v_739 = 0;
    u32 _v_740 = 0;
    Term _v_741 = 0;
    Term _v_742 = 0;
    Term _v_743 = 0;
    Term _fv_692[1];
    _fv_692[0] = 999000ull;
    Term _fv_693[1];
    _fv_693[0] = 999001ull;
    Term _fv_694[1];
    _fv_694[0] = 999002ull;
    Term _fv_695[1];
    _fv_695[0] = 999003ull;
    Term _fv_696[1];
    _fv_696[0] = 999004ull;
    Term _fv_697[1];
    _fv_697[0] = 999005ull;
    Term _fv_698[1];
    _fv_698[0] = 999006ull;
    Term _fv_699[1];
    _fv_699[0] = 999007ull;
    u64 _nd_130 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_130 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_692), blk_new(e, 0, 0, 0, 1, _fv_693)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_694), blk_new(e, 0, 0, 0, 1, _fv_695))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_696), blk_new(e, 0, 0, 0, 1, _fv_697)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_698), blk_new(e, 0, 0, 0, 1, _fv_699)))));
    e.mem[_nd_130 + 1] = rfc_seal(e, 999ull);
    Term _v_744 = 0;
    Term _v_745 = 0;
    Term _v_746 = 0;
    Term _v_747 = 0;
    Term _v_748 = 0;
    Term _v_749 = 0;
    u32 _v_750 = 0;
    Term _v_751 = 0;
    u32 _v_752 = 0;
    Term _v_753 = 0;
    Term _fv_700[1];
    _fv_700[0] = 1000ull;
    Term _fv_701[1];
    _fv_701[0] = 1001ull;
    Term _fv_702[1];
    _fv_702[0] = 1002ull;
    Term _fv_703[1];
    _fv_703[0] = 1003ull;
    Term _fv_704[1];
    _fv_704[0] = 1004ull;
    Term _fv_705[1];
    _fv_705[0] = 1005ull;
    Term _fv_706[1];
    _fv_706[0] = 1006ull;
    Term _fv_707[1];
    _fv_707[0] = 1007ull;
    u32 _o_334 = 0;
    Term _o_335 = 0;
    Term _t_188 = 1;
    if (_t_188 == 0) {
      _o_334 = 0;
    } else {
      _o_334 = 1;
      u64 _nd_131 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_131 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_700), blk_new(e, 0, 0, 0, 1, _fv_701)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_702), blk_new(e, 0, 0, 0, 1, _fv_703))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_704), blk_new(e, 0, 0, 0, 1, _fv_705)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_706), blk_new(e, 0, 0, 0, 1, _fv_707)))));
      e.mem[_nd_131 + 1] = rfc_seal(e, 1ull);
      _o_335 = term_ctr(CID_OWNED, _nd_131);
    }
    Term _fv_708[2];
    _fv_708[0] = _o_334;
    _fv_708[1] = _o_335;
    u32 _o_336 = 0;
    Term _o_337 = 0;
    Term _t_189 = 0;
    if (_t_189 == 0) {
      _o_336 = 0;
    } else {
      _o_336 = 1;
      u64 _nd_132 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_132 + 0] = rfc_seal(e, 0);
      e.mem[_nd_132 + 1] = rfc_seal(e, 0);
      _o_337 = term_ctr(CID_OWNED, _nd_132);
    }
    Term _fv_709[2];
    _fv_709[0] = _o_336;
    _fv_709[1] = _o_337;
    Term _fv_710[1];
    _fv_710[0] = 3000ull;
    Term _fv_711[1];
    _fv_711[0] = 3001ull;
    Term _fv_712[1];
    _fv_712[0] = 3002ull;
    Term _fv_713[1];
    _fv_713[0] = 3003ull;
    Term _fv_714[1];
    _fv_714[0] = 3004ull;
    Term _fv_715[1];
    _fv_715[0] = 3005ull;
    Term _fv_716[1];
    _fv_716[0] = 3006ull;
    Term _fv_717[1];
    _fv_717[0] = 3007ull;
    u32 _o_338 = 0;
    Term _o_339 = 0;
    Term _t_190 = 1;
    if (_t_190 == 0) {
      _o_338 = 0;
    } else {
      _o_338 = 1;
      u64 _nd_133 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_133 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_710), blk_new(e, 0, 0, 0, 1, _fv_711)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_712), blk_new(e, 0, 0, 0, 1, _fv_713))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_714), blk_new(e, 0, 0, 0, 1, _fv_715)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_716), blk_new(e, 0, 0, 0, 1, _fv_717)))));
      e.mem[_nd_133 + 1] = rfc_seal(e, 3ull);
      _o_339 = term_ctr(CID_OWNED, _nd_133);
    }
    Term _fv_718[2];
    _fv_718[0] = _o_338;
    _fv_718[1] = _o_339;
    Term _fv_719[1];
    _fv_719[0] = 4000ull;
    Term _fv_720[1];
    _fv_720[0] = 4001ull;
    Term _fv_721[1];
    _fv_721[0] = 4002ull;
    Term _fv_722[1];
    _fv_722[0] = 4003ull;
    Term _fv_723[1];
    _fv_723[0] = 4004ull;
    Term _fv_724[1];
    _fv_724[0] = 4005ull;
    Term _fv_725[1];
    _fv_725[0] = 4006ull;
    Term _fv_726[1];
    _fv_726[0] = 4007ull;
    u32 _o_340 = 0;
    Term _o_341 = 0;
    Term _t_191 = 1;
    if (_t_191 == 0) {
      _o_340 = 0;
    } else {
      _o_340 = 1;
      u64 _nd_134 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_134 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_719), blk_new(e, 0, 0, 0, 1, _fv_720)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_721), blk_new(e, 0, 0, 0, 1, _fv_722))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_723), blk_new(e, 0, 0, 0, 1, _fv_724)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_725), blk_new(e, 0, 0, 0, 1, _fv_726)))));
      e.mem[_nd_134 + 1] = rfc_seal(e, 4ull);
      _o_341 = term_ctr(CID_OWNED, _nd_134);
    }
    Term _fv_727[2];
    _fv_727[0] = _o_340;
    _fv_727[1] = _o_341;
    Term _fv_728[1];
    _fv_728[0] = 5000ull;
    Term _fv_729[1];
    _fv_729[0] = 5001ull;
    Term _fv_730[1];
    _fv_730[0] = 5002ull;
    Term _fv_731[1];
    _fv_731[0] = 5003ull;
    Term _fv_732[1];
    _fv_732[0] = 5004ull;
    Term _fv_733[1];
    _fv_733[0] = 5005ull;
    Term _fv_734[1];
    _fv_734[0] = 5006ull;
    Term _fv_735[1];
    _fv_735[0] = 5007ull;
    u32 _o_342 = 0;
    Term _o_343 = 0;
    Term _t_192 = 1;
    if (_t_192 == 0) {
      _o_342 = 0;
    } else {
      _o_342 = 1;
      u64 _nd_135 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_135 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_728), blk_new(e, 0, 0, 0, 1, _fv_729)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_730), blk_new(e, 0, 0, 0, 1, _fv_731))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_732), blk_new(e, 0, 0, 0, 1, _fv_733)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_734), blk_new(e, 0, 0, 0, 1, _fv_735)))));
      e.mem[_nd_135 + 1] = rfc_seal(e, 5ull);
      _o_343 = term_ctr(CID_OWNED, _nd_135);
    }
    Term _fv_736[2];
    _fv_736[0] = _o_342;
    _fv_736[1] = _o_343;
    Term _fv_737[1];
    _fv_737[0] = 6000ull;
    Term _fv_738[1];
    _fv_738[0] = 6001ull;
    Term _fv_739[1];
    _fv_739[0] = 6002ull;
    Term _fv_740[1];
    _fv_740[0] = 6003ull;
    Term _fv_741[1];
    _fv_741[0] = 6004ull;
    Term _fv_742[1];
    _fv_742[0] = 6005ull;
    Term _fv_743[1];
    _fv_743[0] = 6006ull;
    Term _fv_744[1];
    _fv_744[0] = 6007ull;
    u32 _o_344 = 0;
    Term _o_345 = 0;
    Term _t_193 = 1;
    if (_t_193 == 0) {
      _o_344 = 0;
    } else {
      _o_344 = 1;
      u64 _nd_136 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_136 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_737), blk_new(e, 0, 0, 0, 1, _fv_738)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_739), blk_new(e, 0, 0, 0, 1, _fv_740))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_741), blk_new(e, 0, 0, 0, 1, _fv_742)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_743), blk_new(e, 0, 0, 0, 1, _fv_744)))));
      e.mem[_nd_136 + 1] = rfc_seal(e, 6ull);
      _o_345 = term_ctr(CID_OWNED, _nd_136);
    }
    Term _fv_745[2];
    _fv_745[0] = _o_344;
    _fv_745[1] = _o_345;
    Term _fv_746[1];
    _fv_746[0] = 7000ull;
    Term _fv_747[1];
    _fv_747[0] = 7001ull;
    Term _fv_748[1];
    _fv_748[0] = 7002ull;
    Term _fv_749[1];
    _fv_749[0] = 7003ull;
    Term _fv_750[1];
    _fv_750[0] = 7004ull;
    Term _fv_751[1];
    _fv_751[0] = 7005ull;
    Term _fv_752[1];
    _fv_752[0] = 7006ull;
    Term _fv_753[1];
    _fv_753[0] = 7007ull;
    u32 _o_346 = 0;
    Term _o_347 = 0;
    Term _t_194 = 1;
    if (_t_194 == 0) {
      _o_346 = 0;
    } else {
      _o_346 = 1;
      u64 _nd_137 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_137 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_746), blk_new(e, 0, 0, 0, 1, _fv_747)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_748), blk_new(e, 0, 0, 0, 1, _fv_749))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_750), blk_new(e, 0, 0, 0, 1, _fv_751)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_752), blk_new(e, 0, 0, 0, 1, _fv_753)))));
      e.mem[_nd_137 + 1] = rfc_seal(e, 7ull);
      _o_347 = term_ctr(CID_OWNED, _nd_137);
    }
    Term _fv_754[2];
    _fv_754[0] = _o_346;
    _fv_754[1] = _o_347;
    Term _fv_755[1];
    _fv_755[0] = 8000ull;
    Term _fv_756[1];
    _fv_756[0] = 8001ull;
    Term _fv_757[1];
    _fv_757[0] = 8002ull;
    Term _fv_758[1];
    _fv_758[0] = 8003ull;
    Term _fv_759[1];
    _fv_759[0] = 8004ull;
    Term _fv_760[1];
    _fv_760[0] = 8005ull;
    Term _fv_761[1];
    _fv_761[0] = 8006ull;
    Term _fv_762[1];
    _fv_762[0] = 8007ull;
    u32 _o_348 = 0;
    Term _o_349 = 0;
    Term _t_195 = 1;
    if (_t_195 == 0) {
      _o_348 = 0;
    } else {
      _o_348 = 1;
      u64 _nd_138 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_138 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_755), blk_new(e, 0, 0, 0, 1, _fv_756)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_757), blk_new(e, 0, 0, 0, 1, _fv_758))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_759), blk_new(e, 0, 0, 0, 1, _fv_760)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_761), blk_new(e, 0, 0, 0, 1, _fv_762)))));
      e.mem[_nd_138 + 1] = rfc_seal(e, 8ull);
      _o_349 = term_ctr(CID_OWNED, _nd_138);
    }
    Term _fv_763[2];
    _fv_763[0] = _o_348;
    _fv_763[1] = _o_349;
    Term _fv_764[1];
    _fv_764[0] = 101000ull;
    Term _fv_765[1];
    _fv_765[0] = 101001ull;
    Term _fv_766[1];
    _fv_766[0] = 101002ull;
    Term _fv_767[1];
    _fv_767[0] = 101003ull;
    Term _fv_768[1];
    _fv_768[0] = 101004ull;
    Term _fv_769[1];
    _fv_769[0] = 101005ull;
    Term _fv_770[1];
    _fv_770[0] = 101006ull;
    Term _fv_771[1];
    _fv_771[0] = 101007ull;
    u32 _o_350 = 0;
    Term _o_351 = 0;
    Term _t_196 = 1;
    if (_t_196 == 0) {
      _o_350 = 0;
    } else {
      _o_350 = 1;
      u64 _nd_139 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_139 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_764), blk_new(e, 0, 0, 0, 1, _fv_765)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_766), blk_new(e, 0, 0, 0, 1, _fv_767))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_768), blk_new(e, 0, 0, 0, 1, _fv_769)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_770), blk_new(e, 0, 0, 0, 1, _fv_771)))));
      e.mem[_nd_139 + 1] = rfc_seal(e, 101ull);
      _o_351 = term_ctr(CID_OWNED, _nd_139);
    }
    Term _fv_772[2];
    _fv_772[0] = _o_350;
    _fv_772[1] = _o_351;
    Term _fv_773[1];
    _fv_773[0] = 102000ull;
    Term _fv_774[1];
    _fv_774[0] = 102001ull;
    Term _fv_775[1];
    _fv_775[0] = 102002ull;
    Term _fv_776[1];
    _fv_776[0] = 102003ull;
    Term _fv_777[1];
    _fv_777[0] = 102004ull;
    Term _fv_778[1];
    _fv_778[0] = 102005ull;
    Term _fv_779[1];
    _fv_779[0] = 102006ull;
    Term _fv_780[1];
    _fv_780[0] = 102007ull;
    u32 _o_352 = 0;
    Term _o_353 = 0;
    Term _t_197 = 1;
    if (_t_197 == 0) {
      _o_352 = 0;
    } else {
      _o_352 = 1;
      u64 _nd_140 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_140 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_773), blk_new(e, 0, 0, 0, 1, _fv_774)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_775), blk_new(e, 0, 0, 0, 1, _fv_776))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_777), blk_new(e, 0, 0, 0, 1, _fv_778)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_779), blk_new(e, 0, 0, 0, 1, _fv_780)))));
      e.mem[_nd_140 + 1] = rfc_seal(e, 102ull);
      _o_353 = term_ctr(CID_OWNED, _nd_140);
    }
    Term _fv_781[2];
    _fv_781[0] = _o_352;
    _fv_781[1] = _o_353;
    Term _fv_782[1];
    _fv_782[0] = 103000ull;
    Term _fv_783[1];
    _fv_783[0] = 103001ull;
    Term _fv_784[1];
    _fv_784[0] = 103002ull;
    Term _fv_785[1];
    _fv_785[0] = 103003ull;
    Term _fv_786[1];
    _fv_786[0] = 103004ull;
    Term _fv_787[1];
    _fv_787[0] = 103005ull;
    Term _fv_788[1];
    _fv_788[0] = 103006ull;
    Term _fv_789[1];
    _fv_789[0] = 103007ull;
    u32 _o_354 = 0;
    Term _o_355 = 0;
    Term _t_198 = 1;
    if (_t_198 == 0) {
      _o_354 = 0;
    } else {
      _o_354 = 1;
      u64 _nd_141 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_141 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_782), blk_new(e, 0, 0, 0, 1, _fv_783)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_784), blk_new(e, 0, 0, 0, 1, _fv_785))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_786), blk_new(e, 0, 0, 0, 1, _fv_787)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_788), blk_new(e, 0, 0, 0, 1, _fv_789)))));
      e.mem[_nd_141 + 1] = rfc_seal(e, 103ull);
      _o_355 = term_ctr(CID_OWNED, _nd_141);
    }
    Term _fv_790[2];
    _fv_790[0] = _o_354;
    _fv_790[1] = _o_355;
    Term _fv_791[1];
    _fv_791[0] = 104000ull;
    Term _fv_792[1];
    _fv_792[0] = 104001ull;
    Term _fv_793[1];
    _fv_793[0] = 104002ull;
    Term _fv_794[1];
    _fv_794[0] = 104003ull;
    Term _fv_795[1];
    _fv_795[0] = 104004ull;
    Term _fv_796[1];
    _fv_796[0] = 104005ull;
    Term _fv_797[1];
    _fv_797[0] = 104006ull;
    Term _fv_798[1];
    _fv_798[0] = 104007ull;
    u32 _o_356 = 0;
    Term _o_357 = 0;
    Term _t_199 = 1;
    if (_t_199 == 0) {
      _o_356 = 0;
    } else {
      _o_356 = 1;
      u64 _nd_142 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_142 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_791), blk_new(e, 0, 0, 0, 1, _fv_792)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_793), blk_new(e, 0, 0, 0, 1, _fv_794))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_795), blk_new(e, 0, 0, 0, 1, _fv_796)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_797), blk_new(e, 0, 0, 0, 1, _fv_798)))));
      e.mem[_nd_142 + 1] = rfc_seal(e, 104ull);
      _o_357 = term_ctr(CID_OWNED, _nd_142);
    }
    Term _fv_799[2];
    _fv_799[0] = _o_356;
    _fv_799[1] = _o_357;
    Term _fv_800[1];
    _fv_800[0] = 105000ull;
    Term _fv_801[1];
    _fv_801[0] = 105001ull;
    Term _fv_802[1];
    _fv_802[0] = 105002ull;
    Term _fv_803[1];
    _fv_803[0] = 105003ull;
    Term _fv_804[1];
    _fv_804[0] = 105004ull;
    Term _fv_805[1];
    _fv_805[0] = 105005ull;
    Term _fv_806[1];
    _fv_806[0] = 105006ull;
    Term _fv_807[1];
    _fv_807[0] = 105007ull;
    u32 _o_358 = 0;
    Term _o_359 = 0;
    Term _t_200 = 1;
    if (_t_200 == 0) {
      _o_358 = 0;
    } else {
      _o_358 = 1;
      u64 _nd_143 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_143 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_800), blk_new(e, 0, 0, 0, 1, _fv_801)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_802), blk_new(e, 0, 0, 0, 1, _fv_803))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_804), blk_new(e, 0, 0, 0, 1, _fv_805)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_806), blk_new(e, 0, 0, 0, 1, _fv_807)))));
      e.mem[_nd_143 + 1] = rfc_seal(e, 105ull);
      _o_359 = term_ctr(CID_OWNED, _nd_143);
    }
    Term _fv_808[2];
    _fv_808[0] = _o_358;
    _fv_808[1] = _o_359;
    Term _fv_809[1];
    _fv_809[0] = 106000ull;
    Term _fv_810[1];
    _fv_810[0] = 106001ull;
    Term _fv_811[1];
    _fv_811[0] = 106002ull;
    Term _fv_812[1];
    _fv_812[0] = 106003ull;
    Term _fv_813[1];
    _fv_813[0] = 106004ull;
    Term _fv_814[1];
    _fv_814[0] = 106005ull;
    Term _fv_815[1];
    _fv_815[0] = 106006ull;
    Term _fv_816[1];
    _fv_816[0] = 106007ull;
    u32 _o_360 = 0;
    Term _o_361 = 0;
    Term _t_201 = 1;
    if (_t_201 == 0) {
      _o_360 = 0;
    } else {
      _o_360 = 1;
      u64 _nd_144 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_144 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_809), blk_new(e, 0, 0, 0, 1, _fv_810)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_811), blk_new(e, 0, 0, 0, 1, _fv_812))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_813), blk_new(e, 0, 0, 0, 1, _fv_814)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_815), blk_new(e, 0, 0, 0, 1, _fv_816)))));
      e.mem[_nd_144 + 1] = rfc_seal(e, 106ull);
      _o_361 = term_ctr(CID_OWNED, _nd_144);
    }
    Term _fv_817[2];
    _fv_817[0] = _o_360;
    _fv_817[1] = _o_361;
    Term _fv_818[1];
    _fv_818[0] = 107000ull;
    Term _fv_819[1];
    _fv_819[0] = 107001ull;
    Term _fv_820[1];
    _fv_820[0] = 107002ull;
    Term _fv_821[1];
    _fv_821[0] = 107003ull;
    Term _fv_822[1];
    _fv_822[0] = 107004ull;
    Term _fv_823[1];
    _fv_823[0] = 107005ull;
    Term _fv_824[1];
    _fv_824[0] = 107006ull;
    Term _fv_825[1];
    _fv_825[0] = 107007ull;
    u32 _o_362 = 0;
    Term _o_363 = 0;
    Term _t_202 = 1;
    if (_t_202 == 0) {
      _o_362 = 0;
    } else {
      _o_362 = 1;
      u64 _nd_145 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_145 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_818), blk_new(e, 0, 0, 0, 1, _fv_819)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_820), blk_new(e, 0, 0, 0, 1, _fv_821))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_822), blk_new(e, 0, 0, 0, 1, _fv_823)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_824), blk_new(e, 0, 0, 0, 1, _fv_825)))));
      e.mem[_nd_145 + 1] = rfc_seal(e, 107ull);
      _o_363 = term_ctr(CID_OWNED, _nd_145);
    }
    Term _fv_826[2];
    _fv_826[0] = _o_362;
    _fv_826[1] = _o_363;
    Term _fv_827[1];
    _fv_827[0] = 108000ull;
    Term _fv_828[1];
    _fv_828[0] = 108001ull;
    Term _fv_829[1];
    _fv_829[0] = 108002ull;
    Term _fv_830[1];
    _fv_830[0] = 108003ull;
    Term _fv_831[1];
    _fv_831[0] = 108004ull;
    Term _fv_832[1];
    _fv_832[0] = 108005ull;
    Term _fv_833[1];
    _fv_833[0] = 108006ull;
    Term _fv_834[1];
    _fv_834[0] = 108007ull;
    u32 _o_364 = 0;
    Term _o_365 = 0;
    Term _t_203 = 1;
    if (_t_203 == 0) {
      _o_364 = 0;
    } else {
      _o_364 = 1;
      u64 _nd_146 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_146 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_827), blk_new(e, 0, 0, 0, 1, _fv_828)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_829), blk_new(e, 0, 0, 0, 1, _fv_830))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_831), blk_new(e, 0, 0, 0, 1, _fv_832)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_833), blk_new(e, 0, 0, 0, 1, _fv_834)))));
      e.mem[_nd_146 + 1] = rfc_seal(e, 108ull);
      _o_365 = term_ctr(CID_OWNED, _nd_146);
    }
    Term _fv_835[2];
    _fv_835[0] = _o_364;
    _fv_835[1] = _o_365;
    Term _fv_836[1];
    _fv_836[0] = 1;
    Term _fv_837[1];
    _fv_837[0] = 1;
    Term _fv_838[1];
    _fv_838[0] = 0;
    Term _fv_839[1];
    _fv_839[0] = 1;
    Term _fv_840[1];
    _fv_840[0] = 1;
    Term _fv_841[1];
    _fv_841[0] = 1;
    Term _fv_842[1];
    _fv_842[0] = 1;
    Term _fv_843[1];
    _fv_843[0] = 1;
    u32 _o_366 = 0;
    Term _o_367 = 0;
    Term _t_204 = 1;
    if (_t_204 == 0) {
      _o_366 = 0;
    } else {
      _o_366 = 1;
      _o_367 = term_pak(CID_UNIT, 0);
    }
    Term _fv_844[2];
    _fv_844[0] = _o_366;
    _fv_844[1] = _o_367;
    u32 _o_368 = 0;
    Term _o_369 = 0;
    Term _t_205 = 0;
    if (_t_205 == 0) {
      _o_368 = 0;
    } else {
      _o_368 = 1;
      _o_369 = term_pak(CID_UNIT, 0);
    }
    Term _fv_845[2];
    _fv_845[0] = _o_368;
    _fv_845[1] = _o_369;
    u32 _o_370 = 0;
    Term _o_371 = 0;
    Term _t_206 = 1;
    if (_t_206 == 0) {
      _o_370 = 0;
    } else {
      _o_370 = 1;
      _o_371 = term_pak(CID_UNIT, 0);
    }
    Term _fv_846[2];
    _fv_846[0] = _o_370;
    _fv_846[1] = _o_371;
    u32 _o_372 = 0;
    Term _o_373 = 0;
    Term _t_207 = 0;
    if (_t_207 == 0) {
      _o_372 = 0;
    } else {
      _o_372 = 1;
      _o_373 = term_pak(CID_UNIT, 0);
    }
    Term _fv_847[2];
    _fv_847[0] = _o_372;
    _fv_847[1] = _o_373;
    u32 _o_374 = 0;
    Term _o_375 = 0;
    Term _t_208 = 1;
    if (_t_208 == 0) {
      _o_374 = 0;
    } else {
      _o_374 = 1;
      _o_375 = term_pak(CID_UNIT, 0);
    }
    Term _fv_848[2];
    _fv_848[0] = _o_374;
    _fv_848[1] = _o_375;
    u32 _o_376 = 0;
    Term _o_377 = 0;
    Term _t_209 = 0;
    if (_t_209 == 0) {
      _o_376 = 0;
    } else {
      _o_376 = 1;
      _o_377 = term_pak(CID_UNIT, 0);
    }
    Term _fv_849[2];
    _fv_849[0] = _o_376;
    _fv_849[1] = _o_377;
    u32 _o_378 = 0;
    Term _o_379 = 0;
    Term _t_210 = 1;
    if (_t_210 == 0) {
      _o_378 = 0;
    } else {
      _o_378 = 1;
      _o_379 = term_pak(CID_UNIT, 0);
    }
    Term _fv_850[2];
    _fv_850[0] = _o_378;
    _fv_850[1] = _o_379;
    u32 _o_380 = 0;
    Term _o_381 = 0;
    Term _t_211 = 0;
    if (_t_211 == 0) {
      _o_380 = 0;
    } else {
      _o_380 = 1;
      _o_381 = term_pak(CID_UNIT, 0);
    }
    Term _fv_851[2];
    _fv_851[0] = _o_380;
    _fv_851[1] = _o_381;
    Term _fv_852[1];
    _fv_852[0] = 100ull;
    Term _fv_853[1];
    _fv_853[0] = 101ull;
    Term _fv_854[1];
    _fv_854[0] = 102ull;
    Term _fv_855[1];
    _fv_855[0] = 103ull;
    Term _fv_856[1];
    _fv_856[0] = 104ull;
    Term _fv_857[1];
    _fv_857[0] = 105ull;
    Term _fv_858[1];
    _fv_858[0] = 106ull;
    Term _fv_859[1];
    _fv_859[0] = 107ull;
    Term _fv_860[1];
    _fv_860[0] = 200ull;
    Term _fv_861[1];
    _fv_861[0] = 201ull;
    Term _fv_862[1];
    _fv_862[0] = 202ull;
    Term _fv_863[1];
    _fv_863[0] = 203ull;
    Term _fv_864[1];
    _fv_864[0] = 204ull;
    Term _fv_865[1];
    _fv_865[0] = 205ull;
    Term _fv_866[1];
    _fv_866[0] = 206ull;
    Term _fv_867[1];
    _fv_867[0] = 207ull;
    Term _v_754 = 0;
    Term _v_755 = 0;
    Term _v_756 = 0;
    Term _v_757 = 0;
    Term _v_758 = 0;
    Term _v_759 = 0;
    u32 _v_760 = 0;
    Term _v_761 = 0;
    u32 _v_762 = 0;
    Term _v_763 = 0;
    Term _o_382[10];
    Term _a_140 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_708), blk_new(e, 1, 0, 1, 2, _fv_709)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_718), blk_new(e, 1, 0, 1, 2, _fv_727))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_736), blk_new(e, 1, 0, 1, 2, _fv_745)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_754), blk_new(e, 1, 0, 1, 2, _fv_763))));
    Term _a_141 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_772), blk_new(e, 1, 0, 1, 2, _fv_781)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_790), blk_new(e, 1, 0, 1, 2, _fv_799))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_808), blk_new(e, 1, 0, 1, 2, _fv_817)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_826), blk_new(e, 1, 0, 1, 2, _fv_835))));
    Term _a_142 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_836), blk_new(e, 0, 0, 0, 1, _fv_837)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_838), blk_new(e, 0, 0, 0, 1, _fv_839))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_840), blk_new(e, 0, 0, 0, 1, _fv_841)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_842), blk_new(e, 0, 0, 0, 1, _fv_843))));
    Term _a_143 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_844), blk_new(e, 1, 0, 1, 2, _fv_845)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_846), blk_new(e, 1, 0, 1, 2, _fv_847))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_848), blk_new(e, 1, 0, 1, 2, _fv_849)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_850), blk_new(e, 1, 0, 1, 2, _fv_851))));
    Term _a_144 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_852), blk_new(e, 0, 0, 0, 1, _fv_853)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_854), blk_new(e, 0, 0, 0, 1, _fv_855))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_856), blk_new(e, 0, 0, 0, 1, _fv_857)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_858), blk_new(e, 0, 0, 0, 1, _fv_859))));
    Term _a_145 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_860), blk_new(e, 0, 0, 0, 1, _fv_861)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_862), blk_new(e, 0, 0, 0, 1, _fv_863))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_864), blk_new(e, 0, 0, 0, 1, _fv_865)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_866), blk_new(e, 0, 0, 0, 1, _fv_867))));
    Term _a_146 = term_pak(CID_NIL, 0);
    if (spin_19(e, _o_382, ((u64)7ull), 1ull, 8ull, 3ull, 7ull, 2, 7ull, _a_140, blk_loc(e.mem, _a_140), _a_141, blk_loc(e.mem, _a_141), _a_142, blk_loc(e.mem, _a_142), _a_143, blk_loc(e.mem, _a_143), _a_144, blk_loc(e.mem, _a_144), _a_145, blk_loc(e.mem, _a_145), _a_146, blk_loc(e.mem, _a_146)) == 0) {
      return 0;
    }
    _v_754 = _o_382[0];
    _v_755 = _o_382[1];
    _v_756 = _o_382[2];
    _v_757 = _o_382[3];
    _v_758 = _o_382[4];
    _v_759 = _o_382[5];
    _v_760 = _o_382[6];
    _v_761 = _o_382[7];
    _v_762 = _o_382[8];
    _v_763 = _o_382[9];
    _v_744 = _v_754;
    _v_745 = _v_755;
    _v_746 = _v_756;
    _v_747 = _v_757;
    _v_748 = _v_758;
    _v_749 = _v_759;
    _v_750 = _v_760;
    _v_751 = _v_761;
    _v_752 = _v_762;
    _v_753 = _v_763;
    u32 _v_764 = 0;
    u32 _v_765 = 0;
    Term _v_766 = 0;
    Term _v_767 = 0;
    Term _v_768 = 0;
    Term _v_769 = 0;
    Term _v_770 = 0;
    Term _v_771 = 0;
    u32 _v_772 = 0;
    Term _v_773 = 0;
    u32 _v_774 = 0;
    Term _v_775 = 0;
    u32 _v_776 = 0;
    Term _v_777 = 0;
    Term _v_778 = 0;
    Term _v_779 = 0;
    Term _o_383[16];
    Term _a_147 = term_pak(CID_NIL, 0);
    Term _a_148 = term_ctr(CID_OWNED, _nd_130);
    Term _a_149 = 123ull;
    if (spin_21(e, _o_383, 7ull, 999ull, _a_147, blk_loc(e.mem, _a_147), 1, _a_148, blk_loc(e.mem, _a_148), _a_149, blk_loc(e.mem, _a_149), _v_744, blk_loc(e.mem, _v_744), _v_745, blk_loc(e.mem, _v_745), _v_746, blk_loc(e.mem, _v_746), _v_747, blk_loc(e.mem, _v_747), _v_748, blk_loc(e.mem, _v_748), _v_749, blk_loc(e.mem, _v_749), _v_750, _v_751, _v_752, _v_753, blk_loc(e.mem, _v_753)) == 0) {
      return 0;
    }
    _v_764 = _o_383[0];
    _v_765 = _o_383[1];
    _v_766 = _o_383[2];
    _v_767 = _o_383[3];
    _v_768 = _o_383[4];
    _v_769 = _o_383[5];
    _v_770 = _o_383[6];
    _v_771 = _o_383[7];
    _v_772 = _o_383[8];
    _v_773 = _o_383[9];
    _v_774 = _o_383[10];
    _v_775 = _o_383[11];
    _v_776 = _o_383[12];
    _v_777 = _o_383[13];
    _v_778 = _o_383[14];
    _v_779 = _o_383[15];
    _v_728 = _v_764;
    _v_729 = _v_765;
    _v_730 = _v_766;
    _v_731 = _v_767;
    _v_732 = _v_768;
    _v_733 = _v_769;
    _v_734 = _v_770;
    _v_735 = _v_771;
    _v_736 = _v_772;
    _v_737 = _v_773;
    _v_738 = _v_774;
    _v_739 = _v_775;
    _v_740 = _v_776;
    _v_741 = _v_777;
    _v_742 = _v_778;
    _v_743 = _v_779;
    u32 _o_384 = 0;
    Term _o_385 = 0;
    u32 _o_386 = 0;
    if (_v_740 == 0) {
      _o_384 = 0;
    } else {
      _o_384 = 1;
      Term _fb_14[2];
      u64 _sp_14 = ctr_take(e, _v_741, 2, _fb_14);
      Term _f_28 = _fb_14[0];
      u32 _f_29 = _fb_14[1];
      spare_free(e, cls_fit(2), _sp_14);
      _o_385 = _f_28;
      _o_386 = _f_29;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K267;
      WL_PUSHN(1);
    } else {
      u64 _t_212 = task_node(e, FID_MAIN_K267, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K267, _t_212);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_213 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_213 + 0] = _v_728;
      e.mem[_t_213 + 1] = _v_729;
      e.mem[_t_213 + 2] = _v_730;
      e.mem[_t_213 + 3] = _v_731;
      e.mem[_t_213 + 4] = _v_732;
      e.mem[_t_213 + 5] = _v_733;
      e.mem[_t_213 + 6] = _v_734;
      e.mem[_t_213 + 7] = _v_735;
      e.mem[_t_213 + 8] = _v_736;
      e.mem[_t_213 + 9] = _v_737;
      e.mem[_t_213 + 10] = _v_738;
      e.mem[_t_213 + 11] = _v_739;
      e.mem[_t_213 + 12] = _o_384;
      e.mem[_t_213 + 13] = _o_385;
      e.mem[_t_213 + 14] = _o_386;
      e.mem[_t_213 + 15] = _v_742;
      e.mem[_t_213 + 16] = _v_743;
      return term_tsk(FID_SNAPSHOT, _t_213);
    }
    r0 = _v_728;
    r1 = _v_729;
    r2 = _v_730;
    r3 = _v_731;
    r4 = _v_732;
    r5 = _v_733;
    r6 = _v_734;
    r7 = _v_735;
    r8 = _v_736;
    r9 = _v_737;
    r10 = _v_738;
    r11 = _v_739;
    r12 = _o_384;
    r13 = _o_385;
    r14 = _o_386;
    r15 = _v_742;
    r16 = _v_743;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K267)
  {
    Term _h_42 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K268;
      WL_PUSHN(1);
    } else {
      u64 _t_214 = task_node(e, FID_MAIN_K268, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K268, _t_214);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_215 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_215 + 0] = term_ctr(CID_SCON, STAT_OFF + 184);
      e.mem[_t_215 + 1] = _h_42;
      return term_tsk(FID_STRING_APPEND, _t_215);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 184);
    r1 = _h_42;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K268)
  {
    Term _h_43 = r0;
    WL_OPEN
    u64 _nd_147 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_147 + 0] = _h_43;
    r0 = term_clo(FID_MAIN_C269, _nd_147);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C269)
  {
    Term _h_44 = r0;
    Term _x_28 = r1;
    WL_OPEN
    u64 _nd_148 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_148 + 0] = _h_44;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_458 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_458 + 0] = term_clo(FID_IO_PRINT, _nd_148);
      e.mem[_t_458 + 1] = term_clo(FID_MAIN_C270, 0);
      e.mem[_t_458 + 2] = _x_28;
      return term_tsk(FID_IO_BIND, _t_458);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_148);
    r1 = term_clo(FID_MAIN_C270, 0);
    r2 = _x_28;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C270)
  {
    Term _x_29 = r0;
    WL_OPEN
    u32 _v_780 = 0;
    u32 _v_781 = 0;
    Term _v_782 = 0;
    Term _v_783 = 0;
    Term _v_784 = 0;
    Term _v_785 = 0;
    Term _v_786 = 0;
    Term _v_787 = 0;
    u32 _v_788 = 0;
    Term _v_789 = 0;
    u32 _v_790 = 0;
    Term _v_791 = 0;
    u32 _v_792 = 0;
    Term _v_793 = 0;
    Term _v_794 = 0;
    Term _v_795 = 0;
    Term _fv_868[1];
    _fv_868[0] = 999000ull;
    Term _fv_869[1];
    _fv_869[0] = 999001ull;
    Term _fv_870[1];
    _fv_870[0] = 999002ull;
    Term _fv_871[1];
    _fv_871[0] = 999003ull;
    Term _fv_872[1];
    _fv_872[0] = 999004ull;
    Term _fv_873[1];
    _fv_873[0] = 999005ull;
    Term _fv_874[1];
    _fv_874[0] = 999006ull;
    Term _fv_875[1];
    _fv_875[0] = 999007ull;
    u64 _nd_149 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_149 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_868), blk_new(e, 0, 0, 0, 1, _fv_869)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_870), blk_new(e, 0, 0, 0, 1, _fv_871))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_872), blk_new(e, 0, 0, 0, 1, _fv_873)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_874), blk_new(e, 0, 0, 0, 1, _fv_875)))));
    e.mem[_nd_149 + 1] = rfc_seal(e, 999ull);
    Term _v_796 = 0;
    Term _v_797 = 0;
    Term _v_798 = 0;
    Term _v_799 = 0;
    Term _v_800 = 0;
    Term _v_801 = 0;
    u32 _v_802 = 0;
    Term _v_803 = 0;
    u32 _v_804 = 0;
    Term _v_805 = 0;
    Term _fv_876[1];
    _fv_876[0] = 1000ull;
    Term _fv_877[1];
    _fv_877[0] = 1001ull;
    Term _fv_878[1];
    _fv_878[0] = 1002ull;
    Term _fv_879[1];
    _fv_879[0] = 1003ull;
    Term _fv_880[1];
    _fv_880[0] = 1004ull;
    Term _fv_881[1];
    _fv_881[0] = 1005ull;
    Term _fv_882[1];
    _fv_882[0] = 1006ull;
    Term _fv_883[1];
    _fv_883[0] = 1007ull;
    u32 _o_387 = 0;
    Term _o_388 = 0;
    Term _t_216 = 1;
    if (_t_216 == 0) {
      _o_387 = 0;
    } else {
      _o_387 = 1;
      u64 _nd_150 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_150 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_876), blk_new(e, 0, 0, 0, 1, _fv_877)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_878), blk_new(e, 0, 0, 0, 1, _fv_879))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_880), blk_new(e, 0, 0, 0, 1, _fv_881)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_882), blk_new(e, 0, 0, 0, 1, _fv_883)))));
      e.mem[_nd_150 + 1] = rfc_seal(e, 1ull);
      _o_388 = term_ctr(CID_OWNED, _nd_150);
    }
    Term _fv_884[2];
    _fv_884[0] = _o_387;
    _fv_884[1] = _o_388;
    u32 _o_389 = 0;
    Term _o_390 = 0;
    Term _t_217 = 0;
    if (_t_217 == 0) {
      _o_389 = 0;
    } else {
      _o_389 = 1;
      u64 _nd_151 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_151 + 0] = rfc_seal(e, 0);
      e.mem[_nd_151 + 1] = rfc_seal(e, 0);
      _o_390 = term_ctr(CID_OWNED, _nd_151);
    }
    Term _fv_885[2];
    _fv_885[0] = _o_389;
    _fv_885[1] = _o_390;
    Term _fv_886[1];
    _fv_886[0] = 3000ull;
    Term _fv_887[1];
    _fv_887[0] = 3001ull;
    Term _fv_888[1];
    _fv_888[0] = 3002ull;
    Term _fv_889[1];
    _fv_889[0] = 3003ull;
    Term _fv_890[1];
    _fv_890[0] = 3004ull;
    Term _fv_891[1];
    _fv_891[0] = 3005ull;
    Term _fv_892[1];
    _fv_892[0] = 3006ull;
    Term _fv_893[1];
    _fv_893[0] = 3007ull;
    u32 _o_391 = 0;
    Term _o_392 = 0;
    Term _t_218 = 1;
    if (_t_218 == 0) {
      _o_391 = 0;
    } else {
      _o_391 = 1;
      u64 _nd_152 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_152 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_886), blk_new(e, 0, 0, 0, 1, _fv_887)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_888), blk_new(e, 0, 0, 0, 1, _fv_889))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_890), blk_new(e, 0, 0, 0, 1, _fv_891)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_892), blk_new(e, 0, 0, 0, 1, _fv_893)))));
      e.mem[_nd_152 + 1] = rfc_seal(e, 3ull);
      _o_392 = term_ctr(CID_OWNED, _nd_152);
    }
    Term _fv_894[2];
    _fv_894[0] = _o_391;
    _fv_894[1] = _o_392;
    Term _fv_895[1];
    _fv_895[0] = 4000ull;
    Term _fv_896[1];
    _fv_896[0] = 4001ull;
    Term _fv_897[1];
    _fv_897[0] = 4002ull;
    Term _fv_898[1];
    _fv_898[0] = 4003ull;
    Term _fv_899[1];
    _fv_899[0] = 4004ull;
    Term _fv_900[1];
    _fv_900[0] = 4005ull;
    Term _fv_901[1];
    _fv_901[0] = 4006ull;
    Term _fv_902[1];
    _fv_902[0] = 4007ull;
    u32 _o_393 = 0;
    Term _o_394 = 0;
    Term _t_219 = 1;
    if (_t_219 == 0) {
      _o_393 = 0;
    } else {
      _o_393 = 1;
      u64 _nd_153 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_153 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_895), blk_new(e, 0, 0, 0, 1, _fv_896)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_897), blk_new(e, 0, 0, 0, 1, _fv_898))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_899), blk_new(e, 0, 0, 0, 1, _fv_900)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_901), blk_new(e, 0, 0, 0, 1, _fv_902)))));
      e.mem[_nd_153 + 1] = rfc_seal(e, 4ull);
      _o_394 = term_ctr(CID_OWNED, _nd_153);
    }
    Term _fv_903[2];
    _fv_903[0] = _o_393;
    _fv_903[1] = _o_394;
    Term _fv_904[1];
    _fv_904[0] = 5000ull;
    Term _fv_905[1];
    _fv_905[0] = 5001ull;
    Term _fv_906[1];
    _fv_906[0] = 5002ull;
    Term _fv_907[1];
    _fv_907[0] = 5003ull;
    Term _fv_908[1];
    _fv_908[0] = 5004ull;
    Term _fv_909[1];
    _fv_909[0] = 5005ull;
    Term _fv_910[1];
    _fv_910[0] = 5006ull;
    Term _fv_911[1];
    _fv_911[0] = 5007ull;
    u32 _o_395 = 0;
    Term _o_396 = 0;
    Term _t_220 = 1;
    if (_t_220 == 0) {
      _o_395 = 0;
    } else {
      _o_395 = 1;
      u64 _nd_154 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_154 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_904), blk_new(e, 0, 0, 0, 1, _fv_905)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_906), blk_new(e, 0, 0, 0, 1, _fv_907))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_908), blk_new(e, 0, 0, 0, 1, _fv_909)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_910), blk_new(e, 0, 0, 0, 1, _fv_911)))));
      e.mem[_nd_154 + 1] = rfc_seal(e, 5ull);
      _o_396 = term_ctr(CID_OWNED, _nd_154);
    }
    Term _fv_912[2];
    _fv_912[0] = _o_395;
    _fv_912[1] = _o_396;
    Term _fv_913[1];
    _fv_913[0] = 6000ull;
    Term _fv_914[1];
    _fv_914[0] = 6001ull;
    Term _fv_915[1];
    _fv_915[0] = 6002ull;
    Term _fv_916[1];
    _fv_916[0] = 6003ull;
    Term _fv_917[1];
    _fv_917[0] = 6004ull;
    Term _fv_918[1];
    _fv_918[0] = 6005ull;
    Term _fv_919[1];
    _fv_919[0] = 6006ull;
    Term _fv_920[1];
    _fv_920[0] = 6007ull;
    u32 _o_397 = 0;
    Term _o_398 = 0;
    Term _t_221 = 1;
    if (_t_221 == 0) {
      _o_397 = 0;
    } else {
      _o_397 = 1;
      u64 _nd_155 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_155 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_913), blk_new(e, 0, 0, 0, 1, _fv_914)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_915), blk_new(e, 0, 0, 0, 1, _fv_916))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_917), blk_new(e, 0, 0, 0, 1, _fv_918)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_919), blk_new(e, 0, 0, 0, 1, _fv_920)))));
      e.mem[_nd_155 + 1] = rfc_seal(e, 6ull);
      _o_398 = term_ctr(CID_OWNED, _nd_155);
    }
    Term _fv_921[2];
    _fv_921[0] = _o_397;
    _fv_921[1] = _o_398;
    Term _fv_922[1];
    _fv_922[0] = 7000ull;
    Term _fv_923[1];
    _fv_923[0] = 7001ull;
    Term _fv_924[1];
    _fv_924[0] = 7002ull;
    Term _fv_925[1];
    _fv_925[0] = 7003ull;
    Term _fv_926[1];
    _fv_926[0] = 7004ull;
    Term _fv_927[1];
    _fv_927[0] = 7005ull;
    Term _fv_928[1];
    _fv_928[0] = 7006ull;
    Term _fv_929[1];
    _fv_929[0] = 7007ull;
    u32 _o_399 = 0;
    Term _o_400 = 0;
    Term _t_222 = 1;
    if (_t_222 == 0) {
      _o_399 = 0;
    } else {
      _o_399 = 1;
      u64 _nd_156 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_156 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_922), blk_new(e, 0, 0, 0, 1, _fv_923)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_924), blk_new(e, 0, 0, 0, 1, _fv_925))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_926), blk_new(e, 0, 0, 0, 1, _fv_927)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_928), blk_new(e, 0, 0, 0, 1, _fv_929)))));
      e.mem[_nd_156 + 1] = rfc_seal(e, 7ull);
      _o_400 = term_ctr(CID_OWNED, _nd_156);
    }
    Term _fv_930[2];
    _fv_930[0] = _o_399;
    _fv_930[1] = _o_400;
    Term _fv_931[1];
    _fv_931[0] = 8000ull;
    Term _fv_932[1];
    _fv_932[0] = 8001ull;
    Term _fv_933[1];
    _fv_933[0] = 8002ull;
    Term _fv_934[1];
    _fv_934[0] = 8003ull;
    Term _fv_935[1];
    _fv_935[0] = 8004ull;
    Term _fv_936[1];
    _fv_936[0] = 8005ull;
    Term _fv_937[1];
    _fv_937[0] = 8006ull;
    Term _fv_938[1];
    _fv_938[0] = 8007ull;
    u32 _o_401 = 0;
    Term _o_402 = 0;
    Term _t_223 = 1;
    if (_t_223 == 0) {
      _o_401 = 0;
    } else {
      _o_401 = 1;
      u64 _nd_157 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_157 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_931), blk_new(e, 0, 0, 0, 1, _fv_932)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_933), blk_new(e, 0, 0, 0, 1, _fv_934))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_935), blk_new(e, 0, 0, 0, 1, _fv_936)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_937), blk_new(e, 0, 0, 0, 1, _fv_938)))));
      e.mem[_nd_157 + 1] = rfc_seal(e, 8ull);
      _o_402 = term_ctr(CID_OWNED, _nd_157);
    }
    Term _fv_939[2];
    _fv_939[0] = _o_401;
    _fv_939[1] = _o_402;
    Term _fv_940[1];
    _fv_940[0] = 101000ull;
    Term _fv_941[1];
    _fv_941[0] = 101001ull;
    Term _fv_942[1];
    _fv_942[0] = 101002ull;
    Term _fv_943[1];
    _fv_943[0] = 101003ull;
    Term _fv_944[1];
    _fv_944[0] = 101004ull;
    Term _fv_945[1];
    _fv_945[0] = 101005ull;
    Term _fv_946[1];
    _fv_946[0] = 101006ull;
    Term _fv_947[1];
    _fv_947[0] = 101007ull;
    u32 _o_403 = 0;
    Term _o_404 = 0;
    Term _t_224 = 1;
    if (_t_224 == 0) {
      _o_403 = 0;
    } else {
      _o_403 = 1;
      u64 _nd_158 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_158 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_940), blk_new(e, 0, 0, 0, 1, _fv_941)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_942), blk_new(e, 0, 0, 0, 1, _fv_943))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_944), blk_new(e, 0, 0, 0, 1, _fv_945)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_946), blk_new(e, 0, 0, 0, 1, _fv_947)))));
      e.mem[_nd_158 + 1] = rfc_seal(e, 101ull);
      _o_404 = term_ctr(CID_OWNED, _nd_158);
    }
    Term _fv_948[2];
    _fv_948[0] = _o_403;
    _fv_948[1] = _o_404;
    Term _fv_949[1];
    _fv_949[0] = 102000ull;
    Term _fv_950[1];
    _fv_950[0] = 102001ull;
    Term _fv_951[1];
    _fv_951[0] = 102002ull;
    Term _fv_952[1];
    _fv_952[0] = 102003ull;
    Term _fv_953[1];
    _fv_953[0] = 102004ull;
    Term _fv_954[1];
    _fv_954[0] = 102005ull;
    Term _fv_955[1];
    _fv_955[0] = 102006ull;
    Term _fv_956[1];
    _fv_956[0] = 102007ull;
    u32 _o_405 = 0;
    Term _o_406 = 0;
    Term _t_225 = 1;
    if (_t_225 == 0) {
      _o_405 = 0;
    } else {
      _o_405 = 1;
      u64 _nd_159 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_159 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_949), blk_new(e, 0, 0, 0, 1, _fv_950)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_951), blk_new(e, 0, 0, 0, 1, _fv_952))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_953), blk_new(e, 0, 0, 0, 1, _fv_954)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_955), blk_new(e, 0, 0, 0, 1, _fv_956)))));
      e.mem[_nd_159 + 1] = rfc_seal(e, 102ull);
      _o_406 = term_ctr(CID_OWNED, _nd_159);
    }
    Term _fv_957[2];
    _fv_957[0] = _o_405;
    _fv_957[1] = _o_406;
    Term _fv_958[1];
    _fv_958[0] = 103000ull;
    Term _fv_959[1];
    _fv_959[0] = 103001ull;
    Term _fv_960[1];
    _fv_960[0] = 103002ull;
    Term _fv_961[1];
    _fv_961[0] = 103003ull;
    Term _fv_962[1];
    _fv_962[0] = 103004ull;
    Term _fv_963[1];
    _fv_963[0] = 103005ull;
    Term _fv_964[1];
    _fv_964[0] = 103006ull;
    Term _fv_965[1];
    _fv_965[0] = 103007ull;
    u32 _o_407 = 0;
    Term _o_408 = 0;
    Term _t_226 = 1;
    if (_t_226 == 0) {
      _o_407 = 0;
    } else {
      _o_407 = 1;
      u64 _nd_160 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_160 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_958), blk_new(e, 0, 0, 0, 1, _fv_959)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_960), blk_new(e, 0, 0, 0, 1, _fv_961))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_962), blk_new(e, 0, 0, 0, 1, _fv_963)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_964), blk_new(e, 0, 0, 0, 1, _fv_965)))));
      e.mem[_nd_160 + 1] = rfc_seal(e, 103ull);
      _o_408 = term_ctr(CID_OWNED, _nd_160);
    }
    Term _fv_966[2];
    _fv_966[0] = _o_407;
    _fv_966[1] = _o_408;
    Term _fv_967[1];
    _fv_967[0] = 104000ull;
    Term _fv_968[1];
    _fv_968[0] = 104001ull;
    Term _fv_969[1];
    _fv_969[0] = 104002ull;
    Term _fv_970[1];
    _fv_970[0] = 104003ull;
    Term _fv_971[1];
    _fv_971[0] = 104004ull;
    Term _fv_972[1];
    _fv_972[0] = 104005ull;
    Term _fv_973[1];
    _fv_973[0] = 104006ull;
    Term _fv_974[1];
    _fv_974[0] = 104007ull;
    u32 _o_409 = 0;
    Term _o_410 = 0;
    Term _t_227 = 1;
    if (_t_227 == 0) {
      _o_409 = 0;
    } else {
      _o_409 = 1;
      u64 _nd_161 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_161 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_967), blk_new(e, 0, 0, 0, 1, _fv_968)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_969), blk_new(e, 0, 0, 0, 1, _fv_970))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_971), blk_new(e, 0, 0, 0, 1, _fv_972)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_973), blk_new(e, 0, 0, 0, 1, _fv_974)))));
      e.mem[_nd_161 + 1] = rfc_seal(e, 104ull);
      _o_410 = term_ctr(CID_OWNED, _nd_161);
    }
    Term _fv_975[2];
    _fv_975[0] = _o_409;
    _fv_975[1] = _o_410;
    Term _fv_976[1];
    _fv_976[0] = 105000ull;
    Term _fv_977[1];
    _fv_977[0] = 105001ull;
    Term _fv_978[1];
    _fv_978[0] = 105002ull;
    Term _fv_979[1];
    _fv_979[0] = 105003ull;
    Term _fv_980[1];
    _fv_980[0] = 105004ull;
    Term _fv_981[1];
    _fv_981[0] = 105005ull;
    Term _fv_982[1];
    _fv_982[0] = 105006ull;
    Term _fv_983[1];
    _fv_983[0] = 105007ull;
    u32 _o_411 = 0;
    Term _o_412 = 0;
    Term _t_228 = 1;
    if (_t_228 == 0) {
      _o_411 = 0;
    } else {
      _o_411 = 1;
      u64 _nd_162 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_162 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_976), blk_new(e, 0, 0, 0, 1, _fv_977)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_978), blk_new(e, 0, 0, 0, 1, _fv_979))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_980), blk_new(e, 0, 0, 0, 1, _fv_981)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_982), blk_new(e, 0, 0, 0, 1, _fv_983)))));
      e.mem[_nd_162 + 1] = rfc_seal(e, 105ull);
      _o_412 = term_ctr(CID_OWNED, _nd_162);
    }
    Term _fv_984[2];
    _fv_984[0] = _o_411;
    _fv_984[1] = _o_412;
    Term _fv_985[1];
    _fv_985[0] = 106000ull;
    Term _fv_986[1];
    _fv_986[0] = 106001ull;
    Term _fv_987[1];
    _fv_987[0] = 106002ull;
    Term _fv_988[1];
    _fv_988[0] = 106003ull;
    Term _fv_989[1];
    _fv_989[0] = 106004ull;
    Term _fv_990[1];
    _fv_990[0] = 106005ull;
    Term _fv_991[1];
    _fv_991[0] = 106006ull;
    Term _fv_992[1];
    _fv_992[0] = 106007ull;
    u32 _o_413 = 0;
    Term _o_414 = 0;
    Term _t_229 = 1;
    if (_t_229 == 0) {
      _o_413 = 0;
    } else {
      _o_413 = 1;
      u64 _nd_163 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_163 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_985), blk_new(e, 0, 0, 0, 1, _fv_986)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_987), blk_new(e, 0, 0, 0, 1, _fv_988))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_989), blk_new(e, 0, 0, 0, 1, _fv_990)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_991), blk_new(e, 0, 0, 0, 1, _fv_992)))));
      e.mem[_nd_163 + 1] = rfc_seal(e, 106ull);
      _o_414 = term_ctr(CID_OWNED, _nd_163);
    }
    Term _fv_993[2];
    _fv_993[0] = _o_413;
    _fv_993[1] = _o_414;
    Term _fv_994[1];
    _fv_994[0] = 107000ull;
    Term _fv_995[1];
    _fv_995[0] = 107001ull;
    Term _fv_996[1];
    _fv_996[0] = 107002ull;
    Term _fv_997[1];
    _fv_997[0] = 107003ull;
    Term _fv_998[1];
    _fv_998[0] = 107004ull;
    Term _fv_999[1];
    _fv_999[0] = 107005ull;
    Term _fv_1000[1];
    _fv_1000[0] = 107006ull;
    Term _fv_1001[1];
    _fv_1001[0] = 107007ull;
    u32 _o_415 = 0;
    Term _o_416 = 0;
    Term _t_230 = 1;
    if (_t_230 == 0) {
      _o_415 = 0;
    } else {
      _o_415 = 1;
      u64 _nd_164 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_164 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_994), blk_new(e, 0, 0, 0, 1, _fv_995)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_996), blk_new(e, 0, 0, 0, 1, _fv_997))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_998), blk_new(e, 0, 0, 0, 1, _fv_999)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1000), blk_new(e, 0, 0, 0, 1, _fv_1001)))));
      e.mem[_nd_164 + 1] = rfc_seal(e, 107ull);
      _o_416 = term_ctr(CID_OWNED, _nd_164);
    }
    Term _fv_1002[2];
    _fv_1002[0] = _o_415;
    _fv_1002[1] = _o_416;
    Term _fv_1003[1];
    _fv_1003[0] = 108000ull;
    Term _fv_1004[1];
    _fv_1004[0] = 108001ull;
    Term _fv_1005[1];
    _fv_1005[0] = 108002ull;
    Term _fv_1006[1];
    _fv_1006[0] = 108003ull;
    Term _fv_1007[1];
    _fv_1007[0] = 108004ull;
    Term _fv_1008[1];
    _fv_1008[0] = 108005ull;
    Term _fv_1009[1];
    _fv_1009[0] = 108006ull;
    Term _fv_1010[1];
    _fv_1010[0] = 108007ull;
    u32 _o_417 = 0;
    Term _o_418 = 0;
    Term _t_231 = 1;
    if (_t_231 == 0) {
      _o_417 = 0;
    } else {
      _o_417 = 1;
      u64 _nd_165 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_165 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1003), blk_new(e, 0, 0, 0, 1, _fv_1004)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1005), blk_new(e, 0, 0, 0, 1, _fv_1006))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1007), blk_new(e, 0, 0, 0, 1, _fv_1008)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1009), blk_new(e, 0, 0, 0, 1, _fv_1010)))));
      e.mem[_nd_165 + 1] = rfc_seal(e, 108ull);
      _o_418 = term_ctr(CID_OWNED, _nd_165);
    }
    Term _fv_1011[2];
    _fv_1011[0] = _o_417;
    _fv_1011[1] = _o_418;
    Term _fv_1012[1];
    _fv_1012[0] = 1;
    Term _fv_1013[1];
    _fv_1013[0] = 1;
    Term _fv_1014[1];
    _fv_1014[0] = 0;
    Term _fv_1015[1];
    _fv_1015[0] = 1;
    Term _fv_1016[1];
    _fv_1016[0] = 1;
    Term _fv_1017[1];
    _fv_1017[0] = 1;
    Term _fv_1018[1];
    _fv_1018[0] = 1;
    Term _fv_1019[1];
    _fv_1019[0] = 1;
    u32 _o_419 = 0;
    Term _o_420 = 0;
    Term _t_232 = 1;
    if (_t_232 == 0) {
      _o_419 = 0;
    } else {
      _o_419 = 1;
      _o_420 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1020[2];
    _fv_1020[0] = _o_419;
    _fv_1020[1] = _o_420;
    u32 _o_421 = 0;
    Term _o_422 = 0;
    Term _t_233 = 0;
    if (_t_233 == 0) {
      _o_421 = 0;
    } else {
      _o_421 = 1;
      _o_422 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1021[2];
    _fv_1021[0] = _o_421;
    _fv_1021[1] = _o_422;
    u32 _o_423 = 0;
    Term _o_424 = 0;
    Term _t_234 = 1;
    if (_t_234 == 0) {
      _o_423 = 0;
    } else {
      _o_423 = 1;
      _o_424 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1022[2];
    _fv_1022[0] = _o_423;
    _fv_1022[1] = _o_424;
    u32 _o_425 = 0;
    Term _o_426 = 0;
    Term _t_235 = 0;
    if (_t_235 == 0) {
      _o_425 = 0;
    } else {
      _o_425 = 1;
      _o_426 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1023[2];
    _fv_1023[0] = _o_425;
    _fv_1023[1] = _o_426;
    u32 _o_427 = 0;
    Term _o_428 = 0;
    Term _t_236 = 1;
    if (_t_236 == 0) {
      _o_427 = 0;
    } else {
      _o_427 = 1;
      _o_428 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1024[2];
    _fv_1024[0] = _o_427;
    _fv_1024[1] = _o_428;
    u32 _o_429 = 0;
    Term _o_430 = 0;
    Term _t_237 = 0;
    if (_t_237 == 0) {
      _o_429 = 0;
    } else {
      _o_429 = 1;
      _o_430 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1025[2];
    _fv_1025[0] = _o_429;
    _fv_1025[1] = _o_430;
    u32 _o_431 = 0;
    Term _o_432 = 0;
    Term _t_238 = 1;
    if (_t_238 == 0) {
      _o_431 = 0;
    } else {
      _o_431 = 1;
      _o_432 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1026[2];
    _fv_1026[0] = _o_431;
    _fv_1026[1] = _o_432;
    u32 _o_433 = 0;
    Term _o_434 = 0;
    Term _t_239 = 0;
    if (_t_239 == 0) {
      _o_433 = 0;
    } else {
      _o_433 = 1;
      _o_434 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1027[2];
    _fv_1027[0] = _o_433;
    _fv_1027[1] = _o_434;
    Term _fv_1028[1];
    _fv_1028[0] = 100ull;
    Term _fv_1029[1];
    _fv_1029[0] = 101ull;
    Term _fv_1030[1];
    _fv_1030[0] = 102ull;
    Term _fv_1031[1];
    _fv_1031[0] = 103ull;
    Term _fv_1032[1];
    _fv_1032[0] = 104ull;
    Term _fv_1033[1];
    _fv_1033[0] = 105ull;
    Term _fv_1034[1];
    _fv_1034[0] = 106ull;
    Term _fv_1035[1];
    _fv_1035[0] = 107ull;
    Term _fv_1036[1];
    _fv_1036[0] = 200ull;
    Term _fv_1037[1];
    _fv_1037[0] = 201ull;
    Term _fv_1038[1];
    _fv_1038[0] = 202ull;
    Term _fv_1039[1];
    _fv_1039[0] = 203ull;
    Term _fv_1040[1];
    _fv_1040[0] = 204ull;
    Term _fv_1041[1];
    _fv_1041[0] = 205ull;
    Term _fv_1042[1];
    _fv_1042[0] = 206ull;
    Term _fv_1043[1];
    _fv_1043[0] = 207ull;
    Term _v_806 = 0;
    Term _v_807 = 0;
    Term _v_808 = 0;
    Term _v_809 = 0;
    Term _v_810 = 0;
    Term _v_811 = 0;
    u32 _v_812 = 0;
    Term _v_813 = 0;
    u32 _v_814 = 0;
    Term _v_815 = 0;
    Term _o_435[10];
    Term _a_150 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_884), blk_new(e, 1, 0, 1, 2, _fv_885)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_894), blk_new(e, 1, 0, 1, 2, _fv_903))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_912), blk_new(e, 1, 0, 1, 2, _fv_921)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_930), blk_new(e, 1, 0, 1, 2, _fv_939))));
    Term _a_151 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_948), blk_new(e, 1, 0, 1, 2, _fv_957)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_966), blk_new(e, 1, 0, 1, 2, _fv_975))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_984), blk_new(e, 1, 0, 1, 2, _fv_993)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1002), blk_new(e, 1, 0, 1, 2, _fv_1011))));
    Term _a_152 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1012), blk_new(e, 0, 0, 0, 1, _fv_1013)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1014), blk_new(e, 0, 0, 0, 1, _fv_1015))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1016), blk_new(e, 0, 0, 0, 1, _fv_1017)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1018), blk_new(e, 0, 0, 0, 1, _fv_1019))));
    Term _a_153 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1020), blk_new(e, 1, 0, 1, 2, _fv_1021)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1022), blk_new(e, 1, 0, 1, 2, _fv_1023))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1024), blk_new(e, 1, 0, 1, 2, _fv_1025)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1026), blk_new(e, 1, 0, 1, 2, _fv_1027))));
    Term _a_154 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1028), blk_new(e, 0, 0, 0, 1, _fv_1029)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1030), blk_new(e, 0, 0, 0, 1, _fv_1031))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1032), blk_new(e, 0, 0, 0, 1, _fv_1033)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1034), blk_new(e, 0, 0, 0, 1, _fv_1035))));
    Term _a_155 = blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1036), blk_new(e, 0, 0, 0, 1, _fv_1037)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1038), blk_new(e, 0, 0, 0, 1, _fv_1039))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1040), blk_new(e, 0, 0, 0, 1, _fv_1041)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1042), blk_new(e, 0, 0, 0, 1, _fv_1043))));
    Term _a_156 = term_pak(CID_NIL, 0);
    if (spin_19(e, _o_435, ((u64)7ull), 1ull, 8ull, 3ull, 7ull, 3, 7ull, _a_150, blk_loc(e.mem, _a_150), _a_151, blk_loc(e.mem, _a_151), _a_152, blk_loc(e.mem, _a_152), _a_153, blk_loc(e.mem, _a_153), _a_154, blk_loc(e.mem, _a_154), _a_155, blk_loc(e.mem, _a_155), _a_156, blk_loc(e.mem, _a_156)) == 0) {
      return 0;
    }
    _v_806 = _o_435[0];
    _v_807 = _o_435[1];
    _v_808 = _o_435[2];
    _v_809 = _o_435[3];
    _v_810 = _o_435[4];
    _v_811 = _o_435[5];
    _v_812 = _o_435[6];
    _v_813 = _o_435[7];
    _v_814 = _o_435[8];
    _v_815 = _o_435[9];
    _v_796 = _v_806;
    _v_797 = _v_807;
    _v_798 = _v_808;
    _v_799 = _v_809;
    _v_800 = _v_810;
    _v_801 = _v_811;
    _v_802 = _v_812;
    _v_803 = _v_813;
    _v_804 = _v_814;
    _v_805 = _v_815;
    u32 _v_816 = 0;
    u32 _v_817 = 0;
    Term _v_818 = 0;
    Term _v_819 = 0;
    Term _v_820 = 0;
    Term _v_821 = 0;
    Term _v_822 = 0;
    Term _v_823 = 0;
    u32 _v_824 = 0;
    Term _v_825 = 0;
    u32 _v_826 = 0;
    Term _v_827 = 0;
    u32 _v_828 = 0;
    Term _v_829 = 0;
    Term _v_830 = 0;
    Term _v_831 = 0;
    Term _o_436[16];
    Term _a_157 = term_pak(CID_NIL, 0);
    Term _a_158 = term_ctr(CID_OWNED, _nd_149);
    Term _a_159 = 123ull;
    if (spin_21(e, _o_436, 7ull, 999ull, _a_157, blk_loc(e.mem, _a_157), 1, _a_158, blk_loc(e.mem, _a_158), _a_159, blk_loc(e.mem, _a_159), _v_796, blk_loc(e.mem, _v_796), _v_797, blk_loc(e.mem, _v_797), _v_798, blk_loc(e.mem, _v_798), _v_799, blk_loc(e.mem, _v_799), _v_800, blk_loc(e.mem, _v_800), _v_801, blk_loc(e.mem, _v_801), _v_802, _v_803, _v_804, _v_805, blk_loc(e.mem, _v_805)) == 0) {
      return 0;
    }
    _v_816 = _o_436[0];
    _v_817 = _o_436[1];
    _v_818 = _o_436[2];
    _v_819 = _o_436[3];
    _v_820 = _o_436[4];
    _v_821 = _o_436[5];
    _v_822 = _o_436[6];
    _v_823 = _o_436[7];
    _v_824 = _o_436[8];
    _v_825 = _o_436[9];
    _v_826 = _o_436[10];
    _v_827 = _o_436[11];
    _v_828 = _o_436[12];
    _v_829 = _o_436[13];
    _v_830 = _o_436[14];
    _v_831 = _o_436[15];
    _v_780 = _v_816;
    _v_781 = _v_817;
    _v_782 = _v_818;
    _v_783 = _v_819;
    _v_784 = _v_820;
    _v_785 = _v_821;
    _v_786 = _v_822;
    _v_787 = _v_823;
    _v_788 = _v_824;
    _v_789 = _v_825;
    _v_790 = _v_826;
    _v_791 = _v_827;
    _v_792 = _v_828;
    _v_793 = _v_829;
    _v_794 = _v_830;
    _v_795 = _v_831;
    u32 _o_437 = 0;
    Term _o_438 = 0;
    u32 _o_439 = 0;
    if (_v_792 == 0) {
      _o_437 = 0;
    } else {
      _o_437 = 1;
      Term _fb_15[2];
      u64 _sp_15 = ctr_take(e, _v_793, 2, _fb_15);
      Term _f_30 = _fb_15[0];
      u32 _f_31 = _fb_15[1];
      spare_free(e, cls_fit(2), _sp_15);
      _o_438 = _f_30;
      _o_439 = _f_31;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K271;
      WL_PUSHN(1);
    } else {
      u64 _t_240 = task_node(e, FID_MAIN_K271, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K271, _t_240);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_241 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_241 + 0] = _v_780;
      e.mem[_t_241 + 1] = _v_781;
      e.mem[_t_241 + 2] = _v_782;
      e.mem[_t_241 + 3] = _v_783;
      e.mem[_t_241 + 4] = _v_784;
      e.mem[_t_241 + 5] = _v_785;
      e.mem[_t_241 + 6] = _v_786;
      e.mem[_t_241 + 7] = _v_787;
      e.mem[_t_241 + 8] = _v_788;
      e.mem[_t_241 + 9] = _v_789;
      e.mem[_t_241 + 10] = _v_790;
      e.mem[_t_241 + 11] = _v_791;
      e.mem[_t_241 + 12] = _o_437;
      e.mem[_t_241 + 13] = _o_438;
      e.mem[_t_241 + 14] = _o_439;
      e.mem[_t_241 + 15] = _v_794;
      e.mem[_t_241 + 16] = _v_795;
      return term_tsk(FID_SNAPSHOT, _t_241);
    }
    r0 = _v_780;
    r1 = _v_781;
    r2 = _v_782;
    r3 = _v_783;
    r4 = _v_784;
    r5 = _v_785;
    r6 = _v_786;
    r7 = _v_787;
    r8 = _v_788;
    r9 = _v_789;
    r10 = _v_790;
    r11 = _v_791;
    r12 = _o_437;
    r13 = _o_438;
    r14 = _o_439;
    r15 = _v_794;
    r16 = _v_795;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K271)
  {
    Term _h_45 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K272;
      WL_PUSHN(1);
    } else {
      u64 _t_242 = task_node(e, FID_MAIN_K272, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K272, _t_242);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_243 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_243 + 0] = term_ctr(CID_SCON, STAT_OFF + 188);
      e.mem[_t_243 + 1] = _h_45;
      return term_tsk(FID_STRING_APPEND, _t_243);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 188);
    r1 = _h_45;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K272)
  {
    Term _h_46 = r0;
    WL_OPEN
    u64 _nd_166 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_166 + 0] = _h_46;
    r0 = term_clo(FID_MAIN_C273, _nd_166);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C273)
  {
    Term _h_47 = r0;
    Term _x_30 = r1;
    WL_OPEN
    u64 _nd_167 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_167 + 0] = _h_47;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_457 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_457 + 0] = term_clo(FID_IO_PRINT, _nd_167);
      e.mem[_t_457 + 1] = term_clo(FID_MAIN_C274, 0);
      e.mem[_t_457 + 2] = _x_30;
      return term_tsk(FID_IO_BIND, _t_457);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_167);
    r1 = term_clo(FID_MAIN_C274, 0);
    r2 = _x_30;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C274)
  {
    Term _x_31 = r0;
    WL_OPEN
    u32 _v_832 = 0;
    u32 _v_833 = 0;
    Term _v_834 = 0;
    Term _v_835 = 0;
    Term _v_836 = 0;
    Term _v_837 = 0;
    Term _v_838 = 0;
    Term _v_839 = 0;
    u32 _v_840 = 0;
    Term _v_841 = 0;
    u32 _v_842 = 0;
    Term _v_843 = 0;
    u32 _v_844 = 0;
    Term _v_845 = 0;
    Term _v_846 = 0;
    Term _v_847 = 0;
    Term _fv_1044[1];
    _fv_1044[0] = 999000ull;
    Term _fv_1045[1];
    _fv_1045[0] = 999001ull;
    Term _fv_1046[1];
    _fv_1046[0] = 999002ull;
    Term _fv_1047[1];
    _fv_1047[0] = 999003ull;
    Term _fv_1048[1];
    _fv_1048[0] = 999004ull;
    Term _fv_1049[1];
    _fv_1049[0] = 999005ull;
    Term _fv_1050[1];
    _fv_1050[0] = 999006ull;
    Term _fv_1051[1];
    _fv_1051[0] = 999007ull;
    Term _fv_1052[1];
    _fv_1052[0] = 999008ull;
    Term _fv_1053[1];
    _fv_1053[0] = 999009ull;
    Term _fv_1054[1];
    _fv_1054[0] = 999010ull;
    Term _fv_1055[1];
    _fv_1055[0] = 999011ull;
    Term _fv_1056[1];
    _fv_1056[0] = 999012ull;
    Term _fv_1057[1];
    _fv_1057[0] = 999013ull;
    Term _fv_1058[1];
    _fv_1058[0] = 999014ull;
    Term _fv_1059[1];
    _fv_1059[0] = 999015ull;
    u64 _nd_168 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_168 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1044), blk_new(e, 0, 0, 0, 1, _fv_1045)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1046), blk_new(e, 0, 0, 0, 1, _fv_1047))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1048), blk_new(e, 0, 0, 0, 1, _fv_1049)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1050), blk_new(e, 0, 0, 0, 1, _fv_1051)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1052), blk_new(e, 0, 0, 0, 1, _fv_1053)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1054), blk_new(e, 0, 0, 0, 1, _fv_1055))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1056), blk_new(e, 0, 0, 0, 1, _fv_1057)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1058), blk_new(e, 0, 0, 0, 1, _fv_1059))))));
    e.mem[_nd_168 + 1] = rfc_seal(e, 999ull);
    Term _v_848 = 0;
    Term _v_849 = 0;
    Term _v_850 = 0;
    Term _v_851 = 0;
    Term _v_852 = 0;
    Term _v_853 = 0;
    u32 _v_854 = 0;
    Term _v_855 = 0;
    u32 _v_856 = 0;
    Term _v_857 = 0;
    Term _fv_1060[1];
    _fv_1060[0] = 1000ull;
    Term _fv_1061[1];
    _fv_1061[0] = 1001ull;
    Term _fv_1062[1];
    _fv_1062[0] = 1002ull;
    Term _fv_1063[1];
    _fv_1063[0] = 1003ull;
    Term _fv_1064[1];
    _fv_1064[0] = 1004ull;
    Term _fv_1065[1];
    _fv_1065[0] = 1005ull;
    Term _fv_1066[1];
    _fv_1066[0] = 1006ull;
    Term _fv_1067[1];
    _fv_1067[0] = 1007ull;
    Term _fv_1068[1];
    _fv_1068[0] = 1008ull;
    Term _fv_1069[1];
    _fv_1069[0] = 1009ull;
    Term _fv_1070[1];
    _fv_1070[0] = 1010ull;
    Term _fv_1071[1];
    _fv_1071[0] = 1011ull;
    Term _fv_1072[1];
    _fv_1072[0] = 1012ull;
    Term _fv_1073[1];
    _fv_1073[0] = 1013ull;
    Term _fv_1074[1];
    _fv_1074[0] = 1014ull;
    Term _fv_1075[1];
    _fv_1075[0] = 1015ull;
    u32 _o_440 = 0;
    Term _o_441 = 0;
    Term _t_244 = 1;
    if (_t_244 == 0) {
      _o_440 = 0;
    } else {
      _o_440 = 1;
      u64 _nd_169 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_169 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1060), blk_new(e, 0, 0, 0, 1, _fv_1061)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1062), blk_new(e, 0, 0, 0, 1, _fv_1063))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1064), blk_new(e, 0, 0, 0, 1, _fv_1065)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1066), blk_new(e, 0, 0, 0, 1, _fv_1067)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1068), blk_new(e, 0, 0, 0, 1, _fv_1069)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1070), blk_new(e, 0, 0, 0, 1, _fv_1071))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1072), blk_new(e, 0, 0, 0, 1, _fv_1073)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1074), blk_new(e, 0, 0, 0, 1, _fv_1075))))));
      e.mem[_nd_169 + 1] = rfc_seal(e, 1ull);
      _o_441 = term_ctr(CID_OWNED, _nd_169);
    }
    Term _fv_1076[2];
    _fv_1076[0] = _o_440;
    _fv_1076[1] = _o_441;
    u32 _o_442 = 0;
    Term _o_443 = 0;
    Term _t_245 = 0;
    if (_t_245 == 0) {
      _o_442 = 0;
    } else {
      _o_442 = 1;
      u64 _nd_170 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_170 + 0] = rfc_seal(e, 0);
      e.mem[_nd_170 + 1] = rfc_seal(e, 0);
      _o_443 = term_ctr(CID_OWNED, _nd_170);
    }
    Term _fv_1077[2];
    _fv_1077[0] = _o_442;
    _fv_1077[1] = _o_443;
    Term _fv_1078[1];
    _fv_1078[0] = 3000ull;
    Term _fv_1079[1];
    _fv_1079[0] = 3001ull;
    Term _fv_1080[1];
    _fv_1080[0] = 3002ull;
    Term _fv_1081[1];
    _fv_1081[0] = 3003ull;
    Term _fv_1082[1];
    _fv_1082[0] = 3004ull;
    Term _fv_1083[1];
    _fv_1083[0] = 3005ull;
    Term _fv_1084[1];
    _fv_1084[0] = 3006ull;
    Term _fv_1085[1];
    _fv_1085[0] = 3007ull;
    Term _fv_1086[1];
    _fv_1086[0] = 3008ull;
    Term _fv_1087[1];
    _fv_1087[0] = 3009ull;
    Term _fv_1088[1];
    _fv_1088[0] = 3010ull;
    Term _fv_1089[1];
    _fv_1089[0] = 3011ull;
    Term _fv_1090[1];
    _fv_1090[0] = 3012ull;
    Term _fv_1091[1];
    _fv_1091[0] = 3013ull;
    Term _fv_1092[1];
    _fv_1092[0] = 3014ull;
    Term _fv_1093[1];
    _fv_1093[0] = 3015ull;
    u32 _o_444 = 0;
    Term _o_445 = 0;
    Term _t_246 = 1;
    if (_t_246 == 0) {
      _o_444 = 0;
    } else {
      _o_444 = 1;
      u64 _nd_171 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_171 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1078), blk_new(e, 0, 0, 0, 1, _fv_1079)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1080), blk_new(e, 0, 0, 0, 1, _fv_1081))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1082), blk_new(e, 0, 0, 0, 1, _fv_1083)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1084), blk_new(e, 0, 0, 0, 1, _fv_1085)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1086), blk_new(e, 0, 0, 0, 1, _fv_1087)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1088), blk_new(e, 0, 0, 0, 1, _fv_1089))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1090), blk_new(e, 0, 0, 0, 1, _fv_1091)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1092), blk_new(e, 0, 0, 0, 1, _fv_1093))))));
      e.mem[_nd_171 + 1] = rfc_seal(e, 3ull);
      _o_445 = term_ctr(CID_OWNED, _nd_171);
    }
    Term _fv_1094[2];
    _fv_1094[0] = _o_444;
    _fv_1094[1] = _o_445;
    Term _fv_1095[1];
    _fv_1095[0] = 4000ull;
    Term _fv_1096[1];
    _fv_1096[0] = 4001ull;
    Term _fv_1097[1];
    _fv_1097[0] = 4002ull;
    Term _fv_1098[1];
    _fv_1098[0] = 4003ull;
    Term _fv_1099[1];
    _fv_1099[0] = 4004ull;
    Term _fv_1100[1];
    _fv_1100[0] = 4005ull;
    Term _fv_1101[1];
    _fv_1101[0] = 4006ull;
    Term _fv_1102[1];
    _fv_1102[0] = 4007ull;
    Term _fv_1103[1];
    _fv_1103[0] = 4008ull;
    Term _fv_1104[1];
    _fv_1104[0] = 4009ull;
    Term _fv_1105[1];
    _fv_1105[0] = 4010ull;
    Term _fv_1106[1];
    _fv_1106[0] = 4011ull;
    Term _fv_1107[1];
    _fv_1107[0] = 4012ull;
    Term _fv_1108[1];
    _fv_1108[0] = 4013ull;
    Term _fv_1109[1];
    _fv_1109[0] = 4014ull;
    Term _fv_1110[1];
    _fv_1110[0] = 4015ull;
    u32 _o_446 = 0;
    Term _o_447 = 0;
    Term _t_247 = 1;
    if (_t_247 == 0) {
      _o_446 = 0;
    } else {
      _o_446 = 1;
      u64 _nd_172 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_172 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1095), blk_new(e, 0, 0, 0, 1, _fv_1096)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1097), blk_new(e, 0, 0, 0, 1, _fv_1098))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1099), blk_new(e, 0, 0, 0, 1, _fv_1100)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1101), blk_new(e, 0, 0, 0, 1, _fv_1102)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1103), blk_new(e, 0, 0, 0, 1, _fv_1104)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1105), blk_new(e, 0, 0, 0, 1, _fv_1106))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1107), blk_new(e, 0, 0, 0, 1, _fv_1108)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1109), blk_new(e, 0, 0, 0, 1, _fv_1110))))));
      e.mem[_nd_172 + 1] = rfc_seal(e, 4ull);
      _o_447 = term_ctr(CID_OWNED, _nd_172);
    }
    Term _fv_1111[2];
    _fv_1111[0] = _o_446;
    _fv_1111[1] = _o_447;
    Term _fv_1112[1];
    _fv_1112[0] = 5000ull;
    Term _fv_1113[1];
    _fv_1113[0] = 5001ull;
    Term _fv_1114[1];
    _fv_1114[0] = 5002ull;
    Term _fv_1115[1];
    _fv_1115[0] = 5003ull;
    Term _fv_1116[1];
    _fv_1116[0] = 5004ull;
    Term _fv_1117[1];
    _fv_1117[0] = 5005ull;
    Term _fv_1118[1];
    _fv_1118[0] = 5006ull;
    Term _fv_1119[1];
    _fv_1119[0] = 5007ull;
    Term _fv_1120[1];
    _fv_1120[0] = 5008ull;
    Term _fv_1121[1];
    _fv_1121[0] = 5009ull;
    Term _fv_1122[1];
    _fv_1122[0] = 5010ull;
    Term _fv_1123[1];
    _fv_1123[0] = 5011ull;
    Term _fv_1124[1];
    _fv_1124[0] = 5012ull;
    Term _fv_1125[1];
    _fv_1125[0] = 5013ull;
    Term _fv_1126[1];
    _fv_1126[0] = 5014ull;
    Term _fv_1127[1];
    _fv_1127[0] = 5015ull;
    u32 _o_448 = 0;
    Term _o_449 = 0;
    Term _t_248 = 1;
    if (_t_248 == 0) {
      _o_448 = 0;
    } else {
      _o_448 = 1;
      u64 _nd_173 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_173 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1112), blk_new(e, 0, 0, 0, 1, _fv_1113)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1114), blk_new(e, 0, 0, 0, 1, _fv_1115))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1116), blk_new(e, 0, 0, 0, 1, _fv_1117)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1118), blk_new(e, 0, 0, 0, 1, _fv_1119)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1120), blk_new(e, 0, 0, 0, 1, _fv_1121)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1122), blk_new(e, 0, 0, 0, 1, _fv_1123))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1124), blk_new(e, 0, 0, 0, 1, _fv_1125)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1126), blk_new(e, 0, 0, 0, 1, _fv_1127))))));
      e.mem[_nd_173 + 1] = rfc_seal(e, 5ull);
      _o_449 = term_ctr(CID_OWNED, _nd_173);
    }
    Term _fv_1128[2];
    _fv_1128[0] = _o_448;
    _fv_1128[1] = _o_449;
    Term _fv_1129[1];
    _fv_1129[0] = 6000ull;
    Term _fv_1130[1];
    _fv_1130[0] = 6001ull;
    Term _fv_1131[1];
    _fv_1131[0] = 6002ull;
    Term _fv_1132[1];
    _fv_1132[0] = 6003ull;
    Term _fv_1133[1];
    _fv_1133[0] = 6004ull;
    Term _fv_1134[1];
    _fv_1134[0] = 6005ull;
    Term _fv_1135[1];
    _fv_1135[0] = 6006ull;
    Term _fv_1136[1];
    _fv_1136[0] = 6007ull;
    Term _fv_1137[1];
    _fv_1137[0] = 6008ull;
    Term _fv_1138[1];
    _fv_1138[0] = 6009ull;
    Term _fv_1139[1];
    _fv_1139[0] = 6010ull;
    Term _fv_1140[1];
    _fv_1140[0] = 6011ull;
    Term _fv_1141[1];
    _fv_1141[0] = 6012ull;
    Term _fv_1142[1];
    _fv_1142[0] = 6013ull;
    Term _fv_1143[1];
    _fv_1143[0] = 6014ull;
    Term _fv_1144[1];
    _fv_1144[0] = 6015ull;
    u32 _o_450 = 0;
    Term _o_451 = 0;
    Term _t_249 = 1;
    if (_t_249 == 0) {
      _o_450 = 0;
    } else {
      _o_450 = 1;
      u64 _nd_174 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_174 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1129), blk_new(e, 0, 0, 0, 1, _fv_1130)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1131), blk_new(e, 0, 0, 0, 1, _fv_1132))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1133), blk_new(e, 0, 0, 0, 1, _fv_1134)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1135), blk_new(e, 0, 0, 0, 1, _fv_1136)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1137), blk_new(e, 0, 0, 0, 1, _fv_1138)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1139), blk_new(e, 0, 0, 0, 1, _fv_1140))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1141), blk_new(e, 0, 0, 0, 1, _fv_1142)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1143), blk_new(e, 0, 0, 0, 1, _fv_1144))))));
      e.mem[_nd_174 + 1] = rfc_seal(e, 6ull);
      _o_451 = term_ctr(CID_OWNED, _nd_174);
    }
    Term _fv_1145[2];
    _fv_1145[0] = _o_450;
    _fv_1145[1] = _o_451;
    Term _fv_1146[1];
    _fv_1146[0] = 7000ull;
    Term _fv_1147[1];
    _fv_1147[0] = 7001ull;
    Term _fv_1148[1];
    _fv_1148[0] = 7002ull;
    Term _fv_1149[1];
    _fv_1149[0] = 7003ull;
    Term _fv_1150[1];
    _fv_1150[0] = 7004ull;
    Term _fv_1151[1];
    _fv_1151[0] = 7005ull;
    Term _fv_1152[1];
    _fv_1152[0] = 7006ull;
    Term _fv_1153[1];
    _fv_1153[0] = 7007ull;
    Term _fv_1154[1];
    _fv_1154[0] = 7008ull;
    Term _fv_1155[1];
    _fv_1155[0] = 7009ull;
    Term _fv_1156[1];
    _fv_1156[0] = 7010ull;
    Term _fv_1157[1];
    _fv_1157[0] = 7011ull;
    Term _fv_1158[1];
    _fv_1158[0] = 7012ull;
    Term _fv_1159[1];
    _fv_1159[0] = 7013ull;
    Term _fv_1160[1];
    _fv_1160[0] = 7014ull;
    Term _fv_1161[1];
    _fv_1161[0] = 7015ull;
    u32 _o_452 = 0;
    Term _o_453 = 0;
    Term _t_250 = 1;
    if (_t_250 == 0) {
      _o_452 = 0;
    } else {
      _o_452 = 1;
      u64 _nd_175 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_175 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1146), blk_new(e, 0, 0, 0, 1, _fv_1147)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1148), blk_new(e, 0, 0, 0, 1, _fv_1149))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1150), blk_new(e, 0, 0, 0, 1, _fv_1151)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1152), blk_new(e, 0, 0, 0, 1, _fv_1153)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1154), blk_new(e, 0, 0, 0, 1, _fv_1155)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1156), blk_new(e, 0, 0, 0, 1, _fv_1157))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1158), blk_new(e, 0, 0, 0, 1, _fv_1159)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1160), blk_new(e, 0, 0, 0, 1, _fv_1161))))));
      e.mem[_nd_175 + 1] = rfc_seal(e, 7ull);
      _o_453 = term_ctr(CID_OWNED, _nd_175);
    }
    Term _fv_1162[2];
    _fv_1162[0] = _o_452;
    _fv_1162[1] = _o_453;
    Term _fv_1163[1];
    _fv_1163[0] = 8000ull;
    Term _fv_1164[1];
    _fv_1164[0] = 8001ull;
    Term _fv_1165[1];
    _fv_1165[0] = 8002ull;
    Term _fv_1166[1];
    _fv_1166[0] = 8003ull;
    Term _fv_1167[1];
    _fv_1167[0] = 8004ull;
    Term _fv_1168[1];
    _fv_1168[0] = 8005ull;
    Term _fv_1169[1];
    _fv_1169[0] = 8006ull;
    Term _fv_1170[1];
    _fv_1170[0] = 8007ull;
    Term _fv_1171[1];
    _fv_1171[0] = 8008ull;
    Term _fv_1172[1];
    _fv_1172[0] = 8009ull;
    Term _fv_1173[1];
    _fv_1173[0] = 8010ull;
    Term _fv_1174[1];
    _fv_1174[0] = 8011ull;
    Term _fv_1175[1];
    _fv_1175[0] = 8012ull;
    Term _fv_1176[1];
    _fv_1176[0] = 8013ull;
    Term _fv_1177[1];
    _fv_1177[0] = 8014ull;
    Term _fv_1178[1];
    _fv_1178[0] = 8015ull;
    u32 _o_454 = 0;
    Term _o_455 = 0;
    Term _t_251 = 1;
    if (_t_251 == 0) {
      _o_454 = 0;
    } else {
      _o_454 = 1;
      u64 _nd_176 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_176 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1163), blk_new(e, 0, 0, 0, 1, _fv_1164)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1165), blk_new(e, 0, 0, 0, 1, _fv_1166))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1167), blk_new(e, 0, 0, 0, 1, _fv_1168)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1169), blk_new(e, 0, 0, 0, 1, _fv_1170)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1171), blk_new(e, 0, 0, 0, 1, _fv_1172)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1173), blk_new(e, 0, 0, 0, 1, _fv_1174))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1175), blk_new(e, 0, 0, 0, 1, _fv_1176)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1177), blk_new(e, 0, 0, 0, 1, _fv_1178))))));
      e.mem[_nd_176 + 1] = rfc_seal(e, 8ull);
      _o_455 = term_ctr(CID_OWNED, _nd_176);
    }
    Term _fv_1179[2];
    _fv_1179[0] = _o_454;
    _fv_1179[1] = _o_455;
    Term _fv_1180[1];
    _fv_1180[0] = 9000ull;
    Term _fv_1181[1];
    _fv_1181[0] = 9001ull;
    Term _fv_1182[1];
    _fv_1182[0] = 9002ull;
    Term _fv_1183[1];
    _fv_1183[0] = 9003ull;
    Term _fv_1184[1];
    _fv_1184[0] = 9004ull;
    Term _fv_1185[1];
    _fv_1185[0] = 9005ull;
    Term _fv_1186[1];
    _fv_1186[0] = 9006ull;
    Term _fv_1187[1];
    _fv_1187[0] = 9007ull;
    Term _fv_1188[1];
    _fv_1188[0] = 9008ull;
    Term _fv_1189[1];
    _fv_1189[0] = 9009ull;
    Term _fv_1190[1];
    _fv_1190[0] = 9010ull;
    Term _fv_1191[1];
    _fv_1191[0] = 9011ull;
    Term _fv_1192[1];
    _fv_1192[0] = 9012ull;
    Term _fv_1193[1];
    _fv_1193[0] = 9013ull;
    Term _fv_1194[1];
    _fv_1194[0] = 9014ull;
    Term _fv_1195[1];
    _fv_1195[0] = 9015ull;
    u32 _o_456 = 0;
    Term _o_457 = 0;
    Term _t_252 = 1;
    if (_t_252 == 0) {
      _o_456 = 0;
    } else {
      _o_456 = 1;
      u64 _nd_177 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_177 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1180), blk_new(e, 0, 0, 0, 1, _fv_1181)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1182), blk_new(e, 0, 0, 0, 1, _fv_1183))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1184), blk_new(e, 0, 0, 0, 1, _fv_1185)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1186), blk_new(e, 0, 0, 0, 1, _fv_1187)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1188), blk_new(e, 0, 0, 0, 1, _fv_1189)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1190), blk_new(e, 0, 0, 0, 1, _fv_1191))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1192), blk_new(e, 0, 0, 0, 1, _fv_1193)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1194), blk_new(e, 0, 0, 0, 1, _fv_1195))))));
      e.mem[_nd_177 + 1] = rfc_seal(e, 9ull);
      _o_457 = term_ctr(CID_OWNED, _nd_177);
    }
    Term _fv_1196[2];
    _fv_1196[0] = _o_456;
    _fv_1196[1] = _o_457;
    Term _fv_1197[1];
    _fv_1197[0] = 10000ull;
    Term _fv_1198[1];
    _fv_1198[0] = 10001ull;
    Term _fv_1199[1];
    _fv_1199[0] = 10002ull;
    Term _fv_1200[1];
    _fv_1200[0] = 10003ull;
    Term _fv_1201[1];
    _fv_1201[0] = 10004ull;
    Term _fv_1202[1];
    _fv_1202[0] = 10005ull;
    Term _fv_1203[1];
    _fv_1203[0] = 10006ull;
    Term _fv_1204[1];
    _fv_1204[0] = 10007ull;
    Term _fv_1205[1];
    _fv_1205[0] = 10008ull;
    Term _fv_1206[1];
    _fv_1206[0] = 10009ull;
    Term _fv_1207[1];
    _fv_1207[0] = 10010ull;
    Term _fv_1208[1];
    _fv_1208[0] = 10011ull;
    Term _fv_1209[1];
    _fv_1209[0] = 10012ull;
    Term _fv_1210[1];
    _fv_1210[0] = 10013ull;
    Term _fv_1211[1];
    _fv_1211[0] = 10014ull;
    Term _fv_1212[1];
    _fv_1212[0] = 10015ull;
    u32 _o_458 = 0;
    Term _o_459 = 0;
    Term _t_253 = 1;
    if (_t_253 == 0) {
      _o_458 = 0;
    } else {
      _o_458 = 1;
      u64 _nd_178 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_178 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1197), blk_new(e, 0, 0, 0, 1, _fv_1198)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1199), blk_new(e, 0, 0, 0, 1, _fv_1200))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1201), blk_new(e, 0, 0, 0, 1, _fv_1202)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1203), blk_new(e, 0, 0, 0, 1, _fv_1204)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1205), blk_new(e, 0, 0, 0, 1, _fv_1206)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1207), blk_new(e, 0, 0, 0, 1, _fv_1208))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1209), blk_new(e, 0, 0, 0, 1, _fv_1210)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1211), blk_new(e, 0, 0, 0, 1, _fv_1212))))));
      e.mem[_nd_178 + 1] = rfc_seal(e, 10ull);
      _o_459 = term_ctr(CID_OWNED, _nd_178);
    }
    Term _fv_1213[2];
    _fv_1213[0] = _o_458;
    _fv_1213[1] = _o_459;
    Term _fv_1214[1];
    _fv_1214[0] = 11000ull;
    Term _fv_1215[1];
    _fv_1215[0] = 11001ull;
    Term _fv_1216[1];
    _fv_1216[0] = 11002ull;
    Term _fv_1217[1];
    _fv_1217[0] = 11003ull;
    Term _fv_1218[1];
    _fv_1218[0] = 11004ull;
    Term _fv_1219[1];
    _fv_1219[0] = 11005ull;
    Term _fv_1220[1];
    _fv_1220[0] = 11006ull;
    Term _fv_1221[1];
    _fv_1221[0] = 11007ull;
    Term _fv_1222[1];
    _fv_1222[0] = 11008ull;
    Term _fv_1223[1];
    _fv_1223[0] = 11009ull;
    Term _fv_1224[1];
    _fv_1224[0] = 11010ull;
    Term _fv_1225[1];
    _fv_1225[0] = 11011ull;
    Term _fv_1226[1];
    _fv_1226[0] = 11012ull;
    Term _fv_1227[1];
    _fv_1227[0] = 11013ull;
    Term _fv_1228[1];
    _fv_1228[0] = 11014ull;
    Term _fv_1229[1];
    _fv_1229[0] = 11015ull;
    u32 _o_460 = 0;
    Term _o_461 = 0;
    Term _t_254 = 1;
    if (_t_254 == 0) {
      _o_460 = 0;
    } else {
      _o_460 = 1;
      u64 _nd_179 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_179 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1214), blk_new(e, 0, 0, 0, 1, _fv_1215)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1216), blk_new(e, 0, 0, 0, 1, _fv_1217))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1218), blk_new(e, 0, 0, 0, 1, _fv_1219)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1220), blk_new(e, 0, 0, 0, 1, _fv_1221)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1222), blk_new(e, 0, 0, 0, 1, _fv_1223)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1224), blk_new(e, 0, 0, 0, 1, _fv_1225))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1226), blk_new(e, 0, 0, 0, 1, _fv_1227)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1228), blk_new(e, 0, 0, 0, 1, _fv_1229))))));
      e.mem[_nd_179 + 1] = rfc_seal(e, 11ull);
      _o_461 = term_ctr(CID_OWNED, _nd_179);
    }
    Term _fv_1230[2];
    _fv_1230[0] = _o_460;
    _fv_1230[1] = _o_461;
    Term _fv_1231[1];
    _fv_1231[0] = 12000ull;
    Term _fv_1232[1];
    _fv_1232[0] = 12001ull;
    Term _fv_1233[1];
    _fv_1233[0] = 12002ull;
    Term _fv_1234[1];
    _fv_1234[0] = 12003ull;
    Term _fv_1235[1];
    _fv_1235[0] = 12004ull;
    Term _fv_1236[1];
    _fv_1236[0] = 12005ull;
    Term _fv_1237[1];
    _fv_1237[0] = 12006ull;
    Term _fv_1238[1];
    _fv_1238[0] = 12007ull;
    Term _fv_1239[1];
    _fv_1239[0] = 12008ull;
    Term _fv_1240[1];
    _fv_1240[0] = 12009ull;
    Term _fv_1241[1];
    _fv_1241[0] = 12010ull;
    Term _fv_1242[1];
    _fv_1242[0] = 12011ull;
    Term _fv_1243[1];
    _fv_1243[0] = 12012ull;
    Term _fv_1244[1];
    _fv_1244[0] = 12013ull;
    Term _fv_1245[1];
    _fv_1245[0] = 12014ull;
    Term _fv_1246[1];
    _fv_1246[0] = 12015ull;
    u32 _o_462 = 0;
    Term _o_463 = 0;
    Term _t_255 = 1;
    if (_t_255 == 0) {
      _o_462 = 0;
    } else {
      _o_462 = 1;
      u64 _nd_180 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_180 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1231), blk_new(e, 0, 0, 0, 1, _fv_1232)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1233), blk_new(e, 0, 0, 0, 1, _fv_1234))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1235), blk_new(e, 0, 0, 0, 1, _fv_1236)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1237), blk_new(e, 0, 0, 0, 1, _fv_1238)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1239), blk_new(e, 0, 0, 0, 1, _fv_1240)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1241), blk_new(e, 0, 0, 0, 1, _fv_1242))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1243), blk_new(e, 0, 0, 0, 1, _fv_1244)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1245), blk_new(e, 0, 0, 0, 1, _fv_1246))))));
      e.mem[_nd_180 + 1] = rfc_seal(e, 12ull);
      _o_463 = term_ctr(CID_OWNED, _nd_180);
    }
    Term _fv_1247[2];
    _fv_1247[0] = _o_462;
    _fv_1247[1] = _o_463;
    Term _fv_1248[1];
    _fv_1248[0] = 13000ull;
    Term _fv_1249[1];
    _fv_1249[0] = 13001ull;
    Term _fv_1250[1];
    _fv_1250[0] = 13002ull;
    Term _fv_1251[1];
    _fv_1251[0] = 13003ull;
    Term _fv_1252[1];
    _fv_1252[0] = 13004ull;
    Term _fv_1253[1];
    _fv_1253[0] = 13005ull;
    Term _fv_1254[1];
    _fv_1254[0] = 13006ull;
    Term _fv_1255[1];
    _fv_1255[0] = 13007ull;
    Term _fv_1256[1];
    _fv_1256[0] = 13008ull;
    Term _fv_1257[1];
    _fv_1257[0] = 13009ull;
    Term _fv_1258[1];
    _fv_1258[0] = 13010ull;
    Term _fv_1259[1];
    _fv_1259[0] = 13011ull;
    Term _fv_1260[1];
    _fv_1260[0] = 13012ull;
    Term _fv_1261[1];
    _fv_1261[0] = 13013ull;
    Term _fv_1262[1];
    _fv_1262[0] = 13014ull;
    Term _fv_1263[1];
    _fv_1263[0] = 13015ull;
    u32 _o_464 = 0;
    Term _o_465 = 0;
    Term _t_256 = 1;
    if (_t_256 == 0) {
      _o_464 = 0;
    } else {
      _o_464 = 1;
      u64 _nd_181 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_181 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1248), blk_new(e, 0, 0, 0, 1, _fv_1249)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1250), blk_new(e, 0, 0, 0, 1, _fv_1251))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1252), blk_new(e, 0, 0, 0, 1, _fv_1253)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1254), blk_new(e, 0, 0, 0, 1, _fv_1255)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1256), blk_new(e, 0, 0, 0, 1, _fv_1257)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1258), blk_new(e, 0, 0, 0, 1, _fv_1259))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1260), blk_new(e, 0, 0, 0, 1, _fv_1261)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1262), blk_new(e, 0, 0, 0, 1, _fv_1263))))));
      e.mem[_nd_181 + 1] = rfc_seal(e, 13ull);
      _o_465 = term_ctr(CID_OWNED, _nd_181);
    }
    Term _fv_1264[2];
    _fv_1264[0] = _o_464;
    _fv_1264[1] = _o_465;
    Term _fv_1265[1];
    _fv_1265[0] = 14000ull;
    Term _fv_1266[1];
    _fv_1266[0] = 14001ull;
    Term _fv_1267[1];
    _fv_1267[0] = 14002ull;
    Term _fv_1268[1];
    _fv_1268[0] = 14003ull;
    Term _fv_1269[1];
    _fv_1269[0] = 14004ull;
    Term _fv_1270[1];
    _fv_1270[0] = 14005ull;
    Term _fv_1271[1];
    _fv_1271[0] = 14006ull;
    Term _fv_1272[1];
    _fv_1272[0] = 14007ull;
    Term _fv_1273[1];
    _fv_1273[0] = 14008ull;
    Term _fv_1274[1];
    _fv_1274[0] = 14009ull;
    Term _fv_1275[1];
    _fv_1275[0] = 14010ull;
    Term _fv_1276[1];
    _fv_1276[0] = 14011ull;
    Term _fv_1277[1];
    _fv_1277[0] = 14012ull;
    Term _fv_1278[1];
    _fv_1278[0] = 14013ull;
    Term _fv_1279[1];
    _fv_1279[0] = 14014ull;
    Term _fv_1280[1];
    _fv_1280[0] = 14015ull;
    u32 _o_466 = 0;
    Term _o_467 = 0;
    Term _t_257 = 1;
    if (_t_257 == 0) {
      _o_466 = 0;
    } else {
      _o_466 = 1;
      u64 _nd_182 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_182 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1265), blk_new(e, 0, 0, 0, 1, _fv_1266)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1267), blk_new(e, 0, 0, 0, 1, _fv_1268))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1269), blk_new(e, 0, 0, 0, 1, _fv_1270)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1271), blk_new(e, 0, 0, 0, 1, _fv_1272)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1273), blk_new(e, 0, 0, 0, 1, _fv_1274)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1275), blk_new(e, 0, 0, 0, 1, _fv_1276))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1277), blk_new(e, 0, 0, 0, 1, _fv_1278)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1279), blk_new(e, 0, 0, 0, 1, _fv_1280))))));
      e.mem[_nd_182 + 1] = rfc_seal(e, 14ull);
      _o_467 = term_ctr(CID_OWNED, _nd_182);
    }
    Term _fv_1281[2];
    _fv_1281[0] = _o_466;
    _fv_1281[1] = _o_467;
    Term _fv_1282[1];
    _fv_1282[0] = 15000ull;
    Term _fv_1283[1];
    _fv_1283[0] = 15001ull;
    Term _fv_1284[1];
    _fv_1284[0] = 15002ull;
    Term _fv_1285[1];
    _fv_1285[0] = 15003ull;
    Term _fv_1286[1];
    _fv_1286[0] = 15004ull;
    Term _fv_1287[1];
    _fv_1287[0] = 15005ull;
    Term _fv_1288[1];
    _fv_1288[0] = 15006ull;
    Term _fv_1289[1];
    _fv_1289[0] = 15007ull;
    Term _fv_1290[1];
    _fv_1290[0] = 15008ull;
    Term _fv_1291[1];
    _fv_1291[0] = 15009ull;
    Term _fv_1292[1];
    _fv_1292[0] = 15010ull;
    Term _fv_1293[1];
    _fv_1293[0] = 15011ull;
    Term _fv_1294[1];
    _fv_1294[0] = 15012ull;
    Term _fv_1295[1];
    _fv_1295[0] = 15013ull;
    Term _fv_1296[1];
    _fv_1296[0] = 15014ull;
    Term _fv_1297[1];
    _fv_1297[0] = 15015ull;
    u32 _o_468 = 0;
    Term _o_469 = 0;
    Term _t_258 = 1;
    if (_t_258 == 0) {
      _o_468 = 0;
    } else {
      _o_468 = 1;
      u64 _nd_183 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_183 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1282), blk_new(e, 0, 0, 0, 1, _fv_1283)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1284), blk_new(e, 0, 0, 0, 1, _fv_1285))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1286), blk_new(e, 0, 0, 0, 1, _fv_1287)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1288), blk_new(e, 0, 0, 0, 1, _fv_1289)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1290), blk_new(e, 0, 0, 0, 1, _fv_1291)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1292), blk_new(e, 0, 0, 0, 1, _fv_1293))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1294), blk_new(e, 0, 0, 0, 1, _fv_1295)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1296), blk_new(e, 0, 0, 0, 1, _fv_1297))))));
      e.mem[_nd_183 + 1] = rfc_seal(e, 15ull);
      _o_469 = term_ctr(CID_OWNED, _nd_183);
    }
    Term _fv_1298[2];
    _fv_1298[0] = _o_468;
    _fv_1298[1] = _o_469;
    Term _fv_1299[1];
    _fv_1299[0] = 16000ull;
    Term _fv_1300[1];
    _fv_1300[0] = 16001ull;
    Term _fv_1301[1];
    _fv_1301[0] = 16002ull;
    Term _fv_1302[1];
    _fv_1302[0] = 16003ull;
    Term _fv_1303[1];
    _fv_1303[0] = 16004ull;
    Term _fv_1304[1];
    _fv_1304[0] = 16005ull;
    Term _fv_1305[1];
    _fv_1305[0] = 16006ull;
    Term _fv_1306[1];
    _fv_1306[0] = 16007ull;
    Term _fv_1307[1];
    _fv_1307[0] = 16008ull;
    Term _fv_1308[1];
    _fv_1308[0] = 16009ull;
    Term _fv_1309[1];
    _fv_1309[0] = 16010ull;
    Term _fv_1310[1];
    _fv_1310[0] = 16011ull;
    Term _fv_1311[1];
    _fv_1311[0] = 16012ull;
    Term _fv_1312[1];
    _fv_1312[0] = 16013ull;
    Term _fv_1313[1];
    _fv_1313[0] = 16014ull;
    Term _fv_1314[1];
    _fv_1314[0] = 16015ull;
    u32 _o_470 = 0;
    Term _o_471 = 0;
    Term _t_259 = 1;
    if (_t_259 == 0) {
      _o_470 = 0;
    } else {
      _o_470 = 1;
      u64 _nd_184 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_184 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1299), blk_new(e, 0, 0, 0, 1, _fv_1300)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1301), blk_new(e, 0, 0, 0, 1, _fv_1302))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1303), blk_new(e, 0, 0, 0, 1, _fv_1304)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1305), blk_new(e, 0, 0, 0, 1, _fv_1306)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1307), blk_new(e, 0, 0, 0, 1, _fv_1308)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1309), blk_new(e, 0, 0, 0, 1, _fv_1310))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1311), blk_new(e, 0, 0, 0, 1, _fv_1312)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1313), blk_new(e, 0, 0, 0, 1, _fv_1314))))));
      e.mem[_nd_184 + 1] = rfc_seal(e, 16ull);
      _o_471 = term_ctr(CID_OWNED, _nd_184);
    }
    Term _fv_1315[2];
    _fv_1315[0] = _o_470;
    _fv_1315[1] = _o_471;
    Term _fv_1316[1];
    _fv_1316[0] = 101000ull;
    Term _fv_1317[1];
    _fv_1317[0] = 101001ull;
    Term _fv_1318[1];
    _fv_1318[0] = 101002ull;
    Term _fv_1319[1];
    _fv_1319[0] = 101003ull;
    Term _fv_1320[1];
    _fv_1320[0] = 101004ull;
    Term _fv_1321[1];
    _fv_1321[0] = 101005ull;
    Term _fv_1322[1];
    _fv_1322[0] = 101006ull;
    Term _fv_1323[1];
    _fv_1323[0] = 101007ull;
    Term _fv_1324[1];
    _fv_1324[0] = 101008ull;
    Term _fv_1325[1];
    _fv_1325[0] = 101009ull;
    Term _fv_1326[1];
    _fv_1326[0] = 101010ull;
    Term _fv_1327[1];
    _fv_1327[0] = 101011ull;
    Term _fv_1328[1];
    _fv_1328[0] = 101012ull;
    Term _fv_1329[1];
    _fv_1329[0] = 101013ull;
    Term _fv_1330[1];
    _fv_1330[0] = 101014ull;
    Term _fv_1331[1];
    _fv_1331[0] = 101015ull;
    u32 _o_472 = 0;
    Term _o_473 = 0;
    Term _t_260 = 1;
    if (_t_260 == 0) {
      _o_472 = 0;
    } else {
      _o_472 = 1;
      u64 _nd_185 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_185 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1316), blk_new(e, 0, 0, 0, 1, _fv_1317)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1318), blk_new(e, 0, 0, 0, 1, _fv_1319))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1320), blk_new(e, 0, 0, 0, 1, _fv_1321)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1322), blk_new(e, 0, 0, 0, 1, _fv_1323)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1324), blk_new(e, 0, 0, 0, 1, _fv_1325)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1326), blk_new(e, 0, 0, 0, 1, _fv_1327))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1328), blk_new(e, 0, 0, 0, 1, _fv_1329)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1330), blk_new(e, 0, 0, 0, 1, _fv_1331))))));
      e.mem[_nd_185 + 1] = rfc_seal(e, 101ull);
      _o_473 = term_ctr(CID_OWNED, _nd_185);
    }
    Term _fv_1332[2];
    _fv_1332[0] = _o_472;
    _fv_1332[1] = _o_473;
    Term _fv_1333[1];
    _fv_1333[0] = 102000ull;
    Term _fv_1334[1];
    _fv_1334[0] = 102001ull;
    Term _fv_1335[1];
    _fv_1335[0] = 102002ull;
    Term _fv_1336[1];
    _fv_1336[0] = 102003ull;
    Term _fv_1337[1];
    _fv_1337[0] = 102004ull;
    Term _fv_1338[1];
    _fv_1338[0] = 102005ull;
    Term _fv_1339[1];
    _fv_1339[0] = 102006ull;
    Term _fv_1340[1];
    _fv_1340[0] = 102007ull;
    Term _fv_1341[1];
    _fv_1341[0] = 102008ull;
    Term _fv_1342[1];
    _fv_1342[0] = 102009ull;
    Term _fv_1343[1];
    _fv_1343[0] = 102010ull;
    Term _fv_1344[1];
    _fv_1344[0] = 102011ull;
    Term _fv_1345[1];
    _fv_1345[0] = 102012ull;
    Term _fv_1346[1];
    _fv_1346[0] = 102013ull;
    Term _fv_1347[1];
    _fv_1347[0] = 102014ull;
    Term _fv_1348[1];
    _fv_1348[0] = 102015ull;
    u32 _o_474 = 0;
    Term _o_475 = 0;
    Term _t_261 = 1;
    if (_t_261 == 0) {
      _o_474 = 0;
    } else {
      _o_474 = 1;
      u64 _nd_186 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_186 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1333), blk_new(e, 0, 0, 0, 1, _fv_1334)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1335), blk_new(e, 0, 0, 0, 1, _fv_1336))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1337), blk_new(e, 0, 0, 0, 1, _fv_1338)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1339), blk_new(e, 0, 0, 0, 1, _fv_1340)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1341), blk_new(e, 0, 0, 0, 1, _fv_1342)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1343), blk_new(e, 0, 0, 0, 1, _fv_1344))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1345), blk_new(e, 0, 0, 0, 1, _fv_1346)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1347), blk_new(e, 0, 0, 0, 1, _fv_1348))))));
      e.mem[_nd_186 + 1] = rfc_seal(e, 102ull);
      _o_475 = term_ctr(CID_OWNED, _nd_186);
    }
    Term _fv_1349[2];
    _fv_1349[0] = _o_474;
    _fv_1349[1] = _o_475;
    Term _fv_1350[1];
    _fv_1350[0] = 103000ull;
    Term _fv_1351[1];
    _fv_1351[0] = 103001ull;
    Term _fv_1352[1];
    _fv_1352[0] = 103002ull;
    Term _fv_1353[1];
    _fv_1353[0] = 103003ull;
    Term _fv_1354[1];
    _fv_1354[0] = 103004ull;
    Term _fv_1355[1];
    _fv_1355[0] = 103005ull;
    Term _fv_1356[1];
    _fv_1356[0] = 103006ull;
    Term _fv_1357[1];
    _fv_1357[0] = 103007ull;
    Term _fv_1358[1];
    _fv_1358[0] = 103008ull;
    Term _fv_1359[1];
    _fv_1359[0] = 103009ull;
    Term _fv_1360[1];
    _fv_1360[0] = 103010ull;
    Term _fv_1361[1];
    _fv_1361[0] = 103011ull;
    Term _fv_1362[1];
    _fv_1362[0] = 103012ull;
    Term _fv_1363[1];
    _fv_1363[0] = 103013ull;
    Term _fv_1364[1];
    _fv_1364[0] = 103014ull;
    Term _fv_1365[1];
    _fv_1365[0] = 103015ull;
    u32 _o_476 = 0;
    Term _o_477 = 0;
    Term _t_262 = 1;
    if (_t_262 == 0) {
      _o_476 = 0;
    } else {
      _o_476 = 1;
      u64 _nd_187 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_187 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1350), blk_new(e, 0, 0, 0, 1, _fv_1351)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1352), blk_new(e, 0, 0, 0, 1, _fv_1353))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1354), blk_new(e, 0, 0, 0, 1, _fv_1355)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1356), blk_new(e, 0, 0, 0, 1, _fv_1357)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1358), blk_new(e, 0, 0, 0, 1, _fv_1359)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1360), blk_new(e, 0, 0, 0, 1, _fv_1361))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1362), blk_new(e, 0, 0, 0, 1, _fv_1363)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1364), blk_new(e, 0, 0, 0, 1, _fv_1365))))));
      e.mem[_nd_187 + 1] = rfc_seal(e, 103ull);
      _o_477 = term_ctr(CID_OWNED, _nd_187);
    }
    Term _fv_1366[2];
    _fv_1366[0] = _o_476;
    _fv_1366[1] = _o_477;
    Term _fv_1367[1];
    _fv_1367[0] = 104000ull;
    Term _fv_1368[1];
    _fv_1368[0] = 104001ull;
    Term _fv_1369[1];
    _fv_1369[0] = 104002ull;
    Term _fv_1370[1];
    _fv_1370[0] = 104003ull;
    Term _fv_1371[1];
    _fv_1371[0] = 104004ull;
    Term _fv_1372[1];
    _fv_1372[0] = 104005ull;
    Term _fv_1373[1];
    _fv_1373[0] = 104006ull;
    Term _fv_1374[1];
    _fv_1374[0] = 104007ull;
    Term _fv_1375[1];
    _fv_1375[0] = 104008ull;
    Term _fv_1376[1];
    _fv_1376[0] = 104009ull;
    Term _fv_1377[1];
    _fv_1377[0] = 104010ull;
    Term _fv_1378[1];
    _fv_1378[0] = 104011ull;
    Term _fv_1379[1];
    _fv_1379[0] = 104012ull;
    Term _fv_1380[1];
    _fv_1380[0] = 104013ull;
    Term _fv_1381[1];
    _fv_1381[0] = 104014ull;
    Term _fv_1382[1];
    _fv_1382[0] = 104015ull;
    u32 _o_478 = 0;
    Term _o_479 = 0;
    Term _t_263 = 1;
    if (_t_263 == 0) {
      _o_478 = 0;
    } else {
      _o_478 = 1;
      u64 _nd_188 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_188 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1367), blk_new(e, 0, 0, 0, 1, _fv_1368)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1369), blk_new(e, 0, 0, 0, 1, _fv_1370))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1371), blk_new(e, 0, 0, 0, 1, _fv_1372)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1373), blk_new(e, 0, 0, 0, 1, _fv_1374)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1375), blk_new(e, 0, 0, 0, 1, _fv_1376)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1377), blk_new(e, 0, 0, 0, 1, _fv_1378))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1379), blk_new(e, 0, 0, 0, 1, _fv_1380)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1381), blk_new(e, 0, 0, 0, 1, _fv_1382))))));
      e.mem[_nd_188 + 1] = rfc_seal(e, 104ull);
      _o_479 = term_ctr(CID_OWNED, _nd_188);
    }
    Term _fv_1383[2];
    _fv_1383[0] = _o_478;
    _fv_1383[1] = _o_479;
    Term _fv_1384[1];
    _fv_1384[0] = 105000ull;
    Term _fv_1385[1];
    _fv_1385[0] = 105001ull;
    Term _fv_1386[1];
    _fv_1386[0] = 105002ull;
    Term _fv_1387[1];
    _fv_1387[0] = 105003ull;
    Term _fv_1388[1];
    _fv_1388[0] = 105004ull;
    Term _fv_1389[1];
    _fv_1389[0] = 105005ull;
    Term _fv_1390[1];
    _fv_1390[0] = 105006ull;
    Term _fv_1391[1];
    _fv_1391[0] = 105007ull;
    Term _fv_1392[1];
    _fv_1392[0] = 105008ull;
    Term _fv_1393[1];
    _fv_1393[0] = 105009ull;
    Term _fv_1394[1];
    _fv_1394[0] = 105010ull;
    Term _fv_1395[1];
    _fv_1395[0] = 105011ull;
    Term _fv_1396[1];
    _fv_1396[0] = 105012ull;
    Term _fv_1397[1];
    _fv_1397[0] = 105013ull;
    Term _fv_1398[1];
    _fv_1398[0] = 105014ull;
    Term _fv_1399[1];
    _fv_1399[0] = 105015ull;
    u32 _o_480 = 0;
    Term _o_481 = 0;
    Term _t_264 = 1;
    if (_t_264 == 0) {
      _o_480 = 0;
    } else {
      _o_480 = 1;
      u64 _nd_189 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_189 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1384), blk_new(e, 0, 0, 0, 1, _fv_1385)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1386), blk_new(e, 0, 0, 0, 1, _fv_1387))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1388), blk_new(e, 0, 0, 0, 1, _fv_1389)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1390), blk_new(e, 0, 0, 0, 1, _fv_1391)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1392), blk_new(e, 0, 0, 0, 1, _fv_1393)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1394), blk_new(e, 0, 0, 0, 1, _fv_1395))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1396), blk_new(e, 0, 0, 0, 1, _fv_1397)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1398), blk_new(e, 0, 0, 0, 1, _fv_1399))))));
      e.mem[_nd_189 + 1] = rfc_seal(e, 105ull);
      _o_481 = term_ctr(CID_OWNED, _nd_189);
    }
    Term _fv_1400[2];
    _fv_1400[0] = _o_480;
    _fv_1400[1] = _o_481;
    Term _fv_1401[1];
    _fv_1401[0] = 106000ull;
    Term _fv_1402[1];
    _fv_1402[0] = 106001ull;
    Term _fv_1403[1];
    _fv_1403[0] = 106002ull;
    Term _fv_1404[1];
    _fv_1404[0] = 106003ull;
    Term _fv_1405[1];
    _fv_1405[0] = 106004ull;
    Term _fv_1406[1];
    _fv_1406[0] = 106005ull;
    Term _fv_1407[1];
    _fv_1407[0] = 106006ull;
    Term _fv_1408[1];
    _fv_1408[0] = 106007ull;
    Term _fv_1409[1];
    _fv_1409[0] = 106008ull;
    Term _fv_1410[1];
    _fv_1410[0] = 106009ull;
    Term _fv_1411[1];
    _fv_1411[0] = 106010ull;
    Term _fv_1412[1];
    _fv_1412[0] = 106011ull;
    Term _fv_1413[1];
    _fv_1413[0] = 106012ull;
    Term _fv_1414[1];
    _fv_1414[0] = 106013ull;
    Term _fv_1415[1];
    _fv_1415[0] = 106014ull;
    Term _fv_1416[1];
    _fv_1416[0] = 106015ull;
    u32 _o_482 = 0;
    Term _o_483 = 0;
    Term _t_265 = 1;
    if (_t_265 == 0) {
      _o_482 = 0;
    } else {
      _o_482 = 1;
      u64 _nd_190 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_190 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1401), blk_new(e, 0, 0, 0, 1, _fv_1402)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1403), blk_new(e, 0, 0, 0, 1, _fv_1404))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1405), blk_new(e, 0, 0, 0, 1, _fv_1406)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1407), blk_new(e, 0, 0, 0, 1, _fv_1408)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1409), blk_new(e, 0, 0, 0, 1, _fv_1410)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1411), blk_new(e, 0, 0, 0, 1, _fv_1412))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1413), blk_new(e, 0, 0, 0, 1, _fv_1414)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1415), blk_new(e, 0, 0, 0, 1, _fv_1416))))));
      e.mem[_nd_190 + 1] = rfc_seal(e, 106ull);
      _o_483 = term_ctr(CID_OWNED, _nd_190);
    }
    Term _fv_1417[2];
    _fv_1417[0] = _o_482;
    _fv_1417[1] = _o_483;
    Term _fv_1418[1];
    _fv_1418[0] = 107000ull;
    Term _fv_1419[1];
    _fv_1419[0] = 107001ull;
    Term _fv_1420[1];
    _fv_1420[0] = 107002ull;
    Term _fv_1421[1];
    _fv_1421[0] = 107003ull;
    Term _fv_1422[1];
    _fv_1422[0] = 107004ull;
    Term _fv_1423[1];
    _fv_1423[0] = 107005ull;
    Term _fv_1424[1];
    _fv_1424[0] = 107006ull;
    Term _fv_1425[1];
    _fv_1425[0] = 107007ull;
    Term _fv_1426[1];
    _fv_1426[0] = 107008ull;
    Term _fv_1427[1];
    _fv_1427[0] = 107009ull;
    Term _fv_1428[1];
    _fv_1428[0] = 107010ull;
    Term _fv_1429[1];
    _fv_1429[0] = 107011ull;
    Term _fv_1430[1];
    _fv_1430[0] = 107012ull;
    Term _fv_1431[1];
    _fv_1431[0] = 107013ull;
    Term _fv_1432[1];
    _fv_1432[0] = 107014ull;
    Term _fv_1433[1];
    _fv_1433[0] = 107015ull;
    u32 _o_484 = 0;
    Term _o_485 = 0;
    Term _t_266 = 1;
    if (_t_266 == 0) {
      _o_484 = 0;
    } else {
      _o_484 = 1;
      u64 _nd_191 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_191 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1418), blk_new(e, 0, 0, 0, 1, _fv_1419)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1420), blk_new(e, 0, 0, 0, 1, _fv_1421))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1422), blk_new(e, 0, 0, 0, 1, _fv_1423)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1424), blk_new(e, 0, 0, 0, 1, _fv_1425)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1426), blk_new(e, 0, 0, 0, 1, _fv_1427)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1428), blk_new(e, 0, 0, 0, 1, _fv_1429))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1430), blk_new(e, 0, 0, 0, 1, _fv_1431)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1432), blk_new(e, 0, 0, 0, 1, _fv_1433))))));
      e.mem[_nd_191 + 1] = rfc_seal(e, 107ull);
      _o_485 = term_ctr(CID_OWNED, _nd_191);
    }
    Term _fv_1434[2];
    _fv_1434[0] = _o_484;
    _fv_1434[1] = _o_485;
    Term _fv_1435[1];
    _fv_1435[0] = 108000ull;
    Term _fv_1436[1];
    _fv_1436[0] = 108001ull;
    Term _fv_1437[1];
    _fv_1437[0] = 108002ull;
    Term _fv_1438[1];
    _fv_1438[0] = 108003ull;
    Term _fv_1439[1];
    _fv_1439[0] = 108004ull;
    Term _fv_1440[1];
    _fv_1440[0] = 108005ull;
    Term _fv_1441[1];
    _fv_1441[0] = 108006ull;
    Term _fv_1442[1];
    _fv_1442[0] = 108007ull;
    Term _fv_1443[1];
    _fv_1443[0] = 108008ull;
    Term _fv_1444[1];
    _fv_1444[0] = 108009ull;
    Term _fv_1445[1];
    _fv_1445[0] = 108010ull;
    Term _fv_1446[1];
    _fv_1446[0] = 108011ull;
    Term _fv_1447[1];
    _fv_1447[0] = 108012ull;
    Term _fv_1448[1];
    _fv_1448[0] = 108013ull;
    Term _fv_1449[1];
    _fv_1449[0] = 108014ull;
    Term _fv_1450[1];
    _fv_1450[0] = 108015ull;
    u32 _o_486 = 0;
    Term _o_487 = 0;
    Term _t_267 = 1;
    if (_t_267 == 0) {
      _o_486 = 0;
    } else {
      _o_486 = 1;
      u64 _nd_192 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_192 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1435), blk_new(e, 0, 0, 0, 1, _fv_1436)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1437), blk_new(e, 0, 0, 0, 1, _fv_1438))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1439), blk_new(e, 0, 0, 0, 1, _fv_1440)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1441), blk_new(e, 0, 0, 0, 1, _fv_1442)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1443), blk_new(e, 0, 0, 0, 1, _fv_1444)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1445), blk_new(e, 0, 0, 0, 1, _fv_1446))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1447), blk_new(e, 0, 0, 0, 1, _fv_1448)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1449), blk_new(e, 0, 0, 0, 1, _fv_1450))))));
      e.mem[_nd_192 + 1] = rfc_seal(e, 108ull);
      _o_487 = term_ctr(CID_OWNED, _nd_192);
    }
    Term _fv_1451[2];
    _fv_1451[0] = _o_486;
    _fv_1451[1] = _o_487;
    Term _fv_1452[1];
    _fv_1452[0] = 109000ull;
    Term _fv_1453[1];
    _fv_1453[0] = 109001ull;
    Term _fv_1454[1];
    _fv_1454[0] = 109002ull;
    Term _fv_1455[1];
    _fv_1455[0] = 109003ull;
    Term _fv_1456[1];
    _fv_1456[0] = 109004ull;
    Term _fv_1457[1];
    _fv_1457[0] = 109005ull;
    Term _fv_1458[1];
    _fv_1458[0] = 109006ull;
    Term _fv_1459[1];
    _fv_1459[0] = 109007ull;
    Term _fv_1460[1];
    _fv_1460[0] = 109008ull;
    Term _fv_1461[1];
    _fv_1461[0] = 109009ull;
    Term _fv_1462[1];
    _fv_1462[0] = 109010ull;
    Term _fv_1463[1];
    _fv_1463[0] = 109011ull;
    Term _fv_1464[1];
    _fv_1464[0] = 109012ull;
    Term _fv_1465[1];
    _fv_1465[0] = 109013ull;
    Term _fv_1466[1];
    _fv_1466[0] = 109014ull;
    Term _fv_1467[1];
    _fv_1467[0] = 109015ull;
    u32 _o_488 = 0;
    Term _o_489 = 0;
    Term _t_268 = 1;
    if (_t_268 == 0) {
      _o_488 = 0;
    } else {
      _o_488 = 1;
      u64 _nd_193 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_193 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1452), blk_new(e, 0, 0, 0, 1, _fv_1453)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1454), blk_new(e, 0, 0, 0, 1, _fv_1455))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1456), blk_new(e, 0, 0, 0, 1, _fv_1457)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1458), blk_new(e, 0, 0, 0, 1, _fv_1459)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1460), blk_new(e, 0, 0, 0, 1, _fv_1461)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1462), blk_new(e, 0, 0, 0, 1, _fv_1463))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1464), blk_new(e, 0, 0, 0, 1, _fv_1465)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1466), blk_new(e, 0, 0, 0, 1, _fv_1467))))));
      e.mem[_nd_193 + 1] = rfc_seal(e, 109ull);
      _o_489 = term_ctr(CID_OWNED, _nd_193);
    }
    Term _fv_1468[2];
    _fv_1468[0] = _o_488;
    _fv_1468[1] = _o_489;
    Term _fv_1469[1];
    _fv_1469[0] = 110000ull;
    Term _fv_1470[1];
    _fv_1470[0] = 110001ull;
    Term _fv_1471[1];
    _fv_1471[0] = 110002ull;
    Term _fv_1472[1];
    _fv_1472[0] = 110003ull;
    Term _fv_1473[1];
    _fv_1473[0] = 110004ull;
    Term _fv_1474[1];
    _fv_1474[0] = 110005ull;
    Term _fv_1475[1];
    _fv_1475[0] = 110006ull;
    Term _fv_1476[1];
    _fv_1476[0] = 110007ull;
    Term _fv_1477[1];
    _fv_1477[0] = 110008ull;
    Term _fv_1478[1];
    _fv_1478[0] = 110009ull;
    Term _fv_1479[1];
    _fv_1479[0] = 110010ull;
    Term _fv_1480[1];
    _fv_1480[0] = 110011ull;
    Term _fv_1481[1];
    _fv_1481[0] = 110012ull;
    Term _fv_1482[1];
    _fv_1482[0] = 110013ull;
    Term _fv_1483[1];
    _fv_1483[0] = 110014ull;
    Term _fv_1484[1];
    _fv_1484[0] = 110015ull;
    u32 _o_490 = 0;
    Term _o_491 = 0;
    Term _t_269 = 1;
    if (_t_269 == 0) {
      _o_490 = 0;
    } else {
      _o_490 = 1;
      u64 _nd_194 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_194 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1469), blk_new(e, 0, 0, 0, 1, _fv_1470)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1471), blk_new(e, 0, 0, 0, 1, _fv_1472))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1473), blk_new(e, 0, 0, 0, 1, _fv_1474)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1475), blk_new(e, 0, 0, 0, 1, _fv_1476)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1477), blk_new(e, 0, 0, 0, 1, _fv_1478)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1479), blk_new(e, 0, 0, 0, 1, _fv_1480))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1481), blk_new(e, 0, 0, 0, 1, _fv_1482)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1483), blk_new(e, 0, 0, 0, 1, _fv_1484))))));
      e.mem[_nd_194 + 1] = rfc_seal(e, 110ull);
      _o_491 = term_ctr(CID_OWNED, _nd_194);
    }
    Term _fv_1485[2];
    _fv_1485[0] = _o_490;
    _fv_1485[1] = _o_491;
    Term _fv_1486[1];
    _fv_1486[0] = 111000ull;
    Term _fv_1487[1];
    _fv_1487[0] = 111001ull;
    Term _fv_1488[1];
    _fv_1488[0] = 111002ull;
    Term _fv_1489[1];
    _fv_1489[0] = 111003ull;
    Term _fv_1490[1];
    _fv_1490[0] = 111004ull;
    Term _fv_1491[1];
    _fv_1491[0] = 111005ull;
    Term _fv_1492[1];
    _fv_1492[0] = 111006ull;
    Term _fv_1493[1];
    _fv_1493[0] = 111007ull;
    Term _fv_1494[1];
    _fv_1494[0] = 111008ull;
    Term _fv_1495[1];
    _fv_1495[0] = 111009ull;
    Term _fv_1496[1];
    _fv_1496[0] = 111010ull;
    Term _fv_1497[1];
    _fv_1497[0] = 111011ull;
    Term _fv_1498[1];
    _fv_1498[0] = 111012ull;
    Term _fv_1499[1];
    _fv_1499[0] = 111013ull;
    Term _fv_1500[1];
    _fv_1500[0] = 111014ull;
    Term _fv_1501[1];
    _fv_1501[0] = 111015ull;
    u32 _o_492 = 0;
    Term _o_493 = 0;
    Term _t_270 = 1;
    if (_t_270 == 0) {
      _o_492 = 0;
    } else {
      _o_492 = 1;
      u64 _nd_195 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_195 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1486), blk_new(e, 0, 0, 0, 1, _fv_1487)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1488), blk_new(e, 0, 0, 0, 1, _fv_1489))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1490), blk_new(e, 0, 0, 0, 1, _fv_1491)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1492), blk_new(e, 0, 0, 0, 1, _fv_1493)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1494), blk_new(e, 0, 0, 0, 1, _fv_1495)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1496), blk_new(e, 0, 0, 0, 1, _fv_1497))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1498), blk_new(e, 0, 0, 0, 1, _fv_1499)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1500), blk_new(e, 0, 0, 0, 1, _fv_1501))))));
      e.mem[_nd_195 + 1] = rfc_seal(e, 111ull);
      _o_493 = term_ctr(CID_OWNED, _nd_195);
    }
    Term _fv_1502[2];
    _fv_1502[0] = _o_492;
    _fv_1502[1] = _o_493;
    Term _fv_1503[1];
    _fv_1503[0] = 112000ull;
    Term _fv_1504[1];
    _fv_1504[0] = 112001ull;
    Term _fv_1505[1];
    _fv_1505[0] = 112002ull;
    Term _fv_1506[1];
    _fv_1506[0] = 112003ull;
    Term _fv_1507[1];
    _fv_1507[0] = 112004ull;
    Term _fv_1508[1];
    _fv_1508[0] = 112005ull;
    Term _fv_1509[1];
    _fv_1509[0] = 112006ull;
    Term _fv_1510[1];
    _fv_1510[0] = 112007ull;
    Term _fv_1511[1];
    _fv_1511[0] = 112008ull;
    Term _fv_1512[1];
    _fv_1512[0] = 112009ull;
    Term _fv_1513[1];
    _fv_1513[0] = 112010ull;
    Term _fv_1514[1];
    _fv_1514[0] = 112011ull;
    Term _fv_1515[1];
    _fv_1515[0] = 112012ull;
    Term _fv_1516[1];
    _fv_1516[0] = 112013ull;
    Term _fv_1517[1];
    _fv_1517[0] = 112014ull;
    Term _fv_1518[1];
    _fv_1518[0] = 112015ull;
    u32 _o_494 = 0;
    Term _o_495 = 0;
    Term _t_271 = 1;
    if (_t_271 == 0) {
      _o_494 = 0;
    } else {
      _o_494 = 1;
      u64 _nd_196 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_196 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1503), blk_new(e, 0, 0, 0, 1, _fv_1504)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1505), blk_new(e, 0, 0, 0, 1, _fv_1506))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1507), blk_new(e, 0, 0, 0, 1, _fv_1508)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1509), blk_new(e, 0, 0, 0, 1, _fv_1510)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1511), blk_new(e, 0, 0, 0, 1, _fv_1512)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1513), blk_new(e, 0, 0, 0, 1, _fv_1514))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1515), blk_new(e, 0, 0, 0, 1, _fv_1516)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1517), blk_new(e, 0, 0, 0, 1, _fv_1518))))));
      e.mem[_nd_196 + 1] = rfc_seal(e, 112ull);
      _o_495 = term_ctr(CID_OWNED, _nd_196);
    }
    Term _fv_1519[2];
    _fv_1519[0] = _o_494;
    _fv_1519[1] = _o_495;
    Term _fv_1520[1];
    _fv_1520[0] = 113000ull;
    Term _fv_1521[1];
    _fv_1521[0] = 113001ull;
    Term _fv_1522[1];
    _fv_1522[0] = 113002ull;
    Term _fv_1523[1];
    _fv_1523[0] = 113003ull;
    Term _fv_1524[1];
    _fv_1524[0] = 113004ull;
    Term _fv_1525[1];
    _fv_1525[0] = 113005ull;
    Term _fv_1526[1];
    _fv_1526[0] = 113006ull;
    Term _fv_1527[1];
    _fv_1527[0] = 113007ull;
    Term _fv_1528[1];
    _fv_1528[0] = 113008ull;
    Term _fv_1529[1];
    _fv_1529[0] = 113009ull;
    Term _fv_1530[1];
    _fv_1530[0] = 113010ull;
    Term _fv_1531[1];
    _fv_1531[0] = 113011ull;
    Term _fv_1532[1];
    _fv_1532[0] = 113012ull;
    Term _fv_1533[1];
    _fv_1533[0] = 113013ull;
    Term _fv_1534[1];
    _fv_1534[0] = 113014ull;
    Term _fv_1535[1];
    _fv_1535[0] = 113015ull;
    u32 _o_496 = 0;
    Term _o_497 = 0;
    Term _t_272 = 1;
    if (_t_272 == 0) {
      _o_496 = 0;
    } else {
      _o_496 = 1;
      u64 _nd_197 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_197 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1520), blk_new(e, 0, 0, 0, 1, _fv_1521)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1522), blk_new(e, 0, 0, 0, 1, _fv_1523))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1524), blk_new(e, 0, 0, 0, 1, _fv_1525)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1526), blk_new(e, 0, 0, 0, 1, _fv_1527)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1528), blk_new(e, 0, 0, 0, 1, _fv_1529)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1530), blk_new(e, 0, 0, 0, 1, _fv_1531))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1532), blk_new(e, 0, 0, 0, 1, _fv_1533)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1534), blk_new(e, 0, 0, 0, 1, _fv_1535))))));
      e.mem[_nd_197 + 1] = rfc_seal(e, 113ull);
      _o_497 = term_ctr(CID_OWNED, _nd_197);
    }
    Term _fv_1536[2];
    _fv_1536[0] = _o_496;
    _fv_1536[1] = _o_497;
    Term _fv_1537[1];
    _fv_1537[0] = 114000ull;
    Term _fv_1538[1];
    _fv_1538[0] = 114001ull;
    Term _fv_1539[1];
    _fv_1539[0] = 114002ull;
    Term _fv_1540[1];
    _fv_1540[0] = 114003ull;
    Term _fv_1541[1];
    _fv_1541[0] = 114004ull;
    Term _fv_1542[1];
    _fv_1542[0] = 114005ull;
    Term _fv_1543[1];
    _fv_1543[0] = 114006ull;
    Term _fv_1544[1];
    _fv_1544[0] = 114007ull;
    Term _fv_1545[1];
    _fv_1545[0] = 114008ull;
    Term _fv_1546[1];
    _fv_1546[0] = 114009ull;
    Term _fv_1547[1];
    _fv_1547[0] = 114010ull;
    Term _fv_1548[1];
    _fv_1548[0] = 114011ull;
    Term _fv_1549[1];
    _fv_1549[0] = 114012ull;
    Term _fv_1550[1];
    _fv_1550[0] = 114013ull;
    Term _fv_1551[1];
    _fv_1551[0] = 114014ull;
    Term _fv_1552[1];
    _fv_1552[0] = 114015ull;
    u32 _o_498 = 0;
    Term _o_499 = 0;
    Term _t_273 = 1;
    if (_t_273 == 0) {
      _o_498 = 0;
    } else {
      _o_498 = 1;
      u64 _nd_198 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_198 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1537), blk_new(e, 0, 0, 0, 1, _fv_1538)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1539), blk_new(e, 0, 0, 0, 1, _fv_1540))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1541), blk_new(e, 0, 0, 0, 1, _fv_1542)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1543), blk_new(e, 0, 0, 0, 1, _fv_1544)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1545), blk_new(e, 0, 0, 0, 1, _fv_1546)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1547), blk_new(e, 0, 0, 0, 1, _fv_1548))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1549), blk_new(e, 0, 0, 0, 1, _fv_1550)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1551), blk_new(e, 0, 0, 0, 1, _fv_1552))))));
      e.mem[_nd_198 + 1] = rfc_seal(e, 114ull);
      _o_499 = term_ctr(CID_OWNED, _nd_198);
    }
    Term _fv_1553[2];
    _fv_1553[0] = _o_498;
    _fv_1553[1] = _o_499;
    Term _fv_1554[1];
    _fv_1554[0] = 115000ull;
    Term _fv_1555[1];
    _fv_1555[0] = 115001ull;
    Term _fv_1556[1];
    _fv_1556[0] = 115002ull;
    Term _fv_1557[1];
    _fv_1557[0] = 115003ull;
    Term _fv_1558[1];
    _fv_1558[0] = 115004ull;
    Term _fv_1559[1];
    _fv_1559[0] = 115005ull;
    Term _fv_1560[1];
    _fv_1560[0] = 115006ull;
    Term _fv_1561[1];
    _fv_1561[0] = 115007ull;
    Term _fv_1562[1];
    _fv_1562[0] = 115008ull;
    Term _fv_1563[1];
    _fv_1563[0] = 115009ull;
    Term _fv_1564[1];
    _fv_1564[0] = 115010ull;
    Term _fv_1565[1];
    _fv_1565[0] = 115011ull;
    Term _fv_1566[1];
    _fv_1566[0] = 115012ull;
    Term _fv_1567[1];
    _fv_1567[0] = 115013ull;
    Term _fv_1568[1];
    _fv_1568[0] = 115014ull;
    Term _fv_1569[1];
    _fv_1569[0] = 115015ull;
    u32 _o_500 = 0;
    Term _o_501 = 0;
    Term _t_274 = 1;
    if (_t_274 == 0) {
      _o_500 = 0;
    } else {
      _o_500 = 1;
      u64 _nd_199 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_199 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1554), blk_new(e, 0, 0, 0, 1, _fv_1555)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1556), blk_new(e, 0, 0, 0, 1, _fv_1557))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1558), blk_new(e, 0, 0, 0, 1, _fv_1559)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1560), blk_new(e, 0, 0, 0, 1, _fv_1561)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1562), blk_new(e, 0, 0, 0, 1, _fv_1563)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1564), blk_new(e, 0, 0, 0, 1, _fv_1565))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1566), blk_new(e, 0, 0, 0, 1, _fv_1567)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1568), blk_new(e, 0, 0, 0, 1, _fv_1569))))));
      e.mem[_nd_199 + 1] = rfc_seal(e, 115ull);
      _o_501 = term_ctr(CID_OWNED, _nd_199);
    }
    Term _fv_1570[2];
    _fv_1570[0] = _o_500;
    _fv_1570[1] = _o_501;
    Term _fv_1571[1];
    _fv_1571[0] = 116000ull;
    Term _fv_1572[1];
    _fv_1572[0] = 116001ull;
    Term _fv_1573[1];
    _fv_1573[0] = 116002ull;
    Term _fv_1574[1];
    _fv_1574[0] = 116003ull;
    Term _fv_1575[1];
    _fv_1575[0] = 116004ull;
    Term _fv_1576[1];
    _fv_1576[0] = 116005ull;
    Term _fv_1577[1];
    _fv_1577[0] = 116006ull;
    Term _fv_1578[1];
    _fv_1578[0] = 116007ull;
    Term _fv_1579[1];
    _fv_1579[0] = 116008ull;
    Term _fv_1580[1];
    _fv_1580[0] = 116009ull;
    Term _fv_1581[1];
    _fv_1581[0] = 116010ull;
    Term _fv_1582[1];
    _fv_1582[0] = 116011ull;
    Term _fv_1583[1];
    _fv_1583[0] = 116012ull;
    Term _fv_1584[1];
    _fv_1584[0] = 116013ull;
    Term _fv_1585[1];
    _fv_1585[0] = 116014ull;
    Term _fv_1586[1];
    _fv_1586[0] = 116015ull;
    u32 _o_502 = 0;
    Term _o_503 = 0;
    Term _t_275 = 1;
    if (_t_275 == 0) {
      _o_502 = 0;
    } else {
      _o_502 = 1;
      u64 _nd_200 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_200 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1571), blk_new(e, 0, 0, 0, 1, _fv_1572)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1573), blk_new(e, 0, 0, 0, 1, _fv_1574))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1575), blk_new(e, 0, 0, 0, 1, _fv_1576)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1577), blk_new(e, 0, 0, 0, 1, _fv_1578)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1579), blk_new(e, 0, 0, 0, 1, _fv_1580)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1581), blk_new(e, 0, 0, 0, 1, _fv_1582))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1583), blk_new(e, 0, 0, 0, 1, _fv_1584)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1585), blk_new(e, 0, 0, 0, 1, _fv_1586))))));
      e.mem[_nd_200 + 1] = rfc_seal(e, 116ull);
      _o_503 = term_ctr(CID_OWNED, _nd_200);
    }
    Term _fv_1587[2];
    _fv_1587[0] = _o_502;
    _fv_1587[1] = _o_503;
    Term _fv_1588[1];
    _fv_1588[0] = 1;
    Term _fv_1589[1];
    _fv_1589[0] = 1;
    Term _fv_1590[1];
    _fv_1590[0] = 0;
    Term _fv_1591[1];
    _fv_1591[0] = 1;
    Term _fv_1592[1];
    _fv_1592[0] = 1;
    Term _fv_1593[1];
    _fv_1593[0] = 1;
    Term _fv_1594[1];
    _fv_1594[0] = 1;
    Term _fv_1595[1];
    _fv_1595[0] = 1;
    Term _fv_1596[1];
    _fv_1596[0] = 1;
    Term _fv_1597[1];
    _fv_1597[0] = 1;
    Term _fv_1598[1];
    _fv_1598[0] = 1;
    Term _fv_1599[1];
    _fv_1599[0] = 1;
    Term _fv_1600[1];
    _fv_1600[0] = 1;
    Term _fv_1601[1];
    _fv_1601[0] = 1;
    Term _fv_1602[1];
    _fv_1602[0] = 1;
    Term _fv_1603[1];
    _fv_1603[0] = 1;
    u32 _o_504 = 0;
    Term _o_505 = 0;
    Term _t_276 = 1;
    if (_t_276 == 0) {
      _o_504 = 0;
    } else {
      _o_504 = 1;
      _o_505 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1604[2];
    _fv_1604[0] = _o_504;
    _fv_1604[1] = _o_505;
    u32 _o_506 = 0;
    Term _o_507 = 0;
    Term _t_277 = 0;
    if (_t_277 == 0) {
      _o_506 = 0;
    } else {
      _o_506 = 1;
      _o_507 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1605[2];
    _fv_1605[0] = _o_506;
    _fv_1605[1] = _o_507;
    u32 _o_508 = 0;
    Term _o_509 = 0;
    Term _t_278 = 1;
    if (_t_278 == 0) {
      _o_508 = 0;
    } else {
      _o_508 = 1;
      _o_509 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1606[2];
    _fv_1606[0] = _o_508;
    _fv_1606[1] = _o_509;
    u32 _o_510 = 0;
    Term _o_511 = 0;
    Term _t_279 = 0;
    if (_t_279 == 0) {
      _o_510 = 0;
    } else {
      _o_510 = 1;
      _o_511 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1607[2];
    _fv_1607[0] = _o_510;
    _fv_1607[1] = _o_511;
    u32 _o_512 = 0;
    Term _o_513 = 0;
    Term _t_280 = 1;
    if (_t_280 == 0) {
      _o_512 = 0;
    } else {
      _o_512 = 1;
      _o_513 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1608[2];
    _fv_1608[0] = _o_512;
    _fv_1608[1] = _o_513;
    u32 _o_514 = 0;
    Term _o_515 = 0;
    Term _t_281 = 0;
    if (_t_281 == 0) {
      _o_514 = 0;
    } else {
      _o_514 = 1;
      _o_515 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1609[2];
    _fv_1609[0] = _o_514;
    _fv_1609[1] = _o_515;
    u32 _o_516 = 0;
    Term _o_517 = 0;
    Term _t_282 = 1;
    if (_t_282 == 0) {
      _o_516 = 0;
    } else {
      _o_516 = 1;
      _o_517 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1610[2];
    _fv_1610[0] = _o_516;
    _fv_1610[1] = _o_517;
    u32 _o_518 = 0;
    Term _o_519 = 0;
    Term _t_283 = 0;
    if (_t_283 == 0) {
      _o_518 = 0;
    } else {
      _o_518 = 1;
      _o_519 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1611[2];
    _fv_1611[0] = _o_518;
    _fv_1611[1] = _o_519;
    u32 _o_520 = 0;
    Term _o_521 = 0;
    Term _t_284 = 1;
    if (_t_284 == 0) {
      _o_520 = 0;
    } else {
      _o_520 = 1;
      _o_521 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1612[2];
    _fv_1612[0] = _o_520;
    _fv_1612[1] = _o_521;
    u32 _o_522 = 0;
    Term _o_523 = 0;
    Term _t_285 = 0;
    if (_t_285 == 0) {
      _o_522 = 0;
    } else {
      _o_522 = 1;
      _o_523 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1613[2];
    _fv_1613[0] = _o_522;
    _fv_1613[1] = _o_523;
    u32 _o_524 = 0;
    Term _o_525 = 0;
    Term _t_286 = 1;
    if (_t_286 == 0) {
      _o_524 = 0;
    } else {
      _o_524 = 1;
      _o_525 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1614[2];
    _fv_1614[0] = _o_524;
    _fv_1614[1] = _o_525;
    u32 _o_526 = 0;
    Term _o_527 = 0;
    Term _t_287 = 0;
    if (_t_287 == 0) {
      _o_526 = 0;
    } else {
      _o_526 = 1;
      _o_527 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1615[2];
    _fv_1615[0] = _o_526;
    _fv_1615[1] = _o_527;
    u32 _o_528 = 0;
    Term _o_529 = 0;
    Term _t_288 = 1;
    if (_t_288 == 0) {
      _o_528 = 0;
    } else {
      _o_528 = 1;
      _o_529 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1616[2];
    _fv_1616[0] = _o_528;
    _fv_1616[1] = _o_529;
    u32 _o_530 = 0;
    Term _o_531 = 0;
    Term _t_289 = 0;
    if (_t_289 == 0) {
      _o_530 = 0;
    } else {
      _o_530 = 1;
      _o_531 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1617[2];
    _fv_1617[0] = _o_530;
    _fv_1617[1] = _o_531;
    u32 _o_532 = 0;
    Term _o_533 = 0;
    Term _t_290 = 1;
    if (_t_290 == 0) {
      _o_532 = 0;
    } else {
      _o_532 = 1;
      _o_533 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1618[2];
    _fv_1618[0] = _o_532;
    _fv_1618[1] = _o_533;
    u32 _o_534 = 0;
    Term _o_535 = 0;
    Term _t_291 = 0;
    if (_t_291 == 0) {
      _o_534 = 0;
    } else {
      _o_534 = 1;
      _o_535 = term_pak(CID_UNIT, 0);
    }
    Term _fv_1619[2];
    _fv_1619[0] = _o_534;
    _fv_1619[1] = _o_535;
    Term _fv_1620[1];
    _fv_1620[0] = 100ull;
    Term _fv_1621[1];
    _fv_1621[0] = 101ull;
    Term _fv_1622[1];
    _fv_1622[0] = 102ull;
    Term _fv_1623[1];
    _fv_1623[0] = 103ull;
    Term _fv_1624[1];
    _fv_1624[0] = 104ull;
    Term _fv_1625[1];
    _fv_1625[0] = 105ull;
    Term _fv_1626[1];
    _fv_1626[0] = 106ull;
    Term _fv_1627[1];
    _fv_1627[0] = 107ull;
    Term _fv_1628[1];
    _fv_1628[0] = 108ull;
    Term _fv_1629[1];
    _fv_1629[0] = 109ull;
    Term _fv_1630[1];
    _fv_1630[0] = 110ull;
    Term _fv_1631[1];
    _fv_1631[0] = 111ull;
    Term _fv_1632[1];
    _fv_1632[0] = 112ull;
    Term _fv_1633[1];
    _fv_1633[0] = 113ull;
    Term _fv_1634[1];
    _fv_1634[0] = 114ull;
    Term _fv_1635[1];
    _fv_1635[0] = 115ull;
    Term _fv_1636[1];
    _fv_1636[0] = 200ull;
    Term _fv_1637[1];
    _fv_1637[0] = 201ull;
    Term _fv_1638[1];
    _fv_1638[0] = 202ull;
    Term _fv_1639[1];
    _fv_1639[0] = 203ull;
    Term _fv_1640[1];
    _fv_1640[0] = 204ull;
    Term _fv_1641[1];
    _fv_1641[0] = 205ull;
    Term _fv_1642[1];
    _fv_1642[0] = 206ull;
    Term _fv_1643[1];
    _fv_1643[0] = 207ull;
    Term _fv_1644[1];
    _fv_1644[0] = 208ull;
    Term _fv_1645[1];
    _fv_1645[0] = 209ull;
    Term _fv_1646[1];
    _fv_1646[0] = 210ull;
    Term _fv_1647[1];
    _fv_1647[0] = 211ull;
    Term _fv_1648[1];
    _fv_1648[0] = 212ull;
    Term _fv_1649[1];
    _fv_1649[0] = 213ull;
    Term _fv_1650[1];
    _fv_1650[0] = 214ull;
    Term _fv_1651[1];
    _fv_1651[0] = 215ull;
    Term _v_858 = 0;
    Term _v_859 = 0;
    Term _v_860 = 0;
    Term _v_861 = 0;
    Term _v_862 = 0;
    Term _v_863 = 0;
    u32 _v_864 = 0;
    Term _v_865 = 0;
    u32 _v_866 = 0;
    Term _v_867 = 0;
    Term _o_536[10];
    Term _a_160 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1076), blk_new(e, 1, 0, 1, 2, _fv_1077)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1094), blk_new(e, 1, 0, 1, 2, _fv_1111))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1128), blk_new(e, 1, 0, 1, 2, _fv_1145)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1162), blk_new(e, 1, 0, 1, 2, _fv_1179)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1196), blk_new(e, 1, 0, 1, 2, _fv_1213)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1230), blk_new(e, 1, 0, 1, 2, _fv_1247))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1264), blk_new(e, 1, 0, 1, 2, _fv_1281)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1298), blk_new(e, 1, 0, 1, 2, _fv_1315)))));
    Term _a_161 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1332), blk_new(e, 1, 0, 1, 2, _fv_1349)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1366), blk_new(e, 1, 0, 1, 2, _fv_1383))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1400), blk_new(e, 1, 0, 1, 2, _fv_1417)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1434), blk_new(e, 1, 0, 1, 2, _fv_1451)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1468), blk_new(e, 1, 0, 1, 2, _fv_1485)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1502), blk_new(e, 1, 0, 1, 2, _fv_1519))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1536), blk_new(e, 1, 0, 1, 2, _fv_1553)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1570), blk_new(e, 1, 0, 1, 2, _fv_1587)))));
    Term _a_162 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1588), blk_new(e, 0, 0, 0, 1, _fv_1589)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1590), blk_new(e, 0, 0, 0, 1, _fv_1591))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1592), blk_new(e, 0, 0, 0, 1, _fv_1593)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1594), blk_new(e, 0, 0, 0, 1, _fv_1595)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1596), blk_new(e, 0, 0, 0, 1, _fv_1597)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1598), blk_new(e, 0, 0, 0, 1, _fv_1599))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1600), blk_new(e, 0, 0, 0, 1, _fv_1601)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1602), blk_new(e, 0, 0, 0, 1, _fv_1603)))));
    Term _a_163 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1604), blk_new(e, 1, 0, 1, 2, _fv_1605)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1606), blk_new(e, 1, 0, 1, 2, _fv_1607))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1608), blk_new(e, 1, 0, 1, 2, _fv_1609)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1610), blk_new(e, 1, 0, 1, 2, _fv_1611)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1612), blk_new(e, 1, 0, 1, 2, _fv_1613)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1614), blk_new(e, 1, 0, 1, 2, _fv_1615))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1616), blk_new(e, 1, 0, 1, 2, _fv_1617)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1618), blk_new(e, 1, 0, 1, 2, _fv_1619)))));
    Term _a_164 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1620), blk_new(e, 0, 0, 0, 1, _fv_1621)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1622), blk_new(e, 0, 0, 0, 1, _fv_1623))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1624), blk_new(e, 0, 0, 0, 1, _fv_1625)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1626), blk_new(e, 0, 0, 0, 1, _fv_1627)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1628), blk_new(e, 0, 0, 0, 1, _fv_1629)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1630), blk_new(e, 0, 0, 0, 1, _fv_1631))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1632), blk_new(e, 0, 0, 0, 1, _fv_1633)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1634), blk_new(e, 0, 0, 0, 1, _fv_1635)))));
    Term _a_165 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1636), blk_new(e, 0, 0, 0, 1, _fv_1637)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1638), blk_new(e, 0, 0, 0, 1, _fv_1639))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1640), blk_new(e, 0, 0, 0, 1, _fv_1641)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1642), blk_new(e, 0, 0, 0, 1, _fv_1643)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1644), blk_new(e, 0, 0, 0, 1, _fv_1645)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1646), blk_new(e, 0, 0, 0, 1, _fv_1647))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1648), blk_new(e, 0, 0, 0, 1, _fv_1649)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1650), blk_new(e, 0, 0, 0, 1, _fv_1651)))));
    Term _a_166 = term_pak(CID_NIL, 0);
    if (spin_19(e, _o_536, ((u64)15ull), 1ull, 16ull, 4ull, 15ull, 0, 7ull, _a_160, blk_loc(e.mem, _a_160), _a_161, blk_loc(e.mem, _a_161), _a_162, blk_loc(e.mem, _a_162), _a_163, blk_loc(e.mem, _a_163), _a_164, blk_loc(e.mem, _a_164), _a_165, blk_loc(e.mem, _a_165), _a_166, blk_loc(e.mem, _a_166)) == 0) {
      return 0;
    }
    _v_858 = _o_536[0];
    _v_859 = _o_536[1];
    _v_860 = _o_536[2];
    _v_861 = _o_536[3];
    _v_862 = _o_536[4];
    _v_863 = _o_536[5];
    _v_864 = _o_536[6];
    _v_865 = _o_536[7];
    _v_866 = _o_536[8];
    _v_867 = _o_536[9];
    _v_848 = _v_858;
    _v_849 = _v_859;
    _v_850 = _v_860;
    _v_851 = _v_861;
    _v_852 = _v_862;
    _v_853 = _v_863;
    _v_854 = _v_864;
    _v_855 = _v_865;
    _v_856 = _v_866;
    _v_857 = _v_867;
    u32 _v_868 = 0;
    u32 _v_869 = 0;
    Term _v_870 = 0;
    Term _v_871 = 0;
    Term _v_872 = 0;
    Term _v_873 = 0;
    Term _v_874 = 0;
    Term _v_875 = 0;
    u32 _v_876 = 0;
    Term _v_877 = 0;
    u32 _v_878 = 0;
    Term _v_879 = 0;
    u32 _v_880 = 0;
    Term _v_881 = 0;
    Term _v_882 = 0;
    Term _v_883 = 0;
    Term _o_537[16];
    Term _a_167 = term_pak(CID_NIL, 0);
    Term _a_168 = term_ctr(CID_OWNED, _nd_168);
    Term _a_169 = 123ull;
    if (spin_21(e, _o_537, 7ull, 999ull, _a_167, blk_loc(e.mem, _a_167), 1, _a_168, blk_loc(e.mem, _a_168), _a_169, blk_loc(e.mem, _a_169), _v_848, blk_loc(e.mem, _v_848), _v_849, blk_loc(e.mem, _v_849), _v_850, blk_loc(e.mem, _v_850), _v_851, blk_loc(e.mem, _v_851), _v_852, blk_loc(e.mem, _v_852), _v_853, blk_loc(e.mem, _v_853), _v_854, _v_855, _v_856, _v_857, blk_loc(e.mem, _v_857)) == 0) {
      return 0;
    }
    _v_868 = _o_537[0];
    _v_869 = _o_537[1];
    _v_870 = _o_537[2];
    _v_871 = _o_537[3];
    _v_872 = _o_537[4];
    _v_873 = _o_537[5];
    _v_874 = _o_537[6];
    _v_875 = _o_537[7];
    _v_876 = _o_537[8];
    _v_877 = _o_537[9];
    _v_878 = _o_537[10];
    _v_879 = _o_537[11];
    _v_880 = _o_537[12];
    _v_881 = _o_537[13];
    _v_882 = _o_537[14];
    _v_883 = _o_537[15];
    _v_832 = _v_868;
    _v_833 = _v_869;
    _v_834 = _v_870;
    _v_835 = _v_871;
    _v_836 = _v_872;
    _v_837 = _v_873;
    _v_838 = _v_874;
    _v_839 = _v_875;
    _v_840 = _v_876;
    _v_841 = _v_877;
    _v_842 = _v_878;
    _v_843 = _v_879;
    _v_844 = _v_880;
    _v_845 = _v_881;
    _v_846 = _v_882;
    _v_847 = _v_883;
    u32 _o_538 = 0;
    Term _o_539 = 0;
    u32 _o_540 = 0;
    if (_v_844 == 0) {
      _o_538 = 0;
    } else {
      _o_538 = 1;
      Term _fb_16[2];
      u64 _sp_16 = ctr_take(e, _v_845, 2, _fb_16);
      Term _f_32 = _fb_16[0];
      u32 _f_33 = _fb_16[1];
      spare_free(e, cls_fit(2), _sp_16);
      _o_539 = _f_32;
      _o_540 = _f_33;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K275;
      WL_PUSHN(1);
    } else {
      u64 _t_292 = task_node(e, FID_MAIN_K275, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K275, _t_292);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_293 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_293 + 0] = _v_832;
      e.mem[_t_293 + 1] = _v_833;
      e.mem[_t_293 + 2] = _v_834;
      e.mem[_t_293 + 3] = _v_835;
      e.mem[_t_293 + 4] = _v_836;
      e.mem[_t_293 + 5] = _v_837;
      e.mem[_t_293 + 6] = _v_838;
      e.mem[_t_293 + 7] = _v_839;
      e.mem[_t_293 + 8] = _v_840;
      e.mem[_t_293 + 9] = _v_841;
      e.mem[_t_293 + 10] = _v_842;
      e.mem[_t_293 + 11] = _v_843;
      e.mem[_t_293 + 12] = _o_538;
      e.mem[_t_293 + 13] = _o_539;
      e.mem[_t_293 + 14] = _o_540;
      e.mem[_t_293 + 15] = _v_846;
      e.mem[_t_293 + 16] = _v_847;
      return term_tsk(FID_SNAPSHOT, _t_293);
    }
    r0 = _v_832;
    r1 = _v_833;
    r2 = _v_834;
    r3 = _v_835;
    r4 = _v_836;
    r5 = _v_837;
    r6 = _v_838;
    r7 = _v_839;
    r8 = _v_840;
    r9 = _v_841;
    r10 = _v_842;
    r11 = _v_843;
    r12 = _o_538;
    r13 = _o_539;
    r14 = _o_540;
    r15 = _v_846;
    r16 = _v_847;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K275)
  {
    Term _h_48 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K276;
      WL_PUSHN(1);
    } else {
      u64 _t_294 = task_node(e, FID_MAIN_K276, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K276, _t_294);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_295 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_295 + 0] = term_ctr(CID_SCON, STAT_OFF + 192);
      e.mem[_t_295 + 1] = _h_48;
      return term_tsk(FID_STRING_APPEND, _t_295);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 192);
    r1 = _h_48;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K276)
  {
    Term _h_49 = r0;
    WL_OPEN
    u64 _nd_201 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_201 + 0] = _h_49;
    r0 = term_clo(FID_MAIN_C277, _nd_201);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C277)
  {
    Term _h_50 = r0;
    Term _x_32 = r1;
    WL_OPEN
    u64 _nd_202 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_202 + 0] = _h_50;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_456 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_456 + 0] = term_clo(FID_IO_PRINT, _nd_202);
      e.mem[_t_456 + 1] = term_clo(FID_MAIN_C278, 0);
      e.mem[_t_456 + 2] = _x_32;
      return term_tsk(FID_IO_BIND, _t_456);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_202);
    r1 = term_clo(FID_MAIN_C278, 0);
    r2 = _x_32;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C278)
  {
    Term _x_33 = r0;
    WL_OPEN
    u32 _v_884 = 0;
    u32 _v_885 = 0;
    Term _v_886 = 0;
    Term _v_887 = 0;
    Term _v_888 = 0;
    Term _v_889 = 0;
    Term _v_890 = 0;
    Term _v_891 = 0;
    u32 _v_892 = 0;
    Term _v_893 = 0;
    u32 _v_894 = 0;
    Term _v_895 = 0;
    u32 _v_896 = 0;
    Term _v_897 = 0;
    Term _v_898 = 0;
    Term _v_899 = 0;
    Term _fv_1652[1];
    _fv_1652[0] = 999000ull;
    Term _fv_1653[1];
    _fv_1653[0] = 999001ull;
    Term _fv_1654[1];
    _fv_1654[0] = 999002ull;
    Term _fv_1655[1];
    _fv_1655[0] = 999003ull;
    Term _fv_1656[1];
    _fv_1656[0] = 999004ull;
    Term _fv_1657[1];
    _fv_1657[0] = 999005ull;
    Term _fv_1658[1];
    _fv_1658[0] = 999006ull;
    Term _fv_1659[1];
    _fv_1659[0] = 999007ull;
    Term _fv_1660[1];
    _fv_1660[0] = 999008ull;
    Term _fv_1661[1];
    _fv_1661[0] = 999009ull;
    Term _fv_1662[1];
    _fv_1662[0] = 999010ull;
    Term _fv_1663[1];
    _fv_1663[0] = 999011ull;
    Term _fv_1664[1];
    _fv_1664[0] = 999012ull;
    Term _fv_1665[1];
    _fv_1665[0] = 999013ull;
    Term _fv_1666[1];
    _fv_1666[0] = 999014ull;
    Term _fv_1667[1];
    _fv_1667[0] = 999015ull;
    u64 _nd_203 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_203 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1652), blk_new(e, 0, 0, 0, 1, _fv_1653)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1654), blk_new(e, 0, 0, 0, 1, _fv_1655))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1656), blk_new(e, 0, 0, 0, 1, _fv_1657)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1658), blk_new(e, 0, 0, 0, 1, _fv_1659)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1660), blk_new(e, 0, 0, 0, 1, _fv_1661)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1662), blk_new(e, 0, 0, 0, 1, _fv_1663))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1664), blk_new(e, 0, 0, 0, 1, _fv_1665)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1666), blk_new(e, 0, 0, 0, 1, _fv_1667))))));
    e.mem[_nd_203 + 1] = rfc_seal(e, 999ull);
    Term _v_900 = 0;
    Term _v_901 = 0;
    Term _v_902 = 0;
    Term _v_903 = 0;
    Term _v_904 = 0;
    Term _v_905 = 0;
    u32 _v_906 = 0;
    Term _v_907 = 0;
    u32 _v_908 = 0;
    Term _v_909 = 0;
    Term _fv_1668[1];
    _fv_1668[0] = 1000ull;
    Term _fv_1669[1];
    _fv_1669[0] = 1001ull;
    Term _fv_1670[1];
    _fv_1670[0] = 1002ull;
    Term _fv_1671[1];
    _fv_1671[0] = 1003ull;
    Term _fv_1672[1];
    _fv_1672[0] = 1004ull;
    Term _fv_1673[1];
    _fv_1673[0] = 1005ull;
    Term _fv_1674[1];
    _fv_1674[0] = 1006ull;
    Term _fv_1675[1];
    _fv_1675[0] = 1007ull;
    Term _fv_1676[1];
    _fv_1676[0] = 1008ull;
    Term _fv_1677[1];
    _fv_1677[0] = 1009ull;
    Term _fv_1678[1];
    _fv_1678[0] = 1010ull;
    Term _fv_1679[1];
    _fv_1679[0] = 1011ull;
    Term _fv_1680[1];
    _fv_1680[0] = 1012ull;
    Term _fv_1681[1];
    _fv_1681[0] = 1013ull;
    Term _fv_1682[1];
    _fv_1682[0] = 1014ull;
    Term _fv_1683[1];
    _fv_1683[0] = 1015ull;
    u32 _o_541 = 0;
    Term _o_542 = 0;
    Term _t_296 = 1;
    if (_t_296 == 0) {
      _o_541 = 0;
    } else {
      _o_541 = 1;
      u64 _nd_204 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_204 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1668), blk_new(e, 0, 0, 0, 1, _fv_1669)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1670), blk_new(e, 0, 0, 0, 1, _fv_1671))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1672), blk_new(e, 0, 0, 0, 1, _fv_1673)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1674), blk_new(e, 0, 0, 0, 1, _fv_1675)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1676), blk_new(e, 0, 0, 0, 1, _fv_1677)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1678), blk_new(e, 0, 0, 0, 1, _fv_1679))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1680), blk_new(e, 0, 0, 0, 1, _fv_1681)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1682), blk_new(e, 0, 0, 0, 1, _fv_1683))))));
      e.mem[_nd_204 + 1] = rfc_seal(e, 1ull);
      _o_542 = term_ctr(CID_OWNED, _nd_204);
    }
    Term _fv_1684[2];
    _fv_1684[0] = _o_541;
    _fv_1684[1] = _o_542;
    u32 _o_543 = 0;
    Term _o_544 = 0;
    Term _t_297 = 0;
    if (_t_297 == 0) {
      _o_543 = 0;
    } else {
      _o_543 = 1;
      u64 _nd_205 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_205 + 0] = rfc_seal(e, 0);
      e.mem[_nd_205 + 1] = rfc_seal(e, 0);
      _o_544 = term_ctr(CID_OWNED, _nd_205);
    }
    Term _fv_1685[2];
    _fv_1685[0] = _o_543;
    _fv_1685[1] = _o_544;
    Term _fv_1686[1];
    _fv_1686[0] = 3000ull;
    Term _fv_1687[1];
    _fv_1687[0] = 3001ull;
    Term _fv_1688[1];
    _fv_1688[0] = 3002ull;
    Term _fv_1689[1];
    _fv_1689[0] = 3003ull;
    Term _fv_1690[1];
    _fv_1690[0] = 3004ull;
    Term _fv_1691[1];
    _fv_1691[0] = 3005ull;
    Term _fv_1692[1];
    _fv_1692[0] = 3006ull;
    Term _fv_1693[1];
    _fv_1693[0] = 3007ull;
    Term _fv_1694[1];
    _fv_1694[0] = 3008ull;
    Term _fv_1695[1];
    _fv_1695[0] = 3009ull;
    Term _fv_1696[1];
    _fv_1696[0] = 3010ull;
    Term _fv_1697[1];
    _fv_1697[0] = 3011ull;
    Term _fv_1698[1];
    _fv_1698[0] = 3012ull;
    Term _fv_1699[1];
    _fv_1699[0] = 3013ull;
    Term _fv_1700[1];
    _fv_1700[0] = 3014ull;
    Term _fv_1701[1];
    _fv_1701[0] = 3015ull;
    u32 _o_545 = 0;
    Term _o_546 = 0;
    Term _t_298 = 1;
    if (_t_298 == 0) {
      _o_545 = 0;
    } else {
      _o_545 = 1;
      u64 _nd_206 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_206 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1686), blk_new(e, 0, 0, 0, 1, _fv_1687)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1688), blk_new(e, 0, 0, 0, 1, _fv_1689))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1690), blk_new(e, 0, 0, 0, 1, _fv_1691)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1692), blk_new(e, 0, 0, 0, 1, _fv_1693)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1694), blk_new(e, 0, 0, 0, 1, _fv_1695)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1696), blk_new(e, 0, 0, 0, 1, _fv_1697))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1698), blk_new(e, 0, 0, 0, 1, _fv_1699)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1700), blk_new(e, 0, 0, 0, 1, _fv_1701))))));
      e.mem[_nd_206 + 1] = rfc_seal(e, 3ull);
      _o_546 = term_ctr(CID_OWNED, _nd_206);
    }
    Term _fv_1702[2];
    _fv_1702[0] = _o_545;
    _fv_1702[1] = _o_546;
    Term _fv_1703[1];
    _fv_1703[0] = 4000ull;
    Term _fv_1704[1];
    _fv_1704[0] = 4001ull;
    Term _fv_1705[1];
    _fv_1705[0] = 4002ull;
    Term _fv_1706[1];
    _fv_1706[0] = 4003ull;
    Term _fv_1707[1];
    _fv_1707[0] = 4004ull;
    Term _fv_1708[1];
    _fv_1708[0] = 4005ull;
    Term _fv_1709[1];
    _fv_1709[0] = 4006ull;
    Term _fv_1710[1];
    _fv_1710[0] = 4007ull;
    Term _fv_1711[1];
    _fv_1711[0] = 4008ull;
    Term _fv_1712[1];
    _fv_1712[0] = 4009ull;
    Term _fv_1713[1];
    _fv_1713[0] = 4010ull;
    Term _fv_1714[1];
    _fv_1714[0] = 4011ull;
    Term _fv_1715[1];
    _fv_1715[0] = 4012ull;
    Term _fv_1716[1];
    _fv_1716[0] = 4013ull;
    Term _fv_1717[1];
    _fv_1717[0] = 4014ull;
    Term _fv_1718[1];
    _fv_1718[0] = 4015ull;
    u32 _o_547 = 0;
    Term _o_548 = 0;
    Term _t_299 = 1;
    if (_t_299 == 0) {
      _o_547 = 0;
    } else {
      _o_547 = 1;
      u64 _nd_207 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_207 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1703), blk_new(e, 0, 0, 0, 1, _fv_1704)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1705), blk_new(e, 0, 0, 0, 1, _fv_1706))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1707), blk_new(e, 0, 0, 0, 1, _fv_1708)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1709), blk_new(e, 0, 0, 0, 1, _fv_1710)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1711), blk_new(e, 0, 0, 0, 1, _fv_1712)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1713), blk_new(e, 0, 0, 0, 1, _fv_1714))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1715), blk_new(e, 0, 0, 0, 1, _fv_1716)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1717), blk_new(e, 0, 0, 0, 1, _fv_1718))))));
      e.mem[_nd_207 + 1] = rfc_seal(e, 4ull);
      _o_548 = term_ctr(CID_OWNED, _nd_207);
    }
    Term _fv_1719[2];
    _fv_1719[0] = _o_547;
    _fv_1719[1] = _o_548;
    Term _fv_1720[1];
    _fv_1720[0] = 5000ull;
    Term _fv_1721[1];
    _fv_1721[0] = 5001ull;
    Term _fv_1722[1];
    _fv_1722[0] = 5002ull;
    Term _fv_1723[1];
    _fv_1723[0] = 5003ull;
    Term _fv_1724[1];
    _fv_1724[0] = 5004ull;
    Term _fv_1725[1];
    _fv_1725[0] = 5005ull;
    Term _fv_1726[1];
    _fv_1726[0] = 5006ull;
    Term _fv_1727[1];
    _fv_1727[0] = 5007ull;
    Term _fv_1728[1];
    _fv_1728[0] = 5008ull;
    Term _fv_1729[1];
    _fv_1729[0] = 5009ull;
    Term _fv_1730[1];
    _fv_1730[0] = 5010ull;
    Term _fv_1731[1];
    _fv_1731[0] = 5011ull;
    Term _fv_1732[1];
    _fv_1732[0] = 5012ull;
    Term _fv_1733[1];
    _fv_1733[0] = 5013ull;
    Term _fv_1734[1];
    _fv_1734[0] = 5014ull;
    Term _fv_1735[1];
    _fv_1735[0] = 5015ull;
    u32 _o_549 = 0;
    Term _o_550 = 0;
    Term _t_300 = 1;
    if (_t_300 == 0) {
      _o_549 = 0;
    } else {
      _o_549 = 1;
      u64 _nd_208 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_208 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1720), blk_new(e, 0, 0, 0, 1, _fv_1721)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1722), blk_new(e, 0, 0, 0, 1, _fv_1723))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1724), blk_new(e, 0, 0, 0, 1, _fv_1725)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1726), blk_new(e, 0, 0, 0, 1, _fv_1727)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1728), blk_new(e, 0, 0, 0, 1, _fv_1729)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1730), blk_new(e, 0, 0, 0, 1, _fv_1731))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1732), blk_new(e, 0, 0, 0, 1, _fv_1733)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1734), blk_new(e, 0, 0, 0, 1, _fv_1735))))));
      e.mem[_nd_208 + 1] = rfc_seal(e, 5ull);
      _o_550 = term_ctr(CID_OWNED, _nd_208);
    }
    Term _fv_1736[2];
    _fv_1736[0] = _o_549;
    _fv_1736[1] = _o_550;
    Term _fv_1737[1];
    _fv_1737[0] = 6000ull;
    Term _fv_1738[1];
    _fv_1738[0] = 6001ull;
    Term _fv_1739[1];
    _fv_1739[0] = 6002ull;
    Term _fv_1740[1];
    _fv_1740[0] = 6003ull;
    Term _fv_1741[1];
    _fv_1741[0] = 6004ull;
    Term _fv_1742[1];
    _fv_1742[0] = 6005ull;
    Term _fv_1743[1];
    _fv_1743[0] = 6006ull;
    Term _fv_1744[1];
    _fv_1744[0] = 6007ull;
    Term _fv_1745[1];
    _fv_1745[0] = 6008ull;
    Term _fv_1746[1];
    _fv_1746[0] = 6009ull;
    Term _fv_1747[1];
    _fv_1747[0] = 6010ull;
    Term _fv_1748[1];
    _fv_1748[0] = 6011ull;
    Term _fv_1749[1];
    _fv_1749[0] = 6012ull;
    Term _fv_1750[1];
    _fv_1750[0] = 6013ull;
    Term _fv_1751[1];
    _fv_1751[0] = 6014ull;
    Term _fv_1752[1];
    _fv_1752[0] = 6015ull;
    u32 _o_551 = 0;
    Term _o_552 = 0;
    Term _t_301 = 1;
    if (_t_301 == 0) {
      _o_551 = 0;
    } else {
      _o_551 = 1;
      u64 _nd_209 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_209 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1737), blk_new(e, 0, 0, 0, 1, _fv_1738)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1739), blk_new(e, 0, 0, 0, 1, _fv_1740))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1741), blk_new(e, 0, 0, 0, 1, _fv_1742)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1743), blk_new(e, 0, 0, 0, 1, _fv_1744)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1745), blk_new(e, 0, 0, 0, 1, _fv_1746)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1747), blk_new(e, 0, 0, 0, 1, _fv_1748))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1749), blk_new(e, 0, 0, 0, 1, _fv_1750)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1751), blk_new(e, 0, 0, 0, 1, _fv_1752))))));
      e.mem[_nd_209 + 1] = rfc_seal(e, 6ull);
      _o_552 = term_ctr(CID_OWNED, _nd_209);
    }
    Term _fv_1753[2];
    _fv_1753[0] = _o_551;
    _fv_1753[1] = _o_552;
    Term _fv_1754[1];
    _fv_1754[0] = 7000ull;
    Term _fv_1755[1];
    _fv_1755[0] = 7001ull;
    Term _fv_1756[1];
    _fv_1756[0] = 7002ull;
    Term _fv_1757[1];
    _fv_1757[0] = 7003ull;
    Term _fv_1758[1];
    _fv_1758[0] = 7004ull;
    Term _fv_1759[1];
    _fv_1759[0] = 7005ull;
    Term _fv_1760[1];
    _fv_1760[0] = 7006ull;
    Term _fv_1761[1];
    _fv_1761[0] = 7007ull;
    Term _fv_1762[1];
    _fv_1762[0] = 7008ull;
    Term _fv_1763[1];
    _fv_1763[0] = 7009ull;
    Term _fv_1764[1];
    _fv_1764[0] = 7010ull;
    Term _fv_1765[1];
    _fv_1765[0] = 7011ull;
    Term _fv_1766[1];
    _fv_1766[0] = 7012ull;
    Term _fv_1767[1];
    _fv_1767[0] = 7013ull;
    Term _fv_1768[1];
    _fv_1768[0] = 7014ull;
    Term _fv_1769[1];
    _fv_1769[0] = 7015ull;
    u32 _o_553 = 0;
    Term _o_554 = 0;
    Term _t_302 = 1;
    if (_t_302 == 0) {
      _o_553 = 0;
    } else {
      _o_553 = 1;
      u64 _nd_210 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_210 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1754), blk_new(e, 0, 0, 0, 1, _fv_1755)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1756), blk_new(e, 0, 0, 0, 1, _fv_1757))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1758), blk_new(e, 0, 0, 0, 1, _fv_1759)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1760), blk_new(e, 0, 0, 0, 1, _fv_1761)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1762), blk_new(e, 0, 0, 0, 1, _fv_1763)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1764), blk_new(e, 0, 0, 0, 1, _fv_1765))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1766), blk_new(e, 0, 0, 0, 1, _fv_1767)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1768), blk_new(e, 0, 0, 0, 1, _fv_1769))))));
      e.mem[_nd_210 + 1] = rfc_seal(e, 7ull);
      _o_554 = term_ctr(CID_OWNED, _nd_210);
    }
    Term _fv_1770[2];
    _fv_1770[0] = _o_553;
    _fv_1770[1] = _o_554;
    Term _fv_1771[1];
    _fv_1771[0] = 8000ull;
    Term _fv_1772[1];
    _fv_1772[0] = 8001ull;
    Term _fv_1773[1];
    _fv_1773[0] = 8002ull;
    Term _fv_1774[1];
    _fv_1774[0] = 8003ull;
    Term _fv_1775[1];
    _fv_1775[0] = 8004ull;
    Term _fv_1776[1];
    _fv_1776[0] = 8005ull;
    Term _fv_1777[1];
    _fv_1777[0] = 8006ull;
    Term _fv_1778[1];
    _fv_1778[0] = 8007ull;
    Term _fv_1779[1];
    _fv_1779[0] = 8008ull;
    Term _fv_1780[1];
    _fv_1780[0] = 8009ull;
    Term _fv_1781[1];
    _fv_1781[0] = 8010ull;
    Term _fv_1782[1];
    _fv_1782[0] = 8011ull;
    Term _fv_1783[1];
    _fv_1783[0] = 8012ull;
    Term _fv_1784[1];
    _fv_1784[0] = 8013ull;
    Term _fv_1785[1];
    _fv_1785[0] = 8014ull;
    Term _fv_1786[1];
    _fv_1786[0] = 8015ull;
    u32 _o_555 = 0;
    Term _o_556 = 0;
    Term _t_303 = 1;
    if (_t_303 == 0) {
      _o_555 = 0;
    } else {
      _o_555 = 1;
      u64 _nd_211 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_211 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1771), blk_new(e, 0, 0, 0, 1, _fv_1772)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1773), blk_new(e, 0, 0, 0, 1, _fv_1774))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1775), blk_new(e, 0, 0, 0, 1, _fv_1776)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1777), blk_new(e, 0, 0, 0, 1, _fv_1778)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1779), blk_new(e, 0, 0, 0, 1, _fv_1780)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1781), blk_new(e, 0, 0, 0, 1, _fv_1782))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1783), blk_new(e, 0, 0, 0, 1, _fv_1784)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1785), blk_new(e, 0, 0, 0, 1, _fv_1786))))));
      e.mem[_nd_211 + 1] = rfc_seal(e, 8ull);
      _o_556 = term_ctr(CID_OWNED, _nd_211);
    }
    Term _fv_1787[2];
    _fv_1787[0] = _o_555;
    _fv_1787[1] = _o_556;
    Term _fv_1788[1];
    _fv_1788[0] = 9000ull;
    Term _fv_1789[1];
    _fv_1789[0] = 9001ull;
    Term _fv_1790[1];
    _fv_1790[0] = 9002ull;
    Term _fv_1791[1];
    _fv_1791[0] = 9003ull;
    Term _fv_1792[1];
    _fv_1792[0] = 9004ull;
    Term _fv_1793[1];
    _fv_1793[0] = 9005ull;
    Term _fv_1794[1];
    _fv_1794[0] = 9006ull;
    Term _fv_1795[1];
    _fv_1795[0] = 9007ull;
    Term _fv_1796[1];
    _fv_1796[0] = 9008ull;
    Term _fv_1797[1];
    _fv_1797[0] = 9009ull;
    Term _fv_1798[1];
    _fv_1798[0] = 9010ull;
    Term _fv_1799[1];
    _fv_1799[0] = 9011ull;
    Term _fv_1800[1];
    _fv_1800[0] = 9012ull;
    Term _fv_1801[1];
    _fv_1801[0] = 9013ull;
    Term _fv_1802[1];
    _fv_1802[0] = 9014ull;
    Term _fv_1803[1];
    _fv_1803[0] = 9015ull;
    u32 _o_557 = 0;
    Term _o_558 = 0;
    Term _t_304 = 1;
    if (_t_304 == 0) {
      _o_557 = 0;
    } else {
      _o_557 = 1;
      u64 _nd_212 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_212 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1788), blk_new(e, 0, 0, 0, 1, _fv_1789)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1790), blk_new(e, 0, 0, 0, 1, _fv_1791))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1792), blk_new(e, 0, 0, 0, 1, _fv_1793)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1794), blk_new(e, 0, 0, 0, 1, _fv_1795)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1796), blk_new(e, 0, 0, 0, 1, _fv_1797)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1798), blk_new(e, 0, 0, 0, 1, _fv_1799))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1800), blk_new(e, 0, 0, 0, 1, _fv_1801)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1802), blk_new(e, 0, 0, 0, 1, _fv_1803))))));
      e.mem[_nd_212 + 1] = rfc_seal(e, 9ull);
      _o_558 = term_ctr(CID_OWNED, _nd_212);
    }
    Term _fv_1804[2];
    _fv_1804[0] = _o_557;
    _fv_1804[1] = _o_558;
    Term _fv_1805[1];
    _fv_1805[0] = 10000ull;
    Term _fv_1806[1];
    _fv_1806[0] = 10001ull;
    Term _fv_1807[1];
    _fv_1807[0] = 10002ull;
    Term _fv_1808[1];
    _fv_1808[0] = 10003ull;
    Term _fv_1809[1];
    _fv_1809[0] = 10004ull;
    Term _fv_1810[1];
    _fv_1810[0] = 10005ull;
    Term _fv_1811[1];
    _fv_1811[0] = 10006ull;
    Term _fv_1812[1];
    _fv_1812[0] = 10007ull;
    Term _fv_1813[1];
    _fv_1813[0] = 10008ull;
    Term _fv_1814[1];
    _fv_1814[0] = 10009ull;
    Term _fv_1815[1];
    _fv_1815[0] = 10010ull;
    Term _fv_1816[1];
    _fv_1816[0] = 10011ull;
    Term _fv_1817[1];
    _fv_1817[0] = 10012ull;
    Term _fv_1818[1];
    _fv_1818[0] = 10013ull;
    Term _fv_1819[1];
    _fv_1819[0] = 10014ull;
    Term _fv_1820[1];
    _fv_1820[0] = 10015ull;
    u32 _o_559 = 0;
    Term _o_560 = 0;
    Term _t_305 = 1;
    if (_t_305 == 0) {
      _o_559 = 0;
    } else {
      _o_559 = 1;
      u64 _nd_213 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_213 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1805), blk_new(e, 0, 0, 0, 1, _fv_1806)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1807), blk_new(e, 0, 0, 0, 1, _fv_1808))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1809), blk_new(e, 0, 0, 0, 1, _fv_1810)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1811), blk_new(e, 0, 0, 0, 1, _fv_1812)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1813), blk_new(e, 0, 0, 0, 1, _fv_1814)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1815), blk_new(e, 0, 0, 0, 1, _fv_1816))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1817), blk_new(e, 0, 0, 0, 1, _fv_1818)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1819), blk_new(e, 0, 0, 0, 1, _fv_1820))))));
      e.mem[_nd_213 + 1] = rfc_seal(e, 10ull);
      _o_560 = term_ctr(CID_OWNED, _nd_213);
    }
    Term _fv_1821[2];
    _fv_1821[0] = _o_559;
    _fv_1821[1] = _o_560;
    Term _fv_1822[1];
    _fv_1822[0] = 11000ull;
    Term _fv_1823[1];
    _fv_1823[0] = 11001ull;
    Term _fv_1824[1];
    _fv_1824[0] = 11002ull;
    Term _fv_1825[1];
    _fv_1825[0] = 11003ull;
    Term _fv_1826[1];
    _fv_1826[0] = 11004ull;
    Term _fv_1827[1];
    _fv_1827[0] = 11005ull;
    Term _fv_1828[1];
    _fv_1828[0] = 11006ull;
    Term _fv_1829[1];
    _fv_1829[0] = 11007ull;
    Term _fv_1830[1];
    _fv_1830[0] = 11008ull;
    Term _fv_1831[1];
    _fv_1831[0] = 11009ull;
    Term _fv_1832[1];
    _fv_1832[0] = 11010ull;
    Term _fv_1833[1];
    _fv_1833[0] = 11011ull;
    Term _fv_1834[1];
    _fv_1834[0] = 11012ull;
    Term _fv_1835[1];
    _fv_1835[0] = 11013ull;
    Term _fv_1836[1];
    _fv_1836[0] = 11014ull;
    Term _fv_1837[1];
    _fv_1837[0] = 11015ull;
    u32 _o_561 = 0;
    Term _o_562 = 0;
    Term _t_306 = 1;
    if (_t_306 == 0) {
      _o_561 = 0;
    } else {
      _o_561 = 1;
      u64 _nd_214 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_214 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1822), blk_new(e, 0, 0, 0, 1, _fv_1823)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1824), blk_new(e, 0, 0, 0, 1, _fv_1825))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1826), blk_new(e, 0, 0, 0, 1, _fv_1827)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1828), blk_new(e, 0, 0, 0, 1, _fv_1829)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1830), blk_new(e, 0, 0, 0, 1, _fv_1831)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1832), blk_new(e, 0, 0, 0, 1, _fv_1833))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1834), blk_new(e, 0, 0, 0, 1, _fv_1835)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1836), blk_new(e, 0, 0, 0, 1, _fv_1837))))));
      e.mem[_nd_214 + 1] = rfc_seal(e, 11ull);
      _o_562 = term_ctr(CID_OWNED, _nd_214);
    }
    Term _fv_1838[2];
    _fv_1838[0] = _o_561;
    _fv_1838[1] = _o_562;
    Term _fv_1839[1];
    _fv_1839[0] = 12000ull;
    Term _fv_1840[1];
    _fv_1840[0] = 12001ull;
    Term _fv_1841[1];
    _fv_1841[0] = 12002ull;
    Term _fv_1842[1];
    _fv_1842[0] = 12003ull;
    Term _fv_1843[1];
    _fv_1843[0] = 12004ull;
    Term _fv_1844[1];
    _fv_1844[0] = 12005ull;
    Term _fv_1845[1];
    _fv_1845[0] = 12006ull;
    Term _fv_1846[1];
    _fv_1846[0] = 12007ull;
    Term _fv_1847[1];
    _fv_1847[0] = 12008ull;
    Term _fv_1848[1];
    _fv_1848[0] = 12009ull;
    Term _fv_1849[1];
    _fv_1849[0] = 12010ull;
    Term _fv_1850[1];
    _fv_1850[0] = 12011ull;
    Term _fv_1851[1];
    _fv_1851[0] = 12012ull;
    Term _fv_1852[1];
    _fv_1852[0] = 12013ull;
    Term _fv_1853[1];
    _fv_1853[0] = 12014ull;
    Term _fv_1854[1];
    _fv_1854[0] = 12015ull;
    u32 _o_563 = 0;
    Term _o_564 = 0;
    Term _t_307 = 1;
    if (_t_307 == 0) {
      _o_563 = 0;
    } else {
      _o_563 = 1;
      u64 _nd_215 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_215 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1839), blk_new(e, 0, 0, 0, 1, _fv_1840)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1841), blk_new(e, 0, 0, 0, 1, _fv_1842))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1843), blk_new(e, 0, 0, 0, 1, _fv_1844)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1845), blk_new(e, 0, 0, 0, 1, _fv_1846)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1847), blk_new(e, 0, 0, 0, 1, _fv_1848)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1849), blk_new(e, 0, 0, 0, 1, _fv_1850))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1851), blk_new(e, 0, 0, 0, 1, _fv_1852)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1853), blk_new(e, 0, 0, 0, 1, _fv_1854))))));
      e.mem[_nd_215 + 1] = rfc_seal(e, 12ull);
      _o_564 = term_ctr(CID_OWNED, _nd_215);
    }
    Term _fv_1855[2];
    _fv_1855[0] = _o_563;
    _fv_1855[1] = _o_564;
    Term _fv_1856[1];
    _fv_1856[0] = 13000ull;
    Term _fv_1857[1];
    _fv_1857[0] = 13001ull;
    Term _fv_1858[1];
    _fv_1858[0] = 13002ull;
    Term _fv_1859[1];
    _fv_1859[0] = 13003ull;
    Term _fv_1860[1];
    _fv_1860[0] = 13004ull;
    Term _fv_1861[1];
    _fv_1861[0] = 13005ull;
    Term _fv_1862[1];
    _fv_1862[0] = 13006ull;
    Term _fv_1863[1];
    _fv_1863[0] = 13007ull;
    Term _fv_1864[1];
    _fv_1864[0] = 13008ull;
    Term _fv_1865[1];
    _fv_1865[0] = 13009ull;
    Term _fv_1866[1];
    _fv_1866[0] = 13010ull;
    Term _fv_1867[1];
    _fv_1867[0] = 13011ull;
    Term _fv_1868[1];
    _fv_1868[0] = 13012ull;
    Term _fv_1869[1];
    _fv_1869[0] = 13013ull;
    Term _fv_1870[1];
    _fv_1870[0] = 13014ull;
    Term _fv_1871[1];
    _fv_1871[0] = 13015ull;
    u32 _o_565 = 0;
    Term _o_566 = 0;
    Term _t_308 = 1;
    if (_t_308 == 0) {
      _o_565 = 0;
    } else {
      _o_565 = 1;
      u64 _nd_216 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_216 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1856), blk_new(e, 0, 0, 0, 1, _fv_1857)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1858), blk_new(e, 0, 0, 0, 1, _fv_1859))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1860), blk_new(e, 0, 0, 0, 1, _fv_1861)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1862), blk_new(e, 0, 0, 0, 1, _fv_1863)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1864), blk_new(e, 0, 0, 0, 1, _fv_1865)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1866), blk_new(e, 0, 0, 0, 1, _fv_1867))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1868), blk_new(e, 0, 0, 0, 1, _fv_1869)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1870), blk_new(e, 0, 0, 0, 1, _fv_1871))))));
      e.mem[_nd_216 + 1] = rfc_seal(e, 13ull);
      _o_566 = term_ctr(CID_OWNED, _nd_216);
    }
    Term _fv_1872[2];
    _fv_1872[0] = _o_565;
    _fv_1872[1] = _o_566;
    Term _fv_1873[1];
    _fv_1873[0] = 14000ull;
    Term _fv_1874[1];
    _fv_1874[0] = 14001ull;
    Term _fv_1875[1];
    _fv_1875[0] = 14002ull;
    Term _fv_1876[1];
    _fv_1876[0] = 14003ull;
    Term _fv_1877[1];
    _fv_1877[0] = 14004ull;
    Term _fv_1878[1];
    _fv_1878[0] = 14005ull;
    Term _fv_1879[1];
    _fv_1879[0] = 14006ull;
    Term _fv_1880[1];
    _fv_1880[0] = 14007ull;
    Term _fv_1881[1];
    _fv_1881[0] = 14008ull;
    Term _fv_1882[1];
    _fv_1882[0] = 14009ull;
    Term _fv_1883[1];
    _fv_1883[0] = 14010ull;
    Term _fv_1884[1];
    _fv_1884[0] = 14011ull;
    Term _fv_1885[1];
    _fv_1885[0] = 14012ull;
    Term _fv_1886[1];
    _fv_1886[0] = 14013ull;
    Term _fv_1887[1];
    _fv_1887[0] = 14014ull;
    Term _fv_1888[1];
    _fv_1888[0] = 14015ull;
    u32 _o_567 = 0;
    Term _o_568 = 0;
    Term _t_309 = 1;
    if (_t_309 == 0) {
      _o_567 = 0;
    } else {
      _o_567 = 1;
      u64 _nd_217 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_217 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1873), blk_new(e, 0, 0, 0, 1, _fv_1874)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1875), blk_new(e, 0, 0, 0, 1, _fv_1876))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1877), blk_new(e, 0, 0, 0, 1, _fv_1878)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1879), blk_new(e, 0, 0, 0, 1, _fv_1880)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1881), blk_new(e, 0, 0, 0, 1, _fv_1882)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1883), blk_new(e, 0, 0, 0, 1, _fv_1884))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1885), blk_new(e, 0, 0, 0, 1, _fv_1886)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1887), blk_new(e, 0, 0, 0, 1, _fv_1888))))));
      e.mem[_nd_217 + 1] = rfc_seal(e, 14ull);
      _o_568 = term_ctr(CID_OWNED, _nd_217);
    }
    Term _fv_1889[2];
    _fv_1889[0] = _o_567;
    _fv_1889[1] = _o_568;
    Term _fv_1890[1];
    _fv_1890[0] = 15000ull;
    Term _fv_1891[1];
    _fv_1891[0] = 15001ull;
    Term _fv_1892[1];
    _fv_1892[0] = 15002ull;
    Term _fv_1893[1];
    _fv_1893[0] = 15003ull;
    Term _fv_1894[1];
    _fv_1894[0] = 15004ull;
    Term _fv_1895[1];
    _fv_1895[0] = 15005ull;
    Term _fv_1896[1];
    _fv_1896[0] = 15006ull;
    Term _fv_1897[1];
    _fv_1897[0] = 15007ull;
    Term _fv_1898[1];
    _fv_1898[0] = 15008ull;
    Term _fv_1899[1];
    _fv_1899[0] = 15009ull;
    Term _fv_1900[1];
    _fv_1900[0] = 15010ull;
    Term _fv_1901[1];
    _fv_1901[0] = 15011ull;
    Term _fv_1902[1];
    _fv_1902[0] = 15012ull;
    Term _fv_1903[1];
    _fv_1903[0] = 15013ull;
    Term _fv_1904[1];
    _fv_1904[0] = 15014ull;
    Term _fv_1905[1];
    _fv_1905[0] = 15015ull;
    u32 _o_569 = 0;
    Term _o_570 = 0;
    Term _t_310 = 1;
    if (_t_310 == 0) {
      _o_569 = 0;
    } else {
      _o_569 = 1;
      u64 _nd_218 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_218 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1890), blk_new(e, 0, 0, 0, 1, _fv_1891)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1892), blk_new(e, 0, 0, 0, 1, _fv_1893))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1894), blk_new(e, 0, 0, 0, 1, _fv_1895)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1896), blk_new(e, 0, 0, 0, 1, _fv_1897)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1898), blk_new(e, 0, 0, 0, 1, _fv_1899)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1900), blk_new(e, 0, 0, 0, 1, _fv_1901))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1902), blk_new(e, 0, 0, 0, 1, _fv_1903)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1904), blk_new(e, 0, 0, 0, 1, _fv_1905))))));
      e.mem[_nd_218 + 1] = rfc_seal(e, 15ull);
      _o_570 = term_ctr(CID_OWNED, _nd_218);
    }
    Term _fv_1906[2];
    _fv_1906[0] = _o_569;
    _fv_1906[1] = _o_570;
    Term _fv_1907[1];
    _fv_1907[0] = 16000ull;
    Term _fv_1908[1];
    _fv_1908[0] = 16001ull;
    Term _fv_1909[1];
    _fv_1909[0] = 16002ull;
    Term _fv_1910[1];
    _fv_1910[0] = 16003ull;
    Term _fv_1911[1];
    _fv_1911[0] = 16004ull;
    Term _fv_1912[1];
    _fv_1912[0] = 16005ull;
    Term _fv_1913[1];
    _fv_1913[0] = 16006ull;
    Term _fv_1914[1];
    _fv_1914[0] = 16007ull;
    Term _fv_1915[1];
    _fv_1915[0] = 16008ull;
    Term _fv_1916[1];
    _fv_1916[0] = 16009ull;
    Term _fv_1917[1];
    _fv_1917[0] = 16010ull;
    Term _fv_1918[1];
    _fv_1918[0] = 16011ull;
    Term _fv_1919[1];
    _fv_1919[0] = 16012ull;
    Term _fv_1920[1];
    _fv_1920[0] = 16013ull;
    Term _fv_1921[1];
    _fv_1921[0] = 16014ull;
    Term _fv_1922[1];
    _fv_1922[0] = 16015ull;
    u32 _o_571 = 0;
    Term _o_572 = 0;
    Term _t_311 = 1;
    if (_t_311 == 0) {
      _o_571 = 0;
    } else {
      _o_571 = 1;
      u64 _nd_219 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_219 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1907), blk_new(e, 0, 0, 0, 1, _fv_1908)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1909), blk_new(e, 0, 0, 0, 1, _fv_1910))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1911), blk_new(e, 0, 0, 0, 1, _fv_1912)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1913), blk_new(e, 0, 0, 0, 1, _fv_1914)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1915), blk_new(e, 0, 0, 0, 1, _fv_1916)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1917), blk_new(e, 0, 0, 0, 1, _fv_1918))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1919), blk_new(e, 0, 0, 0, 1, _fv_1920)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1921), blk_new(e, 0, 0, 0, 1, _fv_1922))))));
      e.mem[_nd_219 + 1] = rfc_seal(e, 16ull);
      _o_572 = term_ctr(CID_OWNED, _nd_219);
    }
    Term _fv_1923[2];
    _fv_1923[0] = _o_571;
    _fv_1923[1] = _o_572;
    Term _fv_1924[1];
    _fv_1924[0] = 101000ull;
    Term _fv_1925[1];
    _fv_1925[0] = 101001ull;
    Term _fv_1926[1];
    _fv_1926[0] = 101002ull;
    Term _fv_1927[1];
    _fv_1927[0] = 101003ull;
    Term _fv_1928[1];
    _fv_1928[0] = 101004ull;
    Term _fv_1929[1];
    _fv_1929[0] = 101005ull;
    Term _fv_1930[1];
    _fv_1930[0] = 101006ull;
    Term _fv_1931[1];
    _fv_1931[0] = 101007ull;
    Term _fv_1932[1];
    _fv_1932[0] = 101008ull;
    Term _fv_1933[1];
    _fv_1933[0] = 101009ull;
    Term _fv_1934[1];
    _fv_1934[0] = 101010ull;
    Term _fv_1935[1];
    _fv_1935[0] = 101011ull;
    Term _fv_1936[1];
    _fv_1936[0] = 101012ull;
    Term _fv_1937[1];
    _fv_1937[0] = 101013ull;
    Term _fv_1938[1];
    _fv_1938[0] = 101014ull;
    Term _fv_1939[1];
    _fv_1939[0] = 101015ull;
    u32 _o_573 = 0;
    Term _o_574 = 0;
    Term _t_312 = 1;
    if (_t_312 == 0) {
      _o_573 = 0;
    } else {
      _o_573 = 1;
      u64 _nd_220 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_220 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1924), blk_new(e, 0, 0, 0, 1, _fv_1925)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1926), blk_new(e, 0, 0, 0, 1, _fv_1927))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1928), blk_new(e, 0, 0, 0, 1, _fv_1929)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1930), blk_new(e, 0, 0, 0, 1, _fv_1931)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1932), blk_new(e, 0, 0, 0, 1, _fv_1933)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1934), blk_new(e, 0, 0, 0, 1, _fv_1935))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1936), blk_new(e, 0, 0, 0, 1, _fv_1937)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1938), blk_new(e, 0, 0, 0, 1, _fv_1939))))));
      e.mem[_nd_220 + 1] = rfc_seal(e, 101ull);
      _o_574 = term_ctr(CID_OWNED, _nd_220);
    }
    Term _fv_1940[2];
    _fv_1940[0] = _o_573;
    _fv_1940[1] = _o_574;
    Term _fv_1941[1];
    _fv_1941[0] = 102000ull;
    Term _fv_1942[1];
    _fv_1942[0] = 102001ull;
    Term _fv_1943[1];
    _fv_1943[0] = 102002ull;
    Term _fv_1944[1];
    _fv_1944[0] = 102003ull;
    Term _fv_1945[1];
    _fv_1945[0] = 102004ull;
    Term _fv_1946[1];
    _fv_1946[0] = 102005ull;
    Term _fv_1947[1];
    _fv_1947[0] = 102006ull;
    Term _fv_1948[1];
    _fv_1948[0] = 102007ull;
    Term _fv_1949[1];
    _fv_1949[0] = 102008ull;
    Term _fv_1950[1];
    _fv_1950[0] = 102009ull;
    Term _fv_1951[1];
    _fv_1951[0] = 102010ull;
    Term _fv_1952[1];
    _fv_1952[0] = 102011ull;
    Term _fv_1953[1];
    _fv_1953[0] = 102012ull;
    Term _fv_1954[1];
    _fv_1954[0] = 102013ull;
    Term _fv_1955[1];
    _fv_1955[0] = 102014ull;
    Term _fv_1956[1];
    _fv_1956[0] = 102015ull;
    u32 _o_575 = 0;
    Term _o_576 = 0;
    Term _t_313 = 1;
    if (_t_313 == 0) {
      _o_575 = 0;
    } else {
      _o_575 = 1;
      u64 _nd_221 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_221 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1941), blk_new(e, 0, 0, 0, 1, _fv_1942)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1943), blk_new(e, 0, 0, 0, 1, _fv_1944))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1945), blk_new(e, 0, 0, 0, 1, _fv_1946)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1947), blk_new(e, 0, 0, 0, 1, _fv_1948)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1949), blk_new(e, 0, 0, 0, 1, _fv_1950)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1951), blk_new(e, 0, 0, 0, 1, _fv_1952))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1953), blk_new(e, 0, 0, 0, 1, _fv_1954)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1955), blk_new(e, 0, 0, 0, 1, _fv_1956))))));
      e.mem[_nd_221 + 1] = rfc_seal(e, 102ull);
      _o_576 = term_ctr(CID_OWNED, _nd_221);
    }
    Term _fv_1957[2];
    _fv_1957[0] = _o_575;
    _fv_1957[1] = _o_576;
    Term _fv_1958[1];
    _fv_1958[0] = 103000ull;
    Term _fv_1959[1];
    _fv_1959[0] = 103001ull;
    Term _fv_1960[1];
    _fv_1960[0] = 103002ull;
    Term _fv_1961[1];
    _fv_1961[0] = 103003ull;
    Term _fv_1962[1];
    _fv_1962[0] = 103004ull;
    Term _fv_1963[1];
    _fv_1963[0] = 103005ull;
    Term _fv_1964[1];
    _fv_1964[0] = 103006ull;
    Term _fv_1965[1];
    _fv_1965[0] = 103007ull;
    Term _fv_1966[1];
    _fv_1966[0] = 103008ull;
    Term _fv_1967[1];
    _fv_1967[0] = 103009ull;
    Term _fv_1968[1];
    _fv_1968[0] = 103010ull;
    Term _fv_1969[1];
    _fv_1969[0] = 103011ull;
    Term _fv_1970[1];
    _fv_1970[0] = 103012ull;
    Term _fv_1971[1];
    _fv_1971[0] = 103013ull;
    Term _fv_1972[1];
    _fv_1972[0] = 103014ull;
    Term _fv_1973[1];
    _fv_1973[0] = 103015ull;
    u32 _o_577 = 0;
    Term _o_578 = 0;
    Term _t_314 = 1;
    if (_t_314 == 0) {
      _o_577 = 0;
    } else {
      _o_577 = 1;
      u64 _nd_222 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_222 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1958), blk_new(e, 0, 0, 0, 1, _fv_1959)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1960), blk_new(e, 0, 0, 0, 1, _fv_1961))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1962), blk_new(e, 0, 0, 0, 1, _fv_1963)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1964), blk_new(e, 0, 0, 0, 1, _fv_1965)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1966), blk_new(e, 0, 0, 0, 1, _fv_1967)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1968), blk_new(e, 0, 0, 0, 1, _fv_1969))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1970), blk_new(e, 0, 0, 0, 1, _fv_1971)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1972), blk_new(e, 0, 0, 0, 1, _fv_1973))))));
      e.mem[_nd_222 + 1] = rfc_seal(e, 103ull);
      _o_578 = term_ctr(CID_OWNED, _nd_222);
    }
    Term _fv_1974[2];
    _fv_1974[0] = _o_577;
    _fv_1974[1] = _o_578;
    Term _fv_1975[1];
    _fv_1975[0] = 104000ull;
    Term _fv_1976[1];
    _fv_1976[0] = 104001ull;
    Term _fv_1977[1];
    _fv_1977[0] = 104002ull;
    Term _fv_1978[1];
    _fv_1978[0] = 104003ull;
    Term _fv_1979[1];
    _fv_1979[0] = 104004ull;
    Term _fv_1980[1];
    _fv_1980[0] = 104005ull;
    Term _fv_1981[1];
    _fv_1981[0] = 104006ull;
    Term _fv_1982[1];
    _fv_1982[0] = 104007ull;
    Term _fv_1983[1];
    _fv_1983[0] = 104008ull;
    Term _fv_1984[1];
    _fv_1984[0] = 104009ull;
    Term _fv_1985[1];
    _fv_1985[0] = 104010ull;
    Term _fv_1986[1];
    _fv_1986[0] = 104011ull;
    Term _fv_1987[1];
    _fv_1987[0] = 104012ull;
    Term _fv_1988[1];
    _fv_1988[0] = 104013ull;
    Term _fv_1989[1];
    _fv_1989[0] = 104014ull;
    Term _fv_1990[1];
    _fv_1990[0] = 104015ull;
    u32 _o_579 = 0;
    Term _o_580 = 0;
    Term _t_315 = 1;
    if (_t_315 == 0) {
      _o_579 = 0;
    } else {
      _o_579 = 1;
      u64 _nd_223 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_223 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1975), blk_new(e, 0, 0, 0, 1, _fv_1976)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1977), blk_new(e, 0, 0, 0, 1, _fv_1978))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1979), blk_new(e, 0, 0, 0, 1, _fv_1980)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1981), blk_new(e, 0, 0, 0, 1, _fv_1982)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1983), blk_new(e, 0, 0, 0, 1, _fv_1984)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1985), blk_new(e, 0, 0, 0, 1, _fv_1986))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1987), blk_new(e, 0, 0, 0, 1, _fv_1988)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1989), blk_new(e, 0, 0, 0, 1, _fv_1990))))));
      e.mem[_nd_223 + 1] = rfc_seal(e, 104ull);
      _o_580 = term_ctr(CID_OWNED, _nd_223);
    }
    Term _fv_1991[2];
    _fv_1991[0] = _o_579;
    _fv_1991[1] = _o_580;
    Term _fv_1992[1];
    _fv_1992[0] = 105000ull;
    Term _fv_1993[1];
    _fv_1993[0] = 105001ull;
    Term _fv_1994[1];
    _fv_1994[0] = 105002ull;
    Term _fv_1995[1];
    _fv_1995[0] = 105003ull;
    Term _fv_1996[1];
    _fv_1996[0] = 105004ull;
    Term _fv_1997[1];
    _fv_1997[0] = 105005ull;
    Term _fv_1998[1];
    _fv_1998[0] = 105006ull;
    Term _fv_1999[1];
    _fv_1999[0] = 105007ull;
    Term _fv_2000[1];
    _fv_2000[0] = 105008ull;
    Term _fv_2001[1];
    _fv_2001[0] = 105009ull;
    Term _fv_2002[1];
    _fv_2002[0] = 105010ull;
    Term _fv_2003[1];
    _fv_2003[0] = 105011ull;
    Term _fv_2004[1];
    _fv_2004[0] = 105012ull;
    Term _fv_2005[1];
    _fv_2005[0] = 105013ull;
    Term _fv_2006[1];
    _fv_2006[0] = 105014ull;
    Term _fv_2007[1];
    _fv_2007[0] = 105015ull;
    u32 _o_581 = 0;
    Term _o_582 = 0;
    Term _t_316 = 1;
    if (_t_316 == 0) {
      _o_581 = 0;
    } else {
      _o_581 = 1;
      u64 _nd_224 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_224 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1992), blk_new(e, 0, 0, 0, 1, _fv_1993)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1994), blk_new(e, 0, 0, 0, 1, _fv_1995))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1996), blk_new(e, 0, 0, 0, 1, _fv_1997)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_1998), blk_new(e, 0, 0, 0, 1, _fv_1999)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2000), blk_new(e, 0, 0, 0, 1, _fv_2001)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2002), blk_new(e, 0, 0, 0, 1, _fv_2003))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2004), blk_new(e, 0, 0, 0, 1, _fv_2005)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2006), blk_new(e, 0, 0, 0, 1, _fv_2007))))));
      e.mem[_nd_224 + 1] = rfc_seal(e, 105ull);
      _o_582 = term_ctr(CID_OWNED, _nd_224);
    }
    Term _fv_2008[2];
    _fv_2008[0] = _o_581;
    _fv_2008[1] = _o_582;
    Term _fv_2009[1];
    _fv_2009[0] = 106000ull;
    Term _fv_2010[1];
    _fv_2010[0] = 106001ull;
    Term _fv_2011[1];
    _fv_2011[0] = 106002ull;
    Term _fv_2012[1];
    _fv_2012[0] = 106003ull;
    Term _fv_2013[1];
    _fv_2013[0] = 106004ull;
    Term _fv_2014[1];
    _fv_2014[0] = 106005ull;
    Term _fv_2015[1];
    _fv_2015[0] = 106006ull;
    Term _fv_2016[1];
    _fv_2016[0] = 106007ull;
    Term _fv_2017[1];
    _fv_2017[0] = 106008ull;
    Term _fv_2018[1];
    _fv_2018[0] = 106009ull;
    Term _fv_2019[1];
    _fv_2019[0] = 106010ull;
    Term _fv_2020[1];
    _fv_2020[0] = 106011ull;
    Term _fv_2021[1];
    _fv_2021[0] = 106012ull;
    Term _fv_2022[1];
    _fv_2022[0] = 106013ull;
    Term _fv_2023[1];
    _fv_2023[0] = 106014ull;
    Term _fv_2024[1];
    _fv_2024[0] = 106015ull;
    u32 _o_583 = 0;
    Term _o_584 = 0;
    Term _t_317 = 1;
    if (_t_317 == 0) {
      _o_583 = 0;
    } else {
      _o_583 = 1;
      u64 _nd_225 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_225 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2009), blk_new(e, 0, 0, 0, 1, _fv_2010)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2011), blk_new(e, 0, 0, 0, 1, _fv_2012))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2013), blk_new(e, 0, 0, 0, 1, _fv_2014)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2015), blk_new(e, 0, 0, 0, 1, _fv_2016)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2017), blk_new(e, 0, 0, 0, 1, _fv_2018)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2019), blk_new(e, 0, 0, 0, 1, _fv_2020))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2021), blk_new(e, 0, 0, 0, 1, _fv_2022)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2023), blk_new(e, 0, 0, 0, 1, _fv_2024))))));
      e.mem[_nd_225 + 1] = rfc_seal(e, 106ull);
      _o_584 = term_ctr(CID_OWNED, _nd_225);
    }
    Term _fv_2025[2];
    _fv_2025[0] = _o_583;
    _fv_2025[1] = _o_584;
    Term _fv_2026[1];
    _fv_2026[0] = 107000ull;
    Term _fv_2027[1];
    _fv_2027[0] = 107001ull;
    Term _fv_2028[1];
    _fv_2028[0] = 107002ull;
    Term _fv_2029[1];
    _fv_2029[0] = 107003ull;
    Term _fv_2030[1];
    _fv_2030[0] = 107004ull;
    Term _fv_2031[1];
    _fv_2031[0] = 107005ull;
    Term _fv_2032[1];
    _fv_2032[0] = 107006ull;
    Term _fv_2033[1];
    _fv_2033[0] = 107007ull;
    Term _fv_2034[1];
    _fv_2034[0] = 107008ull;
    Term _fv_2035[1];
    _fv_2035[0] = 107009ull;
    Term _fv_2036[1];
    _fv_2036[0] = 107010ull;
    Term _fv_2037[1];
    _fv_2037[0] = 107011ull;
    Term _fv_2038[1];
    _fv_2038[0] = 107012ull;
    Term _fv_2039[1];
    _fv_2039[0] = 107013ull;
    Term _fv_2040[1];
    _fv_2040[0] = 107014ull;
    Term _fv_2041[1];
    _fv_2041[0] = 107015ull;
    u32 _o_585 = 0;
    Term _o_586 = 0;
    Term _t_318 = 1;
    if (_t_318 == 0) {
      _o_585 = 0;
    } else {
      _o_585 = 1;
      u64 _nd_226 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_226 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2026), blk_new(e, 0, 0, 0, 1, _fv_2027)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2028), blk_new(e, 0, 0, 0, 1, _fv_2029))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2030), blk_new(e, 0, 0, 0, 1, _fv_2031)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2032), blk_new(e, 0, 0, 0, 1, _fv_2033)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2034), blk_new(e, 0, 0, 0, 1, _fv_2035)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2036), blk_new(e, 0, 0, 0, 1, _fv_2037))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2038), blk_new(e, 0, 0, 0, 1, _fv_2039)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2040), blk_new(e, 0, 0, 0, 1, _fv_2041))))));
      e.mem[_nd_226 + 1] = rfc_seal(e, 107ull);
      _o_586 = term_ctr(CID_OWNED, _nd_226);
    }
    Term _fv_2042[2];
    _fv_2042[0] = _o_585;
    _fv_2042[1] = _o_586;
    Term _fv_2043[1];
    _fv_2043[0] = 108000ull;
    Term _fv_2044[1];
    _fv_2044[0] = 108001ull;
    Term _fv_2045[1];
    _fv_2045[0] = 108002ull;
    Term _fv_2046[1];
    _fv_2046[0] = 108003ull;
    Term _fv_2047[1];
    _fv_2047[0] = 108004ull;
    Term _fv_2048[1];
    _fv_2048[0] = 108005ull;
    Term _fv_2049[1];
    _fv_2049[0] = 108006ull;
    Term _fv_2050[1];
    _fv_2050[0] = 108007ull;
    Term _fv_2051[1];
    _fv_2051[0] = 108008ull;
    Term _fv_2052[1];
    _fv_2052[0] = 108009ull;
    Term _fv_2053[1];
    _fv_2053[0] = 108010ull;
    Term _fv_2054[1];
    _fv_2054[0] = 108011ull;
    Term _fv_2055[1];
    _fv_2055[0] = 108012ull;
    Term _fv_2056[1];
    _fv_2056[0] = 108013ull;
    Term _fv_2057[1];
    _fv_2057[0] = 108014ull;
    Term _fv_2058[1];
    _fv_2058[0] = 108015ull;
    u32 _o_587 = 0;
    Term _o_588 = 0;
    Term _t_319 = 1;
    if (_t_319 == 0) {
      _o_587 = 0;
    } else {
      _o_587 = 1;
      u64 _nd_227 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_227 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2043), blk_new(e, 0, 0, 0, 1, _fv_2044)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2045), blk_new(e, 0, 0, 0, 1, _fv_2046))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2047), blk_new(e, 0, 0, 0, 1, _fv_2048)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2049), blk_new(e, 0, 0, 0, 1, _fv_2050)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2051), blk_new(e, 0, 0, 0, 1, _fv_2052)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2053), blk_new(e, 0, 0, 0, 1, _fv_2054))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2055), blk_new(e, 0, 0, 0, 1, _fv_2056)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2057), blk_new(e, 0, 0, 0, 1, _fv_2058))))));
      e.mem[_nd_227 + 1] = rfc_seal(e, 108ull);
      _o_588 = term_ctr(CID_OWNED, _nd_227);
    }
    Term _fv_2059[2];
    _fv_2059[0] = _o_587;
    _fv_2059[1] = _o_588;
    Term _fv_2060[1];
    _fv_2060[0] = 109000ull;
    Term _fv_2061[1];
    _fv_2061[0] = 109001ull;
    Term _fv_2062[1];
    _fv_2062[0] = 109002ull;
    Term _fv_2063[1];
    _fv_2063[0] = 109003ull;
    Term _fv_2064[1];
    _fv_2064[0] = 109004ull;
    Term _fv_2065[1];
    _fv_2065[0] = 109005ull;
    Term _fv_2066[1];
    _fv_2066[0] = 109006ull;
    Term _fv_2067[1];
    _fv_2067[0] = 109007ull;
    Term _fv_2068[1];
    _fv_2068[0] = 109008ull;
    Term _fv_2069[1];
    _fv_2069[0] = 109009ull;
    Term _fv_2070[1];
    _fv_2070[0] = 109010ull;
    Term _fv_2071[1];
    _fv_2071[0] = 109011ull;
    Term _fv_2072[1];
    _fv_2072[0] = 109012ull;
    Term _fv_2073[1];
    _fv_2073[0] = 109013ull;
    Term _fv_2074[1];
    _fv_2074[0] = 109014ull;
    Term _fv_2075[1];
    _fv_2075[0] = 109015ull;
    u32 _o_589 = 0;
    Term _o_590 = 0;
    Term _t_320 = 1;
    if (_t_320 == 0) {
      _o_589 = 0;
    } else {
      _o_589 = 1;
      u64 _nd_228 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_228 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2060), blk_new(e, 0, 0, 0, 1, _fv_2061)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2062), blk_new(e, 0, 0, 0, 1, _fv_2063))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2064), blk_new(e, 0, 0, 0, 1, _fv_2065)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2066), blk_new(e, 0, 0, 0, 1, _fv_2067)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2068), blk_new(e, 0, 0, 0, 1, _fv_2069)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2070), blk_new(e, 0, 0, 0, 1, _fv_2071))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2072), blk_new(e, 0, 0, 0, 1, _fv_2073)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2074), blk_new(e, 0, 0, 0, 1, _fv_2075))))));
      e.mem[_nd_228 + 1] = rfc_seal(e, 109ull);
      _o_590 = term_ctr(CID_OWNED, _nd_228);
    }
    Term _fv_2076[2];
    _fv_2076[0] = _o_589;
    _fv_2076[1] = _o_590;
    Term _fv_2077[1];
    _fv_2077[0] = 110000ull;
    Term _fv_2078[1];
    _fv_2078[0] = 110001ull;
    Term _fv_2079[1];
    _fv_2079[0] = 110002ull;
    Term _fv_2080[1];
    _fv_2080[0] = 110003ull;
    Term _fv_2081[1];
    _fv_2081[0] = 110004ull;
    Term _fv_2082[1];
    _fv_2082[0] = 110005ull;
    Term _fv_2083[1];
    _fv_2083[0] = 110006ull;
    Term _fv_2084[1];
    _fv_2084[0] = 110007ull;
    Term _fv_2085[1];
    _fv_2085[0] = 110008ull;
    Term _fv_2086[1];
    _fv_2086[0] = 110009ull;
    Term _fv_2087[1];
    _fv_2087[0] = 110010ull;
    Term _fv_2088[1];
    _fv_2088[0] = 110011ull;
    Term _fv_2089[1];
    _fv_2089[0] = 110012ull;
    Term _fv_2090[1];
    _fv_2090[0] = 110013ull;
    Term _fv_2091[1];
    _fv_2091[0] = 110014ull;
    Term _fv_2092[1];
    _fv_2092[0] = 110015ull;
    u32 _o_591 = 0;
    Term _o_592 = 0;
    Term _t_321 = 1;
    if (_t_321 == 0) {
      _o_591 = 0;
    } else {
      _o_591 = 1;
      u64 _nd_229 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_229 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2077), blk_new(e, 0, 0, 0, 1, _fv_2078)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2079), blk_new(e, 0, 0, 0, 1, _fv_2080))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2081), blk_new(e, 0, 0, 0, 1, _fv_2082)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2083), blk_new(e, 0, 0, 0, 1, _fv_2084)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2085), blk_new(e, 0, 0, 0, 1, _fv_2086)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2087), blk_new(e, 0, 0, 0, 1, _fv_2088))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2089), blk_new(e, 0, 0, 0, 1, _fv_2090)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2091), blk_new(e, 0, 0, 0, 1, _fv_2092))))));
      e.mem[_nd_229 + 1] = rfc_seal(e, 110ull);
      _o_592 = term_ctr(CID_OWNED, _nd_229);
    }
    Term _fv_2093[2];
    _fv_2093[0] = _o_591;
    _fv_2093[1] = _o_592;
    Term _fv_2094[1];
    _fv_2094[0] = 111000ull;
    Term _fv_2095[1];
    _fv_2095[0] = 111001ull;
    Term _fv_2096[1];
    _fv_2096[0] = 111002ull;
    Term _fv_2097[1];
    _fv_2097[0] = 111003ull;
    Term _fv_2098[1];
    _fv_2098[0] = 111004ull;
    Term _fv_2099[1];
    _fv_2099[0] = 111005ull;
    Term _fv_2100[1];
    _fv_2100[0] = 111006ull;
    Term _fv_2101[1];
    _fv_2101[0] = 111007ull;
    Term _fv_2102[1];
    _fv_2102[0] = 111008ull;
    Term _fv_2103[1];
    _fv_2103[0] = 111009ull;
    Term _fv_2104[1];
    _fv_2104[0] = 111010ull;
    Term _fv_2105[1];
    _fv_2105[0] = 111011ull;
    Term _fv_2106[1];
    _fv_2106[0] = 111012ull;
    Term _fv_2107[1];
    _fv_2107[0] = 111013ull;
    Term _fv_2108[1];
    _fv_2108[0] = 111014ull;
    Term _fv_2109[1];
    _fv_2109[0] = 111015ull;
    u32 _o_593 = 0;
    Term _o_594 = 0;
    Term _t_322 = 1;
    if (_t_322 == 0) {
      _o_593 = 0;
    } else {
      _o_593 = 1;
      u64 _nd_230 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_230 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2094), blk_new(e, 0, 0, 0, 1, _fv_2095)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2096), blk_new(e, 0, 0, 0, 1, _fv_2097))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2098), blk_new(e, 0, 0, 0, 1, _fv_2099)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2100), blk_new(e, 0, 0, 0, 1, _fv_2101)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2102), blk_new(e, 0, 0, 0, 1, _fv_2103)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2104), blk_new(e, 0, 0, 0, 1, _fv_2105))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2106), blk_new(e, 0, 0, 0, 1, _fv_2107)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2108), blk_new(e, 0, 0, 0, 1, _fv_2109))))));
      e.mem[_nd_230 + 1] = rfc_seal(e, 111ull);
      _o_594 = term_ctr(CID_OWNED, _nd_230);
    }
    Term _fv_2110[2];
    _fv_2110[0] = _o_593;
    _fv_2110[1] = _o_594;
    Term _fv_2111[1];
    _fv_2111[0] = 112000ull;
    Term _fv_2112[1];
    _fv_2112[0] = 112001ull;
    Term _fv_2113[1];
    _fv_2113[0] = 112002ull;
    Term _fv_2114[1];
    _fv_2114[0] = 112003ull;
    Term _fv_2115[1];
    _fv_2115[0] = 112004ull;
    Term _fv_2116[1];
    _fv_2116[0] = 112005ull;
    Term _fv_2117[1];
    _fv_2117[0] = 112006ull;
    Term _fv_2118[1];
    _fv_2118[0] = 112007ull;
    Term _fv_2119[1];
    _fv_2119[0] = 112008ull;
    Term _fv_2120[1];
    _fv_2120[0] = 112009ull;
    Term _fv_2121[1];
    _fv_2121[0] = 112010ull;
    Term _fv_2122[1];
    _fv_2122[0] = 112011ull;
    Term _fv_2123[1];
    _fv_2123[0] = 112012ull;
    Term _fv_2124[1];
    _fv_2124[0] = 112013ull;
    Term _fv_2125[1];
    _fv_2125[0] = 112014ull;
    Term _fv_2126[1];
    _fv_2126[0] = 112015ull;
    u32 _o_595 = 0;
    Term _o_596 = 0;
    Term _t_323 = 1;
    if (_t_323 == 0) {
      _o_595 = 0;
    } else {
      _o_595 = 1;
      u64 _nd_231 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_231 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2111), blk_new(e, 0, 0, 0, 1, _fv_2112)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2113), blk_new(e, 0, 0, 0, 1, _fv_2114))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2115), blk_new(e, 0, 0, 0, 1, _fv_2116)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2117), blk_new(e, 0, 0, 0, 1, _fv_2118)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2119), blk_new(e, 0, 0, 0, 1, _fv_2120)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2121), blk_new(e, 0, 0, 0, 1, _fv_2122))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2123), blk_new(e, 0, 0, 0, 1, _fv_2124)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2125), blk_new(e, 0, 0, 0, 1, _fv_2126))))));
      e.mem[_nd_231 + 1] = rfc_seal(e, 112ull);
      _o_596 = term_ctr(CID_OWNED, _nd_231);
    }
    Term _fv_2127[2];
    _fv_2127[0] = _o_595;
    _fv_2127[1] = _o_596;
    Term _fv_2128[1];
    _fv_2128[0] = 113000ull;
    Term _fv_2129[1];
    _fv_2129[0] = 113001ull;
    Term _fv_2130[1];
    _fv_2130[0] = 113002ull;
    Term _fv_2131[1];
    _fv_2131[0] = 113003ull;
    Term _fv_2132[1];
    _fv_2132[0] = 113004ull;
    Term _fv_2133[1];
    _fv_2133[0] = 113005ull;
    Term _fv_2134[1];
    _fv_2134[0] = 113006ull;
    Term _fv_2135[1];
    _fv_2135[0] = 113007ull;
    Term _fv_2136[1];
    _fv_2136[0] = 113008ull;
    Term _fv_2137[1];
    _fv_2137[0] = 113009ull;
    Term _fv_2138[1];
    _fv_2138[0] = 113010ull;
    Term _fv_2139[1];
    _fv_2139[0] = 113011ull;
    Term _fv_2140[1];
    _fv_2140[0] = 113012ull;
    Term _fv_2141[1];
    _fv_2141[0] = 113013ull;
    Term _fv_2142[1];
    _fv_2142[0] = 113014ull;
    Term _fv_2143[1];
    _fv_2143[0] = 113015ull;
    u32 _o_597 = 0;
    Term _o_598 = 0;
    Term _t_324 = 1;
    if (_t_324 == 0) {
      _o_597 = 0;
    } else {
      _o_597 = 1;
      u64 _nd_232 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_232 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2128), blk_new(e, 0, 0, 0, 1, _fv_2129)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2130), blk_new(e, 0, 0, 0, 1, _fv_2131))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2132), blk_new(e, 0, 0, 0, 1, _fv_2133)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2134), blk_new(e, 0, 0, 0, 1, _fv_2135)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2136), blk_new(e, 0, 0, 0, 1, _fv_2137)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2138), blk_new(e, 0, 0, 0, 1, _fv_2139))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2140), blk_new(e, 0, 0, 0, 1, _fv_2141)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2142), blk_new(e, 0, 0, 0, 1, _fv_2143))))));
      e.mem[_nd_232 + 1] = rfc_seal(e, 113ull);
      _o_598 = term_ctr(CID_OWNED, _nd_232);
    }
    Term _fv_2144[2];
    _fv_2144[0] = _o_597;
    _fv_2144[1] = _o_598;
    Term _fv_2145[1];
    _fv_2145[0] = 114000ull;
    Term _fv_2146[1];
    _fv_2146[0] = 114001ull;
    Term _fv_2147[1];
    _fv_2147[0] = 114002ull;
    Term _fv_2148[1];
    _fv_2148[0] = 114003ull;
    Term _fv_2149[1];
    _fv_2149[0] = 114004ull;
    Term _fv_2150[1];
    _fv_2150[0] = 114005ull;
    Term _fv_2151[1];
    _fv_2151[0] = 114006ull;
    Term _fv_2152[1];
    _fv_2152[0] = 114007ull;
    Term _fv_2153[1];
    _fv_2153[0] = 114008ull;
    Term _fv_2154[1];
    _fv_2154[0] = 114009ull;
    Term _fv_2155[1];
    _fv_2155[0] = 114010ull;
    Term _fv_2156[1];
    _fv_2156[0] = 114011ull;
    Term _fv_2157[1];
    _fv_2157[0] = 114012ull;
    Term _fv_2158[1];
    _fv_2158[0] = 114013ull;
    Term _fv_2159[1];
    _fv_2159[0] = 114014ull;
    Term _fv_2160[1];
    _fv_2160[0] = 114015ull;
    u32 _o_599 = 0;
    Term _o_600 = 0;
    Term _t_325 = 1;
    if (_t_325 == 0) {
      _o_599 = 0;
    } else {
      _o_599 = 1;
      u64 _nd_233 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_233 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2145), blk_new(e, 0, 0, 0, 1, _fv_2146)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2147), blk_new(e, 0, 0, 0, 1, _fv_2148))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2149), blk_new(e, 0, 0, 0, 1, _fv_2150)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2151), blk_new(e, 0, 0, 0, 1, _fv_2152)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2153), blk_new(e, 0, 0, 0, 1, _fv_2154)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2155), blk_new(e, 0, 0, 0, 1, _fv_2156))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2157), blk_new(e, 0, 0, 0, 1, _fv_2158)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2159), blk_new(e, 0, 0, 0, 1, _fv_2160))))));
      e.mem[_nd_233 + 1] = rfc_seal(e, 114ull);
      _o_600 = term_ctr(CID_OWNED, _nd_233);
    }
    Term _fv_2161[2];
    _fv_2161[0] = _o_599;
    _fv_2161[1] = _o_600;
    Term _fv_2162[1];
    _fv_2162[0] = 115000ull;
    Term _fv_2163[1];
    _fv_2163[0] = 115001ull;
    Term _fv_2164[1];
    _fv_2164[0] = 115002ull;
    Term _fv_2165[1];
    _fv_2165[0] = 115003ull;
    Term _fv_2166[1];
    _fv_2166[0] = 115004ull;
    Term _fv_2167[1];
    _fv_2167[0] = 115005ull;
    Term _fv_2168[1];
    _fv_2168[0] = 115006ull;
    Term _fv_2169[1];
    _fv_2169[0] = 115007ull;
    Term _fv_2170[1];
    _fv_2170[0] = 115008ull;
    Term _fv_2171[1];
    _fv_2171[0] = 115009ull;
    Term _fv_2172[1];
    _fv_2172[0] = 115010ull;
    Term _fv_2173[1];
    _fv_2173[0] = 115011ull;
    Term _fv_2174[1];
    _fv_2174[0] = 115012ull;
    Term _fv_2175[1];
    _fv_2175[0] = 115013ull;
    Term _fv_2176[1];
    _fv_2176[0] = 115014ull;
    Term _fv_2177[1];
    _fv_2177[0] = 115015ull;
    u32 _o_601 = 0;
    Term _o_602 = 0;
    Term _t_326 = 1;
    if (_t_326 == 0) {
      _o_601 = 0;
    } else {
      _o_601 = 1;
      u64 _nd_234 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_234 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2162), blk_new(e, 0, 0, 0, 1, _fv_2163)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2164), blk_new(e, 0, 0, 0, 1, _fv_2165))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2166), blk_new(e, 0, 0, 0, 1, _fv_2167)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2168), blk_new(e, 0, 0, 0, 1, _fv_2169)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2170), blk_new(e, 0, 0, 0, 1, _fv_2171)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2172), blk_new(e, 0, 0, 0, 1, _fv_2173))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2174), blk_new(e, 0, 0, 0, 1, _fv_2175)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2176), blk_new(e, 0, 0, 0, 1, _fv_2177))))));
      e.mem[_nd_234 + 1] = rfc_seal(e, 115ull);
      _o_602 = term_ctr(CID_OWNED, _nd_234);
    }
    Term _fv_2178[2];
    _fv_2178[0] = _o_601;
    _fv_2178[1] = _o_602;
    Term _fv_2179[1];
    _fv_2179[0] = 116000ull;
    Term _fv_2180[1];
    _fv_2180[0] = 116001ull;
    Term _fv_2181[1];
    _fv_2181[0] = 116002ull;
    Term _fv_2182[1];
    _fv_2182[0] = 116003ull;
    Term _fv_2183[1];
    _fv_2183[0] = 116004ull;
    Term _fv_2184[1];
    _fv_2184[0] = 116005ull;
    Term _fv_2185[1];
    _fv_2185[0] = 116006ull;
    Term _fv_2186[1];
    _fv_2186[0] = 116007ull;
    Term _fv_2187[1];
    _fv_2187[0] = 116008ull;
    Term _fv_2188[1];
    _fv_2188[0] = 116009ull;
    Term _fv_2189[1];
    _fv_2189[0] = 116010ull;
    Term _fv_2190[1];
    _fv_2190[0] = 116011ull;
    Term _fv_2191[1];
    _fv_2191[0] = 116012ull;
    Term _fv_2192[1];
    _fv_2192[0] = 116013ull;
    Term _fv_2193[1];
    _fv_2193[0] = 116014ull;
    Term _fv_2194[1];
    _fv_2194[0] = 116015ull;
    u32 _o_603 = 0;
    Term _o_604 = 0;
    Term _t_327 = 1;
    if (_t_327 == 0) {
      _o_603 = 0;
    } else {
      _o_603 = 1;
      u64 _nd_235 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_235 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2179), blk_new(e, 0, 0, 0, 1, _fv_2180)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2181), blk_new(e, 0, 0, 0, 1, _fv_2182))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2183), blk_new(e, 0, 0, 0, 1, _fv_2184)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2185), blk_new(e, 0, 0, 0, 1, _fv_2186)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2187), blk_new(e, 0, 0, 0, 1, _fv_2188)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2189), blk_new(e, 0, 0, 0, 1, _fv_2190))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2191), blk_new(e, 0, 0, 0, 1, _fv_2192)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2193), blk_new(e, 0, 0, 0, 1, _fv_2194))))));
      e.mem[_nd_235 + 1] = rfc_seal(e, 116ull);
      _o_604 = term_ctr(CID_OWNED, _nd_235);
    }
    Term _fv_2195[2];
    _fv_2195[0] = _o_603;
    _fv_2195[1] = _o_604;
    Term _fv_2196[1];
    _fv_2196[0] = 1;
    Term _fv_2197[1];
    _fv_2197[0] = 1;
    Term _fv_2198[1];
    _fv_2198[0] = 0;
    Term _fv_2199[1];
    _fv_2199[0] = 1;
    Term _fv_2200[1];
    _fv_2200[0] = 1;
    Term _fv_2201[1];
    _fv_2201[0] = 1;
    Term _fv_2202[1];
    _fv_2202[0] = 1;
    Term _fv_2203[1];
    _fv_2203[0] = 1;
    Term _fv_2204[1];
    _fv_2204[0] = 1;
    Term _fv_2205[1];
    _fv_2205[0] = 1;
    Term _fv_2206[1];
    _fv_2206[0] = 1;
    Term _fv_2207[1];
    _fv_2207[0] = 1;
    Term _fv_2208[1];
    _fv_2208[0] = 1;
    Term _fv_2209[1];
    _fv_2209[0] = 1;
    Term _fv_2210[1];
    _fv_2210[0] = 1;
    Term _fv_2211[1];
    _fv_2211[0] = 1;
    u32 _o_605 = 0;
    Term _o_606 = 0;
    Term _t_328 = 1;
    if (_t_328 == 0) {
      _o_605 = 0;
    } else {
      _o_605 = 1;
      _o_606 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2212[2];
    _fv_2212[0] = _o_605;
    _fv_2212[1] = _o_606;
    u32 _o_607 = 0;
    Term _o_608 = 0;
    Term _t_329 = 0;
    if (_t_329 == 0) {
      _o_607 = 0;
    } else {
      _o_607 = 1;
      _o_608 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2213[2];
    _fv_2213[0] = _o_607;
    _fv_2213[1] = _o_608;
    u32 _o_609 = 0;
    Term _o_610 = 0;
    Term _t_330 = 1;
    if (_t_330 == 0) {
      _o_609 = 0;
    } else {
      _o_609 = 1;
      _o_610 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2214[2];
    _fv_2214[0] = _o_609;
    _fv_2214[1] = _o_610;
    u32 _o_611 = 0;
    Term _o_612 = 0;
    Term _t_331 = 0;
    if (_t_331 == 0) {
      _o_611 = 0;
    } else {
      _o_611 = 1;
      _o_612 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2215[2];
    _fv_2215[0] = _o_611;
    _fv_2215[1] = _o_612;
    u32 _o_613 = 0;
    Term _o_614 = 0;
    Term _t_332 = 1;
    if (_t_332 == 0) {
      _o_613 = 0;
    } else {
      _o_613 = 1;
      _o_614 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2216[2];
    _fv_2216[0] = _o_613;
    _fv_2216[1] = _o_614;
    u32 _o_615 = 0;
    Term _o_616 = 0;
    Term _t_333 = 0;
    if (_t_333 == 0) {
      _o_615 = 0;
    } else {
      _o_615 = 1;
      _o_616 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2217[2];
    _fv_2217[0] = _o_615;
    _fv_2217[1] = _o_616;
    u32 _o_617 = 0;
    Term _o_618 = 0;
    Term _t_334 = 1;
    if (_t_334 == 0) {
      _o_617 = 0;
    } else {
      _o_617 = 1;
      _o_618 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2218[2];
    _fv_2218[0] = _o_617;
    _fv_2218[1] = _o_618;
    u32 _o_619 = 0;
    Term _o_620 = 0;
    Term _t_335 = 0;
    if (_t_335 == 0) {
      _o_619 = 0;
    } else {
      _o_619 = 1;
      _o_620 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2219[2];
    _fv_2219[0] = _o_619;
    _fv_2219[1] = _o_620;
    u32 _o_621 = 0;
    Term _o_622 = 0;
    Term _t_336 = 1;
    if (_t_336 == 0) {
      _o_621 = 0;
    } else {
      _o_621 = 1;
      _o_622 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2220[2];
    _fv_2220[0] = _o_621;
    _fv_2220[1] = _o_622;
    u32 _o_623 = 0;
    Term _o_624 = 0;
    Term _t_337 = 0;
    if (_t_337 == 0) {
      _o_623 = 0;
    } else {
      _o_623 = 1;
      _o_624 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2221[2];
    _fv_2221[0] = _o_623;
    _fv_2221[1] = _o_624;
    u32 _o_625 = 0;
    Term _o_626 = 0;
    Term _t_338 = 1;
    if (_t_338 == 0) {
      _o_625 = 0;
    } else {
      _o_625 = 1;
      _o_626 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2222[2];
    _fv_2222[0] = _o_625;
    _fv_2222[1] = _o_626;
    u32 _o_627 = 0;
    Term _o_628 = 0;
    Term _t_339 = 0;
    if (_t_339 == 0) {
      _o_627 = 0;
    } else {
      _o_627 = 1;
      _o_628 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2223[2];
    _fv_2223[0] = _o_627;
    _fv_2223[1] = _o_628;
    u32 _o_629 = 0;
    Term _o_630 = 0;
    Term _t_340 = 1;
    if (_t_340 == 0) {
      _o_629 = 0;
    } else {
      _o_629 = 1;
      _o_630 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2224[2];
    _fv_2224[0] = _o_629;
    _fv_2224[1] = _o_630;
    u32 _o_631 = 0;
    Term _o_632 = 0;
    Term _t_341 = 0;
    if (_t_341 == 0) {
      _o_631 = 0;
    } else {
      _o_631 = 1;
      _o_632 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2225[2];
    _fv_2225[0] = _o_631;
    _fv_2225[1] = _o_632;
    u32 _o_633 = 0;
    Term _o_634 = 0;
    Term _t_342 = 1;
    if (_t_342 == 0) {
      _o_633 = 0;
    } else {
      _o_633 = 1;
      _o_634 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2226[2];
    _fv_2226[0] = _o_633;
    _fv_2226[1] = _o_634;
    u32 _o_635 = 0;
    Term _o_636 = 0;
    Term _t_343 = 0;
    if (_t_343 == 0) {
      _o_635 = 0;
    } else {
      _o_635 = 1;
      _o_636 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2227[2];
    _fv_2227[0] = _o_635;
    _fv_2227[1] = _o_636;
    Term _fv_2228[1];
    _fv_2228[0] = 100ull;
    Term _fv_2229[1];
    _fv_2229[0] = 101ull;
    Term _fv_2230[1];
    _fv_2230[0] = 102ull;
    Term _fv_2231[1];
    _fv_2231[0] = 103ull;
    Term _fv_2232[1];
    _fv_2232[0] = 104ull;
    Term _fv_2233[1];
    _fv_2233[0] = 105ull;
    Term _fv_2234[1];
    _fv_2234[0] = 106ull;
    Term _fv_2235[1];
    _fv_2235[0] = 107ull;
    Term _fv_2236[1];
    _fv_2236[0] = 108ull;
    Term _fv_2237[1];
    _fv_2237[0] = 109ull;
    Term _fv_2238[1];
    _fv_2238[0] = 110ull;
    Term _fv_2239[1];
    _fv_2239[0] = 111ull;
    Term _fv_2240[1];
    _fv_2240[0] = 112ull;
    Term _fv_2241[1];
    _fv_2241[0] = 113ull;
    Term _fv_2242[1];
    _fv_2242[0] = 114ull;
    Term _fv_2243[1];
    _fv_2243[0] = 115ull;
    Term _fv_2244[1];
    _fv_2244[0] = 200ull;
    Term _fv_2245[1];
    _fv_2245[0] = 201ull;
    Term _fv_2246[1];
    _fv_2246[0] = 202ull;
    Term _fv_2247[1];
    _fv_2247[0] = 203ull;
    Term _fv_2248[1];
    _fv_2248[0] = 204ull;
    Term _fv_2249[1];
    _fv_2249[0] = 205ull;
    Term _fv_2250[1];
    _fv_2250[0] = 206ull;
    Term _fv_2251[1];
    _fv_2251[0] = 207ull;
    Term _fv_2252[1];
    _fv_2252[0] = 208ull;
    Term _fv_2253[1];
    _fv_2253[0] = 209ull;
    Term _fv_2254[1];
    _fv_2254[0] = 210ull;
    Term _fv_2255[1];
    _fv_2255[0] = 211ull;
    Term _fv_2256[1];
    _fv_2256[0] = 212ull;
    Term _fv_2257[1];
    _fv_2257[0] = 213ull;
    Term _fv_2258[1];
    _fv_2258[0] = 214ull;
    Term _fv_2259[1];
    _fv_2259[0] = 215ull;
    Term _v_910 = 0;
    Term _v_911 = 0;
    Term _v_912 = 0;
    Term _v_913 = 0;
    Term _v_914 = 0;
    Term _v_915 = 0;
    u32 _v_916 = 0;
    Term _v_917 = 0;
    u32 _v_918 = 0;
    Term _v_919 = 0;
    Term _o_637[10];
    Term _a_170 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1684), blk_new(e, 1, 0, 1, 2, _fv_1685)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1702), blk_new(e, 1, 0, 1, 2, _fv_1719))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1736), blk_new(e, 1, 0, 1, 2, _fv_1753)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1770), blk_new(e, 1, 0, 1, 2, _fv_1787)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1804), blk_new(e, 1, 0, 1, 2, _fv_1821)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1838), blk_new(e, 1, 0, 1, 2, _fv_1855))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1872), blk_new(e, 1, 0, 1, 2, _fv_1889)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1906), blk_new(e, 1, 0, 1, 2, _fv_1923)))));
    Term _a_171 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1940), blk_new(e, 1, 0, 1, 2, _fv_1957)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_1974), blk_new(e, 1, 0, 1, 2, _fv_1991))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2008), blk_new(e, 1, 0, 1, 2, _fv_2025)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2042), blk_new(e, 1, 0, 1, 2, _fv_2059)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2076), blk_new(e, 1, 0, 1, 2, _fv_2093)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2110), blk_new(e, 1, 0, 1, 2, _fv_2127))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2144), blk_new(e, 1, 0, 1, 2, _fv_2161)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2178), blk_new(e, 1, 0, 1, 2, _fv_2195)))));
    Term _a_172 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2196), blk_new(e, 0, 0, 0, 1, _fv_2197)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2198), blk_new(e, 0, 0, 0, 1, _fv_2199))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2200), blk_new(e, 0, 0, 0, 1, _fv_2201)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2202), blk_new(e, 0, 0, 0, 1, _fv_2203)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2204), blk_new(e, 0, 0, 0, 1, _fv_2205)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2206), blk_new(e, 0, 0, 0, 1, _fv_2207))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2208), blk_new(e, 0, 0, 0, 1, _fv_2209)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2210), blk_new(e, 0, 0, 0, 1, _fv_2211)))));
    Term _a_173 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2212), blk_new(e, 1, 0, 1, 2, _fv_2213)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2214), blk_new(e, 1, 0, 1, 2, _fv_2215))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2216), blk_new(e, 1, 0, 1, 2, _fv_2217)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2218), blk_new(e, 1, 0, 1, 2, _fv_2219)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2220), blk_new(e, 1, 0, 1, 2, _fv_2221)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2222), blk_new(e, 1, 0, 1, 2, _fv_2223))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2224), blk_new(e, 1, 0, 1, 2, _fv_2225)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2226), blk_new(e, 1, 0, 1, 2, _fv_2227)))));
    Term _a_174 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2228), blk_new(e, 0, 0, 0, 1, _fv_2229)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2230), blk_new(e, 0, 0, 0, 1, _fv_2231))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2232), blk_new(e, 0, 0, 0, 1, _fv_2233)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2234), blk_new(e, 0, 0, 0, 1, _fv_2235)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2236), blk_new(e, 0, 0, 0, 1, _fv_2237)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2238), blk_new(e, 0, 0, 0, 1, _fv_2239))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2240), blk_new(e, 0, 0, 0, 1, _fv_2241)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2242), blk_new(e, 0, 0, 0, 1, _fv_2243)))));
    Term _a_175 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2244), blk_new(e, 0, 0, 0, 1, _fv_2245)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2246), blk_new(e, 0, 0, 0, 1, _fv_2247))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2248), blk_new(e, 0, 0, 0, 1, _fv_2249)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2250), blk_new(e, 0, 0, 0, 1, _fv_2251)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2252), blk_new(e, 0, 0, 0, 1, _fv_2253)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2254), blk_new(e, 0, 0, 0, 1, _fv_2255))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2256), blk_new(e, 0, 0, 0, 1, _fv_2257)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2258), blk_new(e, 0, 0, 0, 1, _fv_2259)))));
    Term _a_176 = term_pak(CID_NIL, 0);
    if (spin_19(e, _o_637, ((u64)15ull), 1ull, 16ull, 4ull, 15ull, 1, 7ull, _a_170, blk_loc(e.mem, _a_170), _a_171, blk_loc(e.mem, _a_171), _a_172, blk_loc(e.mem, _a_172), _a_173, blk_loc(e.mem, _a_173), _a_174, blk_loc(e.mem, _a_174), _a_175, blk_loc(e.mem, _a_175), _a_176, blk_loc(e.mem, _a_176)) == 0) {
      return 0;
    }
    _v_910 = _o_637[0];
    _v_911 = _o_637[1];
    _v_912 = _o_637[2];
    _v_913 = _o_637[3];
    _v_914 = _o_637[4];
    _v_915 = _o_637[5];
    _v_916 = _o_637[6];
    _v_917 = _o_637[7];
    _v_918 = _o_637[8];
    _v_919 = _o_637[9];
    _v_900 = _v_910;
    _v_901 = _v_911;
    _v_902 = _v_912;
    _v_903 = _v_913;
    _v_904 = _v_914;
    _v_905 = _v_915;
    _v_906 = _v_916;
    _v_907 = _v_917;
    _v_908 = _v_918;
    _v_909 = _v_919;
    u32 _v_920 = 0;
    u32 _v_921 = 0;
    Term _v_922 = 0;
    Term _v_923 = 0;
    Term _v_924 = 0;
    Term _v_925 = 0;
    Term _v_926 = 0;
    Term _v_927 = 0;
    u32 _v_928 = 0;
    Term _v_929 = 0;
    u32 _v_930 = 0;
    Term _v_931 = 0;
    u32 _v_932 = 0;
    Term _v_933 = 0;
    Term _v_934 = 0;
    Term _v_935 = 0;
    Term _o_638[16];
    Term _a_177 = term_pak(CID_NIL, 0);
    Term _a_178 = term_ctr(CID_OWNED, _nd_203);
    Term _a_179 = 123ull;
    if (spin_21(e, _o_638, 7ull, 999ull, _a_177, blk_loc(e.mem, _a_177), 1, _a_178, blk_loc(e.mem, _a_178), _a_179, blk_loc(e.mem, _a_179), _v_900, blk_loc(e.mem, _v_900), _v_901, blk_loc(e.mem, _v_901), _v_902, blk_loc(e.mem, _v_902), _v_903, blk_loc(e.mem, _v_903), _v_904, blk_loc(e.mem, _v_904), _v_905, blk_loc(e.mem, _v_905), _v_906, _v_907, _v_908, _v_909, blk_loc(e.mem, _v_909)) == 0) {
      return 0;
    }
    _v_920 = _o_638[0];
    _v_921 = _o_638[1];
    _v_922 = _o_638[2];
    _v_923 = _o_638[3];
    _v_924 = _o_638[4];
    _v_925 = _o_638[5];
    _v_926 = _o_638[6];
    _v_927 = _o_638[7];
    _v_928 = _o_638[8];
    _v_929 = _o_638[9];
    _v_930 = _o_638[10];
    _v_931 = _o_638[11];
    _v_932 = _o_638[12];
    _v_933 = _o_638[13];
    _v_934 = _o_638[14];
    _v_935 = _o_638[15];
    _v_884 = _v_920;
    _v_885 = _v_921;
    _v_886 = _v_922;
    _v_887 = _v_923;
    _v_888 = _v_924;
    _v_889 = _v_925;
    _v_890 = _v_926;
    _v_891 = _v_927;
    _v_892 = _v_928;
    _v_893 = _v_929;
    _v_894 = _v_930;
    _v_895 = _v_931;
    _v_896 = _v_932;
    _v_897 = _v_933;
    _v_898 = _v_934;
    _v_899 = _v_935;
    u32 _o_639 = 0;
    Term _o_640 = 0;
    u32 _o_641 = 0;
    if (_v_896 == 0) {
      _o_639 = 0;
    } else {
      _o_639 = 1;
      Term _fb_17[2];
      u64 _sp_17 = ctr_take(e, _v_897, 2, _fb_17);
      Term _f_34 = _fb_17[0];
      u32 _f_35 = _fb_17[1];
      spare_free(e, cls_fit(2), _sp_17);
      _o_640 = _f_34;
      _o_641 = _f_35;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K279;
      WL_PUSHN(1);
    } else {
      u64 _t_344 = task_node(e, FID_MAIN_K279, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K279, _t_344);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_345 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_345 + 0] = _v_884;
      e.mem[_t_345 + 1] = _v_885;
      e.mem[_t_345 + 2] = _v_886;
      e.mem[_t_345 + 3] = _v_887;
      e.mem[_t_345 + 4] = _v_888;
      e.mem[_t_345 + 5] = _v_889;
      e.mem[_t_345 + 6] = _v_890;
      e.mem[_t_345 + 7] = _v_891;
      e.mem[_t_345 + 8] = _v_892;
      e.mem[_t_345 + 9] = _v_893;
      e.mem[_t_345 + 10] = _v_894;
      e.mem[_t_345 + 11] = _v_895;
      e.mem[_t_345 + 12] = _o_639;
      e.mem[_t_345 + 13] = _o_640;
      e.mem[_t_345 + 14] = _o_641;
      e.mem[_t_345 + 15] = _v_898;
      e.mem[_t_345 + 16] = _v_899;
      return term_tsk(FID_SNAPSHOT, _t_345);
    }
    r0 = _v_884;
    r1 = _v_885;
    r2 = _v_886;
    r3 = _v_887;
    r4 = _v_888;
    r5 = _v_889;
    r6 = _v_890;
    r7 = _v_891;
    r8 = _v_892;
    r9 = _v_893;
    r10 = _v_894;
    r11 = _v_895;
    r12 = _o_639;
    r13 = _o_640;
    r14 = _o_641;
    r15 = _v_898;
    r16 = _v_899;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K279)
  {
    Term _h_51 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K280;
      WL_PUSHN(1);
    } else {
      u64 _t_346 = task_node(e, FID_MAIN_K280, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K280, _t_346);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_347 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_347 + 0] = term_ctr(CID_SCON, STAT_OFF + 196);
      e.mem[_t_347 + 1] = _h_51;
      return term_tsk(FID_STRING_APPEND, _t_347);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 196);
    r1 = _h_51;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K280)
  {
    Term _h_52 = r0;
    WL_OPEN
    u64 _nd_236 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_236 + 0] = _h_52;
    r0 = term_clo(FID_MAIN_C281, _nd_236);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C281)
  {
    Term _h_53 = r0;
    Term _x_34 = r1;
    WL_OPEN
    u64 _nd_237 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_237 + 0] = _h_53;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_455 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_455 + 0] = term_clo(FID_IO_PRINT, _nd_237);
      e.mem[_t_455 + 1] = term_clo(FID_MAIN_C282, 0);
      e.mem[_t_455 + 2] = _x_34;
      return term_tsk(FID_IO_BIND, _t_455);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_237);
    r1 = term_clo(FID_MAIN_C282, 0);
    r2 = _x_34;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C282)
  {
    Term _x_35 = r0;
    WL_OPEN
    u32 _v_936 = 0;
    u32 _v_937 = 0;
    Term _v_938 = 0;
    Term _v_939 = 0;
    Term _v_940 = 0;
    Term _v_941 = 0;
    Term _v_942 = 0;
    Term _v_943 = 0;
    u32 _v_944 = 0;
    Term _v_945 = 0;
    u32 _v_946 = 0;
    Term _v_947 = 0;
    u32 _v_948 = 0;
    Term _v_949 = 0;
    Term _v_950 = 0;
    Term _v_951 = 0;
    Term _fv_2260[1];
    _fv_2260[0] = 999000ull;
    Term _fv_2261[1];
    _fv_2261[0] = 999001ull;
    Term _fv_2262[1];
    _fv_2262[0] = 999002ull;
    Term _fv_2263[1];
    _fv_2263[0] = 999003ull;
    Term _fv_2264[1];
    _fv_2264[0] = 999004ull;
    Term _fv_2265[1];
    _fv_2265[0] = 999005ull;
    Term _fv_2266[1];
    _fv_2266[0] = 999006ull;
    Term _fv_2267[1];
    _fv_2267[0] = 999007ull;
    Term _fv_2268[1];
    _fv_2268[0] = 999008ull;
    Term _fv_2269[1];
    _fv_2269[0] = 999009ull;
    Term _fv_2270[1];
    _fv_2270[0] = 999010ull;
    Term _fv_2271[1];
    _fv_2271[0] = 999011ull;
    Term _fv_2272[1];
    _fv_2272[0] = 999012ull;
    Term _fv_2273[1];
    _fv_2273[0] = 999013ull;
    Term _fv_2274[1];
    _fv_2274[0] = 999014ull;
    Term _fv_2275[1];
    _fv_2275[0] = 999015ull;
    u64 _nd_238 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_238 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2260), blk_new(e, 0, 0, 0, 1, _fv_2261)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2262), blk_new(e, 0, 0, 0, 1, _fv_2263))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2264), blk_new(e, 0, 0, 0, 1, _fv_2265)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2266), blk_new(e, 0, 0, 0, 1, _fv_2267)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2268), blk_new(e, 0, 0, 0, 1, _fv_2269)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2270), blk_new(e, 0, 0, 0, 1, _fv_2271))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2272), blk_new(e, 0, 0, 0, 1, _fv_2273)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2274), blk_new(e, 0, 0, 0, 1, _fv_2275))))));
    e.mem[_nd_238 + 1] = rfc_seal(e, 999ull);
    Term _v_952 = 0;
    Term _v_953 = 0;
    Term _v_954 = 0;
    Term _v_955 = 0;
    Term _v_956 = 0;
    Term _v_957 = 0;
    u32 _v_958 = 0;
    Term _v_959 = 0;
    u32 _v_960 = 0;
    Term _v_961 = 0;
    Term _fv_2276[1];
    _fv_2276[0] = 1000ull;
    Term _fv_2277[1];
    _fv_2277[0] = 1001ull;
    Term _fv_2278[1];
    _fv_2278[0] = 1002ull;
    Term _fv_2279[1];
    _fv_2279[0] = 1003ull;
    Term _fv_2280[1];
    _fv_2280[0] = 1004ull;
    Term _fv_2281[1];
    _fv_2281[0] = 1005ull;
    Term _fv_2282[1];
    _fv_2282[0] = 1006ull;
    Term _fv_2283[1];
    _fv_2283[0] = 1007ull;
    Term _fv_2284[1];
    _fv_2284[0] = 1008ull;
    Term _fv_2285[1];
    _fv_2285[0] = 1009ull;
    Term _fv_2286[1];
    _fv_2286[0] = 1010ull;
    Term _fv_2287[1];
    _fv_2287[0] = 1011ull;
    Term _fv_2288[1];
    _fv_2288[0] = 1012ull;
    Term _fv_2289[1];
    _fv_2289[0] = 1013ull;
    Term _fv_2290[1];
    _fv_2290[0] = 1014ull;
    Term _fv_2291[1];
    _fv_2291[0] = 1015ull;
    u32 _o_642 = 0;
    Term _o_643 = 0;
    Term _t_348 = 1;
    if (_t_348 == 0) {
      _o_642 = 0;
    } else {
      _o_642 = 1;
      u64 _nd_239 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_239 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2276), blk_new(e, 0, 0, 0, 1, _fv_2277)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2278), blk_new(e, 0, 0, 0, 1, _fv_2279))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2280), blk_new(e, 0, 0, 0, 1, _fv_2281)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2282), blk_new(e, 0, 0, 0, 1, _fv_2283)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2284), blk_new(e, 0, 0, 0, 1, _fv_2285)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2286), blk_new(e, 0, 0, 0, 1, _fv_2287))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2288), blk_new(e, 0, 0, 0, 1, _fv_2289)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2290), blk_new(e, 0, 0, 0, 1, _fv_2291))))));
      e.mem[_nd_239 + 1] = rfc_seal(e, 1ull);
      _o_643 = term_ctr(CID_OWNED, _nd_239);
    }
    Term _fv_2292[2];
    _fv_2292[0] = _o_642;
    _fv_2292[1] = _o_643;
    u32 _o_644 = 0;
    Term _o_645 = 0;
    Term _t_349 = 0;
    if (_t_349 == 0) {
      _o_644 = 0;
    } else {
      _o_644 = 1;
      u64 _nd_240 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_240 + 0] = rfc_seal(e, 0);
      e.mem[_nd_240 + 1] = rfc_seal(e, 0);
      _o_645 = term_ctr(CID_OWNED, _nd_240);
    }
    Term _fv_2293[2];
    _fv_2293[0] = _o_644;
    _fv_2293[1] = _o_645;
    Term _fv_2294[1];
    _fv_2294[0] = 3000ull;
    Term _fv_2295[1];
    _fv_2295[0] = 3001ull;
    Term _fv_2296[1];
    _fv_2296[0] = 3002ull;
    Term _fv_2297[1];
    _fv_2297[0] = 3003ull;
    Term _fv_2298[1];
    _fv_2298[0] = 3004ull;
    Term _fv_2299[1];
    _fv_2299[0] = 3005ull;
    Term _fv_2300[1];
    _fv_2300[0] = 3006ull;
    Term _fv_2301[1];
    _fv_2301[0] = 3007ull;
    Term _fv_2302[1];
    _fv_2302[0] = 3008ull;
    Term _fv_2303[1];
    _fv_2303[0] = 3009ull;
    Term _fv_2304[1];
    _fv_2304[0] = 3010ull;
    Term _fv_2305[1];
    _fv_2305[0] = 3011ull;
    Term _fv_2306[1];
    _fv_2306[0] = 3012ull;
    Term _fv_2307[1];
    _fv_2307[0] = 3013ull;
    Term _fv_2308[1];
    _fv_2308[0] = 3014ull;
    Term _fv_2309[1];
    _fv_2309[0] = 3015ull;
    u32 _o_646 = 0;
    Term _o_647 = 0;
    Term _t_350 = 1;
    if (_t_350 == 0) {
      _o_646 = 0;
    } else {
      _o_646 = 1;
      u64 _nd_241 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_241 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2294), blk_new(e, 0, 0, 0, 1, _fv_2295)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2296), blk_new(e, 0, 0, 0, 1, _fv_2297))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2298), blk_new(e, 0, 0, 0, 1, _fv_2299)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2300), blk_new(e, 0, 0, 0, 1, _fv_2301)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2302), blk_new(e, 0, 0, 0, 1, _fv_2303)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2304), blk_new(e, 0, 0, 0, 1, _fv_2305))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2306), blk_new(e, 0, 0, 0, 1, _fv_2307)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2308), blk_new(e, 0, 0, 0, 1, _fv_2309))))));
      e.mem[_nd_241 + 1] = rfc_seal(e, 3ull);
      _o_647 = term_ctr(CID_OWNED, _nd_241);
    }
    Term _fv_2310[2];
    _fv_2310[0] = _o_646;
    _fv_2310[1] = _o_647;
    Term _fv_2311[1];
    _fv_2311[0] = 4000ull;
    Term _fv_2312[1];
    _fv_2312[0] = 4001ull;
    Term _fv_2313[1];
    _fv_2313[0] = 4002ull;
    Term _fv_2314[1];
    _fv_2314[0] = 4003ull;
    Term _fv_2315[1];
    _fv_2315[0] = 4004ull;
    Term _fv_2316[1];
    _fv_2316[0] = 4005ull;
    Term _fv_2317[1];
    _fv_2317[0] = 4006ull;
    Term _fv_2318[1];
    _fv_2318[0] = 4007ull;
    Term _fv_2319[1];
    _fv_2319[0] = 4008ull;
    Term _fv_2320[1];
    _fv_2320[0] = 4009ull;
    Term _fv_2321[1];
    _fv_2321[0] = 4010ull;
    Term _fv_2322[1];
    _fv_2322[0] = 4011ull;
    Term _fv_2323[1];
    _fv_2323[0] = 4012ull;
    Term _fv_2324[1];
    _fv_2324[0] = 4013ull;
    Term _fv_2325[1];
    _fv_2325[0] = 4014ull;
    Term _fv_2326[1];
    _fv_2326[0] = 4015ull;
    u32 _o_648 = 0;
    Term _o_649 = 0;
    Term _t_351 = 1;
    if (_t_351 == 0) {
      _o_648 = 0;
    } else {
      _o_648 = 1;
      u64 _nd_242 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_242 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2311), blk_new(e, 0, 0, 0, 1, _fv_2312)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2313), blk_new(e, 0, 0, 0, 1, _fv_2314))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2315), blk_new(e, 0, 0, 0, 1, _fv_2316)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2317), blk_new(e, 0, 0, 0, 1, _fv_2318)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2319), blk_new(e, 0, 0, 0, 1, _fv_2320)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2321), blk_new(e, 0, 0, 0, 1, _fv_2322))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2323), blk_new(e, 0, 0, 0, 1, _fv_2324)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2325), blk_new(e, 0, 0, 0, 1, _fv_2326))))));
      e.mem[_nd_242 + 1] = rfc_seal(e, 4ull);
      _o_649 = term_ctr(CID_OWNED, _nd_242);
    }
    Term _fv_2327[2];
    _fv_2327[0] = _o_648;
    _fv_2327[1] = _o_649;
    Term _fv_2328[1];
    _fv_2328[0] = 5000ull;
    Term _fv_2329[1];
    _fv_2329[0] = 5001ull;
    Term _fv_2330[1];
    _fv_2330[0] = 5002ull;
    Term _fv_2331[1];
    _fv_2331[0] = 5003ull;
    Term _fv_2332[1];
    _fv_2332[0] = 5004ull;
    Term _fv_2333[1];
    _fv_2333[0] = 5005ull;
    Term _fv_2334[1];
    _fv_2334[0] = 5006ull;
    Term _fv_2335[1];
    _fv_2335[0] = 5007ull;
    Term _fv_2336[1];
    _fv_2336[0] = 5008ull;
    Term _fv_2337[1];
    _fv_2337[0] = 5009ull;
    Term _fv_2338[1];
    _fv_2338[0] = 5010ull;
    Term _fv_2339[1];
    _fv_2339[0] = 5011ull;
    Term _fv_2340[1];
    _fv_2340[0] = 5012ull;
    Term _fv_2341[1];
    _fv_2341[0] = 5013ull;
    Term _fv_2342[1];
    _fv_2342[0] = 5014ull;
    Term _fv_2343[1];
    _fv_2343[0] = 5015ull;
    u32 _o_650 = 0;
    Term _o_651 = 0;
    Term _t_352 = 1;
    if (_t_352 == 0) {
      _o_650 = 0;
    } else {
      _o_650 = 1;
      u64 _nd_243 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_243 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2328), blk_new(e, 0, 0, 0, 1, _fv_2329)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2330), blk_new(e, 0, 0, 0, 1, _fv_2331))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2332), blk_new(e, 0, 0, 0, 1, _fv_2333)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2334), blk_new(e, 0, 0, 0, 1, _fv_2335)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2336), blk_new(e, 0, 0, 0, 1, _fv_2337)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2338), blk_new(e, 0, 0, 0, 1, _fv_2339))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2340), blk_new(e, 0, 0, 0, 1, _fv_2341)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2342), blk_new(e, 0, 0, 0, 1, _fv_2343))))));
      e.mem[_nd_243 + 1] = rfc_seal(e, 5ull);
      _o_651 = term_ctr(CID_OWNED, _nd_243);
    }
    Term _fv_2344[2];
    _fv_2344[0] = _o_650;
    _fv_2344[1] = _o_651;
    Term _fv_2345[1];
    _fv_2345[0] = 6000ull;
    Term _fv_2346[1];
    _fv_2346[0] = 6001ull;
    Term _fv_2347[1];
    _fv_2347[0] = 6002ull;
    Term _fv_2348[1];
    _fv_2348[0] = 6003ull;
    Term _fv_2349[1];
    _fv_2349[0] = 6004ull;
    Term _fv_2350[1];
    _fv_2350[0] = 6005ull;
    Term _fv_2351[1];
    _fv_2351[0] = 6006ull;
    Term _fv_2352[1];
    _fv_2352[0] = 6007ull;
    Term _fv_2353[1];
    _fv_2353[0] = 6008ull;
    Term _fv_2354[1];
    _fv_2354[0] = 6009ull;
    Term _fv_2355[1];
    _fv_2355[0] = 6010ull;
    Term _fv_2356[1];
    _fv_2356[0] = 6011ull;
    Term _fv_2357[1];
    _fv_2357[0] = 6012ull;
    Term _fv_2358[1];
    _fv_2358[0] = 6013ull;
    Term _fv_2359[1];
    _fv_2359[0] = 6014ull;
    Term _fv_2360[1];
    _fv_2360[0] = 6015ull;
    u32 _o_652 = 0;
    Term _o_653 = 0;
    Term _t_353 = 1;
    if (_t_353 == 0) {
      _o_652 = 0;
    } else {
      _o_652 = 1;
      u64 _nd_244 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_244 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2345), blk_new(e, 0, 0, 0, 1, _fv_2346)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2347), blk_new(e, 0, 0, 0, 1, _fv_2348))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2349), blk_new(e, 0, 0, 0, 1, _fv_2350)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2351), blk_new(e, 0, 0, 0, 1, _fv_2352)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2353), blk_new(e, 0, 0, 0, 1, _fv_2354)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2355), blk_new(e, 0, 0, 0, 1, _fv_2356))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2357), blk_new(e, 0, 0, 0, 1, _fv_2358)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2359), blk_new(e, 0, 0, 0, 1, _fv_2360))))));
      e.mem[_nd_244 + 1] = rfc_seal(e, 6ull);
      _o_653 = term_ctr(CID_OWNED, _nd_244);
    }
    Term _fv_2361[2];
    _fv_2361[0] = _o_652;
    _fv_2361[1] = _o_653;
    Term _fv_2362[1];
    _fv_2362[0] = 7000ull;
    Term _fv_2363[1];
    _fv_2363[0] = 7001ull;
    Term _fv_2364[1];
    _fv_2364[0] = 7002ull;
    Term _fv_2365[1];
    _fv_2365[0] = 7003ull;
    Term _fv_2366[1];
    _fv_2366[0] = 7004ull;
    Term _fv_2367[1];
    _fv_2367[0] = 7005ull;
    Term _fv_2368[1];
    _fv_2368[0] = 7006ull;
    Term _fv_2369[1];
    _fv_2369[0] = 7007ull;
    Term _fv_2370[1];
    _fv_2370[0] = 7008ull;
    Term _fv_2371[1];
    _fv_2371[0] = 7009ull;
    Term _fv_2372[1];
    _fv_2372[0] = 7010ull;
    Term _fv_2373[1];
    _fv_2373[0] = 7011ull;
    Term _fv_2374[1];
    _fv_2374[0] = 7012ull;
    Term _fv_2375[1];
    _fv_2375[0] = 7013ull;
    Term _fv_2376[1];
    _fv_2376[0] = 7014ull;
    Term _fv_2377[1];
    _fv_2377[0] = 7015ull;
    u32 _o_654 = 0;
    Term _o_655 = 0;
    Term _t_354 = 1;
    if (_t_354 == 0) {
      _o_654 = 0;
    } else {
      _o_654 = 1;
      u64 _nd_245 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_245 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2362), blk_new(e, 0, 0, 0, 1, _fv_2363)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2364), blk_new(e, 0, 0, 0, 1, _fv_2365))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2366), blk_new(e, 0, 0, 0, 1, _fv_2367)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2368), blk_new(e, 0, 0, 0, 1, _fv_2369)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2370), blk_new(e, 0, 0, 0, 1, _fv_2371)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2372), blk_new(e, 0, 0, 0, 1, _fv_2373))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2374), blk_new(e, 0, 0, 0, 1, _fv_2375)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2376), blk_new(e, 0, 0, 0, 1, _fv_2377))))));
      e.mem[_nd_245 + 1] = rfc_seal(e, 7ull);
      _o_655 = term_ctr(CID_OWNED, _nd_245);
    }
    Term _fv_2378[2];
    _fv_2378[0] = _o_654;
    _fv_2378[1] = _o_655;
    Term _fv_2379[1];
    _fv_2379[0] = 8000ull;
    Term _fv_2380[1];
    _fv_2380[0] = 8001ull;
    Term _fv_2381[1];
    _fv_2381[0] = 8002ull;
    Term _fv_2382[1];
    _fv_2382[0] = 8003ull;
    Term _fv_2383[1];
    _fv_2383[0] = 8004ull;
    Term _fv_2384[1];
    _fv_2384[0] = 8005ull;
    Term _fv_2385[1];
    _fv_2385[0] = 8006ull;
    Term _fv_2386[1];
    _fv_2386[0] = 8007ull;
    Term _fv_2387[1];
    _fv_2387[0] = 8008ull;
    Term _fv_2388[1];
    _fv_2388[0] = 8009ull;
    Term _fv_2389[1];
    _fv_2389[0] = 8010ull;
    Term _fv_2390[1];
    _fv_2390[0] = 8011ull;
    Term _fv_2391[1];
    _fv_2391[0] = 8012ull;
    Term _fv_2392[1];
    _fv_2392[0] = 8013ull;
    Term _fv_2393[1];
    _fv_2393[0] = 8014ull;
    Term _fv_2394[1];
    _fv_2394[0] = 8015ull;
    u32 _o_656 = 0;
    Term _o_657 = 0;
    Term _t_355 = 1;
    if (_t_355 == 0) {
      _o_656 = 0;
    } else {
      _o_656 = 1;
      u64 _nd_246 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_246 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2379), blk_new(e, 0, 0, 0, 1, _fv_2380)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2381), blk_new(e, 0, 0, 0, 1, _fv_2382))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2383), blk_new(e, 0, 0, 0, 1, _fv_2384)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2385), blk_new(e, 0, 0, 0, 1, _fv_2386)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2387), blk_new(e, 0, 0, 0, 1, _fv_2388)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2389), blk_new(e, 0, 0, 0, 1, _fv_2390))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2391), blk_new(e, 0, 0, 0, 1, _fv_2392)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2393), blk_new(e, 0, 0, 0, 1, _fv_2394))))));
      e.mem[_nd_246 + 1] = rfc_seal(e, 8ull);
      _o_657 = term_ctr(CID_OWNED, _nd_246);
    }
    Term _fv_2395[2];
    _fv_2395[0] = _o_656;
    _fv_2395[1] = _o_657;
    Term _fv_2396[1];
    _fv_2396[0] = 9000ull;
    Term _fv_2397[1];
    _fv_2397[0] = 9001ull;
    Term _fv_2398[1];
    _fv_2398[0] = 9002ull;
    Term _fv_2399[1];
    _fv_2399[0] = 9003ull;
    Term _fv_2400[1];
    _fv_2400[0] = 9004ull;
    Term _fv_2401[1];
    _fv_2401[0] = 9005ull;
    Term _fv_2402[1];
    _fv_2402[0] = 9006ull;
    Term _fv_2403[1];
    _fv_2403[0] = 9007ull;
    Term _fv_2404[1];
    _fv_2404[0] = 9008ull;
    Term _fv_2405[1];
    _fv_2405[0] = 9009ull;
    Term _fv_2406[1];
    _fv_2406[0] = 9010ull;
    Term _fv_2407[1];
    _fv_2407[0] = 9011ull;
    Term _fv_2408[1];
    _fv_2408[0] = 9012ull;
    Term _fv_2409[1];
    _fv_2409[0] = 9013ull;
    Term _fv_2410[1];
    _fv_2410[0] = 9014ull;
    Term _fv_2411[1];
    _fv_2411[0] = 9015ull;
    u32 _o_658 = 0;
    Term _o_659 = 0;
    Term _t_356 = 1;
    if (_t_356 == 0) {
      _o_658 = 0;
    } else {
      _o_658 = 1;
      u64 _nd_247 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_247 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2396), blk_new(e, 0, 0, 0, 1, _fv_2397)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2398), blk_new(e, 0, 0, 0, 1, _fv_2399))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2400), blk_new(e, 0, 0, 0, 1, _fv_2401)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2402), blk_new(e, 0, 0, 0, 1, _fv_2403)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2404), blk_new(e, 0, 0, 0, 1, _fv_2405)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2406), blk_new(e, 0, 0, 0, 1, _fv_2407))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2408), blk_new(e, 0, 0, 0, 1, _fv_2409)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2410), blk_new(e, 0, 0, 0, 1, _fv_2411))))));
      e.mem[_nd_247 + 1] = rfc_seal(e, 9ull);
      _o_659 = term_ctr(CID_OWNED, _nd_247);
    }
    Term _fv_2412[2];
    _fv_2412[0] = _o_658;
    _fv_2412[1] = _o_659;
    Term _fv_2413[1];
    _fv_2413[0] = 10000ull;
    Term _fv_2414[1];
    _fv_2414[0] = 10001ull;
    Term _fv_2415[1];
    _fv_2415[0] = 10002ull;
    Term _fv_2416[1];
    _fv_2416[0] = 10003ull;
    Term _fv_2417[1];
    _fv_2417[0] = 10004ull;
    Term _fv_2418[1];
    _fv_2418[0] = 10005ull;
    Term _fv_2419[1];
    _fv_2419[0] = 10006ull;
    Term _fv_2420[1];
    _fv_2420[0] = 10007ull;
    Term _fv_2421[1];
    _fv_2421[0] = 10008ull;
    Term _fv_2422[1];
    _fv_2422[0] = 10009ull;
    Term _fv_2423[1];
    _fv_2423[0] = 10010ull;
    Term _fv_2424[1];
    _fv_2424[0] = 10011ull;
    Term _fv_2425[1];
    _fv_2425[0] = 10012ull;
    Term _fv_2426[1];
    _fv_2426[0] = 10013ull;
    Term _fv_2427[1];
    _fv_2427[0] = 10014ull;
    Term _fv_2428[1];
    _fv_2428[0] = 10015ull;
    u32 _o_660 = 0;
    Term _o_661 = 0;
    Term _t_357 = 1;
    if (_t_357 == 0) {
      _o_660 = 0;
    } else {
      _o_660 = 1;
      u64 _nd_248 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_248 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2413), blk_new(e, 0, 0, 0, 1, _fv_2414)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2415), blk_new(e, 0, 0, 0, 1, _fv_2416))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2417), blk_new(e, 0, 0, 0, 1, _fv_2418)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2419), blk_new(e, 0, 0, 0, 1, _fv_2420)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2421), blk_new(e, 0, 0, 0, 1, _fv_2422)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2423), blk_new(e, 0, 0, 0, 1, _fv_2424))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2425), blk_new(e, 0, 0, 0, 1, _fv_2426)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2427), blk_new(e, 0, 0, 0, 1, _fv_2428))))));
      e.mem[_nd_248 + 1] = rfc_seal(e, 10ull);
      _o_661 = term_ctr(CID_OWNED, _nd_248);
    }
    Term _fv_2429[2];
    _fv_2429[0] = _o_660;
    _fv_2429[1] = _o_661;
    Term _fv_2430[1];
    _fv_2430[0] = 11000ull;
    Term _fv_2431[1];
    _fv_2431[0] = 11001ull;
    Term _fv_2432[1];
    _fv_2432[0] = 11002ull;
    Term _fv_2433[1];
    _fv_2433[0] = 11003ull;
    Term _fv_2434[1];
    _fv_2434[0] = 11004ull;
    Term _fv_2435[1];
    _fv_2435[0] = 11005ull;
    Term _fv_2436[1];
    _fv_2436[0] = 11006ull;
    Term _fv_2437[1];
    _fv_2437[0] = 11007ull;
    Term _fv_2438[1];
    _fv_2438[0] = 11008ull;
    Term _fv_2439[1];
    _fv_2439[0] = 11009ull;
    Term _fv_2440[1];
    _fv_2440[0] = 11010ull;
    Term _fv_2441[1];
    _fv_2441[0] = 11011ull;
    Term _fv_2442[1];
    _fv_2442[0] = 11012ull;
    Term _fv_2443[1];
    _fv_2443[0] = 11013ull;
    Term _fv_2444[1];
    _fv_2444[0] = 11014ull;
    Term _fv_2445[1];
    _fv_2445[0] = 11015ull;
    u32 _o_662 = 0;
    Term _o_663 = 0;
    Term _t_358 = 1;
    if (_t_358 == 0) {
      _o_662 = 0;
    } else {
      _o_662 = 1;
      u64 _nd_249 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_249 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2430), blk_new(e, 0, 0, 0, 1, _fv_2431)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2432), blk_new(e, 0, 0, 0, 1, _fv_2433))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2434), blk_new(e, 0, 0, 0, 1, _fv_2435)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2436), blk_new(e, 0, 0, 0, 1, _fv_2437)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2438), blk_new(e, 0, 0, 0, 1, _fv_2439)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2440), blk_new(e, 0, 0, 0, 1, _fv_2441))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2442), blk_new(e, 0, 0, 0, 1, _fv_2443)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2444), blk_new(e, 0, 0, 0, 1, _fv_2445))))));
      e.mem[_nd_249 + 1] = rfc_seal(e, 11ull);
      _o_663 = term_ctr(CID_OWNED, _nd_249);
    }
    Term _fv_2446[2];
    _fv_2446[0] = _o_662;
    _fv_2446[1] = _o_663;
    Term _fv_2447[1];
    _fv_2447[0] = 12000ull;
    Term _fv_2448[1];
    _fv_2448[0] = 12001ull;
    Term _fv_2449[1];
    _fv_2449[0] = 12002ull;
    Term _fv_2450[1];
    _fv_2450[0] = 12003ull;
    Term _fv_2451[1];
    _fv_2451[0] = 12004ull;
    Term _fv_2452[1];
    _fv_2452[0] = 12005ull;
    Term _fv_2453[1];
    _fv_2453[0] = 12006ull;
    Term _fv_2454[1];
    _fv_2454[0] = 12007ull;
    Term _fv_2455[1];
    _fv_2455[0] = 12008ull;
    Term _fv_2456[1];
    _fv_2456[0] = 12009ull;
    Term _fv_2457[1];
    _fv_2457[0] = 12010ull;
    Term _fv_2458[1];
    _fv_2458[0] = 12011ull;
    Term _fv_2459[1];
    _fv_2459[0] = 12012ull;
    Term _fv_2460[1];
    _fv_2460[0] = 12013ull;
    Term _fv_2461[1];
    _fv_2461[0] = 12014ull;
    Term _fv_2462[1];
    _fv_2462[0] = 12015ull;
    u32 _o_664 = 0;
    Term _o_665 = 0;
    Term _t_359 = 1;
    if (_t_359 == 0) {
      _o_664 = 0;
    } else {
      _o_664 = 1;
      u64 _nd_250 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_250 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2447), blk_new(e, 0, 0, 0, 1, _fv_2448)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2449), blk_new(e, 0, 0, 0, 1, _fv_2450))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2451), blk_new(e, 0, 0, 0, 1, _fv_2452)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2453), blk_new(e, 0, 0, 0, 1, _fv_2454)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2455), blk_new(e, 0, 0, 0, 1, _fv_2456)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2457), blk_new(e, 0, 0, 0, 1, _fv_2458))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2459), blk_new(e, 0, 0, 0, 1, _fv_2460)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2461), blk_new(e, 0, 0, 0, 1, _fv_2462))))));
      e.mem[_nd_250 + 1] = rfc_seal(e, 12ull);
      _o_665 = term_ctr(CID_OWNED, _nd_250);
    }
    Term _fv_2463[2];
    _fv_2463[0] = _o_664;
    _fv_2463[1] = _o_665;
    Term _fv_2464[1];
    _fv_2464[0] = 13000ull;
    Term _fv_2465[1];
    _fv_2465[0] = 13001ull;
    Term _fv_2466[1];
    _fv_2466[0] = 13002ull;
    Term _fv_2467[1];
    _fv_2467[0] = 13003ull;
    Term _fv_2468[1];
    _fv_2468[0] = 13004ull;
    Term _fv_2469[1];
    _fv_2469[0] = 13005ull;
    Term _fv_2470[1];
    _fv_2470[0] = 13006ull;
    Term _fv_2471[1];
    _fv_2471[0] = 13007ull;
    Term _fv_2472[1];
    _fv_2472[0] = 13008ull;
    Term _fv_2473[1];
    _fv_2473[0] = 13009ull;
    Term _fv_2474[1];
    _fv_2474[0] = 13010ull;
    Term _fv_2475[1];
    _fv_2475[0] = 13011ull;
    Term _fv_2476[1];
    _fv_2476[0] = 13012ull;
    Term _fv_2477[1];
    _fv_2477[0] = 13013ull;
    Term _fv_2478[1];
    _fv_2478[0] = 13014ull;
    Term _fv_2479[1];
    _fv_2479[0] = 13015ull;
    u32 _o_666 = 0;
    Term _o_667 = 0;
    Term _t_360 = 1;
    if (_t_360 == 0) {
      _o_666 = 0;
    } else {
      _o_666 = 1;
      u64 _nd_251 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_251 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2464), blk_new(e, 0, 0, 0, 1, _fv_2465)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2466), blk_new(e, 0, 0, 0, 1, _fv_2467))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2468), blk_new(e, 0, 0, 0, 1, _fv_2469)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2470), blk_new(e, 0, 0, 0, 1, _fv_2471)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2472), blk_new(e, 0, 0, 0, 1, _fv_2473)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2474), blk_new(e, 0, 0, 0, 1, _fv_2475))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2476), blk_new(e, 0, 0, 0, 1, _fv_2477)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2478), blk_new(e, 0, 0, 0, 1, _fv_2479))))));
      e.mem[_nd_251 + 1] = rfc_seal(e, 13ull);
      _o_667 = term_ctr(CID_OWNED, _nd_251);
    }
    Term _fv_2480[2];
    _fv_2480[0] = _o_666;
    _fv_2480[1] = _o_667;
    Term _fv_2481[1];
    _fv_2481[0] = 14000ull;
    Term _fv_2482[1];
    _fv_2482[0] = 14001ull;
    Term _fv_2483[1];
    _fv_2483[0] = 14002ull;
    Term _fv_2484[1];
    _fv_2484[0] = 14003ull;
    Term _fv_2485[1];
    _fv_2485[0] = 14004ull;
    Term _fv_2486[1];
    _fv_2486[0] = 14005ull;
    Term _fv_2487[1];
    _fv_2487[0] = 14006ull;
    Term _fv_2488[1];
    _fv_2488[0] = 14007ull;
    Term _fv_2489[1];
    _fv_2489[0] = 14008ull;
    Term _fv_2490[1];
    _fv_2490[0] = 14009ull;
    Term _fv_2491[1];
    _fv_2491[0] = 14010ull;
    Term _fv_2492[1];
    _fv_2492[0] = 14011ull;
    Term _fv_2493[1];
    _fv_2493[0] = 14012ull;
    Term _fv_2494[1];
    _fv_2494[0] = 14013ull;
    Term _fv_2495[1];
    _fv_2495[0] = 14014ull;
    Term _fv_2496[1];
    _fv_2496[0] = 14015ull;
    u32 _o_668 = 0;
    Term _o_669 = 0;
    Term _t_361 = 1;
    if (_t_361 == 0) {
      _o_668 = 0;
    } else {
      _o_668 = 1;
      u64 _nd_252 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_252 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2481), blk_new(e, 0, 0, 0, 1, _fv_2482)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2483), blk_new(e, 0, 0, 0, 1, _fv_2484))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2485), blk_new(e, 0, 0, 0, 1, _fv_2486)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2487), blk_new(e, 0, 0, 0, 1, _fv_2488)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2489), blk_new(e, 0, 0, 0, 1, _fv_2490)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2491), blk_new(e, 0, 0, 0, 1, _fv_2492))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2493), blk_new(e, 0, 0, 0, 1, _fv_2494)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2495), blk_new(e, 0, 0, 0, 1, _fv_2496))))));
      e.mem[_nd_252 + 1] = rfc_seal(e, 14ull);
      _o_669 = term_ctr(CID_OWNED, _nd_252);
    }
    Term _fv_2497[2];
    _fv_2497[0] = _o_668;
    _fv_2497[1] = _o_669;
    Term _fv_2498[1];
    _fv_2498[0] = 15000ull;
    Term _fv_2499[1];
    _fv_2499[0] = 15001ull;
    Term _fv_2500[1];
    _fv_2500[0] = 15002ull;
    Term _fv_2501[1];
    _fv_2501[0] = 15003ull;
    Term _fv_2502[1];
    _fv_2502[0] = 15004ull;
    Term _fv_2503[1];
    _fv_2503[0] = 15005ull;
    Term _fv_2504[1];
    _fv_2504[0] = 15006ull;
    Term _fv_2505[1];
    _fv_2505[0] = 15007ull;
    Term _fv_2506[1];
    _fv_2506[0] = 15008ull;
    Term _fv_2507[1];
    _fv_2507[0] = 15009ull;
    Term _fv_2508[1];
    _fv_2508[0] = 15010ull;
    Term _fv_2509[1];
    _fv_2509[0] = 15011ull;
    Term _fv_2510[1];
    _fv_2510[0] = 15012ull;
    Term _fv_2511[1];
    _fv_2511[0] = 15013ull;
    Term _fv_2512[1];
    _fv_2512[0] = 15014ull;
    Term _fv_2513[1];
    _fv_2513[0] = 15015ull;
    u32 _o_670 = 0;
    Term _o_671 = 0;
    Term _t_362 = 1;
    if (_t_362 == 0) {
      _o_670 = 0;
    } else {
      _o_670 = 1;
      u64 _nd_253 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_253 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2498), blk_new(e, 0, 0, 0, 1, _fv_2499)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2500), blk_new(e, 0, 0, 0, 1, _fv_2501))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2502), blk_new(e, 0, 0, 0, 1, _fv_2503)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2504), blk_new(e, 0, 0, 0, 1, _fv_2505)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2506), blk_new(e, 0, 0, 0, 1, _fv_2507)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2508), blk_new(e, 0, 0, 0, 1, _fv_2509))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2510), blk_new(e, 0, 0, 0, 1, _fv_2511)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2512), blk_new(e, 0, 0, 0, 1, _fv_2513))))));
      e.mem[_nd_253 + 1] = rfc_seal(e, 15ull);
      _o_671 = term_ctr(CID_OWNED, _nd_253);
    }
    Term _fv_2514[2];
    _fv_2514[0] = _o_670;
    _fv_2514[1] = _o_671;
    Term _fv_2515[1];
    _fv_2515[0] = 16000ull;
    Term _fv_2516[1];
    _fv_2516[0] = 16001ull;
    Term _fv_2517[1];
    _fv_2517[0] = 16002ull;
    Term _fv_2518[1];
    _fv_2518[0] = 16003ull;
    Term _fv_2519[1];
    _fv_2519[0] = 16004ull;
    Term _fv_2520[1];
    _fv_2520[0] = 16005ull;
    Term _fv_2521[1];
    _fv_2521[0] = 16006ull;
    Term _fv_2522[1];
    _fv_2522[0] = 16007ull;
    Term _fv_2523[1];
    _fv_2523[0] = 16008ull;
    Term _fv_2524[1];
    _fv_2524[0] = 16009ull;
    Term _fv_2525[1];
    _fv_2525[0] = 16010ull;
    Term _fv_2526[1];
    _fv_2526[0] = 16011ull;
    Term _fv_2527[1];
    _fv_2527[0] = 16012ull;
    Term _fv_2528[1];
    _fv_2528[0] = 16013ull;
    Term _fv_2529[1];
    _fv_2529[0] = 16014ull;
    Term _fv_2530[1];
    _fv_2530[0] = 16015ull;
    u32 _o_672 = 0;
    Term _o_673 = 0;
    Term _t_363 = 1;
    if (_t_363 == 0) {
      _o_672 = 0;
    } else {
      _o_672 = 1;
      u64 _nd_254 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_254 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2515), blk_new(e, 0, 0, 0, 1, _fv_2516)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2517), blk_new(e, 0, 0, 0, 1, _fv_2518))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2519), blk_new(e, 0, 0, 0, 1, _fv_2520)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2521), blk_new(e, 0, 0, 0, 1, _fv_2522)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2523), blk_new(e, 0, 0, 0, 1, _fv_2524)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2525), blk_new(e, 0, 0, 0, 1, _fv_2526))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2527), blk_new(e, 0, 0, 0, 1, _fv_2528)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2529), blk_new(e, 0, 0, 0, 1, _fv_2530))))));
      e.mem[_nd_254 + 1] = rfc_seal(e, 16ull);
      _o_673 = term_ctr(CID_OWNED, _nd_254);
    }
    Term _fv_2531[2];
    _fv_2531[0] = _o_672;
    _fv_2531[1] = _o_673;
    Term _fv_2532[1];
    _fv_2532[0] = 101000ull;
    Term _fv_2533[1];
    _fv_2533[0] = 101001ull;
    Term _fv_2534[1];
    _fv_2534[0] = 101002ull;
    Term _fv_2535[1];
    _fv_2535[0] = 101003ull;
    Term _fv_2536[1];
    _fv_2536[0] = 101004ull;
    Term _fv_2537[1];
    _fv_2537[0] = 101005ull;
    Term _fv_2538[1];
    _fv_2538[0] = 101006ull;
    Term _fv_2539[1];
    _fv_2539[0] = 101007ull;
    Term _fv_2540[1];
    _fv_2540[0] = 101008ull;
    Term _fv_2541[1];
    _fv_2541[0] = 101009ull;
    Term _fv_2542[1];
    _fv_2542[0] = 101010ull;
    Term _fv_2543[1];
    _fv_2543[0] = 101011ull;
    Term _fv_2544[1];
    _fv_2544[0] = 101012ull;
    Term _fv_2545[1];
    _fv_2545[0] = 101013ull;
    Term _fv_2546[1];
    _fv_2546[0] = 101014ull;
    Term _fv_2547[1];
    _fv_2547[0] = 101015ull;
    u32 _o_674 = 0;
    Term _o_675 = 0;
    Term _t_364 = 1;
    if (_t_364 == 0) {
      _o_674 = 0;
    } else {
      _o_674 = 1;
      u64 _nd_255 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_255 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2532), blk_new(e, 0, 0, 0, 1, _fv_2533)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2534), blk_new(e, 0, 0, 0, 1, _fv_2535))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2536), blk_new(e, 0, 0, 0, 1, _fv_2537)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2538), blk_new(e, 0, 0, 0, 1, _fv_2539)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2540), blk_new(e, 0, 0, 0, 1, _fv_2541)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2542), blk_new(e, 0, 0, 0, 1, _fv_2543))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2544), blk_new(e, 0, 0, 0, 1, _fv_2545)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2546), blk_new(e, 0, 0, 0, 1, _fv_2547))))));
      e.mem[_nd_255 + 1] = rfc_seal(e, 101ull);
      _o_675 = term_ctr(CID_OWNED, _nd_255);
    }
    Term _fv_2548[2];
    _fv_2548[0] = _o_674;
    _fv_2548[1] = _o_675;
    Term _fv_2549[1];
    _fv_2549[0] = 102000ull;
    Term _fv_2550[1];
    _fv_2550[0] = 102001ull;
    Term _fv_2551[1];
    _fv_2551[0] = 102002ull;
    Term _fv_2552[1];
    _fv_2552[0] = 102003ull;
    Term _fv_2553[1];
    _fv_2553[0] = 102004ull;
    Term _fv_2554[1];
    _fv_2554[0] = 102005ull;
    Term _fv_2555[1];
    _fv_2555[0] = 102006ull;
    Term _fv_2556[1];
    _fv_2556[0] = 102007ull;
    Term _fv_2557[1];
    _fv_2557[0] = 102008ull;
    Term _fv_2558[1];
    _fv_2558[0] = 102009ull;
    Term _fv_2559[1];
    _fv_2559[0] = 102010ull;
    Term _fv_2560[1];
    _fv_2560[0] = 102011ull;
    Term _fv_2561[1];
    _fv_2561[0] = 102012ull;
    Term _fv_2562[1];
    _fv_2562[0] = 102013ull;
    Term _fv_2563[1];
    _fv_2563[0] = 102014ull;
    Term _fv_2564[1];
    _fv_2564[0] = 102015ull;
    u32 _o_676 = 0;
    Term _o_677 = 0;
    Term _t_365 = 1;
    if (_t_365 == 0) {
      _o_676 = 0;
    } else {
      _o_676 = 1;
      u64 _nd_256 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_256 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2549), blk_new(e, 0, 0, 0, 1, _fv_2550)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2551), blk_new(e, 0, 0, 0, 1, _fv_2552))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2553), blk_new(e, 0, 0, 0, 1, _fv_2554)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2555), blk_new(e, 0, 0, 0, 1, _fv_2556)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2557), blk_new(e, 0, 0, 0, 1, _fv_2558)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2559), blk_new(e, 0, 0, 0, 1, _fv_2560))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2561), blk_new(e, 0, 0, 0, 1, _fv_2562)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2563), blk_new(e, 0, 0, 0, 1, _fv_2564))))));
      e.mem[_nd_256 + 1] = rfc_seal(e, 102ull);
      _o_677 = term_ctr(CID_OWNED, _nd_256);
    }
    Term _fv_2565[2];
    _fv_2565[0] = _o_676;
    _fv_2565[1] = _o_677;
    Term _fv_2566[1];
    _fv_2566[0] = 103000ull;
    Term _fv_2567[1];
    _fv_2567[0] = 103001ull;
    Term _fv_2568[1];
    _fv_2568[0] = 103002ull;
    Term _fv_2569[1];
    _fv_2569[0] = 103003ull;
    Term _fv_2570[1];
    _fv_2570[0] = 103004ull;
    Term _fv_2571[1];
    _fv_2571[0] = 103005ull;
    Term _fv_2572[1];
    _fv_2572[0] = 103006ull;
    Term _fv_2573[1];
    _fv_2573[0] = 103007ull;
    Term _fv_2574[1];
    _fv_2574[0] = 103008ull;
    Term _fv_2575[1];
    _fv_2575[0] = 103009ull;
    Term _fv_2576[1];
    _fv_2576[0] = 103010ull;
    Term _fv_2577[1];
    _fv_2577[0] = 103011ull;
    Term _fv_2578[1];
    _fv_2578[0] = 103012ull;
    Term _fv_2579[1];
    _fv_2579[0] = 103013ull;
    Term _fv_2580[1];
    _fv_2580[0] = 103014ull;
    Term _fv_2581[1];
    _fv_2581[0] = 103015ull;
    u32 _o_678 = 0;
    Term _o_679 = 0;
    Term _t_366 = 1;
    if (_t_366 == 0) {
      _o_678 = 0;
    } else {
      _o_678 = 1;
      u64 _nd_257 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_257 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2566), blk_new(e, 0, 0, 0, 1, _fv_2567)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2568), blk_new(e, 0, 0, 0, 1, _fv_2569))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2570), blk_new(e, 0, 0, 0, 1, _fv_2571)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2572), blk_new(e, 0, 0, 0, 1, _fv_2573)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2574), blk_new(e, 0, 0, 0, 1, _fv_2575)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2576), blk_new(e, 0, 0, 0, 1, _fv_2577))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2578), blk_new(e, 0, 0, 0, 1, _fv_2579)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2580), blk_new(e, 0, 0, 0, 1, _fv_2581))))));
      e.mem[_nd_257 + 1] = rfc_seal(e, 103ull);
      _o_679 = term_ctr(CID_OWNED, _nd_257);
    }
    Term _fv_2582[2];
    _fv_2582[0] = _o_678;
    _fv_2582[1] = _o_679;
    Term _fv_2583[1];
    _fv_2583[0] = 104000ull;
    Term _fv_2584[1];
    _fv_2584[0] = 104001ull;
    Term _fv_2585[1];
    _fv_2585[0] = 104002ull;
    Term _fv_2586[1];
    _fv_2586[0] = 104003ull;
    Term _fv_2587[1];
    _fv_2587[0] = 104004ull;
    Term _fv_2588[1];
    _fv_2588[0] = 104005ull;
    Term _fv_2589[1];
    _fv_2589[0] = 104006ull;
    Term _fv_2590[1];
    _fv_2590[0] = 104007ull;
    Term _fv_2591[1];
    _fv_2591[0] = 104008ull;
    Term _fv_2592[1];
    _fv_2592[0] = 104009ull;
    Term _fv_2593[1];
    _fv_2593[0] = 104010ull;
    Term _fv_2594[1];
    _fv_2594[0] = 104011ull;
    Term _fv_2595[1];
    _fv_2595[0] = 104012ull;
    Term _fv_2596[1];
    _fv_2596[0] = 104013ull;
    Term _fv_2597[1];
    _fv_2597[0] = 104014ull;
    Term _fv_2598[1];
    _fv_2598[0] = 104015ull;
    u32 _o_680 = 0;
    Term _o_681 = 0;
    Term _t_367 = 1;
    if (_t_367 == 0) {
      _o_680 = 0;
    } else {
      _o_680 = 1;
      u64 _nd_258 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_258 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2583), blk_new(e, 0, 0, 0, 1, _fv_2584)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2585), blk_new(e, 0, 0, 0, 1, _fv_2586))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2587), blk_new(e, 0, 0, 0, 1, _fv_2588)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2589), blk_new(e, 0, 0, 0, 1, _fv_2590)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2591), blk_new(e, 0, 0, 0, 1, _fv_2592)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2593), blk_new(e, 0, 0, 0, 1, _fv_2594))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2595), blk_new(e, 0, 0, 0, 1, _fv_2596)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2597), blk_new(e, 0, 0, 0, 1, _fv_2598))))));
      e.mem[_nd_258 + 1] = rfc_seal(e, 104ull);
      _o_681 = term_ctr(CID_OWNED, _nd_258);
    }
    Term _fv_2599[2];
    _fv_2599[0] = _o_680;
    _fv_2599[1] = _o_681;
    Term _fv_2600[1];
    _fv_2600[0] = 105000ull;
    Term _fv_2601[1];
    _fv_2601[0] = 105001ull;
    Term _fv_2602[1];
    _fv_2602[0] = 105002ull;
    Term _fv_2603[1];
    _fv_2603[0] = 105003ull;
    Term _fv_2604[1];
    _fv_2604[0] = 105004ull;
    Term _fv_2605[1];
    _fv_2605[0] = 105005ull;
    Term _fv_2606[1];
    _fv_2606[0] = 105006ull;
    Term _fv_2607[1];
    _fv_2607[0] = 105007ull;
    Term _fv_2608[1];
    _fv_2608[0] = 105008ull;
    Term _fv_2609[1];
    _fv_2609[0] = 105009ull;
    Term _fv_2610[1];
    _fv_2610[0] = 105010ull;
    Term _fv_2611[1];
    _fv_2611[0] = 105011ull;
    Term _fv_2612[1];
    _fv_2612[0] = 105012ull;
    Term _fv_2613[1];
    _fv_2613[0] = 105013ull;
    Term _fv_2614[1];
    _fv_2614[0] = 105014ull;
    Term _fv_2615[1];
    _fv_2615[0] = 105015ull;
    u32 _o_682 = 0;
    Term _o_683 = 0;
    Term _t_368 = 1;
    if (_t_368 == 0) {
      _o_682 = 0;
    } else {
      _o_682 = 1;
      u64 _nd_259 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_259 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2600), blk_new(e, 0, 0, 0, 1, _fv_2601)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2602), blk_new(e, 0, 0, 0, 1, _fv_2603))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2604), blk_new(e, 0, 0, 0, 1, _fv_2605)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2606), blk_new(e, 0, 0, 0, 1, _fv_2607)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2608), blk_new(e, 0, 0, 0, 1, _fv_2609)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2610), blk_new(e, 0, 0, 0, 1, _fv_2611))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2612), blk_new(e, 0, 0, 0, 1, _fv_2613)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2614), blk_new(e, 0, 0, 0, 1, _fv_2615))))));
      e.mem[_nd_259 + 1] = rfc_seal(e, 105ull);
      _o_683 = term_ctr(CID_OWNED, _nd_259);
    }
    Term _fv_2616[2];
    _fv_2616[0] = _o_682;
    _fv_2616[1] = _o_683;
    Term _fv_2617[1];
    _fv_2617[0] = 106000ull;
    Term _fv_2618[1];
    _fv_2618[0] = 106001ull;
    Term _fv_2619[1];
    _fv_2619[0] = 106002ull;
    Term _fv_2620[1];
    _fv_2620[0] = 106003ull;
    Term _fv_2621[1];
    _fv_2621[0] = 106004ull;
    Term _fv_2622[1];
    _fv_2622[0] = 106005ull;
    Term _fv_2623[1];
    _fv_2623[0] = 106006ull;
    Term _fv_2624[1];
    _fv_2624[0] = 106007ull;
    Term _fv_2625[1];
    _fv_2625[0] = 106008ull;
    Term _fv_2626[1];
    _fv_2626[0] = 106009ull;
    Term _fv_2627[1];
    _fv_2627[0] = 106010ull;
    Term _fv_2628[1];
    _fv_2628[0] = 106011ull;
    Term _fv_2629[1];
    _fv_2629[0] = 106012ull;
    Term _fv_2630[1];
    _fv_2630[0] = 106013ull;
    Term _fv_2631[1];
    _fv_2631[0] = 106014ull;
    Term _fv_2632[1];
    _fv_2632[0] = 106015ull;
    u32 _o_684 = 0;
    Term _o_685 = 0;
    Term _t_369 = 1;
    if (_t_369 == 0) {
      _o_684 = 0;
    } else {
      _o_684 = 1;
      u64 _nd_260 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_260 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2617), blk_new(e, 0, 0, 0, 1, _fv_2618)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2619), blk_new(e, 0, 0, 0, 1, _fv_2620))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2621), blk_new(e, 0, 0, 0, 1, _fv_2622)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2623), blk_new(e, 0, 0, 0, 1, _fv_2624)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2625), blk_new(e, 0, 0, 0, 1, _fv_2626)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2627), blk_new(e, 0, 0, 0, 1, _fv_2628))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2629), blk_new(e, 0, 0, 0, 1, _fv_2630)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2631), blk_new(e, 0, 0, 0, 1, _fv_2632))))));
      e.mem[_nd_260 + 1] = rfc_seal(e, 106ull);
      _o_685 = term_ctr(CID_OWNED, _nd_260);
    }
    Term _fv_2633[2];
    _fv_2633[0] = _o_684;
    _fv_2633[1] = _o_685;
    Term _fv_2634[1];
    _fv_2634[0] = 107000ull;
    Term _fv_2635[1];
    _fv_2635[0] = 107001ull;
    Term _fv_2636[1];
    _fv_2636[0] = 107002ull;
    Term _fv_2637[1];
    _fv_2637[0] = 107003ull;
    Term _fv_2638[1];
    _fv_2638[0] = 107004ull;
    Term _fv_2639[1];
    _fv_2639[0] = 107005ull;
    Term _fv_2640[1];
    _fv_2640[0] = 107006ull;
    Term _fv_2641[1];
    _fv_2641[0] = 107007ull;
    Term _fv_2642[1];
    _fv_2642[0] = 107008ull;
    Term _fv_2643[1];
    _fv_2643[0] = 107009ull;
    Term _fv_2644[1];
    _fv_2644[0] = 107010ull;
    Term _fv_2645[1];
    _fv_2645[0] = 107011ull;
    Term _fv_2646[1];
    _fv_2646[0] = 107012ull;
    Term _fv_2647[1];
    _fv_2647[0] = 107013ull;
    Term _fv_2648[1];
    _fv_2648[0] = 107014ull;
    Term _fv_2649[1];
    _fv_2649[0] = 107015ull;
    u32 _o_686 = 0;
    Term _o_687 = 0;
    Term _t_370 = 1;
    if (_t_370 == 0) {
      _o_686 = 0;
    } else {
      _o_686 = 1;
      u64 _nd_261 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_261 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2634), blk_new(e, 0, 0, 0, 1, _fv_2635)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2636), blk_new(e, 0, 0, 0, 1, _fv_2637))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2638), blk_new(e, 0, 0, 0, 1, _fv_2639)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2640), blk_new(e, 0, 0, 0, 1, _fv_2641)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2642), blk_new(e, 0, 0, 0, 1, _fv_2643)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2644), blk_new(e, 0, 0, 0, 1, _fv_2645))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2646), blk_new(e, 0, 0, 0, 1, _fv_2647)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2648), blk_new(e, 0, 0, 0, 1, _fv_2649))))));
      e.mem[_nd_261 + 1] = rfc_seal(e, 107ull);
      _o_687 = term_ctr(CID_OWNED, _nd_261);
    }
    Term _fv_2650[2];
    _fv_2650[0] = _o_686;
    _fv_2650[1] = _o_687;
    Term _fv_2651[1];
    _fv_2651[0] = 108000ull;
    Term _fv_2652[1];
    _fv_2652[0] = 108001ull;
    Term _fv_2653[1];
    _fv_2653[0] = 108002ull;
    Term _fv_2654[1];
    _fv_2654[0] = 108003ull;
    Term _fv_2655[1];
    _fv_2655[0] = 108004ull;
    Term _fv_2656[1];
    _fv_2656[0] = 108005ull;
    Term _fv_2657[1];
    _fv_2657[0] = 108006ull;
    Term _fv_2658[1];
    _fv_2658[0] = 108007ull;
    Term _fv_2659[1];
    _fv_2659[0] = 108008ull;
    Term _fv_2660[1];
    _fv_2660[0] = 108009ull;
    Term _fv_2661[1];
    _fv_2661[0] = 108010ull;
    Term _fv_2662[1];
    _fv_2662[0] = 108011ull;
    Term _fv_2663[1];
    _fv_2663[0] = 108012ull;
    Term _fv_2664[1];
    _fv_2664[0] = 108013ull;
    Term _fv_2665[1];
    _fv_2665[0] = 108014ull;
    Term _fv_2666[1];
    _fv_2666[0] = 108015ull;
    u32 _o_688 = 0;
    Term _o_689 = 0;
    Term _t_371 = 1;
    if (_t_371 == 0) {
      _o_688 = 0;
    } else {
      _o_688 = 1;
      u64 _nd_262 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_262 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2651), blk_new(e, 0, 0, 0, 1, _fv_2652)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2653), blk_new(e, 0, 0, 0, 1, _fv_2654))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2655), blk_new(e, 0, 0, 0, 1, _fv_2656)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2657), blk_new(e, 0, 0, 0, 1, _fv_2658)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2659), blk_new(e, 0, 0, 0, 1, _fv_2660)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2661), blk_new(e, 0, 0, 0, 1, _fv_2662))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2663), blk_new(e, 0, 0, 0, 1, _fv_2664)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2665), blk_new(e, 0, 0, 0, 1, _fv_2666))))));
      e.mem[_nd_262 + 1] = rfc_seal(e, 108ull);
      _o_689 = term_ctr(CID_OWNED, _nd_262);
    }
    Term _fv_2667[2];
    _fv_2667[0] = _o_688;
    _fv_2667[1] = _o_689;
    Term _fv_2668[1];
    _fv_2668[0] = 109000ull;
    Term _fv_2669[1];
    _fv_2669[0] = 109001ull;
    Term _fv_2670[1];
    _fv_2670[0] = 109002ull;
    Term _fv_2671[1];
    _fv_2671[0] = 109003ull;
    Term _fv_2672[1];
    _fv_2672[0] = 109004ull;
    Term _fv_2673[1];
    _fv_2673[0] = 109005ull;
    Term _fv_2674[1];
    _fv_2674[0] = 109006ull;
    Term _fv_2675[1];
    _fv_2675[0] = 109007ull;
    Term _fv_2676[1];
    _fv_2676[0] = 109008ull;
    Term _fv_2677[1];
    _fv_2677[0] = 109009ull;
    Term _fv_2678[1];
    _fv_2678[0] = 109010ull;
    Term _fv_2679[1];
    _fv_2679[0] = 109011ull;
    Term _fv_2680[1];
    _fv_2680[0] = 109012ull;
    Term _fv_2681[1];
    _fv_2681[0] = 109013ull;
    Term _fv_2682[1];
    _fv_2682[0] = 109014ull;
    Term _fv_2683[1];
    _fv_2683[0] = 109015ull;
    u32 _o_690 = 0;
    Term _o_691 = 0;
    Term _t_372 = 1;
    if (_t_372 == 0) {
      _o_690 = 0;
    } else {
      _o_690 = 1;
      u64 _nd_263 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_263 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2668), blk_new(e, 0, 0, 0, 1, _fv_2669)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2670), blk_new(e, 0, 0, 0, 1, _fv_2671))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2672), blk_new(e, 0, 0, 0, 1, _fv_2673)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2674), blk_new(e, 0, 0, 0, 1, _fv_2675)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2676), blk_new(e, 0, 0, 0, 1, _fv_2677)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2678), blk_new(e, 0, 0, 0, 1, _fv_2679))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2680), blk_new(e, 0, 0, 0, 1, _fv_2681)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2682), blk_new(e, 0, 0, 0, 1, _fv_2683))))));
      e.mem[_nd_263 + 1] = rfc_seal(e, 109ull);
      _o_691 = term_ctr(CID_OWNED, _nd_263);
    }
    Term _fv_2684[2];
    _fv_2684[0] = _o_690;
    _fv_2684[1] = _o_691;
    Term _fv_2685[1];
    _fv_2685[0] = 110000ull;
    Term _fv_2686[1];
    _fv_2686[0] = 110001ull;
    Term _fv_2687[1];
    _fv_2687[0] = 110002ull;
    Term _fv_2688[1];
    _fv_2688[0] = 110003ull;
    Term _fv_2689[1];
    _fv_2689[0] = 110004ull;
    Term _fv_2690[1];
    _fv_2690[0] = 110005ull;
    Term _fv_2691[1];
    _fv_2691[0] = 110006ull;
    Term _fv_2692[1];
    _fv_2692[0] = 110007ull;
    Term _fv_2693[1];
    _fv_2693[0] = 110008ull;
    Term _fv_2694[1];
    _fv_2694[0] = 110009ull;
    Term _fv_2695[1];
    _fv_2695[0] = 110010ull;
    Term _fv_2696[1];
    _fv_2696[0] = 110011ull;
    Term _fv_2697[1];
    _fv_2697[0] = 110012ull;
    Term _fv_2698[1];
    _fv_2698[0] = 110013ull;
    Term _fv_2699[1];
    _fv_2699[0] = 110014ull;
    Term _fv_2700[1];
    _fv_2700[0] = 110015ull;
    u32 _o_692 = 0;
    Term _o_693 = 0;
    Term _t_373 = 1;
    if (_t_373 == 0) {
      _o_692 = 0;
    } else {
      _o_692 = 1;
      u64 _nd_264 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_264 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2685), blk_new(e, 0, 0, 0, 1, _fv_2686)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2687), blk_new(e, 0, 0, 0, 1, _fv_2688))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2689), blk_new(e, 0, 0, 0, 1, _fv_2690)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2691), blk_new(e, 0, 0, 0, 1, _fv_2692)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2693), blk_new(e, 0, 0, 0, 1, _fv_2694)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2695), blk_new(e, 0, 0, 0, 1, _fv_2696))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2697), blk_new(e, 0, 0, 0, 1, _fv_2698)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2699), blk_new(e, 0, 0, 0, 1, _fv_2700))))));
      e.mem[_nd_264 + 1] = rfc_seal(e, 110ull);
      _o_693 = term_ctr(CID_OWNED, _nd_264);
    }
    Term _fv_2701[2];
    _fv_2701[0] = _o_692;
    _fv_2701[1] = _o_693;
    Term _fv_2702[1];
    _fv_2702[0] = 111000ull;
    Term _fv_2703[1];
    _fv_2703[0] = 111001ull;
    Term _fv_2704[1];
    _fv_2704[0] = 111002ull;
    Term _fv_2705[1];
    _fv_2705[0] = 111003ull;
    Term _fv_2706[1];
    _fv_2706[0] = 111004ull;
    Term _fv_2707[1];
    _fv_2707[0] = 111005ull;
    Term _fv_2708[1];
    _fv_2708[0] = 111006ull;
    Term _fv_2709[1];
    _fv_2709[0] = 111007ull;
    Term _fv_2710[1];
    _fv_2710[0] = 111008ull;
    Term _fv_2711[1];
    _fv_2711[0] = 111009ull;
    Term _fv_2712[1];
    _fv_2712[0] = 111010ull;
    Term _fv_2713[1];
    _fv_2713[0] = 111011ull;
    Term _fv_2714[1];
    _fv_2714[0] = 111012ull;
    Term _fv_2715[1];
    _fv_2715[0] = 111013ull;
    Term _fv_2716[1];
    _fv_2716[0] = 111014ull;
    Term _fv_2717[1];
    _fv_2717[0] = 111015ull;
    u32 _o_694 = 0;
    Term _o_695 = 0;
    Term _t_374 = 1;
    if (_t_374 == 0) {
      _o_694 = 0;
    } else {
      _o_694 = 1;
      u64 _nd_265 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_265 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2702), blk_new(e, 0, 0, 0, 1, _fv_2703)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2704), blk_new(e, 0, 0, 0, 1, _fv_2705))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2706), blk_new(e, 0, 0, 0, 1, _fv_2707)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2708), blk_new(e, 0, 0, 0, 1, _fv_2709)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2710), blk_new(e, 0, 0, 0, 1, _fv_2711)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2712), blk_new(e, 0, 0, 0, 1, _fv_2713))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2714), blk_new(e, 0, 0, 0, 1, _fv_2715)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2716), blk_new(e, 0, 0, 0, 1, _fv_2717))))));
      e.mem[_nd_265 + 1] = rfc_seal(e, 111ull);
      _o_695 = term_ctr(CID_OWNED, _nd_265);
    }
    Term _fv_2718[2];
    _fv_2718[0] = _o_694;
    _fv_2718[1] = _o_695;
    Term _fv_2719[1];
    _fv_2719[0] = 112000ull;
    Term _fv_2720[1];
    _fv_2720[0] = 112001ull;
    Term _fv_2721[1];
    _fv_2721[0] = 112002ull;
    Term _fv_2722[1];
    _fv_2722[0] = 112003ull;
    Term _fv_2723[1];
    _fv_2723[0] = 112004ull;
    Term _fv_2724[1];
    _fv_2724[0] = 112005ull;
    Term _fv_2725[1];
    _fv_2725[0] = 112006ull;
    Term _fv_2726[1];
    _fv_2726[0] = 112007ull;
    Term _fv_2727[1];
    _fv_2727[0] = 112008ull;
    Term _fv_2728[1];
    _fv_2728[0] = 112009ull;
    Term _fv_2729[1];
    _fv_2729[0] = 112010ull;
    Term _fv_2730[1];
    _fv_2730[0] = 112011ull;
    Term _fv_2731[1];
    _fv_2731[0] = 112012ull;
    Term _fv_2732[1];
    _fv_2732[0] = 112013ull;
    Term _fv_2733[1];
    _fv_2733[0] = 112014ull;
    Term _fv_2734[1];
    _fv_2734[0] = 112015ull;
    u32 _o_696 = 0;
    Term _o_697 = 0;
    Term _t_375 = 1;
    if (_t_375 == 0) {
      _o_696 = 0;
    } else {
      _o_696 = 1;
      u64 _nd_266 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_266 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2719), blk_new(e, 0, 0, 0, 1, _fv_2720)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2721), blk_new(e, 0, 0, 0, 1, _fv_2722))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2723), blk_new(e, 0, 0, 0, 1, _fv_2724)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2725), blk_new(e, 0, 0, 0, 1, _fv_2726)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2727), blk_new(e, 0, 0, 0, 1, _fv_2728)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2729), blk_new(e, 0, 0, 0, 1, _fv_2730))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2731), blk_new(e, 0, 0, 0, 1, _fv_2732)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2733), blk_new(e, 0, 0, 0, 1, _fv_2734))))));
      e.mem[_nd_266 + 1] = rfc_seal(e, 112ull);
      _o_697 = term_ctr(CID_OWNED, _nd_266);
    }
    Term _fv_2735[2];
    _fv_2735[0] = _o_696;
    _fv_2735[1] = _o_697;
    Term _fv_2736[1];
    _fv_2736[0] = 113000ull;
    Term _fv_2737[1];
    _fv_2737[0] = 113001ull;
    Term _fv_2738[1];
    _fv_2738[0] = 113002ull;
    Term _fv_2739[1];
    _fv_2739[0] = 113003ull;
    Term _fv_2740[1];
    _fv_2740[0] = 113004ull;
    Term _fv_2741[1];
    _fv_2741[0] = 113005ull;
    Term _fv_2742[1];
    _fv_2742[0] = 113006ull;
    Term _fv_2743[1];
    _fv_2743[0] = 113007ull;
    Term _fv_2744[1];
    _fv_2744[0] = 113008ull;
    Term _fv_2745[1];
    _fv_2745[0] = 113009ull;
    Term _fv_2746[1];
    _fv_2746[0] = 113010ull;
    Term _fv_2747[1];
    _fv_2747[0] = 113011ull;
    Term _fv_2748[1];
    _fv_2748[0] = 113012ull;
    Term _fv_2749[1];
    _fv_2749[0] = 113013ull;
    Term _fv_2750[1];
    _fv_2750[0] = 113014ull;
    Term _fv_2751[1];
    _fv_2751[0] = 113015ull;
    u32 _o_698 = 0;
    Term _o_699 = 0;
    Term _t_376 = 1;
    if (_t_376 == 0) {
      _o_698 = 0;
    } else {
      _o_698 = 1;
      u64 _nd_267 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_267 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2736), blk_new(e, 0, 0, 0, 1, _fv_2737)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2738), blk_new(e, 0, 0, 0, 1, _fv_2739))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2740), blk_new(e, 0, 0, 0, 1, _fv_2741)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2742), blk_new(e, 0, 0, 0, 1, _fv_2743)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2744), blk_new(e, 0, 0, 0, 1, _fv_2745)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2746), blk_new(e, 0, 0, 0, 1, _fv_2747))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2748), blk_new(e, 0, 0, 0, 1, _fv_2749)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2750), blk_new(e, 0, 0, 0, 1, _fv_2751))))));
      e.mem[_nd_267 + 1] = rfc_seal(e, 113ull);
      _o_699 = term_ctr(CID_OWNED, _nd_267);
    }
    Term _fv_2752[2];
    _fv_2752[0] = _o_698;
    _fv_2752[1] = _o_699;
    Term _fv_2753[1];
    _fv_2753[0] = 114000ull;
    Term _fv_2754[1];
    _fv_2754[0] = 114001ull;
    Term _fv_2755[1];
    _fv_2755[0] = 114002ull;
    Term _fv_2756[1];
    _fv_2756[0] = 114003ull;
    Term _fv_2757[1];
    _fv_2757[0] = 114004ull;
    Term _fv_2758[1];
    _fv_2758[0] = 114005ull;
    Term _fv_2759[1];
    _fv_2759[0] = 114006ull;
    Term _fv_2760[1];
    _fv_2760[0] = 114007ull;
    Term _fv_2761[1];
    _fv_2761[0] = 114008ull;
    Term _fv_2762[1];
    _fv_2762[0] = 114009ull;
    Term _fv_2763[1];
    _fv_2763[0] = 114010ull;
    Term _fv_2764[1];
    _fv_2764[0] = 114011ull;
    Term _fv_2765[1];
    _fv_2765[0] = 114012ull;
    Term _fv_2766[1];
    _fv_2766[0] = 114013ull;
    Term _fv_2767[1];
    _fv_2767[0] = 114014ull;
    Term _fv_2768[1];
    _fv_2768[0] = 114015ull;
    u32 _o_700 = 0;
    Term _o_701 = 0;
    Term _t_377 = 1;
    if (_t_377 == 0) {
      _o_700 = 0;
    } else {
      _o_700 = 1;
      u64 _nd_268 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_268 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2753), blk_new(e, 0, 0, 0, 1, _fv_2754)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2755), blk_new(e, 0, 0, 0, 1, _fv_2756))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2757), blk_new(e, 0, 0, 0, 1, _fv_2758)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2759), blk_new(e, 0, 0, 0, 1, _fv_2760)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2761), blk_new(e, 0, 0, 0, 1, _fv_2762)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2763), blk_new(e, 0, 0, 0, 1, _fv_2764))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2765), blk_new(e, 0, 0, 0, 1, _fv_2766)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2767), blk_new(e, 0, 0, 0, 1, _fv_2768))))));
      e.mem[_nd_268 + 1] = rfc_seal(e, 114ull);
      _o_701 = term_ctr(CID_OWNED, _nd_268);
    }
    Term _fv_2769[2];
    _fv_2769[0] = _o_700;
    _fv_2769[1] = _o_701;
    Term _fv_2770[1];
    _fv_2770[0] = 115000ull;
    Term _fv_2771[1];
    _fv_2771[0] = 115001ull;
    Term _fv_2772[1];
    _fv_2772[0] = 115002ull;
    Term _fv_2773[1];
    _fv_2773[0] = 115003ull;
    Term _fv_2774[1];
    _fv_2774[0] = 115004ull;
    Term _fv_2775[1];
    _fv_2775[0] = 115005ull;
    Term _fv_2776[1];
    _fv_2776[0] = 115006ull;
    Term _fv_2777[1];
    _fv_2777[0] = 115007ull;
    Term _fv_2778[1];
    _fv_2778[0] = 115008ull;
    Term _fv_2779[1];
    _fv_2779[0] = 115009ull;
    Term _fv_2780[1];
    _fv_2780[0] = 115010ull;
    Term _fv_2781[1];
    _fv_2781[0] = 115011ull;
    Term _fv_2782[1];
    _fv_2782[0] = 115012ull;
    Term _fv_2783[1];
    _fv_2783[0] = 115013ull;
    Term _fv_2784[1];
    _fv_2784[0] = 115014ull;
    Term _fv_2785[1];
    _fv_2785[0] = 115015ull;
    u32 _o_702 = 0;
    Term _o_703 = 0;
    Term _t_378 = 1;
    if (_t_378 == 0) {
      _o_702 = 0;
    } else {
      _o_702 = 1;
      u64 _nd_269 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_269 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2770), blk_new(e, 0, 0, 0, 1, _fv_2771)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2772), blk_new(e, 0, 0, 0, 1, _fv_2773))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2774), blk_new(e, 0, 0, 0, 1, _fv_2775)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2776), blk_new(e, 0, 0, 0, 1, _fv_2777)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2778), blk_new(e, 0, 0, 0, 1, _fv_2779)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2780), blk_new(e, 0, 0, 0, 1, _fv_2781))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2782), blk_new(e, 0, 0, 0, 1, _fv_2783)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2784), blk_new(e, 0, 0, 0, 1, _fv_2785))))));
      e.mem[_nd_269 + 1] = rfc_seal(e, 115ull);
      _o_703 = term_ctr(CID_OWNED, _nd_269);
    }
    Term _fv_2786[2];
    _fv_2786[0] = _o_702;
    _fv_2786[1] = _o_703;
    Term _fv_2787[1];
    _fv_2787[0] = 116000ull;
    Term _fv_2788[1];
    _fv_2788[0] = 116001ull;
    Term _fv_2789[1];
    _fv_2789[0] = 116002ull;
    Term _fv_2790[1];
    _fv_2790[0] = 116003ull;
    Term _fv_2791[1];
    _fv_2791[0] = 116004ull;
    Term _fv_2792[1];
    _fv_2792[0] = 116005ull;
    Term _fv_2793[1];
    _fv_2793[0] = 116006ull;
    Term _fv_2794[1];
    _fv_2794[0] = 116007ull;
    Term _fv_2795[1];
    _fv_2795[0] = 116008ull;
    Term _fv_2796[1];
    _fv_2796[0] = 116009ull;
    Term _fv_2797[1];
    _fv_2797[0] = 116010ull;
    Term _fv_2798[1];
    _fv_2798[0] = 116011ull;
    Term _fv_2799[1];
    _fv_2799[0] = 116012ull;
    Term _fv_2800[1];
    _fv_2800[0] = 116013ull;
    Term _fv_2801[1];
    _fv_2801[0] = 116014ull;
    Term _fv_2802[1];
    _fv_2802[0] = 116015ull;
    u32 _o_704 = 0;
    Term _o_705 = 0;
    Term _t_379 = 1;
    if (_t_379 == 0) {
      _o_704 = 0;
    } else {
      _o_704 = 1;
      u64 _nd_270 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_270 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2787), blk_new(e, 0, 0, 0, 1, _fv_2788)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2789), blk_new(e, 0, 0, 0, 1, _fv_2790))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2791), blk_new(e, 0, 0, 0, 1, _fv_2792)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2793), blk_new(e, 0, 0, 0, 1, _fv_2794)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2795), blk_new(e, 0, 0, 0, 1, _fv_2796)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2797), blk_new(e, 0, 0, 0, 1, _fv_2798))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2799), blk_new(e, 0, 0, 0, 1, _fv_2800)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2801), blk_new(e, 0, 0, 0, 1, _fv_2802))))));
      e.mem[_nd_270 + 1] = rfc_seal(e, 116ull);
      _o_705 = term_ctr(CID_OWNED, _nd_270);
    }
    Term _fv_2803[2];
    _fv_2803[0] = _o_704;
    _fv_2803[1] = _o_705;
    Term _fv_2804[1];
    _fv_2804[0] = 1;
    Term _fv_2805[1];
    _fv_2805[0] = 1;
    Term _fv_2806[1];
    _fv_2806[0] = 0;
    Term _fv_2807[1];
    _fv_2807[0] = 1;
    Term _fv_2808[1];
    _fv_2808[0] = 1;
    Term _fv_2809[1];
    _fv_2809[0] = 1;
    Term _fv_2810[1];
    _fv_2810[0] = 1;
    Term _fv_2811[1];
    _fv_2811[0] = 1;
    Term _fv_2812[1];
    _fv_2812[0] = 1;
    Term _fv_2813[1];
    _fv_2813[0] = 1;
    Term _fv_2814[1];
    _fv_2814[0] = 1;
    Term _fv_2815[1];
    _fv_2815[0] = 1;
    Term _fv_2816[1];
    _fv_2816[0] = 1;
    Term _fv_2817[1];
    _fv_2817[0] = 1;
    Term _fv_2818[1];
    _fv_2818[0] = 1;
    Term _fv_2819[1];
    _fv_2819[0] = 1;
    u32 _o_706 = 0;
    Term _o_707 = 0;
    Term _t_380 = 1;
    if (_t_380 == 0) {
      _o_706 = 0;
    } else {
      _o_706 = 1;
      _o_707 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2820[2];
    _fv_2820[0] = _o_706;
    _fv_2820[1] = _o_707;
    u32 _o_708 = 0;
    Term _o_709 = 0;
    Term _t_381 = 0;
    if (_t_381 == 0) {
      _o_708 = 0;
    } else {
      _o_708 = 1;
      _o_709 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2821[2];
    _fv_2821[0] = _o_708;
    _fv_2821[1] = _o_709;
    u32 _o_710 = 0;
    Term _o_711 = 0;
    Term _t_382 = 1;
    if (_t_382 == 0) {
      _o_710 = 0;
    } else {
      _o_710 = 1;
      _o_711 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2822[2];
    _fv_2822[0] = _o_710;
    _fv_2822[1] = _o_711;
    u32 _o_712 = 0;
    Term _o_713 = 0;
    Term _t_383 = 0;
    if (_t_383 == 0) {
      _o_712 = 0;
    } else {
      _o_712 = 1;
      _o_713 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2823[2];
    _fv_2823[0] = _o_712;
    _fv_2823[1] = _o_713;
    u32 _o_714 = 0;
    Term _o_715 = 0;
    Term _t_384 = 1;
    if (_t_384 == 0) {
      _o_714 = 0;
    } else {
      _o_714 = 1;
      _o_715 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2824[2];
    _fv_2824[0] = _o_714;
    _fv_2824[1] = _o_715;
    u32 _o_716 = 0;
    Term _o_717 = 0;
    Term _t_385 = 0;
    if (_t_385 == 0) {
      _o_716 = 0;
    } else {
      _o_716 = 1;
      _o_717 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2825[2];
    _fv_2825[0] = _o_716;
    _fv_2825[1] = _o_717;
    u32 _o_718 = 0;
    Term _o_719 = 0;
    Term _t_386 = 1;
    if (_t_386 == 0) {
      _o_718 = 0;
    } else {
      _o_718 = 1;
      _o_719 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2826[2];
    _fv_2826[0] = _o_718;
    _fv_2826[1] = _o_719;
    u32 _o_720 = 0;
    Term _o_721 = 0;
    Term _t_387 = 0;
    if (_t_387 == 0) {
      _o_720 = 0;
    } else {
      _o_720 = 1;
      _o_721 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2827[2];
    _fv_2827[0] = _o_720;
    _fv_2827[1] = _o_721;
    u32 _o_722 = 0;
    Term _o_723 = 0;
    Term _t_388 = 1;
    if (_t_388 == 0) {
      _o_722 = 0;
    } else {
      _o_722 = 1;
      _o_723 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2828[2];
    _fv_2828[0] = _o_722;
    _fv_2828[1] = _o_723;
    u32 _o_724 = 0;
    Term _o_725 = 0;
    Term _t_389 = 0;
    if (_t_389 == 0) {
      _o_724 = 0;
    } else {
      _o_724 = 1;
      _o_725 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2829[2];
    _fv_2829[0] = _o_724;
    _fv_2829[1] = _o_725;
    u32 _o_726 = 0;
    Term _o_727 = 0;
    Term _t_390 = 1;
    if (_t_390 == 0) {
      _o_726 = 0;
    } else {
      _o_726 = 1;
      _o_727 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2830[2];
    _fv_2830[0] = _o_726;
    _fv_2830[1] = _o_727;
    u32 _o_728 = 0;
    Term _o_729 = 0;
    Term _t_391 = 0;
    if (_t_391 == 0) {
      _o_728 = 0;
    } else {
      _o_728 = 1;
      _o_729 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2831[2];
    _fv_2831[0] = _o_728;
    _fv_2831[1] = _o_729;
    u32 _o_730 = 0;
    Term _o_731 = 0;
    Term _t_392 = 1;
    if (_t_392 == 0) {
      _o_730 = 0;
    } else {
      _o_730 = 1;
      _o_731 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2832[2];
    _fv_2832[0] = _o_730;
    _fv_2832[1] = _o_731;
    u32 _o_732 = 0;
    Term _o_733 = 0;
    Term _t_393 = 0;
    if (_t_393 == 0) {
      _o_732 = 0;
    } else {
      _o_732 = 1;
      _o_733 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2833[2];
    _fv_2833[0] = _o_732;
    _fv_2833[1] = _o_733;
    u32 _o_734 = 0;
    Term _o_735 = 0;
    Term _t_394 = 1;
    if (_t_394 == 0) {
      _o_734 = 0;
    } else {
      _o_734 = 1;
      _o_735 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2834[2];
    _fv_2834[0] = _o_734;
    _fv_2834[1] = _o_735;
    u32 _o_736 = 0;
    Term _o_737 = 0;
    Term _t_395 = 0;
    if (_t_395 == 0) {
      _o_736 = 0;
    } else {
      _o_736 = 1;
      _o_737 = term_pak(CID_UNIT, 0);
    }
    Term _fv_2835[2];
    _fv_2835[0] = _o_736;
    _fv_2835[1] = _o_737;
    Term _fv_2836[1];
    _fv_2836[0] = 100ull;
    Term _fv_2837[1];
    _fv_2837[0] = 101ull;
    Term _fv_2838[1];
    _fv_2838[0] = 102ull;
    Term _fv_2839[1];
    _fv_2839[0] = 103ull;
    Term _fv_2840[1];
    _fv_2840[0] = 104ull;
    Term _fv_2841[1];
    _fv_2841[0] = 105ull;
    Term _fv_2842[1];
    _fv_2842[0] = 106ull;
    Term _fv_2843[1];
    _fv_2843[0] = 107ull;
    Term _fv_2844[1];
    _fv_2844[0] = 108ull;
    Term _fv_2845[1];
    _fv_2845[0] = 109ull;
    Term _fv_2846[1];
    _fv_2846[0] = 110ull;
    Term _fv_2847[1];
    _fv_2847[0] = 111ull;
    Term _fv_2848[1];
    _fv_2848[0] = 112ull;
    Term _fv_2849[1];
    _fv_2849[0] = 113ull;
    Term _fv_2850[1];
    _fv_2850[0] = 114ull;
    Term _fv_2851[1];
    _fv_2851[0] = 115ull;
    Term _fv_2852[1];
    _fv_2852[0] = 200ull;
    Term _fv_2853[1];
    _fv_2853[0] = 201ull;
    Term _fv_2854[1];
    _fv_2854[0] = 202ull;
    Term _fv_2855[1];
    _fv_2855[0] = 203ull;
    Term _fv_2856[1];
    _fv_2856[0] = 204ull;
    Term _fv_2857[1];
    _fv_2857[0] = 205ull;
    Term _fv_2858[1];
    _fv_2858[0] = 206ull;
    Term _fv_2859[1];
    _fv_2859[0] = 207ull;
    Term _fv_2860[1];
    _fv_2860[0] = 208ull;
    Term _fv_2861[1];
    _fv_2861[0] = 209ull;
    Term _fv_2862[1];
    _fv_2862[0] = 210ull;
    Term _fv_2863[1];
    _fv_2863[0] = 211ull;
    Term _fv_2864[1];
    _fv_2864[0] = 212ull;
    Term _fv_2865[1];
    _fv_2865[0] = 213ull;
    Term _fv_2866[1];
    _fv_2866[0] = 214ull;
    Term _fv_2867[1];
    _fv_2867[0] = 215ull;
    Term _v_962 = 0;
    Term _v_963 = 0;
    Term _v_964 = 0;
    Term _v_965 = 0;
    Term _v_966 = 0;
    Term _v_967 = 0;
    u32 _v_968 = 0;
    Term _v_969 = 0;
    u32 _v_970 = 0;
    Term _v_971 = 0;
    Term _o_738[10];
    Term _a_180 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2292), blk_new(e, 1, 0, 1, 2, _fv_2293)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2310), blk_new(e, 1, 0, 1, 2, _fv_2327))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2344), blk_new(e, 1, 0, 1, 2, _fv_2361)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2378), blk_new(e, 1, 0, 1, 2, _fv_2395)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2412), blk_new(e, 1, 0, 1, 2, _fv_2429)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2446), blk_new(e, 1, 0, 1, 2, _fv_2463))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2480), blk_new(e, 1, 0, 1, 2, _fv_2497)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2514), blk_new(e, 1, 0, 1, 2, _fv_2531)))));
    Term _a_181 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2548), blk_new(e, 1, 0, 1, 2, _fv_2565)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2582), blk_new(e, 1, 0, 1, 2, _fv_2599))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2616), blk_new(e, 1, 0, 1, 2, _fv_2633)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2650), blk_new(e, 1, 0, 1, 2, _fv_2667)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2684), blk_new(e, 1, 0, 1, 2, _fv_2701)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2718), blk_new(e, 1, 0, 1, 2, _fv_2735))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2752), blk_new(e, 1, 0, 1, 2, _fv_2769)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2786), blk_new(e, 1, 0, 1, 2, _fv_2803)))));
    Term _a_182 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2804), blk_new(e, 0, 0, 0, 1, _fv_2805)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2806), blk_new(e, 0, 0, 0, 1, _fv_2807))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2808), blk_new(e, 0, 0, 0, 1, _fv_2809)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2810), blk_new(e, 0, 0, 0, 1, _fv_2811)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2812), blk_new(e, 0, 0, 0, 1, _fv_2813)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2814), blk_new(e, 0, 0, 0, 1, _fv_2815))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2816), blk_new(e, 0, 0, 0, 1, _fv_2817)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2818), blk_new(e, 0, 0, 0, 1, _fv_2819)))));
    Term _a_183 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2820), blk_new(e, 1, 0, 1, 2, _fv_2821)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2822), blk_new(e, 1, 0, 1, 2, _fv_2823))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2824), blk_new(e, 1, 0, 1, 2, _fv_2825)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2826), blk_new(e, 1, 0, 1, 2, _fv_2827)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2828), blk_new(e, 1, 0, 1, 2, _fv_2829)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2830), blk_new(e, 1, 0, 1, 2, _fv_2831))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2832), blk_new(e, 1, 0, 1, 2, _fv_2833)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2834), blk_new(e, 1, 0, 1, 2, _fv_2835)))));
    Term _a_184 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2836), blk_new(e, 0, 0, 0, 1, _fv_2837)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2838), blk_new(e, 0, 0, 0, 1, _fv_2839))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2840), blk_new(e, 0, 0, 0, 1, _fv_2841)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2842), blk_new(e, 0, 0, 0, 1, _fv_2843)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2844), blk_new(e, 0, 0, 0, 1, _fv_2845)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2846), blk_new(e, 0, 0, 0, 1, _fv_2847))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2848), blk_new(e, 0, 0, 0, 1, _fv_2849)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2850), blk_new(e, 0, 0, 0, 1, _fv_2851)))));
    Term _a_185 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2852), blk_new(e, 0, 0, 0, 1, _fv_2853)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2854), blk_new(e, 0, 0, 0, 1, _fv_2855))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2856), blk_new(e, 0, 0, 0, 1, _fv_2857)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2858), blk_new(e, 0, 0, 0, 1, _fv_2859)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2860), blk_new(e, 0, 0, 0, 1, _fv_2861)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2862), blk_new(e, 0, 0, 0, 1, _fv_2863))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2864), blk_new(e, 0, 0, 0, 1, _fv_2865)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2866), blk_new(e, 0, 0, 0, 1, _fv_2867)))));
    Term _a_186 = term_pak(CID_NIL, 0);
    if (spin_19(e, _o_738, ((u64)15ull), 1ull, 16ull, 4ull, 15ull, 2, 7ull, _a_180, blk_loc(e.mem, _a_180), _a_181, blk_loc(e.mem, _a_181), _a_182, blk_loc(e.mem, _a_182), _a_183, blk_loc(e.mem, _a_183), _a_184, blk_loc(e.mem, _a_184), _a_185, blk_loc(e.mem, _a_185), _a_186, blk_loc(e.mem, _a_186)) == 0) {
      return 0;
    }
    _v_962 = _o_738[0];
    _v_963 = _o_738[1];
    _v_964 = _o_738[2];
    _v_965 = _o_738[3];
    _v_966 = _o_738[4];
    _v_967 = _o_738[5];
    _v_968 = _o_738[6];
    _v_969 = _o_738[7];
    _v_970 = _o_738[8];
    _v_971 = _o_738[9];
    _v_952 = _v_962;
    _v_953 = _v_963;
    _v_954 = _v_964;
    _v_955 = _v_965;
    _v_956 = _v_966;
    _v_957 = _v_967;
    _v_958 = _v_968;
    _v_959 = _v_969;
    _v_960 = _v_970;
    _v_961 = _v_971;
    u32 _v_972 = 0;
    u32 _v_973 = 0;
    Term _v_974 = 0;
    Term _v_975 = 0;
    Term _v_976 = 0;
    Term _v_977 = 0;
    Term _v_978 = 0;
    Term _v_979 = 0;
    u32 _v_980 = 0;
    Term _v_981 = 0;
    u32 _v_982 = 0;
    Term _v_983 = 0;
    u32 _v_984 = 0;
    Term _v_985 = 0;
    Term _v_986 = 0;
    Term _v_987 = 0;
    Term _o_739[16];
    Term _a_187 = term_pak(CID_NIL, 0);
    Term _a_188 = term_ctr(CID_OWNED, _nd_238);
    Term _a_189 = 123ull;
    if (spin_21(e, _o_739, 7ull, 999ull, _a_187, blk_loc(e.mem, _a_187), 1, _a_188, blk_loc(e.mem, _a_188), _a_189, blk_loc(e.mem, _a_189), _v_952, blk_loc(e.mem, _v_952), _v_953, blk_loc(e.mem, _v_953), _v_954, blk_loc(e.mem, _v_954), _v_955, blk_loc(e.mem, _v_955), _v_956, blk_loc(e.mem, _v_956), _v_957, blk_loc(e.mem, _v_957), _v_958, _v_959, _v_960, _v_961, blk_loc(e.mem, _v_961)) == 0) {
      return 0;
    }
    _v_972 = _o_739[0];
    _v_973 = _o_739[1];
    _v_974 = _o_739[2];
    _v_975 = _o_739[3];
    _v_976 = _o_739[4];
    _v_977 = _o_739[5];
    _v_978 = _o_739[6];
    _v_979 = _o_739[7];
    _v_980 = _o_739[8];
    _v_981 = _o_739[9];
    _v_982 = _o_739[10];
    _v_983 = _o_739[11];
    _v_984 = _o_739[12];
    _v_985 = _o_739[13];
    _v_986 = _o_739[14];
    _v_987 = _o_739[15];
    _v_936 = _v_972;
    _v_937 = _v_973;
    _v_938 = _v_974;
    _v_939 = _v_975;
    _v_940 = _v_976;
    _v_941 = _v_977;
    _v_942 = _v_978;
    _v_943 = _v_979;
    _v_944 = _v_980;
    _v_945 = _v_981;
    _v_946 = _v_982;
    _v_947 = _v_983;
    _v_948 = _v_984;
    _v_949 = _v_985;
    _v_950 = _v_986;
    _v_951 = _v_987;
    u32 _o_740 = 0;
    Term _o_741 = 0;
    u32 _o_742 = 0;
    if (_v_948 == 0) {
      _o_740 = 0;
    } else {
      _o_740 = 1;
      Term _fb_18[2];
      u64 _sp_18 = ctr_take(e, _v_949, 2, _fb_18);
      Term _f_36 = _fb_18[0];
      u32 _f_37 = _fb_18[1];
      spare_free(e, cls_fit(2), _sp_18);
      _o_741 = _f_36;
      _o_742 = _f_37;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K283;
      WL_PUSHN(1);
    } else {
      u64 _t_396 = task_node(e, FID_MAIN_K283, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K283, _t_396);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_397 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_397 + 0] = _v_936;
      e.mem[_t_397 + 1] = _v_937;
      e.mem[_t_397 + 2] = _v_938;
      e.mem[_t_397 + 3] = _v_939;
      e.mem[_t_397 + 4] = _v_940;
      e.mem[_t_397 + 5] = _v_941;
      e.mem[_t_397 + 6] = _v_942;
      e.mem[_t_397 + 7] = _v_943;
      e.mem[_t_397 + 8] = _v_944;
      e.mem[_t_397 + 9] = _v_945;
      e.mem[_t_397 + 10] = _v_946;
      e.mem[_t_397 + 11] = _v_947;
      e.mem[_t_397 + 12] = _o_740;
      e.mem[_t_397 + 13] = _o_741;
      e.mem[_t_397 + 14] = _o_742;
      e.mem[_t_397 + 15] = _v_950;
      e.mem[_t_397 + 16] = _v_951;
      return term_tsk(FID_SNAPSHOT, _t_397);
    }
    r0 = _v_936;
    r1 = _v_937;
    r2 = _v_938;
    r3 = _v_939;
    r4 = _v_940;
    r5 = _v_941;
    r6 = _v_942;
    r7 = _v_943;
    r8 = _v_944;
    r9 = _v_945;
    r10 = _v_946;
    r11 = _v_947;
    r12 = _o_740;
    r13 = _o_741;
    r14 = _o_742;
    r15 = _v_950;
    r16 = _v_951;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K283)
  {
    Term _h_54 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K284;
      WL_PUSHN(1);
    } else {
      u64 _t_398 = task_node(e, FID_MAIN_K284, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K284, _t_398);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_399 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_399 + 0] = term_ctr(CID_SCON, STAT_OFF + 200);
      e.mem[_t_399 + 1] = _h_54;
      return term_tsk(FID_STRING_APPEND, _t_399);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 200);
    r1 = _h_54;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K284)
  {
    Term _h_55 = r0;
    WL_OPEN
    u64 _nd_271 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_271 + 0] = _h_55;
    r0 = term_clo(FID_MAIN_C285, _nd_271);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C285)
  {
    Term _h_56 = r0;
    Term _x_36 = r1;
    WL_OPEN
    u64 _nd_272 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_272 + 0] = _h_56;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_454 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_454 + 0] = term_clo(FID_IO_PRINT, _nd_272);
      e.mem[_t_454 + 1] = term_clo(FID_MAIN_C286, 0);
      e.mem[_t_454 + 2] = _x_36;
      return term_tsk(FID_IO_BIND, _t_454);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_272);
    r1 = term_clo(FID_MAIN_C286, 0);
    r2 = _x_36;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C286)
  {
    Term _x_37 = r0;
    WL_OPEN
    u32 _v_988 = 0;
    u32 _v_989 = 0;
    Term _v_990 = 0;
    Term _v_991 = 0;
    Term _v_992 = 0;
    Term _v_993 = 0;
    Term _v_994 = 0;
    Term _v_995 = 0;
    u32 _v_996 = 0;
    Term _v_997 = 0;
    u32 _v_998 = 0;
    Term _v_999 = 0;
    u32 _v_1000 = 0;
    Term _v_1001 = 0;
    Term _v_1002 = 0;
    Term _v_1003 = 0;
    Term _fv_2868[1];
    _fv_2868[0] = 999000ull;
    Term _fv_2869[1];
    _fv_2869[0] = 999001ull;
    Term _fv_2870[1];
    _fv_2870[0] = 999002ull;
    Term _fv_2871[1];
    _fv_2871[0] = 999003ull;
    Term _fv_2872[1];
    _fv_2872[0] = 999004ull;
    Term _fv_2873[1];
    _fv_2873[0] = 999005ull;
    Term _fv_2874[1];
    _fv_2874[0] = 999006ull;
    Term _fv_2875[1];
    _fv_2875[0] = 999007ull;
    Term _fv_2876[1];
    _fv_2876[0] = 999008ull;
    Term _fv_2877[1];
    _fv_2877[0] = 999009ull;
    Term _fv_2878[1];
    _fv_2878[0] = 999010ull;
    Term _fv_2879[1];
    _fv_2879[0] = 999011ull;
    Term _fv_2880[1];
    _fv_2880[0] = 999012ull;
    Term _fv_2881[1];
    _fv_2881[0] = 999013ull;
    Term _fv_2882[1];
    _fv_2882[0] = 999014ull;
    Term _fv_2883[1];
    _fv_2883[0] = 999015ull;
    u64 _nd_273 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_273 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2868), blk_new(e, 0, 0, 0, 1, _fv_2869)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2870), blk_new(e, 0, 0, 0, 1, _fv_2871))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2872), blk_new(e, 0, 0, 0, 1, _fv_2873)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2874), blk_new(e, 0, 0, 0, 1, _fv_2875)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2876), blk_new(e, 0, 0, 0, 1, _fv_2877)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2878), blk_new(e, 0, 0, 0, 1, _fv_2879))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2880), blk_new(e, 0, 0, 0, 1, _fv_2881)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2882), blk_new(e, 0, 0, 0, 1, _fv_2883))))));
    e.mem[_nd_273 + 1] = rfc_seal(e, 999ull);
    Term _v_1004 = 0;
    Term _v_1005 = 0;
    Term _v_1006 = 0;
    Term _v_1007 = 0;
    Term _v_1008 = 0;
    Term _v_1009 = 0;
    u32 _v_1010 = 0;
    Term _v_1011 = 0;
    u32 _v_1012 = 0;
    Term _v_1013 = 0;
    Term _fv_2884[1];
    _fv_2884[0] = 1000ull;
    Term _fv_2885[1];
    _fv_2885[0] = 1001ull;
    Term _fv_2886[1];
    _fv_2886[0] = 1002ull;
    Term _fv_2887[1];
    _fv_2887[0] = 1003ull;
    Term _fv_2888[1];
    _fv_2888[0] = 1004ull;
    Term _fv_2889[1];
    _fv_2889[0] = 1005ull;
    Term _fv_2890[1];
    _fv_2890[0] = 1006ull;
    Term _fv_2891[1];
    _fv_2891[0] = 1007ull;
    Term _fv_2892[1];
    _fv_2892[0] = 1008ull;
    Term _fv_2893[1];
    _fv_2893[0] = 1009ull;
    Term _fv_2894[1];
    _fv_2894[0] = 1010ull;
    Term _fv_2895[1];
    _fv_2895[0] = 1011ull;
    Term _fv_2896[1];
    _fv_2896[0] = 1012ull;
    Term _fv_2897[1];
    _fv_2897[0] = 1013ull;
    Term _fv_2898[1];
    _fv_2898[0] = 1014ull;
    Term _fv_2899[1];
    _fv_2899[0] = 1015ull;
    u32 _o_743 = 0;
    Term _o_744 = 0;
    Term _t_400 = 1;
    if (_t_400 == 0) {
      _o_743 = 0;
    } else {
      _o_743 = 1;
      u64 _nd_274 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_274 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2884), blk_new(e, 0, 0, 0, 1, _fv_2885)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2886), blk_new(e, 0, 0, 0, 1, _fv_2887))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2888), blk_new(e, 0, 0, 0, 1, _fv_2889)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2890), blk_new(e, 0, 0, 0, 1, _fv_2891)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2892), blk_new(e, 0, 0, 0, 1, _fv_2893)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2894), blk_new(e, 0, 0, 0, 1, _fv_2895))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2896), blk_new(e, 0, 0, 0, 1, _fv_2897)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2898), blk_new(e, 0, 0, 0, 1, _fv_2899))))));
      e.mem[_nd_274 + 1] = rfc_seal(e, 1ull);
      _o_744 = term_ctr(CID_OWNED, _nd_274);
    }
    Term _fv_2900[2];
    _fv_2900[0] = _o_743;
    _fv_2900[1] = _o_744;
    u32 _o_745 = 0;
    Term _o_746 = 0;
    Term _t_401 = 0;
    if (_t_401 == 0) {
      _o_745 = 0;
    } else {
      _o_745 = 1;
      u64 _nd_275 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_275 + 0] = rfc_seal(e, 0);
      e.mem[_nd_275 + 1] = rfc_seal(e, 0);
      _o_746 = term_ctr(CID_OWNED, _nd_275);
    }
    Term _fv_2901[2];
    _fv_2901[0] = _o_745;
    _fv_2901[1] = _o_746;
    Term _fv_2902[1];
    _fv_2902[0] = 3000ull;
    Term _fv_2903[1];
    _fv_2903[0] = 3001ull;
    Term _fv_2904[1];
    _fv_2904[0] = 3002ull;
    Term _fv_2905[1];
    _fv_2905[0] = 3003ull;
    Term _fv_2906[1];
    _fv_2906[0] = 3004ull;
    Term _fv_2907[1];
    _fv_2907[0] = 3005ull;
    Term _fv_2908[1];
    _fv_2908[0] = 3006ull;
    Term _fv_2909[1];
    _fv_2909[0] = 3007ull;
    Term _fv_2910[1];
    _fv_2910[0] = 3008ull;
    Term _fv_2911[1];
    _fv_2911[0] = 3009ull;
    Term _fv_2912[1];
    _fv_2912[0] = 3010ull;
    Term _fv_2913[1];
    _fv_2913[0] = 3011ull;
    Term _fv_2914[1];
    _fv_2914[0] = 3012ull;
    Term _fv_2915[1];
    _fv_2915[0] = 3013ull;
    Term _fv_2916[1];
    _fv_2916[0] = 3014ull;
    Term _fv_2917[1];
    _fv_2917[0] = 3015ull;
    u32 _o_747 = 0;
    Term _o_748 = 0;
    Term _t_402 = 1;
    if (_t_402 == 0) {
      _o_747 = 0;
    } else {
      _o_747 = 1;
      u64 _nd_276 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_276 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2902), blk_new(e, 0, 0, 0, 1, _fv_2903)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2904), blk_new(e, 0, 0, 0, 1, _fv_2905))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2906), blk_new(e, 0, 0, 0, 1, _fv_2907)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2908), blk_new(e, 0, 0, 0, 1, _fv_2909)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2910), blk_new(e, 0, 0, 0, 1, _fv_2911)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2912), blk_new(e, 0, 0, 0, 1, _fv_2913))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2914), blk_new(e, 0, 0, 0, 1, _fv_2915)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2916), blk_new(e, 0, 0, 0, 1, _fv_2917))))));
      e.mem[_nd_276 + 1] = rfc_seal(e, 3ull);
      _o_748 = term_ctr(CID_OWNED, _nd_276);
    }
    Term _fv_2918[2];
    _fv_2918[0] = _o_747;
    _fv_2918[1] = _o_748;
    Term _fv_2919[1];
    _fv_2919[0] = 4000ull;
    Term _fv_2920[1];
    _fv_2920[0] = 4001ull;
    Term _fv_2921[1];
    _fv_2921[0] = 4002ull;
    Term _fv_2922[1];
    _fv_2922[0] = 4003ull;
    Term _fv_2923[1];
    _fv_2923[0] = 4004ull;
    Term _fv_2924[1];
    _fv_2924[0] = 4005ull;
    Term _fv_2925[1];
    _fv_2925[0] = 4006ull;
    Term _fv_2926[1];
    _fv_2926[0] = 4007ull;
    Term _fv_2927[1];
    _fv_2927[0] = 4008ull;
    Term _fv_2928[1];
    _fv_2928[0] = 4009ull;
    Term _fv_2929[1];
    _fv_2929[0] = 4010ull;
    Term _fv_2930[1];
    _fv_2930[0] = 4011ull;
    Term _fv_2931[1];
    _fv_2931[0] = 4012ull;
    Term _fv_2932[1];
    _fv_2932[0] = 4013ull;
    Term _fv_2933[1];
    _fv_2933[0] = 4014ull;
    Term _fv_2934[1];
    _fv_2934[0] = 4015ull;
    u32 _o_749 = 0;
    Term _o_750 = 0;
    Term _t_403 = 1;
    if (_t_403 == 0) {
      _o_749 = 0;
    } else {
      _o_749 = 1;
      u64 _nd_277 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_277 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2919), blk_new(e, 0, 0, 0, 1, _fv_2920)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2921), blk_new(e, 0, 0, 0, 1, _fv_2922))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2923), blk_new(e, 0, 0, 0, 1, _fv_2924)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2925), blk_new(e, 0, 0, 0, 1, _fv_2926)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2927), blk_new(e, 0, 0, 0, 1, _fv_2928)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2929), blk_new(e, 0, 0, 0, 1, _fv_2930))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2931), blk_new(e, 0, 0, 0, 1, _fv_2932)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2933), blk_new(e, 0, 0, 0, 1, _fv_2934))))));
      e.mem[_nd_277 + 1] = rfc_seal(e, 4ull);
      _o_750 = term_ctr(CID_OWNED, _nd_277);
    }
    Term _fv_2935[2];
    _fv_2935[0] = _o_749;
    _fv_2935[1] = _o_750;
    Term _fv_2936[1];
    _fv_2936[0] = 5000ull;
    Term _fv_2937[1];
    _fv_2937[0] = 5001ull;
    Term _fv_2938[1];
    _fv_2938[0] = 5002ull;
    Term _fv_2939[1];
    _fv_2939[0] = 5003ull;
    Term _fv_2940[1];
    _fv_2940[0] = 5004ull;
    Term _fv_2941[1];
    _fv_2941[0] = 5005ull;
    Term _fv_2942[1];
    _fv_2942[0] = 5006ull;
    Term _fv_2943[1];
    _fv_2943[0] = 5007ull;
    Term _fv_2944[1];
    _fv_2944[0] = 5008ull;
    Term _fv_2945[1];
    _fv_2945[0] = 5009ull;
    Term _fv_2946[1];
    _fv_2946[0] = 5010ull;
    Term _fv_2947[1];
    _fv_2947[0] = 5011ull;
    Term _fv_2948[1];
    _fv_2948[0] = 5012ull;
    Term _fv_2949[1];
    _fv_2949[0] = 5013ull;
    Term _fv_2950[1];
    _fv_2950[0] = 5014ull;
    Term _fv_2951[1];
    _fv_2951[0] = 5015ull;
    u32 _o_751 = 0;
    Term _o_752 = 0;
    Term _t_404 = 1;
    if (_t_404 == 0) {
      _o_751 = 0;
    } else {
      _o_751 = 1;
      u64 _nd_278 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_278 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2936), blk_new(e, 0, 0, 0, 1, _fv_2937)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2938), blk_new(e, 0, 0, 0, 1, _fv_2939))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2940), blk_new(e, 0, 0, 0, 1, _fv_2941)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2942), blk_new(e, 0, 0, 0, 1, _fv_2943)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2944), blk_new(e, 0, 0, 0, 1, _fv_2945)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2946), blk_new(e, 0, 0, 0, 1, _fv_2947))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2948), blk_new(e, 0, 0, 0, 1, _fv_2949)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2950), blk_new(e, 0, 0, 0, 1, _fv_2951))))));
      e.mem[_nd_278 + 1] = rfc_seal(e, 5ull);
      _o_752 = term_ctr(CID_OWNED, _nd_278);
    }
    Term _fv_2952[2];
    _fv_2952[0] = _o_751;
    _fv_2952[1] = _o_752;
    Term _fv_2953[1];
    _fv_2953[0] = 6000ull;
    Term _fv_2954[1];
    _fv_2954[0] = 6001ull;
    Term _fv_2955[1];
    _fv_2955[0] = 6002ull;
    Term _fv_2956[1];
    _fv_2956[0] = 6003ull;
    Term _fv_2957[1];
    _fv_2957[0] = 6004ull;
    Term _fv_2958[1];
    _fv_2958[0] = 6005ull;
    Term _fv_2959[1];
    _fv_2959[0] = 6006ull;
    Term _fv_2960[1];
    _fv_2960[0] = 6007ull;
    Term _fv_2961[1];
    _fv_2961[0] = 6008ull;
    Term _fv_2962[1];
    _fv_2962[0] = 6009ull;
    Term _fv_2963[1];
    _fv_2963[0] = 6010ull;
    Term _fv_2964[1];
    _fv_2964[0] = 6011ull;
    Term _fv_2965[1];
    _fv_2965[0] = 6012ull;
    Term _fv_2966[1];
    _fv_2966[0] = 6013ull;
    Term _fv_2967[1];
    _fv_2967[0] = 6014ull;
    Term _fv_2968[1];
    _fv_2968[0] = 6015ull;
    u32 _o_753 = 0;
    Term _o_754 = 0;
    Term _t_405 = 1;
    if (_t_405 == 0) {
      _o_753 = 0;
    } else {
      _o_753 = 1;
      u64 _nd_279 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_279 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2953), blk_new(e, 0, 0, 0, 1, _fv_2954)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2955), blk_new(e, 0, 0, 0, 1, _fv_2956))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2957), blk_new(e, 0, 0, 0, 1, _fv_2958)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2959), blk_new(e, 0, 0, 0, 1, _fv_2960)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2961), blk_new(e, 0, 0, 0, 1, _fv_2962)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2963), blk_new(e, 0, 0, 0, 1, _fv_2964))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2965), blk_new(e, 0, 0, 0, 1, _fv_2966)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2967), blk_new(e, 0, 0, 0, 1, _fv_2968))))));
      e.mem[_nd_279 + 1] = rfc_seal(e, 6ull);
      _o_754 = term_ctr(CID_OWNED, _nd_279);
    }
    Term _fv_2969[2];
    _fv_2969[0] = _o_753;
    _fv_2969[1] = _o_754;
    Term _fv_2970[1];
    _fv_2970[0] = 7000ull;
    Term _fv_2971[1];
    _fv_2971[0] = 7001ull;
    Term _fv_2972[1];
    _fv_2972[0] = 7002ull;
    Term _fv_2973[1];
    _fv_2973[0] = 7003ull;
    Term _fv_2974[1];
    _fv_2974[0] = 7004ull;
    Term _fv_2975[1];
    _fv_2975[0] = 7005ull;
    Term _fv_2976[1];
    _fv_2976[0] = 7006ull;
    Term _fv_2977[1];
    _fv_2977[0] = 7007ull;
    Term _fv_2978[1];
    _fv_2978[0] = 7008ull;
    Term _fv_2979[1];
    _fv_2979[0] = 7009ull;
    Term _fv_2980[1];
    _fv_2980[0] = 7010ull;
    Term _fv_2981[1];
    _fv_2981[0] = 7011ull;
    Term _fv_2982[1];
    _fv_2982[0] = 7012ull;
    Term _fv_2983[1];
    _fv_2983[0] = 7013ull;
    Term _fv_2984[1];
    _fv_2984[0] = 7014ull;
    Term _fv_2985[1];
    _fv_2985[0] = 7015ull;
    u32 _o_755 = 0;
    Term _o_756 = 0;
    Term _t_406 = 1;
    if (_t_406 == 0) {
      _o_755 = 0;
    } else {
      _o_755 = 1;
      u64 _nd_280 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_280 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2970), blk_new(e, 0, 0, 0, 1, _fv_2971)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2972), blk_new(e, 0, 0, 0, 1, _fv_2973))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2974), blk_new(e, 0, 0, 0, 1, _fv_2975)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2976), blk_new(e, 0, 0, 0, 1, _fv_2977)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2978), blk_new(e, 0, 0, 0, 1, _fv_2979)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2980), blk_new(e, 0, 0, 0, 1, _fv_2981))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2982), blk_new(e, 0, 0, 0, 1, _fv_2983)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2984), blk_new(e, 0, 0, 0, 1, _fv_2985))))));
      e.mem[_nd_280 + 1] = rfc_seal(e, 7ull);
      _o_756 = term_ctr(CID_OWNED, _nd_280);
    }
    Term _fv_2986[2];
    _fv_2986[0] = _o_755;
    _fv_2986[1] = _o_756;
    Term _fv_2987[1];
    _fv_2987[0] = 8000ull;
    Term _fv_2988[1];
    _fv_2988[0] = 8001ull;
    Term _fv_2989[1];
    _fv_2989[0] = 8002ull;
    Term _fv_2990[1];
    _fv_2990[0] = 8003ull;
    Term _fv_2991[1];
    _fv_2991[0] = 8004ull;
    Term _fv_2992[1];
    _fv_2992[0] = 8005ull;
    Term _fv_2993[1];
    _fv_2993[0] = 8006ull;
    Term _fv_2994[1];
    _fv_2994[0] = 8007ull;
    Term _fv_2995[1];
    _fv_2995[0] = 8008ull;
    Term _fv_2996[1];
    _fv_2996[0] = 8009ull;
    Term _fv_2997[1];
    _fv_2997[0] = 8010ull;
    Term _fv_2998[1];
    _fv_2998[0] = 8011ull;
    Term _fv_2999[1];
    _fv_2999[0] = 8012ull;
    Term _fv_3000[1];
    _fv_3000[0] = 8013ull;
    Term _fv_3001[1];
    _fv_3001[0] = 8014ull;
    Term _fv_3002[1];
    _fv_3002[0] = 8015ull;
    u32 _o_757 = 0;
    Term _o_758 = 0;
    Term _t_407 = 1;
    if (_t_407 == 0) {
      _o_757 = 0;
    } else {
      _o_757 = 1;
      u64 _nd_281 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_281 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2987), blk_new(e, 0, 0, 0, 1, _fv_2988)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2989), blk_new(e, 0, 0, 0, 1, _fv_2990))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2991), blk_new(e, 0, 0, 0, 1, _fv_2992)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2993), blk_new(e, 0, 0, 0, 1, _fv_2994)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2995), blk_new(e, 0, 0, 0, 1, _fv_2996)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2997), blk_new(e, 0, 0, 0, 1, _fv_2998))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2999), blk_new(e, 0, 0, 0, 1, _fv_3000)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3001), blk_new(e, 0, 0, 0, 1, _fv_3002))))));
      e.mem[_nd_281 + 1] = rfc_seal(e, 8ull);
      _o_758 = term_ctr(CID_OWNED, _nd_281);
    }
    Term _fv_3003[2];
    _fv_3003[0] = _o_757;
    _fv_3003[1] = _o_758;
    Term _fv_3004[1];
    _fv_3004[0] = 9000ull;
    Term _fv_3005[1];
    _fv_3005[0] = 9001ull;
    Term _fv_3006[1];
    _fv_3006[0] = 9002ull;
    Term _fv_3007[1];
    _fv_3007[0] = 9003ull;
    Term _fv_3008[1];
    _fv_3008[0] = 9004ull;
    Term _fv_3009[1];
    _fv_3009[0] = 9005ull;
    Term _fv_3010[1];
    _fv_3010[0] = 9006ull;
    Term _fv_3011[1];
    _fv_3011[0] = 9007ull;
    Term _fv_3012[1];
    _fv_3012[0] = 9008ull;
    Term _fv_3013[1];
    _fv_3013[0] = 9009ull;
    Term _fv_3014[1];
    _fv_3014[0] = 9010ull;
    Term _fv_3015[1];
    _fv_3015[0] = 9011ull;
    Term _fv_3016[1];
    _fv_3016[0] = 9012ull;
    Term _fv_3017[1];
    _fv_3017[0] = 9013ull;
    Term _fv_3018[1];
    _fv_3018[0] = 9014ull;
    Term _fv_3019[1];
    _fv_3019[0] = 9015ull;
    u32 _o_759 = 0;
    Term _o_760 = 0;
    Term _t_408 = 1;
    if (_t_408 == 0) {
      _o_759 = 0;
    } else {
      _o_759 = 1;
      u64 _nd_282 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_282 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3004), blk_new(e, 0, 0, 0, 1, _fv_3005)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3006), blk_new(e, 0, 0, 0, 1, _fv_3007))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3008), blk_new(e, 0, 0, 0, 1, _fv_3009)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3010), blk_new(e, 0, 0, 0, 1, _fv_3011)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3012), blk_new(e, 0, 0, 0, 1, _fv_3013)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3014), blk_new(e, 0, 0, 0, 1, _fv_3015))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3016), blk_new(e, 0, 0, 0, 1, _fv_3017)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3018), blk_new(e, 0, 0, 0, 1, _fv_3019))))));
      e.mem[_nd_282 + 1] = rfc_seal(e, 9ull);
      _o_760 = term_ctr(CID_OWNED, _nd_282);
    }
    Term _fv_3020[2];
    _fv_3020[0] = _o_759;
    _fv_3020[1] = _o_760;
    Term _fv_3021[1];
    _fv_3021[0] = 10000ull;
    Term _fv_3022[1];
    _fv_3022[0] = 10001ull;
    Term _fv_3023[1];
    _fv_3023[0] = 10002ull;
    Term _fv_3024[1];
    _fv_3024[0] = 10003ull;
    Term _fv_3025[1];
    _fv_3025[0] = 10004ull;
    Term _fv_3026[1];
    _fv_3026[0] = 10005ull;
    Term _fv_3027[1];
    _fv_3027[0] = 10006ull;
    Term _fv_3028[1];
    _fv_3028[0] = 10007ull;
    Term _fv_3029[1];
    _fv_3029[0] = 10008ull;
    Term _fv_3030[1];
    _fv_3030[0] = 10009ull;
    Term _fv_3031[1];
    _fv_3031[0] = 10010ull;
    Term _fv_3032[1];
    _fv_3032[0] = 10011ull;
    Term _fv_3033[1];
    _fv_3033[0] = 10012ull;
    Term _fv_3034[1];
    _fv_3034[0] = 10013ull;
    Term _fv_3035[1];
    _fv_3035[0] = 10014ull;
    Term _fv_3036[1];
    _fv_3036[0] = 10015ull;
    u32 _o_761 = 0;
    Term _o_762 = 0;
    Term _t_409 = 1;
    if (_t_409 == 0) {
      _o_761 = 0;
    } else {
      _o_761 = 1;
      u64 _nd_283 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_283 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3021), blk_new(e, 0, 0, 0, 1, _fv_3022)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3023), blk_new(e, 0, 0, 0, 1, _fv_3024))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3025), blk_new(e, 0, 0, 0, 1, _fv_3026)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3027), blk_new(e, 0, 0, 0, 1, _fv_3028)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3029), blk_new(e, 0, 0, 0, 1, _fv_3030)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3031), blk_new(e, 0, 0, 0, 1, _fv_3032))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3033), blk_new(e, 0, 0, 0, 1, _fv_3034)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3035), blk_new(e, 0, 0, 0, 1, _fv_3036))))));
      e.mem[_nd_283 + 1] = rfc_seal(e, 10ull);
      _o_762 = term_ctr(CID_OWNED, _nd_283);
    }
    Term _fv_3037[2];
    _fv_3037[0] = _o_761;
    _fv_3037[1] = _o_762;
    Term _fv_3038[1];
    _fv_3038[0] = 11000ull;
    Term _fv_3039[1];
    _fv_3039[0] = 11001ull;
    Term _fv_3040[1];
    _fv_3040[0] = 11002ull;
    Term _fv_3041[1];
    _fv_3041[0] = 11003ull;
    Term _fv_3042[1];
    _fv_3042[0] = 11004ull;
    Term _fv_3043[1];
    _fv_3043[0] = 11005ull;
    Term _fv_3044[1];
    _fv_3044[0] = 11006ull;
    Term _fv_3045[1];
    _fv_3045[0] = 11007ull;
    Term _fv_3046[1];
    _fv_3046[0] = 11008ull;
    Term _fv_3047[1];
    _fv_3047[0] = 11009ull;
    Term _fv_3048[1];
    _fv_3048[0] = 11010ull;
    Term _fv_3049[1];
    _fv_3049[0] = 11011ull;
    Term _fv_3050[1];
    _fv_3050[0] = 11012ull;
    Term _fv_3051[1];
    _fv_3051[0] = 11013ull;
    Term _fv_3052[1];
    _fv_3052[0] = 11014ull;
    Term _fv_3053[1];
    _fv_3053[0] = 11015ull;
    u32 _o_763 = 0;
    Term _o_764 = 0;
    Term _t_410 = 1;
    if (_t_410 == 0) {
      _o_763 = 0;
    } else {
      _o_763 = 1;
      u64 _nd_284 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_284 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3038), blk_new(e, 0, 0, 0, 1, _fv_3039)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3040), blk_new(e, 0, 0, 0, 1, _fv_3041))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3042), blk_new(e, 0, 0, 0, 1, _fv_3043)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3044), blk_new(e, 0, 0, 0, 1, _fv_3045)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3046), blk_new(e, 0, 0, 0, 1, _fv_3047)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3048), blk_new(e, 0, 0, 0, 1, _fv_3049))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3050), blk_new(e, 0, 0, 0, 1, _fv_3051)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3052), blk_new(e, 0, 0, 0, 1, _fv_3053))))));
      e.mem[_nd_284 + 1] = rfc_seal(e, 11ull);
      _o_764 = term_ctr(CID_OWNED, _nd_284);
    }
    Term _fv_3054[2];
    _fv_3054[0] = _o_763;
    _fv_3054[1] = _o_764;
    Term _fv_3055[1];
    _fv_3055[0] = 12000ull;
    Term _fv_3056[1];
    _fv_3056[0] = 12001ull;
    Term _fv_3057[1];
    _fv_3057[0] = 12002ull;
    Term _fv_3058[1];
    _fv_3058[0] = 12003ull;
    Term _fv_3059[1];
    _fv_3059[0] = 12004ull;
    Term _fv_3060[1];
    _fv_3060[0] = 12005ull;
    Term _fv_3061[1];
    _fv_3061[0] = 12006ull;
    Term _fv_3062[1];
    _fv_3062[0] = 12007ull;
    Term _fv_3063[1];
    _fv_3063[0] = 12008ull;
    Term _fv_3064[1];
    _fv_3064[0] = 12009ull;
    Term _fv_3065[1];
    _fv_3065[0] = 12010ull;
    Term _fv_3066[1];
    _fv_3066[0] = 12011ull;
    Term _fv_3067[1];
    _fv_3067[0] = 12012ull;
    Term _fv_3068[1];
    _fv_3068[0] = 12013ull;
    Term _fv_3069[1];
    _fv_3069[0] = 12014ull;
    Term _fv_3070[1];
    _fv_3070[0] = 12015ull;
    u32 _o_765 = 0;
    Term _o_766 = 0;
    Term _t_411 = 1;
    if (_t_411 == 0) {
      _o_765 = 0;
    } else {
      _o_765 = 1;
      u64 _nd_285 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_285 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3055), blk_new(e, 0, 0, 0, 1, _fv_3056)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3057), blk_new(e, 0, 0, 0, 1, _fv_3058))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3059), blk_new(e, 0, 0, 0, 1, _fv_3060)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3061), blk_new(e, 0, 0, 0, 1, _fv_3062)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3063), blk_new(e, 0, 0, 0, 1, _fv_3064)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3065), blk_new(e, 0, 0, 0, 1, _fv_3066))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3067), blk_new(e, 0, 0, 0, 1, _fv_3068)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3069), blk_new(e, 0, 0, 0, 1, _fv_3070))))));
      e.mem[_nd_285 + 1] = rfc_seal(e, 12ull);
      _o_766 = term_ctr(CID_OWNED, _nd_285);
    }
    Term _fv_3071[2];
    _fv_3071[0] = _o_765;
    _fv_3071[1] = _o_766;
    Term _fv_3072[1];
    _fv_3072[0] = 13000ull;
    Term _fv_3073[1];
    _fv_3073[0] = 13001ull;
    Term _fv_3074[1];
    _fv_3074[0] = 13002ull;
    Term _fv_3075[1];
    _fv_3075[0] = 13003ull;
    Term _fv_3076[1];
    _fv_3076[0] = 13004ull;
    Term _fv_3077[1];
    _fv_3077[0] = 13005ull;
    Term _fv_3078[1];
    _fv_3078[0] = 13006ull;
    Term _fv_3079[1];
    _fv_3079[0] = 13007ull;
    Term _fv_3080[1];
    _fv_3080[0] = 13008ull;
    Term _fv_3081[1];
    _fv_3081[0] = 13009ull;
    Term _fv_3082[1];
    _fv_3082[0] = 13010ull;
    Term _fv_3083[1];
    _fv_3083[0] = 13011ull;
    Term _fv_3084[1];
    _fv_3084[0] = 13012ull;
    Term _fv_3085[1];
    _fv_3085[0] = 13013ull;
    Term _fv_3086[1];
    _fv_3086[0] = 13014ull;
    Term _fv_3087[1];
    _fv_3087[0] = 13015ull;
    u32 _o_767 = 0;
    Term _o_768 = 0;
    Term _t_412 = 1;
    if (_t_412 == 0) {
      _o_767 = 0;
    } else {
      _o_767 = 1;
      u64 _nd_286 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_286 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3072), blk_new(e, 0, 0, 0, 1, _fv_3073)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3074), blk_new(e, 0, 0, 0, 1, _fv_3075))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3076), blk_new(e, 0, 0, 0, 1, _fv_3077)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3078), blk_new(e, 0, 0, 0, 1, _fv_3079)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3080), blk_new(e, 0, 0, 0, 1, _fv_3081)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3082), blk_new(e, 0, 0, 0, 1, _fv_3083))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3084), blk_new(e, 0, 0, 0, 1, _fv_3085)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3086), blk_new(e, 0, 0, 0, 1, _fv_3087))))));
      e.mem[_nd_286 + 1] = rfc_seal(e, 13ull);
      _o_768 = term_ctr(CID_OWNED, _nd_286);
    }
    Term _fv_3088[2];
    _fv_3088[0] = _o_767;
    _fv_3088[1] = _o_768;
    Term _fv_3089[1];
    _fv_3089[0] = 14000ull;
    Term _fv_3090[1];
    _fv_3090[0] = 14001ull;
    Term _fv_3091[1];
    _fv_3091[0] = 14002ull;
    Term _fv_3092[1];
    _fv_3092[0] = 14003ull;
    Term _fv_3093[1];
    _fv_3093[0] = 14004ull;
    Term _fv_3094[1];
    _fv_3094[0] = 14005ull;
    Term _fv_3095[1];
    _fv_3095[0] = 14006ull;
    Term _fv_3096[1];
    _fv_3096[0] = 14007ull;
    Term _fv_3097[1];
    _fv_3097[0] = 14008ull;
    Term _fv_3098[1];
    _fv_3098[0] = 14009ull;
    Term _fv_3099[1];
    _fv_3099[0] = 14010ull;
    Term _fv_3100[1];
    _fv_3100[0] = 14011ull;
    Term _fv_3101[1];
    _fv_3101[0] = 14012ull;
    Term _fv_3102[1];
    _fv_3102[0] = 14013ull;
    Term _fv_3103[1];
    _fv_3103[0] = 14014ull;
    Term _fv_3104[1];
    _fv_3104[0] = 14015ull;
    u32 _o_769 = 0;
    Term _o_770 = 0;
    Term _t_413 = 1;
    if (_t_413 == 0) {
      _o_769 = 0;
    } else {
      _o_769 = 1;
      u64 _nd_287 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_287 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3089), blk_new(e, 0, 0, 0, 1, _fv_3090)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3091), blk_new(e, 0, 0, 0, 1, _fv_3092))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3093), blk_new(e, 0, 0, 0, 1, _fv_3094)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3095), blk_new(e, 0, 0, 0, 1, _fv_3096)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3097), blk_new(e, 0, 0, 0, 1, _fv_3098)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3099), blk_new(e, 0, 0, 0, 1, _fv_3100))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3101), blk_new(e, 0, 0, 0, 1, _fv_3102)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3103), blk_new(e, 0, 0, 0, 1, _fv_3104))))));
      e.mem[_nd_287 + 1] = rfc_seal(e, 14ull);
      _o_770 = term_ctr(CID_OWNED, _nd_287);
    }
    Term _fv_3105[2];
    _fv_3105[0] = _o_769;
    _fv_3105[1] = _o_770;
    Term _fv_3106[1];
    _fv_3106[0] = 15000ull;
    Term _fv_3107[1];
    _fv_3107[0] = 15001ull;
    Term _fv_3108[1];
    _fv_3108[0] = 15002ull;
    Term _fv_3109[1];
    _fv_3109[0] = 15003ull;
    Term _fv_3110[1];
    _fv_3110[0] = 15004ull;
    Term _fv_3111[1];
    _fv_3111[0] = 15005ull;
    Term _fv_3112[1];
    _fv_3112[0] = 15006ull;
    Term _fv_3113[1];
    _fv_3113[0] = 15007ull;
    Term _fv_3114[1];
    _fv_3114[0] = 15008ull;
    Term _fv_3115[1];
    _fv_3115[0] = 15009ull;
    Term _fv_3116[1];
    _fv_3116[0] = 15010ull;
    Term _fv_3117[1];
    _fv_3117[0] = 15011ull;
    Term _fv_3118[1];
    _fv_3118[0] = 15012ull;
    Term _fv_3119[1];
    _fv_3119[0] = 15013ull;
    Term _fv_3120[1];
    _fv_3120[0] = 15014ull;
    Term _fv_3121[1];
    _fv_3121[0] = 15015ull;
    u32 _o_771 = 0;
    Term _o_772 = 0;
    Term _t_414 = 1;
    if (_t_414 == 0) {
      _o_771 = 0;
    } else {
      _o_771 = 1;
      u64 _nd_288 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_288 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3106), blk_new(e, 0, 0, 0, 1, _fv_3107)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3108), blk_new(e, 0, 0, 0, 1, _fv_3109))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3110), blk_new(e, 0, 0, 0, 1, _fv_3111)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3112), blk_new(e, 0, 0, 0, 1, _fv_3113)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3114), blk_new(e, 0, 0, 0, 1, _fv_3115)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3116), blk_new(e, 0, 0, 0, 1, _fv_3117))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3118), blk_new(e, 0, 0, 0, 1, _fv_3119)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3120), blk_new(e, 0, 0, 0, 1, _fv_3121))))));
      e.mem[_nd_288 + 1] = rfc_seal(e, 15ull);
      _o_772 = term_ctr(CID_OWNED, _nd_288);
    }
    Term _fv_3122[2];
    _fv_3122[0] = _o_771;
    _fv_3122[1] = _o_772;
    Term _fv_3123[1];
    _fv_3123[0] = 16000ull;
    Term _fv_3124[1];
    _fv_3124[0] = 16001ull;
    Term _fv_3125[1];
    _fv_3125[0] = 16002ull;
    Term _fv_3126[1];
    _fv_3126[0] = 16003ull;
    Term _fv_3127[1];
    _fv_3127[0] = 16004ull;
    Term _fv_3128[1];
    _fv_3128[0] = 16005ull;
    Term _fv_3129[1];
    _fv_3129[0] = 16006ull;
    Term _fv_3130[1];
    _fv_3130[0] = 16007ull;
    Term _fv_3131[1];
    _fv_3131[0] = 16008ull;
    Term _fv_3132[1];
    _fv_3132[0] = 16009ull;
    Term _fv_3133[1];
    _fv_3133[0] = 16010ull;
    Term _fv_3134[1];
    _fv_3134[0] = 16011ull;
    Term _fv_3135[1];
    _fv_3135[0] = 16012ull;
    Term _fv_3136[1];
    _fv_3136[0] = 16013ull;
    Term _fv_3137[1];
    _fv_3137[0] = 16014ull;
    Term _fv_3138[1];
    _fv_3138[0] = 16015ull;
    u32 _o_773 = 0;
    Term _o_774 = 0;
    Term _t_415 = 1;
    if (_t_415 == 0) {
      _o_773 = 0;
    } else {
      _o_773 = 1;
      u64 _nd_289 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_289 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3123), blk_new(e, 0, 0, 0, 1, _fv_3124)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3125), blk_new(e, 0, 0, 0, 1, _fv_3126))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3127), blk_new(e, 0, 0, 0, 1, _fv_3128)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3129), blk_new(e, 0, 0, 0, 1, _fv_3130)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3131), blk_new(e, 0, 0, 0, 1, _fv_3132)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3133), blk_new(e, 0, 0, 0, 1, _fv_3134))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3135), blk_new(e, 0, 0, 0, 1, _fv_3136)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3137), blk_new(e, 0, 0, 0, 1, _fv_3138))))));
      e.mem[_nd_289 + 1] = rfc_seal(e, 16ull);
      _o_774 = term_ctr(CID_OWNED, _nd_289);
    }
    Term _fv_3139[2];
    _fv_3139[0] = _o_773;
    _fv_3139[1] = _o_774;
    Term _fv_3140[1];
    _fv_3140[0] = 101000ull;
    Term _fv_3141[1];
    _fv_3141[0] = 101001ull;
    Term _fv_3142[1];
    _fv_3142[0] = 101002ull;
    Term _fv_3143[1];
    _fv_3143[0] = 101003ull;
    Term _fv_3144[1];
    _fv_3144[0] = 101004ull;
    Term _fv_3145[1];
    _fv_3145[0] = 101005ull;
    Term _fv_3146[1];
    _fv_3146[0] = 101006ull;
    Term _fv_3147[1];
    _fv_3147[0] = 101007ull;
    Term _fv_3148[1];
    _fv_3148[0] = 101008ull;
    Term _fv_3149[1];
    _fv_3149[0] = 101009ull;
    Term _fv_3150[1];
    _fv_3150[0] = 101010ull;
    Term _fv_3151[1];
    _fv_3151[0] = 101011ull;
    Term _fv_3152[1];
    _fv_3152[0] = 101012ull;
    Term _fv_3153[1];
    _fv_3153[0] = 101013ull;
    Term _fv_3154[1];
    _fv_3154[0] = 101014ull;
    Term _fv_3155[1];
    _fv_3155[0] = 101015ull;
    u32 _o_775 = 0;
    Term _o_776 = 0;
    Term _t_416 = 1;
    if (_t_416 == 0) {
      _o_775 = 0;
    } else {
      _o_775 = 1;
      u64 _nd_290 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_290 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3140), blk_new(e, 0, 0, 0, 1, _fv_3141)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3142), blk_new(e, 0, 0, 0, 1, _fv_3143))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3144), blk_new(e, 0, 0, 0, 1, _fv_3145)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3146), blk_new(e, 0, 0, 0, 1, _fv_3147)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3148), blk_new(e, 0, 0, 0, 1, _fv_3149)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3150), blk_new(e, 0, 0, 0, 1, _fv_3151))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3152), blk_new(e, 0, 0, 0, 1, _fv_3153)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3154), blk_new(e, 0, 0, 0, 1, _fv_3155))))));
      e.mem[_nd_290 + 1] = rfc_seal(e, 101ull);
      _o_776 = term_ctr(CID_OWNED, _nd_290);
    }
    Term _fv_3156[2];
    _fv_3156[0] = _o_775;
    _fv_3156[1] = _o_776;
    Term _fv_3157[1];
    _fv_3157[0] = 102000ull;
    Term _fv_3158[1];
    _fv_3158[0] = 102001ull;
    Term _fv_3159[1];
    _fv_3159[0] = 102002ull;
    Term _fv_3160[1];
    _fv_3160[0] = 102003ull;
    Term _fv_3161[1];
    _fv_3161[0] = 102004ull;
    Term _fv_3162[1];
    _fv_3162[0] = 102005ull;
    Term _fv_3163[1];
    _fv_3163[0] = 102006ull;
    Term _fv_3164[1];
    _fv_3164[0] = 102007ull;
    Term _fv_3165[1];
    _fv_3165[0] = 102008ull;
    Term _fv_3166[1];
    _fv_3166[0] = 102009ull;
    Term _fv_3167[1];
    _fv_3167[0] = 102010ull;
    Term _fv_3168[1];
    _fv_3168[0] = 102011ull;
    Term _fv_3169[1];
    _fv_3169[0] = 102012ull;
    Term _fv_3170[1];
    _fv_3170[0] = 102013ull;
    Term _fv_3171[1];
    _fv_3171[0] = 102014ull;
    Term _fv_3172[1];
    _fv_3172[0] = 102015ull;
    u32 _o_777 = 0;
    Term _o_778 = 0;
    Term _t_417 = 1;
    if (_t_417 == 0) {
      _o_777 = 0;
    } else {
      _o_777 = 1;
      u64 _nd_291 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_291 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3157), blk_new(e, 0, 0, 0, 1, _fv_3158)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3159), blk_new(e, 0, 0, 0, 1, _fv_3160))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3161), blk_new(e, 0, 0, 0, 1, _fv_3162)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3163), blk_new(e, 0, 0, 0, 1, _fv_3164)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3165), blk_new(e, 0, 0, 0, 1, _fv_3166)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3167), blk_new(e, 0, 0, 0, 1, _fv_3168))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3169), blk_new(e, 0, 0, 0, 1, _fv_3170)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3171), blk_new(e, 0, 0, 0, 1, _fv_3172))))));
      e.mem[_nd_291 + 1] = rfc_seal(e, 102ull);
      _o_778 = term_ctr(CID_OWNED, _nd_291);
    }
    Term _fv_3173[2];
    _fv_3173[0] = _o_777;
    _fv_3173[1] = _o_778;
    Term _fv_3174[1];
    _fv_3174[0] = 103000ull;
    Term _fv_3175[1];
    _fv_3175[0] = 103001ull;
    Term _fv_3176[1];
    _fv_3176[0] = 103002ull;
    Term _fv_3177[1];
    _fv_3177[0] = 103003ull;
    Term _fv_3178[1];
    _fv_3178[0] = 103004ull;
    Term _fv_3179[1];
    _fv_3179[0] = 103005ull;
    Term _fv_3180[1];
    _fv_3180[0] = 103006ull;
    Term _fv_3181[1];
    _fv_3181[0] = 103007ull;
    Term _fv_3182[1];
    _fv_3182[0] = 103008ull;
    Term _fv_3183[1];
    _fv_3183[0] = 103009ull;
    Term _fv_3184[1];
    _fv_3184[0] = 103010ull;
    Term _fv_3185[1];
    _fv_3185[0] = 103011ull;
    Term _fv_3186[1];
    _fv_3186[0] = 103012ull;
    Term _fv_3187[1];
    _fv_3187[0] = 103013ull;
    Term _fv_3188[1];
    _fv_3188[0] = 103014ull;
    Term _fv_3189[1];
    _fv_3189[0] = 103015ull;
    u32 _o_779 = 0;
    Term _o_780 = 0;
    Term _t_418 = 1;
    if (_t_418 == 0) {
      _o_779 = 0;
    } else {
      _o_779 = 1;
      u64 _nd_292 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_292 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3174), blk_new(e, 0, 0, 0, 1, _fv_3175)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3176), blk_new(e, 0, 0, 0, 1, _fv_3177))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3178), blk_new(e, 0, 0, 0, 1, _fv_3179)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3180), blk_new(e, 0, 0, 0, 1, _fv_3181)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3182), blk_new(e, 0, 0, 0, 1, _fv_3183)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3184), blk_new(e, 0, 0, 0, 1, _fv_3185))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3186), blk_new(e, 0, 0, 0, 1, _fv_3187)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3188), blk_new(e, 0, 0, 0, 1, _fv_3189))))));
      e.mem[_nd_292 + 1] = rfc_seal(e, 103ull);
      _o_780 = term_ctr(CID_OWNED, _nd_292);
    }
    Term _fv_3190[2];
    _fv_3190[0] = _o_779;
    _fv_3190[1] = _o_780;
    Term _fv_3191[1];
    _fv_3191[0] = 104000ull;
    Term _fv_3192[1];
    _fv_3192[0] = 104001ull;
    Term _fv_3193[1];
    _fv_3193[0] = 104002ull;
    Term _fv_3194[1];
    _fv_3194[0] = 104003ull;
    Term _fv_3195[1];
    _fv_3195[0] = 104004ull;
    Term _fv_3196[1];
    _fv_3196[0] = 104005ull;
    Term _fv_3197[1];
    _fv_3197[0] = 104006ull;
    Term _fv_3198[1];
    _fv_3198[0] = 104007ull;
    Term _fv_3199[1];
    _fv_3199[0] = 104008ull;
    Term _fv_3200[1];
    _fv_3200[0] = 104009ull;
    Term _fv_3201[1];
    _fv_3201[0] = 104010ull;
    Term _fv_3202[1];
    _fv_3202[0] = 104011ull;
    Term _fv_3203[1];
    _fv_3203[0] = 104012ull;
    Term _fv_3204[1];
    _fv_3204[0] = 104013ull;
    Term _fv_3205[1];
    _fv_3205[0] = 104014ull;
    Term _fv_3206[1];
    _fv_3206[0] = 104015ull;
    u32 _o_781 = 0;
    Term _o_782 = 0;
    Term _t_419 = 1;
    if (_t_419 == 0) {
      _o_781 = 0;
    } else {
      _o_781 = 1;
      u64 _nd_293 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_293 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3191), blk_new(e, 0, 0, 0, 1, _fv_3192)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3193), blk_new(e, 0, 0, 0, 1, _fv_3194))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3195), blk_new(e, 0, 0, 0, 1, _fv_3196)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3197), blk_new(e, 0, 0, 0, 1, _fv_3198)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3199), blk_new(e, 0, 0, 0, 1, _fv_3200)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3201), blk_new(e, 0, 0, 0, 1, _fv_3202))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3203), blk_new(e, 0, 0, 0, 1, _fv_3204)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3205), blk_new(e, 0, 0, 0, 1, _fv_3206))))));
      e.mem[_nd_293 + 1] = rfc_seal(e, 104ull);
      _o_782 = term_ctr(CID_OWNED, _nd_293);
    }
    Term _fv_3207[2];
    _fv_3207[0] = _o_781;
    _fv_3207[1] = _o_782;
    Term _fv_3208[1];
    _fv_3208[0] = 105000ull;
    Term _fv_3209[1];
    _fv_3209[0] = 105001ull;
    Term _fv_3210[1];
    _fv_3210[0] = 105002ull;
    Term _fv_3211[1];
    _fv_3211[0] = 105003ull;
    Term _fv_3212[1];
    _fv_3212[0] = 105004ull;
    Term _fv_3213[1];
    _fv_3213[0] = 105005ull;
    Term _fv_3214[1];
    _fv_3214[0] = 105006ull;
    Term _fv_3215[1];
    _fv_3215[0] = 105007ull;
    Term _fv_3216[1];
    _fv_3216[0] = 105008ull;
    Term _fv_3217[1];
    _fv_3217[0] = 105009ull;
    Term _fv_3218[1];
    _fv_3218[0] = 105010ull;
    Term _fv_3219[1];
    _fv_3219[0] = 105011ull;
    Term _fv_3220[1];
    _fv_3220[0] = 105012ull;
    Term _fv_3221[1];
    _fv_3221[0] = 105013ull;
    Term _fv_3222[1];
    _fv_3222[0] = 105014ull;
    Term _fv_3223[1];
    _fv_3223[0] = 105015ull;
    u32 _o_783 = 0;
    Term _o_784 = 0;
    Term _t_420 = 1;
    if (_t_420 == 0) {
      _o_783 = 0;
    } else {
      _o_783 = 1;
      u64 _nd_294 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_294 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3208), blk_new(e, 0, 0, 0, 1, _fv_3209)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3210), blk_new(e, 0, 0, 0, 1, _fv_3211))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3212), blk_new(e, 0, 0, 0, 1, _fv_3213)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3214), blk_new(e, 0, 0, 0, 1, _fv_3215)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3216), blk_new(e, 0, 0, 0, 1, _fv_3217)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3218), blk_new(e, 0, 0, 0, 1, _fv_3219))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3220), blk_new(e, 0, 0, 0, 1, _fv_3221)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3222), blk_new(e, 0, 0, 0, 1, _fv_3223))))));
      e.mem[_nd_294 + 1] = rfc_seal(e, 105ull);
      _o_784 = term_ctr(CID_OWNED, _nd_294);
    }
    Term _fv_3224[2];
    _fv_3224[0] = _o_783;
    _fv_3224[1] = _o_784;
    Term _fv_3225[1];
    _fv_3225[0] = 106000ull;
    Term _fv_3226[1];
    _fv_3226[0] = 106001ull;
    Term _fv_3227[1];
    _fv_3227[0] = 106002ull;
    Term _fv_3228[1];
    _fv_3228[0] = 106003ull;
    Term _fv_3229[1];
    _fv_3229[0] = 106004ull;
    Term _fv_3230[1];
    _fv_3230[0] = 106005ull;
    Term _fv_3231[1];
    _fv_3231[0] = 106006ull;
    Term _fv_3232[1];
    _fv_3232[0] = 106007ull;
    Term _fv_3233[1];
    _fv_3233[0] = 106008ull;
    Term _fv_3234[1];
    _fv_3234[0] = 106009ull;
    Term _fv_3235[1];
    _fv_3235[0] = 106010ull;
    Term _fv_3236[1];
    _fv_3236[0] = 106011ull;
    Term _fv_3237[1];
    _fv_3237[0] = 106012ull;
    Term _fv_3238[1];
    _fv_3238[0] = 106013ull;
    Term _fv_3239[1];
    _fv_3239[0] = 106014ull;
    Term _fv_3240[1];
    _fv_3240[0] = 106015ull;
    u32 _o_785 = 0;
    Term _o_786 = 0;
    Term _t_421 = 1;
    if (_t_421 == 0) {
      _o_785 = 0;
    } else {
      _o_785 = 1;
      u64 _nd_295 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_295 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3225), blk_new(e, 0, 0, 0, 1, _fv_3226)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3227), blk_new(e, 0, 0, 0, 1, _fv_3228))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3229), blk_new(e, 0, 0, 0, 1, _fv_3230)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3231), blk_new(e, 0, 0, 0, 1, _fv_3232)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3233), blk_new(e, 0, 0, 0, 1, _fv_3234)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3235), blk_new(e, 0, 0, 0, 1, _fv_3236))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3237), blk_new(e, 0, 0, 0, 1, _fv_3238)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3239), blk_new(e, 0, 0, 0, 1, _fv_3240))))));
      e.mem[_nd_295 + 1] = rfc_seal(e, 106ull);
      _o_786 = term_ctr(CID_OWNED, _nd_295);
    }
    Term _fv_3241[2];
    _fv_3241[0] = _o_785;
    _fv_3241[1] = _o_786;
    Term _fv_3242[1];
    _fv_3242[0] = 107000ull;
    Term _fv_3243[1];
    _fv_3243[0] = 107001ull;
    Term _fv_3244[1];
    _fv_3244[0] = 107002ull;
    Term _fv_3245[1];
    _fv_3245[0] = 107003ull;
    Term _fv_3246[1];
    _fv_3246[0] = 107004ull;
    Term _fv_3247[1];
    _fv_3247[0] = 107005ull;
    Term _fv_3248[1];
    _fv_3248[0] = 107006ull;
    Term _fv_3249[1];
    _fv_3249[0] = 107007ull;
    Term _fv_3250[1];
    _fv_3250[0] = 107008ull;
    Term _fv_3251[1];
    _fv_3251[0] = 107009ull;
    Term _fv_3252[1];
    _fv_3252[0] = 107010ull;
    Term _fv_3253[1];
    _fv_3253[0] = 107011ull;
    Term _fv_3254[1];
    _fv_3254[0] = 107012ull;
    Term _fv_3255[1];
    _fv_3255[0] = 107013ull;
    Term _fv_3256[1];
    _fv_3256[0] = 107014ull;
    Term _fv_3257[1];
    _fv_3257[0] = 107015ull;
    u32 _o_787 = 0;
    Term _o_788 = 0;
    Term _t_422 = 1;
    if (_t_422 == 0) {
      _o_787 = 0;
    } else {
      _o_787 = 1;
      u64 _nd_296 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_296 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3242), blk_new(e, 0, 0, 0, 1, _fv_3243)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3244), blk_new(e, 0, 0, 0, 1, _fv_3245))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3246), blk_new(e, 0, 0, 0, 1, _fv_3247)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3248), blk_new(e, 0, 0, 0, 1, _fv_3249)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3250), blk_new(e, 0, 0, 0, 1, _fv_3251)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3252), blk_new(e, 0, 0, 0, 1, _fv_3253))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3254), blk_new(e, 0, 0, 0, 1, _fv_3255)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3256), blk_new(e, 0, 0, 0, 1, _fv_3257))))));
      e.mem[_nd_296 + 1] = rfc_seal(e, 107ull);
      _o_788 = term_ctr(CID_OWNED, _nd_296);
    }
    Term _fv_3258[2];
    _fv_3258[0] = _o_787;
    _fv_3258[1] = _o_788;
    Term _fv_3259[1];
    _fv_3259[0] = 108000ull;
    Term _fv_3260[1];
    _fv_3260[0] = 108001ull;
    Term _fv_3261[1];
    _fv_3261[0] = 108002ull;
    Term _fv_3262[1];
    _fv_3262[0] = 108003ull;
    Term _fv_3263[1];
    _fv_3263[0] = 108004ull;
    Term _fv_3264[1];
    _fv_3264[0] = 108005ull;
    Term _fv_3265[1];
    _fv_3265[0] = 108006ull;
    Term _fv_3266[1];
    _fv_3266[0] = 108007ull;
    Term _fv_3267[1];
    _fv_3267[0] = 108008ull;
    Term _fv_3268[1];
    _fv_3268[0] = 108009ull;
    Term _fv_3269[1];
    _fv_3269[0] = 108010ull;
    Term _fv_3270[1];
    _fv_3270[0] = 108011ull;
    Term _fv_3271[1];
    _fv_3271[0] = 108012ull;
    Term _fv_3272[1];
    _fv_3272[0] = 108013ull;
    Term _fv_3273[1];
    _fv_3273[0] = 108014ull;
    Term _fv_3274[1];
    _fv_3274[0] = 108015ull;
    u32 _o_789 = 0;
    Term _o_790 = 0;
    Term _t_423 = 1;
    if (_t_423 == 0) {
      _o_789 = 0;
    } else {
      _o_789 = 1;
      u64 _nd_297 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_297 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3259), blk_new(e, 0, 0, 0, 1, _fv_3260)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3261), blk_new(e, 0, 0, 0, 1, _fv_3262))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3263), blk_new(e, 0, 0, 0, 1, _fv_3264)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3265), blk_new(e, 0, 0, 0, 1, _fv_3266)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3267), blk_new(e, 0, 0, 0, 1, _fv_3268)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3269), blk_new(e, 0, 0, 0, 1, _fv_3270))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3271), blk_new(e, 0, 0, 0, 1, _fv_3272)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3273), blk_new(e, 0, 0, 0, 1, _fv_3274))))));
      e.mem[_nd_297 + 1] = rfc_seal(e, 108ull);
      _o_790 = term_ctr(CID_OWNED, _nd_297);
    }
    Term _fv_3275[2];
    _fv_3275[0] = _o_789;
    _fv_3275[1] = _o_790;
    Term _fv_3276[1];
    _fv_3276[0] = 109000ull;
    Term _fv_3277[1];
    _fv_3277[0] = 109001ull;
    Term _fv_3278[1];
    _fv_3278[0] = 109002ull;
    Term _fv_3279[1];
    _fv_3279[0] = 109003ull;
    Term _fv_3280[1];
    _fv_3280[0] = 109004ull;
    Term _fv_3281[1];
    _fv_3281[0] = 109005ull;
    Term _fv_3282[1];
    _fv_3282[0] = 109006ull;
    Term _fv_3283[1];
    _fv_3283[0] = 109007ull;
    Term _fv_3284[1];
    _fv_3284[0] = 109008ull;
    Term _fv_3285[1];
    _fv_3285[0] = 109009ull;
    Term _fv_3286[1];
    _fv_3286[0] = 109010ull;
    Term _fv_3287[1];
    _fv_3287[0] = 109011ull;
    Term _fv_3288[1];
    _fv_3288[0] = 109012ull;
    Term _fv_3289[1];
    _fv_3289[0] = 109013ull;
    Term _fv_3290[1];
    _fv_3290[0] = 109014ull;
    Term _fv_3291[1];
    _fv_3291[0] = 109015ull;
    u32 _o_791 = 0;
    Term _o_792 = 0;
    Term _t_424 = 1;
    if (_t_424 == 0) {
      _o_791 = 0;
    } else {
      _o_791 = 1;
      u64 _nd_298 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_298 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3276), blk_new(e, 0, 0, 0, 1, _fv_3277)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3278), blk_new(e, 0, 0, 0, 1, _fv_3279))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3280), blk_new(e, 0, 0, 0, 1, _fv_3281)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3282), blk_new(e, 0, 0, 0, 1, _fv_3283)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3284), blk_new(e, 0, 0, 0, 1, _fv_3285)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3286), blk_new(e, 0, 0, 0, 1, _fv_3287))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3288), blk_new(e, 0, 0, 0, 1, _fv_3289)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3290), blk_new(e, 0, 0, 0, 1, _fv_3291))))));
      e.mem[_nd_298 + 1] = rfc_seal(e, 109ull);
      _o_792 = term_ctr(CID_OWNED, _nd_298);
    }
    Term _fv_3292[2];
    _fv_3292[0] = _o_791;
    _fv_3292[1] = _o_792;
    Term _fv_3293[1];
    _fv_3293[0] = 110000ull;
    Term _fv_3294[1];
    _fv_3294[0] = 110001ull;
    Term _fv_3295[1];
    _fv_3295[0] = 110002ull;
    Term _fv_3296[1];
    _fv_3296[0] = 110003ull;
    Term _fv_3297[1];
    _fv_3297[0] = 110004ull;
    Term _fv_3298[1];
    _fv_3298[0] = 110005ull;
    Term _fv_3299[1];
    _fv_3299[0] = 110006ull;
    Term _fv_3300[1];
    _fv_3300[0] = 110007ull;
    Term _fv_3301[1];
    _fv_3301[0] = 110008ull;
    Term _fv_3302[1];
    _fv_3302[0] = 110009ull;
    Term _fv_3303[1];
    _fv_3303[0] = 110010ull;
    Term _fv_3304[1];
    _fv_3304[0] = 110011ull;
    Term _fv_3305[1];
    _fv_3305[0] = 110012ull;
    Term _fv_3306[1];
    _fv_3306[0] = 110013ull;
    Term _fv_3307[1];
    _fv_3307[0] = 110014ull;
    Term _fv_3308[1];
    _fv_3308[0] = 110015ull;
    u32 _o_793 = 0;
    Term _o_794 = 0;
    Term _t_425 = 1;
    if (_t_425 == 0) {
      _o_793 = 0;
    } else {
      _o_793 = 1;
      u64 _nd_299 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_299 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3293), blk_new(e, 0, 0, 0, 1, _fv_3294)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3295), blk_new(e, 0, 0, 0, 1, _fv_3296))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3297), blk_new(e, 0, 0, 0, 1, _fv_3298)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3299), blk_new(e, 0, 0, 0, 1, _fv_3300)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3301), blk_new(e, 0, 0, 0, 1, _fv_3302)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3303), blk_new(e, 0, 0, 0, 1, _fv_3304))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3305), blk_new(e, 0, 0, 0, 1, _fv_3306)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3307), blk_new(e, 0, 0, 0, 1, _fv_3308))))));
      e.mem[_nd_299 + 1] = rfc_seal(e, 110ull);
      _o_794 = term_ctr(CID_OWNED, _nd_299);
    }
    Term _fv_3309[2];
    _fv_3309[0] = _o_793;
    _fv_3309[1] = _o_794;
    Term _fv_3310[1];
    _fv_3310[0] = 111000ull;
    Term _fv_3311[1];
    _fv_3311[0] = 111001ull;
    Term _fv_3312[1];
    _fv_3312[0] = 111002ull;
    Term _fv_3313[1];
    _fv_3313[0] = 111003ull;
    Term _fv_3314[1];
    _fv_3314[0] = 111004ull;
    Term _fv_3315[1];
    _fv_3315[0] = 111005ull;
    Term _fv_3316[1];
    _fv_3316[0] = 111006ull;
    Term _fv_3317[1];
    _fv_3317[0] = 111007ull;
    Term _fv_3318[1];
    _fv_3318[0] = 111008ull;
    Term _fv_3319[1];
    _fv_3319[0] = 111009ull;
    Term _fv_3320[1];
    _fv_3320[0] = 111010ull;
    Term _fv_3321[1];
    _fv_3321[0] = 111011ull;
    Term _fv_3322[1];
    _fv_3322[0] = 111012ull;
    Term _fv_3323[1];
    _fv_3323[0] = 111013ull;
    Term _fv_3324[1];
    _fv_3324[0] = 111014ull;
    Term _fv_3325[1];
    _fv_3325[0] = 111015ull;
    u32 _o_795 = 0;
    Term _o_796 = 0;
    Term _t_426 = 1;
    if (_t_426 == 0) {
      _o_795 = 0;
    } else {
      _o_795 = 1;
      u64 _nd_300 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_300 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3310), blk_new(e, 0, 0, 0, 1, _fv_3311)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3312), blk_new(e, 0, 0, 0, 1, _fv_3313))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3314), blk_new(e, 0, 0, 0, 1, _fv_3315)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3316), blk_new(e, 0, 0, 0, 1, _fv_3317)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3318), blk_new(e, 0, 0, 0, 1, _fv_3319)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3320), blk_new(e, 0, 0, 0, 1, _fv_3321))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3322), blk_new(e, 0, 0, 0, 1, _fv_3323)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3324), blk_new(e, 0, 0, 0, 1, _fv_3325))))));
      e.mem[_nd_300 + 1] = rfc_seal(e, 111ull);
      _o_796 = term_ctr(CID_OWNED, _nd_300);
    }
    Term _fv_3326[2];
    _fv_3326[0] = _o_795;
    _fv_3326[1] = _o_796;
    Term _fv_3327[1];
    _fv_3327[0] = 112000ull;
    Term _fv_3328[1];
    _fv_3328[0] = 112001ull;
    Term _fv_3329[1];
    _fv_3329[0] = 112002ull;
    Term _fv_3330[1];
    _fv_3330[0] = 112003ull;
    Term _fv_3331[1];
    _fv_3331[0] = 112004ull;
    Term _fv_3332[1];
    _fv_3332[0] = 112005ull;
    Term _fv_3333[1];
    _fv_3333[0] = 112006ull;
    Term _fv_3334[1];
    _fv_3334[0] = 112007ull;
    Term _fv_3335[1];
    _fv_3335[0] = 112008ull;
    Term _fv_3336[1];
    _fv_3336[0] = 112009ull;
    Term _fv_3337[1];
    _fv_3337[0] = 112010ull;
    Term _fv_3338[1];
    _fv_3338[0] = 112011ull;
    Term _fv_3339[1];
    _fv_3339[0] = 112012ull;
    Term _fv_3340[1];
    _fv_3340[0] = 112013ull;
    Term _fv_3341[1];
    _fv_3341[0] = 112014ull;
    Term _fv_3342[1];
    _fv_3342[0] = 112015ull;
    u32 _o_797 = 0;
    Term _o_798 = 0;
    Term _t_427 = 1;
    if (_t_427 == 0) {
      _o_797 = 0;
    } else {
      _o_797 = 1;
      u64 _nd_301 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_301 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3327), blk_new(e, 0, 0, 0, 1, _fv_3328)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3329), blk_new(e, 0, 0, 0, 1, _fv_3330))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3331), blk_new(e, 0, 0, 0, 1, _fv_3332)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3333), blk_new(e, 0, 0, 0, 1, _fv_3334)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3335), blk_new(e, 0, 0, 0, 1, _fv_3336)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3337), blk_new(e, 0, 0, 0, 1, _fv_3338))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3339), blk_new(e, 0, 0, 0, 1, _fv_3340)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3341), blk_new(e, 0, 0, 0, 1, _fv_3342))))));
      e.mem[_nd_301 + 1] = rfc_seal(e, 112ull);
      _o_798 = term_ctr(CID_OWNED, _nd_301);
    }
    Term _fv_3343[2];
    _fv_3343[0] = _o_797;
    _fv_3343[1] = _o_798;
    Term _fv_3344[1];
    _fv_3344[0] = 113000ull;
    Term _fv_3345[1];
    _fv_3345[0] = 113001ull;
    Term _fv_3346[1];
    _fv_3346[0] = 113002ull;
    Term _fv_3347[1];
    _fv_3347[0] = 113003ull;
    Term _fv_3348[1];
    _fv_3348[0] = 113004ull;
    Term _fv_3349[1];
    _fv_3349[0] = 113005ull;
    Term _fv_3350[1];
    _fv_3350[0] = 113006ull;
    Term _fv_3351[1];
    _fv_3351[0] = 113007ull;
    Term _fv_3352[1];
    _fv_3352[0] = 113008ull;
    Term _fv_3353[1];
    _fv_3353[0] = 113009ull;
    Term _fv_3354[1];
    _fv_3354[0] = 113010ull;
    Term _fv_3355[1];
    _fv_3355[0] = 113011ull;
    Term _fv_3356[1];
    _fv_3356[0] = 113012ull;
    Term _fv_3357[1];
    _fv_3357[0] = 113013ull;
    Term _fv_3358[1];
    _fv_3358[0] = 113014ull;
    Term _fv_3359[1];
    _fv_3359[0] = 113015ull;
    u32 _o_799 = 0;
    Term _o_800 = 0;
    Term _t_428 = 1;
    if (_t_428 == 0) {
      _o_799 = 0;
    } else {
      _o_799 = 1;
      u64 _nd_302 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_302 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3344), blk_new(e, 0, 0, 0, 1, _fv_3345)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3346), blk_new(e, 0, 0, 0, 1, _fv_3347))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3348), blk_new(e, 0, 0, 0, 1, _fv_3349)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3350), blk_new(e, 0, 0, 0, 1, _fv_3351)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3352), blk_new(e, 0, 0, 0, 1, _fv_3353)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3354), blk_new(e, 0, 0, 0, 1, _fv_3355))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3356), blk_new(e, 0, 0, 0, 1, _fv_3357)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3358), blk_new(e, 0, 0, 0, 1, _fv_3359))))));
      e.mem[_nd_302 + 1] = rfc_seal(e, 113ull);
      _o_800 = term_ctr(CID_OWNED, _nd_302);
    }
    Term _fv_3360[2];
    _fv_3360[0] = _o_799;
    _fv_3360[1] = _o_800;
    Term _fv_3361[1];
    _fv_3361[0] = 114000ull;
    Term _fv_3362[1];
    _fv_3362[0] = 114001ull;
    Term _fv_3363[1];
    _fv_3363[0] = 114002ull;
    Term _fv_3364[1];
    _fv_3364[0] = 114003ull;
    Term _fv_3365[1];
    _fv_3365[0] = 114004ull;
    Term _fv_3366[1];
    _fv_3366[0] = 114005ull;
    Term _fv_3367[1];
    _fv_3367[0] = 114006ull;
    Term _fv_3368[1];
    _fv_3368[0] = 114007ull;
    Term _fv_3369[1];
    _fv_3369[0] = 114008ull;
    Term _fv_3370[1];
    _fv_3370[0] = 114009ull;
    Term _fv_3371[1];
    _fv_3371[0] = 114010ull;
    Term _fv_3372[1];
    _fv_3372[0] = 114011ull;
    Term _fv_3373[1];
    _fv_3373[0] = 114012ull;
    Term _fv_3374[1];
    _fv_3374[0] = 114013ull;
    Term _fv_3375[1];
    _fv_3375[0] = 114014ull;
    Term _fv_3376[1];
    _fv_3376[0] = 114015ull;
    u32 _o_801 = 0;
    Term _o_802 = 0;
    Term _t_429 = 1;
    if (_t_429 == 0) {
      _o_801 = 0;
    } else {
      _o_801 = 1;
      u64 _nd_303 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_303 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3361), blk_new(e, 0, 0, 0, 1, _fv_3362)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3363), blk_new(e, 0, 0, 0, 1, _fv_3364))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3365), blk_new(e, 0, 0, 0, 1, _fv_3366)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3367), blk_new(e, 0, 0, 0, 1, _fv_3368)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3369), blk_new(e, 0, 0, 0, 1, _fv_3370)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3371), blk_new(e, 0, 0, 0, 1, _fv_3372))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3373), blk_new(e, 0, 0, 0, 1, _fv_3374)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3375), blk_new(e, 0, 0, 0, 1, _fv_3376))))));
      e.mem[_nd_303 + 1] = rfc_seal(e, 114ull);
      _o_802 = term_ctr(CID_OWNED, _nd_303);
    }
    Term _fv_3377[2];
    _fv_3377[0] = _o_801;
    _fv_3377[1] = _o_802;
    Term _fv_3378[1];
    _fv_3378[0] = 115000ull;
    Term _fv_3379[1];
    _fv_3379[0] = 115001ull;
    Term _fv_3380[1];
    _fv_3380[0] = 115002ull;
    Term _fv_3381[1];
    _fv_3381[0] = 115003ull;
    Term _fv_3382[1];
    _fv_3382[0] = 115004ull;
    Term _fv_3383[1];
    _fv_3383[0] = 115005ull;
    Term _fv_3384[1];
    _fv_3384[0] = 115006ull;
    Term _fv_3385[1];
    _fv_3385[0] = 115007ull;
    Term _fv_3386[1];
    _fv_3386[0] = 115008ull;
    Term _fv_3387[1];
    _fv_3387[0] = 115009ull;
    Term _fv_3388[1];
    _fv_3388[0] = 115010ull;
    Term _fv_3389[1];
    _fv_3389[0] = 115011ull;
    Term _fv_3390[1];
    _fv_3390[0] = 115012ull;
    Term _fv_3391[1];
    _fv_3391[0] = 115013ull;
    Term _fv_3392[1];
    _fv_3392[0] = 115014ull;
    Term _fv_3393[1];
    _fv_3393[0] = 115015ull;
    u32 _o_803 = 0;
    Term _o_804 = 0;
    Term _t_430 = 1;
    if (_t_430 == 0) {
      _o_803 = 0;
    } else {
      _o_803 = 1;
      u64 _nd_304 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_304 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3378), blk_new(e, 0, 0, 0, 1, _fv_3379)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3380), blk_new(e, 0, 0, 0, 1, _fv_3381))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3382), blk_new(e, 0, 0, 0, 1, _fv_3383)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3384), blk_new(e, 0, 0, 0, 1, _fv_3385)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3386), blk_new(e, 0, 0, 0, 1, _fv_3387)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3388), blk_new(e, 0, 0, 0, 1, _fv_3389))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3390), blk_new(e, 0, 0, 0, 1, _fv_3391)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3392), blk_new(e, 0, 0, 0, 1, _fv_3393))))));
      e.mem[_nd_304 + 1] = rfc_seal(e, 115ull);
      _o_804 = term_ctr(CID_OWNED, _nd_304);
    }
    Term _fv_3394[2];
    _fv_3394[0] = _o_803;
    _fv_3394[1] = _o_804;
    Term _fv_3395[1];
    _fv_3395[0] = 116000ull;
    Term _fv_3396[1];
    _fv_3396[0] = 116001ull;
    Term _fv_3397[1];
    _fv_3397[0] = 116002ull;
    Term _fv_3398[1];
    _fv_3398[0] = 116003ull;
    Term _fv_3399[1];
    _fv_3399[0] = 116004ull;
    Term _fv_3400[1];
    _fv_3400[0] = 116005ull;
    Term _fv_3401[1];
    _fv_3401[0] = 116006ull;
    Term _fv_3402[1];
    _fv_3402[0] = 116007ull;
    Term _fv_3403[1];
    _fv_3403[0] = 116008ull;
    Term _fv_3404[1];
    _fv_3404[0] = 116009ull;
    Term _fv_3405[1];
    _fv_3405[0] = 116010ull;
    Term _fv_3406[1];
    _fv_3406[0] = 116011ull;
    Term _fv_3407[1];
    _fv_3407[0] = 116012ull;
    Term _fv_3408[1];
    _fv_3408[0] = 116013ull;
    Term _fv_3409[1];
    _fv_3409[0] = 116014ull;
    Term _fv_3410[1];
    _fv_3410[0] = 116015ull;
    u32 _o_805 = 0;
    Term _o_806 = 0;
    Term _t_431 = 1;
    if (_t_431 == 0) {
      _o_805 = 0;
    } else {
      _o_805 = 1;
      u64 _nd_305 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_305 + 0] = rfc_seal(e, blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3395), blk_new(e, 0, 0, 0, 1, _fv_3396)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3397), blk_new(e, 0, 0, 0, 1, _fv_3398))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3399), blk_new(e, 0, 0, 0, 1, _fv_3400)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3401), blk_new(e, 0, 0, 0, 1, _fv_3402)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3403), blk_new(e, 0, 0, 0, 1, _fv_3404)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3405), blk_new(e, 0, 0, 0, 1, _fv_3406))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3407), blk_new(e, 0, 0, 0, 1, _fv_3408)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3409), blk_new(e, 0, 0, 0, 1, _fv_3410))))));
      e.mem[_nd_305 + 1] = rfc_seal(e, 116ull);
      _o_806 = term_ctr(CID_OWNED, _nd_305);
    }
    Term _fv_3411[2];
    _fv_3411[0] = _o_805;
    _fv_3411[1] = _o_806;
    Term _fv_3412[1];
    _fv_3412[0] = 1;
    Term _fv_3413[1];
    _fv_3413[0] = 1;
    Term _fv_3414[1];
    _fv_3414[0] = 0;
    Term _fv_3415[1];
    _fv_3415[0] = 1;
    Term _fv_3416[1];
    _fv_3416[0] = 1;
    Term _fv_3417[1];
    _fv_3417[0] = 1;
    Term _fv_3418[1];
    _fv_3418[0] = 1;
    Term _fv_3419[1];
    _fv_3419[0] = 1;
    Term _fv_3420[1];
    _fv_3420[0] = 1;
    Term _fv_3421[1];
    _fv_3421[0] = 1;
    Term _fv_3422[1];
    _fv_3422[0] = 1;
    Term _fv_3423[1];
    _fv_3423[0] = 1;
    Term _fv_3424[1];
    _fv_3424[0] = 1;
    Term _fv_3425[1];
    _fv_3425[0] = 1;
    Term _fv_3426[1];
    _fv_3426[0] = 1;
    Term _fv_3427[1];
    _fv_3427[0] = 1;
    u32 _o_807 = 0;
    Term _o_808 = 0;
    Term _t_432 = 1;
    if (_t_432 == 0) {
      _o_807 = 0;
    } else {
      _o_807 = 1;
      _o_808 = term_pak(CID_UNIT, 0);
    }
    Term _fv_3428[2];
    _fv_3428[0] = _o_807;
    _fv_3428[1] = _o_808;
    u32 _o_809 = 0;
    Term _o_810 = 0;
    Term _t_433 = 0;
    if (_t_433 == 0) {
      _o_809 = 0;
    } else {
      _o_809 = 1;
      _o_810 = term_pak(CID_UNIT, 0);
    }
    Term _fv_3429[2];
    _fv_3429[0] = _o_809;
    _fv_3429[1] = _o_810;
    u32 _o_811 = 0;
    Term _o_812 = 0;
    Term _t_434 = 1;
    if (_t_434 == 0) {
      _o_811 = 0;
    } else {
      _o_811 = 1;
      _o_812 = term_pak(CID_UNIT, 0);
    }
    Term _fv_3430[2];
    _fv_3430[0] = _o_811;
    _fv_3430[1] = _o_812;
    u32 _o_813 = 0;
    Term _o_814 = 0;
    Term _t_435 = 0;
    if (_t_435 == 0) {
      _o_813 = 0;
    } else {
      _o_813 = 1;
      _o_814 = term_pak(CID_UNIT, 0);
    }
    Term _fv_3431[2];
    _fv_3431[0] = _o_813;
    _fv_3431[1] = _o_814;
    u32 _o_815 = 0;
    Term _o_816 = 0;
    Term _t_436 = 1;
    if (_t_436 == 0) {
      _o_815 = 0;
    } else {
      _o_815 = 1;
      _o_816 = term_pak(CID_UNIT, 0);
    }
    Term _fv_3432[2];
    _fv_3432[0] = _o_815;
    _fv_3432[1] = _o_816;
    u32 _o_817 = 0;
    Term _o_818 = 0;
    Term _t_437 = 0;
    if (_t_437 == 0) {
      _o_817 = 0;
    } else {
      _o_817 = 1;
      _o_818 = term_pak(CID_UNIT, 0);
    }
    Term _fv_3433[2];
    _fv_3433[0] = _o_817;
    _fv_3433[1] = _o_818;
    u32 _o_819 = 0;
    Term _o_820 = 0;
    Term _t_438 = 1;
    if (_t_438 == 0) {
      _o_819 = 0;
    } else {
      _o_819 = 1;
      _o_820 = term_pak(CID_UNIT, 0);
    }
    Term _fv_3434[2];
    _fv_3434[0] = _o_819;
    _fv_3434[1] = _o_820;
    u32 _o_821 = 0;
    Term _o_822 = 0;
    Term _t_439 = 0;
    if (_t_439 == 0) {
      _o_821 = 0;
    } else {
      _o_821 = 1;
      _o_822 = term_pak(CID_UNIT, 0);
    }
    Term _fv_3435[2];
    _fv_3435[0] = _o_821;
    _fv_3435[1] = _o_822;
    u32 _o_823 = 0;
    Term _o_824 = 0;
    Term _t_440 = 1;
    if (_t_440 == 0) {
      _o_823 = 0;
    } else {
      _o_823 = 1;
      _o_824 = term_pak(CID_UNIT, 0);
    }
    Term _fv_3436[2];
    _fv_3436[0] = _o_823;
    _fv_3436[1] = _o_824;
    u32 _o_825 = 0;
    Term _o_826 = 0;
    Term _t_441 = 0;
    if (_t_441 == 0) {
      _o_825 = 0;
    } else {
      _o_825 = 1;
      _o_826 = term_pak(CID_UNIT, 0);
    }
    Term _fv_3437[2];
    _fv_3437[0] = _o_825;
    _fv_3437[1] = _o_826;
    u32 _o_827 = 0;
    Term _o_828 = 0;
    Term _t_442 = 1;
    if (_t_442 == 0) {
      _o_827 = 0;
    } else {
      _o_827 = 1;
      _o_828 = term_pak(CID_UNIT, 0);
    }
    Term _fv_3438[2];
    _fv_3438[0] = _o_827;
    _fv_3438[1] = _o_828;
    u32 _o_829 = 0;
    Term _o_830 = 0;
    Term _t_443 = 0;
    if (_t_443 == 0) {
      _o_829 = 0;
    } else {
      _o_829 = 1;
      _o_830 = term_pak(CID_UNIT, 0);
    }
    Term _fv_3439[2];
    _fv_3439[0] = _o_829;
    _fv_3439[1] = _o_830;
    u32 _o_831 = 0;
    Term _o_832 = 0;
    Term _t_444 = 1;
    if (_t_444 == 0) {
      _o_831 = 0;
    } else {
      _o_831 = 1;
      _o_832 = term_pak(CID_UNIT, 0);
    }
    Term _fv_3440[2];
    _fv_3440[0] = _o_831;
    _fv_3440[1] = _o_832;
    u32 _o_833 = 0;
    Term _o_834 = 0;
    Term _t_445 = 0;
    if (_t_445 == 0) {
      _o_833 = 0;
    } else {
      _o_833 = 1;
      _o_834 = term_pak(CID_UNIT, 0);
    }
    Term _fv_3441[2];
    _fv_3441[0] = _o_833;
    _fv_3441[1] = _o_834;
    u32 _o_835 = 0;
    Term _o_836 = 0;
    Term _t_446 = 1;
    if (_t_446 == 0) {
      _o_835 = 0;
    } else {
      _o_835 = 1;
      _o_836 = term_pak(CID_UNIT, 0);
    }
    Term _fv_3442[2];
    _fv_3442[0] = _o_835;
    _fv_3442[1] = _o_836;
    u32 _o_837 = 0;
    Term _o_838 = 0;
    Term _t_447 = 0;
    if (_t_447 == 0) {
      _o_837 = 0;
    } else {
      _o_837 = 1;
      _o_838 = term_pak(CID_UNIT, 0);
    }
    Term _fv_3443[2];
    _fv_3443[0] = _o_837;
    _fv_3443[1] = _o_838;
    Term _fv_3444[1];
    _fv_3444[0] = 100ull;
    Term _fv_3445[1];
    _fv_3445[0] = 101ull;
    Term _fv_3446[1];
    _fv_3446[0] = 102ull;
    Term _fv_3447[1];
    _fv_3447[0] = 103ull;
    Term _fv_3448[1];
    _fv_3448[0] = 104ull;
    Term _fv_3449[1];
    _fv_3449[0] = 105ull;
    Term _fv_3450[1];
    _fv_3450[0] = 106ull;
    Term _fv_3451[1];
    _fv_3451[0] = 107ull;
    Term _fv_3452[1];
    _fv_3452[0] = 108ull;
    Term _fv_3453[1];
    _fv_3453[0] = 109ull;
    Term _fv_3454[1];
    _fv_3454[0] = 110ull;
    Term _fv_3455[1];
    _fv_3455[0] = 111ull;
    Term _fv_3456[1];
    _fv_3456[0] = 112ull;
    Term _fv_3457[1];
    _fv_3457[0] = 113ull;
    Term _fv_3458[1];
    _fv_3458[0] = 114ull;
    Term _fv_3459[1];
    _fv_3459[0] = 115ull;
    Term _fv_3460[1];
    _fv_3460[0] = 200ull;
    Term _fv_3461[1];
    _fv_3461[0] = 201ull;
    Term _fv_3462[1];
    _fv_3462[0] = 202ull;
    Term _fv_3463[1];
    _fv_3463[0] = 203ull;
    Term _fv_3464[1];
    _fv_3464[0] = 204ull;
    Term _fv_3465[1];
    _fv_3465[0] = 205ull;
    Term _fv_3466[1];
    _fv_3466[0] = 206ull;
    Term _fv_3467[1];
    _fv_3467[0] = 207ull;
    Term _fv_3468[1];
    _fv_3468[0] = 208ull;
    Term _fv_3469[1];
    _fv_3469[0] = 209ull;
    Term _fv_3470[1];
    _fv_3470[0] = 210ull;
    Term _fv_3471[1];
    _fv_3471[0] = 211ull;
    Term _fv_3472[1];
    _fv_3472[0] = 212ull;
    Term _fv_3473[1];
    _fv_3473[0] = 213ull;
    Term _fv_3474[1];
    _fv_3474[0] = 214ull;
    Term _fv_3475[1];
    _fv_3475[0] = 215ull;
    Term _v_1014 = 0;
    Term _v_1015 = 0;
    Term _v_1016 = 0;
    Term _v_1017 = 0;
    Term _v_1018 = 0;
    Term _v_1019 = 0;
    u32 _v_1020 = 0;
    Term _v_1021 = 0;
    u32 _v_1022 = 0;
    Term _v_1023 = 0;
    Term _o_839[10];
    Term _a_190 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2900), blk_new(e, 1, 0, 1, 2, _fv_2901)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2918), blk_new(e, 1, 0, 1, 2, _fv_2935))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2952), blk_new(e, 1, 0, 1, 2, _fv_2969)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_2986), blk_new(e, 1, 0, 1, 2, _fv_3003)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_3020), blk_new(e, 1, 0, 1, 2, _fv_3037)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_3054), blk_new(e, 1, 0, 1, 2, _fv_3071))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_3088), blk_new(e, 1, 0, 1, 2, _fv_3105)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_3122), blk_new(e, 1, 0, 1, 2, _fv_3139)))));
    Term _a_191 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_3156), blk_new(e, 1, 0, 1, 2, _fv_3173)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_3190), blk_new(e, 1, 0, 1, 2, _fv_3207))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_3224), blk_new(e, 1, 0, 1, 2, _fv_3241)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_3258), blk_new(e, 1, 0, 1, 2, _fv_3275)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_3292), blk_new(e, 1, 0, 1, 2, _fv_3309)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_3326), blk_new(e, 1, 0, 1, 2, _fv_3343))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_3360), blk_new(e, 1, 0, 1, 2, _fv_3377)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_3394), blk_new(e, 1, 0, 1, 2, _fv_3411)))));
    Term _a_192 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3412), blk_new(e, 0, 0, 0, 1, _fv_3413)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3414), blk_new(e, 0, 0, 0, 1, _fv_3415))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3416), blk_new(e, 0, 0, 0, 1, _fv_3417)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3418), blk_new(e, 0, 0, 0, 1, _fv_3419)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3420), blk_new(e, 0, 0, 0, 1, _fv_3421)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3422), blk_new(e, 0, 0, 0, 1, _fv_3423))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3424), blk_new(e, 0, 0, 0, 1, _fv_3425)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3426), blk_new(e, 0, 0, 0, 1, _fv_3427)))));
    Term _a_193 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_3428), blk_new(e, 1, 0, 1, 2, _fv_3429)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_3430), blk_new(e, 1, 0, 1, 2, _fv_3431))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_3432), blk_new(e, 1, 0, 1, 2, _fv_3433)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_3434), blk_new(e, 1, 0, 1, 2, _fv_3435)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_3436), blk_new(e, 1, 0, 1, 2, _fv_3437)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_3438), blk_new(e, 1, 0, 1, 2, _fv_3439))), blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_3440), blk_new(e, 1, 0, 1, 2, _fv_3441)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_3442), blk_new(e, 1, 0, 1, 2, _fv_3443)))));
    Term _a_194 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3444), blk_new(e, 0, 0, 0, 1, _fv_3445)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3446), blk_new(e, 0, 0, 0, 1, _fv_3447))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3448), blk_new(e, 0, 0, 0, 1, _fv_3449)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3450), blk_new(e, 0, 0, 0, 1, _fv_3451)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3452), blk_new(e, 0, 0, 0, 1, _fv_3453)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3454), blk_new(e, 0, 0, 0, 1, _fv_3455))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3456), blk_new(e, 0, 0, 0, 1, _fv_3457)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3458), blk_new(e, 0, 0, 0, 1, _fv_3459)))));
    Term _a_195 = blk_node(e, blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3460), blk_new(e, 0, 0, 0, 1, _fv_3461)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3462), blk_new(e, 0, 0, 0, 1, _fv_3463))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3464), blk_new(e, 0, 0, 0, 1, _fv_3465)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3466), blk_new(e, 0, 0, 0, 1, _fv_3467)))), blk_node(e, blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3468), blk_new(e, 0, 0, 0, 1, _fv_3469)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3470), blk_new(e, 0, 0, 0, 1, _fv_3471))), blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3472), blk_new(e, 0, 0, 0, 1, _fv_3473)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_3474), blk_new(e, 0, 0, 0, 1, _fv_3475)))));
    Term _a_196 = term_pak(CID_NIL, 0);
    if (spin_19(e, _o_839, ((u64)15ull), 1ull, 16ull, 4ull, 15ull, 3, 7ull, _a_190, blk_loc(e.mem, _a_190), _a_191, blk_loc(e.mem, _a_191), _a_192, blk_loc(e.mem, _a_192), _a_193, blk_loc(e.mem, _a_193), _a_194, blk_loc(e.mem, _a_194), _a_195, blk_loc(e.mem, _a_195), _a_196, blk_loc(e.mem, _a_196)) == 0) {
      return 0;
    }
    _v_1014 = _o_839[0];
    _v_1015 = _o_839[1];
    _v_1016 = _o_839[2];
    _v_1017 = _o_839[3];
    _v_1018 = _o_839[4];
    _v_1019 = _o_839[5];
    _v_1020 = _o_839[6];
    _v_1021 = _o_839[7];
    _v_1022 = _o_839[8];
    _v_1023 = _o_839[9];
    _v_1004 = _v_1014;
    _v_1005 = _v_1015;
    _v_1006 = _v_1016;
    _v_1007 = _v_1017;
    _v_1008 = _v_1018;
    _v_1009 = _v_1019;
    _v_1010 = _v_1020;
    _v_1011 = _v_1021;
    _v_1012 = _v_1022;
    _v_1013 = _v_1023;
    u32 _v_1024 = 0;
    u32 _v_1025 = 0;
    Term _v_1026 = 0;
    Term _v_1027 = 0;
    Term _v_1028 = 0;
    Term _v_1029 = 0;
    Term _v_1030 = 0;
    Term _v_1031 = 0;
    u32 _v_1032 = 0;
    Term _v_1033 = 0;
    u32 _v_1034 = 0;
    Term _v_1035 = 0;
    u32 _v_1036 = 0;
    Term _v_1037 = 0;
    Term _v_1038 = 0;
    Term _v_1039 = 0;
    Term _o_840[16];
    Term _a_197 = term_pak(CID_NIL, 0);
    Term _a_198 = term_ctr(CID_OWNED, _nd_273);
    Term _a_199 = 123ull;
    if (spin_21(e, _o_840, 7ull, 999ull, _a_197, blk_loc(e.mem, _a_197), 1, _a_198, blk_loc(e.mem, _a_198), _a_199, blk_loc(e.mem, _a_199), _v_1004, blk_loc(e.mem, _v_1004), _v_1005, blk_loc(e.mem, _v_1005), _v_1006, blk_loc(e.mem, _v_1006), _v_1007, blk_loc(e.mem, _v_1007), _v_1008, blk_loc(e.mem, _v_1008), _v_1009, blk_loc(e.mem, _v_1009), _v_1010, _v_1011, _v_1012, _v_1013, blk_loc(e.mem, _v_1013)) == 0) {
      return 0;
    }
    _v_1024 = _o_840[0];
    _v_1025 = _o_840[1];
    _v_1026 = _o_840[2];
    _v_1027 = _o_840[3];
    _v_1028 = _o_840[4];
    _v_1029 = _o_840[5];
    _v_1030 = _o_840[6];
    _v_1031 = _o_840[7];
    _v_1032 = _o_840[8];
    _v_1033 = _o_840[9];
    _v_1034 = _o_840[10];
    _v_1035 = _o_840[11];
    _v_1036 = _o_840[12];
    _v_1037 = _o_840[13];
    _v_1038 = _o_840[14];
    _v_1039 = _o_840[15];
    _v_988 = _v_1024;
    _v_989 = _v_1025;
    _v_990 = _v_1026;
    _v_991 = _v_1027;
    _v_992 = _v_1028;
    _v_993 = _v_1029;
    _v_994 = _v_1030;
    _v_995 = _v_1031;
    _v_996 = _v_1032;
    _v_997 = _v_1033;
    _v_998 = _v_1034;
    _v_999 = _v_1035;
    _v_1000 = _v_1036;
    _v_1001 = _v_1037;
    _v_1002 = _v_1038;
    _v_1003 = _v_1039;
    u32 _o_841 = 0;
    Term _o_842 = 0;
    u32 _o_843 = 0;
    if (_v_1000 == 0) {
      _o_841 = 0;
    } else {
      _o_841 = 1;
      Term _fb_19[2];
      u64 _sp_19 = ctr_take(e, _v_1001, 2, _fb_19);
      Term _f_38 = _fb_19[0];
      u32 _f_39 = _fb_19[1];
      spare_free(e, cls_fit(2), _sp_19);
      _o_842 = _f_38;
      _o_843 = _f_39;
    }
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K287;
      WL_PUSHN(1);
    } else {
      u64 _t_448 = task_node(e, FID_MAIN_K287, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K287, _t_448);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SNAPSHOT)) {
      u64 _t_449 = task_node(e, FID_SNAPSHOT, WL_CONT, WL_IDX, 0);
      e.mem[_t_449 + 0] = _v_988;
      e.mem[_t_449 + 1] = _v_989;
      e.mem[_t_449 + 2] = _v_990;
      e.mem[_t_449 + 3] = _v_991;
      e.mem[_t_449 + 4] = _v_992;
      e.mem[_t_449 + 5] = _v_993;
      e.mem[_t_449 + 6] = _v_994;
      e.mem[_t_449 + 7] = _v_995;
      e.mem[_t_449 + 8] = _v_996;
      e.mem[_t_449 + 9] = _v_997;
      e.mem[_t_449 + 10] = _v_998;
      e.mem[_t_449 + 11] = _v_999;
      e.mem[_t_449 + 12] = _o_841;
      e.mem[_t_449 + 13] = _o_842;
      e.mem[_t_449 + 14] = _o_843;
      e.mem[_t_449 + 15] = _v_1002;
      e.mem[_t_449 + 16] = _v_1003;
      return term_tsk(FID_SNAPSHOT, _t_449);
    }
    r0 = _v_988;
    r1 = _v_989;
    r2 = _v_990;
    r3 = _v_991;
    r4 = _v_992;
    r5 = _v_993;
    r6 = _v_994;
    r7 = _v_995;
    r8 = _v_996;
    r9 = _v_997;
    r10 = _v_998;
    r11 = _v_999;
    r12 = _o_841;
    r13 = _o_842;
    r14 = _o_843;
    r15 = _v_1002;
    r16 = _v_1003;
    WL_JMP(FID_SNAPSHOT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K287)
  {
    Term _h_57 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K288;
      WL_PUSHN(1);
    } else {
      u64 _t_450 = task_node(e, FID_MAIN_K288, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K288, _t_450);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_451 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_451 + 0] = term_ctr(CID_SCON, STAT_OFF + 204);
      e.mem[_t_451 + 1] = _h_57;
      return term_tsk(FID_STRING_APPEND, _t_451);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 204);
    r1 = _h_57;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K288)
  {
    Term _h_58 = r0;
    WL_OPEN
    u64 _nd_306 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_306 + 0] = _h_58;
    r0 = term_clo(FID_MAIN_C289, _nd_306);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C289)
  {
    Term _h_59 = r0;
    Term _x_38 = r1;
    WL_OPEN
    u64 _nd_307 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_307 + 0] = _h_59;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_453 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_453 + 0] = term_clo(FID_IO_PRINT, _nd_307);
      e.mem[_t_453 + 1] = term_clo(FID_MAIN_C290, 0);
      e.mem[_t_453 + 2] = _x_38;
      return term_tsk(FID_IO_BIND, _t_453);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_307);
    r1 = term_clo(FID_MAIN_C290, 0);
    r2 = _x_38;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C290)
  {
    Term _x_39 = r0;
    WL_OPEN
    r0 = term_clo(FID_MAIN_C291, 0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C291)
  {
    Term _x_40 = r0;
    WL_OPEN
    Term _x_41 = term_pak(CID_UNIT, 0);
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_452 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_452 + 0] = _x_40;
      e.mem[_t_452 + 1] = _x_41;
      return term_tsk(FID_CLO_APPLY, _t_452);
    }
    r0 = _x_40;
    r1 = _x_41;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_PRINT)
  {
    Term _text_2 = r0;
    Term _k_2 = r1;
    WL_OPEN
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = _text_2;
    e.mem[_nd_2 + 1] = _k_2;
    r0 = term_ctr(CID_IO_PRINT, _nd_2);
    WL_RETN(1);
  }}
#endif

  WL_CASE(FID_ENTER)
  {
    Term t = r0;
    WL_OPEN
    u32 f   = (u32)term_aux(t);
    u64 a   = term_loc(t);
    u32 war = fid_arity(f);
    WL_FRAME(t)
    seq |= fid_nofk(f) << 1;
    u32 rw = fid_resw(f);
    if (rw) {
      WL_LOAD(a + war - rw, rw)
      WL_ARGS(a, war - rw + 1)
    } else {
      WL_LOAD(a, war)
    }
    heap_free(e, cls_fit(war + 2), a);
    WL_DYN(f);
  }}

  WL_CASE(FID_IO_EMIT)
  {
    Term x = r0;
    WL_OPEN
    u64 l = heap_alloc(e, 0);
    e.mem[l] = x;
    r0 = term_ctr(CID_EMIT, l);
    WL_RETN(1);
  }}

  WL_CASE(FID_CLO_APPLY)
  {
    Term fun = r0;
    Term arg = r1;
    WL_OPEN
    u32 f    = (u32)term_aux(fun);
    u32 war  = fid_arity(f) - 1;
    u64 a    = term_loc(fun);
    WL_LOAD(a, war)
    spare_free(e, cls_fit(war), a);
    WL_LAST(arg)
    WL_DYN(f);
  }}

  WL_CASE(FID_EXIT)
  {
    u32  n = rn;
    Term rv[WL_RESW];
    WL_SAVE(rv)
    WL_OPEN
    if (err_seen(e.mem)) {
      return 0;
    }
    sp -= 2 * LANE_STEP;
    Term cont = STK(0);
    u32  idx  = (u32)STK(1);
    u32  wf   = (u32)term_aux(cont);
    if (cont != TERM_HOLE && fid_resw(wf)) {
      u64 wa = term_loc(cont);
      u32 wn = fid_arity(wf);
      WL_FRAME(cont)
      seq = (seq & 1) | fid_nofk(wf) << 1;
      WL_ARGS(wa, wn - n + 1)
      heap_free(e, cls_fit(wn + 2), wa);
      WL_TAKE(rv)
      WL_DYN(wf);
    }
    return task_deliver(e.mem, cont, idx, rv, n);
  }}

#if DEVICE
  default: {
    err_post(e.mem, ERR_FIDS);
    return 0;
  }
  }
  }
}
#endif

// Monk
// ====

// One turn on a ring: its head task below put0 runs (a growing
// lane skips a fork-free one). The host grows a row ring by
// ring and drains a ring; a device lane does both.
INLINE u32 monk_step(Env e, DEV Term* stk, u32 rg, u32 put0, u32 base, u32 stride,
  TG u32* cur) {
  DEV u64* H   = e.mem;
  bool     seq = stride == 0;
  DEV u32* get = ring_get(H, rg);
  if (*get == put0) {
    return 0;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, rg, *get);
  u32      hi = a32_load_acq(lo + 1);
  Term     t  = (((u64)hi << 32) | a32_load(lo)) & ~RFC_BIT;
  if ((hi >> 31) != ring_lap(*get) || (!seq && fid_nofk((u32)term_aux(t)))) {
    return 0;
  }
  a32_store(get, *get + 1);
  u32 spin = 0;
  for (;;) {
    Term r = work_loop(e, stk, t, seq);
    if (r == 0) {
      return 2;
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      if (err_spun(H, &spin)) {
        return 2;
      }
      if (stride != 0 && fid_nofk((u32)term_aux(r))) {
        ring_push(H, ring_pick(base, stride, cur), r);
        return 2;
      }
      t      = r;
      seq    = false;
      stride = 0;
      continue;
    }
    task_deal(H, r, base, stride, cur);
    return 1;
  }
}

// Dev
// ===

// One kernel: pass 0 grows the frontier, pass 1 drains each lane's ring,
// pass 2 packs the banks: in one group, each bank's [top, wr) slides onto
// rd, CUBE_T entries a step (loads, barrier, stores: rd <= top), off the
// host's pages. A grow pass ends when its group is full or nothing grew,
// so a spine of forks unrolls whole. TG_HOLD words of threadgroup memory
// hold one group per Apple core (bitonic 1.35x without).

#if DEVICE

INLINE void dev_cut(Env e) {
  if (err_seen(e.mem)) {
    return;
  }
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    u64 gen = (u64)KEEP(c) << c;
    while (ALC_LEN(e, c) >= gen) {
      u64 head = ALC_AT(e, c);
      u64 tail = head;
      for (u32 i = 1; i < KEEP(c); i += 1) {
        tail = e.mem[tail];
      }
      ALC_AT(e, c)    = e.mem[tail];
      ALC_LEN(e, c)  -= gen;
      e.mem[tail]     = 0;
      bank_push(e.mem, c, head);
    }
  }
}

INLINE void bank_pack(DEV u64* H, u32 lane) {
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    DEV Bank* b  = bank_at(H, c);
    u32       rd = b->rd;
    u32       n  = b->wr - b->top;
    for (u32 i = 0; i < n; i += CUBE_T) {
      Term v = i + lane < n ? H[b->off + b->top + i + lane] : 0;
      BAR();
      if (i + lane < n) {
        H[b->off + rd + i + lane] = v;
      }
    }
    BAR();
    if (lane == 0) {
      b->rd = b->wr = b->top = rd + n;
    }
  }
}

#ifdef __METAL_VERSION__
kernel void bend_dev(DEV u64* H [[buffer(0)]], constant u32& pass [[buffer(1)]],
  TG u32* vote [[threadgroup(0)]],
  u32 grids [[threadgroups_per_grid]],
  u32 row [[threadgroup_position_in_grid]],
  u32 lane [[thread_position_in_threadgroup]]) {
#else
extern "C" __global__ void bend_dev(DEV u64* H, u32 pass) {
  extern __shared__ u32 vote[];
  u32 grids = gridDim.x;
  u32 row   = blockIdx.x;
  u32 lane  = threadIdx.x;
#endif
  if (pass == 2) {
    bank_pack(H, lane);
    return;
  }
  u32  stride = grids == 1 ? CUBE_G : 1;
  u32  me     = row * CUBE_T + stride * lane;
  u32 rg     = pass ? ring_flip(me) : me;
  Env  e      = { H, H + ALC_OFF + me };
  DEV Term*  stk    = (DEV Term*)(H + STAK_OFF + me);
  if (lane == 0) {
    for (u32 i = 0; i < 3; i += 1) {
      a32_store(vote + i, 0);
    }
  }
  BAR();
  u32 put0      = a32_load(ring_put(H, rg));
  u32 seen_has  = 0;
  u32 seen_grew = 0;
  for (;;) {
    if (pass) {
      if (*ring_get(H, rg) == put0 || err_seen(H)) {
        break;
      }
    } else {
      put0 = a32_load(ring_put(H, rg));
      u32 has = put0 != a32_load(ring_get(H, rg));
      if (lane == 0 && (err_seen(H) || root_done(H))) {
        has = CUBE_T;
      }
      a32_add(vote + 2, has);
      BAR();
      has = a32_load(vote + 2);
      if (has - seen_has >= CUBE_T) {
        break;
      }
      seen_has = has;
    }
    u32 ran = monk_step(e, stk, rg, put0, row * CUBE_T, pass ? 0 : stride,
      vote);
    if (!pass) {
      if (ran == 1) {
        a32_add(vote + 1, 1);
      }
      BARD();
      u32 grew = a32_load(vote + 1);
      if (grew == seen_grew) {
        break;
      }
      seen_grew = grew;
    }
  }
  dev_cut(e);
}

#endif

// Window
// ======

// Linux's window fill (the Mac's is window_msl): an Image is a quadtree over
// 2^k x 2^k (Qua splits tl, tr, bl, br; Pix is 0xRRGGBB).
#if defined(__linux__) || defined(BEND_RTC)

INLINE u32 window_pix(DEV u64* H, Term t, u32 k, u32 x, u32 y) {
  for (u32 i = k; term_tag(t) == TAG_CTR;) {
    u32 j = 0;
    if (i > 0) {
      i -= 1;
      j = ((y >> i) & 1) * 2 + ((x >> i) & 1);
    }
    t = H[term_peek(H, t) + j];
  }
  return (u32)term_loc(t) & 0xFFFFFF;
}

#ifdef BEND_RTC
extern "C" __global__ void window_dev(DEV u64* H, Term root, u32 w, u32 h,
  u32 k, u32* out) {
  u32 x = blockIdx.x * blockDim.x + threadIdx.x;
  u32 y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x < w && y < h) {
    out[y * w + x] = window_pix(H, root, k, x, y);
  }
}
#endif

#endif

#if !DEVICE

// Row
// ===

static u32 row_grow(Env e, DEV Term* stk, u32 base, u32 stride, u32 want) {
  u64* H = e.mem;
  u32 cur = 0;
  for (;;) {
    u32 put0[CUBE_T];
    u32 has = 0;
    for (u32 i = 0; i < CUBE_T; i += 1) {
      put0[i] = *ring_put(H, base + i * stride);
      has += put0[i] != *ring_get(H, base + i * stride);
    }
    if (root_done(H) || has >= want) {
      return cur;
    }
    u32 grew = 0;
    u32 ran  = 0;
    for (u32 i = 0; i < CUBE_T && ran != 2; i += 1) {
      ran   = monk_step(e, stk, base + i * stride, put0[i], base, stride,
        &cur);
      grew += ran == 1;
    }
    if (grew == 0) {
      return cur;
    }
  }
}

// Pool
// ====

static void* pool_try(void* at, u64 bytes) {
  return mmap(at, bytes, PROT_READ | PROT_WRITE,
    MAP_PRIVATE | MAP_ANON | MAP_NORESERVE, -1, 0);
}

static void* pool_mmap(u64 bytes) {
  void* p = pool_try(NULL, bytes);
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static Term* pool_stack(void) {
  u64   len = 1ull << 31;
  char* p   = pool_mmap(len + 16384 + SIGSTKSZ);
  if (mprotect(p + len, 16384, PROT_NONE) != 0) {
    err_fail("stack guard failed");
  }
  stack_t ss = { .ss_sp = p + len + 16384, .ss_size = SIGSTKSZ };
  sigaltstack(&ss, NULL);
  struct sigaction sa = { .sa_handler = err_trap, .sa_flags = SA_ONSTACK };
  sigaction(SIGSEGV, &sa, NULL);
  sigaction(SIGBUS, &sa, NULL);
  return (Term*)p;
}

// A wait yields a while before it sleeps, so a turn that ends (or follows)
// within microseconds never pays a condvar wake.

#define POOL_WAIT(c, cv) \
  for (u32 s = 0; s < 128 && (c); s += 1) { \
    sched_yield(); \
  } \
  pthread_mutex_lock(&pool_lock); \
  while (c) { \
    pthread_cond_wait(&cv, &pool_lock); \
  } \
  pthread_mutex_unlock(&pool_lock);

static u32 pool_step(u32 rows) {
  u32 per = rows * CUBE_T / (32 * pool_size);
  return CUBE_T >> (31 - CLZ(per < LINE ? per | 1 : LINE));
}

static u32 pool_rows(Env e, DEV Term* stk) {
  u32 n = 0;
  for (;;) {
    u32 c    = a32_add(&pool_row, 1);
    u32 r    = c & 32767;
    u32 rows = c >> 15 & 255;
    u32 step = c >> 23 & 1 ? 1 : pool_step(rows);
    if (r >= rows * step) {
      if (n != 0 && a32_sub_rel(&pool_done, n) == n) {
        pthread_mutex_lock(&pool_lock);
        pthread_cond_signal(&pool_join);
        pthread_mutex_unlock(&pool_lock);
      }
      return c >> 24;
    }
    a32_acq(&pool_row);
    if (c >> 23 & 1) {
      row_grow(e, stk, r * CUBE_T, 1, CUBE_T);
    } else {
      u32 row = r / step * CUBE_T;
      for (u32 rg = row + r % step; rg < row + CUBE_T; rg += step) {
        u32 put0 = a32_load(ring_put(e.mem, rg));
        while (*ring_get(e.mem, rg) != put0 && !err_seen(e.mem)) {
          monk_step(e, stk, rg, put0, rg, 0, NULL);
        }
      }
    }
    n += 1;
  }
}

static void* pool_work(void* arg) {
  Term* stk  = pool_stack();
  u32   seen = 0;
  for (;;) {
    POOL_WAIT(a32_load(&pool_row) >> 24 == seen, pool_wake)
    seen = pool_rows((Env){ CORPUS, ALC[(uintptr_t)arg] }, stk);
  }
}

OUTLINE void pool_open(void) {
  static bool up;
  if (up) {
    return;
  }
  up = true;
  for (u32 w = 1; w < pool_size; w += 1) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, pool_work, (void*)(uintptr_t)w)) {
      err_fail("pthread_create");
    }
  }
}

static int cpu_read(const char* path, long* a, long* b) {
  FILE* f = fopen(path, "r");
  if (f == NULL) {
    return 0;
  }
  int n = fscanf(f, "%ld %ld", a, b);
  fclose(f);
  return n;
}

static long cpu_count(void) {
  long n = sysconf(_SC_NPROCESSORS_ONLN);
#ifdef __linux__
  cpu_set_t set;
  if (sched_getaffinity(0, sizeof set, &set) == 0) {
    n = CPU_COUNT(&set);
  }
  long q = 0;
  long p = 0;
  if (cpu_read("/sys/fs/cgroup/cpu.max", &q, &p) != 2) {
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_quota_us", &q, &p);
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_period_us", &p, &p);
  }
  if (q > 0 && p > 0 && (q + p - 1) / p < n) {
    n = (q + p - 1) / p;
  }
#endif
  return n;
}

OUTLINE void pool_turn(bool grow, u32 rows) {
  static u32 turn;
  u32 n = rows < CUBE_G ? rows : CUBE_G;
  turn += 1;
  a32_store(&pool_done, grow ? n : n * pool_step(n));
  pthread_mutex_lock(&pool_lock);
  a32_store_rel(&pool_row, turn << 24 | grow << 23 | n << 15);
  pthread_cond_broadcast(&pool_wake);
  pthread_mutex_unlock(&pool_lock);
  pool_rows((Env){ CORPUS, ALC[0] }, io_stk);
  POOL_WAIT(a32_load_acq(&pool_done) != 0, pool_join)
}

// Gpu
// ===

// gpu_make compiles the device program into <binary>.gpu
// (--gpu-build): Metal's binary archive, or CUDA's cubin behind a
// hash of the text. A launch loads it, else notes and compiles. CUDA
// shapes the bag by the device: a group of 128 lanes per 64 KB of
// L2, a power of two in 16..128 (Apple keeps the tuned 128). CUDA
// runs one stream: the default 8 cost about half of the startup.

static const char* gpu_path(void) {
  static char path[4096];
  u32 n = sizeof path - 8;
#ifdef __APPLE__
  _NSGetExecutablePath(path, &n);
#else
  path[readlink("/proc/self/exe", path, n)] = 0;
#endif
  return strcat(path, ".gpu");
}

static void gpu_note(const char* path) {
  fprintf(stderr, "bend: compiling the GPU program (%s is missing or"
    " stale)\n", path);
}

#if !BEND_CUDA
#define gpu_map pool_mmap
#endif

#if BEND_METAL || BEND_CUDA

static void gpu_kernel(u32 pass, u32 groups);

static void gpu_run(u32 f) {
  if (f < CUBE_T) {
    gpu_kernel(0, 1);
  }
  if (f < LANES) {
    gpu_kernel(0, CUBE_G);
  }
  gpu_kernel(1, CUBE_G);
  gpu_kernel(2, 1);
}

#endif

#if BEND_CUDA

static u64 gpu_hash(void) {
  u64 key = 14695981039346656037ull ^ CUBE_LOG;
  for (const char* p = BEND_SRC; *p != 0; p += 1) {
    key = (key ^ (u8)*p) * 1099511628211ull;
  }
  return key;
}

#endif

#if BEND_METAL

static void gpu_fail(NSError* err) {
  err_fail([[err localizedDescription] UTF8String]);
}

static bool gpu_probe(void) {
  return (gpu_dev = MTLCreateSystemDefaultDevice()) != nil;
}

static MTLComputePipelineDescriptor* gpu_desc(void) {
  NSError* err = nil;
  MTLCompileOptions* opts = [MTLCompileOptions new];
  opts.mathMode = MTLMathModeSafe;
  opts.preprocessorMacros = @{ @"CUBE_LOG": @(CUBE_LOG) };
  id<MTLLibrary> lib = [gpu_dev newLibraryWithSource:@(BEND_SRC) options:opts
    error:&err];
  if (!lib) {
    gpu_fail(err);
  }
  MTLComputePipelineDescriptor* d = [MTLComputePipelineDescriptor new];
  d.computeFunction = [lib newFunctionWithName:@"bend_dev"];
  return d;
}

static bool gpu_make(const char* path) {
  NSError* err = nil;
  id<MTLBinaryArchive> ar = [gpu_dev
    newBinaryArchiveWithDescriptor:[MTLBinaryArchiveDescriptor new] error:&err];
  if (![ar addComputePipelineFunctionsWithDescriptor:gpu_desc() error:&err]) {
    gpu_fail(err);
  }
  return [ar serializeToURL:[NSURL fileURLWithPath:@(path)] error:&err];
}

static id<MTLComputePipelineState> gpu_pipe(MTLComputePipelineDescriptor* d,
  id<MTLBinaryArchive> ar) {
  NSError* err = nil;
  d.binaryArchives = ar ? @[ar] : @[];
  id<MTLComputePipelineState> pso = [gpu_dev
    newComputePipelineStateWithDescriptor:d
    options:ar ? MTLPipelineOptionFailOnBinaryArchiveMiss : 0 reflection:nil
    error:&err];
  if (!pso && !ar) {
    gpu_fail(err);
  }
  return pso;
}

static u64 gpu_span(void) {
  u64 span = [gpu_dev recommendedMaxWorkingSetSize];
  u64 most = [gpu_dev maxBufferLength];
  span = span < most ? span : most;
  return span < (2ull << 30) ? span : 2ull << 30;
}

static void gpu_load(u64 bytes) {
  gpu_buf = [gpu_dev newBufferWithBytesNoCopy:CORPUS length:bytes
    options:MTLResourceStorageModeShared
      | MTLResourceHazardTrackingModeUntracked deallocator:nil];
  u64 most = [gpu_dev maxBufferLength];
  if (!gpu_buf && bytes > most) {
    char msg[96];
    snprintf(msg, sizeof msg, "--gpu %lluMB is over the device's %lluMB",
      (unsigned long long)(bytes >> 20), (unsigned long long)(most >> 20));
    err_fail(msg);
  }
  if (!gpu_buf) {
    err_fail("the GPU span is more than the device has");
  }
  @autoreleasepool {
    gpu_que = [gpu_dev newCommandQueue];
    const char* path = gpu_path();
    MTLBinaryArchiveDescriptor* ad = [MTLBinaryArchiveDescriptor new];
    ad.url = [NSURL fileURLWithPath:@(path)];
    MTLComputePipelineDescriptor* d = gpu_desc();
    id<MTLBinaryArchive> ar = [gpu_dev newBinaryArchiveWithDescriptor:ad
      error:nil];
    gpu_pso = ar ? gpu_pipe(d, ar) : nil;
    if (!gpu_pso) {
      gpu_note(path);
      gpu_pso = gpu_pipe(d, nil);
    }
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  [gpu_enc setComputePipelineState:gpu_pso];
  [gpu_enc setBuffer:gpu_buf offset:0 atIndex:0];
  [gpu_enc setBytes:&pass length:sizeof pass atIndex:1];
  [gpu_enc setThreadgroupMemoryLength:TG_HOLD * 8 atIndex:0];
  [gpu_enc dispatchThreadgroups:MTLSizeMake(groups, 1, 1)
    threadsPerThreadgroup:MTLSizeMake(CUBE_T, 1, 1)];
  [gpu_enc memoryBarrierWithScope:MTLBarrierScopeBuffers];
}

static void gpu_pass(u32 f) {
  @autoreleasepool {
    id<MTLCommandBuffer> cb = [gpu_que commandBuffer];
    gpu_enc = [cb computeCommandEncoder];
    gpu_run(f);
    [gpu_enc endEncoding];
    [cb commit];
    [cb waitUntilCompleted];
    if ([cb error]) {
      gpu_fail([cb error]);
    }
  }
}

#elif BEND_CUDA

static void gpu_shape(int units) {
  CUBE_LOG = 31 - CLZ(units < 16 ? 16 : units > 128 ? 128 : units);
}

static bool gpu_probe(void) {
  int       managed = 0;
  CUcontext ctx;
  setenv("CUDA_DEVICE_MAX_CONNECTIONS", "1", 0);
  if (cuInit(0) == CUDA_SUCCESS && cuDeviceGet(&gpu_dev, 0) == CUDA_SUCCESS) {
    cuDeviceGetAttribute(&managed,
      CU_DEVICE_ATTRIBUTE_CONCURRENT_MANAGED_ACCESS, gpu_dev);
  }
  int l2 = 1 << 23;
  cuDeviceGetAttribute(&l2, CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE, gpu_dev);
  gpu_shape(l2 >> 16);
  return managed != 0
    && cuDevicePrimaryCtxRetain(&ctx, gpu_dev) == CUDA_SUCCESS
    && cuCtxSetCurrent(ctx) == CUDA_SUCCESS;
}

static u64* gpu_map(u64 bytes) {
  CUdeviceptr p = 0;
  if (cuMemAllocManaged(&p, bytes, CU_MEM_ATTACH_GLOBAL) != CUDA_SUCCESS) {
    err_fail("corpus reservation failed");
  }
#if CUDA_VERSION >= 13000
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION,
    (CUmemLocation){ CU_MEM_LOCATION_TYPE_DEVICE, gpu_dev });
#else
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION, gpu_dev);
#endif
  return (u64*)(uintptr_t)p;
}

static bool gpu_make(const char* path) {
  int cc[2] = {0, 0};
  cuDeviceGetAttribute(cc,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR, gpu_dev);
  cuDeviceGetAttribute(cc + 1,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR, gpu_dev);
  char arch[40];
  char bag[24];
  snprintf(arch, sizeof arch, "--gpu-architecture=sm_%d%d", cc[0], cc[1]);
  snprintf(bag, sizeof bag, "-DCUBE_LOG=%u", CUBE_LOG);
  const char* opts[] = { arch, bag, "--fmad=false", "-default-device" };
  nvrtcProgram prog;
  if (nvrtcCreateProgram(&prog, BEND_SRC, "bend.cu", 0, NULL, NULL)
    != NVRTC_SUCCESS) {
    err_fail("cannot compile the CUDA library");
  }
  if (nvrtcCompileProgram(prog, 4, opts) != NVRTC_SUCCESS) {
    size_t n = 0;
    nvrtcGetProgramLogSize(prog, &n);
    char* log = calloc(n + 1, 1);
    if (log != NULL && nvrtcGetProgramLog(prog, log) == NVRTC_SUCCESS) {
      fprintf(stderr, "%s\n", log);
    }
    err_fail("cannot compile the CUDA library");
  }
  size_t len = 0;
  nvrtcGetCUBINSize(prog, &len);
  char* bin = malloc(len);
  if (bin == NULL || nvrtcGetCUBIN(prog, bin) != NVRTC_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  nvrtcDestroyProgram(&prog);
  u64   key = gpu_hash();
  FILE* out = path == NULL ? NULL : fopen(path, "wb");
  bool  ok  = out != NULL && fwrite(&key, 8, 1, out) == 1
    && fwrite(bin, 1, len, out) == len && fclose(out) == 0;
  if (cuModuleLoadData(&gpu_lib, bin) != CUDA_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  free(bin);
  return path == NULL || ok;
}

static u64 gpu_span(void) {
  size_t span = 0;
  cuDeviceTotalMem(&span, gpu_dev);
  return span;
}

static void gpu_load(u64 bytes) {
  const char* path = gpu_path();
  int         fd   = open(path, O_RDONLY);
  struct stat st   = { 0 };
  u64         key  = 0;
  char*       bin  = fd < 0 || fstat(fd, &st) != 0 || st.st_size <= 8 ? NULL
    : mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
  if (bin != NULL && bin != MAP_FAILED) {
    memcpy(&key, bin, 8);
  }
  if (key != gpu_hash()
    || cuModuleLoadData(&gpu_lib, bin + 8) != CUDA_SUCCESS) {
    gpu_note(path);
    gpu_make(path);
  }
  if (cuModuleGetFunction(&gpu_pso, gpu_lib, "bend_dev") != CUDA_SUCCESS) {
    err_fail("cannot load the GPU program");
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  void* args[] = { &CORPUS, &pass };
  if (cuLaunchKernel(gpu_pso, groups, 1, 1, CUBE_T, 1, 1, TG_HOLD * 8, NULL,
    args, NULL) != CUDA_SUCCESS) {
    err_fail("device launch failed");
  }
}

static void gpu_pass(u32 f) {
  gpu_run(f);
  if (cuCtxSynchronize() != CUDA_SUCCESS) {
    err_fail("device fault");
  }
}

#else

#define gpu_probe() false
#define gpu_make(p) true
#define gpu_span()  0
#define gpu_load(b)
#define gpu_pass(f)

#endif

// Cube
// ====

// The host's column grows to the rows that give a LINE of tasks a thread,
// no more: every task a grow starts early is live at once (tree-matmul's
// 2048 at 16 threads start 384 rounds: 15 MB -> 68 MB), and pool_step
// splits the few rows finely instead. A turn visits only the rows below
// its bound: a drain deals task g to ring_flip(g), whose row is at most g,
// a row grows into itself, and a column grow's cur tasks land in rows 0
// to cur - 1, so those rows hold every task.

// Between turns, each ring's pending tasks move back to slot 0.

static void ring_rewind(u64* H, u32 rows) {
  Term keep[RING_LEN];
  for (u32 r = 0; r < (rows < CUBE_G ? rows : CUBE_G) * CUBE_T; r += 1) {
    u32 g = *ring_get(H, r);
    u32 n = *ring_put(H, r) - g;
    if (g == 0 || n > RING_LEN) {
      continue;
    }
    for (u32 i = 0; i < n; i += 1) {
      keep[i] = *ring_slot(H, r, g + i) & ~RFC_BIT;
    }
    for (u32 i = n; i < g + n && i < RING_LEN; i += 1) {
      ((u32*)ring_slot(H, r, i))[1] = 0;
    }
    *ring_get(H, r) = *ring_put(H, r) = 0;
    for (u32 i = 0; i < n; i += 1) {
      ring_push(H, r, keep[i]);
    }
  }
}

static void cube_run(u64* H, bool gpu) {
  for (;;) {
    u32 f = a32_exch(a32_at(H, H_CURSOR), 0);
    if (root_done(H)) {
      return;
    }
    if (f == 0) {
      err_fail("frontier drained without a result");
    }
    if (gpu) {
      gpu_pass(f);
    } else {
      u32 rows = f;
      u32 want = (pool_size - 1) / (CUBE_T / LINE) + 1;
      if (f < want) {
        u32 cur = row_grow((Env){ H, ALC[0] }, io_stk, 0, CUBE_G, want);
        rows = cur > f ? cur : f;
      }
      if (f < CUBE) {
        pool_turn(true, rows);
      }
      f = a32_load(a32_at(H, H_CURSOR));
      pool_turn(false, f > rows ? f : rows);
      f = a32_load(a32_at(H, H_CURSOR));
      ring_rewind(H, f > rows ? f : rows);
    }
    u32 ec = a32_load(a32_at(H, H_ERROR_CODE));
    if (ec != 0) {
      err_post(H, ec);
    }
  }
}

// Corpus
// ======

// The cores map 8 GiB at a high base and double it in place, so one
// base holds every location; the banks move up past the pages. The GPU maps
// its whole span at once, and never grows it.

static u64 corpus_size;

static void* corpus_map(u64 size) {
  u64   hint = 1ull << 45;
  void* p    = pool_try((void*)hint, size);
  while (p != (void*)hint && hint > size) {
    if (p != MAP_FAILED) {
      munmap(p, size);
    }
    hint /= 2;
    p     = pool_try((void*)hint, size);
  }
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static void corpus_lay(u64* H, u64 size) {
  u64 span = size / 8;
  u64 cap  = span > HEAP_OFF ? (span - HEAP_OFF) / (PAGE_LEN + 10) : 0;
  if (cap <= CUBE) {
    err_fail("the GPU span is under the rings, stacks and a page per lane");
  }
  cap = cap < ~0u ? cap : ~0u - 1;
  u64 at = HEAP_OFF + (cap << PAGE_BITS);
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    Bank* b = bank_at(H, c);
    memcpy(H + at, H + b->off, b->wr * sizeof(u64));
    b->off  = at;
    at     += 2 * (cap >> ((c < NCLS ? NCLS : c) - PAGE_BITS));
  }
  corpus_size = size;
  a32_store_rel(a32_at(H, H_CAP), (u32)cap);
}

static bool corpus_grow(u64* H, u64 need) {
  bool ok = true;
  LOCK(bank_lock);
  while (ok && need > a32_load(a32_at(H, H_CAP))) {
    u64   more = corpus_size;
    char* at   = (char*)H + more;
    void* got  = io_gpu || more >= 1ull << 43 ? MAP_FAILED
      : pool_try(at, more);
    ok = got == at;
    if (ok) {
      corpus_lay(H, more * 2);
    } else if (got != MAP_FAILED) {
      munmap(got, more);
    }
  }
  UNLOCK(bank_lock);
  return ok;
}

static u64* corpus_setup(bool gpu, long threads, u64 bytes) {
  io_gpu     = gpu;
  KEEP_WORDS = gpu ? CHUNK : CAP_WORDS;
  u64 dflt   = gpu ? gpu_span() : 1ull << 33;
  u64 size   = (gpu && bytes != 0 ? bytes : dflt) & ~16383ull;
  CORPUS     = gpu ? gpu_map(size) : corpus_map(size);
  u64* H     = CORPUS;
#if BEND_CUDA
  if (gpu) {
    cuMemsetD8((CUdeviceptr)(uintptr_t)H, 0, STAK_OFF * 8);
    cuCtxSynchronize();
  }
#endif
  corpus_lay(H, size);
  memcpy(H + STAT_OFF, STAT_IMG, STAT_LEN * sizeof(u64));
  a32_store(a32_at(H, H_BUMP), 1);
  if (gpu) {
    gpu_load(size);
  }
  pool_size = threads < 1 ? 1 : threads < CUBE_T ? threads : CUBE_T;
  return H;
}

OUTLINE Term corpus_eval(u64* H, Term t) {
  Env  e = { H, ALC[0] };
  Term rv[WL_RESW];
  for (;;) {
    Term r = work_loop(e, io_stk, t, !BANGS && pool_size == 1);
    if (r == 0) {
      if (root_done(H)) {
        break;
      }
      err_fail("solo delivery lost");
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      t = r;
      if (io_gpu && fid_bangs((u32)term_aux(t))) {
        u64  tl   = task_tail(t);
        Term cont = H[tl];
        u32  idx  = (u32)(H[tl + 1] >> 32) & 0xFFFF;
        H[tl]     = TERM_HOLE;
        a32_store(a32_at(H, H_CURSOR), 1);
        ring_push(H, 0, t);
        cube_run(H, true);
        Term p = task_deliver(H, cont, idx, rv, root_take(H, rv));
        if (root_done(H)) {
          break;
        }
        if (p == 0) {
          err_fail("seam delivery lost");
        }
        t = p;
      }
      continue;
    }
    task_deal(H, r, 0, 0, NULL);
    pool_open();
    cube_run(H, false);
    break;
  }
  root_take(H, rv);
  return rv[0];
}

// Io
// ==

// Base's opaque, linear handles pack host fds or pointers into aux and loc:
// no forging, copying, reuse or host wrapper. A request's cont applied to
// its item is the next request. A parked request keeps its fd, deadline and
// readiness in word, time and evts; the loop then calls pack: a value
// resumes, IO_PARK parks again. The edge is UTF-8, decoded as WHATWG does: a
// broken sequence yields one U+FFFD and its breaking byte is read again as a
// lead. inet_aton reads a leading zero as octal, so io_sys_addr refuses it.
// macOS poll misses FIFO EOF, so io_wait selects, its sets sized to the
// highest fd (_DARWIN_UNLIMITED_SELECT allows fds past FD_SETSIZE).

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define IO_READ 1
#define IO_TIME 2
#define IO_PARK TERM_HOLE

#define io_hand(v)   term_make(TAG_PAK, (u64)(v) >> 40, (u64)(v) & LOC_MASK)
#define io_hand_v(t) (((u64)term_aux(t) << 40) | term_loc(t))

struct IoWork;
typedef void (*IoCall)(struct IoWork* w);
typedef Term (*IoPack)(Env e, struct IoWork* w);

typedef struct IoWork {
  intptr_t       hand;
  intptr_t       made;
  u32            word;
  u64            size;
  char*          data;
  char*          text;
  u32            code;
  IoCall         call;
  IoPack         pack;
  Term           cont;
  Term           item;
  u64            time;
  short          evts;
  struct IoWork* next;
} IoWork;

typedef Term (*Effect)(Env e, Term* f, IoWork* w);

typedef struct {
  Effect run;
  u32    ask;
} IoEff;

static IoEff io_eff_rows[1 << 16];
static u32   io_live;

static u64 io_tick(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}

OUTLINE void* io_mem(void* mem) {
  if (mem == NULL) {
    err_fail("host allocation failed");
  }
  return mem;
}

static int io_sys_addr(const char* host, u32 port, struct sockaddr_in* at) {
  memset(at, 0, sizeof(*at));
  at->sin_family = AF_INET;
  at->sin_port   = htons((uint16_t)port);
  for (const char* p = host; *p != 0; p += 1) {
    if ((p == host || p[-1] == '.') && *p == '0'
      && p[1] >= '0' && p[1] <= '9') {
      return -1;
    }
  }
  return port > 65535 || inet_pton(AF_INET, host, &at->sin_addr) != 1
    ? -1 : 0;
}

static int    io_argc;
static char** io_argv;

static void io_eff(u32 cid, Effect run, u32 need) {
  if (io_eff_rows[cid].run != NULL) {
    err_fail("two effects register one request");
  }
  io_eff_rows[cid] = (IoEff){ run, need };
}

static u64 io_sys_end(IoWork* w, ssize_t n) {
  w->code = n < 0 ? (u32)errno : 0;
  return n < 0 ? 0 : (u64)n;
}

static IoWork* io_runs;
static IoWork* io_park;
static IoWork* io_jobs;

static void io_push(IoWork** q, IoWork* a) {
  IoWork* l = *q != NULL ? *q : a;
  a->next = l->next;
  l->next = a;
  *q      = a;
}

static IoWork* io_pop(IoWork** q) {
  IoWork* a  = (*q)->next;
  (*q)->next = a->next;
  *q         = a != *q ? *q : NULL;
  return a;
}

static void io_spawn(Term m) {
  IoWork* a = io_mem(calloc(1, sizeof(IoWork)));
  a->cont  = m;
  a->item  = term_clo(FID_IO_EMIT, 0);
  io_push(&io_runs, a);
  io_live += 1;
}

// io_park stays in deadline order (time 0, none, sorts last; ties keep
// their park order), so io_wait wakes due timers in the order they expire.
static void io_park_add(IoWork* w) {
  IoWork* p = io_park;
  if (p == NULL || p->time - 1 <= w->time - 1) {
    io_push(&io_park, w);
    return;
  }
  while (p->next->time - 1 <= w->time - 1) {
    p = p->next;
  }
  io_push(&p, w);
}

static Term io_wait_on(IoWork* w, int fd, short evts, u64 time, IoPack more) {
  w->word = (u32)fd;
  w->pack = more;
  w->time = time;
  w->evts = evts;
  io_park_add(w);
  return IO_PARK;
}

OUTLINE void io_out(FILE* h, const char* data, u64 len) {
  if (fwrite(data, 1, len, h) != len) {
    err_fail("a short write on a standard stream");
  }
}

OUTLINE void io_sync(void) {
  if (fflush(stdout) != 0) {
    err_fail("a short write on a standard stream");
  }
}

static u64 io_utf8(char* buf, u64 c) {
  u64 k = c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
  for (u64 i = k; i > 1; i -= 1) {
    buf[i - 1] = (char)(0x80 | (c & 0x3F));
    c >>= 6;
  }
  buf[0] = (char)(k == 1 ? c : (0xF00 >> k) | c);
  return k;
}

// io_cbuf writes a String (cons SCon) as UTF-8, or a List (cons Con) as
// its bytes, with no UTF-8: NULL if a value is past 255.
OUTLINE char* io_cbuf(Env e, Term s, u64* len, u64 cons) {
  u64   cap = 64;
  u64   n   = 0;
  u64   bad = 0;
  char* buf = io_mem(malloc(cap));
  while (term_aux(s) == cons) {
    Term fb[2];
    spare_free(e, cls_fit(2), ctr_take(e, s, 2, fb));
    if (n + 5 > cap) {
      cap *= 2;
      buf = io_mem(realloc(buf, cap));
    }
    if (cons == CID_SCON) {
      n += io_utf8(buf + n, fb[0]);
    } else {
      bad |= fb[0] > 255;
      buf[n++] = (char)fb[0];
    }
    s = fb[1];
  }
  buf[n] = 0;
  *len = n;
  if (bad) {
    free(buf);
    return NULL;
  }
  return buf;
}

#define io_cstr(e, s, len) io_cbuf(e, s, len, CID_SCON)

OUTLINE void io_errs(Env e, Term s) {
  u64   n    = 0;
  char* text = io_cstr(e, s, &n);
  io_sync();
  io_out(stderr, text, n);
  io_out(stderr, "\n", 1);
  free(text);
}

#define io_nul(s, n) (strlen(s) != (n))

#define io_seal(e, t, cid) (cid_hot(cid) ? rfc_seal(e, t) : (t))

static Term io_node(Env e, u64 cid, Term a, Term b) {
  u64 l = heap_alloc(e, 1);
  e.mem[l]     = io_seal(e, a, cid);
  e.mem[l + 1] = io_seal(e, b, cid);
  return term_ctr(cid, l);
}

static Term io_str(Env e, const char* p, u64 n) {
  Term s    = term_pak(CID_SNIL, 0);
  u64  hole = 0;
  u64  c = 0, need = 0, lo = 0x80, hi = 0xBF;
  for (u64 i = 0; i < n || need > 0; i += 1) {
    u64 b = i < n ? (uint8_t)p[i] : 0x100;
    if (need > 0 && (b < lo || b > hi)) {
      need = 0;
      c    = 0xFFFD;
      i   -= 1;
    } else if (need > 0) {
      lo = 0x80;
      hi = 0xBF;
      c  = (c << 6) | (b & 0x3F);
      if (--need > 0) {
        continue;
      }
    } else if (b < 0x80) {
      c = b;
    } else if (b < 0xC2 || b > 0xF4) {
      c = 0xFFFD;
    } else {
      need = b < 0xE0 ? 1 : b < 0xF0 ? 2 : 3;
      lo   = b == 0xE0 ? 0xA0 : b == 0xF0 ? 0x90 : 0x80;
      hi   = b == 0xED ? 0x9F : b == 0xF4 ? 0x8F : 0xBF;
      c    = b & (0x3F >> need);
      continue;
    }
    u64  l = heap_alloc(e, 1);
    Term t = term_ctr(CID_SCON, l);
    e.mem[l] = c;
    if (hole == 0) {
      s = t;
    } else {
      e.mem[hole] = io_seal(e, t, CID_SCON);
    }
    hole = l + 1;
  }
  if (hole != 0) {
    e.mem[hole] = io_seal(e, term_pak(CID_SNIL, 0), CID_SCON);
  }
  return s;
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8.
#ifdef CID_CON

static Term io_list(Env e, const char* p, u64 n) {
  Term xs = term_pak(CID_NIL, 0);
  for (u64 i = n; i > 0; i -= 1) {
    xs = io_node(e, CID_CON, (uint8_t)p[i - 1], xs);
  }
  return xs;
}

#endif

#define io_tup(e, a, b) io_node(e, CID_TUPLE, a, b)
#define io_done(e, v)   io_box(e, CID_DONE, v)
#define io_res(e, w, v) ((w)->code ? io_fail(e, (w)->code, NULL) \
  : io_done(e, v))

static Term io_box(Env e, u64 cid, Term v) {
  u64 l = heap_alloc(e, 0);
  e.mem[l] = io_seal(e, v, cid);
  return term_ctr(cid, l);
}

static Term io_fail(Env e, u32 code, const char* text) {
  const char* s = text != NULL ? text : strerror((int)code);
  Term t = io_tup(e, code, io_str(e, s, strlen(s)));
  return io_box(e, CID_FAIL, t);
}

static pthread_mutex_t io_gate = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  io_bell = PTHREAD_COND_INITIALIZER;
static u32             io_busy;
static u32             io_size;
static int             io_wake_fd[2];

static void io_take(Env e) {
  IoWork* acts[64];
  ssize_t n;
  while ((n = read(io_wake_fd[0], acts, sizeof acts)) > 0) {
    for (u32 i = 0; i < (u32)n / sizeof(IoWork*); i += 1) {
      IoWork* a = acts[i];
      a->item   = a->pack(e, a);
      io_push(&io_runs, a);
      io_busy -= 1;
    }
  }
}

static void* io_help(void* arg) {
  for (;;) {
    pthread_mutex_lock(&io_gate);
    while (io_jobs == NULL) {
      pthread_cond_wait(&io_bell, &io_gate);
    }
    IoWork* a = io_pop(&io_jobs);
    pthread_mutex_unlock(&io_gate);
    a->call(a);
    while (write(io_wake_fd[1], &a, sizeof a) != sizeof a) {
    }
  }
}

static Term io_work(IoWork* w, IoCall call, IoPack pack) {
  w->call  = call;
  w->pack  = pack;
  io_busy += 1;
  if (io_busy > io_size && io_size < IO_HELP) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, io_help, NULL)) {
      err_fail("pthread_create");
    }
    pthread_detach(tid);
    io_size += 1;
  }
  pthread_mutex_lock(&io_gate);
  io_push(&io_jobs, w);
  pthread_cond_signal(&io_bell);
  pthread_mutex_unlock(&io_gate);
  return IO_PARK;
}

static Term io_exec(Env e, IoWork* w) {
  Term fs[256];
  u32  c = (u32)term_aux(w->cont);
  u32  n = cid_arity(c);
  spare_free(e, cls_fit(n), ctr_take(e, w->cont, n, fs));
  w->cont = fs[n - 1];
  return io_eff_rows[c].run(e, fs, w);
}

static bool io_bit(u8* set, int fd, bool put) {
  u8* at = set + fd / 8;
  *at |= put << fd % 8;
  return *at >> fd % 8 & 1;
}

static void io_wait(Env e, bool block) {
  int top  = io_wake_fd[0];
  u64 soon = io_park != NULL ? io_park->next->time : 0;
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0 && (int)a->word > top) {
      top = (int)a->word;
    }
  }
  u64 len = (u64)top / 64 * 8 + 8;
  u8* set[2] = { io_mem(calloc(2, len)), NULL };
  set[1] = set[0] + len;
  io_bit(set[0], io_wake_fd[0], true);
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0) {
      io_bit(set[a->evts == POLLOUT], (int)a->word, true);
    }
  }
  u64 tick = io_tick();
  u64 ms = soon > tick && block ? (soon - tick) / 1000000 + 1 : 0;
  struct timeval tv = { ms / 1000, ms % 1000 * 1000 };
  io_sync();
  if (select(top + 1, (fd_set*)set[0], (fd_set*)set[1], NULL,
    soon == 0 && block ? NULL : &tv) < 0) {
    if (errno != EINTR) {
      err_fail("the poller failed");
    }
    memset(set[0], 0, 2 * len);
  }
  if (io_bit(set[0], io_wake_fd[0], false)) {
    io_take(e);
  }
  u64     now  = io_tick();
  IoWork* todo = io_park;
  io_park = NULL;
  while (todo != NULL) {
    IoWork* a   = io_pop(&todo);
    bool    due = (a->evts != 0
        && io_bit(set[a->evts == POLLOUT], (int)a->word, false))
      || (a->time != 0 && a->time <= now);
    if (!due) {
      io_park_add(a);
      continue;
    }
    Term x = a->pack(e, a);
    if (x != IO_PARK) {
      a->item = x;
      io_push(&io_runs, a);
    }
  }
  free(set[0]);
}

static int f32_text(char* buf, f32 v) {
  int n = 0;
  int p = 0;
  if (v != v) {
    return sprintf(buf, "nan");
  }
  for (; p < 9; p += 1) {
    n = snprintf(buf, 40, "%.*e", p, (double)v);
    if (strtof(buf, NULL) == v) {
      break;
    }
  }
  char* ep = strchr(buf, 'e');
  if (ep == NULL) {
    return n;
  }
  int ex = atoi(ep + 1);
  if (ex >= 21 || ex <= -7) {
    n = (int)(ep - buf) + sprintf(ep, "e%c%d", ex < 0 ? '-' : '+', abs(ex));
  } else if (ex <= p) {
    n = snprintf(buf, 40, "%.*f", p - ex, (double)v);
  } else {
    int s = *buf == '-';
    memmove(buf + s + 1, buf + s + 2, p);
    memset(buf + s + 1 + p, '0', ex - p);
    n = s + 1 + ex;
  }
  return n;
}

static Term f32_show(Env e, Term x) {
  char buf[40];
  return io_str(e, buf, f32_text(buf, f32_unbox(x)));
}

static Term f32_read(Env e, Term s) {
  u64 n = 0;
  char* text = io_cstr(e, s, &n);
  char* end;
  f32 v = strtof(text, &end);
  Term out = n > 0 && (u64)(end - text) == n && strpbrk(text, "xX(") == NULL
    ? io_box(e, CID_SOME, f32_rewrap(v)) : term_pak(CID_NONE, 0);
  free(text);
  return out;
}


// Show
// ====

// show_val prints a pure main's value as term_show spells it: d
// is a SHOW_DESC node (see show_main), w its words, and chain the
// bracket of the [a, b] or (a, b) the value continues, or 0. Con
// or Nil spell a list, Tuple a tuple, and their tails continue
// it. show_chr escapes as char_show does; show_f32 prints the
// shortest text that reads back, with a point before an e.

#if MAIN_PURE

static void show_val(Env e, u32 d, const Term* w, char chain);

static void show_chr(u64 c, char q) {
  char b[4];
  int  k = c == 10 ? 'n' : c == 9 ? 't' : c == 13 ? 'r' : c == 0 ? '0'
    : c == 92 || c == (u64)q ? (int)c : 0;
  if (k != 0) {
    printf("\\%c", k);
  } else if (c < 32 || c == 127 || (c >= 0xD800 && c <= 0xDFFF)
    || c > 0x10FFFF) {
    printf("\\u{%llx}", (unsigned long long)c);
  } else {
    fwrite(b, 1, io_utf8(b, c), stdout);
  }
}

static void show_f32(u32 x) {
  char  buf[40];
  int   n  = f32_text(buf, f32_unbox(x));
  char* ep = memchr(buf, 'e', n);
  int   m  = ep == NULL ? n : (int)(ep - buf);
  buf[n] = 0;
  if (strpbrk(buf, ".ni") == NULL) {
    printf("%.*s.0%s", m, buf, buf + m);
  } else {
    fputs(buf, stdout);
  }
}

static void show_val(Env e, u32 d, const Term* w, char chain) {
  const u32* D = SHOW_DESC;
  Term one;
  char zs[4];
  u32  zn = 0;
  for (bool tail = true; tail;) switch (tail = false, D[d]) {
    case 0:
      printf("%u", (u32)w[0]);
      break;
    case 1:
      show_f32((u32)w[0]);
      break;
    case 2:
      printf("%llun", (unsigned long long)w[0]);
      break;
    case 3:
      putchar('\'');
      show_chr(D[d + 1] != 0 ? term_loc(w[0]) : w[0], '\'');
      putchar('\'');
      break;
    case 4:
      putchar('"');
      for (Term s = w[0]; term_aux(s) == CID_SCON;) {
        u64 l = term_peek(e.mem, s);
        show_chr(e.mem[l], '"');
        s = e.mem[l + 1];
      }
      putchar('"');
      break;
    case 5:
      fputs("{==}", stdout);
      break;
    case 6:
      putchar('[');
      for (u32 i = 0, g = D[d + 2]; i < 1u << (blk_cls(w[0]) - g); i += 1) {
        Term v[1u << g];
        for (u32 j = 0; j < 1u << g; j += 1) {
          v[j] = blk_read(e.mem, term_tag(w[0]) == TAG_ARR,
            term_peek(e.mem, w[0]), (i << g) + j);
        }
        fputs(i > 0 ? ", " : "", stdout);
        show_val(e, D[d + 1], v, 0);
      }
      putchar(']');
      break;
    default: {
      Term t   = w[0];
      bool box = D[d + 1] != 0;
      u32  key = box ? (u32)term_aux(t) : D[d + 2] > 1 ? (u32)t : 0;
      u32  a   = d + 3;
      for (u32 i = 0; box ? D[a + 1] != key : i != key; i += 1) {
        a += 4 + 2 * D[a + 2];
      }
      if (box) {
        one = term_loc(t);
        w   = term_tag(t) == TAG_PAK ? &one : e.mem + term_peek(e.mem, t);
      }
      char o = "{[("[D[a + 3]];
      if (o == '{') {
        printf("%s{", SHOW_NAMES[D[a]]);
      } else if (chain != o) {
        putchar(o);
      }
      if (o == '{' || chain != o) {
        zs[zn++] = "}])"[D[a + 3]];
      }
      for (u32 j = 0; j < D[a + 2]; j += 1) {
        if (o == '[' ? j == 0 && chain == o : j > 0) {
          fputs(", ", stdout);
        }
        if (j == 1 && o != '{') {
          tail  = true;
          chain = o;
          d     = D[a + 5 + 2 * j];
          w     = w + D[a + 4 + 2 * j];
        } else {
          show_val(e, D[a + 5 + 2 * j], w + D[a + 4 + 2 * j], 0);
        }
      }
    }
  }
  while (zn > 0) {
    putchar(zs[--zn]);
  }
}

#endif

// Run
// ===

static void io_step(Env e, IoWork* a) {
  for (;;) {
    u64  ap  = task_node(e, FID_CLO_APPLY, TERM_HOLE, 0, 0);
    e.mem[ap]     = a->cont;
    e.mem[ap + 1] = a->item;
    Term req = corpus_eval(e.mem, term_tsk(FID_CLO_APPLY, ap));
    u32  c   = (u32)term_aux(req);
    u64  at  = term_peek(e.mem, req);
    if (c == CID_EMIT) {
      term_drop(e, req);
      free(a);
      io_live -= 1;
      return;
    }
    if (c == CID_HALT) {
      io_errs(e, e.mem[at + 1]);
      exit((int)(u32)e.mem[at]);
    }
    if (io_eff_rows[c].run == NULL) {
      err_fail("an alien request");
    }
    u32 need = io_eff_rows[c].ask;
    u32 word = (u32)(need & IO_READ ? io_hand_v(e.mem[at]) : e.mem[at]);
    a->cont  = req;
    if (need != 0) {
      io_wait_on(a, (int)word, need & IO_READ ? POLLIN : 0,
        need & IO_TIME ? io_tick() + (u64)word * 1000000ull : 0, io_exec);
      return;
    }
    Term x = io_exec(e, a);
    if (x == IO_PARK) {
      return;
    }
    a->item = x;
  }
}

OUTLINE void io_loop(u64* H) {
  Env e = { H, ALC[0] };
  io_stk = pool_stack();
  signal(SIGPIPE, SIG_IGN);
  if (pipe(io_wake_fd) | fcntl(io_wake_fd[0], F_SETFL, O_NONBLOCK)) {
    err_fail("the event loop failed to open");
  }
  Term m = corpus_eval(H, term_tsk(MAIN_FID, task_node(e, MAIN_FID,
    TERM_HOLE, 0, 0)));
#if MAIN_PURE
  show_val(e, 0, H + H_ROOT_WORD, 0);
  putchar('\n');
  return;
#endif
  io_spawn(m);
  u64 look = 0;
  for (u32 n = 0;; n += 1) {
    if (io_runs == NULL) {
      if (io_live == 0) {
        return;
      }
      if (io_park == NULL && io_busy == 0) {
        io_sync();
        err_fail("deadlock: every computation waits on a channel");
      }
      io_wait(e, true);
      continue;
    }
    if ((n & 63) == 0 && io_busy != 0) {
      io_take(e);
    }
    // A busy loop still checks due timers, and fds periodically.
    if ((n & 63) == 0 && io_park != NULL) {
      u64 now = io_tick();
      if (now >= look || io_park->next->time - 1 < now) {
        look = now + 10000000;
        io_wait(e, false);
      }
    }
    io_step(e, io_pop(&io_runs));
  }
}

// Requests
// ========

// IO
// ==

Term io_print_run(Env e, Term* f, IoWork* w) {
  uint64_t n = 0;
  char* text = io_cstr(e, f[0], &n);
  io_out(stdout, text, n);
  io_out(stdout, "\n", 1);
  free(text);
  return term_pak(CID_UNIT, 0);
}

static void __attribute__((constructor)) io_print_use(void) {
  io_eff(CID_IO_PRINT, io_print_run, 0);
}


// Main
// ====

int main(int argc, char** argv) {
  long thr = 0;
  int  gpu = -1;
  u64  mem = 0;
  io_argv = argv;
  io_argc = 1;
  for (int i = 1; i < argc; i += 1) {
    const char* a = argv[i];
    const char* v = i + 1 < argc ? argv[i + 1] : NULL;
    if (strcmp(a, "--") == 0) {
      while (i + 1 < argc) {
        io_argv[io_argc++] = argv[++i];
      }
    } else if (strcmp(a, "--bend-help") == 0) {
      printf(CLI_HELP, argv[0]);
      return 0;
    } else if (strcmp(a, "--gpu-build") == 0) {
      if (gpu_probe() && !gpu_make(gpu_path())) {
        fprintf(stderr, "bend: cannot write %s\n", gpu_path());
        return 1;
      }
      return 0;
    } else if (strcmp(a, "--threads") == 0) {
      char* end = NULL;
      thr = v != NULL ? strtol(v, &end, 10) : 0;
      if (thr < 1 || *end != '\0') {
        err_fail("expected a thread count of 1 or more after --threads");
      }
      i += 1;
    } else if (strcmp(a, "--gpu") == 0) {
      char*  end = NULL;
      double n   = v != NULL ? strtod(v, &end) : 0;
      u64    mul = end == NULL ? 0 : strcmp(end, "GB") == 0 ? 1ull << 30
        : strcmp(end, "MB") == 0 ? 1ull << 20 : 0;
      if (v != NULL && strcmp(v, "off") == 0) {
        gpu = 0;
      } else if (v != NULL && (strcmp(v, "on") == 0 || (mul != 0 && n > 0))) {
        gpu = 1;
        mem = (u64)(n * (double)mul);
      } else {
        err_fail("expected on, off or a size like 4GB after --gpu");
      }
      i += 1;
    } else {
      io_argv[io_argc++] = argv[i];
    }
  }
  bool dev = gpu != 0 && BANGS != 0 && gpu_probe();
  if (gpu == 1 && BANGS != 0 && !dev) {
    err_fail("--gpu on, but this binary found no usable GPU (a CUDA GPU needs"
      " concurrent managed access, which WSL2's lack)");
  }
  io_loop(corpus_setup(dev, thr > 0 ? thr : cpu_count(), mem));
  io_sync();
  return 0;
}

#endif
