function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

for (const k of ["IO.print"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $IO$print$(($returned$(($query$058each$1260$({$: "query.Required"}, {$: "storage.World", "namespace": 7, "next": 2, "rows": {$: "storage.Rows", "main": [{$: "Some", "value": {$: "Owned", "items": [1000], "scalar": 1}}], "aux": [{$: "Some", "value": {$: "Owned", "items": [101000], "scalar": 101}}], "metadata": {$: "storage.MetadataColumns", "live": [true], "flags": [{$: "Some", "value": {$: "Unit"}}], "added": [100], "changed": [200]}, "capacity": 1, "depth": 0, "high_water": 1}, "pending": {$: "Nil"}, "ledger": {$: "Some", "value": {$: "Owned", "items": [999000], "scalar": 999}}, "mode": 123})))), _x_1), run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $IO$pure$({$: "Unit"}, _x_3);
});
}), _x_0);
});
}

function $IO$bind$(_m_0, _f_0, _k_0) {
  return run_tail(_m_0, run_clo((_x_0) => {
  return run_tail(_f_0(_x_0), _k_0);
}));
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $returned$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Con") {
    const _text_0 = _t_0["head"];
    const _t_1 = _t_0["tail"];
    if (_t_1.$ === "Nil") {
      const _x_0 = ($snapshot$({$: "Tuple", "fst": _world_0, "snd": {$: "Nil"}}));
      const _x_1 = ("|" + _x_0);
      return (_text_0 + _x_1);
    } else {
      return "unexpected-result";
    }
  } else {
    return "unexpected-result";
  }
}

function $query$058each$1260$(_selection_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["next"];
  const _rows_0 = _world_0["rows"];
  const _pending_0 = _world_0["pending"];
  const _ledger_0 = _world_0["ledger"];
  const _mode_0 = _world_0["mode"];
  return $query$058each_return$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, ($query$058read_rows$1260$(_rows_0, _selection_0, _namespace_0)));
}

function $IO$pure$(_x_0, _k_0) {
  return run_tail(_k_0, _x_0);
}

function $snapshot$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["next"];
  const _rows_0 = _t_0["rows"];
  const _t_1 = _t_0["pending"];
  if (_t_1.$ === "Nil") {
    const _t_2 = _t_0["ledger"];
    if (_t_2.$ === "Some") {
      const _ledger_0 = _t_2["value"];
      const _mode_0 = _t_0["mode"];
      const _values_0 = _result_0["snd"];
      return $snapshot_rows$(_ns_0, _next_0, _ledger_0, _mode_0, _values_0, _rows_0);
    } else {
      return "unexpected-context";
    }
  } else {
    return "unexpected-context";
  }
}

function $query$058each_return$(_namespace_0, _next_0, _pending_0, _ledger_0, _mode_0, _result_0) {
  const _rows_0 = _result_0["fst"];
  const _observations_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "storage.World", "namespace": _namespace_0, "next": _next_0, "rows": _rows_0, "pending": _pending_0, "ledger": _ledger_0, "mode": _mode_0}, "snd": _observations_0};
}

function $query$058read_rows$1260$(_rows_0, _selection_0, _namespace_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _t_0 = _rows_0["metadata"];
  const _live_0 = _t_0["live"];
  const _flags_0 = _t_0["flags"];
  const _added_0 = _t_0["added"];
  const _changed_0 = _t_0["changed"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $query$058struct_idx_go$1260$(_high_0, 1, _capacity_0, _depth_0, _high_0, _selection_0, _namespace_0, {$: "query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": {$: "Nil"}});
}

function $snapshot_rows$(_ns_0, _next_0, _ledger_0, _mode_0, _values_0, _rows_0) {
  const _main_0 = _rows_0["main"];
  const _aux_0 = _rows_0["aux"];
  const _t_0 = _rows_0["metadata"];
  const _live_0 = _t_0["live"];
  const _flag_0 = _t_0["flags"];
  const _added_0 = _t_0["added"];
  const _changed_0 = _t_0["changed"];
  const _capacity_0 = _rows_0["capacity"];
  const _depth_0 = _rows_0["depth"];
  const _high_0 = _rows_0["high_water"];
  return $snapshot_fields$(_ns_0, _next_0, _capacity_0, _depth_0, _high_0, _live_0, _flag_0, _added_0, _changed_0, _mode_0, _values_0, {$: "Tuple", "fst": ($owners$(_main_0)), "snd": {$: "Tuple", "fst": ($owners$(_aux_0)), "snd": ($owned$(_ledger_0))}});
}

function $query$058struct_idx_go$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _id_0 = $1;
      const _capacity_0 = $2;
      const _depth_0 = $3;
      const _high_0 = $4;
      const _selection_0 = $5;
      const _namespace_0 = $6;
      const _state_0 = $7;
      if (_remaining_0 === 0) {
        return $query$058struct_cols_finish$(_capacity_0, _depth_0, _high_0, _state_0);
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = ((_id_0 + 1) >>> 0);
        $2 = _capacity_0;
        $3 = _depth_0;
        $4 = _high_0;
        $5 = _selection_0;
        $6 = _namespace_0;
        $7 = ($query$058struct_idx_advance$1260$(($Bool$and$((0 < _id_0), (_id_0 <= _capacity_0))), _id_0, _namespace_0, _selection_0, _state_0));
        continue;
      }
    }
  }
}

function $snapshot_fields$(_ns_0, _next_0, _capacity_0, _depth_0, _high_0, _live_0, _flag_0, _added_0, _changed_0, _mode_0, _values_0, _parts_0) {
  const _t_0 = _parts_0["fst"];
  const _mt_0 = _t_0["snd"];
  const _t_1 = _parts_0["snd"];
  const _t_2 = _t_1["fst"];
  const _at_0 = _t_2["snd"];
  const _t_3 = _t_1["snd"];
  const _lt_0 = _t_3["snd"];
  const _x_0 = ($handles$(_values_0));
  const _x_1 = ($U32$show$(_mode_0));
  const _x_2 = ("|" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ("|" + _x_3);
  const _x_5 = (_lt_0 + _x_4);
  const _x_6 = ($words_text$(($words$(_changed_0))));
  const _x_7 = ("|" + _x_5);
  const _x_8 = (_x_6 + _x_7);
  const _x_9 = ($words_text$(($words$(_added_0))));
  const _x_10 = ("|" + _x_8);
  const _x_11 = (_x_9 + _x_10);
  const _x_12 = ($flags$(_flag_0));
  const _x_13 = ("|" + _x_11);
  const _x_14 = (_x_12 + _x_13);
  const _x_15 = ($bools$(_live_0));
  const _x_16 = ("|" + _x_14);
  const _x_17 = (_x_15 + _x_16);
  const _x_18 = ("|" + _x_17);
  const _x_19 = (_at_0 + _x_18);
  const _x_20 = ("|" + _x_19);
  const _x_21 = (_mt_0 + _x_20);
  const _x_22 = ($U32$show$(_high_0));
  const _x_23 = ("|" + _x_21);
  const _x_24 = (_x_22 + _x_23);
  const _x_25 = ($Nat$show$(_depth_0));
  const _x_26 = (":" + _x_24);
  const _x_27 = (_x_25 + _x_26);
  const _x_28 = ($U32$show$(_capacity_0));
  const _x_29 = (":" + _x_27);
  const _x_30 = (_x_28 + _x_29);
  const _x_31 = ($U32$show$(_next_0));
  const _x_32 = ("|" + _x_30);
  const _x_33 = (_x_31 + _x_32);
  const _x_34 = ($U32$show$(_ns_0));
  const _x_35 = (":" + _x_33);
  return (_x_34 + _x_35);
}

function $owners$(_array_0) {
  if (_array_0.length === 1) {
    const _t_0 = _array_0[0];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": [{$: "None"}], "snd": "none"};
    } else {
      const _owner_0 = _t_0["value"];
      return $maybe_owned$(($owned$(_owner_0)));
    }
  } else {
    const _left_0 = _array_0.slice(0, _array_0.length >> 1);
    const _right_0 = _array_0.slice(_array_0.length >> 1);
    return $owners_join$({$: "Tuple", "fst": ($owners$(_left_0)), "snd": ($owners$(_right_0))});
  }
}

function $owned$(_owner_0) {
  const _items_0 = _owner_0["items"];
  const _scalar_0 = _owner_0["scalar"];
  return $owned_words$(_scalar_0, ($words$(_items_0)));
}

function $query$058struct_cols_finish$(_capacity_0, _depth_0, _high_0, _state_0) {
  const _main_0 = _state_0["main"];
  const _aux_0 = _state_0["aux"];
  const _live_0 = _state_0["live"];
  const _flags_0 = _state_0["flags"];
  const _added_0 = _state_0["added"];
  const _changed_0 = _state_0["changed"];
  const _values_0 = _state_0["values"];
  return $query$058struct_idx_finish$(_capacity_0, _depth_0, _high_0, {$: "query.StructIdxState", "main": _main_0, "aux": _aux_0, "metadata": {$: "storage.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "values": _values_0});
}

function $query$058struct_idx_advance$1260$(_valid_0, _id_0, _namespace_0, _selection_0, _state_0) {
  if (!_valid_0) {
    return _state_0;
  } else {
    const _main_0 = _state_0["main"];
    const _aux_0 = _state_0["aux"];
    const _live_0 = _state_0["live"];
    const _flags_0 = _state_0["flags"];
    const _added_0 = _state_0["added"];
    const _changed_0 = _state_0["changed"];
    const _values_0 = _state_0["values"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $query$058struct_cols_live$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, {$: "Tuple", fst: _live_0, snd: _live_0[_x_0 % _live_0.length]});
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $bools$(_values_0) {
  if (_values_0.length === 1) {
    const _t_0 = _values_0[0];
    if (!_t_0) {
      return "0";
    } else {
      return "1";
    }
  } else {
    const _left_0 = _values_0.slice(0, _values_0.length >> 1);
    const _right_0 = _values_0.slice(_values_0.length >> 1);
    const _x_0 = ($bools$(_right_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($bools$(_left_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("(" + _x_4);
  }
}

function $flags$(_values_0) {
  if (_values_0.length === 1) {
    const _t_0 = _values_0[0];
    if (_t_0.$ === "None") {
      return "0";
    } else {
      return "1";
    }
  } else {
    const _left_0 = _values_0.slice(0, _values_0.length >> 1);
    const _right_0 = _values_0.slice(_values_0.length >> 1);
    const _x_0 = ($flags$(_right_0));
    const _x_1 = (_x_0 + ")");
    const _x_2 = ($flags$(_left_0));
    const _x_3 = ("," + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("(" + _x_4);
  }
}

function $words_text$(_result_0) {
  const _text_0 = _result_0["snd"];
  return _text_0;
}

function $words$(_array_0) {
  if (_array_0.length === 1) {
    const _value_0 = _array_0[0];
    return $words_leaf$(_value_0);
  } else {
    const _left_0 = _array_0.slice(0, _array_0.length >> 1);
    const _right_0 = _array_0.slice(_array_0.length >> 1);
    return $words_join$({$: "Tuple", "fst": ($words$(_left_0)), "snd": ($words$(_right_0))});
  }
}

function $handles$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "end";
  } else {
    const _t_0 = _values_0["head"];
    const _ns_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _tail_0 = _values_0["tail"];
    const _x_0 = ($handles$(_tail_0));
    const _x_1 = ($U32$show$(_id_0));
    const _x_2 = (";" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($U32$show$(_ns_0));
    const _x_5 = (":" + _x_3);
    return (_x_4 + _x_5);
  }
}

function $maybe_owned$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return {$: "Tuple", "fst": [{$: "Some", "value": _owner_0}], "snd": _text_0};
}

function $owners_join$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _left_0 = _t_0["fst"];
  const _lt_0 = _t_0["snd"];
  const _t_1 = _result_0["snd"];
  const _right_0 = _t_1["fst"];
  const _rt_0 = _t_1["snd"];
  const _x_0 = (_rt_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_lt_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_left_0, _right_0), "snd": ("(" + _x_2)};
}

function $owned_words$(_scalar_0, _result_0) {
  const _items_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ($U32$show$(_scalar_0));
  const _x_1 = ("@" + _x_0);
  return {$: "Tuple", "fst": {$: "Owned", "items": _items_0, "scalar": _scalar_0}, "snd": (_text_0 + _x_1)};
}

function $query$058struct_idx_finish$(_capacity_0, _depth_0, _high_0, _state_0) {
  const _main_0 = _state_0["main"];
  const _aux_0 = _state_0["aux"];
  const _metadata_0 = _state_0["metadata"];
  const _values_0 = _state_0["values"];
  return {$: "Tuple", "fst": {$: "storage.Rows", "main": _main_0, "aux": _aux_0, "metadata": _metadata_0, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": ($List$reverse$(_values_0))};
}

function $query$058struct_cols_live$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _flags_0, _added_0, _changed_0, _result_0) {
  const _live_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return {$: "query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $query$058struct_idx_metadata$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, true, {$: "Tuple", fst: _flags_0, snd: _flags_0[_x_0 % _flags_0.length]});
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $words_leaf$(_value_0) {
  return {$: "Tuple", "fst": [_value_0], "snd": ($U32$show$(_value_0))};
}

function $words_join$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _left_0 = _t_0["fst"];
  const _lt_0 = _t_0["snd"];
  const _t_1 = _result_0["snd"];
  const _right_0 = _t_1["fst"];
  const _rt_0 = _t_1["snd"];
  const _x_0 = (_rt_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_lt_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_left_0, _right_0), "snd": ("(" + _x_2)};
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $query$058struct_idx_metadata$1260$(_id_0, _namespace_0, _selection_0, _main_0, _aux_0, _values_0, _live_0, _added_0, _changed_0, _value_0, _result_0) {
  if (!_value_0) {
    const _flags_0 = _result_0["fst"];
    return {$: "query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _flags_1 = _result_0["fst"];
    const _flag_0 = _result_0["snd"];
    return $query$058struct_idx_selected$1260$(($query$058selected$(_selection_0, _flag_0)), _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_1, _added_0, _changed_0, _values_0, _flag_0);
  }
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $query$058struct_idx_selected$1260$(_include_0, _id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0) {
  if (!_include_0) {
    return {$: "query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $query$058struct_idx_main$1260$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, array_rmw(_main_0, _x_0, () => _x_1));
  }
}

function $query$058selected$(_selection_0, _flag_0) {
  if (_selection_0.$ === "query.Present") {
    if (_flag_0.$ === "None") {
      return false;
    } else {
      return true;
    }
  } else if (_selection_0.$ === "query.Absent") {
    if (_flag_0.$ === "Some") {
      return false;
    } else {
      return true;
    }
  } else {
    return true;
  }
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $query$058struct_idx_main$1260$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "query.StructColsState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _owner_0 = _t_0["value"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $query$058struct_idx_aux$1260$(_id_0, _namespace_0, _main_0, _owner_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, array_rmw(_aux_0, _x_0, () => _x_1));
  }
}

function $query$058struct_idx_aux$1260$(_id_0, _namespace_0, _main_0, _owner_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _flag_0, _result_0) {
  const _aux_0 = _result_0["fst"];
  const _a_0 = _result_0["snd"];
  return $query$058struct_idx_return$(((_id_0 - 1) >>> 0), _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, ($client$1260$({$: "storage.Handle", "namespace": _namespace_0, "id": _id_0}, _flag_0, _owner_0, _a_0)));
}

function $query$058struct_idx_return$(_index_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _result_0) {
  const _m_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _value_0 = _t_0["snd"];
  const _x_0 = {$: "Some", "value": _m_0};
  return {$: "query.StructColsState", "main": (_main_0[_index_0 % _main_0.length] = _x_0, _main_0), "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": {$: "Con", "head": _value_0, "tail": _values_0}};
}

function $client$1260$(_handle_0, _flag_0, _p_0, _u_0) {
  return $client_first$1260$(_u_0, ($query$058main_read$1260$(_p_0, {$: "Unit"})));
}

function $client_first$1260$(_u_0, _result_0) {
  const _p_0 = _result_0["fst"];
  const _first_0 = _result_0["snd"];
  return $client_second$1260$(_u_0, _first_0, ($query$058main_read$1260$(_p_0, {$: "Unit"})));
}

function $query$058main_read$1260$(_owner_0, _token_0) {
  return $getter$(_owner_0);
}

function $client_second$1260$(_u_0, _first_0, _result_0) {
  const _p_0 = _result_0["fst"];
  const _second_0 = _result_0["snd"];
  return $client_aux$1260$(_p_0, _first_0, _second_0, ($query$058aux_read$1260$(_u_0)));
}

function $getter$(_owner_0) {
  const _items_0 = _owner_0["items"];
  const _scalar_0 = _owner_0["scalar"];
  return $bump_return$(_scalar_0, {$: "Tuple", fst: _items_0, snd: _items_0[0 % _items_0.length]});
}

function $client_aux$1260$(_p_0, _first_0, _second_0, _result_0) {
  const _u_0 = _result_0["fst"];
  const _af_0 = _result_0["snd"];
  return $client_finish$1260$(_p_0, _first_0, _second_0, _af_0, ($query$058aux_read$1260$(_u_0)));
}

function $query$058aux_read$1260$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}};
  } else {
    const _owner_1 = _owner_0["value"];
    return $query$058aux_return$(($getter$(_owner_1)));
  }
}

function $bump_return$(_scalar_0, _result_0) {
  const _items_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  const _x_0 = ((_value_0 + 1) >>> 0);
  return $owned$({$: "Owned", "items": (_items_0[0 % _items_0.length] = _x_0, _items_0), "scalar": ((_scalar_0 + 1) >>> 0)});
}

function $client_finish$1260$(_p_0, _first_0, _second_0, _auxfirst_0, _result_0) {
  if (_auxfirst_0.$ === "Some") {
    const _af_0 = _auxfirst_0["value"];
    const _u_0 = _result_0["fst"];
    const _t_0 = _result_0["snd"];
    if (_t_0.$ === "Some") {
      const _asecond_0 = _t_0["value"];
      const _x_0 = ("/" + _asecond_0);
      const _x_1 = (_af_0 + _x_0);
      const _x_2 = ("/" + _x_1);
      const _x_3 = (_second_0 + _x_2);
      const _x_4 = ("/" + _x_3);
      return {$: "Tuple", "fst": _p_0, "snd": {$: "Tuple", "fst": _u_0, "snd": (_first_0 + _x_4)}};
    } else {
      return {$: "Tuple", "fst": _p_0, "snd": {$: "Tuple", "fst": _u_0, "snd": "unexpected-aux"}};
    }
  } else {
    const _u_1 = _result_0["fst"];
    return {$: "Tuple", "fst": _p_0, "snd": {$: "Tuple", "fst": _u_1, "snd": "unexpected-aux"}};
  }
}

function $query$058aux_return$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": _owner_0}, "snd": {$: "Some", "value": _value_0}};
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);