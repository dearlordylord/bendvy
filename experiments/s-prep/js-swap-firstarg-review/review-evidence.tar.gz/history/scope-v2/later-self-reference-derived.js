function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}
function receive(pair,tail){const a=pair.fst;const old=pair.snd;return {a,old,tail};}
function swap(a,i){const value=9;const tail=tail;return receive__swap_split_0((a), (i), (value),tail);}
console.log(JSON.stringify(swap([1,2],0,7)));


function receive__swap_split_0(__swap_fst, __swap_index, __swap_value, tail) {
 const __swap_at = __swap_index % __swap_fst.length;
 const __swap_snd = __swap_fst[__swap_at];
 __swap_fst[__swap_at] = __swap_value;
const a=__swap_fst;const old=__swap_snd;return {a,old,tail};}
