const __pool_token_0 = Object.freeze({$: "types.PositionToken"});
const __pool_token_1 = Object.freeze({$: "types.VitalsToken"});
const __pool_token_2 = Object.freeze({$: "types.MotionLedgerToken"});
const __pool_token_3 = Object.freeze({$: "types.HealthLedgerToken"});
function readToken(token){return token.$;}
function reads(){
  const retained=__pool_token_0;
  const same=__pool_token_0;
  const opposite=__pool_token_1;
  const motionLedger=__pool_token_2;
  const healthLedger=__pool_token_3;
  return {reads:[readToken(retained),readToken(same),readToken(opposite),readToken(motionLedger),readToken(healthLedger)],sameTag:retained.$===same.$,oppositeTag:retained.$===opposite.$};
}
console.log(JSON.stringify(reads()));
